# V141 — Chain cleanup and legacy removal

## Scope
This V141 is based on the previously audited V140 and preserves the approved game systems. It fixes only confirmed root issues from the V140 full-cycle audit and removes obsolete helpers/tests.

## Confirmed root fixes
- AI facilities are persistent and advance using the same official FacilityEngine costs and levels as the player.
- AI facility state is carried through weekly technical development and season transitions.
- AI Marketing level is synchronized into the sponsorship engine before sponsorship generation/advancement.
- AI financial snapshots now persist facility levels and restore old snapshots with initial-level fallback.
- Secondary sponsorship pool now contains exactly the 20 non-Master sponsors in each category. Master remains exactly 10 per category.

## Legacy cleanup
- Removed obsolete FacilityEngine.simulatorEfficiency(). The active simulator rule is simulatorPerformanceMultiplier().
- Removed obsolete DriverEvolutionEngine.phaseFor(), which encoded the superseded phase semantics. The active continuous cycle is handled by the current evolution state machine.
- Removed the obsolete V83 evolution-cycle test that asserted the superseded phaseFor contract.

## Preserved compatibility
- TeamCarState remains because it is still an approved compatibility/financial bridge; it is not the physical race-car source of truth.
- Historical documentation/audit files remain because they are useful version history and are not runtime dead code.

## Validation target
The next audit must specifically prove:
1. AI facilities survive multiple weeks and a season transition.
2. AI Marketing upgrades affect sponsorship category generation.
3. Secondary offers are drawn only from the 20 secondary sponsors of the selected category.
4. No production caller references removed legacy helpers.
5. Two-season chain still completes without regression.
