# Auditoria V375 — Pré-validação da simulação instantânea

## Escopo
A validação de configuração e participantes acontece antes de `engine.start()`, para evitar mutação parcial do estado quando os dados de entrada do GP são inválidos.

## Alterações verificadas
- 80 pilotos e IDs únicos.
- 40 equipes distintas, dois pilotos por equipe e nome de equipe consistente.
- Equipe do jogador com exatamente dois pilotos.
- Circuito com ID/nome/distância/tempo-base válidos e riscos finitos entre 0 e 1.
- Dois testes JUnit adicionados à classe de integração já existente.

## Estado de execução
- Inspeção estática das alterações: concluída.
- Execução JUnit/Gradle: pendente; este pacote não inclui Gradle Wrapper e o ambiente não possui Gradle instalado.
- Build Android: pendente.
- Simulação de duas temporadas com persistência Android: pendente.

## Preservação
A interface, os botões, o histórico de versões e os assets externos não foram alterados.
