# V665 — recuperação de desempenho da IA

- Cache limitado para a projeção financeira de patrocínios da temporada atual e seguinte, compartilhado entre chamadas repetidas do fluxo financeiro semanal.
- Chave do cache inclui equipe, temporada, GPs concluídos, níveis comerciais, carteira atual e futura, ledger de GPs processados e posição competitiva usada no cálculo de bônus.
- Alterações reais de contratos, marketing ou ledger geram uma nova projeção; restauração de save limpa o cache.
- Ranking-base das equipes é calculado uma única vez por instância do motor.
- Nenhuma regra de receita, contrato, bônus ou investimento foi removida ou simplificada.
