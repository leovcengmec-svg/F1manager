# Auditoria V744 — correção de compilação do V743

## Erro relatado pelo GitHub Actions

O compilador apontou `Unresolved reference: FacilityEngine` em `CareerPreferences.kt:3680`. A classe/objeto existe em `com.f1teammanager.core.manager.FacilityModels.kt`; `CareerPreferences.kt` pertence ao pacote raiz `com.f1teammanager` e não tinha importado esse símbolo.

## Correção

- Incluído `import com.f1teammanager.core.manager.FacilityEngine` em `CareerPreferences.kt`.
- Nenhuma regra financeira, de contratação ou instalações foi modificada por esta correção.
- Versionamento avançado para `versionCode=744` e `versionName=0.744.0`.
- Todas as alterações funcionais da V743 foram preservadas.

## Verificações disponíveis

- Confirmada a declaração `FacilityEngine` em `core/manager/FacilityModels.kt`.
- Confirmado que o import novo corresponde ao pacote declarado pela classe.
- Confirmado que a referência reportada em `CareerPreferences.kt` agora tem import explícito.
- Confirmados `versionCode=744`, `versionName=0.744.0` e `package_manifest.txt` alinhado.

A compilação Gradle/Android não foi executada neste ambiente, pois não há Gradle instalado nem Gradle Wrapper incluído no projeto. A validação final do APK deve ocorrer no GitHub Actions.
