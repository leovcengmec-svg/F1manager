# V349 — Identidade explícita por temporada e rodada

- Os resultados oficiais agora têm uma chave canônica `race_<temporada>_<rodada>`.
- `isRaceRecorded` verifica a chave canônica; a chave legada sem temporada só é considerada na temporada 1 para não bloquear corridas homônimas em temporadas posteriores.
- A gravação continua mantendo `race_<rodada>` como alias de compatibilidade temporária com leitores antigos.
- A leitura do histórico prioriza a chave da temporada atual e usa a chave legada como fallback.
- Nenhuma alteração de interface.

Validação: revisão estática e verificação de integridade do ZIP. Build Android e JUnit não executados neste ambiente.
