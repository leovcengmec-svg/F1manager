# Auditoria V602 — Calendário, simulação instantânea e regra de nova carreira

## Regra oficial
Cada atualização funcional deve ser validada com uma carreira criada pelo fluxo Novo Jogo. Não usar saves anteriores para aprovar o comportamento atualizado. Recursos de save permanecem disponíveis e nenhum save é apagado automaticamente.

## Causa principal corrigida
Na V601, o botão **PULAR FIM DE SEMANA** estava habilitado enquanto `currentWeek <= round.weekOfSeason`. A função também avançava todas as semanas livres até a semana do GP e então o simulava. Isso permitia disparar uma ação chamada de simulação instantânea antes da semana designada, o que poderia saltar o calendário do ponto de vista do jogador.

## Correções implementadas
1. O botão instantâneo agora fica habilitado somente quando `currentWeek == round.weekOfSeason` e não há sessão incompleta em andamento.
2. A função instantânea não avança mais o calendário. A função de avançar até a próxima corrida é responsável pelo tempo anterior ao GP.
3. A mesma função guarda contra um índice/semana de UI obsoleto em relação ao estado persistido; sincroniza e pede uma segunda tentativa em vez de simular.
4. O início interativo do fim de semana usa a mesma validação de calendário e retoma a sessão pendente em vez de reinicializá-la.
5. A finalização valida a temporada ativa, o `roundIndex` persistido, o número do próximo GP e sua semana programada antes de aplicar qualquer efeito colateral. Resultados fora de sequência são interrompidos com erro explícito.
6. Avanço semanal é bloqueado se atravessaria a semana do próximo GP, se a semana programada já tiver passado ou se o GP da semana atual ainda estiver pendente.
7. Adicionado `RaceCalendarGuard` puro e testes JUnit para semana exata, simulação antecipada, tardia, rodada exibida divergente, sessão em andamento e rodada inexistente.

## Performance
As validações executam apenas nas ações de abertura/simulação/finalização e avanço semanal. Não foram introduzidos loops adicionais no frame de UI.

## Testes
- Teste estático V602: 12/12 aprovados.
- Auditoria estrutural do projeto: a executar após o changelog desta versão.
- Auditoria estrutural de release: a executar após o changelog desta versão.
- Android Gradle Build/JUnit/device: não executados neste ambiente, portanto a versão é candidata, não homologada.

## Arquivos alterados
- `MainActivity.kt`
- `core/race/RaceCalendarGuard.kt` (novo)
- `core/race/RaceCalendarGuardTest.kt` (novo)
- `tools/race_sim_test/v602_calendar_guard_static_test.py` (novo)
- `REGRA_NOVA_CARREIRA_A_CADA_ATUALIZACAO.md` (novo)
- `README.md`, `CHANGELOG.md`, `CHANGELOG_V602.md`
- `app/build.gradle.kts` -> `versionCode 602`, `versionName 0.602.0`

## Resultado final da verificação da distribuição
- 14/14 verificações estáticas específicas passaram.
- 5/5 testes de fumaça executados com `kotlinc` para a função pura `RaceCalendarGuard` passaram.
- 25/25 asserções de calendário passaram para cinco sementes: 30 rodadas, numeração 1–30, semanas oficiais ordenadas e 30 circuitos distintos.
- `tools/race_sim_test/validate_project.py`: 40/40.
- `tools/race_sim_test/final_release_audit.py`: 25/25 estrutural.
- ZIP: verificação `testzip()` passou; todos os 195 arquivos no caminho de assets foram hash-comparados sem alteração; 529 documentos de auditoria/changelog anteriores à V602 foram comparados sem alteração.

## Limite de homologação
Este ambiente não tem Gradle disponível, não contém `gradlew` no projeto e não tem `ANDROID_HOME`; portanto, a compilação Android, a suíte JUnit completa e o teste no dispositivo não foram executados. A V602 permanece candidata até o workflow Build Debug APK executar com sucesso.
