# V45 — Evolução natural + desempenho como aproveitamento

## Regra fechada
- O tipo de evolução mantém sua velocidade natural.
- O limite máximo anual é por atributo: Prodígio 15, Auge rápido 13, Auge moderado 11, Auge tardio 10, Normal 8, Demorado 6.
- O desempenho não reduz a velocidade do tipo e nunca transforma esta evolução em regressão.
- O desempenho determina apenas a fração do potencial anual que pode ser aproveitada:
  - Excepcional 100%
  - Excelente 90%
  - Muito bom 80%
  - Bom 70%
  - Normal 60%
  - Abaixo do esperado 45%
  - Ruim 30%
  - Muito ruim 15%
- O orçamento anual é calculado para os 7 atributos. Não há divisão do limite por 7.
- A evolução é distribuída pelos 30 GPs, usando banco fracionário para manter progressão contínua.
- O teto absoluto da Classe continua sendo aplicado e excedentes positivos são redistribuídos para atributos elegíveis.
- Regressão não é mais causada pelo simples desempenho ruim deste mecanismo; permanece como mecanismo separado.

## Validação
- Core Kotlin compilado sem erros.
- EvolutionPerformanceCapTest: PASS.
- Simulação matemática de 30 GPs confirma que o orçamento normal do Prodígio equivale a 9 pontos médios por atributo (15 x 60%), sem dividir 15 por 7.
