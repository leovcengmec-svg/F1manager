# V601
- Reconciles live driver-market contracts against editable team rosters so new/edited teams can enter an existing career without a stale grid.
- Adds a 41-team / 82-driver market migration regression test and clearer grid preflight diagnostics.
- Avoids replaying each AI team's physical development twice at the race boundary by reusing the current week's computed garage.
- Preserves the official ZIP filename, historical files and external asset structure.
- Android build and device end-to-end validation remain pending.
