# V601 — Auditoria e correção do ciclo de evolução dos pilotos

## Falhas encontradas na V600
- A pressão por resultados ruins podia mudar a fase de crescimento para regressão antes dos cinco anos definidos.
- O comprimento das fases variava conforme o tipo de evolução, em vez de respeitar a curva acordada de 5/2/5 anos.
- A evolução normal passava um contador de ganhos zerado em cada GP, invalidando o limite anual por atributo.

## Correções
- Curva única de 5 anos de evolução, 2 anos de auge e 5 anos de regressão (12 anos por ciclo), tanto na carreira normal quanto no motor de Team Principal.
- Resultados da corrida continuam afetando o ritmo, mas não antecipam nem encurtam as fases.
- Ganhos positivos agora usam e persistem os contadores por piloto e temporada, respeitando o limite anual da categoria de evolução.
- Teto por atributo continua vindo da classe: Fraco 59, Médio 69, Forte 79, Pro 89 e Lenda 100.

## Validação
- Auditorias estáticas de projeto e release executadas após as alterações.
- Build Android/JUnit/emulador não executados neste ambiente; requer validação integrada.
