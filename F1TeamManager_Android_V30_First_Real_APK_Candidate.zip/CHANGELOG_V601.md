# V601 — Correção geral de identidade e evolução dos pilotos

## Alterações
- Substitui a exceção exclusiva de Felipe por um mecanismo geral de identidade persistida `driverId -> nome normalizado`.
- Em saves com ledger de identidade, se um ID passar a representar outro piloto, reinicializa apenas os atributos e estados de evolução/baseline daquele ID, preservando os demais pilotos.
- Em saves legados sem ledger, preserva atributos válidos (não presume que Overall baixo seja corrupção) e registra a identidade atual para evitar novas colisões futuras.
- Conecta a tabela de ratings dedicada aos 20 pilotos reservas à construção do elenco canônico.
- Mantém a correção da V600 para usar o elenco atual no plano de pneus.

## Limitações
- Saves legados sem identidade histórica não permitem saber com certeza quem ocupava cada ID antes da atualização; são preservados sem reset destrutivo.
- Build Android, JUnit e teste em dispositivo ainda pendentes.
