# V402 — Corrigir corte do Overall no plano de pneus

- Aumentada a altura do card `GERAL` de 48 dp para 60 dp, preservando a largura de 46 dp.
- Definidas alturas de linha explícitas para o rótulo e o valor, evitando corte vertical do número.
- Mantidos tamanho da fonte do valor, cores, alinhamento e restante do layout do piloto.
- Nenhuma alteração na lógica de estratégia ou simulação.
