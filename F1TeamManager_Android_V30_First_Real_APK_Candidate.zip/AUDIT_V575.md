# Auditoria V575

## Mudanças

1. Implementada prévia de recuperação não destrutiva em `CustomWorldCatalog.prepareRecovery()`.
2. A proposta verifica estrutura, nomes, IDs, faixas de atributos, nomes de arquivos e dependências entre equipes/pilotos.
3. `applyRecovery()` verifica se a origem continua idêntica à prévia, salva cópia integral das três fontes brutas e só então grava a proposta.
4. O carregador de produção valida o resultado. Se houver inconsistência, tenta restaurar os valores originais e mantém o backup de recuperação.
5. A tela de cadastros mostra contagens, itens descartados da proposta e confirmação explícita antes da aplicação.

## Preservação

- Nenhum arquivo preexistente foi removido.
- As chaves originais `pilots`, `teams` e `countryFlags` permanecem as mesmas.
- Os backups usam chaves locais exclusivas por execução e preservam os textos brutos antes da recuperação.
- A recuperação não escreve em preferências de carreira/mercado, contratos, finanças, resultados ou calendário.
- Assets, IDs oficiais e histórico de versões são preservados no pacote.

## Limitações de validação

- `unzip -t` foi executado.
- Testes foram adicionados, mas não executados.
- Build Android e execução em dispositivo não foram confirmados porque o ambiente não dispõe de Gradle nem do wrapper do projeto.
