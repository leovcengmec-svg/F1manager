# V610 — Novos cards de evento exclusivos na Home

Base oficial: V609 (0.609.0). Mantida a estrutura e os assets externos existentes.

## Alterações
- Adicionado card visual de instalação concluída, apresentado a partir da notificação da equipe do jogador.
- Adicionado card visual para conclusão do programa de desenvolvimento do piloto, usando a notificação da carreira do jogador.
- Adicionado card de janela de transferência aberta, com acesso direto ao mercado de pilotos.
- Cards usam imagens genéricas realistas já presentes no pacote (`event_annual_facility_upgrade`, `notice_driver_development`, `notice_market_offer`); nenhuma imagem nova foi gerada ou adicionada.
- Cards seguem o estilo grafite/vermelho, respeitam rolagem vertical e abrem Notícias/Mercado pelos callbacks existentes.
- A lógica da simulação e os motores de processamento não foram alterados intencionalmente.

## Validação e limitações
- Verificação estática dos novos cards, referências de imagens e versionamento.
- Não foi possível executar testes Gradle/Android neste ambiente porque o ZIP não contém `gradlew` e não há wrapper disponível no projeto extraído.
- Compilação Android e validação visual em dispositivo/emulador permanecem pendentes.
