# Auditoria V667 — Minha Carreira e apoio da diretoria

## Correções

1. O retrato `team_principal_manager_portrait` foi mantido no cartão superior, com opacidade aumentada para 82% e gradiente suavizado para não encobrir a imagem.
2. Removido o badge amarelo de contagem de objetivos do cabeçalho.
3. A área de contrato/metas passou de 58/62 dp para 78/82 dp. O cartão de objetivos ganhou 20 dp para evitar reduzir a altura dos seis objetivos.
4. O cartão de conquistas deixou de renderizar a legenda secundária truncada; a superfície inteira segue clicável.
5. Confiança inicial ajustada para 50/100. `acceptOffer` reinicia confiança a 50 ao mudar de equipe; `renew` mantém o valor da equipe atual.
6. O indicador exibido na tela usa `TeamPrincipalLiveBoardAssessment`, que calcula apoio projetado e risco de demissão a partir da mesma avaliação em tempo real. A projeção usa a rotina de liquidação da temporada e só passa a variar com evidência esportiva durante a temporada; antes da primeira evidência permanece no baseline de 50.
7. Saves V666 em contrato ainda não iniciado, sem temporadas registradas e com o antigo valor padrão 75, migram para 50. Saves com temporada concluída preservam a confiança histórica.

## Verificações automatizadas

- Teste de confiança inicial e reset na troca de equipe.
- Teste de preservação de confiança na renovação da mesma equipe.
- Teste que compara projeção com objetivos cumpridos versus não cumpridos e classificação ruim.
- Teste de migração de save V666 ainda sem temporada.
- Auditoria estática V667 para layout, vínculo de tela e metadados de versão.

## Limites

A compilação Android completa e testes instrumentados em dispositivo dependem do Gradle/Android SDK. Esta revisão foi validada por testes e auditorias locais disponíveis no ambiente; o APK não é declarado como compilado aqui.
