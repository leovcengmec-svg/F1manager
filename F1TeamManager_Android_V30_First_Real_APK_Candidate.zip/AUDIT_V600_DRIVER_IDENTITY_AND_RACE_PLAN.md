# Auditoria V600 — Pilotos e plano de início da corrida

## Causa observada
1. `DriverStartStrategyBlock` procurava pilotos em `WorldDatabase.drivers`, a lista-base de 80 pilotos. A carreira usa `currentDrivers()` com contratos e transferências, incluindo reservas contratados. Isso fazia a UI exibir bandeira, equipe e Overall como vazios.
2. O save pode conter ratings antigos associados ao ID agora usado por Felipe Drugovich. A migração V600 detecta apenas o caso de incompatibilidade forte com o perfil canônico de Felipe e limpa a fase/banco de evolução desse ID, sem resetar o elenco inteiro.

## Alterações
- Passagem explícita do catálogo atual de carreira até o diálogo de início da corrida.
- Lookup de pilotos por ID no catálogo atual.
- Reparação pontual de identidade para Felipe Drugovich e limpeza apenas das entradas de evolução dele.
- Versionamento: 600 / 0.600.0.

## Limitações
Não foi possível executar o build Android/JUnit/emulador neste ambiente. A alteração ainda exige Build Debug APK e teste em corrida real.
