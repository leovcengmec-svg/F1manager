# F1 Team Manager — V363

## Bloco: ativação da validação integrada de duas temporadas

- Promovido o teste `TwoSeasonChainAuditTest` de uma função `main()` manual para um teste JUnit 4 descoberto pelo Gradle.
- O teste percorre 60 rodadas, confirma as duas transições de temporada, o reinício em GP1 e a presença de 80 contratos ativos após cada rodada.
- Também valida a manutenção dos dados de evolução dos 100 pilotos e a ausência de movimentos de mercado vencidos após a segunda transição.
- Atualizado `versionCode` para 363 e `versionName` para `0.363.0`.
- Nenhuma alteração de interface, botões ou assets externos.

## Limitação

O teste foi conectado ao JUnit, mas ainda não foi executado nesta sessão: o ZIP não inclui `gradlew` e não há instalação local de Gradle. O build Android e a simulação real de duas temporadas com o serviço instantâneo continuam pendentes.
