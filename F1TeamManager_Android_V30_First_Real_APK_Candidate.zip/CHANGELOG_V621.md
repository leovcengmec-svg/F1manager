# V621 — Correção da interpolação do ranking da revelação do carro

- Corrigida a interpolação Kotlin de `teamRank`: `${teamRank}º` evita a referência inválida `teamRankº`.
- Preservada a versão V620 como base; mantidas as correções anteriores, os arquivos Gradle da raiz e os 195 assets.
- Validação local: string de destino confirmada, nenhuma outra interpolação do padrão `$identificadorº` encontrada no código principal, versão conferida.
- O build Android completo deve ser reexecutado pelo pipeline.
