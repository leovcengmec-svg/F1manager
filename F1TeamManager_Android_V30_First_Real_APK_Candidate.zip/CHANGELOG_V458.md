# V458 — Menu inicial funcional

- Adicionado menu inicial em Jetpack Compose com Novo Jogo, Continuar Jogo e Configurações.
- Menu inicial passa a ser a primeira tela após abrir o APK.
- Novo Jogo reutiliza a seleção de equipe e o fluxo de criação de carreira existentes.
- Continuar Jogo respeita carreira salva e eventos pendentes.
- Criado fundo genérico de garagem para a tela inicial.
- Cards com ícones vetoriais, layout responsivo e rolagem vertical desativada.
- Versão Android: 0.458.0.

A compilação Android não foi executada neste ambiente.
