# V568 Audit

Scope: durable constructor-points history across app restarts and season rollover.

- Key is scoped by season and round; legacy round-only keys are not used.
- Save is idempotent: same season/round replaces the previous snapshot rather than incrementing totals.
- Season totals are derived from stored per-round snapshots to avoid separate aggregate drift.
- Invalid season/round inputs are rejected; malformed stored JSON returns null rather than crashing career load.
- Race finalization uses a journaled step and checks durable commit success.

Not verified here: Android compilation, runtime SharedPreferences behavior on device, and full two-season simulation.
