# V739 — Validação e limitações de build

## Verificações executadas
- Compilação Kotlin isolada de `SponsorContractPricing.kt` com `kotlinc`: aprovada.
- Harness de testes executável: aprovou limites Básico/Global, progressão sem sobreposição, máximos Globais e tetos absolutos.
- Inspeção estática de `MainActivity.kt`: atributos em 58 dp, tipografia restaurada e mensagem redundante ausente.
- Verificação da integração: `TeamSponsorshipEngine.buildContract` utiliza `categoryBasedOfferAmounts` para propostas novas.
- ZIP: `unzip -t` aprovado; manifest VersionCode 739 e VersionName 0.739.0 confirmados.
- Pacote não contém quadros de vídeo ou anexos temporários da auditoria.

## Não executado
O build Android completo e a suíte JUnit não foram executados nesta sessão: o pacote não contém `gradlew`/`gradle-wrapper` e não há instalação de `gradle` ou Android SDK disponível no ambiente. Portanto, o APK ainda precisa ser validado pelo GitHub Actions.
