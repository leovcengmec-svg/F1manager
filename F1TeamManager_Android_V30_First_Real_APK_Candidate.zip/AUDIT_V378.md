# Auditoria V378 — Bloco 2

## Resultado da execução integrada
- `tools/race_sim_test/TwoSeasonChainRuntimeAudit.kt` compilado com `kotlinc` junto aos módulos reais `core/manager`, `core/race` e `core/season` e executado: **PASS**.
- Resultado: **60 GPs**, temporadas 2026 e 2027 concluídas, transição final para 2028 GP1, 65.340 pontos somados no conjunto das classificações, 80 pilotos ativos, estado de evolução dos 100 pilotos e 60 marcadores de evolução por GP.
- Verificadas em cada GP: 80 classificados sem IDs duplicados, posições 1–80, qualificação Q1/Q2/Q3 80/50/20, pontos não negativos, orçamento do jogador não negativo, manager/calendário sincronizados, garagem com dois carros e marcador de evolução presente.
- Verificados: patrocínio de 30 corridas expira no GP30, premiações das temporadas 2026 e 2027 registradas, 60 chaves salariais sem descarte de obrigações e mercado sem movimentações vencidas pendentes.
- `TwoSeasonChainAuditTest` executado com harness local compatível com as assertions JUnit: **PASS**. Isto valida o corpo do teste, mas não equivale ao runner oficial JUnit.
- `FullSeasonIntegrationTest` compilado e executado separadamente: **PASS**, 30 GPs, transição para 2027 GP1, 80 pilotos ativos, 20 livres, evolução inicializada para 100 pilotos e 428 notificações.
- Auditoria estática `tools/race_sim_test/validate_project.py`: **32/32 PASS**.

## Limites explícitos
- O teste de 60 GPs executa o motor de temporada integrado real em modo headless. Não simula a camada Android `SharedPreferences` nem a interação visual da tela de resultado.
- Gradle/Gradle Wrapper não está disponível; build Android e suíte JUnit oficial continuam pendentes e não são declarados aprovados.
- A auditoria de instalação e pacote Android final pertence ao Bloco 3.

## Preservação
- `versionCode = 378`, `versionName = 0.378.0`.
- Sem alterações de layout, botões ou assets externos.
- Histórico de versões preservado.
