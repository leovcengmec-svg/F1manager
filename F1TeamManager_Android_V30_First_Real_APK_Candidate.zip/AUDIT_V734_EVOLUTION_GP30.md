# Auditoria e correção V734 — progressão de Overall e finalização do GP30

Base técnica: código-fonte V733. Versão: 0.734.0 / VersionCode 734.

## 1. Erro do calendário: etapa `ai_canonical_next_season_garages` ausente

### Causa

A imagem apresenta a mensagem:

> A finalização do GP 30 da temporada 2029 ficou pendente: Etapa `ai_canonical_next_season_garages` não faz parte do plano do GP 30/2029.

O fluxo de `MainActivity.kt` executava a etapa `ai_canonical_next_season_garages` depois da liquidação de `season_prizes`, mas `RaceFinalizationPlan.steps()` não incluía esse identificador. `RaceFinalizationJournal.runStep()` valida cada etapa contra a lista oficial e lança `IllegalArgumentException` quando o identificador não faz parte do plano. A exceção é capturada pelo fluxo de finalização e apresentada no calendário como etapa pendente.

### Correção

- Declarada a constante `RaceFinalizationPlan.AI_CANONICAL_NEXT_SEASON_GARAGES` com o identificador persistido exato.
- O plano inclui a etapa somente no GP final: `SEASON_PRIZES` → `AI_CANONICAL_NEXT_SEASON_GARAGES` → `PERSIST_FINAL_STATE`.
- `MainActivity` usa a constante do plano, reduzindo a possibilidade de divergência entre strings.
- A chave da etapa é nova e específica; os marcadores V733 anteriores não são apagados nem renomeados.
- Saves interrompidos depois de `SEASON_PRIZES` podem retomar diretamente a etapa canônica. Não é necessário simular novamente o GP30.
- O checkpoint usa fingerprint determinístico e `AtomicFile`; uma repetição idempotente regrava o mesmo arquivo de abertura para a mesma equipe/temporada/fingerprint antes de o diário confirmar a etapa.

### Cobertura

`RaceFinalizationCanonicalGarageV734Test.kt` verifica: presença e ordem da etapa somente no GP30; retomada de um diário equivalente a um save V733 cujo último marcador é `SEASON_PRIZES`; execução idempotente; persistência final e conclusão; bloqueio se os prêmios ainda não foram liquidados.

## 2. Evolução dos cinco pontos extras

### Causa

A V733 reutilizava a nota normal de GP para liberar a faixa adicional. A nota normal trata qualquer resultado dentro da margem de ±3 posições como neutro (105). Para os pilotos de carros P1/P2, a própria meta podia ser P1/P2; assim, poles e vitórias permaneciam dentro da faixa e não elevavam a média até os limiares 110–150. Além disso, a margem calculada a partir da média acumulada não era protegida por um número mínimo de corridas, e o caminho de piloto Pro livre não recebia amostra suficiente de uma temporada anterior.

### Correção

- O índice normal (`gpPerformanceIndex`) não foi alterado: continua baseado nos centros de meta exclusivamente derivados da força do carro, tolerância de ±3 e pesos de 40% para classificação / 60% para corrida. Continua sendo a origem da evolução e regressão esportivas normais.
- Criado um índice separado (`classUnlockPerformanceIndex`) usado apenas para a faixa adicional. Ele considera a diferença entre posição real e centro da meta do carro, e reconhece pole position e vitória com bônus específico. Assim, o piloto de equipe líder cuja meta já é P1 consegue demonstrar desempenho excepcional por poles e vitórias, sem misturar atributos do piloto na meta.
- O desbloqueio exige pelo menos cinco GPs reais contabilizados. Uma corrida isolada, mesmo com pole e vitória, não abre a faixa.
- Mantida a tabela de liberação: média 110/120/130/140/150 concede +1/+2/+3/+4/+5.
- `nextEarnedClassMargin` mantém o maior nível já conquistado na temporada; quedas posteriores da média não retiram margem já aberta.
- A evidência e a margem são persistidas por temporada no fluxo de carreira.
- Piloto Pro sem equipe só utiliza média e margem da última temporada completa com resultados reais. Não são criados resultados sintéticos durante a ausência de contrato.
- O Team Manager aplica a mesma nota separada, contagem real de GPs e margem persistida.
- O Centro de Desenvolvimento recebe média, número de amostras e margem já conquistada. Pontos não aplicados permanecem reservados e são reaplicados quando o limite aumenta.

### Migração V733 → V734

Na primeira aplicação da evolução após a atualização, `migrateDriverClassUnlockScoringV734()` reconstrói a evidência a partir dos registros reais de classificação/corrida e dos snapshots de meta de temporada versão 4 (metas exclusivamente pelo carro). Para a temporada atual, exclui a corrida corrente se o tick de evolução ainda não foi processado; inclui-a somente quando o marcador idempotente informa que ela já foi processada. Isso evita contar o mesmo GP duas vezes. Evidência antiga de snapshots de meta com versão incompatível não é reinterpretada como meta válida.

## 3. Regras preservadas

- Metas de classificação e corrida continuam exclusivamente baseadas na força do carro.
- Pesos normais de 40%/60% e tolerância de ±3 permanecem intactos.
- Classes e tetos: Médio 69+5, Forte 79+5, Pro 89+5, Lenda 100; as condições por contrato permanecem iguais.
- Potencial individual continua sendo limite absoluto.
- Regressão esportiva normal, regressão por idade, ciclo 18–45, corte de 30%, piso de atributo 40 e limites anuais foram preservados.
- Avaliação bienal de promoção/rebaixamento permanece usando o histórico normal de desempenho, não o novo índice exclusivo de desbloqueio.

## 4. Validação executada

- 10 testes Kotlin focados passaram: índice normal preservado; pole/vitória para meta P1; pesos 40/60; mínimo de cinco GPs; margem monotônica; piloto Pro contratado; Pro livre com evidência da última temporada; liberação de pontos reservados do Centro de Desenvolvimento; plano GP30; retomada/idempotência do diário.
- Compilação isolada do núcleo Kotlin de evolução, do Centro de Desenvolvimento e do diário/plano de finalização passou.
- Foi tentada a compilação conjunta de todos os 84 arquivos Kotlin em `core/`, mas excedeu o limite de execução do ambiente; não é contabilizada como compilação aprovada.
- Não foi possível executar Gradle/JUnit completo nem `assembleDebug`: o pacote não contém Gradle Wrapper e o ambiente não disponibiliza Gradle nem Android SDK. Portanto, esta entrega é código-fonte atualizado; não se declara APK compilado.
