# V592 — Integridade do grid na virada de temporada

- Adicionada uma última etapa de reconciliação do grid após as negociações normais de pré-temporada.
- Quando uma equipe ainda tem menos de dois pilotos, o motor tenta alocar um agente livre elegível, desde que exista orçamento para a taxa de assinatura.
- A alocação emergencial é registrada em histórico e notificação, separada das transferências negociadas normalmente.
- O processo respeita contratos únicos por piloto e remove a disponibilidade de agente livre após a alocação.
- Adicionado teste de regressão para duas vagas por equipe, IDs de pilotos válidos e contratos sem duplicidade após a virada.

## Validação
- ZIP validado estruturalmente.
- Testes JUnit e build Android não executados neste ambiente; V592 não deve ser considerada compilada/homologada até executar a suíte Gradle.
