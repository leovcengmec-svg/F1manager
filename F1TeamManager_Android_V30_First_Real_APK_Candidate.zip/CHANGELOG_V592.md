# V592 — Redesenho do menu principal

- Mapeada a tela inicial real em `MainMenuScreen.kt` e substituído o layout anterior por uma composição adaptável baseada na referência aprovada.
- Cabeçalho, marca, separador vermelho, navegação e rodapé receberam dimensões e espaçamentos responsivos.
- Cards Novo Jogo, Continuar Jogo e Configurações usam a mesma estrutura e dimensões distribuídas igualmente, com textos em largura flexível e ícones/setas alinhados.
- Rolagem vertical permanece desativada na tela principal. A tela usa `statusBarsPadding()` e `navigationBarsPadding()` e reduz espaçamentos em alturas compactas.
- Preservados os callbacks existentes, o estado `hasCareer`, a tela de configurações, os assets e o histórico do projeto.
- Não houve mudança de lógica de carreira ou de persistência nesta atualização.
