# Auditoria V588 — Etapa 1: base dinâmica e edição completa

## Implementado
- A interface de cadastros separa Equipes, Pilotos e Bandeiras.
- A lista de equipes inclui a base oficial (IDs 1–40) e as equipes personalizadas. A edição usa os mesmos IDs e salva overrides persistentes.
- A lista de pilotos inclui a base oficial (IDs 1–100) e pilotos personalizados. A edição de pilotos salva nome, país, classe, evolução, sete atributos e nome de asset em overrides persistentes quando o ID pertence à base oficial.
- WorldDatabase aplica overrides sem alterar os identificadores históricos da definição original.
- Alterar a escalação de uma equipe atualiza o vínculo efetivo derivado da grade. Pilotos retirados da escalação deixam de ser vinculados à equipe; IDs históricos não são removidos.
- Classe inicial de equipe Fraco/Médio/Forte é persistida e usada para equipes personalizadas.
- Os campos de asset aceitam apenas nome de arquivo, evitando caminhos arbitrários.

## Validações estáticas executadas
- Delimitadores balanceados nos três arquivos Kotlin alterados.
- Conferência manual das chamadas de UI para os métodos de edição e persistência.
- ZIP testado com `zip -T` e aprovado.

## Não executado / pendente
- Compilação Android integral e suíte JUnit não executadas neste ambiente.
- É necessário executar Build Debug APK no GitHub Actions para confirmar a compilação Kotlin/Compose e corrigir eventuais incompatibilidades restantes.
- Edição de classe de equipe usa os níveis já existentes do jogo: Fraco (0), Médio (1), Forte (2). Assets originais não são renomeados automaticamente; o usuário edita o nome do asset explicitamente.
