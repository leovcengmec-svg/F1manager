# V569 — Correção de compilação do áudio dos boxes

- Corrigido o erro `Unresolved reference: externalAudio` no callback de decisão de box da tela de corrida.
- A tela `Race` agora recebe o callback `onBoxAudio`, fornecido por `F1ManagerApp`, mantendo o efeito sonoro `box_audio` exclusivamente na ação explícita do jogador de entrar nos boxes.
- Preservadas as alterações da V568 e incrementada a versão para `0.569.0`.

Validação: verificações estáticas e integridade do ZIP. Compilação Android precisa ser confirmada no pipeline de build.
