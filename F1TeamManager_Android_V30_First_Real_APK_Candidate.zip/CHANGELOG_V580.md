# V580
- Abertura de temporada agora usa o elenco resolvido da carreira e o carro persistido do jogador para calcular os rankings.
- Recomputação dos rankings também considera a temporada.
- Pendente: conectar estado real dos carros de todas as equipes de IA e validar com testes executáveis.
