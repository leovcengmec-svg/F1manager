# V580 — Fechamento integrado da cadeia dinâmica

## Alterações
- Corrigida a escala de classificação econômica para campeonatos expandidos: investimento técnico, descontos de P&D e descontos de fabricação usam o percentual do ranking atual, sem alterar as faixas históricas quando existem exatamente 40 equipes.
- A classificação real da equipe é preservada no estado de investimento; apenas a faixa econômica é normalizada para a escala histórica de 40 equipes.
- A evolução de pilotos agora aceita o tamanho real do grid na avaliação sazonal, em vez de fixar as expectativas de pontos, vitórias e pódios em 80 posições.
- Removidos fallbacks de ranking congelados em 40 nas telas/fluxos atuais, substituindo-os pela quantidade de equipes registradas.
- Criados testes de contrato para a escala de ranking original/expandida e harness reproduzível que acompanha catálogo → mercado → grade de 82 pilotos → classificação de construtores → premiações/patrocínios → investimento técnico/P&D/fábrica/evolução.
- Executada simulação headless de duas temporadas com 41 equipes e 82 pilotos ativos; 60 GPs foram concluídos e a carreira avançou para 2028 GP1.

## Preservação
- Base direta: V579.
- Nenhum arquivo da V579 foi removido.
- Todos os 195 arquivos de assets foram preservados por caminho e hash.
- Histórico, saves, contratos, finanças, calendário e testes anteriores foram mantidos.

## Limites conhecidos
- A compilação Android integral, suíte JUnit oficial, execução de Compose/SharedPreferences reais e teste de áudio em dispositivo não foram executados neste ambiente por ausência de Gradle/Gradle Wrapper e ambiente Android.
- A simulação de 60 GPs é headless, mas utiliza os motores de domínio reais incluídos na lista de fontes V580.
