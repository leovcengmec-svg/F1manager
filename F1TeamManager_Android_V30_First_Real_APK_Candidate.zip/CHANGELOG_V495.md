# V495 — Prévia de ganho tecnológico no P&D

- A tela de pesquisa mostra a faixa estimada de pontos de Performance e Confiabilidade antes de iniciar o projeto.
- A prévia reage ao nível de P&D, foco e complexidade selecionados.
- A estimativa usa a mesma faixa de melhoria, divisão por foco e limite de 100 pontos usados pela pesquisa real.
- Exibe a chance de falha correspondente à complexidade e explica que resultados parciais reduzem o ganho.
- Adicionado teste de regressão para divisão por foco, limite da peça e risco por complexidade.
