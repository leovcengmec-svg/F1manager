# V589 — Ranking novo ao reentrar em Novo Jogo

## Problema
Ao abrir Novo Jogo, sair sem escolher equipe e entrar novamente, `prepareNewCareerSelection()` reaproveitava `pendingCareerSeed`. O ranking de força e as três equipes mais fracas podiam repetir a seleção anterior. A tela também não usava a semente na chave de seus `remember`, permitindo cache antigo.

## Correção
- Sempre cria uma nova semente válida, diferente da seleção provisória anterior, a cada escolha de modo para Novo Jogo.
- Persiste a semente antes de exibir a tela.
- Passa `rankingSeed` a `TeamSelect` e inclui essa chave nos `remember` que calculam equipes, ordenação e valores exibidos nos cards.
- A prévia usa uma semente explícita, sem modificar a semente global de uma carreira existente que foi deixada salva.
- Se o jogador confirmar equipe, `startNewCareer()` consome a mesma `pendingCareerSeed` e só então configura a semente global da carreira; carro e ranking começam iguais aos apresentados na seleção.

## Verificação
Teste unitário adicionado para semente repetida, candidata válida, zero e limites de `Int`. A validação Gradle/Android não foi executada neste ambiente.
