# V674 — evolução dos pilotos e escala correta de metas

A V674 parte integralmente da V673 e corrige o balanceamento de evolução e a separação entre as duas classificações esportivas.

## Metas individuais
- O campeonato de construtores permanece na escala de 1 a 40 equipes.
- O campeonato de pilotos, o alvo de classificação e o alvo de corrida usam sempre a escala de 1 a 80 pilotos.
- Os dois modos de carreira verificam a grade de 80 pilotos contratados antes de construir metas, evitando que a classificação de 40 equipes seja reutilizada como ranking individual.
- A força real do carro e a habilidade do piloto continuam combinadas para criar metas diferentes entre companheiros de equipe.

## Evolução e abandonos
- A penalização por ultrapassar o teto da classe deixou de derrubar o crescimento natural para 15%; o fator mínimo passa a ser 60%. A classe continua influenciando a progressão, mas não bloqueia pilotos com potencial e desempenho.
- DNF por pane/falha mecânica, falta de combustível, pneu degradado e colisão sofrida usa a meta de corrida como referência neutra, sem transformar automaticamente a falha em baixo desempenho do piloto. A posição de classificação segue sendo avaliada.
- Acidente iniciado pelo próprio piloto continua sendo avaliado como resultado esportivo.
- O potencial individual e os limites anuais de ganho por atributo continuam sendo respeitados.

## Validação
- O teste V674 confere a geração das 80 posições, metas no fundo da escala, diferença entre companheiros de equipe, neutralização de DNF por equipamento e crescimento de um piloto de equipe fraca por 60 GPs.
- A auditoria estática do pacote e a integridade do ZIP são verificadas na geração da entrega.
- A compilação Android/JUnit oficial depende da execução do workflow GitHub Actions; não é declarada como concluída localmente.
