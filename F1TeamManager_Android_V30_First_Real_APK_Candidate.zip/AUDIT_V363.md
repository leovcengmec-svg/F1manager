# Auditoria V363

## Alteração verificável

`TwoSeasonChainAuditTest.kt` anteriormente expunha apenas `fun main()`. Esse formato não é descoberto automaticamente pelo executor padrão de testes JUnit do Gradle. A V363 converte o cenário em `class TwoSeasonChainAuditTest` com método anotado `@Test`, tornando o cenário elegível para `testDebugUnitTest`/`test`.

## Cobertura prevista

- 60 rodadas consecutivas do `ManagerSeasonEngine`.
- Transição 2026 -> 2027 após 30 GPs.
- Transição 2027 -> 2028 após mais 30 GPs.
- Reinício do calendário em GP1 após cada encerramento.
- 80 contratos ativos após cada rodada.
- Estado de evolução para 100 pilotos e ausência de movimentos de mercado vencidos.

## Status

- Revisão estática do código alterado: concluída.
- ZIP: será verificado após empacotamento.
- JUnit: não executado.
- Build Android: não executado.
- Teste da simulação instantânea por GP: existe teste separado em `InstantSimulationServiceTest`, ainda não executado.
- Simulação real de duas temporadas com qualificação e corrida instantâneas: pendente; o teste de 60 rodadas valida o motor de temporada headless, não o fluxo Android completo.
