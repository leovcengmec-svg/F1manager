# V462 — Ranking inicial consistente no Modo Difícil

- Corrigido o ranking de força mostrado na abertura da carreira: na semana inicial, as 40 equipes são comparadas usando os mesmos carros iniciais determinísticos usados pela seleção do Modo Difícil.
- Evita que simulações/cache de desenvolvimento da IA alterem o ranking antes do início efetivo da temporada.
- Após a primeira semana, o ranking volta a refletir os carros evoluídos pela simulação da IA.
- Build Android não executado neste ambiente; validar no GitHub Actions.

