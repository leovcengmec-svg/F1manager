# Auditoria v693 — política financeira

## Envelopes
- €200M/temporada: P&D/design, fabricação e instalações.
- €150M/temporada: investimento no carro seguinte, ledger independente.
- Capacidade anual máxima combinada: €350M, sujeita à liquidez e reserva operacional.

## Mentalidades
- Padrão: 50% carro atual/instalações e 50% próximo carro; dentro do primeiro pool, 60% carro atual e 40% instalações.
- Carro dominante: 30% carro atual/instalações e 70% próximo carro; divisão interna 30/70.
- Disputa pelo título: 60% carro atual/instalações e 40% próximo carro; divisão interna 70/30.
- A partir do GP21 (após GP20 concluído), equipes de ranking técnico 17–40 sem disputa pelo título: 40% instalações e 60% próximo carro.

## Limitações da heurística
A classificação de disputa pelo título usa o ranking técnico como proxy (top 8); a dominância compara Overall atual com o melhor Overall inicial das demais equipes, pois a rotina financeira não recebe uma fotografia completa e sincronizada do grid. Essa heurística deve ser refinada quando a tabela completa de construtores e o Overall dinâmico de todas as equipes estiverem disponíveis no mesmo contexto.

## Proteções
- O próximo carro não consome o limite técnico de €200M.
- O carro atual/instalações não consomem o teto independente de €150M do próximo carro.
- Caixa operacional continua protegido.
- Não existe obrigação de gastar os limites anuais.

## Aplicação da estratégia no motor
- A parcela destinada ao próximo carro é protegida como percentual da liquidez discricionária (40/50/60/70%), sem ser convertida em um teto cumulativo inferior ao limite de €150M.
- O motor de P&D utiliza a liquidez remanescente depois da reserva estratégica e operacional.
- A escolha de instalações recebe um peso estratégico conforme a parcela de instalações da mentalidade (padrão 40%, dominante 70%, disputa 30%, reconstrução 100%); isso é prioridade de decisão, não obrigação de gastar.
- A disputa pelo título ainda usa o top 8 do ranking técnico como proxy, porque o serviço financeiro atual não recebe a classificação dinâmica completa de pilotos/construtores.
- A dominância usa a diferença do Overall atual da equipe contra o maior Overall inicial conhecido das rivais; não é uma comparação sincronizada de todos os carros atualizados. Essa heurística é conservadora e deve ser substituída por snapshot global dinâmico quando o motor de temporada disponibilizar esse contexto.
- A proporção interna é aplicada ao caixa discricionário: P&D recebe `currentCarPercentOfPool`, instalações recebem `facilitiesPercentOfPool`; o saldo técnico anual continua sendo um teto comum para essas duas categorias.
- Quando o alvo de construção do próximo carro é satisfeito, a reserva de caixa para esse destino é zerada e a parcela de liquidez volta ao pool atual/instalações.
