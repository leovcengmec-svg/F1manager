# Auditoria V674 — evolução dos pilotos

## Escalas esportivas
- Construtores: ranking de 1 a 40 equipes.
- Pilotos: grid e metas de 1 a 80 pilotos.
- O motor gera metas distintas para qualifying e corrida a partir de 80 contratos ativos, combinando força do carro e habilidade individual.
- Os modos Career e Team Principal exigem 80 pilotos ativos e 80 metas geradas.

## DNF e avaliação individual
- Pane elétrica, falhas de motor/freios/chassi, falta de combustível e pneu degradado não contam como posição final ruim para o desenvolvimento individual.
- DNF por colisão sofrida também é neutro; acidente atribuído ao próprio piloto continua sendo avaliado.
- O resultado de classificação permanece como evidência esportiva do piloto.

## Ritmo de evolução
- Fator de classe acima do teto: 1.00 até o teto; 0.90 até +2; 0.80 até +4; 0.70 até +7; 0.60 acima de +7.
- Potencial, limite anual por atributo e regressão por desempenho continuam ativos.

## Testes executados
- `DriverEvolutionV674Test`: compilado e executado isoladamente com Kotlin/JVM — PASS.
- Auditoria estática V674 — registrada no script `tools/race_sim_test/v674_driver_evolution_audit.py`.
- ZIP testado com `unzip -t`.
- Não foi possível executar o Gradle/Android SDK neste ambiente; APK não declarado como compilado.
