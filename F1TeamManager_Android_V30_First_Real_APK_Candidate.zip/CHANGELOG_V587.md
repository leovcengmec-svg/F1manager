# V587 — Painel Minha Carreira do Team Principal

- Incluído painel dedicado para acompanhar a carreira de Team Principal dentro do jogo.
- O card do modo na HOME agora abre o painel de carreira.
- Exibe prestígio de 0 a 100 com faixa profissional e barra de progresso.
- Exibe equipe atual, posição atual no campeonato, melhor posição registrada e objetivo de diretoria.
- Exibe janela do contrato, estado da avaliação bienal e acesso à tela de avaliação/propostas quando aplicável.
- Adicionadas oito conquistas derivadas dos resultados gravados: estreia, meta cumprida, top 10, pódio, título, salto de cinco posições, prestígio 75 e cinco temporadas.
- Histórico mostra temporada, equipe em que trabalhou, colocação, meta e variação de prestígio, inclusive após mudanças de equipe.
- Adicionado comportamento do botão voltar para retornar ao painel HOME ou da avaliação para o painel de carreira.
- Modos Livre e Difícil permanecem disponíveis sem alterar as regras deles.
- Build Android/Compose e testes funcionais em dispositivo continuam pendentes; ver `AUDIT_V587_TEAM_PRINCIPAL_DASHBOARD.md`.
