# V587 — Base de edição e vínculos dinâmicos

- Incrementada versão interna para 0.587.0, preservando o nome oficial do pacote de entrega.
- Adicionada operação de domínio `editPilotFull`, que valida classe/evolução, país, asset e os sete atributos e persiste a alteração sem mudar o ID do piloto.
- A criação de piloto usa valores do catálogo de perfis em vez de assumir 70 em todos os atributos quando há um perfil compatível.
- Adicionada operação `assignTeamPilots` para associar pilotos já existentes a uma equipe personalizada, evitando criar pilotos duplicados e devolvendo o vínculo dos pilotos substituídos ao mercado.
- Mantidos IDs originais, dados históricos e assets existentes.

## Limitações conhecidas

- A UI ainda precisa ser conectada às novas operações de edição completa e seleção por ID; a edição da base oficial (IDs 1–100) não é implementada por estas APIs, que protegem a base original.
- Não foi executada compilação Android nem suíte oficial neste ambiente; este registro não declara build aprovado.
