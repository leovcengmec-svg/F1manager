# V537 — Integração inicial de áudio externo

- Implementado player externo com leitura via MediaStore em `Pictures/F1Manager/Assets/Audio/`.
- Procura OGG Vorbis primeiro e MP3 como alternativa, incluindo `menu.mp3`.
- Conectados os ambientes de menu, interface, classificação/corrida, resultados e fim de temporada.
- Adicionada permissão Android `READ_MEDIA_AUDIO`; ausência de arquivo não interrompe o jogo.
- Build Android não executado neste ambiente.
