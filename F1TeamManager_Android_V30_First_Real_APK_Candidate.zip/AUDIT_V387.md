# Auditoria V387

## Alterações
- `MainActivity.kt`: simulação instantânea pode avançar semanas anteriores até o próximo GP, processando os efeitos semanais antes de simular.
- Home: botão `PULAR FIM DE SEMANA` habilitado quando a semana atual é anterior ou igual à semana do GP, desde que não haja corrida interativa em andamento e o GP não esteja finalizado.
- `versionCode=387`, `versionName=0.387.0`.

## Validação
- Revisão estática do handler e da condição do botão: realizada.
- Compilação Android e teste no dispositivo: pendentes; precisam ser confirmados pelo build do usuário.
