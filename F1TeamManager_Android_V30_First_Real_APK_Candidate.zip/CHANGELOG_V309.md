# V309 — Correções reais no cabeçalho e histórico da equipe

- Cabeçalho da equipe: removido o texto “Pontos 0”; a bandeira aparece isolada, sem moldura/card extra e sem nome do país.
- Removida a caixa/card do Overall; agora Overall, valor de desempenho e valor de confiabilidade aparecem em uma única linha mais alta, sem corte vertical.
- Removidas bordas e fundos desnecessários ao redor da imagem do carro no cabeçalho.
- Posição da equipe recalculada usando pontos e critérios de desempate por vitórias, pódios, poles e voltas rápidas na temporada corrente; posição mais próxima do escudo e fonte reduzida para caber em “40/40”.
- Títulos dos cards Orçamento e Desempenho Geral harmonizados em 10sp e truncamento substituído por ellipsis controlado.
- Histórico por temporada agora mostra sempre o cabeçalho completo: ANO, EQUIPE, POS, PTS, VIT, PÓD, POL, MV, GP, DNF, inclusive antes da primeira temporada encerrada.
- As linhas do histórico continuam sendo lidas dos registros persistidos por HistoricalDatabase.finalizeSeason; não são fabricados valores.
- Preservados assets externos, demais telas, histórico de versões e funcionalidades não relacionadas.

Validação: ZIP íntegro e inspeção estática do código alterado. Build Android e teste visual no dispositivo pendentes.
