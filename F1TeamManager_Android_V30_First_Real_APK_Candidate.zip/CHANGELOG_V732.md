# V732 — consistência do próximo carro e inteligência financeira da IA

## 1. Fonte única para o próximo carro
- `NextSeasonCarProjectionEngine` é o construtor oficial compartilhado por ranking dos construtores, ficha individual, mercado e transição de temporada.
- Overall oficial usa apenas investimento confirmado, construção física, regulamento anual e penalidade financeira aplicável.
- Projeção de dinheiro ainda não confirmado é exibida separadamente como cenário condicional; não altera o Overall oficial.
- O jogador e a IA usam a mesma construção física e os mesmos limites de crescimento/perda anual.

## 2. Snapshot canônico de GP30
- Após a corrida 30, evolução financeira, prêmios de construtores e penalidades de encerramento são liquidados antes do congelamento.
- A fotografia oficial registra as garagens físicas da próxima temporada, níveis de instalações, investimento comprometido e ranking técnico congelado.
- A virada e as projeções da nova temporada consomem esse snapshot, sem refazer a garagem por replay histórico baseado em orçamento inicial sintético.
- Checkpoints antigos continuam compatíveis; o snapshot canônico tem precedência sobre o replay legado.
- A aplicação do regulamento e da penalidade de encerramento ocorre uma vez no construtor oficial.

## 3. Estratégia financeira e disputa pelo título
- Corrigida a diferença assinada entre a equipe e o carro rival mais forte. Equipes atrás por 5+ pontos não podem ser classificadas como dominantes por um valor negativo convertido em zero.
- Disputa pelo título exige equipe no top 5 e diferença absoluta de até quatro pontos para o carro mais forte.
- Perfil padrão: 55% de prioridade para carro atual/P&D/fabricação e 45% para instalações dentro do envelope técnico compartilhado de €200M.
- Carro dominante: 60% carro atual e 40% instalações. Disputa pelo título: 65%/35%. Reconstrução: 65%/35%.
- O financiamento do próximo carro permanece independente, com limite anual de €150M.
- Os percentuais são prioridades estratégicas, não tetos que desperdicem caixa; todos os débitos continuam protegidos por liquidez, obrigações, previsão e envelope total.

## 4. Desenvolvimento das sete instalações
- Cada instalação tem nível-alvo estratégico: P&D, Fábrica e Túnel de Vento nível 6; Centro Comercial, Simulador, Desenvolvimento de Pilotos e Operações de Corrida nível 5.
- A lacuna até o alvo domina a seleção, impedindo que P&D seja escolhido repetidamente apenas por uma pontuação-base fixa.
- Reavaliação de investimento ocorre a cada quatro semanas; quando uma obra de 12 semanas termina, a próxima elegível pode iniciar imediatamente.
- O P&D/fabricação não reutiliza a parcela protegida de instalações enquanto houver instalação abaixo de nível 10. Se todas chegarem ao nível 10, a parcela não usada pode ser reaproveitada.
- Obras continuam sujeitas a caixa livre, reservas operacionais, previsão financeira e teto compartilhado de €200M.

## 5. Contabilidade técnica
- Custos acumulados de pesquisa/desenvolvimento e fabricação são enviados separadamente ao motor financeiro.
- O ledger debita `RESEARCH_DESIGN` e `FABRICATION` conforme o custo físico efetivo, sem classificar todo o consumo como P&D.
- O débito total não ultrapassa o caixa disponível ou o envelope anual compartilhado.

## 6. Sistemas preservados
- V731: progressão de pilotos, faixa adicional de Overall, condições por classe/contrato, promoção/regressão bienal e ausência de equipe.
- Metas de classificação/corrida exclusivamente baseadas na força do carro.
- Regras de idade 18–45 e reinício com redução de 30%.
- Central de Notícias, categorias e motivos completos.
- Catálogo e rotação de patrocínios V730.
- Identidade pública `F1 Team Manager V30`.

## Versão
- `versionCode = 732`
- `versionName = 0.732.0`
- Base: V731 / 0.731.0
- ZIP: `F1TeamManager_Android_V30_First_Real_APK_Candidate.zip`
