# Auditoria geral V591

## Correções desta vistoria
- `CustomWorldCatalog.save()`: a serialização de equipes personalizadas agora inclui `initialLevel`, alinhando o caminho de salvamento normal ao parser e ao caminho de recuperação. Antes, esse campo era omitido e recarregado com fallback `1`.
- `diagnosticSnapshot()`: inclui `officialPilotOverrides` e `officialTeamOverrides`, que antes não apareciam na exportação diagnóstica.

## Conferências estáticas
- `versionCode=591` / `versionName=0.591.0`.
- ZIP validado com `unzip -t` após empacotamento.
- Contagem de assets no pacote: 100 arquivos em `drivers`, 40 em `teams`, 50 em `circuits`, 2 em `car_assets` e 2 arquivos de áudio, além dos dados de eventos anuais.
- Foram encontrados 81 arquivos Kotlin/Java em `app/src/main` e 167 em `app/src/test`. Nenhum `TODO`, `FIXME`, `NotImplementedError` ou `UnsupportedOperationException` foi encontrado em fontes Kotlin de produção.
- As faixas fixas 1–40 para equipes oficiais e 1–100 para pilotos oficiais aparecem nos fluxos de edição/override e são usadas para manter IDs oficiais; não devem ser confundidas com o limite dinâmico de equipes personalizadas.
- A lógica de mercado tem chamada de reconciliação no carregamento da carreira (`CareerPreferences.kt`) e também na inicialização do motor de mercado.

## Pendências / riscos não certificados
- O projeto não contém `gradlew` e o ambiente não tem `gradle` instalado: build Android, compilação Kotlin completa e testes JUnit não foram executados.
- Não foi feita execução real em dispositivo, nem simulação de duas temporadas completas. Portanto interface, persistência de carreira, calendário, corrida, evolução anual, contratos, finanças, P&D/fábrica e virada de temporada ainda precisam de validação integrada.
- A pasta `app/src/main/assets/car_assets` contém apenas 2 arquivos neste pacote; confirmar se isso é intencional para o mecanismo de assets externos antes de declarar a biblioteca completa. Nenhum asset foi removido nesta atualização.
- O histórico de versões e changelogs foi mantido; V586 não possui um changelog separado na raiz, enquanto os registros disponíveis anteriores e V587–V591 permanecem.

## Resultado
A inspeção estática encontrou e corrigiu uma falha de persistência no nível inicial de equipes personalizadas e completou a exportação diagnóstica de overrides. A integridade do ZIP não equivale à aprovação do build ou do funcionamento ponta a ponta.
