# Auditoria V611 — Renovação de contrato na HOME

## Alterações verificadas
- `MainActivity.kt`: evento de renovação classificado como `MERCADO DE PILOTOS`.
- `MainActivity.kt`: `RENOVAÇÃO DE CONTRATO` seleciona a arte `notice_market_signed`, compartilhando o layout e imagem do evento de assinatura.
- `MainActivity.kt`: filtro da HOME exige que a mensagem de renovação corresponda à equipe do jogador.
- `app/build.gradle.kts`: versão atualizada para 611 / 0.611.0.

## Escopo preservado
- Nenhuma imagem nova criada.
- Nenhuma alteração nos motores de simulação, no mercado de pilotos ou no cálculo financeiro.
- V610 usada como base; preservados os arquivos de assets e o histórico anterior.

## Validação
- Verificações estáticas dos trechos alterados e dos identificadores de versão executadas antes do empacotamento.
- Compilação Android/Gradle, testes JUnit e validação em dispositivo/emulador não executados neste ambiente.
