# V336 — Correção de persistência e exibição das instalações das equipes IA

Base: V335
Versão: 0.336.0
versionCode: 336

## Causa identificada
A tela de detalhes da equipe simulava o desenvolvimento da IA sem fornecer as instalações persistidas (`aiFinance.facilities(teamId)`). A simulação então usava `FacilityEngine.initial(team.initialLevel)`, que representa apenas o nível inicial da equipe, fazendo a tela mostrar níveis antigos mesmo após melhorias. O mesmo padrão existia em caminhos de simulação semanal e no motor de temporada.

## Correções
- A tela de detalhes agora passa as instalações persistidas da equipe IA para a simulação.
- A sincronização semanal usa as instalações reais antes de simular P&D e fabricação.
- A preparação dos participantes usa as instalações persistidas no estado simulado.
- O motor de temporada usa as instalações persistidas ao construir o grid e calcular a cadeia de desenvolvimento/finanças.
- Mantidos níveis individuais por instalação, melhorias de 12 semanas, custos, limites de orçamento, efeitos de corrida e snapshots persistidos.

## Validação
- Verificação estática das chamadas `simulateFinancial` relevantes.
- Verificação de `versionCode`/`versionName`.
- Integridade do ZIP verificada com `zipfile.testzip`.
- Compilação Android e teste em dispositivo não executados nesta sessão.
