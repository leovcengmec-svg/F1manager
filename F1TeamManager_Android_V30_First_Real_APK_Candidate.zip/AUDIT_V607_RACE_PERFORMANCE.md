# Auditoria V607 — Lentidão da corrida e travamento de rolagem

## Evidência observada
O vídeo enviado mostra o fim de semana manual com a classificação de 80 pilotos, controles de simulação em velocidades diferentes e rolagem da lista durante a corrida. O usuário reporta engasgos ao rolar e 16 segundos para simulação instantânea.

## Causa de custo encontrada
`CareerWeekendEngine.simulateRaceInstantly()` avançava a corrida em um loop interno e, em cada passo, chamava `advance()`/`choose()`. Essas operações produziam snapshots completos. Cada snapshot reconstruía e ordenava a classificação, status dos 80 carros, mapas de estratégia e alertas — dados que o loop instantâneo descartava imediatamente, pois só precisava de `decision` e `completed`. Essa alocação repetida é custo evitável durante milhares de passos.

Na tela manual, os itens visíveis da `LazyColumn` repetiam buscas lineares na classificação e na lista de equipes (`firstOrNull`/`indexOfFirst`) a cada recomposição, além de compor logos e miniaturas de carros. Isso aumentava trabalho no caminho de rolagem.

## Alterações V607
1. Adiciona modo interno `instantSimulationFastSnapshots`.
2. Durante o loop instantâneo, snapshots intermediários carregam apenas sinais necessários (fase, volta, decisão, estado de conclusão e clima), sem reconstruir classificação/status/planos/alertas.
3. Ao terminar, o modo rápido é desativado e um snapshot completo é criado; validações da `InstantSimulationService` continuam intactas.
4. Na tela manual, mapas memoizados por ID/posição/nome substituem buscas lineares repetidas em cada item da classificação.
5. Cada avanço da corrida manual e a finalização subsequente passam a ocorrer em `Dispatchers.Default`; um bloqueio impede dois passos simultâneos e impede alterações de estratégia enquanto o motor está avançando.
6. Não altera fórmula de tempo de volta, incidentes, pneus, decisões, classificação final ou economia da carreira.

## Riscos/limitações
- A alteração reduz alocações e ordenações internas, mas o tempo exato depende do aparelho e de outros custos no motor; não prometo que voltará a menos de 5 segundos sem benchmark real.
- Build Android/JUnit/emulador e medição de performance no dispositivo não foram executados neste ambiente.
- A simulação manual continua produzindo snapshots completos para preservar atualizações visuais e decisões em tempo real, mas o cálculo do passo não bloqueia a thread principal.
- As ações de estratégia/box são ignoradas durante o breve passo do motor para impedir mutação concorrente do estado de corrida.
