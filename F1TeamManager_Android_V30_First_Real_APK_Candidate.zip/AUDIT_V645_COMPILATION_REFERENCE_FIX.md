# V645 — correção de referência Kotlin na tela Team Principal

## Problema reportado
O pipeline `:app:compileDebugKotlin` continuou falhando em `MainActivity.kt` na referência `objectiveCurrentTeamRank`, mesmo após a tentativa anterior de declarar uma variável auxiliar. A captura do usuário é a evidência da falha de compilação.

## Correção
Removida a variável auxiliar duplicada e unificado o cálculo/exibição da posição atual usando `currentTeamRank`, que já é calculado no mesmo ramo de tela a partir de `currentRankByTeam[principal.teamId] ?: principal.lastRank`. A chave de `remember` e os cálculos de objetivos usam a mesma referência.

O `projectedOverall` da previsão do carro permanece declarado localmente como `forecast.projectedOverall` antes de ser utilizado.

## Versão
- versionCode: 645
- versionName: 0.645.0

## Limitação
Esta correção resolve a inconsistência nominal apontada no log. O ambiente atual não dispõe de um wrapper Gradle incluído no projeto, portanto não se afirma que `compileDebugKotlin` foi executado com sucesso. O pipeline Android deve ser executado novamente; qualquer novo erro deve ser corrigido antes de declarar a versão compilável.
