# V130 — remoção do baseCar

## Regra
`InitialTeamProfile` é a única fonte oficial para a força inicial da equipe. O legado `TeamDefinition.baseCar` foi removido da raiz do modelo.

## Sistemas migrados
- Finanças iniciais da IA
- Capacidade/orçamento inicial de P&D da IA
- Mercado de pilotos (carro/projeto/prestígio/desempenho/histórico)
- Patrocínios (força e ranking)
- Fallback de orçamento em CareerPreferences

## Preservado
- 3 níveis iniciais Forte/Médio/Fraco
- Construção dos 6 componentes via InitialTeamProfile
- Instalações iniciais por nível
- Motor de corrida, pneus, estratégias e demais sistemas não relacionados à solicitação

## Auditoria
Busca em `app/src/main/java` e `app/src/test`: nenhuma referência de código a `baseCar` permanece.
Não foi possível executar Gradle nesta base porque o projeto não contém `gradlew`.
