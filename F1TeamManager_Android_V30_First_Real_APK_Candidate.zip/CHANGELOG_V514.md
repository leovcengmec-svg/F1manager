# V514 — Correção de carregamento da bandeira da Malásia

- Mantido o reconhecimento de `MY`, `MYS`, `Malaysia` e `Malásia`.
- Adicionado fallback para localizar bandeiras por nome normalizado em pastas `countries`/`Countries` e `flags`/`Flags` dentro de `Pictures/F1Manager/Assets`, inclusive `mys.png`.
- O fallback preserva os arquivos existentes e não exige renomear o pacote externo de bandeiras.
- Versão Android atualizada para `versionCode 514` / `versionName 0.514.0`.
- Validação estática da alteração e integridade do ZIP; compilação e testes Android ainda precisam ser executados em ambiente com Gradle.
