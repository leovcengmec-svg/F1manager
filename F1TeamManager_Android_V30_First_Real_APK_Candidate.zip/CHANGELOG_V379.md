# V379 — Bloco 3: auditoria final e pacote de entrega

## Entregas
- Versão Android atualizada para `versionCode = 379` e `versionName = 0.379.0`.
- Adicionado `tools/race_sim_test/final_release_audit.py` para verificações reproduzíveis de metadados, manifest, fontes críticas, assets externos e histórico.
- Preservado o escopo funcional validado na V378; nenhuma mudança de layout, botões ou assets.
- Mantidos os documentos históricos de versão.

## Verificações realizadas nesta etapa
- Auditoria estrutural final executada pelo script dedicado.
- Auditoria de cadeia de duas temporadas recompilada com `kotlinc` (excluindo dois arquivos de UI Compose que dependem do Android) e executada: 60 GPs, 2026 e 2027 completas, próxima temporada 2028 GP1; PASS.
- Integridade do ZIP conferida após empacotamento: PASS.

## Limitações
- O ambiente não contém Gradle/Gradle Wrapper funcional nem Android SDK configurado; a compilação Android/APK não pôde ser executada.
- A suíte oficial JUnit e testes em dispositivo/emulador não foram executados.
- Portanto, esta entrega é o pacote-fonte auditado, não um APK de produção validado.
