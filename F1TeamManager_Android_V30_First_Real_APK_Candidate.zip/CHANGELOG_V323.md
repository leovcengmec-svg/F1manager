# V323 — Ordem dos eventos e negociações do mercado de pilotos

- A notificação **FABRICAÇÃO CONCLUÍDA** agora aparece antes da decisão obrigatória de instalação. A escolha entre Carro 1 e Carro 2 só é exibida depois de o jogador confirmar/fechar a notificação do evento.
- A Central de Notícias voltou a mostrar os avisos **FABRICAÇÃO CONCLUÍDA**; removido o filtro que ocultava esses eventos.
- A Home passa a priorizar eventos de peça fabricada, depois eventos de P&D e, em seguida, respostas do mercado, antes de outros eventos pendentes.
- Respostas de mercado com os títulos reais do motor passam a ser reconhecidas na Home e nos cards de respostas: proposta recebida, contraproposta recebida, proposta recusada, contrato assinado, contraproposta aceita/recusada, transferência confirmada e negociação encerrada.
- Corrigido o fluxo de propostas recebidas de equipes da IA: elas permanecem pendentes até o jogador aceitar ou recusar, em vez de serem resolvidas automaticamente como se fossem propostas feitas pelo jogador.
- A seção de ofertas recebidas deixou de usar uma lista vazia fixa e passa a apresentar as ofertas pendentes destinadas aos pilotos da equipe do jogador, com ações de aceitar/recusar.
- Adicionadas quatro ilustrações genéricas de eventos do mercado: proposta, contraproposta, recusa e contrato assinado.
- Mantidos os limites de negociação, contratos futuros, taxa de assinatura e estrutura de assets externos já existente.
- Versionamento: versionCode 323 / versionName 0.323.0.
