# Auditoria V608 — Mercado de pilotos

## Escopo

Implementação aprovada a partir da auditoria V607: fim da atribuição forçada na virada, decisões esportivas para interesse e recrutamento, comparação entre renovar e contratar, ofertas concorrentes e proteção da equipe do jogador.

## Alterações

1. **Sem contratação inventada.** A resolução de vagas da IA percorre ofertas com salários escalonados, processa a resposta do piloto e aceita contrapropostas somente dentro de um limite explícito. Se não houver acordo, registra a vaga aberta em vez de fazer uma atribuição silenciosa.
2. **Equipe do jogador protegida.** A virada verifica o elenco projetado antes de iniciar o diário persistente e exige duas vagas com contrato confirmado. Se estiver faltando um contrato, explica o que precisa ser resolvido e não altera a carreira naquela tentativa. Há um fallback em memória para saves legados sem o blob estruturado, sem sobrescrever a carreira durante a verificação.
3. **Atratividade ligada à temporada real.** O cálculo combina força/prestígio de base com desempenho atual da equipe e posição/pontos do piloto. Os sete atributos atuais do piloto são usados no seu valor esportivo. Um candidato ao título recebe penalidade ao considerar uma equipe muito inferior; salários extraordinários podem compensar esse risco, mas uma oferta normal não o apaga.
4. **Renovação não é automática nem bloqueada por cota.** Cada equipe considera o ajuste do titular, alternativas disponíveis e ganho esportivo. A relação histórica 55/45 foi removida como trava global: serve para diagnóstico, não impede uma contratação que faça sentido para determinada equipe.
5. **Menos rotatividade artificial.** A vaga com contrato vencendo é priorizada. Uma equipe não deve rescindir um contrato plurianual para uma troca comum; a IA só considera a substituição se a alternativa representar uma melhoria esportiva expressiva.
6. **Concorrência real entre propostas.** Equipes podem disputar o mesmo piloto em paralelo. Quando há propostas concorrentes, o piloto pode priorizar a que combina melhor competitividade, salário, duração e papel. O contrato futuro só é criado após uma decisão aceita ou contraproposta efetivamente aceita.
7. **Taxas da virada contabilizadas.** Contratos aceitos pela IA no fechamento — e materializados diretamente no elenco da nova temporada — entram no ledger de taxa de assinatura parcelada. O marcador é persistido no snapshot financeiro, evitando duplicação após restauração.

## Validação executada no ZIP final

- **Compilação de núcleo:** 59 fontes Kotlin não Android compiladas com `kotlinc`, sem erros. Isso verifica o núcleo, não a compilação Android/Compose completa.
- **Testes direcionados:** 10 métodos passaram no harness Kotlin local, cobrindo integridade da grade, ausência de preenchimento automático da equipe do jogador, influência de desempenho atual, salário extraordinário, competição de ofertas, proteção a contrato plurianual, idempotência da taxa na virada e regressões V591/V592. Não foi executada a suíte JUnit oficial via Gradle.
- **Mercado semanal:** o teste de diagnóstico passou, gerando 32 renovações e 11 transferências na semente 20261006 sob esse cenário de entrada. Em outro harness com tabela de classificação/atributos explícitos, houve 42 contratos futuros (35 renovações e 7 transferências), sem substituição rotineira de contratos plurianuais por ganho inferior a 9 pontos de Overall. São resultados específicos de sementes/cenários, não proporções fixas.
- **Cadeia de temporadas:** 3 sementes × 4 transições, cobrindo as temporadas 2027–2030; as 12 transições terminaram com 40 equipes, exatamente dois pilotos por equipe e 80 pilotos únicos.
- **Auditorias estáticas:** 17/17 verificações específicas de mercado, 40/40 verificações do projeto e 25/25 verificações estruturais finais aprovadas.
- **Integridade/preservação do ZIP:** arquivo válido; nenhuma entrada anterior removida, nenhum asset alterado e nenhum documento histórico `AUDIT_V*`/`CHANGELOG_V*` alterado.

## Limites conhecidos

- O ambiente não dispõe de Gradle/Android SDK configurado. Não foi executado `assembleDebug`, suíte JUnit oficial, emulador ou dispositivo físico; esses testes ainda são necessários antes de declarar a compilação Android validada.
- Conforme a regra de validação funcional do projeto, testar dentro do jogo começando uma carreira nova via **Novo Jogo**. Saves anteriores e o histórico de versões foram preservados; nenhuma carreira foi apagada por esta atualização.

## Arquivos principais

- `app/src/main/java/com/f1teammanager/core/manager/DriverMarketEngine.kt`
- `app/src/main/java/com/f1teammanager/core/manager/AITeamFinancialEngine.kt`
- `app/src/main/java/com/f1teammanager/core/manager/ManagerSeasonEngine.kt`
- `app/src/main/java/com/f1teammanager/CareerPreferences.kt`
- `app/src/main/java/com/f1teammanager/MainActivity.kt`
- `app/src/test/kotlin/com/f1teammanager/core/manager/DriverMarketRealismV608Test.kt`
- `tools/race_sim_test/v608_driver_market_realism_audit.py`
