# V557 — Cadastro transacional de equipes

- Corrigida a inclusão de equipe para validar os dois nomes de pilotos antes de alterar o catálogo.
- Evita deixar um piloto órfão quando o segundo nome é duplicado ou inválido.
- Valida país e nome de arquivo do escudo e normaliza caminhos para guardar somente o nome do arquivo.
- IDs são calculados antes da mutação e permanecem append-only.
- Atualização baseada na V556; nenhum arquivo histórico foi removido.

## Validação
- Inspeção estática do fluxo de cadastro e verificação de sintaxe do bloco alterado.
- Compilação Android e testes automatizados não executados neste ambiente.
- A inclusão dinâmica de equipes em todos os modos de campeonato continua pendente.
