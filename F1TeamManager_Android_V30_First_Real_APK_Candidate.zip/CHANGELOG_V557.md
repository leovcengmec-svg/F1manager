# V557 — Padronização global de pilotos fracos

- Todos os pilotos anteriormente classificados como `Fraco` no catálogo inicial agora são `Médio`.
- A evolução de todos esses pilotos foi padronizada para `Normal`, inclusive os que estavam como `Demorado`.
- Os perfis individuais de atributos foram preservados como base e são normalizados pelo sistema para o nível da classe `Médio`.
- A mudança vale para os pilotos gerados a partir do banco/catálogo inicial; não altera automaticamente carreiras já salvas no dispositivo.
- Versionamento Android atualizado para `versionCode 557` / `versionName 0.557.0`.
- Integridade do ZIP será verificada. Nenhuma validação de compilação Android é declarada.
