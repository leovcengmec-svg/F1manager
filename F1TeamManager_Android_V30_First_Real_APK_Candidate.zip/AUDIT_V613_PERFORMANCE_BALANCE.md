# Auditoria V613 — Balanceamento do desempenho

## Escopo
A alteração é restrita ao cálculo do ritmo-base no modelo de classificação/corrida: pesos de carro/piloto e unificação do cálculo de classificação interativa. O restante dos sistemas de corrida permanece fora do escopo.

## Pesos configurados
- Seco e nublado: 65% carro / 35% piloto.
- Chuva leve, média e forte: 60% carro / 40% piloto.

## Fórmula
`multiplicador = 1 + (peso_carro × modificador_tempo_carro) - (peso_piloto × modificador_ritmo_piloto)`

O modificador do carro soma motor, chassi e asa dianteira; valores positivos representam perda de tempo. O modificador do piloto representa sua contribuição de ritmo; valores positivos representam ganho de tempo. Os pesos somam 100% em cada condição.

## Controles de não-regressão funcional
- O piloto Pro melhora o mesmo carro em comparação com um piloto médio.
- Um carro no nível mínimo permanece mais lento que a referência neutra mesmo com piloto Pro, inclusive sob os pesos de chuva.
- Carro e piloto são incorporados uma única vez ao ritmo-base.
- Habilidades especializadas e penalidades de pneus, combustível, consistência, clima, DRS/ERS e confiabilidade continuam em seus cálculos separados.
- Arquivos históricos, imagens/assets e sistemas fora do cálculo de ritmo não foram intencionalmente alterados.

## Validação executada
- Compilação isolada de 59 arquivos Kotlin do núcleo (race/manager/season, excluindo telas Android/Compose) concluída sem erros; apenas avisos preexistentes de parâmetros/variáveis não utilizados.
- Smoke test executável da fórmula aprovado (`V613_PACE_BLEND_SMOKE_OK` e `V613_FORMULA_EXACT_VALUES_OK`), incluindo pesos em seco/chuva, piloto Pro com carro fraco e classificação.
- Auditoria de corrida preexistente executada novamente: `V82_FULL_RACE_ENGINE_AUDIT_OK` (qualificação e corrida com 80 pilotos).
- Testes JUnit específicos da fórmula foram adicionados ao projeto.

## Limite da validação
A compilação Android completa, a suíte JUnit do projeto, simulações integrais de temporada e teste em dispositivo dependem de execução no ambiente Android/Gradle e não devem ser considerados aprovados até serem executados.
