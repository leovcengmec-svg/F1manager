# V645 — Kotlin compile fix

- Corrigida a referência de posição da equipe na tela de carreira Team Principal, removendo a variável auxiliar `objectiveCurrentTeamRank` e usando consistentemente `currentTeamRank`.
- Mantida a declaração local `projectedOverall` na projeção da construção do carro.
- Atualizados `versionCode` para 645 e `versionName` para 0.645.0.
- A compilação Android integral precisa ser confirmada pelo pipeline Gradle.
