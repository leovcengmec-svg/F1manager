# V425 — Vistoria geral da virada de temporada

- Corrigido o cálculo do ranking e do teto anual de investimento técnico no fluxo manual: agora usa o carro recém-construído, não o carro da temporada anterior.
- Adicionado teste-fonte para o ranking baseado no novo carro e reset dos gastos anuais.
- Incluído `AUDIT_V425.md` com os fluxos conferidos e riscos restantes.
- Sem alterações de layout; histórico e assets preservados.
- Build Android e testes automatizados não executados neste ambiente.
