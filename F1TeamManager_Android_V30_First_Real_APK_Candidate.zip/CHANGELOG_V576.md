# V576 — Construção do próximo carro

- Removida a aplicação interna duplicada do bônus de regulamento no caminho de construção; o regulamento é aplicado pelo orquestrador após a construção.
- Corrigida a herança dos carros físicos da IA para somar 10% arredondado do atributo próprio de cada carro, mantendo Carro 1 e Carro 2 independentes.
- Mantidas tabela unitária de investimento, foco técnico e remoção da regressão anual genérica de 70%.
- Build Android e teste em dispositivo pendentes.
