# Auditoria V367

## Objetivo

Impedir que a simulação instantânea seja validada contra um circuito diferente daquele que configurou o motor. Antes desta correção, o serviço verificava apenas `circuit.laps > 0` e validava o resultado contra as voltas fornecidas pelo chamador; ID, nome, tempo-base e riscos podiam divergir do circuito efetivamente usado pelo motor.

## Alterações

- Adicionado `CareerWeekendEngine.configuredCircuit()`.
- `InstantSimulationService.completeStartedWeekend` agora exige um circuito configurado e igualdade integral com o circuito fornecido antes de iniciar a simulação.
- Teste de regressão verifica que a divergência é rejeitada e que fase, volta e grid não são modificados.

## Resultado

- Inspeção estática da alteração: concluída.
- JUnit oficial: pendente.
- Build Android: pendente.
- Teste de 60 GPs com persistência Android real: pendente.

A alteração não modifica layout, botões, assets ou histórico de versões anterior.
