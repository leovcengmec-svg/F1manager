# V629 (0.629.0)

- Restaurada a altura compacta aprovada do card principal de prestígio.
- Aumentada somente a altura dos cards Contrato e Metas Cumpridas dentro de Objetivos da Diretoria.
- Aumentada a altura do card pai em 20 dp para acomodar os cards internos.
- Rolagem vertical da página mantida.
