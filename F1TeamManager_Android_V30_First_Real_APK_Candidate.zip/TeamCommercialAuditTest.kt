import com.f1teammanager.core.manager.*
import com.f1teammanager.core.season.WorldDatabase

fun main() {
    val engine = TeamSponsorshipEngine(20261006)
    val all = engine.allTeams(2026)
    check(all.size == 40) { "Esperadas 40 equipes, obtidas ${all.size}" }
    check(all.values.all { it.sponsors.size == 5 }) { "Alguma equipe não possui 5 patrocinadores" }
    check(all.values.all { it.sponsors.all(SponsorContract::active) }) { "Algum patrocinador IA não está ativo" }
    check(all.values.all { it.annualGuaranteedIncome > 0 }) { "Alguma equipe sem receita de patrocínio" }
    check(all.values.flatMap { it.sponsors }.size == 200) { "Esperados 200 contratos" }
    println("TeamCommercialAuditTest: PASS — 40 equipes / 200 patrocínios ativos")
}
