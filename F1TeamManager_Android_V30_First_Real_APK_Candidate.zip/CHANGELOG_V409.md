# V409

- Corrigido o rótulo de clima no diálogo de plano de início da corrida: agora mostra apenas a condição meteorológica (SOL, NUBLADO, CHUVA LEVE, CHUVA MODERADA ou CHUVA FORTE), sem acrescentar o tipo de pneu ao texto.
- Reduzido o tamanho da tipografia do valor climático para caber o maior rótulo, `CHUVA MODERADA`, em uma única linha.
- Removido o uso de reticências nesse valor para não exibir `...`.
- Nenhuma alteração na lógica de clima, pneus, simulação ou demais telas.
