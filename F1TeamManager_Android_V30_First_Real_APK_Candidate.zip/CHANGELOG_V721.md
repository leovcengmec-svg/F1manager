# V721 — Next-season projection and annual-event continuity

Base: V720 / 0.720.0  
VersionCode: 721  
VersionName: 0.721.0

## Next-season car projection

- Added a read-only season-runway forecast for next-season investment. The estimate starts from actual committed investment, estimates the remaining opportunity through the 30-GP season, and is capped by available discretionary cash and the independent €150M next-car envelope.
- At the opening week, the projection can represent the full planned investment when the current available cash covers it; as GPs are completed, the forecast converges toward the actual committed amount. At GP30 it equals the actual investment.
- The Team Ranking, market projection, and Team Overview next-car card now use the same forecast helper.
- Team Ranking now displays actual and projected next-car investment alongside projected Overall. The estimate does not debit cash, change the finance ledger, or alter the actual season-rollover investment.
- The actual rollover still uses only real committed investment and preserves the established underinvestment rule: €1M shortfall = 1 point per installed component, capped at 10 points per component.
- The player and AI use their existing physical construction pipelines, but no longer compare an AI forecast with a player construction made from zero committed investment while the season still has investment runway.

## Annual event timing and persistence

- Multi-week calendar advancement is split at every pending annual-event week. Each segment commits the event boundary before advancing later weeks, so subsequent segments consume post-event facilities, cash, and car state.
- The weekly scheduler delegates team targeting and event resolution to the same deterministic `AnnualTeamEventEngine.resolveSeasonBatch` used by the live career path. Team weights are shared (weak 50, middle 35, strong 15), including acquisitions and facility upgrades.
- Facility upgrade projects are rebased when an annual event changes the same facility. Damage reduces the in-flight project's baseline and target by the same amount; a free annual upgrade moves the paid target up by one, preserving its paid increment. If no physical level remains, the obsolete project is cancelled.
- The player's and AI's active upgrade states are updated as part of event application.
- Event effects, event car snapshots, AI finance/sponsorship snapshots, AI budget balances, processed event keys, the player's career step, and the event boundary week are committed through the same SharedPreferences editor transaction.
- Added an independently persisted mirror of AI facility rows. It is written with the canonical AI finance snapshot and used only to repair missing/invalid facility rows during load; valid canonical snapshot rows remain authoritative. New-career cleanup clears the mirror.
- Season rollover continues to preserve the facility map and in-flight AI upgrades; the V721 code does not reset facilities to `initialLevel` at season opening.

## Regression coverage

- Added tests for opening-week forecast, GP30 convergence, cash/cap limits, zero-cash behavior, paid facility-project rebasing under earthquakes and free upgrades, project cancellation at the physical cap, event-boundary splitting, AI facility snapshot restore, and deterministic weighted event targeting.

## Validation limits

The static V721 audit and release-contract checks are run when packaging. The Android Gradle build, JUnit execution, and on-device career replay must be confirmed by GitHub Actions/device testing when the environment does not provide Gradle and the Android SDK. No existing career save is rewritten or retroactively assigned assumed earthquake damage.


## Superseded by V722
The V721 €1M-per-component underinvestment behavior was identified as inconsistent with the official Overall × Investment table. V722 removes that conversion and applies the table plus the annual maximum 10-Overall loss to both player and AI.
