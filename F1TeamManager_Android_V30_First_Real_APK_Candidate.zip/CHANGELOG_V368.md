# Changelog V368

- Adicionado teste JUnit ponta a ponta do limite de simulação instantânea usando o `CareerWeekendEngine` real.
- Coberta a qualificação Q1/Q2/Q3 (80/50/20), classificação final de 80 pilotos e distância programada.
- Adicionado teste de regressão garantindo que um circuito divergente seja rejeitado antes de o motor avançar.
- Atualizada a versão Android para 0.368.0.
- Nenhuma alteração na interface, nos botões ou nos assets externos.
