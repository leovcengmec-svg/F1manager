# Auditoria de correção — V605

## Alterações

1. `MainActivity.kt`: o próximo carro deixa de usar `nextSeasonInvestmentBudgetBase` como teto cumulativo visual. A tela usa o espaço até €150M e valida separadamente o caixa acima da reserva operacional.
2. `SeasonInvestmentPolicy.maximumCumulativeInvestment`: retorna apenas o teto absoluto do projeto. A disponibilidade de caixa continua sendo validada no momento do débito; entrada futura de caixa pode restaurar capacidade.
3. `TechnicalInvestmentEngine`: teto uniforme de €200M por temporada para todas as equipes. A migração preserva os três acumuladores de gastos e normaliza somente o teto salvo.
4. `CareerPreferences.loadTechnicalInvestment` e restauração de snapshots da IA: convertem o teto legado para €200M sem apagar valores gastos.
5. `AITeamFinancialEngine`: instalações compartilham o teto anual; removido o subteto IA-only de 20%. O limite de caixa operacional, a obra de 12 semanas e uma obra ativa por vez permanecem.
6. `AITeamDevelopmentEngine`: usa o teto técnico uniforme de €200M.
7. Versão Android: `versionCode 605`, `versionName 0.605.0`.

## Regressões adicionadas/atualizadas

- As 40 posições de ranking recebem o mesmo teto de €200M.
- P&D, fabricação e instalações somam no mesmo teto.
- Migração na mesma temporada preserva os gastos já registrados e atualiza o teto.
- O teto do próximo carro continua €150M mesmo se a referência de caixa antiga era €32,5M e o caixa atual passa a €100M.
- O motor do jogador continua bloqueando aportes que violariam a reserva operacional.

## Limitações de validação

Os scripts estáticos e testes disponíveis no projeto devem ser executados após a alteração. A compilação Android completa e testes em aparelho/emulador não são declarados como concluídos sem Gradle/Android SDK disponíveis.
