# AUDIT V728 — notícia de piloto somente por Overall

## Regra verificada
- A central de evolução de pilotos só normaliza/publica uma mensagem que contenha uma transição real `Overall antes → depois` com delta diferente de zero.
- O sufixo `Motivo:` é preservado pela normalização.
- Nenhuma notícia gerada pelo tick expõe nomes/códigos dos sete atributos.
- As mutações de atributo continuam dentro do motor, bancos, limites anuais e snapshots; somente a publicação foi restringida.

## Caminhos corrigidos
1. `CareerPreferences.applyDriverRaceEvolution`: removidos o construtor paralelo e suas chamadas de notícia por atributo.
2. `flushPendingDriverEvolutionNews`: o outbox aceita apenas mensagens normalizáveis de Overall; os tokens antigos de atributo não passam.
3. `MainActivity.MarketNews`: notícias antigas da V725–V727 com `VEL +1`, `CHU +1`, regressão por idade ou reinício detalhado são ocultadas na central. Eventos distintos (promoção de classe/programa) permanecem.
4. Virada 45→18 em `CareerPreferences` e `ManagerSeasonEngine`: se houver alteração real, publica uma regressão de Overall com o motivo do reinício, sem expor valores de atributos.

## Conteúdo do motivo
- Desempenho esportivo acima/abaixo das expectativas.
- Declínio natural da idade.
- Reinício do ciclo etário aos 18 anos após a temporada aos 45, com redução de 30% em cada atributo, piso 40 e preservação de identidade/classe/perfil.

## Testes adicionados
`DriverOverallNewsV728Test.kt` cobre filtro de notícia VEL +1, preservação do motivo, notícia de ciclo somente por Overall e retenção de eventos não relacionados a movimento de atributos. Os tipos de notificação são separados em `DRIVER_EVOLUTION` e `DRIVER_EVENTS`.

## Validação executada nesta revisão
- Probe Kotlin isolado com 9 asserções: aprovado; inclui notícia legada do centro de desenvolvimento com recuperação do motivo e descarte de duplicata GP sem motivo.
- Verificações estáticas dos caminhos de geração, outbox, categorias, deduplicação e versionamento: 12/12 aprovadas.
- Comparação dos métodos `overallMovementNews`, `normalizeOverallMovementNews` e `overallMovementReason` com a V724: os dois primeiros são idênticos; a razão do reinício foi adaptada apenas para refletir a regra atual de 30% (a V724 ainda usava recuperação parcial).
- Teste JUnit incluído no projeto, mas não executado nesta sessão.

## Limitações
- O ambiente não possui Gradle nem Gradle Wrapper; build Android/JUnit integral e `assembleDebug` precisam ser confirmados pelo GitHub Actions.
