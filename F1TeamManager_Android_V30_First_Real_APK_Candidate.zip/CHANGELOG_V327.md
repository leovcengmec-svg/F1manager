# V327 — Compactação do resumo do plano de início da corrida

- Removido o card de combustível inicial do resumo do modal.
- O card de voltas totais agora usa o título em uma única linha: `VOLTAS TOTAIS`.
- O card `CONDIÇÕES CLIMÁTICAS` ocupa o dobro da largura do card de voltas, aproveitando o espaço liberado.
- Títulos e valores dos cards ficam em uma linha, com ellipsis como proteção para condições climáticas extensas.
- Preservados os dados reais do clima, o total de voltas e a lógica de estratégia dos dois pilotos.
- Atualizados `versionCode` para 327 e `versionName` para `0.327.0`.

Validação: ZIP testado com `zipfile.testzip()` e verificações estáticas do trecho alterado. Compilação Android e teste em dispositivo não executados.
