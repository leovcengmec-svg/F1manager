# Auditoria V609 — correção de compilação

## Erro reportado

A compilação do APK Debug falhou em `:app:compileDebugKotlin`, em `MainActivity.kt:4294:63`, com `Unresolved reference 'investableBudget'`.

## Causa

A linha de apresentação do orçamento ainda usava `investableBudget`, variável que foi removida anteriormente quando o limite por fase deixou de ser usado como teto acumulado. O valor não era mais declarado nesse escopo.

## Correção aplicada

- O cartão passou a exibir `Após reserva`, calculado por `caixa - reserva operacional`.
- O teto absoluto segue mostrando o limite cumulativo do próximo carro (até €150M, conforme o motor).
- O dinheiro efetivamente disponível para novo aporte continua sendo o menor valor entre o limite cumulativo restante e o caixa após reserva.
- Removidas as referências redundantes a `investableRemaining`.
- `versionCode = 609`; `versionName = 0.609.0`.

## Verificações realizadas

- Auditoria direcionada da correção: 11/11 verificações aprovadas.
- Auditoria geral do projeto: 40/40 verificações aprovadas.
- Auditoria estrutural da entrega: 25/25 verificações aprovadas.
- Auditoria de regressão do mercado de pilotos V608 preservado: 17/17 verificações aprovadas.
- ZIP passou no teste de integridade (`testzip` sem erros).
- Comparação com a V608: 1.329 entradas anteriores, zero entradas antigas ausentes, zero assets ausentes e zero documentos de histórico ausentes. As quatro entradas anteriores alteradas foram `MainActivity.kt`, `app/build.gradle.kts`, `CHANGELOG.md` e `README.md`, como esperado.

## Limitação

Não foi possível executar `:app:compileDebugKotlin` neste ambiente: não há instalação `gradle` encontrada no PATH e o ZIP de origem não inclui o wrapper `gradlew`. Portanto, esta entrega corrige a causa identificada pelo log, mas o sucesso de compilação Android deve ser confirmado no mesmo ambiente CI que apresentou o erro.
