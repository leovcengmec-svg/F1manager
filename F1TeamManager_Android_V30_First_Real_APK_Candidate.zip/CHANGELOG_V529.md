# V529 — Livro-caixa financeiro ampliado

- Aumentada a retenção do histórico financeiro de 2.000 para 20.000 lançamentos por equipe em memória, salvamento/restauração e serialização financeira da IA.
- Controle financeiro exibe resumo por categorias: salários, patrocínios, vendas, premiações, P&D, fabricação de peças, instalações, despesas operacionais, despesas de GP, taxas/contratos/multas, obrigações pendentes e outras movimentações.
- Cada lançamento visível recebe categoria inferida pela descrição, sem alterar seu valor contábil.
- Versão 529 (0.529.0).

Limitação: classificação por descrição é uma ponte de compatibilidade. O registro estruturado de temporada/semana/categoria na origem de cada operação continua necessário para precisão integral. Compilação Android não executada neste ambiente.
