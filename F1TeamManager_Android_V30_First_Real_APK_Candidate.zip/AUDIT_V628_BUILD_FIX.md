# V628 — correção de compilação após V627

## Erro corrigido
O workflow Android informou `Unresolved reference: careerLoadRevision` em `MainActivity.kt` dentro da composable `Home`. A variável pertence ao escopo da composable principal e estava sendo usada em `Home` sem ser passada como parâmetro.

## Alteração
- Adicionado `careerLoadRevision: Int` à assinatura de `Home`.
- Passado o valor atual no único ponto de chamada de `Home`.
- Mantido `remember(store.season, careerLoadRevision)` para que eventos anuais pendentes sejam reinicializados quando outra carreira for importada.
- Incrementado o versionCode/versionName para 628 / 0.628.0.

## Validação
- Conferência estática do parâmetro, assinatura e chamada efetuada.
- ZIP será validado com `unzip -t`.
- A compilação Android completa precisa ser confirmada pelo workflow; não declarar build concluído sem resultado do runner.
