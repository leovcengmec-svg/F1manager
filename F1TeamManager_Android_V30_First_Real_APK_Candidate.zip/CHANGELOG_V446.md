# V446 — Interface própria de desenvolvimento do próximo carro

- Criada tela independente `PRÓXIMO CARRO`, seguindo os componentes visuais já usados no jogo (fundo escuro, cards compactos, bordas existentes, vermelho de destaque e rolagem vertical).
- Adicionado acesso discreto a partir de CARRO / P&D; o Centro de P&D e as pesquisas atuais foram preservados, sem reintroduzir o card removido de investimento.
- A tela usa `CarDevelopmentEngine.nextSeasonForecast`, `carOverall`, `nextSeasonInvestmentCap`, `investNextSeason` e `setNextSeasonFocus` existentes, sem duplicar a regra de cálculo.
- Exibe caixa, investimento acumulado, teto absoluto, referência de manutenção, classe atual/projetada e foco de desenvolvimento.
- Aportes rápidos de €5M, €10M e €20M passam pelo motor existente, que continua validando fase da temporada, teto e caixa protegido.
- Mostra a sequência de transição: investimento → construção do carro novo → aplicação do regulamento → recálculo da força e persistência. As etapas futuras são identificadas como pendentes, não como concluídas.
- Preservados os assets, o histórico e os demais sistemas existentes.
- Versão atualizada para `446` (`0.446.0`). Nome fixo do ZIP de entrega preservado.

Validação realizada: inspeção estática das referências, enumeração de telas e conexões com as funções existentes. Compilação Android/JUnit não executadas neste ambiente porque o pacote não inclui Gradle Wrapper e o ambiente não disponibiliza a configuração completa de Android SDK/build.
