# Auditoria V596 — correção do erro de compilação

## Erro reportado
`MainActivity.kt:9801:9 — Unresolved reference 'store'` na chamada de `simulateAiDevelopment`.

## Correção
A função `teamOverviewSnapshot()` utiliza `store` para consultar o handoff financeiro da equipe. O parâmetro `store: CareerPreferences` foi adicionado explicitamente à assinatura, eliminando a referência sem declaração.

## Escopo preservado
- Mantida a lógica de simulação e o uso do estado Team Principal/handoff.
- Mantidas as mudanças V595 de identificação, validação, importação e exportação de saves por modo.
- Mantidos os assets e o histórico anterior.

## Limites de validação
Correção de fonte verificada por inspeção textual. O build Android deve ser executado no workflow que gerou o erro para confirmar se existem outros erros de compilação. Não declarar APK validado antes desse resultado.
