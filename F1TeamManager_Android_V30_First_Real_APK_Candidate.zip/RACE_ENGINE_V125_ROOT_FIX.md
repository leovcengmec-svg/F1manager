# V125 — Race strategy execution root fix

- Active dry tyre plans A/B/C/D remain the Manager's selected strategy.
- While a plan is active, its pit sequence executes automatically.
- A planned stint is changed at its planned window; critical tyre wear can trigger the next stint automatically.
- Tyre-critical decisions are shown only after the pilot has entered MANUAL mode (manual pit or weather override), not while a dry plan is active.
- Weather behavior remains as specified: rain abandons the dry plan and subsequent tyre changes are manual; the dry plan does not resume automatically when the track dries.
- Attack / Balanced / Defense remain Manager decisions and are not converted to an AUTO posture.
- Live GAP is displayed relative to the race leader instead of changing reference to the car immediately ahead.
- Manual BOX still abandons the active tyre plan permanently for that driver.

- Restored the approved dry-tyre life: Soft 15 laps, Medium 22 laps, Hard 30 laps.
