# V334 — Annual-event Home replay fix

## Base
- Built directly from the latest delivered V333 ZIP.
- Official ZIP filename preserved: `F1TeamManager_Android_V30_First_Real_APK_Candidate.zip`.

## Root cause
Home popup selection and Home notification counters considered every unread annual-event notification with `season <= current season`. Annual-event notices from prior seasons could therefore be treated as current Home alerts, even though they are historical records.

## Changes
- Home popup selector only considers annual-event notifications whose season equals the active career season.
- Home notification counters apply the same eligibility rule, so past-season annual events no longer keep Home badges active.
- Other unread operational notices from prior seasons retain their existing behavior.
- Central News continues to retain previous-season annual events as historical news; no event records are deleted.
- Version updated to `versionCode 334`, `versionName 0.334.0`.

## Validation
- Static source assertions verify the season gate is present in the popup selector and Home unread counter.
- ZIP integrity checked with Python `zipfile.testzip()`.
- Android build/device validation was not run in this environment (no Gradle wrapper/installed Gradle confirmed).
