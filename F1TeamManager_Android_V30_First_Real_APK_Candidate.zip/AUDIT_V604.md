# Auditoria V604 — inicialização e catálogo dinâmico

## Causa confirmada
O relatório Android fornecido pelo usuário mostrou `IllegalArgumentException` em `DriverMarketEngine.initialState()` quando o mesmo ID de piloto aparecia em mais de um roster. A V603 também continha uma referência não declarada (`resolvedTeamByDriver`), que impediria a compilação.

## Correções nesta versão
- A resolução de proprietário de roster foi definida explicitamente e é determinística: a lista de equipes é ordenada com equipes personalizadas antes das equipes originais; cada ID de piloto resulta em apenas um proprietário para a criação inicial de contratos.
- A lista inicial de agentes livres exclui qualquer piloto declarado em roster, impedindo que um piloto seja simultaneamente contratado e agente livre.
- Removida a referência indefinida da V603.
- Adicionado teste unitário para a política determinística de resolução.
- Atualização da versão para 0.604.0 (código 604).

## Limitações de validação
O pacote foi verificado estruturalmente. A compilação Android e a suíte JUnit não foram executadas neste ambiente porque não há Gradle instalado nem Gradle Wrapper no repositório. Esta correção evita o crash de inicialização e a duplicação de contratos, mas não substitui uma migração persistente do catálogo conflitante; os rosters salvos ainda devem ser reconciliados no editor antes de serem regravados.
