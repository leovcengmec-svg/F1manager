# Changelog V372 — Primeiro bloco de layout do dashboard

- A tela inicial agora apresenta a imagem do próximo GP em proporção horizontal 16:9, reduzindo a altura excessiva do card e preservando a proporção visual do asset.
- O acesso rápido foi reorganizado em duas colunas com botões mais altos, tipografia maior, alinhamento central e suporte a duas linhas para rótulos longos.
- Os callbacks de navegação existentes foram preservados; não houve mudança na lógica de simulação ou carreira.
- Atualizado versionCode/versionName para 372 / 0.372.0.
- Nenhum asset externo, registro histórico ou versão anterior foi removido.
