# V437 — Equilíbrio financeiro e limite de investimento antecipado

- Criada `SeasonInvestmentPolicy`, política central para limites acumulados de investimento no carro da próxima temporada.
- Limites por fase: 10% (GP 1–8), 15% (GP 9–15), 25% (GP 16–22) e 35% (GP 23–30), sempre sobre o caixa livre após reserva protegida.
- Reserva operacional mínima: 20% do caixa, com piso de €2M, sem permitir gastar dinheiro protegido no investimento antecipado.
- IA: melhorias de instalações e orçamento discricionário de P&D respeitam a reserva de caixa.
- Criados testes unitários para progressão de limites, teto acumulado, caixa baixo, reserva da IA e bloqueio do investimento do jogador.
- Não foram alterados layouts nem assets.
