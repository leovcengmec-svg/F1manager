# V408 — Formatação dos salários no mercado de pilotos

- A proposta continua aceitando apenas dígitos, preservando o valor numérico enviado ao motor de negociação.
- Adicionada prévia imediata do salário anual no padrão acordado: milhões com `M` e milhares com `mil`, usando euro e vírgula decimal (ex.: `€ 48,2 M`, `€ 700 mil`).
- Texto de ajuda esclarece que o campo recebe apenas números e que a linha de prévia mostra o valor formatado.
- Nenhuma mudança no layout geral, fluxo de negociação ou assets.
