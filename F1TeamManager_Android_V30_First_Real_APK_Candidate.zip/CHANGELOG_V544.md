# V544 — P&D: versão por temporada e cores por versão

- Cada temporada começa com a tecnologia física do carro identificada como V0.
- As pesquisas de cada componente na temporada atual seguem V1, V2, V3... independentemente por componente.
- Projetos antigos continuam no histórico, mas não influenciam o próximo número de versão.
- As cores de V0 a V10 são distintas e aplicadas às etiquetas de versão no P&D, designs/fábrica e cartões de peças.
- O desempenho e a confiabilidade da peça física continuam sendo a base real da primeira pesquisa da temporada; V0 não zera atributos.
