# Auditoria V599 — inicialização de carreira com equipe personalizada

## Causa raiz encontrada

`DriverMarketEngine.initialState()` criava contratos usando `WorldDatabase.drivers`. Essa lista é uma visão de pilotos titulares e pilotos personalizados vinculados, mas não inclui necessariamente pilotos oficiais de reserva (IDs 81–100) quando um desses pilotos foi associado a uma equipe personalizada. Ao iniciar uma carreira com essa equipe, o roster e o mercado inicial podiam divergir: havia um assento no roster sem contrato correspondente. A validação do grid/mercado podia falhar durante a inicialização subsequente.

## Correção

- O estado inicial do mercado agora é derivado dos vínculos efetivos em `WorldDatabase.teams`.
- Cada piloto em um roster recebe um único contrato para a equipe correspondente.
- O código rejeita vínculos duplicados em múltiplas equipes e mantém todos os pilotos restantes como agentes livres.
- `selectTeam` agora não deixa uma exceção de inicialização encerrar o processo silenciosamente; apresenta uma mensagem de erro e não navega para uma carreira parcialmente inicializada.

## Verificações

- Inspeção estática dos caminhos `selectTeam` → `startNewCareer` → `DriverMarketEngine.initialState`.
- A compilação Android e a suíte JUnit ainda precisam ser executadas no GitHub Actions; não marcar como build aprovado até o workflow passar.
