# Auditoria de estabilização — V704

## Identificação
- VersionCode 704 / VersionName 0.704.0.
- Base V703. Nome público F1 Team Manager V30 preservado.
- Nome original do ZIP preservado: `F1TeamManager_Android_V30_First_Real_APK_Candidate.zip`.

## Correção aplicada
- O erro reportado pelo GitHub Actions ocorria em `CareerWeekendEngine.kt`, dentro de `choose(action)`: a expressão `when (action)` não cobria `RESTART_ATTACK`, `RESTART_BALANCED` e `RESTART_DEFENSE`.
- As três ações foram adicionadas como valores legados sem efeito no fluxo de decisão normal. Isso satisfaz a exaustividade exigida pelo Kotlin sem reintroduzir controles manuais de postura.
- A tela de relargada continua oferecendo somente os planos A, B, C e D. A escolha de Ataque, Equilibrado ou Poupar continua sendo feita por `aiMode()` a cada volta, inclusive para os pilotos da equipe do jogador.
- `DEFENSE` permanece como identificador interno compatível, mas é apresentado como **POUPAR**.

## Versionamento e integridade
- `app/build.gradle.kts`, `README.md` e `package_manifest.txt` sincronizados em 704 / 0.704.0.
- Base declarada no manifesto: V703 / 0.703.0.
- `CHANGELOG_V704.md` atualizado com a correção.
- O nome público do aplicativo e o nome original do ZIP não foram alterados.

## Validação executada neste ambiente
- Contrato de lançamento: 33/33 verificações aprovadas, incluindo os cinco guardas V704 para ações legadas, opções de relargada, postura automática e rótulo POUPAR.
- Auditoria estrutural: 25/25 verificações aprovadas.
- Regressão focada V703: 15/15 verificações aprovadas.
- Compilação Kotlin direcionada: os 19 arquivos do núcleo `core/race` (incluindo `CareerWeekendEngine.kt`) compilaram com `kotlinc 1.9.0`; foi usado apenas um stub isolado para o enum `CarComponent`, dependência do pacote `core.manager`.
- Auditoria de corrida completa V82 executada como programa Kotlin: aprovada (`V82_FULL_RACE_ENGINE_AUDIT_OK`).
- A auditoria auxiliar V93 de relargada não encontrou a bandeira vermelha esperada com a semente fixa 610 e falhou antes da escolha de plano. Esse cenário não alcança o trecho corrigido; fica registrado para revisão separada.
- Gradle e Android SDK não estão instalados neste ambiente e o ZIP não contém Gradle Wrapper; portanto, não é possível declarar APK compilado aqui. O build Android integral e a suíte JUnit permanecem dependentes do GitHub Actions.
