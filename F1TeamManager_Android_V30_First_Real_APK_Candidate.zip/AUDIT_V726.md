# Auditoria V726 — Metas de classificação e corrida por força do carro

## Veredito

**A regra solicitada está implementada no código-fonte:** as metas são determinadas exclusivamente pela força do carro. As informações do piloto não são recebidas pelo construtor de metas e, portanto, não podem ajustar a expectativa.

## Caminho do cálculo

- `DriverEvolutionEngine.TargetInput` tem somente `driverId`, `teamId` e `carStrength`.
- `buildIndividualTargets()` agrupa os 80 pilotos por equipe, exige 40 equipes com dois pilotos cada e ordena os construtores pela força média dos carros.
- A meta dos dois pilotos é o ponto médio do bloco do carro na escala 1–80: P2, P4, P6 ... P80.
- A meta de classificação e a meta de corrida usam o mesmo centro, cada uma com tolerância de ±3 posições e limites de P1 a P80.
- Atributos e Overall do piloto continuam influenciando a simulação do resultado real; não participam da meta.

## Integração de temporada

- `CareerPreferences.startNextSeason()` não inicializa metas com o carro anterior.
- `MainActivity.performStartNextSeason()` constrói o carro novo, aplica o regulamento e só então obtém a fotografia das 40 forças de carro e inicializa as metas.
- O cálculo da fotografia usa a garagem recém-construída do jogador e as garagens simuladas da IA; o mesmo snapshot abastece o ranking de abertura.
- A inicialização de saves ativos recalibra metas V725 antigas uma vez. Os mapas são versionados e permanecem congelados durante a temporada.
- `ManagerSeasonEngine` invalida metas antigas quando o marcador de contrato V726 está ausente, mesmo se o mapa anterior já tiver 80 entradas.

## Evolução e regressão preservadas

O cálculo do índice continua usando 40% da classificação e 60% da corrida. A faixa de tolerância e os níveis de evolução/regressão não foram alterados. O resultado individual contra uma meta comum ao carro determina o índice de cada piloto; os sete atributos continuam evoluindo/regredindo conforme o motor existente.

## Verificações realizadas

- Fonte de `DriverEvolutionEngine` e dependências Kotlin mínimas compiladas com `kotlinc` sem erros.
- Smoke test independente aprovado: 80 pilotos, 40 carros, metas iguais entre companheiros, centro P2 a P80, tolerância ±3 e reposicionamento das metas quando somente a força de um carro muda.
- Chamadas de `TargetInput` e geradores verificadas por busca estática: nenhum caminho ativo passa Overall ou Qualificação do piloto para a geração de metas.
- Teste de integração do `ManagerSeasonEngine` foi atualizado para simular um mapa V725 sem versão e exigir sua migração para o contrato car-only.
- `DriverEvolutionV674Test` falhou no cenário de crescimento de um piloto Overall 78 da classe Médio. Reexecutei a mesma versão do teste com os fontes originais V725 e a falha é idêntica: o teto Médio (69) mais a margem temporária máxima (3) fica abaixo do Overall inicial (78). Trata-se de uma expectativa de teste antiga e independente da regra de metas V726; não foi alterado o motor de evolução nesta revisão.

## Limitações

A compilação integral dos 77 arquivos Kotlin puros do núcleo excedeu o limite de execução nas tentativas realizadas. O ambiente não tem Gradle, Gradle Wrapper ou Android SDK, então não foi possível executar JUnit completo nem gerar APK. A auditoria não certifica a execução Android em dispositivo.

Para saves V725 que já estejam no meio da temporada, e não tenham uma fotografia histórica da força de todas as equipes na abertura, a migração recalibra uma vez com os melhores valores de carro disponíveis no save e congela as novas metas. A partir da próxima virada, a fotografia exata das 40 garagens novas será usada.
