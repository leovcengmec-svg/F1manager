# V626 (0.626.0)

- Rolagem vertical na tela Minha Carreira.
- Cards de Contrato e Metas Cumpridas com espaço vertical preservado.
- Objetivos interativos com expansão/recolhimento.
- Metas de classificação sinalizadas em verde/vermelho conforme posição atual, sem simular progresso para objetivos sem dados disponíveis.
