# Auditoria V540 — Taxas de contratação

Corrigido DriverMarketEngine.signatureFeeFor e signatureFeeForRenewal para aplicar a regra solicitada: 20% para piloto livre, 20% para renovação e 40% para contratação de piloto de outra equipe. O cálculo é sobre o valor de mercado do piloto, nunca sobre o salário.

Adicionado V540DriverSignatureFeePercentTest com casos para os três caminhos. O fluxo de agendamento continua parcelando a taxa pelos GPs restantes usando SignatureFeeAccounting.

Verificações: estrutura do código e pacote ZIP. Não foi possível executar Gradle/JUnit neste ambiente; build Android pendente.
