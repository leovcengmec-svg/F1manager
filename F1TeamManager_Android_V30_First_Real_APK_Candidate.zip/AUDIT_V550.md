# Auditoria V550 — integração e verificações

## Correção aplicada

O motor alternativo/headless `ManagerSeasonEngine` avançava a temporada e construía o carro novo sem executar `AnnualCarRegulationEngine` no carro do jogador. Isso divergia do fluxo principal da `MainActivity`. Agora, após `CarDevelopmentEngine.startNextSeason`, gera a regra para o ano de calendário, aplica a regra aos dois carros físicos, reinicia versões instaladas para V0 e sincroniza o estado legado antes de recalcular a classificação técnica.

O mesmo motor criava instâncias de `AITeamDevelopmentEngine` com sementes derivadas para desenvolvimento e, implicitamente, para regulamento. Agora o parâmetro `regulationSeed` é separado e passado explicitamente para todas as instâncias da IA usadas por `ManagerSeasonEngine`. O construtor mantém compatibilidade com chamadas existentes (`regulationSeed` assume `seed` quando não fornecido).

O validador `audit_v445_regulation.py` foi atualizado: ele verifica a semente compartilhada persistida e a integração dos caminhos principal e alternativo, sem exigir uma semente constante obsoleta.

## Resultados estáticos

- Integridade ZIP antes das alterações: válida.
- Auditoria de transição: 9/9.
- Auditoria de regulamento: 4.772/4.772.
- Continuidade financeira: 13/13.
- Modelo financeiro: 7/7.
- Estrutura do projeto/assets/histórico: 32/32.
- Ciclo de jogo: 18/18.
- Persistência de IA: 8/8.

Os modelos de estresse financeiros são ilustrativos e não substituem a execução do motor real.

## Limitações

Não foi possível compilar o Android nem executar JUnit nesta máquina, pois não há `gradle` instalado e o ZIP não contém `gradlew`/Gradle Wrapper. Portanto, nenhum resultado de build ou de teste Kotlin em runtime é declarado como aprovado. A alteração no teste `TwoSeasonChainAuditTest` foi adicionada ao código-fonte, mas não executada.

## Preservação

Mantidos os assets externos de pilotos, equipes, carros e circuitos, além dos documentos de histórico das versões anteriores. Não foram alteradas as probabilidades de acidentes, falhas mecânicas ou demais regras de corrida.
