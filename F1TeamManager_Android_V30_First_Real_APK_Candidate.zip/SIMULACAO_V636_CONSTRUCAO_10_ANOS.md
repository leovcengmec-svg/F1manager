# Simulação de construção dos carros em 10 anos — V636

## Resultado executivo

**A tabela de construção está coerente e monotônica; o maior risco encontrado está na revolução regulamentar da temporada 11 (2036), que derruba drasticamente o desempenho de todos os carros depois da construção.** A regra de investimento zero também se comportou como solicitado: o carro não mantém a força antiga; com seis peças instaladas, o piso físico observado é Overall 1.

## Como a simulação foi feita

- **Base:** código V636 real de `CarDevelopmentEngine` e `AnnualCarRegulationEngine`, com modelo de dados isolado equivalente às classes físicas do projeto para executar o teste de estresse fora do aplicativo.
- **Grid:** 40 equipes oficiais do `WorldDatabase`, com os níveis Forte/Médio/Fraco, valores iniciais e confiabilidades reproduzindo o cálculo de `InitialTeamProfile` (semente inicial 20261008).
- **Duração:** 10 transições anuais, de 2026→2027 até 2035→2036. A última transição inclui a revolução regulamentar decenal da temporada 11.
- **Regulamentos:** regras anuais reais do motor de regulamentos, usando a semente determinística 20261005.
- **Estratégia nominal da IA:** mesma função inversa da tabela e os mesmos limites de ganho do código V636: até +3 para Overall abaixo de 60, até +2 entre 60 e 79, e sem crescimento gratuito a partir de 80.
- **Cenários de orçamento:** além da referência nominal, foram simulados tetos hipotéticos de €25M e €35M por construção e investimento zero. Os tetos limitam a referência calculada; **não** simulam todo o fluxo financeiro do jogo.

**Limite importante:** esta é uma simulação de construção + regulamentos, não uma carreira end-to-end. Ela não executa o pipeline real de P&D/fábrica, receitas e despesas, mercado de pilotos, resultados de corrida ou salvamento. Por isso, os números são evidência estrutural do modelo de construção e do impacto regulamentar, não uma previsão exata de uma carreira completa.

## 1. Trajetória nominal da IA

| Transição | Overall médio antes da construção | Investimento de referência médio | Carro construído, antes do regulamento | Overall médio após o regulamento |
|---|---:|---:|---:|---:|
| Início de 2026 | 50,40 | — | — | 50,40 |
| 2026 → 2027 | 50,40 | €22,28M | 53,35 | 52,05 |
| 2027 → 2028 | 52,05 | €24,78M | 54,75 | 53,00 |
| 2028 → 2029 | 53,00 | €26,00M | 55,50 | 53,45 |
| 2029 → 2030 | 53,45 | €26,75M | 55,95 | 54,93 |
| 2030 → 2031 | 54,93 | €28,80M | 57,50 | 55,53 |
| 2031 → 2032 | 55,53 | €29,90M | 58,08 | 57,30 |
| 2032 → 2033 | 57,30 | €33,15M | 59,85 | 58,95 |
| 2033 → 2034 | 58,95 | €36,30M | 61,30 | 60,68 |
| 2034 → 2035 | 60,68 | €39,55M | 62,98 | 62,05 |
| 2035 → 2036 — revolução decenal | 62,05 | €41,70M | 64,23 | **40,08** |

Nos nove primeiros regulamentos de transição, o Overall médio cresceu de 50,40 para 62,05. Isso indica evolução gradual sem saturação instantânea. Na transição decenal, porém, o carro é construído com média 64,23 e cai para 40,08 após a aplicação do regulamento — uma perda de **24,15 pontos**, cerca de **37,6%** do valor pré-regulamento.

## 2. Comparação de cenários

| Política | Média do carro construído para 2036, antes do regulamento | Média após o regulamento decenal | Faixa final entre as 40 equipes | Equipes abaixo de Overall 40 |
|---|---:|---:|---:|---:|
| Referência nominal da IA | 64,23 | **40,08** | 36–44 | 14 |
| Teto hipotético de €35M | 60,75 | **37,75** | 36–40 | 38 |
| Teto hipotético de €25M | 55,00 | **34,18** | 33–37 | 40 |
| Investimento zero | 1,00 físico | **1,00** | 1–1 | 40 |

O teto de €25M limita a evolução já antes da revolução: o Overall médio no fim de 2035 fica em 54,08, contra 62,05 na estratégia nominal. Com €0, todos os carros caem para o piso físico 1 na primeira construção seguinte. Isso confirma que, em V636, menos investimento não preserva o desempenho antigo.

Os tetos de €25M e €35M são cenários de estresse, não afirmações de que a IA real investirá exatamente esses valores; as finanças completas não estão simuladas aqui.

## 3. Conferência da tabela investimento × Overall

| Investimento | Overall-base | Alvo após bônus único de 10% | Resultado físico observado com as seis peças instaladas |
|---:|---:|---:|---:|
| €0M | 0 | 0 | 1 — piso por componente físico |
| €1M | 5 | 6 | 6 |
| €4M | 20 | 22 | 22 |
| €8M | 40 | 44 | 44 |
| €25M | 50 | 55 | 55 |
| €43M | 59 | 65 | 65 |
| €50M | 62 | 68 | 68 |
| €70M | 70 | 77 | 77 |
| €100M | 78 | 86 | 86 |
| €150M | 100 | 100 | 100 |

A escada não permite que um investimento menor resulte num alvo nominal maior. O bônus de 10% é aplicado uma vez, e o construtor normaliza as peças instaladas para o alvo possível sem inventar componentes ausentes.

## 4. Avaliação e recomendação

**O que está funcionando:**

- A mesma tabela determina o nível de construção para todos os valores de investimento, inclusive zero.
- O investimento zero derruba a força do carro para o mínimo físico, sem reutilizar o Overall antigo.
- Os alvos da IA são invertidos a partir do bônus único de 10%; a construção nominal não cresce automaticamente até 100.
- Os limites de €25M/€35M demonstram que limitar o investimento deixa o carro mais fraco.

**O ponto que eu não consideraria fechado ainda:** a regra decenal aplicada depois da construção é muito severa. Na simulação, ela comprime o grid para Overall 33–44, inclusive para equipes que acabaram de investir mais de €40M em média. A tabela pode continuar sendo a referência universal, mas é preciso decidir se esse colapso na temporada 11 é intencional.

Minha recomendação é manter a tabela como regra única de construção e, antes da temporada decenal, fazer a previsão e a escolha do investimento considerarem o regulamento conhecido da temporada seguinte. Assim a meta pode representar o Overall pretendido **após** o regulamento, sem criar um segundo bônus gratuito. Se o objetivo for uma revolução realmente destrutiva, então as reduções atuais podem ser mantidas — mas isso deve ser tratado como uma decisão de balanceamento, não como resultado neutro da construção.

## Validações disponíveis

- Auditoria específica da construção V636: **16/16 verificações aprovadas**.
- Validação estática geral do projeto: **40/40 verificações aprovadas**.
- Teste de execução: 40 equipes × 10 transições, com o construtor V636 e o motor real de regulamentos.
- Não foi executada build Android nem simulação integral da carreira dentro do aplicativo neste ambiente.
