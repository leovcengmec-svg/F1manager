# V357 — Idempotência da evolução dos pilotos

- Adicionado ao estado da carreira o conjunto `driverEvolutionProcessedRounds`, com chaves `temporada:rodada`.
- `ManagerSeasonEngine.applyDriverEvolution` retorna o estado sem alterações quando a evolução daquele GP já foi aplicada.
- Ao concluir a evolução, a chave da rodada é anexada ao estado retornado para acompanhar o snapshot da carreira.
- Incluídos testes de regressão para escopo de chaves por temporada/rodada e replay de marcador.
- Versão Android atualizada para `0.357.0`.
- Nenhuma alteração de interface, botões, assets externos ou histórico anterior.

## Limites conhecidos
- Os testes JUnit e o build Android não foram executados neste ambiente: o ZIP não contém `gradlew`/wrapper Gradle.
- A garantia depende de `TeamManagerState` ser persistido como um todo após a aplicação da evolução. Não torna atômica a gravação dos atributos e do marcador em armazenamentos separados.
