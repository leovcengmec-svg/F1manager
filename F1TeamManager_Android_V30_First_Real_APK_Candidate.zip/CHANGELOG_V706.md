# V706 — equilíbrio de demissão e metas do Team Principal

Base: V705 (`versionCode 705`, `versionName 0.705.0`).  
Nova revisão: V706 (`versionCode 706`, `versionName 0.706.0`).  
Nome público e nome padrão do ZIP preservados.

## Contratos e demissão

- No primeiro ano de um contrato de dois anos (1/2), o gestor fica protegido de demissão quando cumpre pelo menos três metas e o apoio projetado/persistido da diretoria fica estritamente acima de 50.
- A proteção é aplicada tanto ao cálculo de risco exibido durante a temporada quanto à liquidação ao encerramento, evitando divergência entre tela e decisão real.
- Contrato de um ano (1/1) e segundo ano de contrato de dois anos (2/2) recebem avaliação explícita da meta principal ao fim do contrato. Não há demissão automática: o motor calcula probabilidade a partir do apoio da diretoria, distância da faixa de posição, desempenho de corrida/classificação, finanças, desenvolvimento, instalações e cumprimento de metas secundárias.
- O descumprimento da meta principal no ano final aumenta a probabilidade de demissão em intensidade graduada pelo apoio da diretoria; cumprir a meta principal continua limitando o risco.

## Metas do campeonato de construtores

- Para metas principais entre 11º e 20º, é aceita uma posição adicional além da meta.
- Para metas principais entre 21º e 40º, são aceitas até duas posições adicionais. Exemplo: meta 25º aceita 25º, 26º e 27º; terminar melhor que 25º também cumpre a meta.
- Metas entre 1º e 10º não recebem tolerância adicional. O 1º lugar é identificado como título/campeonato, sem a expressão impossível “1º ou melhor”.
- Avaliação esportiva, apoio da diretoria, previsão de risco, conquistas e histórico consideram o limite superior da mesma faixa.
- A faixa é serializada em cada objetivo. O decoder aceita saves anteriores, deriva a tolerância para os objetivos principais legados e grava no novo schema 6.

## Validação

- Harness Kotlin compilado com o `TeamPrincipalCareerEngine.kt` real e stubs mínimos apenas para tipos de garagem/instalações externos ao escopo: passou pelos cenários de proteção 1/2 mesmo com a meta principal perdida, demissão sob risco no 1/1 e 2/2, tolerâncias 1º–10º/11º–20º/21º–40º, faixa 25º–27º e migração V705 para schema 6.
- Testes JUnit adicionados em `TeamPrincipalDismissalAndObjectiveBandsV706Test.kt` para cobrir esses contratos.
- Auditoria estática específica, integridade global e contrato de release executados separadamente; ver `AUDIT_V706_STABILIZATION.md`.
- A compilação Android/Gradle e a suíte JUnit integral dependem de Gradle/Android SDK não presentes neste ambiente; o workflow GitHub permanece necessário para validar o APK final.
