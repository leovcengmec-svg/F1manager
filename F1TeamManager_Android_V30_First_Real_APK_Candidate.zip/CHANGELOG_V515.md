# V515 — Ajustes visuais da retrospectiva de temporada

- Banner de temporada encerrada agora usa elementos visuais de troféu e bandeira quadriculada como referência ao fim do campeonato, em vez de usar um carro como fundo genérico.
- Os quatro cards de grandes acontecimentos usam ícones temáticos coerentes: títulos/troféus, vitórias/evolução, GPs/bandeira e poles/estrela.
- Títulos padronizados para `Títulos`, `+ Vitórias`, `GP + Abandonos` e `+ Poles`.
- Títulos dos quatro cards ficam em uma única linha, sem quebra; todos os cards preservam o mesmo peso e estrutura de layout.
- Descrições continuam ligadas aos dados históricos disponíveis; quando não há dado para um dos quatro itens, é mostrado um texto de fallback.
- Versão Android atualizada para `versionCode 515` / `versionName 0.515.0`.
- Validação estática e integridade do ZIP executadas. Compilação Android e testes JUnit permanecem pendentes em ambiente com Gradle.
