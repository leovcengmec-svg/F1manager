# V410 — Consistência do mercado de pilotos

- Corrigido o cancelamento financeiro de renovações/contratações programadas: a notícia positiva não pode continuar afirmando que o acordo foi concluído depois de o compromisso ser removido por falta de saldo.
- O cancelamento agora remove o compromisso e a proposta associada, registra histórico e cria uma notícia explícita de negociação encerrada por saldo insuficiente.
- A mesma rotina é aplicada a compromissos da equipe do jogador e das equipes de IA.
- Corrigida a leitura dos contratos persistidos para preservar o papel do piloto no contrato salvo no formato atual.
- Corrigida a leitura dos acordos futuros para preservar `replaceDriverId` no formato atual; isso mantém a substituição escolhida pelo usuário após fechar e reabrir o jogo.
- Adicionado teste de regressão para renovação programada, elegibilidade no filtro ABERTO e rollback financeiro coerente com a Central de Notícias.
- Sem alterações de layout ou assets.
