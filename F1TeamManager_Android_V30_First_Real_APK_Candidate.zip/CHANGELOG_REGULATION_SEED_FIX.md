# Correção — sorteio dos regulamentos anuais

- Removida a semente fixa `20261005` do sorteio de regulamentos anuais do jogador.
- Adicionada `carRegulationSeed`, persistida uma vez por carreira e compartilhada entre as equipes para manter o regulamento de campeonato idêntico para todos.
- Ao iniciar uma carreira nova, a semente é renovada usando a semente inicial da carreira e as regras anuais persistidas da carreira anterior são limpas.
- A cadeia física histórica da IA recebe a mesma semente regulatória da carreira.
- Regras já salvas continuam sendo carregadas sem novo sorteio; novas regras permanecem determinísticas para que salvar/carregar não as altere.
- Adicionado teste garantindo que sementes de carreiras diferentes produzam sequências anuais diferentes.

Validação: inspeção das alterações e integridade do ZIP. A compilação/testes Gradle não foram executados porque o projeto não inclui Gradle Wrapper e não há instalação de `gradle` disponível neste ambiente.
