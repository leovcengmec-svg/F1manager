# Vistoria da tela principal — V593

## Mapeamento da tela real

1. Ponto de entrada: `app/src/main/java/com/f1teammanager/MainActivity.kt`, ramo `Screen.MAIN_MENU`.
2. Componente de layout: `app/src/main/java/com/f1teammanager/MainMenuScreen.kt`, função `MainMenuScreen`.
3. Fundo: `app/src/main/res/drawable-nodpi/menu_garage_background.png`, carregado por `R.drawable.menu_garage_background` com `ContentScale.Crop`.
4. Ações integradas: `onNewGame` navega para `Screen.NEW_GAME_MODE`; `onContinue` navega para `Screen.LOAD_GAME`; `onSettings` navega para `Screen.SETTINGS`.
5. Estado do card continuar: recebe `hasCareer`; o botão fica desabilitado se não há carreira salva.
6. Cards compartilhados: `MenuOptionCard`, com largura completa, pesos iguais na coluna, ícones e chevrons alinhados.
7. Configurações: `InitialSettingsScreen` permanece fora da alteração visual.
8. Rolagem: `MainMenuScreen` não usa `verticalScroll`/`LazyColumn`; o layout é limitado à viewport e usa insets das barras do sistema.

## Diferenças corrigidas nesta revisão

- Ícone de Novo Jogo passou de bandeira genérica para bandeira quadriculada desenhada em Canvas.
- Cards passaram a usar recortes angulares para se aproximar da referência aprovada.
- Textos usam a coluna flexível disponível e `TextOverflow.Ellipsis`, em vez de corte abrupto quando o espaço horizontal é limitado.
- Mantidos estado e callbacks originais, sem criar fluxo de carreira fictício.

## Verificações e limitações

- Verificação estática de referências e estrutura feita no código-fonte.
- A compilação Android, JUnit e screenshot no POCO X7 Pro não foram executados neste ambiente; não declarar a renderização final certificada até testar em build/dispositivo.
- Não foram removidos assets, histórico de versões ou telas adjacentes.
