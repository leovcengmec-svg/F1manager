# Vistoria geral da virada de temporada — V425

## Escopo da vistoria
Fluxos de encerramento da temporada, arquivo do histórico, criação do carro novo, investimento por Overall, mercado de pilotos, controle de investimento técnico anual, orçamento/salários, calendário e persistência.

## Correção aplicada
- **Controle de investimento técnico anual (corrigido):** o fluxo manual da tela de início de temporada carregava o `TechnicalInvestmentState` que `CareerPreferences.startNextSeason()` havia criado usando o carro salvo antes da virada. Isso podia manter ranking e teto anual da temporada anterior. Agora `MainActivity.startNextSeason()` recria esse controlador depois de construir o carro novo, usando `managerState.car`, e começa com gastos anuais zerados.
- Adicionado teste-fonte para conferir que o ranking do controlador técnico é calculado a partir do carro passado e que o novo período inicia sem gastos acumulados.
- Incrementado `versionCode` para 425 e `versionName` para `0.425.0`.

## Fluxos e invariantes conferidos estaticamente
- O GP final é arquivado antes de permitir a virada manual; `CareerPreferences.isSeasonEnded()` exige a última rodada e a temporada finalizada no histórico.
- A virada manual é explícita; a temporada não avança automaticamente ao apenas concluir o GP final.
- `CarDevelopmentEngine.startNextSeason()` usa o Overall do carro anterior (média dos dois carros físicos quando a garagem existe), consulta a referência individual 40–100 e aplica os passos de investimento ao carro novo.
- O investimento reservado é zerado no carro novo e o foco volta ao padrão, impedindo reaplicação na temporada seguinte.
- A garagem física dos dois carros é reconstruída e salva; os identificadores de peças instaladas são renovados para a temporada nova.
- Pontos de pilotos/construtores são limpos, a rodada retorna a 1, a semana retorna a 1, um calendário novo é gerado e as atribuições de início da temporada são registradas.
- O mercado de pilotos executa contratos programados e preenche vagas; o mercado persistido é carregado para o estado ativo do manager.
- O controle financeiro técnico anual é recalculado a partir do carro novo e os gastos anuais recomeçam em zero.
- A penalidade financeira de encerramento é aplicada após a construção do carro e antes de persistir o estado final.
- O fluxo de simulação de temporadas (`ManagerSeasonEngine`) também chama o mesmo `CarDevelopmentEngine.startNextSeason()`, mas possui sua própria sequência de fechamento.
- O evento visual de início de temporada é marcado por temporada, evitando que seja reapresentado continuamente após já ter sido visto.
- Histórico de versões e diretórios de assets externos foram preservados; nenhuma alteração de layout foi feita.

## Pendências / riscos encontrados
1. **Fechamento não é uma transação única:** o fluxo manual incrementa a temporada no armazenamento antes de terminar de construir e salvar todos os estados do manager. Uma interrupção do processo entre essas etapas pode deixar a temporada avançada com alguns dados antigos. O guard impede uma segunda virada normal, mas não recupera automaticamente todos os estados de uma interrupção no meio. Recomenda-se um journal/checkpoint persistente de transição com recuperação idempotente.
2. **Há dois orquestradores de virada:** `MainActivity`/`CareerPreferences` (carreira Android persistida) e `ManagerSeasonEngine` (simulação em cadeia). Eles compartilham o motor de criação do carro, mas não uma única função de orquestração; testes futuros devem comparar seus invariantes de mercado, finanças, garagem, calendário e histórico.
3. **Cobertura automatizada da virada manual é parcial:** os testes de cadeia cobrem duas temporadas no motor de simulação, e os testes de investimento cobrem o motor de carro; não há ainda um teste end-to-end que inicialize `CareerPreferences`, conclua 30 GPs, interrompa/reabra o app durante a virada e verifique todos os dados persistidos.
4. **Build e testes não executados:** o pacote não inclui `gradlew`/wrapper e `gradle` não está instalado neste ambiente. A vistoria é estática e a integridade do ZIP será verificada separadamente.

## Conclusão
A vistoria encontrou e corrigiu um erro real no teto de investimento técnico da temporada nova. A regra dinâmica de investimento do carro está conectada ao motor de construção, mas a virada ainda não deve ser declarada 100% validada até adicionar recuperação transacional e executar os testes Android/end-to-end.
