# V691 — prioridade do próximo carro, fechamento de premiação e virada financeira

## Correções

- A reserva inicial de €80 milhões para o carro seguinte é calculada sobre o envelope anual original e permanece protegida contra consumo antecipado por P&D/instalações até ser financiada ou chegar à janela de liberação do GP25.
- A janela de liberação do GP25 continua permitindo redirecionar ao próximo carro o saldo que P&D/instalações realmente não utilizaram, sem ultrapassar o envelope global de €200 milhões nem o teto absoluto de €150 milhões por projeto.
- O início de uma temporada nova transporta o caixa e os registros históricos, mas zera os indicadores de receita/despesa da temporada e cria explicitamente um novo ledger técnico de €200 milhões.
- Compromissos do carro seguinte, saldo de P&D, saldo de instalações, base de investimento e sinalizadores do ano anterior não podem contaminar o envelope da nova temporada.
- A consulta de `Invest. Disponível` sincroniza primeiro a temporada do estado financeiro e do ledger técnico, evitando mostrar o caixa de uma temporada junto com o limite de outra.
- O painel geral das equipes sincroniza os 39 estados financeiros da IA antes de capturar os dados exibidos.
- A premiação de construtores congela uma classificação durável das 40 equipes antes de iniciar qualquer crédito. Usa a tabela histórica final validada quando disponível; se o arquivo anual de corridas estiver incompleto, usa a tabela oficial de pontos da carreira no GP30 e mantém todas as equipes, inclusive as que terminaram sem pontos.
- A classificação congelada permite retomar pagamentos parciais depois de encerramento inesperado do app. Os ledgers financeiros de cada equipe permanecem a autoridade de idempotência; nenhum pagamento é repetido.
- A reconciliação também procura snapshots de classificação de premiação pendentes, mesmo quando o arquivo histórico de corridas não conseguiu finalizar o resumo anual. É executada antes da imagem de rollback da virada de temporada.
- A virada Android executa uma abertura explícita do envelope anual para as 39 equipes de IA, mesmo se um snapshot legado já tiver mudado o campo `season` mas mantido débitos técnicos antigos. O caixa e os marcadores históricos de premiação são preservados.
- A auditoria/documentação da v690 foi corrigida para refletir a implementação real da reserva inicial fixa de €80 milhões, em vez de descrever uma reserva de 40% do saldo decrescente.

## Testes adicionados/atualizados

- Confirma que o débito do próximo carro aparece nas despesas da mesma temporada.
- Confirma que a nova temporada recebe €200 milhões disponíveis mesmo quando a primeira leitura é feita pela tela de orçamento antes de `beginSeason()` ser chamado por outra rotina.
- Confirma que a abertura explícita da virada corrige um snapshot legado com `State.season` já atualizado, mas com débitos técnicos residuais, preservando o caixa.
- Confirma que a classificação de prêmio cobre as 40 equipes e que os ledgers AI são idempotentes após replay.
- Confirma que o caixa real é carregado, os contadores anuais são zerados e a premiação não é duplicada após restaurar o snapshot.
- Mantém testes da prioridade de €80 milhões, do pool flexível P&D/instalações e do teto global de €200 milhões.

## Validação executada neste ambiente

- Compilação isolada de `SeasonInvestmentPolicy.kt` com stub tipado de `TechnicalInvestmentState`: aprovada.
- Smoke test da prioridade de €80 milhões, liberação da capacidade, reserva operacional e teto global: `V691_POLICY_SMOKE_OK`.
- Auditoria estática de versionamento, fluxo de fechamento, persistência de premiação e renovação de ledger: aprovada.
- Compilação Android/APK e suíte JUnit completa: não executadas neste ambiente, pois o projeto não inclui Gradle Wrapper e não há Gradle/Android SDK configurado.
