# Auditoria V603 — Catálogo de objetivos Team Principal

## Problema
A imagem do usuário mostra somente o objetivo principal da diretoria, sem os objetivos complementares do catálogo V598/V599. Isso impede visualizar as metas sazonais e torna a tela incompatível com a atualização do sistema.

## Diagnóstico no código
- O motor `TeamPrincipalCareerEngine` possui catálogo ampliado e gera um objetivo principal mais cinco objetivos complementares.
- `ensureCurrentObjectives` migra carreiras com catálogo vazio/incompleto.
- A leitura da carreira em `CareerPreferences.teamPrincipalCareer()` chama essa migração e persiste a lista atualizada.
- A tela anterior usava uma linha compacta por objetivo, com rótulos genéricos e hierarquia visual insuficiente para o catálogo maior.

## V603
- Reorganiza a área em cards individuais, com objetivo principal em destaque e metas complementares numeradas.
- Cada card mostra título, descrição e recompensa de prestígio.
- Exibe contador da quantidade de objetivos carregados e estado de carregamento caso a lista esteja vazia.
- Ajusta textos de pré-temporada para esclarecer que as metas complementares já estão definidas.
- Mantém a migração de saves e o motor de objetivos V598/V599 sem alterar os critérios esportivos.

## Validação
Testes estáticos específicos e auditorias estruturais são executados no pacote. Build Android e validação visual no dispositivo permanecem pendentes.
