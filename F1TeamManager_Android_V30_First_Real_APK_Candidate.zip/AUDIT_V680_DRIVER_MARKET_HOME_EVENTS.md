# Auditoria V680 — eventos de assinatura do mercado na Home

Base: V679  
Versão: 680 / 0.680.0

## Correções

- Centralizada a emissão do evento de assinatura em `recordCompletedSignature`, com títulos compatíveis com o filtro da Home: `RENOVAÇÃO DE CONTRATO`, `TRANSFERÊNCIA CONFIRMADA` ou `CONTRATO ASSINADO`.
- A emissão ocorre somente depois de `signFuture` concluir com sucesso.
- Corrigidos os caminhos de contraproposta aceita pela IA, fechamento da janela, formação de elenco e aceite de contraproposta/oferta pela interface.
- A virada da temporada registra o evento canônico ao aplicar o contrato futuro.
- A deduplicação considera temporada da assinatura, piloto, destino e temporada de início do contrato.
- A Home apresenta eventos pendentes em ordem cronológica, um por vez, respeitando a marcação de leitura.
- Removido o limite de dez itens do resumo de contratos assinados.
- Propostas pendentes, contrapropostas sem aceite, recusas e negociações não concluídas continuam fora do modal de assinatura.

## Verificações estáticas

10/10 verificações aprovadas:

1. Os três títulos canônicos estão implementados.
2. A aceitação de contraproposta pela IA só gera card após assinatura bem-sucedida.
3. O fechamento da janela utiliza o evento canônico.
4. A formação de elenco não emite mais um título não reconhecido.
5. A aceitação de contraproposta na pré-temporada utiliza o evento canônico.
6. A fila da Home está em ordem cronológica.
7. O resumo não limita a dez contratos.
8. O filtro da Home continua limitado a assinaturas concluídas.
9. VersionCode/VersionName atualizados para 680/0.680.0.
10. Testes de regressão de renovação e transferência adicionados.

## Limitações da validação

A suíte Kotlin/Gradle e a compilação Android não foram executadas neste ambiente, pois não há Gradle instalado nem Gradle Wrapper no pacote. O workflow GitHub Actions foi atualizado para publicar o artefato V680 e executar `:app:testDebugUnitTest` e `:app:assembleDebug`.
