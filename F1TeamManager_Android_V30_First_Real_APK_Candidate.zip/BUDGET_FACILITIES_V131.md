V131 ROOT CORRECTION

- InitialTeamProfile is the single source for opening budget.
- Strong = €100,000,000; Medium = €83,750,000; Weak = €67,500,000.
- Player new-career initialization and player fallback now use InitialTeamProfile.initialBudget().
- AI financial initialization now uses the same canonical function.
- No AI-only discount or opening-budget advantage remains.
- Facility state remains derived from InitialTeamProfile.teamFacilities(initialLevel) for AI and player; no new autonomous AI facility-upgrade behavior was invented in this correction.
- The AI development pipeline continues to obey the same TechnicalInvestmentEngine capacity caps and physical P&D chain; it does not receive extra capacity.
