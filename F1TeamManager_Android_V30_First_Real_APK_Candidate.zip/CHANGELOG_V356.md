# V356 — Idempotência de contratos de patrocínio

- `TeamSponsorshipEngine.advanceRace` agora impede o consumo duplicado de duração de contrato para a mesma equipe, temporada e rodada.
- O snapshot inclui as chaves de rodadas já processadas e continua aceitando snapshots antigos sem metadados V356.
- Adicionados testes de replay após exportação/restauração e de avanço normal para a rodada seguinte.
- Sem mudanças na interface, nos botões, nos assets externos ou no histórico anterior.
