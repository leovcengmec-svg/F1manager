# Auditoria V724 — ranking determinístico e consistência das equipes

## Verificações estruturais

- A publicação do Overall está desativada por padrão nos dois métodos de simulação física.
- O helper `simulateAiDevelopment` usa `publishLiveOverall = false` por padrão.
- `syncAiWeeklyState` captura ranking e Overalls antes do lote e publica explicitamente o resultado da simulação semanal canônica.
- A capacidade financeira recebe snapshots congelados durante o processamento semanal, a Visão das Equipes e o Ranking.
- O Ranking do Próximo Carro constrói a força com investimento efetivo e mantém a projeção em campo separado.
- Continuar Jogo está habilitado mesmo sem carreira ativa.

## Limitação identificada e não mascarada

`simulatePhysicalSeason` ainda reconstrói as semanas desde a primeira semana quando não há cache exato. O estado completo de pesquisa ativa, designs prontos, ordens da fábrica, cooldowns, versões e gastos técnicos permanece em variáveis locais. A V724 reduz recomputações inconsistentes por snapshots e evita publicação de projeções, mas não afirma que o simulador físico passou a avançar incrementalmente de forma persistente. Essa refatoração requer serializar o estado integral da simulação e testar equivalência entre avanço sequencial e avanço em bloco.

## Validação

Verificações Python estruturais documentadas em `tools/v724_deterministic_ranking_audit.py`. Compilação Android, JUnit e benchmark real em dispositivo devem ser executados separadamente.
