# V649 — Reestruturação de classe, Overall e evolução dos pilotos

## Objetivo

Unificar o sistema de Overall, classe, potencial individual e evolução por desempenho. A V649 corrige os pilotos que iniciavam com Overall incompatível com a classe, elimina a regressão obrigatória por passagem do tempo e substitui eventos aleatórios de classe por avaliação esportiva em duas temporadas consecutivas.

## Tabela oficial de classes

| Classe | Faixa inicial de Overall |
|---|---:|
| Fraco | 40–59 |
| Médio | 60–69 |
| Forte | 70–79 |
| Pro | 80–89 |
| Lenda | 90–100 |

O Overall continua sendo a média dos sete atributos reais. As faixas definem o patamar inicial e a referência normal da classe; não são tetos absolutos de evolução.

## Potencial inicial e tabela de evolução

- O potencial individual inicial fica limitado a até duas classes acima da classe inicial: Fraco 79, Médio 89, Forte 100, Pro 100 e Lenda 100.
- O perfil individual de evolução continua definindo o potencial efetivo e a velocidade de desenvolvimento.
- Limites anuais máximos por atributo preservados: Prodígio 15, Auge rápido 13, Auge moderado 11, Auge tardio 10, Normal 8 e Demorado 6.
- O potencial permanece individual e não aumenta automaticamente quando o piloto é promovido.

## Promoção e rebaixamento

A avaliação ocorre somente na virada da temporada e exige duas temporadas consecutivas, cada uma com pelo menos 80% dos GPs previstos registrados (24 de 30 em um calendário de 30 etapas).

**Promoção:** ambas as temporadas com índice médio de desempenho igual ou superior a 100, média conjunta igual ou superior a 105 e Overall pelo menos um ponto acima do início da faixa da próxima classe. No máximo uma classe por avaliação.

**Rebaixamento:** ambas as temporadas com índice médio igual ou inferior a 80, média conjunta igual ou inferior a 80 e Overall pelo menos dois pontos abaixo do início da faixa da classe atual. No máximo uma classe por avaliação.

O índice de cada GP compara classificação e corrida com o objetivo esportivo congelado da equipe/piloto para a temporada. Ausência simultânea de registro de classificação e corrida não conta como evidência.

## Evolução e regressão

- Retirado o ciclo obrigatório de 5 temporadas de crescimento, 2 de auge e 5 de regressão.
- O estado GROWING/STABLE/REGRESSION passa a refletir potencial e resultados, não idade ou tempo de carreira.
- Desempenhos melhores aceleram o desenvolvimento; desempenhos neutros reduzem ou interrompem o crescimento; sequências ruins acumulam regressão gradualmente.
- A classe funciona como limite flexível: o ganho se torna progressivamente mais difícil acima da faixa, sem bloquear por completo um piloto de alto desempenho.
- Evolução por GP e Centro de Desenvolvimento compartilham os limites anuais por atributo e o mesmo fator de classe flexível.
- Os sete atributos permanecem individualizados e dentro de 40–100.
- Sem idade, envelhecimento obrigatório ou aposentadoria.

## Eventos anuais

Novas temporadas não geram eventos aleatórios de ganho, perda ou mudança de classe de pilotos. Slots antigos desses tipos são consumidos como no-op para evitar repetição em calendários salvos. As mudanças de atributos ocorrem por desempenho e pelo Centro de Desenvolvimento; classe muda somente pelo motor de avaliação de duas temporadas.

## Migração de carreiras V648 e anteriores

Na primeira abertura após a atualização:

- Os sete atributos persistidos dos 100 pilotos são normalizados para a faixa da classe-base oficial do catálogo.
- Overrides aleatórios de classe anteriores são removidos.
- Fases passam a GROWING ou STABLE de acordo com a distância até o potencial.
- Dados de evidência de classe do novo sistema começam limpos; a promoção/rebaixamento só poderá ocorrer depois de duas temporadas consecutivas avaliadas pelo novo sistema.
- Histórico de corridas, resultados, pontos, contratos e arquivo histórico não são apagados.

**Impacto esperado:** pilotos acima da faixa da classe por regras antigas podem ter seus atributos ajustados para a faixa da classe-base nesta migração. Isso é intencional: a V648 não guardava evidência compatível com o novo critério de duas temporadas, então não é possível presumir que esses excessos representem promoções esportivas válidas.

## Versão

- `versionCode = 649`
- `versionName = 0.649.0`
