# Especificação visual — Fim de temporada (V417)

Referência: layout aprovado pelo usuário em 12/10/2026.

- Tela integral, sem rolagem vertical ou horizontal.
- Dimensões adaptáveis ao espaço útil do POCO X7 Pro; `BoxWithConstraints` ativa tipografia e espaçamento compactos em telas baixas/estreitas.
- Fundo `#070B10`, painéis `#0D141D`/`#121C27`, bordas `#243342`, vermelho `#F20D22`, dourado `#FFC94A`, azul `#38A5FF` e verde `#16D98A`.
- Cabeçalho, banner de encerramento, campeões em dois cards iguais, até quatro acontecimentos, três painéis inferiores e botão final.
- Títulos e texto usam a largura disponível; nomes longos recebem quebra em até duas linhas ou ellipsis apenas em rótulos pequenos onde a largura é estruturalmente limitada.
- Ícones Material Compose: troféu, bandeira, automobilismo, estrela e tendência.
- Carros, retratos e escudos reutilizam `ExternalAssets`.
- Dados entram via `SeasonEndSummary`; preencher esse modelo a partir de `HistoricalDatabase` na integração.
- O front-end não define fatos de temporada fictícios nem contém dados de demonstração fixos.
- A integração com a navegação e persistência de exibição única ainda não foi feita.
