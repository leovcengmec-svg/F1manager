# Auditoria V666 — Estratégia individual de pneus da IA

## Escopo
Correção do planejamento e execução de pneus dos pilotos controlados pela IA, mantendo separados os planos A/B/C/D e os planos livres da equipe do jogador.

## Alterações
- `TyreModel.buildAiRaceStrategy()` gera um plano por piloto, usando atributos individuais, força da equipe, grid e clima.
- `CareerWeekendEngine` mantém `aiStrategies` separado de `plans`, preservando a API de planos do jogador.
- Cada stint possui duração prevista; em corridas secas normais, o plano limita-se a até três paradas. A troca ocorre na janela planejada ou antes dela quando o desgaste chega ao limite operacional.
- O perfil de conservação e o estilo competitivo influenciam a escolha entre estratégias de duas ou três paradas; a sequência e os intervalos variam por piloto.
- Mudança para chuva/seco, Safety Car, furo e bandeira vermelha atualizam a estratégia sem voltar à sequência fixa anterior. Corridas personalizadas muito longas também mantêm alternância segura de compostos no fallback.
- `SessionSnapshot.aiTyreStrategies` permite auditar os planos sem expor controles da IA na interface do jogador.

## Critérios cobertos por teste
- Diversidade de sequências e compostos de largada em pista seca.
- Diferença de estratégia entre companheiros com habilidades distintas.
- Uso exclusivo de INTERMEDIATE/WET em condições de chuva correspondentes.
- Cobertura de todas as voltas e distribuição de stints positivos.
- Criação de 78 planos privados para IA, mantendo exatamente dois planos editáveis para o time do jogador no grid de 80 pilotos.

## Limitação de validação
A compilação Android e a suíte Gradle completa dependem do Gradle/Android SDK do ambiente de build. O pacote não contém Gradle Wrapper. O núcleo Kotlin e os testes específicos V666 são compilados/executados isoladamente com o compilador Kotlin disponível; a validação estática do projeto e a integridade do ZIP são verificadas separadamente.

## Validação executada
- Compilação isolada do núcleo Kotlin de corrida: concluída com sucesso.
- 16 testes unitários direcionados/regressivos: aprovados (V666, planos livres V659, preparação climática V632, regressão de stint curto com chuva e penalidades de pneus de chuva V198).
- 4 simulações completas de 58 voltas com 80 pilotos: concluídas, com diversidade observada nas estratégias secas e molhadas.
- Validador estático do projeto: 45/45 verificações aprovadas.
- A compilação Android/Gradle completa não foi executada neste ambiente: não há Gradle instalado nem Gradle Wrapper no ZIP.
