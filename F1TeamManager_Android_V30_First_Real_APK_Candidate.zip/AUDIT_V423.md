# Auditoria V423

- Referência financeira: tabela indexada por Overall, cobrindo 40–100 (61 pontos).
- Valores únicos e estritamente crescentes verificados durante a geração da tabela.
- Limite inferior/superior: €8M/€150M.
- Testes-fonte atualizados; execução de Gradle/testes Android não confirmada nesta entrega.
