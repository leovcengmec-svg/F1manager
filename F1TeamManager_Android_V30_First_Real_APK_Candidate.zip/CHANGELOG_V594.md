# V594 — Auditoria integral e correção de estratégia em chuva

Base de origem: V593 oficial.

## Correções
- Corrige a geração automática dos planos de pneus de chuva quando restam poucas voltas na corrida.
- Limita o número de stints às voltas efetivamente restantes, evitando stints de zero voltas e falha da simulação.
- Mantém os quatro identificadores de estratégia A/B/C/D, inclusive no encerramento da corrida; para poucas voltas, alguns planos podem ser equivalentes.
- Adiciona teste de regressão para chuva fraca, moderada e forte com 1, 2 e 3 voltas restantes.

## Auditoria e validação
- Mantidos os checks de cadeia anual, calendário, corrida, mercado de pilotos, finanças, P&D, fábrica, garagem física, evolução de pilotos, contratos e persistência existentes.
- Adicionada simulação isolada com o motor Kotlin real para 60 GPs por modo (duas temporadas de 30 GPs): Livre, Difícil e Time Principal.
- A simulação é aceita somente se validar grid, classificação, qualificação, pontos, contratos ativos, caixa não negativa, marcadores de evolução, fechamento de temporada e os registros bienais do Time Principal.
- A compilação Android/Gradle e os testes JUnit oficiais não foram executados neste ambiente, que não possui wrapper/Gradle/ADB. Os resultados da simulação Kotlin isolada são descritos separadamente no relatório de auditoria.
- Corrige negociações concorrentes: após a assinatura futura de um piloto, as propostas rivais para a mesma temporada são fechadas e respostas antigas do lote de expiração são ignoradas.
- Durante o preenchimento de vagas na virada, o resolvedor agora expira apenas a proposta do piloto/equipe em processamento, impedindo que assinaturas de outras negociações sejam criadas depois da lista inicial de contratos vencidos.
- Adiciona regressão para impedir contratos futuros duplicados e notificações falsas de falha de assinatura.

## Testes concluídos
- Simulação dos três modos — 60 GPs por modo / duas temporadas por modo: Livre, Difícil e Time Principal passaram; 180 corridas, 6 viradas de temporada somadas e nenhum contrato vencido pendente no estado final.
- Regressão focada de pneus e propostas concorrentes: passou.
- Eventos anuais: 3.066 asserções e stress de 200 temporadas passaram.
- Finalização/recovery de GP: nove etapas, interrupção, retomada e replay idempotente passaram.
- Corrida direcionada: 200/200 corridas completadas; transições de clima e combustível cobertas.
- Cadeia independente de duas temporadas: 60/60 GPs passaram.
- Auditorias de projeto/release 40/40 e 25/25; transição 9/9; ciclo de jogo 18/18; continuidade financeira 13/13; modelo financeiro 7/7; regulamentos 4.772/4.772.
- Compilação Android e suite JUnit/ADB permanecem pendentes por indisponibilidade do Gradle e Android SDK neste ambiente.
