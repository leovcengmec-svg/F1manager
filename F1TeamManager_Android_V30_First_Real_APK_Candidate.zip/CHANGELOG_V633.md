# V633 (0.633.0)

- Objetivos da diretoria são recalibrados no início da temporada, após construção do carro novo e aplicação do regulamento, usando a força real de abertura do grid.
- Dificuldade considera força do carro, resultado e pontuação anteriores, saldo real e níveis das instalações.
- Renovação e mudança de equipe não geram objetivos com níveis de instalação zerados por padrão quando há dados de equipe disponíveis.
- Corrigida a avaliação do objetivo de reserva financeira para ler o caixa real da equipe controlada.
- Persistido o marcador de calibração por temporada com compatibilidade para saves dos schemas 1–3.
