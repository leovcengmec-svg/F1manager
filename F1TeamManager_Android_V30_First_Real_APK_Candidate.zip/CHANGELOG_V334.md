# V334
- Corrigida a repetição de eventos anuais de temporadas anteriores na Home.
- Eventos anuais históricos permanecem na Central de Notícias, mas deixam de gerar popups e contadores de pendências na Home.
- Aplicada a mesma regra de elegibilidade no seletor de popups e nos badges da Home.
- Preservados eventos operacionais não anuais e todo o histórico de notícias.
