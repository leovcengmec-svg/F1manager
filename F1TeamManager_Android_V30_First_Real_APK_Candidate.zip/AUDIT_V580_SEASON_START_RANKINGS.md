# V580 — vistoria/correção dos rankings da abertura de temporada

## Alterações aplicadas
- A tela de abertura recebe agora `store.currentDrivers()`, que resolve contratos ativos, transferências e agentes livres da carreira, em vez de depender de `WorldDatabase.allDrivers`.
- A definição da equipe do jogador é atualizada com os atributos persistidos do carro da carreira (`store.loadCar(teamId)`) antes do cálculo dos candidatos ao título.
- Os cálculos Compose dos rankings incluem `season` como chave de recomposição.
- A chamada de `SeasonStartEventScreen` passa explicitamente as listas atuais em vez de usar os valores padrão estáticos.

## Limitação importante
A vistoria do código não encontrou um repositório de atributos atuais dos carros de todas as equipes de IA equivalente a `store.loadCar(teamId)`, que atualmente só carrega o carro da equipe do jogador. Portanto, os rankings das equipes de IA ainda usam os atributos de `WorldDatabase.teams`, não uma fotografia comprovada dos carros de IA após a construção de nova temporada. Não é correto declarar que a exigência completa foi atendida até existir e ser ligado à tela um estado de carro atual para cada equipe de IA.

## Validação
- Conferência estática da chamada e das chaves de recomposição: aplicada no código-fonte.
- Testes Kotlin/Gradle e execução Android: não executados neste ambiente.
- Não declarar a compilação ou comportamento em runtime como aprovados.
