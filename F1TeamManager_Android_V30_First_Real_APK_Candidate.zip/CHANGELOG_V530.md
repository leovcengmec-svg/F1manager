# V530 — Controle financeiro exclusivo do jogador

- Mantido o controle financeiro detalhado somente na tela de Finanças da equipe do jogador; a simulação financeira da IA segue separada e não é exposta ao usuário.
- O resumo agora sempre apresenta todas as categorias exigidas, inclusive as que ainda não têm movimentações no histórico disponível.
- Cada categoria apresenta quantidade de lançamentos, entradas e saídas separadas.
- Mantidos os 20.000 lançamentos de histórico configurados na V529.
- Versão 530 (0.530.0).

Limitação conhecida: o controle ainda classifica os registros antigos pela descrição e atribui semana quando há semana explícita ou GP mapeável. Isso não garante atribuição correta de todas as operações. A integração estrutural nos pontos de criação de cada movimentação ainda é necessária; build Android não foi executado.
