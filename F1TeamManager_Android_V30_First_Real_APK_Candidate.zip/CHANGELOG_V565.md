# F1 Team Manager V565 — 0.565.0

## Correção
- O fechamento financeiro do campeonato agora inclui também IDs de equipes presentes no mapa de pontos da carreira, mesmo quando essas equipes personalizadas não estão no catálogo estático `WorldDatabase`.
- A ordenação de equipes empatadas continua determinística: maior pontuação primeiro e, em caso de empate, menor ID primeiro.
- A distribuição de premiações segue usando a posição final, preservando os valores históricos da curva existente.
- Adicionado teste de regressão para equipe personalizada fora do catálogo, repetibilidade do fechamento e desempate por ID.

## Limitações de validação
- A compilação Android e os testes JUnit não foram executados neste ambiente por ausência de Gradle Wrapper/Gradle disponível.
- A simulação de duas temporadas completas com catálogo expandido continua pendente; esta versão corrige especificamente o conjunto de equipes considerado no fechamento de construtores.
