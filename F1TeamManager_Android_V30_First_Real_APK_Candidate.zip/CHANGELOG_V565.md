# V565 — Correção de carregamento dos Assets dos GPs

- A tela do calendário agora envia para o carregador o nome do GP, o nome do circuito e o campo `assetSearchName` do cadastro da temporada.
- O carregador tenta nomes de arquivo derivados desses três campos, incluindo variantes sem sufixos como `F1`, `Circuit` e `International Circuit`.
- São aceitas as pastas externas `Pictures/F1Manager/Assets/races/`, `GPs/`, `gps/`, `circuits/` e `tracks/`.
- A chave de cache distingue circuitos diferentes que compartilham o mesmo nome de GP (por exemplo, etapas históricas na Alemanha, Itália, Espanha e EUA).
- Falhas de busca não são armazenadas no cache, permitindo nova tentativa.
- Nenhum arquivo de imagem foi incluído no ZIP; as imagens continuam sendo assets externos do usuário.
