# Auditoria de estabilização — V703

## Identificação
- VersionCode 703 / VersionName 0.703.0.
- Nome público F1 Team Manager V30 preservado.
- Nome original do ZIP preservado: `F1TeamManager_Android_V30_First_Real_APK_Candidate.zip`.
- Base de código: V702.

## Correções
1. `aiApproachCandidates` agora inclui pilotos contratados pelo jogador quando o contrato está no último ano. O bloqueio de abordagem durante contrato plurianual permanece. O fluxo cria uma proposta recebida vinculada à equipe do jogador e aguarda decisão do Team Principal.
2. O mesmo conjunto de elegibilidade é usado na verificação de upgrades durante renovações.
3. `chooseAiYears` considera potencial antes do Overall corrente. Pilotos com potencial alto em idade de desenvolvimento não recebem automaticamente contratos curtos por ainda não terem alcançado seu Overall de auge. Todas as durações continuam entre 1 e 5 anos.
4. `AiDriverDevelopmentCodec` serializa programas e `reservePoints`. A leitura é compatível com registros V702 que contêm apenas programas.
5. A virada de temporada remove programas cujo piloto não pertence mais à equipe, registra notícia e libera capacidade. O processamento pré-GP também remove programas órfãos como proteção secundária. Os pontos reservados continuam persistidos no estado da equipe.

## Cobertura de testes adicionada
- Persistência de pontos reservados e compatibilidade com o formato anterior.
- Piloto do jogador elegível no último ano e inelegível durante contrato plurianual.
- Cancelamento de programa na transferência e liberação da vaga.
- Duração plurianual para alto potencial com Overall atual baixo.

## Validação neste ambiente
- Auditoria focada das quatro correções: 15/15 verificações estáticas aprovadas (`tools/race_sim_test/v703_driver_market_audit.py`).
- Contrato de lançamento: 28/28 verificações aprovadas (`tools/validate_release_contract.py`).
- Auditoria estrutural: 25/25 verificações aprovadas (`tools/race_sim_test/final_release_audit.py`), incluindo 100 imagens de pilotos, 40 equipes, 50 circuitos e 773 documentos de histórico.
- Compilação Kotlin K2 direcionada: os arquivos reais `DriverMarketEngine.kt`, `DriverMarketModels.kt` e `DriverDevelopmentEngine.kt`, junto aos modelos de temporada necessários, compilaram. Foram usados stubs mínimos apenas para dependências externas de instalações/perfil financeiro não exercitadas nesses cenários.
- Quatro cenários de comportamento executados e aprovados: round-trip de pontos reservados + compatibilidade V702; elegibilidade do piloto do jogador apenas no último ano; contrato de 4 anos para piloto em idade de auge com alto potencial; cancelamento de programa após transferência com liberação de vaga, manutenção dos pontos reservados e notícia.
- A tentativa de compilação do conjunto completo de fontes puras excedeu o limite de execução deste ambiente. `ManagerSeasonEngine.kt` e a integração SharedPreferences/Android foram revisados estaticamente, mas não compilados neste teste direcionado.
- Gradle/Android SDK e suíte JUnit integral não estão disponíveis neste ambiente; devem ser confirmados no GitHub Actions.
- APK: não declarado como compilado.
