# Auditoria da correção V660 — Mercado de pilotos

## Alterações

1. `DriverMarketEngine.interestScore` recebe `nextSeasonCarStrength` e usa a força projetada para comparar equipe atual e destino.
2. Penalidade progressiva para perda de 5, 10, 15, 20, 25 e 30+ pontos de Overall projetado, com penalidade adicional para queda relativa extrema.
3. Pilotos com Overall 82+ recebem proteção adicional quando a mudança representa uma queda relevante. Em quedas de 20+ pontos, propostas abaixo de 3,5x do salário de referência ficam limitadas a score 42; 3,5x–5,99x ficam limitadas a 58; 6x–8,99x ficam limitadas a 72. Compensação a partir de 9x pode ser excepcionalmente considerada.
4. O bônus salarial máximo cai de 88 para 50 pontos quando a avaliação usa a projeção futura.
5. `expireOffers` recalcula o interesse na data da resposta e reavalia também as propostas concorrentes.
6. `ManagerSeasonEngine` constrói um mapa determinístico para as 40 equipes, aplicando a mesma construção física de próximo carro e o regulamento do próximo ano; nas equipes de IA, respeita o piso de continuidade.
7. A projeção é enviada ao mercado semanal de IA e propagada por renovações, contrapropostas, ofertas e fechamento de vagas.

## Limitações de validação

- O pacote de origem não contém Gradle Wrapper.
- Este ambiente não possui Gradle nem Android SDK configurados; portanto, não foi possível executar o build Android completo nem a suíte JUnit.
- Foram adicionados testes de regressão Kotlin, mas eles precisam ser executados no pipeline Gradle/GitHub Actions do projeto.
