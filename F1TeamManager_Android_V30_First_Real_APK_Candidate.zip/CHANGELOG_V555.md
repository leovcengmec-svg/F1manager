# V555 — Substituição de pilotos na base inicial

Alterações destinadas a novas partidas, sem migração de saves em andamento.

- Brando Badoer → Leonardo Vicente (Brasil, Pro, Prodígio)
- Roman Bilinski → Daniel Ricciardo (Austrália, Pro, Prodígio)
- Carlos Pace → Felipe Drugovich (Brasil, Forte, Prodígio)
- Pedro Clerot → Lyam Vicente (Brasil, Pro, Prodígio)

IDs de pilotos já existentes foram preservados quando o cadastro ocupa a mesma posição.
Felipe Drugovich substitui Carlos Pace no mercado de reservas e mantém o ID de reserva correspondente.
Os perfis foram atualizados no catálogo central, os países na base mundial e os nomes nos JSONs de cadastro de pilotos.
