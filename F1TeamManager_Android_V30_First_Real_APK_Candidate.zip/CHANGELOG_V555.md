# V555 — edição de cadastros personalizados

## Alterações
- A tela Cadastros do Jogo agora oferece edição para equipes e pilotos personalizados já cadastrados.
- A edição da equipe permite alterar nome, país, nomes dos dois pilotos e nome do asset do escudo.
- A edição do piloto permite alterar nome, país, classe e evolução.
- Validações impedem nomes vazios, duplicidade de nomes e pilotos iguais na mesma equipe.
- Os IDs dos registros existentes são preservados; os dados editados são persistidos no catálogo local.
- Versão Android incrementada para 0.555.0 / versionCode 555.

## Limitações conhecidas
- A edição dos 40 registros-base originais ainda não está disponível nesta tela; esta versão edita registros personalizados criados pelo catálogo.
- A integração de equipes adicionais em todos os fluxos de temporada/mercado/classificação permanece incompleta, pois há outros sistemas com pressupostos fixos de 40 equipes e 80 pilotos.
- Não foi possível executar build Android nem a suíte de testes neste ambiente. A integridade do arquivo ZIP é verificada separadamente; isso não equivale a teste de compilação ou execução.
