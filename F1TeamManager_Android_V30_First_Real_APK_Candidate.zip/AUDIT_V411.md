# Auditoria V411

## Regra corrigida
A taxa de contratação não é debitada integralmente na assinatura. O valor é dividido em parcelas iguais pelos GPs restantes, começando no GP seguinte à assinatura. O resto da divisão inteira é incluído na última parcela.

## Idempotência e persistência
Cada schedule persiste temporada de cobrança, GP inicial, quantidade de parcelas e GPs já pagos. Reprocessar o mesmo GP não desconta novamente. O formato de serialização foi ampliado mantendo leitura de registros antigos (campos novos têm defaults).

## Limitações de validação
ZIP e inspeção estática devem ser verificados após empacotamento. Não afirmar compilação Android/JUnit se o ambiente não tiver Gradle/Wrapper disponível.
