# AUDIT V603 — Integridade dos pilotos e evolução

## Resultado executivo
A auditoria encontrou problemas reais na continuidade do ciclo de evolução e no custo de montagem do catálogo. Foram corrigidos nesta versão. A validade final da build Android permanece pendente porque não há ambiente Gradle/Android completo aqui.

## Achados e correções

### 1. A fase do piloto era apagada a cada temporada — corrigido
`CareerPreferences.startNextSeason()` incluía nos registros temporários os mapas de fase e removia `driverEvolutionPhases`, `driverEvolutionPhaseGps`, `driverEvolutionPhaseStart`, `driverEvolutionPhaseTarget` e `driverEvolutionPhasePressure`. Isso fazia a carreira normal reiniciar o ciclo ao virar o ano, em vez de respeitar 5 anos de evolução, 2 de auge e 5 de regressão.

A V603 mantém esses mapas entre temporadas. A limpeza da virada é limitada aos contadores anuais/marks de GP expirados. O saldo fracionário `driverEvolutionBank_<season>` também é transportado para a nova temporada.

### 2. Duração do ciclo espalhada e antiga API conflitante — corrigido
A execução já usava 5/2/5 em duas funções, mas `DriverEvolutionEngine.ascentSeasons()` e `regressionSeasons()` ainda retornavam durações por tipo de evolução diferentes da regra oficial. A duração agora é centralizada em `phaseDurationSeasons()` e compartilhada pelos dois caminhos de evolução. Os helpers de compatibilidade retornam 5 anos, sem depender da categoria; a categoria controla o teto anual de ganhos.

### 3. Regressão podia passar do piso da classe — corrigido
`applyRegression()` permitia reduzir cada atributo até 40, sem proteger o Overall mínimo da classe. Assim, um piloto Lenda podia continuar abaixo de 60 de Overall, e as outras classes também podiam cruzar seus pisos. A V603 bloqueia cada perda que faria o Overall inteiro ficar abaixo do mínimo definido: Fraco 40, Médio 45, Forte 50, Pro 55 e Lenda 60.

### 4. Alteração de classe podia reiniciar a contagem da fase — corrigido
Quando o objetivo da fase mudava após ajuste de classe, ambas as rotas zeravam o contador de GPs da fase. A V603 ajusta ponto inicial/alvo sem reiniciar o relógio de 5/2/5. O banco fracionário é refeito para não carregar acumulação incompatível com o novo alvo.

### 5. A heurística de Felipe Drugovich da V600 era ineficaz — removida
A heurística exigia um perfil canônico acima de 75 de Overall, mas os perfis base são normalizados a 75% do teto da classe. Felipe é Forte (teto 79), portanto seu perfil inicial é normalizado para aproximadamente 59 de Overall. O teste específico não podia disparar. Como as atualizações são validadas por uma carreira nova, a V603 remove a heurística: `startNewCareer()` recria os atributos dos 100 pilotos a partir dos perfis canônicos da build, além de limpar as fases/contadores antigos.

### 6. Montagem do elenco executava trabalho quadrático — corrigido
`currentDrivers()` fazia uma lista dos 100 pilotos e chamava `driverDefinition()` para cada piloto; cada chamada relia e mesclava todos os 100 atributos e reparseava os overrides de classe. O custo era aproximadamente O(N²) na montagem. A V603 faz as leituras uma vez antes do `map`, reduzindo o trabalho a O(N) e mantendo as mesmas regras de contrato/equipe/atributos.

### 7. Identidade de pilotos entre versões
O catálogo atribui IDs 1–80 às vagas iniciais (duas por equipe) e IDs 81–100 aos reservas. Dentro de uma carreira, contratos, atributos e evolução usam consistentemente o ID do piloto. Trocar um nome/foto/perfil na base entre versões pode mudar quem ocupa uma vaga; pela regra de projeto, cada atualização funcional é validada por **Novo Jogo**, não pela continuação do save antigo. A V603 não tenta migrar ou reparar saves anteriores e não apaga arquivos de save automaticamente.

## Cadastro canônico verificado
- 40 equipes e 80 titulares no grid.
- 20 reservas, IDs 81–100.
- 100 IDs no total; 100 nomes distintos; 100 nomes com perfil cadastrado.
- Não foram encontradas colisões nominais nem perfis ausentes na base da V602 usada como entrada.

## Testes executados
- `DriverEvolutionSafetyV603Test.kt` compilado isoladamente com `kotlinc` e executado: PASS.
- Cobertura executada: os cinco tetos de classe, os cinco pisos de Overall sob regressão repetida, atributos dentro de 40..teto, duração 5/2/5, normalização de fase inválida, limites anuais e perfis iniciais de Max (OVR 75, Lenda) e Felipe (OVR 59, Forte).
- `tools/driver_evolution_test/v603_pilot_integrity_audit.py`: 19/19 PASS.
- `tools/race_sim_test/validate_project.py`: 40/40 PASS depois de adicionar changelog V603.
- `tools/race_sim_test/final_release_audit.py`: 25/25 PASS depois de adicionar changelog V603.
- Regra oficial `REGRA_NOVA_CARREIRA_A_CADA_ATUALIZACAO.md` preservada.

## Validação pendente
- Android Gradle Build APK.
- JUnit completo e emulador/dispositivo.
- Teste manual de uma carreira nova por 5 temporadas, verificando que a fase cresce durante 150 GPs, fica em auge por 60 GPs, entra em regressão por 150 GPs e não passa abaixo do Overall mínimo da classe.
- Caso de Felipe Drugovich deve ser avaliado numa carreira nova. Overall inicial próximo de 59 é esperado pela regra geral de normalização (75% do teto Forte 79); o ganho deve ser acompanhado também pelos sete atributos, pois o Overall é um inteiro arredondado para baixo e pode ficar igual mesmo com alguns atributos evoluindo.
