# F1 Team Manager V30 — V659

## Modo de Plano Livre de Pneus

- Adicionado o modo **Plano Livre**, acessível na definição da estratégia antes da largada e também no diálogo de box durante o GP.
- O jogador pode montar sua estratégia escolhendo o composto e a quantidade de voltas de cada stint, com limite de **1 a 6 stints**.
- A validação mostra as voltas planejadas versus as voltas necessárias e a porcentagem de cobertura do GP.
- O status só aprova o plano quando a soma cobre exatamente 100% da distância restante, todos os stints respeitam a janela de desgaste automático de 85% e os compostos correspondem ao clima atual.
- Um plano com a distância exata, mas com stint inseguro ou composto incompatível, aparece como 100% coberto com ressalva e não pode ser aplicado até ser corrigido.
- Antes da largada, salvar o Plano Livre o torna a estratégia ativa do piloto. Durante a prova, ele fica em preparação e só substitui a estratégia atual quando o jogador confirma a aplicação no box.
- A aplicação do Plano Livre no box inicia pelo primeiro stint configurado; as próximas paradas avançam sequencialmente pelos demais stints.
- Os planos A/B/C/D continuam disponíveis e preservam sua lógica original.

## Validação técnica

- Adicionados testes para 6 stints, cobertura incompleta, excesso de voltas, stint acima da janela segura, incompatibilidade climática e limite máximo de 6 stints.
- O motor de validação isolado foi compilado e os seis cenários de regressão passaram.
- Os planos A/B/C/D existentes continuam cobrindo exatamente 58 voltas nos quatro cenários verificados (seco, chuva leve, chuva média e chuva forte).
- Build Android completo não executado neste ambiente: pacote sem Gradle Wrapper e ambiente sem Gradle/Android SDK.

## Versionamento

- Identidade pública preservada: **F1 Team Manager V30**.
- `versionCode = 659`.
- `versionName = "0.659.0"`.
- Nome padrão do ZIP preservado.
