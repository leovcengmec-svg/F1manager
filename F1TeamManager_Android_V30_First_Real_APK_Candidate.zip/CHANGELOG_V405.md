# V405 — Classificação completa com rolagem interna

- A tela de resultado agora apresenta a classificação completa recebida em `RaceResult`, sem limitar a lista aos cinco primeiros.
- A rolagem vertical fica restrita ao painel “RESULTADO COMPLETO”; cabeçalho, pódio, resumo da equipe, estatísticas e botão “VOLTAR PARA HOME” permanecem fora da área rolável.
- O título da classificação informa a quantidade de pilotos apresentada.
- O pódio segue a ordem visual P2, P1, P3 da referência aprovada, mantendo o destaque do vencedor.
- Mantidos os dados de resultado, pontos, gaps, logos externos e a ação final existentes.
