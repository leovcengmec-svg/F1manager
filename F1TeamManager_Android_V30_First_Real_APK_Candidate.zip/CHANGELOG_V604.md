# V604 — recuperação de roster dinâmico
- Corrigida referência não declarada `resolvedTeamByDriver` na inicialização do mercado.
- Resolvido deterministicamente o proprietário inicial de cada piloto em conflito de roster, priorizando equipe personalizada na lista ordenada.
- Pilotos roster-bound não são incluídos como agentes livres.
- Adicionado teste de regressão para a resolução determinística.
- Mantido o histórico e os assets existentes.
- Build Android/JUnit pendentes de execução em ambiente com Gradle.
