# V604 — Calibração de desempenho versus evolução dos pilotos

## Corrigido
- O índice de desempenho por GP passa a medir a diferença de posições frente à meta esportiva da equipe, com 40% da classificação e 60% da corrida.
- A antiga razão meta/posição real punia excessivamente resultados competitivos (ex.: meta P1 e resultado P2 = índice 50). Agora P2 contra meta P1 = índice 95.
- O multiplicador de evolução foi recalibrado em torno de 1,0 para desempenho esperado; desempenho acima acelera e abaixo desacelera a progressão.
- Registros de classificação/corrida ausentes usam a meta da equipe como referência neutra, em vez de penalizar automaticamente o piloto como se terminasse em P80.
- Aplicado o mesmo cálculo na carreira normal e no modo Team Principal.
- A curva fixa de 5 anos de evolução, 2 de auge e 5 de regressão e os limites anuais por categoria foram preservados.

## Validação
- Teste Kotlin isolado: índice por posição, multiplicadores, ciclo 5/2/5 e evolução visível de Overall após seis GPs com desempenho esperado/levemente abaixo da meta.
- Auditorias estruturais geral e release realizadas.
- Build Android/JUnit integrado e teste em dispositivo ainda pendentes; V604 é candidata até aprovação do workflow Build Debug APK.
