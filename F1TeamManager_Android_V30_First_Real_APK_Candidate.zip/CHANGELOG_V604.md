# V604 — Desbloqueio da preparação e simulação de corrida

## Correções
- A abertura do fim de semana executa a sincronização semanal da IA, a preparação dos 40 carros/equipes e a criação da sessão fora da thread principal.
- A simulação instantânea completa (classificação Q1/Q2/Q3 + corrida inteira) roda em `Dispatchers.Default`, em vez de bloquear a UI enquanto processa dezenas de pilotos por todas as voltas.
- Há uma trava contra disparos simultâneos da mesma ação e mensagens internas para estado de trabalho/falha.
- A lógica de classificação/corrida continua usando `CareerWeekendEngine` e `InstantSimulationService`; não foi criado um segundo simulador.

## Limitações
- A finalização de carreira e alguns avanços de semanas ainda executam no fluxo principal após a simulação. Se persistir ANR após a chegada, a próxima etapa é perfilar e dividir a finalização por etapas idempotentes.
- Build Android, JUnit e teste físico ainda não executados neste ambiente.
