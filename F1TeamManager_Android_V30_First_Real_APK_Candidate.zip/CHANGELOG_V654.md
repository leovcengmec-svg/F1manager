# F1 Team Manager — V654

## Correção do histórico de campeões de pilotos e construtores

- A temporada deixa de ser considerada encerrada apenas porque existe uma linha `SD`. A validação exige tabelas anuais consistentes, uma linha `C` e uma linha `K`, cada uma correspondendo ao primeiro colocado da tabela.
- Leitura dos arquivos históricos passa a mesclar linhas do arquivo legado e do shard anual por identidade de piloto/equipe/campeão. Um shard parcial não esconde linhas válidas que continuam no legado.
- A finalização monta o grid de pilotos pela união de contratos ativos, participantes registrados nas corridas e IDs da pontuação. Isso evita um resumo vazio/incompleto quando a lista de contratos está ausente ou incompleta.
- Saves antigos são reconciliados na inicialização e após a confirmação da importação do histórico. A recuperação só reconstrói uma temporada quando todos os GPs previstos no calendário estão presentes; pontos vêm dos resultados efetivamente gravados.
- O registro de equipe de cada resultado de corrida agora prioriza o contrato válido na temporada, depois o nome da equipe no resultado e, por último, a equipe-base do piloto. Isso corrige resultados históricos de pilotos transferidos.
- A finalização continua idempotente: temporadas completas e coerentes não são reescritas; resumos incompletos são reparados atomicamente.

## Versão

- Nome externo preservado: **F1 Team Manager V30**.
- `versionCode = 654`.
- `versionName = 0.654.0`.
