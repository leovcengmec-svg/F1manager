# Auditoria V670 — alocação financeira e cards

- 40% carro próximo ano: teto anual 80.000.000€ sobre envelope de 200.000.000€.
- 40% carro atual: teto anual 80.000.000€, debitado de P&D/fabricação.
- 20% instalações: teto anual 40.000.000€.
- A reserva de caixa do próximo carro é protegida em todas as fases da temporada.
- Despesas obrigatórias, caixa protegido e projeção de receitas continuam prevalecendo sobre gastos discricionários.
- Cards de resultados recentes: 88/100/112 dp por faixa de viewport.
