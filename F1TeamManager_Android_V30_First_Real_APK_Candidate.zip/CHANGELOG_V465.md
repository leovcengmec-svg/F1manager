# V465 — Exportação por save e restauração consistente

- Cada save listado agora tem sua própria ação de exportação; o backup exportado é exatamente o arquivo selecionado.
- O toque no corpo do card continua carregando o save.
- Ao importar uma carreira, os geradores determinísticos de calendário e carro são reconfigurados com a seed salva, evitando misturar a força inicial da carreira anterior com a equipe carregada.
- Versão: 0.465.0 (versionCode 465).

Validação estática de código e integridade do ZIP; compilação Android ainda pendente.
