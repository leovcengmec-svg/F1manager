# V389 — Ajustes dos cards de pneus e identificação dos pilotos

- Aumentada a altura dos cards “PNEU ATUAL” e “VOLTAS RESTANTES” para 148 dp, mantendo ambos com a mesma dimensão.
- Removida a posição de largada sobre a foto do piloto.
- Removido o nome da equipe da linha de identificação no plano de início.
- Adicionado card de escudo da equipe, usando o carregador de assets externo existente.
- Adicionado card de posição de largada ao lado do escudo, com dimensões iguais.
- Mantido o indicador de avaliação geral do piloto em formato compacto.
- Nenhum asset externo foi removido ou substituído.
