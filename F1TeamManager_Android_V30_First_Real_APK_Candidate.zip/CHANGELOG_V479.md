# V479 — Planejamento adaptativo do investimento do próximo carro

- A IA calcula o custo de referência para manter o Overall atual.
- A meta por GP é o saldo necessário dividido pelas GPs restantes.
- Mantidos os limites de caixa, reserva operacional, limite progressivo e teto absoluto de €150M.
- Adicionado teste unitário para o cálculo da contribuição-alvo.
