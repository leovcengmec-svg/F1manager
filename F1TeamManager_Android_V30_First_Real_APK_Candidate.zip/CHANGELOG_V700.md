# V700 — Exibição da idade dos pilotos

- Exibe somente a idade numérica em anos na tela Equipe, nos cartões de pilotos, no perfil individual e no Mercado de Pilotos.
- Exibe a idade também no cartão de confirmação de uma nova proposta.
- Usa a idade do motor de carreira para a temporada ativa; a idade avança com o calendário e respeita o reinício do ciclo aos 18 anos depois de chegar aos 43.
- Não altera atributos, potencial, classe, estilo de evolução, histórico, contratos ou regra de envelhecimento.
- As listas `PILOT_AGES_V700.md` e `PILOT_AGES_V700.csv` registram a idade que o sistema atribui atualmente aos 100 pilotos na temporada de 2026.
- A idade inicial ainda é sintética, derivada do perfil de evolução e do ID. A revisão biográfica das idades fica separada para não alterar a simulação sem validação.
