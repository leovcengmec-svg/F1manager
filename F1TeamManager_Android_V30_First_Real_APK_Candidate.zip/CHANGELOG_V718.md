# V718 — Estabilização e escalabilidade de longo prazo

**VersionCode:** 718  
**VersionName:** 0.718.0  
**Base desta revisão:** V717 / 0.717.0  
**Nome público preservado:** F1 Team Manager V30

## Desenvolvimento incremental das equipes da IA

- O motor de desenvolvimento físico da IA agora mantém checkpoints de abertura de temporada com garagem física, instalações, peças instaladas, versões e confiabilidade por componente.
- O checkpoint é identificado por carreira, equipe, temporada de abertura, seed de desenvolvimento, seed regulamentar, posição técnica da equipe, histórico de investimentos para próximo carro e penalidades financeiras históricas.
- A simulação de uma temporada posterior começa no checkpoint compatível mais recente e avança somente as temporadas ausentes, em vez de reconstruir toda a carreira desde 2026 em cada consulta.
- O modo Team Principal ganhou uma cadeia de checkpoints independente, vinculada ao conteúdo do handoff. A evolução da equipe após a saída de um dirigente também avança incrementalmente.
- Os checkpoints persistentes são cache descartável e atômico: o save da carreira continua sendo a fonte autoritativa. Cache ausente, antigo ou incompatível é ignorado e reconstruído.
- O armazenamento de checkpoints mantém no máximo oito arquivos por equipe. Os caches em memória de simulação física e abertura histórica também são limitados.

## Snapshots e consistência entre equipes

- Visão das Equipes e Ranking das Equipes agora compartilham uma única fotografia das garagens da IA, usando o mesmo fingerprint de carreira, finanças, handoffs, eventos anuais, semana e ranking técnico.
- Abrir o Ranking antes da Visão das Equipes (ou vice-versa) reutiliza a garagem já calculada, sem uma segunda simulação das 39 equipes.
- Os lotes semanais, de corrida, de eventos e de finalização congelam uma única classificação técnica antes de processar as equipes. A publicação de Overall de uma equipe não altera a classificação utilizada pelas equipes seguintes no mesmo lote.
- O motor usado para gerar notícias de desenvolvimento utiliza o mesmo seed determinístico do motor principal, evitando projeções divergentes e checkpoints separados sem necessidade.

## Histórico e navegação

- O reparo de resumos históricos continua lazy: não é executado na criação da base de carreira, mas na primeira consulta histórica, que é despachada para IO.
- A fotografia do Livro de Recordes é construída em uma leitura consistente e libera as linhas brutas consolidadas depois de produzir os registros e índices derivados.
- Consultas da Home para o último GP leem somente o shard mais recente, sem carregar todas as temporadas.
- Consultas de temporada no arquivo monolítico legado usam cache limitado a quatro temporadas, invalidado quando o arquivo legado é substituído ou quando um backup é instalado.
- As telas de História, Temporadas, Hall da Fama, Recordes, histórico individual e carreira Team Principal usam os snapshots históricos em segundo plano.

## Persistência financeira da IA

- Os fingerprints de desempenho financeiro não serializam nem percorrem a lista inteira de transações; utilizam saldos, totais, filas e marcadores necessários para invalidar projeções.
- O campo de transações do snapshot mantém o formato externo, mas ledgers acima de 4 KB são compactados com GZIP antes da Base64.
- A leitura continua aceitando ledgers antigos sem compressão. O limite histórico existente de 20.000 transações por equipe foi preservado; nenhuma transação histórica foi descartada por esta atualização.

## Compatibilidade e escopo

- Não foram alteradas regras de desempenho do carro, estratégia, calendário, campeonato, patrocínios ou evolução dos pilotos.
- Não foi criada uma nova base de save nem removidos dados históricos. O cache de checkpoints é auxiliar e regenerável.
- Os dados históricos continuam armazenados por GP e por resumo de temporada; o histórico completo permanece disponível ao jogador.
