# CHANGELOG V679 — Semente climática individual por GP

## Correção principal

A V678 reutilizava a mesma semente inicial dos fluxos isolados de clima e qualificação em todas as corridas da carreira. Como `MainActivity` mantém uma única instância de `CareerWeekendEngine`, a reinicialização do RNG dentro de `start()` repetia a primeira sequência aleatória a cada GP. Isso podia fazer várias ou todas as etapas começarem com o mesmo estado meteorológico, inclusive chuva forte.

## Implementação

- Criado `RaceWeekendSeed`, com mistura determinística dos campos carreira, temporada, etapa e circuito.
- `CareerWeekendEngine.start()` aceita `weekendSeed` e reinicializa os fluxos de qualificação e clima a partir dele.
- O caminho interativo e a simulação instantânea passam a compartilhar a mesma semente derivada para aquele GP.
- Repetir ou reabrir o mesmo GP mantém o mesmo clima; avançar para outra etapa gera uma sequência diferente.
- O modelo de probabilidades por circuito e a transição da chuva introduzida anteriormente permanecem preservados.

## Testes adicionados

- As 30 etapas de uma temporada geram 30 sementes distintas.
- Temporada, etapa, circuito e semente da carreira participam da identidade do sorteio.
- O clima inicial das 30 corridas não reutiliza um único resultado.
- Qualificação e corrida mantêm fluxos aleatórios independentes.

## Versionamento

- `versionCode = 679`
- `versionName = "0.679.0"`
- Nome público preservado: **F1 Team Manager V30**.
- Nome padrão do ZIP preservado: `F1TeamManager_Android_V30_First_Real_APK_Candidate.zip`.
- Base: V678.

## Validação

- Compilação isolada do gerador determinístico de sementes: aprovada.
- Testes de integração novos adicionados ao conjunto JUnit.
- ZIP será validado estruturalmente após empacotamento.
- O build Android/JUnit completo só será considerado aprovado após execução do workflow do GitHub Actions.
