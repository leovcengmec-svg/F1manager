# V714 — Home reformulada e painel dinâmico da carreira

Base: V713 / 0.713.0. Nome público F1 Team Manager V30 e nome original do ZIP preservados.

## Situação do Campeonato
- Reformulado o painel da Home com classificação de construtores, posição e pontos dos dois pilotos, situação financeira e resultado do último GP.
- Construtores usam a mesma tabela oficial de pontos e ordenação da tela Campeonato; o painel mostra equipe imediatamente acima/abaixo e a diferença de pontos.
- Pilotos usam contratos ativos da temporada e a mesma ordenação da tela Campeonato; nomes completos, posição individual e pontos são exibidos para os dois titulares.
- Financeiro separa caixa atual, limite técnico restante e capacidade técnica imediata após a reserva operacional; não confunde saldo com teto anual.
- Último GP usa o arquivo histórico oficial, exibindo GP, circuito, temporada/round, posição e pontos dos dois pilotos da equipe e total de pontos da equipe. Inclui fallback para resultado legado em SharedPreferences quando o arquivo histórico ainda não foi reconstruído.
- Leitura do arquivo histórico é feita em Dispatchers.IO e armazenada para a entrada/estado corrente da Home, evitando I/O em cada recomposição.

## Acesso Rápido
- Reorganizado em três grupos: Competição (4), Gestão da Equipe (6) e História e Estatísticas (3).
- Os 13 atalhos existentes abrem suas telas funcionais: Fim de Semana, Calendário, Campeonato, Temporada, Equipe/Instalações, Pilotos, Mercado, Carro/P&D, Finanças, Central de Notícias, História, Hall da Fama e Recordes.
- Cards de construtores e pilotos abrem a aba correta da tela Campeonato; Financeiro e Último GP abrem Finanças e História, respectivamente.
- Preservados card do próximo GP, navegação inferior e rotas originais.

## Integridade e testes
- Nenhuma fórmula esportiva, financeira ou de temporada foi alterada; a mudança é de apresentação e navegação.
- Contrato de release V714 inclui verificações estáticas do painel, dados oficiais, circuito do último GP, 13 atalhos e destinos.
- Compilação Android integral e suíte JUnit dependem do Gradle/Android SDK no GitHub Actions; este ZIP não inclui Gradle Wrapper e o ambiente de edição não possui essas ferramentas.

- VersionCode 714 / VersionName 0.714.0; base V713.
