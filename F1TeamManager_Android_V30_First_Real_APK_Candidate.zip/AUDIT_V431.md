# Auditoria V431 — cadeia de virada de temporada

## Escopo
Revisão estática do orquestrador `MainActivity.startNextSeason`, persistência em `CareerPreferences`, criação do carro em `CarDevelopmentEngine` e tabela de referência individual de Overall 40 a 100.

## Contratos cobertos por novos testes-fonte
1. Regressão de fim de temporada ocorre antes de avançar o ano.
2. O motor constrói o carro novo antes de recalcular e salvar o teto anual de investimento técnico.
3. A referência de investimento por Overall é explícita e o motor de virada usa a mesma função que a previsão.
4. O investimento do próximo carro é zerado depois de aplicado.
5. Carro, garagem, instalações, investimento técnico, pesquisa, fábrica, desenvolvimento, mercado, finanças e patrocínios são persistidos antes de `STATE_PERSISTED`.
6. A limpeza do diário ocorre depois da confirmação de persistência; o caminho de estado já confirmado não deve executar novamente o motor da temporada.
7. A recuperação distingue rollback antes do commit final e limpeza após `STATE_PERSISTED`.

## Limitações conhecidas
- Esta é uma auditoria estática e adiciona testes de contrato de fonte; não equivale a executar a aplicação ou simular morte do processo em runtime.
- O snapshot de rollback cobre o arquivo de preferências `f1tm_career`; o arquivo histórico é separado e deve continuar consistente com o arquivo da temporada encerrada. A virada não deve modificar o histórico arquivado após esse ponto.
- Não foi possível executar Gradle/JUnit neste ambiente porque não há `gradlew` nem comando `gradle` disponível.
- Antes de declarar o ciclo finalizado, executar build Android, todos os testes unitários e teste integrado de duas temporadas, incluindo interrupções em cada checkpoint.

## Veredito
O código tem caminhos explícitos de confirmação e rollback, e os contratos de ordenação foram ampliados na V431. A confiabilidade em execução ainda não está comprovada até os testes de runtime serem executados.
