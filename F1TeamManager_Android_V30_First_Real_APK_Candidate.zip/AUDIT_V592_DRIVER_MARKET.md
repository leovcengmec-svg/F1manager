# Auditoria V592 — Integridade do grid

Base: V591 (`versionCode 591`, `versionName 0.591.0`).
Entrega: V592 (`versionCode 592`, `versionName 0.592.0`).

## Problema tratado
A simulação anterior indicou equipes com menos de dois pilotos após a transição de temporada, mesmo quando o orçamento informado era suficiente. A etapa normal de negociação pode terminar sem acordo se candidatos rejeitarem propostas ou fizerem contrapropostas não aceitas.

## Correção
Foi adicionada uma reconciliação final após as negociações normais. Para cada equipe abaixo de dois pilotos, o motor tenta alocar agentes livres sem contrato futuro, respeitando a taxa de assinatura de 20% do valor de mercado e o saldo cumulativo informado. A operação é registrada explicitamente como alocação emergencial, não como transferência normal negociada. Se o orçamento for insuficiente ou não houver agentes livres, a vaga permanece aberta em vez de criar dinheiro ou duplicar pilotos.

## Teste adicionado
`V592SeasonTransitionGridIntegrityTest`: com orçamento de 100 milhões por equipe, exige dois pilotos ativos por equipe, contratos sem IDs duplicados e IDs de pilotos conhecidos após a virada para 2027.

## Limitações
O teste foi adicionado, mas não executado: não há Gradle/wrapper disponível no ambiente. Não foi validada a build Android nem uma simulação integrada de duas temporadas. A alocação emergencial é uma salvaguarda de integridade e fica identificada no histórico e nas notificações.
