# V361 — Reconciliação do arquivo histórico após o commit do GP

## Bloco funcional
- `CareerPreferences.recordRace()` não retorna mais silenciosamente quando o marcador canônico do GP já existe e foi fornecido um `seasonRound`.
- Nesse caminho de repetição, o jogo regrava o registro histórico da mesma temporada/rodada e, no GP final, tenta novamente finalizar o snapshot da temporada.
- A reconciliação não soma pontos novamente: ela ocorre antes do caminho que altera as tabelas do campeonato, e `HistoricalDatabase.recordRace()` substitui os registros `R`, `P` e `Q` daquela temporada/rodada.
- O snapshot final continua protegido por `HistoricalDatabase.finalizeSeason()`, que retorna quando a temporada já está finalizada.
- Versão Android atualizada para `0.361.0`.

## Falha tratada
Se a transação do campeonato tiver sido confirmada, mas a escrita separada do arquivo histórico falhar ou o processo morrer antes dela, uma repetição posterior do callback com `seasonRound` reconcilia o arquivo sem duplicar pontos.

## Limitação
A recuperação depende de o fluxo chamar novamente `recordRace()` com `seasonRound` e o resultado correspondente. Esta alteração não implementa um reconciliador automático na inicialização nem uma transação distribuída entre SharedPreferences e o arquivo histórico. Build Android, JUnit e simulação de temporadas ainda precisam ser executados.
