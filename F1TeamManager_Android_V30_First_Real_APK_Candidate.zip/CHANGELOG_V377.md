# V377 — Bloco 1: integração transacional da carreira

## Integrações corrigidas nesta entrega
- A finalização do GP mantém o resultado completo persistido até o jogador confirmar a tela de resultado. Se o Android encerrar o processo depois do commit da carreira, a retomada recupera classificação, qualificação, clima e eventos originais sem executar os efeitos da carreira novamente.
- A confirmação do resultado e o avanço do calendário passam a ser gravados em um único commit síncrono. Chamadas repetidas não avançam duas rodadas; uma rotina de migração repara saves criados pela implementação anterior que ficaram com o GP confirmado e o calendário parado.
- Receita/custos da corrida e duração restante dos contratos de patrocínio da equipe do jogador passam a ser salvos no mesmo commit. Isso fecha a janela de interrupção entre gravar o livro financeiro e gravar os contratos.
- A evolução dos pilotos grava os atributos, os marcadores de idempotência e uma caixa de saída durável das notícias no mesmo commit. A publicação das notícias e a remoção da caixa de saída também são confirmadas juntas, permitindo recuperação sem perder notícias nem repetir a evolução.
- A nova carreira limpa os registros pendentes de notícias de evolução junto com os demais registros específicos de corrida.
- Adicionados contratos de regressão para as janelas de interrupção descritas acima.

## Mantido
- `versionCode = 377`, `versionName = 0.377.0`: esta é uma revisão corretiva do pacote oficial V377, não uma versão intermediária nova.
- Nenhuma mudança de layout ou botões.
- Histórico de versões e assets externos preservados.
