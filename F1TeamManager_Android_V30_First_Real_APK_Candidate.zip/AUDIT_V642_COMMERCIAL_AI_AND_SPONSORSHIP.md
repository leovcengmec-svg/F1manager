# Auditoria V642 — prioridade mínima do Centro Comercial

## Correção
A V641 já colocava o Centro Comercial no primeiro lugar da fila quando abaixo do nível 3, mas ainda permitia uma instalação alternativa caso o upgrade comercial não fosse financiável na semana. Isso não garantia o mínimo estratégico indicado para a IA.

A V642 torna o nível 3 uma meta obrigatória da hierarquia: enquanto o Centro Comercial estiver abaixo desse nível, a única instalação elegível para iniciar uma melhoria é o próprio Centro Comercial. Se o custo não respeitar a reserva operacional, o caixa disponível ou o teto técnico anual, a IA aguarda sem gastar. Ao chegar ao nível 3, a fila normal volta a funcionar, com P&D, Fábrica, Centro Comercial (quando fluxo de caixa justificar), Túnel de Vento, Simulador, Desenvolvimento de Pilotos e Scouting por último.

## Patrocínios IA versus jogador
O sistema V641 permanece: a IA gera as mesmas três ofertas por slot com `TeamSponsorshipEngine`, respeita catálogo/categoria, nível comercial, marca Master, disponibilidade e exclusão de patrocínios já ativos. A IA escolhe automaticamente a oferta de maior valor esperado, enquanto o jogador escolhe manualmente entre as três. Entrada e pagamentos por GP são contabilizados por `FinanceEngine` compartilhado.

## Verificação
- Validação geral do projeto: 45/45 verificações.
- Auditoria de paridade comercial/patrocínio V642: verificações estáticas da versão, gate de nível 3, hierarquia e mercado compartilhado.
- Teste de regressão acrescentado para garantir que a IA não desvie para uma instalação mais barata quando ainda não alcançou o nível comercial mínimo.
- Motor de patrocínio coberto por runner isolado: seleção da melhor das três ofertas, exclusão da carteira ativa e 55 combinações de nível/slot.
- Limitação: a compilação ampla do núcleo Kotlin excedeu o limite de memória/tempo disponível no ambiente. Não se declara build Android completo nem execução no dispositivo.
