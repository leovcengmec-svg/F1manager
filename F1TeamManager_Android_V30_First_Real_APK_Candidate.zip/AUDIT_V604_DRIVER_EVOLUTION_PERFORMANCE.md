# Auditoria V604 — Desempenho x evolução de pilotos

## Causa
A evolução era aplicada após cada GP, mas o índice `meta / posição real * 100` tornava o multiplicador excessivamente punitivo para pilotos próximos da expectativa. Uma meta de P1 com P2 no quali e corrida produzia índice 50 e apenas 0,15 de multiplicador na V603. Além disso, o Overall da interface é a média inteira dos sete atributos; ganhos de atributos podiam não alterar o Overall visível durante várias corridas.

## Alterações
- `gpPerformanceIndex`: 40% quali + 60% corrida, baseado em delta de posições com neutro 100; meta P1 e resultado P2 = 95.
- `performanceUtilization`: calibrado para 1,0 em desempenho esperado/bom; abaixo da expectativa desacelera e resultados excepcionais aceleram.
- Se não houver registro de quali/corrida de um piloto, a meta da equipe é usada como neutra; resultado DNF/classificado continua sendo avaliado com a posição registrada.
- Mudança compartilhada por `CareerPreferences.applyDriverRaceEvolution` e `ManagerSeasonEngine`.
- Ciclo 5/2/5 e limites anuais por categoria mantidos.

## Testes executados
- `DriverEvolutionPerformanceV604Test.kt`: compilado e executado isoladamente com `kotlinc`, PASS; inclui um caso com Max Verstappen inicializado em Overall 75 que, com resultados P2 contra meta P1 em seis GPs, sobe para Overall 76.
- Auditoria estrutural geral: a checagem de release notes só passa depois de adicionar `CHANGELOG_V604.md`.
- Auditoria estrutural de release: a checagem de changelog só passa depois de adicionar `CHANGELOG_V604.md`.
- Build Android/JUnit completos não foram executados por falta de Gradle/Wrapper/Android SDK neste ambiente.

## Regra de atualização
A V604 deve ser validada em uma carreira iniciada pelo fluxo Novo Jogo; não usar um save anterior como critério de aceitação. Saves antigos não são apagados automaticamente.
