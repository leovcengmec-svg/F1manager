# V359 — Commit atômico do resultado do GP

## Bloco implementado
- O registro do resultado agora sincroniza chamadas na instância de `CareerPreferences`.
- A gravação dos pontos dos pilotos, pontos dos construtores, posições anteriores e resultado canônico da corrida ocorre em uma única transação `SharedPreferences.commit()`.
- Se o commit falhar, a operação falha explicitamente em vez de continuar como se o resultado estivesse registrado.
- A atualização do arquivo de histórico da temporada continua depois do commit canônico; essa etapa não é declarada atômica com SharedPreferences e precisa de validação de recuperação separada.
- Versão Android incrementada para `0.359.0`.

## Escopo preservado
- Nenhuma alteração de interface ou botões.
- Nenhum asset ou histórico de versão anterior removido.
