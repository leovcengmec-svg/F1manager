# V450 — Correção de escopo da tela de P&D

- Movido o card “DESENVOLVIMENTO DO CARRO DO PRÓXIMO ANO” para dentro do `LazyColumn` da tela Carro/P&D.
- Removido o card do bloco de diálogo `selectedComponent`, onde `item {}` não era válido e causava erros de compilação Kotlin.
- Mantida a navegação por `onNextCar()` e o recurso visual genérico existente.
- Preservados os fluxos de pesquisa, fabricação, instalação, assets e histórico anterior.
- Versão Android: `versionCode 450`, `versionName 0.450.0`.
