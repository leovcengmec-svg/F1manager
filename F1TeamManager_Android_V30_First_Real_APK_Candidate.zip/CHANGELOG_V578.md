# V578 — Integridade de IDs e integração do roster personalizado

## Correções integradas
- Corrigidos bloqueios reais de compilação no caminho de construção do carro da próxima temporada: as chamadas locais de `base(component)` agora usam a assinatura correta e a projeção legada não tenta gravar `installedPieceVersions`, que pertence aos carros físicos, não a `TeamCarState`.
- A projeção de aerodinâmica do carro novo passa a refletir o maior dos valores reconstruídos de asa dianteira/traseira, mantendo coerência com a regra histórica de desenvolvimento.
- O carregamento do catálogo agora identifica colisões de IDs personalizados com a faixa imutável de equipes oficiais (1–40) e de pilotos oficiais/mercado (1–100), além das duplicidades entre registros personalizados.
- A validação do roster rejeita reutilização de pilotos oficiais em equipes personalizadas, piloto referenciado por mais de uma equipe e vínculo explícito de piloto para equipe diferente da declarada.
- A associação de pilotos personalizados à equipe considera o roster da equipe como fonte autoritativa. Isso preserva catálogos antigos em que o campo `teamId` do piloto ficou em zero, sem regravar automaticamente os dados originais.
- `WorldDatabase` agora projeta esses pilotos com o `teamId` efetivo da equipe que os declara, evita duplicá-los no conjunto global e mantém pilotos livres separados.
- A migração do mercado dá prioridade aos IDs declarados no roster da equipe, mesmo quando o piloto legado não tem `teamId` persistido; também impede que um piloto explicitamente declarado por uma equipe seja consumido por outra vaga.
- Adicionados testes de regressão para colisões de IDs, roster duplicado/cruzado, compatibilidade de pilotos legados, migração do mercado e construção do próximo carro.
- Incluído runner reproduzível para compilar os módulos Kotlin reais de domínio e simular 60 GPs com um roster personalizado expandido; o stub usado é exclusivo do harness e não entra no app Android.

## Preservação
- V577 é a base direta.
- Nenhum asset, save, chave de persistência, arquivo de histórico ou funcionalidade existente foi intencionalmente removido.
- `versionCode = 578`; `versionName = 0.578.0`.

## Verificações executadas após a correção de compilação
- Compilação isolada Kotlin dos módulos reais de temporada, mercado, garagem, finanças e corrida: concluída; somente avisos de depreciação do construtor `Locale`.
- Simulação headless do motor real por **60 GPs em duas temporadas**, com equipe personalizada 41 e pilotos legados 101/102: aprovada; grid de 82 pilotos, 102 pilotos no catálogo, evolução em 60 rodadas e premiações das temporadas 2026/2027.
- Harness de construção do próximo carro: aprovado; preserva Carro 1 e Carro 2 separados e mantém a projeção de aerodinâmica consistente.
- Regressões de migração do mercado V576: 3/3 passaram; regras de identidade V578: 4/4; projeção do catálogo: 5/5; testes de contrato V578: 4/4.

## Limites de validação
- Foram compilados e executados harnesses Kotlin isolados para as regras de identidade, projeção de `WorldDatabase` e migração do mercado.
- Auditores estáticos do pacote e do ciclo do jogo foram executados.
- A compilação Android integral, JUnit oficial e a simulação completa de 60 GPs não foram executadas neste ambiente; os harnesses isolados não substituem esses testes.
