# V578 — Notificações da Home, falha de P&D e vínculo de piloto

- A Home deixa de usar `else-if` entre P&D e patrocínio: cada ação elegível é renderizada independentemente, permitindo até três botões de notificação na mesma linha.
- O contador de P&D passa a incluir tanto `P&D CONCLUÍDO` quanto `FALHA NO P&D — DESIGN NÃO CONCLUÍDO`, para que falhas de design do jogador também apareçam como ação na Home.
- A filtragem do popup já inclui a falha de P&D do time do jogador; mantida e auditada essa regra.
- Conferida a escalação inicial: a equipe `Andretti` permanece com Sergio Pérez e Valtteri Bottas. Mario Andretti não está associado à equipe Andretti; seu registro no grid é para Cadillac Racing. Nenhum vínculo Mario Andretti → equipe Andretti foi adicionado.
- Versionamento: 578 / 0.578.0.
