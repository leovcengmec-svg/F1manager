# V140 — Full System Chain Corrections

Applied on V139 after multi-season cycle audit.

## Corrected
- Fixed sponsorship offer function return so the V139 source compiles.
- Fixed driver-evolution news interpolation (`${manager.round}`) to avoid serializing the entire manager state and causing heap exhaustion.
- Fixed annual driver evolution gain accounting: the real per-driver annual array is now passed into `applyPositiveGain`, preserving the 7-attribute annual cap and historical gain totals.
- Removed the obsolete no-op season regression hook; regression remains handled by the GP-by-GP continuous evolution state machine.
- Removed the obsolete AI budget fallback formula (`35M + strength*650k`); fallback now uses `InitialTeamProfile.initialBudget`, keeping Strong/Medium/Weak budgets unified.

## Preserved
- No change to approved race/tire rules.
- No change to sponsorship category probabilities.
- No change to sponsorship category financial bands.
- No change to 5-slot sponsorship structure or 10 Master + 20 Secondary pools.
- No change to 80 active drivers / 100 registered drivers.
- No change to physical Garage as the race source of truth.
- No change to the approved V138/V139 interfaces.
