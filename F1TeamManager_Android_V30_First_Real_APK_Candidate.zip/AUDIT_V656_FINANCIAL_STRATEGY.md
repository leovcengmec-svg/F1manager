# Auditoria V656 — Estratégia financeira da IA

## Escopo
Base oficial: revisão V655 (`versionCode 655`, `versionName 0.655.0`). A V656 altera somente a estratégia econômica das equipes controladas pela IA e os metadados internos de versão.

## Regras implementadas
1. **Receita comercial:** a projeção do Centro Comercial calcula vendas adicionais após a conclusão real da obra (12 semanas), inclui a temporada seguinte e desconta a manutenção incremental.
2. **Patrocínio:** a seleção usa receita garantida total e por GP como critérios dominantes. Bônus dependem de probabilidade estimada pela posição esportiva e recebem desconto conservador de risco. O multiplicador de Marketing das novas propostas é monotônico: nenhuma melhoria do Centro Comercial reduz o valor-base negociado.
3. **Projeção isolada:** a simulação de renovações de patrocinadores usa uma cópia isolada do estado comercial; não grava contratos, eventos ou chaves de idempotência no estado ativo.
4. **Caixa de duas temporadas:** a IA projeta receitas futuras de lojas e patrocínios; despesas futuras com salários, operação de GPs, manutenção e parcelas de contratação; e dívidas vencidas de salários, manutenção e taxas.
5. **Proteção de liquidez:** o investimento fica limitado pelo menor entre caixa imediatamente livre, saldo de fechamento previsto da temporada atual e saldo previsto da temporada seguinte, sempre preservando a reserva operacional.
6. **Disciplina de investimento:** P&D, instalações e investimento no próximo carro não podem usar caixa reservado para obrigações conhecidas. Melhorias comerciais sem retorno mínimo projetado são descartadas.
7. **Integridade econômica:** não há criação de dinheiro, perdão automático de dívida ou transferência artificial para equipes com caixa negativo.

## Arquivos alterados
- `app/src/main/java/com/f1teammanager/core/manager/AITeamFinancialEngine.kt`
- `app/src/main/java/com/f1teammanager/core/manager/TeamSponsorshipEngine.kt`
- `app/src/main/java/com/f1teammanager/core/manager/SponsorContractPricing.kt`
- `app/src/main/java/com/f1teammanager/MainActivity.kt`
- `app/src/main/java/com/f1teammanager/core/manager/ManagerSeasonEngine.kt`
- `app/src/test/kotlin/com/f1teammanager/core/manager/FinancialStrategyV656Test.kt`
- `tools/save_test/v655_nullable_metadata_build_fix_test.py` (compatibilidade do teste legado com o versionamento novo)
- `app/build.gradle.kts`, `README.md` e `.github/workflows/android-apk.yml`
- `CHANGELOG_V656.md` e `AUDIT_V656_FINANCIAL_STRATEGY.md`

## Validação
- Integridade CRC do ZIP-base V655: aprovada antes das alterações.
- Compilação Kotlin do núcleo de domínio (`app/src/main/java/com/f1teammanager/core`), excluindo somente quatro componentes Compose visuais: aprovada.
- Regressões V656 executadas em harness local: 4/4 aprovadas.
- Regressões históricas selecionadas de patrocínio e instalações (V619, V642 e V651): 10/10 aprovadas.
- Regressão Python legada da correção de saves V655, atualizada para acompanhar o versionamento: 9/9 aprovada.
- Projeção smoke test: determinística e sem mutação do portfólio ativo; dívidas calculadas em €12 milhões; equipe com caixa suficiente inicia melhoria comercial rentável; equipe sem liquidez não gasta nem recebe dinheiro artificial.
- A compilação Android completa e a execução oficial da tarefa JUnit do Gradle não foram executadas localmente: o ambiente não dispõe de Gradle/Android SDK e o pacote-base não contém Gradle Wrapper. O workflow `.github/workflows/android-apk.yml` foi incluído para executar `:app:testDebugUnitTest` e `:app:assembleDebug` no GitHub Actions.
