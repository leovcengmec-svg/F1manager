# Auditoria V605 — Falha de compilação reportada pelo GitHub Actions

## Erro observado
`MainActivity.kt:1058:17 Unresolved reference 'simulateWeekendInstantlyForCareerImpl'`.

## Causa confirmada pelo código
As duas funções são locais ao escopo da Activity composable. A função wrapper era declarada antes da função local suspend que invocava. Kotlin não permite referência antecipada a uma declaração de função local nesse contexto.

## Correção aplicada
A função `simulateWeekendInstantlyForCareer()` foi movida para imediatamente depois de `simulateWeekendInstantlyForCareerImpl()`. Nenhuma lógica interna de simulação foi removida ou reescrita. A V604 permanece como base funcional e a versão foi incrementada para V605.

## Testes
O teste estático verifica:
- versionCode 605 / versionName 0.605.0;
- implementação suspend declarada antes do wrapper;
- wrapper ainda chama a implementação;
- fluxo de coroutine e proteção contra chamadas duplicadas preservados;
- instrumentação `F1TM_PERF` preservada.

A compilação Android precisa ser confirmada no workflow GitHub Actions.
