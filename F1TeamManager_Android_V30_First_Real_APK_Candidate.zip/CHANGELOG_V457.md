# V457 — Notícias do Mercado de Pilotos na Home
- Contrapropostas ligadas à equipe do jogador agora podem gerar card de evento na Home.
- Renovações e assinaturas/fechamentos de contrato aparecem na Home tanto para a equipe do jogador quanto para equipes da IA.
- Contagem e prioridade do aviso de Mercado na Home alinhadas às novas regras; histórico do Central de Notícias preservado.

