# Auditoria v686 — eventos de negociação e falhas de P&D na Home

Base: v685. Escopo: exclusivamente a equipe controlada pelo jogador.

## Alterações
- A Home agora aceita eventos de cada etapa da negociação (proposta enviada, recusada, contraproposta recebida/enviada/recusada, negociação encerrada e proposta não concluída), desde que a mensagem identifique a equipe do jogador.
- O contador do botão de mercado inclui essas etapas e mantém os eventos de contratos assinados.
- O envio de proposta e o envio de contraproposta pela equipe do jogador passam a gerar eventos persistentes imediatamente.
- Recusa de contraproposta identifica explicitamente a equipe, permitindo o filtro exclusivo da Home.
- A geração de eventos de falha de P&D continua baseada no snapshot dos projetos ativos antes/depois da progressão; a notificação é persistida no mesmo bundle atômico de carreira. O filtro da Home e o contador reconhecem sucesso e falha apenas quando o evento pertence à equipe do jogador.
- Equipes controladas pela IA não ganham cards individuais de negociação na Home do jogador; eventos globais de assinatura continuam conforme regra anterior.
- VersionCode 686 / VersionName 0.686.0.

## Validação
- Adicionado teste de regressão para os títulos de cada etapa e escopo por equipe.
- Adicionado teste de verificação da persistência de proposta/contraproposta e da trilha de falha de P&D.
- Verificação estática do código e do pacote concluída.
- Gradle Wrapper não está presente no ZIP; compilação Android deve ser executada pelo GitHub Actions.
