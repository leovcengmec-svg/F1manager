# Auditoria V428 — Virada de temporada

## Correção
A etapa `STATE_PERSISTED` agora é tratada como um commit já concluído. Se o processo morrer entre a gravação do último estado e a remoção das chaves do diário, uma nova tentativa verifica se a temporada atual corresponde à temporada de destino, remove o diário e retorna à tela de abertura. Não reexecuta motores de virada.

## Proteções mantidas
- `PREPARED`: executa a transição normal uma vez.
- `SEASON_ADVANCED`: permanece bloqueada para recuperação assistida, pois pode haver gravação parcial entre subsistemas.
- `STATE_PERSISTED`: finaliza apenas o diário, depois de confirmar o destino.

## Limitações remanescentes
Ainda não existe snapshot transacional/rollback de todos os subsistemas. Uma interrupção durante `SEASON_ADVANCED` requer recuperação assistida. A compilação Android e os testes automatizados não foram executados.
