# V705 — Próximo carro e ciclos de regulamento

Base: V704. Versão interna: `0.705.0` (versionCode `705`). O nome público e o nome padrão do ZIP permanecem inalterados.

## Desenvolvimento do carro seguinte

- Removido o bônus de construção de 10% em todas as rotas de virada; a tabela de investimento define diretamente o Overall-base.
- Criada trava anual de investimento no próximo carro: o jogador pode concluir o aporte que atinge €150 milhões, mas qualquer aporte posterior é bloqueado pelo motor financeiro e desativado na interface.
- A IA constrói a referência técnica planejada e aplica a diferença de investimento não realizada como perda por componente: €1 milhão de déficit corresponde a 1 ponto; o débito é limitado a 10 pontos por componente instalado, em cada um dos dois carros. Peças ausentes permanecem ausentes; identidade e confiabilidade são preservadas.
- Removida também a herança percentual de 10% do helper legado de compatibilidade, evitando que uma chamada antiga reintroduza o bônus.

## Regulamento

- Mudanças anuais agora sorteiam zero, uma ou duas alterações distintas. As probabilidades são 15%, 70% e 15%, respectivamente; portanto, zero e duas alterações são menos frequentes que uma.
- A duração de cada ciclo técnico é sorteada no intervalo de 6 a 10 temporadas concluídas. A revolução ocorre na temporada seguinte ao número sorteado de temporadas; ao iniciar essa temporada, um novo ciclo de 6–10 é imediatamente determinado para o próximo intervalo.
- Os sorteios são derivados da semente persistida da carreira e do início do ciclo: não mudam ao recarregar o jogo e são iguais para jogador, IA, projeções e simulações.
- O início do ciclo e a duração sorteada são persistidos no registro codificado do regulamento por temporada. O decodificador continua aceitando registros legados de três campos.
- Temporadas com zero mudanças anuais também exibem a comunicação “Regulamento mantido”. A revolução técnica substitui o sorteio anual naquela temporada.

## Verificações

Verificações estruturais e de contratos V705 executadas separadamente; ver `AUDIT_V705_NEXT_CAR_AND_REGULATIONS.md`. A compilação Android/Gradle e a suíte JUnit completa dependem de Gradle/Android SDK não disponíveis neste ambiente.
