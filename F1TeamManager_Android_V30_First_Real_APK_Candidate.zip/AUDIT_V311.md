# Auditoria V311 — Tela Carro / P&D

## Escopo
Atualização de front-end da tela `CARRO / P&D` em `app/src/main/java/com/f1teammanager/MainActivity.kt`.

## Alterações
- Removido o item de banner de carro independente no início da lista.
- O mesmo carregador `ExternalAssets.loadTeamCarVisual` agora é usado no cabeçalho de Carro 1 e Carro 2.
- Os cards continuam lendo diretamente `state.garage.car1` e `state.garage.car2`.
- Mantidos os dados de componentes e versões instaladas, bem como médias de desempenho e confiabilidade calculadas a partir desses componentes.
- Painel Fábrica recebe imagem decorativa existente `R.drawable.facility_factory`; status, ordens, custos, prazos e botões continuam vinculados aos dados atuais.
- Não foram alterados os motores `ResearchEngine`, `FactoryEngine`, `CarDevelopmentEngine`, o motor de corrida ou a persistência.

## Verificações
- Alterações textuais e referências de recursos verificadas por inspeção estática.
- Integridade do ZIP verificada após empacotamento.
- Build Gradle/Android não executado neste ambiente; a compilação e validação visual em dispositivo continuam pendentes.


## Atualização complementar — tela Qualificação
- Modificada apenas a camada Compose `Qualifying` e o componente visual da legenda de pneus em `MainActivity.kt`.
- A simulação continua chamando o callback `simulate(virtualSliceMs)`; a transição para a corrida continua chamando `start()`.
- Fases e classificações continuam lendo `s.grid?.phases`, `s.qualifyingPhaseIndex`, `s.qualifyingTyres`, `s.weather` e `s.plans`; não foram criados dados de pilotos fictícios para a tela.
- Diferenças são calculadas em relação ao melhor tempo válido da fase selecionada.
- Build Android/Gradle e validação visual no POCO X7 Pro não foram executados neste ambiente.
