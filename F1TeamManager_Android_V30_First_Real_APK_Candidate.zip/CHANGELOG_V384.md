# V384 — Correção da compilação Kotlin

- Reordenadas as funções locais de finalização para eliminar referências anteriores à declaração.
- Removido o modificador `private` inválido em função local.
- Qualificado o tipo `CareerWeekendEngine.SessionSnapshot` no finalizador.
- Mantida a lógica do modo normal e da simulação instantânea; sem alterações intencionais de layout ou assets.
- Build Android completo ainda precisa ser confirmado no ambiente de compilação do projeto.
