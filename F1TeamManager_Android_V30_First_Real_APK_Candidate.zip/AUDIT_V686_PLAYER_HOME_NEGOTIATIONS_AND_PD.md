# Auditoria V686 — eventos de negociação e P&D na Home

## Escopo

A Home deve exibir notificações relacionadas apenas à equipe controlada pelo jogador. O feed da Central de Notícias permanece global, mantendo o histórico AI-vs-AI sem interromper a carreira do jogador.

## Alterações verificadas

1. `MarketNotification.relatedTeamId` identifica a equipe envolvida no aviso.
2. `CareerPreferences` grava a sétima coluna e mantém leitura compatível com saves legados de seis colunas.
3. `DriverMarketEngine` propaga a equipe do jogador por proposta, contraproposta, recusa, expiração, cancelamento financeiro e assinatura.
4. `PlayerHomeNotificationPolicy` reconhece os estágios da negociação e exclui eventos com ID de outra equipe. A compatibilidade legada usa o nome da equipe somente quando o ID não existe.
5. `MainActivity.Home` usa a mesma política para o popup e para os contadores, e leva todo evento de negociação da equipe do jogador ao Mercado de Pilotos.
6. `ResearchEngine.advanceWeeks` já registra `ResearchOutcome.FAILURE`; V686 converte o resultado em card persistente na semana real de conclusão, inclusive em saltos de calendário.
7. `saveCareerStepBundle` persiste `driverMarket` no mesmo commit do avanço semanal, preservando os avisos de P&D.
8. Testes unitários cobrem filtragem por equipe, compatibilidade legada, proposta/contraproposta, expiração/recusa e P&D.

## Regra de escopo

- Equipe do jogador: evento exibido na Home.
- Outra equipe: evento não abre popup nem aumenta o contador de Mercado da Home.
- Notificações antigas sem `relatedTeamId`: continuam reconhecidas pela mensagem quando o texto identifica a equipe do jogador.

## Limitação de validação

A auditoria de código é executada no repositório. A confirmação do APK depende da execução de `:app:testDebugUnitTest :app:assembleDebug` no GitHub Actions.
