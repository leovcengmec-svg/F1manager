# Changelog V370 — Integração real da cadeia de temporada

- Ampliado o teste JUnit `TwoSeasonChainAuditTest` para validar os 60 resultados gerados pelo `ManagerSeasonEngine` real.
- Para cada GP, o teste valida o resultado com a distância oficial do calendário, 80 pilotos únicos, posições de 1 a 80, grid de qualificação e fases Q1/Q2/Q3 (80/50/20).
- Verifica pontuação não negativa, progressão do histórico e marcador de idempotência da evolução de pilotos para cada uma das 60 rodadas.
- Mantidas as verificações de transição de temporada, 80 contratos ativos e estado de 100 pilotos.
- Atualizada a versão Android para 0.370.0.
- Nenhuma alteração na interface, botões ou assets externos.
