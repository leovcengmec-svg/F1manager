# V585 — Correção de retorno ao menu inicial

## Alterações
- O botão/ação de voltar na seleção de equipe retorna ao menu inicial, em vez de abrir o diálogo de saída.
- O diálogo de confirmação exibido na HOME inclui a ação `MENU INICIAL`, além de `CONTINUAR JOGANDO` e `SAIR`.
- A ação `MENU INICIAL` altera somente a tela e a navegação visual; não apaga nem reinicializa a carreira salva.
- `versionCode=585`, `versionName=0.585.0`.

## Validação
- Revisão estática dos pontos de navegação alterados.
- Compilação Android e teste no dispositivo não executados; não declarar validação runtime.
