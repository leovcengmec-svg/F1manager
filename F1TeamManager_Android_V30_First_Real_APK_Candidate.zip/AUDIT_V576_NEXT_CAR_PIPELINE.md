# V576 — Auditoria e unificação do fluxo de construção do próximo carro

## Correções desta versão

1. A herança de 10% é calculada individualmente para cada atributo físico de cada carro da IA, sem usar média entre Carro 1 e Carro 2 para construir os componentes físicos.
2. O caminho de construção do jogador não aplica mais bônus de regulamento dentro de `CarDevelopmentEngine.startNextSeason`; a orquestração da virada (`MainActivity` e o caminho alternativo `ManagerSeasonEngine`) aplica a regra anual depois da construção. Isso elimina a aplicação duplicada da regulamentação nesse fluxo.
3. O caminho legado `carryAiCarToNextSeason` também deixa a regulamentação para o orquestrador, evitando que a mesma penalidade seja aplicada no carry e novamente na etapa anual.
4. Mantidos a tabela unitária de referência financeira Overall 40–100, a conversão investimento/referência, o foco técnico, o conhecimento técnico e a remoção da regressão genérica de 70%.
5. Versão do app atualizada para `versionCode 576`, `versionName 0.576.0`.

## Fluxo esperado

- Determinar o Overall atual e consultar a tabela unitária para calcular a referência de 100%.
- Converter investimento e foco em efeito de construção uma única vez.
- Construir cada carro físico com seus próprios atributos e acrescentar 10% arredondado por componente.
- Aplicar o regulamento anual uma única vez depois da construção.
- Sincronizar a projeção legada sem usar a média para sobrescrever os valores físicos individuais.

## Limites da verificação

Inspeção estática do código e verificações textuais foram realizadas. A compilação Android, os testes automatizados e uma simulação de virada de temporada não foram executados nesta entrega. A IA usa a mesma regra de herança física e bônus de investimento, mas sua função não recebe o mapa `developmentKnowledge`/foco por equipe do mesmo modo que o estado completo do jogador; isso permanece como diferença arquitetural a ser avaliada antes de afirmar paridade total de todos os efeitos.
