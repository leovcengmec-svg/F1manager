# V708 — Centro de Operações de Corrida

Base: V707 (`versionCode 707`, `versionName 0.707.0`).
Entrega: V708 (`versionCode 708`, `versionName 0.708.0`).

## Instalação substituta
- `Scouting` foi substituído por `Centro de Operações de Corrida`; o conjunto segue com sete instalações.
- Níveis, custo de manutenção e curva de melhoria permanecem no sistema compartilhado das instalações.
- A arte antiga de Scouting foi removida e substituída pela nova arte de Centro de Operações.

## Benefícios integrados ao motor de corrida
- Perda-base por pit stop: 21,0 s no nível 0, reduzindo 0,2 s por nível até 19,0 s no nível 10.
- Probabilidade de atraso operacional: 8,0% no nível 0, reduzindo 0,6 ponto percentual por nível até 2,0%; ocorrência adiciona 2–4 s.
- Tempo adicional de reparo emergencial: 8,0 s no nível 0, reduzindo 0,3 s por nível até 5,0 s.
- Atrasos são determinísticos por semente do GP, equipe, piloto e número da parada; não dependem da ordem de processamento.
- Reparos de asa dianteira são contabilizados no mesmo pit stop, sem criar uma parada duplicada.
- A fórmula é compartilhada pelas corridas interativas e instantâneas e aplicada a todas as 40 equipes.

## Mercado de pilotos
- Atributos VEL, CLA, ULT, DEF, CON, CHU e PNE exibidos diretamente a partir da definição atual do piloto, sem intervalo estimado nem cadeado.
- Removidos botão, diálogo, custo e persistência de relatórios Scout.
- A IA passa a avaliar o Overall atual sem estimativa reduzida pela instalação.

## Migração de carreira
- Chaves antigas `SCOUTING` são lidas como `RACE_OPERATIONS`, preservando o nível das equipes e a obra ativa com seu tempo restante.
- Snapshot financeiro da IA e handoff do modo Team Principal aceitam e migram a chave antiga.
- Objetivos antigos de melhoria do Scouting são convertidos em objetivos do Centro de Operações de Corrida.
- Relatórios de Scouting antigos são descartados, pois os atributos agora são públicos.

## Interfaces e assets
- Atualizados card da instalação, resumo de instalações da Equipe e cards do Mercado de Pilotos.
- Nova imagem `facility_race_operations.webp`; removida a imagem `facility_scouting.webp`.

## Validação
- Contrato de release V708, testes unitários de modelo e regressões estáticas adicionados.
- A compilação Android só será considerada confirmada se Gradle/Android SDK estiver disponível no ambiente ou no workflow GitHub.
