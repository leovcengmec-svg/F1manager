# V643 (0.643.0) — Contagem correta de GPs concluídos no perfil do piloto

- Corrigido o significado de GP no perfil: contabiliza corridas concluídas pelo piloto, excluindo os resultados DNF, que aparecem separadamente.
- Aplicada a mesma regra às estatísticas da temporada atual, ao histórico por temporada e ao total da carreira.
- Ao exibir históricos arquivados, os valores GP/DNF são recalculados a partir dos resultados de corrida disponíveis, corrigindo resumos antigos que incluíam DNFs na contagem de GPs concluídos.
- Mantida a contagem de corridas de construtores por GP quando pelo menos um dos pilotos termina a corrida.
- Adicionado teste de regressão para 30 provas inscritas com 3 DNFs: 27 GPs concluídos e 3 DNFs.
- Build Android completa e teste no dispositivo pendentes neste ambiente.
