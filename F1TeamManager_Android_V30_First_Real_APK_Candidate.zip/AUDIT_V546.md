# Auditoria V546

A alteração de balanceamento de DNFs da V545 foi desfeita restaurando `CareerWeekendEngine.kt` e `app/build.gradle.kts` da V544; o código de teste específico da alteração V545 foi removido. Demais arquivos e assets da V545 foram preservados.

Verificação realizada: integridade do ZIP e comparação dos arquivos de simulação restaurados. Compilação Gradle não executada nesta etapa.
