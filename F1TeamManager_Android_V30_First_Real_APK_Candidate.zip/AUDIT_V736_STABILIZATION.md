# Auditoria de implementação V736

## Escopo verificado no código-fonte

| Área | Verificação | Estado |
|---|---|---|
| Importar/exportar saves | Dois botões preenchidos, mesma altura e largura proporcional; exportação preserva a seleção explícita de saves históricos e a exportação integral da carreira ativa | Implementado |
| Cabeçalho do mercado | Cards estatísticos removidos; contagem dinâmica de pilotos/equipes e temporada | Implementado |
| Mensagens | Snackbar com encerramento automático após 3 segundos | Implementado |
| Ordenação | Overall, Nome, Idade e Classe; direção selecionável | Implementado |
| Filtros | Faixas 16–20, 21–25, 26–30, 31–35, 36–40, 41–45 e classes Médio/Forte/Pro/Lenda; filtros de situação preservados | Implementado |
| Estado de navegação | Filtros, pesquisa, ordenação, piloto selecionado e LazyListState mantidos no escopo da carreira/equipe | Implementado |
| Notícias no mercado | Bloco de assinaturas removido; ações de negociação mantidas | Implementado |
| Notícias na Home/Central | Campos estruturados com compatibilidade para registros antigos; card de assinatura renderiza foto, origem, destino, temporada e duração | Implementado |
| IA de mercado | Prioridade elevada a oportunidades Lenda/Pro/Overall 85+ e menor chance de renovar titular quando há upgrade credível | Implementado |
| Ciclo 16–45 | Idade calculada e snapshots aceitam 16–45; o reinício ocorre no ciclo seguinte após a temporada aos 45 | Implementado |
| Contratos 43/44/45 | Motor mantém a regra normal até 42; limita a 2/1/0 anos aos 43/44/45 e bloqueia novas assinaturas aos 45 | Implementado |
| Contratos legados | Contratos/negociações incompatíveis são limitados ou cancelados na virada do ciclo | Implementado |
| Saves V735 | Campos da notificação são opcionais; migração etária não reescreve atributos nem snapshots | Implementado |

## Testes adicionados/ajustados

- `DriverMarketAgeContractV736Test`: idade 42/43/44/45, transição 45→16, bloqueio de novas propostas e renovação aos 45, e duração máxima de contratos.
- `DriverAgeVisibilityV700Test`: intervalo de idade passa a aceitar 16–45.
- `DriverOverallNewsV728Test`: texto de referência para o novo ciclo atualizado para 16 anos.

## Validação do contrato de release

- V736: **135/137 verificações aprovadas** em `tools/validate_release_contract.py`.
- A V735 original foi validada separadamente e obteve **134/137**.
- As duas falhas funcionais restantes são idênticas na V735 original e na V736, portanto são anteriores a esta atualização e permanecem fora do escopo solicitado:
  1. `AI facility priorities use Race Operations instead of Scouting`.
  2. `V717 projection uses official physical build and regulation pipeline`.
- A terceira falha da V735 (`current changelog and audit exist`) foi corrigida com a documentação e auditoria de estabilização da V736.

## Limite de validação desta execução

O ambiente de trabalho não contém Gradle instalado, Gradle Wrapper no pacote nem Android SDK configurado (`ANDROID_HOME` vazio). Portanto, não foi possível executar o build Android, os testes JUnit instrumentados pelo Gradle ou gerar um APK nesta sessão. A revisão foi feita por inspeção do código-fonte, comparação de validação com a base original e verificações estáticas do código/manifesto. O pacote deve ser aberto em um ambiente Android/Gradle para a validação final de compilação e execução no aparelho.
