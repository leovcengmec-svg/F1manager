# Auditoria V698 — piso universal de atributos em 40 pontos

## Identificação
- Nome público: F1 Team Manager V30
- VersionCode: 698
- VersionName: 0.698.0
- Base: V697 / 0.697.0
- ZIP: `F1TeamManager_Android_V30_First_Real_APK_Candidate.zip`

## Escopo corrigido
1. **Pilotos:** speed, qualifying, overtaking, defense, consistency, wet, tyre e potentialOverall limitados a 40–100. Parser, serializador, Overall derivado, mercado, estado de temporada, ciclo de evolução, regressão e eventos anuais corrigem dados antigos.
2. **Carros:** aerodynamics, chassis, engine, reliability, frontWing, rearWing, brakes e electricPowerUnit limitados a 40–100 em TeamCarState.
3. **Carros físicos:** os seis componentes, confiabilidade global e confiabilidade individual por componente limitados a 40–100.
4. **Cadeia técnica:** ResearchProject, ResearchDesign, FactoryOrder, CarPiece, TeamResearchState e TeamFactoryState normalizam desempenho/confiabilidade.
5. **Persistência e migração:** CareerPreferences normaliza saves antigos ao ler e salvar, inclusive na gravação atômica de investimento financeiro. A identificação de saves zerados foi preservada usando os valores brutos antes da normalização.
6. **IA e modo Team Principal:** carros físicos, snapshots serializados, carros desenvolvidos e peças instaladas utilizam o mesmo piso.
7. **Fornecedores:** avaliações de desempenho/confiabilidade de fornecedor de motor e pneus limitadas a 40–100.
8. **Penalidade financeira:** a redução de 20% aplicada na virada de temporada nunca derruba componentes ou confiabilidade permanente abaixo de 40; os dois carros físicos são normalizados após a penalidade.
9. **Motores de carreira e grid:** avanço de temporada, metas individuais, cálculo de Overall, mercado e desenvolvimento de pilotos normalizam os vetores antes do uso e da persistência.

## Exceção intencional — estados temporários de corrida
Desgaste de pneus, desgaste de chassi e confiabilidade instantânea durante uma falha são medidores transitórios, não atributos-base do piloto ou componentes. Permanecem na faixa operacional 0–100 para que degradação, pane e abandono continuem funcionando. Os atributos-base e confiabilidade de fábrica permanecem sempre em 40–100.

## Testes adicionados
`MinimumAttributeFloorV698Test.kt` contém 13 casos JUnit para verificar:
- normalização dos sete atributos e potencial do piloto;
- reparo de registros históricos abaixo de 40 e acima de 100;
- bloqueio de regressão de piloto abaixo de 40;
- atributos e confiabilidade do TeamCarState;
- componentes e confiabilidade por componente nos carros físicos;
- instalação de peças legadas com valores inválidos;
- projetos, designs, pedidos, peças e estado de fábrica;
- normalização agregada do TeamManagerState e fornecedores;
- RaceParticipant e construção do carro da temporada seguinte.

## Validação da build
A compilação integral Android deve ser confirmada no GitHub Actions. Este ambiente não dispõe de Gradle wrapper executável nem Android SDK; portanto, não se declara APK compilado nesta auditoria.

## Verificações executadas neste ambiente
- Compilação Kotlin (K2) do núcleo de atributos/evolução de pilotos, parser de atributos e desenvolvimento de pilotos, seguida de smoke test executável: aprovado (`DRIVER_FLOOR_SMOKE_OK`).
- Compilação do `CarGarageModels.kt` com tipos mínimos de apoio e smoke test de normalização, instalação de peça e garagem legada: aprovado (`GARAGE_FLOOR_SMOKE_OK`).
- Compilação do `FinancialSeasonClosureEngine.kt` com modelos mínimos de apoio e smoke test da penalidade financeira: aprovado (`FINANCIAL_PENALTY_FLOOR_SMOKE_OK`). Essa verificação isolada não substitui a suíte de integração do aplicativo.
- Foram adicionados 13 casos JUnit em `MinimumAttributeFloorV698Test.kt`, mas eles não foram executados por falta do Gradle/JUnit configurado neste ambiente.
- ZIP final validado com teste de integridade e conferência do manifesto, Gradle e arquivos de auditoria.
