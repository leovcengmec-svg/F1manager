# V533

- Removido o bônus financeiro calculado por pontos conquistados na corrida.
- Mantidos pagamentos fixos de patrocínio, bônus por meta de corrida, bônus por meta de qualificação, premiação do GP e custos operacionais.
- Aplicado tanto ao acerto de corrida com chave idempotente quanto ao caminho legado sem marcador.
- Preservado o campo antigo `pointsBonus` no modelo e no armazenamento para compatibilidade com saves existentes; ele não gera mais receita.
