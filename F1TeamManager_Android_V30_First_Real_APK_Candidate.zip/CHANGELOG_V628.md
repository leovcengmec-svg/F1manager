# V628 (0.628.0)

- Corrige `Unresolved reference: careerLoadRevision` em `MainActivity.kt`.
- Encaminha a revisão de carregamento para a tela Home, preservando a invalidação de eventos em memória após importar uma carreira.
- Mantém as correções V627 de save completo, integridade e invalidação de caches.
