# Auditoria V616 — Agrupamento do pelotão sob Safety Car

## Causa encontrada

O motor principal chamava `groupPeloton()` no deploy espontâneo, mas essa função apenas atualizava posições e limpava DRS; não havia estado de distância separado e o tempo acumulado permanecia inalterado. Na origem acionada por acidente, o Safety Car era ativado sem chamar a função. O motor interativo também ativava a neutralização sem nenhum mecanismo de fechamento de gaps, e sua duração era encerrada pela paridade da volta.

## Correção

- Adicionado `SafetyCarGroupingModel`, compartilhado entre `CareerWeekendEngine` e `InteractiveRaceSession`.
- A cada volta de Safety Car, a perda adicional de tempo é gradualmente reduzida para os pilotos que estavam mais distantes do líder no início da volta, fechando os gaps sem apagar tempos já realizados.
- Sob SC, o motor reduz para 10% a variação de ritmo normal entre carros, que passam a seguir um ritmo comum controlado. A compressão também usa distância-alvo de 1.500 ms, limite de 8.000 ms por volta e tempo de volta mínimo igual à referência do circuito mais 2.000 ms; isso impede teletransporte, tempos acumulados reescritos e voltas implausíveis.
- Os deploys espontâneos e por acidente acionam o agrupamento; eventos de bandeira vermelha preservam a sua lógica própria.
- DRS e duelos de ultrapassagem são desativados durante neutralizações.
- No motor interativo, os eventos de início/fim são registrados e a duração de SC/VSC passa a usar um limite explícito de voltas.

## Validações executadas

- Compilação Kotlin isolada do núcleo de corrida validada antes do ajuste final e recompilação final dos três arquivos alterados (`CareerWeekendEngine`, `InteractiveRaceSession` e `SafetyCarGroupingModel`) contra as dependências compiladas: aprovada (somente avisos preexistentes de parâmetros não utilizados).
- Smoke test determinístico da fórmula: gaps maiores que o alvo recebem fechamento, o limite de fechamento é respeitado e a volta neutralizada mantém um limite mínimo plausível.
- Smoke test de corrida completa com 80 pilotos e Safety Car forçado para exercitar o caminho: classificação completa e duas implantações de Safety Car processadas; DRS permaneceu desligado sob SC.
- Teste de regressão acrescentado em `app/src/test/kotlin/com/f1teammanager/core/race/SafetyCarGroupingV616Test.kt`, incluindo um teste integrado que compara a dispersão temporal antes/depois de deploy real.
- O teste integrado foi executado como smoke separado usando a engine compilada: spread caiu de 27.015 ms para 20.242 ms após um deploy, fechamento de 6.773 ms em uma volta neutralizada.
- O ZIP-base V615 foi validado antes da edição e os recursos/artefatos históricos foram preservados; novas alterações se limitam ao motor de corrida, teste, versão e changelog/auditoria.

## Limites

- O ambiente não contém Gradle Wrapper nem instalação Gradle utilizável; o build Android completo, a suíte JUnit pelo runner oficial, e testes em dispositivo/emulador não foram executados.
- O risco de Safety Car artificialmente elevado foi utilizado somente no smoke de integração para forçar o ramo determinístico; não foi alterada a tabela normal de probabilidade dos circuitos.
