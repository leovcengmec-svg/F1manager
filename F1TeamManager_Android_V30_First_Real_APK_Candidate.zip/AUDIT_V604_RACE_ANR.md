# Auditoria V604 — ANR ao abrir fim de semana e simular GP instantaneamente

## Sintoma reportado
Na V603 o Android mostra “F1 Team Manager não está respondendo” durante a simulação instantânea e também ao abrir o fim de semana interativo.

## Causa estática encontrada
1. `startWeekend()` chamava `syncAiWeeklyState()`, percorria as 39 equipes adversárias e executava `participants()`, que também simula o desenvolvimento de cada equipe, tudo no thread principal.
2. `simulateWeekendInstantlyForCareer()` executava `InstantSimulationService.simulateWeekendInstantly()` de forma síncrona. O serviço simula Q1/Q2/Q3 e todas as voltas da corrida para o grid inteiro (até 80 pilotos), usando loops de avanço sem suspender a UI.

## Correção V604
- `startWeekend()` agora usa `rememberCoroutineScope`, `launch` e `withContext(Dispatchers.Default)` para sincronizar/preparar a sessão em segundo plano; só publica snapshot e muda de tela no retorno ao dispatcher principal.
- A simulação instantânea é chamada de uma coroutine e a simulação pesada é executada em `Dispatchers.Default`.
- Adicionada proteção para impedir duas execuções concorrentes.
- O serviço de simulação e o motor de corrida continuam sendo os mesmos; as regras esportivas não foram alteradas.

## Risco residual
A gravação do resultado, o bônus de qualificação e `finalizeCompletedRace()` continuam ocorrendo no thread principal depois que a simulação retorna. Se o ANR persistir especificamente depois da bandeirada, será necessário instrumentar e separar esses passos mantendo o journal/idempotência. Os saltos de semanas também ainda são síncronos.

## Validação
A inspeção estática confirma que os caminhos de preparação e simulação estão envolvidos por `withContext(Dispatchers.Default)`. Build Android/JUnit/emulador não foram executados.
