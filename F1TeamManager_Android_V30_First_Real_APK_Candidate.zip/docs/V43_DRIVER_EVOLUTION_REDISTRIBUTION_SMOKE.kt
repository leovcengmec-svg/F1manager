import com.f1teammanager.core.season.DriverDefinition
import com.f1teammanager.core.season.DriverEvolutionEngine
import kotlin.random.Random

private fun driver(clazz:String, evolution:String, a:IntArray) = DriverDefinition(1,"TEST",1,a[0],a[1],a[2],a[3],a[4],a[5],a[6],70,clazz,evolution)
private fun attrs(d:DriverDefinition) = intArrayOf(d.speed,d.qualifying,d.overtaking,d.defense,d.consistency,d.wet,d.tyre)

fun main() {
    val start = driver("Lenda", "Prodígio", intArrayOf(100,99,98,98,98,98,98))
    val usage = IntArray(7)
    val evolved = DriverEvolutionEngine.applyPositiveGain(start, 8, usage, Random(7))
    check(evolved.speed == 100)
    check(attrs(evolved).sum() - attrs(start).sum() == 8)
    check(usage.sum() == 8)

    val pro = driver("Pro", "Normal", intArrayOf(89,88,88,88,88,88,88))
    val proEvolved = DriverEvolutionEngine.applyPositiveGain(pro, 6, IntArray(7), Random(9))
    check(proEvolved.speed == 89)
    check(attrs(proEvolved).sum() - attrs(pro).sum() == 6)

    val regression = driver("Lenda", "Normal", intArrayOf(40,41,41,41,41,41,41))
    val regressed = DriverEvolutionEngine.applyRegression(regression, 10, Random(3))
    check(attrs(regressed).all { it >= 40 })

    println("V43_EVOLUTION_REDISTRIBUTION_OK")
}
