# V36 — Weekly Proposal Expiry Regression

Corrected player-side market proposals to pass the actual in-game `currentWeek` into `DriverMarketEngine.makeOffer`.

Regression: a proposal created in week 17 now expires in week 18, not week 2.

No day-based clock is used.
