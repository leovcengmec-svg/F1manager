# V79 — Freios

## Funções
- Recarga de ERS: 70% a 110% por nível, N6 = 90% de referência.
- Defesa: multiplicador de 80% a 110% combinado com Defesa do piloto.
- Ultrapassagem: multiplicador de 80% a 110% combinado com Ultrapassagem do piloto.

Os freios não alteram diretamente o tempo médio de referência do GP. A Unidade elétrica permanece responsável pela utilização/entrega do ERS.
