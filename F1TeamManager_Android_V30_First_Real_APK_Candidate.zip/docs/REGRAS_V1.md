# Regras consolidadas — V1

## Gestores
- Não existe mecânica de "pedido de demissão".
- Desempenho ruim pode levar a equipe a demitir o gestor.
- Um gestor demitido fica disponível no mercado.
- Outra equipe pode contratar um gestor demitido.
- Desempenho bom aumenta a reputação do gestor.
- Outras equipes podem demonstrar interesse e tentar contratar um gestor de bom desempenho.
- Uma equipe pode perder um gestor bom para outra equipe mediante contratação.

## Carro
São 6 componentes:
1. Unidade de potência (motor)
2. Chassi
3. Asa dianteira
4. Asa traseira
5. Freio
6. Unidade de potência elétrica

## Diretriz
Os componentes terão efeitos distintos no desempenho da corrida e poderão evoluir por P&D. A integração matemática com o simulador de corrida será feita depois da fundação estar estável.
