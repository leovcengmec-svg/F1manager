# V81 — Race Engine: ERS/DRS por tempo médio de referência

## Objetivo
Eliminar os antigos bônus fixos de ERS/DRS e a dependência de `powerFactor`/`carBonus` no cálculo de performance.

## Tempo de volta
A base é exclusivamente o tempo médio de referência do GP (`baseLapTimeMs`).

Componentes com efeito direto no tempo:
- Motor
- Chassi
- Asa dianteira

O `carSpeed` genérico não fornece mais bônus de tempo.

## ERS
Potencial máximo por volta:
- 1,0% do tempo médio de referência do GP.
- Escalado pela eficiência da Unidade Elétrica.
- Escalado pela carga atual da bateria.
- Freios continuam determinando a recuperação de energia.

Não existe mais bônus fixo de 180 ms.

## DRS
Potencial quando ativo:
- 1,5% do tempo médio de referência do GP.
- Asa dianteira = 40% da eficiência.
- Asa traseira = 60% da eficiência.

Não existe mais ganho fixo de 280 ms.

## Removido do motor de corrida
- `powerFactor` de circuito como modificador de potência.
- `overtakingFactor` de circuito como modificador legado.
- `carBonus()` baseado em `carSpeed`.
- fórmula antiga de qualificação baseada em `enginePower * powerFactor`.
- bônus fixos de 180 ms ERS e 280 ms DRS.

## Preservado
Pneus, combustível, desgaste, consistência, dirty air, clima, Safety Car/VSC, estratégia, confiabilidade, DNF, qualificação Q1/Q2/Q3, classificação e demais sistemas continuam na cadeia do motor.
