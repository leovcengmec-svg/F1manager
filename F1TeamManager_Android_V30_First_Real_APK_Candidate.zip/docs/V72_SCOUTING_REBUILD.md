# V72 — Scouting reconstruído sobre a V70 completa

A V72 mantém a estrutura integral da V70 e transforma o Scouting em uma camada de conhecimento sobre os 100 pilotos já existentes.

## Regras
- Não cria nem descobre novos pilotos.
- Não altera o mercado de pilotos.
- Não altera Classe, Tipo de Evolução, Potencial ou atributos reais.
- Relatório válido até o fim da temporada.
- Precisão: 40% no nível 0 até 100% no nível 10.
- Nível 10 revela valores exatos.

## Custo por relatório
0 €0,5M; 1 €0,7M; 2 €1,0M; 3 €1,3M; 4 €1,7M; 5 €2,1M; 6 €2,6M; 7 €3,2M; 8 €3,8M; 9 €4,4M; 10 €5,0M.

## Categorias
Dados: Overall, atributos, potencial e evolução.
Análise: pontos fortes, pontos fracos, compatibilidade e risco.
Mercado: valor, salário, interesse e recomendação.

O relatório usa os dados reais existentes e apenas controla a precisão da informação apresentada ao jogador.
