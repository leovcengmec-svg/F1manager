# Stage 3 — Driver Market (implementation)

## Closed rules
- 100 drivers, 40 teams, exactly 2 active drivers per team.
- 20 drivers remain outside the grid.
- Contracts only 1, 2 or 3 years.
- No mid-season transfer. All accepted deals target the next season.
- 3-year contracts: year 1 protected; years 2 and 3 can receive proposals.
- 1-year and 2-year contracts can receive proposals while active.
- Driver roles: Pilot 1, Pilot 2, Equal.
- Role conflict prevents two Pilot 1 assignments.
- Market value, salary and (REMOVIDO) multa contratual are separate values.
- Multa contratual (REMOVIDA) uses a high penalty multiplier based on market value and remaining contract years.
- Small teams may sign strong drivers; interest is difficult, not impossible.
- AI uses the same market state and season-transition rules.
- Scouting costs money and produces a 4-week report.

## UI
- Filters: all, free, contracted, own team, negotiable, future transfers.
- Driver profile row shows Overall/class/evolution, contract year, salary, role and future transfer.
- Proposal dialog selects 1/2/3 years, role and salary.
- When the player's roster has two drivers, a replacement must be selected.

## Persistence
The market state is persisted with contracts, free agents, future deals, role preferences and pending negotiations.


## Tempo oficial do jogo
- O jogo funciona por semanas, não por dias.
- Propostas têm validade de 1 semana de jogo.
- Scouting tem validade de 4 semanas de jogo.
- Nenhuma lógica do mercado usa calendário diário ou timestamp para expiração.


## Regra atualizada
- Contratos: 1 a 5 anos.
- Propostas externas: somente no último ano do contrato (1/1, 2/2, 3/3, 4/4, 5/5).
- Multa/buyout contratual: removido integralmente.
- Transferências: somente para a temporada seguinte.
- Propostas: validade de 1 semana do jogo.
- Scouting: validade de 4 semanas.
