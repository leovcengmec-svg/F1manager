# V3 — Inventário do núcleo do Pitwall

Fonte auditada: `domhnallmorr/Pitwall`, repositório atual.

O repositório atual usa Electron/Vanilla JS no frontend e Python + SQLite + Pydantic no backend. O README documenta carreira, save/load, progressão semanal, mundo semeado, simulação de temporada, qualificação, estratégia, corrida volta a volta, pit stops, DNFs, mercados, finanças e desenvolvimento de equipe.

## Núcleo que será trazido para o Android

### 1. Estado da carreira
Origem principal:
- `backend/app/models/state.py`
- `backend/app/core/save_manager.py`

Responsabilidade:
- temporada/ano;
- equipes;
- pilotos;
- calendário/circuitos;
- staff;
- finanças;
- resultados;
- estratégias;
- desenvolvimento do carro;
- eventos e e-mails;
- estado de conclusão/game over.

### 2. Corrida
Origem principal:
- `backend/app/race/race_manager.py`
- `backend/app/race/lap_simulator.py`
- `backend/app/race/pace.py`
- `backend/app/race/strategy.py`
- `backend/app/race/retirements.py`
- `backend/app/race/stats_manager.py`
- `backend/app/race/constants.py`

Responsabilidade:
- qualificação;
- grid;
- ritmo;
- ultrapassagens;
- defesa;
- pneus;
- estratégia;
- combustível;
- pit stops;
- incidentes;
- falhas;
- DNF;
- classificação final.

### 3. Desenvolvimento do carro
Origem principal:
- `backend/app/core/player_car_development.py`
- `backend/app/core/player_chassis.py`
- `backend/app/core/ai_car_development.py`

Responsabilidade:
- projetos;
- recursos;
- tempo de desenvolvimento;
- qualidade;
- risco;
- progresso;
- evolução da performance;
- desenvolvimento da IA.

### 4. Campeonato
Origem principal:
- `backend/app/core/standings.py`

Responsabilidade:
- pontos;
- classificação de pilotos;
- classificação de construtores;
- countback;
- reset de temporada.

### 5. Mercado e gestão
O estado atual já possui estruturas para:
- Team Principal;
- Technical Director;
- Commercial Manager;
- pilotos;
- patrocinadores;
- fornecedores de motor;
- fornecedores de pneus.

A implementação Android vai transformar isso em um único domínio de mercado, permitindo nossas regras específicas de gestor.

## Estratégia de portabilidade

Não vamos transportar a arquitetura Electron/Python para o celular.

Vamos transportar o **comportamento do domínio** para Kotlin:

Pitwall Python
→ domínio Kotlin
→ persistência Android
→ simulador Kotlin
→ UI Compose.

A UI não terá regras de corrida embutidas.

## Ordem

1. GameState
2. Calendário
3. Equipes/pilotos/staff
4. Save/load
5. Car performance
6. Qualificação
7. Estratégia
8. Lap simulator
9. Incidentes/DNF
10. Resultados/standings
11. Progressão semanal
12. Mercado/finanças
13. P&D
14. IA
15. UI final

## Nossas alterações obrigatórias

O domínio portado será adaptado para:
- 40 equipes;
- 100 pilotos aprovados;
- 6 componentes de carro;
- sistema próprio de atributos;
- regras próprias de campeonato;
- mercado de gestores com demissão por desempenho e contratação por outras equipes;
- evolução do carro integrada ao simulador.

