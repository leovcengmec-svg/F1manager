# Auditoria V570 — Continuidade de áudio

## Correção
- O efeito de reprodução não usa mais `screen` como chave.
- Menu usa `LaunchedEffect(audioTrack, interfaceRotationIndex)`, então telas que compartilham `menu` não reiniciam a música.
- Telas normais da carreira compartilham `interface_sequence`; navegar entre elas não reinicia a faixa.
- `interfaceRotationIndex` só avança se `RESULT` tiver sido visto e a tela retornar a uma interface normal da carreira.

## Limites da validação
- Verificação estática do código e integridade do ZIP.
- Compilação Gradle e teste em aparelho não executados.
