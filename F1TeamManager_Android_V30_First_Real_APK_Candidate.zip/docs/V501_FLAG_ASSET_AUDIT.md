# V501 — Auditoria e correção de bandeiras

- Centralizada a resolução de bandeiras no `ExternalAssets.loadCountryFlag`.
- Aceitos códigos ISO de duas letras e nomes de países em português/inglês, com e sem acentos.
- Tentados nomes de arquivo como `br.png`, `flag_br.png`, `Brazil.png`, `Brasil.png`, `UnitedKingdom.png` e variantes normalizadas.
- Resultados nulos não são mais guardados no cache: se a permissão de mídia for concedida depois da primeira tentativa, a próxima chamada tenta novamente.
- A tela de início da temporada usa o mesmo resolvedor central, evitando manter uma lista incompleta de países em cada tela.
- Nenhum asset externo foi apagado ou renomeado.

Observação: os assets de bandeiras continuam sendo lidos da pasta pública `Pictures/F1Manager/Assets/countries/` (ou `Countries/`). Os arquivos externos do aparelho não estão incluídos no ZIP do código; a validação final de cada imagem precisa ser feita com os exemplos presentes no dispositivo.
