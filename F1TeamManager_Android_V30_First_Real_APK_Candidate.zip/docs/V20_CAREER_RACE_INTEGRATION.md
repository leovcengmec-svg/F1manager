# V20 — Career/Race Integration

`CareerRaceIntegration.kt` fornece uma fachada única para iniciar o fim de semana, configurar a estratégia e avançar a sessão sem a UI conhecer detalhes internos do simulador.

Também inclui resumo serializável em texto e estado mínimo de carreira para continuar o fluxo após a corrida.
