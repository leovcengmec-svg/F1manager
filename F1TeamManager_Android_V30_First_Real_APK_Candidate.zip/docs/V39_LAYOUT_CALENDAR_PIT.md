# V39 — Dashboard, calendário e Pit Wall

## UI / Android insets
- Todas as telas principais respeitam a área segura da barra de status.
- Navegação inferior respeita a barra de gestos/navegação do Android.
- O layout do Dashboard foi reorganizado para hierarquia de temporada, equipe, campeonato, próxima corrida e atalhos.

## Calendário
- Temporada 2026: 56 semanas internas, 30 GPs e 26 semanas livres.
- Datas dos GPs permanecem dentro de 2026 e são coerentes com a semana da temporada.
- Dashboard recebe `PULAR 1 SEMANA` e `PULAR ATÉ PRÓXIMO GP`.
- Não é permitido avançar sobre uma corrida pendente: na semana do GP os comandos de avanço ficam bloqueados e a corrida deve ser simulada.
- `PULAR ATÉ PRÓXIMO GP` chega na semana do GP, mas nunca o ultrapassa.
- Semanas livres contam para o avanço do P&D.

## Seleção inicial de equipe
- As 40 equipes são exibidas da maior para a menor força.
- As 21 equipes da era atual permanecem na faixa superior; as 19 históricas ficam abaixo dela, ordenadas por peso histórico.
- A equipe escolhida continua sendo variável e todo o Dashboard usa a equipe selecionada.

## Pit Wall / pneus
- O botão `BOX` da decisão do manager abre a seleção de composto.
- Os cinco compostos ficam disponíveis no pit stop: SOFT, MEDIUM, HARD, INTERMEDIÁRIO e WET.
- Chuva não bloqueia a escolha; o jogo destaca o composto recomendado.
- Quando a chuva começa, um carro do jogador que esteja em pneu inadequado recebe uma decisão de manager para BOX/MANTER/ESTENDER. Ao escolher BOX, o seletor de pneus é aberto.
- A escolha feita no pit atualiza também o plano do piloto, evitando que um BOX posterior volte silenciosamente ao pneu antigo.

## Patrocínios
- Contratos passam a ser medidos em corridas, não em anos.
- Cada novo contrato inicia com 5 corridas por padrão.
- O pagamento por GP e os bônus são aplicados na corrida; depois da quinta corrida o espaço é liberado para novo contrato.
- O Financeiro mostra `corridas restantes / total`.
