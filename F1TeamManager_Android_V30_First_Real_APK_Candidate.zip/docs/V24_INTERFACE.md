# V24 — Interface Foundation

V24 starts the visual layer on top of the frozen V23 core.

## Navigation
- Home
- Campeonato
- Equipe
- Carro & P&D
- Finanças
- Calendário
- Race Weekend

## Race Weekend
- Qualificação
- Estratégia
- Pit Wall
- Decision modal for VSC / Safety Car / Red Flag
- Result

## UI contract
The interface is a consumer of game state. It must not calculate championship, race or finance rules itself.

## Visual direction
- vertical mobile-first
- dark graphite background
- restrained red racing accent
- large touch targets
- compact cards
- no dependency on remote images or network for the interface shell

V24 is a UI foundation; it does not claim a final production Android APK.
