# V52 — Central de Notícias: layout unificado

Base oficial: V51 (Central de Notícias / Evolução de Pilotos).

- Preserva integralmente a cadeia V51 de evolução de pilotos e auditoria.
- Padroniza Mercado, Evolução de Pilotos, Evolução de Equipes e Eventos Anuais com a mesma estrutura de card.
- Evolução de equipes usa os 6 componentes oficiais: Unidade de potência, Chassi, Asa dianteira, Asa traseira, Freios e Unidade de potência elétrica.
- Ícones dos componentes são vetoriais internos e offline.
- Equipes usam escudos locais e pilotos usam fotos locais quando disponíveis.
- Exibe antes → depois e delta quando a notícia contém valores.
- VersionCode 52 / versionName 0.52.0.
