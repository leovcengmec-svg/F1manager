# V25 Interface Specification

## Visual reference
The user-supplied 6-screen composition is the primary layout reference.

## Rules
- Mobile portrait first.
- Dark graphite background with red racing accents.
- Header with season/round and settings.
- Home: team hero, championship metrics, next race CTA, circuit card, 6 quick-access tiles.
- Team: back/header, 3 tabs, team image, location, four financial/objective cards, facilities list with levels.
- Car: back/header, 3 tabs, car image, model label, six performance metrics, active development cards.
- Drivers: back/header, large portrait cards, number, age, overall, experience and core attributes, hire action.
- Weekend: back/header, session tabs, circuit/weather card, objectives, track report, strategy, car setup, start action.
- Championship: driver/constructor tabs and dense standings rows.
- Bottom nav: Início, Temporada, Mensagens, Menu.

## Pitwall-inspired improvements
The reference Pitwall project exposes Home, Email, Calendar, Grid, Staff, Driver Profile, Car, Finance, Facilities and Standings, plus race-weekend strategy and lap-by-lap race context. V25 keeps the user's six-screen visual language while reserving navigation surfaces for these deeper systems.
