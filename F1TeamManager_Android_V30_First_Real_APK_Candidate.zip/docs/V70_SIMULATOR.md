# V70 — Simulador

- Níveis 0–10.
- Custo de evolução: mesma tabela oficial das instalações (€10M a €120M).
- Reduz o tempo de P&D de todos os componentes em 0%–30% (3% por nível).
- Gera bônus direto global de performance na pista de 0%–1,0% (0,1% por nível).
- O bônus é aplicado individualmente ao carro após o cálculo da performance física.
- Não altera Overall, valores físicos das peças ou bônus específico de asas.
- Túnel de Vento continua exclusivo da eficiência aerodinâmica.
- Cadeia: Simulador → P&D → Design → Fábrica → Peça → Carro → Corrida.
