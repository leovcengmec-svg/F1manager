# V105 — Tela de Pilotos + Resumo da Temporada

- Layout da tela de pilotos reproduz o layout aprovado.
- Cada piloto exibe foto local, bandeira, OVR e 8 atributos.
- Oito atributos mantêm as métricas existentes; barras são somente visuais.
- Resumo da temporada usa o histórico real da temporada corrente: GPs, vitórias, pódios, poles, melhor resultado, pontos, média de chegada, melhor posição no campeonato e DNF.
- Evolução compara OVR/atributos atuais com o snapshot salvo na abertura da temporada.
- Snapshot da temporada é criado no início de uma nova carreira e na abertura de cada nova temporada.
- Nenhum motor de corrida, qualificação, calendário, P&D, fábrica, finanças ou mercado foi alterado.
