# Auditoria V567 — Fotos de pilotos

## Alterações
- `ExternalAssets.loadDriverPhoto`: IDs 12 (Franco Colapinto), 57 (Heikki Kovalainen) e 66 (Bruce McLaren) usam resolução por nome antes de qualquer alternativa, e os nomes numéricos são ignorados para esses IDs para impedir que um arquivo numérico legado mostre uma foto errada.
- Outros pilotos continuam com o comportamento anterior: ID numérico primeiro, nome como alternativa.
- Versão do app: `versionCode 567`, `versionName 0.567.0`.

## Arquivos externos esperados
A pasta continua sendo `Pictures/F1Manager/Assets/drivers/`. Para esses pilotos, use nomes como `Franco Colapinto.png`, `Heikki Kovalainen.png` e `Bruce McLaren.png` (ou variantes `driver_...`). A normalização aceita espaços, sublinhados, hífens e diferenças de maiúsculas/minúsculas.

## Limitações da validação
Verificação estática do código e integridade do ZIP; compilação Android e teste visual em aparelho não foram executados. A imagem só aparecerá se o arquivo correspondente existir na pasta externa e o aplicativo tiver acesso ao armazenamento.
