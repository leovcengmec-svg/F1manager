# V78 — Asa traseira / DRS

- 10 níveis oficiais de 40..100.
- Asa traseira não altera diretamente o tempo médio de referência do GP.
- Eficiência DRS por nível: 65%, 69%, 73%, 78%, 83%, 88%, 93%, 98%, 104%, 110%.
- DRS final = Asa dianteira 40% + Asa traseira 60%.
- O DRS continua automático e só é aplicado quando ativo durante a corrida.
- A asa traseira é o componente principal da eficiência do DRS.
