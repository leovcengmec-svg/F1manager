# V111 — Pipeline sem estoque

- Removido `TeamGarage.inventory` e toda a persistência de estoque.
- A cadeia oficial agora é: P&D → Design → Fábrica → peça física → instalação imediata no Carro 1 ou Carro 2.
- A fábrica continua consumindo custo e tempo e respeita ordens simultâneas/quantidade.
- Ao concluir a fabricação do jogador, cada unidade física é instalada diretamente no carro físico mais fraco para aquele componente.
- A IA usa a mesma cadeia e não mantém peças em estoque.
- A Central de Notícias deixa de mencionar estoque.
- `CarPiece` permanece apenas como representação transitória da peça recém-fabricada, não como inventário persistente.
