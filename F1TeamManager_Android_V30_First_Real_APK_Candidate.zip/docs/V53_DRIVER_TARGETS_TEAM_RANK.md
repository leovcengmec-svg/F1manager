# V53 — Metas de pilotos por ranking de força das equipes

## Regra oficial
As metas de temporada dos pilotos são definidas exclusivamente a partir do ranking de força das equipes no início da temporada.

- O ranking contém as 40 equipes, ordenadas pela força inicial da temporada.
- A força é calculada pelos 8 componentes do carro: aerodinâmica, chassi, unidade de potência, confiabilidade, asa dianteira, asa traseira, freios e unidade de potência elétrica.
- Para a equipe do jogador, quando disponível, é usado o carro efetivamente presente no início da temporada.
- Cada equipe ocupa dois slots consecutivos de meta no campeonato: equipe 1 = P1/P2, equipe 2 = P3/P4, ..., equipe 40 = P79/P80.
- A ordem dos dois pilotos usa a ordem oficial de cadastro da equipe; não usa Overall do piloto.
- O Overall do piloto não participa da definição da meta. Ele continua sendo usado pelo motor de evolução para potencial, teto e progressão individual.

## Remoção de duplicidade
Removidas as regras anteriores que combinavam 60% força da equipe + 40% Overall do piloto e a conversão isolada `baseCar -> posição alvo`.

O fluxo de evolução usa agora a mesma regra de expectativa baseada no ranking de força da equipe.
