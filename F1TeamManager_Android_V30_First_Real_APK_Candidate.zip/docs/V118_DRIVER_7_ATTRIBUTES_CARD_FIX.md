# V118 — Correção estrutural dos cards de pilotos

- Modelo canônico de piloto possui exatamente 7 atributos de desempenho.
- Removido `experience` do `DriverDefinition` e dos dados artificiais do WorldDatabase.
- OVR permanece média inteira dos 7 atributos.
- Evolução anual e ranking de melhores ganhos consideram somente os 7 atributos.
- Card visual usa grade fixa 4x2: 7 cards + 1 espaço vazio, mantendo dimensões idênticas.
- Alturas internas ajustadas para evitar corte do cabeçalho/atributos.
- Labels longos do resumo de temporada podem ocupar até 2 linhas.
