# V89 — Reestruturação do sistema de pneus

- Soft 15 voltas
- Medium 25 voltas
- Hard 36 voltas
- Intermediário 36 voltas
- Full Wet 50 voltas
- 4 planos secos A/B/C/D, todos compatíveis com a distância real do GP
- Capacidade do plano nunca pode ser inferior às voltas da corrida; sobra é permitida
- Soft, Medium e Hard aparecem em pelo menos um dos quatro planos
- Chuva não entra no planejamento seco
- Troca manual abandona o plano daquele piloto e ativa modo manual
- Entrada de chuva abandona os planos dos dois pilotos
- Chuva fraca/média: Intermediário; chuva forte: Full Wet
- Slick na chuva não recebe desgaste adicional; perde desempenho
- Pneu de chuva no seco sofre desgaste muito acelerado
- Ataque/Equilibrado/Defesa usam o tempo médio de volta do GP como referência de velocidade e mantêm os fatores de desgaste/combustível
- Degradação de pneu usa curva progressiva
