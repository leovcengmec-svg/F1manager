# V38 — Sponsorship Rework

## Objetivo
Corrigir o sistema de patrocínio para que cada contrato seja ativado uma única vez, ocupar um espaço fixo e gerar receitas sem duplicação.

## Estrutura
- 5 espaços fixos.
- Slot 1: patrocinador principal, maior potencial de receita.
- Slots 2–5: patrocinadores secundários, valores progressivamente menores.
- Cada slot oferece 3 propostas diferentes para escolha.
- Cada proposta contém entrada na assinatura, pagamento por GP, bônus por ponto, bônus de meta de qualificação e bônus de meta de corrida.

## Fluxo financeiro
- Aceitar contrato: entrada é creditada uma única vez.
- GP: pagamento recorrente de cada contrato ativo.
- Pontos: bônus por ponto de cada contrato ativo.
- Qualificação: bônus se a melhor posição da equipe atingir a meta.
- Corrida: bônus se a melhor posição da equipe atingir a meta.
- Contratos ativos são persistidos por slot.
- Clicar novamente não gera nova entrada: slot ocupado é bloqueado.

## Referências de design
A estrutura foi comparada com sistemas de Motorsport Manager para separar pagamento inicial, pagamentos recorrentes e objetivos/bonificações, evitando copiar valores ou conteúdo proprietário.
