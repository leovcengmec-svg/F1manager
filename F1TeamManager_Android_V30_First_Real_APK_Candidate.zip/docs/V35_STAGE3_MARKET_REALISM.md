# V35 — Stage 3 Market Realism

The AI market now uses a sporting/economic upgrade test before replacing a complete team's current driver during an active season.

Rules:
- No artificial transfer cap.
- Expiring contracts remain the main trigger for market activity.
- A complete team normally needs a meaningful improvement in driver market value or interest.
- Exceptional upgrades can bypass the normal threshold.
- A small random exception remains so the AI is not deterministic or perfect.
- All transfers remain next-season commitments.
- Time unit remains weeks only.
