# V117 — P&D cooldown visible + AI audit

- The six P&D cards now expose the existing per-component cooldown.
- After a design completes, the card shows remaining cooldown weeks and the week when research is released again.
- The disabled action changes from `PESQUISAR` to `BLOQUEADO` while the cooldown is active.
- Active research continues to show `ATIVO`.
- The underlying rule is unchanged: completion at week X releases the same component at week X+4.
- Cooldown remains independent per component.

AI audit over all 40 teams, season 2026, 56 simulated weeks:
- 116 design completions checked.
- 0 cooldown violations.
- Per-component version progression checked.
- No repeated same-component design occurred before a 4-week cooldown elapsed.

The audit confirms the AI respects the same four-week post-completion cooldown rule within a season.
