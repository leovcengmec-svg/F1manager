# V12 — Race Weekend / Pit Wall

## Regra de complexidade
O fim de semana contém apenas Qualificação + Corrida. Não há TL1/TL2/TL3.

## Responsabilidade do gestor
- Ataque / Equilibrado / Defesa
- Estratégia de pneus
- Pit stop normal
- Reação a VSC, Safety Car e bandeira vermelha
- Reação a alertas críticos de combustível e pneus

## Responsabilidade automática do piloto
- DRS
- uso/recuperação de ERS/bateria
- execução de ultrapassagens/defesas dentro da postura definida

## Regra de comunicação
Eventos estratégicos importantes geram uma decisão obrigatória. Alertas de combustível/pneu vêm do piloto e podem provocar mudança de estratégia.
