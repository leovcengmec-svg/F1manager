# V114 — CARRO / P&D layout and team car assets

Base: official V113.

Changes:
- Added a low-height full-width team-car visual banner before Carro 1.
- External car visual assets are resolved from `Pictures/F1Manager/Assets/Cars/`.
- Stable team IDs 01–40 are used as the preferred filenames.
- Carro 1 and Carro 2 now show 6 components in a 3x2 grid.
- Each component shows version, performance and reliability.
- The existing car Overall remains the average of the six component performance values.
- Added average performance and average reliability on the same bottom row.
- Nova Pesquisa is also arranged as 3 rows x 2 components.
- Removed the separate `VER PESQUISAS` action from the CARRO/P&D UI.
- Active research remains functional and is shown inside its component card.
- No race, qualifying, factory, P&D or investment business rule was intentionally removed.
- Installed component version is persisted independently for each physical car.
