V29_FIRST_REAL_UI
Core Kotlin compilation: OK (warnings only)
Android APK compilation: NOT executed in this environment; intended for GitHub Actions.
UI: Compose implementation with dashboard, team, drivers, car/P&D, calendar, standings, finance, weekend, qualifying, pit wall and result.
ZIP: prepared and integrity-tested after packaging.
