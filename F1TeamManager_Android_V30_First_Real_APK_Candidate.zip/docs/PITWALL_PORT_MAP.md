# Mapa de portabilidade Pitwall → Android

| Pitwall | Android | Estado |
|---|---|---|
| `models/state.py` | `core/GameState.kt` | Fundação criada |
| `core/save_manager.py` | `core/SaveRepository.kt` | Próximo |
| `race/race_manager.py` | `core/race/RaceEngine.kt` | Próximo |
| `race/lap_simulator.py` | `core/race/LapSimulator.kt` | Próximo |
| `race/pace.py` | `core/race/PaceModel.kt` | Próximo |
| `race/strategy.py` | `core/race/StrategyEngine.kt` | Próximo |
| `race/retirements.py` | `core/race/IncidentEngine.kt` | Próximo |
| `core/standings.py` | `core/championship/StandingsEngine.kt` | Próximo |
| `core/ai_car_development.py` | `core/car/AiCarDevelopment.kt` | Próximo |
| `core/player_car_development.py` | `core/car/PlayerCarDevelopment.kt` | Próximo |
| management markets | `core/management/ManagerMarket.kt` | Regras próprias |
| frontend pages | Compose screens | Depois do núcleo |

## Regra

"Portado" só será marcado quando houver implementação Android correspondente e teste do comportamento. Não considerar uma tela ou modelo visual como portabilidade do sistema.
