import com.f1teammanager.core.career.*

fun main() {
    val e = CareerFlowEngine()
    check(e.startCareer(1).playerTeamId == 1)
    check(e.openWeekend().phase == CareerPhase.QUALIFYING)
    check(e.qualifyingComplete().phase == CareerPhase.PRE_RACE)
    check(e.startRace().phase == CareerPhase.RACE)
    check(e.requestDecision("Safety Car").phase == CareerPhase.DECISION)
    check(e.resolveDecision().phase == CareerPhase.RACE)
    check(e.finishRace(100, 100, raceIncome = 2_000_000, raceCost = 500_000).budget == 51_500_000L)
    check(e.advanceRound().round == 2)
    val restored = CareerFlowEngine.load(e.save())
    check(restored.state.checkpoint() == e.state.checkpoint())
    repeat(23) {
        if (restored.state.phase == CareerPhase.HOME) {
            restored.openWeekend(); restored.qualifyingComplete(); restored.startRace(); restored.finishRace(1,1)
        }
        if (restored.state.phase == CareerPhase.RESULT) restored.advanceRound()
    }
    check(restored.state.completedRounds == 24 || restored.state.phase == CareerPhase.OFFSEASON)
    println("V16 FULL CAREER FLOW SMOKE TEST OK")
}
