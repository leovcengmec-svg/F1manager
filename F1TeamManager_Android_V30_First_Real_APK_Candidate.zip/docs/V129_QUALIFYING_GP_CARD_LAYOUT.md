# V129 — Qualificação: Card do GP e Rolagem Vertical

Base: V128.

## Escopo
- Mantém a tela de Qualificação em rolagem vertical livre.
- Adiciona no topo o card de GP usando a mesma linguagem visual do card existente do fim de semana.
- Exibe Round, semana, nome do GP, circuito, voltas e distância quando disponível.
- Mantém Q1/Q2/Q3 e o botão de simulação logo após a área de classificação, conforme layout aprovado.
- Mantém o card operacional da sessão, controles de velocidade e lista de pilotos.
- A lista passa a usar POS / EQUIPE / PILOTO / PNEU / TEMPO, preservando escudo e carro já disponíveis nos assets.

## Fora do escopo
Nenhuma alteração em motor de qualificação, tempos, regras Q1/Q2/Q3, estratégia, pneus, corrida ou demais sistemas do jogo.
