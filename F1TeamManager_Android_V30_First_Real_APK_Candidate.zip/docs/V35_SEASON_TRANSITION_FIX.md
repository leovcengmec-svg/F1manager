# V35 — Season Transition / Hall of Fame Fix

## Correções

1. **Hall da Fama — Campeões**
   - O indicador de campeonatos agora usa exclusivamente os registros de campeão arquivados (`C` para pilotos e `K` para construtores).
   - Pilotos/equipes sem título não aparecem no ranking de Campeões.
   - Títulos múltiplos do mesmo piloto/equipe são acumulados em uma única entrada.

2. **GP 30 não inicia 2027 automaticamente**
   - O GP 30 arquiva a temporada.
   - O jogo permanece no ano encerrado até uma ação explícita do jogador.

3. **Nova temporada por ação explícita**
   - A Home mostra `TEMPORADA 2026 ENCERRADA` e `IR PARA NOVA TEMPORADA` após o GP 30.
   - O botão incrementa o ano, zera o campeonato, retorna para a semana 1 e aplica o novo carro.
   - O histórico da temporada anterior permanece arquivado.

4. **Calendário por temporada**
   - O título usa o ano atual.
   - As datas substituem o ano fixo pelo ano da temporada atual.
   - Ex.: `19/02/2026` na temporada 2026 e `19/02/2027` na temporada 2027.

## Validação

- O ZIP mantém o nome oficial do projeto.
- A transição de GP 30 foi separada da ação de início da próxima temporada.
- Foi incluído teste estrutural cobrindo os três contratos principais.
- O ambiente de validação desta execução não possui Gradle/Android SDK; portanto, a compilação Android final deve ser feita no ambiente de build do projeto.
