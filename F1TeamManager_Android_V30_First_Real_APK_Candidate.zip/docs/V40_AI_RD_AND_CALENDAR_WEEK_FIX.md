# V40 — AI P&D real + correção das semanas de calendário

- Equipes da IA deixam de receber `aiProgress` genérico por GP.
- Cada equipe passa a ter um programa virtual determinístico de P&D por semana, com componente, intensidade, custo, duração, instalações, conhecimento e ganho próprios.
- O grid usa o carro virtual resultante do P&D da equipe na semana real da corrida.
- A semana atual não é consumida ao iniciar um projeto do jogador.
- Na semana 8, antes do GP 1, existem exatamente 7 semanas transcorridas para P&D.
- A semana do GP só entra no P&D quando o calendário realmente avança para depois dela.
