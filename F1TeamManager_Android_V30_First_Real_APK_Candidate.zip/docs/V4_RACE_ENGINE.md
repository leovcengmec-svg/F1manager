# V4 — Race Engine

## O que foi efetivamente implementado

A primeira camada Kotlin do simulador agora executa:

1. Qualificação.
2. Formação do grid.
3. Estratégia padrão de 1/2/3 paradas.
4. Combustível.
5. Desgaste de pneus.
6. Dirty air.
7. Ritmo do piloto.
8. Ritmo do carro.
9. Efeito de potência do motor conforme o circuito.
10. Consistência.
11. Classificação volta a volta.
12. Pit stops.
13. Ultrapassagens probabilísticas.
14. Melhor volta.
15. Resultado final.

## Correspondência com o Pitwall

A implementação foi feita a partir dos comportamentos observados nos módulos:
- `race/pace.py`
- `race/lap_simulator.py`
- `race/strategy.py`

O Pitwall documenta esse fluxo no README como qualificação, estratégia pré-corrida, replay volta a volta, pit stops e DNFs. 

## Ainda não marcado como completo

- crash model completo;
- falhas mecânicas;
- chassis wear;
- estratégia reativa durante safety car/VSC;
- suppliers;
- integração com `GameState`;
- pontos do campeonato;
- IA completa.

Esses serão adicionados em camadas para podermos testar cada parte isoladamente.

## Decisão importante

O motor não fica dentro da UI. `RaceEngineImpl` é domínio puro e pode ser testado sem Compose.
