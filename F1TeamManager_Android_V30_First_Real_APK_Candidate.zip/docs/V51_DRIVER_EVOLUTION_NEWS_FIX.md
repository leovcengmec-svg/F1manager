# V51 — Correção da Central de Notícias e auditoria da evolução de pilotos

## Problema encontrado

A evolução dos pilotos era processada e persistida por `CareerPreferences`, mas o fluxo Android mantinha em memória um `managerState.driverMarket` anterior ao GP. A Central de Notícias recebia a lista antiga até a Activity ser recriada.

Além disso, a publicação antiga de notícias só acontecia quando o `Overall` inteiro mudava. Como o Overall é a média inteira dos 7 atributos, um atributo podia subir sem alterar o número exibido. Isso escondia uma evolução real.

## Correções

- Após `applyDriverRaceEvolution()`, o estado persistido do mercado/notícias é recarregado imediatamente para `managerState`.
- A evolução agora gera um evento consolidado por GP na categoria `EVOLUÇÃO DE PILOTOS`.
- A notícia considera alterações de atributo, não somente alteração do Overall.
- A notícia informa quantos pilotos foram processados, quantos receberam alteração e quantos pontos foram distribuídos.
- Até 12 pilotos com alterações têm seus atributos exibidos no texto; os demais aparecem no contador adicional.
- Foi adicionada uma auditoria retroativa idempotente para carreiras criadas em versões anteriores: se já existem GPs concluídos e não existe notícia de evolução da temporada, a Central cria uma notícia comparando os atributos persistidos com a base inicial.

## Cadeia validada

`fim do GP → recordRace → applyDriverRaceEvolution → persistência dos atributos → persistência da notícia → recarga do driverMarket em memória → Central de Notícias`

## Preservado

- Motor de evolução contínua.
- 100 pilotos registrados / 80 titulares / 20 livres.
- Classes e tipos de evolução.
- Teto por classe e limites anuais por atributo.
- Redistribuição de pontos.
- Persistência da carreira.
- Nome oficial do ZIP permanece `F1TeamManager_Android_V30_First_Real_APK_Candidate.zip`.

## Versão

Android `versionCode 51` / `versionName 0.51.0`.
