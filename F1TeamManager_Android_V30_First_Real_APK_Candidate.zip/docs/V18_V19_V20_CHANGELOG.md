# V18 + V19 + V20 — Changelog

## V18
- Contrato `ManagerStrategy` com Ataque/Equilibrado/Defesa.
- Alertas de combustível e degradação dos pneus.
- Decisões separadas da execução automática de DRS/ERS.

## V19
- `InteractiveRaceSession` com estado CONFIGURING → READY → RUNNING → PAUSED_FOR_MANAGER_DECISION → FINISHED.
- VSC e Safety Car podem pausar a corrida para decisão.
- Red Flag pode ser injetada/pausada e exige pneus + postura.
- Alertas críticos podem gerar decisão de pit.

## V20
- `CareerRaceIntegration` encapsula a sessão para o fluxo de carreira.
- Qualificação, estratégia, avanço por volta, decisões e resumo ficam acessíveis por uma única fachada.
- Smoke test cobre qualificação, corrida, decisão e Red Flag.
