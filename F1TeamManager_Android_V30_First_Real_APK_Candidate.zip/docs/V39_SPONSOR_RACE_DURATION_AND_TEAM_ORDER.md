# V39 — Patrocínios por corrida + ordem inicial das equipes

- Patrocínios deixaram de usar duração em anos e passam a usar duração em corridas.
- Cada oferta atual dura 5 corridas.
- A entrada é paga uma única vez no aceite.
- O pagamento por GP e bônus continuam sendo pagos a cada corrida válida.
- Depois da 5ª corrida, o contrato é removido automaticamente e o slot fica livre para novas ofertas.
- O saldo de corridas restantes é persistido por slot.
- A tela de Finanças mostra `X/5 corridas restantes`.
- A seleção inicial de equipe é ordenada da maior força do carro para a menor, usando força, motor e confiabilidade como desempate.
- Os IDs das equipes não foram alterados; somente a ordem visual da escolha foi corrigida.
