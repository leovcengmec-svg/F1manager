# V30 — Correção do Build

O build anterior falhava na aplicação de `org.jetbrains.kotlin.android` porque o projeto usa Android Gradle Plugin 9.3.0, que já fornece Kotlin integrado.

Correções:
- removido `org.jetbrains.kotlin.android` do build raiz;
- removido `org.jetbrains.kotlin.android` do módulo `app`;
- removido `android.kotlinOptions {}` legado;
- removido `kotlin { jvmToolchain(17) }` desnecessário para este projeto;
- mantido o plugin `org.jetbrains.kotlin.plugin.compose` para o Compose Compiler.

Referência: documentação oficial do Android sobre Built-in Kotlin (AGP 9+).
