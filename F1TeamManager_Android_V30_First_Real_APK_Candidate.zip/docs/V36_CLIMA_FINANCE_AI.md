# V36 — Clima, Pneus, Financeiro e IA

Base: `F1TeamManager_Android_V30_First_Real_APK_Candidate.zip` (nome preservado).

## Correções desta rodada
- Equipe 35 renomeada para **Audi F1 Team**, mantendo Carlos Reutemann e Pedro Clerot.
- Força da Audi ajustada para faixa intermediária; desempenho passa a depender do carro + habilidades do piloto.
- Qualificação manualmente simulável: **Q1 80 → Q2 50 → Q3 20**.
- Q1/Q2/Q3 não são liberados automaticamente na interface; cada fase precisa ser simulada.
- Qualificação passou a considerar velocidade, classificação, consistência, experiência/ritmo e força do carro.
- Corrida usa o estado real de P&D do carro do jogador.
- IA evolui o carro progressivamente ao longo das rodadas e toma decisões de ataque/economia/box conforme posição, combustível, desgaste e chuva.
- Cinco compostos com desempenho e vida-alvo distintos: Soft 15, Medium 22, Hard 30, Intermediário 25, Wet 28 voltas.
- Clima: Sol, Nublado, Chuva fraca, Chuva média e Chuva forte.
- Chuva fraca/média recomenda Intermediário; chuva forte recomenda Wet.
- Habilidade de chuva do piloto entra na penalidade de ritmo em pista molhada.
- DRS permanece automático e só ativa a até 1,000 s do carro à frente.
- ERS recupera e utiliza energia automaticamente conforme postura.
- Box abre escolha de composto somente quando o manager manda parar; escolha inclui os cinco compostos.
- Última volta e número de paradas passam a aparecer no Pit Wall.
- Financeiro persistente: saldo, receitas, despesas e patrocinador.
- Patrocínios disponíveis na tela de Finanças, com entrada, pagamento por GP e bônus por ponto.
- P&D desconta dinheiro ao iniciar e continua consumindo semanas reais do calendário.
- Dashboard e calendário usam 30 GPs / 56 semanas, com semana e data.
- Histórico de classificação permanece salvo por GP.
- OVR duplicado removido da tela da equipe; atributos detalhados permanecem na tela de pilotos.
