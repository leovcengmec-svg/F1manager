# V13 — Career Integration

V13 conecta o núcleo de temporada ao Race Weekend/Pit Wall.

Fluxo: Manager -> Qualificação -> estratégia -> corrida interativa -> decisões -> resultado -> pontos -> finanças -> próxima rodada.

O gestor controla Ataque/Equilibrado/Defesa, pneus e pit decisions. O piloto executa DRS/ERS automaticamente. Eventos grandes e alertas críticos pausam a sessão e geram uma decisão.
