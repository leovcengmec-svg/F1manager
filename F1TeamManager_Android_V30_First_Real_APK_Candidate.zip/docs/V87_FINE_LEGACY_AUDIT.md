# V87 — Auditoria fina de legado e isolamento do ciclo

Base: V86.

## Correções

- Fallback de garagem no carregamento da carreira agora migra do `TeamCarState` salvo para a garagem física, em vez de reconstruir o carro-base da equipe.
- Fallback de garagem no avanço de P&D/Fábrica agora usa o estado salvo da carreira como migração, preservando evolução anterior.
- Fallback da tela de corrida agora usa a garagem derivada do estado salvo, evitando regressão para valores iniciais.
- Removida a instanciação não utilizada de `AIManagerEngine` do orquestrador da temporada.

## Auditoria

- `TeamGarage` continua sendo a fonte de desempenho efetiva da corrida.
- `TeamCarState` permanece somente como projeção/compatibilidade, planejamento anual e migração de saves antigos.
- `CarDevelopmentEngine.advanceWeeks()` não é chamado pelo ciclo geral nem pela corrida.
- P&D e Fábrica não alteram diretamente componentes físicos.
- Não há chamada de `TeamGarageFactory.fromInitial()` no caminho normal de corrida; as ocorrências restantes são inicialização genuína de nova carreira/IA.
- `core_v68.jar` é artefato histórico não referenciado pelo Gradle e não participa do APK/runtime.
- Scripts e documentos históricos não são importados pelo aplicativo.

## Validação

- Core Kotlin: compilado sem erros.
- `AICarContinuityAuditTest`: PASS.
- `V86RootIntegrationAuditTest`: PASS.
- `TwoSeasonChainAuditTest`: PASS — 60 GPs, início de 2028, 80 ativos, 100 pilotos.

Versão Android: `0.87.0` / `versionCode 87`.
