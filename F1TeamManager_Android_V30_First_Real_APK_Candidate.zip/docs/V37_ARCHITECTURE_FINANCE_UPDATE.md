# V37 — Unificação de arquitetura e regra financeira

- Removidos CareerFlowEngine/CareerFlowModels, que mantinham um estado paralelo legado.
- SeasonSettlementEngine permanece como autoridade única para classificação e premiação de construtores.
- Fechamento financeiro: saldo negativo é permitido durante a temporada. Após o crédito da premiação, se o saldo permanecer negativo, a equipe recebe -20% em cada um dos 6 componentes: motor, chassi, asa dianteira, asa traseira, freios e unidade de potência elétrica.
- A penalidade é aplicada uma única vez por equipe/temporada e registrada.
- O próximo carro é criado na transição de temporada.
- A cadeia Android passa a executar finanças das equipes IA, liquidação, penalidade e transição usando as mesmas autoridades do motor de temporada.
