# V58 — Níveis iniciais das 40 equipes

## Regra oficial

| Nível | Carro inicial | Instalações iniciais |
|---|---:|---:|
| Forte | 56–60 | 2 |
| Médio | 48–55 | 1 |
| Fraco | 40–47 | 0 |

Os seis componentes oficiais são: Motor, Chassi, Asa dianteira, Asa traseira, Freios e Unidade de potência elétrica. Cada componente recebe um valor individual dentro da faixa do nível da equipe.

A classificação das 40 equipes é persistida em `TeamDefinition.initialLevel`. A criação de carreira e a simulação das equipes IA usam a mesma regra de carro inicial.

Nível 0 de instalações é permitido pelo modelo de estado. A mecânica de evolução/upgrade das instalações não foi redesenhada nesta versão e será tratada na próxima atualização.

## Equipes

Forte: Ferrari, McLaren, Williams, Mercedes, Red Bull Racing, Benetton, Renault, Team Lotus, Aston Martin, Brawn GP, Audi F1 Team.

Médio: Brabham, Jordan Grand Prix, Toro Rosso, Sauber, BMW Sauber, Alfa Romeo, Force India, Racing Point, Toyota Racing, Honda Racing, Jaguar Racing, Stewart Grand Prix, Prost Grand Prix, BAR.

Fraco: Lotus F1 Team, Tyrrell, Minardi, Arrows, Cooper, Maserati, BMW, Ford, Bugatti, Caterham, Super Aguri, Andretti, Campos Racing, Invicta Racing, Rodin Motorsport.
