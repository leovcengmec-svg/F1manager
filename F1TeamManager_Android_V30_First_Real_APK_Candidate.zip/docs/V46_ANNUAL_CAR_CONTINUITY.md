# V46 — Continuidade anual do carro

## Alteração
A construção do carro da temporada seguinte passa a preservar **70% da diferença de cada componente em relação ao nível 50**, substituindo o fator anterior de 45%.

Fórmula:

`novo = 50 + (atual - 50) × 0,70`

O valor continua limitado ao intervalo 1–100 após a aplicação dos bônus normais de conhecimento, investimento, foco e regulamento.

## Ordem de construção
1. Encerramento da temporada e cálculo da classificação.
2. Pagamento da premiação de construtores.
3. Construção normal do carro da próxima temporada, incluindo a redução anual de 70% e os bônus já existentes.
4. Se o saldo final da equipe estiver negativo, aplicação adicional de **-20% nos seis componentes** do carro recém-construído.
5. Transição para a nova temporada.

A penalidade financeira não é aplicada antes da construção do carro, evitando que a construção normal sobrescreva a penalidade.

## Validação
- Compilação do núcleo Kotlin: OK.
- `FinancialPenaltyV37Test`: PASS.
- `CarConstructionAnnualReductionV46Test`: PASS.
- `TwoSeasonChainAuditTest`: PASS — 60 GPs, temporada 2028 / GP 1, 80 pilotos ativos e 100 pilotos cadastrados.
