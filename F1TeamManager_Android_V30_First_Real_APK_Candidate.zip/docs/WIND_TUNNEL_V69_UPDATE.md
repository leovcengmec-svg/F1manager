# V69 — Túnel de Vento

Implementado sobre V68.

- Níveis 0–10.
- Custo de upgrade preservado: €10M, €15M, €22M, €30M, €40M, €52M, €66M, €82M, €100M, €120M.
- Atua em Chassi, Asa Dianteira e Asa Traseira.
- Acelera pesquisa aerodinâmica em até 50% no nível 10.
- Aumenta a qualidade/ganho esperado de projetos aerodinâmicos sem alterar peças diretamente.
- Bônus direto de performance na pista: +0,2% por nível, máximo +2,0%.
- O bônus é aplicado à contribuição aerodinâmica de cada carro, sem alterar Overall ou valores físicos das peças.
- Player usa o nível persistido; IA usa a estrutura inicial da equipe.
- Fluxo preservado: Túnel → P&D → Design → Fábrica → Peça → Carro → Corrida.
