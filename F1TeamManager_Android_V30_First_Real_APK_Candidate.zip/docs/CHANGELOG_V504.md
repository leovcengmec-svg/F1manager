# V504 — Centro Comercial: renda semanal desde o nível 0

- O nível 0 do Centro Comercial agora também gera receita semanal de vendas nas lojas.
- Faixas definidas do nível 0 (€ 200.000–€ 400.000) ao nível 10 (€ 2.000.000–€ 3.000.000), conforme a distribuição acordada.
- Mantida a geração determinística e o bloqueio de crédito duplicado por temporada/semana.
- Atualizados testes unitários para conferir as faixas de todos os níveis e a receita no nível 0.
- Integridade do ZIP validada; compilação Android e execução dos testes Gradle não realizadas neste ambiente.
