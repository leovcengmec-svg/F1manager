# V121 — Calendário 50→30 e interface do GP

## Correções
- A base permanente continua com exatamente 50 circuitos.
- Cada nova carreira recebe uma nova semente de calendário.
- Cada nova temporada recebe uma nova semente.
- A seleção é de 30 circuitos únicos entre os 50.
- A semente fica persistida, portanto o calendário da carreira não muda ao reiniciar o aplicativo.
- Removida a duplicação visual do circuito no card.
- Circuito agora aparece com ícone de localização.
- A última linha duplicada foi substituída por tempo médio de referência por volta do GP.

## Auditoria
- 5 sementes diferentes testadas.
- 30 GPs por calendário.
- 30 circuitos distintos por calendário.
- Calendários diferentes entre sementes.
- Mesmo calendário reproduzido para a mesma semente.
- Resultado: PASS.
