# V60 — Novo modelo de garagem e dois carros

## Objetivo
Primeira etapa da reconstrução do carro/P&D/Fábrica.

A equipe passa a possuir dois carros físicos independentes. O P&D futuro criará projetos; a Fábrica futura produzirá unidades físicas (`CarPiece`) e cada unidade poderá ser instalada no Carro 1 ou Carro 2.

## Regras
- Existem exatamente 6 componentes oficiais: Motor, Chassi, Asa dianteira, Asa traseira, Freios e Unidade de potência elétrica.
- Cada carro possui valores próprios para os 6 componentes.
- `Overall` do carro = média dos 6 componentes físicos instalados.
- O Overall não é mais conceitualmente derivado de P&D.
- A equipe possui `teamAverageOverall` apenas como média dos dois carros quando uma tela/sistema precisar de uma visão agregada.
- Cada peça física possui ID, componente, versão e desempenho.
- Uma peça produzida pode ser instalada em apenas um carro.
- Carro 1 e Carro 2 podem ter configurações diferentes.
- O sistema antigo continua temporariamente como ponte de compatibilidade nesta etapa; não foi removido antes da migração de P&D/Fábrica.

## Próxima etapa
Reconstruir o P&D para produzir `DevelopmentProject`/projetos tecnológicos sem alterar diretamente o desempenho do carro. Em seguida, conectar a Fábrica à produção de `CarPiece` e ao estoque.
