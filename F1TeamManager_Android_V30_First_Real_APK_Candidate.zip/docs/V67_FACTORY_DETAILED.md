# V67 — Fábrica detalhada

A Fábrica é a primeira instalação fechada individualmente.

## Função
Transformar um ResearchDesign concluído em CarPiece física. Não altera Overall e não instala automaticamente.

## Níveis 0–10
| Nível | Ordens simultâneas | Máx. peças/ordem | Tempo | Custo | Estoque |
|---:|---:|---:|---:|---:|---:|
|0|1|1|100%|100%|30|
|1|1|1|95%|98,5%|40|
|2|1|2|90%|97%|50|
|3|2|2|90%|95,5%|60|
|4|2|3|85%|94%|70|
|5|2|3|85%|92,5%|80|
|6|3|4|80%|91%|90|
|7|3|4|80%|89,5%|100|
|8|4|5|75%|88%|110|
|9|5|5|70%|86,5%|130|
|10|6|6|65%|85%|150|

Tempo base: 1,5 semana por unidade, arredondado para cima e multiplicado pelo nível da Fábrica, mínimo 1 semana.

## Regras
- P&D concluído é obrigatório.
- O projeto é retirado da fila quando entra na fabricação.
- O pagamento ocorre no início da ordem.
- Uma ordem produz exatamente a quantidade contratada.
- Ordens podem rodar em paralelo conforme o nível.
- A conclusão cria peças físicas no estoque.
- Nenhuma peça é instalada automaticamente.
- O estoque respeita a capacidade da Fábrica; quando excedido, as peças mais antigas são descartadas do inventário limitado.
- O desempenho do design não é alterado pela Fábrica.

## Cadeia
P&D → Design → Fábrica → Peça física → Estoque → Carro 1/Carro 2 → Corrida.
