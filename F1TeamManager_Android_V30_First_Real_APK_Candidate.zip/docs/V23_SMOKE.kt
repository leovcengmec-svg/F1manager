import com.f1teammanager.core.game.*
import com.f1teammanager.core.race.*

fun main(){
    val g=UnifiedGameEngine(20261003)
    var s=g.snapshot()
    check(s.calendar.size==24)
    check(s.standings.size==80)
    check(s.drivers.size==2)
    g.startWeekend()
    s=g.snapshot(); check(s.race!=null)
    val ids=s.drivers.map{it.id}
    g.setStrategy(ids[0],DriverPosture.ATTACK,Tyre.SOFT)
    g.setStrategy(ids[1],DriverPosture.BALANCED,Tyre.MEDIUM)
    var guard=0
    while(true){
        s=g.advanceRace(); guard++
        if(s.race?.pendingDecision!=null){
            val d=s.race!!.pendingDecision!!
            if(d.type==ManagerDecisionType.RED_FLAG) g.chooseRedFlag(Tyre.MEDIUM,DriverPosture.BALANCED)
            else g.choose(ManagerDecisionAction.STAY_OUT)
        }
        if(s.race?.completed==true) break
        check(guard<200) { "race did not finish" }
    }
    val before=g.seasonState().currentRound
    s=g.finishWeekend()
    check(g.seasonState().currentRound==before+1)
    check(g.managerState().round==before+1)
    check(s.finance.income>=0)
    val save=java.io.File("/tmp/f1tm-v23-save.txt")
    GameSave.save(save,g)
    val loaded=GameSave.load(save)
    check(loaded!=null && loaded.first.currentRound==g.seasonState().currentRound)
    check(save.readText().startsWith("F1TM_SAVE_V23"))
    println("V23_SMOKE_OK round=${s.round} standings=${s.standings.size} budget=${s.finance.budget}")
}
