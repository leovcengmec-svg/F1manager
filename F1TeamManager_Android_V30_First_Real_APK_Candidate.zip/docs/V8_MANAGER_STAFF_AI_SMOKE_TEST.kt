import com.f1teammanager.core.manager.*

fun main() {
    val baseCar=TeamCarState(72,70,75,78)
    var state=TeamManagerState(
        playerTeamId=1,
        car=baseCar,
        finance=TeamFinanceState(50_000_000),
        manager=ManagerProfile(reputation=80,experience=8)
    )
    val market=ManagerMarketEngine()
    val offers=market.availableStaff(state)
    check(offers.size >= 3)
    val tech=StaffMarketEngine().staffPool().first { it.role==StaffRole.TECHNICAL_DIRECTOR }
    state=market.hireStaff(state,tech)
    check(state.staff.any { it.role==StaffRole.TECHNICAL_DIRECTOR })
    val sponsor=SponsorContract("Global Apex",5_000_000,3_000_000,25_000,2,60)
    state=market.replaceSponsor(state,sponsor)
    check(state.sponsor.name=="Global Apex")
    val engine=StaffMarketEngine().supplierPool().first { it.type==SupplierType.ENGINE }
    state=market.replaceSupplier(state,engine)
    check(state.engineSupplier.name==engine.name)
    val ai=AIManagerEngine(42)
    val decision=ai.decide(2,5,baseCar,state.finance.budget)
    check(decision.teamId==2)
    val modifier=ai.performanceModifier(state.staff,state.sponsor,state.engineSupplier,state.tyreSupplier)
    check(modifier in -30..30)
    println("V8 MANAGER STAFF/AI SMOKE TEST OK")
}
