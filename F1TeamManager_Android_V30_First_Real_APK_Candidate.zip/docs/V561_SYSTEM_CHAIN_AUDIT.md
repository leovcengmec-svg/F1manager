# Auditoria de cadeia funcional — F1 Team Manager V561

**Pacote base:** `F1TeamManager_Android_V30_First_Real_APK_Candidate.zip`  
**Versão:** `versionCode 561`, `versionName 0.561.0`  
**Tipo de auditoria:** leitura de código, validações estáticas e cenários financeiros auxiliares.  
**Limitação:** não foi possível compilar o app Android nem executar JUnit/Kotlin runtime nesta sessão: o projeto não inclui Gradle Wrapper e o ambiente não tem Gradle/Android SDK. A aprovação dos scripts abaixo não equivale a aprovação em aparelho.

## Resumo

A auditoria identificou inconsistências reais entre garagem física, modelo legado, perfis iniciais, eventos anuais, regulamento, virada de temporada e persistência. V561 corrige esses caminhos centrais. A cadeia está mais consistente, mas **não deve ser certificada como 100% funcional antes de executar a suíte Kotlin e uma carreira real de pelo menos duas temporadas no Android**.

## Correções aplicadas em V561

1. **Carro do jogador começa vazio:** os seis componentes iniciam em 0, sem peças instaladas. O desempenho só muda no carro físico depois da instalação da peça pesquisada e fabricada.
2. **IA conserva competitividade:** os adversários iniciam com o perfil técnico da equipe (Forte/Médio/Fraco) e hardware-base instalado, com IDs explícitos `INITIAL-AI-*`. Isso evita que todos os adversários comecem com Overall 0.
3. **Modelo legado e projeção:** `TeamCarState.normalized()` e as projeções a partir da garagem aceitam desempenho 0 sem piso artificial 1/40.
4. **Eventos anuais:** ganho/perda em componentes vazios não cria desempenho gratuito para o jogador. Para a IA, a projeção canônica usa o perfil-base compatível com a garagem inicial.
5. **Regulamento e penalidade de temporada:** componentes sem peça continuam em 0; apenas hardware instalado sofre ajuste de desempenho. Confiabilidade mantém a escala independente 1–100.
6. **Virada de temporada:** V0 só é associado a componentes que realmente constam em `installedPieces`. A persistência agora preserva a versão 0 intencional, ignora chaves de versão órfãs e mantém o fallback V1 para saves antigos sem metadado.
7. **Compatibilidade de saves:** desempenho legado positivo sem ledger físico é convertido em baseline `LEGACY-MIGRATED-*`; garagens vazias continuam sem peça sintética. O reset do starter antigo `INIT-*` é restrito ao caso intacto descrito no código.
8. **Transações P&D/fábrica/garagem/finanças:** `saveEngineeringBundle()` grava P&D, fila, investimento, garagem e finanças num único `commit()`. A instalação e o avanço semanal usam `saveCareerStepBundle()` para salvar o snapshot relacionado de uma vez.
9. **Nova carreira:** o núcleo (carro, garagem, P&D, fila da fábrica, investimento técnico, finanças, instalações, desenvolvimento de pilotos, patrocínios e estado inicial do mercado) é gravado com um único `commit()`. Os ledgers auxiliares antigos são limpos antes da inicialização.
10. **Melhoria de instalação:** a UI só publica o novo estado depois que a melhoria, débito, orçamento técnico e notificação são persistidos no mesmo bundle.
11. **Financeiro:** as transações bloqueadas são apresentadas separadamente como obrigações pendentes e não como pagamentos efetuados. A classificação por descrição ainda é heurística e merece futura migração para metadados estruturados.
12. **Ranking/seleção:** o ranking inicial usa `InitialTeamProfile.values()` em vez do Overall físico zerado do jogador.

## Matriz de sistemas

| Sistema | Status após V561 | Confirmação disponível |
|---|---|---|
| Banco inicial de equipes/pilotos | Estrutura preservada | Validações estáticas |
| Perfil inicial/ranking de equipes | Corrigido no código | Contratos de seleção e ranking |
| Carro físico do jogador | Começa em 0 | Teste de regressão fonte adicionado; JUnit não executado |
| Carros da IA | Perfil-base + peças iniciais | Teste de regressão fonte adicionado; JUnit não executado |
| P&D → design → fábrica → instalação | Persistência mais coesa | Contratos estáticos passam; runtime não executado |
| Desempenho e confiabilidade | Escalas separadas (desempenho 0–100, confiabilidade 1–100) | Validadores fonte |
| Eventos anuais/regulamento | Zero preservado em carro vazio | Asserções matemáticas e checagens de código |
| Calendário e 56 semanas | Contratos presentes | Auditoria estática 18/18; sem sessão real de calendário |
| Qualificação, corrida e simulação instantânea | Código/contratos presentes | Sem build nem execução de corrida Kotlin |
| Resultado, pontos e finalização idempotente | Journals/ledgers presentes | Contratos estáticos de ciclo |
| Salários, patrocínios e finanças | Ledgers de idempotência preservados | Continuidade financeira estática e cenários Python |
| Painel financeiro | Pendências destacadas | Código e validação estrutural; categoria continua inferida por descrição |
| Instalações | Atualização e débito em bundle | Contrato estático; runtime pendente |
| Mercado/contratos de pilotos | Migrações e ledger presentes | Persistência estrutural; negociação real não executada |
| Notificações | Vários produtores/persistência existentes | Não exercitado visualmente no Android |
| Assets externos (bandeiras, escudos, fotos, carros, GPs) | Dependência externa permanece | Pastas internas de equipes/pilotos/carros/GPs conferidas; arquivos externos de bandeiras precisam ser conferidos no aparelho |
| Salvamento/recuperação completa | Journals e operações principais reforçados | Só contratos estáticos; teste de matar/reabrir app ainda necessário |
| APK Android | Não validado | Gradle/Android SDK ausentes nesta sessão |

## Validações executadas

| Script | Resultado | Tipo |
|---|---:|---|
| `tools/race_sim_test/validate_project.py` | 40/40 | Estrutural/fonte |
| `tools/race_sim_test/final_release_audit.py` | 25/25 | Estrutural; não compila Android |
| `tools/race_sim_test/v448_game_cycle_audit.py` | 18/18 | Contratos de ciclo do jogo |
| `tools/race_sim_test/v498_ai_persistence_audit.py` | 8/8 | Contratos de persistência da IA |
| `tools/finance_test/v440_financial_continuity_audit.py` | 13/13 | Contratos financeiros |
| `tools/finance_test/v441_financial_model_audit.py` | 7/7 | Modelo financeiro |
| `tools/audit_v429.py` | 9/9 | Diário de transição de temporada |
| `tools/audit_v445_regulation.py` | 4.772/4.772 | Asserções matemáticas/fonte |
| `tools/finance_test/v438_finance_stress_test.py` | PASS | Cenário Python ilustrativo |
| `tools/finance_test/v439_finance_stress_test.py` | PASS | Cenário Python ilustrativo |
| Integridade do ZIP | PASS após reempacotamento | Arquivo |

## Pontos ainda abertos

- Executar JUnit/Kotlin runtime, principalmente `InitialCarStartsAtZeroV560Test`, `V86RootIntegrationAuditTest`, `TwoSeasonChainRuntimeAudit` e os testes de recuperação de corrida.
- Fazer build Android com Android SDK via GitHub Actions ou máquina de build.
- Executar o fluxo no dispositivo: carreira nova → pesquisar → concluir design → fabricar → instalar no carro 1 → confirmar carro 2 inalterado → correr → avançar semana → reabrir o app.
- Simular 60 GPs / duas viradas de temporada e conferir 80 pilotos, Q1/Q2/Q3, pontuação, salários, prêmios, patrocínios e estados persistidos.
- Conferir as bandeiras na pasta externa real; o código pode reconhecer aliases, mas não consegue exibir um arquivo que não existe no diretório esperado.

## Conclusão

V561 remove inconsistências importantes e adiciona guardas para que carro vazio, hardware de IA, eventos anuais e virada de temporada não usem estados conflitantes. A cadeia está melhor coberta por contratos de fonte, mas a aprovação final depende de build e testes de runtime que não foram possíveis nesta sessão.
