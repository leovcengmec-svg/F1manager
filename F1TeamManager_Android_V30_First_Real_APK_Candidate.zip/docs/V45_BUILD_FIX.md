# V45 — Correção de compilação da Central de Notícias

Correção aplicada após erro do Android Build em `MainActivity.kt:553:34`:

- A tela `Home` já montava o atalho `CENTRAL DE NOTÍCIAS` usando `onNews`, mas a assinatura de `Home` não recebia esse callback.
- O callback `onNews={ screen = Screen.NEWS }` foi adicionado à chamada de `Home`.
- `onNews: () -> Unit` foi adicionado à assinatura de `Home`.
- A implementação da `Home` passa a compilar de forma coerente com o atalho já existente.

Validação:
- Todo o núcleo Kotlin (`app/src/main/java/com/f1teammanager/core`) compilado com `kotlinc`: OK, apenas warnings.
- O erro mostrado no build (`Unresolved reference 'onNews'`) foi eliminado na origem.
- Não foi possível executar o APK Android completo neste ambiente por ausência do Gradle Wrapper/executável Gradle.
