# V113 — Controle de Investimento Técnico

## Regra anual
O ranking de força da equipe no início da temporada define 5 níveis:

| Ranking | Nível | Limite anual |
|---|---:|---:|
| 1–8 | 5 | €200M |
| 9–16 | 4 | €250M |
| 17–24 | 3 | €300M |
| 25–32 | 2 | €350M |
| 33–40 | 1 | €400M |

Quanto mais forte a equipe, menor o limite.

## O que consome o limite
- P&D / Design
- Fabricação de peças físicas
- Evolução de instalações

Salários, mercado de pilotos, marketing, patrocínios e outros custos comerciais não entram no limite.

## Comportamento
- Cada equipe possui controle independente.
- O valor investido começa em €0 a cada temporada.
- O limite é recalculado no início da nova temporada.
- O gasto é registrado quando a ação é iniciada.
- Projetos já iniciados não são cancelados quando o limite é atingido.
- O mesmo teto é aplicado à IA; o desenvolvimento físico da IA agora contabiliza P&D e fabricação.
- O controle é persistido entre reinicializações do aplicativo.

## Interface
A tela da equipe ganhou o card **INVESTIMENTO TÉCNICO** e uma tela de **CONTROLE DE INVESTIMENTO** com ranking, nível, limite, investido, disponível e distribuição por categoria.

## Base
V112 permanece a base funcional. Esta alteração gera V113 sem alterar o nome oficial do ZIP.
