# V14 UI/Core Smoke Test

Validação automatizada feita no núcleo Kotlin:
1. Iniciar GP com 80 pilotos.
2. Confirmar grid de 80 após classificação.
3. Definir estratégia para os dois pilotos do jogador.
4. Entrar na corrida.
5. Avançar voltas e resolver decisões pendentes.
6. Confirmar resultado com 80 classificados.

A compilação Android completa depende do Android SDK/Gradle toolchain, que precisa estar disponível no ambiente de build final.
