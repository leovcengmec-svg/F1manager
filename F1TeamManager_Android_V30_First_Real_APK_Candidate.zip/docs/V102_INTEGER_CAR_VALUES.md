# V102 — Atributos de carro inteiros

- Performance dos componentes do carro permanece `Int` 1..100.
- Confiabilidade permanece `Int` 1..100.
- `PhysicalCar.overall` passou de `Double` para `Int`, com arredondamento matemático único.
- `TeamGarage.teamAverageOverall` passou de `Double` para `Int`.
- `InitialTeamProfile.CarValues.overall` passou de `Double` para `Int`.
- Nenhum arredondamento decimal é mantido no estado do carro.
- O motor de corrida permanece inalterado.

## Auditoria
- Core Kotlin: compilado com sucesso.
- FullSeasonIntegrationTest: PASS.
- TwoSeasonChainAuditTest: PASS.
- AICarContinuityAuditTest: PASS.
- V86RootIntegrationAuditTest: PASS.
- SeasonPrizeAuditTest: PASS.
- IntegerCarAudit: PASS — 40 equipes, 11 fortes, 14 médias, 15 fracas.
