# V33 — Pit Wall Playability

## Objetivo
Transformar a corrida em uma sessão realmente gerenciável e observável no Android.

## Entregue
- Corrida automática por volta, com pausa automática quando existe decisão do manager.
- Classificação ao vivo dos 80 pilotos.
- Estado dos dois pilotos da equipe: posição, pneu, desgaste, combustível e pit stops.
- Três posturas durante a corrida: Ataque, Equilibrado e Defesa/Economia.
- Pit stop manual e troca de composto.
- Pneus com aderência e degradação diferentes por composto.
- Combustível com consumo dependente da postura; combustível crítico gera decisão.
- Se o manager manda manter/estender com condição crítica, a condição pode produzir DNF por falta de combustível ou degradação do pneu.
- Safety Car, VSC e bandeira vermelha continuam interrompendo a corrida.
- Bandeira vermelha apresenta escolhas combinadas de pneu/postura.
- Resultado da corrida grava pontos de pilotos e construtores no armazenamento da carreira.
- Campeonato mostra os 80 pilotos e 40 construtores.
- Mercado de pilotos ficou acessível pela tela Equipe, em vez de ficar escondido.
- Telas internas ganharam botão de voltar.
- Botões vermelhos usam texto branco para contraste.

## Validação local
O núcleo Race/Season foi compilado com `kotlinc` e passou por dois smoke tests: corrida completa com 80 classificados/pontuação e teste de consequência por condição crítica ignorada.

## Limitação
O ambiente desta execução não possui Android SDK/Gradle, portanto a geração física do APK continua sendo validada pelo GitHub Actions.
