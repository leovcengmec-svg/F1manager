# V63 — Peças físicas, instalação e corrida com dois carros

## Objetivo
Completar a ligação entre a Fábrica, o estoque e os dois carros físicos e fazer a corrida do jogador consumir os carros físicos.

## Regras
- Uma `CarPiece` fabricada entra no estoque e não altera automaticamente nenhum carro.
- O manager escolhe explicitamente Carro 1 ou Carro 2.
- Ao instalar, a peça sai do estoque e substitui o valor daquele componente no carro escolhido.
- Cada peça instalada também leva sua confiabilidade para o carro.
- O `Overall` de cada carro continua sendo a média dos seus 6 componentes físicos; confiabilidade não entra no Overall.
- A média da equipe é apenas informativa.
- Na corrida do jogador, os dois contratos da equipe são associados de forma determinística aos dois carros, por ID do piloto, e o desempenho do carro físico passa a alimentar o motor de corrida.
- O sistema legado continua como compatibilidade para partes ainda não migradas.
