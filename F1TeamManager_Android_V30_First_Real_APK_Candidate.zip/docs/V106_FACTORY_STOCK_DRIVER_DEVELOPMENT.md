# V106 — Estoque físico e Desenvolvimento de Pilotos

- A Fábrica continua produzindo unidades físicas no `TeamGarage.inventory`.
- O estoque agora fica visível também na tela EQUIPE, dentro do card FÁBRICA, com quantidade e versões por componente.
- `VER ESTOQUE` leva diretamente para CARRO / P&D, onde cada peça física pode ser instalada separadamente em Carro 1 ou Carro 2.
- Instalar uma peça remove somente o `pieceId` selecionado; outras versões/unidades permanecem no estoque.
- O programa de Desenvolvimento de Pilotos foi conectado ao fluxo real.
- O jogador seleciona um dos pilotos titulares para acelerar sua evolução.
- O nível da instalação define capacidade, duração e pontos do programa.
- O programa é persistido por equipe e avança junto com as semanas do calendário.
- Ao concluir, os pontos são aplicados aos atributos persistidos do piloto; classe, tipo de evolução e potencial máximo não são alterados.
