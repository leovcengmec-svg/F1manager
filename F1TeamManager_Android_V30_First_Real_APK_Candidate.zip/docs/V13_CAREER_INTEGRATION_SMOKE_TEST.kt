import com.f1teammanager.core.race.*
import com.f1teammanager.core.season.*

fun main() {
    val ps = WorldDatabase.drivers.map { it.toParticipant(WorldDatabase.teams[it.teamId-1]) }
    val rd = WorldDatabase.rounds.first()
    val c = RaceCircuit(rd.round, rd.circuit, rd.laps, rd.baseLapTimeMs, rd.powerFactor, rd.overtakingFactor, safetyCarRisk=rd.safetyCarRisk)
    val e = CareerWeekendEngine(20261003)
    var s = e.start(ps, c, 1)
    check(s.grid!!.grid.size == 80)
    e.setPlan(ps.first{it.teamId==1}.driverId, DriverStrategyMode.ATTACK, Tyre.MEDIUM)
    var guard = 0
    while (!s.completed && guard++ < 500) {
        val d = s.decision
        s = if (d != null) e.choose(d.request.options.first()) else e.advance()
    }
    check(s.completed)
    val r = e.result()
    check(r.classification.size == 80)
    check(r.points.isNotEmpty())
    println("V13 CAREER INTEGRATION SMOKE TEST OK: laps=${r.classification.maxOf{it.laps}} events=${r.events.size}")
}
