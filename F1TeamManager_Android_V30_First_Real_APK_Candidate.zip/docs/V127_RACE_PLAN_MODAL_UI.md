# V127 — Race Plan Modal UI

Base: V126.

Scope strictly limited to race interface presentation:
- Replaced the inline pre-race plan controls with a modal matching the approved "PLANO DE INÍCIO DA CORRIDA" layout.
- Replaced the red-flag restart decision presentation with a modal matching the approved "BANDEIRA VERMELHA / RELARGADA" layout.
- Preserved existing plan generation, tyre-lap rules, manager posture rules, rain/manual behavior, and race engine logic.
- Preserved existing plan selection callbacks and manager decision actions.
- No tire-life, strategy, simulation, gap, or evolution rules were changed in V127.
