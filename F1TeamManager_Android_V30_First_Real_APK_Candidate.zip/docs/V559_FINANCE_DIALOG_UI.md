# V559 — Organização visual do controle financeiro

## Mudanças
- O diálogo financeiro usa uma única `LazyColumn` para a tela inteira, incluindo cabeçalho, resumo, categorias, lançamentos semanais e movimentações sem semana/GP. Isso permite rolagem vertical contínua em todo o conteúdo.
- Cada categoria aparece em um card individual.
- Categorias com entradas aparecem na seção RECEITAS; categorias com saídas aparecem na seção DESPESAS. Categorias com os dois tipos podem aparecer nas duas seções com o valor correspondente.
- Os cards mostram categoria, quantidade de lançamentos e valor monetário destacado.
- Mantidos o histórico, as 56 semanas, as movimentações sem semana identificada e os registros de GP.

## Arquivo alterado
`app/src/main/java/com/f1teammanager/MainActivity.kt`

## Validação
- Alteração estrutural conferida no código-fonte.
- ZIP de saída será validado por integridade.
- Compilação Gradle/Android e teste em dispositivo não executados nesta sessão.
