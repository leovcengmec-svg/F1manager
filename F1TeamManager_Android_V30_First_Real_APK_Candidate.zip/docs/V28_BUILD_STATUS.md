# V29 — APK GitHub Build Candidate

## Objetivo
Primeiro pacote Android organizado para ser colocado no GitHub e compilado pelo GitHub Actions.

## Estrutura
- Android app real em `app/`
- Jetpack Compose
- Manifest + recursos Android
- 42 arquivos Kotlin no núcleo/app original da V27
- Workflow em `.github/workflows/main.yml`
- AGP 9.3.1
- Gradle 9.5.0 via GitHub Actions
- JDK 17
- compileSdk/targetSdk 37
- Build Tools 36.0.0

## Validação local possível neste ambiente
- Núcleo Kotlin: PASS com kotlinc.
- Estrutura Gradle: revisada estaticamente.
- APK: NÃO alegado como compilado localmente, porque este ambiente não possui Android SDK/Gradle.

## Artifact esperado
`app/build/outputs/apk/debug/app-debug.apk`

## Teste físico após o GitHub Actions
1. Baixar o artifact.
2. Instalar no Android/POCO X7 Pro.
3. Abrir o app.
4. Criar carreira.
5. Selecionar Ferrari e verificar SF-26.
6. Selecionar McLaren e verificar MCL40.
7. Navegar Home → Equipe → Carro → Temporada → Fim de Semana.
