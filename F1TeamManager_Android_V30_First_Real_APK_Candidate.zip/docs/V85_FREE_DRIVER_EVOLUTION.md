# V85 — Evolução dos 20 pilotos livres

## Regra
A cada temporada o motor recalcula os pilotos efetivamente contratados e reconhece os demais como pilotos livres.

- 80 pilotos ativos por temporada.
- 20 pilotos livres por temporada.
- A lista é derivada dos contratos `activeIn(season)`, portanto contratos futuros não tornam um piloto ativo antecipadamente.
- Os 20 livres continuam evoluindo mesmo sem participar do campeonato.
- A evolução dos livres usa **70% da taxa natural** da sua classe/tipo de evolução.
- Não há avaliação de desempenho de corrida para piloto livre.
- O mesmo ciclo de carreira (GROWING / REGRESSION / RECOVERY) continua válido.
- Os 20 livres não recebem metas competitivas de equipe; permanecem com meta 80 apenas como fallback da estrutura de metas.

## Correção realizada
O V84 já armazenava os 100 pilotos, mas `applyDriverEvolution()` só acumulava evolução para os 80 pilotos ativos. Os 20 livres eram persistidos, porém não recebiam avanço.

No V85 o fluxo foi corrigido na raiz:
1. identifica os 80 contratos ativos da temporada;
2. deriva exatamente os 20 IDs livres;
3. valida 80 + 20 = 100;
4. aplica evolução aos ativos usando a avaliação de desempenho;
5. aplica aos livres 70% da evolução natural;
6. mantém banco fracionário e ganhos anuais dos livres;
7. preserva a mesma lógica de teto/regressão/recuperação.

## Validação
`FreeDriverEvolutionV84Test` atualizado para `FreeDriverEvolutionV85Test`:
- 100 pilotos;
- 80 ativos;
- 20 livres;
- após uma temporada de 30 GPs, **20/20 livres apresentaram evolução**;
- taxa configurada: 70% da evolução natural.
