# V9 — Driver Market + Contracts + AI Transfers

## Objetivo
Conectar o Manager a um mercado persistente de pilotos, contratos, renovações, ofertas e movimentações de pré-temporada.

## Regras implementadas
- Cada um dos 80 pilotos ativos começa com exatamente um contrato.
- Um piloto não pode possuir dois contratos ativos.
- Uma equipe não pode ultrapassar dois pilotos.
- Oferta considera salário, força da equipe, reputação, duração restante e aleatoriedade determinística.
- Contratos possuem duração, salário e (REMOVIDO) multa contratual.
- Renovações substituem o contrato existente sem duplicá-lo.
- Pilotos liberados entram no mercado livre.
- IA resolve contratos expirados e preenche vagas na offseason.
- Grid do próximo ano é materializado no DriverMarketState.

## Limitação consciente
A V9 não substitui ainda `WorldDatabase.drivers` durante uma corrida. O mercado já possui o estado persistente do grid futuro; a integração do grid dinâmico ao RaceWeekendEngine fica para o bloco de integração seguinte.


## Regra atualizada
- Contratos: 1 a 5 anos.
- Propostas externas: somente no último ano do contrato (1/1, 2/2, 3/3, 4/4, 5/5).
- Multa/buyout contratual: removido integralmente.
- Transferências: somente para a temporada seguinte.
- Propostas: validade de 1 semana do jogo.
- Scouting: validade de 4 semanas.
