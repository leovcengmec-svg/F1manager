# V9 — Driver Market + Contracts + AI Transfers

## Objetivo
Conectar o Manager a um mercado persistente de pilotos, contratos, renovações, ofertas e movimentações de pré-temporada.

## Regras implementadas
- Cada um dos 80 pilotos ativos começa com exatamente um contrato.
- Um piloto não pode possuir dois contratos ativos.
- Uma equipe não pode ultrapassar dois pilotos.
- Oferta considera salário, força da equipe, reputação, duração restante e aleatoriedade determinística.
- Contratos possuem duração, salário e buyout.
- Renovações substituem o contrato existente sem duplicá-lo.
- Pilotos liberados entram no mercado livre.
- IA resolve contratos expirados e preenche vagas na offseason.
- Grid do próximo ano é materializado no DriverMarketState.

## Limitação consciente
A V9 não substitui ainda `WorldDatabase.drivers` durante uma corrida. O mercado já possui o estado persistente do grid futuro; a integração do grid dinâmico ao RaceWeekendEngine fica para o bloco de integração seguinte.
