# V139 — Central de Equipes / Histórico de Equipes

- Nova entrada **EQUIPES** na Central de Gestão, imediatamente abaixo de **FIM DE SEMANA**.
- Interface vertical com rolagem.
- Todas as 40 equipes são exibidas por navegação com setas esquerda/direita.
- Ordem dinâmica por força atual do carro, usando a média dos 6 componentes dos dois carros.
- A força do jogador usa o garage físico persistido; as demais equipes usam a simulação financeira/técnica atual da IA para refletir a evolução até a semana corrente.
- Troca de equipe atualiza logo, nome, país, posição, pontos, orçamento, instalações, pilotos, atributos dos dois carros, desempenho da temporada e histórico.
- Tela é apenas de consulta; trocar a equipe visualizada não troca a equipe do jogador.
- Layout sem imagem de carro: apenas logo, informações e ícones/indicadores nativos.
- Instalações refletem as sete instalações existentes no modelo: Fábrica, P&D, Túnel de Vento, Simulador, Scouting, Desenvolvimento de Pilotos e Centro Comercial.
- Histórico utiliza os registros reais de construtores e corridas já persistidos.
