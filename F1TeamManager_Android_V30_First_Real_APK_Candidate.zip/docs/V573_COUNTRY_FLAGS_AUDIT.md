# Auditoria V573 — Espanha e Paraguai

## Correção
- `ExternalAssets.normalizeCountryKey` agora resolve `Espanha` e `Spain` para `es`.
- `Paraguai` e `Paraguay` resolvem para `py`.
- Os candidatos de arquivo incluem códigos ISO-2/ISO-3, nomes em português e inglês e prefixos `flag_`/`flags_`.
- A lista `known` de `DriverFlag` foi atualizada para não impedir a solicitação destas bandeiras.

## Validação executada
- Verificado por inspeção estática que os aliases estão nos dois pontos necessários (normalização e lista de aliases).
- Verificada atualização para `versionCode 573` / `versionName 0.573.0`.
- ZIP testado com `unzip -t` após empacotamento.

A compilação Android e o teste visual no aparelho não foram executados nesta sessão.
