# V37.1 — Estratégia, Pneus, ERS e DRS

## Estratégia do piloto
- Ataque: mais pneu + combustível, menor tempo de volta (-ms).
- Equilibrado: consumo normal, sem bônus/penalidade de estratégia.
- Defesa: economiza pneu + combustível, maior tempo de volta (+ms).

## ERS
ERS é independente da estratégia. A bateria elétrica é usada automaticamente para reduzir o tempo da volta quando há carga disponível. Quando a bateria está baixa, o deploy para e a bateria recarrega.

## DRS
DRS é independente da estratégia. Só ativa quando o carro está a no máximo 1,000 s do carro imediatamente à frente e reduz o tempo da volta.

## Pneus
- Soft: seco = desgaste alto / mais velocidade; chuva = menos velocidade.
- Medium: seco = desgaste normal / mais velocidade; chuva = menos velocidade.
- Hard: seco = desgaste lento / sem ganho de velocidade; chuva = menos velocidade.
- Intermediário: seco = desgaste alto / muito mais lento; chuva fraca/média = desgaste normal / mais velocidade; chuva forte = desgaste normal / velocidade normal.
- Wet: seco = desgaste alto / muito mais lento; chuva fraca/média = desgaste normal / velocidade normal; chuva forte = desgaste lento / mais velocidade.

Todos os ganhos de velocidade são representados como redução do tempo da volta em milissegundos (-ms). Penalidades aumentam o tempo (+ms).
