# Auditoria V572 — Fotos de Heikki Kovalainen e Bruce McLaren

## Correção
A resolução dos dois pilotos protegidos agora é baseada na identidade canônica, não apenas no nome/ID recebido. Nomes que contenham `Kovalainen` são tratados como Heikki Kovalainen, incluindo o typo `Heik Kovalainen`; Bruce McLaren é identificado pelos termos `Bruce` + `McLaren`, ou pelo ID permanente 66. Heikki também é reconhecido pelo ID permanente 57.

Para essas identidades, o carregador não tenta arquivos numéricos nem aliases de outros pilotos. Procura `Heikki Kovalainen.png` / `driver_Heikki Kovalainen.png` ou `Bruce McLaren.png` / `driver_Bruce McLaren.png` em `Pictures/F1Manager/Assets/drivers/`, com normalização de maiúsculas e espaços.

## Limite importante
Se o próprio arquivo com o nome canônico contém a foto errada, o código não consegue corrigir o conteúdo da imagem. Nesse caso, o arquivo externo precisa ser substituído pela foto correta. A compilação Android e a validação visual no aparelho não foram executadas.
