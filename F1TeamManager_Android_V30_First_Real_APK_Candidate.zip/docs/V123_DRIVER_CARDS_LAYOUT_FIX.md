# V123 — Driver Cards Layout Fix

Based on V122.

- Preserves exactly seven driver attributes: VEL, QUAL, ULTR, DEF, CONS, CHUVA, PNEU.
- Increases season-stat rows from 58dp to 64dp.
- Increases bottom evolution panels from 78dp to 108dp.
- Reserves vertical space for evolution labels and values.
- Allows long season-stat labels to wrap to two lines without clipping.
- No EXP attribute introduced.
