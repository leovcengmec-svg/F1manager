import com.f1teammanager.core.manager.*
import com.f1teammanager.core.season.*

fun main() {
    val marketEngine = DriverMarketEngine(123)
    var market = marketEngine.initialState(2026)
    val target = market.contracts.first { it.teamId == 1 }
    val seat = market.contracts.first { it.teamId == 40 }
    // Simulate the resolved offseason swap while preserving the 80-seat grid.
    market = market.copy(contracts = market.contracts.map { deal ->
        when (deal.driverId) {
            target.driverId -> deal.copy(teamId = 40, seasonSigned = 2027)
            seat.driverId -> deal.copy(teamId = 1, seasonSigned = 2027)
            else -> deal
        }
    }).normalized()
    check(market.contracts.size == 80)
    check(market.contracts.count { it.teamId == 1 } == 2)
    check(market.contracts.count { it.teamId == 40 } == 2)


    val grid = DynamicGridEngine()
    check(grid.validate(market).isEmpty())
    val participants = grid.participants(market)
    check(participants.size == 80)
    check(participants.count { it.teamId == 40 && it.driverId == target.driverId } == 1)
    check(participants.count { it.teamId == 40 } == 2)
    check(participants.none { it.driverId == target.driverId && it.teamId == 1 })

    val manager = TeamManagerState(
        season=2026, round=1, playerTeamId=1,
        car=TeamCarState(95,94,93,92),
        finance=TeamFinanceState(100_000_000),
        driverMarket=market
    )
    val season = SeasonState()
    val engine = ManagerSeasonEngine(12345)
    check(engine.validateGrid(manager).isEmpty())
    val outcome = engine.runRound(manager, season)
    check(outcome.race.classification.size == 80)
    check(outcome.race.classification.any { it.driverId == target.driverId && it.teamName == "Rodin Motorsport" })
    println("V10 DYNAMIC GRID SMOKE TEST OK")
}
