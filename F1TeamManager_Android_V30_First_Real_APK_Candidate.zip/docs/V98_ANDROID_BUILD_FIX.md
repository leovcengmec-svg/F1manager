# V98 — Android UI build-chain correction

- Fixed an extra closing brace in MainActivity Team composable.
- Added the local FactoryEngine instance required by the Car composable.
- Removed invalid nested `item {}` calls inside `items {}` blocks for active research, completed designs, and inventory.
- Preserved the canonical P&D → Design → Factory → physical piece → garage chain.
- Core Kotlin compilation: PASS.
- versionCode 98 / versionName 0.98.0.
