# V26 — primeiro candidato a teste APK

## Objetivo

Esta versão fecha a transição do protótipo HTML para o projeto Android nativo (Jetpack Compose) e prepara a primeira compilação instalável.

## Correção importante de dados

O modelo do carro agora vem de `CarCatalog.forTeam(teamId)`. A interface não usa mais um modelo Ferrari como valor universal.

Exemplos:
- Ferrari → SF-26
- McLaren → MCL40
- Mercedes → W17
- Red Bull Racing → RB22
- Williams → FW48
- Aston Martin → AMR26
- Audi → R26

As demais equipes também têm identificadores de chassis próprios no catálogo do jogo.

## Build

O projeto está configurado para Android API 37, minSdk 26 e targetSdk 37.

O ambiente desta entrega não possui Android SDK/Gradle executáveis, então **nenhum APK foi declarado como compilado**. O projeto é o candidato de primeiro APK para abrir no Android Studio/ambiente Android com SDK instalado.

Com o ambiente Android configurado, executar:

```bash
./gradlew :app:assembleDebug
```

Saída esperada:

`app/build/outputs/apk/debug/app-debug.apk`

## Critério do primeiro teste

1. Instalar APK.
2. Abrir F1 Team Manager.
3. Criar carreira.
4. Escolher Ferrari e verificar SF-26.
5. Voltar e criar carreira com outra equipe e verificar que o modelo muda.
6. Abrir Fim de Semana.
7. Rodar qualificação.
8. Escolher postura/pneu.
9. Entrar na corrida.
10. Avançar voltas e responder eventos estratégicos.

As imagens reais de carros/equipes/pilotos continuam sendo uma camada de assets local futura; os slots da interface não devem fingir que imagens fictícias são assets reais.
