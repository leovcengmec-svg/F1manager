# Taxa de assinatura — Mercado de Pilotos

Regras oficiais:
- Renovação do próprio piloto: 50% do valor de mercado.
- Tirar piloto de outra equipe: 70% do valor de mercado.
- Contratar piloto livre: 30% do valor de mercado.

A taxa é calculada no momento em que o contrato é fechado e descontada imediatamente.
O salário anual não faz parte da taxa e é cobrado apenas no início da temporada de vigência.
Não existe buyout, multa ou taxa de rescisão.
