# V57 — Países dos pilotos e equipes

Os cadastros raiz de equipes e pilotos agora possuem o campo `country`, preenchido com o nome correto do país.

O campo existe exclusivamente como base de dados para a futura associação com o repositório local de bandeiras. Não há nova tela ou sistema de nacionalidade.

- 40 equipes cadastradas.
- 100 pilotos cadastrados.
- Países armazenados em português e de forma centralizada.
- Nenhuma regra de gameplay foi alterada.
