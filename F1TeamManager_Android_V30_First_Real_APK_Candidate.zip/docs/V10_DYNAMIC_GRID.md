# V10 — Dynamic Grid Integration

V10 closes the loop between the V9 driver market and the race engine.

## Source of truth

`DriverMarketState.contracts` is now the source of truth for team assignments during Manager races. `WorldDatabase` continues to provide immutable driver attributes and team base data.

## Flow

`contracts -> dynamic grid -> RaceParticipant -> qualifying -> race -> championship`

A driver transferred during the offseason therefore races for the new team in the following season. The player team's two current contracts determine which two drivers receive the player's car attributes.

## Integrity

The grid validator requires exactly 80 unique known drivers and no team with more than two drivers. The manager exposes `currentGrid()` and `validateGrid()` for UI/tests.

## Scope

This does not yet add a visual Android grid screen. It is the domain integration layer required before UI work.
