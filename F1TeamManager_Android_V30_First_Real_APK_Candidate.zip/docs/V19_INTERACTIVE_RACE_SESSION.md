# V19 — Interactive Race Session

Transforma a corrida em uma sessão interativa por passos. Quando surge um evento que exige decisão, o motor entra em `PAUSED_FOR_MANAGER_DECISION`.

Decisões suportadas:
- VSC: BOX / MANTER / ESTENDER.
- Safety Car: BOX / MANTER / ESTENDER.
- Red Flag: RESTART_SOFT / RESTART_MEDIUM / RESTART_HARD, cada um com ATAQUE/EQUILIBRADO/DEFESA.
- Alertas críticos: PIT_NOW / MANTER.
