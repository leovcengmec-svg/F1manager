# V54 — Mercado de pilotos: ciclo de negociação 2–3 semanas

## Regra oficial
1. A equipe envia uma proposta.
2. O piloto aguarda 2 ou 3 semanas de calendário e então responde.
3. A resposta pode ser: aceite, recusa ou contraproposta.
4. Se houver contraproposta, a equipe proponente decide: aceitar, recusar ou apresentar outra contraproposta.
5. Uma nova contraproposta inicia outro prazo de 2 ou 3 semanas para o piloto responder.
6. O ciclo pode ocorrer mais uma vez. Na terceira resposta do piloto, uma eventual contraproposta encerra a negociação para decisão final da equipe: aceitar ou recusar.

## Integridade
- Cada piloto pode ter somente uma negociação ativa para a próxima temporada.
- Uma contratação aceita remove outras propostas pendentes para o mesmo piloto.
- O estado persistido agora registra `proposerTeamId`.
- Dados antigos sem esse campo são carregados com compatibilidade (`0`) e não quebram a carreira.
- Respostas são registradas como `RESPOSTA DO PILOTO` na Central de Notícias.
- Decisões automáticas de equipes IA são registradas como `DECISÃO DA EQUIPE`.

## P&D
Quando um projeto do jogador termina durante o avanço do calendário, é criada a notificação `P&D CONCLUÍDO` com componente e ganho obtido. A Home mostra um indicador enquanto essa notificação não foi lida.
