# V23 — Core Freeze / Interface Contract

Objetivo: fechar o núcleo jogável antes da implementação visual definitiva.

## Fonte única de estado
`UnifiedGameEngine` passa a ser a fachada oficial para:
- carreira/temporada;
- calendário e classificação;
- equipe do jogador;
- carro e P&D;
- finanças;
- mercado/contratos já existentes;
- fim de semana de corrida interativo;
- decisões de VSC, Safety Car, Red Flag, combustível e pneus.

A UI futura não deve chamar diretamente motores internos para alterar estado. Ela deve ler `InterfaceSnapshot` e disparar ações da fachada.

## Fluxo oficial
1. Home/Resumo
2. Calendário
3. Preparação do GP
4. Qualificação
5. Estratégia dos dois pilotos
6. Corrida
7. Pausa para decisão quando necessário
8. Resultado
9. Pontos/finanças/P&D/progresso de temporada
10. Próximo GP

## Regras preservadas
- 40 equipes / 80 pilotos no grid de corrida.
- Sem TL1/TL2/TL3.
- DRS e ERS são automáticos pelo piloto.
- Gestor controla estratégia, pneus e pit stop.
- Red Flag exige pneu + postura.
- Pontuação oficial interna 1–60 conforme `ChampionshipEngine`.
- Imagens reais continuam fora do núcleo: serão assets locais/offline na camada visual.

## Persistência
`GameSave` define o formato V23 para saves entre corridas. Uma corrida em andamento não é serializada nesta etapa; o save deve ser feito entre GPs.

## O que fica pronto para a interface
`InterfaceSnapshot` fornece cards de:
- calendário;
- standings;
- finanças;
- carro/P&D;
- pilotos;
- corrida/decisão;
- mensagens.

## Validação
O smoke test V23 deve verificar:
- grid íntegro;
- início de GP;
- estratégia dos dois pilotos;
- corrida com decisão;
- finalização;
- pontos e finanças aplicados uma única vez;
- avanço de rodada;
- save V23.
