# V80 — Unidade elétrica

## Função
A Unidade elétrica atua exclusivamente sobre o ERS: aproveitamento da energia recuperada, reserva útil e entrega de potência do ERS.

## 10 níveis
N1 70%, N2 74%, N3 78%, N4 82%, N5 86%, N6 90%, N7 94%, N8 98%, N9 104%, N10 110%.

Freios determinam a recuperação; a Unidade elétrica determina o aproveitamento/entrega. Não altera diretamente o tempo médio do GP, DRS, defesa ou pneus.
