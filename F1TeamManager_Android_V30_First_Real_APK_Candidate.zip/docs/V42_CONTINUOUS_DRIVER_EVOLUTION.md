# V42 — Evolução contínua dos pilotos

A evolução dos pilotos deixou de ser aplicada somente no encerramento da temporada.

## Regra oficial

- O relógio do jogo continua sendo semanal.
- A evolução é processada durante a temporada, após cada GP concluído.
- O GP 30 apenas encerra/arquiva a temporada; não existe uma segunda aplicação de evolução.
- Cada piloto mantém Classe e Tipo de Evolução fixos.
- Os limites anuais continuam valendo como orçamento acumulado:
  - Prodígio +8
  - Auge rápido +7
  - Auge moderado +6
  - Auge tardio +6
  - Normal +5
  - Demorado +4
- O progresso fracionário é acumulado entre GPs para evitar saltos artificiais de +1 em toda corrida.
- Regressão também ocorre durante a temporada e possui orçamento anual de magnitude equivalente.
- O teto absoluto da Classe continua sendo respeitado.
- A avaliação usa uma janela recente de até 3 GPs, com corrida, classificação, pontos e comparação com companheiro.

## Exemplo

Um piloto pode evoluir assim durante uma temporada:

83 → 83 → 84 → 84 → 85 → 84 → 86

Não é necessário esperar o GP 30 para que os atributos mudem.
