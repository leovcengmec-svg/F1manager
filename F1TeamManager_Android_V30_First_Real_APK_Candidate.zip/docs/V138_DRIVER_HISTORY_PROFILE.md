# V138 — Perfil / Histórico do Piloto

## Objetivo
Criar uma interface de perfil histórico de piloto que não aparece como item de navegação. Ela é aberta diretamente ao tocar na foto de um piloto.

## Entradas
- Foto do piloto titular na interface EQUIPE.
- Foto do piloto na interface MERCADO DE PILOTOS.

## Layout
- Cabeçalho de piloto com foto, nome, nacionalidade, equipe, classe, evolução, Overall e dados de contrato quando existentes.
- Bloco ATRIBUTOS DO PILOTO com os 7 atributos oficiais.
- Bloco DESEMPENHO GERAL com títulos, vitórias, pódios, poles, melhores voltas, corridas e DNF.
- Bloco DESEMPENHO NA TEMPORADA com dados reais da temporada atual.
- Bloco HISTÓRICO POR TEMPORADA usando o arquivo histórico persistido.
- Sem abas Visão Geral / Temporada / Histórico / Contrato.
- Sem criação de campos de piloto que não existam no modelo atual.

## Fluxo
- Ao tocar na foto da EQUIPE, abre o perfil e o botão voltar retorna para EQUIPE.
- Ao tocar na foto do MERCADO, abre o perfil e o botão voltar retorna para MERCADO.
- O perfil não altera contratos, atributos, mercado ou qualquer estado esportivo.
