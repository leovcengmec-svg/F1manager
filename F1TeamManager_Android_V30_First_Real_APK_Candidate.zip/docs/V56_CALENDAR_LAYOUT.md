# V56 — Layout do Calendário

Atualização exclusivamente visual do calendário Android, aplicada sobre a V55 oficial.

## Regras visuais
- Margens laterais de 16dp e espaçamento vertical consistente.
- Cabeçalho de temporada com 30 GP, 56 semanas e 26 semanas livres.
- Card da semana atual com borda vermelha, destaque de temporada e ações em botões arredondados.
- Semanas livres em cards compactos com ícone de calendário e hierarquia P&D.
- Semanas de GP com faixa lateral vermelha, imagem local do GP, round/data, nome, circuito, voltas e acesso a resultados.
- Nenhuma regra de calendário, P&D, resultados ou navegação foi removida.
