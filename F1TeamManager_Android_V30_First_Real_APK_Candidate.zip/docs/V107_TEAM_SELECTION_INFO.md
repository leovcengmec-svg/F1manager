# V107 — Informações da seleção de equipe

A tela de escolha de equipe mantém a estrutura visual do V106. A atualização é exclusivamente informacional no conteúdo dos indicadores do card:

- Overall físico inicial da equipe;
- Confiabilidade física inicial;
- Piloto 1 com OVR;
- Piloto 2 com OVR.

Os pilotos são obtidos pelos `driverIds` da própria `TeamDefinition` e o OVR é calculado a partir dos ratings cadastrados no `WorldDatabase`. Nenhuma regra de corrida, calendário, P&D, fábrica, estoque ou mercado foi alterada.
