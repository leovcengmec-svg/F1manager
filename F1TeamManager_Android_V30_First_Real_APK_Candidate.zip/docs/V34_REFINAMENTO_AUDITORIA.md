# V34 — Refinamento após teste real

## Auditoria das ideias vs. app

- Campeonato: 80 pilotos / 40 equipes.
- Mercado: 100 pilotos, sendo 80 titulares + 20 nomes de mercado/reserva.
- Corrida: avanço automático de voltas, pausa em decisões e classificação ao vivo completa.
- Pneus: Soft/Medium/Hard têm grip e degradação diferentes.
- Combustível: consumo depende da postura; alerta baixo/crítico; opção explícita de poupar combustível.
- Consequência: ignorar condição crítica pode levar a perda de desempenho e DNF.
- DRS/ERS: execução automática do piloto; o manager apenas observa os indicadores.
- Pontos: resultado mostra pontos conquistados e o ledger existente continua usando SharedPreferences.
- Navegação: botão voltar preserva a sessão em memória e a Home passa a mostrar “RETOMAR PIT WALL” quando há corrida em andamento.
- Funções: menu de gestão centraliza Pilotos, Mercado, Carro/P&D, Campeonato, Calendário, Finanças e Fim de semana.
- Contraste: ações principais usam vermelho com texto branco.

## Testes

O núcleo Kotlin foi compilado localmente e o smoke V34 verifica 40 equipes, 80 pilotos de corrida, 100 pilotos no mercado, classificação completa, pneus e estado ERS.

A compilação física do APK continua sendo responsabilidade do workflow GitHub Actions, pois este ambiente não possui o Android SDK/Gradle do projeto.
