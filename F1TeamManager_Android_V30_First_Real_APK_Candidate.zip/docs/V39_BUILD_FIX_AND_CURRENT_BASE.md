# V39 — Build fix / versão atual

Esta atualização é construída sobre a versão imediatamente anterior do projeto.

## Correções
- Restaurados os composables `SectionTitle` e `StatCard` usados pelo Dashboard.
- Mantida a ordem de seleção de equipes do melhor carro para o pior.
- Mantidos os 5 espaços de patrocínio, com contratos por número de corridas e duração de 1 a 10 corridas.
- Mantida a liberação do espaço ao término do contrato.
- Mantida a formatação financeira em milhões/mil.
- O botão `BOX` não abre mais uma segunda tela para escolha manual de pneu: o composto é definido automaticamente conforme clima/estratégia.
- Evitada largada com pneu de seco quando a condição de corrida já for de chuva.
- Mantidos o clima com persistência e o desgaste de pneus baseado em `targetLaps`.
- Mantido o campeonato com abas de pilotos e construtores.

## Validação
- Núcleo Kotlin compilado com `kotlinc`: sem erros; apenas warnings não críticos existentes.
- O APK completo depende do Gradle/Android SDK do GitHub Actions. Esta máquina não possui o Gradle wrapper/Gradle Android configurado, portanto não é declarado como APK compilado localmente.
- ZIP validado com `unzip -t`.
