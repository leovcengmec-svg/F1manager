# V30 — First Android Build Candidate

This version is the first candidate intended to be compiled by GitHub Actions into a real debug APK.

## Native scope
- Jetpack Compose interface with multiple management screens.
- Unified game/race core retained from V23-V29.
- Team-specific car catalog.
- Offline asset catalogs for 40 teams, 52 driver records and 24 circuits.
- Real team logos and driver photos are explicitly marked as required/deferred; no fake photos are presented as real.
- GitHub Actions build is the authoritative Android build environment for this repository.

## Build matrix
- Android Gradle Plugin 9.3.1
- Gradle 9.5.0
- JDK 17
- compileSdk/targetSdk 37
- Build Tools 36.0.0

AGP 9.3 supports API 37 and requires Gradle 9.5 and JDK 17. See Android Developers release notes.

## First physical test
1. Upload the V30 ZIP to GitHub.
2. Put `main.yml` in `.github/workflows/main.yml`.
3. Run the workflow.
4. Download `F1TeamManager-debug-apk-v30`.
5. Install on the POCO X7 Pro.
6. Verify Home, team selection, Ferrari/SF-26, McLaren/MCL40, Car, Calendar, Standings, Weekend, Qualifying and Race screens.
