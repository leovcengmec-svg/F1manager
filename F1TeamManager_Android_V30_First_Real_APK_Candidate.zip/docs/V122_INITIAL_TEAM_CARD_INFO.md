# V122 — Initial Team Card Information

## Correção
- Mantido o layout aprovado da seleção inicial de equipe.
- Área de métricas recebeu altura explícita para impedir corte vertical.
- Informações exibidas: Overall, Confiabilidade, Piloto 1 e Piloto 2.
- Valores permanecem derivados dos dados reais de `InitialTeamProfile` e `WorldDatabase`.
- Botão ESCOLHER e regra de seleção não foram alterados.
