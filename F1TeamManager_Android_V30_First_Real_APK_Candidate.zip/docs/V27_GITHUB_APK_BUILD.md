# V27 — GitHub APK Build

Objetivo: primeiro build Android reproduzível no GitHub Actions.

## Workflow

O arquivo `.github/workflows/main.yml` executa:

1. checkout;
2. JDK 17;
3. Gradle 9.5.0;
4. Android SDK API 37 + Build Tools 36.0.0;
5. `gradle :app:assembleDebug`;
6. validação física do `app-debug.apk`;
7. upload do APK como artefato `F1TeamManager-debug-apk`.

O workflow usa Gradle instalado pelo `gradle/actions/setup-gradle` porque esta entrega ainda não depende de um Gradle Wrapper local.

## Resultado esperado

`app/build/outputs/apk/debug/app-debug.apk`

Este arquivo só deve ser chamado de APK pronto quando a execução do GitHub Actions terminar com sucesso e o artefato existir.
