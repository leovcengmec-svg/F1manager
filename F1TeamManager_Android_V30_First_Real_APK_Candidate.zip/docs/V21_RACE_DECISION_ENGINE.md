# V21 — Race Decision Engine

V21 moves the V18/V19/V20 decision rules into a pure Kotlin state machine.

## Responsibilities
- Driver: DRS/ERS execution remains automatic and outside manager decisions.
- Manager: posture, tyres, pit action and red-flag restart configuration.
- Engine: fuel, tyre wear, event generation, pause/resume and consequences.

## Events
- Fuel low
- Tyre degradation
- VSC
- Safety Car
- Red Flag

## Validation
`V21RaceDecisionEngineTest.kt` exercises VSC → BOX, Safety Car → MAINTAIN, degradation/fuel → EXTEND, Red Flag → restart tyre/posture, and full-race completion.
