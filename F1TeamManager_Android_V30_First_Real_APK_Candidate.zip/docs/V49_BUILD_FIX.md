# V49 — Correção de compilação após limpeza arquitetural

## Correções
- Restaurados os imports necessários de `FinanceEngine` e `TeamManagerState` em `CareerPreferences`.
- Restaurado o acesso explícito a `FinancialSeasonClosureEngine` em `MainActivity`.
- Corrigido o armazenamento das notícias lidas para usar uma lista antes de `takeLast`, evitando incompatibilidade de tipo da coleção.
- `Home` deixou de depender da função local `unreadNewsCount()` que pertencia ao escopo de `MainActivity`; a contagem de notícias não lidas agora é calculada no próprio `Home` a partir do estado recebido.
- Nenhum motor legado foi reintroduzido.

## Preservado
- Arquitetura V47 consolidada.
- Redução anual de carro em 70%.
- Penalidade financeira adicional de -20% nos seis componentes.
- Fluxo de temporada, mercado, evolução, P&D, patrocínios, finanças e premiação.
- Assets reais continuam fora desta etapa.
