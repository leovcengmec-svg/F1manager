# V128 — Pit Wall Layout Update

Base: V127.

UI-only update requested by user:
- Race screen header uses the current Grand Prix name instead of "PIT WALL".
- Race content scrolls freely vertically; no fixed-height classification viewport.
- Pause/Resume control moved to the top race header.
- Live classification columns: POS | EQUIPE | CARRO | PILOTO | PNEU | GAP.
- Team shield appears before the car visual in live classification.
- Compact team-car visual added to player cards and live classification.
- No change to race strategy logic, tyre life, plan generation, Manager attack/balanced/defense rules, weather/manual rules, GAP engine, or other game systems.
