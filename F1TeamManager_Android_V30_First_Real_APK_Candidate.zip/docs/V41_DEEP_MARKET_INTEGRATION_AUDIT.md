# V41 — Deep Etapa 3 Integration Audit

Correções realizadas antes do teste do usuário:
- Renovação não substitui mais o contrato vigente; cria decisão/contrato futuro para a próxima temporada.
- Metas de temporada usam o elenco ativo do DriverMarketState, incluindo pilotos 81–100 quando contratados.
- Evolução Stage 1 avalia os 100 pilotos que possuem registros na temporada, não apenas os 80 do banco legado.
- Campeonato no UnifiedGameEngine usa o elenco atual do mercado e a equipe do contrato atual.
- Pontuação de construtores e histórico usam a equipe efetiva do mercado, com fallback legado apenas para saves antigos.
- RaceHistory grava o teamId efetivo quando disponível, preservando compatibilidade com registros antigos.
- Scouting usa a temporada informada e validade de 4 semanas (semana criada até semana +3).
- UI de scouting corrigida de dias para semanas.
- Compilação do núcleo Kotlin passou sem erros.
