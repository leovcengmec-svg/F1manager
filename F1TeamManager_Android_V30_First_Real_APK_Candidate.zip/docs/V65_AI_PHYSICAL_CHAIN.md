# V65 — IA: cadeia P&D → Fábrica → Peça física → Carro

## Objetivo
Migrar o desenvolvimento das equipes controladas pela IA para a mesma lógica física aprovada para o jogador.

## Cadeia
1. P&D escolhe um componente e cria um projeto.
2. O projeto termina e vira um design tecnológico.
3. A Fábrica recebe o design e produz 1 ou 2 peças físicas.
4. As peças entram no estoque da equipe.
5. A IA instala a peça fisicamente no Carro 1 ou Carro 2.
6. O desempenho da corrida usa o carro físico daquele piloto.

## Regras
- Se apenas uma unidade for fabricada, apenas um carro recebe a atualização.
- Dois pilotos da mesma equipe podem ter Overalls diferentes.
- Nenhum carro é alterado diretamente pelo P&D.
- Os seis componentes oficiais permanecem: Motor, Chassi, Asa dianteira, Asa traseira, Freios e Unidade de potência elétrica.
- O TeamCarState permanece somente como ponte de compatibilidade para sistemas legados.

## Validação
O núcleo Kotlin foi compilado com sucesso. Permaneceram apenas warnings preexistentes/não críticos.
