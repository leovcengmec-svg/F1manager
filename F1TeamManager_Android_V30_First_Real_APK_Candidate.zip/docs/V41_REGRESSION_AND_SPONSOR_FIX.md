# V41 — REGRESSÃO, BOX, CAMPEONATO, CLIMA, PNEUS E PATROCÍNIOS

Correção feita sobre `F1TeamManager_Android_V30_First_Real_APK_Candidate.zip` sem remover funções que já existiam.

## Home / calendário
- Restaurados os controles `PULAR 1 SEMANA` e `PULAR ATÉ PRÓXIMO GP` na Home.
- Mantido o calendário completo com os mesmos controles.
- Após uma corrida concluída, o fluxo termina em `RESULTADO` e o botão leva de volta ao `CALENDÁRIO`.

## Campeonato
- Restaurado o seletor entre `PILOTOS` e `CONSTRUTORES`.
- A Home continua mostrando a posição do piloto no campeonato, e não posição da escuderia.

## Pit stop
- `BOX` não monta mais automaticamente um pneu.
- O botão abre o seletor dos cinco compostos: SOFT, MEDIUM, HARD, INTERMEDIÁRIO e WET.
- O seletor também é usado quando uma decisão pendente pede BOX.
- A troca limpa a decisão pendente somente depois que o composto é escolhido.

## Clima e pneus
- Mudanças de clima são espaçadas por pelo menos 12 voltas e limitadas a 2 mudanças por corrida.
- Regras de desgaste/desempenho permanecem separadas por composto e condição.
- Seco/sol aumenta desgaste; Hard desgasta mais lentamente; pneus de chuva degradam fortemente no seco.
- Intermediário e Wet têm desgaste normal/reduzido em chuva e penalidade forte quando usados fora da condição adequada.
- Vida do pneu usa acumulador contínuo, evitando arredondamento prematuro por volta.
- Combustível inicial foi dimensionado para a distância da corrida; o modelo não usa reabastecimento no pit.

## Motor de corrida
- A contribuição da força do carro foi aumentada em relação à influência do piloto e a variância aleatória foi reduzida.
- Um carro muito inferior não pode transformar uma sequência de sorte em vitórias repetidas.
- O piloto continua influenciando ritmo, qualificação e chuva, mas não substitui a força estrutural do carro.

## Patrocínios
- Cada contrato dura aleatoriamente de 1 a 10 GPs.
- Cada contrato usa uma única forma de pagamento base: valor na assinatura OU valor por GP.
- Bônus por pontos e metas continuam separados.
- Metas de quali/corrida são geradas de acordo com a força atual da equipe; equipes fracas não recebem metas incompatíveis como P1/P10.
- Valores são exibidos em milhões ou milhares.
- Duração e forma de pagamento são persistidas no save.
