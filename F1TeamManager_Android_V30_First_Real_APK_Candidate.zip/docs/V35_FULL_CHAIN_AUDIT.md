# V35 — Full Chain Integration Audit

## Objetivo
Unificar e validar a cadeia real do jogo em duas temporadas completas, incluindo GP30, premiação de construtores, finanças, mercado, P&D, evolução e transição de temporada.

## Correções
- A premiação de fim de temporada passou a ser aplicada no fluxo real da `MainActivity` no fechamento do GP30.
- Ranking de construtores e valor da premiação foram centralizados em `SeasonSettlementEngine`.
- `TeamFinanceState.seasonPrizesPaid` passou a ser persistido, impedindo pagamento duplicado após reabertura do aplicativo.
- O fechamento de temporada mantém o saldo disponível e zera somente os acumuladores anuais/de corrida.
- A transição da temporada preserva o marcador histórico de prêmios pagos.
- O motor principal de temporada e o fluxo real usam a mesma regra de settlement.
- Testes antigos foram atualizados para as regras atuais: 80 pilotos no grid e 30 GPs por temporada.
- Testes de temporada foram atualizados para a transição GP30 -> temporada seguinte / GP1.
- `versionCode` atualizado para 35 e `versionName` para 0.35.0.

## Auditoria executada
- `SeasonPrizeAuditTest`: PASS
- `UiSeasonSettlementAuditTest`: PASS
- `RaceCoreSmokeTest`: PASS
- `SeasonCoreSmokeTest`: PASS
- `EvolutionPerformanceCapTest`: PASS
- `FullSeasonIntegrationTest`: PASS
- `TwoSeasonChainAuditTest`: PASS

### Cadeia de 60 GPs
Resultado final: temporada 2028, GP1, 80 pilotos ativos e 100 pilotos com estado de evolução.

### Premiação
- 1º lugar: €100.000.000
- 40º lugar: €10.000.000
- 40 posições distintas
- valores estritamente decrescentes por posição
- pagamento idempotente por temporada

## Observação de build
O projeto não contém Gradle Wrapper. O workflow oficial do repositório utiliza Gradle 9.5.0 + Android SDK 36 para gerar o APK. O núcleo Kotlin foi compilado localmente integralmente e todos os testes de núcleo disponíveis passaram.
