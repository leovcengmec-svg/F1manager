# V112 — Fábrica sem estoque, instalação escolhida pelo Manager

A etapa de estoque permanece removida. A cadeia do jogador é:

P&D -> Design -> Fábrica -> peça física concluída -> escolha do Manager -> Carro 1/Carro 2.

A peça concluída não entra em estoque e não altera automaticamente nenhum carro. Ela fica apenas como `pendingInstallations`, um estado transitório que aguarda a decisão explícita do Manager.

A IA continua escolhendo automaticamente o destino porque a IA precisa tomar sua própria decisão de gestão.
