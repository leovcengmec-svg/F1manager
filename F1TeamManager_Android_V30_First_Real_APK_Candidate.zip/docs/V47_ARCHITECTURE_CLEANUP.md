# V47 — Arquitetura consolidada

## Objetivo
Eliminar caminhos duplicados/legados que permitiam que a auditoria headless e o fluxo interativo usassem autoridades diferentes.

## Autoridades atuais
- **Corrida interativa e simulação headless:** `CareerWeekendEngine`.
- **Orquestração de temporada/auditoria:** `ManagerSeasonEngine`.
- **Construção de carro:** `CarDevelopmentEngine`.
- **Continuidade de carro AI:** `AITeamDevelopmentEngine`, usando a mesma regra de 70% e a mesma penalidade financeira.
- **Fechamento financeiro/penalidade:** `FinancialSeasonClosureEngine`.
- **Premiação de construtores:** `SeasonSettlementEngine`.
- **Persistência Android:** `CareerPreferences`.

## Removidos
- `UnifiedGameEngine` e `GameSave` — caminho paralelo não utilizado pela UI.
- `CareerRaceIntegration` — wrapper redundante da corrida interativa.
- `SeasonEngine` — motor de temporada legado separado.
- `RaceWeekendV12Engine` e seu modelo exclusivo — implementação paralela; os modelos compartilhados foram preservados em `RaceControlModels`.
- `ManagerActions`, `ManagementAction`, `DriverMarketSeasonEngine` — APIs sem consumidores no fluxo atual.
- `ManagerSave`, `SaveGame`, `GameState`, `EngineContracts`, `ManagerMarket` — persistências/modelos antigos sem consumidores.
- Métodos de compatibilidade de evolução/avanço de rodada que não pertenciam mais ao fluxo oficial.
- Smoke tests históricos que dependiam dos engines removidos.

## AI — continuidade anual
A AI não volta mais para `TeamDefinition.baseCar` a cada temporada. O motor:
1. conclui o desenvolvimento da temporada anterior;
2. aplica a continuidade anual de 70%;
3. aplica a penalidade financeira da temporada anterior, quando registrada;
4. inicia o desenvolvimento da nova temporada.

## Validação V47
- Core Kotlin compilado.
- Construção anual 70%: PASS.
- Temporada completa 30 GPs: PASS.
- Cadeia de 2 temporadas / 60 GPs: PASS.
- 40 equipes / 80 ativos / 20 livres / 100 pilotos: PASS.
- Continuidade AI 2026 → 2027 → 2028: PASS.
- Patrocínios: PASS.
- Orçamento AI: PASS.
- Premiação: PASS.

As imagens reais das equipes/pilotos permanecem fora desta etapa, conforme definido para a finalização do jogo.
