# Stage 1 — Initial Driver Balance: 75% of Class Ceiling

All 100 official drivers now start the career at **75% of the maximum Overall of their fixed class**.

| Class | Ceiling | Initial Overall target |
|---|---:|---:|
| Fraco | 59 | 44 |
| Médio | 69 | 52 |
| Forte | 79 | 59 |
| Pro | 89 | 67 |
| Lenda | 100 | 75 |

The seven attributes are **not flattened to the same number**. Their original relative strengths and weaknesses are preserved by proportional normalization, then integer rounding is corrected so the seven-attribute arithmetic mean reaches the class target.

This keeps drivers differentiated from the start while preventing a driver from beginning close to his class ceiling.

The rule applies to all 100 official profiles through `DriverProfileCatalog.profile()`, so the normalized values are also used by `WorldDatabase`, career initialization and the initial race grid.

Evolution remains unchanged: the class ceiling is still absolute and the previously approved per-attribute seasonal gains (+12/+10/+8/+8/+6/+5) and ceiling redistribution remain active.
