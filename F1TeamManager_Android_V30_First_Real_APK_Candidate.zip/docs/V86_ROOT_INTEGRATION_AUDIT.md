# V86 — Unificação da cadeia física + integração das instalações + continuidade AI

Base: V85 enviada para esta correção.

## Correções

- `ManagerSeasonEngine` não usa mais `CarDevelopmentEngine.advanceWeeks()` para alterar diretamente o carro.
- Avanço semanal do motor geral usa a cadeia canônica `P&D -> Design -> Fábrica -> Peça física -> Estoque`.
- `TeamGarage` permanece como fonte de desempenho da corrida.
- Carro 1 e Carro 2 continuam independentes; a transição anual não recria dois carros a partir da média.
- `DynamicGridEngine` recebe as instalações e aplica Túnel de Vento + Simulador no desempenho efetivo da corrida.
- Continuidade AI passa o garagem físico fechado da temporada anterior para a seguinte.
- Penalidade financeira de fim de temporada passa a atingir também os dois carros físicos.
- Scouting usa o nível da instalação de Scouting para controlar a precisão do relatório.
- Desenvolvimento de pilotos usa a eficiência da instalação de Desenvolvimento de Pilotos na evolução dos pilotos contratados.
- `MainActivity` foi alinhado à assinatura atual do `DynamicGridEngine.participants()`.

## Validação

- `AICarContinuityAuditTest`: PASS
- `TwoSeasonChainAuditTest`: PASS — 60 GPs, início de 2028, 80 ativos, 100 pilotos rastreados
- `PipelineIntegrationCheck`: PASS — P&D/design/fábrica/estoque/instalação/corrida + instalações

Versão interna Android: `0.86.0` / `versionCode 86`.
