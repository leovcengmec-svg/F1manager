# V123 — Unificação raiz IA x Gestor no P&D

## Regra oficial
A IA é um jogador automático. Ela não possui matemática, bônus, carteira ou fórmula de P&D exclusiva.

## Alterações
- Removido o split fixo de 50/50 da IA.
- IA agora escolhe um `ResearchFocus` entre Performance, Confiabilidade e Balanceada, como o jogador.
- Cálculo de ganhos usa a mesma regra do `ResearchEngine`:
  - Performance: 70/30
  - Confiabilidade: 30/70
  - Balanceada: 50/50
- O ganho de performance parte do valor do componente pesquisado, não do Overall médio do carro.
- O ganho de confiabilidade parte da confiabilidade atual do componente.
- Complexidade, duração, custo, melhoria máxima e risco usam as regras do `ResearchEngine`.
- A IA continua obrigada a pagar P&D e fabricação com capacidade derivada do caixa financeiro real.
- O grid de corrida não recalcula mais a IA com uma carteira virtual: recebe a garagem física já reconstruída pelo pipeline financeiro.
- O avanço de semanas na interface passa a liquidar imediatamente o custo incremental de P&D da IA no ledger financeiro.

## Confiabilidade inicial
- Forte: 65–74
- Médio: 55–64
- Fraco: 45–54

## Cadeia validada
`Caixa real -> P&D -> Design -> Fábrica -> Peça -> Instalação -> Garagem física -> Grid/Race`

## Validação
A simulação de 56 semanas verificou:
- eventos de design/fábrica/instalação encadeados;
- valores de performance e confiabilidade dentro de 1..100;
- confiabilidade derivada da peça atual;
- sem saldo negativo;
- com caixa insuficiente, nenhum projeto é iniciado;
- o grid deve consumir a garagem física resultante do mesmo pipeline financeiro.

O build Android completo não foi executado neste ambiente por ausência do wrapper Gradle no ZIP.
