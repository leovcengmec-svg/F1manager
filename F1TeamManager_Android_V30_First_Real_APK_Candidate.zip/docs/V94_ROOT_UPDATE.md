# V94 — Correção de cadeia raiz e auditoria de 2 temporadas

Base oficial: V93 / `F1TeamManager_Android_V30_First_Real_APK_Candidate.zip`

## Correções estruturais

1. **Salários anuais** — cobrança canônica no início de cada nova temporada, depois da transição do mercado, com marcador persistente por equipe/temporada. Evita cobrança dupla após reinício do aplicativo.
2. **Garagem física** — o fechamento/abertura de temporada agora persiste Carro 1, Carro 2 e estoque físico, mantendo a garagem como fonte real da corrida após reinício.
3. **Regressão anual** — fechamento da temporada Android aplica a mesma regra de ciclo de carreira antes de abrir a temporada seguinte, com fase persistida (`GROWING`, `REGRESSION`, `RECOVERY`) e idempotência por temporada.
4. **Bônus de qualificação** — o bônus de patrocinador é conectado ao fim real do Q3, usa a melhor posição do jogador e possui ledger persistente por temporada/GP para impedir pagamento duplicado.
5. **Tempo de P&D/Fábrica** — os motores passaram a registrar a semana real de conclusão ao avançar várias semanas de uma vez. Cooldown e `manufacturedWeek` agora usam a semana em que o evento realmente ocorreu.
6. **Persistência comercial/financeira da IA** — estados financeiros, contratos de patrocínio, pagamentos iniciais, contratos vistos, custos de desenvolvimento e penalidades são serializados e restaurados após reinício do processo.

## Auditoria de raiz

- Compilação de todo `core`: **PASS**, somente warnings preexistentes/benignos.
- `FullSeasonIntegrationTest`: **PASS** — 30 GPs, 80 ativos, 20 livres, 100 evoluídos.
- `TwoSeasonChainAuditTest`: **PASS** — 60 GPs, temporada 2028 / round 1.
- `AICarContinuityAuditTest`: **PASS**.
- `V86RootIntegrationAuditTest`: **PASS**.
- Auditoria V94 própria: **PASS**.
  - P&D concluído na semana real 12.
  - Cooldown encerrando na semana 16.
  - Fabricação concluída na semana real 14.
  - Snapshot financeiro/comercial da IA restaurado sem perda.
  - Pagamento inicial de patrocínio não duplicado após restart simulado.
  - 60 GPs contínuos, 2028/round 1, grid válido com 80 pilotos.

## Observação de build

O ambiente de auditoria não possui Gradle/Android SDK executável. Portanto, esta atualização foi validada por compilação completa do `core` e por auditorias headless/estáticas; não é declarado APK compilado neste ambiente.
