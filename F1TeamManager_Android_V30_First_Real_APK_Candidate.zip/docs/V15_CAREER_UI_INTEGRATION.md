# V15 — Career UI Integration

Pacote grande de integração da interface Android.

## Entrou
- seleção de equipe para nova carreira;
- persistência local de equipe, temporada e rodada via SharedPreferences;
- dashboard de carreira;
- telas de Equipe, Garagem e Temporada;
- fim de semana integrado: classificação → estratégia → corrida → Pit Wall → resultado;
- nomes dos pilotos da equipe do jogador derivados do WorldDatabase, sem nomes hardcoded;
- Race Weekend recebe o `playerTeamId` da carreira;
- avanço de rodada e virada de temporada persistidos.

## Limitação
A persistência salva o metadado da carreira e a posição da temporada. O estado detalhado de uma corrida em andamento ainda não é serializado; se o app for fechado no meio de uma corrida, o fim de semana será reiniciado. Isso é deliberado para não mascarar uma persistência parcial como save completo.

## Validação
A versão foi verificada por inspeção estrutural dos arquivos Kotlin/Gradle e pelos testes de núcleo já presentes no V14. A geração de APK não foi declarada como validada porque o ambiente não possui o Gradle/Android SDK completo disponível nesta execução.
