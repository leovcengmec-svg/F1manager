# V74 — Centro Comercial / Marketing

Implementação sobre a base oficial V73.

## Banco real
- 180 registros únicos.
- 60 Master (10 por categoria).
- 120 secundários (20 por categoria).
- Categorias: Básico, Regional, Nacional, Internacional, Premium e Global.
- Origem priorizada: F1 → F2 → F3 → Fórmula E → MotoGP → GT → WEC/24 Horas de Le Mans → INDYCAR.
- Nenhum patrocinador pode estar simultaneamente em dois slots da mesma equipe.

## Ofertas
- 3 ofertas por oportunidade.
- Slot 1 usa o pool Master; slots 2–5 usam o pool secundário.
- A mesma marca pode voltar em um ciclo futuro depois de terminar um contrato.
- Não existe bloqueio histórico de repetição.

## Valores
Todos os valores são sorteados dentro das margens comerciais já aprovadas; não há valor fixo por patrocinador.
- Entrada, €/GP, bônus de qualificação, bônus de corrida e bônus por ponto usam faixas por categoria.
- Duração: 3–10 GPs.
- Master: bônus de vitória de €1M.

## Metas
Qualificação e corrida usam a posição do ranking definitivo de força da equipe no início da temporada.

## Ciclo permanente
Contrato ativo → GPs restantes → 0 → slot liberado → 3 novas ofertas → nova assinatura.
Contratos que atravessam a virada da temporada mantêm os GPs restantes.
