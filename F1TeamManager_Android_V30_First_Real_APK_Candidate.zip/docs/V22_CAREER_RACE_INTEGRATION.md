# V22 — Career Race Integration

## Objetivo
Tornar `CareerWeekendEngine` o motor interativo efetivamente usado pela fachada de carreira.

## Mudanças
- `CareerRaceIntegration` deixou de instanciar `InteractiveRaceSession` como estado de corrida paralelo.
- A fachada agora delega para `CareerWeekendEngine`.
- Estratégia do jogador: postura + pneu.
- DRS/ERS continuam automáticos; não existem comandos manuais para o gestor.
- VSC/Safety Car/Fuel/Tyre continuam podendo pausar a corrida para decisão.
- Bandeira vermelha agora exige **uma escolha composta**: pneu + postura de relargada.
- Novo evento `RED_FLAG_DEPLOYED` para não confundir bandeira vermelha com mudança climática.
- O antigo `RaceDecisionEngine` V21 permanece apenas como camada legada/regressão e recebeu `LegacyDecisionTyre` para não conflitar com o enum `Tyre` do motor completo.

## Validação
`V22_SMOKE_OK redFlag=true classification=6`

A validação compila o núcleo Kotlin sem Android/Gradle e percorre classificação, decisões, bandeira vermelha, relargada e resultado final.
