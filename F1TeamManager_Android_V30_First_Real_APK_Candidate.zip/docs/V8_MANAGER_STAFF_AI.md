# V8 — Manager Staff + Contracts + Sponsors + Suppliers + AI

V8 adds the management layer around the V7 car/finance core.

## Added
- Staff roles: Team Principal, Technical Director, Commercial Manager.
- Staff market and contract offers.
- Hiring costs and replacement logic.
- Sponsor contracts with upfront, per-race and points revenue.
- Engine and tyre supplier contracts with performance/reliability.
- Supplier costs.
- AI management decisions per team/round.
- Staff/supplier effects on player race car performance/reliability.

## Scope
This is the domain/core layer. It is not yet the final Android UI, and staff progression/contract expiry/driver transfer market remain future work.

## Verification
`V8 MANAGER STAFF/AI SMOKE TEST OK`
