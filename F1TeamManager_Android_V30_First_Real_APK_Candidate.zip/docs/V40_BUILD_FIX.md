# V40 — Build Fix / Base Atual

Correções aplicadas sobre a versão atual, sem reversão das melhorias anteriores.

- Corrigido `RaceHero` ausente no `MainActivity.kt`.
- Corrigida referência de piloto nas decisões do Pit Wall (`d.request.driverId`).
- Corrigada expressão `sortedWith` do campeonato de construtores.
- Mantidos `SectionTitle` e `StatCard` da interface atual.
- Mantido o ícone F1 Team Manager presente nos recursos `mipmap-*`.
- Núcleo Kotlin compilado com `kotlinc`: 0 erros; apenas warnings não críticos.
- O build Android completo depende do GitHub Actions/Android SDK configurado no workflow.
