# V32 — MainActivity Kotlin syntax fix

Corrige a função `Race()` em `MainActivity.kt`.

## Problema observado no GitHub Actions

O compilador apontou:
- `155:1671 Syntax error: Unexpected tokens`
- `155:1673 Syntax error: Expecting ')'`
- falha em `:app:compileDebugKotlin`

A função `Race()` estava excessivamente compactada, com o bloco `AlertDialog`/`confirmButton` sujeito a fechamento incorreto de lambdas e parênteses.

## Correção

A função foi reescrita em formato multiline, com fechamento explícito de:
- `Column`
- `Row`
- `Card`
- `LazyColumn`
- `Button`
- `AlertDialog`
- `forEach`
- `let`

Também foram usados argumentos nomeados de forma consistente nos componentes Compose.

## Verificação local

- Contagem bruta de `{}` e `()` balanceada.
- O compilador Kotlin local não reportou erros de sintaxe nesta versão; ele apenas reporta referências Android/Compose ausentes porque este ambiente não possui o classpath Android do projeto.
- O ZIP foi validado com `unzip -t`.

O APK só será considerado gerado após o GitHub Actions produzir fisicamente `app-debug.apk`.
