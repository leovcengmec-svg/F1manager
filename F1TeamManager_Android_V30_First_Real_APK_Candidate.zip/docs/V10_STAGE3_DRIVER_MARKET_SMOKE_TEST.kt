package com.f1teammanager.docs

import com.f1teammanager.core.manager.*

/** Core Stage 3 invariants; run with the core module/test harness. */
fun stage3SmokeTest() {
    val engine = DriverMarketEngine(20261003)
    var market = engine.initialState(2026)
    check(market.contracts.size == 80)
    check(market.freeAgents.size == 20)
    check(market.contracts.groupBy { it.teamId }.values.all { it.size == 2 })

    // A free driver can sign for next season, but does not enter the current grid.
    val freeDriver = market.freeAgents.first()
    val replacement = market.contracts.first { it.teamId == 1 }.driverId
    val (afterOffer, offer) = engine.makeOffer(
        market, freeDriver, 1, 1, engine.salaryFor(freeDriver),
        DriverTeamRole.EQUAL, 2026, replaceDriverId = replacement
    )
    market = afterOffer
    check(offer.seasonTarget == 2027)
    check(market.contracts.size == 80)
    check(market.scheduled.any { it.driverId == freeDriver && it.startSeason == 2027 })
    check(engine.roster(market, 1, season = 2026).contains(replacement))

    // Start of 2027 executes the future transfer and keeps 80 active drivers.
    market = engine.applySeasonTransition(market, 2027)
    check(market.contracts.size == 80)
    check(market.freeAgents.size == 20)
    check(engine.roster(market, 1, season = 2027).contains(freeDriver))
    check(!engine.roster(market, 1, season = 2027).contains(replacement))
    check(market.contracts.groupBy { it.teamId }.values.all { it.size == 2 })
}


// Negotiation lifecycle: max 3 rounds and 1-week expiration.
// The implementation must never move a driver before the target season.
fun stage3NegotiationLifecycle(engine: DriverMarketEngine, state: DriverMarketState) {
    val eligible = state.freeAgents.firstOrNull() ?: error("Need a free driver")
    val (_, first) = engine.makeOffer(state, eligible, 1, 1, 1, engine.salaryFor(eligible), DriverTeamRole.EQUAL, 2026, currentWeek = 1)
    check(first.seasonTarget == 2027)
    check(first.round in 1..3)
    if (first.status == NegotiationStatus.COUNTER) {
        val (_, second) = engine.counterOffer(state, first, 2026, 1, first.salary + 1_000_000L, 1, DriverTeamRole.EQUAL)
        check(second.round == 2)
    }
}
