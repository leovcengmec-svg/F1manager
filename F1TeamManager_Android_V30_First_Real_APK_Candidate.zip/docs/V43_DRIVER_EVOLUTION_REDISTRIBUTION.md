# V43 — Evolução de Pilotos: teto + redistribuição

## Regras implementadas

- Evolução continua durante a temporada, após cada GP.
- Limite máximo de ganho positivo por atributo em uma temporada:
  - Prodígio: +12
  - Auge rápido: +10
  - Auge moderado: +8
  - Auge tardio: +8
  - Normal: +6
  - Demorado: +5
- O limite é **individual por atributo**, não um banco único de pontos do piloto.
- Os 7 atributos continuam independentes e são armazenados separadamente.
- O teto da classe continua absoluto por atributo:
  - Fraco 59
  - Médio 69
  - Forte 79
  - Pro 89
  - Lenda 100

## Redistribuição

Quando a evolução sorteia um atributo que não pode receber o ponto (por teto da classe, 100 ou limite anual daquele atributo), o ponto não é perdido. Ele é imediatamente redirecionado para outro atributo elegível.

Exemplo: Lenda com Velocidade 100 recebe +8. Velocidade não absorve nenhum ponto; os 8 pontos são distribuídos entre outros atributos que ainda tenham espaço.

Se nenhum atributo tiver espaço, o ganho não pode ser aplicado.

## Regressão

A regressão permanece separada da evolução positiva. O atributo selecionado pode cair até 40; ao atingir 40, a perda daquele ponto é simplesmente limitada a 40 e **não é redistribuída**.

## Persistência

O uso anual é salvo por piloto e por atributo, permitindo que um piloto regresse e depois se recupere sem alterar sua Classe ou Tipo de Evolução.

## Validação

Smoke test validado no ambiente Kotlin para:
- redistribuição quando Velocidade já está em 100;
- respeito ao teto Pro 89;
- preservação do ganho total enquanto houver atributos elegíveis;
- piso absoluto 40 na regressão.

O ambiente desta atualização não possui Android Gradle/SDK, portanto não é declarado um APK compilado aqui.
