# V18 — Pit Wall Decision Layer

Cria o contrato explícito entre piloto, gestor e motor.

- Postura: ATAQUE, EQUILIBRADO, DEFESA.
- Pneus: escolha inicial e sequência.
- Alertas: combustível, pneus, desgaste, mecânica.
- DRS/ERS não são comandos do gestor.
