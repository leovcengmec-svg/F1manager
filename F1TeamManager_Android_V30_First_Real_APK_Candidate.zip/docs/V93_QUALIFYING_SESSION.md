# V93 — Qualificação por sessão

- Q1: 30 minutos, 80 pilotos.
- Q2: 20 minutos, 50 pilotos.
- Q3: 10 minutos, 20 pilotos.
- Cada piloto completa várias voltas; somente a melhor volta da sessão classifica o piloto.
- Voltas podem ser excelentes, boas, normais, ruins ou muito ruins; consistência controla a variância.
- A classificação é atualizada durante a simulação e pode trocar posições.
- A UI oferece 0,5x / 1x / 2x / 4x e pausa.
- Ao terminar uma sessão, a interface muda para a próxima, mas a próxima somente começa quando o usuário toca em `SIMULAR Q2` ou `SIMULAR Q3`.
- Nenhuma definição de plano de pneus aparece na qualificação.
- `INICIAR CORRIDA` abre o Pit Wall em modo de preparação, onde os dois pilotos do jogador escolhem plano A/B/C/D e postura. A corrida só começa depois do segundo `INICIAR CORRIDA`.
- O RNG da qualificação é isolado do RNG da corrida para não alterar eventos de corrida por causa da nova simulação visual.
