# V560 — Carro começa em zero e evolui por P&D

## Correção
- Novas carreiras agora criam os dois carros físicos com os seis componentes em desempenho 0.
- Não existem peças instaladas artificiais na abertura; `installedPieces` e versões começam vazios.
- A evolução segue exclusivamente P&D → projeto concluído → fabricação → peça física pendente → instalação no Carro 1 ou Carro 2.
- A escala de influência de desempenho na corrida agora cobre 0–100 em dez faixas, de modo que o progresso abaixo de 40 também é reconhecido.
- A fabricação e a tela de investimento não forçam mais o desempenho inicial para no mínimo 40.
- Confiabilidade inicial continua independente do desempenho; a alteração não zera confiabilidade.

## Teste acrescentado
`InitialCarStartsAtZeroV560Test`: valida os seis componentes dos dois carros em zero, ausência de peças pré-instaladas, Overall 0 e progressão da escala de corrida.

## Limitação
O ZIP foi verificado estruturalmente. Compilação Gradle/Android e teste no aparelho não foram executados nesta sessão.
