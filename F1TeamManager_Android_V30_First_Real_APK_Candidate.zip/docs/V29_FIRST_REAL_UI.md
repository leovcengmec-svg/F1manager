# V29 — First Real Android UI

Esta versão transforma o protótipo visual anterior em uma camada Compose mais completa.

## Telas
- Nova carreira / seleção das 40 equipes
- Home / Dashboard
- Equipe
- Pilotos
- Carro / P&D
- Calendário
- Campeonato
- Finanças
- Fim de semana
- Qualificação
- Pit Wall / Corrida
- Resultado

## Regra visual
A imagem enviada pelo usuário é referência de layout/hierarquia. Dados específicos não são universalizados. O modelo do carro é carregado por equipe via `CarCatalog.forTeam(teamId)`.

## Assets
Não são usados retratos/escudos fictícios como se fossem reais. O pacote prepara a interface para os assets locais reais, que serão adicionados em etapa própria.
