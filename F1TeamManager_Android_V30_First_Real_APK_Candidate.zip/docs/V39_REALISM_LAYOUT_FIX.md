# V39 — Layout aprovado + Realismo de corrida + fluxo pós-GP

## Objetivo
Correção integrada sem remover funcionalidades previamente implementadas.

## Interface
- Home reorganizada para seguir a referência aprovada: cabeçalho único, situação do campeonato, próxima corrida, acesso rápido, equipe e navegação inferior.
- Removido o bloco de calendário duplicado da Home.
- Removido o botão PIT WALL da Central de Gestão; o Pit Wall continua sendo a interface da corrida ativa.
- Pilotos titulares na Home agora mostram a posição do piloto no campeonato e seus pontos, não a posição de construtores.
- Destaque dos pilotos do jogador continua por cor/peso, sem asterisco no nome.
- Campeonato passa a mostrar Pilotos e Construtores na mesma tela.

## Fluxo
- Ao finalizar uma corrida, o botão do resultado retorna ao Calendário, em vez de avançar diretamente para a Home/próximo GP.

## Pit stop
- BOX agora pausa a corrida e abre novamente a seleção dos cinco compostos.
- A troca física do pneu só acontece depois da escolha do composto.
- A corrida retoma após a escolha.

## Clima
- Mudanças de clima são persistentes e espaçadas: mínimo de 10 voltas entre mudanças e máximo de 3 transições por corrida.
- Chuva continua possível, mas não alterna continuamente entre estados.

## Pneus
- Desgaste usa acumulador contínuo para respeitar a vida-base em voltas definida para cada composto.
- Seco/sol desgasta mais que nublado; chuva prolonga a vida.
- O desempenho dos compostos em chuva foi reforçado para impedir que Medium/Soft/Hard mantenham desempenho competitivo em chuva média/forte.
- Intermediate é favorecido em chuva fraca/média e Wet é favorecido em chuva forte.

## Modelo de corrida
- A força do carro continua pertencendo à escuderia; a qualidade do piloto influencia a volta, mas não altera artificialmente o rating-base do carro.
- A influência do carro foi aumentada no tempo de volta e a variância aleatória reduzida.
- Falhas/acidentes foram reduzidos para evitar que carros muito inferiores vençam repetidamente apenas por aleatoriedade.
- ERS/DRS continuam independentes da postura de corrida.

## Patrocínios
- Mantidos os cinco espaços e contratos com duração aleatória de 1–10 GPs.
- Mantidos entrada, pagamento por GP, pontos e metas de qualificação/corrida.
- Bônus de qualificação é aplicado ao finalizar Q3.
