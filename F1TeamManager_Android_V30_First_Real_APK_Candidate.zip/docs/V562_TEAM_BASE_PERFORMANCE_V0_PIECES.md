# V562 — Correção da semântica de desempenho e versão de peça

## Regra correta

- O nível da equipe escolhida define a faixa de desempenho inicial: Forte, Médio ou Fraco.
- V0 é a versão do hardware-base instalado no início da temporada, não desempenho 0.
- Ao iniciar a primeira pesquisa de um componente, o novo design é V1.
- Pesquisa cria tecnologia; não altera o carro físico imediatamente.
- Fábrica cria uma peça física do design; a instalação no Carro 1 ou Carro 2 aplica o desempenho do novo design somente ao carro escolhido.
- A cada virada de temporada, as peças instaladas podem voltar à referência de versão V0 mantendo o desempenho construído para a nova temporada conforme as regras de regulamento/desenvolvimento.

## Código alterado

- `core/manager/InitialTeamProfile.kt`: o desempenho-base da equipe alimenta a projeção legada do carro; não é zerado para o jogador.
- `core/manager/CarGarageModels.kt`: os seis componentes do jogador e da IA começam com desempenho-base e registros explícitos de hardware V0.
- `CareerPreferences.kt`: migra carreiras criadas incorretamente pela V561 com desempenho zero para o perfil de equipe, e converte starter antigo `INIT-*` para base V0 mantendo seu desempenho.
- `ManagerModels.kt`: comentário corrigido para separar escala de desempenho e versão de peça.
- Testes de regressão: desempenho inicial por nível, componentes em V0, primeiro design em V1 e nenhuma mudança física ao iniciar pesquisa.

## Testes

Foi preparada/atualizada uma suíte de regressão JUnit no código-fonte. Ela não foi executada nesta sessão porque o pacote não contém Gradle Wrapper e não há Gradle/Android SDK disponível no ambiente. Validadores estáticos e teste de integridade ZIP são executáveis separadamente; não substituem build e JUnit.
