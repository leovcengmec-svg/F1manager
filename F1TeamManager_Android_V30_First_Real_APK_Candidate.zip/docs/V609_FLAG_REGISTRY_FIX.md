# V609 — Correção de aliases do registro de bandeiras

## Diagnóstico
A base já cadastra Sauber como Suíça (ID permanente 15), Force India como Índia (ID 19) e Campos Racing como Espanha (ID 38). O resolvedor aceitava nomes em português/inglês e códigos ISO-2, mas não declarava explicitamente alguns aliases ISO-3 e nomes comuns usados por pacotes externos.

## Alteração
Arquivo alterado: `app/src/main/java/com/f1teammanager/ExternalAssets.kt`.

Aliases adicionados:
- Suíça: `SUI`, `CHE`, `Swiss`, `Suisse`, além de `ch`.
- Índia: `IND`, `Indian`, além de `in`.
- Espanha: `ESP`, `Spanish`, além de `es`.

Os aliases são normalizados para as chaves ISO-2 e incluídos na lista de candidatos com e sem prefixos `flag_`/`flags_`. A leitura mantém as pastas externas já suportadas.

## Preservação
Nenhuma imagem foi removida, renomeada ou incorporada ao pacote. O histórico de auditorias e os demais arquivos do ZIP foram preservados.

## Validação
- Arquivo ZIP de entrada extraído sem erro.
- Integridade do ZIP de saída verificada.
- Não foi executada compilação Gradle/Android nem teste no dispositivo nesta sessão.
