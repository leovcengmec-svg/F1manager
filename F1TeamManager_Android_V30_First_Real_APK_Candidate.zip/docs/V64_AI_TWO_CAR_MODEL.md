# V64 — Modelo físico de dois carros para equipes AI

A evolução das equipes controladas pela IA agora também termina em dois carros físicos independentes.

- Os seis componentes oficiais permanecem: Motor, Chassi, Asa dianteira, Asa traseira, Freios e Unidade de potência elétrica.
- O histórico de desenvolvimento legado continua sendo usado como ponte financeira/compatibilidade.
- A partir desse histórico, cada equipe AI recebe Carro 1 e Carro 2 com pequenas diferenças determinísticas por componente.
- O piloto 1 utiliza Carro 1 e o piloto 2 utiliza Carro 2, mantendo o mapeamento determinístico já usado para o jogador.
- Reliability também passa a acompanhar o carro físico AI.
- O Overall/performance de corrida AI é calculado a partir do carro físico atribuído ao piloto.
- Não há alteração automática do carro do jogador e não há remoção do fluxo P&D -> Fábrica -> peça física.

Próxima etapa natural: substituir a ponte de desenvolvimento AI por uma cadeia AI completa P&D -> projeto -> fábrica -> peças físicas, compartilhando as mesmas regras de capacidade e instalação do jogador.
