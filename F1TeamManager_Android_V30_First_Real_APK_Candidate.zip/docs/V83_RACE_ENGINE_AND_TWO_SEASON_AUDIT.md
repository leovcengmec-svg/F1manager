# V83 — Race Engine Cleanup + 2-Season Audit

## Objetivo
Eliminar caminhos legados do motor de corrida e corrigir a integração entre carro físico, transição de temporada e evolução de pilotos.

## Correções
- `RaceParticipant` deixou de possuir `carSpeed` e `racecraft` armazenados.
- `enginePower` foi substituído por `enginePerformance`, representando exclusivamente o componente Motor físico.
- O motor de corrida não possui mais caminho direto por `TeamCarState`.
- A garagem física (`TeamGarage`) é a fonte de verdade dos 6 componentes usados na corrida.
- Removido o caminho direto `DriverDefinition.toParticipant()` da camada de corrida.
- `DynamicGridEngine` exige garagem física do jogador.
- A qualificação e a corrida usam os seis componentes físicos por participante.
- Na virada de temporada, o novo carro é derivado do estado físico real da garagem atual antes da continuidade anual.
- A nova garagem Car 1/Car 2 é reconstruída a partir do mesmo carro de temporada, evitando carro lógico e carro físico divergentes.
- `driverEvolutionAnnualGains` é zerado no início de cada nova temporada.
- Regressão individual é aplicada no fechamento da temporada e preserva Classe/Evolution Type.
- `seasonTargetForDriver()` usa a força física da garagem do jogador.
- Removidas referências do motor a `powerFactor`, `overtakingFactor`, `carBonus`, `distanceToT1M`, `180 ms` e `280 ms`.

## Auditoria de 2 temporadas
Simulação: 60 GPs (30 + 30), 80 titulares, 100 pilotos no mercado.

Resultado:
- 60/60 corridas concluídas.
- 80 pilotos no grid em todos os GPs.
- Mercado final: 80 titulares / 20 livres.
- Validação do grid final: OK.
- Reset anual: OK.
- 6 componentes físicos presentes nos dois carros.
- DRS e ERS ativos e conectados.
- 29.494 eventos de ultrapassagem na simulação.
- 2.944 ultrapassagens com DRS identificadas.
- 0 DNF no cenário determinístico de auditoria (riscos de incidente estavam zerados nesse cenário de teste).
- Nenhum erro de integridade no ZIP.

## Verificações de código
- Compilação do núcleo Kotlin: OK, somente warnings existentes de código não relacionado ao motor.
- `V82_ARCHITECTURE_AUDIT`: PASS.
- `V82_FULL_RACE_ENGINE_AUDIT`: PASS.
- Busca de legado no núcleo: nenhum `carSpeed`, `enginePower`, `racecraft=`, `powerFactor`, `overtakingFactor`, `carBonus`, `distanceToT1M`, `180L` ou `280L` encontrado.

## Regra oficial
V83 passa a ser a nova base oficial. O motor de corrida utiliza somente a arquitetura nova de componentes físicos + 7 atributos + ERS/DRS + pneus/clima/combustível/desgaste.
