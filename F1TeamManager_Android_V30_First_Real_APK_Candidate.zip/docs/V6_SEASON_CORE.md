# V6 — Season Core

Grande bloco de integração do motor esportivo com a temporada.

## Incluído
- banco local de 40 equipes / 80 pilotos;
- ratings oficiais já definidos para os 22 pilotos atuais e defaults determinísticos para o restante do elenco aprovado;
- calendário de 24 rodadas;
- execução de rodada completa usando o RaceWeekendEngine;
- campeonato de pilotos com pontuação até P60;
- vitórias, pódios e largadas;
- tabela ordenada por pontos, vitórias e pódios;
- save/load local sem dependências externas;
- smoke test: 40 equipes, 80 pilotos, 24 GPs, corrida completa e round-trip do save.

## Não incluído ainda
- economia completa;
- mercado de pilotos/gestores;
- P&D conectado ao desempenho do carro;
- calendário UI completo;
- APK release.
