# V566 — Auditoria do reconhecimento de bandeiras

A versão V566 amplia o resolvedor para China, Coreia do Sul e Estônia, preservando os Assets externos.

| País | Chaves aceitas (exemplos) | Nome/código normalizado |
|---|---|---|
| China | CN, CHN, China, Chinese | `cn` |
| Coreia do Sul | KR, KOR, South Korea, Korea, Republic of Korea, Coreia do Sul | `kr` |
| Estônia | EE, EST, Estonia, Eesti | `ee` |

Os arquivos podem usar o nome/código base ou prefixos `flag_` e `flags_`. A busca segue limitada às pastas de bandeiras do Asset Pack externo.

Validação estática concluída; compilação e teste no Android pendentes.
