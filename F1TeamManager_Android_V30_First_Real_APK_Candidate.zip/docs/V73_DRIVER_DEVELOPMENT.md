# V73 — Desenvolvimento de Pilotos

## Regras oficiais
- A equipe possui exatamente 2 pilotos titulares.
- Nível 0: nenhum programa.
- Níveis 1–4: 1 piloto simultaneamente.
- Níveis 5–10: 2 pilotos simultaneamente.
- Cada programa tem duração e pontos fixos conforme o nível.
- Ao terminar, os pontos são distribuídos aleatoriamente entre os 7 atributos.
- O teto do piloto é respeitado; ponto bloqueado por teto é redistribuído.
- Se todos os atributos elegíveis estiverem no teto, o excedente fica em reserva e não é perdido.
- Classe, Tipo de Evolução e Potencial não são alterados pelo programa.

| Nível | Pilotos | Prazo | Pontos |
|---:|---:|---:|---:|
| 0 | 0 | — | — |
| 1 | 1 | 12 semanas | +2 |
| 2 | 1 | 11 semanas | +3 |
| 3 | 1 | 10 semanas | +4 |
| 4 | 1 | 9 semanas | +5 |
| 5 | 2 | 8 semanas | +6 |
| 6 | 2 | 7 semanas | +7 |
| 7 | 2 | 6 semanas | +8 |
| 8 | 2 | 5 semanas | +9 |
| 9 | 2 | 4 semanas | +10 |
| 10 | 2 | 3 semanas | +12 |

## Cadeia
Instalação → programa → prazo → conclusão → distribuição dos pontos → atributos persistidos → evolução/race.
