# V35 — Correções de coerência, P&D e calendário

Base: `F1TeamManager_Android_V30_First_Real_APK_Candidate.zip` (nome preservado).

## Corrigido
- 40 equipes / 80 titulares mantidos.
- Escalação aprovada preservada; equipe 35 é Fittipaldi, com Carlos Reutemann e Pedro Clerot.
- Força do carro deixou de ser calculada pelo ID da equipe: agora cada equipe possui níveis explícitos de desempenho e seis componentes.
- Seis componentes oficiais: motor, chassi, asa dianteira, asa traseira, freio e unidade de potência elétrica.
- P&D deixou de ser uma tela estática: cada componente pode receber projeto real e o projeto avança por semanas do calendário.
- Durações fixas: motor 4 semanas, chassi 3, asa dianteira 2, asa traseira 2, freios 2, unidade de potência elétrica 4.
- Um projeto de 3 semanas consome exatamente 3 semanas, independentemente de quantas corridas ocorram nesse intervalo.
- P&D passou a alimentar o desempenho do carro na corrida.
- ERS passa a recuperar energia automaticamente; ataque usa mais, equilibrado usa moderadamente e defesa recupera mais.
- DRS é automático e só fica ativo quando o carro está a no máximo 1,000 s do carro à frente.
- Botões BOX SOFT/MEDIUM/HARD foram removidos do Pit Wall. BOX abre uma escolha de composto somente quando o gestor decide parar.
- Cards dos dois pilotos foram compactados para liberar área para a classificação.
- Classificação ao vivo recebe prioridade visual.
- Qualificação passou a ter Q1/Q2/Q3: 80 -> 60 -> 40 -> 20 finalistas, com o grid final de 80 posições.
- Calendário ampliado de 24 para 30 GPs, com circuitos reais e semanas 1–56 distribuídas ao longo do ano.
- Classificação de cada corrida é salva no armazenamento da carreira e pode ser consultada posteriormente pelo calendário.

## Validação do núcleo
`V35_CORE_OK teams=40 drivers=80 gps=30 q1=80 q2=60 q3=40`
