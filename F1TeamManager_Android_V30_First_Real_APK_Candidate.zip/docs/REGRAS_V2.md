# F1 Team Manager — V2 — Regras

## Mercado de gestores
- Não existe pedido de demissão.
- Desempenho ruim pode resultar em demissão pela equipe.
- O gestor demitido fica disponível no mercado.
- Outra equipe pode contratá-lo.
- Bom desempenho aumenta reputação.
- Outras equipes podem demonstrar interesse e tentar contratar gestores de bom desempenho.
- A equipe pode perder um gestor bom por contratação de outra equipe.
- O mercado deve considerar desempenho, reputação, contrato, salário e interesse das equipes nas próximas evoluções.

## Carro
Seis componentes:
1. Unidade de potência (motor)
2. Chassi
3. Asa dianteira
4. Asa traseira
5. Freio
6. Unidade de potência elétrica

## Próxima integração
Os níveis dos componentes deverão alimentar o cálculo de desempenho do carro. O simulador de corrida será integrado depois que o estado de carreira estiver persistente.
