# Auditoria V571 — Fotos de pilotos

## Alterações
- `ExternalAssets.loadDriverPhoto` aplica prioridade estrita por nome normalizado para `Heikki Kovalainen` e `Bruce McLaren`, independente do ID que venha da escalação ou de um save migrado.
- Para esses dois pilotos, os candidatos numéricos (`057.png`, `66.png` etc.) são excluídos; isso evita selecionar fotos antigas associadas ao slot numérico.
- O cache agora usa `driverId + nome normalizado`, evitando reutilizar um bitmap quando um mesmo ID é exibido com outro nome.

## Arquivos externos esperados
- `Pictures/F1Manager/Assets/drivers/Heikki Kovalainen.png`
- `Pictures/F1Manager/Assets/drivers/Bruce McLaren.png`

São aceitas variações de maiúsculas, espaços e prefixos já suportadas pelo normalizador, como `driver_Heikki Kovalainen.png`. Os arquivos precisam existir na pasta externa.

## Validação
Verificações estáticas do código e integridade do ZIP realizadas. Não foi executada compilação Android nem teste visual em dispositivo.
