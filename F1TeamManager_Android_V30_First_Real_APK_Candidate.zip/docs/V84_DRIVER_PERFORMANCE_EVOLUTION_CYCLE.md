# V84 — Desempenho por Meta + Ciclo de Evolução/Regressão

## Meta de temporada
- A força das 40 equipes é calculada no início da temporada.
- Para a equipe do jogador, a fonte é a garagem física de abertura.
- Para as demais equipes, é usado o perfil inicial da equipe na abertura.
- O ranking é convertido em duas metas por equipe (P1–P80), usando os contratos ativos da temporada.
- A meta é congelada em `driverEvolutionSeasonTargets` durante toda a temporada.
- Pilotos livres recebem meta 80 e não alteram a meta de equipes ativas.

## Desempenho
O índice compara o resultado real com a meta congelada. A curva de pontos esperados foi recalibrada para um teto de aproximadamente 450 pontos para a meta P1, decaindo linearmente até a parte final do grid. O índice controla a utilização do potencial anual.

## Limite por atributo
O potencial anual do tipo de evolução continua sendo a referência máxima por atributo. O desempenho reduz esse teto por atributo através do multiplicador de desempenho. Pontos não podem ultrapassar o teto da classe nem o limite anual individual.

## Ciclo de carreira
1. `GROWING` — evolução normal até o teto da classe.
2. `REGRESSION` — só começa depois que o Overall atinge o teto da classe; perda mínima de 1 ponto por temporada, sempre respeitando mínimo 40.
3. `RECOVERY` — quando o Overall entra em 40–49, a evolução volta em ritmo reduzido (50% do potencial).
4. `GROWING` — ao chegar a 50, retorna à evolução normal e pode novamente subir até o teto.

Classe e tipo de evolução são permanentes. O ciclo pode se repetir.
