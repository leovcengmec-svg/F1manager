# V108 — IA: cadeia física e Central de Notícias

## Regra
A IA segue a mesma cadeia física do jogador:

P&D → Design concluído → Fábrica → Estoque → Instalação no Carro 1/Carro 2 → aumento de Desempenho/Overall.

## Central de Notícias
- `P&D CONCLUÍDO`: publicado quando o design é concluído.
- `FABRICAÇÃO CONCLUÍDA`: publicado quando a peça física entra no estoque.
- `PEÇA INSTALADA`: publicado quando a peça é instalada em um carro.
- `EVOLUÇÃO DE EQUIPE`: publicado somente quando o Overall físico da equipe aumenta após a instalação.
- Nenhuma notícia de evolução é gerada por simples comparação agregada, nem quando o Overall cai ou permanece igual.

## Instalação da IA
A IA escolhe uma peça física do estoque que realmente melhora o componente do carro-alvo. Peças recém-fabricadas não podem ser instaladas na mesma semana em que entram no estoque, garantindo separação temporal entre fabricação e instalação.

## Interface da equipe
O card da equipe passa a mostrar apenas `DESEMPENHO` e `CONFIABILIDADE`, sem a duplicação `FORNECEDOR / MOTOR` / `Engine`. O desempenho é derivado do `TeamGarage.teamAverageOverall` atual.
