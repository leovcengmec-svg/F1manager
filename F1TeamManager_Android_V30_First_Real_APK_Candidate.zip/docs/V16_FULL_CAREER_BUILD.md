# V16 — Full Career Build

## Objetivo
Consolidar o fluxo de carreira em um único estado de alto nível, evitando que a UI mantenha uma segunda lógica de temporada.

## Fluxo
Nova carreira → Home → Classificação → Pré-corrida → Corrida → Decisão → Resultado → Próximo GP → Offseason → Nova temporada.

## Responsabilidades
- `CareerFlowEngine`: orquestração da carreira.
- `CareerWeekendEngine`: simulação do fim de semana.
- Engines de Manager: carro, finanças, staff, mercado e P&D.
- UI: apenas renderiza o estado e envia comandos.

## Race Weekend
Sem TL1/TL2/TL3. Apenas classificação e corrida.

Gestor: Ataque/Equilibrado/Defesa, pneus, pit e resposta a eventos grandes.
Piloto: DRS/ERS e execução de condução automaticamente.
Piloto → gestor: alertas de combustível e pneus.

## Persistência
Save V16 contém o checkpoint de carreira. O estado detalhado de uma volta em execução ainda pertence ao próximo bloco de persistência de corrida e não é mascarado como concluído.
