# V31 — correção de compilação Kotlin

Correções aplicadas sobre o V30:

1. `MainActivity.kt` agora importa explicitamente `com.f1teammanager.core.season.toParticipant`, corrigindo o erro `Unresolved reference 'toParticipant'` e a consequente falha de inferência do parâmetro `R` em `participants()`.
2. A linha da grade de classificação não passa mais um `Int` para `Text` quando o piloto não é encontrado. O fallback agora é `"Piloto <id>"`, mantendo o argumento como `String`.

O log do GitHub mostrado em 03/10/2026 apontava especificamente esses dois erros.
