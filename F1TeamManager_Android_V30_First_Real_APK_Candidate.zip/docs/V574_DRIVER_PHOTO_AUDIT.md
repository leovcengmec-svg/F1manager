# V574 — Auditoria geral dos Assets de pilotos

## Resultado

A lista oficial contém **80 titulares + 20 reservas = 100 pilotos**. Os nomes normalizados não apresentam colisões entre os 100 cadastros. A resolução de imagens foi alterada para que cada cadastro procure exclusivamente o próprio nome completo, sem fallback por ID numérico e sem aliases históricos.

Pasta externa esperada: `Pictures/F1Manager/Assets/drivers/`. Exemplos aceitos para Felipe Massa: `Felipe Massa.png`, `Felipe_Massa.png` ou `driver_Felipe Massa.png`; nomes são normalizados para comparação, mas não se aceitam fotos de outros nomes.

## Lista auditada

001. Charles Leclerc
002. Lewis Hamilton
003. Lando Norris
004. Oscar Piastri
005. Carlos Sainz
006. Alexander Albon
007. George Russell
008. Kimi Antonelli
009. Max Verstappen
010. Isack Hadjar
011. Michael Schumacher
012. Rafael Câmara
013. Pierre Gasly
014. Franco Colapinto
015. Ayrton Senna
016. Nikola Tsolov
017. Alain Prost
018. Gabriele Minì
019. Sebastian Vettel
020. Martinius Stenshorne
021. Jenson Button
022. Alexander Dunne
023. Nico Rosberg
024. Dino Beganovic
025. Mika Häkkinen
026. Paul Aron
027. Liam Lawson
028. Arvid Lindblad
029. Nico Hülkenberg
030. Gabriel Bortoleto
031. Nigel Mansell
032. Sebastian Montoya
033. Nelson Piquet
034. Mari Boya
035. Fernando Alonso
036. Lance Stroll
037. Niki Lauda
038. Joshua Dürksen
039. James Hunt
040. Ritomo Miyata
041. Emerson Fittipaldi
042. Noel León
043. Jackie Stewart
044. Daniel Ricciardo
045. Jim Clark
046. Tuukka Taponen
047. Juan Manuel Fangio
048. Ugo Ugochukwu
049. Jack Brabham
050. Freddie Slater
051. Mario Andretti
052. Théophile Naël
053. Damon Hill
054. Noah Strømsted
055. Kimi Räikkönen
056. Matteo De Palo
057. Felipe Massa
058. Mattia Colnaghi
059. Rubens Barrichello
060. Enzo Deligny
061. Mark Webber
062. Leonardo Vicente
063. Juan Pablo Montoya
064. James Wharton
065. Jacques Villeneuve
066. Alex Powell
067. Esteban Ocon
068. Oliver Bearman
069. Carlos Reutemann
070. Lyam Vicente
071. Gilles Villeneuve
072. Laurens van Hoepen
073. Sergio Pérez
074. Valtteri Bottas
075. Gerhard Berger
076. Pyong Cris
077. David Coulthard
078. Maciej Gładysz
079. Eddie Irvine
080. Jean Alesi
081. Heinz-Harald Frentzen
082. Jarno Trulli
083. Nick Heidfeld
084. Robert Kubica
085. Heikki Kovalainen
086. Romain Grosjean
087. Guanyu Zhou
088. Giancarlo Fisichella
089. Takuma Sato
090. Yuki Tsunoda
091. Riccardo Patrese
092. Michele Alboreto
093. Felipe Drugovich
094. Bruce McLaren
095. Ralf Schumacher
096. Pedro de la Rosa
097. Adrian Sutil
098. Mick Schumacher
099. Pastor Maldonado
100. Alexander Rossi

## Verificações estáticas

- [x] no numeric driver filename candidates
- [x] no legacy roster aliases in photo loader
- [x] only full-name candidates
- [x] 100 drivers audited
- [x] no normalized full-name collisions
- [x] versionCode 574
- [x] versionName 0.574.0

## Limitação

A auditoria valida a lista do cadastro e a lógica de seleção dos nomes, mas não consegue confirmar que cada arquivo de imagem externo contém o rosto correto, pois os Assets do aparelho não estão incluídos no projeto. A compilação Android e a conferência visual no dispositivo permanecem pendentes.
