# V7 — Manager Core

V7 connects the season/race core to the first management loop.

## Added
- Player team state and team selection field.
- Team car attributes: aerodynamics, chassis, engine and reliability.
- Facility levels: factory, wind tunnel, simulator and testing.
- P&D queue with round-based completion.
- Facility upgrades with budget costs.
- Finance ledger with sponsor, prize, points bonus and race costs.
- Manager reputation and experience progression.
- Driver contract records.
- ManagerSeasonEngine connecting management state -> race -> finance -> P&D -> next round.
- Versioned V7 save/load.

## Deliberate scope
This is the domain/core layer. It does not claim a final Android UI or APK.
