package com.f1teammanager.core.race

import kotlin.random.Random

fun main() {
    val circuit = RaceCircuit(1, "Teste", 60, 78000L, .9, .9, safetyCarRisk = 2.0)
    val p = RaceParticipant(1, "Piloto Teste", 1, "Equipe", 90, 90, 90, 90, 90, 85, 85)
    val e = RaceWeekendV12Engine(Random(7))
    var step = e.start(p, circuit, Tyre.MEDIUM)
    step = e.setDriverStrategy(DriverStrategyMode.ATTACK)
    var lapsObserved = 0
    var decisions = 0
    var drs = 0
    var ers = 0
    while (!step.completed && lapsObserved < 200) {
        lapsObserved = maxOf(lapsObserved, step.lap)
        drs += step.events.count { it.text.contains("DRS") }
        ers += step.events.count { it.text.contains("ERS") }
        val decision = step.decision
        if (decision != null) {
            decisions++
            val action = when (decision.type) {
                ManagerDecisionType.RED_FLAG -> ManagerDecisionAction.RESTART_BALANCED
                ManagerDecisionType.SAFETY_CAR, ManagerDecisionType.VSC -> ManagerDecisionAction.BOX
                ManagerDecisionType.FUEL_CRITICAL, ManagerDecisionType.TYRE_CRITICAL -> ManagerDecisionAction.EXTEND_STINT
                ManagerDecisionType.MECHANICAL_ALERT -> ManagerDecisionAction.STAY_OUT
            }
            step = e.choose(action)
        } else {
            step = e.advance()
        }
    }
    check(lapsObserved > 0)
    check(drs > 0)
    check(ers > 0)
    check(decisions > 0)
    println("V12 RACE WEEKEND PIT WALL SMOKE TEST OK")
    println("laps=$lapsObserved decisions=$decisions drs=$drs ers=$ers")
}
