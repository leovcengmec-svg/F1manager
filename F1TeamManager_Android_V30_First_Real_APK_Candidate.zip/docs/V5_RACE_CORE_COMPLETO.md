# V5 — Race Core Completo

Esta versão consolida a próxima camada do motor em um único pacote.

## Incluído
- Qualificação e formação do grid.
- Ritmo de piloto/carro/motor.
- Combustível e degradação de pneus.
- Dirty air.
- Pit stops e estratégia planejada.
- Reação básica a Safety Car/VSC e chuva.
- Compostos seco/intermediário/chuvoso.
- Incidentes: acidente e falha mecânica.
- Desgaste acumulado do chassi com alerta.
- DNF e classificação.
- Eventos de ultrapassagem derivados da mudança real de posição.
- Volta mais rápida.
- Pontuação do campeonato nas 60 primeiras posições conforme regra do projeto.
- `GameState.applyRace()` para acumular pontos entre GPs.
- Aleatoriedade determinística por seed.

## Correção importante sobre V4
O V4 calculava `lastLapMs`, mas não o armazenava no estado. O V5 corrige o fluxo e muda a detecção de ultrapassagem para comparar posições entre voltas, evitando a falsa dependência daquele valor zerado.

## Não declarar como concluído ainda
Ainda não estão nesta versão: mercado completo, staff, fornecedores, facilities, desenvolvimento completo de carro, calendário/championship UI, persistência Room e APK final assinado. Esses módulos devem ser integrados depois do núcleo de corrida estar estável.
