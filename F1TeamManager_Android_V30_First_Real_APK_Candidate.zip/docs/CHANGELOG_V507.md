# V507 — Caminho financeiro único para jogador e IA

- Centralizada a liquidação de GP em `FinanceEngine.settleRaceFinance`, usada pelo jogador e pela IA.
- A mesma regra agora calcula pagamentos fixos de patrocinadores, bônus por pontos, metas de corrida, metas de qualificação, premiação, custos operacionais e penalidade DNF.
- A IA deixou de manter uma implementação paralela de liquidação de corrida e passou a usar a chave canônica `GP_SETTLEMENT:temporada:GP`.
- Receita semanal do Centro Comercial e manutenção semanal foram movidas para funções compartilhadas usadas pelos dois caminhos.
- Mantidos os livros compartilhados de salários (`SalaryLedger`) e taxas de contratação (`SignatureFeeAccounting`).
- A posição de qualificação do jogador é encaminhada ao fechamento financeiro do GP, usando a mesma regra aplicada à IA.
- Adicionado teste de equivalência de liquidação e prevenção de duplicidade.

Validação nesta entrega: verificação estrutural do ZIP e revisão estática do código. Compilação Android e execução de testes JUnit permanecem pendentes.


## Continuação da unificação financeira
- Criados métodos canônicos de crédito, entrada de patrocínio e ajuste de orçamento por evento anual em `FinanceEngine`.
- Contratação de patrocínio do jogador e da IA agora registra a entrada pelo mesmo método compartilhado, com a mesma descrição contábil.
- Ajustes de orçamento por eventos anuais da IA usam o mesmo cálculo central do saldo e da variação registrada.
- Acrescentados testes de equivalência para entrada de patrocínio e ajuste anual.
- Limite desta etapa: decisões estratégicas de investimento da IA continuam sendo escolhidas pelo motor de estratégia da IA; os lançamentos comuns devem usar as mesmas regras contábeis. Compilação e execução de testes Android ainda não foram realizadas neste ambiente.
