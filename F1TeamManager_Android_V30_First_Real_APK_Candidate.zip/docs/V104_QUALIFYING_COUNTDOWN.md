# V104 — Qualificação com relógio regressivo

- Q1: 30:00 → 00:00; Q2: 20:00 → 00:00; Q3: 10:00 → 00:00.
- O relógio é um tempo virtual contínuo, avançando em fatias de 5 segundos. Os controles 0,5x/1x/2x/4x alteram somente a velocidade visual, não a lógica da sessão.
- A referência de volume de voltas é `tempo_da_sessão / baseLapTimeMs` do GP.
- Cada piloto possui seu próprio tempo de volta e agenda a próxima volta quando conclui a anterior.
- A melhor volta válida determina a classificação; voltas descartadas consomem tempo e não entram no melhor tempo.
- A chance de descarte depende da consistência do piloto (1% a 5%).
- Q1 elimina 30, Q2 elimina 30 e Q3 define P1–P20.
- O motor de corrida permanece isolado da aleatoriedade de classificação.
