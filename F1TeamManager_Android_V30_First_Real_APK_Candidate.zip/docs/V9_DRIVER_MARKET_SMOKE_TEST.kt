import com.f1teammanager.core.manager.*

fun main() {
    val engine = DriverMarketEngine(99)
    var market = engine.initialState(2026)
    check(market.contracts.size == 80)
    check(market.contracts.map { it.driverId }.distinct().size == 80)
    check(market.contracts.groupBy { it.teamId }.values.all { it.size == 2 })

    val playerTeam = 1
    val target = market.contracts.first { it.teamId != playerTeam }
    val salary = engine.salaryFor(target.driverId) * 2
    val result = engine.offer(market, target.driverId, target.teamId, playerTeam, 2, salary, salary/2,
        teamStrength = 95, reputation = 95, season = 2026, rngSeed = 12345)
    check(!result.second.accepted)
    check(result.first.pending.isNotEmpty())

    val teamDriver = market.contracts.first { it.teamId == playerTeam }
    val renewed = engine.renew(market, teamDriver.driverId, playerTeam, 3, engine.salaryFor(teamDriver.driverId) * 2, 2026)
    check(renewed.contracts.count { it.driverId == teamDriver.driverId } == 1)

    val seasonEngine = DriverMarketSeasonEngine(engine)
    var manager = TeamManagerState(playerTeamId=playerTeam, car=TeamCarState(90,90,90,90), finance=TeamFinanceState(100_000_000), manager=ManagerProfile(reputation=95, experience=10), driverMarket=renewed)
    manager = seasonEngine.offseason(manager)
    check(manager.season == 2027)
    check(manager.driverMarket.contracts.map { it.driverId }.distinct().size == manager.driverMarket.contracts.size)
    check(manager.driverMarket.contracts.groupBy { it.teamId }.values.all { it.size <= 2 })
    check(manager.driverMarket.contracts.size == 80)
    println("V9 DRIVER MARKET SMOKE TEST OK")
}
