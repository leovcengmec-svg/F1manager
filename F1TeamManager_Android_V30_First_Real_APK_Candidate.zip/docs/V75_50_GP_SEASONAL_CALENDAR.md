# V75 — Banco permanente de 50 GPs e calendário sazonal de 30 GPs

- Banco permanente: exatamente 50 circuitos reais.
- Início de cada temporada: 30 GPs são selecionados pseudoaleatoriamente a partir dos 50.
- A seleção usa a temporada como semente: a mesma temporada é estável após reiniciar o aplicativo, mas temporadas diferentes recebem calendários diferentes.
- Dentro da temporada não há GP duplicado.
- O calendário continua com 56 semanas: 30 semanas de GP e 26 semanas livres.
- Cada GP possui extensão, número de voltas, tempo médio de referência de uma volta competitiva e nome de busca do asset.
- O tempo armazenado é referência competitiva; não é recorde de volta nem volta mais rápida oficial.
- O `baseLapTimeMs` do motor de corrida passa a usar esse tempo médio de referência.
- A interface de calendário mantém o layout aprovado da V56.
