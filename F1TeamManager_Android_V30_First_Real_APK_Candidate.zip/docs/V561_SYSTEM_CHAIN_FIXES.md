# V561 — Correções de cadeia e regressões

## Carro / IA / ranking
- Carro do jogador começa com os seis componentes físicos em 0 e sem peças instaladas.
- Carros rivais recebem o perfil técnico inicial e peças-base explicitamente instaladas (`INITIAL-AI-*`), mantendo a diferença Forte/Médio/Fraco na corrida.
- O ranking inicial é calculado a partir do perfil oficial, nunca a partir da garagem zerada do jogador.
- A projeção de legado do oponente usa `InitialTeamProfile.aiCarState()`; a do jogador usa `carState()` vazio.

## Evolução / eventos / temporada
- Eventos anuais não elevam componentes vazios; regras e penalidades só alteram componentes que têm hardware instalado.
- V0 de temporada é persistido somente nos componentes instalados. Chaves de versão órfãs são ignoradas/removidas e saves antigos sem metadado continuam a usar V1.
- Componentes do carro legado podem permanecer em 0; confiabilidade não usa a mesma escala.

## Persistência
- P&D, designs, fábrica, garagem e finanças usam `saveEngineeringBundle()` com um único commit.
- Instalação de peças, avanço semanal e melhorias de instalações usam `saveCareerStepBundle()` antes de atualizar o estado exposto à UI.
- Nova carreira persiste seus sistemas nucleares num único commit; os ledgers auxiliares da carreira anterior são limpos antes do bootstrap.
- Garagens antigas sem ledger físico preservam desempenho positivo por marcadores `LEGACY-MIGRATED-*`; carros vazios não recebem peças falsas.

## Validação
- `validate_project.py`: 40/40.
- `final_release_audit.py`: 25/25.
- `v448_game_cycle_audit.py`: 18/18.
- `v498_ai_persistence_audit.py`: 8/8.
- `v440_financial_continuity_audit.py`: 13/13.
- `v441_financial_model_audit.py`: 7/7.
- `audit_v429.py`: 9/9.
- `audit_v445_regulation.py`: 4.772/4.772.
- `v438_finance_stress_test.py` e `v439_finance_stress_test.py`: PASS em modelos Python ilustrativos.

**Sem build Android ou execução de JUnit nesta sessão.** O relatório de cadeia completo lista os itens pendentes para teste no dispositivo.
