# V82 — Integração completa do motor de corrida

Base: V81.

## Fonte de verdade do carro
Os seis componentes físicos são a única fonte de performance do carro durante a corrida:
- Motor: tempo médio de referência do GP.
- Chassi: tempo médio + estabilidade da volta.
- Asa dianteira: tempo médio + DRS.
- Asa traseira: DRS.
- Freios: recuperação de ERS + ataque/defesa.
- Unidade elétrica: eficiência/entrega do ERS.

`carSpeed` permanece apenas como campo legado de compatibilidade de dados; não participa do cálculo de tempo, qualificação, DRS, ERS ou duelos.

## Piloto
Os sete atributos oficiais permanecem separados por função:
- Velocidade: ritmo.
- Classificação: quali.
- Ultrapassagem: ataque.
- Defesa: defesa.
- Consistência: variação/erro.
- Chuva: desempenho em pista molhada.
- Pneus: desgaste.

Experiência não é mais usada como um oitavo atributo de performance. `racecraft` interno, quando necessário por compatibilidade, é derivado de Ultrapassagem 45% + Defesa 35% + Consistência 20%.

## Qualificação
Tempo médio do GP + Motor + Chassi + Asa dianteira + combinação de Velocidade (40%) e Classificação (60%) + pequena variação.

## ERS
- Potencial de entrega: 1,0% do tempo médio da volta do GP.
- Freios determinam recuperação.
- Unidade elétrica determina aproveitamento/entrega.
- Ciclo automático real: usa com carga útil e recupera quando a estratégia preserva a bateria.
- Não existe bônus fixo de 180 ms.

## DRS
- Potencial: 1,5% do tempo médio da volta do GP.
- Asa dianteira: 40%.
- Asa traseira: 60%.
- Ativo somente quando a janela de 1 segundo e volta mínima são atendidas.
- A eficiência do DRS entra diretamente no duelo de ultrapassagem.
- Não existe bônus fixo de 280 ms.

## Ultrapassagem e defesa
A troca de posição é resolvida por duelo adjacente, limitada a uma posição por troca por volta:
`gap + DRS + Ultrapassagem + Freios do atacante` versus `Defesa + Freios do defensor`.

## Limpeza de arquitetura
Removidas as dependências ativas de `powerFactor`, `overtakingFactor`, `carBonus`, bônus fixos antigos de ERS/DRS e cálculos duplicados de Velocidade/Consistência.
