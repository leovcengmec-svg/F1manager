# V14 — Android UI Integration

## Objetivo
Transformar o núcleo V13 em um fluxo jogável de fim de semana no Android.

## Fluxo
Home → Classificação → Corrida/Pit Wall → decisão estratégica → Resultado → Próximo GP.

## Regras mantidas
- Sem TL1/TL2/TL3.
- Estratégia do gestor: Ataque, Equilibrado, Defesa.
- Escolha de pneu inicial.
- Piloto controla DRS/ERS automaticamente.
- Piloto alerta combustível/pneus.
- Gestor decide em VSC, Safety Car e bandeira vermelha.

## Limitação desta entrega
A UI é uma integração Compose do núcleo. Persistência Room e telas administrativas completas ainda não são o foco deste bloco.
