# V137 — Finance / Sponsorship UI Revision

- Base: V136.
- Finance screen revised to match the approved reference layout.
- Sponsorship offers are displayed as three compact cards side-by-side per slot, preserving vertical scrolling for the page.
- No sponsor image/logo assets are introduced; sponsor identities remain dynamic text names from SponsorCatalog.
- Native Canvas vector-style icons are used for sponsor/category/payment information.
- Slot 1 remains Master / Principal; Slots 2–5 remain Secondary.
- Empty slots continue to receive live three-offer draws from the existing sponsorship engine.
- Removed the old bottom explanatory rules block from the Finance UI to keep the approved composition clean.
- Budget summary now separates balance/income/expenses from active sponsorship count visually.
- No sponsorship business rules, category probabilities, financial bands, or sponsor catalog names were changed in this UI revision.
