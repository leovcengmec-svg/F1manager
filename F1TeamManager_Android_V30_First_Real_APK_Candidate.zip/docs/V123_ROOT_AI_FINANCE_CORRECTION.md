# V123 — Correção de raiz do orçamento da IA

## Problema identificado
A cadeia de desenvolvimento da IA reconstruía uma carteira virtual própria (`initialBudget`) a cada simulação. Isso permitia que P&D + fabricação fossem simulados sem obedecer integralmente ao caixa financeiro persistente da equipe.

## Correção
- AITeamDevelopmentEngine recebeu uma entrada explícita de capacidade financeira real.
- AITeamFinancialEngine agora calcula a capacidade de desenvolvimento como:
  `caixa real atual + P&D já pago na temporada`.
- O valor já gasto em P&D é usado somente para reconstruir o histórico cumulativo; não volta para o caixa.
- O custo incremental da nova simulação é debitado do ledger financeiro real da IA.
- Existe uma trava final que impede qualquer débito de P&D superior ao caixa disponível.
- MainActivity e ManagerSeasonEngine foram ajustados para usar a mesma regra.
- As simulações de notícias/eventos também passam pela mesma capacidade financeira, evitando que a IA publique evolução que não poderia pagar.

## Regra final
Gestor e IA seguem o mesmo princípio econômico:

`Caixa real -> P&D -> Design -> Fábrica -> Peça -> Instalação`

A IA continua tomando decisões automaticamente, mas não recebe dinheiro virtual adicional para desenvolvimento.

## Compatibilidade
O snapshot financeiro existente continua sendo lido. O novo cálculo usa o histórico de P&D salvo quando disponível e preserva o ledger financeiro persistente.

## Validação criada
`AIFinanceRootV124Test.kt` cobre:
1. P&D não pode gastar acima do caixa real.
2. Saldo da IA não pode ficar negativo por P&D.
3. O orçamento não é reiniciado entre ticks semanais.
