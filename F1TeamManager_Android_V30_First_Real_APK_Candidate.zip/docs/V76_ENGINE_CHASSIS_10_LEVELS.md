# V76 — Motor e Chassi em 10 níveis

Implementação sobre a base oficial V75.

## Regra comum
Valores físicos 40..100 são convertidos em 10 níveis: 40–45, 46–51, 52–57, 58–63, 64–69, 70–75, 76–81, 82–87, 88–93 e 94–100.

## Motor
Função: potência e velocidade.
Base: tempo médio de referência da volta do GP (`baseLapTimeMs`).
Níveis 1..10: +3,00%, +2,35%, +1,75%, +1,15%, +0,55%, 0%, -0,55%, -1,15%, -1,75%, -2,35%.

## Chassi
Função: desempenho geral e estabilidade.
Base: tempo médio de referência da volta do GP.
Níveis 1..10 no tempo: +2,40%, +1,90%, +1,40%, +0,90%, +0,45%, 0%, -0,45%, -0,90%, -1,40%, -1,90%.

Estabilidade reduz a amplitude da variação natural da volta em: 0%, 4%, 8%, 12%, 16%, 20%, 25%, 30%, 36%, 42%.

Não são usados retas, curvas ou setores. O circuito fornece apenas o tempo médio de referência da volta como base.
