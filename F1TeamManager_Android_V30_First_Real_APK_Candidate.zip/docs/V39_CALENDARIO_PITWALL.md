# V39 — Calendário semanal + Pit Wall / pneus

## Correções
- Box manual passa a oferecer sempre os 5 compostos: Soft, Medium, Hard, Intermediário e Wet.
- A escolha feita no Box atualiza também o plano do piloto; um Box posterior não volta silenciosamente ao pneu antigo.
- Em chuva, o jogo destaca o composto recomendado, mas não bloqueia os demais.
- Os dois pilotos da equipe do jogador ficam permanentemente destacados em vermelho na classificação ao vivo e na classificação da qualificação.
- O calendário passa a ser controlado por semana (1–56), não apenas por Round.
- Existem 30 semanas de GP e 26 semanas livres.
- Semana livre pode ser avançada individualmente ou até a próxima corrida.
- O avanço das semanas livres também consome o tempo real dos projetos de P&D do carro.
- Não é permitido pular uma semana quando a semana atual é a do GP pendente.

## Regra de P&D
As semanas sem GP são o espaço principal de desenvolvimento. Ao avançar diretamente até o próximo GP, somente as semanas que não contêm uma corrida são aplicadas ao relógio dos projetos.
