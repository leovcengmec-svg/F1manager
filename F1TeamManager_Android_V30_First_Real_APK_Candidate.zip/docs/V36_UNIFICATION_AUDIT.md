# V36 — Unificação definitiva da cadeia de temporada

- `SeasonSettlementEngine` é a única autoridade de cálculo de premiação de construtores.
- O fluxo Android usa `CareerPreferences.settleConstructorsSeason()` no GP30.
- As 40 equipes são liquidadas, não somente a equipe do jogador.
- O pagamento é idempotente por temporada/equipe e persiste em `constructorPrizePaidTeams_<season>`.
- Os saldos das equipes IA são persistidos em `aiTeamBudgets`.
- `ManagerSeasonEngine` usa a mesma lista `settleAll()` para a simulação headless.
- Versão do aplicativo: 0.36.0 / versionCode 36.

A cadeia de premiação não possui mais uma implementação Android paralela.
