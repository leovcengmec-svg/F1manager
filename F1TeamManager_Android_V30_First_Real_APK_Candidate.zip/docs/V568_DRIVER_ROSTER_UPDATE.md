# Auditoria V568 — Elenco e perfis de pilotos

## Alterações aplicadas

| Substituído | Novo piloto | País | Classe | Evolução |
|---|---|---|---|---|
| Paul di Resta | Mick Schumacher | Alemanha | Forte | Auge moderado |
| Johnny Herbert | Yuki Tsunoda | Japão | Forte | Auge moderado |
| Olivier Panis | Ralf Schumacher | Alemanha | Forte | Auge moderado |
| Oliver Goethe | Paul Aron | Estônia | Forte | Normal |
| Timo Glock | Guanyu Zhou | China | Forte | Normal |
| Taito Kato (pedido: Taiko Kato) | Pyong Cris | Coreia do Sul | Pro | Prodígio |

Oliver Goethe → Paul Aron e Taito Kato → Pyong Cris são substituições no grid inicial; as outras quatro substituições são no mercado/reservas. IDs/vagas preservados. A resolução de imagem foi configurada para priorizar o nome do piloto nos IDs alterados.

## Verificações estáticas

- `versionCode = 568` e `versionName = 0.568.0`.
- 40 equipes e 80 titulares continuam definidos pelo roster de 40 × 2.
- 20 nomes continuam no mercado/reservas, totalizando 100 pilotos disponíveis.
- Os seis nomes novos têm perfil e país definidos.
- As seis entradas antigas não permanecem no grid inicial nem na lista de mercado/reservas.
- ZIP validado com `unzip -t`.

A compilação Android e o teste visual no aparelho não foram executados nesta entrega.
