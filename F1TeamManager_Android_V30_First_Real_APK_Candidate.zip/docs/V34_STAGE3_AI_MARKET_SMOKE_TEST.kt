import com.f1teammanager.core.manager.*

/** Stage 3 AI market smoke test: same rules as player, future transfers only. */
fun main() {
    val engine = DriverMarketEngine(20261005)
    var state = engine.initialState(2026)
    val playerTeam = 1

    repeat(20) { week ->
        state = engine.processAiMarketWeek(state, 2026, week + 1, playerTeam)
        check(state.contracts.count { it.activeIn(2026) } == 80)
        check(state.contracts.groupBy { it.teamId }.values.all { it.size <= 2 })
        check(state.scheduled.groupBy { it.driverId }.values.all { it.size == 1 })
    }

    val next = engine.applySeasonTransition(state, 2027, (1..40).associateWith { 30_000_000L })
    check(next.contracts.count { it.activeIn(2027) } == 80)
    check(next.contracts.groupBy { it.teamId }.values.all { it.size == 2 })
    check(next.freeAgents.size == 20)
    println("STAGE3 AI MARKET OK: 80 active / 20 outside / max 2 per team")
}
