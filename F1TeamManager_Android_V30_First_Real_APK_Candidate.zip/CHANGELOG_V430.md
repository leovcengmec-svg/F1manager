# V430 — Snapshot de segurança para a virada de temporada

- Antes de iniciar a virada, grava uma cópia síncrona de todas as chaves/valores suportados do `SharedPreferences` canônico `f1tm_career` em um arquivo de backup separado.
- Ao encontrar uma virada pendente antes de `STATE_PERSISTED`, restaura o snapshot anterior à virada e recria o diário para uma nova tentativa, em vez de reaplicar motores sobre estado misto.
- Se não existir snapshot válido, mantém o bloqueio seguro e apresenta erro explícito.
- A finalização remove primeiro o snapshot e só depois limpa o diário. Assim, falha na limpeza do backup não apaga o marcador `STATE_PERSISTED`.
- A rotina da tela passa a usar a temporada de origem persistida no diário, evitando usar como origem a temporada de destino após uma retomada.
- Incluídos testes-fonte para a ordem de snapshot/restauração e limpeza do diário.
- Versionamento Android: `versionCode 430`, `versionName 0.430.0`.

## Limites
O snapshot cobre o arquivo `f1tm_career` e os estados canônicos serializados nele. Não é uma transação distribuída de Room/SQLite, arquivos externos ou outros SharedPreferences. Testes de processo interrompido e compilação Android ainda precisam ser executados em ambiente Gradle/dispositivo.
