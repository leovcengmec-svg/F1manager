# Auditoria V390

- Alteração de layout limitada à tela de qualificação em `MainActivity.kt`.
- O painel exibe somente Cronômetro, Média do GP e Status da simulação, em três colunas com valores abaixo dos títulos.
- Cabeçalho da tabela usa as mesmas larguras da linha de classificação para alinhar cada título à coluna correspondente.
- Versão Android: `versionCode=390`, `versionName=0.390.0`.
- A compilação Android não foi executada neste ambiente; requer build externo para validação final.
