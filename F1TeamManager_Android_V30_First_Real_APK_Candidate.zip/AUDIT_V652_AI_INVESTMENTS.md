# Auditoria V652 — Investimento das IAs e construção do carro seguinte

## Escopo

Revisão da V651 e implementação das correções prioritárias no código-fonte para a V652. O foco foi a cadeia de orçamento da IA, investimento em instalações, P&D/fabricação, reserva do carro seguinte, penalidade financeira e consistência entre construção física e resumo legado.

## Achados e correções

### 1. Orçamento corrente sobrescrito pelo replay histórico

**Arquivo:** `app/src/main/java/com/f1teammanager/core/manager/AITeamDevelopmentEngine.kt`

A reconstrução de anos anteriores voltava a usar o orçamento de abertura do perfil da equipe e reutilizava essa variável na temporada solicitada. Isso fazia o simulador físico atual trabalhar com uma capacidade artificial, em vez da capacidade informada pelo ledger financeiro.

**Correção:** separados `historicalSeasonBudget` e `currentSeasonStartingBudget`. Cada ano histórico continua usando a referência inicial canônica; a temporada corrente usa exclusivamente a capacidade recebida. O retorno antecipado para temporadas anteriores a 2026 também preserva a capacidade corrente normalizada.

### 2. Investimento em instalações sem adaptação suficiente

**Arquivo:** `AITeamFinancialEngine.kt`

A política antiga tratava a expansão do Centro Comercial como etapa obrigatória até o nível 3, independentemente da competitividade. A nova seleção compara Research, Factory, Marketing, Wind Tunnel, Simulator, Driver Development e Scouting em uma lista ranqueada. Uma equipe que perdeu pelo menos cinco pontos em relação ao perfil inicial reduz drasticamente a prioridade de Marketing; Pesquisa e Fábrica recebem peso extra pela perda de desempenho.

Antes de iniciar uma obra, a IA preserva caixa para salários e manutenção pendentes, custo operacional, reserva mínima, parcela planejada do próximo carro e limites do orçamento técnico anual.

### 3. P&D/fábrica abandonava pedido quando duas unidades não cabiam

**Arquivo:** `AITeamDevelopmentEngine.kt`

A quantidade planejada agora é registrada junto com o projeto. O cálculo de viabilidade tenta a quantidade desejada, depois reduz para uma unidade, respeitando caixa e teto técnico. A pesquisa só é impedida quando uma unidade também não pode ser fabricada. A checagem reserva antes o custo do design atual dentro do teto anual, para não aprovar duas unidades e descobrir somente depois que o orçamento técnico deixou espaço para apenas uma. A viabilidade também é reavaliada quando a pesquisa termina, com o custo da fábrica vigente; se duas unidades não cabem mais, tenta uma. A conclusão usa a quantidade final efetivamente aprovada.

A complexidade da pesquisa e o tempo de fábrica passaram a refletir o Overall físico atual da equipe, não apenas o perfil inicial.

### 4. Construção do próximo carro podia provocar colapso desproporcional

**Arquivo:** `CarDevelopmentEngine.kt`

A tabela universal de investimento permanece ativa. Para as equipes controladas pela IA, o resultado da tabela é comparado com um piso de continuidade calculado a partir do Overall do carro anterior e do percentual do custo de manutenção financiado.

- Sem investimento: a construção pode reduzir até 8 pontos de Overall, antes de outros efeitos independentes como regulamentação ou penalidade financeira.
- Financiamento parcial: a perda máxima é reduzida proporcionalmente.
- Cobertura integral do custo de manutenção: o piso impede que a falta de investimento reduza o Overall anterior.
- Investimento suficiente para um alvo superior: o resultado da tabela ainda pode superar o piso e melhorar o carro.

A regra de piso é aplicada tanto ao carro físico da IA quanto à representação legada usada em fluxos de compatibilidade.

### 5. Penalidade financeira inconsistente

**Arquivos:** `FinancialSeasonClosureEngine.kt`, `AITeamDevelopmentEngine.kt`

A rotina específica da IA aplicava uma redução simplificada apenas em motor e chassi. Agora o histórico da IA usa o mesmo mecanismo canônico da temporada financeira: -20% nos seis componentes, confiabilidade geral e confiabilidade por componente, mantendo peças ausentes em zero.

## Integração por modo

A rotina de investimento e evolução de equipes é compartilhada. A revisão atualizou os pontos de entrada da carreira principal em `MainActivity.kt` e o caminho Team Principal em `ManagerSeasonEngine.kt`, que agora fornecem o Overall físico atual e o estado do mercado de pilotos à decisão de instalações. Os três modos de jogo continuam usando a cadeia compartilhada do motor de equipes; não foi alterado o conjunto de modos ou suas regras de escolha inicial. No caminho Team Principal, a reconstrução também recebe o histórico persistido de aportes para o próximo carro, evitando que esse modo reconstrua temporadas anteriores como se o investimento tivesse sido zero.

## Testes adicionados

`app/src/test/kotlin/com/f1teammanager/core/manager/AITeamInvestmentV652Test.kt` contém sete regressões focadas:

1. o orçamento real corrente não é substituído no replay histórico;
2. o piso de continuidade varia progressivamente com o investimento;
3. a garagem física não sofre queda superior a oito pontos apenas por investimento zero;
4. fabricação de duas unidades reduz para uma quando necessário, e cancela somente quando uma unidade também não cabe;
5. o teto anual considera o custo de P&D já reservado ao dimensionar a fabricação;
6. penalidade financeira alcança os seis componentes e confiabilidade;
7. equipe em forte declínio prioriza recuperação técnica em vez de expansão comercial.

## Verificações executadas e limites

As verificações estáticas `validate_project.py`, `final_release_audit.py`, `v651_sponsorship_ai_audit.py` e `v652_ai_investment_audit.py` são usadas para validar estrutura, metadados, contratos de código e preservar a correção de patrocínios da V651. O resultado de execução consta na resposta de entrega.

**Limite importante:** o ambiente desta sessão não dispõe de Gradle nem de Gradle Wrapper configurado. O teste JUnit foi incluído, mas não foi executado. Também não houve build completo Android, APK, nem teste em aparelho. A simulação original da Red Bull não pode ser reproduzida sem o save correspondente; os testes estáticos não devem ser interpretados como uma reprodução de três temporadas da carreira real.
