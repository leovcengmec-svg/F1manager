# Auditoria V549

## Alterações verificadas no código
- `AnnualCarRegulationEngine.generate`: nos anos decenais, `annualEvents` é uma lista vazia.
- `teamAdaptationReductionPercent`: produz valor de 0 a 8 usando semente estável formada pela equipe e temporada, sem alterar temporadas comuns.
- `applyToCar` e `applyToGarage`: aplicam regra anual somente fora dos anos decenais; em ano decenal, aplicam reduções decenais e a margem aleatória específica da equipe.
- `MainActivity`: passa o ID da equipe do jogador à aplicação.
- `AITeamDevelopmentEngine`: passa a identidade estável de cada equipe de IA para o carro físico e para o estado legado.
- Tela do regulamento atualizada para explicar que a regra decenal substitui a anual e que há variação por equipe.
- Testes-fonte atualizados para a exclusividade decenal e para o intervalo/determinismo da margem.

## Limitações
- Não foi executado Gradle, compilação Android nem testes automatizados.
- A integridade estrutural do ZIP será verificada na geração do pacote.
