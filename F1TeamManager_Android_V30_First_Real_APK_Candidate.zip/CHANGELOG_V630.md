# V630 (0.630.0)

- Adicionado card de resumo do Team Principal com arte genérica realista em baixa opacidade e estatísticas agregadas: títulos de pilotos/construtores, vitórias, poles e pódios.
- Aumentado o card de prestígio para parar de cortar as informações existentes, sem substituir o conteúdo original.
- A lista de conquistas no corpo principal foi substituída por um botão que abre um painel com as oito conquistas.
- Os objetivos da diretoria agora exibem estado verde/vermelho conforme progresso ao vivo quando existe fonte confiável; estados sem dados ficam neutros. Toque expande informações do objetivo.
- Preservada a rolagem vertical da tela Minha Carreira.
