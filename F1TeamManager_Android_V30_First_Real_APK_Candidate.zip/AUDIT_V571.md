# V571 — Asset cache identity audit

## Root cause
ExternalAssets cached team logos using only `team:<id>` and car visuals using only `car:<id>`. When a custom team retained its permanent ID but its registered shield asset or display name changed, the existing bitmap could be returned without consulting the updated candidate filenames.

## Change
Cache keys now include the custom team's registered logo asset and normalized display name for logos, and normalized display name for car visuals. The existing candidate resolution order and external folders are unchanged. `clearMemoryCache()` remains available for full invalidation.

## Risk and validation
The change may keep older bitmaps in memory until normal cache clearing, but no longer returns them for the updated identity. Source-level regression tests were added. Android compilation, JUnit execution, and device verification were not performed.
