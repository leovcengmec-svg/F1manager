# V132 — Randomização real do carro inicial

## Regra
- As 40 equipes mantêm seus níveis oficiais: 11 Forte, 14 Médio, 15 Fraco.
- A construção inicial não usa mais força histórica/legada para os componentes do TeamDefinition.
- O carro efetivo é sempre derivado de InitialTeamProfile.
- Cada nova carreira recebe um seed próprio, persistido junto ao seed do calendário.
- Dentro do mesmo nível, os seis componentes são sorteados independentemente dentro da faixa oficial.
- Assim, nenhuma equipe é pré-programada para ser a mais forte em todas as carreiras.

## Faixas
- Forte: 56..60
- Médio: 48..55
- Fraco: 40..47

## Preservado
- Níveis iniciais.
- Orçamento por nível.
- Instalações por nível.
- P&D e demais sistemas que consomem InitialTeamProfile.
- Nenhum sistema de corrida, pneus, estratégia ou interface foi alterado.
