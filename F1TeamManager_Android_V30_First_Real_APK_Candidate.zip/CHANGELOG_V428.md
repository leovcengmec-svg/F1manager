# V428 — Recuperação da janela final da virada

- Corrigida a janela de interrupção em que todos os estados da nova temporada já foram persistidos (`STATE_PERSISTED`), mas o aplicativo fechou antes de limpar o diário da virada.
- Na repetição da ação, o sistema agora valida a temporada de destino e limpa somente o diário pendente, sem executar novamente a regressão, construção do carro, pagamentos, transição do mercado ou investimentos.
- Etapas anteriores à persistência completa continuam bloqueadas para recuperação assistida; não há promessa de rollback transacional completo nesta versão.
- Nenhuma mudança de layout; histórico e assets preservados.
- Compilação/testes não executados neste ambiente.
