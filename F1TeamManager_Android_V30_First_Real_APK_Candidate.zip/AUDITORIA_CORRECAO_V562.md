# Auditoria de correção — F1 Team Manager V562

## Correção de interpretação

O problema foi uma confusão entre o **desempenho do componente** e a **versão da peça**.

- O desempenho inicial vem do perfil da equipe selecionada: Forte (56–60), Médio (48–55) ou Fraco (40–47), com variação determinística por equipe/carreira.
- A versão inicial de cada um dos seis componentes é V0.
- A primeira pesquisa de um componente cria um design V1.
- Pesquisa e fabricação não alteram o carro físico. A nova performance só entra no Carro 1 ou Carro 2 quando a peça fabricada é instalada.
- Jogador e IA começam com os seus desempenhos-base; não existe mais carro do jogador zerado por causa do uso de V0.

## Código corrigido

- `app/src/main/java/com/f1teammanager/core/manager/InitialTeamProfile.kt`: o perfil inicial é aplicado ao carro legado do jogador e da IA.
- `app/src/main/java/com/f1teammanager/core/manager/CarGarageModels.kt`: todos os seis componentes começam com desempenho-base e metadados de hardware V0.
- `app/src/main/java/com/f1teammanager/CareerPreferences.kt`: recupera carreiras criadas incorretamente pela V561 com o carro legado/garagem em zero e converte starters `INIT-*` antigos para V0 sem apagar o desempenho.
- `app/src/main/java/com/f1teammanager/core/manager/ManagerModels.kt`: comentário de normalização corrigido para não misturar versão e desempenho.
- `app/src/test/kotlin/com/f1teammanager/InitialCarStartsAtVersionZeroV562Test.kt`: testes de regressão para o desempenho por nível, V0, primeira pesquisa V1 e o carro permanecer inalterado antes da instalação.
- `app/src/test/kotlin/com/f1teammanager/core/manager/V86RootIntegrationAuditTest.kt`: fluxo antigo de P&D atualizado para verificar a preservação do desempenho-base.

## Validações executadas

- `validate_project.py`: **40/40**.
- `final_release_audit.py`: **25/25** verificações estruturais.
- `v448_game_cycle_audit.py`: **18/18**.
- `v498_ai_persistence_audit.py`: **8/8**.
- `v440_financial_continuity_audit.py`: **13/13**.
- `v441_financial_model_audit.py`: **7/7**.
- `audit_v429.py`: **9/9**.
- `audit_v445_regulation.py`: **4.772/4.772** asserções.
- Testes de stress financeiro V438/V439: **PASS** nos cenários Python.
- `v562_piece_version_audit.py`: **13/13** contratos da nova regra.
- Integridade do ZIP após reempacotamento: verificada sem erro.

## Limitação

A compilação Android e a execução de JUnit/Kotlin no runtime não foram feitas nesta sessão: o projeto não tem Gradle Wrapper e o ambiente não dispõe de Gradle/Android SDK. Os resultados listados são validações estáticas/auxiliares, não certificação de execução no dispositivo.
