# Auditoria V598

## Causa raiz
A regra de integridade tratava todo ID de 1 a 100 como piloto pertencente à base oficial e, portanto, proibido em equipes personalizadas. Isso confundia identidade oficial com vínculo a uma equipe. Os IDs 81–100 representam o mercado/reservas e ficam livres quando não estão presentes em um roster.

## Correção
A validação usa agora os IDs atualmente presentes nos rosters das 40 equipes oficiais como conjunto de pilotos efetivamente vinculados. O mercado oficial continua reconhecido para colisões de IDs e nomes, mas pode ser contratado. A recuperação só clona pilotos oficiais que estão atualmente vinculados a um assento oficial.

A edição de equipe aceita pilotos de qualquer roster e faz uma troca com o piloto deslocado, atualizando o roster de origem e o destino. A operação salva as alterações de roster e os vínculos personalizados em uma transação síncrona, restaurando os snapshots em caso de falha de gravação.

## UI
Botões de abas, backup, diagnóstico, recuperação e inclusão têm alturas explícitas e rótulos de linha única para impedir quebra e alturas divergentes.

## Validação
- Inspeção estática do código e das referências alteradas.
- Teste de regressão adicionado para o piloto livre ID 89.
- A compilação Android/JUnit ainda não foi executada nesta sessão. Executar o workflow Build Debug APK antes de considerar o pacote certificado.
