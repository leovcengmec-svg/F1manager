# V441 — Registro de auditoria

Escopo desta entrega: endurecer os testes do modelo financeiro que atende às 40 equipes.

- Premiação de construtores: teste para valores únicos e estritamente decrescentes do P1 ao P40, mantendo os limites de €100 milhões e €10 milhões.
- Custos por GP: teste contra o nível canônico de cada equipe (forte, média ou pequena).
- Orçamento inicial: teste de validade para todas as equipes do banco de dados.
- Auditoria Python: verifica presença dos contratos de código e versão 0.441.0.

**Não alegar como executados:** compilação APK, JUnit/Kotlin, simulação integrada de 60 GPs ou teste real de interrupção/restauração. O ambiente desta execução não possui Gradle/Android SDK.
