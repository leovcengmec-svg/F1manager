# V520 — correção visual da tela de fim de temporada

- Substituído o carro específico de equipe no banner por uma ilustração genérica de encerramento de campeonato (troféu, pódio e bandeira quadriculada).
- Substituídos os ícones simples dos quatro cards de grandes acontecimentos por ilustrações próprias: títulos, vitórias, GP/abandono e pole position.
- Mantidos os títulos em uma linha: `Títulos`, `+ Vitórias`, `GP + Abandonos`, `+ Poles`.
- Mantidos os quatro cards com dimensões e estrutura iguais e o texto com truncamento em vez de quebra de linha.
- Recursos adicionados em `app/src/main/res/drawable-nodpi/` e referenciados diretamente pela tela.
- Não altera dados de temporada, estatísticas, saves ou regras de jogo.
