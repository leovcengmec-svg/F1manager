import com.f1teammanager.core.manager.*
fun main(){
 val se=TeamSponsorshipEngine()
 val fe=AITeamFinancialEngine()
 val market=DriverMarketState()
 val team=2
 val s=se.forTeam(team,2026)
 val before=fe.state(team,2026).finance.budget
 fe.applySponsorshipSignings(team,2026,s)
 val after=fe.state(team,2026).finance.budget
 check(after-before==s.sponsors.sumOf{it.upfront}) { "initial upfront mismatch ${after-before} vs ${s.sponsors.sumOf{it.upfront}}" }
 fe.applySponsorshipSignings(team,2026,s)
 check(fe.state(team,2026).finance.budget==after) { "double charge" }
 val s2=se.advanceRace(team,2026,1)
 val before2=fe.state(team,2026).finance.budget
 fe.applySponsorshipSignings(team,2026,s2)
 val expectedNew=s2.sponsors.filter{a->s.sponsors.none{b->b.name==a.name}}.sumOf{it.upfront}
 check(fe.state(team,2026).finance.budget-before2==expectedNew) { "replacement mismatch" }
 println("SponsorUpfrontIntegrationTest: PASS")
}
