# Auditoria V595 — Salvamento, exportação e importação sem mistura de modos

## Resultado
O formato de backup passou de schema 1 para schema 2. O cabeçalho agora declara o modo e o identificador persistente da carreira, além de equipe e temporada. A tela de gerenciamento apresenta o modo de cada arquivo e usa a validação central antes de importar, carregar ou exportar.

## Proteções introduzidas
1. **Identidade de carreira:** cada novo jogo recebe um UUID, persistido nas preferências e no envelope. Nomes de snapshots incluem modo, equipe, temporada e ID completo.
2. **Modo consistente:** `FREE`, `HARD` e `TEAM_PRINCIPAL` devem coincidir entre cabeçalho e `preferences.activeGameMode`.
3. **Estado específico do Time Principal:** exige estado de carreira gerencial decodificável, equipe ativa correspondente e coerência da proposta pendente. Saves Livre/Difícil não podem carregar estado/handoff gerencial residual.
4. **Validação antes de substituir:** formato, schema, tipos, equipe, temporada, modo, ID e arquivo histórico são inspecionados antes do commit nas preferências ativas.
5. **Compatibilidade:** schema 1 continua sendo aceito. O modo é obtido do marcador salvo; se não houver marcador, estado gerencial válido indica Time Principal e os saves antigos sem estado gerencial são migrados como Livre. O marcador e um ID estável derivado do payload são persistidos na importação. Se os dados contradisserem o modo declarado, o arquivo é recusado.
6. **Histórico e rollback:** o arquivo histórico continua incluído no backup. Falhas ao aplicar o histórico restauram as preferências e o arquivo anterior.
7. **Arquivos:** snapshots e imports são gravados por `AtomicFile`, evitando substituir o arquivo existente por um arquivo incompleto.

## Testes
`tools/save_test/v595_save_mode_contract_test.py` contém verificações estáticas do contrato de formato, fixtures para os três modos e detecção de divergência. Esses checks não equivalem à execução da classe Android em runtime.

## Limitações
Não há Gradle wrapper, Gradle instalado, Android SDK ou ADB disponíveis no ambiente. Portanto, a compilação Android, testes JUnit e validação real de importar/exportar no dispositivo ainda precisam ser executados antes da homologação.
