# V431 — Auditoria integrada da virada

- Adicionados testes de contrato entre o orquestrador Android, o motor de criação do carro e a tabela de referência de Overall 40–100.
- Verificada por teste-fonte a ordem regressão da temporada encerrada → avanço/reset → construção do carro novo → recálculo do teto técnico → persistência.
- Verificada a ordem das gravações canônicas antes de `STATE_PERSISTED` e da limpeza do diário.
- Verificados os caminhos distintos de rollback antes do commit final e limpeza idempotente após `STATE_PERSISTED`.
- Sem mudanças de layout; assets e histórico preservados.
