# V420 — Escala de investimento do próximo carro

- Ajustadas as referências de Manter Força para a faixa de € 8 milhões a € 150 milhões, escalonadas por classe do carro atual.
- O limite de investimento acumulado e a normalização do estado da carreira agora aceitam até € 150 milhões.
- Mantida a lógica de previsão de classe baseada na proporção entre investimento e referência.
- Atualizado teste para validar os extremos e a referência da classe média.
