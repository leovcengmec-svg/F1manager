# Auditoria V624 — cards de regulamento e modal de renovação

## Problemas reproduzidos nas capturas

1. `CarRegulationEventScreen` não aplicava `statusBarsPadding()` nem `navigationBarsPadding()`. Assim, em aparelhos com áreas de sistema proeminentes, o título encostava/colidia visualmente com os ícones superiores e o botão podia ficar muito próximo da navegação inferior.
2. `AnnualCarRegulationEventCard` fixava a arte em `height(164.dp)` com `ContentScale.Crop`. As artes do regulamento são 600×330 e trazem uma faixa de informação na parte inferior, que era cortada por esse recorte.
3. O diálogo de renovação dependia de uma condição genérica por `contains`, sem uma regra explícita no início do mapeamento de arte. O modal agora mapeia primeiro títulos normalizados `RENOVAÇÃO DE CONTRATO`, `CONTRATO ASSINADO`, `CONTRATO FECHADO` e `TRANSFERÊNCIA CONFIRMADA` à arte de assinatura, e renderiza o asset em proporção panorâmica 730×280.
4. A caixa do diálogo não tinha limite explícito de altura/rolagem interna para textos longos; agora respeita uma altura máxima e permite que todo o conteúdo continue acessível.

## Arquivos alterados

- `app/src/main/java/com/f1teammanager/core/manager/CarRegulationEventScreen.kt`
- `app/src/main/java/com/f1teammanager/core/manager/AnnualCarRegulationEventCard.kt`
- `app/src/main/java/com/f1teammanager/MainActivity.kt`
- `app/build.gradle.kts`
- `CHANGELOG.md` e `CHANGELOG_V624.md`

## Preservação

Não foram alterados o motor de regras anuais/decenais, a geração de eventos, os resultados de simulação, o mercado de pilotos ou os saves. Não foi criado nenhum asset novo. Os 195 assets da V623 devem continuar com hashes idênticos.

## Validação realizada

- Confirmado `versionCode=624` e `versionName=0.624.0`.
- SHA-256 comparado entre V623 e V624: os 195 arquivos de `app/src/main/assets` são idênticos.
- O ZIP final contém todos os 1.344 arquivos do diretório de trabalho, sem entradas de arquivos ausentes, extras ou conteúdo divergente.
- `unzip -t` finaliza sem erros; os arquivos `settings.gradle.kts`, `build.gradle.kts` e `gradle.properties` estão na raiz do pacote.
- Build Android completo (`assembleDebug`) e teste visual em dispositivo continuam pendentes, pois não há Gradle/Gradle Wrapper nem Android SDK disponíveis neste ambiente.
