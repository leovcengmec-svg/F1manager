# Changelog V373 — Entrada real da simulação instantânea e consistência sazonal

- Criado `InstantSimulationService.simulateWeekendInstantly(...)`, ponto de entrada que inicializa uma sessão nova, valida os 80 participantes e executa qualificação + corrida sem exigir a passagem pela tela interativa de qualificação.
- `MainActivity.simulateWeekendInstantlyForCareer()` agora chama esse ponto de entrada e sincroniza o estado semanal da IA quando parte de um calendário sem sessão ativa ou de uma sessão concluída. Também impede simular um GP antes da semana oficial do calendário.
- Mantida a validação completa antes de aplicar bônus de qualificação e demais efeitos à carreira.
- Corrigida a leitura de resultados antigos: o alias legado `race_<round>` só pode ser usado como fallback na temporada 1; temporadas posteriores usam exclusivamente a chave canônica sazonal.
- Adicionados testes para entrada direta do calendário, política de chaves sazonais e finalização ordenada de 60 GPs com callbacks repetidos e retry de etapa interrompida.
- Atualizada a versão Android para 0.373.0.
- Nenhuma alteração de interface ou botões nesta etapa; assets externos e histórico anterior preservados.
