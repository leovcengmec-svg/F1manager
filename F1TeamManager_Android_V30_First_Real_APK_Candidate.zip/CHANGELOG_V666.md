# V666 — estratégia individual de pneus da IA

- Cada piloto controlado pela IA recebe um plano próprio de compostos e duração dos stints antes da largada.
- A escolha considera conservação de pneus, velocidade, consistência, ultrapassagem, defesa, força do carro/equipe e posição no grid; perfis mais conservadores podem selecionar duas paradas, enquanto perfis mais agressivos podem optar por três.
- Em pista seca, os planos exploram diferentes combinações de SOFT, MEDIUM e HARD, respeitando a regra de utilizar ao menos dois compostos distintos e limitando a estratégia normal a até três paradas.
- Em chuva, a IA utiliza o composto adequado e individualiza as janelas de parada conforme a vida estimada do pneu e o perfil do piloto.
- As paradas programadas seguem a duração de cada stint; desgaste crítico, mudança de clima e Safety Car podem antecipar a parada e recalcular o restante da estratégia.
- Furo de pneu e relargada após bandeira vermelha reiniciam o planejamento individual da IA.
- Os planos da IA ficam separados dos planos editáveis do jogador; a interface e o controle estratégico da equipe do jogador permanecem inalterados.
- Adicionados testes para diversidade de estratégias, diferenças entre companheiros, adequação à chuva e cobertura integral dos planos dos 78 pilotos da IA.
