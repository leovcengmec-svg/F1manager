# V388 — Controle de avanço do calendário e retorno para Home

- O botão **PULAR ATÉ PRÓXIMO GP** fica desativado quando a semana atual é a semana do GP. Ele volta a ficar disponível depois que a corrida é simulada, confirmada e o calendário avança para o próximo GP.
- O resultado da corrida, tanto no modo manual quanto na simulação instantânea, agora oferece **VOLTAR PARA HOME**.
- Ao confirmar o resultado, a navegação retorna sempre à Home, inclusive após o encerramento da temporada. O calendário segue acessível pela navegação inferior.
- Nome fixo do ZIP de entrega preservado.
