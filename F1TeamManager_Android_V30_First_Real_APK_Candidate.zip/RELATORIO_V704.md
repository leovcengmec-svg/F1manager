# F1 Team Manager V30 — V704

Base: V703. Nome público do aplicativo e nome padrão do ZIP preservados.

## Alterações aplicadas
- Versionamento Android atualizado para `versionCode 704` / `versionName 0.704.0`.
- Pneus iniciais do Q1 agora respeitam o clima: compostos secos em pista seca/nublada, intermediários em chuva leve/moderada e WET em chuva forte.
- A classificação interativa e a instantânea usam a mesma linha do tempo de avanço por relógio e checkpoints climáticos alinhados.
- Todos os pilotos, incluindo os dois pilotos da equipe do jogador, recalculam automaticamente Ataque, Equilibrado ou Poupar a cada volta.
- A decisão automática considera projeção de combustível até a bandeirada e reserva, desgaste dos pneus, clima, fase e posição na prova, atributos do piloto e proximidade de adversários.
- Combustível crítico não interrompe a prova nem pede comando manual; o piloto ativa Poupar e informa a equipe por rádio.
- O rótulo visual de `DEFENSE` passa a ser `POUPAR`. O identificador interno foi mantido para preservar compatibilidade; o atributo técnico Defesa do piloto não foi alterado.
- Removidos os callbacks de seleção manual de ritmo da `MainActivity`. As APIs legadas `setStrategy` e `setPlan(mode=...)` não podem sobrescrever a decisão automática.
- Em bandeira vermelha, o gestor escolhe plano e pneus; a postura de relargada permanece automática.
- Planos de pneus, seleção de compostos e decisões de box continuam independentes do perfil de ritmo.

## Verificações direcionadas
- Compilação Kotlin direcionada do motor atualizado: aprovada.
- Grid da classificação manual versus instantânea (80 pilotos): idêntico.
- Q1 iniciado em chuva leve: intermediários selecionados corretamente.
- Corrida instantânea de 8 voltas: concluída em 8/8.
- Corrida manual de 58 voltas: concluída; Ataque, Equilibrado e Poupar observados; nenhuma solicitação manual de combustível crítico; 80 classificados.
- APIs legadas de ritmo manual: não alteram o modo calculado pelo piloto.

## Limitações de validação
O ambiente não contém `gradlew`, Gradle CLI ou Android SDK configurado. Não foi possível executar o build Android completo, a suíte JUnit integral ou gerar APK local nesta sessão. As verificações acima foram realizadas com compilação Kotlin e harnesses comportamentais direcionados do motor; não equivalem a uma APK compilada ou a testes em dispositivo.
