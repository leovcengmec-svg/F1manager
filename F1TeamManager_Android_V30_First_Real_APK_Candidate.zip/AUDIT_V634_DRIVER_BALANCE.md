# Auditoria V634 — Pilotos, ratings iniciais e evolução

## Escopo

Correção aplicada sobre a base oficial V633. O objetivo foi eliminar o efeito pelo qual a classe do piloto substituía seu rating real e limitava permanentemente a evolução. Foram preservadas as estruturas de save e os 100 perfis do catálogo. Esta auditoria combina leitura de código, testes JVM direcionados e verificação da estrutura do pacote; não substitui uma compilação Android nem uma simulação completa de campeonato no aplicativo.

## Causas corrigidas

### 1. Ratings iniciais

Antes, `DriverProfileCatalog.profile()` normalizava cada conjunto de ratings para 75% do teto da classe. Assim, todos os pilotos da mesma classe começavam com Overall igual, independentemente dos dados cadastrados. Além disso, os mapas `current` e `reserveRatings` de `WorldDatabase.kt` existiam, mas não eram usados na montagem real dos pilotos.

Agora:

- Os sete ratings individuais são preservados, sem reescalonamento pela classe.
- O mapa de ratings atuais é aplicado aos pilotos titulares aos quais se refere.
- O mapa de ratings de reserva/mercado é aplicado ao conjunto de reservas.
- Foi acrescentada uma calibração explícita de ratings de auge para pilotos históricos cujos registros legados subestimavam seu desempenho no período pretendido.
- Os ratings continuam limitados à faixa válida de 40 a 100.

### 2. Classe versus potencial

`DriverDefinition` agora possui `potentialOverall`. O campo é calculado a partir do Overall individual e do estilo de evolução do perfil, com uma faixa mínima por estilo e limite superior 100; não é derivado da classe. A classe continua disponível para reputação e regras de mercado, mas deixou de definir o teto de evolução esportiva.

Estimativa de potencial por estilo:

| Estilo | Headroom de referência | Piso de potencial |
|---|---:|---:|
| Prodígio | +12 | 92 |
| Auge rápido | +10 | 90 |
| Auge moderado | +9 | 88 |
| Auge tardio | +8 | 90 |
| Normal | +7 | 84 |
| Demorado | +11 | 86 |

O potencial efetivo é o maior entre o Overall atual e o menor valor de `100`, `Overall + headroom` e o piso definido pelo estilo. Isso permite que pilotos iniciantes tenham espaço de evolução sem atribuir automaticamente Overall alto ao começar.

### 3. Evolução por GP e instalação

- `DriverEvolutionEngine.applyPositiveGain()` agora evolui até o potencial individual, com atributos individuais limitados a 100 e os limites de ganho anual mantidos.
- `DriverDevelopmentEngine` usa o mesmo limite de potencial. Pontos não são aplicados depois de o piloto chegar ao potencial.
- A fase inicial é `PEAK` quando o Overall já está a até três pontos do potencial; caso contrário é `GROWING`.
- O crescimento exige cinco temporadas mínimas e pode continuar até oito temporadas se o potencial ainda não for atingido. O auge continua em duas temporadas; a regressão, em cinco.
- O piso de regressão é individual (`potencial - 35`, limitado a 45–65), e não o piso de classe.
- As regras foram aplicadas tanto à carreira normal em `CareerPreferences.kt` quanto ao modo Team Principal em `ManagerSeasonEngine.kt`.
- O potencial aparece nas telas de mercado de pilotos, equipe e seleção para desenvolvimento.

## Verificação observável após a alteração

Ratings do elenco de 100 perfis (80 titulares + 20 reservas), calculados com a definição efetivamente carregada:

| Classe | Quantidade | Overall observado | Overalls distintos |
|---|---:|---:|---:|
| Lenda | 11 | 92–97 | 6 |
| Pro | 24 | 72–96 | 14 |
| Forte | 27 | 69–94 | 15 |
| Médio | 38 | 58–87 | 14 |

As classes agora têm distribuições sobrepostas: há pilotos Pro e Forte com Overall superior ao de pilotos Lenda cadastrados mais baixos. Os pilotos atuais que tinham ratings próprios voltaram a usar esses valores: por exemplo, Lando Norris começa com os ratings de velocidade 92 e classificação 93, em vez de ser reduzido para o Overall fixo da classe. Os ratings de reserva também são usados no modelo real.

Exemplos de estado inicial conferidos no catálogo e no banco:

| Piloto | Classe | Overall inicial | Potencial | Fase inicial |
|---|---|---:|---:|---|
| Max Verstappen | Lenda | 95 | 100 | Crescimento |
| Lewis Hamilton | Lenda | 93 | 100 | Crescimento |
| Lando Norris | Pro | 86 | 95 | Crescimento |
| Charles Leclerc | Pro | 87 | 97 | Crescimento |
| Isack Hadjar | Forte | 80 | 89 | Crescimento |
| Michael Schumacher | Lenda | 97 | 100 | Auge |
| Ayrton Senna | Lenda | 97 | 100 | Auge |
| Nico Rosberg | Pro | 93 | 100 | Crescimento |
| Jim Clark | Pro | 96 | 100 | Crescimento |

Isso corrige o viés de dados e remove o bloqueio artificial por classe; não prova, sozinho, a distribuição final de campeonatos. Uma simulação multitemporada segue necessária para medir títulos, vitórias, pódios e influência do carro.

## Testes executados

O compilador Kotlin compilou isoladamente os modelos de corrida e temporada, catálogo, banco de pilotos, motor de evolução, motor da instalação de desenvolvimento e três testes JVM atualizados. Resultados:

- `Stage1Initial75PercentTest` (agora validando ratings individuais, os 100 perfis, mapas de ratings atual/reserva e potenciais): passou.
- `DriverEvolutionPerformanceV604Test` (atualizado para os novos ratings e potenciais; inclui teste de evolução de classe Pro acima de 89 e teste da instalação): passou.
- `DriverEvolutionSafetyV603Test` (atualizado para validar limites individuais e regressão): passou.

Avisos Kotlin restantes são parâmetros já não utilizados em `evaluate()` e `recoveryCap()`; não são erros de compilação.

## Validações não executadas

- A compilação Android `assembleDebug` não pôde ser executada: este ambiente não tem Gradle/Gradle Wrapper nem `ANDROID_HOME`/SDK Android disponíveis.
- Não foi executada uma simulação de quatro temporadas no runtime do jogo. Por isso, não afirmo ainda que a distribuição real de títulos foi validada em corrida.
- O pacote ZIP será validado quanto à integridade estrutural e aos recursos preservados, mas isso não substitui o teste no dispositivo.

## Arquivos principais alterados

- `DriverProfileCatalog.kt`
- `WorldDatabase.kt`
- `SeasonModels.kt`
- `DriverEvolutionEngine.kt`
- `DriverDevelopmentEngine.kt`
- `CareerPreferences.kt`
- `ManagerSeasonEngine.kt`
- `ManagerModels.kt`
- `MainActivity.kt`
- `app/build.gradle.kts`
- testes JVM relacionados a perfil e evolução
