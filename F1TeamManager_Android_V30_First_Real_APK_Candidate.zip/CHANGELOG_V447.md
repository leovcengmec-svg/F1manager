# V447 — Layout compacto do próximo carro

- Reformulada a tela `NextSeasonCarScreen` com cards padronizados e identidade visual existente do jogo.
- Tela principal do próximo carro usa `Column` sem rolagem vertical, com conteúdo compacto para telas de smartphone.
- Os dados exibidos vêm do `CarDevelopmentEngine` e do estado financeiro real: Overall, classe atual/projetada, referência de manutenção, investimento acumulado e teto.
- Card de efeito do investimento relaciona o percentual da referência à variação prevista de classe.
- Mantidas as quatro opções de foco já implementadas no jogo; não foram criados focos nem investimentos por componente fictícios.
- Botões de aporte rápido consideram teto absoluto, limite cumulativo da fase e reserva operacional antes de habilitar o aporte; o motor continua validando a operação.
- O acesso ao próximo carro foi movido para o final da lista de CARRO / P&D, com imagem genérica de fundo e texto “DESENVOLVIMENTO DO CARRO DO PRÓXIMO ANO”. A navegação usa o callback já conectado a `Screen.NEXT_CAR`.
- Preservados o histórico de versões, os assets existentes, a pesquisa de componentes e os sistemas de corrida.
- Versão atualizada para `447` (`0.447.0`). Nome fixo do ZIP preservado: `F1TeamManager_Android_V30_First_Real_APK_Candidate.zip`.

## Validação
- Inspeção estática de navegação, callback, nomes de recursos e referências ao motor: realizada.
- Compilação Android e testes automatizados não executados: o pacote não inclui Gradle Wrapper e este ambiente não disponibiliza o ambiente completo de build Android.
