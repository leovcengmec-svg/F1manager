# V459 — Modo de carreira ao iniciar novo jogo

- Novo Jogo agora abre a escolha entre Modo Livre e Modo Difícil.
- Modo Livre mantém a seleção de todas as 40 equipes.
- Modo Difícil limita a seleção às três equipes com menor força média inicial calculada pelo mesmo modelo de carro inicial usado no ranking.
- As outras 37 equipes não aparecem como opção no Modo Difícil.
- A seleção final continua usando o fluxo de criação de carreira existente.
- Versão Android: 0.459.0 (versionCode 459).
