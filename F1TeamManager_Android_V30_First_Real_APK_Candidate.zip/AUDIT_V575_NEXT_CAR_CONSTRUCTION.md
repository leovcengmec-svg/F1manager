# Auditoria V575 — construção do próximo carro

## Alterações verificadas estaticamente

1. `app/build.gradle.kts` declara `versionCode = 575` e `versionName = "0.575.0"`.
2. `CarDevelopmentEngine.startNextSeason` calcula `round(attribute * 0.10)` para cada componente e soma esse valor ao atributo correspondente.
3. A construção do `TeamGarage` calcula a transferência separadamente para cada carro físico, sem substituir os atributos individuais pela média.
4. `carryAiCarToNextSeason` usa a mesma regra de transferência de 10% por componente.
5. A transferência é aplicada antes do bônus de regulamento no cálculo final.
6. O teste de regressão V548 foi atualizado para verificar a nova herança de 10% e garantir que não exista compressão genérica de 70%.
7. A tabela de referência unitária de Overall 40 a 100 foi preservada.

## Exemplo de arredondamento

- 49 × 10% = 4,9 → 5 pontos herdados.
- 53 × 10% = 5,3 → 5 pontos herdados.
- 54 × 10% = 5,4 → 5 pontos herdados.

## Limitações da validação

A validação desta entrega é estática. Não há `gradlew` no ZIP oficial; a compilação Android e a execução dos testes JUnit não foram realizadas neste ambiente. O ajuste numérico que converte a proporção de investimento em um Overall inicial contínuo não foi redefinido nesta entrega; foram preservadas as funções existentes de referência, classe, passos de investimento e foco técnico, adicionando-se a transferência de 10% acordada.
