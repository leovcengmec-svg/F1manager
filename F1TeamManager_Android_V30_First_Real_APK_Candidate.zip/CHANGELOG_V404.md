# V404 — Novo layout compacto da tela de resultado

- Redesenhada a função `Result` em `app/src/main/java/com/f1teammanager/MainActivity.kt`.
- Adicionado pódio visual para P1, P2 e P3 usando os recursos existentes `DriverPhoto` e `TeamLogo`.
- Padronizadas largura e altura dos três cards do pódio, com destaque de cor para cada posição.
- Resumo da equipe, pontos conquistados, classificação compacta Top 5, estatísticas e botão fixo “VOLTAR PARA HOME”.
- Removida a rolagem vertical desta tela; o resultado completo continua preservado no modelo e no histórico, mas esta vista mostra os cinco primeiros para caber no ecrã.
- Sem alterações na lógica de corrida, pontuação, persistência ou navegação do botão.
