# V611 — Renovação de contrato na HOME

- A notificação `RENOVAÇÃO DE CONTRATO` passa a usar o mesmo card modal, layout e arte `notice_market_signed` já usados na assinatura de contratos.
- A renovação é identificada como evento do Mercado de Pilotos.
- Para manter os eventos da HOME exclusivos à equipe do jogador, a notificação de renovação só abre o card quando a mensagem corresponde à equipe do jogador.
- Mantida a lógica de negociação, contratos, finanças e simulação da V610; alteração restrita à apresentação/filtro da notificação na HOME.
- Versão: `versionCode = 611`, `versionName = 0.611.0`.
