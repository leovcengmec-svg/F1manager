# V629 — Ajuste cirúrgico da tela Minha Carreira

## Pedido
Restaurar o card principal de prestígio ao tamanho compacto aprovado na imagem 1. Aumentar somente os dois cards internos de Contrato e Metas Cumpridas para revelar os dados cortados.

## Alterações
- Card principal de prestígio: altura compacta restaurada para 120 dp (132 dp em telas maiores), em vez de 208/224 dp. Conteúdo, cores, ícones, métricas e disposição interna preservados.
- Cards Contrato e Metas Cumpridas: altura da linha aumentada de 38/42 dp para 58/62 dp.
- Card pai Objetivos da Diretoria: altura aumentada em 20 dp para acomodar os dois cards internos sem sobreposição.
- Rolagem vertical da página mantida para acessar as seções abaixo.
- Nenhuma alteração feita à lógica de prestígio, objetivos, conquistas, trajetória ou save.

## Validação
Versão 629 / 0.629.0. ZIP testado quanto à integridade. Compilação Android e inspeção visual em aparelho não executadas neste ambiente.
