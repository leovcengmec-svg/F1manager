# Auditoria V446 — Próximo carro

## Alterações
- Nova rota `Screen.NEXT_CAR` com `DetailScaffold`, retornando para `Screen.CAR`.
- Nova tela Compose `NextSeasonCarScreen`, usando paleta, cards e tipografia compacta do projeto.
- Entrada para a tela adicionada à área CARRO / P&D; pesquisas atuais permanecem no mesmo fluxo.
- Investimento e foco conectados às funções de domínio já existentes.

## Limites preservados
- Teto de investimento obtido do `CarDevelopmentEngine` (atualmente €150M).
- O motor de domínio continua sendo a autoridade para limites cumulativos por fase e proteção de caixa.
- A previsão usa o motor existente e não é apresentada como garantia de resultado.
- Construção, regulamento e ranking são descritos na ordem já estabelecida; a tela não executa antecipadamente essas etapas.

## Validação
- Inspeção estática dos pontos de navegação e callbacks: aprovada.
- ZIP será verificado por teste de integridade após empacotamento.
- Não declarar build APK aprovado: compilação Android e JUnit não foram executados neste ambiente.

## Pendências conhecidas
- Verificar visualmente em dispositivo Android.
- Corrigir o README geral, se houver referências de versão adicionais além das substituições realizadas.
