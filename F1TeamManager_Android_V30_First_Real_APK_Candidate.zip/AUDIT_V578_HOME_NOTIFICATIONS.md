# Auditoria V578 — Home e escalação Andretti

## Alterações
1. Removida a dependência entre os botões de P&D e patrocínio. Notícias/mercado, P&D e patrocínio podem aparecer simultaneamente, conforme elegibilidade.
2. O indicador de P&D conta sucesso e falha de projeto, incluindo `FALHA NO P&D — DESIGN NÃO CONCLUÍDO`.
3. O popup da Home já filtrava a falha de P&D por nome do time do jogador; o filtro foi mantido.
4. Verificada a escalação de `Andretti` no `WorldDatabase`: Sergio Pérez e Valtteri Bottas. Mario Andretti consta no grid sob `Cadillac Racing`, não sob `Andretti`; a relação errada não existe no cadastro atual.

## Verificações estáticas
- [x] versionCode 578 / versionName 0.578.0.
- [x] `rdCompletionCount` considera sucesso e falha de P&D.
- [x] Patrocínio é renderizado em condição independente do P&D.
- [x] Os botões não são limitados a dois por `else-if` entre categorias.
- [x] Título da falha continua no filtro de popup da Home.
- [x] Escalação Andretti não contém Mario Andretti.
- [x] Integridade do ZIP validada com `unzip -t`.

## Limitações
Validação estática apenas. Não foi executada compilação Android nem teste visual em dispositivo. O botão de patrocínio aparece quando há menos de cinco slots ativos; os botões de notícias/mercado e P&D aparecem quando há notificações não lidas correspondentes.
