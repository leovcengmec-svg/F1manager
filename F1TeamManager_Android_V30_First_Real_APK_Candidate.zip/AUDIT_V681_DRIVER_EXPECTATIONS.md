# Auditoria V681 — metas individuais de evolução

Base: V680
Versão: 681 / 0.681.0

## Diagnóstico corrigido

A V680 ranqueava diretamente os 80 pilotos por uma combinação global de força do carro e Overall/qualificação. A classificação individual podia, assim, deslocar demais a expectativa de um piloto e o motor recalculava os alvos a cada GP, inclusive depois que o piloto evoluía.

## Nova regra

- Primeiro são ordenadas as 40 equipes pela força média dos carros.
- Cada equipe ocupa duas posições-base entre os 80 pilotos: `P(2 × rank − 1)` e `P(2 × rank)`.
- A habilidade individual ajusta o centro da meta de classificação e de corrida em no máximo três posições.
- As metas continuam individuais: companheiros com capacidades diferentes recebem centros distintos.
- A tolerância foi padronizada em ±3 posições em toda a escala de P1 a P80.
- A função exige 40 equipes, duas vagas ativas por equipe e exatamente 80 pilotos.

### Conversão de referência

| Posição do construtor | Posições-base dos pilotos |
|---:|---:|
| P1 | P1 / P2 |
| P10 | P19 / P20 |
| P22 | P43 / P44 |
| P30 | P59 / P60 |
| P40 | P79 / P80 |

Para a equipe em P22, o ajuste de habilidade mantém os centros dentro de P40–P47. Um piloto que termina em P35 supera claramente a expectativa. Com centro P44 e resultados P35 tanto na classificação quanto na corrida, o índice é 135, acima do limiar de evolução acelerada (115).

## Metas congeladas durante a temporada

- Carreira: saves V680 usam o marcador V2; no primeiro GP após a atualização, as metas são recalculadas com a nova regra e salvas como V3. Depois disso, a função retorna as mesmas metas até a virada da temporada.
- A força do carro das equipes controladas pela IA usa o snapshot anual específico de cada equipe (`loadAnnualEventCarStats`), com o perfil inicial como fallback; não confunde o slot único do carro do jogador com os carros da IA.
- Team Principal / motor de temporada: as metas são calculadas com as garagens físicas reais preparadas para a etapa de abertura e mantidas no estado da temporada; a virada de temporada limpa o mapa para a geração seguinte.
- Melhorias de carro e ganhos de atributos continuam afetando os resultados reais, mas não deslocam retroativamente as próprias metas durante a temporada.

## Testes executados

- Auditoria estática específica: 17/17 verificações aprovadas.
- Smoke test Kotlin: 40 equipes, 80 pilotos, mapeamentos P1/P10/P22/P30/P40, ajuste entre companheiros e reconhecimento de P35 acima de P44: aprovado.
- Teste de regressão V674 retido, incluindo evolução de piloto de equipe fraca e proteção contra DNF mecânico: aprovado.
- Cinco testes JUnit adicionados em `DriverEvolutionV681Test.kt` para mapeamento, ajuste individual, desempenho P35, tolerância e validação da grade.

## Limitações

A suíte Gradle completa e a compilação Android não foram executadas localmente: o pacote não contém Gradle Wrapper e o ambiente não possui Gradle/Android SDK configurados. O workflow do GitHub Actions foi atualizado para executar `:app:testDebugUnitTest` e `:app:assembleDebug`, publicando o artefato V681. APK só deve ser considerado compilado depois que esse workflow terminar com sucesso.

## Identidade e pacote

- Nome público: **F1 Team Manager V30** (preservado).
- VersionCode: `681`.
- VersionName: `0.681.0`.
- ZIP: `F1TeamManager_Android_V30_First_Real_APK_Candidate.zip` (nome original preservado).
