# V381 — Limpeza da tela Home

- Removido da Home o card `CALENDÁRIO`, incluindo os botões de avanço de semana que duplicavam o acesso ao calendário.
- Removida da Home a seção `EQUIPE` com o card `PILOTOS TITULARES` e o atalho `VER PERFIL COMPLETO`.
- Mantidos os atalhos rápidos existentes, o card de próxima corrida e a navegação inferior.
- Nenhuma alteração intencional na lógica da carreira, no motor de corrida ou nos assets externos.
