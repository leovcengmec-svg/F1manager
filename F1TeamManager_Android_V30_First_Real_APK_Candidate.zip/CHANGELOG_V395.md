# V395 — Correção de compilação da Home

- Corrigida referência Kotlin não resolvida `roundIndex` no card de próxima corrida da tela Home.
- A Home agora consulta `store.roundIndex`, que é o índice de rodada disponível no escopo do composable.
- Atualizada versão Android para `0.395.0` (`versionCode = 395`).
- Mantida a imagem genérica de fábrica e as alterações anteriores.
- Sem alterações de layout nesta correção.
