# V595 — Saves identificados por modo e carreira

Base: V594 (`versionCode 594`, `versionName 0.594.0`).

## Alterações
- Novo formato de backup `F1TM_SAVE` schema 2 com `mode`, `careerId`, equipe, temporada e horário de criação no cabeçalho.
- Identificador único persistente por carreira; uma nova carreira recebe novo ID, evitando colisões de nomes entre carreiras diferentes com a mesma equipe/temporada/data.
- Exportação identifica o modo e valida o arquivo selecionado antes de exportar.
- Importação aceita schema 1 legado e schema 2, inspeciona todos os tipos e metadados antes de tocar no save ativo, e migra os saves legados para um marcador explícito de modo/ID.
- Saves de Time Principal exigem estado gerencial válido e coerência entre equipe ativa e estado da carreira; saves Livre/Difícil rejeitam dados residuais incompatíveis do Time Principal.
- Cabeçalho e dados internos precisam concordar sobre modo, equipe, temporada e ID de carreira; divergências são recusadas.
- A tela mostra o modo de cada save e bloqueia o carregamento/exportação de arquivos inválidos.
- Snapshots e imports são escritos com `AtomicFile` para reduzir risco de arquivo parcial.
- Arquivo histórico segue junto do backup e é restaurado com rollback se a gravação falhar.

## Validação
- Executados checks estáticos de contrato para os três modos, migração legada, rejeição de metadados divergentes, ordenação da validação antes do commit e identidade de arquivos.
- ZIP validado estruturalmente e assets/históricos comparados com a V594.
- Compilação Android, JUnit e teste em emulador não executados neste ambiente por ausência de Gradle/wrapper e Android SDK/ADB. V595 permanece candidata até validação Android integrada.
