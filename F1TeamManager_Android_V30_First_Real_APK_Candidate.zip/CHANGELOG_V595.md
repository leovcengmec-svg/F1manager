# V595 — persistência e portabilidade dos cadastros

- Adicionada exportação/importação JSON do catálogo completo: pilotos, equipes, bandeiras e substituições dos registros oficiais.
- A importação valida formato e estrutura JSON antes da escrita e mantém backup local durável dos valores anteriores. Se o catálogo importado tiver inconsistências semânticas, os dados são restaurados integralmente em modo de proteção para permitir diagnóstico e recuperação controlada, sem descarte automático.
- A recuperação controlada remapeia referências de pilotos oficiais em equipes personalizadas para cópias personalizadas com novos IDs, preservando o roster sem alterar a base oficial.
- Os formulários de nova equipe e novo piloto são limpos a cada abertura.
- País passou a ser selecionado de uma lista formada pelos países conhecidos no jogo, cadastros personalizados e bandeiras registradas.
- Ao editar piloto oficial, o campo de asset é preenchido com o override existente ou com o padrão de nome `NNN.png`.
- Preservado o conteúdo original em backups locais; nenhuma edição antiga é apagada silenciosamente.

## Validação

- Inspeção estática dos fluxos e sintaxe revisada.
- Compilação Android e testes JUnit não executados neste ambiente por ausência do Gradle/Gradle Wrapper.
- Importação real e persistência após reinstalação devem ser confirmadas no aparelho com um arquivo exportado.
