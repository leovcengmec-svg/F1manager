# V631 (0.631.0)

- Redesenhada a tela de avaliação contratual do Team Principal segundo o mockup aprovado.
- Incluído retrato discreto do chefe de equipe no card principal.
- Resultados recentes em duas colunas e propostas com escudos e controles uniformes.
- Tela sem rolagem vertical, com dimensões adaptativas para a área útil do telefone.
- Mantidos os callbacks existentes de renovação, aceite de oferta e retorno ao menu.
