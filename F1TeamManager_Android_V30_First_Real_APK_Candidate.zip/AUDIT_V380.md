# Auditoria V380

- Base: V379.
- Alteração limitada à composição da Home e à remoção do card de semana atual do Calendário.
- O resumo da semana usa `SeasonCalendar.forSeason(store.season)` e os callbacks existentes `onSkipWeek` e `onJumpNextRace`.
- O quadro apresenta a semana atual e até três semanas subsequentes, usando os dados reais do calendário da temporada.
- `versionCode=380`, `versionName=0.380.0`.
- Sem alteração de assets externos, motores de corrida, finanças ou histórico preexistente.
- Limitação: build Android e teste visual em dispositivo/emulador pendentes.
