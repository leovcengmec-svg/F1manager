# V336 — Ajustes de incidentes de corrida (patch de código, sem novo ZIP)

## Alterações
- A chance de iniciar uma colisão passou de 1,2% para 2,0% por volta em bandeira verde, ajustada pelo risco do circuito; continua sendo um sorteio global por volta, não um sorteio por piloto.
- Foi adicionado um sorteio de furo de pneu por GP com chance de 30%; o estado garante no máximo um furo por corrida. Quando ocorre, o carro faz uma parada emergencial com troca de composto e perda de 21 s.
- Foi adicionado evento de pane elétrica MGU-K - ERS, que provoca DNF. A chance global depende da confiabilidade elétrica média do grid; confiabilidade menor aumenta a probabilidade. No máximo uma pane elétrica é agendada por GP.
- Criada imagem genérica dedicada para pane elétrica e ligada ao registro de imagens do card universal de evento.
- Os cards identificam explicitamente “FURO DE PNEU” e “PANE ELÉTRICA • DNF”, com consequências específicas.

## Validação
- Verificações estáticas de fluxo, chaves de imagem, flags de evento único e referências ao recurso.
- Não foi gerado novo ZIP, conforme solicitado.
- Compilação Android e simulação de múltiplas temporadas não executadas nesta sessão.
