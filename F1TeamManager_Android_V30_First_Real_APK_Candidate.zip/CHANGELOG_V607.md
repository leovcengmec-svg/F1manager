# V607 — Evolução dos pilotos

## Alteração
Todos os pilotos cujo tipo de evolução no catálogo oficial era `Normal` agora usam `Auge moderado`. Foram alterados 53 perfis. A classe do piloto e seus sete atributos não foram modificados.

Também foi removida a exceção legada que reescrevia a evolução para `Normal` quando a classe original era `Fraco`; a normalização de classe permanece como estava. Nenhum outro tipo de evolução foi alterado.

## Validação
- Auditoria de catálogo: 53 alterações, zero perfis restantes com evolução `Normal`, todos os perfis e atributos preservados exceto o campo de evolução pretendido.
- A compilação Android completa e teste em dispositivo/emulador não foram executados neste ambiente.
- A validação funcional deve ser feita com **Novo Jogo**, sem excluir saves antigos.
