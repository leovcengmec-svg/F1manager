# V330 - Contract offer modal redesign

- Replaced the default Material AlertDialog for new driver offers with a custom compact Compose Dialog.
- Standardized duration and role choices into equal-size cards; removed the accidental vertical wrapping of the fifth duration option.
- Added existing driver photo, team label, contract season note, salary input and consistent action buttons.
- Disabled internal vertical/horizontal scrolling in the new offer dialog; text is single-line where appropriate and constrained to the available width.
- Preserved the existing onProposal callback and numeric salary state.
