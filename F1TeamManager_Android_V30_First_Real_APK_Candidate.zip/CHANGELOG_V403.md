# V403 — Aleatoriedade dos eventos por carreira

- Removidas as sementes fixas `20261010` do fluxo de eventos anuais de pilotos e equipes.
- Criada `CareerPreferences.annualEventSeed(season)`: gera um seed aleatório por carreira/temporada e o persiste para manter o calendário estável ao recarregar ou avançar semanas.
- O sorteio do calendário, alvo de equipe, piloto afetado, ganhos/perdas e mudança de classe usa agora a semente aleatória persistida daquela carreira/temporada.
- Ao iniciar uma nova carreira, são limpos calendário, semente e ledger de eventos anuais anteriores, impedindo que a nova carreira herde alvos/eventos processados.
- A lógica de idempotência dos eventos dentro da mesma carreira foi preservada.
- Nome oficial do ZIP de entrega mantido sem alterações.
