import com.f1teammanager.core.career.CareerRaceIntegration
import com.f1teammanager.core.race.*

fun main() {
    val circuit = RaceCircuit(1, "Teste", 40, 90000L, 1.0, 1.0, safetyCarRisk = 1.0)
    val drivers = (1..6).map { i ->
        RaceParticipant(i, "D$i", 1, "Equipe", 85+i, 82+i, 80, 80, 80, 80+i, 80, tyreWear = 55, reliability = 98)
    }
    var redSeen = false
    var completed = false
    var chosen = false
    for (seed in 1..80) {
        val game = CareerRaceIntegration(2026, circuit, drivers, playerTeamId = 1, seed = seed)
        var s = game.begin()
        game.setStrategy(1, DriverPosture.ATTACK, Tyre.MEDIUM)
        var guard = 0
        while (!s.completed && guard++ < 120) {
            s = game.advance()
            val d = s.decision
            if (d != null) {
                if (d.request.type == ManagerDecisionType.RED_FLAG) {
                    game.chooseRedFlag(Tyre.HARD, DriverPosture.DEFENSE)
                    redSeen = true
                    chosen = true
                } else {
                    game.choose(ManagerDecisionAction.BOX)
                }
                s = game.snapshot()
            }
        }
        if (s.completed) completed = true
        if (redSeen && completed) break
    }
    check(redSeen) { "Red flag decision was not exercised" }
    check(chosen) { "Red flag restart choice was not applied" }
    check(completed) { "Career weekend did not finish" }
    val result = run {
        val game = CareerRaceIntegration(2026, circuit, drivers, 1, 777)
        var x = game.begin()
        game.setStrategy(1, DriverPosture.BALANCED, Tyre.MEDIUM)
        var guard = 0
        while (!x.completed && guard++ < 120) {
            x = game.advance()
            val d = x.decision
            if (d != null) {
                if (d.request.type == ManagerDecisionType.RED_FLAG) game.chooseRedFlag(Tyre.MEDIUM, DriverPosture.BALANCED)
                else game.choose(ManagerDecisionAction.STAY_OUT)
                x = game.snapshot()
            }
        }
        game.result()
    }
    check(result.classification.size == 6)
    println("V22_SMOKE_OK redFlag=$redSeen classification=${result.classification.size}")
}
