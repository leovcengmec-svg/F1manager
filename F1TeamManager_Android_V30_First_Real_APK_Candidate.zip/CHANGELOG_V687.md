# v687 — mercado de pilotos realista e cards globais de contratos assinados

- A Home volta a exibir globalmente os desfechos de contrato de todas as equipes: contrato assinado, troca de equipe e renovação.
- Cards detalhados de proposta, recusa, contraproposta, expiração e encerramento continuam exclusivos das negociações que envolvem a equipe do jogador.
- Rejeições e expirações de propostas recebidas agora identificam explicitamente a equipe do jogador na mensagem, garantindo que o filtro de Home reconheça o evento correto.
- A IA passa a procurar oportunidades de transferência antes de decidir renovações; renovações de pilotos expirantes são avaliadas uma única vez, na fase final do mercado, e aguardam a conclusão de propostas rivais pendentes.
- O mercado de IA pode abordar uma parcela seletiva de pilotos ainda sob contrato quando existe uma melhoria esportiva relevante no carro projetado, com taxa de assinatura e fluxo normal de aceite preservados.
- A atividade de mercado considera a qualidade do elenco e a força esportiva da equipe, reduzindo o congelamento do grid após as primeiras temporadas sem impor cotas fixas de transferências.
- A virada da temporada usa o mesmo evento canônico de assinatura da negociação e evita duplicar cards já emitidos.
