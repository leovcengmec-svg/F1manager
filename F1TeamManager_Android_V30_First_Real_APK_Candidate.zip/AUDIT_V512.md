# Auditoria V512 — Cards de componentes

- [x] Imagem genérica à esquerda nos cards de designs concluídos e fábrica.
- [x] Imagem aplicada com alpha de 0.34 para manter a leitura do texto.
- [x] Informações e ações à direita da imagem.
- [x] Mesmo padrão de card (bordas, fundo, espaçamento e hierarquia visual) nas duas seções.
- [x] Catálogo continua usando a seleção da versão mais recente por componente.
- [x] Histórico de pesquisa, ordens e peças físicas não são alterados por este ajuste de UI.
- [x] `versionCode=512`, `versionName=0.512.0`.
- [ ] Compilação Android e testes JUnit não executados neste ambiente.
