# Auditoria V647 — Correção da interpolação do ordinal

## Causa raiz
Os builds falharam em série porque strings usavam interpolação sem chaves antes do símbolo `º`, por exemplo `"Posição atual: $objectiveRankº"`. O Kotlin tenta resolver `objectiveRankº` como um identificador só, gerando `Unresolved reference`. Renomear as variáveis não solucionava a causa.

## Correção
Usar `"Posição atual: ${objectiveRank}º"`, separando explicitamente o identificador do símbolo ordinal.

## Escopo
A varredura de `*.kt` e `*.kts` confirmou que não há outros padrões `\$identificadorº`. A lógica de classificação e de metas não foi alterada.

## Limitação
A compilação Android completa deve ser confirmada no pipeline com Gradle/SDK. As verificações estáticas e a integridade do pacote não são equivalentes a um build bem-sucedido.
