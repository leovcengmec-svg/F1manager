# V598 — edição livre de pilotos e padronização de botões

- Corrigida a validação do catálogo: IDs oficiais de mercado/reserva (81–100) são identidades oficiais, mas não são pilotos presos ao roster oficial quando estão livres. Podem ser atribuídos a uma equipe nova.
- A recuperação controlada só cria identidade personalizada para pilotos realmente vinculados a uma equipe oficial; agentes livres preservam seu ID e perfil.
- A edição de equipe permite selecionar pilotos de qualquer equipe ou do mercado. Uma transferência troca os pilotos de lugar entre as equipes de origem e destino, preservando dois assentos e atualizando os rosters oficial/personalizado em uma transação persistente.
- Recalcula `teamId` dos pilotos personalizados a partir do roster após transferências, liberando corretamente os pilotos substituídos.
- Padronizados altura, largura disponível e texto de botões na tela de cadastros; rótulos não quebram em múltiplas linhas.
- Incluído teste de regressão para permitir piloto oficial livre de mercado em equipe personalizada.
- Build Android e testes JUnit precisam ser executados no GitHub Actions; não declarar compilação aprovada sem esse resultado.
