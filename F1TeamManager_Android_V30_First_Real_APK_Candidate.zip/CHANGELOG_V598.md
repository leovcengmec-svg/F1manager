# V598 — Objetivos dinâmicos do Team Principal

- Prestígio inicial reduzido de 10 para 1.
- Objetivo principal recalculado conforme a posição/força atual da equipe e regenerado ao fim de cada temporada.
- Sistema de 1 objetivo principal, 1 secundário financeiro e 4 objetivos sazonais escolhidos de um conjunto maior e adequado à força da equipe.
- Objetivos concluídos somam prestígio; objetivos fracassados descontam pontos. Ganho sazonal limitado a +8.
- Persistência de objetivos e resultados com migração compatível com saves antigos.
