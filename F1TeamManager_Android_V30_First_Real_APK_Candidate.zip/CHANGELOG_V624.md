# V624 — Correção da tela de regulamento e padronização do modal de renovação

- A tela de mudança de regulamento agora respeita as áreas seguras do Android, usando padding de barra de status e navegação para impedir que o título encoste nos ícones do telefone ou que o botão inferior fique atrás da navegação.
- Os cards de regulamento foram padronizados com fundo grafite, contorno discreto e raio de 16 dp.
- A imagem regulamentar mantém a proporção original 600×330, deixando visível a faixa/banner já embutida nas artes e evitando que a imagem seja cortada ou pareça ficar atrás do texto.
- O modal de notificações agora garante explicitamente a arte `notice_market_signed` para renovação, assinatura/fechamento de contrato e transferência confirmada; a arte de mercado usa proporção panorâmica para não desaparecer nem ser excessivamente recortada.
- O modal de evento respeita as áreas seguras e tem altura máxima com rolagem interna para que título, mensagem e botões não sejam cortados em telas menores.
- Preservados os dados, a lógica de regulamentação, os estados de contratos, a Central de Notícias e todos os assets existentes.
- Validação de pacote e análise estática concluídas; compilação Android completa ainda precisa ser confirmada no pipeline, pois este ambiente não tem Gradle/gradlew.

