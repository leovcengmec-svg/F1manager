# V722 — Overall × Investment audit

## Official table
The existing 61-row mapping from Overall 40–100 and €8M–€150M is preserved. No linear €1M-to-attribute conversion is used for annual underinvestment.

## Unified rule
`annualOverallFromInvestment(previousOverall, invested)` converts actual investment through the official table, then clamps the result to `[previousOverall - 10, previousOverall + maximumAnnualGain]`, bounded by physical Overall 40–100.

The same rule is used by AI physical/legacy rollover and player physical/legacy rollover. Forecast paths apply the same lower and upper annual bounds.

## Tests added/updated
- Exact reference rows (40, 50, 60, 70, 80, 90, 100).
- Monotonicity over €8M–€150M.
- AI and player physical construction parity.
- Zero-investment annual loss capped at 10 Overall points.
- Fully funded construction respects annual growth ceiling.
- Legacy AI continuity no longer expects component-wise €1M penalties.

## Limitations
Static source checks do not replace Kotlin compilation, JUnit execution or Android career replay.
