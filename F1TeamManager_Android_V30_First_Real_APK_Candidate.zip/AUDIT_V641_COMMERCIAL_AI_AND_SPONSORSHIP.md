# Auditoria V641 — Prioridade comercial e paridade de patrocínio

## Conclusão

A hierarquia foi corrigida e a IA agora usa o mesmo processo de geração de ofertas do jogador para contratação inicial e renovação de patrocínios. A diferença remanescente é apenas a ação decisória: o jogador escolhe manualmente entre as três ofertas e a IA seleciona automaticamente a de maior valor esperado.

## Hierarquia de instalações

A ordem estratégica em `AITeamFinancialEngine.advanceFacilityDevelopment` é Centro de P&D, Fábrica, Centro Comercial, Túnel de Vento, Simulador, Desenvolvimento de Pilotos e Scouting. Os candidatos alternativos são ordenados primeiro por essa hierarquia e só depois pelo nível atual. Isso elimina a falha em que um Scouting de nível 0 furava a fila por ser a instalação menos desenvolvida.

Abaixo do nível 3, o Centro Comercial é colocado na frente dos candidatos alternativos se o upgrade couber no caixa, preservar as reservas operacionais e respeitar o limite de investimento técnico. Se estiver temporariamente inviável, a IA pode adotar uma alternativa acessível sem violar a reserva. A partir do nível 3, ampliações adicionais dependem do fluxo de caixa projetado.

## Patrocínio: comparação jogador × IA

### Regras compartilhadas
- `TeamSponsorshipEngine` e `SponsorCatalog`: catálogo, seis categorias, nível do Centro Comercial, slot Master/principal e geração de três propostas por slot.
- `buildContract`: mesmos valores base por categoria, bônus do slot Master, multiplicador comercial, pagamento inicial, valor garantido por GP, bônus de classificação e qualificação, metas esportivas e duração em GPs.
- `FinanceEngine`: mesma liquidação de patrocinadores por entrada, corrida, qualificação e pontos, sem fórmulas financeiras exclusivas da IA.
- As equipes da IA continuam persistindo seus próprios portfólios e chaves de idempotência no snapshot da carreira.

### Diferença de decisão
- O jogador recebe três ofertas e escolhe uma manualmente.
- A IA recebe as mesmas três ofertas geradas pelo mecanismo comum, tanto ao iniciar o portfólio como quando um contrato expira, e escolhe a que maximiza uma estimativa determinística de receita esperada. O cálculo prioriza entrada e pagamentos por GP durante o prazo, com uma estimativa conservadora dos bônus de qualificação/corrida.
- A tela Finanças passa o conjunto verdadeiro de patrocínios ativos da equipe do jogador para o gerador; assim, as ofertas não repetem uma marca que já esteja ativa em outro slot.

Portanto, a resposta é: **sim quanto às regras de mercado, cálculo e contabilização; a diferença é que a IA escolhe automaticamente a melhor das três ofertas, enquanto o jogador decide manualmente.**

## Cobertura
- Testes: `CommercialPriorityAndSponsorshipV641Test` e `SponsorshipAndCommercialAI_V619Test`.
- Auditoria estática: `tools/race_sim_test/v641_commercial_ai_sponsorship_audit.py`.
- Não se afirma compilação Android integral nem execução em dispositivo: o pacote não inclui `gradlew` e este ambiente não possui Gradle utilizável.
