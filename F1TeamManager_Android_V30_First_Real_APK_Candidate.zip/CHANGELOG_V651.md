# V651 — Avaliação inteligente de contratos de patrocínio

## Objetivo
Corrigir a escolha automática das IAs, que na V650 favorecia excessivamente contratos longos por somar os pagamentos de todas as corridas sem equilibrar retorno médio e oportunidade de renegociação.

## Alterações
- A IA continua avaliando exatamente as três propostas exibidas ao jogador para o mesmo slot e categoria.
- Novo modelo comparativo com quatro dimensões normalizadas dentro do conjunto de propostas:
  - 35%: receita garantida total (entrada + pagamentos por GP durante o contrato).
  - 30%: receita garantida média por GP, incluindo a entrada amortizada pela duração.
  - 20%: valor esperado dos bônus de classificação e corrida.
  - 15%: flexibilidade para renegociar mais cedo.
- A probabilidade dos bônus deixa de usar uma fração fixa de 1/5. O modelo estima a chance de atingir a janela de classificação e a meta de corrida em relação à posição esperada do melhor piloto da equipe, derivada do ranking do carro.
- Contratos curtos podem vencer quando entregam melhor retorno por GP e flexibilidade, mas contratos longos continuam podendo vencer quando sua vantagem financeira total e média é claramente superior.
- `pointsBonus` continua excluído porque a liquidação compartilhada não paga bônus por pontos.
- Nenhuma alteração na geração de ofertas, categorias por Centro Comercial, exclusividade de marcas, cinco espaços, condições contratuais ou pagamentos/liquidação dos contratos já assinados.
- Atualização de `versionCode` para 651 e `versionName` para `0.651.0`.

## Compatibilidade
- O formato de snapshot V356 permanece inalterado.
- Contratos existentes e saves anteriores mantêm seus valores; a nova avaliação se aplica apenas às novas escolhas automáticas feitas pela IA.
