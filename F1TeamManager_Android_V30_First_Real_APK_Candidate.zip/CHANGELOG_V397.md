# V397 — Diagnóstico visível da simulação instantânea

- A tela Home agora apresenta a mensagem real quando a simulação instantânea falha, quando o resultado não pode ser persistido ou quando a finalização precisa ser retomada.
- A mensagem é exibida no card da próxima corrida, abaixo dos botões, evitando que falhas silenciosas pareçam um botão sem ação.
- Mantida a chamada existente para `simulateWeekendInstantlyForCareer()` e o fluxo de simulação/finzalização; não foi substituída a lógica por navegação falsa.
- Versão Android atualizada para 0.397.0.

Validação: inspeção estática das alterações e teste de integridade do ZIP. A compilação Android não foi executada neste ambiente.
