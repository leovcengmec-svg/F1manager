# F1 Team Manager — V366

## Bloco: integração de simulação instantânea com liquidação da carreira

- Adicionado `InstantSimulationCareerSettlementV366Test`, que encadeia 60 fins de semana reais pelo `InstantSimulationService` e verifica a aplicação de liquidação financeira com identidade temporada/GP.
- O teste repete cada liquidação e exige igualdade do estado financeiro, verificando que a chave persistente `raceSettlementKeys` evita créditos/débitos duplicados.
- A cada GP, o teste exporta e restaura o snapshot de patrocínios e repete a mesma rodada; a duração dos contratos deve permanecer igual e a chave de idempotência deve sobreviver à restauração.
- O teste cobre duas temporadas de 30 GPs (2026 e 2027), sem alterar a interface nem adicionar botões.
- Atualizados `versionCode=366` e `versionName=0.366.0`.

## Limites de validação

O teste foi adicionado ao projeto, mas não executado pela suíte JUnit: este ZIP não contém `gradlew` e não há Gradle instalado no ambiente. O build Android e a execução integrada com `CareerPreferences`/SharedPreferences seguem pendentes. A cadeia V364 do motor continua sendo uma validação de domínio, não uma prova da carreira Android completa.
