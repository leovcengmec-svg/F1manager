# V600 — Correção de identidade de pilotos e plano de pneus

## Correções
- O diálogo de plano de pneus agora consulta o elenco atual da carreira, não apenas o grid imutável de abertura. Transferidos e pilotos de mercado contratados exibem bandeira, equipe e Overall corretos.
- Adicionada migração pontual para Felipe Drugovich: quando um save contém atributos incompatíveis com o perfil canônico (perfil médio >=75 e atributos persistidos <=65), restaura seus atributos de perfil e remove apenas o estado de evolução associado à colisão de identidade.
- O restante dos atributos e das fases de evolução dos demais pilotos é preservado.

## Validação
- ZIP e verificações estáticas conferidos.
- Compilação Android, JUnit e simulação no dispositivo permanecem pendentes.
