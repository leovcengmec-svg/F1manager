# V600 — Correção definitiva da versão inicial dos componentes

- Corrigida a persistência que forçava `installedPieceVersions` a no mínimo 1, convertendo o V0 dos carros recém-criados em V1 ao salvar.
- Migração de compatibilidade ao carregar garagens já gravadas por versões anteriores: IDs de baseline `INIT-*` e `SEASON-*` com versão 1 são normalizados para V0. Peças reais pesquisadas/manufaturadas não são alteradas.
- Corrigido o contador inicial de versão de pesquisa da IA para usar baseline 0; versões pesquisadas continuam sendo calculadas individualmente por componente a partir do último nível da temporada.
- Preservados os valores de desempenho, confiabilidade, peças instaladas, histórico de pesquisa, temporada e dados da carreira.
- Atualizado versionCode para 600 / versionName 0.600.0.
