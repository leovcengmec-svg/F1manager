# V486 — Correção dos erros de compilação Kotlin

- Corrigido o callback do card de notificação da Home: o componente não acessa mais a variável local `screen` fora do escopo; a navegação para o mercado usa `onMarket()`.
- Corrigido o receiver do conteúdo do diálogo de negociação de `Column` para `ColumnScope`, tipo correto da API Jetpack Compose.
- Escopo limitado a correções de compilação/navegação, sem alterar as regras financeiras ou de simulação.
- Validada a presença das correções no código-fonte e integridade do ZIP. Compilação Android completa depende do ambiente Gradle/Android SDK.
