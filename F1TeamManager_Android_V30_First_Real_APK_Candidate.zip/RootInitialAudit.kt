import com.f1teammanager.core.season.WorldDatabase
import com.f1teammanager.core.manager.*

fun main(){
  val teams=WorldDatabase.teams
  require(teams.size==40)
  val bad=teams.filter { t ->
    val v=InitialTeamProfile.values(t)
    when(t.initialLevel){
      InitialTeamProfile.FORTE -> v.overall !in 56.0..60.0
      InitialTeamProfile.MEDIO -> v.overall !in 48.0..55.0
      else -> v.overall !in 40.0..47.0
    }
  }
  require(bad.isEmpty()) { "bad initial: ${bad.map{it.name}}" }
  val rb=teams.first{it.name=="Red Bull Racing"}
  val rbv=InitialTeamProfile.values(rb)
  println("RB level=${rb.initialLevel} values=${rbv} overall=${rbv.overall} rel=${InitialTeamProfile.carState(rb).reliability}")
  val risks=ResearchEngine().options(2).joinToString { "${it.complexity}:${it.riskLabel}:${it.weeks}" }
  println("RISKS=$risks")
  val ai=AITeamDevelopmentEngine(20261005)
  val a=ai.simulateFinancial(rb,2,2026)
  println("AI week2 overall=${a.garage!!.teamAverageOverall} legacy=${a.car.engine}/${a.car.chassis}/${a.car.frontWing}/${a.car.rearWing}/${a.car.brakes}/${a.car.electricPowerUnit}")
  require(a.garage!!.car1.componentValue(CarComponent.ENGINE) >= 56)
  require(a.garage!!.car1.componentValue(CarComponent.ENGINE) <= 100)
  println("ROOT_INITIAL_OK")
}
