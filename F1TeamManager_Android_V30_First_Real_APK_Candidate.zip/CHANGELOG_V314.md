# V314 — Compactação da tela de qualificação

- Removida a linha de seleção Q1/Q2/Q3 e os textos de contagem Q1/Q2/Q3; a fase atual continua indicada no card de sessão.
- Botão de simulação movido para a mesma linha dos controles de velocidade, preservando as ações de simular, pausar e iniciar corrida.
- Removidos os indicadores de quantidade de pilotos e eliminados.
- Removidos os textos do relógio regressivo; o cronômetro permanece visível.
- Média do GP e melhor volta movidas para a área ao lado do cronômetro, com card mais compacto.
- Substituído o fundo do card do GP por uma imagem genérica de automobilismo sem texto nem logotipos.
- Mantidos o nome oficial do ZIP e os demais assets e históricos.
