# V316 — Layout do Plano de Início da Corrida

## Implementado
- Redesenhado o card de piloto para seguir a referência aprovada: foto/posição, nome/equipe/bandeira e classificação geral em uma linha compacta.
- Reduzidas margens e alturas verticais para aproveitar melhor a tela em orientação retrato.
- Mantidos os quatro seletores Plano A–D com destaque vermelho para o plano selecionado.
- Compostos de pneus apresentados em grade de duas colunas, com suporte dinâmico a até quatro stints e suas voltas reais.
- Removido da interface o bloco “Postura de corrida”; o modelo e a API de estratégia não foram removidos.
- Botões inferiores compactados e texto do cabeçalho alinhado à referência.
- Mantida a lógica de seleção de planos e o fluxo existente de cancelar/confirmar/iniciar.

## Verificação
- Alteração limitada à apresentação da tela de início da corrida e metadados da versão.
- Integridade do ZIP e presença dos arquivos serão verificadas após empacotamento.
- Não foi possível declarar compilação Android nem teste em dispositivo sem execução real de Gradle/build.
