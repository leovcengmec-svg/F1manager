# V330 static audit

Scope: driver-market new-contract proposal dialog in MainActivity.kt.

- Dialog uses platform width override and a fixed compact card layout.
- Duration choices (1-5 years) use equal weights in a single row.
- Role choices use equal weights in a single row.
- Driver portrait reuses DriverPhoto and team name resolves from WorldDatabase.
- Salary remains digit-only and calls the pre-existing onProposal callback with the same argument order.
- No verticalScroll or horizontalScroll is introduced in the proposal dialog.

Validation: ZIP integrity and static source checks only. Android compilation/device validation not performed.
