# Auditoria V653 — Mercado de pilotos, atratividade e contratos

## Escopo

Revisão da V652 com foco nas duas inconsistências observadas: pilotos de alto nível recusando equipes que se tornaram competitivas e equipes da IA chegando ao fim da temporada sem dois contratos futuros confirmados.

## Achados confirmados e corrigidos

### Atratividade esportiva excessivamente presa ao perfil inicial

Antes, `teamSportingStrength()` usava 55% da força de início e somente 45% da classificação atual. Prestígio e histórico repetiam essencialmente o perfil inicial. Isso deixava uma equipe que havia reconstruído o carro e vencido o campeonato com um valor de projeto artificialmente baixo.

A V653 calcula uma nota de classificação entre 35 e 100 e aumenta seu peso conforme o campeonato acumula pontos: de 20% até 80%. A força inicial continua contribuindo para estabilidade, mas não bloqueia uma transformação esportiva. Prestígio e histórico também migram gradualmente, com pesos menores.

### Uma tentativa de renovação por temporada

O ledger `renewalEvaluations` armazenava apenas `temporada:equipe:piloto`, tornando irreversível uma decisão aleatória de não enviar proposta. A chave agora inclui uma janela de oito semanas. Há nova avaliação nos checkpoints posteriores, com incentivo progressivo conforme o fim da temporada se aproxima. Um contrato futuro já assinado encerra a reavaliação daquele piloto.

### Elencos não eram fechados antes da virada

A V653 adiciona fechamento do mercado de IA na semana 52 em diante. A rotina calcula a projeção da próxima temporada e preenche vagas por ofertas normais. Na semana 56, propostas legadas ainda abertas são resolvidas antes de qualquer transição; contrapropostas dentro do teto financeiro configurado podem ser aceitas. Não é criada uma contratação fictícia e a equipe do jogador é excluída.

### Reserva duplicada de assentos

Na simulação de regressão foi identificado que uma renovação pendente e uma contratação externa podiam reservar o mesmo titular a substituir. A validação em `makeOffer()` agora protege tanto contratos futuros quanto negociações pendentes. O seletor de substituição ignora assentos já comprometidos.

## Regressões executadas

O motor `DriverMarketEngine.kt` e `DriverMarketModels.kt` foram compilados com Kotlin junto ao `WorldDatabase`, `SeasonCalendar`, `SeasonModels` e `DriverProfileCatalog` originais do projeto. Foram executados testes focados de mercado e transição:

1. Checkpoints de renovação V618 — aprovado.
2. Não renovar piloto fraco quando há alternativa muito superior — aprovado.
3. Renovação mantém fluxo de negociação e período de resposta — aprovado.
4. Identificação de renovação versus transferência futura — aprovado.
5. Integridade do grid após transição V592 — aprovado.
6. Classificação atual supera reputação inicial quando a equipe reconstrói e vence — aprovado.
7. Interesse de piloto de elite aumenta quando a equipe vira campeã — aprovado.
8. Fechamento da semana 56 projeta dois pilotos para todas as 40 equipes — aprovado.
9. Fechamento automático não modifica o elenco futuro da equipe do jogador — aprovado.

**Resultado: 9/9 regressões direcionadas aprovadas.**

## Simulação multitemporada

Simulação determinística de 2026 a 2030, com processamento semanal das semanas 9 a 56 e transição de temporada, usando o banco real de 40 equipes, 100 pilotos e o calendário de 30 GPs do projeto. Para o teste de mercado, as equipes recebem orçamento de referência suficiente para cumprir taxas de contratação.

| Temporada processada | Contratos futuros | Elencos incompletos antes da virada | Propostas pendentes | Assentos duplicados | Elencos incompletos após a virada |
|---:|---:|---:|---:|---:|---:|
| 2026 | 41 | 0 | 0 | 0 | 0 |
| 2027 | 55 | 0 | 0 | 0 | 0 |
| 2028 | 47 | 0 | 0 | 0 | 0 |
| 2029 | 56 | 0 | 0 | 0 | 0 |
| 2030 | 48 | 0 | 0 | 0 | 0 |

Em todas as temporadas, as 40 equipes terminaram a preparação com dois pilotos únicos projetados e a transição manteve dois contratos ativos por equipe. O jogador foi tratado como ausente na simulação geral; sua proteção foi verificada em regressão separada.

## Limitações e ressalvas

- Não há Gradle/Gradle Wrapper nem Android SDK neste ambiente. Portanto, esta auditoria não equivale a `gradle test`, compilação APK ou teste em dispositivo.
- O harness usa substitutos leves para JUnit e dependências Android auxiliares não exercitadas. O banco real de pilotos/equipes, calendário e catálogo de pilotos foi compilado a partir da base do projeto.
- A simulação multitemporada usa orçamento de referência suficiente; não valida cada variação real de caixa das equipes. As taxas continuam sendo validadas no ledger financeiro Android existente, fora deste harness.
- Não é possível garantir aceitação de um piloto em qualquer circunstância: recusas legítimas, orçamento insuficiente ou ausência de candidatos elegíveis podem manter vaga aberta, que passa a ser reportada explicitamente em vez de receber piloto fictício.

## Parecer

As inconsistências estruturais identificadas na V652 foram corrigidas na V653. A atratividade agora acompanha a evolução esportiva, as renovações têm mais de uma oportunidade controlada, a reta final fecha os elencos da IA por contratos reais e uma vaga não pode ser reservada simultaneamente por negociações concorrentes.
