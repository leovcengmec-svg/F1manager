# V689 (0.689.0) — restauração do saldo disponível no orçamento

- O card de orçamento volta a exibir “Invest. Disponível” no lugar da linha redundante “Carro Seguinte”.
- A linha usa o valor `availableTechnical`, já calculado pelo envelope anual consolidado e abatendo o investimento no próximo carro.
- O painel separado “Investimento do Próximo Carro” permanece inalterado e continua exibindo valor investido, referência atual e projeção.
- Aplicado à visão das equipes do jogador e da IA, mantendo o restante do layout e da economia da V688.
- VersionCode 689 / VersionName 0.689.0.
