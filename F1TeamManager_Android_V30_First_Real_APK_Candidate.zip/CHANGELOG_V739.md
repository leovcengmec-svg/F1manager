# CHANGELOG V739 — Cards de pilotos e patrocínios por categoria

## Mercado de pilotos
- Restaurados os cards completos dos sete atributos, sem redução de altura que cortava os valores. Cada card passa a ter 58 dp, rótulo 8 sp e valor 11 sp.
- Removida a linha redundante “CONTRATO EM VIGOR OU JANELA FECHADA”.
- Removido o placeholder vazio de ação: RENOVAR/NEGOCIAR aparece apenas quando a ação está realmente disponível.
- Mantidas as informações contratuais úteis, inclusive equipe atual, duração, ano do contrato, salário e situação de renovação.
- O espaço inferior do card passa a ser ocupado somente por uma ação disponível; caso contrário, o card termina logo após os atributos, sem mensagem redundante.

## Patrocínios
- Os novos valores de GP, meta de qualificação e meta de corrida passam a ser definidos pela categoria comercial efetiva do contrato, e não por multiplicadores que faziam ofertas Regionais chegarem ao teto Global.
- Faixas por categoria (valores por GP / bônus de qualificação / bônus de corrida):
  - Básico: €120–220 mil / €50–100 mil / €50–100 mil.
  - Regional: €220–340 mil / €100–160 mil / €100–160 mil.
  - Nacional: €340–460 mil / €160–220 mil / €160–220 mil.
  - Internacional: €460–580 mil / €220–280 mil / €220–280 mil.
  - Premium: €580–700 mil / €280–340 mil / €280–340 mil.
  - Global: €700–800 mil / €340–400 mil / €340–400 mil.
- Básico fica na menor faixa e Global na maior; as faixas são progressivas e não se sobrepõem.
- Nível de Marketing e slot Master ajustam o valor dentro da faixa da categoria, sem permitir que Básico/Regional saltem para os valores de Global.
- Tetos absolutos preservados: €800 mil/GP e €400 mil para cada meta.
- Contratos já assinados e saves existentes não são reprecificados retroativamente.
- Jogador e IA continuam recebendo propostas pelo mesmo motor e pela mesma tabela.

## Testes
- Adicionado `SponsorOfferCategoryPricingV739Test` para ordem das faixas, máximos globais, limites absolutos e diferenciação Básico/Global.
- Inspeção estática confirma que o texto redundante foi removido e os cards de atributos não usam mais 42 dp.

## Versionamento
- VersionCode 739; VersionName 0.739.0.
- Nome público e nome do ZIP preservados.

## Build
- Compilação isolada de `SponsorContractPricing.kt` e harness de regressão executados com sucesso.
- Build Android completo/JUnit pendente no GitHub Actions por ausência do Gradle Wrapper e Android SDK neste ambiente.
