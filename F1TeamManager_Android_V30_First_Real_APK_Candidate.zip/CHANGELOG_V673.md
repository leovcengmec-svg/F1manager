# V673 — Eventos de assinatura no mercado de pilotos


## V673 — eventos de assinatura no mercado de pilotos

- A Home agora apresenta um card de evento para cada assinatura concluída no mercado de pilotos, incluindo renovações, novas contratações e transferências entre equipes da IA.
- Assinaturas concluídas na montagem de elenco da pré-temporada também usam o evento padronizado `CONTRATO ASSINADO`.
- Eventos de assinatura e renovação são globais: o jogador recebe a notícia mesmo quando nenhuma das equipes envolvidas é a sua.
- Propostas, contrapropostas, recusas, expirações e demais etapas de negociação deixam de gerar card popup/alerta de negociação na Home; continuam registradas no histórico central do mercado.
- O resumo de eventos da Home passou a listar somente contratos assinados/renovados, sem misturar negociações ainda não concluídas.
- Versão interna incrementada para 673; nome público e nome original do ZIP preservados.
