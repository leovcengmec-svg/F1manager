# V345 — Finalizador compartilhado da carreira

- Extraído o fechamento do GP para `finalizeCompletedRace`, compartilhado pelo fluxo interativo e pela entrada interna de simulação instantânea.
- Adicionado `simulateWeekendInstantlyForCareer()`: executa qualificação e corrida com o motor real e encaminha o resultado pelo mesmo finalizador de carreira.
- A integração não adiciona botões nem altera telas/layouts.
- Mantida a proteção contra GP já registrado.
- Versionamento Android atualizado para 345 / 0.345.0.
