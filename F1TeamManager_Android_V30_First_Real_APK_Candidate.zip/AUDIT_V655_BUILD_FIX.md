# Auditoria V655 — Build fix SaveManagementScreen

## Erro relatado
O GitHub Actions falhou em `:app:compileDebugKotlin` com:

`Only safe (?.) or non-null asserted (!!.) calls are allowed on a nullable receiver of type CareerSaveMetadata?`

Origem: `SaveManagementScreen.kt`, callback do botão de carregar save, linha 247 na V654.

## Causa
A expressão `metadataByPath[file.absolutePath]` usa o operador `Map.get`, cujo retorno é anulável (`CareerSaveMetadata?`). A condição `enabled = metadata != null` é apenas uma propriedade de estado da interface e não garante smart cast do valor capturado pelo lambda `onClick`.

## Correção aplicada
O callback faz uma captura local `saveMetadata = metadata`, testa explicitamente `saveMetadata == null` e só chama `saveMetadata.modeLabel()` dentro do ramo não nulo. O ramo nulo exibe mensagem e não inicia a importação. Nenhum `!!` foi introduzido.

## Validação executada
- Teste específico de regressão: 9/9 aprovado.
- Compilação isolada Kotlin da mesma estrutura de acesso anulável e guarda local com `kotlinc`: aprovada.
- Auditoria geral do projeto: 45/45 aprovada.
- Auditoria estrutural de release: 25/25 aprovada.
- Integridade do ZIP final: aprovada.

## Limitação
Não foi executado `:app:compileDebugKotlin` nem gerado APK neste ambiente: não há Gradle/Gradle Wrapper nem Android SDK configurados. A correção aborda o erro específico mostrado nas capturas; o build no GitHub continua sendo a confirmação final de integração do projeto completo.
