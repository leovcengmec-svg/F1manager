# V322 — Aviso de falha de design do P&D

- A conclusão de uma tentativa de P&D com resultado FAILURE agora gera uma notificação persistente no fluxo de notícias/avisos já utilizado pela Home.
- O aviso identifica componente e versão e explica que nenhum design foi criado, a tecnologia anterior foi preservada e custo/tempo foram consumidos.
- A falha é distinguida de um design concluído usando o snapshot dos projetos ativos antes do avanço das semanas.
- Avisos de conclusão de design foram preservados.
- Versionamento: versionCode 322 / versionName 0.322.0.
