import com.f1teammanager.core.race.*

fun main() {
    val participants = (1..80).map { id ->
        val team = ((id - 1) / 2) + 1
        RaceParticipant(
            driverId = id, driverName = "Driver $id", teamId = team, teamName = "Team $team",
            driverSpeed = 40 + (id % 61), qualifying = 40 + (id % 61),
            overtaking = 60, defense = 60, consistency = 70, enginePerformance = 60,
            tyreGrip = 60, tyreWear = 60, reliability = 100, wetSkill = 60,
            chassisPerformance = 60, frontWingPerformance = 60, rearWingPerformance = 60,
            brakesPerformance = 60, electricPowerUnitPerformance = 60,
            engineReliability = 100, chassisReliability = 100, frontWingReliability = 100,
            rearWingReliability = 100, brakesReliability = 100, electricPowerUnitReliability = 100
        )
    }
    val initialCircuit = RaceCircuit(617, "V616 Gap GP", 12, 75_500L, 0.0, 0.0, 0.0)
    val engine = CareerWeekendEngine(20261018)
    engine.start(participants, initialCircuit, 1)
    engine.simulateQualifyingInstantly()
    var snap = engine.snapshotForUi()
    fun finishPending() {
        var safety = 0
        while (snap.decision != null && safety++ < 10) snap = engine.choose(ManagerDecisionAction.STAY_OUT)
        check(safety < 10)
    }
    repeat(4) {
        finishPending()
        snap = engine.advance()
        finishPending()
    }
    fun spread(): Long {
        val active = snap.classification.filter { it.status != "DNF" }
        return active.maxOf { it.totalTimeMs } - active.minOf { it.totalTimeMs }
    }
    val spreadBefore = spread()
    val field = engine.javaClass.getDeclaredField("circuit")
    field.isAccessible = true
    field.set(engine, initialCircuit.copy(safetyCarRisk = 1000.0))
    snap = engine.advance()
    check(snap.neutral == Neutralisation.SAFETY_CAR) { "Expected forced Safety Car, got ${snap.neutral} at lap ${snap.lap} with ${snap.decision}" }
    finishPending()
    // Complete the same lap that was paused for the Safety Car deployment.
    snap = engine.advance()
    val spreadAfter = spread()
    check(spreadAfter < spreadBefore) { "Safety Car did not bunch the field: before=$spreadBefore after=$spreadAfter" }
    check(snap.carStatus.none { it.drsActive }) { "DRS active under Safety Car" }
    println("V616_SAFETY_CAR_GAP_COMPRESSION_OK; before=${spreadBefore}ms; after=${spreadAfter}ms; closed=${spreadBefore-spreadAfter}ms")
}
