package org.junit
annotation class Test
object Assert {
    @JvmStatic fun assertEquals(expected: Any?, actual: Any?) {
        check(expected == actual) { "Expected <$expected> but was <$actual>" }
    }
    @JvmStatic fun assertTrue(condition: Boolean) {
        check(condition) { "Expected condition to be true" }
    }
    @JvmStatic fun assertTrue(message: String, condition: Boolean) {
        check(condition) { message }
    }
}
