import com.f1teammanager.core.season.DriverClassUnlockMarginV734Test
import com.f1teammanager.core.manager.RaceFinalizationCanonicalGarageV734Test
import com.f1teammanager.core.season.DriverClassCeilingMarginV702Test

fun main() {
    val driver = DriverClassUnlockMarginV734Test()
    driver.leaderCanEarnTheAdditionalBandWithoutChangingNormalGpScore()
    driver.classUnlockScoreKeepsQualifyingAndRaceWeightsAtFortySixty()
    driver.earnedMarginRequiresFiveRealGpsAndNeverShrinksWithinTheSeason()
    driver.contractedProMustWaitForFiveRealGpsBeforeUsingPoleWinEvidence()
    driver.contractedProCanUseEarnedMarginAfterExceptionalSeasonEvidence()
    driver.proFreeAgentCanUseOnlyLastCompletedSeasonEvidence()
    driver.facilityReserveIsReleasedWhenTheSeasonMarginOpens()

    val legacy = DriverClassCeilingMarginV702Test()
    legacy.mediumGetsFullFivePointBandWithOrWithoutTeam()
    legacy.freeForteGetsFullBandButContractedForteMustEarnIt()
    legacy.proNeedsPerformanceWhetherFreeOrContracted()
    legacy.legendaHasNoAdditionalClassBand()
    legacy.normalGrowthSpeedIsNotReducedForMediumOrFreeForte()
    legacy.positiveGainCanReachFivePointBandWhenAllowanceIsGranted()
    legacy.proFreeAgentCannotCrossNormalCeilingWithoutSeasonEvidence()
    legacy.aSingleExcellentGpCannotReplaceTheSeasonAverageRequirement()
    legacy.facilityProgramsUseTheSameFivePointClassGate()
    legacy.contractedProOnlyCrossesAccordingToSeasonPerformanceThreshold()

    val gp30 = RaceFinalizationCanonicalGarageV734Test()
    gp30.gp30PlanIncludesCanonicalGaragesAfterAwardsAndBeforeFinalPersistence()
    gp30.v733PendingGp30CanResumeAtTheNewCanonicalGarageStep()
    gp30.canonicalGarageStepCannotRunBeforePrizeSettlement()
    println("V734 focused tests: 20 passed")
}
