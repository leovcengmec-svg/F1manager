import com.f1teammanager.core.race.*

fun main() {
    val modelLap = 84_000L
    val grouped = SafetyCarGroupingModel.applyCatchUp(modelLap, 5_000L, 75_000L)
    check(grouped == 81_900L) { "Unexpected grouped lap: $grouped" }
    check(SafetyCarGroupingModel.applyCatchUp(modelLap, 1_000L, 75_000L) == modelLap)
    check(SafetyCarGroupingModel.applyCatchUp(modelLap, 80_000L, 75_000L) == 77_000L)

    val participants = (1..80).map { id ->
        val team = ((id - 1) / 2) + 1
        RaceParticipant(
            driverId = id, driverName = "Driver $id", teamId = team, teamName = "Team $team",
            driverSpeed = 40 + (id % 61), qualifying = 40 + (id % 61),
            overtaking = 60, defense = 60, consistency = 70, enginePerformance = 60,
            tyreGrip = 60, tyreWear = 60, reliability = 100, wetSkill = 60,
            chassisPerformance = 60, frontWingPerformance = 60, rearWingPerformance = 60,
            brakesPerformance = 60, electricPowerUnitPerformance = 60,
            engineReliability = 100, chassisReliability = 100, frontWingReliability = 100,
            rearWingReliability = 100, brakesReliability = 100, electricPowerUnitReliability = 100
        )
    }
    // Deliberately elevated risk only for this smoke test, to exercise the SC paths reliably.
    val circuit = RaceCircuit(616, "V616 SC audit GP", 8, 75_500L, 0.0, 0.0, 1000.0)
    val engine = CareerWeekendEngine(616)
    engine.start(participants, circuit, 1)
    engine.simulateQualifyingInstantly()
    var snapshot = engine.snapshotForUi()
    var advances = 0
    while (!snapshot.completed && advances++ < 80) {
        snapshot = if (snapshot.decision != null) engine.choose(ManagerDecisionAction.STAY_OUT) else engine.advance()
        if (snapshot.neutral == Neutralisation.SAFETY_CAR) {
            check(snapshot.carStatus.none { it.drsActive }) { "DRS remained enabled under Safety Car" }
        }
    }
    check(snapshot.completed) { "Race did not complete" }
    val result = engine.result()
    check(result.classification.size == 80)
    check(result.events.any { it.type == EventType.SAFETY_CAR_DEPLOYED }) { "Safety Car path was not exercised" }
    println("V616_SAFETY_CAR_SMOKE_OK; deployed=${result.events.count { it.type == EventType.SAFETY_CAR_DEPLOYED }}; advances=$advances")
}
