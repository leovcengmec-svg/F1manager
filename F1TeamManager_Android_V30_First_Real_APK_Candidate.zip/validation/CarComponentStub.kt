package com.f1teammanager.core.manager
enum class CarComponent { ENGINE, CHASSIS, FRONT_WING, REAR_WING, BRAKES, ELECTRIC_POWER_UNIT }
