# V452 — Card de investimento do próximo carro na visão da equipe

- Incluído card entre “ATRIBUTOS DOS CARROS” e “DESEMPENHO NA TEMPORADA”.
- Exibe investimento acumulado no próximo carro, referência financeira pelo Overall atual, percentual da referência e projeção de classe.
- Os dados são lidos do estado do carro da equipe selecionada; não altera a lógica financeira, o layout dos cards existentes nem adiciona botões.
- A projeção segue os mesmos limites de razão investimento/referência definidos em `CarDevelopmentEngine.nextSeasonForecast`.
