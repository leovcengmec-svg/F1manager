# Auditoria V664 — correções da auditoria V663

## Correções implementadas

1. **Risco do Team Principal**: a tela passou a receber a estimativa calculada em `CareerPreferences.teamPrincipalDismissalRiskEstimate()`. A estimativa usa `TeamPrincipalCareerEngine.dismissalProbabilityPercent()` com as métricas atuais; o fechamento da temporada usa a mesma função com os dados consolidados.
2. **Financeiro**: `FinanceEngine.effectiveClosingBalance()` agora desconta salários e manutenção pendentes do caixa. A avaliação de metas e o risco do Team Principal usam esse saldo efetivo.
3. **Meta impossível em P1**: o objetivo `improve` vira `maintain_rank` quando não há posição possível para ganhar; em outros casos a melhoria é limitada ao número de posições disponíveis.
4. **Instalações**: a pontuação é proporcional ao número de objetivos atribuídos; concluir uma única meta disponível resulta em entrega integral. Upgrade em andamento com pelo menos 50% de progresso conta como investimento parcial.
5. **Desenvolvimento**: projetos de pesquisa com pelo menos 50% de progresso contam como avanço parcial. Peças físicas guardam `manufacturedSeason`, com migração compatível para saves antigos.
6. **Renovação**: a confiança na mesma diretoria não é reiniciada para 75%; assumir uma nova equipe ainda recebe o piso de confiança de uma nova diretoria.
7. **Identificação de release**: versionCode/versionName, manifesto, README, etiqueta Android e nome do artefato de CI atualizados para V664.

## Validações executadas

- ZIP de origem íntegro antes da edição.
- Revisão estática dos pontos alterados.
- Testes de regressão adicionados para saldo financeiro, meta de líder, entrega de instalação, progresso técnico e renovação.
- Não declarar suíte JUnit ou APK Android aprovados até executar o workflow com Android SDK/Gradle.

8. **Histórico**: consultas por temporada leem os shards daquela temporada e o fallback legado, em vez de abrir todos os shards de todas as temporadas.
9. **Desempate**: fechamento de carreira usa a classificação oficial persistida do campeonato, incluindo vitórias, poles e voltas mais rápidas antes do ID da equipe.
10. **Saves existentes**: objetivos impossíveis de evolução para equipes já em P1 são normalizados mesmo quando o marcador da temporada já foi gravado.
11. **Histórico de carreira entre equipes**: a penalidade por duas temporadas consecutivas abaixo da meta só considera reincidência quando ambas ocorreram na mesma equipe. Uma contratação nova não herda a sequência negativa da diretoria anterior.
12. **Auditoria automatizada**: o script legado V639 foi atualizado para validar as regras atuais da V664, removendo falsos alarmes de versões e contratos antigos.
