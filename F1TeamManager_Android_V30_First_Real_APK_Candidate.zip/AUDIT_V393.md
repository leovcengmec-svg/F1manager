# Auditoria V393

Escopo: diálogo de escolha de fabricação em `app/src/main/java/com/f1teammanager/MainActivity.kt`, no bloco `selectedDesign`.

- A ação de fabricação continua chamando `manufactureDesign(...)` com quantity, weeks e costPerUnit fornecidos por `FactoryEngine`.
- A opção só pode ser selecionada quando o orçamento e a capacidade de ordens permitem.
- O diálogo não usa `verticalScroll` ou `LazyColumn`; a altura é limitada a 92% da área disponível e o layout utiliza cards com pesos.
- A imagem usa o recurso já existente `R.drawable.factory_generic_piece`.
- Nenhum asset removido; histórico de versões preservado.
- Verificação de integridade do ZIP realizada após empacotamento.
- Compilação Android e teste visual em dispositivo ainda precisam ser executados.
