# V676 — Integração funcional das sete instalações

Base: V675. Nome público preservado: **F1 Team Manager V30**.

## Desenvolvimento de Pilotos
- O bônus passivo da instalação agora entra no fluxo normal de evolução após cada GP, usando a instalação da equipe atual do piloto.
- O mesmo fator é aplicado aos pilotos contratados das equipes da IA e no modo Team Principal. Agentes livres continuam evoluindo pelo mecanismo próprio, sem receber um bônus de equipe inexistente.
- O crescimento-base sem investimento foi normalizado em 100%; cada nível acrescenta 3%, chegando a 130% no nível 10. Programas individuais, potencial, teto de classe e limites anuais continuam respeitados.

## Pesquisa e Fábrica
- A capacidade do Centro de P&D é centralizada em uma regra compartilhada: 1 projeto nos níveis 0–3, 2 nos níveis 4–7 e 3 nos níveis 8–10.
- A IA agora mantém projetos simultâneos, preserva designs finalizados em fila quando a Fábrica está ocupada e inicia fabricação quando há vaga e orçamento.
- Jogador e IA usam a mesma faixa de ganho facility-aware, incluindo bônus universal de P&D e bônus extra do Túnel de Vento em componentes aerodinâmicos.
- A IA usa os mesmos cálculos de duração e custo de pesquisa e os mesmos parâmetros oficiais de capacidade, tamanho de ordem, duração e custo de fabricação.

## Túnel de Vento e Simulador
- O bônus de pista é aplicado como modificador fracionário no ritmo do carro, em classificação e corrida, sem arredondar e alterar os atributos físicos das peças.
- No nível 10, o bônus combinado é de 1,0% do Túnel de Vento e 0,5% do Simulador antes da ponderação carro/piloto da simulação.

## Scouting e Mercado de Pilotos
- As instalações de Scouting da IA passam a influenciar a estimativa de atributos de candidatos no processo de renovação e contratação.
- A precisão cresce de 20% a 100%; no nível 10 a estimativa coincide com o Overall real. O jogador mantém os relatórios com margem de erro correspondente ao nível.

## Centro Comercial
- O multiplicador de novos contratos é monotônico: começa em 1,60 no nível 0 e chega a 1,85 no nível 10. Contratos já assinados não são reprecificados.
- Receita semanal das lojas e qualidade/categoria de patrocinadores continuam vinculadas ao nível e são sincronizadas para equipes da IA.
- Corrigido o sentido do bônus de qualidade: a melhoria agora desloca o sorteio em direção às categorias mais fortes já liberadas, em vez de aumentar a chance das categorias inferiores.

## Interface
- Os cards das instalações mostram efeitos atuais e o benefício do próximo nível, usando o estado completo para exibir sinergias de P&D e Túnel de Vento.
- O resumo de instalações da equipe inclui Desenvolvimento de Pilotos.

## Validação
- Adicionados testes unitários para capacidade de P&D, intervalos de ganho, progressão de fábrica, velocidade de corrida/classificação, scouting, crescimento de pilotos e monotonicidade comercial.
- A auditoria estrutural verifica os caminhos de integração da IA, do jogador e da interface.
- A compilação Android e a suíte JUnit não foram executadas localmente: o ambiente não contém Gradle nem Gradle Wrapper. O workflow GitHub Actions está configurado para executar `:app:testDebugUnitTest` e `:app:assembleDebug`.
