# Auditoria V450

- Corrigido o erro `Unresolved reference: item` movendo o card de entrada do próximo carro para o escopo do `LazyColumn` em `Car(...)`.
- Corrigidos em cascata os erros de inferência em `selectedComponent?.let` e chamadas `@Composable` reportados no build V449, removendo a expressão `item {}` do bloco de diálogo.
- O card de navegação continua chamando `onNextCar()` e utiliza `team_card_generic_bg` já existente.
- Versão: `versionCode 450` / `versionName 0.450.0`.
- ZIP submetido a teste de integridade após empacotamento.
- Compilação Gradle/Android não executada neste ambiente; o próximo build do usuário deve confirmar se há erros adicionais.
