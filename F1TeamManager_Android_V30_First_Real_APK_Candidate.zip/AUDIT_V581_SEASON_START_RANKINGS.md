# V581 — Ranking dinâmico de início de temporada

## Correção
- A tela de abertura continua usando o elenco efetivo da carreira (`CareerPreferences.currentDrivers()`), que resolve contratos ativos, transferências e agentes livres para a temporada atual.
- O ranking de equipes agora recebe atributos derivados dos dois carros físicos, calculando a média por componente de Carro 1 e Carro 2.
- Para a equipe do jogador, a origem é a garagem persistida da carreira, com fallback para a garagem do estado atual e migração do carro legado.
- Para cada equipe de IA, a garagem é reconstruída pela cadeia física de temporada (`AITeamDevelopmentEngine.simulateFinancial`), incluindo investimento de próximo carro e regulamentação anual, e recebe deltas de eventos anuais através do mesmo adaptador usado pelo grid.
- O card calcula as quatro candidatas usando 58% de força do carro e 42% de média dos pilotos atuais da equipe. O ranking de pilotos usa 72% de avaliação individual e 28% de força da equipe atual. Os cards são ordenados a partir desses scores, não de uma lista fixa.
- `versionCode` atualizado para 581 e `versionName` para 0.581.0.

## Limites de verificação
- Fonte inspecionada e alterada; pacote ZIP testado quanto à integridade.
- Compilação Gradle/Android e testes Kotlin não foram executados neste ambiente. Não declarar a build funcional até essas etapas serem executadas.
