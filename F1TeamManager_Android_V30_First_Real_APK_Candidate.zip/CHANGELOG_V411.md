# V411 — Parcelamento real da taxa de contratação

- Remove o débito integral da taxa no momento da assinatura.
- Registra obrigação parcelada por GP restante, começando no próximo GP após a assinatura.
- Cada parcela é descontada do caixa após o GP, com marcador persistente para impedir cobrança duplicada.
- Aplica a regra ao fluxo da equipe do jogador e às novas contratações processadas para equipes da IA.
- Persiste início, quantidade de parcelas e GPs pagos nos snapshots e saves de carreira.
- Atualiza testes de regressão para a regra de parcelamento.
