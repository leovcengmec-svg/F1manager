# Auditoria V590 — ranking realmente renovado

## Lacuna identificada na V589
A V589 exigia uma semente diferente, mas isso não garante resultados diferentes: duas sementes podem produzir a mesma ordenação e até as mesmas três equipes mais fracas. Portanto, o resultado percebido pelo usuário ainda podia parecer fixo.

## Correção aplicada
- `InitialTeamProfile.freshRankingSeed` compara a ordenação completa e as três equipes mais fracas associadas à semente anterior.
- A função tenta novas sementes até que a ordem completa e o grupo das três piores sejam diferentes, por até 256 tentativas.
- O método é puro em relação à carreira ativa: usa sementes explícitas e não altera `careerSeed`.
- `CareerPreferences.prepareNewCareerSelection` usa a nova função antes de persistir a semente provisória.
- A tela recebe a semente como chave dos cálculos de `remember`; os dados de carro mostrados são recalculados para a mesma semente.
- A nova carreira continua usando a semente exibida durante a escolha, para evitar diferenças depois de confirmar a equipe.

## Verificações
- Teste de regressão adicionado para exigir mudança na ordem completa e no grupo das três piores.
- ZIP deve ser validado com `unzip -t`.
- Nenhum build Android/Gradle completo executado neste ambiente.
