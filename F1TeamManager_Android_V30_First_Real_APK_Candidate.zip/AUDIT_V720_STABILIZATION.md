# AUDIT V720 — Ranking estável, simulação somente leitura e áudio

## Objetivo

Corrigir a oscilação de posição observada ao abrir e fechar a interface de Equipe na primeira semana da terceira temporada e implementar controles de áudio independentes do volume global do Android.

## 1. Diagnóstico e correção do ranking

A simulação física de desenvolvimento da IA era compartilhada por fluxos oficiais da carreira e por projeções solicitadas pelas telas. Em ambos os casos, o motor publicava automaticamente o Overall calculado em `TechnicalInvestmentEngine.recordLiveOverall()`. Isso fazia uma consulta visual modificar a grade global usada pelos próximos cálculos de classificação técnica e capacidade de investimento.

A V720 introduz `publishLiveOverall` nos dois caminhos do motor (`simulateFinancial` e `simulateFinancialFromHandoff`):

- Padrão `true`: mantém publicação para os fluxos oficiais de progressão da carreira.
- `false`: permite calcular garagens para exibição sem alterar o registro global da carreira.

Foi aplicado `false` em:

- Visão das Equipes;
- Ranking das Equipes;
- projeção de força do próximo carro no mercado;
- helper de consulta do perfil da equipe.

A abertura oficial de temporada, avanço semanal, corrida, eventos e finalização preservam a publicação anterior. Assim, a classificação não fica artificialmente congelada: ela pode mudar quando a carreira realmente evoluir, mas não pela simples navegação entre telas.

Foi incluído o teste `AITeamDevelopmentReadOnlyV720Test`, que coloca um Overall conhecido no registro global, executa uma simulação de consulta e verifica que o valor não foi sobrescrito.

## 2. Controles de áudio nas Configurações

A tela Configurações agora oferece:

- interruptor geral para ativar ou desativar músicas e efeitos sonoros;
- barra de volume de 0% a 100%;
- persistência das duas preferências entre sessões do aplicativo.

O ganho é aplicado individualmente nos `MediaPlayer` de música e efeitos por `MediaPlayer.setVolume()`. Não há chamadas a `AudioManager`, `setStreamVolume()` ou alteração do volume do celular. O controle de volume é desabilitado visualmente quando o áudio geral está desligado. Um efeito que ainda esteja em preparação não consegue iniciar depois que o áudio é desativado.

## 3. Preservação

- Nome público permanece `F1 Team Manager V30`.
- Nome do ZIP permanece `F1TeamManager_Android_V30_First_Real_APK_Candidate.zip`.
- V719 é a base imediata.
- Nenhum dado de carreira ou histórico é apagado ou migrado por estas mudanças.

## 4. Validação e limitações

Foram criados testes estáticos para garantir o isolamento das projeções, a aplicação local do volume, a persistência dos controles e a ausência de alteração do volume do sistema. O teste unitário do motor também foi adicionado ao projeto.

Este ambiente não contém Gradle, Gradle Wrapper nem Android SDK; por isso, não é possível declarar `compileDebugKotlin`, JUnit ou `assembleDebug` como executados. O build e os testes Android deverão ser confirmados pelo GitHub Actions.

Teste recomendado no aparelho: na mesma semana e sem avançar o calendário, abrir/fechar Visão das Equipes e Ranking das Equipes em sequência e verificar que as 40 posições permanecem idênticas; depois testar áudio desligado/ligado e volumes de 0%, 25%, 50%, 75% e 100% durante música ambiente e efeitos de corrida.
