# Auditoria V371 — Pipeline de finalização do GP

## Alteração funcional
A ordem de finalização deixou de ser apenas uma convenção implícita no `MainActivity`. `RaceFinalizationPlan` define os identificadores persistidos e a sequência obrigatória; `RaceFinalizationJournal` verifica os pré-requisitos antes de executar uma ação e só aceita o marcador terminal quando todas as etapas previstas estão confirmadas.

## Sequência padrão
1. `player_finance`
2. `player_salary`
3. `ai_finance`
4. `ai_sponsorship`
5. `race_record`
6. `driver_evolution`
7. `race_news`
8. `season_prizes` (somente na última rodada)
9. `persist_final_state`
10. `complete` (marcador terminal, depois das etapas anteriores)

Os nomes persistidos foram mantidos para compatibilidade com os marcadores criados por versões anteriores.

## Testes
- Adicionados testes JUnit para ordem, isolamento por temporada/rodada, repetição de etapa já concluída, interrupção de ação, falha ao gravar marcador, premiação obrigatória no GP final e rejeição de premiação fora do GP final.
- Smoke test Kotlin executado com `kotlinc` para o plano/journal: PASS.
- Integridade do ZIP: verificada após empacotamento.

## Limitações conhecidas
- O JUnit oficial e o build Android completo não foram executados: o projeto fornecido não inclui Gradle Wrapper e não há instalação de Gradle neste ambiente.
- O journal ordena e confirma etapas, mas não torna transacionais os diferentes armazenamentos. Cada ação precisa manter sua própria chave idempotente para cobrir a janela entre o efeito e o marcador.
- A execução completa de 60 GPs com persistência Android real ainda precisa ser feita em ambiente Android/Gradle.
