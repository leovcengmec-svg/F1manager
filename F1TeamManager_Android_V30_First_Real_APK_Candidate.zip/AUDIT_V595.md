# Auditoria V595 — cadastros do jogo

## Achados
1. O catálogo entrava em modo de proteção quando uma equipe personalizada apontava para um piloto oficial (exemplo observado: equipe 41 usando piloto 84). Nesse estado, todas as gravações eram corretamente bloqueadas para evitar perda silenciosa, o que explicava a impressão de que as edições não persistiam.
2. Não havia um fluxo de backup portátil completo para os cadastros, separado do diagnóstico.
3. Os formulários de criação reaproveitavam estados anteriores em algumas aberturas.
4. O país era texto livre em vez de seleção a partir do catálogo de países conhecidos.
5. O campo de asset dos pilotos oficiais começava vazio quando não existia override.

## Correções
- Backup portátil inclui arrays de pilotos/equipes/bandeiras e overrides oficiais.
- Importação valida o formato e os arrays antes da escrita e salva os valores anteriores em preferências com commit síncrono. Se os dados importados tiverem inconsistências semânticas, preserva o backup importado em modo de proteção para permitir recuperação controlada, em vez de rejeitá-lo ou descartar dados.
- Exportação via Android Storage Access Framework para arquivo JSON fora do armazenamento privado do aplicativo, permitindo restauração após reinstalação.
- Recuperação controlada remapeia referências a pilotos oficiais em equipes personalizadas para cópias personalizadas com novos IDs, mantendo o roster sem alterar a base oficial.
- Formulários de inclusão reinicializam os campos a cada abertura.
- Campos País usam opções derivadas dos países oficiais e personalizados, além de países com bandeiras cadastradas.
- Asset de piloto oficial usa override ou padrão `NNN.png`.

## Limitações de validação
ZIP e código-fonte são artefatos entregues; compilação Android, testes JUnit e validação no aparelho não foram executados neste ambiente. Antes de reinstalar, exporte o catálogo e guarde o JSON fora do aparelho. O backup de cadastros não substitui o backup separado da carreira/saves.
