# Auditoria V548 — remoção da regra anual de 70%

## Escopo da raiz
1. `CarDevelopmentEngine.startNextSeason`: removida a transformação genérica em direção ao nível 50 dos atributos resumidos, confiabilidade e componentes dos dois carros físicos.
2. `CarDevelopmentEngine.carryAiCarToNextSeason`: mesma remoção para a representação de compatibilidade da IA.
3. `AITeamDevelopmentEngine.carryAiGarageToNextSeason`: mesma remoção para ambos os carros físicos de cada equipe de IA.
4. `AuditMarker`: removida constante da regra antiga; incluído marcador da política de construção V548.
5. Teste histórico de regressão substituído por teste que verifica a preservação dos valores-base sem bônus adicionais.

## Fluxo que permanece ativo
- O investimento reservado para o próximo carro continua sendo convertido em bônus pela regra existente de classe/etapas.
- Conhecimento técnico e foco continuam aplicados na construção do jogador.
- A IA continua com investimento equilibrado e conhecimento técnico.
- Regulamentos anuais continuam aplicados separadamente.
- Penalidade financeira de fim de temporada permanece separada e não foi alterada.
- A garagem do jogador mantém Carro 1 e Carro 2 individualizados.

## Pesquisa estática
Não devem existir referências executáveis a `ANNUAL_CONTINUITY_FACTOR` ou `ANNUAL_CAR_CONTINUITY`. As menções em documentos V46/V47 são históricas e estão identificadas como superadas pela V548.

## Limitações
Não foi possível executar compilação Android ou testes Gradle: não há `gradlew`/Gradle Wrapper no pacote e o executável Gradle não está instalado. A verificação é de código e estrutura do ZIP, não uma declaração de build aprovado.
