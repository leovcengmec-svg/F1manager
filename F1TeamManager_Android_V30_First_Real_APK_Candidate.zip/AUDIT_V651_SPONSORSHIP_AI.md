# Auditoria V651 — decisão de patrocínios pela IA

## Escopo
Auditoria da seleção automática de propostas no `TeamSponsorshipEngine`, baseada na V650. Foi mantida a geração de três ofertas iguais às apresentadas ao jogador; a alteração está somente no critério que escolhe uma delas.

## Diagnóstico confirmado na V650
O método anterior `expectedContractValue()` somava o pagamento inicial e multiplicava pagamentos por GP e bônus por toda a duração. Como não havia uma medida independente de retorno por corrida ou flexibilidade de renovação, a duração maior recebia uma vantagem estrutural.

## Regra V651
A seleção usa normalização min-max dentro das três propostas concorrentes. Pesos: 35% receita garantida total; 30% receita garantida média por GP (entrada amortizada pela duração); 20% valor esperado dos bônus; 15% flexibilidade de renegociação. Quando uma dimensão é idêntica entre as ofertas, recebe nota neutra 0,5 para não distorcer a comparação.

O valor esperado dos bônus considera:
- Classificação: aproximação por densidade normal em torno da posição esperada do melhor piloto da equipe, com janela do contrato e dispersão de sete posições.
- Corrida: aproximação logística da chance de terminar na posição-alvo ou melhor.
- As probabilidades são estimativas de IA, não promessa de pagamento. A liquidação financeira real continua sendo determinada pelo resultado efetivo da corrida.

A posição esperada usa o ranking do carro inicial da equipe, o mesmo ranking-base usado para construir a faixa de metas dos contratos.

## Testes adicionados/ajustados
- `SponsorshipAiDecisionV651Test.higherReturnInLessTimeCanBeatTheLongestContract`: proposta curta com melhor retorno por corrida vence contrato longo de menor rentabilidade.
- `SponsorshipAiDecisionV651Test.longerContractStillWinsWhenItsTotalAndPerGpReturnsAreClearlySuperior`: duração longa ainda vence quando a vantagem financeira é substancial.
- `SponsorshipAiDecisionV651Test.bonusEstimateRewardsTargetsAlignedWithTeamStrength`: bônus de classificação em faixa compatível com a força da equipe tem valor esperado maior que meta improvável.
- `SponsorshipAiDecisionV651Test.raceBonusProbabilityReflectsTheTeamsExpectedPosition`: a probabilidade de uma meta de corrida considera a posição esperada da equipe.
- `SponsorshipAiDecisionV651Test.rankingDoesNotTreatAZeroBonusOfferAsHavingARealizedBonus`: propostas sem bônus não recebem valor esperado fictício.
- `CommercialPriorityAndSponsorshipV641Test.aiRenewalEvaluatesTheSameThreeOffersThatThePlayerMarketDisplays`: atualizado para verificar a nova regra, preservando paridade do mercado.

## Limitações
Os testes unitários e a auditoria estrutural não substituem build Android completo nem simulação de jogo em aparelho. Este ambiente não possui Gradle Wrapper, Gradle instalado ou Android SDK; portanto não declaro APK compilado nem teste em dispositivo.
