# V556 — Cadastro explícito de bandeiras por país

## Implementado
- Cadastro persistente de associação País → nome do asset da bandeira dentro das configurações do jogo.
- A lista de associações é armazenada junto ao catálogo personalizado do dispositivo e carregada de forma compatível com instalações anteriores (catálogo ausente inicia vazio).
- `ExternalAssets.loadCountryFlag` consulta primeiro o asset registrado para o país e depois mantém a busca automática anterior como fallback.
- O cadastro aceita somente o nome do arquivo com extensão, sem caminho arbitrário, reduzindo ambiguidades no carregamento.
- Versão Android atualizada para 0.556.0 / versionCode 556.

## Local dos arquivos externos
`Pictures/F1Manager/Assets/countries/`

## Limites conhecidos
- Não foi possível executar compilação Android nem testes automatizados neste ambiente.
- Esta entrega não declara concluída a participação dinâmica de equipes adicionais em todos os fluxos de temporada; essa integração exige validação de ponta a ponta.
