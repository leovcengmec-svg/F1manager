# V556 — Busca de fotos dos quatro pilotos atualizados

- A busca de fotos prioriza os IDs permanentes dos pilotos.
- Adicionados nomes atuais e aliases históricos para os IDs 65, 85, 94 e 97.
- Compatibilidade de nomes de arquivo: `065.png`, `65.png`, `driver_065.png`, `driver_65.png`, nome normalizado e variantes `driver_...`.
- Pasta externa esperada: `Pictures/F1Manager/Assets/drivers/`.
- A atualização configura a descoberta dos arquivos existentes; não inclui as fotografias em si.
- versionCode 556 / versionName 0.556.0.
- Não foi executada compilação Android.
