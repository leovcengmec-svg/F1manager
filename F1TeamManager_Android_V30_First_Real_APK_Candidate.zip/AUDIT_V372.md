# Auditoria V372 — Layout da tela inicial

## Escopo
Primeiro bloco visual depois da fase de integração do motor: melhorar hierarquia e legibilidade da Home sem alterar regras de negócio.

## Mudanças
- Imagem do próximo GP ajustada de proporção quadrada para 16:9, mantendo `ContentScale.Fit` em `RaceImage` para não cortar os assets existentes.
- Acesso rápido passou de três colunas com fonte de 7sp para duas colunas com fonte de 10sp, até duas linhas, botões com altura mínima de 54dp e alinhamento central.
- Mantidos os mesmos rótulos e callbacks; a única mudança é de apresentação e espaçamento.
- Versão Android: 0.372.0.

## Validação
- Inspeção das substituições e verificações estáticas do código: concluídas.
- Integridade do ZIP: verificada após empacotamento.
- Build Android/preview em dispositivo: pendente; o ZIP não inclui Gradle Wrapper e o ambiente não dispõe de Gradle instalado.

## Preservação
- Sem alterações na simulação, estado da carreira, callbacks de navegação, assets externos ou histórico anterior.
