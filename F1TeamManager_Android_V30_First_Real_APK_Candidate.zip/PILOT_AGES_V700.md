# Idades dos pilotos — temporada 2026 (base V700)

Esta relação reproduz exatamente a idade calculada atualmente por `DriverEvolutionEngine.careerAge(driver, 2026)` para os 100 pilotos do banco do jogo. Não são idades verificadas por data de nascimento: a idade inicial é gerada de forma determinística pelo perfil de evolução e pelo ID do piloto; a cada temporada aumenta um ano e, ao completar o ciclo até 43, reinicia em 18.

A interface exibe somente o número da idade em anos. Não foi adicionada classificação textual como jovem, meia-idade ou veterano.

## Pilotos titulares — 80 pilotos / 40 equipes

| Equipe | Piloto titular 1 | Idade | Piloto titular 2 | Idade |
|---|---|---:|---|---:|
| Ferrari | Charles Leclerc | 19 | Lewis Hamilton | 26 |
| McLaren | Lando Norris | 20 | Oscar Piastri | 27 |
| Williams | Carlos Sainz | 19 | Alexander Albon | 26 |
| Mercedes | George Russell | 18 | Kimi Antonelli | 19 |
| Red Bull Racing | Max Verstappen | 26 | Isack Hadjar | 24 |
| Benetton | Michael Schumacher | 29 | Rafael Câmara | 23 |
| Renault | Pierre Gasly | 30 | Franco Colapinto | 22 |
| Team Lotus | Ayrton Senna | 29 | Nikola Tsolov | 21 |
| Alpine F1 Team | Alain Prost | 30 | Gabriele Minì | 20 |
| Brabham | Sebastian Vettel | 21 | Martinius Stenshorne | 19 |
| Tyrrell | Jenson Button | 26 | Alexander Dunne | 18 |
| Jordan Grand Prix | Nico Rosberg | 25 | Dino Beganovic | 32 |
| Minardi | Mika Häkkinen | 26 | Paul Aron | 31 |
| Toro Rosso | Liam Lawson | 23 | Arvid Lindblad | 30 |
| Sauber | Nico Hülkenberg | 24 | Gabriel Bortoleto | 23 |
| BMW Sauber | Nigel Mansell | 23 | Sebastian Montoya | 28 |
| Alfa Romeo | Nelson Piquet | 20 | Mari Boya | 27 |
| Aston Martin | Fernando Alonso | 21 | Lance Stroll | 26 |
| Force India | Niki Lauda | 18 | Joshua Dürksen | 25 |
| Racing Point | James Hunt | 32 | Ritomo Miyata | 24 |
| Brawn GP | Emerson Fittipaldi | 31 | Noel León | 23 |
| Toyota Racing | Jackie Stewart | 30 | Daniel Ricciardo | 18 |
| Honda Racing | Jim Clark | 29 | Tuukka Taponen | 21 |
| Jaguar Racing | Juan Manuel Fangio | 30 | Ugo Ugochukwu | 20 |
| Stewart Grand Prix | Jack Brabham | 27 | Freddie Slater | 19 |
| Cadillac Racing | Mario Andretti | 26 | Théophile Naël | 18 |
| Prost Grand Prix | Damon Hill | 25 | Noah Strømsted | 32 |
| BAR | Kimi Räikkönen | 26 | Matteo De Palo | 31 |
| Haas F1 Team | Felipe Massa | 23 | Mattia Colnaghi | 30 |
| Maserati | Rubens Barrichello | 22 | Enzo Deligny | 29 |
| Bagos F1 Racing | Mark Webber | 21 | Leonardo Vicente | 22 |
| Ford | Juan Pablo Montoya | 22 | James Wharton | 27 |
| Bugatti | Jacques Villeneuve | 19 | Alex Powell | 22 |
| Caterham | Esteban Ocon | 18 | Oliver Bearman | 19 |
| Audi F1 Team | Carlos Reutemann | 32 | Lyam Vicente | 18 |
| Super Aguri | Gilles Villeneuve | 31 | Laurens van Hoepen | 23 |
| Andretti | Sergio Pérez | 30 | Valtteri Bottas | 22 |
| Campos Racing | Gerhard Berger | 29 | Pyong Cris | 18 |
| Invicta Racing | David Coulthard | 28 | Maciej Gładysz | 20 |
| Rodin Motorsport | Eddie Irvine | 27 | Jean Alesi | 19 |

## Pilotos reservas/mercado — 20 pilotos

| Piloto | Idade |
|---|---:|
| Heinz-Harald Frentzen | 26 |
| Jarno Trulli | 18 |
| Nick Heidfeld | 25 |
| Robert Kubica | 32 |
| Heikki Kovalainen | 24 |
| Romain Grosjean | 31 |
| Guanyu Zhou | 23 |
| Giancarlo Fisichella | 30 |
| Takuma Sato | 22 |
| Yuki Tsunoda | 29 |
| Riccardo Patrese | 19 |
| Michele Alboreto | 30 |
| Felipe Drugovich | 18 |
| Bruce McLaren | 27 |
| Ralf Schumacher | 19 |
| Pedro de la Rosa | 22 |
| Adrian Sutil | 18 |
| Mick Schumacher | 25 |
| Pastor Maldonado | 32 |
| Alexander Rossi | 24 |

## Observação para revisão dos dados

A lista revela que a regra atual é sintética, não biográfica. Alguns nomes conhecidos de gerações anteriores recebem idades de 18–32 anos por causa da variação determinística. Esta atualização não altera esses valores: apenas torna visível a idade que o jogo já usa, para que a idade-base possa ser revisada deliberadamente numa etapa separada sem confundir correção visual com alteração da simulação.
