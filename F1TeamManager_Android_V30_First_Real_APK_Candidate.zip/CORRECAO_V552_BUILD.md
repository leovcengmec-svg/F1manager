# V552 — Correção de compilação a partir da base oficial V551

Correções aplicadas sem incorporar alterações de versões posteriores à V551:

1. `MainActivity.kt`: removido `installedPieceVersions` do `TeamCarState.copy`, pois esse campo pertence aos carros físicos (`PhysicalCar`), não ao estado legado `TeamCarState`. A redefinição de versão V0 permanece aplicada aos dois carros físicos da garagem.
2. `CarDevelopmentEngine.kt`: corrigidas as chamadas `base(valor, componente)` no construtor do carro do jogador para `base(componente)`, conforme a assinatura real e a regra que deriva o valor base da garagem física.
3. `ManagerSeasonEngine.kt`: removidas atribuições inválidas de `installedPieceVersions` ao `TeamCarState`, mantendo a redefinição das versões nos dois carros físicos.
4. Atualizada a versão para `versionCode = 552` e `versionName = 0.552.0`.

Validação: estrutura e integridade do ZIP verificadas. Não foi possível executar compilação Gradle neste ambiente porque o projeto não contém Gradle Wrapper e o comando `gradle` não está instalado; portanto, o build Android ainda precisa ser confirmado no ambiente de compilação.
