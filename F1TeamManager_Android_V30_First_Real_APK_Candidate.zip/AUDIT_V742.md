# Auditoria V742 — correção de compilação do mercado de pilotos

## Origem do erro
A captura do GitHub Actions na V741 apresentou `Unresolved reference: signatureFeeForTeam` em `MainActivity.kt` nas linhas 896, 913 e 927, além de erro secundário de inferência de operador na sequência. A causa era a visibilidade de declaração local em Kotlin: `signatureFeeForTeam` estava declarada depois da função local `advanceFreeWeeksSegment`, que já a chamava. Declarações locais Kotlin não podem ser referenciadas antes do ponto em que são declaradas.

## Correção aplicada
- Movida a função local `signatureFeeForTeam` para antes da primeira função que a utiliza.
- Mantidos os parâmetros, defaults, consulta de atributos atuais, classificação financeira e delegação para `DriverMarketEngine.signatureFeeFor()`.
- Nenhuma regra de negócio da V741 foi alterada por esta correção.
- Versionamento atualizado para `versionCode = 742` e `versionName = 0.742.0`.

## Verificações
- Auditoria estática V742: verifica declaração única, posição antes da primeira função de chamada, chamadas posteriores à declaração, delegação para a política central e metadados de versão.
- A compilação Android completa não foi executada neste ambiente: não há Gradle instalado nem Gradle Wrapper no ZIP. O APK deve ser compilado no GitHub Actions.

## Resultado
Correção de ordem/escopo da declaração local aplicada. A atualização V741 de contratos, valores de pilotos, taxas por classe financeira e prioridade comercial é preservada integralmente.
