# V701 — Idades oficiais, ciclo de carreira e teto de classe

- Importadas as 100 idades iniciais de 2026 do arquivo `PILOT_AGES_V700.csv` fornecido pelo usuário.
- Idade avança um ano a cada temporada; após completar 43 anos, o piloto encerra o ciclo e reinicia aos 18 na temporada seguinte, mantendo ID, histórico e identidade.
- Central de notícias recebe aviso de virada de temporada com todos os pilotos que concluíram o ciclo e reiniciaram aos 18.
- Classe Lenda torna-se permanente e não pode ser rebaixada.
- Campeonatos conquistados passam a ser registrados por piloto na carreira; um título é suficiente para cumprir o requisito histórico de Lenda, ainda sujeito à revisão bienal de classe e aos critérios esportivos/overall.
- Evolução natural por desempenho respeita o teto de Overall da classe. Programa de desenvolvimento das instalações pode ultrapassar esse teto, mas continua respeitando potencial individual, limite de atributo e orçamento anual do perfil.
- A IA ainda usa o bônus passivo da instalação de Desenvolvimento de Pilotos, mas não foi implementada nesta revisão uma fila persistente de programas individuais de desenvolvimento para cada equipe de IA; requer estado próprio por equipe e persistência no save.

## Velocidade dos perfis (limite anual por atributo)

| Perfil | Limite anual | Leitura |
|---|---:|---|
| Prodígio | 15 | Mais rápido |
| Auge rápido | 13 | Muito rápido |
| Auge moderado | 11 | Rápido/intermediário |
| Auge tardio | 10 | Intermediário, com pico mais tarde |
| Normal | 8 | Gradual |
| Demorado | 6 | Mais lento |

Esses números são tetos por atributo, não pontos garantidos. O ganho real depende do desempenho por GP, idade, potencial individual e instalação. A idade multiplica a evolução positiva: até 21 anos 1,15x; 22–25 1,05x; 26–29 0,90x; 30–32 0,70x; 33–35 0,48x; 36–38 0,24x; 39+ 0,10x. A pressão de regressão física começa aos 34 anos e cresce com a idade.

A revisão de classe agora roda em cadência bienal: ao fim das temporadas 2027, 2029, 2031 etc., usando as duas temporadas completas anteriores. Rebaixamento exige duas temporadas ruins e Overall abaixo da faixa da classe; Lenda é permanente.
