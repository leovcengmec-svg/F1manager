# Auditoria V335

## Alteração
A fonte única `TyreModel.buildPlansForWeather` agora seleciona o composto recomendado pela intensidade da chuva e gera A/B/C/D usando apenas esse composto. Chuva fraca/moderada = INTERMEDIÁRIO; chuva forte = WET.

## Verificações estáticas
- Confirmado que a geração automática de planos de chuva não inclui o composto alternativo.
- Cada plano mantém soma de stints igual ao total de voltas e cada stint respeita o limite nominal do composto.
- `compoundForWeather` e a recomendação de pneus para pit stop permanecem coerentes com a intensidade da chuva.
- Compilação Android e teste no aparelho não executados nesta sessão.
