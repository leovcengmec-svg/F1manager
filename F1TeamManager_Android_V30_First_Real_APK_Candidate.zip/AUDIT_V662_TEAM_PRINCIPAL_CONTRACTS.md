# Auditoria e correção V662 — Team Principal: propostas e contratos

## Escopo
Base: pacote V661. Escopo restrito ao ciclo de contrato do Team Principal, propostas externas, confiança da diretoria e bloqueio da virada de temporada.

## Regras implementadas

### Confiança da diretoria
O valor inicial padrão já existente era 75%. A V662 define esse valor como baseline mínimo (`INITIAL_BOARD_SUPPORT = 75`) e o aplica no início de uma nova carreira, ao renovar com a equipe atual e ao aceitar um contrato de uma nova equipe. Se a confiança acumulada já for superior a 75%, ela é preservada; se for inferior, sobe para 75%. O prestígio e o histórico de temporadas não são apagados. Ao mudar de equipe, o novo vínculo começa com pelo menos 75% desde o primeiro ano no novo time.

### Propostas externas por prestígio
- Prestígio 0–39: 1 proposta externa.
- Prestígio 40–59: 2 propostas externas.
- Prestígio 60–100: 3 propostas externas.

Para prestígio 0–19, a elegibilidade foi ampliada para todas as posições do grid; a seleção ordena do pior colocado para cima, oferecendo uma porta de entrada a partir do prestígio zero. O limite total continua em até quatro ofertas quando há renovação (a atual mais até três externas).

### Contratos
As únicas durações possíveis agora são 1 ou 2 temporadas. A regra é aplicada à geração das propostas, renovação, aceite de equipe externa, serialização e desserialização. Um save V661 ou anterior que contenha 3 anos é carregado com 2 anos no máximo. Isso evita que a nova regra seja contornada por uma carreira antiga.

Não foi introduzida remuneração, salário nem bônus para o Team Principal.

### Integridade da virada
Se `reviewPending` estiver verdadeiro, a temporada não pode avançar. O bloqueio foi adicionado à ação da Home, ao fluxo `performStartNextSeason` e à própria operação `CareerPreferences.startNextSeason`, antes de qualquer mutação da temporada. Ao renovar ou aceitar uma equipe externa, o estado contratual é resolvido e a virada volta a ser permitida. Um contrato externo aceito continua sendo ativado somente no início da próxima temporada.

## Arquivos alterados
- `app/src/main/java/com/f1teammanager/core/manager/TeamPrincipalCareerEngine.kt`
- `app/src/main/java/com/f1teammanager/CareerPreferences.kt`
- `app/src/main/java/com/f1teammanager/MainActivity.kt`
- `app/src/test/java/com/f1teammanager/core/manager/TeamPrincipalContractCycleV639Test.kt`
- `app/src/test/java/com/f1teammanager/core/manager/V586TeamPrincipalCareerEngineTest.kt`
- `app/src/test/java/com/f1teammanager/core/manager/V638TeamPrincipalHandoffRegressionTest.kt`
- `app/build.gradle.kts`
- `CHANGELOG_V662.md`

## Verificações estáticas realizadas
- Conferência dos limites de duração em todos os pontos de criação, validação, leitura e gravação dos contratos Team Principal.
- Conferência das faixas de propostas e elegibilidade em prestígio zero.
- Conferência do reset para 75% na carreira inicial, renovação e contratação por nova equipe.
- Conferência do bloqueio de virada na interface e na camada persistente.
- Conferência de `versionCode = 662` e `versionName = 0.662.0`.

## Limitações
Os novos testes JUnit foram adicionados/atualizados, mas não foram executados. Não há Gradle instalado, Gradle Wrapper no pacote ou Android SDK disponível neste ambiente; portanto, não afirmo que a compilação Android foi concluída. A integridade do ZIP será verificada separadamente após a geração do pacote.
