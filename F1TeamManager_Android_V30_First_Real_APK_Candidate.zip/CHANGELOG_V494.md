# V494 — Semente imutável para ranking do carro inicial

- Corrigida a causa raiz da divergência entre as três equipes do Modo Difícil e as posições 38–40 do perfil das equipes.
- A semente do carro inicial é agora persistida separadamente em `openingCarSeed` e permanece estável durante toda a carreira.
- A geração de uma nova semente de calendário por temporada não altera mais o perfil físico inicial nem o ranking de abertura.
- Incluída migração para carreiras existentes: preserva a semente de abertura de 2026 quando disponível, sem apagar regulamentos, assets ou histórico.
- A criação de uma nova carreira grava a semente usada na seleção, mantendo o trio selecionado consistente ao abrir o jogo.
- O ranking continua sendo calculado pelo overall físico dos carros iniciais, com desempate estável por ID.
