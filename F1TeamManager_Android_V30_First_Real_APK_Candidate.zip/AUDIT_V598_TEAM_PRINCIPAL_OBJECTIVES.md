# Auditoria V598 — objetivos do Team Principal

## Alterações
- Prestígio inicial de novas carreiras reduzido de 10 para 1.
- Meta principal recalculada conforme a posição da equipe: equipes do fundo do grid recebem metas alcançáveis; equipes fortes recebem metas mais exigentes.
- Cada temporada passa a ter seis objetivos: 1 principal (posição), 1 secundário (saldo financeiro) e 4 sazonais escolhidos de um conjunto variável.
- Objetivos esportivos incluem pontos, evolução de posição, competitividade e posição no grid; objetivos de top 10/top 20 são filtrados conforme a força inicial da equipe.
- Objetivos cumpridos somam prestígio e objetivos fracassados descontam pontos. A variação positiva máxima é +8 por temporada.
- Estado dos objetivos e resultados usa schema 3, mantendo leitura de saves schema 1 e 2.

## Testes
- `tools/save_test/v598_team_principal_objectives_test.py`: 15/15 verificações estáticas passaram.
- Integridade do ZIP verificada após empacotamento.
- A compilação Android, testes JUnit e simulação ponta a ponta não foram executados neste ambiente; V598 é candidata até o workflow Android confirmar o build.

## Limitação conhecida
O objetivo financeiro lê o saldo/budget persistido da equipe no ledger de orçamentos AI. É necessário validar no build/simulação integrada que esse saldo corresponde ao caixa apresentado para a equipe Team Principal em todos os pontos da temporada.
