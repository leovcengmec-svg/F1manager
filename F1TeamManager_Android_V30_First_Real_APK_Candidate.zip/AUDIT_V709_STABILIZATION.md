# Auditoria estrutural de estabilização — V709

## Identificação
- Público: F1 Team Manager V30
- VersionCode: 709
- VersionName: 0.709.0
- Base: V708
- ZIP: `F1TeamManager_Android_V30_First_Real_APK_Candidate.zip` (nome preservado)

## Escopo desta estabilização
1. Distribuição do envelhecimento natural pelos sete atributos do piloto.
2. Recuperação parcial do ciclo de idade nos mesmos sete atributos, sem reverter perdas esportivas.
3. Progressão natural de pilotos sem equipe até seu potencial individual, sem regressão esportiva.
4. Correção das notícias para explicar a causa e os atributos afetados.
5. Bloqueio de aportes no próximo carro pelo teto de Overall, além do limite financeiro, com validação na UI e no motor.

## Resultado da inspeção
- O motor de envelhecimento usa o conjunto completo de índices 0..6, associado a VEL, CLA, ULT, DEF, CON, CHU e PNE.
- Os ledgers de perdas e picos seguem persistidos em vetores de sete posições. Os nomes históricos das chaves são preservados para compatibilidade de save; sua semântica foi ampliada para os sete atributos.
- A recuperação de ciclo mantém a fração agregada de 50%, a distribuição por maiores restos e o limite por pico histórico de cada atributo.
- O fluxo de piloto livre usa evidência neutra, pode ultrapassar o teto da classe e para no potencial individual. Um saldo negativo herdado da fase contratada é descartado ao entrar nesse fluxo.
- As telas de carreira e Team Principal mantêm os dados do piloto livre e registram notícias com causas separadas.
- `nextSeasonForecast` calcula o teto da faixa, o investimento-meta e o restante; `investNextSeason` rejeita o aporte após a meta e também rejeita excesso de valor. A tela desativa os botões e não oferece valor superior ao restante necessário.

## Testes e verificações
- Testes Kotlin específicos acrescentados para progressão de agente livre, banco negativo legado, envelhecimento em todos os atributos, notícias e limite do próximo carro.
- Script estático V709 acrescentado para conferir os caminhos de carreira, Team Principal, mercado, UI e motor financeiro.
- `tools/validate_release_contract.py` permanece como validação de metadados e integrações gerais do release.

## Limites
Não foi possível executar Gradle, Android SDK, compilação APK ou a suíte JUnit completa neste ambiente. Não se declara build Android aprovado nem ausência absoluta de erros em runtime. A validação final de compilação e testes deve ocorrer no workflow GitHub Actions.
