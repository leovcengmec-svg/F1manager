# V378 — Bloco 2: auditoria integrada de duas temporadas

## Escopo desta entrega
- Executável de auditoria de carreira para percorrer 60 GPs consecutivos no motor `ManagerSeasonEngine`, usando classificação e corrida reais do motor de corrida.
- Valida a classificação completa de 80 pilotos, IDs únicos, posições 1–80, qualificação Q1/Q2/Q3 com campos 80/50/20 e pontos não negativos em cada GP.
- Valida a sincronização manager/calendário, orçamento não negativo, garagem física com dois carros, 80 contratos ativos e marcador idempotente de evolução em cada GP.
- Valida expiração do patrocínio após 30 corridas, premiações de encerramento, reinício para GP1 e transições de 2026→2027→2028.
- Preserva as verificações de evolução para 100 pilotos e a resolução de movimentações do mercado ao longo da cadeia.

## Limites explícitos
- O audit executável cobre o motor de temporada integrado; não substitui testes Android de persistência do `SharedPreferences` nem a execução pelo ciclo visual do aplicativo.
- A compilação Android e a suíte JUnit oficial não são declaradas aprovadas neste ambiente.
- A auditoria de instalação e pacote final continua reservada ao Bloco 3.

## Preservação
- `versionCode = 378`, `versionName = 0.378.0`.
- Sem alterações de layout, botões ou assets externos.
- Histórico de versões preservado.

## Resultado da execução
- `TwoSeasonChainRuntimeAudit`: PASS — 60 GPs; 2026 e 2027 completas; transição para 2028 GP1; 80 pilotos ativos; 100 estados de evolução; 60 marcadores de evolução; premiações de 2026 e 2027 registradas.
- `TwoSeasonChainAuditTest`: PASS em harness local compatível com assertions (não runner oficial JUnit).
- `FullSeasonIntegrationTest`: PASS — 30 GPs e transição para 2027 GP1.
- `validate_project.py`: 32/32 PASS.
