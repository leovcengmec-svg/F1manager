# Auditoria V614 — Card de conclusão de instalação na HOME

## Causa corrigida
O card da HOME selecionava qualquer notificação chamada `MELHORIA DE INSTALAÇÃO` e excluía mensagens que continham `Desenvolvimento de Pilotos`. O mesmo título era usado tanto no início quanto na conclusão, e as notificações da IA também usam títulos genéricos. Isso tornava a seleção ambígua e podia suprimir uma instalação válida do jogador.

## Correções
- Criado `FacilityUpgradeNotificationPolicy` para distinguir início e conclusão, reconhecer avisos legados e associar conclusões ao evento de início da equipe do jogador.
- A conclusão criada no avanço de calendário usa `MELHORIA DE INSTALAÇÃO CONCLUÍDA` e inclui o nome da equipe do jogador.
- O card da HOME só considera conclusão não lida da temporada atual e reconhecida como pertencente à equipe do jogador.
- Upgrades da instalação Desenvolvimento de Pilotos passam a ser elegíveis para o card de instalação concluída, sem confusão com o card separado de programa de desenvolvimento de um piloto.
- Adicionada recuperação idempotente de notificações que faltam em saves antigos, baseada no registro de início e no nível de instalação persistido. Um upgrade ainda ativo não gera conclusão.
- A notícia de conclusão usa o asset que já existia `event_annual_facility_upgrade`; não foram geradas imagens.

## Arquivos alterados
- `app/src/main/java/com/f1teammanager/MainActivity.kt`
- `app/src/main/java/com/f1teammanager/core/manager/FacilityUpgradeNotificationPolicy.kt`
- `app/src/test/kotlin/com/f1teammanager/FacilityUpgradeHomeEventV614Test.kt`
- `app/build.gradle.kts` (versionCode 614, versionName 0.614.0)
- `CHANGELOG.md`

## Testes direcionados adicionados ao projeto
- Um aviso de início não se qualifica como conclusão.
- Conclusão explícita deve pertencer à equipe do jogador.
- Conclusão legada é associada ao aviso de início da equipe, inclusive para a instalação `Desenvolvimento de Pilotos`.
- Conclusão ausente é recuperada do estado salvo, sem duplicar um evento conhecido ou concluir uma melhoria ainda ativa.

## Limites
O ZIP foi validado estruturalmente e a política de eventos foi compilada/testada em harness isolado. Compilação Gradle/Android completa, suíte JUnit integral e teste visual em dispositivo/emulador não são afirmados sem execução bem-sucedida.

## Resultado da validação isolada
- Compilado `FacilityUpgradeNotificationPolicy.kt` contra as classes Kotlin do núcleo já compiladas.
- Executado smoke test cobrindo: início não é conclusão; conclusão legada associada à equipe correta; filtro entre equipes; recuperação de conclusão ausente; atualização com upgrade ainda ativo; idempotência quando uma notificação explícita já existe.
- Resultado: `V614_FACILITY_HOME_EVENT_POLICY_PASS`.
- Verificação Kotlin/Android completa: não executada, pois este pacote não contém Gradle Wrapper e não há `gradle` instalado no ambiente.
