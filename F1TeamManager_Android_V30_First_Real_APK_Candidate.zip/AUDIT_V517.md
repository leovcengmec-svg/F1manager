# Auditoria V517 — P&D entre temporadas

## Causa raiz
`ResearchEngine.advanceWeeks` gravava `cooldownUntil` usando semana local da temporada (conclusão + 4), enquanto `CareerPreferences.startNextSeason` reiniciava `currentWeek` para 1 sem expirar os cooldowns. Na temporada seguinte, a interface comparava os números de semanas de calendários diferentes e exibia bloqueios indevidos de 28–30 semanas.

## Correção
A transição oficial limpa `cooldownUntil` através de `ResearchEngine.clearSeasonBoundaryCooldowns`. Projetos ativos e designs concluídos são preservados. Nenhum evento aleatório é responsável por esse bloqueio.

## Verificação
Incluído `ResearchSeasonCooldownV517Test` cobrindo limpeza de cooldowns e preservação de progresso. ZIP será validado estruturalmente; compilação/testes reais requerem Gradle.
