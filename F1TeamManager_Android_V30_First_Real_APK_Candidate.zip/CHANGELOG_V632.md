# V632 (0.632.0) — Clima por circuito

- Reduzida a frequência de alterações climáticas na classificação e corrigido o marcador entre Q1, Q2 e Q3.
- Corrigido o sorteio climático da corrida para não tentar novamente em voltas consecutivas quando nenhum estado muda.
- Introduzidos perfis climáticos por circuito; corrida e classificação têm sorteios iniciais separados.
- Clima meteorológico utiliza RNG isolado para preservar a sequência de desempenho e incidentes.
- O sorteio de clima da corrida é feito uma única vez e os planos de pneus correspondem às condições de largada.
