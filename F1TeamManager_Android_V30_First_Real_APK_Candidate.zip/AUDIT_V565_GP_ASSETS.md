# Auditoria V565 — Assets de GPs

## Alterações verificadas estaticamente
1. `RaceImage` passa `round.grandPrix`, `round.circuit` e `round.assetSearchName` ao carregador.
2. `loadGrandPrixImage` pesquisa nas pastas externas `races`, `GPs`, `gps`, `circuits` e `tracks`.
3. Os nomes candidatos incluem o nome exibido, circuito e nome de busca do cadastro, além de variantes comuns sem sufixos.
4. A chave de cache inclui GP, circuito e `assetSearchName`.
5. Resultados nulos não são armazenados no cache.

## Limitação
A inspeção estática não confirma a leitura no aparelho nem substitui uma compilação Android. O ZIP não contém imagens de GP; elas devem permanecer em `Pictures/F1Manager/Assets/` nas pastas suportadas.
