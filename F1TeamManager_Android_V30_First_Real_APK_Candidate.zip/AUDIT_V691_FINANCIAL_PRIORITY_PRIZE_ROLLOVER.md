# Auditoria V691 — investimento anual e fechamento financeiro

## 1. Prioridade do próximo carro

- A prioridade de abertura é €80M, derivada de 40% do envelope original de €200M.
- A função não recalcula os 40% sobre um saldo cada vez menor. Com €80M consumidos por P&D/instalações, continuam protegidos €80M do próximo carro enquanto houver caixa e envelope suficientes.
- P&D do carro atual e instalações compartilham o restante, sem teto individual rígido.
- A partir do GP25, o próximo carro pode receber saldo tecnicamente livre que as outras categorias não consumiram.
- O teto de €150M por projeto e o teto global de €200M/temporada continuam ativos.

## 2. Virada de temporada

`ensureFinanceSeason(teamId, season)` é agora a fronteira canônica usada por `beginSeason`, previsões financeiras, leituras do orçamento e débitos:

- mantém o caixa efetivo e os ledgers históricos, inclusive `seasonPrizesPaid`;
- zera `seasonIncome`, `seasonExpenses`, `raceIncome` e `raceExpenses` do novo ano;
- cria explicitamente um `TechnicalInvestmentState` novo para a temporada;
- remove, apenas para a nova chave anual, compromissos de carro seguinte, base de orçamento, decisão da temporada anterior, alvo satisfeito e penalidade anual anterior;
- não apaga upgrades de instalação em andamento nem reservas históricas de instalação que ainda sejam compatíveis.

O caminho de leitura `remainingTechnicalBudget()` chama essa fronteira antes de calcular o saldo. A tela geral também sincroniza os estados da IA antes de capturar caixa e orçamento disponível. Na virada, `openNewSeasonForAllTeams()` força a criação de um ledger técnico anual limpo mesmo para snapshots legados em que o campo `State.season` já esteja no ano novo, mas os débitos técnicos estejam contaminados.

## 3. Premiação de construtores

`CareerPreferences.settleConstructorsSeason()` congela primeiro uma classificação de prêmio durável para as 40 equipes. Usa a tabela histórica validada quando disponível; se a tabela de corridas não estiver completa no GP30, deriva a classificação da pontuação oficial da carreira por meio de `SeasonSettlementEngine`, mantendo também equipes com zero pontos. Depois calcula os prêmios com `SeasonPrizeEngine` e grava cada pagamento no ledger financeiro individual. O marcador `seasonPrizesPaid` continua sendo a fonte de idempotência; o cache legado `aiTeamBudgets` é atualizado a partir dos saldos reais.

A classificação congelada é persistida antes do primeiro crédito. Se o processo for encerrado no meio dos 40 pagamentos, a reconciliação consegue retomar os ledgers que faltam, mesmo quando o arquivo histórico de corridas não foi finalizado. A reconciliação é chamada durante o sincronismo semanal e imediatamente antes da imagem de rollback da virada de temporada.

A classificação histórica é preferida quando está completa. Se ela estiver incompleta no fechamento do GP30, a classificação oficial de pontos ainda disponível na carreira é congelada como fallback, com as 40 equipes e posições únicas. Para temporadas históricas sem arquivo de classificação nem snapshot congelado, a operação continua bloqueada em vez de inventar posições.

## 4. Contabilidade e interpretação do painel

- `Invest. Disponível` é o saldo do limite técnico anual, não uma indicação de que a equipe possui o mesmo valor em caixa.
- Cada débito de P&D, instalação ou carro seguinte continua usando `FinanceEngine.applyCashDebitFinance`, que reduz caixa e aumenta despesas da temporada.
- O novo teste de rollover verifica que o débito do próximo carro aparece em `seasonExpenses` e que a nova temporada começa com o envelope técnico integral.

## 5. Verificações

- `SeasonInvestmentPolicy.kt` compilado isoladamente com stub mínimo: aprovado.
- Smoke test de proteção inicial, pool compartilhado, teto por projeto e teto global: aprovado.
- Inspeção estática das chamadas `ensureFinanceSeason`, da persistência do snapshot, dos marcadores `seasonPrizesPaid`, do fluxo GP30 e da transição anual: aprovada.
- Não foi possível executar APK/Gradle ou JUnit completo neste ambiente; a validação final de build permanece no GitHub Actions.
