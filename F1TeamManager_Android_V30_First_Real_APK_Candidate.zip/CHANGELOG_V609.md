# V609 — simulação fora da thread principal

- Diagnóstico baseado no vídeo enviado: a classificação progride, mas o Android apresenta “não está respondendo” ao iniciar/processar a corrida.
- Move cada passo de classificação e corrida manual para `Dispatchers.Default`, devolvendo os snapshots para a UI na thread principal.
- Move o motor completo da simulação instantânea para `Dispatchers.Default`; mantém a finalização/persistência da carreira na thread principal.
- Adiciona guardas contra disparos simultâneos de passos de classificação, corrida e simulação instantânea.
- Mantém a mesma implementação de domínio `CareerWeekendEngine`; não cria um segundo motor nem altera as regras esportivas.
- Limitação: este ambiente não possui Gradle/Gradle Wrapper nem Android SDK executável; compilação APK e teste em aparelho/emulador continuam pendentes.
