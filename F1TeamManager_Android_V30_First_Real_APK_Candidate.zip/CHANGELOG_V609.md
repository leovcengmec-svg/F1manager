# V609 — Correção de compilação da tela do próximo carro

- Corrigida referência Kotlin inexistente `investableBudget` em `MainActivity.kt`, responsável pela falha `Unresolved reference` em `:app:compileDebugKotlin`.
- O cartão de orçamento agora exibe o caixa disponível após a reserva operacional; o teto cumulativo absoluto continua sendo apresentado separadamente.
- Removida a variável redundante `investableRemaining`; os botões e o cálculo de disponibilidade respeitam o saldo após reserva e o teto acumulado restante.
- Preservadas as regras do mercado de pilotos V608, assets externos, histórico completo, dados de carreira e saves.
- Validação estática local confirma que as referências removidas não existem mais. Compilação Gradle/Android não executável neste ambiente: a origem não contém `gradlew` e o comando `gradle` não está instalado.
- Auditorias direcionadas, gerais e estruturais aprovadas; assets e histórico da V608 preservados integralmente.

