# Auditoria V396

## Escopo
Ajuste visual do cabeçalho dos cards de pilotos no diálogo Plano de Início da Corrida.

## Alterações verificadas estaticamente
- Nome do piloto ocupa a primeira linha do bloco de identificação.
- Bandeira, escudo e posição aparecem alinhados na segunda linha.
- Cards de bandeira, escudo e posição têm 36 dp de altura.
- Card de posição tem 48 dp de largura e texto de uma linha.
- Card de overall preserva 46 × 48 dp.
- `versionCode=396`; `versionName=0.396.0`.

## Validação
Verificação estática do diff e integridade do ZIP. Compilação Android não foi executada neste ambiente; requer confirmação no workflow Build Debug APK.
