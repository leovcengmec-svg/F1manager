# Auditoria V718 — Estabilização e escalabilidade

## Escopo

Revisão focada em carreiras extensas de 10, 15 e 20 temporadas, com atenção à simulação das 39 equipes controladas pela IA, às telas que dependem de snapshots das equipes, ao histórico de GPs/temporadas e aos snapshots financeiros.

## Correções estruturais implementadas

1. **Desenvolvimento padrão da IA:** checkpoints persistentes e em memória guardam o estado de abertura de cada temporada. O fingerprint contempla identidade da carreira, equipe, seed, regulamento, ranking técnico, investimentos históricos e penalidades financeiras.
2. **Modo Team Principal:** caminho de checkpoint próprio, com fingerprint que inclui o handoff codificado. A cadeia não reexecuta todas as temporadas desde a troca de dirigente em cada consulta.
3. **Cache limitado:** simulações físicas e estados históricos usam LRU limitados; arquivos persistentes mantêm no máximo oito checkpoints por equipe.
4. **Snapshots compartilhados:** Visão das Equipes e Ranking das Equipes usam a mesma chave de cache e o mesmo mapa de garagens. Eventos anuais, handoffs, finanças e ranking técnico participam da invalidação.
5. **Determinismo em lotes:** processamento semanal, corrida, evento e notícia de desenvolvimento congela o ranking técnico antes de percorrer as equipes.
6. **Histórico:** reparo de resumo é lazy; o último GP é lido a partir do shard mais recente; caches de temporadas do arquivo legado são limitados; linhas brutas são liberadas após gerar a fotografia interpretada.
7. **Finanças da IA:** o fingerprint não usa `exportSnapshot().hashCode()`. Ledgers grandes são compactados, com leitura retrocompatível do formato antigo.

## Cenários de 10 temporadas, 15 temporadas e 20 temporadas

Os cenários de 10 temporadas, 15 temporadas e 20 temporadas estão contemplados nas contagens abaixo e na homologação recomendada.

## Crescimento estimado do arquivo histórico

A carreira mantém os resultados oficiais, sem apagar temporadas antigas. Considerando 30 GPs por temporada e até 80 registros de pilotos por GP, o volume aproximado de linhas de resultados de corrida cresce assim:

| Temporadas | GPs | Registros de pilotos de corrida (até 80 por GP) |
|---:|---:|---:|
| 5 | 150 | 12.000 |
| 10 | 300 | 24.000 |
| 15 | 450 | 36.000 |
| 20 | 600 | 48.000 |

Classificação, poles, voltas rápidas e resumos de temporada acrescentam registros além desses valores. Isso é crescimento linear, não quadrático, porque cada GP é gravado em shard próprio e o encerramento de temporada consulta somente a temporada alvo.

## O que esta auditoria consegue confirmar

- Os caminhos principais não precisam reconstruir o desenvolvimento de todas as temporadas anteriores em cada tela, depois de existir um checkpoint compatível.
- A primeira execução sem checkpoint ainda precisa reconstruir o histórico necessário uma vez e gravar checkpoints; isso pode demorar mais em uma carreira antiga já importada.
- Navegar entre Visão das Equipes e Ranking reaproveita snapshots enquanto a chave da carreira não mudar.
- O último GP não exige leitura de todos os shards.
- Os caches têm limites explícitos; os arquivos históricos oficiais não são descartados.

## Limitações de validação

- Não foi possível executar Gradle/Android SDK nesta sessão; portanto não há build Android integral nem suíte JUnit completa aprovada aqui.
- Não foram executados benchmarks no aparelho Android com saves reais de 10, 15 ou 20 temporadas. As projeções de linhas acima são contagens matemáticas baseadas no calendário e no tamanho potencial do grid, não medições de RAM, I/O ou latência.
- A fluidez final também depende do dispositivo, do tamanho real do ledger financeiro e da quantidade de dados legados que a carreira traz.

## Homologação recomendada

No GitHub Actions, executar `:app:testDebugUnitTest` e `:app:assembleDebug`. Em aparelho Android, usar cópias de saves com 5, 10, 15 e 20 temporadas e medir: abertura da Home, troca entre as 40 equipes, Ranking (três modos), História, Hall da Fama, Recordes, avanço de semana, finalização de GP, uso de RAM e tamanho do backup. A primeira abertura após migração deve ser medida separadamente das visitas seguintes, pois ela pode gerar checkpoints faltantes.

## Veredito

A V718 melhora a arquitetura para crescimento linear e evita reconstruções históricas repetidas nos caminhos de desenvolvimento da IA, inclusive Team Principal. A estrutura ficou mais preparada para carreiras longas, mas não é correto prometer fluidez garantida em 20 temporadas sem medições reais no Android.
