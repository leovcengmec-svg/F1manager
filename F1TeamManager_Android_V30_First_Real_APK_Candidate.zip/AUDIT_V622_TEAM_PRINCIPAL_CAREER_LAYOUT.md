# Auditoria V622 — Tela Minha Carreira

## Objetivo
Comparar a tela antiga com o mockup aprovado e implementar uma estrutura compacta e consistente, adequada à largura lógica de telefones como o Poco X7 Pro, mantendo a página principal sem rolagem vertical.

## Diferenças objetivas

As imagens de comparação chegaram em exportações de tamanhos diferentes: a captura atual mede **305 × 1521 px** e o mockup de referência mede **1024 × 1536 px**. Esses pixels exportados não representam diretamente a resolução lógica do Poco X7 Pro; por isso, o novo front-end mede largura e altura em **dp do Compose** e adapta margens/densidade ao espaço disponível, em vez de fixar dimensões em pixels.


| Aspecto | Layout atual antes da V622 | Referência aprovada | Implementação V622 |
|---|---|---|---|
| Dimensões/base | A tela ocupava uma coluna longa e dependia do tamanho total do conteúdo. A função aplicava `fillMaxSize().verticalScroll(...)`. | Conteúdo de carreira inteiro visível dentro da área útil vertical de um telefone, sem aparência de captura esticada. | `BoxWithConstraints` adapta a densidade à altura/largura disponíveis em dp; o pai da tela não tem `verticalScroll` nem rolagem horizontal. |
| Margens | `16.dp` horizontais, `12.dp` verticais e 12 dp entre seções. | Margens menores proporcionais à tela e espaçamento regular. | 8 dp se largura disponível for menor que 370 dp; caso contrário, 11 dp. Padding vertical de 5 dp e gaps de 5–6 dp. |
| Cards | Raios e preenchimentos variavam (14–16 dp), com cards de objetivos e conquistas altos em uma única coluna. | Cards visivelmente padronizados e agrupados em grades/tabela. | Cards externos com raio de 14 dp, borda de 1 dp; tiles internos com raio de 8 dp e borda de 1 dp. A altura é distribuída por pesos, não por rolagem do conteúdo todo. |
| Cores | Fundo `#08090C`, superfícies `#14161B` / `#1B1E24`, texto secundário `#8D929C`, destaque verde `#38C878`; parte dos indicadores era só texto/glyph. | Mesmo tema escuro, dourado com contorno destacado, cinza azulado em rótulos e verde para estados positivos. | Paleta consistente preservada; dourado `#FFC857`, bordas `#2B2F3A`, cinza azulado `#9AA3B7`, verde `#38C878` e azul `#72B7F2`. |
| Tipografia | Título `23.sp`; a hierarquia se perdia porque as linhas de objetivos e as conquistas eram estreitas e empilhadas. | Títulos de seção destacados, labels discretos e números/valores alinhados. | Título de página `19–21.sp`; cabeçalhos `11–12.sp`; dados e textos das células entre ~7–11.sp com ajuste em telas compactas. |
| Alinhamento | Os títulos/descrições de objetivos começavam depois de uma coluna de categoria de largura fixa (`76.dp`); valores eram distribuídos verticalmente. | Títulos de seção alinhados com ícones, bônus à direita e textos usando o espaço disponível do tile. | Objetivos passam a uma grade 2×3 com ícone, categoria, texto do objetivo em até duas linhas e bônus alinhado à direita; contrato/metas ficam em caixas simétricas. |
| Proporções | Objetivos: 6 linhas, cada uma com título e detalhe; conquistas: 8 cards em sequência vertical; trajetória: vazio sem tabela. | Objetivos em duas colunas; conquistas em duas colunas e quatro linhas; trajetória com tabela compacta. | Objetivos em grade de duas colunas; conquistas em grade 2×4; trajetória com colunas Ano, Escudo, Equipe, POS, VIT, POLE, POD e larguras proporcionais ao conteúdo. |
| Ícones | Estrelas e símbolo de trajetória eram glifos Unicode (★, ☆, ▥); não havia ícone semântico para vários cabeçalhos. | Ícones semânticos e uniformes; escudo da equipe por temporada. | Ícones Material de troféu, bandeira, estrela, bloqueio, confirmação e gráfico. A coluna Escudo usa `TeamLogo` e os assets existentes. |
| Comportamento | A página toda rolava; a trajetória era apenas texto vazio/placeholder, sem expansão. | Card da trajetória com tabela por temporada e indicação de expansão. | Página principal fixa. A trajetória começa recolhida (até 3 temporadas recentes), expande para o histórico completo e restringe eventual rolagem à área interna das linhas do próprio card. |

## Mapeamento do código

- `app/src/main/java/com/f1teammanager/TeamPrincipalCareerScreen.kt`: novo front-end da tela, cards de prestígio/objetivos/conquistas/trajetória, pesos adaptativos e estilos compartilhados.
- `app/src/main/java/com/f1teammanager/MainActivity.kt`: chama a nova tela preservando os callbacks existentes e constrói `trajectoryStats` a partir do histórico oficial. O helper `TeamLogo` passou de `private` para `internal` para permitir reutilização pelo novo arquivo; a renderização do escudo e o carregamento dos assets não foram reescritos.
- `app/src/main/java/com/f1teammanager/core/manager/TeamPrincipalCareerEngine.kt`: dados de carreira/objetivos e resultados persistidos permanecem intactos.
- `app/src/main/java/com/f1teammanager/CareerPreferences.kt`: sem alteração.

## Dados e integridade

- A tabela usa `state.records`, `store.history.constructorSeasonRecords()` e `store.history.raceRecords()` por temporada/equipe.
- Vitórias e poles ausentes no histórico legado aparecem como “—”; pódios aparecem como zero somente quando há registros de corrida para aquela temporada/equipe.
- Nenhum dado de exemplo do mockup foi incluído no jogo.
- Confirmado: os 195 assets de `app/src/main/assets` têm caminhos e hashes SHA-256 idênticos aos da V621.

## Limitação da validação

O ambiente não tem Gradle/Android SDK ou wrapper `gradlew` disponíveis, então esta entrega recebeu revisão estática e verificações de ZIP/assets, não um `assembleDebug` nem inspeção visual em um dispositivo Poco X7 Pro. O pipeline precisa confirmar a compilação Android.
