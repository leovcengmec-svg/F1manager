#!/usr/bin/env python3
"""Deterministic structural + balance audit for the annual car-regulation engine.
This does not replace Android/JUnit execution; it checks source invariants and a
mathematical model of the documented reductions across 40 distinct team profiles.
"""
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
engine = (ROOT / 'app/src/main/java/com/f1teammanager/core/manager/AnnualCarRegulationEngine.kt').read_text()
prefs = (ROOT / 'app/src/main/java/com/f1teammanager/CareerPreferences.kt').read_text()
ai = (ROOT / 'app/src/main/java/com/f1teammanager/core/manager/AITeamDevelopmentEngine.kt').read_text()
activity = (ROOT / 'app/src/main/java/com/f1teammanager/MainActivity.kt').read_text()

checks = []
def check(name, condition):
    checks.append((name, bool(condition)))
    if not condition:
        raise AssertionError(name)

# Catalog: exactly 18 unique event IDs, 3 events for every component, reductions 5–10%.
events = re.findall(r'Event\("([A-Z0-9-]+)",\s*"[^"]+",\s*CarComponent\.([A-Z_]+),\s*(\d+)\)', engine)
check('18 unique annual events', len(events) == 18 and len({e[0] for e in events}) == 18)
components = {'ENGINE','CHASSIS','FRONT_WING','REAR_WING','BRAKES','ELECTRIC_POWER_UNIT'}
check('all six components represented exactly three times', {c:sum(1 for e in events if e[1] == c) for c in components} == {c:3 for c in components})
check('annual reductions stay in 5..10%', all(5 <= int(e[2]) <= 10 for e in events))
check('decennial values present', all(f'CarComponent.{c} to {v}' in engine for c,v in {
    'ENGINE':35,'CHASSIS':25,'FRONT_WING':40,'REAR_WING':40,'BRAKES':25,'ELECTRIC_POWER_UNIT':35}.items()))
check('season 1 exempt and decennial starts season 11', 'if (season == 1) return SeasonRule(1, emptyList(), false, emptyMap())' in engine and 'season > 1 && (season - 1) % 10 == 0' in engine)

# Persistence and identical championship seed for player/AI.
check('season rules are persisted with commit', 'carRegulationRule_$seasonNumber' in prefs and '.commit()' in prefs)
check('AI uses shared regulation seed', 'generateForCalendarYear(s + 1, 20261005)' in ai)
check('player uses same shared rule source', 'ensureCarRegulationRule(store.season)' in activity and 'val seed = 20261005' in prefs)

# Transition order: new car construction happens before applying regulation; persist after.
construct = activity.find('managerState = development.startNextSeason(managerState, store.season)')
apply = activity.find('AnnualCarRegulationEngine.applyToGarage(', construct)
rank_rebuild = activity.find('TechnicalInvestmentEngine.forTeam(', apply)
save = activity.find('store.saveGarage(teamId, managerState.garage', rank_rebuild)
check('new car -> regulation -> new technical ranking -> garage persistence order', -1 not in (construct, apply, rank_rebuild, save) and construct < apply < rank_rebuild < save)
check('regulation does not directly alter reliability', 'reliability =' not in engine[engine.find('fun applyToGarage'):engine.find('/** Stable, compact representation')])

# Mathematical balance model: same rule applied to 40 different team component strengths.
# The ranking may move because absolute losses differ, but no team receives a different rule.
for season in range(1, 61):
    if season == 1:
        chosen = []
    else:
        # The deterministic production rule is tested in Kotlin; this model exercises each possible
        # one/two-component annual event shape and decennial reset separately.
        chosen = events[(season * 7) % len(events):][:1 + (season % 2)]
        if len(chosen) == 2 and chosen[0][1] == chosen[1][1]:
            chosen = [chosen[0]]
    for team in range(40):
        values = {c: 45 + ((team * 13 + idx * 7) % 51) for idx,c in enumerate(sorted(components))}
        before = values.copy()
        for _, component, percent in chosen:
            values[component] = int(values[component] * (100-int(percent))/100)
        if season > 1 and (season-1) % 10 == 0:
            dec = {'ENGINE':35,'CHASSIS':25,'FRONT_WING':40,'REAR_WING':40,'BRAKES':25,'ELECTRIC_POWER_UNIT':35}
            for component, percent in dec.items():
                values[component] = int(values[component] * (100-percent)/100)
        check(f'bounded component values season={season} team={team+1}', all(1 <= v <= 100 for v in values.values()))
        if season > 1:
            affected = {c for _,c,_ in chosen}
            if (season-1) % 10 == 0:
                affected |= components
            check(f'affected components reduced season={season} team={team+1}', all(values[c] < before[c] for c in affected))

print(f'PASS: {sum(ok for _,ok in checks)}/{len(checks)} audit assertions; 60 seasons x 40 team profiles modeled.')
print('NOTE: mathematical/source audit only; Android/JUnit build was not run because Gradle is unavailable in this environment.')
