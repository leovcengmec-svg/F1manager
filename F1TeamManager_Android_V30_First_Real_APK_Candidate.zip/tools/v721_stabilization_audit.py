#!/usr/bin/env python3
"""Focused static regression audit for V721 car projection and annual-event continuity."""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
read = lambda rel: (ROOT / rel).read_text(encoding="utf-8")
main = read("app/src/main/java/com/f1teammanager/MainActivity.kt")
car = read("app/src/main/java/com/f1teammanager/core/manager/CarDevelopmentEngine.kt")
facilities = read("app/src/main/java/com/f1teammanager/core/manager/FacilityModels.kt")
ai_finance = read("app/src/main/java/com/f1teammanager/core/manager/AITeamFinancialEngine.kt")
events = read("app/src/main/java/com/f1teammanager/core/manager/AnnualTeamEventEngine.kt")
scheduler = read("app/src/main/java/com/f1teammanager/core/manager/AnnualTeamEventScheduler.kt")
prefs = read("app/src/main/java/com/f1teammanager/CareerPreferences.kt")
gradle = read("app/build.gradle.kts")
manifest = read("package_manifest.txt")

projection_tests = ROOT / "app/src/test/kotlin/com/f1teammanager/core/manager/NextSeasonProjectionRunwayV721Test.kt"
event_tests = ROOT / "app/src/test/kotlin/com/f1teammanager/core/manager/AnnualFacilityEventContinuityV721Test.kt"

checks = {
    "V722 versionCode/versionName are aligned": "versionCode = 722" in gradle and 'versionName = "0.722.0"' in gradle,
    "package manifest identifies V722 and V721 base": "Version: 722 / 0.722.0" in manifest and "Base: V721 / 0.721.0" in manifest,
    "release ZIP filename and public app name are preserved": "F1TeamManager_Android_V30_First_Real_APK_Candidate.zip" in manifest and "Public name: F1 Team Manager V30" in manifest,
    "projection is read-only and constrained by GP runway": all(token in car[car.index("fun projectedNextSeasonInvestment("):car.index("/** Compatibility value now follows")] for token in ["actualInvested", "completedRounds", "availableCash", "roundsRemaining", "AI_NEXT_CAR_ABSOLUTE_CAP"]),
    "projection reaches actual committed investment after GP30": "if (roundsRemaining == 0) return alreadyInvested" in car,
    "market projection uses estimated rather than only actual investment": "projectedNextSeasonInvestment(" in main[main.index("fun buildMarketNextSeasonCarStrengths("):main.index("fun participants()")],
    "Team Ranking projection uses the common forecast helper": "projectedNextSeasonInvestment(" in main[main.index("private fun buildTeamRankingSnapshot("):main.index("@Composable\nprivate fun TeamRankingScreen(")],
    "Team Overview projection uses the common forecast helper": "projectedNextSeasonInvestment(" in main[main.index("private fun TeamOverviewNextSeasonInvestment("):main.index("@Composable\nprivate fun TeamOverviewSeason")],
    "Team Ranking shows actual and projected next-car funding": all(token in main for token in ["nextSeasonActualInvestment", "nextSeasonProjectedInvestment", "Investido €${actualM}M • previsto €${forecastM}M"]),
    "AI underinvestment now follows official table and annual cap": "fun annualOverallFromInvestment(" in car and "return buildNextSeasonGarage(" in car and "missingMillions" not in car,
    "weekly advance is split at all pending annual-event boundaries": "advancementBoundaries(currentWeek, targetWeek, pendingEventWeeks)" in main and "advanceFreeWeeksSegment(segmentWeeks, boundary)" in main,
    "annual scheduler exposes deterministic event boundaries": "fun advancementBoundaries(" in scheduler and ".distinct().sorted()" in scheduler,
    "player facility projects are rebased after annual events": "FacilityEngine.rebaseUpgradeAfterExternalChange(" in main,
    "AI facility projects are rebased through the financial engine": "applyAnnualEventFacilities(" in main and "afterExternalLevelChange(" in ai_finance,
    "facility target moves with damage and event upgrades": "val rebasedPrevious = (previousLevel + delta)" in facilities and "val rebasedTarget = (targetLevel + delta)" in facilities,
    "obsolete project is cancelled when no physical target remains": "rebasedTarget <= afterLevel.coerceIn(0, 10)" in facilities,
    "legacy scheduler delegates to the shared batch resolver": "AnnualTeamEventEngine.resolveSeasonBatch(" in scheduler,
    "both event paths share weighted team selection": "weightedTeam(candidates, rng)" in events and "AnnualTeamEventEngine.resolveSeasonBatch(" in scheduler,
    "event effects and idempotency keys commit with current week": all(token in prefs for token in ["processedAnnualEventKeys", "annualEventCarStats", "aiFinanceSnapshot", "committedCurrentWeek", "return e.commit()"]),
    "AI facility row mirror is saved with finance snapshot": "aiFacilitiesSnapshot" in prefs and "putString(\"aiFacilitiesSnapshot\", mirror)" in prefs,
    "missing/corrupt primary facility rows are repaired from mirror on load": "mergeAiFacilitySnapshotFallback" in prefs and "val missing = backupRows.filterKeys { it !in primaryRows }" in prefs,
    "V721 projection regression tests are included": projection_tests.is_file() and all(t in projection_tests.read_text(encoding="utf-8") for t in ["opening week", "season end", "cash runway", "no cash"]),
    "V721 annual-event continuity regression tests are included": event_tests.is_file() and all(t in event_tests.read_text(encoding="utf-8") for t in ["earthquake", "free annual upgrade", "rebased remaining paid level", "event boundary", "weighted event selection"]),
    "V720 audio/ranking and V718 scalability tests remain in source": (ROOT / "tools/v720_regression_audit.py").is_file() and (ROOT / "tools/v718_scalability_audit.py").is_file() and (ROOT / "app/src/main/java/com/f1teammanager/ExternalAudio.kt").is_file(),
    "V722 changelog and audit are included": (ROOT / "CHANGELOG_V722.md").is_file() and (ROOT / "AUDIT_V722_STABILIZATION.md").is_file(),
}

for label, ok in checks.items():
    print(("PASS" if ok else "FAIL") + " | " + label)
failed = sum(not ok for ok in checks.values())
print(f"RESULT: {len(checks) - failed}/{len(checks)} V721 static checks passed")
sys.exit(1 if failed else 0)
