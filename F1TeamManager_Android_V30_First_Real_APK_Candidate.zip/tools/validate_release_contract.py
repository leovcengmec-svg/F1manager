#!/usr/bin/env python3
"""Validate release metadata and integration guards for the current Android package."""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
gradle = (ROOT / "app/build.gradle.kts").read_text(encoding="utf-8")
manifest = (ROOT / "package_manifest.txt").read_text(encoding="utf-8")
workflow = (ROOT / ".github/workflows/android-apk.yml").read_text(encoding="utf-8")
main = (ROOT / "app/src/main/java/com/f1teammanager/MainActivity.kt").read_text(encoding="utf-8")
historical = (ROOT / "app/src/main/java/com/f1teammanager/HistoricalDatabase.kt").read_text(encoding="utf-8")
weekend = (ROOT / "app/src/main/java/com/f1teammanager/core/race/CareerWeekendEngine.kt").read_text(encoding="utf-8")
instant = (ROOT / "app/src/main/java/com/f1teammanager/core/race/InstantSimulationService.kt").read_text(encoding="utf-8")
models = (ROOT / "app/src/main/java/com/f1teammanager/core/race/RaceModels.kt").read_text(encoding="utf-8")
research = (ROOT / "app/src/main/java/com/f1teammanager/core/manager/ResearchModels.kt").read_text(encoding="utf-8")
facilities = (ROOT / "app/src/main/java/com/f1teammanager/core/manager/FacilityModels.kt").read_text(encoding="utf-8")
market_models = (ROOT / "app/src/main/java/com/f1teammanager/core/manager/DriverMarketModels.kt").read_text(encoding="utf-8")
market_engine = (ROOT / "app/src/main/java/com/f1teammanager/core/manager/DriverMarketEngine.kt").read_text(encoding="utf-8")
financial_ai = (ROOT / "app/src/main/java/com/f1teammanager/core/manager/AITeamFinancialEngine.kt").read_text(encoding="utf-8")
grid = (ROOT / "app/src/main/java/com/f1teammanager/core/manager/DynamicGridEngine.kt").read_text(encoding="utf-8")
preferences = (ROOT / "app/src/main/java/com/f1teammanager/CareerPreferences.kt").read_text(encoding="utf-8")
sponsor_engine = (ROOT / "app/src/main/java/com/f1teammanager/core/manager/TeamSponsorshipEngine.kt").read_text(encoding="utf-8")
sponsor_test = (ROOT / "app/src/test/kotlin/com/f1teammanager/core/manager/SponsorOfferStabilityV712Test.kt").read_text(encoding="utf-8")

code_match = re.search(r"versionCode\s*=\s*(\d+)", gradle)
name_match = re.search(r'versionName\s*=\s*"([^"]+)"', gradle)
version_code = int(code_match.group(1)) if code_match else -1
version_name = name_match.group(1) if name_match else ""
changelog = ROOT / f"CHANGELOG_V{version_code}.md"
audit = ROOT / f"AUDIT_V{version_code}_STABILIZATION.md"
v717_audit = ROOT / "AUDIT_V717_STABILIZATION.md"

checks = {
    "Gradle versionCode/versionName are present": version_code > 0 and bool(version_name),
    "versionName follows VersionCode convention": version_name == f"0.{version_code}.0",
    "package_manifest matches Gradle metadata": f"Version: {version_code} / {version_name}" in manifest,
    "ZIP naming convention preserved": "F1TeamManager_Android_V30_First_Real_APK_Candidate.zip" in manifest,
    "current changelog and audit exist": changelog.is_file() and audit.is_file(),
    "workflow invokes current release contract validator": "tools/validate_release_contract.py" in workflow,
    "workflow no longer gates build on V685 metadata": "v685_contract_duration_audit.py" not in workflow and "versionCode = 685" not in workflow,
    "workflow publishes APK with dynamic version label": "F1-Team-Manager-V30-V${{ steps.app-version.outputs.version_code }}-debug-apk" in workflow,
    "workflow reads app version into output": "id: app-version" in workflow and "version_code=$VERSION_CODE" in workflow,
    "CareerWeekendEngine normalizes direct race entry": "val normalizedParticipants = participants.map { it.normalized() }" in weekend and "qualifyingParticipants = normalizedParticipants" in weekend,
    "instant simulation normalizes its roster": "val normalizedParticipants = participants.map { it.normalized() }" in instant and "engine.start(normalizedParticipants" in instant,
    "wet-weather helper applies floor 40": "p.wetSkill.coerceIn(40, 100)" in models,
    "P&D success notification uses stored completion week": "design.completedWeek.coerceIn(1, 56)" in main,
    "P&D failure notification uses per-project completion week": "projectCompletionWeeks[project.projectId]" in main,
    "completion-week policy exists": "object ResearchCompletionWeekPolicy" in research,
    "race-entry regression test exists": (ROOT / "app/src/test/kotlin/com/f1teammanager/core/race/RaceEngineAttributeFloorV699Test.kt").is_file(),
    "P&D week regression test exists": (ROOT / "app/src/test/kotlin/com/f1teammanager/core/manager/ResearchCompletionWeekPolicyV699Test.kt").is_file(),
    "physical construction test expects the 40-point floor": "assertEquals(40, builtWithoutInvestment.teamAverageOverall)" in (ROOT / "app/src/test/kotlin/com/f1teammanager/core/manager/NextSeasonCarConstructionV636Test.kt").read_text(encoding="utf-8"),
    "weather regression test covers the 40-point wet-skill floor": "direct rain penalty helper respects the universal 40 point wet skill floor" in (ROOT / "app/src/test/kotlin/com/f1teammanager/core/race/RaceWeatherPerformanceV682Test.kt").read_text(encoding="utf-8"),
    "AI development queues are part of the canonical market state": "aiDriverDevelopment: Map<Int, DriverDevelopmentState>" in (ROOT / "app/src/main/java/com/f1teammanager/core/manager/DriverMarketModels.kt").read_text(encoding="utf-8"),
    "AI programme queues and calendar ticks are persisted": "marketAiDriverDevelopmentLastTick" in (ROOT / "app/src/main/java/com/f1teammanager/CareerPreferences.kt").read_text(encoding="utf-8"),
    "AI programmes use the same player development engine before the GP": "advanceAiDriverDevelopment(managerState, aiFacilities, rd.weekOfSeason)" in (ROOT / "app/src/main/java/com/f1teammanager/core/manager/ManagerSeasonEngine.kt").read_text(encoding="utf-8"),
    "AI starts programmes using facility capacity": "DriverDevelopmentEngine.start(queue, level, candidate.first" in (ROOT / "app/src/main/java/com/f1teammanager/core/manager/ManagerSeasonEngine.kt").read_text(encoding="utf-8"),
    "passive facility growth is disabled": "fun driverDevelopmentEfficiency(state: TeamFacilitiesState): Double = 1.0" in (ROOT / "app/src/main/java/com/f1teammanager/core/manager/FacilityModels.kt").read_text(encoding="utf-8"),
    "initial AI contracts use the 1-to-5-year planner": "val years = chooseAiYears(d.id, season, 1)" in (ROOT / "app/src/main/java/com/f1teammanager/core/manager/DriverMarketEngine.kt").read_text(encoding="utf-8"),
    "AI roster-gap contracts do not force one year": "chooseAiYears(candidate, responseSeason, 53, driverAttributes)" in (ROOT / "app/src/main/java/com/f1teammanager/core/manager/DriverMarketEngine.kt").read_text(encoding="utf-8"),
    "season-performance class margin is implemented": "seasonPerformanceAverage" in (ROOT / "app/src/main/java/com/f1teammanager/core/season/DriverEvolutionEngine.kt").read_text(encoding="utf-8"),
    "V702 AI and class-margin tests exist": (ROOT / "app/src/test/kotlin/com/f1teammanager/core/manager/AIDriverDevelopmentAndContractsV702Test.kt").is_file() and (ROOT / "app/src/test/kotlin/com/f1teammanager/core/season/DriverClassCeilingMarginV702Test.kt").is_file(),
    "V708 Race Operations regression tests exist": (ROOT / "app/src/test/kotlin/com/f1teammanager/core/manager/RaceOperationsFacilityV708Test.kt").is_file(),
    "Scouting facility key migrates to Race Operations": '"SCOUTING" -> RACE_OPERATIONS' in facilities and 'FacilityType.RACE_OPERATIONS' in facilities,
    "Race Operations facility exposes all three specified curves": all(token in facilities for token in ["21.0 - normalizedLevel(level) * 0.2", "0.08 - normalizedLevel(level) * 0.006", "8.0 - normalizedLevel(level) * 0.3"]),
    "Race Operations delay is deterministic per team, driver and stop": all(token in facilities for token in ["weekendSeed", "teamId", "driverId", "stopNumber", "kotlin.random.Random(mixed)"]),
    "Race grid receives each team's Race Operations level": "raceOperationsLevel=activeFacilities.level(FacilityType.RACE_OPERATIONS)" in grid,
    "Race engine adds base stop, delay and optional repair exactly once": all(token in weekend for token in ["val totalStopLossMs = baseLossMs + delayMs + repairMs", "s.total += totalStopLossMs", "emergencyRepair = true"]),
    "AI and manual race use the shared CareerWeekendEngine": "CareerWeekendEngine(careerSeed + round)" in (ROOT / "app/src/main/java/com/f1teammanager/core/manager/ManagerSeasonEngine.kt").read_text(encoding="utf-8") and "engine.start(normalizedParticipants" in instant,
    "AI facility priorities use Race Operations instead of Scouting": "FacilityType.RACE_OPERATIONS -> 48 - level * 5" in financial_ai and "FacilityType.SCOUTING" not in financial_ai,
    "Driver market no longer persists Scouting reports": "ScoutingReport" not in market_models and "fun scout(" not in market_engine and 'remove("marketScouting")' in preferences,
    "V710 no longer requires marketScouting in complete saves": '"marketScouting"' not in preferences[preferences.index("val requiredStrings = listOf("):preferences.index("val integerKeys = setOf(")],
    "V710 export sanitizes legacy Scouting preference": "withoutRemovedScoutingPreferences(encodePreferenceSnapshot(prefs.all))" in preferences,
    "V710 import validates then removes legacy Scouting preference": "val metadata = inspectCareerBackup(payload)" in preferences and "withoutRemovedScoutingPreferences(payload.getJSONObject(\"preferences\"))" in preferences,
    "V710 has targeted save migration regression test": (ROOT / "tools/save_test/v710_scouting_backup_migration_test.py").is_file(),
    "Driver market renders all seven real attributes": all(token in main for token in ['"VEL" to d.speed', '"CLA" to d.qualifying', '"ULT" to d.overtaking', '"DEF" to d.defense', '"CON" to d.consistency', '"CHU" to d.wet', '"PNE" to d.tyre']),
    "New facility artwork replaces the old Scouting artwork": (ROOT / "app/src/main/res/drawable-nodpi/facility_race_operations.webp").is_file() and not (ROOT / "app/src/main/res/drawable-nodpi/facility_scouting.webp").exists(),
    "V711 driver Overall news regression tests exist": (ROOT / "app/src/test/kotlin/com/f1teammanager/core/season/DriverOverallNewsV711Test.kt").is_file(),
    "V712 driver news includes cause without attribute names": (ROOT / "app/src/test/kotlin/com/f1teammanager/core/season/DriverOverallNewsV712Test.kt").is_file() and "overallMovementReason(tick" in preferences,
    "V712 sponsor offers are deterministic across screen re-entry": "TeamSponsorshipEngine(marketKey)" in main and "kotlin.random.Random.nextLong()" not in main[main.index("private fun Finance("):main.index("private fun DriverMarket(")],
    "V712 sponsor cards use full-width readable proposal layout": "slotOffers.take(3).forEach" in main and "fontSize=10.sp, lineHeight=13.sp" in main,
    "V712 sponsor stability regression test exists": (ROOT / "app/src/test/kotlin/com/f1teammanager/core/manager/SponsorOfferStabilityV712Test.kt").is_file(),
    "V712 race and pole archives store/read circuit names": all(token in (ROOT / "app/src/main/java/com/f1teammanager/HistoricalDatabase.kt").read_text(encoding="utf-8") for token in ["enc(round.circuit)", "circuit = p.getOrNull(18)", "p.getOrNull(9)", "SeasonCalendar.configuredCircuit(s, p[2].toInt())"]),
    "V712 history UI displays exact circuit": "r.grandPrix, r.circuit" in main,
    "V711 career evolution news is Overall-only": "overallMovementNews(" in preferences and "hasAttributeMovement(tick)" not in preferences and "teve alterações nos atributos" not in preferences,
    "V711 Team Principal evolution news is Overall-only": "overallMovementNews(" in (ROOT / "app/src/main/java/com/f1teammanager/core/manager/ManagerSeasonEngine.kt").read_text(encoding="utf-8") and "hasAttributeMovement(tick)" not in (ROOT / "app/src/main/java/com/f1teammanager/core/manager/ManagerSeasonEngine.kt").read_text(encoding="utf-8"),
    "V711 legacy pending outbox is normalized": "normalizeOverallMovementNews" in preferences,
    "V711 Central News normalizes old cards and drops Overall delta zero": "normalizeOverallMovementNews(notice.message)" in main and "return@mapNotNull null" in main,
    "V711 overall news message omits attribute-level detail": "evoluiu Overall" in (ROOT / "app/src/main/java/com/f1teammanager/core/season/DriverEvolutionEngine.kt").read_text(encoding="utf-8") and "perdeu Overall" in (ROOT / "app/src/main/java/com/f1teammanager/core/season/DriverEvolutionEngine.kt").read_text(encoding="utf-8"),
    "V713 historical records engine exists": (ROOT / "app/src/main/java/com/f1teammanager/HistoricalRecordsEngine.kt").is_file(),
    "V713 Records screen contains all five categories": all(label in main for label in ["VISÃO GERAL", "PILOTOS", "EQUIPES", "CIRCUITOS", "TEMPORADAS"]),
    "V713 Records screen uses one official archive snapshot": "db.recordBookSnapshot()" in main and all(token in main for token in ["loadedArchive.races", "loadedArchive.poles", "loadedArchive.driverChampions", "loadedArchive.constructorChampions", "loadedArchive.driverSeasonRecords", "loadedArchive.constructorSeasonRecords"]),
    "V713 archive snapshot parses all record sources from one read": all(token in historical for token in ["fun recordBookSnapshot()", "val source = readLines()", "raceRecordsFrom(source)", "poleRecordsFrom(source)", "driverSeasonRecordsFrom(source)", "constructorSeasonRecordsFrom(source)", "driverChampionsFrom(source)", "constructorChampionsFrom(source)"]),
    "V713 completed seasons validated inside the shared archive snapshot": "completedSeasons: List<Int>" in historical and "SeasonCalendar.forSeason(season).size" in historical and "driverWinnersBySeason[season]" in historical,
    "V713 career title records exclude incomplete legacy champion rows": "loadedArchive.driverChampions.filter { it.season in completedSeasons }" in main and "loadedArchive.constructorChampions.filter { it.season in completedSeasons }" in main,
    "V713 record cards preserve equal leaders": "values.filter { it.value == maximum }" in (ROOT / "app/src/main/java/com/f1teammanager/HistoricalRecordsEngine.kt").read_text(encoding="utf-8"),
    "V713 annual pole percentages use finalized season summary values": "row.poles * 1_000_000.0 / total" in (ROOT / "app/src/main/java/com/f1teammanager/HistoricalRecordsEngine.kt").read_text(encoding="utf-8"),
    "V713 multi-team driver careers are not attributed to one arbitrary team": '"Múltiplas equipes"' in (ROOT / "app/src/main/java/com/f1teammanager/HistoricalRecordsEngine.kt").read_text(encoding="utf-8"),
    "V713 circuit records use exact circuit identity": "it.circuit.equals(circuit, true)" in (ROOT / "app/src/main/java/com/f1teammanager/HistoricalRecordsEngine.kt").read_text(encoding="utf-8"),
    "V713 annual records use only finalized seasons": "completedSeasons" in main and "driverSeasonRows.filter { it.season in completedSeasons }" in main and "constructorSeasonRows.filter { it.season in completedSeasons }" in main,
    "V713 constructor streak counts one event per GP": "gpRows.firstOrNull(predicate) ?: gpRows.first()" in (ROOT / "app/src/main/java/com/f1teammanager/HistoricalRecordsEngine.kt").read_text(encoding="utf-8"),
    "V713 streaks require contiguous rounds": "prior.round == 30 && row.round == 1" in (ROOT / "app/src/main/java/com/f1teammanager/HistoricalRecordsEngine.kt").read_text(encoding="utf-8"),
    "V713 record reconstruction regression tests exist": (ROOT / "app/src/test/kotlin/com/f1teammanager/HistoricalRecordsEngineV713Test.kt").is_file(),
    "V713 multi-team career attribution regression test exists": "Múltiplas equipes" in (ROOT / "app/src/test/kotlin/com/f1teammanager/HistoricalRecordsEngineV713Test.kt").read_text(encoding="utf-8"),
    "V713 records engine does not write a parallel record ledger": "No separate mutable counter is stored" in (ROOT / "app/src/main/java/com/f1teammanager/HistoricalRecordsEngine.kt").read_text(encoding="utf-8"),
    "V714 Home dashboard audit is included in release": (ROOT / "tools/v714_home_dashboard_audit.py").is_file(),
    "V714 Home separates competition, management and history shortcuts": all(token in main for token in ['title = "COMPETIÇÃO"', 'title = "GESTÃO DA EQUIPE"', 'title = "HISTÓRIA E ESTATÍSTICAS"']),
    "V714 Home uses the latest official GP shard and exact circuit": "store.history.latestRaceRecords()" in main and "firstRow.circuit" in main,
    "V714 Home has 13 functional shortcuts": all(token in main for token in ['HomeShortcut("FIM DE SEMANA"', 'HomeShortcut("CALENDÁRIO"', 'HomeShortcut("CAMPEONATO"', 'HomeShortcut("TEMPORADA"', 'HomeShortcut("EQUIPE / INSTALAÇÕES"', 'HomeShortcut("PILOTOS"', 'HomeShortcut("MERCADO"', 'HomeShortcut("CARRO / P&D"', 'HomeShortcut("FINANÇAS"', 'HomeShortcut("CENTRAL DE NOTÍCIAS"', 'HomeShortcut("HISTÓRIA"', 'HomeShortcut("HALL DA FAMA"', 'HomeShortcut("RECORDES"']),
    "V714 Home preserves V713 Records screen and engine": "Screen.RECORDS -> DetailScaffold" in main and (ROOT / "app/src/main/java/com/f1teammanager/HistoricalRecordsEngine.kt").is_file(),
    "V715 Compose delegated race state is captured once into a stable local": "val completedRace = lastCompletedRace" in main,
    "V715 last GP card smart-casts only the immutable local snapshot": "if (completedRace == null)" in main and "completedRace.teamDrivers.take(2)" in main and "completedRace.teamPoints" in main,
    "V715 last GP card has no direct delegated-property dereference": "lastCompletedRace.grandPrix" not in main and "lastCompletedRace.circuit" not in main and "lastCompletedRace.teamDrivers" not in main and "lastCompletedRace.teamPoints" not in main,
    "V715 compile-fix audit is preserved": (ROOT / "AUDIT_V715_STABILIZATION.md").is_file() and "delegated property" in (ROOT / "AUDIT_V715_STABILIZATION.md").read_text(encoding="utf-8"),
    "V716 historical line cache is present": "private var archiveLinesCache: List<String>? = null" in historical and "archiveLinesCache?.let { return it }" in historical,
    "V716 parsed record-book snapshot is cached": "private var recordBookCache: RecordBookSnapshot? = null" in historical and "recordBookCache?.let { return it }" in historical,
    "V716 Hall metrics share a single aggregate projection": "private var hallAggregateCache: HallAggregateSnapshot? = null" in historical and "hallValuesForPeriod(includeSeason = true)" in historical and "hallValuesForPeriod(includeSeason = false)" in historical,
    "V716 historical cache invalidation follows archive writes": "@Synchronized\n    private fun writeAtomicLines" in historical and "targetAtomicFile.finishWrite(output)\n            if (target.absoluteFile == file.absoluteFile) legacyRaceLinesBySeason.clear()\n            invalidateReadCaches()" in historical,
    "V716 record snapshot has team, season, circuit and presentation indexes": all(token in historical for token in ["victories:", "fastestLaps:", "circuits:", "racesByTeam:", "racesByTeamSeason:", "racesBySeason:", "polesByTeam:", "polesBySeason:", "circuitsBySeason:", "constructorSeasonsByTeam:", "constructorChampionsByTeam:"]),
    "V716 Team Overview consumes indexed history": all(token in main for token in ["historyArchive?.racesByTeam?.get(selectedTeam.id)", "historyArchive?.racesByTeamSeason?.get(selectedTeam.id to store.season)", "historyArchive?.polesByTeam?.get(selectedTeam.id)", "historyArchive?.constructorSeasonsByTeam?.get(selectedTeam.id)"]),
    "V716 40-team snapshot preparation is off UI thread": "value = withContext(Dispatchers.Default)" in main[main.index("private fun TeamOverviewScreen("):main.index("private fun TeamOverviewBudgetCard(")],
    "V716 team snapshots are cached across visits": "TeamOverviewSnapshotMemoryCache.get(cacheKey)" in main and "TeamOverviewSnapshotMemoryCache.put(cacheKey, built)" in main,
    "V716 team switching remains available during background preparation": "Você já pode navegar entre as equipes." in main and "onSelectTeam(quickOrder[quickIndex + 1].id)" in main,
    "V716 team selection does not invalidate 40-team snapshot cache": "selectedTeamId" not in main[main.index("val snapshotsState by produceState<List<TeamOverviewSnapshot>?>"):main.index("val snapshots = snapshotsState")],
    "V716 history and Hall ranking load off UI thread": all(token in main for token in ["withContext(Dispatchers.IO) { db.recordBookSnapshot() }", "withContext(Dispatchers.Default) { db.hallRanking(scope, metric) }"]),
    "V716 sponsor baseline remains BASIC and other offers draw independently": "val baseline = unlocked.first()" in sponsor_engine and "else drawCategory(marketingLevel, teamId, season, slot, round, index)" in sponsor_engine,
    "V716 sponsor offers retain unique names and deterministic seeds": "usedNames += profile.name" in sponsor_engine and "Random(drawSeed + index * 101L)" in sponsor_engine,
    "V716 sponsor regression test covers level-two Regional offers": "always offers a basic baseline and can independently offer regional upgrades" in sponsor_test and "SponsorCategory.REGIONAL" in sponsor_test,
    "V716 performance and sponsorship audit is included": (ROOT / "tools/v716_performance_and_sponsorship_audit.py").is_file(),
    "V717 Team Ranking screen is routed independently": "TEAM_RANKING" in main and 'DetailScaffold("RANKING DAS EQUIPES"' in main,
    "V717 Team Ranking is accessible from Management Hub": '"RANKING DAS EQUIPES" to onTeamRanking' in main and "onTeamRanking={screen=Screen.TEAM_RANKING}" in main,
    "V717 ranking uses all WorldDatabase teams": "WorldDatabase.teams.map { definition ->" in main[main.index("private fun buildTeamRankingSnapshot("):main.index("@Composable\nprivate fun TeamRankingScreen(")],
    "V717 all three rankings sort descending": all(token in main for token in ["compareByDescending<TeamRankingEntry> { it.currentStrength }", "compareByDescending<TeamRankingEntry> { it.cash }", "compareByDescending<TeamRankingEntry> { it.nextSeasonStrength }"]),
    "V717 current force is physical average of two cars": "currentGarage.teamAverageOverall" in main and "val teamAverageOverall: Int get() = (car1.overall + car2.overall + 1) / 2" in (ROOT / "app/src/main/java/com/f1teammanager/core/manager/CarGarageModels.kt").read_text(encoding="utf-8"),
    "V717 cash uses canonical player and AI finance balances": "playerManagerState.finance.budget" in main and "aiFinanceByTeam[definition.id]?.finance?.budget" in main,
    "V717 projection uses official physical build and regulation pipeline": all(token in main[main.index("private fun buildTeamRankingSnapshot("):main.index("@Composable\nprivate fun TeamRankingScreen(")] for token in ["buildNextSeasonGarage(", "buildAiNextSeasonGarage(", "AnnualCarRegulationEngine.applyToGarage"]),
    "V717 next-car card shows projected Overall and delta": "entry.nextSeasonStrength" in main and "entry.nextSeasonDelta" in main and '"OVERALL / Δ"' in main,
    "V717 Team Ranking calculation runs off UI thread": "withContext(Dispatchers.Default)" in main[main.index("private fun TeamRankingScreen("):main.index("@Composable\nprivate fun ManagementHub(")],
    "V717 ranking snapshot has shared cache and compact AI fingerprint": "TeamRankingMemoryCache.get(key)" in main and "TeamRankingMemoryCache.put(key, rows)" in main and "aiFinance.performanceFingerprint(store.season)" in main,
    "V717 existing team profile is opened from ranking row": "onOpenTeam(entry.team.id)" in main and "teamOverviewOrigin = Screen.TEAM_RANKING" in main,
    "V717 ranking has explicit audit": v717_audit.is_file() and "Ranking das Equipes" in v717_audit.read_text(encoding="utf-8"),
    "V717 focused ranking audit is included": (ROOT / "tools/v717_team_ranking_audit.py").is_file(),
    "V718 standard AI development uses bounded in-memory caches": all(token in (ROOT / "app/src/main/java/com/f1teammanager/core/manager/AITeamDevelopmentEngine.kt").read_text(encoding="utf-8") for token in ["MAX_ENTRIES = 96", "MAX_ENTRIES = 160", "PhysicalSimulationMemoryCache.get(key)", "HistoricalOpeningMemoryCache.get("]),
    "V718 standard AI development persists season-opening checkpoints": "checkpointStore?.loadCandidates(team.id, targetSeason)" in (ROOT / "app/src/main/java/com/f1teammanager/core/manager/AITeamDevelopmentEngine.kt").read_text(encoding="utf-8") and "checkpointStore?.save(" in (ROOT / "app/src/main/java/com/f1teammanager/core/manager/AITeamDevelopmentEngine.kt").read_text(encoding="utf-8"),
    "V718 Team Principal handoff replay is checkpointed": "historicalOpeningStateFromHandoff" in (ROOT / "app/src/main/java/com/f1teammanager/core/manager/AITeamDevelopmentEngine.kt").read_text(encoding="utf-8") and "AI_HANDOFF_CHECKPOINT_V1" in (ROOT / "app/src/main/java/com/f1teammanager/core/manager/AITeamDevelopmentEngine.kt").read_text(encoding="utf-8"),
    "V718 checkpoint identity isolates career, seed, regulation, team and investment": all(token in (ROOT / "app/src/main/java/com/f1teammanager/core/manager/AITeamDevelopmentEngine.kt").read_text(encoding="utf-8") for token in ["careerScope", "regulationSeed", "investmentPrefix", "team.hashCode()", "AI_PHYSICAL_CHECKPOINT_V3"]),
    "V718 durable checkpoint files are fingerprinted and bounded": "fingerprint.take(16)" in (ROOT / "app/src/main/java/com/f1teammanager/AiDevelopmentCheckpointStore.kt").read_text(encoding="utf-8") and "files.drop(8)" in (ROOT / "app/src/main/java/com/f1teammanager/AiDevelopmentCheckpointStore.kt").read_text(encoding="utf-8"),
    "V718 all interactive AI team batches freeze one ranking snapshot": all(token in main for token in ["weeklyInvestmentRanking", "raceInvestmentRanking", "eventInvestmentRanking", "finalizationInvestmentRanking"]),
    "V718 news simulation reuses the same deterministic AI seed": "AITeamDevelopmentEngine(20261005, store.carRegulationSeed()" in main and "20261005 + store.season" not in main,
    "V718 Team Overview and Team Ranking use the same garage snapshot cache": "TeamGarageSnapshotMemoryCache.get(key)" in main and "TeamGarageSnapshotMemoryCache.put(key, rows.filter" in main,
    "V718 AI projection cache avoids full finance snapshot hashing": "performanceFingerprint(season: Int)" in financial_ai and "exportSnapshot().hashCode()" not in main,
    "V718 large AI finance transaction ledgers use backward-compatible compression": "AIFinanceTransactionCodec.encode(f.transactions)" in financial_ai and "GZIPOutputStream" in (ROOT / "app/src/main/java/com/f1teammanager/core/manager/AIFinanceTransactionCodec.kt").read_text(encoding="utf-8") and "else outer" in (ROOT / "app/src/main/java/com/f1teammanager/core/manager/AIFinanceTransactionCodec.kt").read_text(encoding="utf-8"),
    "V718 historical summary repair is lazy and archive projection releases raw line cache": "ensureSeasonSummaryRepair()" in historical and "archiveLinesCache = null" in historical and "reconcileCompletedSeasonSummaries()" not in historical[historical.index("init {"):historical.index("@Synchronized\n    private fun ensureSeasonSummaryRepair")],
    "V718 Home reads only the newest GP shard": "fun latestRaceRecords()" in historical and "store.history.latestRaceRecords()" in main,
    "V718 scalability audit is included": (ROOT / "tools/v718_scalability_audit.py").is_file() and "20 temporadas" in (ROOT / "AUDIT_V718_STABILIZATION.md").read_text(encoding="utf-8"),
    "V721 next-season runway projection and event continuity audit are included": (ROOT / "tools/v721_stabilization_audit.py").is_file() and (ROOT / "AUDIT_V721_STABILIZATION.md").is_file(),
    "V721 annual facility backup mirror is included in the current save path": "aiFacilitiesSnapshot" in preferences and "mergeAiFacilitySnapshotFallback" in preferences,
    "V721 annual-event boundaries are processed before later weeks": "advancementBoundaries(currentWeek, targetWeek, pendingEventWeeks)" in main and "advanceFreeWeeksSegment(segmentWeeks, boundary)" in main,
}

for label, ok in checks.items():
    print(("PASS" if ok else "FAIL") + " | " + label)
failed = sum(not ok for ok in checks.values())
print(f"RESULT: {len(checks)-failed}/{len(checks)} V{version_code} release contract checks passed")
sys.exit(1 if failed else 0)
