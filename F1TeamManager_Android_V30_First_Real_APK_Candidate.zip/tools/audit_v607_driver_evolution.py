#!/usr/bin/env python3
"""Static regression audit for the V607 driver evolution catalog update."""
import re
from pathlib import Path
p = Path(__file__).resolve().parents[1] / 'app/src/main/java/com/f1teammanager/core/season/DriverProfileCatalog.kt'
s = p.read_text(encoding='utf-8')
entries = re.findall(r'"([^"\n]+)"\s+to\s+Profile\("(Fraco|Médio|Forte|Pro|Lenda)",\s*"([^"]+)",\s*intArrayOf\(([^)]*)\)\)', s)
assert len(entries) >= 90, f'Unexpected catalog size: {len(entries)}'
assert len({x[0] for x in entries}) == len(entries), 'Duplicate pilot names in catalog'
remaining = [name for name, cls, evo, attrs in entries if evo == 'Normal']
assert not remaining, f'Pilots still marked Normal: {remaining}'
updated = [x for x in entries if x[2] == 'Auge moderado']
assert len(updated) >= 50, f'Expected at least 50 Auge moderado profiles, got {len(updated)}'
assert all(len([a for a in attrs.split(',') if a.strip()]) == 7 for _,_,_,attrs in entries), 'A pilot does not have seven attributes'
assert 'evolution = base.evolution' in s, 'Profile normalization does not preserve the configured evolution'
assert 'normalizedEvolution' not in s, 'Legacy Normal override still present'
print(f'V607 driver evolution audit: PASS — {len(entries)} profiles, {len(updated)} Auge moderado, 0 Normal, seven attributes each')
