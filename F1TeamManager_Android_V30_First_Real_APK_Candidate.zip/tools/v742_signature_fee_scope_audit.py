#!/usr/bin/env python3
"""Regression audit for V742: local helper declaration must precede all calls."""
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
source = (ROOT / "app/src/main/java/com/f1teammanager/MainActivity.kt").read_text(encoding="utf-8")
match = "fun signatureFeeForTeam("
if source.count(match) != 1:
    print(f"FAIL | expected one local signatureFeeForTeam declaration, found {source.count(match)}")
    sys.exit(1)

declaration = source.index(match)
first_week_advance = source.index("fun advanceFreeWeeksSegment(")
references = [i for i in range(len(source)) if source.startswith("signatureFeeForTeam(", i)]
# Ignore the declaration itself when checking calls.
calls = [i for i in references if i != declaration]
checks = {
    "fee helper is declared before the weekly market function": declaration < first_week_advance,
    "all call sites occur after the local helper declaration": all(i > declaration for i in calls),
    "helper delegates to the centralized financial fee policy": "marketEngine.signatureFeeFor(" in source[declaration:source.index("fun acceptIncomingMarketOffer(", declaration)],
    "version metadata is V742": 'versionCode = 742' in (ROOT / "app/build.gradle.kts").read_text(encoding="utf-8"),
    "manifest agrees with V742": "Version: 742 / 0.742.0" in (ROOT / "package_manifest.txt").read_text(encoding="utf-8"),
}
failed = False
for label, ok in checks.items():
    print(("PASS" if ok else "FAIL") + " | " + label)
    failed |= not ok
print(f"RESULT: {sum(checks.values())}/{len(checks)} V742 scope checks passed")
sys.exit(1 if failed else 0)
