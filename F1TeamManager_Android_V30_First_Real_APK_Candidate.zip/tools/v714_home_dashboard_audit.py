#!/usr/bin/env python3
"""Focused structural regression checks for the V714 Home dashboard."""
from pathlib import Path
import re
ROOT = Path(__file__).resolve().parents[1]
main = (ROOT / "app/src/main/java/com/f1teammanager/MainActivity.kt").read_text(encoding="utf-8")
checks = {
    "Home constructor panel uses official constructor points": "store.constructorPoints()" in main and "CAMPEONATO DE CONSTRUTORES" in main,
    "Constructor dashboard shows position within 40 teams": '"P${constructorIndex + 1}/40"' in main,
    "Constructor dashboard compares adjacent teams": 'constructorAbove?.let' in main and 'constructorBelow?.let' in main,
    "Driver dashboard uses active seasonal contracts": 'filter { it.activeIn(store.season) }' in main and 'CAMPEONATO DE PILOTOS' in main,
    "Driver dashboard shows full pilot names and points": 'Text(driver.name' in main and '"$points PTS"' in main,
    "Finance dashboard separates cash and technical envelope": '"CAIXA ATUAL"' in main and '"Limite técnico restante"' in main and '"Capacidade técnica imediata"' in main,
    "Technical capacity respects protected operating reserve": 'SeasonInvestmentPolicy.protectedCash(cashAvailable)' in main and 'minOf(technicalRoom, spendableAfterReserve)' in main,
    "Latest GP is read from the newest official archive shard": 'store.history.latestRaceRecords()' in main and 'firstRow.circuit' in main,
    "Last GP delegated state is snapshotted into an immutable local before rendering": 'val completedRace = lastCompletedRace' in main and 'if (completedRace == null)' in main,
    "Last GP card uses stable local snapshot for circuit, drivers and points": '"${completedRace.circuit}  •  ${completedRace.season} R${completedRace.round}"' in main and 'completedRace.teamDrivers.take(2)' in main and 'completedRace.teamPoints' in main,
    "Historical I/O is moved off the UI thread": 'withContext(Dispatchers.IO)' in main and 'loadHomeLastRaceSummary(store, teamId, team)' in main,
    "Legacy race-result fallback remains available": 'store.raceHistory(index + 1)' in main and 'Legacy fallback' in main,
    "All three shortcut groups exist": all(x in main for x in ['title = "COMPETIÇÃO"', 'title = "GESTÃO DA EQUIPE"', 'title = "HISTÓRIA E ESTATÍSTICAS"']),
    "Shortcut group item counts are 4, 6 and 3": all(x in main for x in ['HomeShortcut("FIM DE SEMANA"', 'HomeShortcut("TEMPORADA"', 'HomeShortcut("EQUIPE / INSTALAÇÕES"', 'HomeShortcut("CENTRAL DE NOTÍCIAS"', 'HomeShortcut("HISTÓRIA"', 'HomeShortcut("RECORDES"']),
    "Team shortcut opens existing Team screen": 'onTeam={ nav=Nav.TEAM; screen=Screen.TEAM }' in main,
    "Calendar and season shortcuts open existing screens": 'onCalendar={ nav=Nav.CALENDAR; screen=Screen.CALENDAR }' in main and 'onSeason={ screen=Screen.SEASON }' in main,
    "History, Hall of Fame and Records shortcuts open existing screens": all(x in main for x in ['onHistory={ screen=Screen.HISTORY_CENTER }', 'onHallOfFame={ screen=Screen.HALL_OF_FAME }', 'onRecords={ screen=Screen.RECORDS }']),
    "Constructor card selects Constructors standings tab": 'onConstructorStandings={ standingsInitialTab=1; nav=Nav.STANDINGS; screen=Screen.STANDINGS }' in main and 'Standings(team.id, store, standingsInitialTab)' in main,
    "Driver card selects Drivers standings tab": 'onDriverStandings={ standingsInitialTab=0; nav=Nav.STANDINGS; screen=Screen.STANDINGS }' in main,
    "Original next-race card and five-item bottom navigation remain": 'else "PRÓXIMA CORRIDA"' in main and 'listOf(Nav.HOME to "⌂",Nav.TEAM to "♟",Nav.CAR to "▰",Nav.CALENDAR to "▦",Nav.STANDINGS to "≡")' in main,
}
for label, ok in checks.items():
    print(("PASS" if ok else "FAIL") + " | " + label)
failed = sum(not x for x in checks.values())
print(f"RESULT: {len(checks)-failed}/{len(checks)} V714 Home checks passed")
raise SystemExit(1 if failed else 0)
