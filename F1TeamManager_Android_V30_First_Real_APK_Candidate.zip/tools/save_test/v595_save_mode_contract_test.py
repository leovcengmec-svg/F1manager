#!/usr/bin/env python3
"""Static contract checks for V595 save metadata. Does not replace Android runtime tests."""
from pathlib import Path
import json
import re

ROOT = Path(__file__).resolve().parents[2]
career = (ROOT / 'app/src/main/java/com/f1teammanager/CareerPreferences.kt').read_text()
screen = (ROOT / 'app/src/main/java/com/f1teammanager/SaveManagementScreen.kt').read_text()
gradle = (ROOT / 'app/build.gradle.kts').read_text()

checks = []
def check(name, condition):
    checks.append((name, bool(condition)))

check('versionCode 596', re.search(r'versionCode\s*=\s*596\b', gradle))
check('versionName 0.596.0', 'versionName = "0.596.0"' in gradle)
check('export uses schema 2', '.put("schema", 2)' in career)
check('export declares mode', '.put("mode", mode)' in career)
check('export declares career identity', '.put("careerId", careerId)' in career)
check('preferences carry explicit mode', '.putString("activeGameMode", mode)' in career)
check('new career receives unique identity', '.putString("careerId", java.util.UUID.randomUUID().toString())' in career)
check('legacy schema 1 remains readable', 'require(schema in 1..2)' in career)
check('legacy saves infer Team Principal from manager state', 'if (principalRaw.isNotBlank()) "TEAM_PRINCIPAL" else "FREE"' in career)
check('legacy saves receive a stable identity on import', 'UUID.nameUUIDFromBytes(payload.toString().toByteArray(Charsets.UTF_8))' in career)
check('import normalizes the mode marker', 'editor.putString("activeGameMode", metadata.mode)' in career)
check('mode mismatch is rejected', 'topMode == mode' in career and 'modo declarado no arquivo não corresponde' in career)
check('Team Principal requires its own state', 'Save marcado como Time Principal' in career)
check('non-TP saves reject TP-only state', 'dados de Time Principal incompatíveis' in career)
check('validation happens before live preferences commit', career.index('val metadata = inspectCareerBackup(payload)') < career.index('check(editor.commit()) { "Não foi possível gravar a carreira importada." }'))
check('save list displays mode', 'metadata.modeLabel()' in screen)
check('invalid saves cannot be loaded', 'IconButton(enabled = metadata != null' in screen)
check('selected save is validated before export', 'val metadata = store.inspectCareerBackup(payload)' in screen)
check('auto-save identity includes mode and career ID', '${mode}_${safeTeam}_${store.season}_${careerId}_${date}.json' in screen)
check('file writes use AtomicFile', 'AtomicFile(destination)' in screen and 'writeSaveAtomically' in screen)

# Format-level examples for all three modes and deliberate mismatch cases.
def envelope(mode, team, career_id):
    return {'format':'F1TM_SAVE','schema':2,'mode':mode,'careerId':career_id,'teamId':team,'season':2027,
            'preferences':{'activeGameMode':mode,'careerId':career_id,'teamId':team,'season':2027,'hasCareer':True}}
valid = [envelope('FREE', 1, 'career-free'), envelope('HARD', 2, 'career-hard'), envelope('TEAM_PRINCIPAL', 3, 'career-tp')]
check('three modes can be represented distinctly', len({x['mode'] for x in valid}) == 3)
check('metadata fixtures agree internally', all(x['mode'] == x['preferences']['activeGameMode'] and x['careerId'] == x['preferences']['careerId'] for x in valid))
corrupt = envelope('HARD', 2, 'career-hard')
corrupt['preferences']['activeGameMode'] = 'FREE'
check('mismatched mode fixture is detectable', corrupt['mode'] != corrupt['preferences']['activeGameMode'])
corrupt_id = envelope('FREE', 1, 'id-a')
corrupt_id['preferences']['careerId'] = 'id-b'
check('mismatched career identity fixture is detectable', corrupt_id['careerId'] != corrupt_id['preferences']['careerId'])
legacy = {'format':'F1TM_SAVE','schema':1,'teamId':3,'season':2027,'preferences':{'teamPrincipalCareer':'encoded-state','teamId':3,'season':2027,'hasCareer':True}}
legacy_mode = 'TEAM_PRINCIPAL' if legacy['preferences']['teamPrincipalCareer'] else 'FREE'
check('legacy Team Principal fixture can be identified', legacy_mode == 'TEAM_PRINCIPAL')
legacy['preferences'].pop('teamPrincipalCareer')
legacy_mode = 'TEAM_PRINCIPAL' if legacy['preferences'].get('teamPrincipalCareer') else 'FREE'
check('legacy non-manager fixture migrates to Free', legacy_mode == 'FREE')

failed = [name for name, ok in checks if not ok]
for name, ok in checks:
    print(f"{'PASS' if ok else 'FAIL'}: {name}")
print(f"\n{len(checks)-len(failed)}/{len(checks)} static contract checks passed")
if failed:
    raise SystemExit(1)
