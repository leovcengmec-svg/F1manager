#!/usr/bin/env python3
"""Static regression checks for save/export/import after retiring Scouting in V708."""
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[2]
source = (ROOT / "app/src/main/java/com/f1teammanager/CareerPreferences.kt").read_text(encoding="utf-8")
manifest = (ROOT / "package_manifest.txt").read_text(encoding="utf-8")
gradle = (ROOT / "app/build.gradle.kts").read_text(encoding="utf-8")
code_match = re.search(r"versionCode\s*=\s*(\d+)", (ROOT / "app/build.gradle.kts").read_text(encoding="utf-8"))
current_version = int(code_match.group(1)) if code_match else -1
changelog = ROOT / f"CHANGELOG_V{current_version}.md"
audit = ROOT / f"AUDIT_V{current_version}_STABILIZATION.md"

checks = []
def check(name, ok):
    checks.append((name, bool(ok)))

# New backups must not contain the removed Scouting preference.
export_start = source.index("fun exportCareerBackup()")
export_end = source.index("/** Serialize all Android SharedPreferences", export_start)
export_block = source[export_start:export_end]
check("new export sanitizes legacy Scouting key", "withoutRemovedScoutingPreferences(encodePreferenceSnapshot(prefs.all))" in export_block)

# The canonical complete-save manifest must not require Scouting.
required_start = source.index("val requiredStrings = listOf(")
required_end = source.index("val integerKeys = setOf(", required_start)
required_block = source[required_start:required_end]
check("marketScouting is not a required save field", '"marketScouting"' not in required_block)
check("other market state remains required", all(f'"{key}"' in required_block for key in ["marketContracts", "marketFree", "marketScheduled", "marketRoles", "marketPending", "marketNotifications", "marketRenewalEvaluations", "marketAiDriverDevelopment"]))

# Compatibility: inspect/checksum the exact old payload first, then normalize a copy for import.
import_start = source.index("fun importCareerBackup(payload:")
import_end = source.index("private object WorldTeamResolver", import_start)
import_block = source[import_start:import_end]
inspect_pos = import_block.index("val metadata = inspectCareerBackup(payload)")
normalize_pos = import_block.index("withoutRemovedScoutingPreferences(payload.getJSONObject(\"preferences\"))")
write_pos = import_block.index("check(editor.commit()) { \"Não foi possível gravar a carreira importada.\" }")
check("legacy backup is fully inspected before migration", inspect_pos < normalize_pos < write_pos)
inspect_start = source.index("fun inspectCareerBackup(payload:")
inspect_end = source.index("private fun readCareerImportJournal()", inspect_start)
inspect_block = source[inspect_start:inspect_end]
check("legacy checksum is verified against the original payload", 'preferenceSnapshotSha256(values)' in inspect_block and inspect_pos < normalize_pos)
check("import writes normalized preferences only", "val values = withoutRemovedScoutingPreferences(payload.getJSONObject(\"preferences\"))" in import_block)
check("round-trip comparison uses normalized legacy state", "withoutRemovedScoutingPreferences(values)" in import_block)

# Ensure sanitizer copies input, preserving the checksum evidence on original legacy payload.
helper_start = source.index("private fun withoutRemovedScoutingPreferences")
helper_end = source.index("/** Canonical digest", helper_start)
helper = source[helper_start:helper_end]
check("sanitizer copies JSON before removing obsolete key", 'JSONObject(values.toString()).apply { remove("marketScouting") }' in helper)
check("old key still cleaned from local preferences", 'prefs.edit().remove("marketScouting").apply()' in source)

check("release metadata remains on a version newer than the V710 migration", current_version >= 710 and f'versionName = "0.{current_version}.0"' in gradle)
check("package manifest and current audit/changelog match release metadata", f"Version: {current_version} / 0.{current_version}.0" in manifest and changelog.is_file() and audit.is_file())

failed = [name for name, ok in checks if not ok]
for name, ok in checks:
    print(f"{'PASS' if ok else 'FAIL'}: {name}")
print(f"\n{len(checks)-len(failed)}/{len(checks)} V710 save migration checks passed")
if failed:
    raise SystemExit(1)
