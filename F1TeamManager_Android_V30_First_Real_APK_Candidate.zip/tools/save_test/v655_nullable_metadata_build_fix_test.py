#!/usr/bin/env python3
"""Regression checks for the nullable CareerSaveMetadata callback build fix."""
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[2]
screen = (ROOT / "app/src/main/java/com/f1teammanager/SaveManagementScreen.kt").read_text(encoding="utf-8")
gradle = (ROOT / "app/build.gradle.kts").read_text(encoding="utf-8")

checks = []
def check(label, condition):
    checks.append((label, bool(condition)))

start = screen.find('IconButton(enabled = metadata != null && !busy, onClick = {')
end = screen.find('IconButton(onClick = { pendingDelete = file }', start)
callback = screen[start:end] if start >= 0 and end >= 0 else ""
version_code = re.search(r"versionCode\s*=\s*(\d+)\b", gradle)
version_name = re.search(r'versionName\s*=\s*"([^"]+)"', gradle)
current_code = int(version_code.group(1)) if version_code else -1
check("versionCode retains the V655 build-fix baseline", current_code >= 655)
check("versionName matches the current versionCode", bool(version_name) and version_name.group(1) == f"0.{current_code}.0")
check("load callback found", bool(callback))
check("callback copies nullable value into local", "val saveMetadata = metadata" in callback)
check("callback explicitly handles null", "if (saveMetadata == null)" in callback)
check("modeLabel called only on guarded local", "saveMetadata.modeLabel()" in callback and "metadata.modeLabel()" not in callback)
check("invalid metadata prevents import", callback.find("if (saveMetadata == null)") < callback.find("store.importCareerBackup(payload)"))
check("no unsafe non-null assertion", "metadata!!" not in callback and "saveMetadata!!" not in callback)
check("V655 changelog exists", (ROOT / "CHANGELOG_V655.md").is_file())

for label, ok in checks:
    print(("PASS" if ok else "FAIL") + " | " + label)
failed = sum(not ok for _, ok in checks)
print(f"RESULT: {len(checks)-failed}/{len(checks)} checks passed")
raise SystemExit(1 if failed else 0)
