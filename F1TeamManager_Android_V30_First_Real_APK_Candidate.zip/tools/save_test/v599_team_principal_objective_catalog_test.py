from pathlib import Path
root=Path(__file__).resolve().parents[2]
engine=(root/'app/src/main/java/com/f1teammanager/core/manager/TeamPrincipalCareerEngine.kt').read_text()
prefs=(root/'app/src/main/java/com/f1teammanager/CareerPreferences.kt').read_text()
checks={
 'one fixed primary rank objective':'"Objetivo principal"' in engine and '"rank", mainTarget, 4' in engine,
 'five non-primary objectives selected':'take(5)' in engine and 'return listOf(primary) + selected' in engine,
 'secondary is no longer forced to cash':'return listOf(primary, secondary)' not in engine,
 'cash goal remains in general pool':'"Reserva financeira"' in engine and '"cash"' in engine,
 'all seven facility categories available':all(f'FacilityType.{x}' in engine for x in ['FACTORY','RESEARCH','WIND_TUNNEL','SIMULATOR','SCOUTING','DRIVER_DEVELOPMENT','MARKETING']),
 'facility goal target reflects current level':'current + 1' in engine and '"facility_${facility.name}"' in engine,
 'facility completion checks actual levels':'facilityLevels[facility] ?: 0' in engine and '>= goal.target' in engine,
 'research goal checks completed designs':'"research" -> completedResearchCount >= goal.target' in engine,
 'manufacturing goal checks physical pieces ready':'"manufacture" -> manufacturedPiecesReady >= goal.target' in engine,
 'season end passes facility metrics':'facilityLevels = loadFacilities(state.teamId)' in prefs,
 'season end passes completed research metric':'completedResearchCount = loadResearch(state.teamId)' in prefs,
 'season end passes manufacturing metric':'manufacturedPiecesReady = loadFactory(state.teamId)' in prefs,
 'prestige max +8 retained':'if (rawDelta > 8) 8' in engine,
 'failed objectives still penalize prestige':'if (result) goal.prestige else -goal.prestige' in engine,
 'version 599':'versionCode = 599' in (root/'app/build.gradle.kts').read_text() and 'versionName = "0.599.0"' in (root/'app/build.gradle.kts').read_text(),
}
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL')+' '+name)
print(f'{sum(checks.values())}/{len(checks)} checks passed')
raise SystemExit(0 if all(checks.values()) else 1)
