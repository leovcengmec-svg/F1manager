from pathlib import Path
root=Path(__file__).resolve().parents[2]
engine=(root/'app/src/main/java/com/f1teammanager/core/manager/TeamPrincipalCareerEngine.kt').read_text()
prefs=(root/'app/src/main/java/com/f1teammanager/CareerPreferences.kt').read_text()
ui=(root/'app/src/main/java/com/f1teammanager/MainActivity.kt').read_text()
checks={
 'initial prestige is 1':'teamId = teamId, prestige = 1' in engine,
 'schema 3 serializes objectives':'            3, teamId, prestige' in engine and 'objectivesText' in engine,
 'legacy schemas 1-2 remain accepted':'schema !in 1..3' in engine,
 'primary objective rank scales by current team rank':'fun targetRank(teamRank: Int)' in engine,
 'six objectives generated':'return listOf(primary) + selected' in engine and 'take(5)' in engine,
 'cash objective evaluated':'"cash" -> cashBalance >= goal.target.toLong()' in engine,
 'constructor points objective evaluated':'"points" -> constructorPoints >= goal.target' in engine,
 'missed goals subtract prestige':'if (result) goal.prestige else -goal.prestige' in engine,
 'positive seasonal prestige capped at 8':'if (rawDelta > 8) 8' in engine,
 'season generates next objectives':'objectives = generateObjectives(state.teamId, season + 1' in engine,
 'contract renewal regenerates objectives':'objectives = generateObjectives(state.teamId, nextSeason' in engine,
 'team change regenerates objectives':'objectives = generateObjectives(newTeamId, nextSeason' in engine,
 'season evaluator receives points and cash':'constructorPoints = points[state.teamId] ?: 0' in prefs and 'cashBalance = aiTeamBudget(state.teamId)' in prefs,
 'UI lists objective categories':'state.objectives.forEachIndexed' in ui and '"PRINCIPAL"' in ui and '"SECUNDÁRIO"' in ui,
 'version is 599':'versionCode = 599' in (root/'app/build.gradle.kts').read_text(),
}
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL')+' '+name)
print(f'{sum(checks.values())}/{len(checks)} checks passed')
raise SystemExit(0 if all(checks.values()) else 1)
