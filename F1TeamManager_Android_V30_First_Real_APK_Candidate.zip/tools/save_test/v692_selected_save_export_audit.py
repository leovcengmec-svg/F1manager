from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[2]
screen = (ROOT / "app/src/main/java/com/f1teammanager/SaveManagementScreen.kt").read_text(encoding="utf-8")
policy = (ROOT / "app/src/main/java/com/f1teammanager/SaveExportTargetPolicy.kt").read_text(encoding="utf-8")
test = (ROOT / "app/src/test/kotlin/SaveExportTargetPolicyV692Test.kt").read_text(encoding="utf-8")
gradle = (ROOT / "app/build.gradle.kts").read_text(encoding="utf-8")

checks = {
    "release version is V692": "versionCode = 692" in gradle and 'versionName = "0.692.0"' in gradle,
    "explicit selected path controls export source": "shouldExportLiveCareer(selectedPath)" in screen,
    "selected file is resolved by its exact absolute path": 'availableSaves.firstOrNull { it.absolutePath == selectedPath }' in screen,
    "selected file payload is read from selected file": 'payload = JSONObject(chosen.readText())' in screen,
    "career ID equality no longer triggers live substitution": "chosenPayloadCareerId" not in screen and "liveCareerId" not in screen,
    "selected save is not overwritten during selected export": "writeSaveAtomically(snapshotFile" in screen and "payload = JSONObject(chosen.readText())" in screen,
    "null selection falls back to live career only": "selectedSavePath.isNullOrBlank()" in policy,
    "same-career different-team snapshot regression is tested": "same career ID" in test,
}
for name, ok in checks.items():
    print(("PASS" if ok else "FAIL") + " - " + name)
if not all(checks.values()):
    raise SystemExit(1)
print(f"V692 selected-save export audit: {sum(checks.values())}/{len(checks)} passed")
