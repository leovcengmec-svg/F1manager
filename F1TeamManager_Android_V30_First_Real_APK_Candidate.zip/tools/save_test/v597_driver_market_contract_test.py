from pathlib import Path

p = Path(__file__).resolve().parents[2] / "app/src/main/java/com/f1teammanager/core/manager/DriverMarketEngine.kt"
s = p.read_text(encoding="utf-8")
checks = {
    "current team strength compared": "currentStrength - destinationStrength" in s,
    "sporting penalty capped": "coerceIn(0, 32)" in s,
    "salary compared to current deal": "current?.salary?.toLong()" in s,
    "exceptional salary thresholds": all(x in s for x in ["salaryRatio >= 4.0", "salaryRatio >= 3.0", "salaryRatio >= 2.0", "salaryRatio >= 1.5"]),
    "sporting penalty reduces interest": "exceptionalMoneyBonus - sportingPenalty" in s,
}
for name, ok in checks.items(): print(("PASS" if ok else "FAIL") + " — " + name)
if not all(checks.values()): raise SystemExit(1)
print(f"{sum(checks.values())}/{len(checks)} checks passed")
