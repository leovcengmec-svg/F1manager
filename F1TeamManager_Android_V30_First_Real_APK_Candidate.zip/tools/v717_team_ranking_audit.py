#!/usr/bin/env python3
"""Static and contract audit for V717 Team Ranking integration."""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
main = (ROOT / "app/src/main/java/com/f1teammanager/MainActivity.kt").read_text(encoding="utf-8")
models = (ROOT / "app/src/main/java/com/f1teammanager/core/manager/CarGarageModels.kt").read_text(encoding="utf-8")
finance = (ROOT / "app/src/main/java/com/f1teammanager/core/manager/AITeamFinancialEngine.kt").read_text(encoding="utf-8")
car_dev = (ROOT / "app/src/main/java/com/f1teammanager/core/manager/CarDevelopmentEngine.kt").read_text(encoding="utf-8")
gradle = (ROOT / "app/build.gradle.kts").read_text(encoding="utf-8")
manifest = (ROOT / "package_manifest.txt").read_text(encoding="utf-8")

screen = main[main.index("private fun TeamRankingScreen("):main.index("@Composable\nprivate fun ManagementHub(")]
builder = main[main.index("private fun buildTeamRankingSnapshot("):main.index("@Composable\nprivate fun TeamRankingScreen(")]
management = main[main.index("@Composable\nprivate fun ManagementHub("):main.index("private fun strategyLabel")]

checks = {
    "V717 ranking implementation remains available in the V718 base": "TeamRankingScreen" in main and "Screen.TEAM_RANKING" in main,
    "Ranking screen is independently routed": "TEAM_RANKING" in main and 'DetailScaffold("RANKING DAS EQUIPES"' in main,
    "Ranking is linked from management hub": '"RANKING DAS EQUIPES" to onTeamRanking' in management and "onTeamRanking={screen=Screen.TEAM_RANKING}" in main,
    "All 40 world teams are the source": "WorldDatabase.teams.map { definition ->" in builder and "WorldDatabase.teams.size" in screen,
    "Rows show team logo and open existing team profile": "TeamLogo(entry.team.name, entry.team.id" in screen and "onOpenTeam(entry.team.id)" in screen,
    "Current strength uses physical two-car average": "currentGarage.teamAverageOverall" in builder and "val teamAverageOverall: Int get() = (car1.overall + car2.overall + 1) / 2" in models,
    "Cash ranking uses player and AI finance ledgers": "playerManagerState.finance.budget" in builder and "aiFinanceByTeam[definition.id]?.finance?.budget" in builder and "fun allStates(): List<State>" in finance,
    "Next-car ranking uses official physical construction pipeline": "buildNextSeasonGarage(" in builder and "buildAiNextSeasonGarage(" in builder and "AnnualCarRegulationEngine.applyToGarage" in builder,
    "Next-car comparator sorts by projected Overall, descending": "compareByDescending<TeamRankingEntry> { it.nextSeasonStrength }" in screen,
    "All three modes sort descending": all(x in screen for x in ["compareByDescending<TeamRankingEntry> { it.currentStrength }", "compareByDescending<TeamRankingEntry> { it.cash }", "compareByDescending<TeamRankingEntry> { it.nextSeasonStrength }"]),
    "Next-car mode exposes Overall and delta": "entry.nextSeasonStrength" in screen and "entry.nextSeasonDelta" in screen and '"OVERALL / Δ"' in screen,
    "Player team is visually highlighted": 'if (isPlayer) Color(0xFF2B1B21) else Panel' in screen and '"SUA EQUIPE"' in screen,
    "Snapshot work runs off UI thread": "withContext(Dispatchers.Default)" in screen,
    "Single AI garage simulation reused for current and next car": builder.count("simulateAiDevelopment(") == 1 and "val currentGarage = if (isPlayer)" in builder,
    "Shared memory cache with compact invalidation fingerprint": all(x in main for x in ["TeamRankingMemoryCache.get(key)", "TeamRankingMemoryCache.put(key, rows)", "aiFinance.performanceFingerprint(store.season)", "playerStateFingerprint", "regulationSeed"]),
    "No ranking persistence fields introduced": "TeamRankingCacheKey" in main and "saveTeamRanking" not in main and "teamRanking" not in (ROOT / "app/src/main/java/com/f1teammanager/CareerPreferences.kt").read_text(encoding="utf-8"),
    "Prior performance/sponsorship audits retained": (ROOT / "tools/v716_performance_and_sponsorship_audit.py").is_file() and "val baseline = unlocked.first()" in (ROOT / "app/src/main/java/com/f1teammanager/core/manager/TeamSponsorshipEngine.kt").read_text(encoding="utf-8"),
}

for label, ok in checks.items():
    print(("PASS" if ok else "FAIL") + " | " + label)
failed = sum(not ok for ok in checks.values())
print(f"RESULT: {len(checks)-failed}/{len(checks)} V717 team-ranking checks passed")
sys.exit(1 if failed else 0)
