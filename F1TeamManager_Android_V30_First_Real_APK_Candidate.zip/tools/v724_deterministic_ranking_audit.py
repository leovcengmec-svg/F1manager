#!/usr/bin/env python3
from pathlib import Path
import sys
R=Path(__file__).resolve().parents[1]
main=(R/'app/src/main/java/com/f1teammanager/MainActivity.kt').read_text()
fin=(R/'app/src/main/java/com/f1teammanager/core/manager/AITeamFinancialEngine.kt').read_text()
dev=(R/'app/src/main/java/com/f1teammanager/core/manager/AITeamDevelopmentEngine.kt').read_text()
menu=(R/'app/src/main/java/com/f1teammanager/MainMenuScreen.kt').read_text()
gradle=(R/'app/build.gradle.kts').read_text(); manifest=(R/'package_manifest.txt').read_text()
checks={
 'VersionCode/Name are 724':'versionCode = 724' in gradle and 'versionName = "0.724.0"' in gradle,
 'Package manifest aligned':'Version: 724 / 0.724.0' in manifest and 'Base: V723 / 0.723.0' in manifest,
 'Simulation publish defaults disabled':dev.count('publishLiveOverall: Boolean = false') >= 2,
 'UI helper publish default disabled':'publishLiveOverall: Boolean = false' in main,
 'Weekly ranking frozen before team loop':'weeklyInvestmentRanking = TechnicalInvestmentEngine.seasonRanking().toSortedMap()' in main,
 'Weekly Overall snapshot frozen before team loop':'weeklyOverallSnapshot = TechnicalInvestmentEngine.liveOverallGrid().toMap()' in main,
 'Weekly capacity consumes both frozen snapshots':'developmentCapacity(aiTeam.id, store.season, weeklyInvestmentRanking, weeklyOverallSnapshot)' in main,
 'Weekly canonical simulation explicitly publishes':'publishLiveOverall = true' in main,
 'Finance capacity accepts ranking snapshot':'investmentRankingSnapshot: Map<Int, Int>? = null' in fin,
 'Finance capacity accepts Overall snapshot':'liveOverallSnapshot: Map<Int, Double>? = null' in fin,
 'Finance uses supplied rank when present':'investmentRankingSnapshot?.get(teamId)' in fin,
 'Finance uses supplied Overall grid when present':'liveOverallSnapshot ?: TechnicalInvestmentEngine.liveOverallGrid()' in fin,
 'Team overview capacity uses frozen references':'developmentCapacity(t.id, store.season, investmentRankingSnapshot, investmentOverallSnapshot)' in main,
 'Team ranking freezes references':'val frozenRanking = (investmentRankingSnapshot ?: TechnicalInvestmentEngine.seasonRanking()).toSortedMap()' in main and 'val frozenOveralls = TechnicalInvestmentEngine.liveOverallGrid().toMap()' in main,
 'Official next car uses committed investment':'val investment = actualInvestment.coerceAtLeast(0L)' in main,
 'Projection remains separate informational value':'nextSeasonProjectedInvestment = projectedInvestment' in main,
 'Continue game always enabled':'Icons.Filled.FolderOpen, true, onContinue' in menu,
 'V724 changelog and audit exist':(R/'CHANGELOG_V724.md').exists() and (R/'AUDIT_V724_DETERMINISTIC_RANKING.md').exists(),
 'No history-deletion directive introduced':'deleteHistorical' not in main,
}
for n,ok in checks.items(): print(('PASS' if ok else 'FAIL')+' | '+n)
f=sum(not x for x in checks.values()); print(f'RESULT: {len(checks)-f}/{len(checks)} V724 checks passed')
sys.exit(1 if f else 0)
