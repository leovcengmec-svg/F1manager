#!/usr/bin/env python3
"""Version-independent static contract audit for the current season transition."""
from pathlib import Path
import re
root = Path(__file__).resolve().parents[1]
main = (root/'app/src/main/java/com/f1teammanager/MainActivity.kt').read_text(encoding='utf-8')
prefs = (root/'app/src/main/java/com/f1teammanager/CareerPreferences.kt').read_text(encoding='utf-8')
gradle = (root/'app/build.gradle.kts').read_text(encoding='utf-8')
fn = main.split('fun startNextSeason() {', 1)[1].split('fun startDriverDevelopment(', 1)[0]
checks = []
def check(label, ok):
    checks.append((label, bool(ok)))
code = re.search(r'versionCode\s*=\s*(\d+)', gradle)
name = re.search(r'versionName\s*=\s*"([^"]+)"', gradle)
check('version metadata matches', bool(code and name and name.group(1) == f'0.{code.group(1)}.0'))
check('season-end precondition exists', 'require(isSeasonEnded())' in prefs)
check('durable transition journal begins', 'beginSeasonTransitionJournal(store.season)' in fn)
check('committed state recovery does not replay engine', 'pendingTransition.third == "STATE_PERSISTED"' in fn)
check('committed transition cleanup exists', 'completeSeasonTransitionJournal()' in fn)
check('rollback restores snapshot', 'restoreCareerSeasonTransitionSnapshot()' in prefs and 'rollbackSeasonTransitionJournal()' in fn)
stages = ['MANAGER_STATE_READY','CAR_SAVED','GARAGE_SAVED','FACILITIES_SAVED','TECHNICAL_INVESTMENT_SAVED','RESEARCH_SAVED','FACTORY_SAVED','DRIVER_DEVELOPMENT_SAVED','MARKET_SAVED','FINANCE_SAVED','SPONSORS_SAVED','STATE_PERSISTED']
positions = [fn.find(f'markSeasonTransitionStage("{stage}")') for stage in stages]
check('all canonical checkpoints exist and are ordered', all(p >= 0 for p in positions) and positions == sorted(positions))
saves = ['store.saveCar(teamId, managerState.car)','store.saveGarage(teamId,','store.saveFacilities(teamId, managerState.facilities)','store.saveTechnicalInvestment(teamId, managerState.technicalInvestment)','store.saveResearch(teamId, managerState.research)','store.saveFactory(teamId, managerState.factory)','store.saveDriverDevelopment(teamId, managerState.driverDevelopment)','store.saveDriverMarket(managerState.driverMarket)','store.saveFinance(teamId, managerState.finance)','store.saveSponsors(teamId, managerState.sponsors)']
save_positions = [fn.find(item) for item in saves]
commit = fn.find('markSeasonTransitionStage("STATE_PERSISTED")')
check('all ten canonical saves precede durable commit', all(p >= 0 for p in save_positions) and commit > 0 and all(p < commit for p in save_positions))
allowed = prefs.split('private val seasonTransitionStages = listOf(',1)[1].split(')',1)[0]
check('checkpoint state machine includes all checkpoints', all(f'"{stage}"' in allowed for stage in ['PREPARED','SEASON_ADVANCED','CAREER_RESET_DONE'] + stages))
failed = [label for label, ok in checks if not ok]
for label, ok in checks: print(('PASS' if ok else 'FAIL') + ' | ' + label)
print(f'RESULT: {len(checks)-len(failed)}/{len(checks)} transition contract checks passed')
if failed: raise SystemExit(1)
