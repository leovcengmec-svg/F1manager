from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
read = lambda p: (ROOT / p).read_text(encoding="utf-8")

gradle = read("app/build.gradle.kts")
manifest = read("package_manifest.txt")
evolution = read("app/src/main/java/com/f1teammanager/core/season/DriverEvolutionEngine.kt")
profile = read("app/src/main/java/com/f1teammanager/core/season/DriverProfileCatalog.kt")
career = read("app/src/main/java/com/f1teammanager/CareerPreferences.kt")
facility = read("app/src/main/java/com/f1teammanager/core/manager/FacilityModels.kt")
main = read("app/src/main/java/com/f1teammanager/MainActivity.kt")
snapshot = read("app/src/main/java/com/f1teammanager/core/season/DriverEvolutionSnapshot.kt")

checks = {
    "version metadata is V735": "versionCode = 735" in gradle and 'versionName = "0.735.0"' in gradle and "Version: 735 / 0.735.0" in manifest and "Base: V734 / 0.734.0" in manifest,
    "class margin uses 105/110/115/120/125": all(f"average >= {v}.0" in evolution for v in (105, 110, 115, 120, 125)),
    "five real GP minimum retained": "CLASS_MARGIN_MINIMUM_GP_SAMPLE = 5" in evolution,
    "earned margin remains monotonic": "maxOf(\n        previousMargin.coerceIn(0, 5)" in evolution,
    "Pro potential floor reaches 94": '"Pro" -> ceiling("Pro") + 5' in profile,
    "career promotion checks all historical titles": "history.driverChampions()" in career and "base.id in careerChampionDriverIds" in career and "history.driverChampions(completedSeason)" not in career,
    "free driver margin recalculates from real prior-year average": "maxOf(\n                    previousClassEarnedMargins[id] ?: 0" in career,
    "manager free driver margin also recalculates": "maxOf(\n                    earnedMargins[base.id]?.get(manager.season - 1) ?: 0" in read("app/src/main/java/com/f1teammanager/core/manager/ManagerSeasonEngine.kt"),
    "current-cycle graph selector exists": "object DriverEvolutionChartModel" in snapshot and "filter { it.cycleIndex == cycle }" in snapshot,
    "UI uses only current cycle": "DriverEvolutionChartModel.currentCycle(snapshots)" in main,
    "UI draws endpoint circles only": "drawCircle(Color(0xFFFFC857)" in main and "drawCircle(curveColor" in main and "ordered.forEach { point" not in main[main.index("private fun DriverEvolutionHistoryCard"):main.index("private data class DriverHistorySeasonUi")],
    "curve is cubic and intermediate snapshots remain curve geometry": "path.cubicTo" in main,
    "all facility percentage output uses one-decimal formatter": (ROOT / "app/src/main/java/com/f1teammanager/core/manager/FacilityPercentageFormatter.kt").is_file() and 'String.format(java.util.Locale("pt", "BR"), "%.1f", value)' in read("app/src/main/java/com/f1teammanager/core/manager/FacilityPercentageFormatter.kt"),
    "wind tunnel and simulator percentages are formatted": "FacilityPercentageFormatter.format(normalized * 0.10)" in facility and "FacilityPercentageFormatter.format(normalized * 0.05)" in facility,
    "promotion regression tests present": (ROOT / "app/src/test/kotlin/com/f1teammanager/core/season/DriverClassProgressionV735Test.kt").is_file(),
    "chart tests present": (ROOT / "app/src/test/kotlin/com/f1teammanager/core/season/DriverEvolutionChartModelV735Test.kt").is_file(),
    "facility formatting tests present": (ROOT / "app/src/test/kotlin/com/f1teammanager/core/manager/FacilityPercentageFormattingV735Test.kt").is_file(),
}
failed = [name for name, ok in checks.items() if not ok]
for name, ok in checks.items():
    print(f"{'PASS' if ok else 'FAIL'}: {name}")
print(f"RESULT: {len(checks)-len(failed)}/{len(checks)} checks passed")
if failed:
    raise SystemExit(1)
