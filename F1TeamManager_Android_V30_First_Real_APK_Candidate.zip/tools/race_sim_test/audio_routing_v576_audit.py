#!/usr/bin/env python3
"""Static contract audit for the V576 external audio event routing."""
from pathlib import Path
import json
import sys

ROOT = Path(__file__).resolve().parents[2]
checks = []
def check(name, ok, detail=""):
    checks.append((name, bool(ok), detail))

catalog_path = ROOT / "app/src/main/assets/audio/catalog.json"
main_path = ROOT / "app/src/main/java/com/f1teammanager/MainActivity.kt"
audio_path = ROOT / "app/src/main/java/com/f1teammanager/ExternalAudio.kt"
try:
    catalog = json.loads(catalog_path.read_text(encoding="utf-8"))
    ids = {item["id"] for item in catalog["items"]}
    check("Audio catalog JSON parses", True)
except Exception as exc:
    catalog, ids = {}, set()
    check("Audio catalog JSON parses", False, str(exc))

main = main_path.read_text(encoding="utf-8") if main_path.is_file() else ""
audio = audio_path.read_text(encoding="utf-8") if audio_path.is_file() else ""
required = {
    "menu", "interface", "interface_2", "interface_3", "qualifying_race", "results",
    "brazilian_driver_victory", "season_end", "player_driver_events", "pit_call", "safety_car", "red_flag"
}
check("All requested canonical audio IDs are cataloged", required <= ids, f"missing={sorted(required - ids)}")
for token, description in [
    ('playEvent("pit_call", listOf("box_audio"))', "pit stop uses canonical ID and legacy fallback"),
    ('playEvent("player_driver_events", listOf("driver_warning"))', "driver events use canonical ID and legacy fallback"),
    ('EventType.SAFETY_CAR_DEPLOYED', "Safety Car event is routed"),
    ('EventType.VSC_DEPLOYED', "VSC deployment is routed"),
    ('EventType.RED_FLAG_DEPLOYED', "red flag event is routed"),
    ('EventType.CRASH', "driver incident event is routed"),
    ('EventType.OVERTAKE', "overtake event is routed"),
    ('lastAudioEventKey', "duplicate event playback is guarded"),
]:
    check(description, token in main)
check("Event playback supports fallback IDs", "fun playEvent(id: String, fallbackIds: List<String> = emptyList())" in audio and "listOf(id) + fallbackIds" in audio)
check("Missing external files do not require bundled audio", "val uri = resolvedUri ?: return" in audio)
for name, ok, detail in checks:
    print(("PASS" if ok else "FAIL") + " | " + name + (f" | {detail}" if detail else ""))
failed = sum(not ok for _, ok, _ in checks)
print(f"RESULT: {len(checks)-failed}/{len(checks)} audio routing checks passed")
print("LIMIT: Static routing/catalog audit; real playback requires user audio files and Android device testing.")
sys.exit(1 if failed else 0)
