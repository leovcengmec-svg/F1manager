package com.f1teammanager.core.manager

import com.f1teammanager.core.season.WorldDatabase

fun main() {
    val team = WorldDatabase.teams.first()
    val engine = AITeamFinancialEngine(seed = 73_233)
    val market = DriverMarketState()
    engine.adoptFormerPlayerTeam(
        team.id,
        2028,
        TeamFinanceState(budget = 500_000_000L, seasonIncome = 150_000_000L, seasonExpenses = 30_000_000L),
        TeamFacilitiesState(FacilityType.values().associateWith { 0 })
    )
    var currentSeason = 2028
    for (absoluteWeek in 1..280) {
        val seasonOffset = (absoluteWeek - 1) / 56
        val season = 2028 + seasonOffset
        val week = ((absoluteWeek - 1) % 56) + 1
        if (season != currentSeason) {
            currentSeason = season
            engine.openNewSeasonAtBoundary(team.id, season, market)
        }
        engine.advanceFacilityDevelopment(team.id, season, week, currentOverall = 62)
    }
    val finalLevels = FacilityType.values().associate { it.name to engine.facilities(team.id).level(it) }
    val upgraded = finalLevels.values.count { it > 0 }
    check(upgraded == 7) { "After five seasons the AI should have begun developing all seven facilities: $finalLevels" }
    check(engine.state(team.id, currentSeason).finance.budget >= 0L)
    println("V732 5-SEASON FACILITY SMOKE PASS: $finalLevels; cash=${engine.state(team.id, currentSeason).finance.budget}")
}
