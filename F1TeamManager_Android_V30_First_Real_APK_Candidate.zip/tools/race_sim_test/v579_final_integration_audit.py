from pathlib import Path
import re
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[2]
checks = []
def check(label, condition):
    checks.append((label, bool(condition)))
    print(("PASS" if condition else "FAIL") + " | " + label)

build = (ROOT / "app/build.gradle.kts").read_text()
manifest = ROOT / "app/src/main/AndroidManifest.xml"
main = (ROOT / "app/src/main/java/com/f1teammanager/MainActivity.kt").read_text()
career = (ROOT / "app/src/main/java/com/f1teammanager/CareerPreferences.kt").read_text()
market = (ROOT / "app/src/main/java/com/f1teammanager/core/manager/DriverMarketEngine.kt").read_text()
sponsor = (ROOT / "app/src/main/java/com/f1teammanager/core/manager/TeamSponsorshipEngine.kt").read_text()
grid = (ROOT / "app/src/main/java/com/f1teammanager/core/season/ChampionshipGridRules.kt").read_text()

check("version code/name are V579", "versionCode = 579" in build and 'versionName = "0.579.0"' in build)
try:
    ET.parse(manifest)
    manifest_ok = True
except Exception:
    manifest_ok = False
check("Android manifest XML parses", manifest_ok)
check("shared grid rules derive positions from current team count", "fun targetPosition" in grid and "fun sponsorTargetRange" in grid and "gridSize(teams)" in grid)
check("sponsor targets use dynamic grid rules", "ChampionshipGridRules.sponsorTargetRange" in sponsor and "coerceIn(1,40)" not in sponsor and "coerceAtMost(80)" not in sponsor)
check("career evolution targets and fallbacks use dynamic grid size", "ChampionshipGridRules.targetPosition" in career and "ChampionshipGridRules.gridSize(WorldDatabase.teams.size)" in career and "coerceIn(1, 80)" not in career)
check("market driver IDs are resolved from the live catalog", "private val allIds: Set<Int> get() = WorldDatabase.allDrivers.map { it.id }.toSet()" in market)
check("new-game and team-selection counts derive from live teams", "$teamCount" in main and "allTeams.sumOf { it.driverIds.distinct().size }" in main and "40 equipes  •  80 pilotos" not in main)
check("market counters derive from catalog and grid", "catalogDriverCount = WorldDatabase.allDrivers.size" in main and "activeGridCount = WorldDatabase.teams.sumOf" in main and 'MarketStat("100", "PILOTOS"' not in main)
check("history descriptions use actual record counts", '"${rows.size} registros' in main and '"80 pilotos • Ano' not in main and '"40 equipes • Ano' not in main)
check("live catalog runtime harness exists", (ROOT / "tools/race_sim_test/CatalogLiveMarketAuditV579.kt").exists())
check("dynamic-grid unit tests cover base and expanded rosters", (ROOT / "app/src/test/java/com/f1teammanager/core/season/ChampionshipGridRulesV579Test.kt").exists())
check("reproducible 60-GP runner uses V579 source list", "headless_core_sources_v579.txt" in (ROOT / "tools/race_sim_test/run_two_season_headless_audit.sh").read_text())
check("V579 changelog and audit are present", (ROOT / "CHANGELOG_V579.md").exists() and (ROOT / "AUDIT_V579.md").exists())
assets = ROOT / "app/src/main/assets"
asset_files = [p for p in assets.rglob("*") if p.is_file()] if assets.exists() else []
check(f"external/local assets remain populated ({len(asset_files)} files)", len(asset_files) >= 190)
check("historical version records remain present", len(list(ROOT.glob("AUDIT_V*.md"))) + len(list(ROOT.glob("CHANGELOG_V*.md"))) >= 500)

failed = [label for label, ok in checks if not ok]
print(f"RESULT: {len(checks)-len(failed)}/{len(checks)} V579 integration source checks passed")
if failed:
    raise SystemExit(1)
