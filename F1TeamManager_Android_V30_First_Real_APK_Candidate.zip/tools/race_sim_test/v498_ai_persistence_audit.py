from pathlib import Path
import re, zipfile
root = Path(__file__).resolve().parents[2]
engine = (root/'app/src/main/java/com/f1teammanager/core/manager/AITeamFinancialEngine.kt').read_text()
test = (root/'app/src/test/kotlin/com/f1teammanager/AIFacilitySeasonContinuityV496Test.kt').read_text()
gradle = (root/'app/build.gradle.kts').read_text()
checks = {
 'snapshot parser has no 30-field truncation': 'line.split("|", limit=Int.MAX_VALUE)' in engine and 'line.split("|", limit=30)' not in engine,
 'facility ledger exported independently': 'listOf("F", teamId' in engine,
 'active facility upgrade exported independently': 'listOf("U", teamId' in engine,
 'facility-only persistence is tested': 'facilityLedgerPersistsEvenBeforeFinancialStateExists' in test,
 'extended 32-field snapshot is tested': 'snapshotKeepsFacilityLevelsAndSeasonLedgersInExtendedRecord' in test and '32, financialRow.split' in test,
 'Android version is 0.498.0': 'versionCode = 498' in gradle and 'versionName = "0.498.0"' in gradle,
 'prior V497 history retained': (root/'AUDIT_V497.md').exists() and (root/'CHANGELOG_V497.md').exists(),
 'external assets retained': len(list((root/'assets').rglob('*'))) >= 100 if (root/'assets').exists() else any('assets' in p.parts for p in root.rglob('*')),
}
for name, ok in checks.items(): print(('PASS' if ok else 'FAIL')+' | '+name)
print(f'RESULT: {sum(checks.values())}/{len(checks)}')
raise SystemExit(0 if all(checks.values()) else 1)
