#!/usr/bin/env python3
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[2]

def ck(label: str, ok: bool) -> bool:
    print(f"{'PASS' if ok else 'FAIL'} | {label}")
    return ok

gradle = (ROOT / 'app/build.gradle.kts').read_text(encoding='utf-8')
engine = (ROOT / 'app/src/main/java/com/f1teammanager/core/season/DriverEvolutionEngine.kt').read_text(encoding='utf-8')
manager = (ROOT / 'app/src/main/java/com/f1teammanager/core/manager/ManagerSeasonEngine.kt').read_text(encoding='utf-8')
career = (ROOT / 'app/src/main/java/com/f1teammanager/CareerPreferences.kt').read_text(encoding='utf-8')
focused = (ROOT / 'app/src/test/kotlin/FreeDriverEvolutionV650Test.kt').read_text(encoding='utf-8')
rate_test = (ROOT / 'app/src/test/kotlin/FreeDriverEvolutionTest.kt').read_text(encoding='utf-8')

checks = []
checks.append(ck('V650 versionCode/versionName', 'versionCode = 650' in gradle and 'versionName = "0.650.0"' in gradle))
checks.append(ck('Free-driver growth rate is exactly 0.90', bool(re.search(r'const val FREE_DRIVER_GROWTH_RATE\s*=\s*0\.90', engine))))
checks.append(ck('Shared free-driver tick uses neutral evidence and 90% factor', 'applyFreeDriverTick' in engine and 'FREE_DRIVER_NEUTRAL_PERFORMANCE_INDEX' in engine and 'facilityGrowthEfficiency = FREE_DRIVER_GROWTH_RATE' in engine))
checks.append(ck('Team Manager applies the free-driver tick to uncontracted roster members', 'freeDrivers' in manager and 'applyFreeDriverTick' in manager and 'if (base.id in active)' in manager))
checks.append(ck('Career mode applies the free-driver tick when market confirms no active contract', 'val driverMarket = loadDriverMarket()' in career and 'if (driverMarket == null) return@forEach' in career and 'applyFreeDriverTick' in career))
checks.append(ck('Free drivers are not added to sporting class-review samples', 'fabricated GP result' in manager and 'no synthetic result' in career))
checks.append(ck('Potential and annual attribute caps stay in shared engine', 'driver.potentialOverall' in engine and 'maxAnnualGain(driver.evolution)' in engine and 'applyPositiveGain' in engine))
checks.append(ck('Focused 30-GP test covers all free drivers and no class evidence', 'changed == 20' in focused and 'driverClassPerformance' in focused and 'driverEvolutionPhaseGps' in focused))
checks.append(ck('Exact 90% ratio has a deterministic test', 'baseline.bank * 0.90' in rate_test and 'FREE_DRIVER_GROWTH_RATE' in rate_test))
checks.append(ck('V650 release notes and audit are present', (ROOT/'CHANGELOG_V650.md').is_file() and (ROOT/'AUDIT_V650_FREE_DRIVER_EVOLUTION.md').is_file()))

passed = sum(checks)
print(f'RESULT: {passed}/{len(checks)} checks passed')
raise SystemExit(0 if passed == len(checks) else 1)
