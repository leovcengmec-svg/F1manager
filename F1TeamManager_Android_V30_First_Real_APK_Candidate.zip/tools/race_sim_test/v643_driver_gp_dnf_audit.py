from pathlib import Path
root=Path(__file__).resolve().parents[2]
main=(root/'app/src/main/java/com/f1teammanager/MainActivity.kt').read_text()
hist=(root/'app/src/main/java/com/f1teammanager/HistoricalDatabase.kt').read_text()
checks={
 'version 643': 'versionCode = 643' in (root/'app/build.gradle.kts').read_text(),
 'live season GP excludes DNFs': 'gps = valid.size' in main,
 'career GP excludes DNFs': 'val careerStarts = allRaces.count { !it.status.startsWith("DNF", ignoreCase = true) }' in main,
 'historical rows recalculate GP per driver': 'gps = driverRows.count { !it.status.startsWith("DNF", ignoreCase = true) }' in main,
 'historical rows recalculate DNF per driver': 'dnf = driverRows.count { it.status.startsWith("DNF", ignoreCase = true) }' in main,
 'season archive GP excludes DNFs': 'gps = rows.count { !it.status.startsWith("DNF", ignoreCase = true) }' in hist,
 'constructor GP counts a GP with at least one finisher': 'gpRows.any { !it.status.startsWith("DNF", ignoreCase = true) }' in hist,
 '30 races / 3 DNF => 27 completed': sum(1 for i in range(30) if i >= 3) == 27,
 '180 career records / 32 DNF => 148 completed': 180-32 == 148,
}
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL')+' '+name)
print(f'{sum(checks.values())}/{len(checks)}')
if not all(checks.values()): raise SystemExit(1)
