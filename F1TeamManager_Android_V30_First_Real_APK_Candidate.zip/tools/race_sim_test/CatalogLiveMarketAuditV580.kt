package com.f1teammanager.core.season

import com.f1teammanager.core.manager.DriverMarketEngine
import com.f1teammanager.core.manager.DriverMarketCatalogMigrationV560
import com.f1teammanager.core.manager.DriverTeamRole

/** Reproduces catalog edits after a long-lived market engine has already been created. */
fun main() {
    CustomWorldCatalog.pilots = emptyList()
    CustomWorldCatalog.teams = emptyList()
    val engine = DriverMarketEngine(5802026) // deliberately predates the new catalog records

    CustomWorldCatalog.pilots = listOf(
        CustomWorldCatalog.Pilot(101, "Piloto Custom A", "Brasil", "Médio", "Normal", 75, 74, 73, 72, 71, 70, 72, 41),
        CustomWorldCatalog.Pilot(102, "Piloto Custom B", "Brasil", "Médio", "Normal", 74, 73, 72, 71, 70, 69, 71, 41),
        CustomWorldCatalog.Pilot(103, "Agente Livre Custom", "Portugal", "Forte", "Normal", 78, 77, 76, 75, 74, 73, 75, 0)
    )
    CustomWorldCatalog.teams = listOf(
        CustomWorldCatalog.Team(41, "Equipe Custom V580", "Brasil", 101, 102, "equipe-41.png")
    )

    val worldDrivers = WorldDatabase.allDrivers
    val worldTeams = WorldDatabase.teams
    check(worldTeams.size == 41) { "Catalog edit did not expand team list: ${worldTeams.size}" }
    check(worldDrivers.any { it.id == 103 && it.teamId == 0 }) { "New free pilot missing from live catalog" }

    // Market is created from the new catalog, but its engine object predates the catalog edit.
    val initial = engine.initialState(2026)
    val migration = DriverMarketCatalogMigrationV560(engine).migrateAgainstCatalog(
        source = initial,
        season = 2026,
        catalogDrivers = worldDrivers,
        catalogTeams = worldTeams
    )
    val migrated = migration.state
    check(migrated.contracts.count { it.teamId == 41 && it.driverId in setOf(101, 102) } == 2) {
        "Custom team's two declared drivers were not contracted to that team"
    }
    check(103 in migrated.freeAgents) { "New free pilot was not reconciled into the market" }

    val openWeek = com.f1teammanager.core.season.SeasonCalendar.forSeason(2026).maxOf { it.weekOfSeason }
    val (afterOffer, offer) = engine.makeOffer(
        state = migrated,
        driverId = 103,
        toTeamId = 41,
        years = 1,
        salary = 1_000_000L,
        role = DriverTeamRole.EQUAL,
        season = 2026,
        currentWeek = openWeek,
        replaceDriverId = 101
    )
    check(offer.driverId == 103 && offer.toTeamId == 41) { "Long-lived market engine rejected the newly added pilot" }
    check(afterOffer.pending.any { it.driverId == 103 && it.toTeamId == 41 }) { "Offer for the new pilot was not persisted in market state" }

    check(ChampionshipGridRules.gridSize(40) == 80)
    check(ChampionshipGridRules.targetPosition(40, 0, 40) == 79)
    check(ChampionshipGridRules.targetPosition(40, 1, 40) == 80)
    check(ChampionshipGridRules.sponsorTargetRange(40, 40) == 77..80)
    check(ChampionshipGridRules.gridSize(worldTeams.size) == 82)
    check(ChampionshipGridRules.targetPosition(41, 0, worldTeams.size) == 81)
    check(ChampionshipGridRules.targetPosition(41, 1, worldTeams.size) == 82)
    check(ChampionshipGridRules.sponsorTargetRange(41, worldTeams.size) == 79..82)

    // Verify the real market validator and race-grid projection, not only ID discovery.
    check(com.f1teammanager.core.manager.DynamicGridEngine().validate(migrated).isEmpty()) {
        "Expanded market rejected by the dynamic grid validator: ${com.f1teammanager.core.manager.DynamicGridEngine().validate(migrated)}"
    }
    val liveGrid = com.f1teammanager.core.manager.DynamicGridEngine().snapshot(migrated)
    check(liveGrid.size == 82 && liveGrid.map { it.driverId }.distinct().size == 82)
    check(liveGrid.count { it.teamId == 41 } == 2)
    check(liveGrid.filter { it.teamId == 41 }.map { it.driverId }.toSet() == setOf(101, 102))

    // New team flows into constructor points, season prize ranking and sponsorship state.
    val customFinish = com.f1teammanager.core.race.FinishEntry(81, 101, "Piloto Custom A", "Equipe Custom V580", 60, 9_000_000L, "FINISHED", com.f1teammanager.core.race.Tyre.MEDIUM, 1)
    val customFinish2 = com.f1teammanager.core.race.FinishEntry(82, 102, "Piloto Custom B", "Equipe Custom V580", 60, 9_100_000L, "FINISHED", com.f1teammanager.core.race.Tyre.HARD, 1)
    val raceResult = com.f1teammanager.core.race.RaceResult(listOf(customFinish, customFinish2), emptyList(), null, com.f1teammanager.core.race.Weather.DRY, mapOf(101 to 0, 102 to 0), 0, 0)
    val constructorPoints = com.f1teammanager.core.race.ConstructorRacePoints.aggregate(raceResult, mapOf(101 to 41, 102 to 41))
    check(41 in constructorPoints && constructorPoints[41] == 0)
    check(com.f1teammanager.core.manager.SeasonPrizeEngine.rankTeams(mapOf(41 to 25)).any { it.first == 41 })
    check(com.f1teammanager.core.manager.TeamSponsorshipEngine(580).forTeam(41, 2026).sponsors.size == 5)

    // Economic rank and evolution now use the live team count while the legacy 40-team rules remain exact.
    check(com.f1teammanager.core.season.TeamRankScale.toBaselineRank(40, 40) == 40)
    check(com.f1teammanager.core.season.TeamRankScale.toBaselineRank(41, 41) == 40)
    check(com.f1teammanager.core.manager.TechnicalInvestmentEngine.create(2027, 41, 41).ranking == 41)
    check(com.f1teammanager.core.manager.TechnicalInvestmentEngine.create(2027, 41, 41).level == 1)
    check(com.f1teammanager.core.manager.ResearchEngine().discountPercentForRank(41, 41) == 60)
    check(com.f1teammanager.core.manager.FactoryEngine().fabricationDiscountPercentForRank(41, 41) == 30)
    val evolutionDriver = worldDrivers.first { it.id == 101 }
    val evolutionInput = com.f1teammanager.core.season.DriverEvolutionEngine.PerformanceInput(81, 5, 81.0, 0, 0, 81.0, null, 0)
    val evolutionTarget = com.f1teammanager.core.season.DriverEvolutionEngine.Target(81)
    val legacyEvolution = com.f1teammanager.core.season.DriverEvolutionEngine.evaluate(evolutionDriver, evolutionTarget, evolutionInput, 80)
    val expandedEvolution = com.f1teammanager.core.season.DriverEvolutionEngine.evaluate(evolutionDriver, evolutionTarget, evolutionInput, 82)
    check(legacyEvolution.index in 0.0..150.0 && expandedEvolution.index in 0.0..150.0)
    check(legacyEvolution.index != expandedEvolution.index) { "Driver evolution still behaves as if expanded grids had only 80 seats" }

    println("CatalogLiveMarketAuditV580: PASS | catalog->market->grid(82)->constructor/prize/sponsors->technical/research/factory/evolution")
}
