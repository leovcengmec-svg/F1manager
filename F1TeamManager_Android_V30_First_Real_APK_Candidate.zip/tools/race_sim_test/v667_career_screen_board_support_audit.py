#!/usr/bin/env python3
"""V667 static regression audit for Team Principal career presentation and board trust."""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[2]
def read(path):
    p = ROOT / path
    return p.read_text(encoding="utf-8") if p.is_file() else ""

GRADLE = read("app/build.gradle.kts")
ENGINE = read("app/src/main/java/com/f1teammanager/core/manager/TeamPrincipalCareerEngine.kt")
SCREEN = read("app/src/main/java/com/f1teammanager/TeamPrincipalCareerScreen.kt")
STORE = read("app/src/main/java/com/f1teammanager/CareerPreferences.kt")
MAIN = read("app/src/main/java/com/f1teammanager/MainActivity.kt")
TEST = read("app/src/test/java/com/f1teammanager/core/manager/TeamPrincipalContractCycleV639Test.kt")
checks = []
def ck(name, ok):
    checks.append((name, bool(ok)))

ck("Version is V667", "versionCode = 667" in GRADLE and 'versionName = "0.667.0"' in GRADLE)
ck("Initial support is 50", "const val INITIAL_BOARD_SUPPORT = 50" in ENGINE)
ck("Switching team resets support to 50", "boardSupport = INITIAL_BOARD_SUPPORT" in ENGINE)
ck("Same-team renewal preserves earned support", "boardSupport = state.boardSupport.coerceIn(0, 100)" in ENGINE)
ck("Legacy unstarted saves migrate from old default", "records.isEmpty() && p[8] != \"1\" && decodedLastProcessedSeason < migratedStartSeason" in ENGINE)
ck("Live assessment returns projected support and dismissal risk", "data class TeamPrincipalLiveBoardAssessment" in STORE and "TeamPrincipalLiveBoardAssessment(projectedSupport, dismissalRisk)" in STORE)
ck("Career screen receives live board support", "boardSupportEstimate = boardSupportEstimate" in MAIN and "support = boardSupportEstimate" in SCREEN)
ck("Portrait is visible with adjusted opacity and softened gradient", ".alpha(0.82f)" in SCREEN and "CareerPanel.copy(alpha = 0.10f)" in SCREEN)
ck("Cropped objective counter badge was removed", '"${state.objectives.size} OBJ."' not in SCREEN)
ck("Contract and achievements cards have room for full text", "height(if (compact) 78.dp else 82.dp)" in SCREEN and '"Toque para ver todas as conquistas"' not in SCREEN)
ck("Achievements surface remains clickable", ".clickable(onClick = onClick)" in SCREEN)
ck("Dynamic support and migration tests were added", "projectedBoardSupportChangesWithLiveSportingAndObjectiveEvidence" in TEST and "legacyV666UnstartedContractMigratesFormerSeventyFivePointDefaultToFifty" in TEST)
ck("Changelog and audit report are present", bool(read("CHANGELOG_V667.md")) and bool(read("AUDIT_V667_CAREER_SCREEN_AND_BOARD_SUPPORT.md")))

failed = [name for name, ok in checks if not ok]
for name, ok in checks:
    print(("PASS" if ok else "FAIL") + " | " + name)
print(f"RESULT: {len(checks)-len(failed)}/{len(checks)} checks passed")
sys.exit(1 if failed else 0)
