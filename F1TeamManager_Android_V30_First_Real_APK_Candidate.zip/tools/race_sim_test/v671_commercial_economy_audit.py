from pathlib import Path
root = Path(__file__).resolve().parents[2]
pricing = (root/'app/src/main/java/com/f1teammanager/core/manager/SponsorContractPricing.kt').read_text()
sponsors = (root/'app/src/main/java/com/f1teammanager/core/manager/TeamSponsorshipEngine.kt').read_text()
finance = (root/'app/src/main/java/com/f1teammanager/core/manager/FinanceEngine.kt').read_text()
ai = (root/'app/src/main/java/com/f1teammanager/core/manager/AITeamFinancialEngine.kt').read_text()
gradle = (root/'app/build.gradle.kts').read_text()
manifest = (root/'package_manifest.txt').read_text()
checks = {
    'level 0 sponsor bonus +60%': '0 -> 1.60' in pricing,
    'level 1 sponsor bonus +40%': '1 -> 1.40' in pricing,
    'level 2 sponsor bonus +20%': '2 -> 1.20' in pricing,
    'normal progression starts above level 2': '1.20 + (marketingLevel.coerceIn(0, 10) - 2) * 0.025' in pricing,
    'marketing quality affects sponsor category draw': 'marketingQualityCategoryShift(normalizedLevel)' in sponsors and 'FacilityEngine.marketingQuality(marketingState)' in sponsors,
    'new contracts remove dormant points bonus': 'valued(gp),0L,1,strength/2' in sponsors,
    'race bonus uses exact range': 'finishPosition in minPosition..maxPosition' in finance,
    'AI race-bonus valuation uses bounded window': 'raceTargetMin' in sponsors and 'raceTargetMax' in sponsors and 'val raceProbability' in sponsors,
    'facilities reserve accumulates season grants': 'annualAllowance * seasonsToCredit' in ai,
    'facilities reserve is debited on upgrade': '(availableFacilityReserve - cost)' in ai,
    'reserve has independent persistence record': 'listOf("A", teamId' in ai and 'p.firstOrNull() == "A"' in ai,
    'shared 40/40/20 allocation preserved': 'AI_NEXT_SEASON_CAR_PERCENT = 40' in (root/'app/src/main/java/com/f1teammanager/core/manager/SeasonInvestmentPolicy.kt').read_text() and 'AI_FACILITIES_PERCENT = 20' in (root/'app/src/main/java/com/f1teammanager/core/manager/SeasonInvestmentPolicy.kt').read_text(),
    'V671 version metadata': 'versionCode = 671' in gradle and 'versionName = "0.671.0"' in gradle,
    'original ZIP name preserved': 'F1TeamManager_Android_V30_First_Real_APK_Candidate.zip' in manifest,
    'V671 regression test exists': (root/'app/src/test/kotlin/com/f1teammanager/core/manager/CommercialEconomyV671Test.kt').is_file(),
}
for label, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ' | ' + label)
print(f'{sum(checks.values())}/{len(checks)} V671 checks passed')
raise SystemExit(0 if all(checks.values()) else 1)
