package com.f1teammanager.core.manager

import com.f1teammanager.core.season.WorldDatabase

private class MemoryCheckpointStore : AITeamDevelopmentCheckpointStore {
    private val rows = mutableListOf<AITeamDevelopmentHistoricalCheckpoint>()
    override fun loadCandidates(teamId: Int, beforeSeason: Int): List<AITeamDevelopmentHistoricalCheckpoint> =
        rows.filter { it.teamId == teamId && it.openingSeason < beforeSeason }
    override fun save(checkpoint: AITeamDevelopmentHistoricalCheckpoint) {
        rows.removeAll { it.teamId == checkpoint.teamId && it.openingSeason == checkpoint.openingSeason && it.fingerprint == checkpoint.fingerprint }
        rows += checkpoint
    }
}

fun main() {
    val team = WorldDatabase.teams.first()
    val previous = TeamGarageFactory.fromInitial(team)
    val development = CarDevelopmentEngine()
    val committed = 59_000_000L
    val unregulated = NextSeasonCarProjectionEngine.buildUnregulatedGarage(
        previousGarage = previous,
        committedInvestment = committed,
        isPlayerTeam = false,
        development = development
    )
    check(unregulated == development.buildAiNextSeasonGarage(previous, committed))
    val rule = AnnualCarRegulationEngine.generateForCalendarYear(2028, 7312)
    val expected = AnnualCarRegulationEngine.applyToGarage(unregulated, rule, team.id.hashCode())
    val actual = NextSeasonCarProjectionEngine.buildOfficialGarage(
        teamId = team.id, previousGarage = previous, committedInvestment = committed,
        nextSeason = 2028, regulationSeed = 7312, isPlayerTeam = false, development = development
    )
    check(expected == actual) { "Official projection differs from one-time regulation output" }

    val checkpointStore = MemoryCheckpointStore()
    val aiDevelopment = AITeamDevelopmentEngine(7313, 7314, checkpointStore, "V732_SMOKE")
    val canonical = previous.copy(
        car1 = previous.car1.copy(engine = (previous.car1.engine + 7).coerceAtMost(100)),
        car2 = previous.car2.copy(chassis = (previous.car2.chassis + 5).coerceAtMost(100))
    ).normalized()
    val facilities = FacilityEngine.initial(team.initialLevel)
    aiDevelopment.persistCanonicalSeasonOpening(
        team, 2028, canonical, facilities, emptyMap(), mapOf(team.id to 40)
    )
    val opening = aiDevelopment.simulateFinancial(
        team, 0, 2028, 1L, facilities, emptyMap(), mapOf(team.id to 1), false
    )
    check(opening.garage == canonical) { "AI GP30 canonical garage was not used at season opening" }

    check(SeasonInvestmentPolicy.signedGapToStrongestRival(69, 85) == -16)
    check(!SeasonInvestmentPolicy.isInTitleFight(5, -16))
    check(SeasonInvestmentPolicy.isInTitleFight(5, -4))
    check(!SeasonInvestmentPolicy.isInTitleFight(6, 0))
    check(FacilityType.values().size == 7)
    FacilityType.values().forEach { facility ->
        val target = SeasonInvestmentPolicy.facilityTargetLevel(facility)
        check(SeasonInvestmentPolicy.facilityDeficitBonus(facility, target - 1) > 0)
        check(SeasonInvestmentPolicy.facilityDeficitBonus(facility, target) == 0)
    }

    val finance = AITeamFinancialEngine(7315)
    val startingCash = 100_000_000L
    finance.adoptFormerPlayerTeam(team.id, 2028, TeamFinanceState(startingCash), facilities)
    val charged = finance.applyDevelopmentCost(
        team.id, 2028, 90_000_000L, startingCash,
        cumulativeResearchSpent = 6_000_000L,
        cumulativeFabricationSpent = 4_000_000L
    )
    val ledger = finance.technicalInvestment(team.id, 2028)
    check(ledger.researchDesignSpent == 6_000_000L)
    check(ledger.fabricationSpent == 4_000_000L)
    check(ledger.totalSpent == 10_000_000L)
    check(charged.finance.budget == 90_000_000L)

    println("V732 AI/CAR SMOKE PASS: canonical projection, GP30 checkpoint, title-fight gap, 7 facility targets, R&D/fabrication ledger")
}
