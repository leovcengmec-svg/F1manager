from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
models = (ROOT / "app/src/main/java/com/f1teammanager/core/race/RaceModels.kt").read_text()
engine = (ROOT / "app/src/main/java/com/f1teammanager/core/race/CareerWeekendEngine.kt").read_text()
pace = (ROOT / "app/src/main/java/com/f1teammanager/core/race/PitwallPaceModel.kt").read_text()
gradle = (ROOT / "app/build.gradle.kts").read_text()
workflow = (ROOT / ".github/workflows/android-apk.yml").read_text()
manifest = (ROOT / "package_manifest.txt").read_text()
test_weights = (ROOT / "app/src/test/kotlin/com/f1teammanager/core/race/RacePerformanceWeightsV613Test.kt").read_text()
test_rain = (ROOT / "app/src/test/kotlin/com/f1teammanager/core/race/RaceWeatherPerformanceV682Test.kt").read_text()
checks = {
    "dry/cloudy car 65 percent": "DRY_CAR_WEIGHT = 0.65" in models and "Weather.DRY, Weather.CLOUDY -> DRY_CAR_WEIGHT" in models,
    "dry/cloudy driver 35 percent": "DRY_DRIVER_WEIGHT = 0.35" in models,
    "light/medium rain car 55 percent": "LIGHT_MEDIUM_RAIN_CAR_WEIGHT = 0.55" in models,
    "light/medium rain driver 45 percent": "LIGHT_MEDIUM_RAIN_DRIVER_WEIGHT = 0.45" in models,
    "heavy rain car 50 percent": "HEAVY_RAIN_CAR_WEIGHT = 0.50" in models,
    "heavy rain driver 50 percent": "HEAVY_RAIN_DRIVER_WEIGHT = 0.50" in models,
    "weather weights drive qualifying and race pace": pace.count("RacePerformanceWeights.combinedTimeMultiplier(") >= 2,
    "race rain penalty delegates to bounded model": "RaceWeatherPerformance.rainPenaltyMs(p, tyre, rain)" in engine,
    "wet skill clamp is present": "p.wetSkill.coerceIn(0, 100)" in models,
    "consistency clamp aligns with influence range": "p.consistency.coerceIn(40, 100)" in models,
    "rain test covers invalid ranges and monotonicity": "out of range imported wet skill" in test_rain and "stronger wet skill" in test_rain,
    "weight test covers all five weather values": all(x in test_weights for x in ["Weather.DRY", "Weather.CLOUDY", "Weather.LIGHT_RAIN", "Weather.MEDIUM_RAIN", "Weather.HEAVY_RAIN"]),
    "internal version code 684": "versionCode = 684" in gradle,
    "internal version name 0.684.0": 'versionName = "0.684.0"' in gradle,
    "GitHub artifact says V684": "F1-Team-Manager-V30-V684-debug-apk" in workflow,
    "official ZIP name preserved": "F1TeamManager_Android_V30_First_Real_APK_Candidate.zip" in manifest,
}
failed = [name for name, ok in checks.items() if not ok]
for name, ok in checks.items():
    print(("PASS" if ok else "FAIL") + " - " + name)
if failed:
    raise SystemExit(f"{len(failed)} checks failed")
print(f"V682 weather mechanics preserved in V684 package: {len(checks)}/{len(checks)} PASS")
