from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
source = (ROOT / "app/src/main/java/com/f1teammanager/MainActivity.kt").read_text()
team_start = source.index("private fun Team(")
team_end = source.find("\n@Composable", team_start)
if team_end < 0:
    team_end = len(source)
team = source[team_start:team_end]

checks = {
    "Team receives next-season investment explicitly": "nextSeasonInvestment: Long" in team,
    "Team computes the consolidated amount once": "val totalCommitted = technicalInvestment.totalSpent + nextSeasonInvestment" in team,
    "Team screen has no out-of-scope managerState reference": "managerState" not in team,
    "progress indicator uses consolidated commitment": "totalCommitted.toFloat() / annualCap.toFloat()" in team,
    "remaining balance uses the explicit next-car value": "technicalInvestment.totalSpent, nextSeasonInvestment" in team,
    "parent passes the current next-car investment": "managerState.car.nextSeasonInvestment, facilityMessage" in source,
    "corrective version is 684": "versionCode = 684" in (ROOT / "app/build.gradle.kts").read_text(),
}
for label, ok in checks.items():
    print(("PASS" if ok else "FAIL") + " - " + label)
failed = [label for label, ok in checks.items() if not ok]
if failed:
    raise SystemExit(f"{len(failed)} regression checks failed")
print(f"V684 team screen binding regression: {len(checks)}/{len(checks)} PASS")
