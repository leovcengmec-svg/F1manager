#!/usr/bin/env python3
"""Static regression checks for Kotlin string interpolation before ordinal º."""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[2]
ACTIVITY = ROOT / 'app/src/main/java/com/f1teammanager/MainActivity.kt'
BUILD = ROOT / 'app/build.gradle.kts'
CHANGELOG = ROOT / 'CHANGELOG_V647.md'
src = ACTIVITY.read_text(encoding='utf-8')
build = BUILD.read_text(encoding='utf-8')
checks = []
def check(name, condition):
    checks.append((name, bool(condition)))
    print(('PASS' if condition else 'FAIL') + ' | ' + name)

check('versionCode is 647', re.search(r'versionCode\s*=\s*647\b', build))
check('versionName is 0.647.0', re.search(r'versionName\s*=\s*"0\.647\.0"', build))
check('ordinal interpolation is explicitly braced', 'Posição atual: ${objectiveRank}º' in src)
check('no unbraced identifier immediately before º remains', not re.search(r'\$[A-Za-z_][A-Za-z_0-9]*º', src))
check('objectiveRank is derived inside objectiveStatuses calculation', 'val objectiveRank = currentRankByTeam[principal.teamId] ?: principal.lastRank' in src)
check('projectedOverall is declared before interpolated display use', 'val projectedOverall = forecast.projectedOverall' in src and src.index('val projectedOverall = forecast.projectedOverall') < src.index('invested <= 0L -> \"Sem investimento: construção no nível mínimo da tabela; Overall previsto $projectedOverall\"'))
check('version-specific changelog exists', CHANGELOG.exists() and '0.647.0' in CHANGELOG.read_text(encoding='utf-8'))
print(f'RESULT: {sum(ok for _, ok in checks)}/{len(checks)} checks passed')
sys.exit(0 if all(ok for _, ok in checks) else 1)
