#!/usr/bin/env python3
"""Static regression audit for V703 pilot-market and AI development fixes."""
from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[2]
market = (ROOT / "app/src/main/java/com/f1teammanager/core/manager/DriverMarketEngine.kt").read_text(encoding="utf-8")
models = (ROOT / "app/src/main/java/com/f1teammanager/core/manager/DriverMarketModels.kt").read_text(encoding="utf-8")
prefs = (ROOT / "app/src/main/java/com/f1teammanager/CareerPreferences.kt").read_text(encoding="utf-8")
manager = (ROOT / "app/src/main/java/com/f1teammanager/core/manager/ManagerSeasonEngine.kt").read_text(encoding="utf-8")
tests = (ROOT / "app/src/test/kotlin/com/f1teammanager/core/manager/AIDriverDevelopmentAndContractsV703Test.kt").read_text(encoding="utf-8")

def has(snippet, source): return snippet in source
checks = {
    "AI candidate pool exists as a shared policy": has("internal fun aiApproachCandidates(", market),
    "Player-owned drivers are eligible in final contract year": "deal.teamId == playerTeamId -> canReceiveProposals(state, deal.driverId, season)" in market,
    "Player-owned multi-year contracts are not mid-contract poaching targets": "deal.teamId == playerTeamId -> canReceiveProposals(state, deal.driverId, season)" in market and "current.teamId == playerTeamId" in market,
    "Primary AI market window uses shared candidate pool": "val candidates = aiApproachCandidates(" in market,
    "Renewal upgrade analysis uses shared candidate pool": "val possibleUpgrades = aiApproachCandidates(" in market,
    "Incoming proposal is routed to player decision and scoped Home notice": "if (candidateDeal?.teamId == playerTeamId)" in market and "relatedTeamId = playerTeamId)" in market,
    "Potential is evaluated before current Overall fallback": market.index("age <= 29 && potential >= 90") < market.index("age <= 29 && overall >= 82"),
    "High-potential 26–29 group receives 3–5 years": "age <= 29 && potential >= 90 -> if (roll < 28) 5 else if (roll < 78) 4 else 3" in market,
    "AI development queue codec includes reserve points": "reservePoints.toSortedMap()" in models and "DriverDevelopmentState(programmes, reserves)" in models,
    "Career load uses backward-compatible codec": "AiDriverDevelopmentCodec.decode(" in prefs,
    "Career save uses reserve-aware codec": "AiDriverDevelopmentCodec.encode(s.aiDriverDevelopment)" in prefs,
    "Season transition cancels orphaned programmes": "cancelOrphanedAiDevelopmentPrograms(s, newSeason, playerTeamId)" in market,
    "Cancellation notice states that vacancy is freed": "PROGRAMA DE DESENVOLVIMENTO CANCELADO" in market and "A vaga foi liberada imediatamente" in market,
    "Pre-GP path has defensive orphan cleanup": "val orphanedPrograms = queue.programs.filter { it.driverId !in teamIds }" in manager,
    "Regression tests cover all four findings": all(x in tests for x in ["aiDevelopmentCodecPersistsUnusedReservePoints", "playerDriversInFinalContractYearEnterAiApproachPoolButMidContractDriversDoNot", "aiCancelsDevelopmentProgrammeImmediatelyWhenDriverChangesTeam", "highPotentialDriversDoNotReceiveOneYearDealsOnlyBecauseCurrentOverallIsLow"]),
}
for label, passed in checks.items():
    print(("PASS" if passed else "FAIL") + " | " + label)
failed = sum(not x for x in checks.values())
print(f"RESULT: {len(checks)-failed}/{len(checks)} V703 targeted checks passed")
sys.exit(1 if failed else 0)
