#!/usr/bin/env python3
"""V578 final source/integration audit. Static checks do not replace Android UI/device validation."""
from pathlib import Path
import re, sys, xml.etree.ElementTree as ET
ROOT = Path(__file__).resolve().parents[2]
checks = []
def check(name, ok, detail=''):
    checks.append((name, bool(ok), detail))
def read(rel):
    p = ROOT / rel
    return p.read_text(encoding='utf-8') if p.is_file() else ''

gradle = read('app/build.gradle.kts')
manifest = ROOT / 'app/src/main/AndroidManifest.xml'
custom = read('app/src/main/java/com/f1teammanager/core/season/CustomWorldCatalog.kt')
rules = read('app/src/main/java/com/f1teammanager/core/season/CustomCatalogIdentityRules.kt')
world = read('app/src/main/java/com/f1teammanager/core/season/WorldDatabase.kt')
market = read('app/src/main/java/com/f1teammanager/core/manager/DriverMarketCatalogMigrationV560.kt')
engine = read('app/src/main/java/com/f1teammanager/core/manager/DriverMarketEngine.kt')
dynamic_grid = read('app/src/main/java/com/f1teammanager/core/manager/DynamicGridEngine.kt')
car_dev = read('app/src/main/java/com/f1teammanager/core/manager/CarDevelopmentEngine.kt')
manager_season = read('app/src/main/java/com/f1teammanager/core/manager/ManagerSeasonEngine.kt')
runtime_audit = read('tools/race_sim_test/TwoSeasonChainRuntimeAudit.kt')
season_test = read('app/src/test/kotlin/com/f1teammanager/core/manager/CarDevelopmentNextSeasonV578Test.kt')
market_test = read('app/src/test/kotlin/com/f1teammanager/core/manager/DriverMarketCatalogIntegrationV576Test.kt')
identity_test = read('app/src/test/java/com/f1teammanager/core/season/CustomCatalogIdentityRulesV578Test.kt')
try:
    ET.parse(manifest); check('Android manifest XML parses', True)
except Exception as e:
    check('Android manifest XML parses', False, str(e))
vc = re.search(r'versionCode\s*=\s*(\d+)', gradle)
vn = re.search(r'versionName\s*=\s*"([^"]+)"', gradle)
check('Version metadata is V578 and internally consistent', bool(vc and vn and vc.group(1) == '578' and vn.group(1) == '0.578.0'))
check('Custom team ID collisions with official range are rejected', 'teamIdCollisions(parsedTeams.map { it.id }, officialTeamIds)' in custom and 'teamIdCollisions' in rules)
check('Custom pilot ID collisions with official range are rejected', 'pilotIdCollisions(parsedPilots.map { it.id }, officialDriverIds)' in custom and 'pilotIdCollisions' in rules)
check('Roster validation detects reused/cross-bound pilots', 'rosterIssues(' in custom and 'Piloto $driverId vinculado às equipes' in rules and 'aponta para a equipe' in rules)
check('WorldDatabase resolves legacy teamId=0 via roster', 'customRosterTeamByDriverId' in world and 'rosterTeamId ?: d.teamId' in world)
check('Market migration prioritizes roster owner', 'rosterOwnerByDriverId[id] == team.id' in market and 'rosterOwnerByDriverId[id] == null || rosterOwnerByDriverId[id] == team.id' in market)
check('Market migration preserves contracts/transfers and is idempotent', 'source.scheduled' in market and 'source.contracts.distinctBy' in market and 'V578: catálogo reconciliado' in market and 'reconciliationIsIdempotentWithExpandedCatalog' in market_test)
check('Dynamic grid derives expected size from registered teams', 'WorldDatabase.teams.size * 2' in dynamic_grid)
check('Season construction uses correct component-based base calls', 'aerodynamics = maxOf(base(CarComponent.FRONT_WING), base(CarComponent.REAR_WING))' in car_dev and 'aerodynamics = base(old.aerodynamics, CarComponent.FRONT_WING)' in car_dev)
check('Season finalization keeps component baseline only on physical cars', 'val regulatedLegacy = AnnualCarRegulationEngine.applyToCar(next.car, seasonRule, teamSeed)' in manager_season and 'synchronizedNext.copy(car = synchronizedNext.car.copy(installedPieceVersions = baselineVersions))' not in manager_season and 'car1 = regulatedGarage.car1.copy(installedPieceVersions = baselineVersions)' in manager_season and 'car2 = regulatedGarage.car2.copy(installedPieceVersions = baselineVersions)' in manager_season)
check('Next-season car regression test exists', 'nextSeasonConstructionCompilesAndPreservesBothPhysicalCars' in season_test)
check('Identity tests cover collisions and legacy/cross-team roster', all(x in identity_test for x in ['customIdsCannotAliasTheOfficialTeamOrDriverRanges','teamRosterIsAuthoritativeForLegacyPilotsWithoutPersistedTeamId','aPilotCannotBeAssignedToTwoCustomTeamsOrToTheWrongTeam']))
check('60-GP runtime audit includes a custom team and two legacy-bound pilots', 'repeat(60)' in runtime_audit and 'CustomWorldCatalog.Team(41' in runtime_audit and 'activeDeals.groupBy { it.teamId }.values.all { it.size == 2 }' in runtime_audit)
check('Headless 60-GP audit is reproducible from the package', (ROOT/'tools/race_sim_test/run_two_season_headless_audit.sh').is_file() and (ROOT/'tools/race_sim_test/CustomWorldCatalogHeadlessStub.kt').is_file() and (ROOT/'tools/race_sim_test/headless_core_sources_v578.txt').is_file())
check('V578 audit and changelog are present', (ROOT/'AUDIT_V578.md').is_file() and (ROOT/'CHANGELOG_V578.md').is_file())
assets = [p for p in (ROOT/'app/src/main/assets').rglob('*') if p.is_file()]
check('External assets directory preserved', len(assets) >= 195, f'count={len(assets)}')
asset_families = {'drivers': 100, 'teams': 40, 'circuits': 50}
for family, minimum in asset_families.items():
    files = [p for p in assets if family in p.parts or family in p.as_posix().lower()]
    check(f'Asset family {family} preserved', len(files) >= minimum, f'count={len(files)}')
history = len(list(ROOT.glob('AUDIT_V*.md'))) + len(list(ROOT.glob('CHANGELOG_V*.md')))
check('Historical audit/changelog files retained', history >= 531, f'docs={history}')
for name, ok, detail in checks:
    print(('PASS' if ok else 'FAIL') + ' | ' + name + (f' | {detail}' if detail else ''))
failed = sum(not ok for _, ok, _ in checks)
print(f'RESULT: {len(checks)-failed}/{len(checks)} V578 final integration source checks passed')
print('LIMIT: Source-level checks; Android UI, SharedPreferences on device, official JUnit suite and audio playback are not covered.')
sys.exit(1 if failed else 0)
