from pathlib import Path
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[2]
checks = []
def check(label, condition):
    checks.append((label, bool(condition)))
    print(("PASS" if condition else "FAIL") + " | " + label)

build = (ROOT / "app/build.gradle.kts").read_text()
manifest = ROOT / "app/src/main/AndroidManifest.xml"
world = (ROOT / "app/src/main/java/com/f1teammanager/core/season/WorldDatabase.kt").read_text()
market = (ROOT / "app/src/main/java/com/f1teammanager/core/manager/DriverMarketEngine.kt").read_text()
migration = (ROOT / "app/src/main/java/com/f1teammanager/core/manager/DriverMarketCatalogMigrationV560.kt").read_text()
grid = (ROOT / "app/src/main/java/com/f1teammanager/core/manager/DynamicGridEngine.kt").read_text()
rank_scale = ROOT / "app/src/main/java/com/f1teammanager/core/season/TeamRankScale.kt"
technical = (ROOT / "app/src/main/java/com/f1teammanager/core/manager/TechnicalInvestmentEngine.kt").read_text()
research = (ROOT / "app/src/main/java/com/f1teammanager/core/manager/ResearchEngine.kt").read_text()
factory = (ROOT / "app/src/main/java/com/f1teammanager/core/manager/FactoryEngine.kt").read_text()
evolution = (ROOT / "app/src/main/java/com/f1teammanager/core/season/DriverEvolutionEngine.kt").read_text()

check("version metadata is V580", "versionCode = 580" in build and 'versionName = "0.580.0"' in build)
try:
    ET.parse(manifest); manifest_ok = True
except Exception:
    manifest_ok = False
check("Android manifest XML parses", manifest_ok)
check("WorldDatabase projects custom teams and pilots dynamically", "CustomWorldCatalog.customTeams()" in world and "CustomWorldCatalog.customPilots()" in world)
check("market resolves IDs from live catalog", "private val allIds: Set<Int> get() = WorldDatabase.allDrivers.map { it.id }.toSet()" in market)
check("migration prioritizes team-bound drivers", "knownDrivers[id]?.teamId == team.id || rosterOwnerByDriverId[id] == team.id" in migration)
check("migration preserves contracts and scheduled transfers", "contracts = contracts" in migration and "scheduled =" not in migration.split("val migrated =",1)[1].split(".normalized()",1)[0])
check("dynamic grid derives seats from live team count", "WorldDatabase.teams.size * 2" in grid and "WorldDatabase.allDrivers" in grid)
check("shared economic rank scaling exists", rank_scale.exists() and "BASELINE_TEAM_COUNT = 40" in rank_scale.read_text())
check("technical investment scales ranks to current field", "TeamRankScale.toBaselineRank" in technical and "teamCount: Int = WorldDatabase.teams.size" in technical)
check("research discounts scale to current field", "TeamRankScale.toBaselineRank" in research and "teamCount: Int = WorldDatabase.teams.size" in research)
check("factory discounts scale to current field", "TeamRankScale.toBaselineRank" in factory and "teamCount: Int = WorldDatabase.teams.size" in factory)
check("driver evolution supports actual grid size", "fun evaluate(driver:DriverDefinition, target:Target, input:PerformanceInput, gridSize: Int = 80)" in evolution and "normalizedGridSize" in evolution)
check("runtime chain harness includes expanded market/grid/economics", (ROOT / "tools/race_sim_test/CatalogLiveMarketAuditV580.kt").exists())
check("two-season runner uses V580 source list", "headless_core_sources_v580.txt" in (ROOT / "tools/race_sim_test/run_two_season_headless_audit_v580.sh").read_text())
check("unit tests cover legacy and expanded rank behavior", (ROOT / "app/src/test/kotlin/com/f1teammanager/core/manager/TeamRankScaleIntegrationV580Test.kt").exists())
check("V580 changelog and audit exist", (ROOT / "CHANGELOG_V580.md").exists() and (ROOT / "AUDIT_V580.md").exists())
assets = ROOT / "app/src/main/assets"
asset_files = [p for p in assets.rglob("*") if p.is_file()] if assets.exists() else []
check(f"assets are present ({len(asset_files)} files)", len(asset_files) >= 190)
check("historical version records retained", len(list(ROOT.glob("AUDIT_V*.md"))) + len(list(ROOT.glob("CHANGELOG_V*.md"))) >= 500)
failed = [label for label, ok in checks if not ok]
print(f"RESULT: {len(checks)-len(failed)}/{len(checks)} V580 integration source checks passed")
if failed: raise SystemExit(1)
