#!/usr/bin/env python3
"""Static integration audit for V676 facility progression paths.

This checks source wiring and metadata only; it is not a Kotlin/Android build.
"""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[2]
checks = []

def check(name: str, condition: bool):
    checks.append((name, bool(condition)))


def read(relative: str) -> str:
    return (ROOT / relative).read_text(encoding="utf-8")

facility = read("app/src/main/java/com/f1teammanager/core/manager/FacilityModels.kt")
research = read("app/src/main/java/com/f1teammanager/core/manager/ResearchEngine.kt")
ai_dev = read("app/src/main/java/com/f1teammanager/core/manager/AITeamDevelopmentEngine.kt")
market = read("app/src/main/java/com/f1teammanager/core/manager/DriverMarketEngine.kt")
career = read("app/src/main/java/com/f1teammanager/CareerPreferences.kt")
manager_season = read("app/src/main/java/com/f1teammanager/core/manager/ManagerSeasonEngine.kt")
grid = read("app/src/main/java/com/f1teammanager/core/manager/DynamicGridEngine.kt")
race_models = read("app/src/main/java/com/f1teammanager/core/race/RaceModels.kt")
pace = read("app/src/main/java/com/f1teammanager/core/race/PitwallPaceModel.kt")
sponsor = read("app/src/main/java/com/f1teammanager/core/manager/SponsorContractPricing.kt")
ui = read("app/src/main/java/com/f1teammanager/MainActivity.kt")

build = read("app/build.gradle.kts")
manifest = read("package_manifest.txt")
workflow = read(".github/workflows/android-apk.yml")

check("versionCode 676", "versionCode = 676" in build)
check("versionName 0.676.0", 'versionName = "0.676.0"' in build)
check("original ZIP filename preserved", "F1TeamManager_Android_V30_First_Real_APK_Candidate.zip" in manifest)
check("public app name preserved", "F1 Team Manager V30" in manifest)
check("V676 GitHub artifact label", "F1-Team-Manager-V30-V676-debug-apk" in workflow)
check("exactly seven facility types", len(re.findall(r"[A-Z_]+", facility.split("enum class FacilityType")[1].split("}")[0])) == 7)
check("driver growth baseline 100%, +3% per facility level", "1.00 + state.level(FacilityType.DRIVER_DEVELOPMENT) * 0.03" in facility)
check("normal career GP evolution receives facility map", "teamFacilitiesById: Map<Int, TeamFacilitiesState>" in career and "facilityGrowthEfficiency = facilityFactor" in career)
check("Team Principal applies the same driver facility factor", "FacilityEngine.driverDevelopmentEfficiency(teamFacilities)" in manager_season and "facilityGrowthEfficiency = facilityFactor" in manager_season)
check("continuous track bonus injected into grid participants", "facilityPaceBonus=FacilityEngine.racePaceBonus(activeFacilities)" in grid)
check("continuous bonus applied to lap and qualifying pace", "facilityPaceBonus.coerceIn(0.0, 0.015)" in pace and pace.count("carTimeModifier(p)") >= 2)
check("shared player/AI R&D project capacity", "fun activeProjectCapacity(level: Int)" in research and "activeProjectCapacity(facilities.level(FacilityType.RESEARCH))" in ai_dev)
check("AI has concurrent project and completed-design queues", "val researchProjects = mutableListOf<AiResearchProject>()" in ai_dev and "val readyDesigns = mutableListOf<AiResearchProject>()" in ai_dev)
check("AI factory uses shared manufacturing duration/cost", "FactoryEngine().manufacturingWeeks(actualQuantity, facilities)" in ai_dev and "FactoryEngine().manufacturingCost(plannedDesign, facilities, ranking)" in ai_dev)
check("AI factory respects official parallel-order capacity", "FactorySpecification.level(facilities.level(FacilityType.FACTORY)).parallelOrders" in ai_dev)
check("AI scouting precision is used in renewal and candidate selection", market.count("aiScoutingEstimateForMarket(") >= 3)
check("AI facilities passed in both career modes", "nextSeasonCarStrength, aiFacilities" in manager_season and "nextSeasonCarStrength, aiFacilitiesForScouting" in ui)
check("commercial multiplier is monotonic", "1.60 + marketingLevel.coerceIn(0, 10) * 0.025" in sponsor)
check("facility UI shows current and next effect", '"ATUAL: ${FacilityEngine.levelEffect(type, level, facilities)}"' in ui and '"PRÓXIMO: ${FacilityEngine.nextLevelEffect(type, level, facilities)}"' in ui)
check("driver development included in facility overview", "FacilityType.DRIVER_DEVELOPMENT to \"Desenv. Pilotos\"" in ui)
check("V676 facility progression tests present", (ROOT / "app/src/test/kotlin/com/f1teammanager/core/manager/FacilityProgressionV676Test.kt").exists())
check("V676 race pace tests present", (ROOT / "app/src/test/kotlin/com/f1teammanager/core/race/FacilityPaceV676Test.kt").exists())
check("V676 audit documentation present", (ROOT / "AUDIT_V676_FACILITIES.md").exists())
check("V676 changelog present", (ROOT / "CHANGELOG_V676.md").exists())

for name, ok in checks:
    print(f"{'PASS' if ok else 'FAIL'} | {name}")

passed = sum(ok for _, ok in checks)
print(f"\nRESULT: {passed}/{len(checks)} static checks passed")
if passed != len(checks):
    sys.exit(1)
