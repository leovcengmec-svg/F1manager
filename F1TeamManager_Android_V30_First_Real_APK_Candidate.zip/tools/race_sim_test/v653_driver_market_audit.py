#!/usr/bin/env python3
"""Static release audit for V653 driver-market and pre-season roster fixes."""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[2]
checks = []

def check(name, ok, detail=""):
    checks.append((name, bool(ok), detail))

def read(rel):
    path = ROOT / rel
    return path.read_text(encoding="utf-8") if path.is_file() else ""

engine = read("app/src/main/java/com/f1teammanager/core/manager/DriverMarketEngine.kt")
models = read("app/src/main/java/com/f1teammanager/core/manager/DriverMarketModels.kt")
prefs = read("app/src/main/java/com/f1teammanager/CareerPreferences.kt")
gradle = read("app/build.gradle.kts")
changelog = read("CHANGELOG_V653.md")
audit = read("AUDIT_V653_DRIVER_MARKET.md")
renewal_test = read("app/src/test/kotlin/com/f1teammanager/core/manager/DriverMarketRenewalRealismV618Test.kt")
career_test = read("app/src/test/kotlin/com/f1teammanager/core/manager/DriverMarketCareerRealismV653Test.kt")

code = re.search(r"versionCode\s*=\s*(\d+)", gradle)
name = re.search(r'versionName\s*=\s*"([^"]+)"', gradle)
check("Version metadata is V653 / 0.653.0", bool(code and name and code.group(1) == "653" and name.group(1) == "0.653.0"))
check("V653 changelog and audit are present", bool(changelog and audit))
check("External V30 identity remains unchanged", "V30" in changelog and "applicationId = \"com.f1teammanager\"" in gradle)

# Dynamic sporting profile and reputation.
check("Current championship rating is derived from live team points", "private fun currentChampionshipRating(teamId: Int, points: Map<Int, Int>)" in engine and "points[it.id] ?: 0" in engine)
check("Season performance weight grows progressively and is bounded", "totalPoints / 2_500.0" in engine and "coerceIn(0.20, 0.80)" in engine)
check("Live sporting results are blended with initial strength", "blendedTeamRating(base, current, weight)" in engine)
check("Prestige and history move with current championship", "teamPrestige(toTeamId, teamChampionshipPoints)" in engine and "teamHistory(toTeamId, teamChampionshipPoints)" in engine)
check("Old fixed 55/45 weighting is absent", "base * 0.55 + current * 0.45" not in engine and "0.55 + current" not in engine)
check("Elite-driver interest consumes current destination strength", "val destinationStrength = teamSportingStrength(toTeamId, teamChampionshipPoints)" in engine and "titleContenderDropPenalty" in engine)

# Renewal checkpoint policy and persistence.
check("Renewal evaluation keys include an eight-week window", '"$season:$teamId:$driverId:$window"' in engine and "(week.coerceAtLeast(1) - 1) / 8" in engine)
check("Renewal is reconsidered in spaced checkpoints", "renewalEvaluationWindow(currentWeek)" in engine and "if (evaluationKey in s.renewalEvaluations) return@dealLoop" in engine)
check("Late-season renewal incentives are progressively higher", "currentWeek >= 48 -> 32" in engine and "currentWeek >= 40 -> 18" in engine and "currentWeek >= 32 -> 8" in engine)
check("Already-scheduled future contracts skip renewal evaluation", "if (s.scheduled.any { it.driverId == deal.driverId && it.startSeason == season + 1 }) return@dealLoop" in engine)
check("Renewal ledger capacity is expanded and normalized", "takeLast(600).toSet()" in models and "takeLast(600).toSet()" in engine)
check("Career preferences continue loading and saving renewal ledger", 'getString("marketRenewalEvaluations"' in prefs and 'putString("marketRenewalEvaluations"' in prefs)

# Projection and pre-season closure.
check("Season projection accounts for outgoing and replaced drivers", "fun projectedRosterForSeason" in engine and "it.driverId !in leavingIds && it.driverId !in replacedIds" in engine)
check("AI roster closure starts from week 52", "if (currentWeek >= 52)" in engine and "closeAiRosterGaps(" in engine)
check("Rosters are checked against the next season", "val targetSeason = season + 1" in engine and "projectedRosterForSeason(s, team.id, targetSeason)" in engine)
check("Player team is excluded from automatic closure", "WorldDatabase.teams.filter { it.id != playerTeamId }" in engine)
check("Closure uses real offer and contract-signing workflow", "makeOffer(" in engine and "signFuture(" in engine and "expireOffers(" in engine)
check("Closure does not fabricate driver assignments", "nenhuma contratação foi atribuída sem aceitação do piloto" in engine)
check("Unresolved vacancies are explicitly reported at week 56", "currentWeek >= 56" in engine and '"VAGA DE PILOTO EM ABERTO"' in engine)
check("Legacy late proposals receive final resolution", "legacyLateOffers" in engine and "s = expireOffers(s, currentWeek, season, playerTeamId)" in engine)
check("Week-56 counteroffers are either accepted or explicitly declined", "CONTRAPROPOSTA ACEITA NO FECHAMENTO" in engine and "CONTRAPROPOSTA RECUSADA NO FECHAMENTO" in engine)

# Duplicate-seat and response deadline protections.
check("Response deadlines contract in the final negotiation window", "currentWeek >= 56 -> 0" in engine and "currentWeek >= 52 -> 1" in engine)
check("Replacement seats reserved by future deals are protected", "state.scheduled.none { it.toTeamId == toTeamId && it.replaceDriverId == replaceDriverId }" in engine)
check("Replacement seats reserved by pending negotiations are protected", "state.pending.none {" in engine and "it.seasonTarget == season + 1 && it.replaceDriverId == replaceDriverId" in engine and "A vaga selecionada já está em negociação" in engine)
check("AI selection skips already-reserved replacement seats", "reservedReplacementIds" in engine and "id !in reservedReplacementIds" in engine)
check("Only one unresolved destination negotiation is processed per closeout pass", "val unresolved = s.pending.any" in engine and "if (unresolved) break" in engine)

# Regression coverage.
check("V653 regression suite covers dynamic championship attraction", "championship" in career_test.lower() and "elite" in career_test.lower())
check("V653 regression suite covers 40-team week-56 roster closure", "final AI market week" in career_test and "WorldDatabase.teams.forEach" in career_test and "two projected drivers" in career_test)
check("V653 regression suite protects player-controlled roster", "player" in career_test.lower() and "roster" in career_test.lower())
check("V618 renewal regression now covers spaced checkpoints", "checkpoint" in renewal_test.lower() and "renewalEvaluations" in renewal_test)

failed = sum(not ok for _, ok, _ in checks)
for label, ok, detail in checks:
    print(("PASS" if ok else "FAIL") + " | " + label + (f" | {detail}" if detail else ""))
print(f"RESULT: {len(checks)-failed}/{len(checks)} V653 driver-market checks passed")
if failed:
    sys.exit(1)
