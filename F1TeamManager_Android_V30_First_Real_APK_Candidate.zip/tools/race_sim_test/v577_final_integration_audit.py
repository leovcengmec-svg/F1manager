#!/usr/bin/env python3
"""V577 final integration source audit; static contracts only, not an Android build."""
from pathlib import Path
import re, sys, xml.etree.ElementTree as ET
ROOT = Path(__file__).resolve().parents[2]
checks = []
def check(name, ok, detail=''):
    checks.append((name, bool(ok), detail))
def read(rel):
    p = ROOT / rel
    return p.read_text(encoding='utf-8') if p.is_file() else ''
gradle = read('app/build.gradle.kts')
service = read('app/src/main/java/com/f1teammanager/core/race/InstantSimulationService.kt')
engine = read('app/src/main/java/com/f1teammanager/core/race/CareerWeekendEngine.kt')
market = read('app/src/main/java/com/f1teammanager/core/manager/DriverMarketCatalogMigrationV560.kt')
prize = read('app/src/main/java/com/f1teammanager/core/manager/SeasonPrizeEngine.kt')
season_test = read('app/src/test/kotlin/com/f1teammanager/core/season/TwoSeasonChainAuditTest.kt')
expanded_test = read('app/src/test/kotlin/com/f1teammanager/core/race/InstantSimulationServiceExpandedGridV577Test.kt')
try:
    ET.parse(ROOT / 'app/src/main/AndroidManifest.xml'); check('Android manifest XML parses', True)
except Exception as e:
    check('Android manifest XML parses', False, str(e))
vc = re.search(r'versionCode\s*=\s*(\d+)', gradle)
vn = re.search(r'versionName\s*=\s*"([^"]+)"', gradle)
check('Version metadata is monotonic from V577 and internally consistent', bool(vc and vn and int(vc.group(1)) >= 577 and vn.group(1) == f"0.{vc.group(1)}.0"))
check('Engine exposes an immutable copy of configured roster', 'private var configuredWeekendParticipants = emptyList<RaceParticipant>()' in engine and 'fun configuredParticipants(): List<RaceParticipant> = configuredWeekendParticipants.toList()' in engine)
check('Completion uses engine roster instead of an out-of-scope variable', 'val participants = engine.configuredParticipants()' in service and 'val gridSize = participants.size' in service)
check('Completion verifies exact configured driver identities', 'configuredDriverIds' in service and 'gridIds.toSet() == configuredDriverIds' in service)
check('Qualifying cutoffs scale proportionally for expanded grids', 'ceil(gridSize * 50.0 / 80.0)' in service and 'ceil(gridSize * 20.0 / 80.0)' in service)
check('Expanded grid end-to-end tests cover 6-driver and 4-driver grids', 'teamCount = 3' in expanded_test and 'listOf(6, 4, 2)' in expanded_test and 'listOf(4, 3, 1)' in expanded_test)
check('Career season audit derives grid and qualifying sizes dynamically', 'val expectedGridSize = WorldDatabase.teams.size * 2' in season_test and 'expectedQ2Size' in season_test and 'expectedQ3Size' in season_test)
check('Custom market reconciliation preserves team-bound pilot priority', 'knownDrivers[id]?.teamId == team.id' in market and 'registeredTeamId == 0 || registeredTeamId == team.id' in market)
check('Existing prize ranks extend beyond 40 with a stable floor', 'require(position >= 1)' in prize and 'coerceAtLeast(30.0)' in prize)
assets = [p for p in (ROOT / 'app/src/main/assets').rglob('*') if p.is_file()]
check('All prior assets are still present', len(assets) >= 195, f'count={len(assets)}')
history = len(list(ROOT.glob('AUDIT_V*.md'))) + len(list(ROOT.glob('CHANGELOG_V*.md')))
check('Version audit/changelog history is retained', history >= 529, f'docs={history}')
check('V577 changelog and audit are included', (ROOT/'CHANGELOG_V577.md').is_file() and (ROOT/'AUDIT_V577.md').is_file())
for name, ok, detail in checks:
    print(('PASS' if ok else 'FAIL') + ' | ' + name + ((' | ' + detail) if detail else ''))
failed = sum(not ok for _, ok, _ in checks)
print(f'RESULT: {len(checks)-failed}/{len(checks)} V577-origin integration checks passed')
print('LIMIT: Static/source checks only; does not compile Android or execute JUnit/device tests.')
sys.exit(1 if failed else 0)
