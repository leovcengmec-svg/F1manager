from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SOURCE = ROOT / "app/src/main/java/com/f1teammanager/core/manager/ManagerSeasonEngine.kt"
text = SOURCE.read_text(encoding="utf-8")
checks = {
    "runRound passes its local AI facilities snapshot": "applyDriverEvolution(next, race, performanceSeason, aiFacilities)" in text,
    "applyDriverEvolution declares the AI facilities parameter": "aiFacilities: Map<Int, TeamFacilitiesState> = emptyMap()" in text,
    "driver evolution reads the passed map": "driverTeamId != null -> aiFacilities[driverTeamId]" in text,
    "snapshot is populated before the GP is simulated": "aiFacilities[aiTeam.id] = aiState.facilities" in text,
    "version code is 677": "versionCode = 677" in (ROOT / "app/build.gradle.kts").read_text(encoding="utf-8"),
}
for label, ok in checks.items():
    print(f"{'PASS' if ok else 'FAIL'}: {label}")
if not all(checks.values()):
    raise SystemExit(1)
print(f"{sum(checks.values())}/{len(checks)} checks passed")
