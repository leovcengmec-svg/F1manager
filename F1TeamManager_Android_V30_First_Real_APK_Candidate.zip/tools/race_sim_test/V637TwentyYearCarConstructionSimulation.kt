import com.f1teammanager.core.manager.*
import kotlin.math.roundToInt

private data class TeamRecord(val id: Int, val label: String, val initialOverall: Int, var garage: TeamGarage)
private data class YearResult(
    val transition: Int,
    val fromYear: Int,
    val toYear: Int,
    val averageBefore: Double,
    val averageInvestmentM: Double,
    val averageBuiltBeforeRegulation: Double,
    val minBuiltBeforeRegulation: Int,
    val maxBuiltBeforeRegulation: Int,
    val builtInTargetBandCount: Int,
    val averageAfterRegulation: Double,
    val minAfter: Int,
    val maxAfter: Int,
    val afterInTargetBandCount: Int,
    val decennial: Boolean
)

private enum class Policy(val label: String, val cap: Long?) {
    TARGET("Meta IA sem limite financeiro", null),
    CAP25("Teto hipotético €25M/ano", 25_000_000L),
    CAP35("Teto hipotético €35M/ano", 35_000_000L),
    ZERO("Investimento zero", 0L)
}

private val engine = CarDevelopmentEngine()
private var regulationSeed = 20261005
private const val FIRST_YEAR = 2026
private const val TRANSITIONS = 20

private const val INITIAL_VALUES_SEED = 20261008
private val teamNames = listOf(
    "Ferrari", "McLaren", "Williams", "Mercedes", "Red Bull Racing", "Benetton", "Renault", "Team Lotus",
    "Alpine F1 Team", "Brabham", "Tyrrell", "Jordan Grand Prix", "Minardi", "Toro Rosso", "Sauber", "BMW Sauber",
    "Alfa Romeo", "Aston Martin", "Force India", "Racing Point", "Brawn GP", "Toyota Racing", "Honda Racing",
    "Jaguar Racing", "Stewart Grand Prix", "Cadillac Racing", "Prost Grand Prix", "BAR", "Haas F1 Team", "Maserati",
    "Bagos F1 Racing", "Ford", "Bugatti", "Caterham", "Audi F1 Team", "Super Aguri", "Andretti", "Campos Racing",
    "Invicta Racing", "Rodin Motorsport"
)
private val teamLevels = listOf(
    2,2,2,2,2,2,2,2,1,1,0,1,0,1,1,1,1,2,1,1,2,1,1,1,1,0,1,1,0,0,0,0,0,0,2,0,0,0,0,0
)

private fun openingValues(teamId: Int, level: Int): List<Int> {
    val (minValue, maxValue) = when (level) {
        2 -> 56 to 60
        1 -> 48 to 55
        else -> 40 to 47
    }
    val span = maxValue - minValue + 1
    return (1..6).map { slot ->
        val mixedSeed = INITIAL_VALUES_SEED + teamId * 997 + slot * 313 + teamId * slot * 71
        minValue + kotlin.random.Random(mixedSeed).nextInt(span)
    }
}

private fun openingReliability(teamId: Int, level: Int, overall: Int): Int {
    val (minValue, maxValue) = when (level) {
        2 -> 65 to 74
        1 -> 55 to 64
        else -> 45 to 54
    }
    val mixedSeed = teamId * 53 + overall * 11 + teamId * teamId * 3
    return minValue + Math.floorMod(mixedSeed, maxValue - minValue + 1)
}

private fun makeInitialCar(id: GarageCarId, teamId: Int, values: List<Int>, reliability: Int): PhysicalCar {
    val components = CarComponent.values().toList()
    val installed = components.associateWith { component -> "INITIAL-AI-V0-${teamId}-${id.name}-${component.name}" }
    return PhysicalCar(
        id = id,
        engine = values[0], chassis = values[1], frontWing = values[2], rearWing = values[3],
        brakes = values[4], electricPowerUnit = values[5], reliability = reliability,
        componentReliabilities = components.associateWith { reliability },
        installedPieces = installed,
        installedPieceVersions = components.associateWith { 0 }
    )
}

private fun initialGarage(teamId: Int, level: Int): TeamGarage {
    val values = openingValues(teamId, level)
    val overall = (values.sum() + 3) / 6
    val reliability = openingReliability(teamId, level, overall)
    return TeamGarage(
        makeInitialCar(GarageCarId.CAR_1, teamId, values, reliability),
        makeInitialCar(GarageCarId.CAR_2, teamId, values, reliability)
    )
}

private fun newTeams() = (1..40).map { id ->
    val level = teamLevels[id - 1]
    val garage = initialGarage(id, level)
    TeamRecord(id, teamNames[id - 1], garage.teamAverageOverall, garage)
}

private fun average(values: List<Int>): Double = if (values.isEmpty()) 0.0 else values.average()
private fun currentOveralls(teams: List<TeamRecord>) = teams.map { it.garage.teamAverageOverall }
private fun median(values: List<Int>): Double {
    val sorted = values.sorted()
    return if (sorted.size % 2 == 0) (sorted[sorted.size / 2 - 1] + sorted[sorted.size / 2]) / 2.0 else sorted[sorted.size / 2].toDouble()
}

private fun maxGain(overall: Int): Int = NextSeasonCarGrowthPolicy.maximumGain(overall)

private fun simulate(policy: Policy): Pair<List<YearResult>, List<TeamRecord>> {
    val teams = newTeams()
    val results = mutableListOf<YearResult>()
    repeat(TRANSITIONS) { transitionIndex ->
        val fromYear = FIRST_YEAR + transitionIndex
        val toYear = fromYear + 1
        val before = currentOveralls(teams)
        val investments = mutableListOf<Long>()
        val built = mutableListOf<Int>()
        val after = mutableListOf<Int>()
        val rule = AnnualCarRegulationEngine.generateForCalendarYear(toYear, regulationSeed)

        teams.forEach { team ->
            val overall = team.garage.teamAverageOverall
            val intended = engine.investmentReferenceForNextSeasonTarget(overall, maxGain(overall))
            val investment = when (policy) {
                Policy.TARGET -> intended
                Policy.ZERO -> 0L
                else -> minOf(intended, policy.cap ?: intended)
            }.coerceIn(0L, 150_000_000L)
            investments += investment
            val next = engine.buildNextSeasonGarage(team.garage, investment, CarDevelopmentFocus.BALANCED, emptyMap(), false)
            built += next.teamAverageOverall
            // Real regulation engine is applied to the car just constructed, matching the season handoff.
            team.garage = AnnualCarRegulationEngine.applyToGarage(next, rule, team.id)
            after += team.garage.teamAverageOverall
        }
        results += YearResult(
            transition = transitionIndex + 1,
            fromYear = fromYear,
            toYear = toYear,
            averageBefore = average(before),
            averageInvestmentM = investments.average() / 1_000_000.0,
            averageBuiltBeforeRegulation = average(built),
            minBuiltBeforeRegulation = built.minOrNull() ?: 0,
            maxBuiltBeforeRegulation = built.maxOrNull() ?: 0,
            builtInTargetBandCount = built.count { it in 80..100 },
            averageAfterRegulation = average(after),
            minAfter = after.minOrNull() ?: 0,
            maxAfter = after.maxOrNull() ?: 0,
            afterInTargetBandCount = after.count { it in 40..60 },
            decennial = rule.decennialRevolution
        )
    }
    return results to teams
}

fun main(args: Array<String>) {
    regulationSeed = args.getOrNull(0)?.toIntOrNull() ?: regulationSeed
    println("V637 20-YEAR CONSTRUCTION CYCLE SIMULATION")
    println("40 canonical teams; initial values/reliability mirror InitialTeamProfile; actual CarDevelopmentEngine + AnnualCarRegulationEngine; seed=$regulationSeed")
    println("Includes two decennial resets, into years 2036 and 2046. Pre-reset target band is 80–100; post-reset target band is 40–60.")
    println("No financial ledger, driver market, race results, or AI P&D/factory pipeline is simulated in this harness.")
    println("INITIAL_GRID: " + newTeams().map { it.garage.teamAverageOverall }.joinToString(","))
    for (policy in Policy.values()) {
        val (results, teams) = simulate(policy)
        println("\nPOLICY=${policy.label}")
        println("transition,calendar,avg_before,avg_invest_M,avg_before_reg,min_before_reg,max_before_reg,teams_built_80_100,avg_after_reg,min_after,max_after,teams_after_40_60,decennial")
        results.forEach { r ->
            println("${r.transition},${r.fromYear}->${r.toYear},${"%.2f".format(r.averageBefore)},${"%.2f".format(r.averageInvestmentM)},${"%.2f".format(r.averageBuiltBeforeRegulation)},${r.minBuiltBeforeRegulation},${r.maxBuiltBeforeRegulation},${r.builtInTargetBandCount},${"%.2f".format(r.averageAfterRegulation)},${r.minAfter},${r.maxAfter},${r.afterInTargetBandCount},${r.decennial}")
        }
        val final = currentOveralls(teams)
        println("FINAL_STATS=min=${final.minOrNull()},avg=${"%.2f".format(final.average())},median=${"%.2f".format(median(final))},max=${final.maxOrNull()},gt80=${final.count { it > 80 }},below40=${final.count { it < 40 }}")
        println("FINAL_BY_TEAM=" + teams.joinToString(";") { "${it.label}:${it.initialOverall}->${it.garage.teamAverageOverall}" })
    }
    val fixedAmounts = listOf(0L, 8_000_000L, 25_000_000L, 43_000_000L, 50_000_000L, 70_000_000L, 100_000_000L, 150_000_000L)
    println("\nFIXED_INVESTMENT_TABLE")
    println("investment_M,base_Overall,built_Overall")
    fixedAmounts.forEach { amount ->
        println("${amount / 1_000_000},${engine.constructionBaseOverallForInvestment(amount)},${engine.constructionOverallForInvestment(amount)}")
    }
}
