#!/usr/bin/env python3
"""V636 source + table stress audit for next-season car construction.

The deterministic trajectory is a formula-only stress test: it intentionally excludes
cash constraints, R&D, and annual/decennial regulations; it is not an end-to-end game sim.
"""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[2]
ENGINE = (ROOT / 'app/src/main/java/com/f1teammanager/core/manager/CarDevelopmentEngine.kt').read_text(encoding='utf-8')
AI = (ROOT / 'app/src/main/java/com/f1teammanager/core/manager/AITeamFinancialEngine.kt').read_text(encoding='utf-8')
GRADLE = (ROOT / 'app/build.gradle.kts').read_text(encoding='utf-8')
checks = []
def check(name, result):
    checks.append((name, bool(result)))

check('V636 version code/name', 'versionCode = 636' in GRADLE and 'versionName = "0.636.0"' in GRADLE)
check('Single canonical construction target exists', 'fun constructionOverallForInvestment(invested: Long): Int?' in ENGINE)
check('AI uses inverse target helper', 'investmentReferenceForNextSeasonTarget(' in AI and 'fun investmentReferenceForNextSeasonTarget(' in ENGINE)
check('AI weak-team ambition bounded at +3', 'currentOverall < 60 -> 3' in AI)
check('AI mid-team ambition bounded at +2', 'currentOverall < 80 -> 2' in AI)
check('AI strong-team construction growth disabled', 'else -> 0' in AI)
check('Old blind reference target removed', 'val targetCost = development.referenceInvestmentForOverall(currentOverall)' not in AI)
check('Player and AI physical paths use the same builder', 'buildNextSeasonGarage(' in ENGINE and 'development.buildNextSeasonGarage(' in (ROOT / 'app/src/main/java/com/f1teammanager/core/manager/AITeamDevelopmentEngine.kt').read_text(encoding='utf-8'))
check('Forecast uses achievable physical build', 'state.garage != null -> buildNextSeasonGarage(' in ENGINE)

block = ENGINE.split('val referencesByOverall = longArrayOf(', 1)[1].split(')', 1)[0]
refs = [int(x) for x in re.findall(r'(\d+)_000_000L', block)]
def build(base):
    return min(100, int(base * 1.10 + 0.5))
check('Investment table has 61 strictly increasing rows', len(refs) == 61 and all(a < b for a, b in zip(refs, refs[1:])))
check('Investment table spans €8M–€150M', bool(refs) and refs[0] == 8 and refs[-1] == 150)

def base_for_investment(amount):
    if amount < 0:
        return None
    if amount < 8_000_000:
        return amount * 40 // 8_000_000
    return next((overall for overall in range(100, 39, -1) if amount >= refs[overall - 40] * 1_000_000), 40)
ladder_amounts = list(range(0, 150_000_001, 200_000)) + [m * 1_000_000 for m in refs]
ladder_outputs = [build(base_for_investment(amount)) for amount in sorted(set(ladder_amounts))]
check('Universal investment ladder is monotonic from €0 to €150M', all(a <= b for a, b in zip(ladder_outputs, ladder_outputs[1:])))
check('Zero investment is a table-driven minimum, not previous-car reuse', 'if (invested < 0L) return null' in ENGINE and 'invested <= 0L -> overall' not in ENGINE and 'invested <= 0L -> overall' not in (ROOT / 'app/src/main/java/com/f1teammanager/MainActivity.kt').read_text(encoding='utf-8'))
check('Zero investment skips free focus/knowledge specialization', 'applyTechnicalSpecialization && targetOverall > 0' in ENGINE)

# Mirror the deterministic mapping in the Kotlin helper to detect policy regressions.
def ref_for_overall(overall):
    if overall < 40:
        return overall * 0.2
    return refs[overall - 40]
rows = [(ref_for_overall(base), base, build(base)) for base in range(101)]
def chosen_output(current, gain):
    current = max(0, min(100, current))
    target = max(0, min(100, current + max(0, gain)))
    if gain <= 0:
        return min(rows, key=lambda x: (abs(x[2] - current), 1 if x[2] > current else 0, x[0]))[2]
    in_range = [row for row in rows if row[2] > current and row[2] <= target]
    if in_range:
        best = max(row[2] for row in in_range)
        return min((row for row in in_range if row[2] == best), key=lambda x: x[0])[2]
    if current < 100:
        next_output = min((row[2] for row in rows if row[2] > current), default=None)
        if next_output is not None:
            return min((row for row in rows if row[2] == next_output), key=lambda x: x[0])[2]
    return min((row for row in rows if row[2] >= target), key=lambda x: x[0])[2]
def policy_gain(overall):
    return 3 if overall < 60 else 2 if overall < 80 else 0
def trajectory(start, transitions=10):
    values = [start]
    current = start
    for _ in range(transitions):
        current = max(current, chosen_output(current, policy_gain(current)))
        values.append(current)
    return values

trajectories = {overall: trajectory(overall) for overall in (45, 50, 60, 70, 80, 90)}
check('Construction ladder never reduces the nominal Overall in the no-rules stress case', all(all(a <= b for a, b in zip(v, v[1:])) for v in trajectories.values()))
check('Weak/mid/strong policy stops mechanical saturation before 10-year stress horizon', all(v[-1] < 100 for v in trajectories.values()))
failed = [name for name, ok in checks if not ok]
for name, ok in checks:
    print(('PASS' if ok else 'FAIL') + ' | ' + name)
print('FORMULA-ONLY TRAJECTORIES (no budget, P&D or regulations):')
for start, values in trajectories.items():
    print(f'  Overall {start}: ' + ' -> '.join(map(str, values)))
print(f'RESULT: {len(checks)-len(failed)}/{len(checks)} checks passed')
if failed:
    sys.exit(1)
