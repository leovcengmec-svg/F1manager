#!/usr/bin/env python3
"""Static regressions for the V615 persistent transfer-window Home event."""
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]
MAIN = (ROOT / "app/src/main/java/com/f1teammanager/MainActivity.kt").read_text(encoding="utf-8")
POLICY = (ROOT / "app/src/main/java/com/f1teammanager/core/manager/DriverMarketWindowNotificationPolicy.kt").read_text(encoding="utf-8")
ENGINE = (ROOT / "app/src/main/java/com/f1teammanager/core/manager/DriverMarketEngine.kt").read_text(encoding="utf-8")
GRADLE = (ROOT / "app/build.gradle.kts").read_text(encoding="utf-8")
TEST = ROOT / "app/src/test/kotlin/com/f1teammanager/DriverMarketWindowHomeEventV615Test.kt"

def check(name, condition):
    print(("PASS" if condition else "FAIL") + " | " + name)
    return condition

checks = [
    check("V615 version metadata", 'versionCode = 615' in GRADLE and 'versionName = "0.615.0"' in GRADLE),
    check("Market opening rule is still the engine's rule", 'isMarketOpen = marketEngine.marketOpen(week, store.season)' in MAIN and 'fun marketOpen(currentWeek: Int, season: Int = 2026)' in ENGINE),
    check("Opening event is saved on weekly market tick", 'state = aiCommittedMarket' in MAIN and 'currentWeek = week' in MAIN and 'DriverMarketWindowNotificationPolicy.ensureOpeningNotice' in MAIN),
    check("Current/open career save has idempotent recovery", 'repairedMarket = com.f1teammanager.core.manager.DriverMarketWindowNotificationPolicy.ensureOpeningNotice' in MAIN and 'managerState.driverMarket.notifications' in MAIN),
    check("Home card is driven by unread persisted notification", 'if (marketWindowEvent != null)' in MAIN and 'marketWindowEvent.isMarkedRead' not in MAIN and 'marketWindowEvent.readNewsKey()' in MAIN),
    check("Direct transient week-only card is removed", 'val marketOpenNow = SeasonCalendar.forSeason(store.season)' not in MAIN),
    check("Click acknowledges alert and opens market", 'store.markNewsRead(listOf(marketWindowEvent.readNewsKey(), marketWindowEvent.legacyReadNewsKey()))' in MAIN and 'onMarket()' in MAIN),
    check("News Center uses the existing market artwork", 'event.title.equals(com.f1teammanager.core.manager.DriverMarketWindowNotificationPolicy.OPEN_TITLE, ignoreCase = true) -> R.drawable.notice_market_offer' in MAIN and '-> "MERCADO DE PILOTOS"' in MAIN),
    check("Policy de-duplicates by season/title", 'notice.season == season && notice.title.trim().equals(OPEN_TITLE, ignoreCase = true)' in POLICY),
    check("Unit test suite is present", TEST.is_file()),
]
print(f"RESULT: {sum(checks)}/{len(checks)} V615 static checks passed")
sys.exit(0 if all(checks) else 1)
