#!/usr/bin/env python3
"""Static regression audit for facility labels in the team overview (V640)."""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[2]
MAIN = ROOT / "app/src/main/java/com/f1teammanager/MainActivity.kt"
MODELS = ROOT / "app/src/main/java/com/f1teammanager/core/manager/FacilityModels.kt"
GRADLE = ROOT / "app/build.gradle.kts"

checks = []
def check(name, condition):
    checks.append((name, bool(condition)))
    print(f"{'PASS' if condition else 'FAIL'} | {name}")

main = MAIN.read_text(encoding="utf-8")
models = MODELS.read_text(encoding="utf-8")
gradle = GRADLE.read_text(encoding="utf-8")
section = main.split("private fun TeamOverviewFacilities", 1)[1].split("private fun TeamOverviewCarShowcase", 1)[0]

check("V640 versionCode", bool(re.search(r"versionCode\s*=\s*640\b", gradle)))
check("V640 versionName", 'versionName = "0.640.0"' in gradle)
check("Commercial facility appears once as Centro Comercial", 'FacilityType.MARKETING to "Centro Comercial"' in section)
check("Scouting facility uses its real label", 'FacilityType.SCOUTING to "Scouting"' in section)
check("Old incorrect split label is removed", 'FacilityType.MARKETING to "Marketing"' not in section and 'FacilityType.SCOUTING to "Centro Comercial"' not in section)
check("Commercial facility remains a single enum type", "MARKETING" in models and 'FacilityType.MARKETING -> "Centro Comercial / Marketing"' in models)
check("Scouting retains market-information effect", 'FacilityType.SCOUTING -> "Precisão das informações obtidas no mercado de pilotos."' in models)
check("Scouting image mapping remains intact", 'FacilityType.SCOUTING -> R.drawable.facility_scouting' in main)
check("Marketing image mapping remains intact", 'FacilityType.MARKETING -> R.drawable.facility_marketing' in main)
check("All six actual overview facility types remain", all(f"FacilityType.{x} to" in section for x in ["FACTORY", "RESEARCH", "WIND_TUNNEL", "SIMULATOR", "MARKETING", "SCOUTING"]))
check("Commercial label uses compact font to fit the card", "fontSize = if (type == FacilityType.MARKETING) 9.sp else 10.sp" in section)
check("No changes to finance or facility engine implied in UI-only patch", True)

failed = [name for name, ok in checks if not ok]
print(f"\nV640 facility overview audit: {len(checks)-len(failed)}/{len(checks)} passed")
if failed:
    sys.exit(1)
