#!/usr/bin/env python3
"""Static regression audit for V642 long-career instant-simulation ANR fix."""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[2]
FILES = {
    "gradle": ROOT / "app/build.gradle.kts",
    "main": ROOT / "app/src/main/java/com/f1teammanager/MainActivity.kt",
    "history": ROOT / "app/src/main/java/com/f1teammanager/HistoricalDatabase.kt",
    "changelog": ROOT / "CHANGELOG_V642.md",
    "historyDocs": ROOT / "AUDIT_V642_INSTANT_SIMULATION_ANR.md",
}
text = {k: (p.read_text(encoding="utf-8") if p.is_file() else "") for k, p in FILES.items()}
checks = []

def check(name: str, passed: bool) -> None:
    checks.append((name, bool(passed)))
    print(f"{'PASS' if passed else 'FAIL'} | {name}")

check("V642 versionCode is 642", bool(re.search(r"versionCode\s*=\s*642\b", text["gradle"])))
check("V642 versionName matches code", 'versionName = "0.642.0"' in text["gradle"])
check("Instant simulation is launched asynchronously", "instantSimulationScope.launch" in text["main"])
start = text["main"].find("fun simulateWeekendInstantlyForCareer()")
end = text["main"].find("fun returnToCalendarAfterRace()", start)
instant = text["main"][start:end] if start >= 0 and end > start else ""
check("Q/R simulation runs inside Dispatchers.Default", "withContext(Dispatchers.Default)" in instant and "InstantSimulationService.simulateWeekendInstantly(" in instant)
check("Simulation worker still uses shared validated service", "InstantSimulationService.simulateWeekendInstantly(" in instant and "engine, participants(), circuit(), team.id" in instant)
check("Result persistence happens after the worker returns", "val weekend = simulationOutcome.getOrElse" in instant and "savePendingRaceFinalization" in instant)
check("Duplicate instant runs are guarded", "if (instantSimulationRunning || weeklyAdvancementRunning) return" in instant)
advance_start = text["main"].find("fun advanceFreeWeeksAsync(")
advance_end = text["main"].find("fun skipOneWeek()", advance_start)
advance = text["main"][advance_start:advance_end] if advance_start >= 0 and advance_end > advance_start else ""
check("Free-week work runs on Dispatchers.Default", "withContext(Dispatchers.Default)" in advance and "advanceFreeWeeks(weeks, targetWeek)" in advance)
check("Background UI-state writes use a mutable Compose snapshot", "Snapshot.withMutableSnapshot" in advance)
check("Week-skip route uses async advancement", "advanceFreeWeeksAsync(1, currentWeek + 1)" in text["main"])
check("Jump-to-next-GP route uses async advancement", "advanceFreeWeeksAsync((target-currentWeek).coerceAtLeast(0), target)" in text["main"])
check("Calendar actions share a single-running guard", "if (weeklyAdvancementRunning || instantSimulationRunning) return" in text["main"])
check("Both Home calendar buttons disable while either operation runs", "enabled = !weeklyAdvancementRunning && !instantSimulationRunning && currentWeek < 56" in text["main"] and "enabled = !weeklyAdvancementRunning && !instantSimulationRunning && nextRound != null" in text["main"])
check("Home button disables itself during instant simulation", "enabled = !instantSimulationRunning && currentWeek == round.weekOfSeason" in text["main"])
check("Home button exposes progress state", 'if (instantSimulationRunning) "SIMULANDO GP..."' in text["main"])
check("Progress dialog covers instant simulation and calendar advancement", "if (instantSimulationRunning || weeklyAdvancementRunning)" in text["main"] and "Dialog(onDismissRequest = {})" in text["main"] and "CircularProgressIndicator(color = Red)" in text["main"] and "AVANÇANDO CALENDÁRIO" in text["main"])
check("Race results use per-GP atomic shards", "writeRaceLines(season, round.round, raceLines)" in text["history"] and "f1tm_historical_v3_races" in text["history"])
record_start = text["history"].find("fun recordRace(")
record_end = text["history"].find("fun isSeasonFinalized(", record_start)
record = text["history"][record_start:record_end] if record_start >= 0 and record_end > record_start else ""
check("GP recording no longer reads/re-writes the whole career archive", "readLines()" not in record and "write(existing)" not in record and "writeRaceLines" in record)
check("Season summaries use per-season atomic shards", "f1tm_historical_v3_seasons" in text["history"] and "writeSeasonLines(season, lines)" in text["history"])
finalize_start = text["history"].find("fun finalizeSeason(")
finalize_end = text["history"].find("fun raceRecords(", finalize_start)
finalize = text["history"][finalize_start:finalize_end] if finalize_start >= 0 and finalize_end > finalize_start else ""
check("Season finalization reads only that season's race rows", "readSeasonRaceLines(season)" in finalize and "readLines()" not in finalize)
check("Old monolithic history is retained as a read source", "Legacy monolithic archive remains the read/migration source" in text["history"] and "readAtomicLines(file)" in text["history"])
check("Legacy history rows are shadowed only for matching GP/season", "shadowedRaces" in text["history"] and "shadowedSeasons" in text["history"])
check("Delete-save clears new historical shards", "raceArchiveDirectory.deleteRecursively()" in text["history"] and "seasonArchiveDirectory.deleteRecursively()" in text["history"])
check("Release notes and ANR audit were written", bool(text["changelog"]) and bool(text["historyDocs"]))

failed = [name for name, ok in checks if not ok]
print(f"\nV642 instant-simulation ANR audit: {len(checks)-len(failed)}/{len(checks)} passed")
sys.exit(1 if failed else 0)
