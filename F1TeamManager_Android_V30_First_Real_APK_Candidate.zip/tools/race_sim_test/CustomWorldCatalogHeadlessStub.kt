package com.f1teammanager.core.season

/**
 * Headless-only stand-in for the Android SharedPreferences catalog. It is never
 * compiled into the app; it lets the real WorldDatabase/market/race/season engines
 * be exercised with a legacy custom roster in a plain Kotlin runtime.
 */
object CustomWorldCatalog {
    data class Pilot(
        val id: Int, val name: String, val country: String, val driverClass: String,
        val evolution: String, val speed: Int, val qualifying: Int, val overtaking: Int,
        val defense: Int, val consistency: Int, val wet: Int, val tyre: Int,
        val teamId: Int = 0
    )
    data class Team(
        val id: Int, val name: String, val country: String,
        val driver1Id: Int, val driver2Id: Int, val assetName: String
    )
    var pilots: List<Pilot> = emptyList()
    var teams: List<Team> = emptyList()
    fun customPilots(): List<Pilot> = pilots.toList()
    fun customTeams(): List<Team> = teams.toList()
}
