from pathlib import Path
import re
root = Path(__file__).resolve().parents[2]
evolution = (root/'app/src/main/java/com/f1teammanager/core/season/DriverEvolutionEngine.kt').read_text()
manager = (root/'app/src/main/java/com/f1teammanager/core/manager/ManagerSeasonEngine.kt').read_text()
prefs = (root/'app/src/main/java/com/f1teammanager/CareerPreferences.kt').read_text()
gradle = (root/'app/build.gradle.kts').read_text()
workflow = (root/'.github/workflows/android-apk.yml').read_text()
test = root/'app/src/test/kotlin/com/f1teammanager/core/season/DriverEvolutionV674Test.kt'
checks = {
    'version code/name V674': 'versionCode = 674' in gradle and 'versionName = "0.674.0"' in gradle,
    'canonical driver grid size is 80': 'const val DRIVER_GRID_SIZE = 80' in evolution,
    'qualifying/race targets clamp to 80': 'coerceAtMost(DRIVER_GRID_SIZE)' in evolution and 'coerceIn(1, DRIVER_GRID_SIZE)' in evolution,
    'Team Principal requires 80 active driver contracts': 'activeContracts.size == DriverEvolutionEngine.DRIVER_GRID_SIZE' in manager,
    'Team Principal confirms 80 target inputs and outputs': 'inputs.size == DriverEvolutionEngine.DRIVER_GRID_SIZE' in manager and 'individualTargets.size == DriverEvolutionEngine.DRIVER_GRID_SIZE' in manager,
    'Career mode requires 80 active drivers': 'active.size == DriverEvolutionEngine.DRIVER_GRID_SIZE' in prefs,
    'Career mode confirms 80 target inputs and outputs': 'inputs.size == DriverEvolutionEngine.DRIVER_GRID_SIZE' in prefs and 'targets.size == DriverEvolutionEngine.DRIVER_GRID_SIZE' in prefs,
    'mechanical/external DNF helper exists': 'fun racePositionForEvolution' in evolution and all(x in evolution for x in ['"PANE"', '"FALHA"', '"SEM COMBUSTÍVEL"', '"PNEU DEGRADADO"', '"COLISÃO"']),
    'Team Principal evolution consumes normalized DNF result': 'racePositionForEvolution(' in manager,
    'Career evolution consumes normalized DNF result': 'racePositionForEvolution(' in prefs,
    'class growth factor minimum is 60 percent': 'excess <= 7 -> 0.70' in evolution and 'else -> 0.60' in evolution,
    'new regression test present': test.is_file(),
    'release notes and audit present': (root/'CHANGELOG_V674.md').is_file() and (root/'AUDIT_V674_DRIVER_EVOLUTION.md').is_file(),
    'workflow artifact identifies V674': 'F1-Team-Manager-V30-V674-debug-apk' in workflow,
    'ZIP naming manifest preserved': 'F1TeamManager_Android_V30_First_Real_APK_Candidate.zip' in (root/'package_manifest.txt').read_text(),
}
for name, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ' - ' + name)
print(f'RESULT: {sum(checks.values())}/{len(checks)} checks passed')
raise SystemExit(0 if all(checks.values()) else 1)
