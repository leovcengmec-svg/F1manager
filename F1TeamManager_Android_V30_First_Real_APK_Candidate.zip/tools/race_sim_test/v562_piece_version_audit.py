#!/usr/bin/env python3
"""Static contract audit for V562: team-level starting performance and component piece V0."""
from pathlib import Path
import re
import sys
ROOT = Path(__file__).resolve().parents[2]
def read(rel):
    p = ROOT / rel
    return p.read_text(encoding='utf-8') if p.is_file() else ''
checks = []
def check(name, ok):
    checks.append((name, bool(ok)))

gradle = read('app/build.gradle.kts')
profile = read('app/src/main/java/com/f1teammanager/core/manager/InitialTeamProfile.kt')
garage = read('app/src/main/java/com/f1teammanager/core/manager/CarGarageModels.kt')
research = read('app/src/main/java/com/f1teammanager/core/manager/ResearchEngine.kt')
factory = read('app/src/main/java/com/f1teammanager/core/manager/FactoryEngine.kt')
main = read('app/src/main/java/com/f1teammanager/MainActivity.kt')
prefs = read('app/src/main/java/com/f1teammanager/CareerPreferences.kt')
test = read('app/src/test/kotlin/com/f1teammanager/InitialCarStartsAtVersionZeroV562Test.kt')
check('versionCode/versionName set to 562', 'versionCode = 562' in gradle and 'versionName = "0.562.0"' in gradle)
check('team profile covers Forte/Médio/Fraco performance bands', 'FORTE -> 56 to 60' in profile and 'MEDIO -> 48 to 55' in profile and 'else -> 40 to 47' in profile)
check('legacy team car projects the profile values', 'engine = profile.engine' in profile and 'frontWing = profile.frontWing' in profile and 'brakes = profile.brakes' in profile)
check('player and AI garages both use the same baseline performance map', 'val performance = openingValues' in garage)
check('six baseline components are registered at V0', '"$owner-V0-${team.id}-${id.name}-${component.name}"' in garage and 'installedPieceVersions = installed.keys.associateWith { 0 }' in garage)
check('research version increments from the current-season latest design or V0', 'val previousVersion = latest?.version ?: 0' in research and 'val version = previousVersion + 1' in research)
check('research base performance is taken from design/base garage', 'latest?.performance ?: maxOf(garage.car1.componentValue(component), garage.car2.componentValue(component))' in research)
check('research start does not manufacture/install a piece', 'O carro NÃO muda até uma peça ser fabricada e instalada.' in main and 'factory.pendingInstallations' in main)
check('physical installation applies the manufactured piece to the selected car', 'fun install(piece: CarPiece, target: GarageCarId)' in garage and 'val updatedGarage = garage.install(piece, target)' in main)
check('V561 zero-performance saves recover from physical garage/profile', 'val garage = loadGarage(forTeamId)' in prefs and 'InitialTeamProfile.carState(it)' in prefs and 'saveCar(forTeamId, restored)' in prefs)
check('old INIT starter migration preserves component performance and resets piece version only', 'fun moveStarterToV0(car: PhysicalCar)' in prefs and 'installedPieceVersions = installed.keys.associateWith { 0 }' in prefs and 'engine=0' not in prefs[prefs.find('fun moveStarterToV0'):prefs.find('val migrated = when')])
check('regression test covers V0 and base performance', test and 'PieceVersionV0' in test and 'TeamOpeningPerformance' in test and 'ResearchEngine().start' in test)
check('version-specific changelog exists', (ROOT/'CHANGELOG_V562.md').is_file())
for name, ok in checks:
    print(('PASS' if ok else 'FAIL') + ' | ' + name)
failed = sum(not ok for _, ok in checks)
print(f'RESULT: {len(checks)-failed}/{len(checks)} V562 piece-version checks passed')
sys.exit(1 if failed else 0)
