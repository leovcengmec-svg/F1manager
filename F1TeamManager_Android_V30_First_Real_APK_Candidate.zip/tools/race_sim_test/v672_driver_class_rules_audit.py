#!/usr/bin/env python3
"""Static source audit for V672 driver class floor and championship gate."""
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[2]
checks = []
def ck(label, ok):
    checks.append((label, bool(ok)))
def read(rel):
    path = ROOT / rel
    return path.read_text(encoding="utf-8") if path.is_file() else ""

progression = read("app/src/main/java/com/f1teammanager/core/season/DriverClassProgressionEngine.kt")
prefs = read("app/src/main/java/com/f1teammanager/CareerPreferences.kt")
manager = read("app/src/main/java/com/f1teammanager/core/manager/ManagerSeasonEngine.kt")
annual = read("app/src/main/java/com/f1teammanager/core/manager/AnnualTeamEventEngine.kt")
profile = read("app/src/main/java/com/f1teammanager/core/season/DriverProfileCatalog.kt")
test = read("app/src/test/kotlin/com/f1teammanager/core/season/DriverClassProgressionV672Test.kt")
gradle = read("app/build.gradle.kts")
manifest = read("package_manifest.txt")
workflow = read(".github/workflows/android-apk.yml")

ck("Official ladder begins at Médio and excludes Fraco", 'listOf("Médio", "Forte", "Pro", "Lenda")' in progression)
ck("Legacy Fraco and Normal labels canonicalize to Médio", '"Fraco", "Normal", "Médio" -> "Médio"' in progression)
ck("Normal/Fraco cannot move below the floor", 'if (nextIndex !in ladder.indices) return null' in progression and 'index > 0' in progression)
ck("Adjacent transition helper applies the champion gate", 'officialClass == "Pro" && nextClass == "Lenda" && !isChampion' in progression)
ck("Pro-to-Lenda season review requires champion", 'officialClass != "Pro" || nextClass != "Lenda" || isChampion' in progression)
ck("Career path passes official archived driver champion", 'history.driverChampions(completedSeason).singleOrNull()?.driverId' in prefs and 'isChampion = base.id == championDriverId' in prefs)
ck("Manager path identifies season champion and passes gate", 'val championDriverId = seasonNext.standings.entries.sortedWith' in manager and 'isChampion = base.id == championDriverId' in manager)
ck("Legacy annual class helper delegates to shared guard", 'DriverClassProgressionEngine.adjacentClass(current, promote, isChampion)' in annual)
ck("Legacy class overrides are normalized when loaded and saved", 'DriverClassProgressionEngine::canonicalClass' in prefs and 'canonicalClass(driverClass)' in prefs)
ck("Legacy Normal class maps to the Médio Overall band", '"Fraco", "Médio", "Normal" -> 69' in profile and '"Fraco", "Médio", "Normal" -> 60' in profile and 'driverClass == "Fraco" || base.driverClass == "Normal"' in profile)
ck("Promotion, champion, minimum-floor and legacy cases have tests", all(x in test for x in ['"Pro"', 'isChampion = true', '"Normal"', '"Fraco"', '"Médio"']))
ck("Release metadata is V672", 'versionCode = 672' in gradle and 'versionName = "0.672.0"' in gradle)
ck("Original ZIP name preserved in manifest", 'F1TeamManager_Android_V30_First_Real_APK_Candidate.zip' in manifest)
ck("GitHub APK artifact label updated", 'F1-Team-Manager-V30-V672-debug-apk' in workflow)
ck("V672 release notes and audit retained", (ROOT / 'CHANGELOG_V672.md').is_file() and (ROOT / 'AUDIT_V672_DRIVER_CLASS_RULES.md').is_file())

failed = 0
for label, ok in checks:
    print(("PASS" if ok else "FAIL") + " | " + label)
    failed += not ok
print(f"RESULT: {len(checks)-failed}/{len(checks)} V672 source checks passed")
raise SystemExit(1 if failed else 0)
