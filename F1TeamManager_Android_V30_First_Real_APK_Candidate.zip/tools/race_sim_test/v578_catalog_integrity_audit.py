#!/usr/bin/env python3
"""V578 static integration audit for custom catalog identities and roster synchronization."""
from pathlib import Path
import re, sys, xml.etree.ElementTree as ET
ROOT = Path(__file__).resolve().parents[2]
checks=[]
def check(name, ok, detail=''):
    checks.append((name, bool(ok), detail))
def read(rel):
    p=ROOT/rel
    return p.read_text(encoding='utf-8') if p.is_file() else ''
gradle=read('app/build.gradle.kts')
catalog=read('app/src/main/java/com/f1teammanager/core/season/CustomWorldCatalog.kt')
rules=read('app/src/main/java/com/f1teammanager/core/season/CustomCatalogIdentityRules.kt')
world=read('app/src/main/java/com/f1teammanager/core/season/WorldDatabase.kt')
market=read('app/src/main/java/com/f1teammanager/core/manager/DriverMarketCatalogMigrationV560.kt')
rule_test=read('app/src/test/java/com/f1teammanager/core/season/CustomCatalogIdentityRulesV578Test.kt')
market_test=read('app/src/test/kotlin/com/f1teammanager/core/manager/DriverMarketRosterAuthorityV578Test.kt')
try:
    ET.parse(ROOT/'app/src/main/AndroidManifest.xml'); check('Manifest XML parses', True)
except Exception as e: check('Manifest XML parses', False, str(e))
vc=re.search(r'versionCode\s*=\s*(\d+)',gradle); vn=re.search(r'versionName\s*=\s*"([^"]+)"',gradle)
check('Version metadata is V578', bool(vc and vn and vc.group(1)=='578' and vn.group(1)=='0.578.0'))
check('Custom team IDs colliding with official 1–40 are rejected', 'teamIdCollisions(parsedTeams.map { it.id }, officialTeamIds)' in catalog and 'teamIdCollisions' in rules)
check('Custom pilot IDs colliding with official 1–100 are rejected', 'pilotIdCollisions(parsedPilots.map { it.id }, officialDriverIds)' in catalog and 'pilotIdCollisions' in rules)
check('Custom team rosters cannot reuse official pilots', 'belongs to the official base' in rules or 'pertence à base oficial' in rules)
check('Duplicate cross-team roster references are rejected', 'Piloto $driverId vinculado às equipes' in rules)
check('Legacy pilot team binding is resolved from authoritative team roster', 'customRosterTeamByDriverId' in world and 'rosterTeamId ?: d.teamId' in world)
check('Legacy roster binding prevents custom pilots being allocated to a different team', 'rosterOwnerByDriverId[id] == team.id' in market and 'rosterOwnerByDriverId[id] == null || rosterOwnerByDriverId[id] == team.id' in market)
check('Custom pilot roster rules have regression tests', all(x in rule_test for x in ['customIdsCannotAliasTheOfficialTeamOrDriverRanges','teamRosterIsAuthoritativeForLegacyPilotsWithoutPersistedTeamId','aPilotCannotBeAssignedToTwoCustomTeamsOrToTheWrongTeam']))
check('Market migration has a legacy teamId=0 regression test', 'rosterBindingWinsEvenWhenLegacyPilotTeamIdIsZero' in market_test)
check('Version changelog and audit exist', (ROOT/'CHANGELOG_V578.md').is_file() and (ROOT/'AUDIT_V578.md').is_file())
assets=[p for p in (ROOT/'app/src/main/assets').rglob('*') if p.is_file()]
check('External assets preserved', len(assets)>=195, f'count={len(assets)}')
history=len(list(ROOT.glob('AUDIT_V*.md')))+len(list(ROOT.glob('CHANGELOG_V*.md')))
check('Historical audit/changelog records preserved', history>=531, f'docs={history}')
for name,ok,detail in checks:
    print(('PASS' if ok else 'FAIL')+' | '+name+(f' | {detail}' if detail else ''))
failed=sum(not ok for _,ok,_ in checks)
print(f'RESULT: {len(checks)-failed}/{len(checks)} V578 catalog integration checks passed')
print('LIMIT: Static/source checks only; Android compilation and device/JUnit suite require an Android build environment.')
sys.exit(1 if failed else 0)
