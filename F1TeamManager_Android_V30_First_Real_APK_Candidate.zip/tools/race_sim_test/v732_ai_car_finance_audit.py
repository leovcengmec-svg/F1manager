#!/usr/bin/env python3
"""Static release audit for V732 canonical next-car and AI financial systems."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]

def read(path: str) -> str:
    p = ROOT / path
    if not p.exists():
        raise AssertionError(f"Missing file: {path}")
    return p.read_text(encoding="utf-8")

checks = []
def check(label: str, condition: bool) -> None:
    if not condition:
        raise AssertionError(label)
    checks.append(label)

projection = read("app/src/main/java/com/f1teammanager/core/manager/NextSeasonCarProjectionEngine.kt")
car = read("app/src/main/java/com/f1teammanager/core/manager/CarDevelopmentEngine.kt")
main = read("app/src/main/java/com/f1teammanager/MainActivity.kt")
ai_dev = read("app/src/main/java/com/f1teammanager/core/manager/AITeamDevelopmentEngine.kt")
ai_fin = read("app/src/main/java/com/f1teammanager/core/manager/AITeamFinancialEngine.kt")
policy = read("app/src/main/java/com/f1teammanager/core/manager/SeasonInvestmentPolicy.kt")
manager = read("app/src/main/java/com/f1teammanager/core/manager/ManagerSeasonEngine.kt")
checkpoint = read("app/src/main/java/com/f1teammanager/AiDevelopmentCheckpointStore.kt")
version = read("app/build.gradle.kts")
manifest = read("package_manifest.txt")

# Single physical construction / official projection.
check("shared unregulated garage builder exists", "fun buildUnregulatedGarage(" in projection)
check("official projection applies annual regulation centrally", "AnnualCarRegulationEngine.applyToGarage(built, regulation, teamId.hashCode())" in projection)
check("official projection applies closure penalty after regulation", "FinancialSeasonClosureEngine.applyGaragePenalty(regulated)" in projection)
check("AI uses same official projection helper", "NextSeasonCarProjectionEngine.buildOfficialGarage(" in main and "NextSeasonCarProjectionEngine.buildOfficialGarage(" in manager)
check("player rollover uses shared unregulated builder", "NextSeasonCarProjectionEngine.buildUnregulatedGarage(" in car)
check("team overview labels official Overall", "Overall oficial $officialOverall/100" in main)
check("conditional runway does not replace official Overall", "Cenário condicional:" in main)
check("ranking uses committed next-car investment", "committedInvestment = investment" in main)
check("ranking's official builder receives penalty state", "applyFinancialPenalty = financialPenalty" in main)

# GP30 canonical opening snapshot / durable checkpoint.
check("GP30 canonical garage finalization step exists", 'runFinalizationStep("ai_canonical_next_season_garages")' in main)
check("AI canonical snapshot persisted after official build", "persistCanonicalSeasonOpening(" in main)
check("headless season engine persists canonical snapshot", "persistCanonicalSeasonOpening(" in manager)
check("canonical opening overrides historical replay", "loadCanonicalOpening(team.id, targetSeason)" in ai_dev)
check("canonical checkpoint has explicit marker", "canonicalSeasonOpening: Boolean = false" in ai_dev)
check("checkpoint store writes schema 3", '.put("schema", 3)' in checkpoint)
check("checkpoint store persists canonical marker", '.put("canonicalSeasonOpening", checkpoint.canonicalSeasonOpening)' in checkpoint)
check("checkpoint store remains backwards compatible with schema 2", 'json.optInt("schema") in 2..3' in checkpoint)

# Correct strategic mindset / signed title fight gap.
check("signed gap points to strongest rival", "fun signedGapToStrongestRival" in policy)
check("title fight uses absolute gap and top-five filter", "ranking in 1..5 && kotlin.math.abs(signedGapToStrongestRival) <= 4" in policy)
check("financial engine uses common mindset selector", "private fun selectedInvestmentMindset(" in ai_fin)
check("facility and next-car decisions share mindset selector", ai_fin.count("selectedInvestmentMindset(") >= 4)
check("default car/facility split is 55/45", "STANDARD(\"Padrão / meio do grid\", 100, 55, 45, 50)" in policy)
check("dominant car split is 60/40", "DOMINANT_CAR(\"Carro dominante\", 100, 60, 40, 70)" in policy)
check("title fight split is 65/35", "TITLE_FIGHT(\"Disputa pelo título\", 100, 65, 35, 40)" in policy)
check("rebuild split is 65/35", "NEXT_SEASON_REBUILD(\"Reconstrução\", 100, 65, 35, 60)" in policy)

# Facility distribution and technical accounting.
check("R&D/factory/wind tunnel targets 6", "FacilityType.RESEARCH, FacilityType.FACTORY, FacilityType.WIND_TUNNEL -> 6" in policy)
check("marketing/simulator/driver development/race operations targets 5", "FacilityType.MARKETING, FacilityType.SIMULATOR," in policy and "FacilityType.DRIVER_DEVELOPMENT, FacilityType.RACE_OPERATIONS -> 5" in policy)
check("facility deficit has progressive priority", "(facilityTargetLevel(type) - currentLevel.coerceIn(0, 10)).coerceAtLeast(0) * 10" in policy)
check("facility investment re-evaluates every four weeks", "week % 4 != 0" in ai_fin)
check("facility construction remains 12 weeks", "FacilityUpgradeState(type, current.level(type), current.level(type)+1, 12, 12" in ai_fin)
check("unused facility share is reused only after all seven facilities max", "if (allFacilitiesMaxed) facilityAnnualRoom else 0L" in ai_fin)
check("current-car development keeps protected facility share", "developmentCashShare = if (allFacilitiesMaxed) currentAndFacilityCash else currentCarCashShare" in ai_fin)
check("research ledger and fabrication ledger are separate", "withSpend(TechnicalInvestmentCategory.RESEARCH_DESIGN" in ai_fin and "withSpend(TechnicalInvestmentCategory.FABRICATION" in ai_fin)
check("facility spending remains inside shared annual envelope", "annualEnvelopeRemaining = SeasonInvestmentPolicy.aiCurrentAndFacilityEnvelopeRemaining" in ai_fin)
check("next-car remains on independent 150M cap", "AI_NEXT_CAR_ABSOLUTE_CAP = 150_000_000L" in policy)

# Release identity.
check("versionCode 732", "versionCode = 732" in version)
check("versionName 0.732.0", 'versionName = "0.732.0"' in version)
check("package manifest identifies V732", "Version: 732 / 0.732.0" in manifest)
check("original ZIP filename is preserved", "F1TeamManager_Android_V30_First_Real_APK_Candidate.zip" in manifest)

print(f"V732 AI/CAR/FINANCE STATIC AUDIT: {len(checks)}/{len(checks)} checks passed")
for label in checks:
    print(f"PASS {label}")
