#!/usr/bin/env python3
"""Static safeguards for the V669 race-weather balance update."""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[2]
model = (ROOT / "app/src/main/java/com/f1teammanager/core/race/CircuitWeatherModel.kt").read_text(encoding="utf-8")
engine = (ROOT / "app/src/main/java/com/f1teammanager/core/race/CareerWeekendEngine.kt").read_text(encoding="utf-8")
test = ROOT / "app/src/test/java/com/f1teammanager/core/race/V669RaceWeatherBalanceTest.kt"
gradle = (ROOT / "app/build.gradle.kts").read_text(encoding="utf-8")
manifest = (ROOT / "package_manifest.txt").read_text(encoding="utf-8")

checks = []
def check(name, ok, detail=""):
    checks.append((name, bool(ok), detail))

profiles = {
    "arid": (0.020, 0.012),
    "dry": (0.040, 0.018),
    "standard": (0.075, 0.025),
    "variable": (0.120, 0.030),
    "wet": (0.200, 0.040),
}
for name, (rain_start, transition) in profiles.items():
    pattern = rf"private val {name} = CircuitWeatherProfile\((.*?)\n    \)"
    match = re.search(pattern, model, re.S)
    block = match.group(1) if match else ""
    check(f"{name} rain-start profile calibrated", f"raceRainStartChance = {rain_start:.3f}" in block)
    check(f"{name} new-rain transition remains low", f"raceTransitionChance = {transition:.3f}" in block)

check("continuous rain cap is 18 laps", "const val MAX_CONTINUOUS_RAIN_LAPS = 18" in model)
check("active rain clears independently from new-front probability", "random.nextDouble() < RAIN_CLEAR_TRANSITION_CHANCE" in model and "RAIN_CLEAR_TRANSITION_CHANCE = 0.52" in model)
check("hard cap forces cloudy weather", "continuousRainLaps >= MAX_CONTINUOUS_RAIN_LAPS) return Weather.CLOUDY" in model)
check("engine resets rain start marker per weekend", "raceRainStartedLap = -1" in engine)
check("engine initializes marker when race starts wet", "raceRainStartedLap = if (CircuitWeatherModel.isRain(weather)) 1 else -1" in engine)
check("engine passes continuous wet duration into weather model", "weather, profile, raceWeatherRandom, continuousRainLaps" in engine and "weather, raceWeatherRandom, continuousRainLaps" in engine)
check("V668 manual tyre-choice regression remains present", (ROOT / "app/src/test/java/com/f1teammanager/core/race/V668RainToDryPlayerTyreChoiceTest.kt").is_file())
check("V669 Monte Carlo and duration tests exist", test.is_file())
check("version code is 669", bool(re.search(r"versionCode\s*=\s*669\b", gradle)))
check("version name is 0.669.0", 'versionName = "0.669.0"' in gradle)
check("public name and ZIP filename are preserved", "F1TeamManager_Android_V30_First_Real_APK_Candidate.zip" in manifest and "Public name: F1 Team Manager V30" in manifest)

failed = 0
for name, ok, detail in checks:
    print(("PASS" if ok else "FAIL") + " | " + name + ((" | " + detail) if detail else ""))
    failed += not ok
print(f"RESULT: {len(checks)-failed}/{len(checks)} checks passed")
sys.exit(1 if failed else 0)
