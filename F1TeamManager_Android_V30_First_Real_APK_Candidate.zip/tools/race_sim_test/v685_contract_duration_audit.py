#!/usr/bin/env python3
"""Source-level regression audit for V685 sponsorship duration by marketing level."""
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]
engine = (ROOT / 'app/src/main/java/com/f1teammanager/core/manager/TeamSponsorshipEngine.kt').read_text(encoding='utf-8')
gradle = (ROOT / 'app/build.gradle.kts').read_text(encoding='utf-8')
unit = (ROOT / 'app/src/test/kotlin/com/f1teammanager/core/manager/SponsorshipContractDurationV685Test.kt').read_text(encoding='utf-8')
season = (ROOT / 'app/src/test/kotlin/ThreeSeasonCommercialAuditTest.kt').read_text(encoding='utf-8')
manifest = (ROOT / 'package_manifest.txt').read_text(encoding='utf-8')

checks = {
    'V685 version metadata': 'versionCode = 685' in gradle and 'versionName = "0.685.0"' in gradle,
    'levels 0-2 use the previous 3-10 GP window': 'SHORT_TERM_MIN_CONTRACT_RACES = 3' in engine and 'SHORT_TERM_MAX_CONTRACT_RACES = 10' in engine,
    'levels 3-10 retain the 8-16 GP window': 'MIN_CONTRACT_RACES = 8' in engine and 'MAX_CONTRACT_RACES = 16' in engine,
    'duration is selected from the effective marketing level': 'if (effectiveMarketingLevel <= 2)' in engine and 'durationRange.first + Math.floorMod(cycle, durationRange.count())' in engine,
    'AI scoring uses the signed contract duration without forcing the 8-16 window': 'sponsor.races.coerceIn(SHORT_TERM_MIN_CONTRACT_RACES, MAX_CONTRACT_RACES)' in engine,
    'upgrade does not modify already signed contract durations': 'retroactively rewrite existing contracts' in engine and 'upgradingMarketingDoesNotRewriteAlreadySignedContractDurations' in unit,
    'tests cover all levels and AI renewals': 'for (level in 0..10)' in unit and 'engine.advanceRace(teamId, 2027, round)' in unit,
    'three-season audit uses a level-dependent range for initial contracts and renewals': 'if (level <= 2) 3..10 else 8..16' in season and 'Renovação fora da faixa comercial' in season,
    'ZIP naming convention preserved': 'F1TeamManager_Android_V30_First_Real_APK_Candidate.zip' in manifest,
    'new V685 audit and changelog exist': (ROOT / 'AUDIT_V685_SPONSOR_DURATION_BY_LEVEL.md').is_file() and (ROOT / 'CHANGELOG_V685.md').is_file(),
}
for label, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ' | ' + label)
failed = sum(not ok for ok in checks.values())
print(f'RESULT: {len(checks)-failed}/{len(checks)} V685 source checks passed')
sys.exit(1 if failed else 0)
