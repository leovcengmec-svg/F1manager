#!/usr/bin/env python3
"""V609 static audit for the reported missing Kotlin reference."""
from pathlib import Path
import re
import sys
ROOT = Path(__file__).resolve().parents[2]
checks = []
def check(name, ok, detail=''):
    checks.append((name, bool(ok), detail))
main = (ROOT/'app/src/main/java/com/f1teammanager/MainActivity.kt').read_text(encoding='utf-8')
build = (ROOT/'app/build.gradle.kts').read_text(encoding='utf-8')
ui = main[main.find('private fun NextSeasonCarScreen'):]
check('No unresolved investableBudget reference remains', 'investableBudget' not in main)
check('Redundant investableRemaining reference removed', 'investableRemaining' not in main)
check('Cash after operational reserve is displayed', 'FinanceInfoRow("Após reserva", "€ ${cashAvailableNow / 1_000_000}M")' in ui)
check('Current available cash preserves operating reserve', 'state.finance.budget - SeasonInvestmentPolicy.protectedCash(state.finance.budget)' in ui)
check('Available investment respects cumulative room and cash', 'minOf(remaining, cashAvailableNow)' in ui)
check('Investment buttons respect cumulative room and cash', 'amount <= remaining && amount <= cashAvailableNow' in ui)
check('Absolute ceiling remains sourced from engine', 'nextSeasonInvestmentCap(state.car, state.garage)' in ui)
check('Version code is 609', re.search(r'versionCode\s*=\s*609\b', build) is not None)
check('Version name is 0.609.0', 'versionName = "0.609.0"' in build)
check('Version changelog exists', (ROOT/'CHANGELOG_V609.md').is_file())
check('Audit report exists', (ROOT/'AUDIT_V609_BUILD_FIX.md').is_file())
for name, ok, detail in checks:
    print(('PASS' if ok else 'FAIL') + ' | ' + name + (f' | {detail}' if detail else ''))
print(f'RESULT: {sum(ok for _,ok,_ in checks)}/{len(checks)} checks passed')
sys.exit(0 if all(ok for _,ok,_ in checks) else 1)
