from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
engine = (ROOT / "app/src/main/java/com/f1teammanager/core/season/DriverEvolutionEngine.kt").read_text()
career = (ROOT / "app/src/main/java/com/f1teammanager/CareerPreferences.kt").read_text()
manager = (ROOT / "app/src/main/java/com/f1teammanager/core/manager/ManagerSeasonEngine.kt").read_text()
gradle = (ROOT / "app/build.gradle.kts").read_text()
workflow = (ROOT / ".github/workflows/android-apk.yml").read_text()
manifest = (ROOT / "package_manifest.txt").read_text()
test = (ROOT / "app/src/test/kotlin/com/f1teammanager/core/season/DriverEvolutionV681Test.kt").read_text()
checks = {
    "driver grid fixed at 80": "const val DRIVER_GRID_SIZE = 80" in engine,
    "target input carries team identity": "val teamId: Int" in engine,
    "exactly 40 constructor teams required": "byTeam.size != 40" in engine,
    "exactly two active drivers per constructor": "byTeam.values.any { it.size != 2 }" in engine,
    "constructor ranking uses car strength only": "drivers.map { it.carStrength.coerceIn(0.0, 100.0) }.average()" in engine,
    "base positions are two driver slots per constructor": "teamRank * 2 - 1" in engine,
    "individual adjustment capped at three positions": ".coerceIn(-3, 3)" in engine,
    "uniform three-position tolerance": "positionMargin(@Suppress(\"UNUSED_PARAMETER\") position: Int): Int = 3" in engine,
    "Career V680 targets migrate to V3 and freeze": "savedTargetVersion >= 3" in career and 'putInt("driverSeasonTargetsVersion_$season", 3)' in career,
    "career reads current AI car profiles when persisted": "loadAnnualEventCarStats(teamId, InitialTeamProfile.carState(team))" in career,
    "Team Principal freezes target map per season": "hasFrozenSeasonTargets" in manager,
    "Team Principal target builder includes team id": "teamId = deal.teamId" in manager,
    "internal version code 681": "versionCode = 681" in gradle,
    "internal version name 0.681.0": 'versionName = "0.681.0"' in gradle,
    "GitHub artifact says V681": "F1-Team-Manager-V30-V681-debug-apk" in workflow,
    "original ZIP name preserved": "F1TeamManager_Android_V30_First_Real_APK_Candidate.zip" in manifest,
    "P22 example and P35 regression covered": "getValue(43).racePosition" in test and "qualifyingPosition = 35, racePosition = 35" in test,
}
failed = [name for name, ok in checks.items() if not ok]
for name, ok in checks.items():
    print(("PASS" if ok else "FAIL") + " - " + name)
if failed:
    raise SystemExit(f"{len(failed)} audit checks failed")
print(f"V681 static audit: {len(checks)}/{len(checks)} PASS")
