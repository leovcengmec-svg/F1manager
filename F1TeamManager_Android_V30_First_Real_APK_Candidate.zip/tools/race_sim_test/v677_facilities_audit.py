#!/usr/bin/env python3
"""Targeted static integration audit for the V677 facility/build correction."""
from pathlib import Path
import re, sys
ROOT = Path(__file__).resolve().parents[2]
checks = []
def check(name, condition, detail=""):
    checks.append((name, bool(condition), detail))
def read(rel):
    p = ROOT / rel
    return p.read_text(encoding="utf-8") if p.is_file() else ""

gradle = read("app/build.gradle.kts")
manifest = read("package_manifest.txt")
facilities = read("app/src/main/java/com/f1teammanager/core/manager/FacilityModels.kt")
research = read("app/src/main/java/com/f1teammanager/core/manager/ResearchEngine.kt")
factory = read("app/src/main/java/com/f1teammanager/core/manager/FactoryEngine.kt")
ai_development = read("app/src/main/java/com/f1teammanager/core/manager/AITeamDevelopmentEngine.kt")
market = read("app/src/main/java/com/f1teammanager/core/manager/DriverMarketEngine.kt")
career = read("app/src/main/java/com/f1teammanager/CareerPreferences.kt")
manager = read("app/src/main/java/com/f1teammanager/core/manager/ManagerSeasonEngine.kt")
dynamic_grid = read("app/src/main/java/com/f1teammanager/core/manager/DynamicGridEngine.kt")
race_model = read("app/src/main/java/com/f1teammanager/core/race/RaceModels.kt")
pace = read("app/src/main/java/com/f1teammanager/core/race/PitwallPaceModel.kt")
sponsor = read("app/src/main/java/com/f1teammanager/core/manager/SponsorContractPricing.kt")
sponsorship = read("app/src/main/java/com/f1teammanager/core/manager/TeamSponsorshipEngine.kt")
main = read("app/src/main/java/com/f1teammanager/MainActivity.kt")

def has_all(text, *tokens):
    return all(token in text for token in tokens)

check("V677 version metadata", "versionCode = 677" in gradle and 'versionName = "0.677.0"' in gradle)
check("Original ZIP and public name preserved", has_all(manifest, "F1TeamManager_Android_V30_First_Real_APK_Candidate.zip", "F1 Team Manager V30", "Base: V676"))
check("Seven facility types preserved", has_all(facilities, "FACTORY", "RESEARCH", "WIND_TUNNEL", "SIMULATOR", "SCOUTING", "DRIVER_DEVELOPMENT", "MARKETING"))
check("Factory spec is shared with AI", has_all(factory, "FactorySpecification", "manufacturingWeeks", "manufacturingCost") and has_all(ai_development, "FactorySpecification.level", "FactoryEngine().manufacturingWeeks", "FactoryEngine().manufacturingCost", "readyDesigns"))
check("AI factory retains completed designs until funding/capacity", has_all(ai_development, "readyDesigns += project", "if (actualQuantity <= 0) break", "readyDesigns.removeAt(0)"))
check("P&D concurrency rule shared", "fun activeProjectCapacity(level: Int)" in research and "ResearchEngine().activeProjectCapacity" in ai_development and "activeProjectCapacity(level)" in research)
check("P&D gains include actual installation levels", has_all(research, "maxImprovement(facilities: TeamFacilitiesState, component: CarComponent)", "FacilityEngine.researchGain", "maxImprovement(state.facilities, component)"))
check("AI and player project ranges match", has_all(ai_development, "research.maxImprovement(facilities, component)") and has_all(main, "previewGain(", "state.facilities, component"))
check("Race bonuses reach race and qualifying", has_all(race_model, "facilityPaceBonus") and has_all(dynamic_grid, "FacilityEngine.racePaceBonus(activeFacilities)") and "p.facilityPaceBonus.coerceIn(0.0, 0.015)" in pace and has_all(pace, "fun qualifyingLapTime", "carTimeModifier(p)"))
check("Driver Development reaches normal Career GP", has_all(career, "teamFacilitiesById: Map<Int, TeamFacilitiesState>", "facilityGrowthEfficiency = facilityFactor") and "store.applyDriverRaceEvolution(finalizationRound, facilitiesForDriverEvolution)" in main)
check("Driver Development reaches Team Principal GP", has_all(manager, "FacilityEngine.driverDevelopmentEfficiency(teamFacilities)", "facilityGrowthEfficiency = facilityFactor"))
check("Scouting affects AI market decisions", has_all(market, "aiScoutingEstimateForMarket", "scoutingFacilities") and has_all(main, "aiFacilitiesForScouting", "nextSeasonCarStrength, aiFacilitiesForScouting") and "performanceSeason.standings, nextSeasonCarStrength, aiFacilities" in manager)
check("Commercial contract multiplier is monotonic", "1.60 + marketingLevel.coerceIn(0, 10) * 0.025" in sponsor)
check("Marketing quality shifts toward stronger tiers", "rawRoll.coerceIn(0, 99) + qualityShift" in sponsorship and "rawRoll.coerceIn(0, 99) - qualityShift" not in sponsorship)
check("Marketing regression test checks category outcome", has_all(read("app/src/test/kotlin/com/f1teammanager/core/manager/CommercialEconomyV671Test.kt"), "categoryForQualityRoll(2, 68)", "SponsorCategory.REGIONAL", "categoryForQualityRoll(9, 84)"))
check("Facility UI shows current and next effects", has_all(main, '"ATUAL: ${FacilityEngine.levelEffect(type, level, facilities)}"', '"PRÓXIMO: ${FacilityEngine.nextLevelEffect(type, level, facilities)}"', 'FacilityType.DRIVER_DEVELOPMENT to'))
check("V676 facility regression tests retained", (ROOT / "app/src/test/kotlin/com/f1teammanager/core/manager/FacilityProgressionV676Test.kt").is_file() and (ROOT / "app/src/test/kotlin/com/f1teammanager/core/race/FacilityPaceV676Test.kt").is_file())
check("V676 and V677 release notes and audit included", (ROOT / "CHANGELOG_V676.md").is_file() and (ROOT / "CHANGELOG_V677.md").is_file() and (ROOT / "AUDIT_V677_BUILD_FIX.md").is_file())
check("CI publishes V677 and runs tests/build", has_all(read(".github/workflows/android-apk.yml"), "F1-Team-Manager-V30-V677-debug-apk", ":app:testDebugUnitTest :app:assembleDebug"))

check("V677 compile fix passes AI facilities snapshot to GP evolution", "applyDriverEvolution(next, race, performanceSeason, aiFacilities)" in manager)
check("V677 evolution method declares scoped AI facilities parameter", "aiFacilities: Map<Int, TeamFacilitiesState> = emptyMap()" in manager)
check("V677 AI facility lookup uses passed snapshot", "driverTeamId != null -> aiFacilities[driverTeamId]" in manager)
failed = 0
for name, ok, detail in checks:
    print(("PASS" if ok else "FAIL") + " | " + name + ((" | " + detail) if detail else ""))
    failed += not ok
print(f"RESULT: {len(checks)-failed}/{len(checks)} checks passed")
sys.exit(1 if failed else 0)
