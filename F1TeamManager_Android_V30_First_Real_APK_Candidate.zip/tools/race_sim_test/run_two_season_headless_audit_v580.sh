#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
BUILD_DIR="${TMPDIR:-/tmp}/f1tm-v580-headless-build"
rm -rf "$BUILD_DIR"
mkdir -p "$BUILD_DIR"
mapfile -t RELATIVE_SOURCES < <(grep -v '^[[:space:]]*#' "$ROOT/tools/race_sim_test/headless_core_sources_v580.txt" | sed '/^[[:space:]]*$/d')
SOURCES=()
for source in "${RELATIVE_SOURCES[@]}"; do SOURCES+=("$ROOT/$source"); done
SOURCES+=("$ROOT/tools/race_sim_test/CustomWorldCatalogHeadlessStub.kt")
SOURCES+=("$ROOT/tools/race_sim_test/TwoSeasonChainRuntimeAudit.kt")
KOTLINC_BIN="${KOTLINC:-kotlinc}"
KOTLIN_BIN="${KOTLIN:-kotlin}"
"$KOTLINC_BIN" -language-version 2.0 -J-Xmx3g "${SOURCES[@]}" -d "$BUILD_DIR"
"$KOTLIN_BIN" -cp "$BUILD_DIR" com.f1teammanager.core.season.TwoSeasonChainRuntimeAuditKt
