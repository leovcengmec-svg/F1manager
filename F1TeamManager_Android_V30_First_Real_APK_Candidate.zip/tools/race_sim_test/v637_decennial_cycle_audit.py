#!/usr/bin/env python3
"""V637 decennial 80–100 -> 40–60 source and simulation audit."""
from pathlib import Path
import csv
import re
import sys

ROOT = Path(__file__).resolve().parents[2]
def read(rel):
    path = ROOT / rel
    return path.read_text(encoding='utf-8') if path.is_file() else ''

GRADLE = read('app/build.gradle.kts')
AI = read('app/src/main/java/com/f1teammanager/core/manager/AITeamFinancialEngine.kt')
POLICY = read('app/src/main/java/com/f1teammanager/core/manager/NextSeasonCarGrowthPolicy.kt')
REG = read('app/src/main/java/com/f1teammanager/core/manager/AnnualCarRegulationEngine.kt')
TEST = read('app/src/test/kotlin/com/f1teammanager/core/manager/DecennialCycleBalanceV637Test.kt')
HARNESS = read('tools/race_sim_test/V637TwentyYearCarConstructionSimulation.kt')
REPORT = read('SIMULACAO_V637_CICLO_DECENAL_20_ANOS.md')
CSV_PATH = ROOT / 'SIMULACAO_V637_CICLO_DECENAL_20_ANOS.csv'

checks=[]
def check(name, ok):
    checks.append((name, bool(ok)))

check('Version metadata is V637', 'versionCode = 637' in GRADLE and 'versionName = "0.637.0"' in GRADLE)
check('Changelog and audit report exist', (ROOT/'CHANGELOG_V637.md').is_file() and (ROOT/'AUDIT_V637_DECENNIAL_CYCLE.md').is_file())
check('AI keeps one canonical inverse investment target', 'investmentReferenceForNextSeasonTarget(' in AI and 'NextSeasonCarGrowthPolicy.maximumGain(currentOverall)' in AI)
check('Growth policy favors growth then tapers near 100', all(x in POLICY for x in ['in 0..69 -> 7','in 70..89 -> 5','in 90..96 -> 2','else -> 1']))
check('AI gains remain a requested target, not a free bonus', 'requested target, not a free performance bonus' in POLICY and 'coerceAtMost(absoluteCap)' in AI)
check('Universal investment table and +10% construction logic stay in place', 'fun constructionOverallForInvestment(invested: Long): Int?' in read('app/src/main/java/com/f1teammanager/core/manager/CarDevelopmentEngine.kt') and '(base * 1.10).roundToInt()' in read('app/src/main/java/com/f1teammanager/core/manager/CarDevelopmentEngine.kt'))
check('Decennial reduction profile is 40% average', all(x in REG for x in ['CarComponent.ENGINE to 40','CarComponent.CHASSIS to 35','CarComponent.FRONT_WING to 45','CarComponent.REAR_WING to 45','CarComponent.BRAKES to 35','CarComponent.ELECTRIC_POWER_UNIT to 40']))
check('Decennial rule replaces rather than stacks with annual events', 'if (decennialSeason) emptyList() else chosen' in REG)
check('Automated V637 tests assert pre/post bands', 'regulated.teamAverageOverall in 40..60' in TEST and 'maximumGain(100)' in TEST)
check('20-year harness uses the actual growth policy and both real engines', 'NextSeasonCarGrowthPolicy.maximumGain(overall)' in HARNESS and 'CarDevelopmentEngine()' in HARNESS and 'AnnualCarRegulationEngine.generateForCalendarYear' in HARNESS)

rows=[]
if CSV_PATH.is_file():
    with CSV_PATH.open(encoding='utf-8', newline='') as f:
        rows=list(csv.DictReader(f))
check('CSV contains 160 rows (2 seeds × 4 policies × 20 transitions)', len(rows)==160)
check('Report correctly discloses finance/full-career simulation limits', 'não uma simulação integral do livro-caixa' in REPORT and 'dinheiro disponível' in REPORT)

cycle_ok = True
for seed in ('20261005','42'):
    for to_year in ('2036','2046'):
        matches=[r for r in rows if r['seed']==seed and r['policy']=='Meta IA sem limite financeiro' and r['calendar'].endswith('->'+to_year)]
        if len(matches)!=1:
            cycle_ok=False
            continue
        r=matches[0]
        try:
            cycle_ok &= (
                int(r['teams_built_80_100'])==40 and
                80 <= int(r['min_before_reg']) <= int(r['max_before_reg']) <= 100 and
                int(r['teams_after_40_60'])==40 and
                40 <= int(r['min_after']) <= int(r['max_after']) <= 60 and
                r['decennial']=='true'
            )
        except (ValueError, KeyError):
            cycle_ok=False
check('Both decennial resets meet 80–100 before and 40–60 after for all 40 teams in both seeds', cycle_ok)

# Underfunding must remain visibly weaker: no bonus can rescue a low construction.
underfunded=True
for policy in ('Teto hipotético €25M/ano','Teto hipotético €35M/ano','Investimento zero'):
    matches=[r for r in rows if r['seed']=='20261005' and r['policy']==policy and r['calendar']=='2035->2036']
    if len(matches)!=1:
        underfunded=False
        continue
    r=matches[0]
    try:
        if policy=='Investimento zero': underfunded &= int(r['max_before_reg'])<=1 and int(r['max_after'])<=1
        else: underfunded &= int(r['max_before_reg'])<80 and int(r['avg_after_reg'].split('.')[0])<40
    except (ValueError, KeyError):
        underfunded=False
check('Insufficient/zero investment does not receive a free reset to the target band', underfunded)

failed=[name for name,ok in checks if not ok]
for name,ok in checks:
    print(('PASS' if ok else 'FAIL')+' | '+name)
print(f'RESULT: {len(checks)-len(failed)}/{len(checks)} checks passed')
if failed:
    sys.exit(1)
