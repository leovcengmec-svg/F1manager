#!/usr/bin/env python3
"""V705 source audit for next-car construction and randomized regulation cycles."""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[2]
def read(rel):
    path = ROOT / rel
    return path.read_text(encoding='utf-8') if path.is_file() else ''

GRADLE = read('app/build.gradle.kts')
CAR = read('app/src/main/java/com/f1teammanager/core/manager/CarDevelopmentEngine.kt')
AI = read('app/src/main/java/com/f1teammanager/core/manager/AITeamDevelopmentEngine.kt')
REG = read('app/src/main/java/com/f1teammanager/core/manager/AnnualCarRegulationEngine.kt')
PREFS = read('app/src/main/java/com/f1teammanager/CareerPreferences.kt')
MAIN = read('app/src/main/java/com/f1teammanager/MainActivity.kt')
AI_TEST = read('app/src/test/kotlin/com/f1teammanager/core/manager/AITeamInvestmentV652Test.kt')
REG_TEST = read('app/src/test/kotlin/com/f1teammanager/AnnualCarRegulationEngineTest.kt')
CAP_TEST = read('app/src/test/kotlin/com/f1teammanager/core/manager/SeasonInvestmentPolicyV437Test.kt')
HARNESS = read('tools/race_sim_test/V637TwentyYearCarConstructionSimulation.kt')

checks=[]
def check(name, ok): checks.append((name, bool(ok)))

check('Version metadata is V705', 'versionCode = 705' in GRADLE and 'versionName = "0.705.0"' in GRADLE)
check('No free 10% rollover construction bonus remains', 'return base.coerceIn(40, 100)' in CAR and '(base * 1.10)' not in CAR)
check('Player investment has hard annual cap guard', 'alreadyInvested < annualCap && alreadyInvested < cap' in CAR and 'Trava ativada' in CAR)
check('Player UI disables contributions at annual cap', 'investmentLocked = invested >= minOf(cap, SeasonInvestmentPolicy.nextCarAnnualCap())' in MAIN and 'enabled = !investmentLocked' in MAIN)
check('AI underinvestment uses official Overall-investment table with annual ten-point cap', 'fun annualOverallFromInvestment(' in CAR and '(previous - 10).coerceAtLeast(40)' in CAR and 'missingMillions' not in CAR)
check('AI applies loss to every installed piece in both cars', 'applyAiUnderinvestmentPenalty' in CAR and all(f'CarComponent.{c} in car.installedPieces' in CAR for c in ['ENGINE','CHASSIS','FRONT_WING','REAR_WING','BRAKES','ELECTRIC_POWER_UNIT']))
check('AI underinvestment regression covers 7- and 15-point deficits', 'target - 7_000_000L' in AI_TEST and 'target - 15_000_000L' in AI_TEST)
check('Annual rule draws 0, 1 or 2 changes with weighted outcomes', 'countRoll < 15 -> 0' in REG and 'countRoll < 85 -> 1' in REG and 'else -> 2' in REG)
check('Regulation cycle is randomized from 6 through 10', 'nextInt(6, 11)' in REG and 'cycleLengthForStart' in REG)
check('Cycle length is redrawn using the new cycle start', 'cycleLengthForStart(boundary, careerSeed)' in REG)
check('Regulation rule persists cycle start and duration', 'append(rule.cycleStartSeason)' in REG and 'append(rule.cycleLength)' in REG and 'putString("carRegulationRule_' in PREFS)
check('Inaugural cycle draw and zero-change annual rules are shown to the user', 'ensureCarRegulationRule(seasonNumber)' in PREFS and 'return seasonNumber > 1' in PREFS and 'CICLO TÉCNICO SORTEADO' in read('app/src/main/java/com/f1teammanager/core/manager/CarRegulationEventScreen.kt'))
check('Tests cover weighted annual draws and repeat cycle draws', 'annualDrawIsDeterministicAndCanSelectZeroOneOrTwoDistinctComponents' in REG_TEST and 'cycleLengthIsDrawnFromSixToTenAndRedrawnAtEveryRevolution' in REG_TEST)
check('Tests cover the exact cap lock', 'nextCarInvestmentHardLocksAtTheAnnualCapAndAllowsTheFinalContribution' in CAP_TEST)
check('Simulation uses the production AI builder and variable cycle description', 'buildAiNextSeasonGarage(team.garage, investment)' in HARNESS and '6–10 completed seasons' in HARNESS)
check('Release notes and audit report exist', (ROOT/'CHANGELOG_V705.md').is_file() and (ROOT/'AUDIT_V705_NEXT_CAR_AND_REGULATIONS.md').is_file())

for name,ok in checks: print(('PASS' if ok else 'FAIL')+' | '+name)
failed=[name for name,ok in checks if not ok]
print(f'RESULT: {len(checks)-len(failed)}/{len(checks)} V705 source checks passed')
if failed: sys.exit(1)
