package com.f1teammanager.core.manager

/**
 * Runtime-only recovery audit for the GP journal. Simulates a process stop after an
 * effect is applied but before its durable marker is written, then recreates the
 * journal and replays the same step using an effect-level idempotency key.
 */
fun main() {
    val durableMarkers = mutableSetOf<String>()
    val durableEffects = mutableSetOf<String>()
    var failMarkerOnce = true
    val season = 2027
    val round = 30
    fun key(step: String) = "$season:$round:$step"
    fun journal() = RaceFinalizationJournal(
        season = season,
        round = round,
        isDone = { y, r, step -> "$y:$r:$step" in durableMarkers },
        markDone = { y, r, step ->
            if (step == RaceFinalizationPlan.PLAYER_FINANCE && failMarkerOnce) {
                failMarkerOnce = false
                false
            } else durableMarkers.add("$y:$r:$step")
        }
    )

    val first = journal()
    var interrupted = false
    try {
        first.runStep(RaceFinalizationPlan.PLAYER_FINANCE) {
            // Real side effects must be idempotent by this stable key.
            durableEffects.add(key(RaceFinalizationPlan.PLAYER_FINANCE))
        }
    } catch (_: IllegalStateException) {
        interrupted = true
    }
    check(interrupted) { "Fault injection did not interrupt after effect commit" }
    check(key(RaceFinalizationPlan.PLAYER_FINANCE) in durableEffects) { "Effect did not commit before interruption" }
    check(key(RaceFinalizationPlan.PLAYER_FINANCE) !in durableMarkers) { "Marker unexpectedly persisted" }

    // A new journal instance represents process restart; replay must be safe.
    val resumed = journal()
    resumed.runStep(RaceFinalizationPlan.PLAYER_FINANCE) {
        durableEffects.add(key(RaceFinalizationPlan.PLAYER_FINANCE))
    }
    check(durableEffects.count { it == key(RaceFinalizationPlan.PLAYER_FINANCE) } == 1) {
        "Idempotency key failed to prevent duplicate financial effect"
    }

    val steps = RaceFinalizationPlan.steps(round, 30)
    steps.drop(1).forEach { step ->
        resumed.runStep(step) { durableEffects.add(key(step)) }
    }
    resumed.complete()
    check("$season:$round:${RaceFinalizationPlan.COMPLETE}" in durableMarkers) { "Completion marker missing" }
    val effectsBeforeReplay = durableEffects.toSet()
    steps.forEach { step -> resumed.runStep(step) { durableEffects.add(key(step)) } }
    resumed.complete()
    check(durableEffects == effectsBeforeReplay) { "Completed GP replay changed side effects" }
    check(durableMarkers.containsAll(steps.map(::key))) { "At least one step marker missing" }
    check(durableEffects.size == steps.size) { "Unexpected duplicate or missing side effects: ${durableEffects.size}/${steps.size}" }

    println("RaceFinalizationRecoveryRuntimeAudit: PASS")
    println("round=$season/$round | plannedSteps=${steps.size} | durableEffects=${durableEffects.size} | interruptedAfterEffect=true | resumed=true | replayIdempotent=true")
}
