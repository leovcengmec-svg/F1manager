#!/usr/bin/env python3
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[2]

def ck(label: str, ok: bool) -> bool:
    print(f"{'PASS' if ok else 'FAIL'} | {label}")
    return ok

gradle = (ROOT / 'app/build.gradle.kts').read_text(encoding='utf-8')
engine = (ROOT / 'app/src/main/java/com/f1teammanager/core/season/DriverEvolutionEngine.kt').read_text(encoding='utf-8')
manager = (ROOT / 'app/src/main/java/com/f1teammanager/core/manager/ManagerSeasonEngine.kt').read_text(encoding='utf-8')
career = (ROOT / 'app/src/main/java/com/f1teammanager/CareerPreferences.kt').read_text(encoding='utf-8')
free_test = (ROOT / 'app/src/test/kotlin/FreeDriverEvolutionV657Test.kt').read_text(encoding='utf-8')
target_test = (ROOT / 'app/src/test/kotlin/DriverIndividualTargetsV657Test.kt').read_text(encoding='utf-8')
rate_test = (ROOT / 'app/src/test/kotlin/FreeDriverGrowthRateV657Test.kt').read_text(encoding='utf-8')

checks = []
checks.append(ck('V657 versionCode/versionName', 'versionCode = 657' in gradle and 'versionName = "0.657.0"' in gradle))
checks.append(ck('Free-driver multiplier is exactly 1.20', bool(re.search(r'const val FREE_DRIVER_GROWTH_RATE\s*=\s*1\.20', engine))))
checks.append(ck('Free-agent path keeps neutral evidence and applies the shared 1.20 factor', 'applyFreeDriverTick' in engine and 'FREE_DRIVER_NEUTRAL_PERFORMANCE_INDEX' in engine and 'facilityGrowthEfficiency = FREE_DRIVER_GROWTH_RATE' in engine))
checks.append(ck('Career and Team Principal evaluate individual target bands', 'DriverEvolutionEngine.gpPerformanceIndex(' in career and 'target.qualifyingPosition' in career and 'gpPerformanceIndex(target, q, r)' in manager))
checks.append(ck('Career and Team Principal recalibrate targets every GP', 'Recalibrate every completed GP' in career and 'Rebuild each GP from the exact AI garages' in manager))
checks.append(ck('Target builder combines car and driver qualifying/race strengths', 'buildIndividualTargets' in engine and '0.55 + it.qualifyingStrength' in engine and '0.60 + it.driverOverall' in engine))
checks.append(ck('Target bands have adaptive tolerances', 'in 1..10 -> 2' in engine and 'in 11..30 -> 3' in engine and 'in 31..60 -> 4' in engine and 'else -> 5' in engine))
checks.append(ck('Career targets persist schema V2 and migrate legacy saves', 'driverSeasonTargetsVersion_$season' in career and 'p.size >= 4' in career and 'initializeDriverSeasonTargets(loadCar(teamId))' in career))
checks.append(ck('Team Principal encodes two centers and migrates old 1..80 targets', 'qualifyingPosition.coerceIn(1, 80) * 100' in manager and 'encoded in 1..80' in manager))
checks.append(ck('Same-car teammate target separation and tolerance have a focused test', 'qualifyingPosition < weaker.qualifyingPosition' in target_test and '105.0, inside, 0.0' in target_test and 'performanceEvolutionRate(inside)' in target_test))
checks.append(ck('Free agents still receive one tick each GP and no class-review sample', 'All 20 free agents should show development' in free_test and 'driverEvolutionPhaseGps' in free_test and 'driverClassPerformance' in free_test))
checks.append(ck('Exact 1.20 growth ratio has a deterministic unit test', '1.20, DriverEvolutionEngine.FREE_DRIVER_GROWTH_RATE, 0.0' in rate_test and 'natural.bank * 1.20' in rate_test))

passed = sum(checks)
print(f'RESULT: {passed}/{len(checks)} checks passed')
raise SystemExit(0 if passed == len(checks) else 1)
