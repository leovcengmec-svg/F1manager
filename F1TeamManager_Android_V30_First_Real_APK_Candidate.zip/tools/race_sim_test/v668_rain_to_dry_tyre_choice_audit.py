from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
ENGINE = (ROOT / "app/src/main/java/com/f1teammanager/core/race/CareerWeekendEngine.kt").read_text()
UI = (ROOT / "app/src/main/java/com/f1teammanager/MainActivity.kt").read_text()
GRADLE = (ROOT / "app/build.gradle.kts").read_text()
TEST = (ROOT / "app/src/test/java/com/f1teammanager/core/race/V668RainToDryPlayerTyreChoiceTest.kt").read_text()
checks = []

def ck(label, condition):
    checks.append((label, bool(condition)))

start = ENGINE.index("internal fun requestPlayerTyreChoiceAfterRain")
end = ENGINE.index("fun advance(): SessionSnapshot", start)
handler = ENGINE[start:end]
ck("Versão interna V668", "versionCode = 668" in GRADLE and 'versionName = "0.668.0"' in GRADLE)
ck("Handler de secagem usa apenas carros do jogador ainda com pneu de chuva", "plans.containsKey(it.p.driverId)" in handler and "it.tyre in TyreModel.wetCompounds" in handler)
ck("Handler não executa parada nem escolhe composto automaticamente", "pit(" not in handler and "dryCompoundForRemainingLaps" not in handler)
ck("BOX direto é bloqueado até haver escolha explícita do composto", "Escolha SOFT, MEDIUM ou HARD no seletor" in ENGINE and "check(!(TyreModel.isDryTrack(weather)" in ENGINE)
ck("Plano automático é desativado e a decisão obrigatória é enfileirada", "plan.weatherManualMode = true" in handler and "ManagerDecisionType.WEATHER_CHANGE" in handler)
ck("Seletor seco oferece SOFT/MEDIUM/HARD e confirmação manual", "TyreModel.dryCompounds" in UI and "pitNow(activeDriverId, selectedTyre)" in UI)
ck("Botão BOX explica que abre a seleção de composto", "Abrir seleção: SOFT, MEDIUM ou HARD" in UI)
ck("Testes de regressão cobrem a transição chuva→seco e escolhas explícitas", "wetRaceStartThenDryingPausesAndNeverMountsHardAutomatically" in TEST and "playerCanChooseSoftAndHardAfterRainWithoutEngineReplacingTheChoice" in TEST)

failed = [label for label, ok in checks if not ok]
for label, ok in checks:
    print(("PASS" if ok else "FAIL") + " — " + label)
print(f"\n{len(checks)-len(failed)}/{len(checks)} verificações aprovadas")
if failed:
    raise SystemExit(1)
