package com.f1teammanager.core.season

import com.f1teammanager.core.manager.*
import com.f1teammanager.core.race.RaceResultValidator

/**
 * End-to-end headless audit for two full seasons in each actual new-game mode.
 * Uses the production ManagerSeasonEngine, DriverMarketEngine, initial-team profile,
 * race validator, finance ledger and Team Principal career engine.
 * Android preferences/UI remain outside this pure-engine runtime harness.
 */
fun main() {
    data class ModeCase(val code: String, val seed: Int, val chosenRank: Int)
    val cases = listOf(
        ModeCase("FREE", 20261017, 1),
        ModeCase("HARD", 20261018, 38),
        ModeCase("TEAM_PRINCIPAL", 20261019, 40)
    )
    val globalFailures = mutableListOf<String>()
    val report = mutableListOf<String>()

    for (mode in cases) {
        try {
            InitialTeamProfile.configureCareerSeed(mode.seed)
            val teams = WorldDatabase.teams
            check(teams.size == 40) { "${mode.code}: expected 40 teams, got ${teams.size}" }
            check(WorldDatabase.allDrivers.size == 100) { "${mode.code}: expected 100 drivers, got ${WorldDatabase.allDrivers.size}" }
            val openingRanking = InitialTeamProfile.openingRanking(teams, mode.seed)
            val openingRanks = openingRanking.mapIndexed { index, team -> team.id to (index + 1) }.toMap()
            val chosen = when (mode.code) {
                "FREE" -> openingRanking.first()
                "HARD" -> InitialTeamProfile.weakestInitialTeams(teams, 3, mode.seed).first()
                else -> InitialTeamProfile.weakestInitialTeams(teams, 3, mode.seed).last()
            }
            val allowedWeakest = InitialTeamProfile.weakestInitialTeams(teams, 3, mode.seed).map { it.id }.toSet()
            if (mode.code != "FREE") check(chosen.id in allowedWeakest) { "${mode.code}: selected team outside bottom three" }
            else check(openingRanks[chosen.id] == 1) { "FREE: test team must be any available team; chosen strongest for coverage" }

            val principalMode = mode.code == "TEAM_PRINCIPAL"
            var principalState: TeamPrincipalCareerState? = if (principalMode) {
                TeamPrincipalCareerEngine.initial(chosen.id, 2026, openingRanks)
            } else null
            check(TeamPrincipalCareerEngine.isActiveMode(mode.code, principalState != null) == principalMode) {
                "${mode.code}: Team Principal visibility mode gate failed"
            }
            if (principalMode) {
                check(principalState!!.prestige == 10) { "TEAM_PRINCIPAL: initial prestige not minimal" }
                check(TeamPrincipalCareerState.decode(principalState!!.encode()) == principalState) { "TEAM_PRINCIPAL: career state serialization round-trip failed" }
            }

            val marketEngine = DriverMarketEngine(mode.seed + 500)
            var market = marketEngine.initialState(2026)
            val gridValidator = DynamicGridEngine()
            check(gridValidator.validate(market).isEmpty()) { "${mode.code}: invalid initial grid: ${gridValidator.validate(market)}" }
            teams.forEach { t -> check(market.contracts.count { it.teamId == t.id && it.activeIn(2026) } == 2) { "${mode.code}: ${t.name} does not start with two active drivers" } }

            val car = InitialTeamProfile.carState(chosen, mode.seed)
            val garage = TeamGarageFactory.fromInitial(chosen, playerCareer = true)
            val sponsor = SponsorContract(
                name = "Patrocinador de auditoria ${mode.code}", upfront = 0L, racePayment = 150_000L,
                pointsBonus = 2_000L, years = 2, minimumReputation = 0, slot = 1,
                qualifyingTarget = 1, qualifyingBonus = 50_000L, raceTarget = 20,
                raceTargetBonus = 25_000L, active = true, races = 30, racesRemaining = 30
            )
            var manager = TeamManagerState(
                season = 2026, round = 1, playerTeamId = chosen.id, car = car,
                garage = garage,
                facilities = InitialTeamProfile.teamFacilities(chosen.initialLevel),
                finance = TeamFinanceState(InitialTeamProfile.initialBudget(chosen)),
                technicalInvestment = TechnicalInvestmentEngine.forTeam(2026, chosen.id, chosen.id, car),
                driverMarket = market, sponsor = sponsor, sponsors = listOf(sponsor)
            )
            var season = SeasonState()
            val engine = ManagerSeasonEngine(mode.seed, mode.seed)
            val constructorPointsBySeason = mutableMapOf<Int, MutableMap<Int, Int>>()
            var totalPoints = 0
            var racesChecked = 0
            var transitionChecks = 0

            repeat(60) { index ->
                val year = season.season
                val round = season.currentRound
                check(year in 2026..2027) { "${mode.code}: unexpected year $year at loop index $index" }
                check(round in 1..30) { "${mode.code}: unexpected round $round" }
                val calendar = SeasonCalendar.forSeason(year)
                check(calendar.size == 30) { "${mode.code}: $year calendar has ${calendar.size} races" }
                check(calendar.map { it.circuit }.distinct().size == 30) { "${mode.code}: duplicate circuit in $year calendar" }
                val roundDefinition = calendar[round - 1]
                val activeContracts = manager.driverMarket.contracts.filter { it.activeIn(year) }
                val teamByDriver = activeContracts.associate { it.driverId to it.teamId }
                check(teamByDriver.size == 80) { "${mode.code} $year GP$round: expected 80 active driver contracts, got ${teamByDriver.size}" }
                check(activeContracts.groupBy { it.teamId }.all { (_, ds) -> ds.size == 2 }) { "${mode.code} $year GP$round: roster not two drivers per team" }

                val outcome = engine.runRound(manager, season)
                manager = outcome.state
                season = outcome.season
                val race = outcome.race
                RaceResultValidator.requireValid(race, roundDefinition.laps)
                check(race.classification.size == 80) { "${mode.code} $year GP$round: classification size ${race.classification.size}" }
                check(race.classification.map { it.driverId }.toSet().size == 80) { "${mode.code} $year GP$round: duplicate classified driver" }
                check(race.classification.map { it.position }.sorted() == (1..80).toList()) { "${mode.code} $year GP$round: missing/duplicate finish positions" }
                val qualifying = requireNotNull(race.qualifying) { "${mode.code} $year GP$round: qualifying missing" }
                check(qualifying.grid.size == 80) { "${mode.code} $year GP$round: qualifying grid incomplete" }
                check(qualifying.phases.map { it.entries.size } == listOf(80, 50, 20)) { "${mode.code} $year GP$round: Q1/Q2/Q3 field mismatch" }
                check(race.points.values.all { it >= 0 }) { "${mode.code} $year GP$round: negative points" }
                check(race.points.keys.all { it in teamByDriver.keys }) { "${mode.code} $year GP$round: points for unknown active driver" }
                check(manager.finance.budget >= 0L) { "${mode.code} $year GP$round: player budget negative" }
                check(manager.season == season.season && manager.round == season.currentRound) { "${mode.code} $year GP$round: manager/calendar drift" }
                check(manager.garage != null && manager.garage!!.car1.id != manager.garage!!.car2.id) { "${mode.code} $year GP$round: physical two-car garage missing" }
                check("$year:$round" in manager.driverEvolutionProcessedRounds) { "${mode.code} $year GP$round: missing evolution ledger marker" }
                check(gridValidator.validate(manager.driverMarket).isEmpty()) { "${mode.code} $year GP$round: market integrity failed: ${gridValidator.validate(manager.driverMarket)}" }
                check(manager.driverMarket.contracts.filter { it.activeIn(manager.season) }.groupBy { it.teamId }.all { (_, ds) -> ds.size == 2 }) {
                    "${mode.code} after $year GP$round: next active grid not exactly two/team"
                }

                val teamPoints = constructorPointsBySeason.getOrPut(year) { teams.associate { it.id to 0 }.toMutableMap() }
                race.points.forEach { (driverId, points) ->
                    val tId = teamByDriver[driverId] ?: error("${mode.code}: no team mapping for driver $driverId in $year")
                    teamPoints[tId] = (teamPoints[tId] ?: 0) + points
                }
                totalPoints += race.points.values.sum()
                racesChecked++

                if (round == 30) {
                    check(manager.season == year + 1 && manager.round == 1) { "${mode.code}: GP30 did not transition manager to next season" }
                    check(season.season == year + 1 && season.currentRound == 1) { "${mode.code}: GP30 did not reset SeasonState" }
                    check(teamPoints.values.sum() > 0) { "${mode.code}: no constructor points in $year" }
                    if (principalMode) {
                        val ranked = teams.sortedWith(compareByDescending<com.f1teammanager.core.season.TeamDefinition> { teamPoints[it.id] ?: 0 }.thenBy { it.id })
                        val ranks = ranked.mapIndexed { i, t -> t.id to (i + 1) }.toMap()
                        val rank = ranks[chosen.id] ?: 40
                        principalState = TeamPrincipalCareerEngine.recordSeason(requireNotNull(principalState), year, rank, ranks)
                        check(principalState!!.lastProcessedSeason == year) { "TEAM_PRINCIPAL: season $year not recorded exactly" }
                        check(principalState!!.records.count { it.season == year } == 1) { "TEAM_PRINCIPAL: duplicate record for $year" }
                        check(TeamPrincipalCareerState.decode(principalState!!.encode()) == principalState) { "TEAM_PRINCIPAL: persistence round-trip failed after $year" }
                        if (year == 2026) check(!principalState!!.reviewPending) { "TEAM_PRINCIPAL: review happened after one contract season" }
                        if (year == 2027) check(principalState!!.reviewPending) { "TEAM_PRINCIPAL: biennial review missing after second season" }
                    }
                    transitionChecks++
                }
            }

            check(racesChecked == 60) { "${mode.code}: expected 60 races, got $racesChecked" }
            check(transitionChecks == 2) { "${mode.code}: expected two season transitions, got $transitionChecks" }
            check(manager.season == 2028 && manager.round == 1) { "${mode.code}: final state not 2028 GP1" }
            check(manager.finance.seasonPrizesPaid.containsAll(setOf(2026, 2027))) { "${mode.code}: constructor prizes missing for a season" }
            check((manager.finance.salaryPaidRounds + manager.finance.salaryOutstanding.keys).size == 60) { "${mode.code}: salary ledger expected 60 GP keys" }
            check(manager.driverEvolutionAttributes.size == 100) { "${mode.code}: expected evolution state for 100 drivers" }
            check(manager.driverEvolutionProcessedRounds.size == 60) { "${mode.code}: expected 60 evolution markers" }
            check(manager.driverMarket.scheduled.none { it.startSeason <= manager.season }) { "${mode.code}: overdue scheduled driver deal at finish" }
            if (principalMode) {
                check(principalState!!.records.map { it.season } == listOf(2026, 2027)) { "TEAM_PRINCIPAL: career history does not include both seasons" }
                check(principalState!!.teamId == chosen.id) { "TEAM_PRINCIPAL: unexpected team identity mutation" }
            } else {
                check(principalState == null) { "${mode.code}: unexpected Team Principal career state" }
            }
            report += "${mode.code}: PASS | team=${chosen.id}:${chosen.name} | ranks=${openingRanks[chosen.id]} | races=$racesChecked | transitions=$transitionChecks | points=$totalPoints | budget=${manager.finance.budget} | activeContracts=${manager.driverMarket.contracts.count { it.activeIn(2028) }} | TPRecords=${principalState?.records?.size ?: 0}"
        } catch (t: Throwable) {
            globalFailures += "${mode.code}: ${t::class.java.simpleName}: ${t.message}"
        }
    }
    report.forEach(::println)
    if (globalFailures.isNotEmpty()) {
        globalFailures.forEach { System.err.println("FAIL | $it") }
        error("AllModesTwoSeasonRuntimeAudit failed: ${globalFailures.size} mode(s) failed")
    }
    println("AllModesTwoSeasonRuntimeAudit: PASS | modes=${cases.size} | simulatedRaces=${cases.size * 60} | seasonsPerMode=2")
}
