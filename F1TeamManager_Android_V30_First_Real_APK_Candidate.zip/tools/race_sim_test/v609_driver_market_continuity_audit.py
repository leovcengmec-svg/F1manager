#!/usr/bin/env python3
"""Static contract audit for V609 regression audit for preserved driver market."""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[2]
checks = []
def check(name, ok, detail=""):
    checks.append((name, bool(ok), detail))
def read(rel):
    path = ROOT / rel
    return path.read_text(encoding="utf-8") if path.is_file() else ""

engine = read("app/src/main/java/com/f1teammanager/core/manager/DriverMarketEngine.kt")
main = read("app/src/main/java/com/f1teammanager/MainActivity.kt")
prefs = read("app/src/main/java/com/f1teammanager/CareerPreferences.kt")
season_engine = read("app/src/main/java/com/f1teammanager/core/manager/ManagerSeasonEngine.kt")
ai_finance = read("app/src/main/java/com/f1teammanager/core/manager/AITeamFinancialEngine.kt")
test = read("app/src/test/kotlin/com/f1teammanager/core/manager/DriverMarketRealismV608Test.kt")
movement_mix = read("app/src/test/kotlin/MarketMovementMixTest.kt")
gradle = read("app/build.gradle.kts")

code_match = re.search(r"versionCode\s*=\s*(\d+)", gradle)
name_match = re.search(r'versionName\s*=\s*"([^"]+)"', gradle)
check("Version metadata is V609", bool(code_match and name_match and code_match.group(1) == "609" and name_match.group(1) == "0.609.0"))
check("Version changelog and audit are present", (ROOT / "CHANGELOG_V608.md").is_file() and (ROOT / "AUDIT_V608_DRIVER_MARKET.md").is_file())
check("AI vacancy resolution uses actual offer workflow", all(token in engine for token in ["makeOffer(", "expireOffers(", "signFuture(", "CONTRATO ACEITO NA PRÉ-TEMPORADA"]))
check("Legacy forced-rollover assignment label is absent", "ELENCO COMPLETADO NA VIRADA" not in engine and "Alocação emergencial" not in engine)
check("Player team is excluded from automatic vacancy fill", "WorldDatabase.teams.filter { it.id != playerTeamId }" in engine)
check("AI can record an unresolved vacancy instead of inventing a signing", "VAGA DE PILOTO EM ABERTO" in engine and "nenhum piloto foi atribuído sem aceitar um contrato" in engine)
check("Rollover signing fees enter the idempotent AI financial ledger", "applyRolloverSigningFee" in ai_finance and "SignatureFeeAccounting.register" in ai_finance and "aiFinance.applyRolloverSigningFee" in main)
check("Live team and driver championship signals influence interest", all(x in engine for x in ["teamChampionshipPoints", "driverChampionshipPoints", "teamSportingStrength", "driverIsTitleContender"]))
check("Extraordinary salary has progressively larger influence", all(x in engine for x in ["salaryRatio >= 10.0", "salaryRatio >= 8.0", "salaryRatio >= 6.0", "salaryRatio >= 4.5"]))
check("Contract-expiry seat is prioritized", "expiringIds" in engine and "replacementIsExpiring" in engine)
check("Multi-year replacement requires major improvement", "multiYearBreakout" in engine and "candidateOverall >= replacementOverall + 12" in engine)
check("No global 55/45 movement gate remains", "allowsRenewalMovement" not in engine and "allowsTransferMovement" not in engine and "movementCounts" not in engine)
check("Player rollover guarded before season transition journal", "projectedDriverRosterForSeason(targetSeason, targetPlayerTeamId)" in main and "Nenhum dado foi alterado" in main)
check("Career service also validates the projected roster", "projectedDriverRosterForSeason(targetSeason, targetTeamId)" in prefs and "marketContracts" in prefs)
check("Weekly/headless market passes live sporting context", "store.constructorPoints()" in main and "store.driverPoints()" in main and "outgoingTeamMarketPoints" in season_engine and "season.standings" in season_engine)
check("Regression tests cover rollover, competition, and long contracts", all(x in test for x in ["rollover fills AI seats", "never auto fills", "title contender downgrade", "competing offer", "multi-year deals"]))
check("Movement ratio is diagnostic, not a gate", "Diagnostic only" in movement_mix and "quota" in movement_mix and "check(total > 0)" in movement_mix)

failed = 0
for name, ok, detail in checks:
    print(("PASS" if ok else "FAIL") + " | " + name + (f" | {detail}" if detail else ""))
    failed += not ok
print(f"RESULT: {len(checks)-failed}/{len(checks)} static driver-market checks passed")
if failed:
    sys.exit(1)
