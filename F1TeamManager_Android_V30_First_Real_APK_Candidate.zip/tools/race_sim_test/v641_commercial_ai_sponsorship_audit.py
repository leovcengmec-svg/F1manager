#!/usr/bin/env python3
"""Static regression audit for V641 AI facility priorities and sponsorship parity."""
from pathlib import Path
import re
import sys
ROOT = Path(__file__).resolve().parents[2]
FILES = {
    "gradle": ROOT / "app/build.gradle.kts",
    "ai": ROOT / "app/src/main/java/com/f1teammanager/core/manager/AITeamFinancialEngine.kt",
    "sponsor": ROOT / "app/src/main/java/com/f1teammanager/core/manager/TeamSponsorshipEngine.kt",
    "finance": ROOT / "app/src/main/java/com/f1teammanager/core/manager/FinanceEngine.kt",
    "main": ROOT / "app/src/main/java/com/f1teammanager/MainActivity.kt",
    "tests": ROOT / "app/src/test/kotlin/com/f1teammanager/core/manager/CommercialPriorityAndSponsorshipV641Test.kt",
    "changelog": ROOT / "CHANGELOG_V641.md",
}
text = {k: (p.read_text(encoding="utf-8") if p.is_file() else "") for k,p in FILES.items()}
checks=[]
def check(name, ok):
    checks.append((name, bool(ok)))
    print(f"{'PASS' if ok else 'FAIL'} | {name}")

check("V641 versionCode", bool(re.search(r"versionCode\s*=\s*641\b", text["gradle"])))
check("V641 versionName", 'versionName = "0.641.0"' in text["gradle"])
check("V641 changelog present", bool(text["changelog"]))
priority = text["ai"].split("val priority = listOf(",1)[-1].split(")",1)[0] if "val priority = listOf(" in text["ai"] else ""
expected_order = ["RESEARCH", "FACTORY", "MARKETING", "WIND_TUNNEL", "SIMULATOR", "DRIVER_DEVELOPMENT", "SCOUTING"]
positions = [priority.find(f"FacilityType.{v}") for v in expected_order]
check("Scouting is last in facility hierarchy", all(pos >= 0 for pos in positions) and positions == sorted(positions))
check("Commercial minimum is level 3", "const val AI_MIN_COMMERCIAL_LEVEL = 3" in text["ai"] and "marketingLevel < AI_MIN_COMMERCIAL_LEVEL" in text["ai"])
check("Facility ranking uses hierarchy before level", "priority.indexOf(it)" in text["ai"] and "thenBy { current.level(it) }" in text["ai"])
check("Commercial upgrade is moved to front below target", "if (marketingShouldLead && marketingLevel < 10) listOf(FacilityType.MARKETING) + otherCandidates else otherCandidates" in text["ai"])
check("AI initial portfolio chooses offers, not one deterministic sponsor", "chooseAiReplacement(teamId, season, 0, slot, reservedNames)" in text["sponsor"] and "for (slot in 1..5)" in text["sponsor"])
check("AI replacement uses the shared three-offer generator", "generateOffersForSlot(" in text["sponsor"] and "chooseAiReplacement(teamId,season,round,slot,reservedNames)" in text["sponsor"])
check("AI selects offer by expected value", "maxWithOrNull(" in text["sponsor"] and "expectedContractValue(it.sponsor)" in text["sponsor"])
check("Shared generator draws exactly three offers", "take(3)" in text["sponsor"] and "offers.mapIndexed" in text["sponsor"])
check("Player offer function accepts its true active portfolio", "activeSponsorNames:Set<String>?=null" in text["sponsor"])
check("Player Finance passes the actual active sponsorship names", "activeSponsorNames = state.sponsors.filter { it.active && it.racesRemaining > 0 && it.slot != slot }.map { it.name }.toSet()" in text["main"])
check("AI race settlement delegates to shared FinanceEngine", "settleRaceFinance(s.finance, teamId, active, bestFinish, points" in text["ai"])
check("AI signing credits upfront through shared finance rule", "applySponsorshipUpfrontFinance(s.finance, sponsor.upfront" in text["ai"])
check("Regression tests assert AI chooses among same offers", "aiRenewalEvaluatesTheSameThreeOffersThatThePlayerMarketDisplays" in text["tests"])
check("Regression test covers actual player portfolio exclusions", "playerOfferGenerationExcludesItsActualActivePortfolio" in text["tests"])
check("Old single-sponsor path removed", "createSponsor(teamId,season,round,slot" not in text["sponsor"])
failed = [n for n,ok in checks if not ok]
print(f"\nV641 commercial AI/sponsorship audit: {len(checks)-len(failed)}/{len(checks)} passed")
sys.exit(1 if failed else 0)
