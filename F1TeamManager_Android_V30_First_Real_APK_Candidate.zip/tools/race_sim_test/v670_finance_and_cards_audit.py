from pathlib import Path
root = Path(__file__).resolve().parents[2]
policy = (root/'app/src/main/java/com/f1teammanager/core/manager/SeasonInvestmentPolicy.kt').read_text()
ai = (root/'app/src/main/java/com/f1teammanager/core/manager/AITeamFinancialEngine.kt').read_text()
ui = (root/'app/src/main/java/com/f1teammanager/MainActivity.kt').read_text()
gradle = (root/'app/build.gradle.kts').read_text()
checks = {
 '40% next-season car': 'AI_NEXT_SEASON_CAR_PERCENT = 40' in policy,
 '40% current-season car': 'AI_CURRENT_SEASON_CAR_PERCENT = 40' in policy,
 '20% facilities': 'AI_FACILITIES_PERCENT = 20' in policy,
 'next car annual cap': 'aiNextSeasonCarAnnualLimit' in ai,
 'current car allocation enforced': 'remainingAiCurrentCarAllocation(investment)' in ai,
 'facilities allocation enforced': 'remainingAiFacilitiesAllocation(investment)' in ai,
 'next-car cash reserve remains protected': 'val phaseAllocation = SeasonInvestmentPolicy.aiNextCarReserve(cash, round)' in ai,
 'recent result cards enlarged': 'if (veryCompact) 88.dp else if (compact) 100.dp else 112.dp' in ui,
 'version bumped': 'versionCode = 670' in gradle and 'versionName = "0.670.0"' in gradle,
}
for label, ok in checks.items(): print(('PASS' if ok else 'FAIL') + ': ' + label)
print(f'{sum(checks.values())}/{len(checks)} checks passed')
raise SystemExit(0 if all(checks.values()) else 1)
