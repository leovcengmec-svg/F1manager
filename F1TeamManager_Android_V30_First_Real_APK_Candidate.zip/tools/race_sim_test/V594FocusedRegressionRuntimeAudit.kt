package com.f1teammanager.core.manager

import com.f1teammanager.core.race.TyreModel
import com.f1teammanager.core.race.Tyre
import com.f1teammanager.core.race.Weather
import com.f1teammanager.core.season.WorldDatabase

/** Focused runtime regression for the V594 short-rain stint and concurrent-offer fixes. */
fun main() {
    var tyreCases = 0
    listOf(Weather.LIGHT_RAIN, Weather.MEDIUM_RAIN, Weather.HEAVY_RAIN).forEach { weather ->
        (1..3).forEach { remaining ->
            val plans = TyreModel.buildPlansForWeather(remaining, weather)
            check(plans.keys == setOf("A", "B", "C", "D")) { "Missing wet plan ids for $weather/$remaining: ${plans.keys}" }
            plans.values.forEach { plan ->
                check(plan.sequence.size == plan.stintLaps.size) { "Tyre sequence/stint mismatch: $weather/$remaining/${plan.id}" }
                check(plan.stintLaps.sum() == remaining) { "Stints do not cover remaining laps: $weather/$remaining/${plan.stintLaps}" }
                check(plan.stintLaps.all { it >= 1 } && plan.stintLaps.size <= remaining) { "Zero/excess stint generated: $weather/$remaining/${plan.stintLaps}" }
                check(plan.sequence.all { it == Tyre.INTERMEDIATE || it == Tyre.WET }) { "Dry compound in rain plan: $weather/${plan.sequence}" }
            }
            tyreCases++
        }
    }

    val engine = DriverMarketEngine(20261017)
    val initial = engine.initialState(2026)
    val freeDriver = initial.freeAgents.first()
    val teamA = WorldDatabase.teams[0]
    val teamB = WorldDatabase.teams[1]
    val replacementA = engine.roster(initial, teamA.id, season = 2026).first()
    val replacementB = engine.roster(initial, teamB.id, season = 2026).first()
    val (afterA, offerA) = engine.makeOffer(
        initial, freeDriver, teamA.id, 2, engine.salaryFor(freeDriver), DriverTeamRole.EQUAL,
        2026, currentWeek = 56, replaceDriverId = replacementA, proposerTeamId = teamA.id
    )
    val (afterB, offerB) = engine.makeOffer(
        afterA, freeDriver, teamB.id, 2, engine.salaryFor(freeDriver), DriverTeamRole.EQUAL,
        2026, currentWeek = 56, replaceDriverId = replacementB, proposerTeamId = teamB.id
    )
    val ready = afterB.copy(pending = afterB.pending.map { it.copy(interestScore = 100, expiresAfterWeek = 56) })
    val resolved = engine.expireOffers(ready, currentWeek = 56, season = 2026, playerTeamId = Int.MIN_VALUE)
    check(resolved.scheduled.count { it.driverId == freeDriver && it.startSeason == 2027 } == 1) { "Competing offers produced multiple deals: ${resolved.scheduled.filter { it.driverId == freeDriver }}" }
    check(resolved.pending.none { it.driverId == freeDriver && it.seasonTarget == 2027 }) { "Competing proposal remained active after signature" }
    check(resolved.notifications.none { it.title == "PROPOSTA NÃO CONCLUÍDA" && it.message.contains(WorldDatabase.allDrivers.first { d -> d.id == freeDriver }.name) }) { "Stale offer emitted a false failure notice" }
    check(resolved.scheduled.single { it.driverId == freeDriver }.toTeamId in setOf(teamA.id, teamB.id))
    check(offerA.seasonTarget == offerB.seasonTarget)

    println("V594FocusedRegressionRuntimeAudit: PASS | tyreWeatherRemainingCases=$tyreCases | offersTested=2 | futureDealsForDriver=1 | stalePending=0")
}
