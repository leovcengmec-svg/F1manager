#!/usr/bin/env python3
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
main = (ROOT / "app/src/main/java/com/f1teammanager/MainActivity.kt").read_text(encoding="utf-8")
guard = (ROOT / "app/src/main/java/com/f1teammanager/core/race/RaceCalendarGuard.kt").read_text(encoding="utf-8")
test = (ROOT / "app/src/test/java/com/f1teammanager/core/race/RaceCalendarGuardTest.kt").read_text(encoding="utf-8")
rule = (ROOT / "REGRA_NOVA_CARREIRA_A_CADA_ATUALIZACAO.md").read_text(encoding="utf-8")
gradle = (ROOT / "app/build.gradle.kts").read_text(encoding="utf-8")
checks = {
    "version is V602": 'versionCode = 602' in gradle and 'versionName = "0.602.0"' in gradle,
    "official fresh-career development rule exists": "nova carreira iniciada" in rule and "não autoriza apagar saves" in rule,
    "instant action uses calendar guard": "RaceCalendarGuard.validationError(" in main,
    "instant action does not advance weeks": "Instant simulation never advances the calendar" in main and "advanceFreeWeeks(round.weekOfSeason - currentWeek" not in main,
    "instant button only enabled on scheduled week": "enabled = currentWeek == round.weekOfSeason && !weekendInProgress" in main,
    "interactive race uses calendar guard": "val startError = com.f1teammanager.core.race.RaceCalendarGuard.validationError" in main,
    "finalization checks persisted round index": "store.roundIndex == finalizationRound - 1" in main,
    "finalization checks persisted GP week": "store.currentWeek == canonicalRound.weekOfSeason" in main,
    "week skipping cannot cross next scheduled GP": "targetWeek > expectedNextRound.weekOfSeason" in main,
    "week skipping fails closed if scheduled GP already passed": "currentWeek > expectedNextRound.weekOfSeason" in main,
    "week skipping cannot pass an unfinished GP week": "!store.isRaceFinalized(store.season, expectedNextRound.round)" in main,
    "qualifying/race sessions cannot be replaced": "snapshot != null && snapshot?.completed == false" in main,
    "guard tests cover scheduled-week success": "acceptsOnlyTheScheduledWeekForTheCurrentRound" in test,
    "guard tests cover early/late/stale/in-progress cases": all(k in test for k in ("rejectsEarlyInstantSimulation", "rejectsLateInstantSimulation", "rejectsStaleDisplayedRound", "rejectsTryingToStartAnInstantWeekend")),
}
for name, ok in checks.items():
    print(f"{'PASS' if ok else 'FAIL'} | {name}")
print(f"RESULT: {sum(checks.values())}/{len(checks)} checks passed")
if not all(checks.values()):
    raise SystemExit(1)
