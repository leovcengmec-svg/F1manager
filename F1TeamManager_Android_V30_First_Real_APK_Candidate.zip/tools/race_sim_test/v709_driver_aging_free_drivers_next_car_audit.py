#!/usr/bin/env python3
"""V709 regression audit: seven-attribute aging, free agents, next-car investment guard."""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[2]
def read(rel):
    path = ROOT / rel
    return path.read_text(encoding="utf-8") if path.is_file() else ""

gradle = read("app/build.gradle.kts")
manifest = read("package_manifest.txt")
engine = read("app/src/main/java/com/f1teammanager/core/season/DriverEvolutionEngine.kt")
career = read("app/src/main/java/com/f1teammanager/CareerPreferences.kt")
manager = read("app/src/main/java/com/f1teammanager/core/manager/ManagerSeasonEngine.kt")
manager_models = read("app/src/main/java/com/f1teammanager/core/manager/ManagerModels.kt")
car = read("app/src/main/java/com/f1teammanager/core/manager/CarDevelopmentEngine.kt")
main = read("app/src/main/java/com/f1teammanager/MainActivity.kt")
market = read("app/src/main/java/com/f1teammanager/core/manager/DriverMarketEngine.kt")
cycle_test = read("app/src/test/kotlin/com/f1teammanager/core/season/DriverCareerCycleV709Test.kt")
free_test = read("app/src/test/kotlin/com/f1teammanager/core/season/FreeDriverNaturalGrowthV709Test.kt")
car_test = read("app/src/test/kotlin/com/f1teammanager/core/manager/NextSeasonCarGrowthLimitV709Test.kt")

checks = []
def ck(name, ok):
    checks.append((name, bool(ok)))

ck("versionCode and versionName are V709", "versionCode = 709" in gradle and 'versionName = "0.709.0"' in gradle)
ck("package manifest matches V709 and retains official ZIP filename", "Version: 709 / 0.709.0" in manifest and "F1TeamManager_Android_V30_First_Real_APK_Candidate.zip" in manifest and "Base: V708 / 0.708.0" in manifest)
ck("natural aging selects the complete seven-attribute vector", "AGE_ATTRIBUTE_INDICES: IntArray = IntArray(7) { it }" in engine)
ck("age regression and loss recovery both iterate all seven indices", "AGE_ATTRIBUTE_INDICES.filter { values[it] > 40 }" in engine and "AGE_ATTRIBUTE_INDICES.forEach { index ->" in engine and "AGE_CYCLE_RECOVERY_RATE = 0.50" in engine)
ck("legacy save ledger names are retained with seven-value vectors", "agePhysicalLosses: IntArray = IntArray(7)" in engine and "agePhysicalPeaks: IntArray = IntArray(7)" in engine and "driverAgePhysicalLosses" in manager_models and "driverAgePhysicalPeaks" in manager_models)
ck("free-driver progress uses neutral index and can bypass class ceiling up to potential", "FREE_DRIVER_NEUTRAL_PERFORMANCE_INDEX = 105.0" in engine and "allowNaturalGrowthBeyondClassCeiling = true" in engine and "driver.potentialOverall.coerceIn(40, 100)" in engine and "bypassClassCeiling = allowNaturalGrowthBeyondClassCeiling" in engine)
ck("negative sporting bank is cleared on free-agent entry while positive bank is preserved", "currentBank = currentBank.coerceAtLeast(0.0)" in engine)
ck("career and Team Principal both route uncontracted drivers through free-driver progression", "applyFreeDriverTick(" in career and "applyFreeDriverTick(" in manager and "if (id !in activeDriverIds)" in career and "val tick = if (base.id in active)" in manager)
ck("free drivers are still eligible for AI market evaluation and recruitment", "freeAgents(s)" in market and "currentDriverOverall(candidate, driverAttributes)" in market and "highPotentialBet" in market)
ck("news explicitly separates sporting, natural growth, aging and cycle recovery", all(token in engine for token in ["desenvolvimento natural", "desempenho abaixo das expectativas", "declínio natural da idade", "recuperação parcial do ciclo"]) and "describeTickCauses" in career and "describeTickCauses" in manager)
ck("news includes all seven attribute labels", all(f'"{label}"' in engine for label in ["VEL", "CLA", "ULT", "DEF", "CON", "CHU", "PNE"]))
ck("next-car forecast calculates annual Overall ceiling and exact target investment", "NextSeasonCarGrowthPolicy.maximumGain(overall)" in car and "targetInvestment = referenceInvestmentForOverall(maximumAllowedOverall)" in car and "remainingToTarget" in car and "goalReached" in car)
ck("financial engine rejects investment after the Overall target and rejects excess amount", "require(!forecast.goalReached && forecast.remainingToTarget > 0L)" in car and "require(amount <= room)" in car)
ck("next-car UI disables buttons at target and limits button amount to remaining goal/cash", "val investmentLocked = goalReached || annualRoom <= 0L" in main and "minOf(it, availableForGoal)" in main and "enabled = !investmentLocked && amount > 0L && amount <= availableForGoal" in main)
ck("all V709 regression tests are present", all([cycle_test, free_test, car_test]))
ck("free-agent tests cover potential ceiling and inherited negative bank", "pass the Médio class ceiling 69" in free_test and "never inherits negative sporting regression" in free_test)
ck("seven-attribute aging test asserts each of the seven attributes", all(f'losses[{i}] > 0' in cycle_test for i in range(7)))
ck("investment tests cover €31M for Overall 46 to 53, no overpayment and final exact contribution", all(token in car_test for token in ["31_000_000L", "overall 46 target 53", "1_000_000L", "2_000_000L"]))
ck("release notes, stabilization audit and detailed audit exist", all((ROOT / f).is_file() for f in ["CHANGELOG_V709.md", "AUDIT_V709_STABILIZATION.md", "AUDIT_V709_DRIVER_AGING_FREE_DRIVERS_NEXT_CAR.md"]))

for name, ok in checks:
    print(("PASS" if ok else "FAIL") + " | " + name)
failed = [name for name, ok in checks if not ok]
print(f"RESULT: {len(checks)-len(failed)}/{len(checks)} V709 source checks passed")
if failed:
    sys.exit(1)
