#!/usr/bin/env python3
"""Source-level regression audit for player-scoped market and P&D Home events in V686."""
from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[2]
def read(path): return (ROOT / path).read_text(encoding="utf-8")
models = read("app/src/main/java/com/f1teammanager/core/manager/DriverMarketModels.kt")
policy = read("app/src/main/java/com/f1teammanager/core/manager/PlayerHomeNotificationPolicy.kt")
engine = read("app/src/main/java/com/f1teammanager/core/manager/DriverMarketEngine.kt")
main = read("app/src/main/java/com/f1teammanager/MainActivity.kt")
prefs = read("app/src/main/java/com/f1teammanager/CareerPreferences.kt")
gradle = read("app/build.gradle.kts")
workflow = read(".github/workflows/android-apk.yml")
manifest = read("package_manifest.txt")
test = read("app/src/test/kotlin/com/f1teammanager/core/manager/PlayerHomeNotificationsV686Test.kt")
checks = {
    "V686 app and package metadata": 'versionCode = 686' in gradle and 'versionName = "0.686.0"' in gradle and "Version: 686 / 0.686.0" in manifest,
    "MarketNotification stores the involved team ID": "val relatedTeamId: Int? = null" in models,
    "legacy and seven-column notification saves load": "row.split('|', limit=7)" in prefs and 'it.relatedTeamId ?: ""' in prefs,
    "player-only policy includes proposal, counter, rejection and expiry stages": all(x in policy for x in ["PROPOSTA ENVIADA", "PROPOSTA RECEBIDA", "PROPOSTA RECUSADA", "PROPOSTA NÃO CONCLUÍDA", "OFERTA EXPIRADA", "CONTRAPROPOSTA ENVIADA", "CONTRAPROPOSTA RECEBIDA", "CONTRAPROPOSTA DA EQUIPE", "CONTRAPROPOSTA RECUSADA", "NEGOCIAÇÃO ENCERRADA", "RENOVAÇÃO DE CONTRATO", "CONTRATO ASSINADO", "TRANSFERÊNCIA CONFIRMADA", "TRANSFERÊNCIA CANCELADA"]),
    "market engine tags player-related offer and response events": all(x in engine for x in ["relatedTeamId = playerTeamId?.takeIf", '"CONTRAPROPOSTA RECEBIDA"', '"PROPOSTA RECUSADA"', '"CONTRAPROPOSTA RECUSADA"', '"OFERTA EXPIRADA"', '"CONTRAPROPOSTA ENVIADA"']),
    "player callbacks propagate playerTeamId": all(x in main for x in ["playerTeamId = team.id", "rejectIncomingOffer(managerState.driverMarket, offer, store.season, currentWeek, team.id)", "rejectCounterOffer(managerState.driverMarket, offer, store.season, currentWeek, team.id)"]),
    "Home popup and badges scope events to player and route negotiation cards to Market": all(x in main for x in ["isPlayerMarketEvent(notice, teamId, team)", "isPlayerResearchEvent(notice, teamId, team)", "isPlayerMarketEvent(event, teamId, team) || isMarketWindowOpening -> onMarket()", 'MERCADO $marketResponseCount']),
    "P&D failure uses explicit outcome and actual completion week": all(x in policy for x in ["it.outcome == ResearchOutcome.FAILURE", "it.remainingWeeks.coerceAtLeast(1) <= elapsedWeeks", "currentWeek + project.remainingWeeks", 'title = "FALHA NO P&D — DESIGN NÃO CONCLUÍDO"']) and "failedResearchNotices(" in main,
    "P&D event notifications carry player team ID": "relatedTeamId = teamId" in main and "relatedTeamId = playerTeamId" in policy,
    "atomic weekly save persists notification-bearing market state": "updatedManagerState.driverMarket" in main and "driverMarketEditor(e, driverMarket)" in prefs,
    "unit tests cover player-only negotiation stages and P&D failures": all(x in test for x in ["all player negotiation stages", "player proposal and counterproposal", "incoming offer expiry and player rejection", "P and D failure", "legacy market notifications"]),
    "GitHub Actions runs V686 audit and publishes V686 APK": "v686_player_home_notifications_audit.py" in workflow and "V686-debug-apk" in workflow,
    "V686 changelog and audit report exist": (ROOT / "CHANGELOG_V686.md").is_file() and (ROOT / "AUDIT_V686_PLAYER_HOME_NEGOTIATIONS_AND_PD.md").is_file(),
}
for label, ok in checks.items(): print(("PASS" if ok else "FAIL") + " | " + label)
failed = sum(not ok for ok in checks.values())
print(f"RESULT: {len(checks)-failed}/{len(checks)} V686 source checks passed")
sys.exit(1 if failed else 0)
