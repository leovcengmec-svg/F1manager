package com.f1teammanager.core.manager

import com.f1teammanager.core.season.WorldDatabase

fun main() {
    val team = WorldDatabase.teams.first()
    val levels = TeamFacilitiesState(FacilityType.values().associateWith { 0 })
    val engine = AITeamFinancialEngine(seed = 73_232)
    engine.adoptFormerPlayerTeam(
        teamId = team.id,
        season = 2028,
        finance = TeamFinanceState(budget = 500_000_000L, seasonIncome = 100_000_000L, seasonExpenses = 20_000_000L),
        teamFacilities = levels
    )
    for (week in 1..80) {
        engine.advanceFacilityDevelopment(team.id, 2028, week, currentOverall = 62)
    }
    val after = engine.facilities(team.id)
    val upgraded = FacilityType.values().filter { after.level(it) > 0 }
    check(upgraded.size >= 4) { "Facilities did not diversify: ${FacilityType.values().associateWith { after.level(it) }}" }
    check(after.level(FacilityType.RESEARCH) < 10)
    check(after.level(FacilityType.FACTORY) > 0)
    check(after.level(FacilityType.WIND_TUNNEL) > 0)
    check(engine.state(team.id, 2028).finance.budget >= 0L)
    check(engine.remainingTechnicalBudget(team.id, 2028) >= 0L)
    println("V732 FACILITY DIVERSITY PASS: ${FacilityType.values().associate { it.name to after.level(it) }}; cash=${engine.state(team.id, 2028).finance.budget}; technicalRoom=${engine.remainingTechnicalBudget(team.id, 2028)}")
}
