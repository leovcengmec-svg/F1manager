#!/usr/bin/env python3
"""Source-level regression audit for the V651 sponsorship AI decision model."""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[2]
engine = (ROOT / 'app/src/main/java/com/f1teammanager/core/manager/TeamSponsorshipEngine.kt').read_text(encoding='utf-8')
gradle = (ROOT / 'app/build.gradle.kts').read_text(encoding='utf-8')
test = (ROOT / 'app/src/test/kotlin/com/f1teammanager/core/manager/SponsorshipAiDecisionV651Test.kt').read_text(encoding='utf-8')
legacy_market_test = (ROOT / 'app/src/test/kotlin/com/f1teammanager/core/manager/CommercialPriorityAndSponsorshipV641Test.kt').read_text(encoding='utf-8')

checks = []
def ck(label, condition):
    checks.append((label, bool(condition)))

ck('versionCode/versionName are V651', 'versionCode = 651' in gradle and 'versionName = "0.651.0"' in gradle)
ck('AI selects from the generated three-offer set', 'selectBestAiSponsorOffer(offers, teamStrengthRank(teamId))' in engine)
ck('Guaranteed total weight is 35%', '* 0.35' in engine and 'm.guaranteedTotal' in engine)
ck('Guaranteed return per GP weight is 30%', '* 0.30' in engine and 'm.guaranteedPerGp' in engine)
ck('Expected bonus value weight is 20%', '* 0.20' in engine and 'm.expectedBonusTotal' in engine)
ck('Renegotiation flexibility weight is 15%', '* 0.15' in engine and 'm.flexibility' in engine)
ck('Qualifying bonus probability uses target window and team ranking', 'qualifyingTargetMin' in engine and 'expectedPosition' in engine and 'Math.PI' in engine)
ck('Race bonus probability uses target position and team ranking', 'sponsor.raceTarget - expectedPosition' in engine and '1.702' in engine)
ck('Points bonus remains excluded from the AI expectation model', 'pointsBonus' not in engine[engine.index('internal fun expectedSponsorBonusPerGp'):engine.index('private fun teamStrengthRank')])
ck('Offer generation and active-brand exclusions remain intact', '.filterNot { it.name in active }' in engine and 'take(3)' in engine)
ck('No persistence schema change', '"@V356|"' in engine and 'listOf(s.name,s.upfront,s.racePayment' in engine)
ck('Regression tests cover short and long contract choices', 'higherReturnInLessTimeCanBeatTheLongestContract' in test and 'longerContractStillWinsWhenItsTotalAndPerGpReturnsAreClearlySuperior' in test)
ck('Bonus feasibility tests are present', 'bonusEstimateRewardsTargetsAlignedWithTeamStrength' in test and 'rankingDoesNotTreatAZeroBonusOfferAsHavingARealizedBonus' in test and 'raceBonusProbabilityReflectsTheTeamsExpectedPosition' in test)
ck('Market parity regression is updated for V651 scoring', 'selectBestAiSponsorOffer(visibleOffers, teamRank)' in legacy_market_test)
ck('V651 changelog and audit are present', (ROOT / 'CHANGELOG_V651.md').is_file() and (ROOT / 'AUDIT_V651_SPONSORSHIP_AI.md').is_file())

for label, ok in checks:
    print(('PASS' if ok else 'FAIL') + ' | ' + label)
failed = sum(not ok for _, ok in checks)
print(f'RESULT: {len(checks)-failed}/{len(checks)} V651 sponsorship checks passed')
sys.exit(1 if failed else 0)
