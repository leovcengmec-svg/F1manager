#!/usr/bin/env python3
"""V652 source-level audit for AI finance, facility priorities and next-car continuity."""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[2]
AI = (ROOT / 'app/src/main/java/com/f1teammanager/core/manager/AITeamDevelopmentEngine.kt').read_text(encoding='utf-8')
FIN = (ROOT / 'app/src/main/java/com/f1teammanager/core/manager/AITeamFinancialEngine.kt').read_text(encoding='utf-8')
CAR = (ROOT / 'app/src/main/java/com/f1teammanager/core/manager/CarDevelopmentEngine.kt').read_text(encoding='utf-8')
CLOSURE = (ROOT / 'app/src/main/java/com/f1teammanager/core/manager/FinancialSeasonClosureEngine.kt').read_text(encoding='utf-8')
MAIN = (ROOT / 'app/src/main/java/com/f1teammanager/MainActivity.kt').read_text(encoding='utf-8')
MANAGER = (ROOT / 'app/src/main/java/com/f1teammanager/core/manager/ManagerSeasonEngine.kt').read_text(encoding='utf-8')
GRADLE = (ROOT / 'app/build.gradle.kts').read_text(encoding='utf-8')
TEST = (ROOT / 'app/src/test/kotlin/com/f1teammanager/core/manager/AITeamInvestmentV652Test.kt').read_text(encoding='utf-8')
SPONSOR = (ROOT / 'app/src/main/java/com/f1teammanager/core/manager/TeamSponsorshipEngine.kt').read_text(encoding='utf-8')

checks = []
def ck(name, ok):
    checks.append((name, bool(ok)))

ck('Internal version is V652', 'versionCode = 652' in GRADLE and 'versionName = "0.652.0"' in GRADLE)
ck('Current-season cash capacity has its own immutable variable', 'val currentSeasonStartingBudget = startingBudget.coerceAtLeast(0L)' in AI)
ck('Historical replay uses a separate canonical budget', 'var historicalSeasonBudget = InitialTeamProfile.initialBudget(team)' in AI and 'simulatePhysicalSeason(team, garage, 56, s, historicalSeasonBudget' in AI)
ck('Historical replay no longer overwrites current-season capacity', 'budget = InitialTeamProfile.initialBudget(team)' not in AI and 'simulatePhysicalSeason(team, garage, weeks, season, currentSeasonStartingBudget' in AI)
ck('Pre-2026 return preserves caller-supplied capacity', 'SimulatedState(legacy, currentSeasonStartingBudget, garage' in AI)
ck('Factory quantity can fall back from two units to one', 'selectAffordableFactoryQuantity(' in AI and 'desired downTo 1' in AI)
ck('Planned physical quantity is preserved through design completion', 'researchPlannedQuantity = plannedQuantity' in AI and 'researchPlannedQuantity.coerceIn(1, 2)' in AI)
ck('Factory affordability includes the current design cost in the annual cap', 'technicalSpent = technicalSpent + cost' in AI)
ck('Factory quantity is revalidated at design completion', 'desiredQuantity = plannedQuantity' in AI and 'factoryQuantity = actualQuantity' in AI)
ck('Research complexity follows current physical Overall', 'chooseResearchComplexity(currentOverall, state.budget)' in AI)
ck('Factory speed follows current physical Overall', 'factoryWeeks(if (state.garage.teamAverageOverall >= 70) 1 else 2' in AI)
ck('AI facility strategy has no mandatory commercial-center gate', 'shouldPrioritizeCommercialCenter' not in FIN and 'val candidates = priority.filter' in FIN)
ck('Technical recovery priority responds to competitive decline', 'competitiveDecline.coerceAtMost(15) * 3' in FIN and 'competitiveDecline >= 5 -> 58 - level * 4' in FIN)
ck('AI facility planning protects salary and maintenance liabilities', 'salaryOutstanding.values.sumOf' in FIN and 'facilityMaintenanceOutstanding.values.sumOf' in FIN)
ck('AI facility planning protects the next-car contribution', 'carFundingReserve' in FIN and 'plannedNextCarContribution(' in FIN)
ck('Actual team operating cost is used in AI cash reserve', 'aiOperatingReserve(annualSalaries, round, RaceOperatingCost.forTeam(teamId))' in FIN)
ck('AI continuity floor scales with funded maintenance', 'aiContinuityFloorOverall(previousOverall: Int, invested: Long)' in CAR and 'coverage = (invested.coerceAtLeast(0L).toDouble() / maintenanceFunding.toDouble()).coerceIn(0.0, 1.0)' in CAR)
ck('Physical AI next-car builder receives continuity floor', 'minimumOverall = development.aiContinuityFloorOverall(garage.teamAverageOverall, invested)' in AI)
ck('Legacy AI next-car builder receives continuity floor', 'minimumOverall = aiContinuityFloorOverall(carOverall(old), invested)' in CAR)
ck('Canonical financial penalty applies to all six physical components', all(x in CLOSURE for x in ['physical(c, CarComponent.ENGINE', 'physical(c, CarComponent.CHASSIS', 'physical(c, CarComponent.FRONT_WING', 'physical(c, CarComponent.REAR_WING', 'physical(c, CarComponent.BRAKES', 'physical(c, CarComponent.ELECTRIC_POWER_UNIT']))
ck('AI historical penalty uses canonical garage penalty in both replay paths', AI.count('FinancialSeasonClosureEngine.applyGaragePenalty(') >= 2 and 'private fun applyGaragePenalty' not in AI)
ck('Main career passes actual AI Overall and driver market to facility policy', 'currentAiOverall, managerState.driverMarket' in MAIN)
ck('Team Principal path passes actual AI Overall and driver market', 'week, currentAiOverall, next.driverMarket' in MANAGER)
ck('Team Principal replay carries the saved next-car investment history', 'aiFinance.nextSeasonInvestmentsForTeam(aiTeam.id)' in MANAGER[MANAGER.index('val afterAi = aiDevelopment.simulateFinancial'):MANAGER.index('aiFinance.setFacilities(aiTeam.id, afterAi.facilities)')])
ck('V651 sponsor model remains in source', 'selectBestAiSponsorOffer(offers, teamStrengthRank(teamId))' in SPONSOR and '* 0.35' in SPONSOR and '* 0.30' in SPONSOR)
ck('Seven regression tests are included for V652', TEST.count('@Test fun ') >= 7)
ck('Legacy commercial-gate tests now assert the V652 adaptive policy', 'aiPrioritizesTechnicalRecoveryBeforeCommercialExpansion' in (ROOT / 'app/src/test/kotlin/com/f1teammanager/core/manager/CommercialPriorityAndSponsorshipV641Test.kt').read_text(encoding='utf-8') and 'aiUsesAffordableTechnicalUpgradeWhenCommercialExpansionWouldBreakItsReserve' in (ROOT / 'app/src/test/kotlin/com/f1teammanager/core/manager/CommercialPriorityAndSponsorshipV642Test.kt').read_text(encoding='utf-8') and 'aiPrioritizesTechnicalBaseAndKeepsOperatingReserveBeforeCommercialExpansion' in (ROOT / 'app/src/test/kotlin/com/f1teammanager/core/manager/SponsorshipAndCommercialAI_V619Test.kt').read_text(encoding='utf-8'))
ck('Factory-cap regression reserves the design cost before choosing quantity', 'factoryQuantityAccountsForTheResearchCostAlreadyReserved' in TEST)
ck('Release notes and audit are retained', (ROOT / 'CHANGELOG_V652.md').is_file() and (ROOT / 'AUDIT_V652_AI_INVESTMENTS.md').is_file())

# Deterministic numeric assertions for the documented continuity policy.
def floor(previous, invested, maintenance):
    coverage = max(0.0, min(1.0, max(0, invested) / max(1, maintenance)))
    drop = int(__import__('math').ceil(8.0 * (1.0 - coverage)))
    return max(1, max(0, min(100, previous)) - drop)
ck('Continuity floor: Overall 90 with €0 => 82', floor(90, 0, 114_000_000) == 82)
ck('Continuity floor: Overall 90 with €45M => 85', floor(90, 45_000_000, 114_000_000) == 85)
ck('Continuity floor: full maintenance funding preserves 90', floor(90, 114_000_000, 114_000_000) == 90)

for name, ok in checks:
    print(('PASS' if ok else 'FAIL') + ' | ' + name)
failed = sum(not ok for _, ok in checks)
print(f'RESULT: {len(checks)-failed}/{len(checks)} V652 checks passed')
sys.exit(1 if failed else 0)
