#!/usr/bin/env python3
"""Static integrity audit for F1 Team Manager. No third-party packages required."""
from pathlib import Path
import re, sys, xml.etree.ElementTree as ET
ROOT = Path(__file__).resolve().parents[2]
checks=[]
def check(name, ok, detail=''):
    checks.append((name, bool(ok), detail))
def read(rel):
    p=ROOT/rel
    return p.read_text(encoding='utf-8') if p.is_file() else ''
# Project essentials
check('Android manifest exists', (ROOT/'app/src/main/AndroidManifest.xml').is_file())
manifest=read('app/src/main/AndroidManifest.xml')
try:
    root=ET.fromstring(manifest)
    ns={'a':'http://schemas.android.com/apk/res/android'}
    app=root.find('application')
    launcher=any(x.attrib.get('{http://schemas.android.com/apk/res/android}name')=='.MainActivity' and x.attrib.get('{http://schemas.android.com/apk/res/android}exported')=='true' for x in app.findall('activity')) if app is not None else False
    check('Manifest XML parses', True)
    check('Launcher activity exported', launcher)
except Exception as e:
    check('Manifest XML parses', False, str(e))
gradle=read('app/build.gradle.kts')
version_code_match = re.search(r'versionCode\s*=\s*(\d+)\b', gradle)
version_name_match = re.search(r'versionName\s*=\s*"([^"]+)"', gradle)
current_version_code = int(version_code_match.group(1)) if version_code_match else -1
current_version_name = version_name_match.group(1) if version_name_match else ''
check('Version code metadata is readable', current_version_code > 0)
check('Version name matches version code', current_version_name == f'0.{current_version_code}.0')
check('Java 17 configured', 'JavaVersion.VERSION_17' in gradle)
# Annual-event engine integration contracts
engine=read('app/src/main/java/com/f1teammanager/core/manager/AnnualTeamEventEngine.kt')
calendar=read('app/src/main/java/com/f1teammanager/core/manager/AnnualTeamEventSeasonCalendar.kt')
main=read('app/src/main/java/com/f1teammanager/MainActivity.kt')
prefs=read('app/src/main/java/com/f1teammanager/CareerPreferences.kt')
checks_contracts={
 'All annual event kinds exist': all(x in engine for x in ['INVESTOR_ACQUISITION','FINANCIAL_CRISIS','CAR_GAIN','CAR_LOSS','RELIABILITY_GAIN','RELIABILITY_LOSS','FIRE','EARTHQUAKE','FACILITY_UPGRADE','DRIVER_GAIN','DRIVER_LOSS','DRIVER_CLASS_CHANGE']),
 'Calendar bounds weeks 1–56': ('1..56' in calendar),
 'Multi-week advancement iterates each week': 'for (eventWeek in (currentWeek + 1)..targetWeek)' in main,
 'Annual events only on ordinary weekly path': 'canApplyWeeklyEvent(store.season, eventWeek' in main,
 'Annual events enter central news category': 'MarketNewsCategory.ANNUAL_EVENTS' in main,
 'Central news label exists': 'ANNUAL_EVENTS to "EVENTOS ANUAIS"' in main,
 'Processed event ledger persisted': 'commitAnnualDriverStateAndKeys' in main and 'processedAnnual' in prefs.lower() or 'annualEventKeys' in prefs,
 'Investor target eligibility checked before weighting': 'eligibleTeams = orderedTeams.filter' in engine and 'eligibleTeams.isEmpty()' in engine,
 'Acquisition requires two facilities below max': 'count { (snapshot.facilities[it] ?: 0) < 10 } >= 2' in engine,
 'Acquisition adds 100m': '100_000_000L' in engine,
 'Budget crisis capped and nonnegative': 'coerceAtMost(100_000_000L)' in engine and '(s.budget-loss).coerceAtLeast(0L)' in engine,
 'Blank car performance stays zero while reliability remains bounded': 'fun eventValue(value: Int): Int = if (value <= 0) 0 else (value + delta).coerceIn(1,100)' in engine and 'engine=engine.coerceIn(0,100)' in read('app/src/main/java/com/f1teammanager/core/manager/ManagerModels.kt'),
 'Facility damage never below zero': 'coerceAtLeast(0)' in engine,
 'Driver events require seven attributes': 'currentAttributes.size != 7' in engine,
 'P&D / factory / garage / finance committed in one engineering bundle': 'fun saveEngineeringBundle(' in prefs and 'return e.commit()' in prefs and 'saveEngineeringBundle(teamId, updated.research, updated.factory' in main,
 'Physical zero preserved by season projection': 'componentValue(component)) / 2.0).toInt().coerceIn(0,100)' in read('app/src/main/java/com/f1teammanager/core/manager/ManagerSeasonEngine.kt'),
 'Season V0 exists only for components that have installed hardware': 'car.installedPieces.keys.associateWith { 0 }' in read('app/src/main/java/com/f1teammanager/core/manager/ManagerSeasonEngine.kt') and 'car.installedPieces.keys.associateWith { 0 }' in main and '(car.installedPieceVersions[c] ?: 1).coerceAtLeast(0)' in prefs,
 'Player and AI start at team performance with piece V0': 'playerCareer: Boolean = false' in read('app/src/main/java/com/f1teammanager/core/manager/CarGarageModels.kt') and 'val performance = openingValues' in read('app/src/main/java/com/f1teammanager/core/manager/CarGarageModels.kt') and 'installedPieceVersions = installed.keys.associateWith { 0 }' in read('app/src/main/java/com/f1teammanager/core/manager/CarGarageModels.kt') and 'InitialTeamProfile.aiCarState(aiTeam)' in main and 'playerCareer = true' in prefs,
 'Fresh career core is saved atomically': 'saveFreshCareerCore(' in prefs and 'return e.commit()' in prefs and 'saveFreshCareerCore(' in prefs[prefs.find('fun startNewCareer'):],
 'Weekly advancement persists one career bundle': 'saveCareerStepBundle(teamId, updatedManagerState.car, finalGarage' in main,
 'Facility upgrades commit their full related state atomically': 'saveCareerStepBundle(' in main[main.find('fun upgradeFacility'):main.find('LaunchedEffect(recoveredPendingRace')],
 'Current season release notes exist': (ROOT/f'CHANGELOG_V{current_version_code}.md').is_file(),
 'Existing source-level regression tests present': (ROOT/'app/src/test/java/com/f1teammanager/core/manager/V285AnnualEventIntegrationContractTest.kt').is_file(),
 'Comprehensive Kotlin runtime audit source present': (ROOT/'tools/race_sim_test/AnnualEventComprehensiveAudit.kt').is_file(),
 'No duplicate test class declarations': len([name for name, paths in __import__('collections').Counter(re.findall(r'\\bclass\\s+(\\w+)', '\\n'.join(p.read_text(encoding='utf-8', errors='ignore') for p in (ROOT/'app/src/test').rglob('*.kt')))).items() if paths > 1]) == 0,
}
for n,ok in checks_contracts.items(): check(n,ok)
# Package inventory and preservation signals
assets=ROOT/'app/src/main/assets'
asset_files=[p for p in assets.rglob('*') if p.is_file()] if assets.exists() else []
check('External/local assets directory populated', len(asset_files)>=150, f'{len(asset_files)} files')
for sub in ['drivers','car_assets','teams','circuits','annual_events']:
    hits=[p for p in asset_files if sub.lower() in str(p.relative_to(assets)).lower()]
    check(f'Asset family {sub} present', len(hits)>0, f'{len(hits)} matching files')
check('Version history retained', len(list(ROOT.glob('*V*.md')))>=50, f'{len(list(ROOT.glob("*V*.md")))} root history/audit docs')
check('V286 audit preserved', (ROOT/'AUDIT_V286.md').is_file())
check('V288 audit and changelog present', (ROOT/'AUDIT_V288.md').is_file() and (ROOT/'CHANGELOG_V288.md').is_file())
failed=0
for name,ok,detail in checks:
    print(('PASS' if ok else 'FAIL')+' | '+name+((' | '+detail) if detail else ''))
    failed += not ok
print(f'RESULT: {len(checks)-failed}/{len(checks)} checks passed')
sys.exit(1 if failed else 0)
