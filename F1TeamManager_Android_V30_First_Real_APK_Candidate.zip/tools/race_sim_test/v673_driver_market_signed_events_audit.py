from pathlib import Path
root = Path(__file__).resolve().parents[2]
engine = (root/'app/src/main/java/com/f1teammanager/core/manager/DriverMarketEngine.kt').read_text()
main = (root/'app/src/main/java/com/f1teammanager/MainActivity.kt').read_text()
gradle = (root/'app/build.gradle.kts').read_text()
workflow = (root/'.github/workflows/android-apk.yml').read_text()
checks = {
 'version 673': 'versionCode = 673' in gradle and 'versionName = "0.673.0"' in gradle,
 'AI signed contract event': 'if (isRenewal) "RENOVAÇÃO DE CONTRATO" else "CONTRATO ASSINADO"' in engine,
 'AI preseason signature standardized': '"CONTRATO ASSINADO"' in engine and 'CONTRATO ACEITO NA PRÉ-TEMPORADA' not in engine,
 'global signed and renewal cards': 'title in setOf("RENOVAÇÃO DE CONTRATO", "CONTRATO ASSINADO", "CONTRATO FECHADO")' in main,
 'negotiation popup excluded': 'title in setOf("CONTRAPROPOSTA RECEBIDA", "CONTRAPROPOSTA DA EQUIPE", "CONTRAPROPOSTA ACEITA", "CONTRAPROPOSTA RECUSADA") &&' not in main,
 'home response summary only signed events': 'state.notifications.filter { it.season == store.season && it.title.trim().uppercase(Locale.ROOT)' in main and 'CONTRATO ASSINADO", "CONTRATO FECHADO")' in main,
 'artifact label V673': 'F1-Team-Manager-V30-V673-debug-apk' in workflow,
 'release docs': (root/'CHANGELOG_V673.md').is_file() and (root/'AUDIT_V673_DRIVER_MARKET_SIGNED_EVENTS.md').is_file(),
 'zip naming manifest preserved': 'F1TeamManager_Android_V30_First_Real_APK_Candidate.zip' in (root/'package_manifest.txt').read_text(),
}
for name, ok in checks.items(): print(('PASS' if ok else 'FAIL') + ' - ' + name)
print(f'RESULT: {sum(checks.values())}/{len(checks)} checks passed')
raise SystemExit(0 if all(checks.values()) else 1)
