package com.f1teammanager.core.season

import com.f1teammanager.core.manager.DriverMarketEngine
import com.f1teammanager.core.manager.DriverMarketCatalogMigrationV560
import com.f1teammanager.core.manager.DriverTeamRole

/** Reproduces catalog edits after a long-lived market engine has already been created. */
fun main() {
    CustomWorldCatalog.pilots = emptyList()
    CustomWorldCatalog.teams = emptyList()
    val engine = DriverMarketEngine(5792026) // deliberately predates the new catalog records

    CustomWorldCatalog.pilots = listOf(
        CustomWorldCatalog.Pilot(101, "Piloto Custom A", "Brasil", "Médio", "Normal", 75, 74, 73, 72, 71, 70, 72, 41),
        CustomWorldCatalog.Pilot(102, "Piloto Custom B", "Brasil", "Médio", "Normal", 74, 73, 72, 71, 70, 69, 71, 41),
        CustomWorldCatalog.Pilot(103, "Agente Livre Custom", "Portugal", "Forte", "Normal", 78, 77, 76, 75, 74, 73, 75, 0)
    )
    CustomWorldCatalog.teams = listOf(
        CustomWorldCatalog.Team(41, "Equipe Custom V579", "Brasil", 101, 102, "equipe-41.png")
    )

    val worldDrivers = WorldDatabase.allDrivers
    val worldTeams = WorldDatabase.teams
    check(worldTeams.size == 41) { "Catalog edit did not expand team list: ${worldTeams.size}" }
    check(worldDrivers.any { it.id == 103 && it.teamId == 0 }) { "New free pilot missing from live catalog" }

    // Market is created from the new catalog, but its engine object predates the catalog edit.
    val initial = engine.initialState(2026)
    val migration = DriverMarketCatalogMigrationV560(engine).migrateAgainstCatalog(
        source = initial,
        season = 2026,
        catalogDrivers = worldDrivers,
        catalogTeams = worldTeams
    )
    val migrated = migration.state
    check(migrated.contracts.count { it.teamId == 41 && it.driverId in setOf(101, 102) } == 2) {
        "Custom team's two declared drivers were not contracted to that team"
    }
    check(103 in migrated.freeAgents) { "New free pilot was not reconciled into the market" }

    val openWeek = com.f1teammanager.core.season.SeasonCalendar.forSeason(2026).maxOf { it.weekOfSeason }
    val (afterOffer, offer) = engine.makeOffer(
        state = migrated,
        driverId = 103,
        toTeamId = 41,
        years = 1,
        salary = 1_000_000L,
        role = DriverTeamRole.EQUAL,
        season = 2026,
        currentWeek = openWeek,
        replaceDriverId = 101
    )
    check(offer.driverId == 103 && offer.toTeamId == 41) { "Long-lived market engine rejected the newly added pilot" }
    check(afterOffer.pending.any { it.driverId == 103 && it.toTeamId == 41 }) { "Offer for the new pilot was not persisted in market state" }

    check(ChampionshipGridRules.gridSize(40) == 80)
    check(ChampionshipGridRules.targetPosition(40, 0, 40) == 79)
    check(ChampionshipGridRules.targetPosition(40, 1, 40) == 80)
    check(ChampionshipGridRules.sponsorTargetRange(40, 40) == 77..80)
    check(ChampionshipGridRules.gridSize(worldTeams.size) == 82)
    check(ChampionshipGridRules.targetPosition(41, 0, worldTeams.size) == 81)
    check(ChampionshipGridRules.targetPosition(41, 1, worldTeams.size) == 82)
    check(ChampionshipGridRules.sponsorTargetRange(41, worldTeams.size) == 79..82)
    println("CatalogLiveMarketAuditV579: PASS | teams=41 | grid=82 | customPilots=101,102 | freePilot=103 | existingEngineAcceptedNewPilot=true")
}
