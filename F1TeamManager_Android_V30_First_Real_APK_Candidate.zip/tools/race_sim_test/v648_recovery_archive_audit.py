#!/usr/bin/env python3
"""Static regression audit for V648 race recovery, archive portability and worker execution."""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[2]
ACTIVITY = (ROOT / "app/src/main/java/com/f1teammanager/MainActivity.kt").read_text(encoding="utf-8")
PREFS = (ROOT / "app/src/main/java/com/f1teammanager/CareerPreferences.kt").read_text(encoding="utf-8")
HISTORY = (ROOT / "app/src/main/java/com/f1teammanager/HistoricalDatabase.kt").read_text(encoding="utf-8")
SAVE_UI = (ROOT / "app/src/main/java/com/f1teammanager/SaveManagementScreen.kt").read_text(encoding="utf-8")
POLICY = (ROOT / "app/src/main/java/com/f1teammanager/core/race/WeekendSessionRecoveryPolicy.kt").read_text(encoding="utf-8")
TEST = ROOT / "app/src/test/java/com/f1teammanager/core/race/WeekendSessionRecoveryPolicyV648Test.kt"
BUILD = (ROOT / "app/build.gradle.kts").read_text(encoding="utf-8")
CHANGELOG = ROOT / "CHANGELOG_V648.md"
checks = []
def check(name, condition):
    checks.append((name, bool(condition)))
    print(("PASS" if condition else "FAIL") + " | " + name)

# 1. Manual completed result is saved before finalization and retries the same in-memory result.
manual = ACTIVITY[ACTIVITY.index("fun advanceRace()") : ACTIVITY.index("/** Domain integration hook", ACTIVITY.index("fun advanceRace()"))]
check("manual race persists exact result to durable outbox", "savePendingRaceFinalization" in manual)
check("manual outbox commit happens before finalizer call", manual.index("savePendingRaceFinalization") < manual.index("finalizeCompletedRace(outcome.first)"))
check("manual save failure does not apply side effects and exposes retry action", "if (!saved)" in manual and "Nenhum efeito da carreira foi aplicado" in manual and "TENTAR SALVAR RESULTADO" in manual)
check("manual persistence exception routes to calendar retry", "screen = Screen.CALENDAR" in manual and "resulto integral falhou" not in manual and "gravação do resultado integral falhou" in manual)
retry = ACTIVITY[ACTIVITY.index("fun simulateWeekendInstantlyForCareer()") : ACTIVITY.index("fun returnToCalendarAfterRace()")]
check("retained completed result is retried before a new simulation", retry.index("retainedCompletedSnapshot") < retry.index("InstantSimulationService.simulateWeekendInstantly"))
check("calendar exposes a retry button for unsaved completed result", "canRetryCompletedResult" in ACTIVITY and "retryCompletedResult = ::simulateWeekendInstantlyForCareer" in ACTIVITY and "TENTAR SALVAR RESULTADO" in ACTIVITY)
check("instant outbox serialization runs on IO", "withContext(Dispatchers.IO)" in retry and "store.savePendingRaceFinalization" in retry)

# 2. Complete history export/import (legacy plus both V3 shard sets).
check("backup schema 4 includes history bundle", '.put("schema", 4)' in PREFS and '.put("historicalArchiveBundle", historyBundle)' in PREFS)
check("export bundle includes legacy/V3 shards and AtomicFile backup recovery", 'readAtomic("legacy/f1tm_historical_v2.db", file)' in HISTORY and 'committedShardFiles(raceArchiveDirectory, raceArchiveName)' in HISTORY and 'committedShardFiles(seasonArchiveDirectory, seasonArchiveName)' in HISTORY and 'removeSuffix(".bak")' in HISTORY)
check("bundle validates checksum, file count and path allowlist", "sha256Hex(bytes)" in HISTORY and "fileCount" in HISTORY and "Caminho de arquivo histórico não permitido" in HISTORY)
check("import stages history and verifies readback before commit", "history.replaceArchiveBundle(importedHistoryBundle, deferCommit = true)" in PREFS and "restoredHistoryBundle" in PREFS)
check("career import has one atomic PREPARED/COMMITTED journal", 'writeCareerImportJournal("PREPARED"' in PREFS and 'writeCareerImportJournal("COMMITTED"' in PREFS and "careerImportJournalAtomic.startWrite()" in PREFS)
check("startup coordinates preference and archive rollback/commit", "recoverInterruptedCareerImportTransaction()" in PREFS and 'careerImportJournalStatus() == "COMMITTED"' in HISTORY and "rollbackArchiveBundleReplacement()" in PREFS)
check("history import has startup rollback marker", "recoverInterruptedArchiveImport()" in HISTORY and "archiveImportMarker" in HISTORY and "archiveImportBackup" in HISTORY)
check("save UI moves archive serialization/import to IO", SAVE_UI.count("withContext(Dispatchers.IO)") >= 5)

# 3. Finalization and season rollover run away from Main.
finalizer = ACTIVITY[ACTIVITY.index("fun finalizeCompletedRace(") : ACTIVITY.index("fun advanceRace()", ACTIVITY.index("fun finalizeCompletedRace("))]
check("manual and instant finalization share IO worker", "withContext(Dispatchers.IO)" in finalizer and "finalizeCompletedRaceLocked" in finalizer)
rollover = ACTIVITY[ACTIVITY.index("fun startNextSeason()", ACTIVITY.index("fun performStartNextSeason()")) : ACTIVITY.index("fun startDriverDevelopment", ACTIVITY.index("fun startNextSeason()", ACTIVITY.index("fun performStartNextSeason()")))]
check("season rollover runs on Default worker", "withContext(Dispatchers.Default)" in rollover and "performStartNextSeason()" in rollover)

# 4. Explicit active-session policy.
check("checkpoint is written before manual engine start", ACTIVITY.index("markWeekendSessionStarted(store.season, round.round)") < ACTIVITY.index("snapshot = engine.start(participants(), circuit(), team.id)"))
check("startup uses explicit recovery policy", "WeekendSessionRecoveryPolicy.decide" in ACTIVITY and "DISCARD_INCOMPLETE_SESSION" in ACTIVITY)
check("policy distinguishes unfinished, pending and finalized sessions", all(name in POLICY for name in ["DISCARD_INCOMPLETE_SESSION", "FINALIZE_DURABLE_RESULT", "RESTORE_ALREADY_FINALIZED_RESULT"]))
check("unit regression test exists", TEST.exists() and "incompleteSessionIsDiscardedWithoutCareerSettlement" in TEST.read_text(encoding="utf-8"))
check("qualifying sponsor bonus is not credited twice", "applyQualifyingBonusOnce" not in ACTIVITY and "qualifyingBonus(active, bestQualifyingPosition)" in (ROOT / "app/src/main/java/com/f1teammanager/core/manager/FinanceEngine.kt").read_text(encoding="utf-8"))

# Version metadata.
check("versionCode is 648", re.search(r"versionCode\s*=\s*648\b", BUILD))
check("versionName is 0.648.0", 'versionName = "0.648.0"' in BUILD)
check("V648 changelog exists", CHANGELOG.exists() and "0.648.0" in CHANGELOG.read_text(encoding="utf-8"))
print(f"RESULT: {sum(ok for _, ok in checks)}/{len(checks)} checks passed")
sys.exit(0 if all(ok for _, ok in checks) else 1)
