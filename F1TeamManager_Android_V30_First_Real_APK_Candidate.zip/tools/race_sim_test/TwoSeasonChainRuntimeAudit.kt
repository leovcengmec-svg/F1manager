package com.f1teammanager.core.season

import com.f1teammanager.core.manager.*
import com.f1teammanager.core.race.RaceResultValidator

/** Executable 60-GP integration audit for the two-season career chain. */
fun main() {
    // Seed a legacy-format custom team before any WorldDatabase getter is evaluated.
    // Its pilots deliberately have teamId=0 to verify that the declared team roster
    // remains authoritative through the real manager/race engine over 60 GPs.
    CustomWorldCatalog.pilots = listOf(
        CustomWorldCatalog.Pilot(101, "Piloto Personalizado A", "Brasil", "Médio", "Normal", 74, 73, 72, 71, 70, 69, 72, 0),
        CustomWorldCatalog.Pilot(102, "Piloto Personalizado B", "Brasil", "Médio", "Normal", 73, 72, 71, 70, 71, 70, 73, 0)
    )
    CustomWorldCatalog.teams = listOf(
        CustomWorldCatalog.Team(41, "Equipe Personalizada de Auditoria", "Brasil", 101, 102, "41.png")
    )
    check(WorldDatabase.teams.size == 41) { "Custom team not projected into WorldDatabase" }
    check(WorldDatabase.drivers.filter { it.id in setOf(101, 102) }.all { it.teamId == 41 }) {
        "Legacy teamId=0 custom pilots were not bound to their declared roster"
    }
    val market = DriverMarketEngine(20261003).initialState(2026)
    check(market.contracts.single { it.driverId == 101 }.teamId == 41) { "Custom pilot 101 did not start at its declared team" }
    check(market.contracts.single { it.driverId == 102 }.teamId == 41) { "Custom pilot 102 did not start at its declared team" }
    val team = WorldDatabase.teams.first()
    val car = TeamCarState(
        InitialTeamProfile.strength(team), team.chassis, team.engine, team.reliability,
        frontWing = team.frontWing, rearWing = team.rearWing, brakes = team.brakes,
        electricPowerUnit = team.electricPowerUnit
    )
    val sponsor = SponsorContract(
        name = "Patrocinador de auditoria", upfront = 0L, racePayment = 150_000L,
        pointsBonus = 2_000L, years = 2, minimumReputation = 0, slot = 1,
        qualifyingTarget = 1, qualifyingBonus = 50_000L, raceTarget = 20,
        raceTargetBonus = 25_000L, active = true, races = 30, racesRemaining = 30
    )
    var manager = TeamManagerState(
        season = 2026, round = 1, playerTeamId = team.id, car = car,
        finance = TeamFinanceState(35_000_000), driverMarket = market,
        sponsor = sponsor, sponsors = listOf(sponsor)
    )
    var season = SeasonState()
    val engine = ManagerSeasonEngine(20261003)
    var pointsAwarded = 0
    var racesChecked = 0
    val expectedGridSize = WorldDatabase.teams.size * 2
    val expectedQ2Size = kotlin.math.ceil(expectedGridSize * 50.0 / 80.0).toInt().coerceIn(1, expectedGridSize)
    val expectedQ3Size = kotlin.math.ceil(expectedGridSize * 20.0 / 80.0).toInt().coerceIn(1, expectedGridSize)
    var lastSeasonPoints = 0
    var pointsInCurrentSeason = 0

    repeat(60) { index ->
        val auditStartedAt = System.nanoTime()
        val year = season.season
        println("START GP ${index + 1}/60 ($year GP${season.currentRound})")
        val round = season.currentRound
        val definition = SeasonCalendar.forSeason(year)[round - 1]
        val outcome = engine.runRound(manager, season)
        manager = outcome.state
        season = outcome.season
        val race = outcome.race

        RaceResultValidator.requireValid(race, definition.laps)
        check(race.classification.size == expectedGridSize) { "$year GP$round: expected $expectedGridSize classified drivers" }
        check(race.classification.map { it.driverId }.toSet().size == expectedGridSize) { "$year GP$round: duplicate driver" }
        check(race.classification.map { it.position }.sorted() == (1..expectedGridSize).toList()) { "$year GP$round: missing/duplicate position" }
        val qualifying = requireNotNull(race.qualifying) { "$year GP$round: qualifying missing" }
        check(qualifying.grid.size == expectedGridSize) { "$year GP$round: qualifying grid incomplete" }
        check(qualifying.phases.map { it.entries.size } == listOf(expectedGridSize, expectedQ2Size, expectedQ3Size)) { "$year GP$round: Q1/Q2/Q3 field mismatch" }
        check(race.points.values.all { it >= 0 }) { "$year GP$round: negative championship points" }
        check(manager.finance.budget >= 0L) { "$year GP$round: negative player budget" }
        check(manager.season == season.season && manager.round == season.currentRound) { "$year GP$round: manager/calendar desynchronized" }
        check(manager.garage != null && manager.garage!!.car1.id != manager.garage!!.car2.id) { "$year GP$round: two-car garage missing" }
        check("$year:$round" in manager.driverEvolutionProcessedRounds) { "$year GP$round: evolution marker missing" }
        check(manager.driverMarket.contracts.count { it.activeIn(manager.season) } == expectedGridSize) {
            "$year GP$round: active driver count mismatch: active=${manager.driverMarket.contracts.count { it.activeIn(manager.season) }} expected=$expectedGridSize season=${manager.season} round=${manager.round} teamCounts=${manager.driverMarket.contracts.filter { it.activeIn(manager.season) }.groupingBy { it.teamId }.eachCount()} scheduled=${manager.driverMarket.scheduled.filter { it.startSeason <= manager.season }.map { it.driverId }} free=${manager.driverMarket.freeAgents.size}"
        }
        check(manager.driverMarket.contracts.map { it.driverId }.distinct().size == expectedGridSize) { "$year GP$round: duplicate active market driver" }
        val activeDeals = manager.driverMarket.contracts.filter { it.activeIn(manager.season) }
        check(activeDeals.groupBy { it.teamId }.keys == WorldDatabase.teams.map { it.id }.toSet()) { "$year GP$round: a registered team disappeared from the active market" }
        check(activeDeals.groupBy { it.teamId }.values.all { it.size == 2 }) { "$year GP$round: a team does not have exactly two active contracts" }
        if (year == 2026 && round < 30) check(manager.sponsors.firstOrNull()?.racesRemaining == 30 - round) { "Sponsor countdown failed at GP$round" }
        if (year == 2026 && round == 30) check(manager.sponsors.none { it.active }) { "30-GP sponsor did not expire" }

        val gpPoints = race.points.values.sum()
        pointsAwarded += gpPoints
        pointsInCurrentSeason += gpPoints
        racesChecked++
        println("DONE GP ${index + 1}/60 in ${((System.nanoTime() - auditStartedAt) / 1_000_000_000.0)}s")
        if (round == 30) lastSeasonPoints = pointsInCurrentSeason
        if (index == 29) {
            check(manager.season == 2027 && manager.round == 1) { "GP30 did not transition to 2027 GP1" }
            check(season.season == 2027 && season.currentRound == 1) { "SeasonState did not transition to 2027 GP1" }
            check(lastSeasonPoints > 0) { "2026 championship points missing at transition" }
            check(manager.garage!!.car1.installedPieceVersions.values.all { it == 0 }) { "2027 Car 1 component baseline was not reset" }
            check(manager.garage!!.car2.installedPieceVersions.values.all { it == 0 }) { "2027 Car 2 component baseline was not reset" }
            pointsInCurrentSeason = 0
        }
        if (index == 59) {
            check(manager.season == 2028 && manager.round == 1) { "second GP30 did not transition to 2028 GP1" }
            check(season.season == 2028 && season.currentRound == 1) { "SeasonState did not transition to 2028 GP1" }
            check(manager.garage!!.car1.installedPieceVersions.values.all { it == 0 }) { "2028 Car 1 component baseline was not reset" }
            check(manager.garage!!.car2.installedPieceVersions.values.all { it == 0 }) { "2028 Car 2 component baseline was not reset" }
        }
    }

    check(racesChecked == 60)
    check(pointsAwarded > 0)
    check(manager.driverEvolutionAttributes.size == WorldDatabase.allDrivers.size)
    check(manager.driverEvolutionAnnualGains.size == WorldDatabase.allDrivers.size)
    check(manager.driverEvolutionBanks.size == WorldDatabase.allDrivers.size)
    check(manager.driverEvolutionProcessedRounds.size == 60)
    check(manager.finance.seasonPrizesPaid.containsAll(setOf(2026, 2027)))
    check((manager.finance.salaryPaidRounds + manager.finance.salaryOutstanding.keys).size == 60) { "salary ledger must have one entry per GP" }
    check(manager.finance.transactions.isNotEmpty())
    check(manager.driverMarket.scheduled.none { it.startSeason <= manager.season })

    println("TwoSeasonChainRuntimeAudit: PASS")
    check(manager.driverMarket.contracts.map { it.driverId }.distinct().size == expectedGridSize)
    check(manager.driverMarket.contracts.filter { it.activeIn(manager.season) }.groupBy { it.teamId }.values.all { it.size == 2 })
    println("$racesChecked GPs | seasons 2026-2027 complete | next=${manager.season} GP${manager.round} | points=$pointsAwarded | activeDrivers=$expectedGridSize | catalogDrivers=${WorldDatabase.allDrivers.size} | customTeam=41/customDrivers=101,102 | evolvedDrivers=${manager.driverEvolutionAttributes.size} | evolutionMarkers=${manager.driverEvolutionProcessedRounds.size} | prizes=${manager.finance.seasonPrizesPaid.sorted()}")
}
