package com.f1teammanager.core.season

import com.f1teammanager.core.manager.*
import com.f1teammanager.core.race.RaceResultValidator

/** Executable 60-GP integration audit for the two-season career chain. */
fun main() {
    val market = DriverMarketEngine(20261003).initialState(2026)
    val team = WorldDatabase.teams.first()
    val car = TeamCarState(
        InitialTeamProfile.strength(team), team.chassis, team.engine, team.reliability,
        frontWing = team.frontWing, rearWing = team.rearWing, brakes = team.brakes,
        electricPowerUnit = team.electricPowerUnit
    )
    val sponsor = SponsorContract(
        name = "Patrocinador de auditoria", upfront = 0L, racePayment = 150_000L,
        pointsBonus = 2_000L, years = 2, minimumReputation = 0, slot = 1,
        qualifyingTarget = 1, qualifyingBonus = 50_000L, raceTarget = 20,
        raceTargetBonus = 25_000L, active = true, races = 30, racesRemaining = 30
    )
    var manager = TeamManagerState(
        season = 2026, round = 1, playerTeamId = team.id, car = car,
        finance = TeamFinanceState(35_000_000), driverMarket = market,
        sponsor = sponsor, sponsors = listOf(sponsor)
    )
    var season = SeasonState()
    val engine = ManagerSeasonEngine(20261003)
    var pointsAwarded = 0
    var racesChecked = 0
    var lastSeasonPoints = 0
    var pointsInCurrentSeason = 0

    repeat(60) { index ->
        val year = season.season
        val round = season.currentRound
        val definition = SeasonCalendar.forSeason(year)[round - 1]
        val outcome = engine.runRound(manager, season)
        manager = outcome.state
        season = outcome.season
        val race = outcome.race

        RaceResultValidator.requireValid(race, definition.laps)
        check(race.classification.size == 80) { "$year GP$round: expected 80 classified drivers" }
        check(race.classification.map { it.driverId }.toSet().size == 80) { "$year GP$round: duplicate driver" }
        check(race.classification.map { it.position }.sorted() == (1..80).toList()) { "$year GP$round: missing/duplicate position" }
        val qualifying = requireNotNull(race.qualifying) { "$year GP$round: qualifying missing" }
        check(qualifying.grid.size == 80) { "$year GP$round: qualifying grid incomplete" }
        check(qualifying.phases.map { it.entries.size } == listOf(80, 50, 20)) { "$year GP$round: Q1/Q2/Q3 field mismatch" }
        check(race.points.values.all { it >= 0 }) { "$year GP$round: negative championship points" }
        check(manager.finance.budget >= 0L) { "$year GP$round: negative player budget" }
        check(manager.season == season.season && manager.round == season.currentRound) { "$year GP$round: manager/calendar desynchronized" }
        check(manager.garage != null && manager.garage!!.car1.id != manager.garage!!.car2.id) { "$year GP$round: two-car garage missing" }
        check("$year:$round" in manager.driverEvolutionProcessedRounds) { "$year GP$round: evolution marker missing" }
        check(manager.driverMarket.contracts.count { it.activeIn(manager.season) } == 80) { "$year GP$round: active driver count mismatch" }
        if (year == 2026 && round < 30) check(manager.sponsors.firstOrNull()?.racesRemaining == 30 - round) { "Sponsor countdown failed at GP$round" }
        if (year == 2026 && round == 30) check(manager.sponsors.none { it.active }) { "30-GP sponsor did not expire" }

        val gpPoints = race.points.values.sum()
        pointsAwarded += gpPoints
        pointsInCurrentSeason += gpPoints
        racesChecked++
        if (round == 30) lastSeasonPoints = pointsInCurrentSeason
        if (index == 29) {
            check(manager.season == 2027 && manager.round == 1) { "GP30 did not transition to 2027 GP1" }
            check(season.season == 2027 && season.currentRound == 1) { "SeasonState did not transition to 2027 GP1" }
            check(lastSeasonPoints > 0) { "2026 championship points missing at transition" }
            pointsInCurrentSeason = 0
        }
        if (index == 59) {
            check(manager.season == 2028 && manager.round == 1) { "second GP30 did not transition to 2028 GP1" }
            check(season.season == 2028 && season.currentRound == 1) { "SeasonState did not transition to 2028 GP1" }
        }
    }

    check(racesChecked == 60)
    check(pointsAwarded > 0)
    check(manager.driverEvolutionAttributes.size == 100)
    check(manager.driverEvolutionAnnualGains.size == 100)
    check(manager.driverEvolutionBanks.size == 100)
    check(manager.driverEvolutionProcessedRounds.size == 60)
    check(manager.finance.seasonPrizesPaid.containsAll(setOf(2026, 2027)))
    check((manager.finance.salaryPaidRounds + manager.finance.salaryOutstanding.keys).size == 60) { "salary ledger must have one entry per GP" }
    check(manager.finance.transactions.isNotEmpty())
    check(manager.driverMarket.scheduled.none { it.startSeason <= manager.season })

    println("TwoSeasonChainRuntimeAudit: PASS")
    println("$racesChecked GPs | seasons 2026-2027 complete | next=${manager.season} GP${manager.round} | points=$pointsAwarded | activeDrivers=80 | evolvedDrivers=${manager.driverEvolutionAttributes.size} | evolutionMarkers=${manager.driverEvolutionProcessedRounds.size} | prizes=${manager.finance.seasonPrizesPaid.sorted()}")
}
