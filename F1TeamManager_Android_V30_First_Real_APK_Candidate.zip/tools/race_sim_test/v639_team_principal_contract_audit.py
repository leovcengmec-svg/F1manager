#!/usr/bin/env python3
"""Current Team Principal career and dismissal audit (maintained from V664)."""
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]
def read(rel):
    p = ROOT / rel
    return p.read_text(encoding="utf-8") if p.is_file() else ""

GRADLE = read("app/build.gradle.kts")
ENGINE = read("app/src/main/java/com/f1teammanager/core/manager/TeamPrincipalCareerEngine.kt")
FINANCE = read("app/src/main/java/com/f1teammanager/core/manager/FinanceEngine.kt")
STORE = read("app/src/main/java/com/f1teammanager/CareerPreferences.kt")
MAIN = read("app/src/main/java/com/f1teammanager/MainActivity.kt")
CAREER_SCREEN = read("app/src/main/java/com/f1teammanager/TeamPrincipalCareerScreen.kt")
HISTORY = read("app/src/main/java/com/f1teammanager/HistoricalDatabase.kt")
FOCUSED_TEST = read("app/src/test/java/com/f1teammanager/core/manager/TeamPrincipalContractCycleV639Test.kt")
LEGACY_TEST = read("app/src/test/java/com/f1teammanager/core/manager/V586TeamPrincipalCareerEngineTest.kt")
CHANGELOG = read("CHANGELOG_V664.md")
AUDIT = read("AUDIT_V664_CORRECTIONS.md")

checks = []
def check(name, ok):
    checks.append((name, bool(ok)))

check("V664 versionCode/versionName are synchronized", "versionCode = 664" in GRADLE and 'versionName = "0.664.0"' in GRADLE)
check("V664 changelog and audit report exist", bool(CHANGELOG) and bool(AUDIT))
check("Team Principal contracts are limited to one or two years", "contractYears: Int = 1" in ENGINE and "contractYears.coerceIn(1, 2)" in ENGINE and "years.coerceIn(1, 2)" in ENGINE)
check("Outside offer quota and dismissal window remain bounded", "in 0..39 -> 1" in ENGINE and "in 40..59 -> 2" in ENGINE and "else -> 3" in ENGINE and "distinctBy { it.teamId }.take(4)" in ENGINE)
check("Dismissal risk includes sports, finance, development and facilities", all(x in ENGINE for x in ["racePenalty", "qualifyingPenalty", "financePenalty", "developmentPenalty", "facilityPenalty", "objectivePenalty"]))
check("Live risk forecast shares the end-season risk function", "teamPrincipalDismissalRiskEstimate()" in STORE and "dismissalProbabilityPercent(" in STORE and "dismissalRiskEstimate = dismissalRiskEstimate" in MAIN)
check("Projected support uses the same board-support settlement", "projectedBoardSupport(" in ENGINE and "calculateBoardSupport(state.boardSupport" in ENGINE)
check("Repeated failure is limited to consecutive seasons at the same team", "it.teamId == state.teamId" in ENGINE and "previousRecord.teamId == state.teamId" in STORE)
check("Effective closing balance deducts salary and maintenance liabilities", "salaryOutstanding.values.sumOf" in FINANCE and "facilityMaintenanceOutstanding.values.sumOf" in FINANCE and "finance.budget - totalLiabilities" in FINANCE)
check("Cash objective UI uses balance after mandatory obligations", "effectiveClosingBalance(currentFinance)" in MAIN)
check("P1 objective is converted to title defence", '"maintain_rank"' in ENGINE and "normalizeImpossibleObjectives" in ENGINE)
check("Single facility objective can be fully satisfied and active upgrades receive credit", "completed * 2" in ENGINE and "upgradeProgressPercent.coerceIn(0, 100) > 0" in ENGINE)
check("Research and factory work in progress receive development credit", "researchProgressPercent.coerceIn(0, 100) > 0" in ENGINE and "manufacturingProgressPercent.coerceIn(0, 100) > 0" in ENGINE)
check("Manufactured pieces carry season identity with legacy-safe decoding", "manufacturedSeason" in read("app/src/main/java/com/f1teammanager/core/manager/CarGarageModels.kt") and "p.getOrNull(6)?.toIntOrNull() ?: 0" in STORE)
check("Renewal preserves trust while a new team gets a new-board floor", "boardSupport = state.boardSupport.coerceIn(0, 100)" in ENGINE and "boardSupport = maxOf(state.boardSupport.coerceIn(0, 100), INITIAL_BOARD_SUPPORT)" in ENGINE)
check("Season-specific history queries use season shards", "readSeasonRaceLines(season)" in HISTORY and "readSeasonSummaryLines(season)" in HISTORY)
check("Official constructor ranking is used at season settlement", "teamPrincipalRanksForSeason(season, points)" in STORE and "history.constructorSeasonRecords(targetSeason)" in STORE)
check("Focused tests cover current Team Principal fixes", all(s in FOCUSED_TEST for s in ["leaderGetsDefendTitleObjectiveInsteadOfImpossibleImprovement", "completingSingleFacilityGoalCountsAsFullInvestmentDelivery", "ongoingResearchAndNewlyManufacturedPieceReceivePartialDevelopmentCredit", "renewalPreservesLowBoardSupportInsteadOfResettingIt", "previouslySavedImpossibleLeaderObjectiveIsMigratedWithoutRegeneratingSeason"]))
check("Legacy Team Principal tests align with fallback-offer policy", "assertEquals(listOf(5), offers)" in LEGACY_TEST)

failed = [name for name, ok in checks if not ok]
for name, ok in checks:
    print(("PASS" if ok else "FAIL") + " | " + name)
print(f"RESULT: {len(checks)-len(failed)}/{len(checks)} checks passed")
if failed:
    sys.exit(1)
