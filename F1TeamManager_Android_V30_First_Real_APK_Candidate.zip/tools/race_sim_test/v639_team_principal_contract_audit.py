#!/usr/bin/env python3
"""Static policy and integration audit for V639 Team Principal contracts."""
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]
def read(rel):
    p = ROOT / rel
    return p.read_text(encoding='utf-8') if p.is_file() else ''

GRADLE = read('app/build.gradle.kts')
ENGINE = read('app/src/main/java/com/f1teammanager/core/manager/TeamPrincipalCareerEngine.kt')
STORE = read('app/src/main/java/com/f1teammanager/CareerPreferences.kt')
MAIN = read('app/src/main/java/com/f1teammanager/MainActivity.kt')
CAREER_SCREEN = read('app/src/main/java/com/f1teammanager/TeamPrincipalCareerScreen.kt')
FOCUSED_TEST = read('app/src/test/java/com/f1teammanager/core/manager/TeamPrincipalContractCycleV639Test.kt')
LEGACY_TEST = read('app/src/test/java/com/f1teammanager/core/manager/V586TeamPrincipalCareerEngineTest.kt')
CHANGELOG = read('CHANGELOG_V639.md')
AUDIT = read('AUDIT_V639_TEAM_PRINCIPAL_CONTRACT_CYCLE.md')

checks = []
def check(name, ok):
    checks.append((name, bool(ok)))

check('V639 versionCode and versionName', 'versionCode = 639' in GRADLE and 'versionName = "0.639.0"' in GRADLE)
check('Changelog and audit report exist', bool(CHANGELOG) and bool(AUDIT) and 'V639' in read('CHANGELOG.md')[:200])
check('New career starts with one-year Team Principal contract', 'val contractYears: Int = 1' in ENGINE and 'contractStartSeason = season' in ENGINE)
check('Expiry is exact; no premature multi-year proposals', 'season == state.contractEndSeason' in ENGINE and 'val contractEndSeason: Int get() = contractStartSeason + contractYears.coerceIn(1, 3) - 1' in ENGINE)
check('Outside-offer quota is zero/one/two/three by prestige', all(x in ENGINE for x in ['in 0..19 -> 0', 'in 20..39 -> 1', 'in 40..59 -> 2', 'else -> 3']))
check('Open window includes current renewal only if not dismissed and caps at four total', 'includeCurrentTeam = !fired' in ENGINE and 'outsiders.take(if (includeCurrentTeam) 3 else 4)' in ENGINE and 'distinctBy { it.teamId }.take(4)' in ENGINE)
check('Each generated offer is assigned a persisted 1–3-year term', 'fun offerDuration(' in ENGINE and 'years.coerceIn(1, 3)' in ENGINE and 'offersText' in ENGINE)
check('Accepted or renewed term must match persisted offer', 'years == offeredCurrentYears' in STORE and 'contractYears == signedYears' in STORE)
check('Board support is persisted and season performance recalculates it', 'boardSupport: Int = 75' in ENGINE and 'calculateBoardSupport(' in ENGINE and 'boardSupport = nextBoardSupport' in ENGINE)
check('Dismissal risk is probabilistic and bounded', 'dismissalProbabilityPercent(' in ENGINE and 'coerceIn(0, 95)' in ENGINE and 'dismissalRoll.coerceIn(0, 99) < dismissalOdds' in ENGINE)
check('Legacy schemas 1–4 migrate; active saves get next unprocessed contract year', 'schema !in 1..5' in ENGINE and 'schema < 5 && p[8] != "1" && p[9] != "1"' in ENGINE and 'decodedLastProcessedSeason + 1' in ENGINE)
check('Proposal/dismissal event is stored atomically with the career result', 'driverMarketEditor(editor, market.copy(notifications = (market.notifications + notice).takeLast(1000)))' in STORE and 'check(editor.commit())' in STORE)
check('Home uses approved event modal and routes offers to contract review', '"PROPOSTAS DE TEAM PRINCIPAL"' in MAIN and 'R.drawable.notice_market_offer' in MAIN and 'onTeamPrincipalReview()' in MAIN)
check('Review UI displays offered term for renewal and external offers', 'CONTRATO $years' in MAIN and 'RENOVAR COM ${teamName.uppercase()} • $currentOfferYears' in MAIN and 'offerYears = principal.contractOffers.associate' in MAIN)
check('Career panel shows board support and current ranking-based dismissal risk', 'APOIO DA DIRETORIA' in CAREER_SCREEN and 'effectiveRank' in CAREER_SCREEN and 'dismissalProbabilityPercent(' in CAREER_SCREEN)
check('Focused tests cover term, offer caps, persistence and legacy migration', all(s in FOCUSED_TEST for s in ['initialContractLastsOneSeason','prestigeControlsZeroToThreeOutsideOffers','multiYearContractDoesNotOpenMarketBeforeExpiry','acceptingOfferPersistsTheSpecificTerm','encodedStateRoundTripsContractTermSupportAndOffers','schemaFourSaveMigratesCurrentTeamRenewal','activeSchemaFourSaveGetsNextUnprocessedOneYearContractWindow']))
check('Prior Team Principal regression tests are deterministic for firing probability', 'dismissalRoll = 99' in LEGACY_TEST and 'twoSeverelyFailedSeasonsCanTriggerDismissal' in LEGACY_TEST)

failed = [name for name, ok in checks if not ok]
for name, ok in checks:
    print(('PASS' if ok else 'FAIL') + ' | ' + name)
print(f'RESULT: {len(checks)-len(failed)}/{len(checks)} checks passed')
if failed:
    sys.exit(1)
