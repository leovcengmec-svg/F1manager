package com.f1teammanager.core.season

fun main() {
    val equalSkillGrid = (1..40).flatMap { teamId ->
        (0..1).map { slot ->
            DriverEvolutionEngine.TargetInput(
                driverId = (teamId - 1) * 2 + slot + 1,
                teamId = teamId,
                carStrength = 100.0 - (teamId - 1),
                driverOverall = 80,
                qualifyingStrength = 80
            )
        }
    }
    val equalTargets = DriverEvolutionEngine.buildIndividualTargets(equalSkillGrid)
    check(equalTargets.size == 80)
    check(equalTargets.getValue(1).racePosition == 1 && equalTargets.getValue(2).racePosition == 2)
    check(equalTargets.getValue(19).racePosition == 19 && equalTargets.getValue(20).racePosition == 20)
    check(equalTargets.getValue(43).racePosition == 43 && equalTargets.getValue(44).racePosition == 44)
    check(equalTargets.getValue(59).racePosition == 59 && equalTargets.getValue(60).racePosition == 60)
    check(equalTargets.getValue(79).racePosition == 79 && equalTargets.getValue(80).racePosition == 80)

    val skillGrid = equalSkillGrid.map { input ->
        when (input.driverId) {
            43 -> input.copy(driverOverall = 95, qualifyingStrength = 95)
            44 -> input.copy(driverOverall = 65, qualifyingStrength = 65)
            else -> input
        }
    }
    val skillTargets = DriverEvolutionEngine.buildIndividualTargets(skillGrid)
    check(skillTargets.getValue(43).racePosition < skillTargets.getValue(44).racePosition)
    check(skillTargets.getValue(43).racePosition in 40..46)
    check(skillTargets.getValue(44).racePosition in 41..47)

    val p22Target = DriverEvolutionEngine.Target(44, 44, 44)
    val index = DriverEvolutionEngine.gpPerformanceIndex(p22Target, 35, 35)
    check(index >= 115.0 && DriverEvolutionEngine.performanceEvolutionRate(index) > 1.0)
    check(DriverEvolutionEngine.buildIndividualTargets(equalSkillGrid.dropLast(1)).isEmpty())
    println("V681 driver expectations smoke: PASS (40 teams, 80 drivers, P22→P43/P44, P35 rewarded)")
}
