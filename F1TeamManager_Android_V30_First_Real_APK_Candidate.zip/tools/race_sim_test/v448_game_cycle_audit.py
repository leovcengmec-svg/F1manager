#!/usr/bin/env python3
"""V448 release audit for gameplay-cycle invariants and atomic next-car investment persistence."""
from pathlib import Path
import re, sys, xml.etree.ElementTree as ET
ROOT = Path(__file__).resolve().parents[2]
checks=[]
def check(name, ok, detail=''):
    checks.append((name, bool(ok), detail))
def read(rel):
    p=ROOT/rel
    return p.read_text(encoding='utf-8') if p.is_file() else ''
main=read('app/src/main/java/com/f1teammanager/MainActivity.kt')
prefs=read('app/src/main/java/com/f1teammanager/CareerPreferences.kt')
car=read('app/src/main/java/com/f1teammanager/core/manager/CarDevelopmentEngine.kt')
season=read('app/src/main/java/com/f1teammanager/core/manager/ManagerSeasonEngine.kt')
policy=read('app/src/main/java/com/f1teammanager/core/manager/SeasonInvestmentPolicy.kt')
reg=read('app/src/main/java/com/f1teammanager/core/manager/AnnualCarRegulationEngine.kt')
finance=read('app/src/main/java/com/f1teammanager/core/manager/FinanceEngine.kt')
# Release metadata / Android entrypoint.
gradle=read('app/build.gradle.kts')
vc=re.search(r'versionCode\s*=\s*(\d+)',gradle); vn=re.search(r'versionName\s*=\s*"([^"]+)"',gradle)
check('Android version metadata consistent', bool(vc and vn and vn.group(1)==f'0.{int(vc.group(1))}.0'))
try:
    ET.parse(ROOT/'app/src/main/AndroidManifest.xml'); check('Android manifest XML valid',True)
except Exception as e: check('Android manifest XML valid',False,str(e))
# Season-cycle state machine and recovery.
check('season transition journal blocks unsafe replay', 'beginSeasonTransitionJournal' in main and 'STATE_PERSISTED' in main and 'rollbackSeasonTransitionJournal' in main)
check('new car built before annual regulation', main.find('development.startNextSeason(managerState, store.season') >= 0 and main.find('development.startNextSeason(managerState, store.season') < main.find('AnnualCarRegulationEngine.applyToGarage('))
check('annual regulation precedes new technical ranking', main.find('AnnualCarRegulationEngine.applyToGarage(') < main.find('TechnicalInvestmentEngine.forTeam(', main.find('AnnualCarRegulationEngine.applyToGarage(')))
check('regulation leaves reliability untouched', 'reliability =' not in reg[reg.find('fun applyToGarage'):reg.find('/** Stable, compact representation')])
check('instant race simulation validates engine-configured dynamic grid', 'engine.configuredParticipants()' in read('app/src/main/java/com/f1teammanager/core/race/InstantSimulationService.kt') and 'configuredDriverIds' in read('app/src/main/java/com/f1teammanager/core/race/InstantSimulationService.kt') and 'RaceResultValidator.requireValid' in read('app/src/main/java/com/f1teammanager/core/race/InstantSimulationService.kt'))
check('race finalization is journaled and retry-safe', 'RaceFinalizationJournal' in main and 'finalizeCompletedRaceLocked' in main and 'savePendingRaceFinalization' in main)
check('player finance GP settlement idempotency preserved', 'GP_SETTLEMENT:$season:$round' in finance and 'settlementKey in state.finance.raceSettlementKeys' in finance)
check('sponsor settlement idempotency preserved', 'processedRaceKeys' in read('app/src/main/java/com/f1teammanager/core/manager/TeamSponsorshipEngine.kt'))
check('calendar week progression applies due events per week', 'for (eventWeek in (currentWeek + 1)..targetWeek)' in main and 'canApplyWeeklyEvent(store.season, eventWeek' in main)
# Next-car rules: investment and debit must share one synchronous durable commit.
fn=main[main.find('fun investNextSeason(amount: Long)'):main.find('fun setNextSeasonFocus', main.find('fun investNextSeason(amount: Long)'))]
check('next-car UI persists car + debit atomically', 'saveCarAndFinance(teamId, updated.car, updated.finance)' in fn and 'managerState = updated' in fn and fn.find('saveCarAndFinance') < fn.find('managerState = updated'))
atomic=prefs[prefs.find('fun saveCarAndFinance'):prefs.find('private fun loadKnowledge',prefs.find('fun saveCarAndFinance'))]
check('atomic investment save uses one commit', 'return combined.commit()' in atomic and 'financeTransactions' in atomic and 'nextSeasonInvestment' in atomic)
check('investment engine enforces global cap', 'return 150_000_000L' in car and 'amount <= room' in car)
check('investment engine enforces current reserve and shared cumulative policy', 'protectedCash(state.finance.budget)' in car and 'maximumCumulativeInvestment' in policy and 'allowedNextCarInvestmentAmount' in policy)
check('forecast and actual transition share reference function', 'referenceInvestmentForOverall(overall)' in car and 'nextSeasonInvestmentSteps(overall, old.nextSeasonInvestment)' in car)
check('all 61 Overall references are explicit and monotonic', 'referencesByOverall' in car and '8_000_000L' in car and '150_000_000L' in car)
check('history and external assets preserved', len(list(ROOT.glob('AUDIT_V*.md')))+len(list(ROOT.glob('CHANGELOG_V*.md')))>=350 and len([p for p in (ROOT/'app/src/main/assets').rglob('*') if p.is_file()])>=190)
for n,ok,detail in checks: print(('PASS' if ok else 'FAIL')+' | '+n+((' | '+detail) if detail else ''))
failed=sum(not ok for _,ok,_ in checks)
print(f'RESULT: {len(checks)-failed}/{len(checks)} gameplay-cycle checks passed')
sys.exit(1 if failed else 0)
