#!/usr/bin/env python3
"""V706 contract audit for Team Principal dismissal and constructor objective bands."""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[2]
def read(rel):
    path = ROOT / rel
    return path.read_text(encoding="utf-8") if path.is_file() else ""

gradle = read("app/build.gradle.kts")
manifest = read("package_manifest.txt")
readme = read("README.md")
engine = read("app/src/main/java/com/f1teammanager/core/manager/TeamPrincipalCareerEngine.kt")
store = read("app/src/main/java/com/f1teammanager/CareerPreferences.kt")
main = read("app/src/main/java/com/f1teammanager/MainActivity.kt")
screen = read("app/src/main/java/com/f1teammanager/TeamPrincipalCareerScreen.kt")
test = read("app/src/test/java/com/f1teammanager/core/manager/TeamPrincipalDismissalAndObjectiveBandsV706Test.kt")
changelog = read("CHANGELOG_V706.md")
audit = read("AUDIT_V706_STABILIZATION.md")

checks = []
def check(name, condition):
    checks.append((name, bool(condition)))

code = re.search(r"versionCode\s*=\s*(\d+)", gradle)
name = re.search(r'versionName\s*=\s*"([^\"]+)"', gradle)
check("Release version 706 is synchronized", bool(code and name and code.group(1) == "706" and name.group(1) == "0.706.0"))
check("Package manifest preserves ZIP name and V705 base", "F1TeamManager_Android_V30_First_Real_APK_Candidate.zip" in manifest and "Version: 706 / 0.706.0" in manifest and "Base: V705 / 0.705.0" in manifest)
check("README, changelog and audit identify V706", "F1 Team Manager V30 — V706" in readme and bool(changelog) and bool(audit))
check("Objective upper range is persisted in schema six", "rangeMax" in engine and "            6, teamId" in engine and "schema !in 1..6" in engine)
check("Legacy objectives migrate to the new range", "TeamPrincipalCareerEngine.objectiveRangeMax(target)" in engine and "primaryObjectiveDescription(target, rangeMax)" in engine)
check("Top ten has no tolerance, 11-20 gets one and 21-40 gets two", all(x in engine for x in ["target <= 10 -> 0", "target <= 20 -> 1", "else -> 2"]))
check("Main objective evaluation uses rangeMax", '"rank" -> rank <= goal.rangeMax' in engine)
check("Main target description correctly labels P1 champion", '"Ser campeão (1º lugar no Mundial de Equipes)"' in engine and "1º ou melhor" not in engine.replace("/** Avoid the impossible wording \"1º ou melhor\"", ""))
check("Two-year first-season protection uses three goals and support strictly over 50", "contractYears.coerceIn(1, 2) == 2" in engine and "completedObjectiveCount >= 3" in engine and "projectedBoardSupport > 50" in engine)
check("Protection is enforced in both risk forecast and final dismissal", "firstYearProtectionApplies" in engine and "firstYearProtected" in engine and "return 0" in engine)
check("Final-year main-objective miss adds graded probability, not automatic firing", "finalYearMainTargetPenalty" in engine and "normalizedContractYear == normalizedContractYears" in engine and "dismissalRoll.coerceIn(0, 99) < dismissalOdds" in engine)
check("Live UI forecast passes contract year, term and completed goals", all(x in store for x in ["contractYear = TeamPrincipalCareerEngine.contractYear(state, season)", "contractYears = state.contractYears", "completedObjectiveCount = completedObjectives"]))
check("Season settlement uses main-objective result and contract-specific rules", all(x in engine for x in ["val primaryObjectiveAchieved", "val completedObjectiveCount", "contractYear = currentContractYear"]))
check("Board support and repeated-failure scoring honor the position band", "rank <= objectiveRangeMax(objectiveRank)" in engine and "it.teamRank > objectiveRangeMax(it.objectiveRank)" in engine)
check("Main screen shows target range and exact Top-10 target", "primaryObjectiveDescription(goal.target, goal.rangeMax)" in main and "goal.rangeMax" in main)
check("Career screen uses the same range for progress and history", "primaryObjectiveMaxRank(state)" in screen and "recordMetPrimaryObjective(it)" in screen)
check("Historical achievement reads persisted primary-objective result", "main_${record.season}:" in engine and "record.objectiveResults" in engine)
check("Focused V706 tests cover contracts, target ranges and migration", all(x in test for x in ["firstYearOfTwoYearContractIsProtected", "missedMainObjectiveIsEvaluatedAtOneYearAndFinalTwoYearContractReviews", "mainGoalRangeAcceptsTwentyFiveToTwentySeven", "topTenMainTargetsDoNotReceiveAnyPositionMargin", "legacySavedMainObjectiveMigratesToRange"]))
check("Public game name and package identity remain unchanged", 'applicationId = "com.f1teammanager"' in gradle and "Public name: F1 Team Manager V30" in manifest)

failed = [name for name, ok in checks if not ok]
for name, ok in checks:
    print(("PASS" if ok else "FAIL") + " | " + name)
print(f"RESULT: {len(checks)-len(failed)}/{len(checks)} V706 checks passed")
sys.exit(1 if failed else 0)
