#!/usr/bin/env python3
"""Source-level contract audit for V649 driver class / Overall / evolution rules."""
from pathlib import Path
import re
ROOT = Path(__file__).resolve().parents[2]
checks = []
def ck(name, ok):
    checks.append((name, bool(ok)))
def read(path):
    p = ROOT / path
    return p.read_text(encoding='utf-8') if p.is_file() else ''

profile = read('app/src/main/java/com/f1teammanager/core/season/DriverProfileCatalog.kt')
evolution = read('app/src/main/java/com/f1teammanager/core/season/DriverEvolutionEngine.kt')
progression = read('app/src/main/java/com/f1teammanager/core/season/DriverClassProgressionEngine.kt')
development = read('app/src/main/java/com/f1teammanager/core/manager/DriverDevelopmentEngine.kt')
prefs = read('app/src/main/java/com/f1teammanager/CareerPreferences.kt')
manager = read('app/src/main/java/com/f1teammanager/core/manager/ManagerSeasonEngine.kt')
main = read('app/src/main/java/com/f1teammanager/MainActivity.kt')
calendar = read('app/src/main/java/com/f1teammanager/core/manager/AnnualTeamEventSeasonCalendar.kt')
gradle = read('app/build.gradle.kts')

ck('V649 versionCode/versionName', 'versionCode = 649' in gradle and 'versionName = "0.649.0"' in gradle)
ck('Official class ceilings retained', all(f'"{c}" -> {v}' in profile for c,v in [('Fraco',59),('Médio',69),('Forte',79),('Pro',89),('Lenda',100)]))
ck('Distinct Overall floors defined', all(f'"{c}" -> {v}' in profile for c,v in [('Fraco',40),('Médio',60),('Forte',70),('Pro',80),('Lenda',90)]))
ck('Initial attributes normalized to class band', 'normalizeRatingsToClassBand(rawRatings, normalizedClass)' in profile)
ck('Potential limited to two classes above at career start', 'maxPotentialOverall(driverClass)' in profile and 'maxPotentialOverall(normalizedClass)' in profile)
ck('Evolution profile annual gain table retained', all(f'"{c}" -> {v}' in profile for c,v in [('Prodígio',15),('Auge rápido',13),('Auge moderado',11),('Auge tardio',10),('Normal',8),('Demorado',6)]))
ck('Performance-driven progression tick is shared', 'fun applyPerformanceTick(' in evolution and 'DriverEvolutionEngine.applyPerformanceTick(' in prefs and 'DriverEvolutionEngine.applyPerformanceTick(' in manager)
ck('Class is a soft growth threshold', 'fun classGrowthFactor(' in evolution and 'classGrowthFactor(driver.driverClass' in evolution)
ck('No fixed 5/2/5 timed cycle remains in live engine', all(token not in evolution for token in ['phaseDurationSeasons','shouldCompleteGrowth','phaseTarget','phasePressure']))
ck('Promotion and demotion require adjacent consecutive seasons', 'latest.season != previous.season + 1' in progression)
ck('Two-season promotion threshold and one-class step', 'previous.averageIndex >= 100.0' in progression and 'average >= 105.0' in progression and 'ladder[index + 1]' in progression)
ck('Two-season demotion threshold and one-class step', 'previous.averageIndex <= 80.0' in progression and 'average <= 80.0' in progression and 'ladder[index - 1]' in progression)
ck('At least 80 percent of both seasons is required', 'expectedSeasonRounds * 0.80' in progression and 'previous.raceCount < minimumRaces' in progression and 'latest.raceCount < minimumRaces' in progression)
ck('Only actual race or qualifying evidence is counted', 'if (raceResult == null && qualifyingResult == null) return@forEach' in prefs)
ck('Class evaluation runs at season rollover', 'reviewDriverClassesForCompletedSeason(previousSeason)' in prefs)
ck('Legacy V648 save migration is one-time and normalizes current ratings', 'driverClassSystemV649' in prefs and 'normalizeRatingsToClassBand(source, base.driverClass)' in prefs)
ck('Legacy save import triggers migration in the live process', 'migrateDriverClassSystemV649()' in prefs[prefs.find('fun importCareerBackup'):])
ck('Migration retains race-history archive', 'history.replaceArchiveBundle' in prefs and 'history.rollbackArchiveBundleReplacement' in prefs)
ck('Center development uses annual attribute caps', 'maxAnnualGain(driver.evolution)' in development and 'annualGains[it] < annualCap' in development)
ck('Center development recalculates class factor per point', 'overallAfterPreviousPoint' in development and 'random.nextDouble() > classFactor' in development)
ck('Random pilot class events removed from new calendars', 'planned += AnnualTeamEventEngine.Kind.DRIVER_CLASS_CHANGE' not in calendar)
ck('Old saved random driver event slots are consumed as no-ops', 'Kind.DRIVER_CLASS_CHANGE' in main and 'processedKeys += "${slot.week}:${slot.kind.name}:${slot.ordinal}"' in main)
ck('No time-based regression at season rollover', 'compatibility no-op for older call sites' in main and 'fun applySeasonEndRegression(seasonToClose:Int): Int = 0' in prefs)
ck('No age/retirement fields added to the driver model', not re.search(r'\b(?:val|var)\s+(?:age|retired|retirement)\b', evolution + read('app/src/main/java/com/f1teammanager/core/season/SeasonModels.kt'), re.I))
ck('Regression safety stays within 40–100', 'next[it]>40' in evolution and 'minimumOverall(driver:DriverDefinition):Int = 40' in evolution)
ck('V649 class-promotion runtime tests present', (ROOT/'app/src/test/kotlin/com/f1teammanager/core/season/DriverClassProgressionV649Test.kt').is_file())
ck('V649 ten-season simulation test present', (ROOT/'app/src/test/kotlin/com/f1teammanager/core/season/DriverEvolutionTenSeasonSimulationV649Test.kt').is_file())
ck('V649 release notes and detailed audit present', (ROOT/'CHANGELOG_V649.md').is_file() and (ROOT/'AUDIT_V649_DRIVER_CLASS_EVOLUTION.md').is_file())

failed = 0
for name, ok in checks:
    print(('PASS' if ok else 'FAIL') + ' | ' + name)
    failed += not ok
print(f'RESULT: {len(checks)-failed}/{len(checks)} checks passed')
raise SystemExit(1 if failed else 0)
