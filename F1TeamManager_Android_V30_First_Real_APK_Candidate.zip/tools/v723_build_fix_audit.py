#!/usr/bin/env python3
"""Static regression checks for the V723 fixes to the GitHub Actions Kotlin build errors."""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
main = (ROOT / "app/src/main/java/com/f1teammanager/MainActivity.kt").read_text(encoding="utf-8")
gradle = (ROOT / "app/build.gradle.kts").read_text(encoding="utf-8")
manifest = (ROOT / "package_manifest.txt").read_text(encoding="utf-8")
prefs = (ROOT / "app/src/main/java/com/f1teammanager/CareerPreferences.kt").read_text(encoding="utf-8")
checks = {}
checks["VersionCode and VersionName are V723"] = "versionCode = 723" in gradle and 'versionName = "0.723.0"' in gradle
checks["Package manifest records V723 with V722 as its base"] = "Version: 723 / 0.723.0" in manifest and "Base: V722 / 0.722.0" in manifest
checks["Original ZIP name and public app name are preserved"] = "F1TeamManager_Android_V30_First_Real_APK_Candidate.zip" in manifest and "Public name: F1 Team Manager V30" in manifest
checks["advanceFreeWeeksSegment is a valid local function"] = "    fun advanceFreeWeeksSegment(weeks: Int, targetWeek: Int) {" in main
checks["Invalid private modifier is removed from local function"] = "    private fun advanceFreeWeeksSegment(" not in main
checks["No other private function declarations remain nested in F1ManagerApp"] = len(re.findall(r"(?m)^\s{4}private\s+fun\s+", main[main.index("@Composable\nprivate fun F1ManagerApp"):main.index("@Composable private fun AppScaffold")])) == 0
checks["Weekly save call closes saveCareerStepBundle and check separately"] = "committedCurrentWeek = targetWeek)) {" in main
checks["Weekly save failure message remains the check lazy message"] = re.search(r"committedCurrentWeek\s*=\s*targetWeek\)\)\s*\{\s*\"Não foi possível salvar a progressão semanal completa de forma atômica\.\"\s*\}", main) is not None
checks["saveCareerStepBundle accepts committedCurrentWeek as its final optional argument"] = re.search(r"committedCurrentWeek:\s*Int\?\s*=\s*null\s*\)\s*:\s*Boolean", prefs) is not None
checks["No trailing lambda is passed to saveCareerStepBundle"] = "committedCurrentWeek = targetWeek) {" not in main
checks["Other saveCareerStepBundle call sites keep their check wrappers"] = all(token in main for token in ["incomingState.sponsors, null\n                    )) {", "updatedState.sponsors, updatedState.facilityUpgrade)) {", "managerState.driverMarket, managerState.sponsors, managerState.facilityUpgrade\n            )) {"])
checks["V722 investment table and annual cap implementation are retained"] = "fun annualOverallFromInvestment(" in (ROOT / "app/src/main/java/com/f1teammanager/core/manager/CarDevelopmentEngine.kt").read_text(encoding="utf-8")
checks["V721 annual event and projection regressions are retained"] = (ROOT / "app/src/test/kotlin/com/f1teammanager/core/manager/NextSeasonProjectionRunwayV721Test.kt").is_file() and (ROOT / "app/src/test/kotlin/com/f1teammanager/core/manager/AnnualFacilityEventContinuityV721Test.kt").is_file()
checks["Audio controls and team ranking assets are retained"] = (ROOT / "app/src/main/java/com/f1teammanager/ExternalAudio.kt").is_file() and "TEAM_RANKING" in main
checks["Changelog and build-fix audit report are included"] = (ROOT / "CHANGELOG_V723.md").is_file() and (ROOT / "AUDIT_V723_BUILD_FIX.md").is_file()

for label, ok in checks.items():
    print(("PASS" if ok else "FAIL") + " | " + label)
failed = sum(not ok for ok in checks.values())
print(f"RESULT: {len(checks) - failed}/{len(checks)} V723 build-fix checks passed")
sys.exit(1 if failed else 0)
