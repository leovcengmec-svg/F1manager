#!/usr/bin/env python3
"""Focused static regression checks preserving the V719 Kotlin compile fixes in newer releases."""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
main = (ROOT / "app/src/main/java/com/f1teammanager/MainActivity.kt").read_text(encoding="utf-8")
gradle = (ROOT / "app/build.gradle.kts").read_text(encoding="utf-8")
manifest = (ROOT / "package_manifest.txt").read_text(encoding="utf-8")

# Scope the navigation check to BackHandler, rather than finding the enum value anywhere.
back_start = main.index("BackHandler(enabled = true)")
back_end = main.index("val activityContext", back_start)
back_handler = main[back_start:back_end]

# Scope the Compose DSL check to SeasonArchive's LazyColumn builder.
season_start = main.index("private fun SeasonArchive(")
history_start = main.index("private fun HistoryScreen(", season_start)
season_archive = main[season_start:history_start]
lazy_start = season_archive.index("    LazyColumn(")
lazy_end = season_archive.index("\n    }\n}", lazy_start)
lazy_builder = season_archive[lazy_start:lazy_end]

version_match = re.search(r"versionCode\s*=\s*(\d+)", gradle)
version_code = int(version_match.group(1)) if version_match else -1
version_name = f"0.{version_code}.0"
base_code = version_code - 1

checks = {
    "V719 compile fixes are carried forward in the current release": version_code >= 720 and f'versionName = "{version_name}"' in gradle,
    "package manifest identifies current release and immediate base": f"Version: {version_code} / {version_name}" in manifest and f"Base: V{base_code} / 0.{base_code}.0" in manifest,
    "BackHandler explicitly handles TEAM_RANKING": re.search(r"Screen\.TEAM_RANKING\s*->\s*screen\s*=\s*Screen\.MANAGEMENT", back_handler) is not None,
    "SeasonArchive prepares driver rows in composable scope": "val driverRows = remember(archive, selectedSeason)" in season_archive and season_archive.index("val driverRows = remember") < lazy_start,
    "SeasonArchive prepares constructor rows in composable scope": "val constructorRows = remember(archive, selectedSeason)" in season_archive and season_archive.index("val constructorRows = remember") < lazy_start,
    "LazyListScope consumes precomputed driver rows": "items(driverRows) { SeasonDriverRow(it) }" in lazy_builder,
    "LazyListScope consumes precomputed constructor rows": "items(constructorRows) { SeasonConstructorRow(it) }" in lazy_builder,
    "No remember calls remain inside SeasonArchive LazyListScope": "remember(" not in lazy_builder,
    "Historical season selector and scope toggle are preserved": "HistoryScopeSelector(scope) { scope = it }" in lazy_builder and "selectedSeason = season" in lazy_builder,
}

for label, ok in checks.items():
    print(("PASS" if ok else "FAIL") + " | " + label)
failed = sum(not ok for ok in checks.values())
print(f"RESULT: {len(checks)-failed}/{len(checks)} V719 compile-fix checks passed")
sys.exit(1 if failed else 0)
