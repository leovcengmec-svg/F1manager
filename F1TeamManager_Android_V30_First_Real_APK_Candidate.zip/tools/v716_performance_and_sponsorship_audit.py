#!/usr/bin/env python3
"""Focused V716 regression audit: archive reuse, team navigation and sponsor tiers."""
from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[1]
main = (ROOT / "app/src/main/java/com/f1teammanager/MainActivity.kt").read_text(encoding="utf-8")
history = (ROOT / "app/src/main/java/com/f1teammanager/HistoricalDatabase.kt").read_text(encoding="utf-8")
sponsor = (ROOT / "app/src/main/java/com/f1teammanager/core/manager/TeamSponsorshipEngine.kt").read_text(encoding="utf-8")
test = (ROOT / "app/src/test/kotlin/com/f1teammanager/core/manager/SponsorOfferStabilityV712Test.kt").read_text(encoding="utf-8")
checks = {
    "merged archive lines are cached": "archiveLinesCache?.let { return it }" in history and ".also { archiveLinesCache = it }" in history,
    "parsed record snapshot is cached": "recordBookCache?.let { return it }" in history and ".also { recordBookCache = it }" in history,
    "Hall rankings are cached by scope and metric": "hallRankingCache[key]?.let { return it }" in history and "hallRankingCache.clear()" in history,
    "all Hall metrics are aggregated in one pair of archive passes": "hallValuesForPeriod(includeSeason = true)" in history and "hallValuesForPeriod(includeSeason = false)" in history and "HallAggregateSnapshot" in history,
    "archive mutations invalidate all read caches and clear legacy season slices on monolith writes": history.count("invalidateReadCaches()") >= 4 and "targetAtomicFile.finishWrite(output)\n            if (target.absoluteFile == file.absoluteFile) legacyRaceLinesBySeason.clear()\n            invalidateReadCaches()" in history,
    "history writes are synchronized with snapshot reads": "@Synchronized\n    private fun writeAtomicLines" in history,
    "record snapshot precomputes history rows and circuit indexes": all(k in history for k in ["victories:", "fastestLaps:", "circuits:", "racesByTeam:", "racesByTeamSeason:", "racesBySeason:", "polesByTeam:", "polesBySeason:", "circuitsBySeason:", "constructorSeasonsByTeam:", "constructorChampionsByTeam:"]),
    "Team Overview reads per-team history indexes": all(k in main for k in ["racesByTeam?.get(selectedTeam.id)", "racesByTeamSeason?.get(selectedTeam.id to store.season)", "polesByTeam?.get(selectedTeam.id)", "constructorSeasonsByTeam?.get(selectedTeam.id)"]),
    "40-team preparation is executed on Default dispatcher": "value = withContext(Dispatchers.Default)" in main[main.index("private fun TeamOverviewScreen("):main.index("private fun TeamOverviewBudgetCard(")],
    "team overview snapshots persist in a bounded single-entry cache across navigation": "TeamOverviewSnapshotMemoryCache.get(cacheKey)" in main and "TeamOverviewSnapshotMemoryCache.put(cacheKey, built)" in main and "private var cachedValue: List<TeamOverviewSnapshot>?" in main,
    "team-switch controls remain active while background snapshots load": "Você já pode navegar entre as equipes." in main and "onSelectTeam(quickOrder[quickIndex + 1].id)" in main,
    "team carousel selection is absent from snapshot cache keys": "selectedTeamId" not in main[main.index("val snapshotsState by produceState<List<TeamOverviewSnapshot>?>"):main.index("val snapshots = snapshotsState")],
    "History and Hall use background dispatchers": "withContext(Dispatchers.IO) { db.recordBookSnapshot() }" in main and "withContext(Dispatchers.Default) { db.hallRanking(scope, metric) }" in main,
    "Record screen reads one shared archive snapshot": "withContext(Dispatchers.IO) { db.recordBookSnapshot() }" in main and "val loadedArchive = archive" in main,
    "Record cards and milestone reconstruction run on Default dispatcher": "withContext(Dispatchers.Default)" in main[main.index("private fun RecordsScreen("):main.index("private fun RecordsPeriodSelector(")],
    "season-wide record calculations run outside Compose UI thread": "seasonCareerProjection by produceState" in main and "HistoricalRecordsEngine.driverSeason(driverSeasonRows.filter { it.season in completedSeasons }, finalizedRaces)" in main,
    "level-two first proposal remains BASIC": "val baseline = unlocked.first()" in sponsor and "val category = if (index == 0) baseline" in sponsor,
    "other proposals are independent category draws": "else drawCategory(marketingLevel, teamId, season, slot, round, index)" in sponsor,
    "proposal selection remains deterministic and excludes duplicate brands": "Random(drawSeed + index * 101L)" in sponsor and "usedNames += profile.name" in sponsor,
    "level-two regression test checks regional upgrades": "always offers a basic baseline and can independently offer regional upgrades" in test and "SponsorCategory.REGIONAL" in test,
}
for label, ok in checks.items():
    print(("PASS" if ok else "FAIL") + " | " + label)
failed = sum(not ok for ok in checks.values())
print(f"RESULT: {len(checks)-failed}/{len(checks)} V716 focused checks passed")
sys.exit(1 if failed else 0)
