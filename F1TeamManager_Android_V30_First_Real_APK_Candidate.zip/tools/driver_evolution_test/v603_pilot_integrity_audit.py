from pathlib import Path
import re
root = Path(__file__).resolve().parents[2]
prefs = (root/'app/src/main/java/com/f1teammanager/CareerPreferences.kt').read_text()
engine = (root/'app/src/main/java/com/f1teammanager/core/season/DriverEvolutionEngine.kt').read_text()
manager = (root/'app/src/main/java/com/f1teammanager/core/manager/ManagerSeasonEngine.kt').read_text()
main = (root/'app/src/main/java/com/f1teammanager/MainActivity.kt').read_text()
gradle = (root/'app/build.gradle.kts').read_text()
catalog = (root/'app/src/main/java/com/f1teammanager/core/season/DriverProfileCatalog.kt').read_text()
world = (root/'app/src/main/java/com/f1teammanager/core/season/WorldDatabase.kt').read_text()
roster_text = world.split('private val roster = listOf(', 1)[1].split('    )', 1)[0]
roster_rows = re.findall(r'"([^"]+)"', roster_text)
starting_drivers = []
for row in roster_rows:
    parts = row.split('|')
    if len(parts) == 3:
        starting_drivers.extend(parts[1:])
reserve_text = world.split('private val reserveMarket = listOf(', 1)[1].split('    )', 1)[0]
reserves = re.findall(r'"([^"]+)"', reserve_text)
profile_names = set(re.findall(r'^\s*"(.+?)" to Profile\(', catalog, re.M))
all_names = starting_drivers + reserves

checks = {
    '40 teams / 80 starters / 20 reserves / 100 unique names': len(roster_rows) == 40 and len(starting_drivers) == 80 and len(reserves) == 20 and len(set(all_names)) == 100,
    'all 100 current pilots have canonical profiles': len(profile_names) == 100 and set(all_names) == profile_names,
    'version V603': 'versionCode = 603' in gradle and 'versionName = "0.603.0"' in gradle,
    'bad Felipe heuristic removed': 'overall(canonical) >= 75.0' not in prefs and 'clearDriverEvolutionIdentityState' not in prefs,
    'fresh start seeds all current canonical attributes': 'val openingAttrs = WorldDatabase.allDrivers.associate' in prefs and 'saveDriverAttributes(openingAttrs)' in prefs,
    'fresh start clears phase state': 'key == "driverEvolutionPhases"' in prefs and 'key == "driverEvolutionPhaseGps"' in prefs,
    'season rollover preserves career phase state': 'Intentionally retain driverEvolutionPhases, phaseGps/start/target/pressure and' in prefs,
    'fractional bank carried into new season': 'val previousEvolutionBank = prefs.getString("driverEvolutionBank_$previousSeason", null)' in prefs and 'putString("driverEvolutionBank_$season", previousEvolutionBank)' in prefs,
    'normal career timer not reset on class target change': 'phaseTarget[id] = target\n                bank = 0.0' in prefs and 'phaseTarget[id] = target; gps = 0' not in prefs,
    'manager career timer not reset on class target change': 'phaseTarget[base.id] = target\n                phaseStart[base.id] = DriverProfileCatalog.overall(current.ratingsForManager())\n                bank = 0.0' in manager and 'phaseTarget[base.id] = target\n                gps = 0' not in manager,
    'regression uses overall class floor': 'if ((next.sum()-1) / 7 < floor) return@repeat' in engine,
    'Lenda ceiling remains 100': '"Lenda" -> 100' in catalog,
    'current roster reads the attribute map once': 'val attributes = driverAttributes()' in prefs and 'val current = driverDefinition(base.id)' not in prefs[prefs.index('fun currentDrivers()'):prefs.index('private fun readSeasonTargets()')],
    'current roster reads class overrides once': 'val classOverrides = driverClassOverrides()' in prefs[prefs.index('fun currentDrivers()'):prefs.index('private fun readSeasonTargets()')],
    'race plan resolves active career catalog': 'driverCatalog.firstOrNull { it.id == st.driverId }' in main,
    'fixed cycle centralized as 5/2/5': 'fun phaseDurationSeasons(phase: String)' in engine and 'phaseDurationSeasons(phase)' in prefs and 'phaseDurationSeasons(phase)' in manager,
    'unknown phase tokens default safely to growth': 'fun normalizePhase(phase: String?)' in engine and 'normalizePhase(phases[id])' in prefs and 'normalizePhase(phases[id])' in manager,
    'V602 calendar guard preserved': 'RaceCalendarGuard.validationError' in main,
    'rule new career remains documented': (root/'REGRA_NOVA_CARREIRA_A_CADA_ATUALIZACAO.md').exists(),
}
for name, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ' | ' + name)
assert all(checks.values()), 'One or more V603 integrity checks failed'
print(f'RESULT: {len(checks)}/{len(checks)} checks passed')
