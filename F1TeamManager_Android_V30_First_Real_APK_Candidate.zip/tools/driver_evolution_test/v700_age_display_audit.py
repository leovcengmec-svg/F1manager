from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[2]
main = (ROOT / "app/src/main/java/com/f1teammanager/MainActivity.kt").read_text(encoding="utf-8")
gradle = (ROOT / "app/build.gradle.kts").read_text(encoding="utf-8")
manifest = (ROOT / "package_manifest.txt").read_text(encoding="utf-8")
list_file = ROOT / "PILOT_AGES_V700.md"
test_file = ROOT / "app/src/test/kotlin/com/f1teammanager/core/season/DriverAgeVisibilityV700Test.kt"
checks = {
    "Android version is V700 / 0.700.0": "versionCode = 700" in gradle and 'versionName = "0.700.0"' in gradle,
    "package manifest matches V700": "Version: 700 / 0.700.0" in manifest and "Base: V699 / 0.699.0" in manifest,
    "all visible ages use career-age engine": "import com.f1teammanager.core.season.DriverEvolutionEngine" in main,
    "Team screen receives the active season": "Team(team.name, teamPerformance, teamReliability, store.season, drivers" in main,
    "Team driver card displays a prominent standalone age": 'Text("$age anos", color = Red, fontSize = 11.sp' in main,
    "Team driver profile cards display age": 'Text("$age anos", color = Color.White' in main,
    "Individual history header displays age": 'Text("$driverAge anos"' in main,
    "Driver market cards display age": 'Text("${DriverEvolutionEngine.careerAge(d, store.season)} anos", color = Red' in main,
    "New-driver proposal shows age": 'Text("${DriverEvolutionEngine.careerAge(d, store.season)} anos •' in main,
    "Development pilot choices display age on its own line": 'Text("${DriverEvolutionEngine.careerAge(d, season)} anos", color = Red' in main,
    "Team overview pilots display age": "TeamOverviewDrivers(teamDrivers, store.season, onDriverProfile)" in main,
    "100-driver age list exists": list_file.is_file() and "Pilotos reservas/mercado — 20 pilotos" in list_file.read_text(encoding="utf-8"),
    "CSV list contains 100 pilot rows": (ROOT / "PILOT_AGES_V700.csv").is_file() and len((ROOT / "PILOT_AGES_V700.csv").read_text(encoding="utf-8-sig").splitlines()) == 101,
    "age regression test exists": test_file.is_file(),
}
for name, ok in checks.items():
    print(("PASS" if ok else "FAIL") + " | " + name)
failed = sum(not ok for ok in checks.values())
print(f"RESULT: {len(checks)-failed}/{len(checks)} V700 age-display checks passed")
raise SystemExit(1 if failed else 0)
