#!/usr/bin/env python3
from pathlib import Path
root = Path(__file__).resolve().parents[2]
engine = (root/'app/src/main/java/com/f1teammanager/core/season/DriverEvolutionEngine.kt').read_text()
prefs = (root/'app/src/main/java/com/f1teammanager/CareerPreferences.kt').read_text()
manager = (root/'app/src/main/java/com/f1teammanager/core/manager/ManagerSeasonEngine.kt').read_text()
gradle = (root/'app/build.gradle.kts').read_text()
checks = {
    'version 604': 'versionCode = 604' in gradle and 'versionName = "0.604.0"' in gradle,
    'position-delta performance formula replaces ratio': '100.0 + (target - q) * 5.0' in engine and 'target / q * 100.0' not in engine,
    'expected performance uses baseline multiplier': 'index >= 92.0 -> 1.00' in engine and 'index >= 98.0 -> 1.05' in engine,
    'excellent performance accelerates growth': 'index >= 105.0 -> 1.15' in engine and 'index >= 115.0 -> 1.25' in engine,
    'poor performance still slows growth': 'index >= 75.0 -> 0.65' in engine and 'else -> 0.30' in engine,
    '40/60 qualifying and race weights retained': 'qualifyingScore * 0.40 + raceScore * 0.60' in engine,
    'missing normal-career results are neutral': 'qq?.position ?: expectedPosition' in prefs and 'rr?.position ?: expectedPosition' in prefs,
    'missing Team Principal results are neutral': 'qualifyingGrid[base.id]?.position ?: expectedPosition' in manager and 'classification[base.id]?.position ?: expectedPosition' in manager,
    'fixed 5/2/5 curve retained': 'fun phaseDurationSeasons(phase: String)' in engine and 'phaseDurationSeasons(phase)' in prefs and 'phaseDurationSeasons(phase)' in manager,
    'evolution type still sets annual cap': 'DriverProfileCatalog.maxAnnualGain(current.evolution)' in prefs and 'DriverEvolutionEngine.applyPositiveGain(current, whole, annualArray, rng)' in manager,
    'fresh career rule retained': (root/'REGRA_NOVA_CARREIRA_A_CADA_ATUALIZACAO.md').exists(),
    'V604 Kotlin regression test retained': (root/'app/src/test/kotlin/com/f1teammanager/core/season/DriverEvolutionPerformanceV604Test.kt').exists(),
    'audit and changelog retained': (root/'AUDIT_V604_DRIVER_EVOLUTION_PERFORMANCE.md').exists() and (root/'CHANGELOG_V604.md').exists(),
}
for label, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ' | ' + label)
assert all(checks.values()), 'V604 performance audit failed'
print(f'RESULT: {sum(checks.values())}/{len(checks)} checks passed')
