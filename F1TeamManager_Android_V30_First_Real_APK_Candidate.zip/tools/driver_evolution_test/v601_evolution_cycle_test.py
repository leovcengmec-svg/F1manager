"""Regression guard retained at its historical path; validates current V603 behavior."""
from pathlib import Path
r=Path(__file__).resolve().parents[2]
p=(r/"app/src/main/java/com/f1teammanager/CareerPreferences.kt").read_text()
m=(r/"app/src/main/java/com/f1teammanager/core/manager/ManagerSeasonEngine.kt").read_text()
e=(r/"app/src/main/java/com/f1teammanager/core/season/DriverEvolutionEngine.kt").read_text()
g=(r/"app/build.gradle.kts").read_text()
checks={
"version 603":"versionCode = 603" in g and "0.603.0" in g,
"5-year ascent":"phaseDurationSeasons(phase)" in p and '"GROWING" -> 5' in e,
"2-year peak":'"PEAK" -> 2' in e,
"5-year regression":'"REGRESSION" -> 5' in e,
"no early pressure regression":"if (pp >= 12.0)" not in p and "if (p >= 12.0)" not in m,
"annual gain map loaded":"val annualGains = readAnnualAttributeGains()" in p,
"annual gain map persisted":"driverEvolutionAttributeGains_$season" in p,
"legend ceiling 100":"\"Lenda\" -> 100" in (r/"app/src/main/java/com/f1teammanager/core/season/DriverProfileCatalog.kt").read_text(),
}
for k,v in checks.items(): print(("PASS" if v else "FAIL")+" | "+k)
assert all(checks.values())
