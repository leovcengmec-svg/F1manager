#!/usr/bin/env python3
"""Deterministic scenario stress test for V437 finance guardrails.

This is a model-level stress test, not a substitute for Android/JUnit runtime tests.
It uses exact team class counts, opening cash, tiered race operating costs, GP prize tiers and season prizes
from source, with explicitly stated representative salary/sponsor inputs.
"""
from statistics import median

LEVELS = {2: 11, 1: 14, 0: 15}
OPENING = {2: 100_000_000, 1: 83_750_000, 0: 67_500_000}
ANNUAL_SALARY = {2: 55_000_000, 1: 30_000_000, 0: 14_000_000}
SPONSOR_UPFRONT = {2: 25_000_000, 1: 14_000_000, 0: 7_000_000}
SPONSOR_GP = {2: 2_500_000, 1: 1_500_000, 0: 750_000}
SEASON_PRIZE = {2: 44_000_000, 1: 18_000_000, 0: 10_000_000}
GP_PRIZE = {2: 1_500_000, 1: 500_000, 0: 500_000}
GP_OPERATING_COST = {2: 2_200_000, 1: 1_700_000, 0: 1_200_000}

def phase_percent(round_number):
    return 10 if round_number <= 8 else 15 if round_number <= 15 else 25 if round_number <= 22 else 35

def protected_cash(budget):
    if budget <= 0:
        return 0
    return min(budget, max(budget // 5, 2_000_000))

def maximum_investment(budget_base, round_number):
    free = max(0, budget_base - protected_cash(budget_base))
    return min(150_000_000, free * phase_percent(round_number) // 100)

def main():
    # Boundary checks
    assert [phase_percent(r) for r in (1, 9, 16, 23, 30)] == [10, 15, 25, 35, 35]
    assert maximum_investment(100_000_000, 1) == 8_000_000
    assert maximum_investment(100_000_000, 10) == 12_000_000
    assert maximum_investment(1_000_000, 1) == 0
    assert protected_cash(100_000_000) == 20_000_000

    cash = {}
    records = []
    for level, count in LEVELS.items():
        for team in range(count):
            cash[(level, team)] = OPENING[level]
    for season in range(2026, 2031):
        for (level, team), opening in list(cash.items()):
            budget = opening + SPONSOR_UPFRONT[level]
            spent = 0
            for round_number in range(1, 31):
                budget += SPONSOR_GP[level] + GP_PRIZE[level] - GP_OPERATING_COST[level] - ANNUAL_SALARY[level] // 30
                budget = max(0, budget)
                cumulative_cap = maximum_investment(opening + SPONSOR_UPFRONT[level], round_number)
                free_to_spend = max(0, budget - protected_cash(budget))
                remaining_cap = max(0, cumulative_cap - spent)
                requested = 1_000_000 if level == 2 else 500_000 if level == 1 else 0
                spend = min(requested, remaining_cap, free_to_spend)
                budget -= spend
                spent += spend
            budget += SEASON_PRIZE[level]
            cash[(level, team)] = budget
            records.append((season, level, budget, spent))

    print("PASS: phase limits, cumulative cap, cash reserve and low-cash boundaries")
    for level, label in ((2, "Grande"), (1, "Média"), (0, "Pequena")):
        final = [r[2] for r in records if r[0] == 2030 and r[1] == level]
        print(f"{label}: equipes={len(final)}, caixa_min={min(final)/1e6:.1f}M, "
              f"mediana={median(final)/1e6:.1f}M, caixa_max={max(final)/1e6:.1f}M, "
              f"insolventes={sum(x <= 0 for x in final)}")
    print("FINDING: custos operacionais por nível foram aumentados; excedentes remanescentes devem ser avaliados com dados reais de contratos e salários.")
    print("LIMIT: patrocínios e salários são hipóteses de cenário; não equivale à execução real da IA Android.")

if __name__ == "__main__":
    main()
