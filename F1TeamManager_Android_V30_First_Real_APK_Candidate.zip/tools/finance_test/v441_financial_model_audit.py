#!/usr/bin/env python3
"""Deterministic source/data audit for 40-team financial model invariants (not Android runtime)."""
from pathlib import Path
import re, sys
ROOT = Path(__file__).resolve().parents[2]
checks=[]
def check(name, ok, detail=''):
    checks.append((name, bool(ok), detail))
def read(path):
    p=ROOT/path
    return p.read_text(encoding='utf-8') if p.is_file() else ''
prize=read('app/src/main/java/com/f1teammanager/core/manager/SeasonPrizeEngine.kt')
cost=read('app/src/main/java/com/f1teammanager/core/manager/RaceOperatingCost.kt')
profile=read('app/src/main/java/com/f1teammanager/core/manager/InitialTeamProfile.kt')
test=read('app/src/test/kotlin/com/f1teammanager/core/manager/FinancialModelV441Test.kt')
gradle=read('app/build.gradle.kts')
check('constructor prize supports expanded rankings with a stable floor', 'require(position >= 1)' in prize and 'in 11..20' in prize and 'coerceAtLeast(30.0)' in prize and 'position - 21' in prize)
check('constructor prize endpoints retained', '1 -> 100.0' in prize and '2 -> 92.0' in prize and 'return (millions * 1_000_000L).toLong()' in prize)
check('all three canonical operating cost tiers exist', all(v in cost for v in ('2_500_000L','1_500_000L','800_000L')))
check('opening budgets exist for all three team levels', all(v in profile for v in ('100_000_000L','83_750_000L','67_500_000L')))
check('JUnit covers prize monotonicity and unique values', 'StrictlyDescendingAndBounded' in test and 'prizes.toSet().size' in test)
check('JUnit checks costs across all database teams', 'WorldDatabase.teams.forEach' in test and 'RaceOperatingCost.forTeam' in test)
version_code = re.search(r'versionCode\s*=\s*(\d+)', gradle)
version_name = re.search(r'versionName\s*=\s*"([^"]+)"', gradle)
check('current version metadata is internally consistent', bool(version_code and version_name and version_name.group(1) == f"0.{int(version_code.group(1))}.0"))
for name,ok,detail in checks:
    print(('PASS' if ok else 'FAIL')+' | '+name+((' | '+detail) if detail else ''))
failed=sum(not ok for _,ok,_ in checks)
print(f'RESULT: {len(checks)-failed}/{len(checks)} financial model source checks passed')
print('LIMIT: Static source/data audit only; does not execute Kotlin/JUnit or compile Android.')
sys.exit(1 if failed else 0)
