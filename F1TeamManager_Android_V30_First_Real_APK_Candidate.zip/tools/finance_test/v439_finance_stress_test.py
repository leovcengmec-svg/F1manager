#!/usr/bin/env python3
"""Deterministic scenario stress test for V437 finance guardrails.

This is a model-level stress test, not a substitute for Android/JUnit runtime tests.
It uses exact team class counts, opening cash, tiered race operating costs, GP prize tiers and season prizes
from source, with explicitly stated representative salary/sponsor inputs.
"""
from statistics import median

LEVELS = {2: 11, 1: 14, 0: 15}
OPENING = {2: 100_000_000, 1: 83_750_000, 0: 67_500_000}
ANNUAL_SALARY = {2: 55_000_000, 1: 30_000_000, 0: 14_000_000}
SPONSOR_UPFRONT = {2: 25_000_000, 1: 14_000_000, 0: 7_000_000}
SPONSOR_GP = {2: 2_500_000, 1: 1_500_000, 0: 750_000}
GP_OPERATING_COST = {2: 2_200_000, 1: 1_700_000, 0: 1_200_000}

def phase_percent(round_number):
    return 10 if round_number <= 8 else 15 if round_number <= 15 else 25 if round_number <= 22 else 35

def protected_cash(budget):
    if budget <= 0:
        return 0
    return min(budget, max(budget // 5, 2_000_000))

def maximum_investment(budget_base, round_number):
    free = max(0, budget_base - protected_cash(budget_base))
    return min(150_000_000, free * phase_percent(round_number) // 100)

def season_prize(position):
    prizes = [100,90,82,75,69,63,58,53,48,44,41,39,37,35,33,31,29,27,25,23,
              22,21,20,19,18,17,16,15,14,13,12.5,12,11.5,11,10.8,10.6,10.4,10.2,10.1,10]
    assert 1 <= position <= 40
    return int(prizes[position - 1] * 1_000_000)

def gp_prize(best_finish):
    if best_finish <= 3: return 2_500_000
    if best_finish <= 10: return 1_500_000
    if best_finish <= 20: return 900_000
    return 500_000

def main():
    # Boundary checks
    assert [phase_percent(r) for r in (1, 9, 16, 23, 30)] == [10, 15, 25, 35, 35]
    assert maximum_investment(100_000_000, 1) == 8_000_000
    assert maximum_investment(100_000_000, 10) == 12_000_000
    assert maximum_investment(1_000_000, 1) == 0
    assert protected_cash(100_000_000) == 20_000_000
    assert season_prize(1) == 100_000_000 and season_prize(40) == 10_000_000
    assert all(season_prize(p) > season_prize(p + 1) for p in range(1, 40))

    cash = {}
    records = []
    for level, count in LEVELS.items():
        for team in range(count):
            cash[(level, team)] = OPENING[level]
    # Stable illustrative standings: strength classes occupy ordered rank bands.
    # Within each class team index determines tie-break order, matching deterministic ranking.
    ordered = sorted(cash, key=lambda key: (-key[0], key[1]))
    rank_by_team = {team_key: rank for rank, team_key in enumerate(ordered, start=1)}
    for season in range(2026, 2031):
        for (level, team), opening in list(cash.items()):
            budget = opening + SPONSOR_UPFRONT[level]
            spent = 0
            team_rank = rank_by_team[(level, team)]
            best_finish = min(80, team_rank * 2 - 1)
            for round_number in range(1, 31):
                budget += SPONSOR_GP[level] + gp_prize(best_finish) - GP_OPERATING_COST[level] - ANNUAL_SALARY[level] // 30
                budget = max(0, budget)
                cumulative_cap = maximum_investment(opening + SPONSOR_UPFRONT[level], round_number)
                free_to_spend = max(0, budget - protected_cash(budget))
                remaining_cap = max(0, cumulative_cap - spent)
                requested = 1_000_000 if level == 2 else 500_000 if level == 1 else 0
                spend = min(requested, remaining_cap, free_to_spend)
                budget -= spend
                spent += spend
            budget += season_prize(team_rank)
            cash[(level, team)] = budget
            records.append((season, level, budget, spent))

    print("PASS: phase limits, cumulative cap, cash reserve, GP prize logic and all 40 season-prize positions")
    for level, label in ((2, "Grande"), (1, "Média"), (0, "Pequena")):
        final = [r[2] for r in records if r[0] == 2030 and r[1] == level]
        print(f"{label}: equipes={len(final)}, caixa_min={min(final)/1e6:.1f}M, "
              f"mediana={median(final)/1e6:.1f}M, caixa_max={max(final)/1e6:.1f}M, "
              f"insolventes={sum(x <= 0 for x in final)}")
    print("FINDING: cenário usa posições determinísticas ilustrativas; o motor real precisa ser executado para medir resultados de temporada reais.")
    print("LIMIT: salários e patrocínios são hipóteses; o cenário não executa contratos, trocas de patrocinadores, mercado ou motor IA Kotlin.")

if __name__ == "__main__":
    main()
