#!/usr/bin/env python3
"""Static regression audit for V731 driver evolution and class progression."""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]

def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")

gradle = read("app/build.gradle.kts")
manifest = read("package_manifest.txt")
evolution = read("app/src/main/java/com/f1teammanager/core/season/DriverEvolutionEngine.kt")
progression = read("app/src/main/java/com/f1teammanager/core/season/DriverClassProgressionEngine.kt")
development = read("app/src/main/java/com/f1teammanager/core/manager/DriverDevelopmentEngine.kt")
career = read("app/src/main/java/com/f1teammanager/CareerPreferences.kt")
manager = read("app/src/main/java/com/f1teammanager/core/manager/ManagerSeasonEngine.kt")
models = read("app/src/main/java/com/f1teammanager/core/manager/ManagerModels.kt")
main = read("app/src/main/java/com/f1teammanager/MainActivity.kt")

checks = {
    "release metadata is V731": "versionCode = 731" in gradle and 'versionName = "0.731.0"' in gradle and "Version: 731 / 0.731.0" in manifest and "Base: V730 / 0.730.0" in manifest,
    "Médio receives a five-point band regardless of contract": '"Médio" -> 5' in evolution,
    "Forte receives five points free and performance-gated while contracted": '"Forte" -> if (isContracted) performanceClassMargin(seasonPerformanceAverage) else 5' in evolution,
    "Pro is performance-gated in both contract states": '"Pro" -> performanceClassMargin(seasonPerformanceAverage)' in evolution,
    "Lenda receives no additional band": '"Lenda" -> 0' in evolution,
    "performance thresholds unlock +1 through +5": all(t in evolution for t in ["average >= 110.0 -> 1", "average >= 120.0 -> 2", "average >= 130.0 -> 3", "average >= 140.0 -> 4", "average >= 150.0 -> 5"]),
    "gated classes use season average only, not a single GP score": "classGrowthMargin(driver.driverClass, isContracted, seasonPerformanceAverage)" in evolution and "seasonPerformanceAverage ?: performanceIndex" not in evolution,
    "Médio and free Forte retain normal growth speed": 'canonical == "Médio" || (canonical == "Forte" && !isContracted)' in evolution,
    "contracted Forte and Pro have progressive above-ceiling growth factor": all(t in evolution for t in ["excess <= 2 -> 0.90", "excess <= 4 -> 0.80", "else -> 0.70"]),
    "overall class margin is capped at five and at global 100": "classCeilingMargin.coerceIn(0, 5)" in evolution and "effectiveCeiling" in evolution and ".coerceAtMost(100)" in evolution,
    "potential remains an absolute positive-growth ceiling": "potentialOverall.coerceIn(40, 100)" in evolution and "minOf(driver.potentialOverall" in evolution,
    "free-agent tick explicitly uses uncontracted rules": "isContracted = false" in evolution,
    "Career mode identifies active contracts before natural growth": "isContracted = id in activeDriverIds" in career,
    "P&D uses the same class gate and preserves unallocated points": "DriverEvolutionEngine.classGrowthMargin(" in development and "applied.remaining" in development and "seasonPerformanceAverages[driver.id]" in development,
    "player P&D passes team membership and season-performance averages": "contractedDriverIds = playerTeamDriverIds" in main and "seasonPerformanceAverages = store.driverSeasonPerformanceAverages()" in main,
    "AI P&D passes contracted drivers and current-season averages": "contractedDriverIds = teamIds" in manager and "seasonPerformanceAverages = seasonAverages" in manager,
    "class review remains biennial for sporting promotion/demotion": "completedSeason % 2 == 1" in career and "completedSeason % 2 == 1" in manager,
    "promotion retains two-season evidence, 80% minimum, 105 combined and title gate": all(t in progression for t in ["previous.averageIndex >= 100.0", "latest.averageIndex >= 100.0", "average >= 105.0", "minimumEvidenceRaces", "!isChampion"]),
    "poor performance can demote Lenda as well as Pro and Forte": "if (index > 0)" in progression and "overall <= currentBandEntry - 2" in progression and "Lenda never" not in progression,
    "uncontracted thresholds are Forte 2, Pro 3, Lenda 5": all(t in progression for t in ['"Forte" -> 2', '"Pro" -> 3', '"Lenda" -> 5']),
    "an active contract resets the consecutive absence counter": "if (hasActiveContract) 0 else previousCount.coerceAtLeast(0) + 1" in progression,
    "absence demotion is one class step and class clock resets": "evaluateUncontractedAbsence" in career and "uncontractedCounts.remove(base.id)" in career and "absenceCounts.remove(base.id)" in manager,
    "absence counter is persisted in CareerPreferences": "driverClassUncontractedSeasonCounts" in career and "encodeDriverClassUncontractedSeasonCounts" in career,
    "absence counter is included in full preference backup": "encodePreferenceSnapshot(prefs.all)" in career,
    "Team Manager state includes absence counter": "driverClassUncontractedSeasonCounts:Map<Int,Int>" in models,
    "absence counts start fresh after a new career": 'key == "driverClassUncontractedSeasonCounts"' in career,
    "class notifications retain the reason in Events of Pilots": 'MarketNewsCategory.DRIVER_EVENTS' in career and 'Motivo: ${change.reason}' in career,
    "V730 car-only targets remain unchanged": "Car strength is the only permitted performance input" in evolution and "Driver Overall, qualifying skill, class, potential" in evolution,
    "existing age cycle 18–45 and 30% reset remain": "AGE_CYCLE_END = 45" in evolution and "AGE_CYCLE_RESET_REDUCTION_RATE = 0.30" in evolution,
    "V731 changelog and stabilization audit are included": (ROOT / "CHANGELOG_V731.md").is_file() and (ROOT / "AUDIT_V731_STABILIZATION.md").is_file(),
    "focused ceiling and class progression tests exist": (ROOT / "app/src/test/kotlin/com/f1teammanager/core/season/DriverClassCeilingMarginV702Test.kt").is_file() and (ROOT / "app/src/test/kotlin/com/f1teammanager/core/season/DriverClassProgressionV731Test.kt").is_file(),
}

for label, ok in checks.items():
    print(("PASS" if ok else "FAIL") + " | " + label)
failed = sum(not ok for ok in checks.values())
print(f"RESULT: {len(checks)-failed}/{len(checks)} V731 driver-rule checks passed")
sys.exit(1 if failed else 0)
