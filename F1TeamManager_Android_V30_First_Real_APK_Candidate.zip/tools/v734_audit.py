#!/usr/bin/env python3
"""Static V734 checks for the GP30 finalization and driver +5 class-band fix."""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
def read(rel):
    return (ROOT / rel).read_text(encoding="utf-8")

gradle = read("app/build.gradle.kts")
manifest = read("package_manifest.txt")
plan = read("app/src/main/java/com/f1teammanager/core/manager/RaceFinalizationPlan.kt")
journal = read("app/src/main/java/com/f1teammanager/core/manager/RaceFinalizationJournal.kt")
main = read("app/src/main/java/com/f1teammanager/MainActivity.kt")
evolution = read("app/src/main/java/com/f1teammanager/core/season/DriverEvolutionEngine.kt")
career = read("app/src/main/java/com/f1teammanager/CareerPreferences.kt")
development = read("app/src/main/java/com/f1teammanager/core/manager/DriverDevelopmentEngine.kt")
manager = read("app/src/main/java/com/f1teammanager/core/manager/ManagerSeasonEngine.kt")
models = read("app/src/main/java/com/f1teammanager/core/manager/ManagerModels.kt")
checks = {
    "release metadata is V734 based on V733": "versionCode = 734" in gradle and 'versionName = "0.734.0"' in gradle and "Version: 734 / 0.734.0" in manifest and "Base: V733 / 0.733.0" in manifest,
    "canonical garage step is declared with exact persisted key": 'const val AI_CANONICAL_NEXT_SEASON_GARAGES = "ai_canonical_next_season_garages"' in plan,
    "canonical garage step is only included at GP30": "if (round == totalRounds)" in plan and "SEASON_PRIZES + AI_CANONICAL_NEXT_SEASON_GARAGES + PERSIST_FINAL_STATE" in plan,
    "MainActivity uses the plan constant": "RaceFinalizationPlan.AI_CANONICAL_NEXT_SEASON_GARAGES" in main,
    "journal still validates the plan and idempotent markers": "step in plannedSteps" in journal and "if (isDone(season, round, step)) return" in journal,
    "normal GP score remains separate with 40/60 and target tolerance": "qualifyingScore * 0.40 + raceScore * 0.60" in evolution and "positionBandScore(q, qCenter, target.qualifyingMargin)" in evolution,
    "class unlock scoring recognizes poles and wins": "if (q == 1) 50.0 else 0.0" in evolution and "if (r == 1) 50.0 else 0.0" in evolution,
    "unlock scoring keeps the 40/60 weighting": "qScore * 0.40 + rScore * 0.60" in evolution,
    "five real GPs are required": "CLASS_MARGIN_MINIMUM_GP_SAMPLE = 5" in evolution and "completedGps < CLASS_MARGIN_MINIMUM_GP_SAMPLE" in evolution,
    "unlock margin thresholds remain +1 through +5": all(x in evolution for x in ["average >= 110.0 -> 1", "average >= 120.0 -> 2", "average >= 130.0 -> 3", "average >= 140.0 -> 4", "average >= 150.0 -> 5"]),
    "earned margin is monotonic": "previousMargin.coerceIn(0, 5)" in evolution and "maxOf(" in evolution and "earnedClassMargin" in evolution,
    "career active driver passes real sample count": "seasonPerformanceSamples = nextUnlockAccumulated.second" in career,
    "career persists separate unlock evidence and earned margin": 'putString("driverClassUnlockPerformance_$season"' in career and 'putString("driverClassMarginEarned_$season"' in career,
    "V733 migration rebuilds from real results and frozen car-only target snapshots": "migrateDriverClassUnlockScoringV734" in career and "history.raceRecords(seasonNumber)" in career and "driverSeasonTargetsVersion_$seasonNumber" in career,
    "migration avoids recounting an unprocessed current GP": "race.round < currentRound" in career and "currentRoundAlreadyProcessed" in career,
    "Pro free agent uses last season evidence and its count": "previousUnlockAverage" in career and "seasonPerformanceSamples = previousUnlock?.second ?: 0" in career,
    "player facility development receives average count and earned margin": "seasonPerformanceSamples = store.driverSeasonClassUnlockPerformanceSamples()" in main and "earnedClassMargins = store.driverSeasonEarnedClassMargins()" in main,
    "facility development retains and retries reserved points": "nextReserve.toMap().forEach" in development and "completedGps = seasonPerformanceSamples[driverId] ?: 0" in development,
    "Team Manager active/free paths use same scoring and sample counts": "classUnlockPerformanceIndex(target, q, r)" in manager and "seasonPerformanceSamples = nextUnlock.raceCount" in manager and "seasonPerformanceSamples = previousUnlock?.raceCount ?: 0" in manager,
    "Team Manager persists unlock and high-water maps in state": "driverClassUnlockPerformance=unlockPerformance.mapValues" in manager and "driverClassEarnedMargins=earnedMargins.mapValues" in manager and "driverClassUnlockPerformance:" in models and "driverClassEarnedMargins:" in models,
    "focused test files exist": (ROOT / "app/src/test/kotlin/com/f1teammanager/core/season/DriverClassUnlockMarginV734Test.kt").is_file() and (ROOT / "app/src/test/java/com/f1teammanager/core/manager/RaceFinalizationCanonicalGarageV734Test.kt").is_file(),
    "release notes and audit exist": (ROOT / "CHANGELOG_V734.md").is_file() and (ROOT / "AUDIT_V734_EVOLUTION_GP30.md").is_file(),
}
for name, ok in checks.items():
    print(("PASS" if ok else "FAIL") + " | " + name)
failed = sum(not ok for ok in checks.values())
print(f"RESULT: {len(checks)-failed}/{len(checks)} V734 static checks passed")
sys.exit(1 if failed else 0)
