#!/usr/bin/env python3
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
car=(ROOT/'app/src/main/java/com/f1teammanager/core/manager/CarDevelopmentEngine.kt').read_text()
gradle=(ROOT/'app/build.gradle.kts').read_text()
manifest=(ROOT/'package_manifest.txt').read_text()
test=(ROOT/'app/src/test/kotlin/com/f1teammanager/core/manager/OverallInvestmentAnnualCapV722Test.kt').read_text()
ai_test=(ROOT/'app/src/test/kotlin/com/f1teammanager/core/manager/AITeamInvestmentV652Test.kt').read_text()
checks=[]
def ck(n,v): checks.append((n,bool(v)))
ck('VersionCode and VersionName are V722','versionCode = 722' in gradle and 'versionName = "0.722.0"' in gradle)
ck('Package manifest matches V722','Version: 722 / 0.722.0' in manifest)
ck('Official table retains €8M and €150M endpoints','8_000_000L' in car and '150_000_000L' in car)
ck('61 Overall reference rows remain present','referencesByOverall' in car and 'longArrayOf(' in car)
ck('Annual shared rule uses table target','fun annualOverallFromInvestment' in car and 'constructionOverallForInvestment(invested)' in car)
ck('Annual loss floor is previous Overall minus ten','(previous - 10).coerceAtLeast(40)' in car)
ck('Annual growth ceiling remains policy-driven','NextSeasonCarGrowthPolicy.maximumGain(previous)' in car)
ck('AI physical builder delegates to shared builder','fun buildAiNextSeasonGarage' in car and 'return buildNextSeasonGarage(' in car)
ck('AI legacy builder delegates to shared legacy builder','return buildNextSeasonLegacyCar(' in car)
ck('No €1M shortfall-to-point calculation remains','missingMillions' not in car and 'shortfall + 999_999L' not in car)
ck('Player rollover applies the annual floor','minimumOverall = (previousOverall - 10)' in car)
ck('Player forecast applies the same annual floor','minimumOverall = (overall - 10)' in car)
ck('New tests cover exact reference rows and parity','officialTableMapsInvestmentToOverall' in test and 'playerAndAiShareSameAnnualInvestmentResult' in test)
ck('New tests cover ten-point cap and monotonicity','annualLossNeverExceedsTenAndGrowthUsesExistingPolicy' in test and 'everyInvestmentLevelIsMonotonic' in test)
ck('Legacy AI tests no longer encode per-component euro penalty','MissingMillions' not in ai_test and 'target - 7_000_000L' not in ai_test)
ck('Changelog and audit report exist',(ROOT/'CHANGELOG_V722.md').is_file() and (ROOT/'AUDIT_V722_OVERALL_INVESTMENT.md').is_file())
for n,v in checks: print(('PASS' if v else 'FAIL')+' | '+n)
failed=[n for n,v in checks if not v]
print(f'RESULT: {len(checks)-len(failed)}/{len(checks)} V722 checks passed')
if failed: sys.exit(1)
