#!/usr/bin/env python3
"""Static scalability and longevity checks for V718."""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
main = (ROOT / "app/src/main/java/com/f1teammanager/MainActivity.kt").read_text(encoding="utf-8")
history = (ROOT / "app/src/main/java/com/f1teammanager/HistoricalDatabase.kt").read_text(encoding="utf-8")
engine = (ROOT / "app/src/main/java/com/f1teammanager/core/manager/AITeamDevelopmentEngine.kt").read_text(encoding="utf-8")
checkpoint = (ROOT / "app/src/main/java/com/f1teammanager/AiDevelopmentCheckpointStore.kt").read_text(encoding="utf-8")
finance = (ROOT / "app/src/main/java/com/f1teammanager/core/manager/AITeamFinancialEngine.kt").read_text(encoding="utf-8")
codec = (ROOT / "app/src/main/java/com/f1teammanager/core/manager/AIFinanceTransactionCodec.kt").read_text(encoding="utf-8")
gradle = (ROOT / "app/build.gradle.kts").read_text(encoding="utf-8")
manifest = (ROOT / "package_manifest.txt").read_text(encoding="utf-8")

m = re.search(r"versionCode\s*=\s*(\d+)", gradle)
version = int(m.group(1)) if m else -1

checks = {
    "V718 scalability features remain in the current release": version >= 718 and f'versionName = "0.{version}.0"' in gradle and f"Version: {version} / 0.{version}.0" in manifest,
    "standard AI development has bounded physical simulation cache": "MAX_ENTRIES = 96" in engine and "PhysicalSimulationMemoryCache.get(key)" in engine,
    "historical opening cache is bounded": "MAX_ENTRIES = 160" in engine and "HistoricalOpeningMemoryCache.get(" in engine,
    "normal AI development reuses durable season-opening checkpoints": "checkpointStore?.loadCandidates(team.id, targetSeason)" in engine and "checkpointStore?.save(" in engine,
    "normal checkpoint fingerprint includes career and deterministic inputs": all(x in engine for x in ["AI_PHYSICAL_CHECKPOINT_V3", "careerScope", "seed, regulationSeed", "investmentPrefix", "rankingFingerprint"]),
    "Team Principal handoff development has its own checkpoint path": "historicalOpeningStateFromHandoff" in engine and "AI_HANDOFF_CHECKPOINT_V1" in engine,
    "handoff checkpoint is stored at opening and rollover": engine.count("AITeamDevelopmentHistoricalCheckpoint(team.id,") >= 2,
    "handoff current-season projection uses shared bounded simulation cache": "PhysicalSimulationMemoryCache.get(key)" in engine and "PhysicalSimulationMemoryCache.put(key, current)" in engine,
    "checkpoint store filenames include the content fingerprint": "fingerprint.take(16)" in checkpoint and "checkpointFile(checkpoint)" in checkpoint,
    "checkpoint disk growth is bounded per team": "files.drop(8)" in checkpoint,
    "checkpoint writes are atomic and disposable": "AtomicFile(file)" in checkpoint and "atomic.finishWrite(stream)" in checkpoint,
    "all MainActivity AI simulation engines share a stable seed": "AITeamDevelopmentEngine(20261005 + store.season" not in main and "AITeamDevelopmentEngine(20261005," in main,
    "weekly and race AI batches freeze technical ranking once": all(x in main for x in ["weeklyInvestmentRanking", "raceInvestmentRanking", "eventInvestmentRanking", "finalizationInvestmentRanking"]),
    "team overview and team ranking share the AI garage snapshot cache": "TeamGarageSnapshotMemoryCache.get(cacheKey)" in main and "TeamGarageSnapshotMemoryCache.get(key)" in main and "TeamGarageSnapshotMemoryCache.put(key, rows.filter" in main,
    "team overview and ranking cache keys include career and financial fingerprints": "careerId: String" in main and "aiStateFingerprint: Int" in main and "performanceFingerprint(store.season)" in main,
    "MainActivity does not hash full AI finance export for cache keys": "exportSnapshot().hashCode()" not in main,
    "compact finance fingerprint excludes full transaction serialization": "fun performanceFingerprint(season: Int)" in finance and "finance.transactions" not in finance[finance.index("fun performanceFingerprint(season: Int)"):finance.index("\n    /**", finance.index("fun performanceFingerprint(season: Int)"))],
    "large finance ledgers are gzip-compressed in snapshots": "GZIPOutputStream" in codec and "AIFinanceTransactionCodec.encode(f.transactions)" in finance,
    "all historical AI negative-balance penalties are persisted as N ledger rows": 'listOf("N", teamId, penaltySeason)' in finance and 'p.firstOrNull() == "N"' in finance,
    "AI penalty authority is restored from the full historical ledger": "FinancialSeasonClosureEngine.restoreAiPenalties(negativeBalancePenalties.keys)" in finance and "fun restoreAiPenalties(entries: Set<Pair<Int, Int>>)" in (ROOT / "app/src/main/java/com/f1teammanager/core/manager/FinancialSeasonClosureEngine.kt").read_text(encoding="utf-8"),
    "historical penalty multi-season snapshot regression test is included": (ROOT / "app/src/test/java/com/f1teammanager/core/manager/AIFinancePenaltyLedgerV718Test.kt").is_file(),
    "old raw Base64 transaction ledgers remain readable": "else outer" in codec and "takeLast(20_000)" in codec,
    "history summary repair is deferred until an archive query": "ensureSeasonSummaryRepair()" in history and "reconcileCompletedSeasonSummaries()" not in history[history.index("init {"):history.index("private fun ensureSeasonSummaryRepair")],
    "historical record-book snapshot is synchronized and cached": "@Synchronized\n    fun recordBookSnapshot()" in history and "recordBookCache?.let { return it }" in history,
    "raw archive lines are released after parsed snapshot creation": "archiveLinesCache = null" in history[history.index("fun recordBookSnapshot()"):history.index("fun seasons()")],
    "legacy monolithic season slices use a bounded cache": "while (legacyRaceLinesBySeason.size > 4)" in history,
    "legacy slices and shared archive caches invalidate on writes": "if (target.absoluteFile == file.absoluteFile) legacyRaceLinesBySeason.clear()\n            invalidateReadCaches()" in history,
    "Home reads only the newest GP shard and does so on IO": "fun latestRaceRecords()" in history and "store.history.latestRaceRecords()" in main and "withContext(Dispatchers.IO)" in main,
    "History, Hall, Records and Team Principal archive loads run off UI thread": main.count("withContext(Dispatchers.IO) { db.recordBookSnapshot() }") >= 4 and "withContext(Dispatchers.IO) { store.history.recordBookSnapshot() }" in main,
    "per-driver historical positions are precomputed once per snapshot": "driverPositionsBySeason" in history and "snapshot.driverPositionsBySeason" in main,
    "GP history remains sharded and season summary checks are scoped": "f1tm_historical_v3_races" in history and "f1tm_historical_v3_seasons" in history and "readSeasonSummaryLines(season)" in history,
    "scalability audit documents 10, 15 and 20 season scenarios": all(x in (ROOT / "AUDIT_V718_STABILIZATION.md").read_text(encoding="utf-8") for x in ["10 temporadas", "15 temporadas", "20 temporadas"]),
}

for label, ok in checks.items():
    print(("PASS" if ok else "FAIL") + " | " + label)
failed = sum(not ok for ok in checks.values())
print(f"RESULT: {len(checks)-failed}/{len(checks)} V718 scalability checks passed")
sys.exit(1 if failed else 0)
