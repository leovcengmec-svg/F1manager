#!/usr/bin/env python3
from pathlib import Path
root=Path(__file__).resolve().parents[2]
main=(root/'app/src/main/java/com/f1teammanager/MainActivity.kt').read_text()
prefs=(root/'app/src/main/java/com/f1teammanager/CareerPreferences.kt').read_text()
grad=(root/'app/build.gradle.kts').read_text()
checks={
 'version 600':'versionCode = 600' in grad and '0.600.0' in grad,
 'Race receives current career catalog':'Race(round.grandPrix, snapshot!!, drivers, store.currentDrivers(), ::advanceRace,' in main,
 'RaceStartPlanDialog receives catalog':'driverCatalog = driverCatalog' in main,
 'race plan looks up active roster':'driverCatalog.firstOrNull { it.id == st.driverId }' in main,
 'identity repair names Felipe':'Felipe Drugovich' in prefs,
 'identity repair only for severe mismatch':'overall(canonical) >= 75.0 && overall(current) <= 65.0' in prefs,
 'clear only target driver state':'clearDriverEvolutionIdentityState(felipe.id)' in prefs,
 'no global roster reset':'saveDriverAttributes(repaired)' in prefs,
}
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL')+' '+name)
assert all(checks.values())
