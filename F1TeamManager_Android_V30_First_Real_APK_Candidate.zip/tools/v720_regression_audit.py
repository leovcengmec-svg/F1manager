#!/usr/bin/env python3
"""Focused static regression audit for V720 ranking isolation and game audio controls."""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
main = (ROOT / "app/src/main/java/com/f1teammanager/MainActivity.kt").read_text(encoding="utf-8")
engine = (ROOT / "app/src/main/java/com/f1teammanager/core/manager/AITeamDevelopmentEngine.kt").read_text(encoding="utf-8")
audio = (ROOT / "app/src/main/java/com/f1teammanager/ExternalAudio.kt").read_text(encoding="utf-8")
settings = (ROOT / "app/src/main/java/com/f1teammanager/MainMenuScreen.kt").read_text(encoding="utf-8")
gradle = (ROOT / "app/build.gradle.kts").read_text(encoding="utf-8")
manifest = (ROOT / "package_manifest.txt").read_text(encoding="utf-8")
test_file = ROOT / "app/src/test/kotlin/com/f1teammanager/core/manager/AITeamDevelopmentReadOnlyV720Test.kt"

checks = {
    "V722 preserves V720 versioned features": "versionCode = 722" in gradle and 'versionName = "0.722.0"' in gradle,
    "package manifest identifies V722 and V721 base": "Version: 722 / 0.722.0" in manifest and "Base: V721 / 0.721.0" in manifest,
    "standard AI simulation exposes explicit publication switch": "publishLiveOverall: Boolean = true" in engine,
    "standard cache hit publishes only when requested": "if (publishLiveOverall) cached.garage?.let" in engine,
    "standard computed simulation publishes only when requested": "if (publishLiveOverall) result.garage?.let" in engine,
    "handoff AI simulation exposes explicit publication switch": engine.count("publishLiveOverall: Boolean = true") == 2,
    "handoff cache hit publishes only when requested": engine.count("if (publishLiveOverall) cached.garage?.let") == 2,
    "handoff computed simulation publishes only when requested": "if (publishLiveOverall) current.garage?.let" in engine,
    "wrapper forwards publication switch to handoff simulation": "publishLiveOverall = publishLiveOverall" in main,
    "wrapper forwards publication switch to standard simulation": "investmentRankingSnapshot,\n            publishLiveOverall" in main,
    "Team Overview helper is a read-only projection": "publishLiveOverall = false" in main[main.index("private fun teamOverviewSnapshot("):main.index("@Composable\nprivate fun TeamOverviewScreen(")],
    "Team Overview screen is a read-only projection": "publishLiveOverall = false" in main[main.index("private fun TeamOverviewScreen("):main.index("private fun TeamOverviewBudgetCard(")],
    "Team Ranking screen is a read-only projection": "publishLiveOverall = false" in main[main.index("private fun buildTeamRankingSnapshot("):main.index("@Composable\nprivate fun TeamRankingScreen(")],
    "next-season market projection is read-only": "publishLiveOverall = false" in main[main.index("fun buildMarketNextSeasonCarStrengths("):main.index("fun participants()")],
    "real weekly development path keeps default authoritative publication": "weeklyInvestmentRanking\n            )" in main[main.index("fun syncAiWeeklyState("):main.index("fun buildMarketNextSeasonCarStrengths(")],
    "audio preferences are persisted separately from career data": 'getSharedPreferences("f1_manager_audio"' in main and 'putBoolean("enabled", enabled)' in main and 'putFloat("volume", normalized)' in main,
    "audio enabled preference is loaded on app start": 'getBoolean("enabled", true)' in main,
    "audio volume preference is loaded and clamped": 'getFloat("volume", 0.70f).coerceIn(0f, 1f)' in main,
    "settings route passes the audio toggle": "audioEnabled = gameAudioEnabled" in main and "onAudioEnabledChange =" in main,
    "settings route passes the volume slider": "audioVolume = gameAudioVolume" in main and "onAudioVolumeChange =" in main,
    "settings UI includes an audio on/off switch": "Switch(" in settings and "checked = audioEnabled" in settings,
    "settings UI includes a 0-100 percent slider": "Slider(" in settings and "valueRange = 0f..1f" in settings,
    "settings UI explicitly explains device volume is unchanged": "volume padrão do celular permanece inalterado" in settings,
    "game MediaPlayer gain is clamped and applied": "volume = value.coerceIn(0f, 1f)" in audio and "active.setVolume(volume, volume)" in audio,
    "ambient and event players receive local gain": audio.count("mp.setVolume(volume, volume)") == 2,
    "muted audio prevents event playback": "if (!enabled) return" in audio[audio.index("fun playEvent("):audio.index("@Synchronized fun stop()")],
    "late event prepare cannot restart audio after mute": "foreground && enabled && generation == oldGeneration && player === prepared" in audio,
    "Android system stream volume is never changed": "AudioManager" not in audio and "setStreamVolume" not in audio,
    "read-only ranking regression test exists": test_file.is_file() and "readOnlyProjectionDoesNotPublishItsGarageToCareerRanking" in test_file.read_text(encoding="utf-8"),
    "V720 changelog and audit are included": (ROOT / "CHANGELOG_V720.md").is_file() and (ROOT / "AUDIT_V720_STABILIZATION.md").is_file(),
}

for label, ok in checks.items():
    print(("PASS" if ok else "FAIL") + " | " + label)
failed = sum(not ok for ok in checks.values())
print(f"RESULT: {len(checks)-failed}/{len(checks)} V720 static checks passed")
sys.exit(1 if failed else 0)
