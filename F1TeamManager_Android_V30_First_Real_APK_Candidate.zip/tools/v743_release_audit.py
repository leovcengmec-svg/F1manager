#!/usr/bin/env python3
"""Static release checks for V743 development, AI R&D, regulation and market parity."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def read(path: str) -> str:
    p = ROOT / path
    if not p.exists():
        raise AssertionError(f"Missing file: {path}")
    return p.read_text(encoding="utf-8")

checks = []
def check(label: str, condition: bool) -> None:
    if not condition:
        raise AssertionError(label)
    checks.append(label)

# Driver-development points.
dev = read("app/src/main/java/com/f1teammanager/core/manager/DriverDevelopmentEngine.kt")
codec = read("app/src/main/java/com/f1teammanager/core/manager/DriverMarketModels.kt")
main = read("app/src/main/java/com/f1teammanager/MainActivity.kt")
manager = read("app/src/main/java/com/f1teammanager/core/manager/ManagerSeasonEngine.kt")
check("driver facility program points are the only completion input", "val total = original.points" in dev and "original.points +" not in dev)
check("legacy reserves are cleared on normalization", "reservePoints = emptyMap()" in dev)
check("blocked points are explicitly discarded", "Any points blocked by potential" in dev and "are discarded" in dev)
check("attribute selection avoids repeats within each pass", "passCandidates.removeAt(selectedPosition)" in dev)
check("codec discards legacy reserve rows", "discards it" in codec and "DriverDevelopmentState(programmes, reserves).normalized()" in codec)
check("player development news reports granted/applied/discarded counts", "ponto(s) concedido(s)" in main and "não ficam guardados" in main)
check("AI development news reports granted/applied/discarded counts", "ponto(s), ${done.appliedPoints}" in manager and "não ficam reservados" in manager)

# AI R&D batches and manufacturing safeguards.
ai = read("app/src/main/java/com/f1teammanager/core/manager/AITeamDevelopmentEngine.kt")
check("AI chooses three distinct components per batch", "repeat(3)" in ai and "remaining.remove(chosen)" in ai)
check("AI has explicit V1/V2/fabrication state", "0 idle, 1 V1 research, 2 V2 research, 3 fabrication" in ai)
check("AI reserves both research rounds before starting", "unitResearchCost * (selected.size * 2L)" in ai)
check("AI reserves fabrication cost before starting", "factory.manufacturingCost(preview, facilities, ranking) * quantity.toLong()" in ai)
check("AI only starts a batch if cash and technical cap cover it", "state.budget >= totalReserve && technicalSpent + totalReserve <= technicalCap" in ai)
check("AI does not start another batch before existing factory orders clear", "factoryOrders.isEmpty()) {\n                beginBatch(week)" in ai)
check("research outcomes are stored on each project", "val outcome: ResearchOutcome" in ai)
check("failed research has an explicit event", "DevelopmentEvent.Type.DESIGN_FAILED" in ai)
check("two manufactured units are assigned to both physical cars", "aiFactoryBatchTargets" in ai and "index % 2 == 0" in ai)
check("AI factory targets weakest car when only one unit can be made", "car1Value <= car2Value" in ai)

# V0 reset and annual rule.
car = read("app/src/main/java/com/f1teammanager/core/manager/CarDevelopmentEngine.kt")
check("AI next-season garage resets every installed component to V0", "installedPieceVersions = car.installedPieces.keys.associateWith { 0 }" in car)
check("AI simulation repairs historical openings to V0", "val garageAtOpening = resetSeasonPieceVersions(opening.garage)" in ai)
regulation = read("app/src/main/java/com/f1teammanager/core/manager/AnnualCarRegulationEngine.kt")
check("ordinary annual regulation draws 80/20 one/two changes", "countRoll < 80) 1 else 2" in regulation)
check("annual season 1 remains exempt", "if (season == 1) return SeasonRule" in regulation)
check("decennial regulation replaces ordinary annual events", "if (decennialSeason) emptyList() else chosen" in regulation)

# All rollover call paths must supply full financial and facility maps.
market = read("app/src/main/java/com/f1teammanager/core/manager/DriverMarketEngine.kt")
check("season transition accepts full financial/facility maps", "teamFinances: Map<Int, TeamFinanceState>" in market and "teamFacilities: Map<Int, TeamFacilitiesState>" in market)
check("vacancy fill computes financial class from full ledger and facilities", "financialLevelFor(\n                        s, team.id, season - 1, openingFinance, openingFacilities, driverAttributes" in market)
check("vacancy fill calls the same signature fee policy", "financialLevelOverride = signingLevel" in market)
season_engine = read("app/src/main/java/com/f1teammanager/core/manager/ManagerSeasonEngine.kt")
career = read("app/src/main/java/com/f1teammanager/CareerPreferences.kt")
check("headless transition supplies finance and facility maps", "teamFinances = transitionFinances, teamFacilities = transitionFacilities" in season_engine)
check("career transition supplies finance and facility maps", "teamFinances = transitionFinances" in career and "teamFacilities = transitionFacilities" in career)
check("previous team is never credited a transfer fee", "The current/previous team never receives a transfer payment." in market)

# Version identity.
version = read("app/build.gradle.kts")
manifest = read("package_manifest.txt")
check("versionCode is 743", "versionCode = 743" in version)
check("versionName is 0.743.0", 'versionName = "0.743.0"' in version)
check("package manifest identifies V743", "Version: 743 / 0.743.0" in manifest)
check("original ZIP filename is preserved", "F1TeamManager_Android_V30_First_Real_APK_Candidate.zip" in manifest)

print(f"V743 RELEASE AUDIT: {len(checks)}/{len(checks)} checks passed")
for label in checks:
    print(f"PASS | {label}")
