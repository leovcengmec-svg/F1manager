# Auditoria V531

## Raiz corrigida
O estado de pesquisa e fábrica persistia através de `startNextSeason`, preservando designs, projetos ativos, ordens e instalações pendentes da temporada anterior. O número da versão também partia de 1 quando não havia design, fazendo a primeira pesquisa ser V2.

## Correção
Depois de `CarDevelopmentEngine.startNextSeason` construir o novo carro e antes de persistir a carreira, o estado P&D e fábrica do jogador é reiniciado. A pesquisa subsequente usa os valores da garagem física recém-construída como baseline e inicia em V1. Os dados do carro/garagem, histórico de temporadas, finanças, instalações, assets e IA são preservados.

## Validação
- ZIP submetido a teste de integridade.
- Teste de regressão adicionado.
- Build Gradle não executado neste ambiente; compilação e execução dos testes precisam ser confirmadas no runner Android.
