# Auditoria V637 — ciclo de construção e revolução decenal

## Escopo da mudança

- Versão: `versionCode = 637`, `versionName = 0.637.0`.
- Mantida a tabela universal investimento × Overall e o bônus único de construção de 10%.
- Alterada apenas a meta de crescimento da IA e a intensidade percentual da revolução decenal.
- Preservados os limites reais de caixa/reservas e o teto cumulativo de €150 milhões para a construção.
- Mantida a regra de que a revolução decenal substitui os eventos regulamentares anuais naquele ano.

## Regras V637

### Meta de investimento da IA

| Overall atual | Ganho-alvo máximo |
|---:|---:|
| 0–69 | +7 |
| 70–89 | +5 |
| 90–96 | +2 |
| 97–100 | +1 |

É uma meta de compra, não um bônus de desempenho. O Overall físico continua derivado do valor investido pela tabela comum. A IA pode ficar abaixo da meta se não tiver caixa disponível, após proteger suas despesas operacionais.

### Revolução decenal

| Peça | Redução de desempenho |
|---|---:|
| Motor | 40% |
| Chassi | 35% |
| Asa dianteira | 45% |
| Asa traseira | 45% |
| Freios | 35% |
| Unidade elétrica | 40% |
| Média | 40% |

A confiabilidade e a identidade das peças não são alteradas pela regra regulamentar; somente o desempenho do componente é reduzido, conforme o motor existente.

## Resultado da simulação de 20 transições

Executado `V637TwentyYearCarConstructionSimulation.kt` com o construtor físico `CarDevelopmentEngine`, o motor regulamentar `AnnualCarRegulationEngine`, 40 equipes, duas sementes (`20261005` e `42`) e 20 transições de 2026→2027 a 2045→2046.

| Semente | Temporada de reset | Construído antes da regra | Equipes 80–100 | Após a regra | Equipes 40–60 |
|---:|---:|---:|---:|---:|---:|
| 20261005 | 2036 | 89–94; média 91,30 | 40/40 | 49–55; média 51,50 | 40/40 |
| 20261005 | 2046 | 92–94; média 92,60 | 40/40 | 50–56; média 52,68 | 40/40 |
| 42 | 2036 | 86–94; média 90,18 | 40/40 | 47–55; média 50,93 | 40/40 |
| 42 | 2046 | 92–94; média 92,40 | 40/40 | 50–55; média 52,40 | 40/40 |

Com as sementes testadas, o modelo alcança a faixa alta antes das duas revoluções e volta à faixa 40–60 após ambas. A progressão pós-reset volta a colocar as 40 construções na faixa 80–100 até a transição para 2042.

## Sensibilidade ao investimento

Os cenários artificiais de teto por carro mostram que a meta depende do financiamento:

- Teto de €25M: Overall-base da construção fica em 55 e a média após a regra decenal é 30,73.
- Teto de €35M: Overall-base da construção fica em 61 e a média após a regra decenal é 34,08.
- Investimento zero: construção mínima física 1; não há bônus gratuito de adaptação para cair em 40–60.

Isso é intencional: a faixa 40–60 pós-reset é a consequência da redução de um carro desenvolvido até 80–100, não um piso artificial para carros sem investimento.

## Testes executados

- Testes focados: **20/20 métodos passaram** — 3 testes V637 do ciclo, 10 testes V636 de construção e 7 testes do motor regulamentar.
- Auditoria V637 por fonte e CSV: **14 verificações**, depois de incluir este relatório.
- A validação geral do projeto é executada separadamente e registrada no `CHANGELOG_V637.md` apenas depois de confirmar o resultado.

## Limitações

Esta simulação é de construção e regulamentação, não uma carreira completa. Ela não executa o livro-caixa real, todo o pipeline de P&D/fábrica, contratos, resultados de corrida nem uma build Android. O cenário principal faz o teste da meta de investimento plenamente financiada. No jogo, o caixa real e as reservas continuam restringindo a compra; para garantir que todas as equipes alcancem 80–100 em uma carreira integral, ainda é necessário observar um ciclo rodando com a economia completa.
