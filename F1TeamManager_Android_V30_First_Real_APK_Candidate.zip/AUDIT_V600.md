# Auditoria V600 — V0 de componentes

## Causa-raiz confirmada no código

`CareerPreferences.saveGarage()` persistia cada versão com `coerceAtLeast(1)`. Isso sobrescrevia o V0 emitido por `TeamGarageFactory.fromInitial()` e `TeamGarageFactory.fromCarState()` e fazia os componentes aparecerem como V1 após o salvamento/carregamento. O bug afetava os dois carros e podia reaparecer depois de fechar e reabrir o jogo.

## Correções

1. Salvar versões com mínimo 0.
2. Ao carregar, corrigir dados antigos apenas quando o ID da peça indica baseline (`INIT-*` ou `SEASON-*`) e a versão persistida é 1. Não alterar peças reais com outros IDs.
3. A IA começa com versão-base 0 e calcula cada novo design como a versão instalada mais 1, por componente.

## Validação

- Inspeção estática confirma que não há mais `coerceAtLeast(1)` na gravação de versões dos componentes.
- Inspeção estática confirma os defaults V0 dos carros físicos e o cálculo de pesquisa individual por componente.
- O build Android e a suíte JUnit devem ser executados pelo GitHub Actions; não declarar compilação aprovada sem resultado do workflow.
