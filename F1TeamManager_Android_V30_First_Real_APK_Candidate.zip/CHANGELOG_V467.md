# Changelog V467

- Salvamento explícito do estado ativo da carreira antes de retornar à tela inicial ou encerrar o aplicativo.
- Persiste carro, finanças, patrocinadores, garagem, instalações, melhorias em andamento, P&D, fábrica, desenvolvimento de pilotos, investimento técnico, mercado de pilotos e snapshots financeiros da IA.
- Adicionada barreira de persistência (`commit`) para aguardar gravações anteriormente enfileiradas em `SharedPreferences`.
- Mantém exportação de backup como operação separada do salvamento automático local.
- Não foi possível executar a compilação Android neste ambiente; validar com Build Debug APK.
