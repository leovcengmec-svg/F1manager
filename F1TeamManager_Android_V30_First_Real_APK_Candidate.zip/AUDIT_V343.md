# Auditoria V343

Avanço: ponto de entrada único para qualificação e corrida instantâneas, reutilizando o motor existente.

Arquivos: CareerWeekendEngine.kt, InstantSimulationEngineTest.kt, app/build.gradle.kts.

Sem alterações de UI. Teste unitário adicionado, mas Gradle/JUnit não executados neste ambiente.

Pendência essencial: integrar o resultado ao fluxo normal de carreira (recordRace, finanças, evolução, notícias, prêmios e avanço de calendário) antes de adicionar interface.
