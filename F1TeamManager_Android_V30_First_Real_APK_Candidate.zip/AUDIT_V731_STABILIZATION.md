# Auditoria V731 — evolução, faixa de Overall e progressão de classe

## Base e versão
- Base: V730 / 0.730.0.
- Versão resultante: V731 / 0.731.0.
- Nome público preservado: F1 Team Manager V30.
- Nome do ZIP preservado: `F1TeamManager_Android_V30_First_Real_APK_Candidate.zip`.
- A V730 original não foi sobrescrita.

## 1. Faixa adicional por classe
| Classe | Teto normal | Margem máxima | Teto adicional |
|---|---:|---:|---:|
| Médio | 69 | +5 | 74 |
| Forte | 79 | +5 | 84 |
| Pro | 89 | +5 | 94 |
| Lenda | 100 | +0 | 100 |

Fraco/Normal legado continua sendo convertido para Médio. Overall segue calculado pela média dos sete atributos. Potencial individual e Overall 100 permanecem limites absolutos.

## 2. Acesso à margem adicional
- Médio, com ou sem contrato: acesso integral à margem de +5, sem penalidade adicional de velocidade por estar acima do teto normal.
- Forte sem equipe: acesso integral à margem de +5, sem penalidade adicional de velocidade.
- Forte contratado: precisa de média de desempenho da temporada.
- Pro, livre ou contratado: precisa de média de desempenho da temporada.
- Lenda: não recebe margem além de 100.

Para Forte contratado e Pro, a média de desempenho libera a margem progressivamente:
| Média da temporada | Margem liberada |
|---:|---:|
| 110–119,99 | +1 |
| 120–129,99 | +2 |
| 130–139,99 | +3 |
| 140–149,99 | +4 |
| 150 ou mais | +5 |

A média é calculada com os resultados reais de classificação/corrida da temporada. Um GP isolado com nota alta não libera a margem por si só. As metas que alimentam esse índice continuam calculadas exclusivamente pela força do carro.

Para classes com exigência de desempenho, a velocidade natural acima do teto normal é progressivamente reduzida: 0,90x até +2; 0,80x em +3/+4; 0,70x no quinto ponto. Médio e Forte livre mantêm 1,00x. O limite anual de cada perfil e o potencial individual continuam ativos.

## 3. Centro de Desenvolvimento
- Usa o mesmo gate de classe/contrato/desempenho da evolução natural.
- O jogador envia ao motor a lista dos pilotos efetivamente contratados pela equipe e a média de desempenho da temporada.
- A IA usa a mesma regra, com os pilotos contratados e as médias atuais da temporada.
- Pontos que não podem ser aplicados porque a margem ainda não foi liberada permanecem reservados; não ultrapassam potencial, teto liberado ou limites anuais por atributo.
- Programa não continua depois que o piloto deixa a equipe responsável pelo programa.

## 4. Promoção e regressão esportiva
- A avaliação esportiva de classe continua bienal, na virada de 2027, 2029, 2031 etc.
- A promoção preserva os critérios anteriores: pelo menos 80% dos GPs previstos em cada temporada; média individual de cada temporada >=100; média conjunta >=105; Overall pelo menos um ponto acima do início da próxima classe; uma classe por avaliação.
- Pro -> Lenda continua exigindo ao menos um título de pilotos na carreira.
- A regressão esportiva também é avaliada a cada duas temporadas: média de cada temporada <=80, média conjunta <=80 e Overall pelo menos dois pontos abaixo do início da classe atual. Uma classe por avaliação.
- Lenda não é mais imune à regressão por desempenho ruim; pode cair para Pro se cumprir os critérios bienais.

## 5. Rebaixamento por ausência de equipe
A contagem é independente da avaliação esportiva:
| Classe atual | Temporadas completas consecutivas sem contrato | Nova classe |
|---|---:|---|
| Forte | 2 | Médio |
| Pro | 3 | Forte |
| Lenda | 5 | Pro |
| Médio | — | permanece Médio |

Qualquer contrato ativo na temporada zera a sequência. Ao rebaixar, apenas uma classe é perdida e o contador é zerado para iniciar o período exigido pela nova classe. Saves V730 começam a contabilizar ausência após temporadas completas concluídas na V731; o código não inventa ausência passada quando o save não tem esse registro. A contagem fica persistida em SharedPreferences e é incluída no backup integral porque o backup serializa o conjunto completo de preferências.

## 6. Integridade dos sistemas preservados
- Metas de classificação e corrida continuam exclusivamente baseadas na força do carro; atributos/Overall/classe/potencial do piloto não entram nas metas.
- Ciclo etário continua de 18 a 45, com reinício aos 18 e redução de 30% atributo por atributo.
- Regressão etária permanece separada da regressão esportiva.
- Central de Notícias mantém as cinco categorias e Eventos de Pilotos; as notícias de promoção/rebaixamento continuam nessa categoria com o motivo completo.
- Patrocínios, sorteios, durações e renovação V730 não foram modificados.
- A identidade pública do aplicativo e o nome original do ZIP foram preservados.

## 7. Testes e validação executados
- Núcleo Kotlin direcionado (atributos, modelos de piloto, catálogo, idade, evolução, progressão e desenvolvimento) compilado com Kotlin 2.0/K2 via `kotlinc`.
- 14 testes direcionados de asserção executados em runner local para margem +5, requisitos de desempenho, velocidade por classe/contrato, P&D, ausência de equipe, regressão bienal e promoção Pro -> Lenda: PASS.
- 10 testes de preservação executados em runner local: ciclo etário 18–45, redução de 30% atributo por atributo, piso 40, regressão física separada e crescimento natural de pilotos livres: PASS.
- Smoke legado `DriverEvolutionPerformanceV649Test`: PASS.
- Simulação determinística de 10 temporadas: PASS; distribuição final do cenário de teste: Pro 39, Lenda 9, Forte 33, Médio 19. É uma checagem de coerência do motor, não uma calibração estatística de milhares de carreiras.
- `tools/v731_driver_rules_audit.py`: 31 verificações estáticas cobrindo os dois modos de processamento, persistência, limites e preservações: PASS.
- `tools/validate_release_contract.py`: 137 verificações estruturais e de contrato da versão: PASS.
- O contador de ausência é reiniciado em qualquer mudança de classe, impedindo reaproveitar temporadas sem equipe acumuladas sob uma classe anterior.

## 8. Limitações
- Este ambiente não tem Gradle, Gradle Wrapper nem Android SDK configurados. Portanto, a suíte JUnit integral, `compileDebugKotlin` e `assembleDebug` não foram executados aqui.
- O build do APK e a suíte Android devem ser confirmados pelo GitHub Actions antes de declarar a V731 pronta para instalação.
- A nova contagem de temporadas sem equipe começa sem retropreencher temporadas anteriores do save V730; isso evita inferir ausência sem dados persistidos confiáveis.
