# Auditoria — eventos de corrida V336

## Comportamento anterior
- Colisão: 0,012 * risco do circuito por volta em bandeira verde.
- Não havia um sorteio dedicado de furo de pneu no fluxo principal da corrida, apesar de existir a imagem `event_puncture.webp`.
- A pane da unidade elétrica apenas removia o ERS ao chegar a 0% de confiabilidade; não existia um evento aleatório próprio de pane elétrica que causasse DNF.

## Comportamento novo
- Colisão: 0,020 * risco do circuito por volta, com teto de 7,5%, e apenas um causador sorteado por volta.
- Furo: chance de 30% por GP, no máximo um por corrida; parada emergencial e troca de pneu, penalidade de 21 s.
- Pane elétrica: no máximo um evento por GP, chance de 0,30 * (1,40 - confiabilidade elétrica média / 100), limitada a 8%-40%; o piloto selecionado abandona com DNF.
- A confiabilidade alta reduz a chance de pane elétrica, mantendo o impacto da evolução das equipes.

## Arquivos alterados
- `app/src/main/java/com/f1teammanager/core/race/CareerWeekendEngine.kt`
- `app/src/main/java/com/f1teammanager/MainActivity.kt`
- `app/src/main/java/com/f1teammanager/RaceEventImageRegistry.kt`
- `app/src/main/res/drawable-nodpi/event_electric_failure.webp`

## Limitações
Não houve compilação Gradle nem teste de corrida real em dispositivo. O ZIP original V336 foi mantido sem alteração; estas mudanças estão no projeto extraído de trabalho e nos arquivos/patch entregues separadamente.
