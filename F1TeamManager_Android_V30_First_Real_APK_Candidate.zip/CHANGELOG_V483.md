# V483 — Persistência financeira na virada de temporada (causa estrutural)

- O snapshot financeiro/comercial da IA era gravado com `apply()` (assíncrono) e a ação de virada não forçava um commit explícito antes de criar o diário de rollback. Uma morte do processo nesse intervalo podia deixar o snapshot atrasado/ausente; na restauração, `AITeamFinancialEngine.state()` cria o orçamento inicial quando não encontra estado carregado.
- `saveAiFinanceSnapshot` e `saveAiSponsorshipSnapshot` agora retornam o resultado de `commit()` síncrono.
- A virada persiste ambos os livros-razão antes de criar o journal e volta a persistir após migrar as equipes de IA para a nova temporada.
- Após a migração, `ensureAllTeams` chama `beginSeason`: preserva o caixa, zera apenas os indicadores anuais e mantém o histórico de transações.
- Se a transição for revertida, os motores em memória são recarregados do snapshot restaurado para não misturar estados de temporadas diferentes.
- O nome oficial do ZIP de entrega foi mantido.

## Validação

- Revisão estática dos pontos de persistência, journal, rollback e migração de temporada.
- Verificação de integridade do ZIP após empacotamento.
- A compilação Android completa e a reprodução instrumentada no dispositivo ainda precisam ser executadas; não são declaradas como aprovadas.
