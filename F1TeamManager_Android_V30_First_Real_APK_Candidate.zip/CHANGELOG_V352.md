# V352 — Validação estrutural do resultado

- Reforçada a validação prévia ao fechamento do GP: identificação de piloto/equipe, posição, tempo total, paradas, voltas de Safety Car/VSC e tempo da volta mais rápida.
- Adicionados testes unitários para metadados malformados e contadores negativos.
- Nenhuma alteração de interface.
