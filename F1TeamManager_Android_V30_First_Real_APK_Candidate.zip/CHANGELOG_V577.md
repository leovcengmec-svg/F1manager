# V577 — Construção unificada do próximo carro

- Player e IA agora usam a mesma função canônica para calcular a transferência de cada componente físico na virada da temporada.
- A função comum aplica: componente instalado, 10% do valor individual anterior com arredondamento, conhecimento técnico e efeito do investimento/foco.
- O carro físico da IA recebe o conhecimento técnico persistido no estado legado da equipe, além do investimento, usando o foco equilibrado da política atual da IA.
- A aplicação do regulamento continua fora da construção física e deve ocorrer uma única vez após a criação do carro.
- Mantida a remoção da regressão anual genérica de 70%.
