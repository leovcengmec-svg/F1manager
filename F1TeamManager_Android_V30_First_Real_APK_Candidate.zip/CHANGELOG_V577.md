# V577 — Fechamento integrado e grade dinâmica

## Correção crítica no fluxo de simulação instantânea
- Corrigida a referência a `participants` fora do escopo em `completeStartedWeekend`, que impedia a compilação desse caminho.
- `CareerWeekendEngine` agora mantém o roster original do GP separado da lista temporária que encolhe conforme os pilotos são eliminados da Q1/Q2 e expõe uma cópia imutável do roster original.
- A validação da simulação instantânea calcula o tamanho do grid pela lista realmente configurada no motor e verifica que a qualificação contém exatamente os mesmos IDs.
- Q2 e Q3 continuam proporcionais ao tamanho real do grid, mantendo os resultados históricos para 80 pilotos.

## Testes e auditorias integradas
- Adicionado teste de fim a fim para grids de 6 e 4 pilotos, com tamanhos de fases Q1/Q2/Q3 de 6/4/2 e 4/3/1.
- O contrato de simulação de duas temporadas deriva o tamanho esperado do catálogo de equipes e do corte proporcional de qualificação.
- Os auditores vivos de ciclo de jogo e premiação foram alinhados ao grid dinâmico e à curva de premiação extensível; documentos e históricos de versões anteriores foram preservados.
- Adicionado auditor final estático V577 para os contratos de integração corrigidos.

## Preservação
- V576 é a base direta desta entrega.
- Nenhum arquivo removido; todos os assets externos, saves, chaves de persistência, contratos, finanças, calendário e histórico permanecem no projeto.
- `versionCode = 577`, `versionName = 0.577.0`.

## Limites de validação
- Os auditores estáticos são executados localmente.
- A compilação Android e a suíte JUnit completa não foram executadas porque o ambiente não contém Gradle nem Gradle Wrapper.
- O teste de seis pilotos foi adicionado ao projeto, mas não é apresentado como executado sem o runtime de testes Android/JUnit.
