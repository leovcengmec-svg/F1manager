# V728 — Central de notícias somente por Overall, com motivo preservado

**VersionCode:** 728  
**VersionName:** 0.728.0  
**Base:** V727 / 0.727.0  
**Nome público:** F1 Team Manager V30  
**ZIP:** `F1TeamManager_Android_V30_First_Real_APK_Candidate.zip`

## Correção principal

- Restaurado o contrato de notícias de pilotos da V724: a central de Evolução de Pilotos publica somente evolução ou regressão quando o Overall inteiro exibido realmente muda.
- Mantido o campo `Motivo:` completo nos cards, incluindo desempenho esportivo acima/abaixo das expectativas, declínio natural da idade e reinício do ciclo etário.
- As alterações dos sete atributos continuam sendo calculadas, aplicadas e persistidas normalmente; elas não geram cards individuais.
- Removida a geração paralela de notícias de atributo introduzida na V725 (`buildDriverAttributeMovementNews`) e removidas suas chamadas para pilotos contratados e livres.
- O outbox pendente publica somente mensagens normalizáveis de Overall; mensagens de atributo sem Overall e mudanças neutras (delta zero) são descartadas.
- Cards antigos de atributos da V725–V727 são ocultados também em saves já existentes.
- Mensagens legadas de Overall do centro de desenvolvimento recebem o motivo específico de conclusão do programa; duplicatas de GP sem motivo são descartadas para não exibir notícia incompleta.
- Promoções/rebaixamentos de classe, conclusão/cancelamento de programas e outros eventos são mantidos em uma nova aba **Eventos de Pilotos**; a aba **Evolução de Pilotos** fica exclusiva para Overall.

## Reinício do ciclo etário

- A transição aos 18 anos passa a gerar, quando houver mudança real, um card de regressão de Overall com o motivo completo: temporada concluída aos 45 anos, novo ciclo aos 18, redução de 30% aplicada atributo por atributo, piso 40 e preservação de identidade/classe/perfil.
- Os sete valores detalhados continuam preservados nos snapshots/histórico técnico; não são exibidos na central.
- A mesma regra foi aplicada à carreira normal e ao caminho de simulação de temporadas.

## Preservado

- Metas de classificação e corrida baseadas exclusivamente na força do carro.
- Pesos de avaliação 40% classificação / 60% corrida e tolerância de ±3 posições.
- Cálculo interno dos sete atributos, bancos fracionários, limites anuais, regressão natural e ciclo 18–45 com reinício -30%.
- Motivo da mudança de Overall; não foi removido nem substituído por uma mensagem genérica.
- Correção do codec de fases etárias da V727.
- Nome público e nome original do ZIP.

## Testes adicionados

- Card antigo de atributo (ex.: `VEL +1`) é identificado como legado e não passa pela normalização Overall.
- Normalização de notícia de Overall preserva `Motivo:`.
- Reinício de ciclo gera somente a notícia Overall e contém o motivo completo, sem nomes de atributos.
- Promoções e eventos de programas são mantidos em `DRIVER_EVENTS`, separados da aba `DRIVER_EVOLUTION`.
- Mensagens antigas de saves são reclassificadas na apresentação para não exigir migração destrutiva do histórico.

## Validação

- Testes JUnit adicionados em `DriverOverallNewsV728Test.kt`.
- Integridade do ZIP e auditoria estática a executar após o empacotamento.
- Build Android completo / `assembleDebug` depende da execução no GitHub Actions; não declarar APK aprovado sem resultado desse workflow.
