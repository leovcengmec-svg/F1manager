# V429
- Amplia o diário de virada com checkpoints persistentes por subsistema.
- Registra separadamente o reset do calendário, cálculo do estado gerencial e gravações de carro, garagem, instalações, investimento técnico, pesquisa, fábrica, desenvolvimento, mercado, finanças e patrocinadores.
- Acrescenta testes-fonte para ordem e validade dos checkpoints.
- Mantém bloqueio conservador quando a virada fica em estado parcial; recuperação transacional completa continua pendente.
