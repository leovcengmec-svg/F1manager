# Auditoria V497 — progresso de equipes na abertura de temporadas

## Erro encontrado
A visão geral de equipes tratava `currentWeek <= 1` como sinônimo de abertura da carreira. Isso fazia o jogo reconstruir a apresentação usando carros iniciais, instalações iniciais e ranking inicial no começo de toda temporada, ocultando a evolução persistida das equipes depois da virada anual.

## Correção
- O estado inicial agora só é usado quando `currentWeek <= 1` e a temporada é a inicial (2026).
- Nas temporadas seguintes, a visão geral mantém a garagem do jogador e reconstrói a garagem física da IA a partir do encadeamento histórico da simulação, passando os níveis de instalações persistidos.
- A ordenação por ranking inicial também foi limitada à abertura da primeira carreira; temporadas subsequentes ordenam pelo Overall atual dos carros.
- O fallback de instalações na visão geral passa a consultar o ledger de instalações da IA nas temporadas já progredidas.
- Criado `TeamOverviewSeasonProgressV497Test.kt` como contrato de regressão.

## Verificações executadas
- `tools/race_sim_test/validate_project.py`: 32/32 checks passaram.
- `tools/race_sim_test/final_release_audit.py`: verificado após atualizar a referência da versão atual.
- Integridade do ZIP: verificação `unzip -t` sem erros.
- Assets externos e histórico de versões preservados.

## Limitação
Não há Gradle wrapper nem instalação Gradle disponível neste ambiente. Não se declara compilação Android, execução JUnit ou validação em dispositivo.
