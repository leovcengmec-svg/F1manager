# Auditoria V350

## Implementado nesta etapa
- Diário persistente de etapas, indexado por temporada + rodada + nome da etapa.
- Cada etapa só recebe o marcador de concluída depois que sua ação retorna; o marcador é persistido com `commit()` para sobreviver ao encerramento do processo.
- O marcador final `complete` é escrito somente depois da persistência final do carro, finanças, patrocínios e mercado.
- A existência do registro do resultado não é mais usada como prova de que todos os subsistemas terminaram. Isso permite retomar um fechamento interrompido após o registro do GP.
- Finanças e salários conservam seus próprios mecanismos de idempotência; a IA financeira mantém seus marcadores por equipe/temporada/rodada.

## Limites que permanecem
- O diário melhora a recuperação entre etapas, mas não oferece transação atômica entre SharedPreferences e todos os subsistemas.
- Uma falha no meio de uma etapa composta ainda pode exigir idempotência própria dessa etapa. Em particular, evolução, patrocínios e prêmios devem ser validados com testes de repetição/interrupção antes de declarar recuperação total.
- Compatibilidade com carreiras já existentes depende de os mecanismos de idempotência legados continuarem válidos.
- Build Android, testes JUnit e simulação completa de temporadas não foram executados neste ambiente.
- Nenhum botão, tela ou layout foi alterado.
