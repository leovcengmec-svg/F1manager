# V444 — Integração do regulamento no carro da nova temporada

- Integração do regulamento anual/decenal após a construção do carro da temporada seguinte.
- Aplicação às duas unidades físicas da garagem e ao estado-resumo do carro.
- Mesma semente de regulamento compartilhada entre carreira do jogador e simulação das equipes de IA.
- Efeitos limitados à performance dos componentes; confiabilidade e identidades dos carros preservadas.
- A preparação do investimento técnico e os alvos de temporada são calculados depois da aplicação do regulamento.
- Adicionados testes unitários de redução anual, revolução decenal e preservação de confiabilidade.

## Limitação de validação

Os testes foram adicionados ao projeto. Neste ambiente, não há Gradle Wrapper nem distribuição Gradle disponível, então a suíte Android/JUnit e o APK não puderam ser executados/compilados.
