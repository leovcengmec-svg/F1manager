# V712 — notícias com motivo, propostas estáveis e histórico por circuito

- Notícias de evolução/regressão mostram o motivo sem revelar alterações individuais de atributos.
- Propostas de patrocínio ficam estáveis ao sair e reabrir a interface, com renovação somente quando o estado comercial muda.
- Cards de patrocínio ficam em largura total, com tipografia maior e informações completas.
- Histórico grava e exibe o circuito exato junto ao nome do GP, mantendo compatibilidade com registros antigos.
- VersionCode 712 / VersionName 0.712.0; base V711.

## Testes adicionados
- Motivo da notícia de Overall e preservação do motivo na normalização.
- Estabilidade das três propostas para o mesmo estado da carreira.
- Validações estáticas de gravação/leitura do circuito e apresentação na interface.

## Limites
Compilação Android e JUnit/Gradle integral dependem do GitHub Actions/Android SDK.
