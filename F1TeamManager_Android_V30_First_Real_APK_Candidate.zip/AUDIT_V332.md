# Auditoria V332 — leitura e repetição de eventos

## Causa encontrada
A Home permitia eventos de temporadas anteriores, mas `markNewsRead()` marcava apenas a temporada atual. Além disso, a chave de leitura incluía a semana, de modo que uma notificação equivalente republicada em outra semana podia ser tratada como nova. A retenção de chaves era limitada a 300.

## Correções
1. Chave estável: temporada + título + mensagem, com normalização de ponto e vírgula para evitar quebrar o armazenamento delimitado.
2. Compatibilidade: consulta e gravação também consideram a chave legada com semana.
3. Central de Notícias: abrir a Central marca como lidos todos os avisos visíveis, de qualquer temporada até a atual.
4. Home: os contadores e a seleção de eventos pendentes usam o mesmo critério.
5. Retenção de chaves ampliada para 5.000.

## Verificações executadas
- Conferência estática dos locais que criam/consultam chaves de leitura.
- Conferência de versão: versionCode 332 e versionName 0.332.0.
- Integridade do ZIP validada após empacotamento.

## Limitação
Não foi executada compilação Android nem teste no dispositivo nesta sessão.
