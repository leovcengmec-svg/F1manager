# V711 — Central de Notícias limitada à evolução e regressão de Overall

**VersionCode:** 711  
**VersionName:** 0.711.0  
**Base:** V710  
**Nome público:** F1 Team Manager V30

## Correção
- A Central de Notícias, na categoria Evolução de Pilotos, só recebe cartões quando o Overall inteiro exibido muda.
- Alterações internas em VEL, CLA, ULT, DEF, CON, CHU e PNE que mantêm o mesmo Overall não criam notícia.
- Notícias positivas mostram somente a evolução do Overall (valor anterior → novo valor e delta).
- Notícias negativas mostram somente a regressão do Overall (valor anterior → novo valor e delta).
- Removidas das notícias de GP as descrições de atributos individuais e os textos que diziam genericamente que houve alterações nos atributos.
- A regra foi aplicada tanto à carreira normal quanto ao modo Team Principal, incluindo pilotos contratados e sem equipe.
- A outbox pendente da V709/V710 é normalizada antes de ser publicada: mensagens antigas de delta zero são descartadas; mensagens antigas com mudança real de Overall são reescritas sem nomes de atributos ou causas detalhadas.
- O motor continua atualizando os sete atributos e seus bancos internos normalmente; somente a apresentação da Central foi limitada ao Overall.

## Testes adicionados
- Overall sem alteração: nenhuma notícia.
- Overall crescente: notícia somente com valores de Overall.
- Overall decrescente: notícia somente com valores de Overall.
- Outbox legada com delta zero: descartada.
- Outbox legada com delta não zero: normalizada.

## Limites
A compilação Android e a suíte JUnit completa requerem Gradle/Android SDK no runner do GitHub Actions.
