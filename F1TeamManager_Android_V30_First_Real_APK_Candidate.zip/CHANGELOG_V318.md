# V318 — Simulação focada e cards de pilotos compactos

- Mantida a classificação completa como área de rolagem vertical independente, suportando todos os pilotos retornados pelo motor (até 80).
- Os dois cards dos pilotos do jogador continuam fixos no rodapé da tela.
- Tocar em qualquer card fixo desloca a classificação até à posição atual desse piloto; tocar numa linha também permite focá-la.
- Reduzida a altura da linha de velocidade e dos quatro botões para liberar mais espaço vertical à simulação.
- Compactados os cards fixos: fotografia, posição, carro, métricas e botão BOX ocupam menos altura.
- Mantidos os dados reais do motor e os callbacks existentes, incluindo pausa/retoma, avanço da simulação e entrada no fluxo de BOX.
- Sem remoção de assets, histórico de versões ou sistemas de jogo.
