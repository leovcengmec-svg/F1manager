# V531 — Reinício correto de P&D e fábrica na virada da temporada

- Ao iniciar a nova temporada, pesquisa ativa, designs concluídos, cooldowns, ordens de fabricação e peças pendentes de instalação da temporada anterior são encerrados/limpos.
- O reset ocorre depois da construção do carro novo e da garagem física da temporada seguinte, preservando os níveis efetivos das peças como ponto de partida.
- A primeira pesquisa sem design anterior começa em V1, em vez de pular incorretamente para V2.
- A mudança é exclusiva ao fluxo da equipe do jogador; a simulação financeira/desenvolvimento das equipes de IA não foi alterada.
- Adicionado teste de regressão para baseline físico e versão inicial V1.
