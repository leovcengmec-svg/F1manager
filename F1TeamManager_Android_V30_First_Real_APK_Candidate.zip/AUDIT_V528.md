# Auditoria V528

## Corrigido
- O controle financeiro antes separava lançamentos de GP das 56 semanas quando a descrição não continha `semana N`.
- Agora o número do GP é convertido para a semana do calendário da temporada através de `SeasonCalendar.forSeason(season)`; usa a semana explícita quando presente e só faz fallback para a semana do GP quando necessário.
- As entradas vinculadas ao GP passam a compor os totais semanais e continuam listadas no detalhamento de movimentações de GP.

## Limitações conhecidas
- Operações sem semana e sem número de GP continuam na seção de movimentações não atribuídas. Para atribuição confiável no momento da criação, cada fluxo financeiro precisa carregar contexto de temporada/semana; não se deve fabricar esse contexto retrospectivamente.
- Histórico antigo já descartado pelo limite anterior não pode ser reconstruído.
- ZIP validado estruturalmente. Build Gradle/Android não executado neste ambiente.
