# V673 — Auditoria de eventos de assinatura no mercado de pilotos

## Regra validada
A Home deve exibir um card para cada assinatura concluída no mercado, incluindo renovação e troca/entrada em outra equipe da IA. Propostas, contrapropostas, recusas e outras fases de negociação não geram card popup na Home; permanecem no histórico central do mercado.

## Pontos alterados
- `DriverMarketEngine.expireOffers`: usa os eventos de assinatura/renovação já emitidos após aceitação efetiva do piloto.
- Fechamento de elenco na pré-temporada: padroniza a assinatura concluída como `CONTRATO ASSINADO`.
- `MainActivity`: cards e contador da Home consideram globalmente apenas renovação/contrato assinado; não filtram por equipe do jogador.
- Resumo do mercado na Home: exibe apenas assinaturas concluídas, não etapas de negociação.

## Validação
Executar `python3 tools/race_sim_test/v673_driver_market_signed_events_audit.py`.

A compilação Android completa depende do Gradle/Android SDK no ambiente de build do GitHub Actions.
