# Changelog V371 — Finalização ordenada e recuperação da carreira

- Centralizadas as chaves persistidas e a ordem canônica das etapas em `RaceFinalizationPlan`, preservando os nomes já usados pelas versões anteriores.
- `RaceFinalizationJournal` agora rejeita etapas fora de ordem e etapas que não pertencem ao plano daquela rodada.
- A conclusão terminal (`complete`) só é gravada depois de todas as etapas obrigatórias confirmarem persistência.
- A premiação de construtores é obrigatória no GP final da temporada e inválida nas rodadas anteriores.
- O fluxo de `MainActivity` passou a usar o plano com a quantidade real de rodadas da temporada e `journal.complete()`.
- Substituídos os testes isolados antigos por testes JUnit cobrindo ordem, repetição, falha de ação, falha do marcador, prêmio de fim de temporada e marcador terminal.
- Android versionCode/versionName: 371 / 0.371.0.
- Nenhuma alteração de layout, botões ou assets externos.
