# Changelog V376 — Retomada segura da finalização do GP

- O caminho comum de finalização agora captura falhas de persistência/etapas e retorna ao calendário sem apresentar uma corrida parcialmente concluída como finalizada.
- Se a simulação instantânea for acionada novamente na mesma sessão após uma finalização incompleta, ela retoma o commit usando o snapshot e o resultado já concluídos, em vez de gerar outra corrida aleatória sobre efeitos parcialmente aplicados.
- A retomada continua usando o diário durável por temporada/rodada e as chaves idempotentes de cada subsistema.
- Versão Android atualizada para 0.376.0.
- Sem alterações em layout, botões, assets externos ou histórico anterior.
