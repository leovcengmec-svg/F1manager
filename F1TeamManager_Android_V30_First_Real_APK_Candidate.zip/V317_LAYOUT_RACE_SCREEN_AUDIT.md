# V317 — Layout da simulação de corrida

## Alterações de interface
- Cabeçalho, clima, bandeira e velocidade da simulação compactados no topo.
- A classificação ao vivo passou a usar `LazyColumn`, com a lista completa de pilotos (até 80) rolável de forma independente.
- Os dois cards dos pilotos controlados pelo jogador ficam fora da lista e fixos no rodapé.
- Tocar num card inferior desloca a classificação até à linha do piloto correspondente.
- Tocar numa linha da classificação também permite focar essa posição.
- O botão BOX continua a abrir o fluxo de decisão existente (`pitDriver`).
- As fontes de dados continuam a ser `SessionSnapshot`, `carStatus`, `plans` e `classification` do motor de corrida.

## Preservação
- Não alterada a lógica do motor, cálculo de posições, tempos, pneus, combustível, ERS/DRS, decisões ou avanço da corrida.
- Não removidos os assets externos nem os registos de equipas/pilotos.
- ZIP oficial mantém o nome original.

## Validação
- Alteração estática do código e validação de integridade do ZIP.
- A compilação Android e o teste em dispositivo real não foram executados neste ambiente.
