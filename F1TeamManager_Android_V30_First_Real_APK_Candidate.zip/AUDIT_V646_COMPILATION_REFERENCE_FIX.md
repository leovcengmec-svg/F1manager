# Auditoria V646 — referência de ranking no Team Principal

## Problema relatado
O pipeline Android continuou falhando em `MainActivity.kt` com `Unresolved reference currentTeamRank` na construção do texto de progresso dos objetivos Team Principal, mesmo após a tentativa de correção anterior. Isso mostra que a V645 não resolveu o erro no ambiente real de compilação.

## Alteração
O cálculo `objectiveStatuses` agora deriva `objectiveRank` dentro do próprio bloco `remember`, diretamente de `currentRankByTeam[principal.teamId] ?: principal.lastRank`. O texto da posição atual e a avaliação das metas de classificação/evolução usam essa variável local. A referência `currentTeamRank` não é mais usada dentro desse bloco.

A declaração de `projectedOverall` continua antes dos usos na tela de previsão do carro.

## Limites
Foi feita verificação estática da alteração e dos metadados. Não há wrapper Gradle (`gradlew`) no pacote fornecido, portanto a compilação Android completa não foi executada neste ambiente. O pacote não deve ser considerado build-validado até o pipeline terminar com sucesso.
