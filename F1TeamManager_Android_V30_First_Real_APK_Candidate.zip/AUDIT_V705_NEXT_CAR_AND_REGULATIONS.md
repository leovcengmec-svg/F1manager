# Auditoria V705 — desenvolvimento do próximo carro e regulamentos

## Resultado

A V705 foi preparada a partir da V704, com versionCode 705 e versionName 0.705.0. O nome público do aplicativo e o nome padrão do ZIP foram preservados.

## Regras confirmadas na implementação

### Carro do próximo ano

1. `constructionOverallForInvestment()` agora devolve o valor direto da tabela, com o piso físico de 40; não existe multiplicador de 1,10.
2. `investNextSeason()` bloqueia aportes quando o acumulado alcança o menor valor entre o teto absoluto e o teto anual. O último aporte pode completar exatamente €150M, mas chamadas posteriores falham. A tela desativa os botões ao atingir a trava e informa o motivo.
3. A IA calcula o investimento-meta para atingir seu alvo anual. Para cada milhão de euros abaixo dessa meta, aplica menos um ponto em cada componente instalado, até o máximo de dez pontos por componente no fechamento da temporada. A perda é aplicada nos dois carros físicos, sem alterar confiabilidade ou identidade das peças. Componentes ausentes continuam em zero.
4. A rota física da IA é compartilhada entre simulação histórica, handoff de Team Principal, projeções do mercado e simulação da temporada. O construtor de compatibilidade legado também aplica o mesmo déficit.
5. O helper legado de carregamento técnico já não adiciona 10% do componente antigo; ele apenas preserva o valor recebido e soma conhecimento técnico explicitamente passado.

### Regulamento

1. O sorteio anual usa 0 alterações em 15% dos casos, 1 em 70%, e 2 em 15%; componentes escolhidos são distintos.
2. O ciclo técnico usa um sorteio pseudoaleatório estável de 6 a 10 temporadas, derivado da semente da carreira e do início do ciclo. Se o ciclo começa na temporada 1 e a duração sorteada é 6, a revolução acontece na temporada 7. Essa temporada abre imediatamente o ciclo seguinte e fixa a nova duração.
3. Todas as rotas usam `generateForCalendarYear()`/`generate()` com a mesma semente da carreira; assim, jogador, IA e simulações recebem a mesma regra.
4. Cada regra codificada agora persiste temporada, revolução, eventos, início do ciclo e duração. O decoder aceita o formato antigo de três campos para compatibilidade com saves anteriores.
5. O briefing da temporada inaugural também revela a primeira duração sorteada; anos seguintes exibem o resultado mesmo quando o sorteio anual resulta em zero mudanças.

## Testes adicionados/atualizados

- Teste de conversão direta do investimento sem bônus e teste explícito para o helper legado não devolver 10% extra.
- Testes de IA com déficit de €7M (perda de 7 pontos) e €15M (perda limitada a 10), conferindo todos os componentes instalados dos dois carros e preservação da confiabilidade.
- Teste de limite anual, permitindo o aporte final até €150M e bloqueando o aporte seguinte.
- Testes dos resultados anuais 0/1/2 com 1 sendo o resultado mais comum, determinismo e ausência de componentes duplicados.
- Teste de ciclos repetidos, duração 6–10, revolução na fronteira e novo sorteio a cada início de ciclo.
- Testes de serialização/decodificação e de aplicação da revolução aos seis componentes físicos.
- Harness de simulação atualizado para 30 transições, com ciclo variável e uso do construtor físico de IA da produção.

## Validação executável neste ambiente

- `tools/race_sim_test/v705_next_car_and_regulation_audit.py`: 16/16 verificações específicas aprovadas.
- `tools/race_sim_test/validate_project.py`: 45/45 verificações de projeto aprovadas.
- `tools/race_sim_test/final_release_audit.py`: 25/25 verificações estruturais aprovadas.
- Harness Kotlin compilado com o motor real `AnnualCarRegulationEngine.kt`: ciclos repetidos de 6–10 temporadas, fronteiras de revolução, novo sorteio por ciclo, serialização e distribuição anual ponderada passaram. Em 100 sementes e temporadas 2–80, a amostra produziu 1.054 anos com zero mudanças, 4.889 com uma mudança e 1.020 com duas mudanças (anos de revolução excluídos).
- Harness Kotlin compilado com o motor real `CarDevelopmentEngine.kt`: meta de €134M para Overall 90; garagem integral Overall 92; déficit de €7M -> Overall 85; déficit de €15M -> Overall 82; limite €149M -> €150M e tentativa posterior bloqueada. Confiabilidade preservada no teste focado.
- Os harnesses usam stubs mínimos para dependências de modelos não incluídas na compilação focada; são validações comportamentais dos motores, não substituem a suíte JUnit completa.
- Não foi possível gerar APK aqui: Gradle/Gradle Wrapper e Android SDK não estão disponíveis no pacote/ambiente. O workflow GitHub permanece o caminho de compilação APK.

## Observações de escopo

- O ciclo técnico é chamado de “revolução decenal” em partes do histórico, mas a duração agora é variável de 6–10 temporadas.
- Regulamento de revolução continua substituindo o evento anual naquela temporada; as reduções decenais existentes e o modificador de adaptação 0–8% por equipe foram preservados.
- Saves antigos com regras já registradas mantêm os eventos que já foram sorteados; novos sorteios seguem a política V705.
