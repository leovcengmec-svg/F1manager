# V400 — Proporção do diálogo de fabricação

- Corrigido o uso de peso vertical nos cards de escolha de ordem, que fazia cada opção ocupar uma parcela excessiva da altura do diálogo.
- Cards de quantidade agora têm altura fixa de 112 dp, mantendo as opções visualmente padronizadas.
- Diálogo passa a usar altura máxima em vez de ocupar obrigatoriamente 92% da tela, reduzindo o espaço vazio e preservando a área de botões.
- Mantidos preços, quantidades, validação de orçamento, seleção e ação de confirmar fabricação.
- Nome oficial do ZIP de entrega preservado.
