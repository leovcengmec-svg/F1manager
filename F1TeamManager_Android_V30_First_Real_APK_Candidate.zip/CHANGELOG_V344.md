# V344 — Idempotência do fechamento de GP

- Adicionado `CareerPreferences.isRaceRecorded(round)` para consultar o marcador persistido do resultado oficial da etapa atual.
- `recordRace` agora ignora uma segunda gravação da mesma etapa, impedindo duplicação de pontos de pilotos/construtores e regravação repetida do histórico no fluxo normal.
- `advanceRace` interrompe o fechamento repetido quando o resultado já está persistido, evitando reaplicar finanças do GP, salário, processamento financeiro das equipes de IA, avanço de patrocínios e evolução de pilotos.
- Nenhuma tela, botão ou layout foi alterado. A qualificação e a corrida instantâneas continuam sendo APIs de domínio; ainda não foram conectadas à interface.

## Limites

A proteção cobre callbacks repetidos depois de o registro canônico `race_$round` ter sido persistido. Ela não transforma todo o fechamento do GP em uma transação única entre SharedPreferences, histórico em arquivo e todos os estados financeiros. A integração transacional completa continua sendo uma etapa separada.
