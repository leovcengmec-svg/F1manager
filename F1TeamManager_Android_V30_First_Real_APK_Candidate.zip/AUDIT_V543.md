# Auditoria V543

Correção raiz: o orçamento histórico de P&D da IA era reconstruído usando o caixa discricionário disponível, podendo alocar praticamente todo o caixa restante e deixar a decisão de investimento do carro sem liquidez. Agora o P&D só recebe o caixa após proteger uma reserva real de 10% (mínimo de €2M, limitada ao caixa existente), além da reserva operacional usada no ponto de decisão.

A reserva não cria receitas nem altera o saldo; apenas limita quanto o P&D pode consumir. Investimentos continuam individualizados por equipe/temporada, reavaliados depois de cada GP, persistidos no snapshot e aplicados ao carro da temporada seguinte.

Validação feita: inspeção estática, consistência dos usos da política e integridade do ZIP. Gradle/JUnit não executados neste ambiente; o novo teste foi adicionado, não executado.
