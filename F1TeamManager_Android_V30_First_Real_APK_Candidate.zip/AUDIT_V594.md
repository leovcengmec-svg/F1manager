# AUDIT V594 — varredura de cadeia do motor

## Escopo vistoriado
- Catálogo dinâmico (`CustomWorldCatalog`, `WorldDatabase`, `CustomCatalogIdentityRules`).
- Mercado e grid (`DriverMarketEngine`, `DriverMarketCatalogMigrationV560`, `DynamicGridEngine`).
- Finalização de corrida e persistência de pontos (`MainActivity`, `ChampionshipEngine`, `ConstructorRacePoints`, `CareerPreferences`).
- Ranking de pilotos e construtores; eventos anuais; P&D/fábrica/finanças; telas de edição do catálogo.

## Correção V594
As rotas de ranking que ainda usavam `WorldDatabase.drivers` como fallback não incluíam todo o catálogo de pilotos. Agora usam `WorldDatabase.allDrivers` e limitam o ranking aos pilotos vinculados a equipes conhecidas. Isso mantém o comportamento legado quando não existe mercado salvo, mas permite que pilotos adicionais vinculados ao grid sejam considerados no ranking e nas posições de campeonato.

## Cadeia esperada
1. Edição/cadastro persiste no `CustomWorldCatalog`.
2. `WorldDatabase` expõe equipes e pilotos oficiais com substituições e registros personalizados.
3. Migração/reconciliação atualiza contratos e agentes livres.
4. `DynamicGridEngine` valida o mercado e produz participantes.
5. Finalização da corrida grava pontos por piloto e snapshot de pontos por construtor/rodada.
6. Rankings leem os pontos persistidos e cruzam os IDs com o catálogo vigente.
7. Eventos anuais e sistemas de gestão consomem os catálogos atuais; as alterações persistidas são mantidas na carreira.

## Pontos que exigem teste integrado no dispositivo
- Foi confirmada por inspeção estática a existência dos módulos e das ligações descritas; isso não prova execução de ponta a ponta.
- A disponibilidade de equipes adicionadas vem do catálogo e da tela de seleção; não foi encontrado um evento independente obrigatório de “nova equipe disponível”. Se a intenção de produto for desbloqueio condicionado por evento, essa regra ainda precisa ser especificada.
- Não foi possível executar Gradle/Android/JUnit neste ambiente (sem Gradle instalado e sem Gradle Wrapper no pacote). Simulação de duas temporadas e validação no aparelho permanecem pendentes.
- Não afirmar aprovação de corrida real, virada de temporada ou migração de carreira até a execução desses testes.

## Preservação
Nenhum asset ou histórico de versão foi intencionalmente removido. Nome oficial do ZIP mantido.
