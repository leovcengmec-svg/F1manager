# Auditoria V382

## Alteração
Integração do botão “PULAR FIM DE SEMANA” no card Próxima Corrida da Home.

## Conferências estáticas
- Callback conectado ao método `simulateWeekendInstantlyForCareer()`.
- Botões usam `Modifier.weight(1f)` na mesma linha para compartilhar a largura igualmente.
- Simulação instantânea desabilitada quando não é semana de GP, durante corrida interativa em andamento ou após GP finalizado.
- Botão normal mantém a ação `startWeekend()` e permite retomar Pit Wall quando aplicável.
- `versionCode=382`, `versionName=0.382.0`.

## Limitações
Build Android e testes oficiais ainda não executados neste ambiente; funcionamento em dispositivo ainda precisa ser confirmado.
