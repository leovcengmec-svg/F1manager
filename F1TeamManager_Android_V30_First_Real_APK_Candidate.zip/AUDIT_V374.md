# Auditoria V374 — Persistência de efeitos da carreira

## Bloco funcional
Esta versão reforça três efeitos financeiros/esportivos que ocorrem no caminho de finalização do GP: bônus de qualificação, pagamento de salários e evolução dos pilotos.

## Alterações verificadas
- Evolução: atributos e todos os mapas auxiliares, incluindo `driverEvolutionProcessedRounds_<season>`, são gravados no mesmo editor e confirmados com `commit()`.
- Salários: gravação de finanças e marcador do GP é verificada; falha aborta a etapa.
- Migração salarial antiga: o marcador de migração e os 30 marcadores de GP são confirmados no mesmo commit.
- Bônus de qualificação: estado financeiro e marcador de idempotência são confirmados no mesmo commit.
- Versão Android: 0.374.0.

## Validação
- Inspeção estática das alterações: concluída.
- Verificação de versão e dos caminhos de persistência: concluída.
- JUnit oficial / Gradle: não executado; o pacote não contém Gradle Wrapper e não há Gradle instalado no ambiente.
- Build Android: pendente.
- Simulação de 60 GPs com armazenamento Android real: pendente.

## Limites
A evolução do piloto é atômica dentro do arquivo SharedPreferences, mas as notícias de evolução são persistidas depois, em estado de mercado separado. A transação integral entre todas as preferências, histórico, finanças e notícias ainda exige testes de recuperação no ambiente Android.

## Preservação
Histórico de versões e assets externos mantidos; layout e botões não alterados.
