# Auditoria V309

## Escopo
Correções de interface na tela Equipe, conforme imagens do usuário.

## Conferências estáticas
- Cabeçalho não contém mais a linha “Pontos ${selected.points}”.
- Cabeçalho não usa mais um card separado para Overall; valores aparecem em linha inline com altura mínima de 44dp.
- Posição calculada pela classificação de construtores da temporada e critérios de desempate.
- Histórico sempre renderiza os cabeçalhos ANO/EQUIPE/POS/PTS/VIT/PÓD/POL/MV/GP/DNF; dados vêm dos registros históricos reais por equipe.
- VersionCode 309 / versionName 0.309.0.

## Não verificado
Compilação Kotlin/Android, execução em emulador e inspeção em aparelho não foram executadas neste ambiente.
