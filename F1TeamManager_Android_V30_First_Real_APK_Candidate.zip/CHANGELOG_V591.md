# V591 — Corrigir negociações e contagem do mercado de pilotos

## Correções
- Renovações da IA agora são propostas pendentes pelo mesmo fluxo de negociação do mercado, com prazo de resposta de 2 ou 3 semanas; não geram compromisso futuro instantâneo.
- A renovação pendente não impede equipes rivais de apresentar propostas. Depois que um contrato futuro é assinado, o motor mantém a regra de compromisso único por piloto.
- Respostas aceitas para a própria equipe são registradas como renovação, não como transferência.
- A proporção 55/45 continua sendo a meta definida, e as funções aceitam uma faixa de alvo entre 40% e 60%, eliminando o `coerceIn(55, 55)` que prendia o parâmetro.
- A contagem de movimentações usa compromissos assinados (`scheduled`) da temporada de decisão, distinguindo renovação de troca pelo time de origem/destino. Propostas e notificações isoladas não contam como contrato concluído.
- O teste de equilíbrio passou a medir contratos futuros assinados e verificar a banda de tolerância, em vez de aprovar com contagem vazia/incompleta.
- A conclusão emergencial de vagas na virada agora cria uma proposta, aguarda a janela de resposta de 2–3 semanas (simulada dentro da transição atômica), processa a resposta e só então efetiva o contrato aceito. Consulta o orçamento fornecido, considera a taxa de assinatura de agente livre e desconta taxas cumulativamente por equipe. Quando o orçamento é explicitamente insuficiente, a vaga permanece aberta. Chamadas antigas sem mapa de orçamento mantêm compatibilidade.

## Validação
- Incluídos testes de regressão para o prazo da renovação da IA, concorrência durante a janela e classificação das movimentações assinadas.
- A compilação Gradle/Android e a execução oficial da suíte JUnit não foram realizadas neste ambiente; não declarar APK compilado nem testes executados.
