# V591 — vistoria geral e persistência do catálogo

- Corrigido o salvamento de equipes personalizadas: `initialLevel` agora é persistido no registro principal, evitando que a classe/nível inicial volte ao padrão após reiniciar o aplicativo.
- O snapshot diagnóstico passa a incluir também os JSONs de overrides de pilotos e equipes oficiais, para que a exportação represente o catálogo completo.
- Preservada a reconciliação de mercado/roster da V590 e os IDs históricos.
- Vistoria estática: conferidos versionamento, estrutura do ZIP, contagem de assets, ausência de marcadores TODO/FIXME e principais caminhos de catálogo/mercado.
- Limite: sem Gradle Wrapper e sem Gradle instalado no ambiente, não foi possível executar build Android nem a suíte JUnit. Também falta validar em dispositivo e simular duas temporadas completas.
