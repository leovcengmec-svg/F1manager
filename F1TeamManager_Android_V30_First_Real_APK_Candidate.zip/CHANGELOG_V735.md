# V735 — evolução, promoção, curva de carreira e instalações

Base V734. Atualização integrada dos quatro pontos solicitados.

## Evolução adicional de Overall
- Recalibra a liberação da margem adicional: 105/110/115/120/125 liberam +1/+2/+3/+4/+5.
- Mantém cinco GPs reais como amostra mínima e conserva a maior margem conquistada na temporada.
- Atualiza o cálculo de margem para pilotos Pro livres com a média real da última temporada, sem inventar resultados enquanto estiverem sem equipe.
- Preserva o uso da mesma regra no desenvolvimento natural, Centro de Desenvolvimento, carreira e IA.
- Ajusta o piso do potencial estimado das classes Médio/Forte/Pro para 74/84/94, preservando potenciais individuais mais altos.

## Promoção para Lenda
- Corrige a verificação de título: um piloto Pro pode cumprir o requisito de campeão com qualquer título registrado na carreira, não apenas sendo campeão na última temporada avaliada.
- Critérios de desempenho bienal e promoção de uma classe por avaliação permanecem.

## Gráfico
- Exibe somente o ciclo etário mais recente.
- Desenha curva suave a partir dos snapshots reais, sem marcadores intermediários.
- Mantém apenas o ponto inicial e o ponto atual.
- O gráfico reinicia visualmente quando o piloto volta aos 18 anos; os ciclos anteriores continuam no histórico persistido.

## Instalações
- Percentuais de Fábrica, P&D, Túnel de Vento, Simulador e Operações de Corrida passam a ser apresentados com uma casa decimal e vírgula decimal brasileira.
- A precisão dos cálculos internos não foi alterada.

## Validação
- 26 testes focados de motores e progressão aprovados em execução Kotlin isolada.
- Teste do formatador percentual aprovado.
- 17 verificações estáticas aprovadas.
- Build Android completo e suíte Gradle integral permanecem pendentes de GitHub Actions.
