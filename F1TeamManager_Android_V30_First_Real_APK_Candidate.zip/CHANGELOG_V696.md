# v696 — ciclo de carreira dos pilotos

## Regras implementadas
- Pilotos não se aposentam nem são removidos. Ao final do ciclo etário, a idade volta a 18 e o piloto inicia outro ciclo mantendo identidade, contrato/mercado, histórico, perfil de evolução e classe competitiva.
- O primeiro ciclo respeita a coorte inicial determinística; após chegar a 43 anos, ciclos seguintes percorrem 18–43 anos e reiniciam em 18.
- No reinício, recupera 50% das perdas físicas acumuladas exclusivamente por envelhecimento. Recuperação limitada ao pico histórico de velocidade, ultrapassagem e defesa.
- Qualificação, consistência, chuva e gestão de pneus não são recuperadas por envelhecimento; perdas de atributos causadas por desempenho ruim também não são desfeitas.
- Perfil da tabela de evolução (Prodígio, Auge Rápido, Auge Moderado, Auge Tardio e demais perfis) permanece fixo; a idade só altera o ritmo de crescimento e a pressão de regressão.
- Pilotos livres recebem 100% da taxa natural de evolução dos pilotos contratados, mantendo potencial, limites anuais e envelhecimento. Não são criados resultados fictícios para avaliação de classe.
- Classe competitiva permanece baseada em evidências das duas últimas temporadas completas, independentemente da idade; promoção Pro→Lenda exige título e a classe Normal/Médio permanece como piso.

## Compatibilidade e validação
- Novos ledgers persistidos separadamente: pressão fracionária de idade, perdas físicas por atributo, picos físicos e índice do ciclo. Saves antigos inicializam os ledgers no ciclo/atributos atuais sem atribuir retroativamente perdas passadas que não estavam separadas por causa.
- Adicionados testes de ciclo, recuperação de 50%, proteção dos atributos não físicos, perfil imutável e evolução integral de agentes livres.
- Núcleo Kotlin de evolução compilado e verificações isoladas executadas. Compilação Android completa e suíte JUnit integral precisam ser confirmadas no GitHub Actions (o pacote não contém Gradle Wrapper e este ambiente não possui Gradle/Android SDK).
