# Auditoria V562 — limites de posição na evolução

- DriverEvolutionEngine.gpPerformanceIndex agora aceita `gridSize`; valor padrão 80 preserva comportamento legado.
- ManagerSeasonEngine constrói posições-alvo e fallback usando `WorldDatabase.teams.size * 2`.
- CareerPreferences fornece tamanho do grid ao cálculo anual.
- Risco residual: outros sistemas ainda podem conter limites esportivos fixos (por exemplo, patrocinadores, qualificação, classificação e premiações); não declarar grid expandido completo até auditar e testar esses fluxos.
- Build e testes não executados.
