# Auditoria V643 — GP concluído versus DNF

## Problema observado
O perfil do piloto mostrava 30 GPs e 3 DNFs, mesmo que o campo GP pretendido represente corridas concluídas. A estatística de temporada e o total de carreira misturavam participações com conclusões.

## Correção
- `HistoricalDatabase.finalizeSeason`: `gps` do piloto conta somente resultados cujo status não começa com DNF.
- `liveSeasonRow`: GP conta apenas resultados concluídos; DNF permanece em campo separado.
- Perfil do piloto: total da carreira conta apenas resultados não-DNF.
- Histórico por temporada: GP e DNF são recalculados por piloto a partir dos resultados de corrida existentes, inclusive para resumos antigos arquivados.
- Estatística de construtores permanece como GPs em que pelo menos um dos pilotos terminou, pois é uma métrica da equipe.

## Caso de regressão
30 resultados de um piloto, 3 com status DNF e 27 concluídos devem render `GP=27`, `DNF=3`. Para carreira com 180 resultados e 32 DNFs, a exibição será `GP=148`, `DNF=32`.

## Limitação
As alterações de fonte e os checks de consistência podem ser verificados localmente; compilação Android completa e renderização em dispositivo não foram executadas neste ambiente.
