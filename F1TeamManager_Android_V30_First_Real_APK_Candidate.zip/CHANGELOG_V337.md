# V337 — Incidentes de corrida: colisão, furo e pane elétrica

Base: V336 com o patch de eventos de corrida solicitado.
Versão: 0.337.0 · versionCode 337

- Aumenta moderadamente a ocorrência global de colisões por volta, ajustada ao risco do circuito.
- Agenda no máximo um furo de pneu por GP, com parada emergencial e perda de tempo.
- Adiciona pane elétrica MGU-K - ERS como evento de abandono (DNF), com chance vinculada à confiabilidade elétrica média.
- Associa os eventos de furo e pane elétrica às imagens específicas na interface.
- Mantém as regras de confiabilidade, classificação e registo de eventos já existentes.

Validação: verificações estáticas e integridade do ZIP realizadas. Compilação Android e simulação completa de temporadas não executadas.
