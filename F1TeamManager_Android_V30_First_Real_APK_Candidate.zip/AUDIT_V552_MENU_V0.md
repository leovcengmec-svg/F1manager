# V552 — Menu compacto e baseline V0

## Alterações
- Menu inicial: reduzi aproximadamente pela metade o espaço vertical destinado aos três cards, removi parte dos espaços internos e entre cards, e movi o logotipo para o topo da coluna para posicioná-lo na área escura da imagem de fundo.
- P&D/garagem: carros físicos iniciais agora registram todas as peças-base como V0.
- Transição de temporada: o carro físico novo começa com peças-base V0, mantendo a progressão de pesquisa independente (primeira pesquisa concluída/projeto versionado é V1).
- IA: versões-base ausentes passam a ser V0; a próxima pesquisa por componente passa a V1, não V2.
- Mantidos versionCode 552 e versionName 0.552.0.

## Verificações
- Conferência estática dos pontos de criação de carros físicos e dos fallbacks de versão da IA.
- Conferência de integridade do ZIP realizada após empacotamento.
- Build Android não executado: o projeto não contém Gradle Wrapper e não há Gradle instalado neste ambiente.
