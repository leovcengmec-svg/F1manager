# Auditoria V399

## Alterações
- `app/src/main/java/com/f1teammanager/MainActivity.kt`: rótulo do botão e estado visual sincronizado dos dois botões do card Próxima Corrida.
- `app/build.gradle.kts`: `versionCode=399`, `versionName=0.399.0`.

## Verificações realizadas
- Inspeção estática confirma que o card usa `ABRIR FIM DE SEMANA` quando não há corrida em andamento e `RETOMAR PIT WALL` durante corrida em andamento.
- Os dois botões usam `nextRaceActionColor`: vermelho na semana do GP e `Panel2` fora dela; texto branco também no estado desabilitado.
- Build Android e testes automatizados não foram executados neste ambiente.
