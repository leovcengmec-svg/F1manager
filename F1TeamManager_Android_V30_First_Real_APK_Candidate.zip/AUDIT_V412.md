# Auditoria V412

## Regras
- Meta desejada: 55% renovações / 45% transferências.
- Mais atividade sem exagero: 10 equipes avaliadas por semana (antes 8), atividade 82% para equipes com contrato expirando (antes 78%) e 10% para elencos completos sem contrato expirando (antes 7%).
- Renovação IA: probabilidades moderadamente aumentadas para 15/12/8/3 conforme interesse.
- Contagem aceita aliases de títulos de notificação que o próprio fluxo usa.

## Limitações
A meta é aplicada às movimentações registradas e depende da elegibilidade dos pilotos, do interesse e da disponibilidade de vagas; não garante exatamente 55/45 em toda temporada. A compilação Android e a execução da suíte de testes precisam ser realizadas no ambiente Gradle do projeto.
