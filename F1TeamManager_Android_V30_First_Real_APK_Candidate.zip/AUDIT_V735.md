# Auditoria e entrega V735 — evolução de pilotos, promoção, gráfico e instalações

## Base e versão
- Base: V734 (0.734.0)
- Entrega: V735 (VersionCode 735 / VersionName 0.735.0)
- Nome público preservado: F1 Team Manager V30
- Nome do ZIP preservado: `F1TeamManager_Android_V30_First_Real_APK_Candidate.zip`

## 1. Faixa adicional de Overall
- Mantidos os tetos de classe: Médio 69, Forte 79, Pro 89 e Lenda 100.
- Margem adicional máxima mantida em +5 para Médio/Forte/Pro; Lenda continua no teto global 100.
- Calibração do índice exclusivo de desbloqueio: 105 → +1, 110 → +2, 115 → +3, 120 → +4, 125 → +5.
- A amostra mínima de cinco GPs foi preservada.
- O high-water mark da temporada continua monotônico: margem conquistada não é retirada por uma queda posterior da média.
- A média usada para pilotos livres é recalculada também a partir da temporada anterior e combinada com a margem já salva, para que saves antigos usem a nova calibração.
- O Centro de Desenvolvimento continua usando o mesmo limite e mantém pontos pendentes até a margem ficar disponível.
- Potencial estimado de perfis Médio/Forte/Pro agora tem piso correspondente à faixa adicional (74/84/94). Potenciais individuais superiores continuam preservados; o limite efetivo ainda respeita potencial, classe e Overall 100.

## 2. Promoção Pro → Lenda
- A carreira normal consulta todos os títulos registrados em `history.driverChampions()`, não apenas o campeão da temporada mais recente.
- Os demais critérios bienais permanecem: duas temporadas consecutivas com evidência suficiente, média individual mínima, média combinada e Overall de entrada na classe seguinte.
- A promoção continua sendo de uma classe por avaliação.
- O modo Team Manager já acumula `driverCareerTitles`; sua regra foi preservada.

## 3. Gráfico de evolução
- A persistência dos snapshots não foi apagada nem reescrita.
- O seletor `DriverEvolutionChartModel` entrega somente snapshots do ciclo etário mais recente para o gráfico.
- O traçado usa interpolação cúbica suave através dos snapshots reais do ciclo, sem desenhar marcadores intermediários.
- Apenas o ponto inicial e o ponto atual são destacados.
- Evolução colore a curva em verde; regressão em vermelho; estabilidade usa a cor neutra da métrica.
- Ao reiniciar aos 18 anos, o snapshot `CYCLE_RESET` inicia o novo gráfico; ciclos anteriores continuam arquivados.

## 4. Percentuais das instalações
- Todas as descrições percentuais em `FacilityEngine.levelEffect()` usam `FacilityPercentageFormatter` usa `Locale("pt", "BR")` e uma casa decimal.
- Inclui Fábrica, P&D, Túnel de Vento, Simulador e Operações de Corrida.
- Somente a apresentação é arredondada; cálculos internos preservam `Double` original.
- Multiplicadores comerciais (`x1.xxx`) não são percentuais e mantêm seu formato existente.

## 5. Testes adicionados/atualizados
- Degraus de desbloqueio de +1 a +5.
- Potencial estimado mínimo para perfil Pro/Prodígio alcançar 94.
- Crescimento natural e Centro de Desenvolvimento com margem disponível.
- Promoção Pro → Lenda quando o indicador de título de carreira está ativo.
- Seleção do ciclo atual e preservação dos endpoints do gráfico.
- Formatação percentual de instalações com uma casa decimal.

## 6. Validação executada nesta sessão
- Compilação Kotlin isolada dos motores de evolução, progressão, catálogo de perfis, Centro de Desenvolvimento e modelo de gráfico: aprovada.
- 26 testes focados Kotlin/JUnit-style executados com stub compatível local: aprovados.
- Teste direto do `FacilityPercentageFormatter`: aprovado.
- 17 verificações estáticas de release, integração do histórico, ciclo do gráfico e formatação: aprovadas (`tools/v735_audit.py`).
- O ambiente não disponibiliza Gradle/Gradle Wrapper nem Android SDK; portanto, `testDebugUnitTest` completo e `assembleDebug`/APK não foram executados.

## Limites da validação
A promoção baseada no histórico foi corrigida no fluxo de carreira, mas a confirmação do caso específico do piloto exige que os três títulos estejam presentes no record book do save usado no teste. A compilação completa da Activity Compose e o build Android ainda precisam do GitHub Actions.
