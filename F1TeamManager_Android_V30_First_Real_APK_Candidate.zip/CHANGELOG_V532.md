# V532 — Correção de identidade dos pilotos no quali

- A classificação de qualificação usa o catálogo completo (`allDrivers`), incluindo pilotos reservas/mercado, evitando nomes genéricos como “Piloto 89”.
- Escudo e carro exibidos no quali seguem o contrato ativo do piloto na temporada, e não a equipe histórica/estática do catálogo.
- Bônus financeiro de qualificação do jogador e das equipes IA usa a equipe contratual ativa, alinhando o cálculo com o grid real.
- Mantida a lógica da simulação e o histórico existente.
