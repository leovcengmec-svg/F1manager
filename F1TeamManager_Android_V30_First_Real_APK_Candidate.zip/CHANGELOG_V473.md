# V473 — Contraproposta do piloto com exigências completas e acesso direto

- A notificação de contraproposta passa a informar salário anual exigido, duração, papel na equipe e temporada de início, usando valores monetários em milhões ou mil.
- O botão do aviso na Home passa a abrir diretamente o Mercado de Pilotos quando se trata de contraproposta.
- Ao entrar no Mercado de Pilotos, uma contraproposta pendente do jogador é aberta automaticamente; o card persistente continua disponível para reabrir e decidir.
- O diálogo mantém as três decisões: aceitar os termos, recusar ou enviar nova contraproposta, incluindo salário, duração e papel.
- Atualizada a versão Android para `versionCode 473` / `versionName 0.473.0`.
- ZIP verificado quanto à integridade; build Android ainda precisa ser confirmado no GitHub Actions.

