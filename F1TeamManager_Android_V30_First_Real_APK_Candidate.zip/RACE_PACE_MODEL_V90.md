# V90 — Unified Race Pace Model

## Approved reference
All dynamic pace influences are calculated relative to the GP average lap time.

### Tyres
- Dry: Soft -2.0%, Medium -1.0%, Hard 0.0%.
- Light rain: Intermediate 0.0%; slicks +8.0%; Wet +6.0%.
- Medium rain: Intermediate 0.0%; slicks +15.0%; Wet +5.0%.
- Heavy rain: Full Wet 0.0%; Intermediate +10.0%; slicks +30.0%.

### Degradation
- 0–20%: 0.0% additional
- 20–40%: +0.25%
- 40–60%: +0.75%
- 60–80%: +1.50%
- 80–100%: +3.00%

### Driver strategy
- Attack: -1.0%
- Balanced: 0.0%
- Defense: +1.0%

### Fuel
Continuous interpolation of the approved reference points:
- 100%: +1.50%
- 75%: +1.10%
- 50%: +0.70%
- 25%: +0.30%
- 10%: +0.10%
- 0%: DFN

The CareerWeekendEngine and InteractiveRaceSession now consume the same TyreModel rules.
Fixed millisecond tyre/fuel/strategy modifiers were removed from the race pace path.
