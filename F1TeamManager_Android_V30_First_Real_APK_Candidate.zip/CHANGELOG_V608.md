# V608 — Mercado de pilotos realista e virada sem atribuição forçada

- Eliminada a atribuição direta de pilotos na virada: a IA só fecha vaga por oferta aceita ou contraproposta dentro do limite financeiro/negocial, com histórico e notícia próprios.
- A equipe do jogador não recebe pilotos automaticamente. A ação de iniciar temporada verifica os dois contratos antes de abrir o diário persistente e indica como resolver uma vaga pendente sem alterar a carreira.
- Atratividade dos pilotos considera desempenho/classificação atual da equipe e posição/pontos do piloto, além da força/prestígio de base e dos atributos evoluídos.
- Candidato ao título tem resistência esportiva para trocar uma equipe competitiva por uma equipe muito inferior; remuneração extraordinária pode compensar, mas a decisão não é tratada como normal.
- A IA compara titulares e candidatos, prioriza contratos que vencem e só quebra contrato plurianual quando a melhoria esportiva é expressiva.
- Removida a barreira global 55/45 entre renovação e transferência. A IA pode renovar quando não há alternativa melhor, mas a proporção não impede uma substituição estrategicamente necessária.
- Ofertas concorrentes são comparadas antes da assinatura; múltiplas equipes podem disputar o mesmo piloto.
- As taxas de assinatura das contratações resolvidas na virada agora entram no ledger financeiro parcelado da IA, com registro idempotente persistido.
- Preservados os assets, o histórico de versões e os saves existentes. Validar dentro do jogo em uma carreira nova via **Novo Jogo**.
- Validação realizada: 59 fontes Kotlin do núcleo compiladas; 10 testes direcionados, 17 verificações específicas de mercado, 40 verificações gerais e 25 verificações finais aprovadas; 12 transições de temporada em 3 sementes mantiveram o grid completo.
- Limite: compilação Android/Gradle completa, JUnit oficial e validação em emulador/dispositivo não foram executadas neste ambiente.
