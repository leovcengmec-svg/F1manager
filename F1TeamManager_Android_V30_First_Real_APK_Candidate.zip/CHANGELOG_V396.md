# V396 — Identificação dos pilotos no plano de largada

- Reorganizada a identificação de cada piloto: nome na primeira linha; bandeira, escudo da equipe e posição de largada alinhados na linha seguinte.
- Bandeira, escudo e posição agora usam cards de altura padronizada de 36 dp.
- A posição usa largura dedicada de 48 dp e texto em uma linha para evitar corte de `P10`, `P15` e posições com dois dígitos.
- Mantido o card de overall nas dimensões anteriores de 46 × 48 dp.
- Nenhuma regra de estratégia, pneus, simulação ou assets externos foi alterada.
