# V738 — Correção de compilação Kotlin

## Erro reportado
O workflow falhou em `:app:compileDebugKotlin` no `MainActivity.kt` (linhas 11192, 11195 e 11196). `DriverMarketOrdering.sort` usa o tipo genérico `K : Comparable<K>`, mas o seletor misturava `String` (Nome) e `Int` (Idade, Classe e Overall). Isso impedia a inferência de `K` e fazia a chave retornada pelo `when` não satisfazer um comparável homogêneo.

## Correção
- Todos os ramos de `value` retornam `String`.
- Idade e Overall recebem `padStart(3, '0')`, mantendo ordenação numérica correta entre os valores válidos.
- Nome continua alfabético.
- A ordenação secundária por nome e ID permanece inalterada.
- Teste de regressão adicionado ao conjunto `DriverMarketOrderingV738Test`.

## Validação executada
- Compilação isolada do utilitário `DriverMarketOrdering.kt` via `kotlinc`: aprovada.
- Harness de execução: crescente, decrescente, idade e nome: aprovado.
- Integridade do ZIP: verificada após empacotamento.
- Gradle/Android SDK: indisponíveis neste ambiente; não foi possível afirmar que o APK Android foi compilado.

## Versionamento
Correção aplicada na mesma V738 (`versionCode=738`, `versionName=0.738.0`), sem alterar nome público ou nome de arquivo ZIP.
