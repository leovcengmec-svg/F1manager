# V453 — Investimento automático da IA no próximo carro

- Implementado investimento gradual da IA no carro da temporada seguinte.
- Aplicadas as mesmas travas acumuladas por fase, reserva de caixa e teto de €150M usados pelo jogador; IA também protege a reserva operacional de salários e corridas.
- Investimentos persistidos por equipe/temporada e aplicados à construção do carro no início do ano seguinte.
- Card da equipe ligado ao ledger financeiro persistido e ano de projeção dinâmico.
- Layout existente preservado.
