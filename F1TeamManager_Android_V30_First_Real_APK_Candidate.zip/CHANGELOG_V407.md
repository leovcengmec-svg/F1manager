# V407 — Integração de eventos do mercado de pilotos

- A Home agora reconhece e pode exibir o evento `PROPOSTA ENVIADA`, além das respostas de propostas e do fechamento por contraproposta.
- O card de evento reconhece `CONTRATO FECHADO` como evento de mercado assinado.
- Se uma proposta recebe resposta positiva mas a gravação do contrato futuro falha por conflito, o mercado grava `PROPOSTA NÃO CONCLUÍDA` em vez de descartar a resposta sem aviso.
- Mantido o fluxo acordado de eventos na Home e mantido o processamento semanal do mercado nos dois comandos de avanço do calendário.
- Adicionados testes para a criação do evento de proposta e processamento da resposta ao avançar semanas.
