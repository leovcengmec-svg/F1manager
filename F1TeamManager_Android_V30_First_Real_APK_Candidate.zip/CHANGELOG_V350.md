# V350 — Recuperação por etapas do fechamento de GP

- Adicionado diário persistente de etapas de finalização por temporada e rodada.
- A finalização agora diferencia um resultado já registrado de um GP cujo fechamento inteiro já foi concluído.
- O fechamento pode retomar etapas ainda não marcadas, sem repetir etapas já confirmadas.
- Persistência explícita após finanças do jogador, salário, finanças de IA, avanço de patrocínios, registro da corrida, evolução, notícia, premiações de temporada e estado final.
- A simulação instantânea só bloqueia um GP já finalizado; um fechamento incompleto pode ser retomado pelo finalizador compartilhado.
- Nenhuma mudança de layout ou botão.
