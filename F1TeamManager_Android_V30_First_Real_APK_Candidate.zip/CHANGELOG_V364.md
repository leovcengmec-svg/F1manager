# F1 Team Manager — V364

## Bloco: cadeia de simulação instantânea por duas temporadas

- Adicionado `InstantSimulationTwoSeasonChainTest`, teste JUnit para 60 fins de semana consecutivos (30 em 2026 e 30 em 2027) usando o serviço real de simulação instantânea.
- Cada GP utiliza 80 participantes, seed determinística própria e circuito com distância e riscos variáveis.
- Verificações por GP: fases de qualificação 80/50/20, IDs únicos, posições 1–80, distância programada e validador final sem erros.
- Corrigido erro de compilação em `CareerWeekendEngine.simulateQualifyingInstantly()`: acesso incorreto `finalGrid.entries` alterado para `finalGrid.grid`, propriedade real de `QualifyingResult`.
- Compilação Kotlin isolada do domínio de corrida e execução do harness: 60/60 fins de semana aprovados.
- Atualizado `versionCode` para 364 e `versionName` para `0.364.0`.
- Interface, botões, assets externos e histórico anterior mantidos.

## Limitações

O Gradle/JUnit e o build Android não foram executados nesta sessão. A cadeia de 60 corridas foi exercitada por harness Kotlin diretamente contra as classes reais do motor; a integração persistente com finanças, patrocínios, notificações e evolução precisa de testes adicionais no ambiente completo.
