# Auditoria V427 — recuperação da virada de temporada

## Alterações
- `CareerPreferences` guarda origem, destino e etapa da virada em SharedPreferences usando `commit()`.
- `MainActivity.startNextSeason()` cria o registro antes da transição, marca `SEASON_ADVANCED` após a mudança de temporada, marca `STATE_PERSISTED` depois de salvar os estados canônicos e limpa o journal no final.
- Se encontrar uma transição pendente que já avançou de etapa, o fluxo bloqueia uma nova tentativa automática. Isso evita repetir cegamente investimento, construção do carro ou gravações de histórico.
- O teste-fonte `SeasonTransitionV427AuditTest` verifica os contratos básicos do journal.

## Riscos/pendências
- Isto é detecção segura e bloqueio, não recuperação automática completa. Se o processo morrer no meio da persistência, é necessária recuperação assistida.
- Os subsistemas ainda gravam em múltiplas operações de SharedPreferences; não há transação única que abarque calendário, garagem, finanças, mercado e histórico.
- O caminho de simulação de temporada de `ManagerSeasonEngine` é distinto do fluxo manual e ainda precisa de teste de integração comparativo.
- Não foi possível executar Gradle ou testes automatizados: o projeto não inclui `gradlew`/`gradlew.bat` e o comando `gradle` não está disponível neste ambiente.
