# CHANGELOG V720 — Ranking estável e controles de áudio

## 1. Correção da oscilação de posição ao abrir a equipe

- Simulações de desenvolvimento usadas apenas como projeção nas telas Visão das Equipes e Ranking das Equipes agora são explicitamente somente leitura em relação ao ranking técnico global.
- O mecanismo de simulação aceita `publishLiveOverall`; o valor padrão continua habilitado nos fluxos reais de progressão, enquanto as projeções da interface passam `false`.
- O mesmo isolamento foi aplicado à projeção de força do próximo carro no mercado.
- As simulações reais de abertura de temporada, avanço semanal, processamento de eventos, corrida e encerramento continuam seguindo o fluxo de publicação existente.
- A alteração não congela artificialmente a posição exibida: as equipes continuam ordenadas por Overall físico. Ela impede que a simples consulta da tela modifique o conjunto de dados que será usado no próximo cálculo.

## 2. Configurações de áudio

- A tela Configurações agora possui um interruptor para ativar/desativar todo o áudio do jogo.
- Foi adicionada uma barra deslizante de volume de 0% a 100%, habilitada quando o áudio está ligado.
- O volume é aplicado diretamente aos `MediaPlayer` do jogo, incluindo músicas e efeitos, por `MediaPlayer.setVolume()`.
- Não há chamada a `AudioManager.setStreamVolume()` nem alteração do volume de mídia do Android.
- Estado ligado/desligado e volume são guardados em SharedPreferences e sobrevivem ao fechamento/reabertura do app.
- Eventos sonoros que terminarem de preparar após o usuário desligar o áudio não poderão iniciar a reprodução.

## 3. Compatibilidade

- Mantidos o nome público `F1 Team Manager V30` e o nome original do pacote ZIP.
- Carreira, save, histórico, contratos, resultados e estado financeiro não são migrados nem apagados por esta atualização.
- V719 permanece como base imediata.

## Versão

- `versionCode`: 720
- `versionName`: `0.720.0`
- Base: V719 / 0.719.0
