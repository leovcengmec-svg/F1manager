# Auditoria de implementação — V658: planos e limiares de pneus

Base: V657 (`versionCode 657`, `versionName 0.657.0`).
Candidato: V658 (`versionCode 658`, `versionName 0.658.0`).

## Alterações verificadas

- `TyreModel` centraliza os limiares: manual 80%, automático 85%.
- Estimativa de stint usa clima, modo de condução e atributo de gestão de pneus.
- Plano automático troca por desgaste a partir de 85%.
- Modo manual abre uma decisão de box a partir de 80%; a decisão de permanecer na pista não reabre repetidamente no mesmo jogo de pneus.
- Planos de chuva usam intermediário em chuva fraca/média e WET em chuva forte.
- Planos secos são classificados por tempo projetado, incluindo degradação e 21 s de perda por parada.
- Distribuição de stints mantém a soma igual às voltas da corrida e não ultrapassa a janela de desgaste calculada.
- A interface usa a mesma estimativa central do motor para vida útil do composto.

## Verificação executada

- Compilação isolada de `TyreModel.kt` com os modelos centrais e execução de harness Kotlin.
- Harness executado em 58 voltas para pista seca, chuva fraca, chuva média e chuva forte; os quatro planos de cada cenário cobriram exatamente 58 voltas e respeitaram os limites de stint.
- Conferência dos limiares reportou manual=80 e automático=85.
- Testes JUnit e build Android completo não foram executados: o pacote não contém Gradle Wrapper e o ambiente não disponibiliza Gradle/Android SDK. Portanto, este ZIP não deve ser descrito como APK compilado/validado.
