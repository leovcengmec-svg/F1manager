# V574 — Diagnóstico e proteção operacional do catálogo

- A tela **Cadastros do Jogo** agora mostra o modo de proteção quando a validação do catálogo encontra inconsistências e apresenta as primeiras ocorrências.
- Escritas, novos cadastros e ações de edição ficam desabilitados enquanto o catálogo estiver inconsistente, sem apagar nem substituir os dados existentes.
- Adicionada exportação manual para a área de transferência de um pacote de diagnóstico contendo as ocorrências e os valores brutos persistidos de pilotos, equipes e bandeiras, para recuperação orientada sem reconstrução por suposição.
- Adicionada revalidação explícita e somente de leitura.
- A auditoria também verifica atributos dos pilotos fora de 1–100 e nomes de arquivos de escudos/bandeiras inválidos.
- Mantidos IDs, histórico, carreiras, dados persistidos e assets externos. Nenhuma rotina automática de correção ou descarte foi introduzida.

## Validação

- ZIP verificado com `unzip -t`.
- Testes de contrato adicionados; não executados neste ambiente.
- Compilação Android não executada: o projeto não inclui Gradle Wrapper e não há Gradle instalado no ambiente.
