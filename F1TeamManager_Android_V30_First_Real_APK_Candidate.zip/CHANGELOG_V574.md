# V574 — Busca exclusiva por nome de piloto

- A busca das fotos de todos os pilotos foi unificada: usa somente o nome completo do piloto cadastrado.
- Removidos fallback por ID numérico e aliases de outros pilotos, que podiam exibir fotos trocadas após substituições de elenco.
- Continua aceitando acentos, espaços, hífens e sublinhados por normalização do nome, além do prefixo `driver_`.
- Aplicado a titulares e reservas; o restante dos Assets externos não foi alterado.
- Base: V573.
