# Auditoria V386

Alterações limitadas à composição da Home em `MainActivity.kt` e metadados da versão Android.

Verificações estáticas:
- O título "QUADRO DE SEMANAS" foi removido da Home.
- O card "PRÓXIMA CORRIDA" aparece antes de "SITUAÇÃO DO CAMPEONATO".
- A área da imagem usa `aspectRatio(1f)`.
- O nome fixo do ZIP de entrega permanece `F1TeamManager_Android_V30_First_Real_APK_Candidate.zip`.

A compilação Android e a verificação visual em dispositivo permanecem pendentes neste ambiente.
