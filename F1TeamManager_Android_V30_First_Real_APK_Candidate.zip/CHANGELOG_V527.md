# V527

- O controle financeiro da temporada agora exibe explicitamente as movimentacoes que existem no historico, mas nao possuem semana identificavel na descricao.
- Essas operacoes nao sao silenciosamente omitidas nem atribuidas a uma semana inventada.
- O rodape informa quantas movimentacoes da temporada foram lidas e quantas nao possuem semana.
- Mantido o limite de historico de 2.000 lancamentos.

Limitacao conhecida: operacoes antigas sem metadado de semana nao podem ser distribuídas retrospectivamente com confiabilidade. Os fluxos que geram novos lancamentos ainda precisam gravar temporada/semana para permitir atribuicao semanal completa.
