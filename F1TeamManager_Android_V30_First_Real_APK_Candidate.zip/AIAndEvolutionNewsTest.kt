import com.f1teammanager.core.manager.*
import com.f1teammanager.core.season.WorldDatabase

fun main(){
 val ai=AITeamDevelopmentEngine(20261006)
 var changed=0
 for(t in WorldDatabase.teams){
  val a=ai.simulate(t,0,2026); val b=ai.simulate(t,30,2026)
  if(a!=b) changed++
 }
 check(changed>0) { "Nenhuma equipe IA evoluiu no teste" }
 println("AIAndEvolutionNewsTest: PASS ($changed equipes com mudança em 30 semanas)")
}
