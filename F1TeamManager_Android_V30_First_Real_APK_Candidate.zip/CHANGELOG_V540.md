# V540 — Correção das taxas de contratação de pilotos

- Taxa de contratação de piloto livre: 20% do valor de mercado do piloto.
- Renovação de piloto da própria equipe: 20% do valor de mercado do piloto.
- Contratação de piloto vinculado a outra equipe: 40% do valor de mercado do piloto.
- O cálculo usa o valor de mercado do piloto, não o salário, e é compartilhado pelos caminhos de contratação/renovação.
- Adicionado teste de regressão para as três regras.

Nota aritmética: 20% de €100 milhões = €20 milhões; para uma taxa de €24 milhões a 20%, o valor de mercado é €120 milhões.
