# Auditoria de estabilização V714 — Home e Acesso Rápido

## Escopo
Base V713. Mudanças restritas à Home, navegação dos atalhos e seleção da aba inicial da tela Campeonato.

## Dados da Situação do Campeonato
- Construtores: `CareerPreferences.constructorPoints()` e a mesma ordenação da tela `Standings`, com posições de 1 a 40, diferença para a equipe anterior e seguinte.
- Pilotos: contratos ativos na temporada e pontos oficiais de `driverPoints()`, com a mesma ordenação da tela `Standings`; exibidos os dois pilotos da equipe.
- Finanças: saldo (`finance.budget`), envelope técnico anual restante (`SeasonInvestmentPolicy.remainingAnnualTechnicalEnvelope`) e capacidade técnica imediata após `protectedCash`; cada valor tem rótulo próprio.
- Último GP: projeção derivada de `HistoricalDatabase.raceRecords()`, agregada por temporada/round e ordenada da mais recente; guarda identidade da pista e resultados da equipe. A leitura é executada em `Dispatchers.IO`, não em cada recomposição. Se o arquivo histórico ainda não contém registros, há fallback para `CareerPreferences.raceHistory()` da temporada ativa.

## Navegação
- Competição: Fim de Semana, Calendário, Campeonato, Temporada.
- Gestão da Equipe: Equipe/Instalações, Pilotos, Mercado, Carro/P&D, Finanças, Central de Notícias.
- História e Estatísticas: História, Hall da Fama, Recordes.
- Cada atalho aponta para o `Screen` existente; não foram criadas rotas simuladas.
- Cards de classificação selecionam Pilotos ou Construtores na tela Campeonato; botão inferior Campeonato volta a iniciar na aba Pilotos.

## Preservação
- Card Próxima Corrida e seus callbacks não foram alterados.
- Barra inferior HOME/TEAM/CAR/CALENDAR/STANDINGS preservada.
- Sem alterações em cálculos de pontos, resultados de corrida, orçamento, limite de investimento, P&D, mercado, contratos ou saves.

## Testes realizados
- Auditoria de Home V714: 20/20 verificações estruturais aprovadas.
- Contrato de release: 76/76 verificações estruturais aprovadas.
- Kotlin PSI: `MainActivity.kt` e `CareerPreferences.kt` sem erros sintáticos.

## Limitações
- PSI Kotlin passou para `MainActivity.kt` e `CareerPreferences.kt`.
- Contrato estrutural V714 executado após a atualização de metadados.
- Gradle e Android SDK não estão instalados neste ambiente; build APK e suíte Android JUnit devem ser concluídos no GitHub Actions.
