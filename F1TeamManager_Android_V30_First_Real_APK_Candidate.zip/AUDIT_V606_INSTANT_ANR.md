# Auditoria V606 — ANR depois da simulação instantânea

## Evidência
A V605 já movia a simulação Q1/Q2/corrida para `Dispatchers.Default`, mas voltava para a thread principal antes de persistir o resultado, calcular o bônus de qualificação e chamar `finalizeCompletedRace()`. Essa finalização executa várias etapas idempotentes de finanças, classificação, evolução, notícias, premiações e persistência para a carreira. A captura do usuário mostra o diálogo ANR sobre a tela de resultado, compatível com travamento após o cálculo da corrida.

## Correção
- Mantém `raceWorkInProgress` ativo até completar toda a cadeia pós-simulação.
- Move persistência do resultado pendente, cálculo/aplicação do bônus e finalização journalizada para `Dispatchers.Default`.
- Mantém a ordem crítica: primeiro salva o resultado completo; só depois aplica bônus e liquida a carreira.
- Falhas mantêm o resultado disponível para recuperação e não iniciam uma segunda simulação.
- Não altera regras esportivas nem a fórmula de evolução dos pilotos.

## Verificações estáticas
- [OK] Versão 606
- [OK] Pós-simulação em Dispatchers.Default
- [OK] Persistência antes do bônus
- [OK] Proteção permanece até finally
- [OK] Journal existente preservado
- [OK] Validação de resultado permanece no serviço


## Limites
Build Android, JUnit e teste em dispositivo não foram executados neste ambiente. A captura não inclui um ANR trace; portanto, a localização do gargalo é uma hipótese forte baseada na ordem do código e no sintoma de travamento sobre a tela de resultado, não uma medição de profiler. A V606 precisa ser compilada e testada no dispositivo; se ainda houver ANR, coletar o ANR trace/logcat para localizar o próximo gargalo.
