# Changelog V374 — Persistência atômica dos efeitos de carreira

- A evolução dos pilotos agora grava atributos, fases, bancos fracionários, progresso e marcador idempotente em um único `SharedPreferences.commit()`.
- A finalização é interrompida se essa gravação não for confirmada, impedindo que o diário marque a evolução como concluída após falha de persistência.
- O pagamento de salários por GP e a migração do legado agora verificam o retorno de `commit()` e falham explicitamente se o armazenamento não confirmar.
- O bônus de qualificação e seu marcador idempotente agora também exigem confirmação do mesmo commit.
- Atualizada a versão Android para 0.374.0.
- Nenhuma alteração de interface, botões ou assets externos.
