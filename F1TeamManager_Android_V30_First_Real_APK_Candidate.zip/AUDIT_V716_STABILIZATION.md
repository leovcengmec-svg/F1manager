# Auditoria V716 — Performance e patrocínios

## Alterações verificadas

1. `HistoricalDatabase` mantém `archiveLinesCache`, `recordBookCache` e `hallRankingCache`.
2. As caches são invalidadas após mutações de arquivo concluídas, instalação/limpeza de bundles e exclusão do histórico.
3. `recordBookSnapshot()` produz listas agregadas e mapas indexados por equipe e temporada.
4. Team Overview consome os mapas indexados em vez de percorrer o arquivo histórico completo em cada troca.
5. O preparo dos 40 snapshots de equipes ocorre em `Dispatchers.Default` e a leitura do arquivo ocorre em `Dispatchers.IO`. O `selectedTeamId` não integra a chave de preparação, permitindo reutilizar o resultado ao navegar entre equipes.
6. História e Hall da Fama carregam o snapshot fora da thread visual; o ranking do Hall usa `Dispatchers.Default` e cache por categoria/métrica. Recordes também usa o snapshot compartilhado.
7. Propostas do Centro Comercial mantêm uma proposta de categoria-base e sorteiam as outras duas de forma independente, sem aleatoriedade nova ao reabrir a mesma situação da carreira.

## Limitações da validação

- A auditoria confirma a integração estrutural e os testes direcionados. Não equivale a uma medição de FPS/ANR num aparelho físico.
- O ambiente desta sessão não contém Gradle/Android SDK; o build Android integral e a suíte JUnit devem ser executados pelo workflow do GitHub Actions.
- Recomenda-se testar a troca repetida entre as 40 equipes numa carreira longa e reabrir História, Hall da Fama e Recordes após vários GPs.

## Complementos de desempenho e navegação

8. `hallRanking()` calcula os agregados de todas as métricas de pilotos e construtores em duas passagens do arquivo histórico; as classificações por métrica ficam em cache e são limpas na próxima mutação.
9. `TeamOverviewSnapshotMemoryCache` retém os 40 snapshots da equipe entre saídas e retornos à tela. A chave considera temporada, semana, estado da carreira, finanças, instalações, investimentos técnicos, carro da próxima temporada e handoffs do Team Principal.
10. A preparação inicial não bloqueia a navegação: a tela mostra navegação provisória por equipe enquanto os dados avançados são calculados em `Dispatchers.Default`.
11. `RecordsScreen` calcula recordes de carreira, marcos recentes, recordes de temporada e cartões por circuito fora da thread visual. História e Hall da Fama reutilizam o snapshot/cache do arquivo.
12. O menu de patrocinadores no nível 2 garante uma proposta BASIC e sorteia independentemente as outras duas; a mesma situação de carreira gera as mesmas propostas ao reabrir a tela.
