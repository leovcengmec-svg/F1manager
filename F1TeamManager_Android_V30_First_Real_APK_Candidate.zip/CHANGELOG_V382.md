# V382 — Botão de simulação instantânea na Home

- O card Próxima Corrida agora apresenta dois botões de mesma largura: “ABRIR FIM DE SEMANA” e “PULAR FIM DE SEMANA”.
- O segundo botão chama `simulateWeekendInstantlyForCareer()`, integrando a simulação instantânea à carreira.
- Os textos foram reduzidos e centralizados para caber em telas móveis.
- A simulação instantânea fica desabilitada fora da semana do GP, durante uma corrida interativa em andamento e após o GP já ter sido finalizado.
- O fluxo normal de abrir/retomar o fim de semana foi preservado.
- Nenhuma mudança intencional em assets, histórico anterior ou outros elementos de layout.
