# V325 — Compactação dos controles da corrida

- Removido o rótulo “VELOCIDADE” da linha de controles.
- O botão PAUSAR/INICIAR foi movido para o lugar do rótulo e compactado para 58 × 21 dp, mantendo a mesma altura visual dos controles de velocidade.
- O texto do botão permanece em uma única linha e o controle fica desabilitado antes de a corrida começar, para não contornar o fluxo normal de início.
- Corrigido o cabeçalho “EQUIPE” da classificação: coluna ampliada para 37 dp, fonte reduzida para 6 sp e quebra de linha desativada.
- Mantidos os controles 0,7x, 1x, 1,7x e 3x e a lógica de corrida existente.
- Base: V324. Nome oficial do ZIP preservado.

Validação: inspeção estática do código e integridade do ZIP. Compilação Android e teste em dispositivo não executados.
