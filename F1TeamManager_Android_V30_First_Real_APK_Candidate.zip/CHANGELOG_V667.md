# V667 — ajustes na tela Minha Carreira e confiança da diretoria

- Retrato do chefe de equipe com opacidade e transição de fundo ajustadas para permanecer claramente visível no cartão de carreira.
- Removido o selo amarelo de quantidade de objetivos que aparecia cortado no cabeçalho.
- Cartões de contrato e metas cumpridas ampliados para exibir os textos completos em telas compactas e normais; altura do cartão de objetivos ajustada em conjunto.
- Cartão clicável de conquistas simplificado: removido o subtítulo que era truncado; título, contador e indicador de abertura permanecem totalmente visíveis.
- Apoio inicial da diretoria alterado de 75 para 50 pontos no primeiro contrato e na assinatura com uma nova equipe.
- Troca para uma nova equipe reinicia o apoio em 50 pontos, independentemente da confiança que existia na equipe anterior; renovação com a mesma equipe preserva a confiança.
- Saves V666 ainda sem temporada iniciada migram do valor padrão antigo de 75 para 50; carreiras já iniciadas preservam o histórico salvo.
- A tela passa a exibir a projeção dinâmica do apoio, calculada com os mesmos resultados esportivos, objetivos, finanças e fatores de risco usados na avaliação de demissão.
- Adicionados testes de variação da projeção de apoio e migração de saves da V666.
