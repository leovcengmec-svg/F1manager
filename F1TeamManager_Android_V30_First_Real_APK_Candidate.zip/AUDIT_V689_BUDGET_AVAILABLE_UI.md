# Auditoria V689 — painel de orçamento

## Mudança
Restaurada a linha “Invest. Disponível” no card Orçamento da visão de equipe. Removida do mesmo card a linha “Carro Seguinte”, pois a interface já possui o painel dedicado “Investimento do Próximo Carro”.

## Conferência do cálculo
- Equipe do jogador: `SeasonInvestmentPolicy.remainingAnnualTechnicalEnvelope(annualCap, totalSpent, nextSeasonInvestment)` calcula o saldo após P&D/instalações e pagamentos comprometidos no carro seguinte.
- Equipes da IA: `AITeamFinancialEngine.remainingTechnicalBudget(teamId, season)` utiliza o mesmo envelope e desconta o investimento no próximo carro.
- A UI exibe `selected.availableTechnical` como “Invest. Disponível”, sem recalcular ou duplicar o abatimento.
- O painel “Investimento do Próximo Carro” continua recebendo `selected.nextSeasonInvestment` e não foi alterado.

## Itens verificados estaticamente
1. VersionCode 689 e VersionName 0.689.0.
2. Card Orçamento contém Caixa Atual, Receitas, Despesas, Invest. Anual e Invest. Disponível.
3. Card Orçamento não contém a linha Carro Seguinte.
4. Painel dedicado de investimento do próximo carro permanece na tela.
5. Jogador e IA utilizam saldo anual consolidado que considera o carro seguinte.

A compilação APK deve ser validada pelo GitHub Actions.
