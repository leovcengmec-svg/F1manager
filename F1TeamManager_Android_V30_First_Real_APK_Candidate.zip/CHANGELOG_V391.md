# V391

- Alterado somente o rótulo do terceiro indicador do card da qualificação de `STATUS DA SIMULAÇÃO` para `SITUAÇÃO`.
- Mantida a lógica e o valor dinâmico do indicador (PRONTA, SIMULANDO ou CONCLUÍDA).
- Nenhuma alteração de layout adicional, motor de simulação ou assets.
