# V538 — Integração de áudio externo

- Simplificado catálogo para os seis áudios solicitados.
- Roteamento central por tela: menu, interface, qualificação/corrida, resultados, vitória brasileira e fim de temporada.
- Vitória brasileira identificada pelo país do piloto vencedor na classificação final; usa faixa específica em vez da faixa genérica de resultados.
- Mantido fallback OGG Vorbis -> MP3 e funcionamento silencioso quando o arquivo não existe.
- Nenhum arquivo de áudio vazio foi criado; os arquivos reais precisam ser instalados pelo usuário na pasta externa documentada.
