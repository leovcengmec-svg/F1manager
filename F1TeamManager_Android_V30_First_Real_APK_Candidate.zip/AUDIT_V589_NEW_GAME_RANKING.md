# Auditoria V589 — ranking de seleção em Novo Jogo

## Falha observada
Ao cancelar a seleção sem confirmar uma equipe e entrar em Novo Jogo novamente, o ranking podia ser repetido. `prepareNewCareerSelection()` reaproveitava `pendingCareerSeed` quando já existia uma seleção provisória. Além disso, os `remember` de `TeamSelect` não incluíam uma chave de geração nova.

## Alterações
- Toda escolha de modo para iniciar Novo Jogo gera e persiste uma nova semente provisória, distinta da semente provisória/abertura anterior.
- A tela de seleção recebe `rankingSeed` e usa essa chave para recalcular a lista das três equipes mais fracas, a ordenação por desempenho e os atributos exibidos nos cards.
- `InitialTeamProfile` aceita uma semente explícita para a prévia. Assim, abrir e cancelar Novo Jogo não altera o ranking de força de uma carreira já salva no mesmo processo.
- Ao confirmar a equipe, `startNewCareer()` utiliza a mesma semente `pendingCareerSeed` usada pela prévia e só então configura o perfil global da nova carreira.
- Adicionado teste de regressão para semente inválida/repetida e para a mudança das três equipes mais fracas com sementes diferentes, preservando a classificação da carreira ativa.

## Verificações executadas
- Compilação Kotlin isolada do `InitialTeamProfile.kt` com stubs das dependências externas: passou.
- 8 verificações de semente/ranking no teste executável isolado: passaram.
- Asserções estáticas de integração dos três modos, chaves `remember`, uso da semente nos cards e isolamento do ranking da carreira existente: passaram.
- Integridade do ZIP: verificar após empacotamento.

## Limites conhecidos
Não havia `gradlew` nem instalação de Gradle identificável neste ambiente, então não foi possível executar o build Android nem a suíte oficial JUnit/Gradle. Não declarar APK compilado ou teste ponta a ponta confirmado.
