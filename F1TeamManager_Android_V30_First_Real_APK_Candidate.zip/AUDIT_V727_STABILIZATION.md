# Auditoria V727 — correção de compilação Kotlin

## Falha recebida

O GitHub Actions falhou em `:app:compileDebugKotlin` com erros em `CareerPreferences.kt`:

- Linha 3280: `Unresolved reference 'toMutableMap'`.
- Linha 3347: erros de inferência de `K`, `V` e `T`.
- Linha 3347: referências `key` e `value` não resolvidas.

## Causa raiz

O código fazia `mapNotNull { ... }` sobre a string serializada e chamava `toMutableMap()` diretamente no `List<Pair<Int, String>>`. A extensão `toMutableMap()` aplica-se ao mapa, não à lista de pares. Os erros em `key`/`value` eram consequência da expressão inválida não produzir um mapa tipado.

## Correção aplicada

- Criado `DriverEvolutionPhaseCodec` para decodificar `driverId:phase;...` em `MutableMap<Int, String>` por meio de `.toMap().toMutableMap()`.
- O tipo de retorno explícito torna o contrato de chave/valor inequívoco para o compilador Kotlin.
- `readDriverEvolutionPhases()`, `saveDriverEvolutionPhases()` e `applyAgeCycleTransitionsForSeason()` compartilham o codec.
- A serialização preserva ordenação numérica e o formato persistido legado.

## Testes adicionados

`DriverEvolutionPhaseCodecV727Test.kt` cobre:

1. Decodificação de registros válidos e descarte de tokens malformados.
2. Ordenação numérica estável na escrita.
3. Round-trip com valores de fase que contêm dois-pontos.

Foi executado um probe com o compilador Kotlin instalado no ambiente, cobrindo a expressão tipada `MutableMap<Int, String>` e a serialização ordenada; resultado aprovado.

## Escopo preservado

A V727 é uma correção de compilação sobre a V726. Não modifica as metas de classificação/corrida baseadas exclusivamente na força do carro, nem os pesos do índice esportivo, nem a lógica de regressão/evolução ou outros sistemas do jogo.

## Limite da validação

Este ambiente não tem Gradle, Gradle Wrapper ou Android SDK disponíveis. Portanto, não é possível afirmar que `:app:compileDebugKotlin`, `testDebugUnitTest` ou `assembleDebug` foram executados localmente. O build completo deve ser confirmado no workflow Android do GitHub Actions.
