# V582

- Corrigido o filtro do evento de falha de P&D na Home: a mensagem de falha começa com `Equipe:` enquanto o filtro anterior só aceitava `Equipe `.
- O popup e o contador/botão de P&D da Home exibem somente resultados de P&D da equipe do jogador.
- Adicionado teste de regressão para sucesso, falha e exclusão de mensagens de outras equipes.
- versionCode 582 / versionName 0.582.0.
- Validação estática e integridade do ZIP; build Android ainda pendente.
