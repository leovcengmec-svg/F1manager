import com.f1teammanager.core.manager.*
import com.f1teammanager.core.season.WorldDatabase

fun main() {
    val engine = DriverMarketEngine(20261003)
    var s = engine.initialState(2026)
    val driver = WorldDatabase.allDrivers.first { it.id == 45 }
    // Force a weak first offer that normally produces a counter by using a modest salary.
    val (s1, first) = engine.makeOffer(s, driver.id, 2, 2, 1_000_000L, DriverTeamRole.EQUAL, 2026, currentWeek = 30, replaceDriverId = 3)
    check(first.round == 1)
    if (first.status == NegotiationStatus.COUNTER) {
        check(first.salary > 1_000_000L)
        check(first.years in 1..5)
        check(first.role in DriverTeamRole.values())
        val accepted = engine.acceptCounterOffer(s1, first, 2026, 30)
        check(accepted.scheduled.any { it.driverId == driver.id && it.startSeason == 2027 })
    }

    val salaryState = TeamManagerState(
        season = 2026, round = 1, playerTeamId = 1,
        car = TeamCarState(75,75,75,75),
        finance = TeamFinanceState(75_000_000L),
        driverMarket = engine.initialState(2026)
    )
    val charged = FinanceEngine().applyAnnualDriverSalaries(salaryState, 2026)
    val expected = salaryState.driverMarket.contracts.filter { it.teamId == 1 && it.activeIn(2026) }.sumOf { it.salary }
    check(charged.finance.budget == 75_000_000L - expected)
    check(charged.finance.transactions.last().contains("Salários anuais"))

    println("Stage4AuditTest: PASS")
}
