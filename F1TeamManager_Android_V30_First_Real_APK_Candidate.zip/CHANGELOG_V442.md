# V442 — recuperação idempotente da finalização de GP

- Avançada a versão Android para `0.442.0` (versionCode 442).
- Adicionado um teste de execução Kotlin para a janela crítica em que um efeito financeiro já foi aplicado, mas o marcador durável ainda não foi gravado.
- O teste simula interrupção, recriação do journal, retomada das etapas em ordem, conclusão e repetição após conclusão.
- O teste exige uma chave idempotente no efeito, evitando contabilização duplicada ao repetir uma etapa após a interrupção.
- Preservados o nome oficial do ZIP, o histórico, os assets e o layout.

## Limites
A auditoria Kotlin do journal e a cadeia de 60 GPs podem ser executadas com `kotlinc` no subconjunto puro Kotlin. A compilação Android/Compose e o conjunto oficial JUnit/Gradle não foram executados neste ambiente.
