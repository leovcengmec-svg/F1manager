# F1 Team Manager V30 — V660

## Mercado de pilotos: decisões com projeção do próximo carro

- O mercado passou a receber a força física projetada do carro de cada equipe para a próxima temporada.
- A projeção usa a garagem física atual, investimento comprometido para o próximo carro, foco e conhecimento técnico do jogador, piso de continuidade aplicado às equipes de IA e regulamento técnico do ano seguinte.
- A comparação esportiva da transferência agora considera o projeto da equipe atual contra o projeto da equipe de destino no ano de início do contrato.
- Quedas grandes de Overall futuro recebem penalidades progressivas; quedas extremas limitam a atratividade de propostas comuns para pilotos de elite.
- O bônus salarial foi reduzido no cálculo que utiliza a projeção futura. Salário extraordinário ainda pode influenciar uma decisão, mas não apaga automaticamente um rebaixamento esportivo severo.
- Propostas pendentes são reavaliadas quando vencem, usando a projeção mais recente e comparando ofertas concorrentes pelo interesse atualizado, em vez de confiar somente na pontuação salva quando a oferta foi criada.
- A IA também usa o projeto futuro para avaliar renovações, candidatos e preenchimento das vagas da temporada seguinte.
- Chamadas antigas sem mapa de projeção preservam a pontuação anterior para compatibilidade com fluxos e testes legados.

## Testes de regressão

- Adicionado teste para impedir que piloto de elite aceite proposta salarial comum ao abandonar um carro projetado de ponta por um projeto muito inferior.
- Adicionado teste para garantir que uma pontuação antiga e artificialmente alta seja recalculada antes da resposta da proposta.

## Versionamento

- Identidade pública preservada: **F1 Team Manager V30**.
- `versionCode = 660`.
- `versionName = "0.660.0"`.
- Nome padrão do ZIP preservado.
