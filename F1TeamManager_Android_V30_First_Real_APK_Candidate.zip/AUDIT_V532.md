# Auditoria V532

Causa identificada: a UI de qualificação procurava pilotos em `WorldDatabase.drivers`, que exclui os pilotos adicionais/reservas em `allDrivers`; por isso IDs 81+ eram exibidos como “Piloto N”. Além disso, a UI inferia equipe por `DriverDefinition.teamId` estático, ignorando transferências persistidas em `DriverMarketState.contracts`. Isso mostrava escudo/carro de equipe errada após trocas. Corrigida a resolução para catálogo completo e contratos ativos por temporada. Corrigida também a apuração da melhor posição de quali usada nos bônus financeiros, que tinha a mesma dependência de equipe estática.

Validação: ZIP íntegro após empacotamento. Compilação Gradle não executada neste ambiente.
