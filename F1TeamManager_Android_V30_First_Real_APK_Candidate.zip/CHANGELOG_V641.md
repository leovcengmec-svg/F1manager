# V641 (0.641.0) — Hierarquia de instalações e patrocínios da IA alinhados ao jogador

## Prioridades da IA
- Centro Comercial nível 3 é a meta comercial mínima e lidera a fila enquanto o próximo upgrade puder respeitar a reserva operacional, o caixa real e o teto técnico anual compartilhado.
- Scouting é a instalação de menor prioridade. A ordem estratégica é: Centro de P&D, Fábrica, Centro Comercial (além da meta mínima quando o fluxo justificar), Túnel de Vento, Simulador, Desenvolvimento de Pilotos e Scouting. A exceção é o Centro Comercial abaixo do nível 3 quando seu upgrade for financeiramente viável.
- A IA não gasta dinheiro necessário para a reserva de operação só para cumprir a meta comercial; se não puder financiar o Centro Comercial com segurança, ainda pode escolher um upgrade alternativo viável.

## Paridade de patrocínio entre jogador e IA
- Contratação inicial e renovação automática da IA passam a usar o mesmo gerador de três ofertas por slot, categoria liberada pelo nível do Centro Comercial, lista de marcas disponíveis, slot Master, faixas de pagamento, multiplicadores e alvos esportivos usados para o jogador.
- A IA escolhe automaticamente a oferta de maior valor esperado: pagamento de entrada + pagamentos garantidos ao longo da duração em GPs + estimativa conservadora dos bônus de qualificação/corrida. O jogador mantém a escolha manual entre as mesmas três ofertas.
- A UI do jogador passa a informar ao gerador a lista real de patrocinadores ativos de outros slots, impedindo que uma marca ativa da própria equipe reapareça como nova oferta devido a um estado sintético interno.
- A contabilização de pagamentos iniciais e de GP continua compartilhada com `FinanceEngine`; nenhuma regra de preço ou faixa monetária exclusiva para a IA foi criada.

## Compatibilidade e testes
- Preservados snapshots, chaves de idempotência, catálogo de 180 marcas, slots permanentes e contratos existentes.
- Testes específicos cobrem o nível comercial mínimo, Scouting no fim da hierarquia, a seleção da IA entre as mesmas três ofertas e o uso da liquidação financeira comum.
- A compilação Android completa continua dependente de um ambiente Gradle/Android disponível; a auditoria e os testes de núcleo são executados separadamente.
