# CHANGELOG V730

## Central de Notícias
- Ordem: 1 Mercado, 2 Evolução de Pilotos, 3 Evolução de Equipes, 4 Eventos de Pilotos, 5 Eventos Anuais.
- Eventos de Pilotos permanece disponível; não foram renomeados nem reordenados os identificadores persistidos do enum.

## Patrocínios
- Novo sorteio de marcas, categoria, condições e duração a cada nova negociação.
- O sorteio usa o catálogo existente: Master no slot 1; pool secundário nos slots 2–5.
- O mesmo patrocinador não pode reaparecer imediatamente no mesmo slot após encerrar o contrato. Marcas ativas nos outros slots continuam excluídas.
- Não foi criado histórico de patrocínios nem uma tabela de marcas utilizadas. O contrato encerrado fica somente como registro inativo do próprio slot e é sobrescrito na contratação seguinte.
- Três propostas distintas por negociação e estáveis durante a mesma negociação.
- Níveis 0–2: 3–10 GPs. Níveis 3–10: 8–14 GPs, inclusive, com todos os inteiros elegíveis.
- Jogador e IA compartilham as regras de sorteio e catálogo; a escolha final continua manual para o jogador e automática para a IA.
- Liquidação do último GP e notificação existente preservadas.

## Preservações
- Catálogo, seis categorias, listas Master/secundárias, preços-base, bônus, cinco slots e desbloqueio pelo Centro Comercial.
- Contratos assinados não são recalculados nem encurtados.
