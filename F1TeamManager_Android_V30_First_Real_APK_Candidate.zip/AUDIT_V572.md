# V572 — Auditoria de persistência do catálogo

## Problema
`CustomWorldCatalog.save()` usava `SharedPreferences.apply()`, que não expõe resultado da gravação e permitia a interface manter alterações em memória mesmo se elas não fossem persistidas.

## Correção
A gravação dos três conjuntos (pilotos, equipes e bandeiras) usa uma única operação `commit()`. Se falhar, o catálogo é recarregado do último estado persistido e uma exceção clara é lançada ao chamador.

## Compatibilidade e risco
As mesmas chaves (`pilots`, `teams`, `countryFlags`) e o formato JSON são mantidos. Não há migração destrutiva e nenhum asset externo é movido ou removido.

## Testes
Foi adicionado teste de contrato. JUnit e compilação Android não foram executados neste ambiente.
