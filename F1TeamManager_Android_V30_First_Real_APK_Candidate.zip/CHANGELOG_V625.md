# V625 (0.625.0)

- Corrigida falha de compilação Compose removendo o import inacessível `androidx.compose.foundation.layout.weight` de `TeamPrincipalCareerScreen.kt`.
- Mantidas as chamadas `Modifier.weight(...)` dentro dos escopos apropriados.
- Sem mudanças de gameplay ou assets.
