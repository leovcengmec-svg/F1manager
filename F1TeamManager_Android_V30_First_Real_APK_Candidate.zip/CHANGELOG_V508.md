# V508 — Consolidação do caminho financeiro jogador/IA

- O ajuste financeiro de eventos anuais do jogador agora chama o mesmo método canônico utilizado pela IA, garantindo que orçamento final, delta e extrato sejam coerentes.
- Gastos discricionários da IA deixam de aceitar débito parcial: usam o mesmo bloqueio por saldo insuficiente disponível no motor financeiro compartilhado, evitando registrar investimento incompleto.
- Acrescentados testes para débito completo quando há saldo e bloqueio sem alteração do saldo quando o caixa é insuficiente.
- Mantidos os caminhos compartilhados de corridas, qualificação, patrocínios, manutenção semanal, receita comercial, premiação de construtores, salários e taxas de contratação.
- Validação estática e integridade do ZIP realizadas. A compilação Android e a execução da suíte JUnit dependem de ambiente Gradle disponível e não foram declaradas como aprovadas.
