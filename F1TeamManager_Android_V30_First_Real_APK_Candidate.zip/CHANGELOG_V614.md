# V614 — Correção do card de instalação concluída na HOME

- Separado o evento de conclusão do evento de início de melhoria, com título explícito e identificação da equipe do jogador.
- O card da HOME seleciona somente conclusões não lidas pertencentes à equipe do jogador; notificações de upgrades da IA não são usadas no card exclusivo.
- Corrigida a exclusão da instalação Desenvolvimento de Pilotos: upgrades dessa instalação agora também podem gerar o card de instalação concluída.
- Adicionada recuperação idempotente para saves legados em que a melhoria alcançou o nível-alvo mas falta o aviso específico de conclusão. Um upgrade ainda ativo não é tratado como concluído.
- Mantidos assets existentes, histórico, lógica financeira, ritmo do carro/piloto e motores de simulação.
- Criados testes direcionados de seleção e recuperação de notificações.
- Versionamento: `versionCode = 614`, `versionName = 0.614.0`.
