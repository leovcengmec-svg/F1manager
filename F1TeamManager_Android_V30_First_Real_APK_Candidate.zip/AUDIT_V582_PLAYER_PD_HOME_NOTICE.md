# Auditoria V582 — Falha de P&D do jogador na Home

## Correção
- A falha do P&D cria uma notificação cujo texto começa com `NomeDaEquipe:`; o popup da Home filtrava apenas textos que começassem com `NomeDaEquipe `, com espaço. Isso impedia que o evento de falha fosse exibido.
- Criado `isPlayerResearchNotice`, que aceita os dois formatos (`Equipe ` para sucesso e `Equipe:` para falha).
- O popup de evento e o botão/contador de P&D na Home agora aplicam o mesmo filtro pelo nome da equipe do jogador. Eventos de P&D de outras equipes não contam nem aparecem como evento do jogador.

## Verificações estáticas
- [x] Fonte do popup usa o helper de correspondência da equipe do jogador.
- [x] Contador do botão de P&D filtra pela equipe do jogador.
- [x] Teste unitário adicionado para os dois formatos e para exclusão de outras equipes.
- [x] `versionCode = 582` e `versionName = 0.582.0`.
- [ ] Testes Kotlin/Gradle e compilação Android: não executados neste ambiente.
- [ ] Verificação visual no dispositivo: pendente.
