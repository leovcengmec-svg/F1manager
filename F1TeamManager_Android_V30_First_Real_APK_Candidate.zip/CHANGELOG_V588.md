# V588 — Etapa 1: base dinâmica e cadastro personalizado

- Separada a área de cadastros em seções de Equipes, Pilotos e Bandeiras.
- Classes e tipos de evolução selecionáveis por listas oficiais do jogo.
- Cadastro e edição de pilotos personalizados com país, classe, evolução, sete atributos e nome do asset.
- Atributos iniciais derivados do perfil-base da classe, sem forçar sete atributos em 70.
- Cadastro e edição de equipes personalizadas por seleção de pilotos livres já existentes; não cria pilotos automaticamente ao cadastrar equipe.
- Inclusão de ação para limpar uma vaga de piloto no formulário; a validação impede salvar escalação incompleta.
- Persistência do nome do asset dos pilotos no catálogo local, mantendo compatibilidade com registros antigos (asset vazio por padrão).
- Salvamento com rollback em memória nas novas operações de equipe se a persistência falhar.

## Limitações conhecidas desta etapa

- A edição dos 40 registros oficiais originais (equipes e pilotos) ainda não foi implementada como camada de sobrescrita; a edição desta etapa cobre os registros personalizados. Isso requer uma camada persistente de overrides integrada ao `WorldDatabase` e às carreiras para preservar os IDs históricos.
- A validação Android integral não foi executada neste ambiente. Esta atualização não deve ser considerada compilada até o workflow GitHub Actions concluir com sucesso.

## Fechamento integrado da Etapa 1 — edição completa da base (V588)
- A tela de Equipes lista também as 40 equipes oficiais e permite editar nome, país, classe inicial, nome do asset e os dois pilotos por IDs.
- A tela de Pilotos lista os pilotos oficiais da base (IDs históricos preservados) e permite editar nome, país, classe, evolução, sete atributos e nome do asset.
- Alterações oficiais são armazenadas como overrides persistentes separados, sem reescrever a definição original nem reutilizar IDs.
- O WorldDatabase aplica os overrides na leitura da base e recalcula o vínculo ativo piloto-equipe a partir da escalação atual, deixando o piloto removido da equipe disponível no mercado.
- Equipes personalizadas passam a guardar a classe inicial (Fraco/Médio/Forte) em vez de fixar silenciosamente a classe média.
- Seleção de pilotos usa IDs e só oferece agentes livres mais os dois pilotos já vinculados à equipe em edição; isso evita roubar piloto de outra equipe sem transferência explícita.
- O nome oficial do ZIP permanece F1TeamManager_Android_V30_First_Real_APK_Candidate.zip; versão interna 0.588.0.
- Limitação de validação: não há Gradle Wrapper neste pacote e a compilação Android não foi executada neste ambiente. Confirmar o build no GitHub Actions antes de considerar a etapa aprovada.
