# V588 — Painel Team Principal isolado por modo

- O painel “Minha Carreira” é exibido apenas quando o modo da carreira ativa é `TEAM_PRINCIPAL`.
- O modo ativo é persistido explicitamente: `FREE`, `HARD` ou `TEAM_PRINCIPAL`.
- Ao iniciar uma carreira nova, estado e handoffs antigos de Team Principal são removidos; após a seleção, o modo escolhido é gravado.
- A leitura de saves antigos que possuem estado de Team Principal, mas não possuem a chave `activeGameMode`, migra o modo para manter compatibilidade.
- Adicionado teste de regressão para garantir que os modos Livre e Difícil não exibam a tela, mesmo com um estado residual, e que a tela não abra sem um estado válido.

## Validação
- Verificações estáticas das condições de persistência e renderização realizadas.
- Predicado de modo executado em teste Kotlin isolado (6 cenários).
- ZIP verificado. Build Android e suite Gradle/JUnit não executadas: não há `gradlew` no pacote e Gradle não está instalado neste ambiente.
