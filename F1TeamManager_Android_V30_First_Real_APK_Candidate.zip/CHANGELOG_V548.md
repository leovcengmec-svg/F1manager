# V548 — Remoção da regressão anual genérica do carro

## Decisão
Removida da raiz a regra histórica de continuidade de 70% (fórmula `50 + (valor - 50) * 0.70`). A construção do próximo carro, já existente no jogo, passa a ser a única autoridade para a transição entre temporadas.

## Código alterado
- Jogador: `CarDevelopmentEngine.startNextSeason` preserva os valores reais dos componentes da garagem e aplica conhecimento técnico, investimento/foco e bônus de regulamento.
- Confiabilidade: removida a compressão anual em direção a 50, preservando a base física/geral e o bônus de investimento.
- Dois carros físicos do jogador: ambos continuam individualizados; cada carro conserva seus próprios valores e confiabilidade dos componentes.
- IA: removida a mesma regressão do resumo legado e da garagem física, mantendo o encadeamento de temporadas, investimento e regras de regulamento.
- Marcador de auditoria atualizado para identificar a política V548.
- Teste de construção anual atualizado para garantir que os valores-base não sofrem regressão genérica.
- Documentação histórica V46/V47 preservada e marcada como comportamento superado a partir da V548.

## Preservado
- Bônus de conhecimento técnico, investimento e foco.
- Aplicação do regulamento anual.
- Penalidade financeira de fim de temporada existente.
- Limites dos atributos e individualidade dos dois carros físicos.
- Histórico de versões e assets externos.

## Validação
- Pesquisa global no código confirma ausência de `ANNUAL_CONTINUITY_FACTOR` e `ANNUAL_CAR_CONTINUITY`.
- ZIP e integridade estrutural serão verificados após empacotamento.
- Compilação Android e suíte de testes não executadas: o pacote não contém Gradle Wrapper e não há Gradle instalado no ambiente.
