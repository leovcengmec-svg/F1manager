# Auditoria V522

- Confirmados seis recursos WebP distintos e seis mapeamentos enum -> drawable.
- A seção Nova Pesquisa usa imagem de preenchimento total com sobreposição escura.
- Os cards de designs concluídos e de fabricação passam a selecionar a imagem pelo componente.
- ZIP deve ser verificado com testzip; compilação Android/JUnit não foi executada neste ambiente.
