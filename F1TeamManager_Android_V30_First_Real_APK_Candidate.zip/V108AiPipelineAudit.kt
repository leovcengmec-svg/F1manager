import com.f1teammanager.core.manager.AITeamDevelopmentEngine
import com.f1teammanager.core.manager.CarComponent
import com.f1teammanager.core.manager.GarageCarId
import com.f1teammanager.core.season.WorldDatabase

fun main() {
    val engine = AITeamDevelopmentEngine(20261005 + 2026)
    val team = WorldDatabase.teams.first { it.name == "Red Bull Racing" }
    val state = engine.simulateFinancial(team, 12, 2026)
    check(state.events.isNotEmpty()) { "IA não gerou eventos de desenvolvimento" }
    val events = state.events
    val designs = events.filter { it.type == AITeamDevelopmentEngine.DevelopmentEvent.Type.DESIGN_COMPLETED }
    val factories = events.filter { it.type == AITeamDevelopmentEngine.DevelopmentEvent.Type.FACTORY_COMPLETED }
    val installs = events.filter { it.type == AITeamDevelopmentEngine.DevelopmentEvent.Type.PIECE_INSTALLED }
    check(designs.isNotEmpty() && factories.isNotEmpty() && installs.isNotEmpty()) { "Cadeia incompleta" }
    factories.forEach { factory ->
        check(designs.any { it.component == factory.component && it.version == factory.version && it.week <= factory.week })
    }
    installs.forEach { install ->
        check(factories.any { it.component == install.component && it.version == install.version && it.week <= install.week })
    }
    installs.forEach { install ->
        check(install.target == GarageCarId.CAR_1 || install.target == GarageCarId.CAR_2)
    }
    val validEvolution = installs.filter { (it.afterOverall ?: 0) > (it.beforeOverall ?: 0) }
    check(validEvolution.all { (it.afterOverall ?: 0) > (it.beforeOverall ?: 0) })
    println("V111_AI_PIPELINE_OK designs=${designs.size} factory=${factories.size} installs=${installs.size} validEvolution=${validEvolution.size}")
}
