# Auditoria V702 — estabilização de pilotos

## Implementação
- Filas individuais de desenvolvimento da IA persistidas por equipe no `DriverMarketState`; os programas e o último tick absoluto de calendário são serializados em `CareerPreferences` e restaurados em `loadDriverMarket`.
- IA e jogador usam o mesmo `DriverDevelopmentEngine`, com a mesma tabela de duração/pontos/vagas, potencial individual e limite anual por atributo.
- A fila da IA é avançada pelas semanas reais entre GPs e processada antes da simulação do próximo GP. Todas as vagas disponíveis são preenchidas, e a IA não inicia programa quando os limites anuais já estão consumidos.
- Bônus passivo de crescimento foi removido: `FacilityEngine.driverDevelopmentEfficiency` retorna 1.0 e os dois caminhos de evolução natural passam explicitamente 1.0.
- Contratos iniciais, ofertas, renovações, transferências e fechamento de vagas usam planejamento de 1 a 5 anos, baseado em idade, Overall e potencial.
- Evolução natural por desempenho recebe margem sobre o teto de classe baseada na média da temporada: +1 a partir de 110; +2 a partir de 120; +3 a partir de 130. Potencial individual e Overall 100 continuam absolutos.

## Testes
- Validador de lançamento: 28/28.
- Núcleo Kotlin `core` compilado com Kotlin K2; apenas avisos preexistentes de nulidade/Locale.
- Smoke test executado: fila e conclusão do programa; duração contratual 1–5; limite de Overall 92 para Pro em temporada excepcional; ausência de bônus passivo.
- Testes JUnit adicionados: `AIDriverDevelopmentAndContractsV702Test` e `DriverClassCeilingMarginV702Test`; teste de instalação atualizado para proibir crescimento passivo.

## Não comprovado neste ambiente
- Compilação Android integral e execução da suíte JUnit pelo Gradle/GitHub Actions. O pacote não inclui Gradle Wrapper e este ambiente não tem Android SDK/Gradle configurados. Não declarar APK compilado até o workflow terminar com sucesso.
