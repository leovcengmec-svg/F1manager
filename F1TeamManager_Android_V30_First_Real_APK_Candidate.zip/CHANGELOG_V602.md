# V602 — recuperação de inicialização após catálogo editado

- Corrige a separação entre disponibilidade de registros válidos em runtime e permissão de escrita do catálogo.
- Após reiniciar, registros estruturalmente legíveis (incluindo equipes personalizadas referenciadas pela carreira) são publicados mesmo quando existe alerta semântico no catálogo.
- Os dados brutos persistidos não são regravados automaticamente; o modo de integridade continua bloqueando novas edições até a recuperação/validação.
- IDs duplicados são reduzidos a uma entrada por ID na visão em memória para evitar ambiguidades imediatas, sem alterar o JSON original.
- Adicionado teste de regressão para carregamento a frio.
