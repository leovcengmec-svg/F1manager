# V602 — Regra de nova carreira e proteção do calendário

## Regra do projeto
- Toda atualização funcional deve ser validada em uma carreira recém-criada por Novo Jogo, nunca continuando um save de versão anterior.
- A regra orienta desenvolvimento e homologação; os recursos de save continuam disponíveis e saves existentes não são apagados automaticamente.

## Correções do calendário e da simulação instantânea
- “Pular fim de semana” só pode ser usado na semana exata programada para o GP.
- O botão não avança semanas automaticamente; para avançar, deve-se usar “Pular até a próxima corrida”, que processa as semanas intermediárias.
- A ação instantânea é desabilitada durante uma sessão interativa em andamento, inclusive na qualificação.
- A abertura de fim de semana e a finalização do resultado validam índice de rodada, definição do GP e semana persistida antes de executar a corrida ou aplicar efeitos financeiros, esportivos, de salários, evolução e histórico.
- Avanços semanais são bloqueados caso tentem ultrapassar o próximo GP agendado.
- Sessões ativas são retomadas na tela apropriada, em vez de reinicializadas.

## Performance
- As novas verificações são pequenas validações executadas na entrada de ações, não em cada quadro de renderização.

## Validação
- 12/12 verificações estáticas específicas passaram.
- Auditorias estruturais executadas depois de incluir este changelog.
- Build Android e execução JUnit/dispositivo ainda pendentes; não declarar a atualização homologada até executar o workflow Build Debug APK.
