# V602 — Correção do travamento no encerramento de temporada

## Alterações
- O resumo do fim da temporada é preparado fora da thread principal usando `Dispatchers.IO`.
- O registro de temporada do Team Principal e a marcação do evento são executados no mesmo fluxo de preparação, antes de mostrar o resumo.
- O resultado fica em cache por temporada para evitar reconsultar o histórico em cada recomposição do Compose.
- A tela apresenta estado de carregamento e permite tentar novamente se a preparação falhar, em vez de bloquear a interface.
- Mantém a transição para a avaliação contratual do Team Principal após continuar.

## Validação
- Testes estáticos e auditorias estruturais executados.
- Build Android, JUnit e reprodução em dispositivo ainda pendentes.
