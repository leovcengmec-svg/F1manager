# V390 — Painel compacto de qualificação

- Reorganizado o painel de sessão em três colunas: cronômetro, média do GP e status da simulação, cada uma com valor abaixo do título.
- Removido o cabeçalho redundante de fase/tempo e a linha auxiliar de voltas por piloto para reduzir espaços vazios e altura do card.
- Cabeçalhos da classificação alinhados com as larguras reais das colunas: posição, equipe (escudo/carro), piloto, pneu, tempo e diferença.
- Sem alterações intencionais no motor de qualificação, simulação ou assets.
