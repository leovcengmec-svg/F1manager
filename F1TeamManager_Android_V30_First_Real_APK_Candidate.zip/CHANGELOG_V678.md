# CHANGELOG V678 — Cards padrão de eventos do mercado de pilotos

## Correção

A V677 já tinha a arte e o tratamento visual para `TRANSFERÊNCIA CONFIRMADA`, mas o filtro que selecionava os eventos para o modal padrão da Home não permitia esse título. A transferência era descartada antes de chegar ao componente visual.

- Incluído `TRANSFERÊNCIA CONFIRMADA` no filtro de eventos elegíveis para o modal padrão da Home.
- Incluída a transferência confirmada na prioridade de exibição do modal.
- Incluída no contador de mercado da Home e na lista-resumo de contratos assinados.
- Renovação, contrato assinado e transferência confirmada continuam utilizando o modelo visual padrão existente.
- Negociações, propostas e contrapropostas não passam a gerar popups.

## Versionamento
- `versionCode = 678`
- `versionName = "0.678.0"`
- Nome público: F1 Team Manager V30.
- Nome do ZIP preservado: `F1TeamManager_Android_V30_First_Real_APK_Candidate.zip`.
