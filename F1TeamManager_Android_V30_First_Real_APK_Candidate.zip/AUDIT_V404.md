# Auditoria V404

## Mapeamento da tela anterior
- Arquivo: `app/src/main/java/com/f1teammanager/MainActivity.kt`.
- Entrada: `Screen.RESULT` cria `Result(result!!, team.id, store, ::returnToCalendarAfterRace)` perto da linha 1519.
- Composable principal: `Result(...)`, anteriormente perto da linha 5970.
- Componentes visuais reutilizados: `HeaderBlock`, `DriverPhoto`, `TeamLogo`, `Card`, `Button`, cores `Red`, `Panel`, `Panel2`, `Line`, `Muted`.
- Dados: `RaceResult.classification`, `points`, `safetyCarLaps`, `vscLaps`; equipa do utilizador via `WorldDatabase.teams`; pontos de construtores via `CareerPreferences`.
- Imagens: `ExternalAssets.loadDriverPhoto` e `ExternalAssets.loadTeamLogo`, usados por `DriverPhoto` e `TeamLogo`.
- Ícones no layout antigo eram maioritariamente texto/emoji; a nova versão conserva símbolos compactos para estatísticas e usa os escudos/fotos já existentes.

## Diferenças objetivas em relação à referência
- Hierarquia: introduz o pódio de três pilotos imediatamente abaixo do cabeçalho, ausente no layout atual.
- Dimensões: cards do pódio com largura igual e altura fixa de 174 dp; resumo da equipa e classificação usam a largura total útil.
- Margens: 12 dp horizontais e espaçamento vertical regular de 7 dp, reduzindo os grandes vazios da versão atual.
- Cores: fundo/superfícies existentes preservados; ouro para P1, azul para P2, vermelho para P3, texto branco e secundário cinza.
- Tipografia: título forte; nomes e dados reduzidos de forma consistente para caber sem cortes.
- Alinhamento: posição, escudo, nome, diferença e pontos usam colunas estáveis.
- Rolagem: removida da tela de resultado; a visualização mostra Top 5 para manter o botão final visível. A classificação integral permanece nos dados/histórico.

## Validação
- Inspeção estática do diff e atualização de `versionCode=404`, `versionName=0.404.0`.
- Build Android e teste visual no POCO X7 Pro ainda precisam ser executados no ambiente de compilação do projeto.
