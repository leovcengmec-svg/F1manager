# V699 — estabilização da cadeia de corrida, P&D e CI

- Removida do workflow a verificação de versão fixa V685, que bloqueava toda build atual; substituída por validação de contrato da versão declarada no Gradle e no package_manifest.
- Nome do artefato APK passa a usar dinamicamente o VersionCode atual, sem manter rótulo V697.
- CareerWeekendEngine normaliza os 80 participantes no próprio limite de entrada, independentemente de o chamador ser a tela de grid, simulação instantânea, teste headless ou restauração.
- InstantSimulationService normaliza explicitamente o roster antes de iniciar o fim de semana.
- Penalidade direta de chuva respeita 40–100 para wetSkill, igual às demais entradas de atributo permanente.
- Notificações de conclusão e falha de P&D agora usam a semana efetiva de conclusão do projeto; avanços de várias semanas não deslocam a notícia para a semana final do salto.
- Testes de construção de carro atualizados para que o Overall físico e cada componente nunca esperem valores 0/1 abaixo do piso global 40. A ausência de peça continua sendo representada pela ausência do identificador em installedPieces, não por um atributo permanente abaixo de 40.
- Imagens externas em Pictures/F1Manager/Assets são mantidas como o modo de funcionamento esperado e não são tratadas como falha do pacote.
- Preservados o nome público F1 Team Manager V30 e o nome original do ZIP.

VersionCode 699 / VersionName 0.699.0. Base: V698 / 0.698.0.
