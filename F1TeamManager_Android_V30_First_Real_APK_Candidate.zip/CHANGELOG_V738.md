# CHANGELOG V738 — Mercado, patrocínios e calibração de evolução

## Mercado de pilotos
- Ordenação refeita com comparador explícito: crescente começa no menor valor elegível; decrescente começa no maior.
- Corrigida a causa observada no vídeo: ao trocar a direção/filtro, a LazyColumn preservava a rolagem antiga e o usuário via um trecho intermediário da lista. Agora a lista volta ao primeiro resultado em cada alteração de ordenação, busca ou filtro.
- Critério aplicado somente aos pilotos que já passaram pelos filtros de situação, idade, pesquisa e faixa de Overall.
- Empates permanecem estáveis por nome e ID.
- Direção exibida por extenso (MENOR → MAIOR / MAIOR → MENOR).
- Filtros de idade e faixa de Overall reorganizados em linhas compactas, com texto e valor na mesma linha.
- Reduzida a altura dos cards de pilotos, da fotografia e dos atributos, sem remover informações contratuais essenciais.

## Patrocínios
- Novas propostas limitadas após todos os multiplicadores de categoria, slot Master e Centro Comercial:
  - Valor por GP: máximo €800.000.
  - Bônus de qualificação: máximo €400.000.
  - Bônus de corrida: máximo €400.000.
- Valores abaixo dos tetos são preservados.
- Contratos já assinados não são reprecificados retroativamente.

## Evolução
- Nova calibração da margem adicional de classe:
  - média 85: +1
  - média 90: +2
  - média 95: +3
  - média 100: +4
  - média 105: +5
- Mantido mínimo de cinco GPs válidos e máximo de cinco pontos.
- Adicionado teste para dez resultados P2 com alvo P2, que geram índice 100 e liberam +4.

## Testes adicionados/atualizados
- Ordenação crescente, decrescente e após filtro.
- Tetos de valores de novas propostas de patrocínio.
- Limiares da margem de classe e sequência consistente de P2.

## Versionamento
- versionCode: 738
- versionName: 0.738.0
- Nome público preservado: F1 Team Manager V30.
- Nome padrão do ZIP preservado: F1TeamManager_Android_V30_First_Real_APK_Candidate.zip.

## Validação
- Validação estática e inspeção de alterações executadas.
- Compilação Android/Gradle e testes JUnit completos precisam ser executados no GitHub Actions.


## Correção de compilação após execução no GitHub Actions
- Corrigida a chave de ordenação no `MainActivity.kt`: todos os ramos do seletor agora retornam `String`, evitando inferência genérica incompatível entre `String` e `Int`.
- Idade e Overall são convertidos em números com preenchimento à esquerda para preservar ordenação numérica; nome permanece em ordem alfabética.
- Critério de Classe (caso legado) também retorna chave textual homogênea.
- Adicionado teste de regressão cujo `when` combina critérios e exige um tipo comparável único.
- VersionCode/VersionName mantidos em 738 / 0.738.0, pois esta é uma correção de build da mesma entrega.
