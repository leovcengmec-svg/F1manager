# V717 — Ranking das Equipes

Base: V716 / 0.716.0

## Implementação
- Adicionada a tela independente **Ranking das Equipes**, acessível pela Central de Gestão.
- A lista apresenta as 40 equipes com posição, logotipo, nome e indicador selecionado.
- Três modos de classificação, todos em ordem decrescente: força atual do carro, dinheiro em caixa e projeção do próximo carro.
- A projeção apresenta o Overall projetado e a variação em relação à força atual (+/- pontos). A ordenação usa o Overall projetado, não a variação.
- O toque em uma equipe abre a Visão da Equipe já existente. A equipe controlada pelo jogador recebe destaque visual.

## Dados e desempenho
- Força atual calculada pelo Overall médio dos dois carros físicos.
- Caixa do jogador lido do estado financeiro atual; caixa das equipes de IA lido dos respectivos ledgers financeiros.
- Projeção do próximo carro usa o pipeline físico existente de construção e aplicação de regulamento.
- Cada garagem de IA é simulada uma vez por snapshot e reutilizada para força atual e projeção.
- Resultado das 40 equipes armazenado em cache em memória, invalidado por mudanças relevantes de temporada, semana, estado financeiro/IA, estado da equipe do jogador ou semente regulamentar.
- A preparação do snapshot ocorre fora da thread de interface.

## Compatibilidade
- Não altera classificações oficiais de pilotos ou construtores.
- Não altera os saves nem adiciona campos persistentes.
- Mantém a V716 como base e preserva nome público e nome original do ZIP.
