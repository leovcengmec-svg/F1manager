# V519 — Imagens genéricas na área de P&D

- Adicionada a imagem genérica do componente aos cards de **Nova Pesquisa**, com transparência e posicionamento à esquerda para não comprometer a leitura.
- Mantido o asset `factory_generic_piece` nos cards de designs concluídos e peças disponíveis para fabricação.
- Preservadas as regras de pesquisa, bloqueios, designs, fabricação e filtragem da versão mais recente.
- Versionamento Android atualizado para `versionCode 519` / `versionName 0.519.0`.
- A compilação e os testes automatizados precisam ser executados no ambiente de build com Gradle.
