# V328 — Modal compacto de escolha de pneus

- Removida a rolagem vertical do modal de escolha de pneus.
- Reduzidos cabeçalho, espaçamentos, banners e altura dos cinco cards de compostos.
- Padronizados os cards de pneus com altura fixa e ícone do composto preservado.
- Reduzido o tamanho do rádio para manter alinhamento e espaço útil para os nomes completos.
- Texto dos compostos e quantidade de voltas permanece em uma única linha, sem reticências; tipografia compacta para caber na largura disponível.
- Mantidos os avisos de chuva, recomendação, plano atual, opções de plano, confirmação do pneu e saída explícita sem box.
- Mantido o nome oficial do ZIP de entrega.

Validação executada: inspeção estática das alterações e teste de integridade do ZIP. A compilação Android e o teste no aparelho não foram executados nesta sessão.
