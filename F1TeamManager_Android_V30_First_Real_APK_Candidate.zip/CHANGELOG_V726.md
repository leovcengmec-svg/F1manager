# V726 — Metas esportivas baseadas exclusivamente na força do carro

**VersionCode:** 726  
**VersionName:** 0.726.0  
**Base:** V725 / 0.725.0  
**Nome público:** F1 Team Manager V30  
**ZIP:** `F1TeamManager_Android_V30_First_Real_APK_Candidate.zip`

## Regra principal

As metas individuais de classificação e corrida passam a depender exclusivamente da força do carro da equipe. Atributos, Overall, classe, potencial, perfil de evolução e identidade individual do piloto não podem alterar a expectativa.

## Como a meta é formada

1. As 40 equipes são ordenadas pela força média do carro, em ordem decrescente.
2. A posição do construtor `R` corresponde ao bloco de posições `2R-1` e `2R` do campeonato de pilotos (escala 1–80).
3. Como os dois pilotos do mesmo carro devem compartilhar uma única meta, o centro inteiro usa o ponto médio arredondado para cima: `2R`.
4. Classificação e corrida recebem esse mesmo centro de carro. A faixa de tolerância continua sendo de três posições para cada lado, limitada a P1–P80.

Exemplos: carro P1 recebe meta P2 para ambos os pilotos; carro P10 recebe P20; carro P22 recebe P44; carro P40 recebe P80.

A capacidade individual continua influenciando a posição real na classificação e na corrida. Portanto, dois pilotos no mesmo carro podem obter índices de desempenho e progressões diferentes, mas não recebem expectativas diferentes.

## Alterações técnicas

- `DriverEvolutionEngine.TargetInput` agora contém apenas `driverId`, `teamId` e `carStrength`. Os campos de Overall e Qualificação do piloto foram removidos do contrato.
- `buildIndividualTargets()` classifica somente os 40 carros e atribui uma meta idêntica aos dois pilotos de cada equipe.
- Mantidos os pesos do índice de desempenho (40% classificação / 60% corrida), as faixas de tolerância de ±3 posições e os limiares existentes de evolução/regressão.
- A virada de temporada não cria mais metas usando o carro anterior. O cálculo ocorre depois da construção física e aplicação do regulamento ao carro novo.
- A geração da meta recebe a fotografia da força dos 40 carros usada no ranking da abertura da temporada.
- Uma versão de cache V726 (`driverSeasonTargetsVersion = 4`) invalida metas V725 que continham ajustes de habilidade individual.
- O `ManagerSeasonEngine` recebeu um marcador de versão próprio para reconstruir grades congeladas antigas da V725.
- A ficha individual exibe metas centrais e faixas esperadas de classificação e corrida, com explicação de que são baseadas somente no carro.
- Uma carreira nova limpa snapshots antigos de carros de eventos anuais e caches de metas para não herdar dados de outra carreira.

## Migração de saves V725

Metas antigas da V725 são recalculadas uma vez e congeladas para o restante da temporada. Como o save V725 não conserva necessariamente uma fotografia completa da força de todos os carros na abertura da temporada, a migração usa os melhores dados de carro persistidos disponíveis no save. A partir da próxima virada, a nova fotografia das 40 garagens será capturada depois da construção e regulamentação.

## Validação

- Compilação standalone do núcleo Kotlin de evolução: aprovada.
- Smoke test das 80 metas: aprovado (40 carros, mesma meta para os dois pilotos, escala 1–80, tolerância ±3 e mudança de meta somente quando a força do carro muda).
- Testes de contrato foram atualizados para remover dependência de atributos do piloto e verificar migração de uma grade V725 congelada; nove verificações focadas nas metas foram executadas e passaram.
- O teste legado `DriverEvolutionV674Test` mantém uma falha reproduzível também na base V725: fixture Overall 78 / classe Médio acima do teto da classe e da margem temporária. O mecanismo de evolução não foi alterado nesta revisão.
- A compilação integral do núcleo excedeu o limite de execução deste ambiente em duas tentativas.
- O pacote não contém Gradle Wrapper e o ambiente não dispõe de Gradle/Android SDK; build Android, APK e testes JUnit completos não puderam ser executados aqui.
