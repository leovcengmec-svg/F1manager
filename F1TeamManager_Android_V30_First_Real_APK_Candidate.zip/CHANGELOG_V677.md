# V677 — correção de compilação do APK

## Causa
A V676 chamava `aiFacilities` dentro de `applyDriverEvolution`, mas essa variável era local de `runRound`. O GitHub Actions reportou `Unresolved reference: aiFacilities` em `ManagerSeasonEngine.kt:585`.

## Correção
- `runRound` agora passa explicitamente o mapa `aiFacilities` para `applyDriverEvolution`.
- O método recebe `Map<Int, TeamFacilitiesState>` e mantém `emptyMap()` como valor padrão, preservando compatibilidade com chamadas já existentes.
- Os níveis de Desenvolvimento de Pilotos da IA continuam sendo obtidos do mesmo snapshot de instalações usado na simulação do GP, sem recalcular ou usar estado de outra semana.

## Preservação
Mantidas as sete correções de instalações da V676, as regras esportivas, as demais mecânicas e o nome público do app/ZIP.
