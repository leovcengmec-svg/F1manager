# V427 — Journal persistente da virada de temporada

- Adicionado registro persistente da virada com temporada de origem, destino e etapa.
- O registro usa gravação síncrona (`commit`) para não depender de gravação assíncrona ao encerrar o processo.
- A transição registra PREPARED, SEASON_ADVANCED e STATE_PERSISTED.
- Se a aplicação reabrir com transição parcial, a virada é bloqueada para evitar reaplicar investimentos e duplicar registros.
- O registro é removido somente depois da persistência dos estados principais.
- Teste de contrato atualizado para conferir journal e bloqueio de replay inseguro.

Limitação: a recuperação automática transacional ainda não existe. O journal detecta e bloqueia uma transição parcial, mas exige recuperação assistida. Testes e compilação Android não executados neste ambiente.
