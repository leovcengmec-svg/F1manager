# V634 — Correção do equilíbrio de pilotos e evolução

## Alterações

- Removida a normalização global que forçava cada piloto a iniciar com 75% do teto da própria classe.
- O catálogo agora preserva os sete ratings individuais cadastrados, aplica os ratings do elenco atual e do mercado/reservas e inclui ratings históricos de auge para pilotos lendários e campeões cujo cadastro legado não representava o nível pretendido.
- Adicionado `potentialOverall` ao modelo de piloto. O potencial é individual e independente da classe; a classe passa a representar reputação/segmentação, não um bloqueio absoluto da capacidade esportiva.
- A evolução por GP e a instalação de desenvolvimento podem elevar atributos acima dos antigos tetos de classe, mantendo cada atributo em até 100 e o Overall limitado ao potencial individual.
- O ciclo inicial deixa de colocar todos os pilotos obrigatoriamente em crescimento: pilotos que já estão muito próximos do próprio potencial podem iniciar em auge.
- O crescimento dura no mínimo cinco temporadas e pode se estender até oito se o piloto ainda não alcançou o potencial. O auge mantém duas temporadas e a regressão mantém cinco.
- O piso de regressão passa a ser individual, calculado a partir do potencial em vez de usar a classe como limite de habilidade.
- Potencial individual exibido nas telas de mercado de pilotos, equipe e desenvolvimento para ajudar a comparar capacidade atual e futura.
- Atualizados testes de regressão que assumiam a normalização antiga de 75%.

## Integridade e compatibilidade

- Versão Android: `versionCode = 634`, `versionName = "0.634.0"`.
- Atributos persistidos de carreiras existentes não são sobrescritos na migração; as mudanças de catálogo entram integralmente em novas carreiras. Em saves existentes, o novo potencial orienta a evolução futura.
- Nenhum asset externo, bandeira, escudo, foto de piloto, carro, GP ou histórico de versões foi removido intencionalmente.
