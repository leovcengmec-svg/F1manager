# Auditoria V608 — causa raiz e instrumentação

## Evidência
Na preparação de um GP, `syncAiWeeklyState()` simulava o desenvolvimento financeiro de cada equipe adversária e aplicava o custo; imediatamente depois `participants()` chamava `simulateAiDevelopment()` novamente para as mesmas 39 equipes. Isso duplicava até 39 simulações de desenvolvimento antes da classificação/corrida. A segunda chamada também ocorria depois da alteração do caixa, podendo gerar uma projeção diferente da primeira dentro do mesmo GP.

## Correção
- `simulatedAiState()` armazena o resultado por `season:elapsedWeeks:teamId` e é compartilhado pelos dois caminhos.
- O cache é limpo após a finalização, pois as finanças mudam durante a liquidação.
- O motor `InteractiveRaceSession.kt` e o `InstantSimulationService.kt` permanecem sem mudanças; não alteramos regras esportivas ou aleatoriedade do motor nesta revisão.

## Instrumentação
Logcat tag `F1TM_PERF` registra:
- `syncAiWeeklyState`: custo da sincronização semanal IA;
- `participants`: custo da construção do grid;
- `instantPreparation`: preparação IA + grid;
- `instantEngine`: serviço de simulação de qualificação/corrida;
- `instantSettlement`: persistência, bônus e liquidação final;
- `total`: tempo medido desde o início da simulação até a etapa registrada.

## Limitações
Esta alteração remove trabalho duplicado identificado no código e permite medir a distribuição do tempo, mas não comprova por si só o retorno a menos de cinco segundos. A comparação direta com o ZIP V597 não foi possível porque não havia um ZIP V597 independente no ambiente; a base usada foi o ZIP V607. O build Android e o benchmark no aparelho continuam pendentes.
