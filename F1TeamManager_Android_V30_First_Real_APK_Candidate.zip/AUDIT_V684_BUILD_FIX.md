# Auditoria V684 — correção do erro de compilação da V683

- Erro reportado no GitHub Actions: `MainActivity.kt` referenciava `managerState` dentro do composable `Team`, fora do escopo.
- Correção: novo parâmetro `nextSeasonInvestment: Long`, passado pela Activity e consumido pelo composable sem acesso a estado externo.
- `totalCommitted` e `annualCap` calculados uma única vez e reutilizados nos componentes de UI.
- Os erros de `compareTo` nas mesmas expressões eram consequência da referência não resolvida e foram eliminados ao tipar os operandos pela assinatura `Long`.
- Versionamento: `versionCode=684`, `versionName=0.684.0`.
- Nome do artefato GitHub atualizado para V684; nome oficial do ZIP preservado.
- APK não compilado localmente por ausência de Gradle/Gradle Wrapper neste ambiente.
