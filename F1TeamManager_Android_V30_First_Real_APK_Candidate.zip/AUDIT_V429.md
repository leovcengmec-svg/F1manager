# Auditoria V429 — virada de temporada com checkpoints por subsistema

## Alterações desta versão
- O diário persistente agora aceita etapas explícitas para o reset da carreira e para a persistência de cada subsistema da equipe.
- A virada marca checkpoints após carro, garagem física, instalações, investimento técnico, pesquisa, fábrica, desenvolvimento de pilotos, mercado, finanças e patrocinadores.
- Se uma execução for interrompida entre gravações, o diário preserva a última etapa confirmada. O fluxo existente bloqueia replay cego de etapas intermediárias, reduzindo risco de duplicação.
- Os testes-fonte verificam a ordem dos checkpoints e a lista de etapas permitidas.
- Versão Android: versionCode 429 / versionName 0.429.0.

## Limite de segurança (explícito)
Os checkpoints não são uma transação atômica entre múltiplas chaves e subsistemas. Eles melhoram diagnóstico e evitam repetição automática insegura, mas não reconstroem sozinhos um estado parcial. Uma transição interrompida antes de `STATE_PERSISTED` continua exigindo recuperação assistida. Não declarar recuperação transacional completa.

## Fluxo de virada coberto
1. Confirmar temporada encerrada e gravar journal.
2. Aplicar fechamento da temporada e avançar calendário/mercado.
3. Construir carro novo e recalcular teto anual técnico.
4. Preparar estado financeiro, notificações e mercado da nova temporada.
5. Persistir cada subsistema com checkpoint subsequente.
6. Marcar `STATE_PERSISTED` e limpar journal sem repetir motores.

## Validação
- Testes-fonte adicionados/atualizados.
- ZIP verificado com `unzip -t`.
- Compilação Gradle e testes JUnit não executados: o projeto não possui `gradlew`/`gradlew.bat` e não há comando `gradle` disponível neste ambiente.
