# Auditoria V700 — exibição de idade dos pilotos

## Escopo

Base V699, versão Android 700 / 0.700.0. Alteração restrita à apresentação da idade corrente do motor de carreira.

## Integrações de tela

- Tela Equipe: cartões dos dois pilotos titulares exibem `idade anos`.
- Tela Pilotos da Equipe: cada `DriverSeasonCard` exibe idade numérica sob o nome.
- Perfil individual/histórico: idade aparece no cabeçalho do piloto.
- Mercado de Pilotos: todos os cartões exibem a idade, para titulares, contratados, livres, reservas e futuras contratações.
- Modal de proposta: idade permanece visível antes de enviar a negociação.

## Fonte da idade

Todas as chamadas usam `DriverEvolutionEngine.careerAge(driver, season)` com a temporada ativa (`store.season`), sem duplicar fórmula, gravar uma idade paralela ou depender da temporada civil do telefone. O motor continua a controlar o ciclo 18–43 e o reinício aos 18.

## Regras preservadas

- Nenhum atributo, potencial, classe competitiva, estilo de evolução, histórico, contrato, desempenho ou envelhecimento foi alterado.
- Não foram introduzidas categorias textuais de idade.
- Imagens externas permanecem inalteradas.

## Qualidade dos dados de idade

O motor de idade atual não usa data de nascimento. A idade inicial é uma geração determinística baseada no perfil de evolução e no ID do piloto; por isso pode atribuir idades pouco realistas a pilotos históricos. Esta revisão torna os números visíveis e entrega a lista completa em `PILOT_AGES_V700.md`, mas não corrige a idade-base sem validação específica.

## Testes

- `DriverAgeVisibilityV700Test`: garante 100 pilotos no catálogo, idades válidas em 2026, incremento anual em 2027 e independência em relação à evolução dos atributos.
- Contrato de release: atualizado para V700, 0.700.0.
- Compilação Android integral: depende do GitHub Actions; este ambiente não possui Gradle nem Android SDK.

## Ajuste final de legibilidade

- Na tela Equipe, a idade foi separada dos metadados do piloto e destacada em vermelho/negrito para leitura imediata.
- Na tela de Desenvolvimento, a idade também ocupa uma linha própria nos candidatos e programas ativos.
- O `README.md` agora apresenta os metadados de versão 700 / 0.700.0 em todos os pontos de identificação.
- Também foi gerado `PILOT_AGES_V700.csv` para facilitar filtros e conferência da idade atribuída aos 100 pilotos.

## Faixa atual observada em 2026

A execução do motor sobre `WorldDatabase.allDrivers` confirmou 100 pilotos e idades de 18 a 32 anos (média 24,41). A sequência de idades foi comparada com o CSV exportado, sem diferenças. Isso evidencia que a idade inicial ainda é sintética; a distribuição biográfica dos pilotos deve ser revista separadamente.
