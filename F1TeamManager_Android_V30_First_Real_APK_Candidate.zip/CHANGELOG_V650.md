# V650 — Evolução dos pilotos livres a 90%

## Correção
- Restaurada a evolução dos pilotos livres nos dois modos: Carreira e Team Manager.
- Pilotos sem contrato recebem um tick por GP concluído, com **90% da taxa natural de evolução**.
- O tick livre usa referência neutra de crescimento e não inventa classificação, pontos ou resultado de corrida.
- Pilotos livres não acumulam evidência esportiva para promoção/rebaixamento; as duas temporadas continuam exigindo participação real.

## Regras preservadas
- Potencial individual continua sendo o limite final.
- A classe permanece como limite flexível de crescimento.
- Perfil de evolução, banco fracionário e limite anual por atributo continuam compartilhados com o motor normal.
- Não há regressão baseada apenas na ausência de contrato ou de corridas.
- Os 80 pilotos contratados continuam evoluindo pelo desempenho real e pelas instalações aplicáveis.

## Versão
- `versionCode = 650`
- `versionName = 0.650.0`
- Identidade pública do projeto preservada como V30.
