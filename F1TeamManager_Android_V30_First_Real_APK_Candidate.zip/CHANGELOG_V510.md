# V510 — Unificação financeira integrada

- Centralizada a regra de saldo debitável, usada pelo livro financeiro e pelo replay determinístico de desenvolvimento da IA.
- O fechamento da temporada agora consulta a mesma regra de saldo efetivo para jogador e IA, incluindo obrigações salariais não pagas.
- Scouting de pilotos passou pelo débito financeiro canônico e não pode criar saldo negativo por despesa discricionária.
- O bônus de qualificação persistido usa a mesma regra de elegibilidade e faixa de posição que o cálculo financeiro compartilhado.
- Auditorias estruturais tornaram-se compatíveis com a versão efetiva do projeto, sem expectativas fixas de versões antigas.
- Incluídos testes para saldo debitável e passivos salariais no fechamento da temporada.


## Correção da Fábrica — catálogo por versão mais recente
- A lista de fabricação agora mostra somente o design de maior versão de cada componente (ex.: Motor V4 substitui Motor V3/V2 na lista).
- Quando surgir V5, a lista passa a exibir V5 automaticamente para esse componente.
- O histórico completo de P&D, ordens já iniciadas e peças físicas existentes é preservado.
- Adicionados testes para garantir uma única versão mais recente por componente e catálogo vazio.
