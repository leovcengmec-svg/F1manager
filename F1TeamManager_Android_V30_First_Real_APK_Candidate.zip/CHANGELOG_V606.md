# V606 — Finalização da corrida fora da thread principal

- Mantém o bloqueio de execução até terminar persistência, bônus de classificação e finalização journalizada.
- Move gravação do resultado pendente, bônus e liquidação final da simulação instantânea para `Dispatchers.Default`, evitando prender a UI ao processar classificação, evolução dos pilotos, finanças, notícias e prêmios de até 40 equipes.
- Preserva a gravação do resultado antes dos efeitos financeiros e usa o journal/idempotência existente para recuperação sem simular uma segunda corrida.
- Tratamento de falha conserva o resultado e orienta retomar a finalização, sem repetir a simulação.
- A duração real ainda precisa ser medida em dispositivo; a mudança mira o ANR na fase pós-simulação, não altera regras de corrida.

