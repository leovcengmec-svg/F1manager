# V606 — Prioridade equilibrada entre carro atual e próximo carro

- Criada uma tabela explícita de prioridade para o caixa discricionário da IA: 10% para o próximo carro nos GPs 1–8; 15% nos GPs 9–15; 25% nos GPs 16–22; 35% nos GPs 23–30.
- A porcentagem funciona como alocação de prioridade, não como teto cumulativo do projeto. O próximo carro continua limitado separadamente a €150M e pode recuperar capacidade quando entra receita.
- O carro atual continua recebendo orçamento técnico até o limite anual compartilhado de €200M para P&D, fabricação e instalações; a IA não pode consumir a parcela priorizada para o próximo carro.
- O aporte ao próximo carro usa somente a parcela de prioridade disponível e nunca viola a reserva operacional, salários ou custos da próxima corrida.
- A fase atual é inferida pelo ledger idempotente de GPs concluídos, evitando depender de um contador transitório ou de uma carreira antiga.
- Incluídos testes de regressão para as quatro faixas, a continuidade do orçamento do carro atual, a alocação do próximo carro e a preservação da reserva operacional.
- Mantida a migração não destrutiva e a regra de validar as atualizações em uma carreira nova. Nenhum save antigo é apagado.
