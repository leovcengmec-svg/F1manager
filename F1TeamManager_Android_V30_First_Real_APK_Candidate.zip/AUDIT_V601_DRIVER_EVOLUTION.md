# Auditoria V601 — evolução de pilotos

## Achados na V600
1. `CareerPreferences.applyDriverRaceEvolution` permitia entrar em regressão quando a pressão acumulada chegava a 12, mesmo antes dos cinco anos de crescimento.
2. A duração dependia do tipo de evolução (Prodígio 5, Normal 9, etc.), contrariando o ciclo acordado 5/2/5.
3. A rotina enviava `IntArray(7)` novo a cada GP para `applyPositiveGain`, reiniciando os limites anuais por atributo a cada corrida.
4. O motor de Team Principal repetia o atalho de regressão prematura e durações por tipo.

## Correção
- Ambas as rotas usam 150 GPs de crescimento, 60 GPs de auge e 150 GPs de regressão (30 GPs/temporada).
- A pressão não muda de fase antecipadamente.
- Contadores de ganhos positivos são carregados e gravados por temporada.
- Os tetos de atributo são aplicados pelo `DriverProfileCatalog.ceiling`: Lenda 100.

## Max Verstappen
A queda 75 → 72 em duas temporadas é compatível com o bug de regressão antecipada, mas não é possível afirmar a causa exata daquele save sem inspecionar os valores persistidos do Max (fase, contador de GPs, pressão e atributos). A V601 impede a regressão antecipada em novos ticks; não aumenta automaticamente os atributos já perdidos no save.

## Limites de validação
A versão foi verificada por análise estática. Build Android, JUnit e dispositivo não disponíveis nesta execução.
