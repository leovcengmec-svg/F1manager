# Auditoria integral do F1 Team Manager — V594

## Escopo
Base auditada: V593, promovida a V594 apenas para corrigir falha reproduzível de estratégia de pneus e registrar a auditoria. O pacote oficial de saída mantém o nome `F1TeamManager_Android_V30_First_Real_APK_Candidate.zip`.

A vistoria cobre os contratos entre calendário e avanço semanal, eventos anuais, ciclo de corrida/qualificação/classificação, finalização idempotente, mercado e contratos de pilotos, orçamento e fechamento financeiro, salários e prêmios, patrocínios, P&D, investimentos técnicos, fábricas, instalações, garagem física, construção anual do carro/regulamentos, evolução de pilotos, modo Time Principal, serialização/save, catálogos e assets externos.

## Falha reproduzida e correção
O cenário do modo Livre interrompeu a simulação por uma `IllegalArgumentException` em `TyreModel.buildPlansForWeather`: ao restarem uma volta em chuva, o gerador ainda criava planos com dois stints e distribuição `[0, 1]`. A geração agora limita o número de stints a `min(4, totalLaps)`, mantendo todos os quatro IDs de estratégia e garantindo que nenhum stint ultrapasse a quantidade de voltas restantes. Foi adicionado teste JUnit `WetTyreShortRemainingLapsRegressionTest` para chuva fraca, média e forte com 1–3 voltas restantes.

A mesma simulação revelou uma falha de encadeamento no mercado: a rotina de preenchimento emergencial chamava `expireOffers` sem limitar o piloto/equipe e poderia assinar negociações de outros pilotos após a lista inicial de contratos vencidos. Além disso, ofertas rivais de um piloto podiam continuar no lote de expiração depois de uma assinatura bem-sucedida, gerando notificações falsas e um contrato futuro pendente. `DriverMarketEngine` agora fecha todas as propostas do piloto para a temporada assinada, ignora ofertas obsoletas no lote e restringe o resolvedor emergencial à negociação sob processamento. Foi adicionado teste JUnit `V594ConcurrentDriverOffersRegressionTest`.

## Checagens estáticas executadas na V594
- `validate_project.py`: 40/40 passaram após a adição de `CHANGELOG_V594.md`.
- Contratos da transição anual: 9/9.
- Auditoria matemática de regulamentos: 4.772/4.772 asserções; simulação matemática de 60 temporadas x 40 perfis.
- Auditorias financeiras V438/V439: passaram nos cenários definidos; os próprios scripts documentam premissas de cenário, não são simulações da IA Android.
- Continuidade financeira V440: 13/13.
- Modelo financeiro V441: 7/7.
- Auditoria do ciclo de jogo V448: 18/18.
- Persistência da IA V498: 8/8.
- Auditoria estrutural de release: 25/25 passaram depois da inclusão do changelog.
- Inventário: 76 arquivos Kotlin principais, 147 arquivos de teste, 195 assets locais; 100 perfis de pilotos, 40 equipes e 50 circuitos. Os catálogos JSON foram verificados por parse.

## Simulação integrada de duas temporadas por modo — APROVADA
A rotina `tools/race_sim_test/AllModesTwoSeasonRuntimeAudit.kt` usa componentes Kotlin de produção (motor de temporada, mercado de pilotos, grid dinâmico, validador de resultados, finanças, evolução de pilotos, perfil inicial da equipe e carreira de Time Principal). Para cada modo, avança 60 GPs em duas temporadas de 30 corridas. Verifica calendário, 80 pilotos ativos, dois contratos por equipe, grid/classificação, qualificação 80/50/20, pontos, caixa, coerência de temporada/rodada, garagem de dois carros, evolução idempotente, integridade do mercado, ausência de contratos agendados vencidos, prêmios e ledgers de salários, e avaliação bienal do Time Principal.

Após as correções, a rotina foi recompilada e executada: os três modos passaram, com 60 GPs (duas temporadas completas de 30 GPs) cada, totalizando 180 corridas.

| Modo | Equipe usada no cenário | Ranking inicial | GPs | Viradas | Contratos ativos no final | Registros TP |
|---|---|---:|---:|---:|---:|---:|
| Livre | Team Lotus (ID 8) | 1 | 60 | 2 | 80 | 0 |
| Difícil | Caterham (ID 34) | 38 | 60 | 2 | 80 | 0 |
| Time Principal | Haas F1 Team (ID 29) | 40 | 60 | 2 | 80 | 2 |

Todos os modos terminaram em 2028 GP1, com dois pilotos por equipe, classificação de 80 carros, classificação de qualificação Q1/Q2/Q3 de 80/50/20 pilotos, caixa do jogador não negativa, garagem física com dois carros distintos, marcadores de evolução para os 60 GPs e sem contratos agendados vencidos. No Time Principal, a carreira tem registros únicos de 2026 e 2027 e a revisão bienal está pendente após a segunda temporada.

A regressão focada passou: nove combinações de condições de chuva/voltas restantes, e duas ofertas concorrentes por um mesmo piloto resultando em exatamente um contrato futuro e nenhuma oferta pendente obsoleta. Os testes runtime de eventos anuais passaram com 3.066 asserções e stress de 200 temporadas (1.148 slots); a recuperação da finalização de corrida passou com nove passos e replay idempotente. O `TargetedAudit` concluiu 200/200 corridas com mudanças nos dois sentidos de clima (129 seca→chuva, 139 chuva→seca), 49 decisões de combustível crítico e zero alertas repetidos após `SAVE_FUEL`. A cadeia independente de 60 GPs também passou, finalizando em 2028 GP1, com 80 pilotos ativos, 100 pilotos evoluídos e prêmios registrados em 2026 e 2027.

## Inventário de código e assets
- 76 arquivos Kotlin em `app/src/main/java`, com 25.680 linhas.
- 49 arquivos Kotlin de teste em `app/src/test/java`, com 139 anotações `@Test` no código-fonte.
- 192 arquivos JSON de assets foram analisados com parser: 0 erros.
- Inventário estrutural retém 195 assets no conjunto, incluindo 100 perfis de pilotos, 40 equipes e 50 circuitos.

## Limitações
- O ZIP não fornece `gradlew`, e este ambiente não tem Gradle instalado nem Android SDK/ADB/emulador configurado. Não foi possível executar `assembleDebug`, a suíte JUnit oficial ou o fluxo de interface Android real.
- A simulação headless executa os motores Kotlin puros de produção, mas substituições de dependências de UI/Android significam que ela não prova o comportamento completo da interface nem todos os adaptadores de persistência do Android.
- A auditoria de versão V562 é histórica e espera explicitamente versionCode 562, portanto não é um teste de release aplicável à V594.

## Critério de homologação
Só considerar a V594 homologada após: (1) simulação pós-correção passar nos três modos; (2) auditorias estáticas atuais passarem; e (3) compilação Android e testes integrados serem executados em ambiente com Gradle/Android SDK.
