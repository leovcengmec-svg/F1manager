# Auditoria V619 — Patrocínios completos e inteligência financeira comercial

## Base e escopo

- Base: V618 (0.618.0).
- Versão produzida: V619 (0.619.0).
- Escopo: modelos de pagamento de patrocínio, migração dos contratos existentes, sincronização do nível comercial da IA, decisão de investimento no Centro Comercial e receita comercial semanal na simulação.
- Não foram removidos assets, bancos de dados, histórico de versões, salvamentos, contratos de pilotos ou sistemas de corrida.

## Patrocínios

- Os 180 perfis do catálogo foram ajustados para `ENTRY_AND_GP`.
- O contrato gerado passa a incluir, em todas as categorias e slots, um valor de entrada e um pagamento garantido por GP.
- As faixas monetárias por categoria foram preservadas. O slot Master segue com seus multiplicadores próprios; os bônus de classificação, corrida e pontos continuam separados dos dois pagamentos garantidos.
- `SponsorContractPricing` migra contratos antigos que não tinham ambos os componentes. O valor já existente é mantido; apenas o campo faltante é preenchido com uma estimativa determinística dentro da faixa definida pela categoria. O processo é idempotente.
- `CareerPreferences.loadSponsors` grava de volta a migração de contratos do jogador. `TeamSponsorshipEngine` aplica a compatibilidade aos contratos salvos da IA quando a equipe é consultada ou o nível de Marketing é sincronizado.

## Consciência financeira da IA

- A IA prioriza Marketing/Centro Comercial até o nível 2 quando o caixa permite; esse nível amplia o conjunto de categorias de patrocínio acessíveis.
- Nenhum investimento em instalação começa se, após o custo, o saldo não preservar a reserva de política e pelo menos €15M de caixa operacional.
- Acima do nível 2, a instalação só vira prioridade quando o caixa projetado e o fluxo de caixa acumulado da temporada satisfazem limites crescentes: nível 2–3 exige €40M pós-obra e fluxo não negativo; nível 4–5 exige €80M e fluxo de €15M; nível 6–7 exige €150M e fluxo de €35M; nível 8–9 exige €250M e fluxo de €70M.
- Se não estiver financeiramente saudável para continuar elevando o Centro Comercial, a IA volta a considerar as outras instalações disponíveis, sem insistir em gastos comerciais de alto risco. Se a obra de Marketing estiver estrategicamente priorizada, mas não couber na reserva, ela ainda pode escolher uma instalação mais barata e viável financeiramente.
- O nível persistido de Marketing é sincronizado no fluxo normal antes de consultar contratos e antes de substituir contratos expirados. Assim, uma melhoria altera as categorias de patrocínio das próximas ofertas.
- A simulação `ManagerSeasonEngine` passa a lançar a receita semanal de lojas da IA junto das obrigações de manutenção. A chave `season:week` já existente evita crédito duplicado.

## Testes adicionados

- `SponsorshipAndCommercialAI_V619Test`: valida perfis e ofertas com entrada + GP, migração idempotente dos contratos antigos, investimento inicial no Centro Comercial quando há saldo suficiente, preservação da reserva operacional, alternativa de upgrade mais barata quando Marketing não é viável, investimento adicional de equipe saudável e idempotência da receita semanal após restauração do snapshot.

## Limitações de validação

- O pacote não contém `gradlew` e o ambiente não possui Gradle instalado, então não foi possível executar uma compilação Android completa, a suíte integral de testes ou validação em dispositivo.
- A integridade do ZIP, o conteúdo da versão, os diffs e os arquivos de assets são verificados separadamente antes da entrega.
