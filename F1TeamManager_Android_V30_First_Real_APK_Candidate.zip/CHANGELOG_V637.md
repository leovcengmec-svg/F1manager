# V637 (0.637.0) — Ciclo decenal 80–100 → 40–60

- Recalibrada a ambição de investimento da IA: carros financiados evoluem de forma mais forte, com ganho planejado de até +7 Overall abaixo de 70, +5 de 70 a 89, +2 de 90 a 96 e +1 acima disso. O alvo é alcançar 80–100 antes da revolução decenal, sem bônus adicional além da tabela.
- Recalibrada a revolução regulamentar a cada dez temporadas: redução média de 40% nos seis componentes (motor 40%, chassi 35%, asas 45%, freios 35%, unidade elétrica 40%). Uma construção entre 80 e 100 volta à faixa de 40–60 quando aplicada a regra.
- Preservada a tabela universal investimento × Overall, o bônus único de 10%, o limite de investimento de €150M, os limites de caixa/reservas da IA, as identidades das peças e as confiabilidades.
- Estendido o teste de estresse para 20 transições e duas revoluções decenais (2036 e 2046), com testes automatizados da faixa pré/pós-regulamento.


- Validação V637: testes focados 20/20 métodos; auditoria do ciclo 14/14 verificações; validação estática geral 40/40. Não foi criada APK nem executada uma carreira financeira end-to-end neste ambiente.
