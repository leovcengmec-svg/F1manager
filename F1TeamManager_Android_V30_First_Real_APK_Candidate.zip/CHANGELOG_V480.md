# V480 — Meta de investimento com evolução do próximo carro

- A estratégia da IA deixa de mirar somente o custo de referência do Overall atual.
- Passa a usar uma meta de evolução moderada de até +3 pontos de Overall, com referência financeira calculada pelo `CarDevelopmentEngine`.
- A IA continua priorizando a saúde financeira da temporada atual: reserva operacional, caixa disponível e teto progressivo por fase seguem obrigatórios.
- O aporte efetivo é limitado ao saldo restante da meta de evolução, ao limite progressivo e ao teto absoluto de €150M, evitando continuar investindo depois de financiar a meta.
- O limite de investimento no próximo carro permanece separado do orçamento de P&D técnico.
- Incluído teste de contrato para confirmar que a referência de Overall +3 supera a referência atual e que a contribuição planejada zera ao atingir a meta.
