# Auditoria V583 — Limpeza de pacote

## Base e método
- Base oficial: árvore raiz extraída do pacote V582.
- A pasta `v552_work` foi identificada como snapshot aninhado antigo (seu `app/build.gradle.kts` indicava versionCode 564).
- Antes de excluir essa pasta do pacote de entrega, todos os arquivos foram comparados por caminho relativo e SHA-256 com a raiz oficial.

## Resultado da comparação
- Arquivos no snapshot antigo: 1.140.
- Arquivos sem correspondente na raiz: 0.
- Arquivos idênticos à raiz: 1.102.
- Caminhos correspondentes com conteúdo diferente: 38; a raiz oficial foi mantida em todos esses casos.
- `docs` no snapshot: 125 arquivos; todos idênticos à raiz.
- Assets no snapshot: 195 arquivos; todos possuem correspondentes na raiz; dois arquivos de áudio têm conteúdo atualizado na raiz.
- Nenhum arquivo da raiz oficial foi removido. O pacote final não inclui a pasta aninhada `v552_work`.

## Versão e validação do pacote
- `versionCode = 583`, `versionName = 0.583.0`.
- O ZIP foi testado com `ZipFile.testzip()` após a criação.
- SHA-256 do ZIP está registrado no relatório de entrega.

## Limitações
- Esta atualização remove uma cópia de trabalho antiga do pacote, não altera a lógica de jogo.
- Compilação Android, suíte JUnit e teste em dispositivo não foram executados neste ambiente.
