# V398 — Correção da simulação instantânea

- Corrigida a validação dos multiplicadores de risco do circuito na simulação instantânea.
- O calendário gera multiplicadores legítimos até 1,20; a validação anterior aceitava somente até 1,00 e bloqueava corridas normais antes de iniciar o motor.
- A faixa agora aceita valores finitos entre 0,00 e 1,25, preservando os valores de risco já definidos pelo calendário e pelo motor de corrida.
- A validação de NaN/infinito e de valores fora da faixa continua ativa.
- Sem alterações de interface, assets ou nome do ZIP de entrega.
