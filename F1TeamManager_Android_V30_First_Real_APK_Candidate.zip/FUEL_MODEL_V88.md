# V88 — Fuel Model

- No refueling during pit stops.
- Starting tank: 110 kg.
- Safety reserve: 2 laps.
- ATTACK: 10% more fuel consumption than BALANCED.
- BALANCED: reference consumption.
- DEFENSE: 10% less fuel consumption than BALANCED.
- Race distance is part of the consumption calculation.
- Weather modifies consumption; rain reduces it.
- Fuel reserve is sized so continuous ATTACK completes the scheduled race with two attack-equivalent laps remaining in dry conditions.
- Pit stops change tyres and add time only; fuel is preserved.

Example: 78-lap dry GP
- ATTACK: 1.375 kg/lap
- BALANCED: 1.250 kg/lap
- DEFENSE: 1.125 kg/lap
- ATTACK finish after 78 laps: 2.750 kg remaining (two attack-equivalent laps).
