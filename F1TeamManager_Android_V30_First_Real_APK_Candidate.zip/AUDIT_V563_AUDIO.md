# Auditoria V563 — Áudio

Checklist de revisão estática:

- [x] `driver_warning` não está associado a `MECHANICAL_FAILURE` nem a evento genérico de desgaste.
- [x] `driver_warning` exige alerta `TYRE_CRITICAL` e confirmação de que o `driverId` pertence à equipe do jogador.
- [x] `box_audio` é acionado na seleção explícita da ação `BOX` pelo gestor.
- [x] Removido o disparo de `box_audio` por qualquer evento `PIT_STOP`.
- [x] A rotação da interface é `interface` → `interface_2` → `interface_3` → `interface` após cada GP concluído.
- [x] Trocas de telas comuns da interface não avançam a rotação.
- [x] Áudios de Safety Car e bandeira vermelha permanecem independentes.
- [ ] Build Android e teste no dispositivo: pendentes.
- [ ] Testes JUnit: pendentes.
