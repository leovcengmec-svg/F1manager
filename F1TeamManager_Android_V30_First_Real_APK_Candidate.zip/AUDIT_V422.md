# Auditoria V422

- Alteração focada na referência financeira do sistema Manter Força.
- Classes continuam em seis faixas: 40–49, 50–59, 60–69, 70–79, 80–89 e 90–100.
- Referência agora é interpolada pelo Overall exato, com âncoras 40/50/60/70/80/100 e valores €8M/€25M/€45M/€70M/€110M/€150M.
- A referência dinâmica é usada tanto na previsão exibida quanto na aplicação dos efeitos ao iniciar a próxima temporada.
- O teto global de investimento continua €150M.
- Testes-fonte foram atualizados, mas não foram executados nesta etapa. Compilação Android não confirmada.
- ZIP oficial mantém o nome obrigatório `F1TeamManager_Android_V30_First_Real_APK_Candidate.zip`.
