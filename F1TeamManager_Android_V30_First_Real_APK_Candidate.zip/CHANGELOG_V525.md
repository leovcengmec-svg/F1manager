# V525 — Retenção do histórico financeiro

- Aumentado de 100 para 2.000 lançamentos o limite de histórico financeiro nas operações de crédito, débito, acerto de GP, manutenção, salários, taxas e marcadores relacionados.
- Persistência local e restauração de carreira ampliadas para 2.000 lançamentos.
- Serialização/restauração financeira das equipes de IA ampliada para o mesmo limite.
- Aviso no controle das 56 semanas atualizado para refletir o novo limite e explicar que lançamentos já descartados por versões anteriores não podem ser recriados.
- Preservadas as estruturas e regras de contabilização existentes; alteração focada em retenção e persistência do histórico.
