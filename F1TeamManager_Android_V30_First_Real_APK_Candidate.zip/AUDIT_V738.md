# Auditoria V738 — correções solicitadas após testes V737

## Correções aplicadas
1. Mercado: direção de ordenação usa comparador explícito por chave e estável por nome/ID. O filtro é aplicado antes da ordenação. O vídeo mostrou a causa do sintoma: a rolagem antiga permanecia após trocar para MENOR; a lista agora retorna ao índice zero ao alterar direção, critério, idade, faixa, situação ou busca.
2. Interface: direção do sort ocupa mais largura e explicita a ordem; idade e faixa Overall têm rótulo/valor na mesma linha e menor altura; cards de pilotos mais compactos.
3. Patrocínios: novas propostas são limitadas após multiplicadores de categoria, Master e Centro Comercial: €800 mil/GP, €400 mil bônus de qualificação e €400 mil bônus de corrida.
4. Evolução: limiares reduzidos em mais 10 pontos: 85/90/95/100/105 para +1/+2/+3/+4/+5.

## Compatibilidade
- Contratos de patrocínio já assinados não são alterados retroativamente.
- Saves antigos continuam usando os mesmos modelos e campos.
- Nenhuma migração de save é necessária.

## Limitações de validação
- O ambiente não executa Gradle/Android SDK; a compilação e os testes JUnit devem ser confirmados pelo workflow do GitHub.
- As alterações foram verificadas estaticamente; não declarar APK compilado.


## Correção do erro de compilação reportado (GitHub Actions)
Erro observado em `MainActivity.kt` nas linhas 11192, 11195 e 11196: o seletor `value` retornava `String` para Nome e `Int` para Idade/Classe/Overall, impossibilitando inferir o tipo genérico único `K` exigido por `DriverMarketOrdering.sort`.

Correção aplicada: o seletor agora retorna `String` em todos os ramos. Chaves numéricas são convertidas com `toString().padStart(3, '0')`, preservando ordenação numérica para idade e Overall; nome permanece alfabético. A ordenação estável por nome e ID não foi alterada.

Validação adicional: `DriverMarketOrdering.kt` compilado com `kotlinc` e harness executado com sucesso para Overall crescente/decrescente, idade e nome. Teste de regressão foi adicionado para a inferência do tipo único em `when` com múltiplos critérios. Compilação Android completa não foi executada: este ambiente não possui Gradle instalado nem Android SDK configurado.
