# V558 — Compatibilidade de saves com equipes cadastradas

- A importação de saves agora valida a equipe pelo catálogo real `WorldDatabase.teams`, em vez de rejeitar automaticamente IDs acima de 40.
- A validação do backup de carreira usa a mesma regra, permitindo reconhecer equipes personalizadas registradas no catálogo.
- Mantidos os IDs históricos e os formatos atuais de save (`F1TM_SAVE`, schema 1).
- Atualizada a versão Android para 558 / 0.558.0.

## Limites conhecidos
- Esta alteração remove a rejeição artificial de equipes cadastradas na importação/validação; não torna, por si só, as equipes extras elegíveis para todos os campeonatos.
- `DynamicGridEngine` e `ManagerSeasonEngine` ainda contêm pressupostos de 80 pilotos ativos/100 entradas de mercado; o suporte esportivo completo a grids variáveis continua pendente.

## Validação
- Inspeção estática das duas validações alteradas e conferência das referências ao catálogo.
- Compilação Android e suíte de testes não executadas neste ambiente.
