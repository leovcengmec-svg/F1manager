# V558 — Auditoria global das classes de pilotos

- Mantida a V557 como base oficial de trabalho.
- Adicionada uma salvaguarda central no `DriverProfileCatalog`: qualquer perfil cadastrado como `Fraco` é exposto para novas gerações como `Médio`, com evolução `Normal`.
- Os atributos do piloto são normalizados usando o teto da classe `Médio`, preservando a distribuição relativa dos atributos e a regra de normalização já existente.
- Perfis já classificados como `Médio`, `Forte`, `Pro` ou `Lenda` mantêm sua classe e evolução cadastradas.
- IDs de pilotos, equipes, fotos/assets e dados persistidos de carreiras existentes não são migrados nem apagados por esta alteração.
- Versão Android declarada: versionCode 558 / versionName 0.558.0.

## Validação

- Auditoria estática das classes no catálogo e dos arquivos JSON de assets.
- Teste de integridade do ZIP final.
- A compilação Android e os testes dentro do jogo só serão considerados executados se rodarem com sucesso em ambiente Android/Gradle disponível.
