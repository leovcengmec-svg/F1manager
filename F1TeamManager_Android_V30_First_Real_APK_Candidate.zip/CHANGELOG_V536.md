# V536 — Correcao de compilacao da finalizacao do GP

- Corrigido o escopo de `qualifyingTeamByDriver`: o mapa de contratos ativos por temporada agora e calculado uma vez e fica acessivel tanto ao fechamento financeiro do jogador quanto ao da IA.
- Corrige o erro Kotlin `Unresolved reference: qualifyingTeamByDriver` no processamento dos resultados da qualificacao.
- Preservadas as mudancas de assets de audio da V535 e os demais arquivos do projeto.

Validacao: ZIP integro e escopo da variavel conferido estaticamente. Build Gradle ainda precisa ser executado no ambiente Android.
