# V616 — Agrupamento do pelotão sob Safety Car

- Corrigido o fluxo de deploy do Safety Car por sorteio espontâneo e por incidente: ambos ativam o comportamento de agrupamento.
- Criado `SafetyCarGroupingModel`, compartilhado pelos motores de corrida, para reduzir progressivamente o tempo de volta dos carros distantes do líder enquanto o Safety Car permanece ativo.
- O fechamento de gaps ocorre nas voltas neutralizadas; os tempos acumulados das voltas já concluídas não são reescritos nem substituídos por gaps artificiais.
- Sob SC, o efeito das diferenças normais de ritmo entre carros é reduzido a 10%; o pelotão segue uma referência de ritmo comum, com fechamento limitado por volta e piso de tempo neutralizado para evitar ganhos impossíveis.
- DRS e ultrapassagens ficam bloqueados enquanto há neutralização (Safety Car ou VSC).
- `InteractiveRaceSession` agora registra implantação/recolhimento e mantém Safety Car/VSC por uma janela de voltas definida, em vez de encerrar apenas pela paridade da volta.
- Teste de regressão valida redução real da diferença de tempos após deploy, preservação do tempo acumulado e DRS desativado.
- Compilação isolada do núcleo de corrida validada antes do ajuste final e recompilação final dos três arquivos alterados aprovada; smoke test executou corrida de 80 pilotos com 2 Safety Cars e verificou compressão real de 27.015 ms para 20.242 ms após deploy de teste.
- Build Android/Gradle completo, suíte JUnit oficial e teste em dispositivo não executados neste ambiente.
