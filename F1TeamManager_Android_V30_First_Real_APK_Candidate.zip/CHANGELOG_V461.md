# V461 — Nomes completos dos pilotos na seleção de equipe

- A seleção de equipe agora apresenta o nome completo de cada piloto nos campos PILOTO 1 e PILOTO 2, sem reduzir para o sobrenome.
- Ajustada a tipografia e permitidas até duas linhas para acomodar nomes longos no espaço existente.
- Nenhuma regra de força inicial, modo difícil ou seleção de equipe foi alterada.
- Compilação Android não executada neste ambiente.
