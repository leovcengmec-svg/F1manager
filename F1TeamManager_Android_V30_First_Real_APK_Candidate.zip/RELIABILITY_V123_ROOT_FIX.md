# V123 — Correção de raiz: confiabilidade inicial e IA

## Regras oficiais

### Carro inicial por categoria
- Forte: performance 56..60 / confiabilidade 65..74 / instalações nível 2
- Médio: performance 48..55 / confiabilidade 55..64 / instalações nível 1
- Fraco: performance 40..47 / confiabilidade 45..54 / instalações nível 0

A confiabilidade inicial é independente do overall de performance. Equipes da mesma categoria começam próximas e nenhuma equipe recebe confiabilidade artificialmente alta por possuir carro mais forte.

## IA

O P&D da IA deixou de fabricar designs com confiabilidade sintética 94..100. A confiabilidade de cada novo design parte da confiabilidade atual do componente instalado e recebe somente o ganho técnico do próprio P&D.

A alocação neutra da IA usa o mesmo princípio de pesquisa balanceada do gestor:
- 50% do ganho efetivo para performance;
- 50% do ganho efetivo para confiabilidade.

A fabricação e instalação continuam passando pelo mesmo fluxo físico de peças.

## Objetivo

IA e gestor usam a mesma base de confiabilidade e a mesma lógica de evolução. A IA continua escolhendo automaticamente o componente, foco e momento de investimento, mas não recebe vantagem oculta de confiabilidade.
