# Auditoria V606 — transferência de pilotos

## Causa abordada
A edição de uma equipe atualizava o elenco-alvo e tentava devolver o piloto deslocado ao assento da equipe de origem, mas a reconciliação era sensível a elencos antigos com vínculos duplicados e não consolidava todas as ocorrências do piloto transferido.

## Alteração
`CustomWorldCatalog.editTeamWithDrivers` passa a operar sobre um mapa de todos os elencos, substitui pilotos na origem pelo piloto deslocado, atualiza elencos oficiais e personalizados e prioriza a equipe editada ao resolver duplicidades remanescentes. A gravação mantém rollback em exceção.

## Cenário esperado
Transferir Alexander Albon de Williams para Force India deve colocar o piloto selecionado na Force India e o piloto deslocado da Force India no assento que Albon ocupava na Williams. A operação não deve criar uma segunda ocorrência de Albon em outra equipe.

## Limitações de validação
A verificação estrutural do ZIP não comprova compilação, teste JUnit, persistência após reinício nem simulação de corrida. Esses testes precisam ser executados pelo Gradle/GitHub Actions e no dispositivo antes de considerar a correção aprovada.
