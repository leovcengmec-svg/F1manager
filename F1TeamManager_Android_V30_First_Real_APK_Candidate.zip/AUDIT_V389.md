# Auditoria V389

## Alterações
- `MainActivity.kt`: cards de situação da corrida com altura igual de 148 dp.
- `DriverStartStrategyBlock`: foto sem sobreposição da posição; escudo da equipe e posição de largada em cards de dimensões iguais; nome da equipe removido da linha de identificação.
- `app/build.gradle.kts`: `versionCode=389`, `versionName=0.389.0`.

## Verificações
- Revisão estática dos trechos alterados concluída.
- Integridade do ZIP será verificada após empacotamento.
- Build Android e teste visual em dispositivo não executados neste ambiente; dependem da compilação do usuário.
