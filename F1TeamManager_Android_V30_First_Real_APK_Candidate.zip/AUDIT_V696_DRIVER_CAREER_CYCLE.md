# Auditoria v696 — ciclo de carreira dos pilotos

## Escopo
Correção das ressalvas do sistema etário introduzido na v695, mantendo o restante do equilíbrio da v695.

## Comportamento
1. A idade inicial é determinística e deriva do perfil de desenvolvimento fixo e do ID do piloto.
2. Primeiro ciclo: coorte inicial até 43 anos. Ciclos seguintes: 18 a 43 anos, depois reinicia em 18.
3. Não existe aposentadoria, remoção ou criação de nova identidade. O mesmo piloto continua no elenco/mercado.
4. Recupera 50% das perdas físicas registradas como causadas pelo envelhecimento, limitado ao pico histórico de cada atributo físico. Os atributos físicos modelados são velocidade, ultrapassagem e defesa.
5. A pressão de envelhecimento e as regressões por desempenho usam bancos separados. Só o banco de envelhecimento entra na recuperação parcial.
6. Perfil/tabela de evolução não é alterado pela idade. O perfil original continua governando a taxa/limite de crescimento.
7. Agentes livres evoluem a 100% da taxa natural, mas não recebem amostras de resultado inventadas para sua avaliação de classe.
8. A classe competitiva continua sendo avaliada pelo motor de progressão que exige duas temporadas consecutivas com evidência suficiente; a idade não é parâmetro dessa avaliação.

## Compatibilidade de saves
Os saves antigos não tinham ledger separado de perdas físicas causadas por idade. Na primeira corrida após atualizar, o sistema inicializa o pico físico com os atributos atuais e o ciclo atual. Não tenta inferir ou restaurar perdas antigas misturadas com regressões por desempenho, evitando recuperação incorreta. As perdas de idade acumuladas a partir da v696 passam a ser rastreadas com precisão.

## Testes
- Ciclo etário reinicia em 18 sem aposentar/remover o piloto.
- Reinício recupera metade das perdas físicas registradas (floor por atributo) e mantém atributos não físicos intactos.
- Recuperação não ultrapassa o pico histórico dos atributos físicos.
- Piloto livre e contratado recebem a mesma taxa natural, com a mesma semente e idade.
- Perfil e classe competitiva não são modificados pelo tick de idade.

## Limitação de build
Núcleo de evolução compilado isoladamente com Kotlin e verificações funcionais isoladas aprovadas. A compilação Android integral e a suíte JUnit completa ainda precisam ser executadas no GitHub Actions.
