# Auditoria V683 — economia e envelope de investimento

## Objetivo
Reduzir o enriquecimento excessivamente rápido observado nas simulações de três temporadas e distinguir caixa real de orçamento técnico ainda não consumido.

## Centro Comercial
- Níveis 0–3 preservados: receita semanal de €200k–400k, €350k–600k, €500k–800k e €650k–1.000k, respectivamente.
- Níveis 4–10 passam a €700k–1.050k até €1.000k–1.350k; o ganho marginal é fixado em €50k na faixa mínima e máxima por nível.
- Multiplicador comercial: 1,6000x / 1,6250x / 1,6500x / 1,6750x nos níveis 0–3; depois +0,0075 por nível até 1,7275x no nível 10.
- Manutenção comercial semanal: nível 3 = €80k; nível 10 = €980k. A manutenção avançada cresce mais rápido que as vendas incrementais.

## Patrocínios
- Duração de novos contratos: 8–16 GPs, substituindo a janela anterior de 3–10 GPs.
- A mudança reduz a frequência potencial dos pagamentos de entrada; não muda contratos já assinados em saves existentes.

## Envelope técnico
- Limite anual: €200M.
- Pesos de referência da IA: 40% próximo carro (€80M), 40% carro atual (€80M) e 20% instalações (€40M). Esses pesos orientam prioridades, mas não são três tetos rígidos que prendem o orçamento quando uma categoria não tem projetos viáveis.
- O cálculo de saldo agora subtrai também os pagamentos do próximo carro armazenados no ledger específico.
- Reserva de caixa da IA: teto de €50M. Reserva do próximo carro: até €80M, limitada ao caixa disponível e reduzida pelo que já foi investido.
- Todas as rotas de P&D, fabricação, instalações e carro seguinte, tanto da IA quanto do jogador, validam o saldo anual consolidado. Para o jogador, o limite é um envelope comum, não uma divisão obrigatória 40/40/20.
- A IA deixa de tratar os 40% do carro atual como teto rígido: quando instalações ou outro destino não usam sua alocação, o P&D pode reaproveitar o espaço livre dentro do envelope global. O carro seguinte preserva prioridade de até €80M. Não existe obrigação de gastar os €200M se não houver projeto viável ou caixa acima das reservas.

## Interface
- “Caixa Atual” substitui o rótulo incorreto “Salário Anual”.
- “Carro Seguinte” aparece em linha própria e “Invest. Restante” reflete o saldo real depois de todas as categorias.

## Limitações
- Não foi possível executar Gradle/JUnit/APK neste ambiente: o arquivo de origem não contém `gradlew` e o binário `gradle` não está instalado.
- Recomenda-se executar pelo GitHub Actions a simulação de 40 equipes por três temporadas, comparando caixa final, receitas, despesas e envelope anual investido com a v682.
