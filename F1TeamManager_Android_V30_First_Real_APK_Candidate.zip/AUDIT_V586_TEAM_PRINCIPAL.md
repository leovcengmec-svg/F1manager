# AUDITORIA V586 — MODO TEAM PRINCIPAL

## Escopo

Introduzir o terceiro modo de jogo sem remover nem alterar a seleção dos modos Livre e Difícil. O modo Team Principal trata a carreira profissional do gerente separadamente do estado da equipe administrada.

## Implementado na fonte

- Opção **Modo Team Principal** na seleção de modo e seleção limitada às três equipes com menor força inicial canônica.
- Prestígio inicial 10/100 e meta de campeonato baseada na posição inicial da equipe, com objetivo de progredir aproximadamente três posições.
- Atualização anual do prestígio com base na meta, movimentação no campeonato e chegada ao top 3.
- Avaliação contratual depois das duas primeiras temporadas de cada contrato; as janelas se reiniciam após renovação ou contratação por outra equipe.
- Saídas possíveis na avaliação: renovação (quando não demitido), propostas externas e demissão depois de duas temporadas consecutivas significativamente abaixo da meta com prestígio baixo.
- Elegibilidade das propostas usa o ranking atual do campeonato e o prestígio, não só o ranking inicial da equipe.
- Histórico profissional mantém o ID da equipe em que cada temporada foi disputada, inclusive depois de mudar de empregador.
- Estado persistido em `CareerPreferences`, incluído no backup normal de carreira e restaurado ao carregar um save.
- Preparação da equipe de destino e handoff do carro físico/equipe anterior, para reduzir o risco de o carro da equipe que deixou de ser controlada voltar ao carro-base ao passar para IA.
- Card de prestígio e objetivo na HOME; avaliação e propostas em uma tela dedicada.
- Testes de motor cobrindo prestígio, meta, revisão bienal, propostas dinâmicas, demissão, idempotência, renovação, histórico por equipe e serialização.

## Regras iniciais de balanceamento

- Prestígio inicial: 10 de 100.
- Meta inicial: terminar cerca de três posições acima do ranking de força inicial.
- Ganhos/perdas por temporada: de -12 a +15 antes do limite total de 0 a 100.
- Janelas contratuais: duas temporadas.
- Propostas abrem progressivamente para equipes com ranking atual mais alto à medida que o prestígio aumenta.

Esses são valores iniciais de gameplay e poderão ser balanceados depois dos testes de temporadas completas.

## Validações realizadas

- Executados 9 casos de teste definidos no arquivo `V586TeamPrincipalCareerEngineTest.kt` usando um executor local e stubs mínimos de JUnit/modelos (não é a execução oficial do Gradle/JUnit do app); os 9 passaram.
- Executado também um harness Kotlin isolado com stubs dos modelos físicos, verificando prestígio, revisão bienal, propostas, demissão, idempotência e serialização de estado e carros; passou.
- Integridade do ZIP será verificada após a geração final.

## Limitações conhecidas

- Não foi executada build Android/Compose: o pacote não contém `gradlew` nem `gradle-wrapper.properties`, e `gradle` não está instalado neste ambiente.
- Não foram executadas simulações de temporadas completas no aplicativo ou em dispositivo.
- Portanto, esta entrega implementa a primeira versão funcional em código do modo, mas não certifica ainda a integração ponta a ponta no runtime Android.
