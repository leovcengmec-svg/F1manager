# Auditoria V565

- [x] Versão Android declarada como `versionCode = 565` e `versionName = 0.565.0`.
- [x] `SeasonPrizeEngine.rankTeams` une IDs do catálogo com IDs presentes no mapa de pontos salvo.
- [x] Ordenação determinística: pontos decrescentes, ID crescente para desempate.
- [x] Testes de regressão adicionados para equipe customizada, idempotência determinística e desempate.
- [x] Curva de premiação não alterada.
- [ ] Compilação Android: não executada.
- [ ] Testes automatizados: não executados.
- [ ] Simulação de duas temporadas com equipes extras: pendente.
