# Auditoria V604 — travamento na simulação instantânea e abertura do GP

## Base
V603, usada como base oficial pelo usuário. Assets, bandeiras, escudos, circuitos, pilotos, carros e histórico de versões foram mantidos.

## Achado de alto impacto
`startWeekend()` executava no callback da UI `syncAiWeeklyState(currentWeek)`, que itera sobre 39 equipes de IA e simula desenvolvimento semanal, e logo depois `participants()`, que volta a iterar sobre as 39 equipes e simula desenvolvimento para construir garagens/instalações dinâmicas. Em seguida `engine.start()` valida/prepara o grid de 80 pilotos. Tudo estava no caminho síncrono de UI.

O botão de simulação instantânea também executava `syncAiWeeklyState`, `participants`, Q1/Q2/Q3, corrida completa, validações de classificação e validação de resultado sem sair da thread principal. O motor pode executar muitas voltas de cada piloto; a lógica síncrona é compatível com o ANR observado no resultado.

## Correção
- `startWeekend()` lança coroutine, faz sincronização AI, gera participantes e inicia o motor em `Dispatchers.Default`; somente atualiza o estado de navegação depois do retorno.
- A simulação instantânea agora corre em coroutine e move sincronização, grid, qualificação, corrida e validações para `Dispatchers.Default`.
- Guarda única `raceWorkInProgress` impede reentrada e toque duplicado.
- Dialog de progresso evita que o usuário interprete o processamento como congelamento.
- Logs por fase com tag `F1TM_PERF` e warnings para fases acima de 250 ms.
- Teste de regressão para 80 pilotos e 95 voltas adicionado ao conjunto JUnit.

## Medição de processamento
Não foram inventados tempos. O ambiente não tem Gradle, wrapper, Kotlin compiler nem ADB, portanto não é possível executar o teste JUnit nem medir tempos reais do motor Android aqui. V604 instrumenta as fases para coletar tempos reais via Logcat no dispositivo:
- `weekend.syncAiWeeklyState`
- `weekend.participants`
- `weekend.engineStart`
- `weekend.total`
- `instant.syncAiWeeklyState`
- `instant.participants`
- `instant.simulateAndValidate`
- `instant.totalSimulation`
- `instant.advanceFreeWeeks`
- `finalize.total`

## Risco residual
O avanço de semanas livres e a finalização persistente do resultado ainda têm trechos síncronos que alteram estado da carreira. V604 mede esses trechos, mas não muda o contrato transacional da finalização, pois movê-la indiscriminadamente para background pode competir com o estado Compose e os passos idempotentes do diário. Se os logs mostrarem que `advanceFreeWeeks` ou `finalize.total` excedem o orçamento, a próxima correção deve isolá-los por etapas, mantendo o diário de finalização idempotente.

## Validação
- Teste estático de V604: executado.
- Auditorias estruturais de projeto/release: executadas.
- JUnit real, compilação Android e corrida no aparelho: pendentes.
