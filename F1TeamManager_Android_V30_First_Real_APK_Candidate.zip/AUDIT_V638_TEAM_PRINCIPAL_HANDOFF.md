# Auditoria V638 — Transferência do Team Principal para outra equipe

## Sintoma reproduzido por inspeção do fluxo

Ao aceitar uma oferta externa, o jogo registra a contratação para `season + 1` e mantém a equipe atual até a virada. Porém, `MainActivity.startNextSeason()` validava o elenco da equipe de destino antes de abrir o diário da transição. Se contratos dessa equipe expirassem no ano seguinte, a projeção podia ter 0 ou 1 piloto e a validação encerrava a operação antes de o mercado de pré-temporada poder completar o elenco. A oferta permanecia pendente, tornando o mesmo bloqueio recorrente. A mesma validação existia dentro de `CareerPreferences.startNextSeason()`.

## Correção aplicada

1. Centralizada a decisão em `TeamPrincipalCareerEngine.mayAdvanceWithProjectedRoster`: elencos comuns continuam exigindo exatamente dois pilotos; uma oferta Team Principal válida para a temporada-alvo pode avançar para a resolução transacional do mercado.
2. A ativação do contrato grava um marcador de uso único para a temporada de entrada. O marcador permite identificar a exceção dentro de `CareerPreferences.startNextSeason()`, mesmo após a oferta pendente ter sido consumida dentro do diário da virada.
3. `DriverMarketEngine.applySeasonTransition()` aceita uma lista explícita de equipes que podem ter vagas preenchidas pelo mercado automático. No handoff, somente a equipe entrante é adicionada à lista; as outras equipes IA continuam sendo resolvidas normalmente. O restante das carreiras mantém o comportamento existente e não recebe pilotos artificiais.
4. A resolução automática tenta confirmar dois contratos ativos para a equipe entrante. Caso a equipe esteja sem caixa suficiente ou não consiga fechar ofertas, a transição não é abortada: o mercado registra uma notificação importante e o calendário avança, orientando o usuário a completar as vagas manualmente. A carreira não entra em bloqueio permanente por uma segunda falha no mercado.
5. Incluídos testes de regressão para ambos os gates de elenco, manutenção do comportamento estrito em carreira normal e preenchimento do elenco entrante durante a pré-temporada.

## Arquivos alterados

- `MainActivity.kt`
- `CareerPreferences.kt`
- `core/manager/DriverMarketEngine.kt`
- `core/manager/TeamPrincipalCareerEngine.kt`
- `V638TeamPrincipalHandoffRegressionTest.kt`

## O que ainda precisa de validação no app

O pacote pode ser verificado estaticamente e a lógica de mercado pode ser testada em testes Kotlin focados. Este ambiente não contém um `gradlew` utilizável nem executa a interface Android completa, portanto a reprodução visual em um save real de seis temporadas ainda precisa ser confirmada no dispositivo.

## Resultados de validação da V638

- Validação estática do projeto: **45/45 verificações aprovadas**.
- Testes focados do fluxo Team Principal/mercado: **4/4 aprovados** em harness Kotlin (incluindo cenário de caixa insuficiente na equipe entrante).
- Os testes focados usam o `DriverMarketEngine`, o `TeamPrincipalCareerEngine`, `WorldDatabase` e `SeasonCalendar` reais do projeto. Serviços periféricos de instalação/finanças foram substituídos por stubs no harness; isso não equivale a uma compilação ou execução Android integral.
- A equipe entrante ficou com dois pilotos confirmados na virada, e todas as 40 equipes terminaram com dois pilotos no cenário de mercado solvente testado.
- O comportamento da carreira normal foi preservado: uma equipe controlada pelo jogador sem dois pilotos ainda não pode avançar.
- Revisão de robustez adicional: se a IA não conseguir completar o elenco da nova equipe por restrição financeira/contratual, o Team Principal ainda assume a equipe; a UI e as notificações avisam para completar os pilotos antes do GP. Isso elimina um possível bloqueio secundário em equipes financeiramente debilitadas.
