# V443 — Motor de regulamento anual do carro (Etapa 1)

- Criado catálogo imutável de 18 eventos fictícios de regulamento, três para cada um dos seis componentes do carro.
- Sorteio determinístico por temporada: da temporada 2 em diante, seleciona um ou dois componentes distintos; temporada 1 fica sem evento.
- Criada revolução decenal nas temporadas 11, 21, 31... com reduções mais agressivas previstas para os seis componentes.
- Incluída serialização validada para persistir a regra sorteada e impedir novo sorteio ao recarregar a carreira.
- Esta etapa só define e persiste as regras. A aplicação das reduções ao carro, a ordem de construção do carro e o ranking de força ficam para a etapa 2.
- Fluxo obrigatório registrado para a etapa 2: encerrar temporada anterior → construir carro da próxima temporada → aplicar regulamento àquele carro novo → calcular ranking de força da temporada nova. A atualização normal do carro não substitui nem duplica a aplicação do regulamento.
- Nenhuma alteração de layout; histórico e assets preservados.
