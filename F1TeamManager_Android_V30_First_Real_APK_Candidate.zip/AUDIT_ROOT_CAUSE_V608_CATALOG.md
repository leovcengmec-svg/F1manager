# V608 — Análise de causa-raiz: cadastro e troca de pilotos/equipes

## Escopo
Inspeção do catálogo dinâmico, editor de equipes, persistência de overrides oficiais e reconciliação do mercado de pilotos. Esta revisão não equivale a uma certificação completa do aplicativo Android.

## Defeitos concretos encontrados e corrigidos

### 1. Editar equipe oficial não persistia a própria equipe
**Arquivo:** `app/src/main/java/com/f1teammanager/core/season/CustomWorldCatalog.kt`

`editTeamWithDrivers()` permitia editar equipes oficiais (IDs 1–40), mas a atualização de `nextCustomTeams` só persistia equipes personalizadas (>40). O método persistia overrides de equipes oficiais de origem cujo roster mudava durante a troca, mas não gravava o override do próprio alvo editado. Consequência: nome, país, escudo, classe/nível e/ou pilotos escolhidos para a equipe oficial podiam voltar aos valores anteriores após recarregar o catálogo.

**Correção aplicada:** quando o ID alvo está entre 1 e 40, gravar `updated` em `nextOfficialOverrides[id]` na mesma transação antes de salvar.

### 2. Pilotos vinculados a roster podiam reaparecer como agentes livres
**Arquivo:** `app/src/main/java/com/f1teammanager/core/manager/DriverMarketCatalogMigrationV560.kt`

A migração removia os IDs de pilotos vinculados a equipes do pool livre, mas o cálculo final `allKnownFree` voltava a adicionar qualquer piloto conhecido sem contrato e sem transferência agendada. Em rosters inconsistentes ou com mais de dois pilotos declarados, um ID ainda vinculado ao roster podia acabar simultaneamente no mercado livre.

**Correção aplicada:** a reconstrução final do mercado exclui IDs presentes em `rosterOwnerByDriverId`.

### 3. Exclusão de cadastro não está implementada no catálogo
**Arquivo:** `CustomWorldCatalog.kt` / `MainMenuScreen.kt`

A inspeção não encontrou operações `remove/delete` para pilotos ou equipes personalizadas. Portanto, o fluxo de cadastro/edição existe, mas a remoção completa não está implementada por essas APIs. Não foi feita uma exclusão improvisada porque seria necessário definir a reconciliação de contratos, resultados históricos, saves e referências de carreira.

## Validações executadas após as correções
- `validate_project.py`: **32/32** verificações estáticas aprovadas.
- `final_release_audit.py`: **34/34** verificações estruturais aprovadas.
- `run_catalog_live_market_audit_v580.sh`: **PASS** — catálogo → mercado → grid de 82 pilotos → pontos de construtores/prêmios/patrocínios → investimento técnico/P&D/fábrica/evolução.
- Verificação de código: override da equipe oficial alvo é persistido; IDs vinculados a roster não são reintroduzidos como agentes livres.

## Limitações importantes
- Não foi possível compilar o APK neste ambiente: o projeto não tem Gradle Wrapper utilizável nem instalação local de Gradle/SDK Android.
- Testes JUnit Android e execução em emulador/aparelho não foram executados.
- A simulação de duas temporadas permanece inconclusiva nesta etapa.
- O relatório não afirma que todos os fluxos de salvamento/importação, todas as transferências ou todas as telas estejam 100% corrigidos.
