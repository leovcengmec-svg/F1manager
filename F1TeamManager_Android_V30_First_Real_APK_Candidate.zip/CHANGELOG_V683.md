# V683 — reequilíbrio econômico, Centro Comercial e investimento da IA

Base: V682  
VersionCode: 683  
VersionName: 0.683.0

## Centro Comercial
- Níveis 0–3 preservam a curva anterior de receita das lojas e de multiplicador comercial.
- Do nível 4 ao 10, a receita semanal de lojas passa a crescer em incrementos de €50 mil por faixa, evitando a aceleração anterior até €3 milhões por semana.
- O multiplicador de contratos mantém os valores dos níveis 0–3 e reduz o ganho marginal dos níveis 4–10 para 0,75 ponto percentual por nível; nível 10 = 1,7275x.
- A manutenção do Centro Comercial passa a ter uma tabela própria: os níveis avançados incorporam custos maiores de operação, pessoal, licenciamento e ativação comercial.
- A avaliação de retorno de upgrades da IA usa a nova manutenção específica do Centro Comercial.

## Patrocínios
- Novos contratos passam a durar entre 8 e 16 GPs, reduzindo a frequência de novas assinaturas e pagamentos de entrada ao longo de uma temporada de 30 corridas.
- Contratos já assinados e saves existentes não são reprecificados nem têm sua duração alterada.
- As projeções da IA passam a avaliar os contratos com a nova faixa de duração.

## Investimentos e liquidez da IA
- O investimento no carro da próxima temporada agora é descontado do mesmo envelope técnico anual de €200 milhões, embora continue preservado em seu ledger específico para compatibilidade com saves.
- O saldo disponível real é calculado como teto anual menos P&D/fabricação/instalações e investimento no próximo carro.
- A IA não reserva mais 40% de todo o patrimônio sem limite para o próximo carro: a reserva acompanha a prioridade de 40%, mas é limitada à alocação anual de €80 milhões e diminui conforme o investimento é feito.
- A reserva operacional da IA passa a ter teto de €50 milhões, preservando caixa para obrigações sem congelar centenas de milhões em equipes muito ricas. O piso mínimo e a reserva de salários/custos da próxima corrida continuam ativos.
- Desenvolvimento, instalações e carro seguinte consultam o mesmo saldo consolidado para impedir que a soma ultrapasse €200 milhões.
- Os percentuais 40/40/20 permanecem como prioridades de planejamento da IA, não como bloqueios rígidos: P&D pode reaproveitar espaço anual que outra categoria não utilizou quando houver projeto viável. Para o jogador, as categorias compartilham o mesmo envelope sem cotas obrigatórias.
- O investimento anual não é uma meta de gasto: a IA não deve consumir orçamento sem projeto viável ou à custa das reservas operacionais.

## Painel financeiro
- Corrigido o rótulo incorreto “Salário Anual” para “Caixa Atual”.
- O card agora exibe separadamente o investimento no carro seguinte e o saldo restante do envelope anual, já descontando esse investimento.

## Testes
- Atualizados os testes da receita semanal, multiplicador comercial e duração dos contratos.
- Adicionados testes para retornos decrescentes após o nível 3, manutenção avançada, limite da reserva de caixa da IA, contabilização consolidada do envelope de €200 milhões e reaproveitamento de alocação não utilizada pelo P&D da IA.
- A auditoria de três temporadas verifica que contratos iniciais e renovações mantêm a nova duração de 8–16 GPs.

## Limitações de validação
- Verificação estrutural e revisão dos arquivos alterados realizadas localmente.
- O ZIP de origem não contém Gradle Wrapper e o ambiente não possui Gradle instalado; portanto, a suíte JUnit e a compilação APK precisam ser confirmadas pelo GitHub Actions.

ZIP oficial preservado: `F1TeamManager_Android_V30_First_Real_APK_Candidate.zip`.
