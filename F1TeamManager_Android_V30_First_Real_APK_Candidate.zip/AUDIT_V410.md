# Auditoria de causa-raiz — V410

## Falha reproduzida pelo fluxo de código

**Alta — Central de Notícias divergente do estado real do mercado.** `DriverMarketEngine.processAiMarketWeek` pode programar renovação/contratação e gerar a notícia de sucesso. Em `MainActivity`, a validação de taxa de assinatura pode depois remover o compromisso futuro por falta de caixa. A implementação anterior removia o compromisso e histórico, mas não removia a notícia positiva. O filtro `ABERTO` usa `canReceiveProposals`; sem compromisso em `scheduled`, o piloto voltava a ser elegível, enquanto a notícia continuava dizendo que renovou.

A rotina antiga de rejeição da equipe do jogador também tentava remover avisos procurando o ID numérico no texto da notícia, embora o texto seja composto pelo nome do piloto/equipe. Portanto, a limpeza não era confiável para os avisos de sucesso.

## Correções aplicadas

- Centralizada a reversão financeira em `DriverMarketEngine.cancelUnaffordableScheduledDeals`.
- A rotina remove o acordo futuro rejeitado e a proposta correspondente, retira notícias positivas ligadas àquele piloto/equipe na temporada, grava histórico e emite `NEGOCIAÇÃO ENCERRADA` com a causa financeira.
- Usada para rejeições financeiras tanto da equipe do jogador quanto da IA.
- Teste `DriverMarketRenewalConsistencyV410Test`: verifica que renovação assinada bloqueia ofertas; após rejeição financeira, o piloto volta a ser elegível e a notícia de renovação concluída desaparece.

## Outras falhas encontradas no caminho de persistência

**Média — Papel contratual perdido ao recarregar o mercado.** O serializador atual grava 7 campos de contrato incluindo o papel em `p[6]`, mas o leitor no formato de 7 campos descartava o papel e restaurava `EQUAL`. Corrigido para ler o papel salvo, mantendo compatibilidade com o formato legado de 8 campos.

**Média — Piloto substituto perdido ao recarregar acordos futuros.** O serializador atual grava 9 campos e armazena `replaceDriverId` em `p[8]`, mas o leitor do formato de 9 campos ignorava esse campo. Corrigido para restaurá-lo, preservando a escolha de substituição ao reiniciar o aplicativo.

## Limites da validação

- Revisão estática do fluxo de geração, rejeição financeira, filtro `ABERTO` e serialização.
- Teste de regressão adicionado ao projeto, mas **não executado** neste ambiente.
- Compilação Android/JUnit completa não executada: não há Gradle executável nem Gradle Wrapper no projeto disponível neste ambiente.
- Recomenda-se confirmar no dispositivo uma carreira nova e um save já existente: notícias de renovações que ficaram inconsistentes antes desta correção não são automaticamente reconstruídas retroativamente.
