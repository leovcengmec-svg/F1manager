# V670 — cards de resultados e distribuição financeira da IA

## Interface
- Aumentada a altura dos dois cards em RESULTADOS RECENTES: 88 dp em telas muito compactas, 100 dp em compactas e 112 dp no layout padrão.
- Mantidos os dois cards lado a lado e os dados/ações existentes.

## Inteligência financeira da IA
- Política estratégica fixa: 40% carro da próxima temporada, 40% desenvolvimento do carro atual e 20% instalações.
- A reserva do próximo carro passa a ser constante em 40% do caixa disponível em cada decisão, respeitando sempre folha, custos de corrida, obrigações e projeção financeira.
- O investimento acumulado no próximo carro passa a respeitar a alocação anual de 40% do envelope técnico (80M€ sobre 200M€), além do teto absoluto histórico de 150M€.
- P&D do carro atual fica limitado a 40% do teto técnico anual (80M€).
- Melhorias de instalações ficam limitadas a 20% do teto técnico anual (40M€).
- Nenhuma das três alocações pode consumir a parcela das outras categorias; saldo não utilizado não é convertido automaticamente para instalações.

## Compatibilidade
- Mantida a identidade pública F1 Team Manager V30 e o nome original do ZIP.
- Base V669; versão interna 670 / 0.670.0.
