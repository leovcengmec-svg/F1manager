# V449 — Correções de compilação

- Corrigida a expressão `Modifier.background` na tabela de efeito do investimento da tela Próximo Carro, fechando corretamente a chamada antes dos argumentos do `Row`.
- Adicionado o tratamento de retorno para `Screen.NEXT_CAR` no `BackHandler`, retornando à tela Carro/P&D e restaurando `Nav.CAR`.
- Preservados o motor de desenvolvimento, os dados financeiros, os assets externos e o histórico das versões anteriores.
- Versão Android atualizada para `versionCode 449` / `versionName 0.449.0`.
- Compilação Android ainda precisa ser executada em ambiente com Gradle e SDK Android configurados.
