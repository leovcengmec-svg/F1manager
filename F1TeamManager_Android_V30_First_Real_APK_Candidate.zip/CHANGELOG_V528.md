# V528 — vínculo de lançamentos de GP às 56 semanas

- O controle financeiro da temporada agora associa movimentações que identificam um GP à semana correspondente no calendário persistido da temporada, mesmo quando a descrição não inclui explicitamente `semana N`.
- Movimentações com semana explícita continuam usando essa semana; a semana inferida pelo calendário só é usada quando a descrição contém GP e não contém semana.
- Movimentações sem semana e sem GP continuam em “Outras movimentações”, sem inventar uma data.
- Mantidos o limite de 2.000 lançamentos, o histórico anterior e os assets.
- Não recupera lançamentos que já tenham sido descartados por versões anteriores.
