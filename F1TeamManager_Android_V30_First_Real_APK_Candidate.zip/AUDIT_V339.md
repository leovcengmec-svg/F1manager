# Auditoria V339 — Transferências de pilotos

## Causa confirmada
`CareerPreferences.currentDrivers()` devolvia `driverDefinition()` baseado em `WorldDatabase.allDrivers`, cujo `teamId` é estático. Mesmo após o motor de mercado executar e salvar contratos para a nova temporada, telas que consultavam `currentDrivers()` continuavam mostrando a equipe original.

## Correção
O método agora resolve a equipe a partir do contrato ativo (`activeIn(season)`) persistido no mercado. Agentes livres sem contrato recebem `teamId = 0`; o vínculo estático é usado apenas como fallback para saves antigos sem estado de mercado.

## Caminho da transição
`CareerPreferences.startNextSeason()` já chama `DriverMarketEngine.applySeasonTransition(...)` e salva o estado do mercado. V339 conecta esse estado canônico às definições de piloto consumidas pelas interfaces.

## Verificações
- Versão configurada: `versionCode 339`, `versionName 0.339.0`.
- Verificação estática do método e do ponto de transição realizada.
- Compilação Android e simulação real de temporada não executadas neste ambiente.
