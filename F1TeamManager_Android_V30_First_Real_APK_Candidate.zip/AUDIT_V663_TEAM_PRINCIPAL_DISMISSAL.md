# Auditoria V663 — demissão do Team Principal

A V662 utilizava uma base de apenas 2% para confiança 70–79 e 0% para 80–100, com poucos modificadores. Isso tornava a demissão rara demais, especialmente com confiança inicial em 75.

A V663 substitui essa lógica por uma avaliação composta:

| Fator | Como entra no risco |
|---|---|
| Confiança | Base de 4% a 90%, conforme a faixa de apoio |
| Posição final | Penalidade crescente conforme a distância para a meta |
| Corridas | Média das posições dos pilotos em todas as corridas arquivadas na temporada |
| Classificação | Média das posições dos pilotos em todas as sessões de quali arquivadas |
| Finanças | Caixa negativo ou abaixo da reserva-alvo aumenta a pressão |
| Evolução | Ausência de pesquisa concluída e peça fabricada disponível aumenta a pressão |
| Instalações | Não cumprir os objetivos de melhoria de instalações aumenta a pressão |
| Objetivos | Baixa taxa de conclusão aumenta a pressão |
| Reincidência | Duas temporadas seguidas abaixo da meta aumentam a pressão |

Com 75 de apoio, posição dentro da meta e métricas neutras, o risco exibido parte de 26%; uma temporada ruim em várias dimensões pode elevá-lo para patamares severos. Bons resultados, caixa saudável, desenvolvimento e investimentos reduzem a pressão ao melhorar apoio e desempenho.

A pontuação esportiva usa o objetivo de construtores para estimar a posição esperada dos pilotos. A ausência de histórico de corrida/classificação é tratada como neutra, não como falha.

A decisão continua ocorrendo no fechamento da temporada, mantendo o fluxo de propostas e transição de equipe já existente.
