# F1 Team Manager V567 — 0.567.0

## Apuração dos pontos dos construtores
- Adicionado `ConstructorRacePoints`, agregador determinístico de pontos por ID de equipe.
- A associação por contrato ativo do piloto tem prioridade sobre o nome exibido da equipe, evitando que nomes antigos ou repetidos atribuam pontos à equipe errada.
- Equipes personalizadas com IDs fora dos intervalos históricos são suportadas pelo agregador.
- Há fallback opcional por nome para saves antigos sem mapa de contratos; pilotos sem equipe resolvida são ignorados, sem atribuição especulativa.
- Incluídos testes para soma dos dois pilotos, IDs personalizados, prioridade do contrato e fallback de legado.
- Versão Android atualizada para `versionCode = 567` e `versionName = 0.567.0`.

## Validação
- Estrutura do ZIP verificada após empacotamento.
- Testes adicionados, mas não executados; compilação Android e simulação integrada de temporadas não executadas neste ambiente.
