# V567 — Correção de fotos de pilotos

- Corrigida a resolução das fotos externas de Franco Colapinto (ID 12), Heikki Kovalainen (ID 57) e Bruce McLaren (ID 66).
- Para esses três IDs, a busca prioriza nomes de arquivo derivados do nome real do piloto e não usa arquivos numéricos potencialmente associados a outra pessoa.
- Os demais pilotos mantêm a busca por ID permanente antes do nome, preservando a compatibilidade com os packs existentes.
- Local esperado: `Pictures/F1Manager/Assets/drivers/`. Arquivos de imagem continuam externos ao APK.
