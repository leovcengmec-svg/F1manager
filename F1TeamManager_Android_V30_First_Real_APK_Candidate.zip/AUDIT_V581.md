# Auditoria V581 — Evolução de agentes livres

## Alterações verificadas por inspeção

- `CareerPreferences.applyDriverRaceEvolution` continua percorrendo `WorldDatabase.allDrivers`, e não somente os IDs do grid; isso inclui pilotos reservas e pilotos personalizados conhecidos pelo catálogo.
- A evolução fora do grid permanece ativa com fator `0.70`, agora nomeado em `DriverEvolutionEngine.OFF_GRID_PROGRESSION_MULTIPLIER`.
- O estado de mercado é obtido uma vez por ciclo de GP; os agentes livres efetivos são calculados com `DriverMarketEngine.freeAgents`.
- `DriverEvolutionEngine.evolutionNotice` publica ganho de Overall para agentes livres e registra ganhos positivos de atributos mesmo quando a média inteira (Overall) não muda.
- A persistência existente de atributos, fases, bancos fracionários e marcador idempotente por GP foi mantida.

## Testes adicionados

`DriverEvolutionFreeAgentV581Test.kt` cobre cinco cenários: ganho de Overall do agente livre; ganho de atributo com Overall constante; ausência de notícia de atributo para contratado sem ganho de Overall; ausência de falso positivo quando nenhum atributo sobe; fator de evolução fora do grid.

## Preservação

- Alteração focada em evolução e notícias de mercado.
- Nenhum asset ou histórico de versões foi intencionalmente removido.
- A compilação Android integral e a execução da suíte JUnit dependem de ambiente Gradle/Android e não foram realizadas nesta auditoria.
