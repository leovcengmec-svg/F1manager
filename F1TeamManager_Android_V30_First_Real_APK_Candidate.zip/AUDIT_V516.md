# Auditoria V516

Escopo: tela Carregar Jogo / gerenciamento de saves.

- Seleção: caminho do save fica explicitamente selecionado e visualmente destacado.
- Exportação: lê o JSON do save selecionado e grava esse conteúdo no documento escolhido pelo usuário.
- Carregamento: ação dedicada por save, sem conflitar com seleção para exportação.
- Exclusão: confirmação explícita antes de remover o arquivo local; erro informado se a remoção falhar.
- Consistência: seleção removida quando o arquivo selecionado é excluído.
- Segurança: fluxo de importação/validação existente preservado.
- ZIP: verificar integridade após empacotamento.
- Limitação: compilação Android e testes JUnit não executados por ausência de Gradle no ambiente.
