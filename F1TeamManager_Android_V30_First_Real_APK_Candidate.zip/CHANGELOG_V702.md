# V702 — programas individuais da IA, margem de classe e contratos

## Desenvolvimento de pilotos
- A IA passa a manter uma fila persistente por equipe para programas individuais de desenvolvimento.
- A fila é armazenada dentro do estado canônico do mercado e acompanha saves, reinício do aplicativo e virada de temporada.
- A IA usa o mesmo `DriverDevelopmentEngine` do jogador: mesma tabela de pontos, duração, vagas por nível, potencial individual e limite anual por perfil.
- A seleção prioriza pilotos contratados com maior diferença entre potencial e Overall atual, favorecendo idades mais propícias e perfis de alto crescimento; não inicia novos programas quando o limite anual de todos os atributos já foi consumido.
- Os programas avançam pelo tempo real decorrido no calendário entre GPs, não por um tick fixo por corrida.
- Conclusões geram notícia com equipe, piloto e pontos efetivamente aplicados.
- Crescimento passivo por nível da instalação foi removido para jogador e IA. Instalações oferecem apenas capacidade e programas explícitos.

## Teto de classe e desempenho
- A evolução natural por desempenho pode ultrapassar o teto da classe em até 3 pontos quando a média de desempenho da temporada for excepcional: 110–119,99 = +1; 120–129,99 = +2; 130+ = +3.
- A margem não altera a classe, não substitui a revisão bienal e não ultrapassa o potencial individual nem Overall 100.
- O programa de instalação continua sendo a única exceção que permite ultrapassar o teto de classe independentemente dessa margem, respeitando potencial, limite anual e atributo máximo.

## Contratos da IA
- Todas as rotas de oferta, renovação e fechamento de vagas usam planejamento de duração entre 1 e 5 anos.
- Jovens de alto potencial podem receber contratos de 4–5 anos; pilotos no auge normalmente 2–4; veteranos tendem a 1–2 anos.
- Duração é determinística por piloto/temporada/semana, mas varia entre decisões e não fica concentrada em 1 ano.

## Limites preservados
- Classe continua sendo revista a cada duas temporadas completas.
- Lenda continua exigindo título mundial e permanece permanente.
- Idade continua controlando evolução/regressão natural; programas não alteram idade, classe ou perfil de evolução.
