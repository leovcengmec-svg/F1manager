# V438 — Rebalanceamento do custo operacional por GP

- Introduz política compartilhada de custo operacional por GP, escalonada pelo nível inicial da equipe: Forte €2,2M; Médio €1,7M; Fraco €1,2M.
- Aplica a mesma regra à IA e à equipe do jogador, mantendo o adicional de €450 mil em caso de abandono (DNF).
- Adiciona testes Kotlin para a tabela de custos e para a reserva operacional parametrizada.
- Atualiza o stress test financeiro de cinco temporadas para usar os novos custos.
- Mantém o limite cumulativo de investimento no carro da próxima temporada e os dados persistidos existentes.

## Limitações

A compilação Android, JUnit e simulação integrada do motor completo não foram executadas neste ambiente por ausência de Gradle/Android SDK. Os números do stress test ainda usam salários e receitas de patrocínio representativos, explicitamente declarados no script.
