# V423 — Referência individual por Overall

- Criada uma tabela explícita de 61 referências financeiras, uma para cada Overall inteiro de 40 a 100.
- Cada pontuação tem um valor próprio, crescente, com granularidade de €100.000.
- Mantidos os limites: Overall 40 = €8.000.000; Overall 100 = €150.000.000.
- A classe de desempenho continua separada da referência financeira.
- Adicionado teste-fonte garantindo 61 valores distintos e estritamente crescentes.
- Nenhuma alteração de layout.
