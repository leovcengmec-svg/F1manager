# V142 — Legacy Test/Cleanup

- Preserves the V141 official gameplay architecture and all functional systems.
- Corrects source-path assumptions in legacy architecture/regression tests from `src/main/java/...` to `app/src/main/java/...`.
- Removes obsolete root-level one-off audit/test scripts that were outside the Android source/test tree and no longer participate in the project build.
- Removes Python cache generated during historical maintenance.
- Does not remove historical `docs/` or version/audit markdown records.
- Does not alter approved game rules or production gameplay logic.
