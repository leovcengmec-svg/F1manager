# Auditoria V313 — Notícias de evolução de pilotos

## Correções
- A geração por GP compara `DriverProfileCatalog.overall(currentAttrs)` com o Overall após o tick. Só cria notícia se `afterOverall > beforeOverall`.
- A mensagem contém nome do piloto, equipe ativa no momento do evento, número do GP, Overall anterior e novo e ganho positivo.
- Mantida a proteção de idempotência por rodada (`driverEvolutionProcessedRounds`) e deduplicação de notícia por temporada/semana/categoria/mensagem.
- A retenção de notificações foi elevada para 1000 nas operações de acréscimo e na normalização persistida, reduzindo o risco de expulsar notícias de evolução por excesso de eventos de outras categorias. Scouting continua limitado a 200.

## Limitação
A retenção não recupera retroativamente notícias que já tenham sido descartadas em saves antigos, nem reprocessa rodadas já marcadas como concluídas. A validação foi estática; não houve build Android ou simulação em dispositivo.
