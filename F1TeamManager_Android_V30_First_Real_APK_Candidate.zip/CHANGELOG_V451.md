# V451 — Melhor distribuição dos cards de seleção de equipe

- Reorganizado o card de cada equipe para aproveitar a largura total disponível.
- Cabeçalho mantém escudo/logo, nome, nível e botão ESCOLHER.
- Overall, confiabilidade e os dois pilotos agora ocupam uma segunda linha que atravessa a largura do card, liberando espaço para os nomes dos pilotos.
- Aumentado levemente o tamanho dos textos de métricas e aplicado truncamento por reticências para evitar corte abrupto.
- Preservados filtros, ordenação, seleção de equipe, dados de pilotos, assets e demais sistemas.
- Versão Android: `versionCode 451`, `versionName 0.451.0`.
- Validação estática e integridade do ZIP executadas; compilação Android e teste visual no dispositivo ainda pendentes.
