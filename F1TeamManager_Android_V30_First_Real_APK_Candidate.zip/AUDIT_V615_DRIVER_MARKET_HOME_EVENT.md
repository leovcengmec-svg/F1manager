# Auditoria V615 — Card de abertura da janela de transferência

## Causa
A HOME calculava o card da janela diretamente a partir de `currentWeek`. Não existia uma notificação persistente para a abertura real do mercado. Isso tornava o aviso dependente da recomposição visual e não oferecia recuperação de um save em que o mercado já estivesse aberto.

## Correção
- Adicionada `DriverMarketWindowNotificationPolicy`, que cria uma única notificação por temporada quando o mercado está aberto e não existe aviso previamente registrado.
- O avanço semanal registra o aviso no estado do mercado antes de salvar o pacote da progressão do calendário.
- O efeito de recuperação da carreira garante a notificação em saves existentes cujo mercado já esteja aberto.
- A HOME mostra o card apenas quando existe a notificação de abertura não lida da temporada atual; a mensagem inclui o nome da equipe do jogador.
- Ao selecionar `ABRIR MERCADO`, a HOME marca a notificação como lida e navega para o mercado.
- A Central de Notícias classifica o evento como `MERCADO DE PILOTOS` e usa a arte já existente `notice_market_offer`.
- Não foi criada imagem nova nem alterada a regra de elegibilidade do mercado; a condição de abertura continua centralizada em `DriverMarketEngine.marketOpen`.

## Testes direcionados
Teste adicionado em `app/src/test/kotlin/com/f1teammanager/DriverMarketWindowHomeEventV615Test.kt`:
- janela fechada não gera evento;
- abertura gera notificação importante na categoria Mercado;
- recuperação repetida não duplica a notificação;
- evento da temporada anterior não suprime o evento da nova temporada;
- uma notificação já registrada não é recriada.

## Limites de validação
- Executada validação Kotlin isolada da política e smoke tests de idempotência.
- Executadas verificações estáticas da ligação entre o avanço semanal, a recuperação da carreira e o card da HOME.
- A compilação Android completa, JUnit oficial e teste em dispositivo/emulador não foram executados; este ambiente não tem Gradle instalado e o pacote não contém Gradle Wrapper.
