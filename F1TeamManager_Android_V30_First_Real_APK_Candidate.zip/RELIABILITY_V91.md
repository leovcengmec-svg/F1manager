# V91 — Confiabilidade das 6 peças

## Cadeia
P&D → Fábrica → peça física → Carro 1/Carro 2 → GP.

A corrida usa a confiabilidade individual da peça física. `TeamCarState` continua fora da fonte de corrida.

## Faixas de fábrica
- Muito baixa: 40–51
- Baixa: 52–63
- Média: 64–75
- Alta: 76–87
- Muito alta: 88–100
- 0 só existe como estado de falha durante o GP.

## Cálculo por volta
A cada volta, para cada componente:
- desgaste normal = `0,12 + (100 - confiabilidade_de_fábrica) × 0,001`
- margem dinâmica por volta:
  - Motor/Chassi/Freios: 0,90–1,10
  - demais peças: 0,80–1,20
- evento de esforço anormal: probabilidade base `0,005 + (100 - confiabilidade_de_fábrica) × 0,00007`, ajustada pelo `reliabilityRisk` do circuito; quando ocorre, acrescenta 8–25 pontos de degradação.

A margem é sorteada novamente em cada volta. Portanto, um GP de 44 voltas faz 44 cálculos e um GP de 78 voltas faz 78 cálculos. Não existe vida fixa em voltas.

## Desempenho
A perda gradual é calculada sobre o tempo médio de referência do GP. O máximo em confiabilidade 0 é:
- Motor 0,40%
- Chassi 0,35% + 0,80% adicional enquanto o carro continua após falha de chassi
- Asa dianteira 0,25%
- Asa traseira 0,20%
- Freios 0,30%
- Unidade elétrica 0,20%

Máximo gradual acumulado das seis peças: 1,70%, antes da penalidade especial do chassi em 0.

## Consequências em 0
- Motor → DFN
- Chassi → grande perda de desempenho; se faltarem até 20% das voltas, DFN
- Asa dianteira → pit-stop automático restaura para a confiabilidade de fábrica
- Asa traseira → perde DRS
- Freios → DFN
- Unidade de potência elétrica → perde ERS

## Reset
A degradação é apenas do estado da corrida. No GP seguinte, a peça volta a começar com sua confiabilidade de fábrica, porque o `RaceParticipant` é reconstruído a partir do Garage físico.

## Validação
- Núcleo Kotlin recompilado sem erros.
- Falhas individuais observadas para motor, chassi, freios, asa dianteira, asa traseira e unidade elétrica.
- Asa dianteira confirmou restauração no pit.
- Asa traseira confirmou perda de DRS.
- Unidade elétrica confirmou perda de ERS.
- Acidentes foram mantidos separados da confiabilidade; o antigo teste mecânico genérico baseado apenas em `RaceParticipant.reliability` foi removido da corrida.
- Combustível e pneus continuam em suas cadeias existentes e não são reabastecidos pelo pit.
- `versionCode=91`, `versionName=0.91.0`.
