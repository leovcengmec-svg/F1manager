# V333 — Nomenclatura dos componentes de potência

- Substituídos em toda a interface e nas mensagens atuais do jogo os rótulos `Unidade de potência` / `Unidade de potência elétrica` por `Motor - ICE` / `MGU-K - ERS`.
- Aplicado em P&D, desenvolvimento, fábrica, evolução de equipes, resumo dos carros e eventos de corrida.
- Mantidos os identificadores internos `CarComponent.ENGINE` e `CarComponent.ELECTRIC_POWER_UNIT`; nenhuma regra, atributo ou cálculo mecânico foi alterado.
- O parser de notícias continua reconhecendo os nomes antigos para preservar a leitura do histórico existente.
- Versionamento Android: `versionCode 333`, `versionName 0.333.0`.
