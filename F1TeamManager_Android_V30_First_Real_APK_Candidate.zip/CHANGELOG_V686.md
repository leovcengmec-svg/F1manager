# v686 — Eventos completos de negociação e falhas de P&D na Home

- Todas as etapas das negociações da equipe do jogador passam a gerar cards na Home.
- Inclui propostas enviadas, recusas, contrapropostas recebidas e enviadas, encerramentos e propostas não concluídas.
- A IA permanece fora dos cards individuais de negociação da Home do jogador.
- Reforçada a trilha de notificação de falha de P&D, com persistência no salvamento atômico da progressão semanal.
- Mantidas as regras de sucesso/falha de P&D e demais sistemas da v685.
