from pathlib import Path
p=Path('/mnt/data/f1nationedit/app/src/main/java/com/f1teammanager/core/season/SeasonModels.kt')
s=p.read_text()
s=s.replace('val electricPowerUnit:Int=engine\n)', 'val electricPowerUnit:Int=engine,\n    val country:String=""\n)')
s=s.replace('val driverClass:String="Médio", val evolution:String="Normal"\n)', 'val driverClass:String="Médio", val evolution:String="Normal", val country:String=""\n)')
p.write_text(s)

p=Path('/mnt/data/f1nationedit/app/src/main/java/com/f1teammanager/core/season/WorldDatabase.kt')
s=p.read_text()
team_map={
1:'Itália',2:'Reino Unido',3:'Reino Unido',4:'Alemanha',5:'Áustria',6:'Reino Unido',7:'França',8:'Reino Unido',9:'Reino Unido',10:'Reino Unido',11:'Reino Unido',12:'Irlanda',13:'Itália',14:'Itália',15:'Suíça',16:'Alemanha',17:'Itália',18:'Reino Unido',19:'Índia',20:'Reino Unido',21:'Reino Unido',22:'Japão',23:'Japão',24:'Reino Unido',25:'Reino Unido',26:'Reino Unido',27:'França',28:'Reino Unido',29:'Reino Unido',30:'Itália',31:'Alemanha',32:'Estados Unidos',33:'França',34:'Malásia',35:'Alemanha',36:'Japão',37:'Estados Unidos',38:'Espanha',39:'Reino Unido',40:'Nova Zelândia'}
driver_map={
'Charles Leclerc':'Mônaco','Lewis Hamilton':'Reino Unido','Lando Norris':'Reino Unido','Oscar Piastri':'Austrália','Carlos Sainz':'Espanha','Alexander Albon':'Tailândia','George Russell':'Reino Unido','Kimi Antonelli':'Itália','Max Verstappen':'Países Baixos','Isack Hadjar':'França','Michael Schumacher':'Alemanha','Rafael Câmara':'Brasil','Pierre Gasly':'França','Franco Colapinto':'Argentina','Ayrton Senna':'Brasil','Nikola Tsolov':'Bulgária','Alain Prost':'França','Gabriele Minì':'Itália','Sebastian Vettel':'Alemanha','Martinius Stenshorne':'Noruega','Jenson Button':'Reino Unido','Alexander Dunne':'Irlanda','Nico Rosberg':'Alemanha','Dino Beganovic':'Suécia','Mika Häkkinen':'Finlândia','Oliver Goethe':'Alemanha','Liam Lawson':'Nova Zelândia','Arvid Lindblad':'Reino Unido','Nico Hülkenberg':'Alemanha','Gabriel Bortoleto':'Brasil','Nigel Mansell':'Reino Unido','Sebastian Montoya':'Colômbia','Nelson Piquet':'Brasil','Mari Boya':'Espanha','Fernando Alonso':'Espanha','Lance Stroll':'Canadá','Niki Lauda':'Áustria','Joshua Dürksen':'Paraguai','James Hunt':'Reino Unido','Ritomo Miyata':'Japão','Emerson Fittipaldi':'Brasil','Noel León':'México','Jackie Stewart':'Reino Unido','Roman Bilinski':'Polônia','Jim Clark':'Reino Unido','Tuukka Taponen':'Finlândia','Juan Manuel Fangio':'Argentina','Ugo Ugochukwu':'Estados Unidos','Jack Brabham':'Austrália','Freddie Slater':'Reino Unido','Mario Andretti':'Estados Unidos','Théophile Naël':'França','Damon Hill':'Reino Unido','Noah Strømsted':'Dinamarca','Kimi Räikkönen':'Finlândia','Matteo De Palo':'Itália','Felipe Massa':'Brasil','Mattia Colnaghi':'Itália','Rubens Barrichello':'Brasil','Enzo Deligny':'França','Mark Webber':'Austrália','Brando Badoer':'Itália','Juan Pablo Montoya':'Colômbia','James Wharton':'Austrália','Jacques Villeneuve':'Canadá','Alex Powell':'Estados Unidos','Esteban Ocon':'França','Oliver Bearman':'Reino Unido','Carlos Reutemann':'Argentina','Pedro Clerot':'Brasil','Gilles Villeneuve':'Canadá','Laurens van Hoepen':'Países Baixos','Sergio Pérez':'México','Valtteri Bottas':'Finlândia','Gerhard Berger':'Áustria','Taito Kato':'Japão','David Coulthard':'Reino Unido','Maciej Gładysz':'Polônia','Eddie Irvine':'Reino Unido','Jean Alesi':'França','Heinz-Harald Frentzen':'Alemanha','Jarno Trulli':'Itália','Nick Heidfeld':'Alemanha','Robert Kubica':'Polônia','Heikki Kovalainen':'Finlândia','Romain Grosjean':'França','Timo Glock':'Alemanha','Giancarlo Fisichella':'Itália','Takuma Sato':'Japão','Johnny Herbert':'Reino Unido','Riccardo Patrese':'Itália','Michele Alboreto':'Itália','Carlos Pace':'Brasil','Bruce McLaren':'Nova Zelândia','Olivier Panis':'França','Pedro de la Rosa':'Espanha','Adrian Sutil':'Alemanha','Paul di Resta':'Reino Unido','Pastor Maldonado':'Venezuela','Alexander Rossi':'Estados Unidos'}
# insert maps before teams
marker='    val teams: List<TeamDefinition> by lazy {'
team_lines='    private val teamCountry = mapOf(\n'+''.join(f'        {k} to "{v}",\n' for k,v in team_map.items())+'    )\n\n'
s=s.replace(marker,team_lines+marker)
# add country to TeamDefinition constructor after electricPowerUnit line
old='                electricPowerUnit=(s + 3 - (i%6)).coerceIn(1,100)\n            )'
new='                electricPowerUnit=(s + 3 - (i%6)).coerceIn(1,100),\n                country=teamCountry[i+1] ?: ""\n            )'
s=s.replace(old,new)
# driver country map
marker='    /** 80 pilotos titulares: exatamente 2 por equipe e, portanto, exatamente 80 no grid. */'
dmap='    private val driverCountry = mapOf(\n'+''.join(f'        "{k}" to "{v}",\n' for k,v in driver_map.items())+'    )\n\n'
s=s.replace(marker,dmap+marker)
old='DriverDefinition(id,name,t.id,a[0],a[1],a[2],a[3],a[4],a[5],a[6], if(id<=44) 70 else 35, p.driverClass, p.evolution)'
new='DriverDefinition(id,name,t.id,a[0],a[1],a[2],a[3],a[4],a[5],a[6], if(id<=44) 70 else 35, p.driverClass, p.evolution, driverCountry[name] ?: "")'
s=s.replace(old,new)
old='DriverDefinition(81 + index, name, 0, r[0], r[1], r[2], r[3], r[4], r[5], r[6], 72 - (index % 9), p.driverClass, p.evolution)'
new='DriverDefinition(81 + index, name, 0, r[0], r[1], r[2], r[3], r[4], r[5], r[6], 72 - (index % 9), p.driverClass, p.evolution, driverCountry[name] ?: "")'
s=s.replace(old,new)
p.write_text(s)
