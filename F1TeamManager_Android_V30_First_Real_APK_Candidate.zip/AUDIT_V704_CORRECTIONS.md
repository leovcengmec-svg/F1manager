# Auditoria das correções — V704

## Base e identificação
- Base de trabalho: revisão V703 recebida nesta conversa.
- Versão interna: `versionCode = 704`, `versionName = 0.704.0`.
- O nome público do aplicativo e o nome padrão do ZIP permanecem inalterados.

## Correções aplicadas

### Qualificação
- O Q1 inicial passa a montar o composto coerente com o clima: seco, composto seco; chuva leve/moderada, intermediário; chuva forte, WET.
- O avanço manual e o instantâneo compartilham a mesma linha do tempo de classificação, com checkpoints climáticos alinhados. Os resultados são reproduzíveis com a mesma base e semente.

### Ritmo automático dos pilotos
- Uma única política por volta decide Ataque, Equilibrado ou Poupar para todos os 80 pilotos, incluindo os dois pilotos da equipe do jogador.
- A decisão considera projeção de combustível para terminar a distância, reserva, desgaste dos pneus, clima, posição, fase da corrida, características individuais e proximidade de adversários.
- Ataque só é usado quando existe margem de combustível e pneus e uma oportunidade de disputa. Equilibrado é o padrão quando as margens estão limitadas. Poupar assume prioridade quando combustível ou pneus exigem preservação.
- O antigo perfil visual Defesa é apresentado como Poupar. O identificador interno `DEFENSE` foi mantido para preservar compatibilidade com dados e regras existentes. O atributo técnico Defesa do piloto não foi renomeado.
- A seleção manual de ritmo foi removida da tela da corrida. Os métodos antigos `setStrategy` e `setPlan(mode=...)` foram mantidos por compatibilidade, mas não alteram mais a decisão do piloto.
- Combustível crítico não pausa a corrida nem pede uma decisão de ritmo ao jogador. O piloto ativa Poupar automaticamente e envia um aviso de rádio.
- Em bandeira vermelha, o jogador escolhe somente plano e pneus da relargada. O ritmo continua automático.
- Os planos de pneus, compostos e confirmações de box continuam editáveis. Essa escolha de pneus é independente do perfil de ritmo automático.

## Verificações executadas
- Compilação Kotlin direcionada do motor atualizado `CareerWeekendEngine` e da política automática: aprovada.
- Qualificação acompanhada versus instantânea, mesmo seed e grid de 80 pilotos: aprovada, grid idêntico.
- Início de Q1 sob chuva: aprovado, chuva leve resultou em pneu intermediário.
- Simulação instantânea de corrida de 8 voltas: aprovada, concluiu 8/8.
- Simulação manual de corrida de 58 voltas com grid de 80 pilotos: aprovada, concluiu 58 voltas, registrou os três modos automáticos (Ataque, Equilibrado e Poupar), zero solicitações manuais de combustível crítico e 80 classificados.
- Teste de compatibilidade: chamadas antigas de `setStrategy` e `setPlan(mode=...)` não sobrescrevem o ritmo automático.
- Revisão estática: não restaram callbacks `setStrategy` ou estado `selectedMode` na `MainActivity`.

## Limitação de build
O ambiente de trabalho não contém `gradlew`, Gradle CLI nem Android SDK configurado. Por isso, não foi possível executar o build Android completo, a suíte JUnit integral ou gerar APK local nesta sessão. Os testes comportamentais acima foram executados por harness Kotlin direcionado contra o motor atualizado; isso não equivale a um build APK.
