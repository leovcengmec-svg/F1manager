# F1 Team Manager — V658

## Estratégias e gestão de pneus

- Modo manual: os pilotos da equipe do jogador passam a emitir recomendação de troca e abrir a decisão de pit stop a partir de 80% de desgaste. A escolha de permanecer na pista é respeitada sem repetir o mesmo alerta continuamente; a recomendação é rearmada após a troca de pneus.
- Plano automático: a troca por desgaste é acionada a partir de 85%, sem esperar o limite crítico anterior. A janela programada do plano e as correções obrigatórias por mudança de clima continuam válidas.
- A estimativa de vida útil dos pneus agora considera composto, clima, postura de condução e atributo de gestão de pneus do piloto. A interface informa o limite operacional correspondente ao modo manual ou automático.
- Os planos de chuva usam somente o composto adequado à intensidade da chuva e dimensionam cada stint para a janela de 85% de desgaste.
- Os planos secos passaram a ser classificados por tempo estimado de corrida, incluindo desempenho/degradação do composto e perda de 21 segundos por parada. Cada stint é limitado à janela operacional e a soma dos stints corresponde exatamente às voltas restantes.
- Corrigida a exibição dos stints: o último trecho não mostra mais a vida nominal completa do composto quando a corrida termina antes disso.
- Atualizados os testes de regressão de chuva e adicionadas verificações para soma exata das voltas, limite de desgaste e limiares distintos de 80%/85%.

## Versionamento

- Identidade pública preservada: **F1 Team Manager V30**.
- `versionCode = 658`.
- `versionName = "0.658.0"`.
- Nome padrão do ZIP preservado: `F1TeamManager_Android_V30_First_Real_APK_Candidate.zip`.
