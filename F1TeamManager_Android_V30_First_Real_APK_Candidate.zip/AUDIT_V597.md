# Auditoria V597 — Correção do build

## Falha reproduzida pelo log do GitHub Actions
`CustomWorldCatalog.kt:237`: `Unresolved reference: parsedPilots`; a referência `it` também falhava como erro derivado da expressão inválida.

## Causa raiz
`parsedPilots` existe no fluxo normal de leitura do catálogo, mas não no escopo local de `prepareRecovery()`. Nesse método, a coleção já validada chama-se `validPilotRows`.

## Correção
O cálculo de `nextRecoveredPilotId` usa `validPilotRows.maxOfOrNull { it.id }`, preservando a proteção contra colisão de IDs com a base oficial e com os pilotos válidos já recuperados.

## Validação
- Inspeção estática: referência antiga ausente do método de recuperação; referência nova presente.
- ZIP: será verificado com `unzip -t`.
- Build Android/JUnit: ainda precisa ser executado no GitHub Actions. O ambiente local não contém Gradle nem wrapper no projeto.
