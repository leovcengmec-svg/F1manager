# V736 — Mercado de Pilotos 2.0 e Ciclo de Carreira 16–45

## Interface e navegação

- Padronizados os botões IMPORTAR e EXPORTAR em CARREGAR JOGO, com dimensões equivalentes e rótulos curtos.
- Mantidas as rotas de importação, exportação da carreira ativa e exportação do save histórico selecionado.
- Removidos os quatro cards estatísticos do topo do Mercado de Pilotos; substituídos por cabeçalho compacto com total de pilotos, equipes e temporada.
- Mensagens do mercado exibidas em Snackbar temporária, com encerramento automático após aproximadamente três segundos.
- Incluída ordenação por Overall, Nome, Idade e Classe, com direção ascendente/descendente.
- Incluídos filtros por faixa etária e classe, preservando os filtros por situação.
- Pesquisa, filtros, critério/direção de ordenação, piloto destacado, vaga de reposição selecionada e rolagem ficam associados à carreira/equipe e sobrevivem à navegação para a ficha do piloto.
- Removida a seção de contratos assinados da lista do Mercado de Pilotos. Contrapropostas, propostas recebidas e negociações que exigem decisão continuam disponíveis.

## Notícias de assinatura

- A lista de notificações passou a persistir opcionalmente `driverId`, `fromTeamId`, `toTeamId` e `contractYears`.
- A leitura continua aceitando registros antigos sem os novos campos.
- Notícias estruturadas exibem foto do piloto, equipes de origem/destino, temporada de início e duração. Pilotos sem equipe anterior são apresentados como SEM EQUIPE; renovações são identificadas separadamente.
- A notificação de renovação programada não é confundida com a assinatura efetiva; o evento estruturado é registrado quando o contrato futuro é concluído/aplicado.

## Inteligência de mercado

- A IA aumenta a prioridade de pilotos Lenda, Pro e Overall 85+ quando são uma melhoria esportiva compatível para a equipe.
- Oportunidades de elite elegíveis recebem tentativa prioritária na janela final de negociação.
- Renovações de titulares são reavaliadas quando existe upgrade de elite disponível.
- Restrições de idade são aplicadas no motor central de propostas, assinatura de contratos futuros, contrapropostas, ofertas recebidas, renovação, respostas automáticas e propostas da IA.

## Ciclo etário e contratos

- Início do novo ciclo alterado de 18 para 16 anos; a temporada aos 45 é concluída antes do retorno aos 16 no ano seguinte.
- Mantida a redução de 30% por atributo no evento de reinício, respeitando o piso de 40 e preservando identidade, classe e perfil de evolução.
- Contratos: 16–42 anos seguem a regra normal (até cinco anos); aos 43, até dois anos; aos 44, até um ano; aos 45, nenhuma renovação/contratação para o ano seguinte.
- Contratos antigos incompatíveis com o encerramento aos 45 são limitados/encerrados na virada; negociações futuras pendentes de pilotos de 45 anos são canceladas.
- Gráfico e rótulos da ficha foram atualizados para 16–45.
- Migração V736 alinha os índices etários sem reescrever atributos ou histórico já salvos.

## Versão

- `versionCode`: 736
- `versionName`: 0.736.0
- Nome público: F1 Team Manager V30
- Nome do ZIP: preservado conforme o pacote original.
## Correção de compilação após o primeiro Build Debug APK

- Corrigido o escopo do `SnackbarHost` no `DriverMarket`: o host passou a ser irmão da `Column` de conteúdo, diretamente no `Box` externo.
- `Modifier.align(Alignment.BottomCenter)` agora é resolvido no `BoxScope`, eliminando o erro Kotlin de receiver implícito reportado em `MainActivity.kt` durante `:app:compileDebugKotlin`.
- Mantidos o alinhamento inferior, a largura total, o espaçamento horizontal e a duração automática das mensagens.
