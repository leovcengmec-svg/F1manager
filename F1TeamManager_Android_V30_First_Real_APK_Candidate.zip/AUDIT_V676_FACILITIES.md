# Auditoria V676 — Instalações e integração de benefícios

## Escopo
Auditoria dos sete tipos de instalação, verificando o caminho entre nível, cálculo do benefício e aplicação em jogo para jogador e IA.

## Resultado por instalação

### Fábrica
- A fábrica do jogador usa `FactorySpecification` para capacidade paralela, máximo de unidades por ordem, tempo e custo.
- A simulação da IA agora usa a mesma especificação e `FactoryEngine.manufacturingWeeks` / `manufacturingCost`.
- Ordens da IA progridem independentemente e podem ficar simultaneamente em fabricação até a capacidade oficial. Designs completos aguardam em fila quando não existe vaga ou orçamento; não são descartados.

### Centro de P&D
- `ResearchEngine.activeProjectCapacity` é a regra única usada pelo jogador e pela IA: 1 projeto nos níveis 0–3, 2 nos níveis 4–7 e 3 nos níveis 8–10.
- Tempo, custo e faixa de ganho facility-aware são compartilhados. O ganho do P&D é universal; o Túnel de Vento acrescenta ganho aos componentes aerodinâmicos.
- A IA preserva designs concluídos em uma fila até que a fábrica possa iniciar a produção, mantendo a separação entre pesquisa, design, fabricação e instalação.
- A prévia da interface usa a mesma faixa de ganho aplicada ao projeto real.

### Túnel de Vento e Simulador
- `DynamicGridEngine` injeta um bônus fracionário na `RaceParticipant`; `PitwallPaceModel` aplica o modificador ao ritmo de carro compartilhado por classificação e corrida.
- Nível 10: Túnel de Vento +1,0% e Simulador +0,5% no modificador de ritmo do carro, antes da ponderação carro/piloto.
- Os valores físicos das peças permanecem inalterados; ganhos pequenos não desaparecem por arredondamento para inteiros.
- Ambos afetam jogador e IA porque a grade usa as instalações persistidas de cada equipe.

### Scouting
- Relatórios do jogador continuam usando `FacilityEngine.scoutingPrecision` para calcular margens.
- A IA recebe o mapa de instalações no mercado de pilotos e usa uma estimativa de Overall ponderada pela precisão da sua instalação nas decisões de renovação e contratação. Nível 10 revela o valor exato.
- O mapa de instalações é passado tanto no fluxo de carreira principal como no modo Team Principal.

### Desenvolvimento de Pilotos
- O fluxo normal de GP em `CareerPreferences.applyDriverRaceEvolution` recebe o estado da instalação da equipe atual de cada piloto contratado.
- O Team Principal aplica o mesmo fator através de `ManagerSeasonEngine`.
- A base é 100% no nível 0; cada nível aumenta 3 pontos percentuais, chegando a 130% no nível 10. Potencial, classe, redistribuição por atributo e limite anual continuam controlando o crescimento.
- Programas individuais continuam separados e respeitam duração, vagas e limites de atributo. Agentes livres não recebem benefício de uma equipe.

### Centro Comercial / Marketing
- `SponsorContractPricing.commercialMultiplier` é monotônico: 1,60 no nível 0 a 1,85 no nível 10, aumentando 0,025 por nível.
- A geração de novas ofertas usa o multiplicador; os contratos assinados permanecem imutáveis.
- Receita de loja e qualidade/categoria de patrocinador seguem vinculadas ao nível e o nível comercial das equipes IA é sincronizado com o motor de patrocínio.
- Corrigido o sentido do ajuste de qualidade no sorteio: o deslocamento agora é somado ao resultado aleatório, aumentando a chance da categoria mais forte já desbloqueada; os limites de nível continuam impedindo desbloqueios antecipados.

## Interface
- Cards exibem o benefício atual e a projeção do próximo nível usando o conjunto completo de instalações, para apresentar sinergias reais.
- O resumo do perfil da equipe agora inclui Desenvolvimento de Pilotos.

## Testes adicionados/atualizados
- Capacidade paralela e unidades por ordem da Fábrica nos 11 níveis.
- Capacidade simultânea de P&D nos 11 níveis, com uma única regra compartilhada.
- Ganho universal de P&D e ganho aerodinâmico adicional do Túnel de Vento.
- Crescimento passivo de pilotos (100%–130%) e estimativa de Scouting da IA (20%–100%).
- Bônus contínuo de ritmo em classificação e corrida, sem alteração dos atributos físicos.
- Progressão comercial monotônica; testes determinísticos verificam que o mesmo resultado-base pode cruzar o limite para a categoria superior com o aumento do nível, sem desbloquear categorias antes da hora.
- Progressão de tempo/custo/capacidade da Fábrica.
- Presença de efeito atual e próximo nível em todas as sete instalações.

## Limitação de validação
A auditoria de código e os testes foram adicionados/atualizados, mas não executados como suíte oficial neste ambiente porque não há `gradle` instalado nem `gradlew` no projeto. Não foi gerado APK localmente. O workflow `.github/workflows/android-apk.yml` está configurado para rodar testes unitários e `assembleDebug` no GitHub Actions.
