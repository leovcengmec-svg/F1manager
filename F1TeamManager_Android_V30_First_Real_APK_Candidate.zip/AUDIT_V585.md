# Auditoria V585

## Correções relacionadas ao log do GitHub Actions

1. `MainActivity.kt`: a chave de evento de áudio referenciava `round.round` antes da declaração de `round`, gerando `Unresolved reference 'round'`. Agora utiliza `roundIndex`, já declarado no escopo.
2. `MainActivity.kt`: `installedPieceVersions` não pertence ao modelo `TeamCarState`, causando `No parameter with name`. O argumento foi removido do `regulatedCar.copy`; os dois carros físicos continuam recebendo `baselineVersions` no `TeamGarage`.
3. Incrementada versão Android para `versionCode 585` / `versionName 0.585.0`.

## Limitações

O ZIP pode ser verificado estruturalmente, mas a compilação integral Android não foi executada neste ambiente. Executar novamente `Build Debug APK` no GitHub Actions e tratar quaisquer novos erros do compilador antes de considerar o APK validado.
