# V568 — Atualização de seis pilotos

- Substituído Oliver Goethe por Paul Aron no elenco inicial da Minardi, preservando o ID do piloto e a vaga da equipe.
- Substituído Taito Kato (referido no pedido como Taiko Kato) por Pyong Cris na Campos Racing, preservando o ID e a vaga.
- No mercado/reservas, Paul di Resta → Mick Schumacher; Johnny Herbert → Yuki Tsunoda; Olivier Panis → Ralf Schumacher; Timo Glock → Guanyu Zhou.
- Países, classe e evolução configurados conforme solicitado:
  - Mick Schumacher — Alemanha, Forte, Auge moderado.
  - Yuki Tsunoda — Japão, Forte, Auge moderado.
  - Ralf Schumacher — Alemanha, Forte, Auge moderado.
  - Paul Aron — Estônia, Forte, Normal.
  - Guanyu Zhou — China, Forte, Normal.
  - Pyong Cris — Coreia do Sul, Pro, Prodígio.
- Mantidos os IDs permanentes e a estrutura de 80 titulares + 20 pilotos de mercado.
- Atualizada a resolução de fotos para priorizar o nome nos seis IDs afetados, evitando que o arquivo numérico antigo exiba a foto do piloto substituído.
