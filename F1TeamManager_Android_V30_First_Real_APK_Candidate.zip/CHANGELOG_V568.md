# F1 Team Manager V568 — 0.568.0

- Persists constructor points per season and race round in career preferences.
- Replaying a finalized round replaces that round snapshot, preventing duplicate totals after recovery.
- Adds read APIs for per-round points and rebuilt season totals.
- Hooks persistence into the race-finalization journal so a failed save stops finalization rather than silently losing history.
- Keeps historical version files and external asset folders unchanged.

Validation: ZIP integrity checked. Android compilation and automated tests were not run in this environment.
