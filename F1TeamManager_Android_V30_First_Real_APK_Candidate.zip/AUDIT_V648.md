# Auditoria V648 — Integridade de corrida, histórico completo e recuperação

## Escopo

Atualização conjunta das quatro frentes solicitadas: outbox para resultado de corrida manual, backup/importação integral do histórico v2+v3, processamento fora da Main thread e política de recuperação de fim de semana interrompido.

## Alterações verificadas no código

1. `MainActivity.advanceRace()` valida o `RaceResult` e persiste `savePendingRaceFinalization(season, round, totalLaps, result)` antes de chamar `finalizeCompletedRace`. Em falha de persistência, não chama efeitos da carreira e mantém o resultado concluído em memória para retry.
2. `CareerPreferences` exporta schema 4 com `historicalArchiveBundle`; o bundle inclui o arquivo monolítico legado e shards de corridas e temporadas. O import valida conteúdo, checksums, nomes de caminho e limite total antes da substituição e compara a leitura de retorno.
3. `HistoricalDatabase` cria backup local e marcador durável durante a substituição dos arquivos históricos. `CareerPreferences` grava o diário coordenador antes de alterar preferências e só confirma `COMMITTED` depois de validar os dois lados; a inicialização recupera os dois componentes de forma coerente mesmo após encerramento inesperado.
4. `finalizeCompletedRace()` roda o diário de etapas em `Dispatchers.IO`; `startNextSeason()` chama a transição existente em `Dispatchers.Default`, mantendo a lógica de journal/rollback.
5. O início do fim de semana grava `active_weekend_session_checkpoint`. Na inicialização, a política distingue outbox pronto, corrida já finalizada e sessão incompleta. A sessão incompleta não é retomada a partir de um snapshot incompleto: é descartada sem pagar ou pontuar o GP.
6. A gravação, leitura, validação e exportação/importação de saves completos também foram colocadas em worker I/O.
7. O bônus de qualificação é tratado uma única vez no settlement de `FinanceEngine.applyRace`, sem crédito separado duplicado.

## Testes executáveis

- `tools/race_sim_test/v648_recovery_archive_audit.py`: verificações de contrato/estrutura da V648.
- `app/src/test/java/com/f1teammanager/core/race/WeekendSessionRecoveryPolicyV648Test.kt`: teste unitário das três decisões da política de recuperação.
- Validadores gerais e auditorias anteriores devem ser executados como regressão; algumas auditorias históricas estão intencionalmente fixadas em suas versões e não são aplicáveis literalmente à V648.

## Limitações de validação

O ambiente de edição não possui Gradle/Gradle Wrapper nem Android SDK. Portanto, não foi possível executar `assembleDebug`, `testDebugUnitTest`, gerar APK ou validar o comportamento em dispositivo Android. A auditoria estática e a compilação isolada do helper puro não substituem esses passos.
