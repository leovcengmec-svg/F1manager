# V584

- Ajustados os quatro cards de Grandes Acontecimentos da tela de fim de temporada.
- Imagens menores e com proporcao preservada (ContentScale.Fit), todas na mesma area.
- Descricoes longas agora podem ser lidas com rolagem vertical dentro do proprio card.
- Incluido teste de regressao do layout.
