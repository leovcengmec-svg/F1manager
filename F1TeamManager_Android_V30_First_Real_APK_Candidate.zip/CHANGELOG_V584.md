# V584 — Correção de compilação do APK

- Corrigida chamada inválida ao método de instância `DriverMarketEngine.freeAgents` em `CareerPreferences.kt`.
- Tipagem explícita de `freeAgentIds` como `Set<Int>`, removendo a cascata de erros de inferência e membership reportada pelo GitHub Actions.
- Mantido o comportamento de evolução e notificação dos agentes livres; nenhuma funcionalidade ou asset removido.
- Versão Android incrementada para 0.584.0.

Validação: correção estática confirmada. A compilação Android deve ser reexecutada no GitHub Actions para confirmar que não restam outros erros.
