# Auditoria V657 — Metas individuais e evolução de pilotos

## Alterações analisadas

- `DriverEvolutionEngine.buildIndividualTargets` ranqueia cada piloto ativo em duas dimensões: classificação (55% carro / 45% qualificação) e corrida (60% carro / 40% Overall).
- `Target` mantém centros distintos de classificação e corrida e expõe faixas de tolerância dinâmicas conforme a zona do grid.
- `gpPerformanceIndex(Target, ...)` avalia o resultado pela distância da faixa individual; resultados dentro da faixa recebem índice 105 (taxa normal de crescimento no motor) e somente resultados fora dela geram bônus/penalidade.
- `CareerPreferences` recalcula e persiste metas individuais a cada GP, usando carro atual e atributos atuais dos pilotos. Metas legadas `id:posição` são lidas para compatibilidade e migradas para o esquema V2. Na carreira nova, o alvo inicial é criado depois de salvar o carro e os contratos.
- `ManagerSeasonEngine` recalcula as expectativas a cada GP com a garagem real da equipe do jogador, os carros simulados das equipes de IA na semana corrente e os atributos atuais de cada piloto. A representação compacta de dois centros no mapa de save é compatível com o campo já existente; valores legados 1..80 são migrados automaticamente.
- O multiplicador compartilhado para pilotos livres passou de 0,90 para 1,20. O caminho de evolução continua sem fabricar resultados de corrida e continua respeitando potencial, classe e teto anual por atributo.

## Validações executadas e incluídas

- `DriverEvolutionEngine` compilado isoladamente com `kotlinc`: aprovado.
- Cinco métodos focados de `DriverIndividualTargetsV657Test` e `FreeDriverGrowthRateV657Test` compilados e executados: aprovados.
- Auditoria estática V657: 12/12 verificações aprovadas.
- `FreeDriverEvolutionV657Test` incluído como teste JUnit integrado de 30 GPs para o workflow do GitHub; não foi executado neste ambiente.

## Limitação de build

A compilação Android integral não foi executada neste ambiente porque Gradle/Android SDK não estão disponíveis localmente. O workflow Android do GitHub deve confirmar o build completo e gerar o APK.
