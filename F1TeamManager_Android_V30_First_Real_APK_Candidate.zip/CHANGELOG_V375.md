# Changelog V375 — Pré-validação completa da simulação instantânea

- O serviço de simulação agora valida roster completo antes de iniciar o motor: 80 pilotos únicos, 40 equipes, exatamente dois pilotos por equipe e nomes consistentes.
- A equipe do jogador deve ter exatamente dois participantes.
- O circuito é validado antes de alterar o estado do motor: ID, nome, voltas, tempo-base e riscos finitos no intervalo 0..1.
- Acrescentados dois testes de regressão para roster malformado e risco NaN, verificando que o motor permanece sem sessão iniciada.
- Atualizada a versão Android para 0.375.0.
- Sem alterações na interface, nos botões ou nos assets externos.
