# Auditoria V357 — evolução de pilotos

## Base
ZIP oficial da V356; histórico, assets e arquivos anteriores preservados.

## Alterações
- Marcador de processamento da evolução por `season:round` no estado de carreira.
- Guarda de replay em `ManagerSeasonEngine.applyDriverEvolution`.
- Testes unitários de regressão do marcador.

## Validação
- Verificação estrutural do ZIP após empacotamento.
- Build Android: não executado.
- JUnit: não executado.
- Simulação de temporadas completas: pendente.

## Limitação
O marcador previne replay quando já faz parte do estado restaurado. Se a persistência da carreira gravar atributos e marcador de forma não atômica, ainda pode existir janela de interrupção entre as gravações.
