# V385 — Correção do escopo da finalização de corrida

- Corrigido o fechamento prematuro do escopo em `MainActivity.kt` entre `finalizeCompletedRaceLocked` e `finalizeCompletedRace`.
- Os métodos `finalizeCompletedRace`, `advanceRace`, `simulateWeekendInstantlyForCareer` e `returnToCalendarAfterRace` permanecem no escopo que contém o estado da carreira (`store`, `round`, `screen`, `calendarMessage`).
- Mantidos os fluxos normal e instantâneo, sem alterações intencionais de layout ou assets.
- Versão Android: `0.385.0` (versionCode 385).
