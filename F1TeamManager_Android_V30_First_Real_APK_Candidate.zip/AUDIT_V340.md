# Auditoria V340 — Pontuação

- Fonte única da pontuação posicional: `core/race/ChampionshipEngine.kt`.
- 50 posições pontuam por colocação; P51+ recebem 0.
- P36–P40 recebem 3; P41–P45 recebem 2; P46–P50 recebem 1.
- Volta mais rápida concede +1 ao `fastestLapDriverId`.
- Pontuação de construtores é acumulada a partir de `result.points`, portanto soma os dois pilotos e inclui o bônus.
- Histórico de resultados antigos não é recalculado retroativamente; a regra passa a valer para resultados processados com esta versão.
- Não foi executada compilação Gradle nem simulação completa.
