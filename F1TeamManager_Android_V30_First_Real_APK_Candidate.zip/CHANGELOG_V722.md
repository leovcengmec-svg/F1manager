# V722 — Unified Overall × Investment Rule

VersionCode: 722  
VersionName: 0.722.0  
Base: V721

## Corrections
- Removed the AI-only €1M-to-one-component-point underinvestment penalty.
- All 40 teams now use the official Overall 40–100 × investment €8M–€150M table.
- Actual investment maps to the table's greatest fully funded Overall row.
- Annual underinvestment loss is capped at 10 Overall points relative to the previous season.
- Existing annual growth ceiling remains governed by `NextSeasonCarGrowthPolicy`.
- Player rollover, AI rollover, legacy-car rollover and next-car forecast use the same table and annual bounds.
- Preserved component identity, installed-piece state and reliability behavior of the existing physical builder.
- Replaced obsolete AI investment tests that encoded €1M = one point per component.
- Preserved V720/V721 features, including audio controls, stable ranking, event sequencing and facility persistence.

## Validation status
- Static source audit: see `AUDIT_V722_OVERALL_INVESTMENT.md`.
- Android Gradle compilation, JUnit execution and on-device career replay must be confirmed by GitHub Actions/device testing if Gradle/Android SDK are unavailable in the packaging environment.
