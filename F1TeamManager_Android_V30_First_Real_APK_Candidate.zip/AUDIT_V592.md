# Vistoria V592 — Menu principal

## Mapeamento realizado

- Entrada real: `app/src/main/java/com/f1teammanager/MainMenuScreen.kt`, função `MainMenuScreen`.
- Fundo: `R.drawable.menu_garage_background` em `drawable-nodpi/menu_garage_background.png`.
- Ações: callbacks existentes `onNewGame`, `onContinue`, `onSettings`; o botão continuar depende de `hasCareer`.
- Card compartilhado: `MenuOptionCard`, usado pelas três opções.
- Tela de configurações iniciais: `InitialSettingsScreen`, mantida fora da área alterada.

## Mudanças

- Layout principal recomposto para viewport fixa, sem `verticalScroll` nesta tela.
- Cabeçalho dimensionado com base na altura disponível e margens adaptáveis.
- Cards com largura, estrutura, proporções e espaçamentos padronizados; texto usa o espaço flexível entre ícone e seta.
- Contraste do fundo reforçado, borda grafite e acento vermelho consistentes.
- Área segura de status/navigation preservada.

## Limitações de validação

- ZIP validado estruturalmente após empacotamento.
- Não foi possível executar Gradle/Android build neste ambiente (sem Gradle instalado e sem Gradle Wrapper no projeto).
- Não foi possível fazer screenshot em dispositivo/emulador; a validação visual final deve ocorrer no Poco X7 Pro.
