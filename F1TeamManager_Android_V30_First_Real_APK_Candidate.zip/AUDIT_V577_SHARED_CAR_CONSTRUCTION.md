# Auditoria V577 — caminho comum de construção

## Alterações verificadas

1. `CarDevelopmentEngine.nextSeasonPhysicalComponentValue` é agora a função canônica compartilhada pelo jogador e pela IA.
2. `startNextSeason` usa a função comum para Carro 1 e Carro 2, mantendo valores físicos individuais e respeitando peças instaladas.
3. `AITeamDevelopmentEngine.carryAiGarageToNextSeason` usa a mesma função comum e passa o conhecimento técnico da equipe. A política atual da IA usa `CarDevelopmentFocus.BALANCED`.
4. O regulamento continua aplicado pelo orquestrador depois da construção, não dentro da função comum.
5. Versão Android atualizada para 0.577.0 (versionCode 577).

## Limitações

- Não foi executada compilação Android nesta sessão; o pacote-fonte não contém `gradlew`.
- A auditoria é estática; ainda é necessário executar os testes e simular a virada de temporada no Android.
- A IA atualmente utiliza foco equilibrado por política; não foi criado um seletor de foco individual para IA.
