# V505 — Paridade de acerto financeiro entre jogador e IA

- O acerto financeiro da IA agora aplica o mesmo premio de DNF (EUR 250.000) e o custo adicional de EUR 450.000 usado pelo jogador.
- Metas de corrida do patrocinador nao pagam quando todos os pilotos da equipe abandonam.
- O acerto financeiro da IA inclui bonus por meta de qualificacao, calculado com as faixas minima/maxima do contrato ativo.
- O fechamento do GP passa a enviar ao motor da IA o estado DNF, a melhor posicao de qualificacao e os pontos efetivamente marcados, tanto na finalizacao interativa quanto na simulacao headless.
- Preservados os marcadores de idempotencia do acerto por GP.
- Validacao realizada: inspecao estatica das alteracoes e integridade estrutural do ZIP. Compilacao e testes Gradle ainda pendentes.
