# V601 — Root audit: expanded grid, results pipeline and race latency

## Findings
- The race entry point builds participants from persisted driver-market contracts. Merely having 41 catalog teams does not guarantee an 82-driver grid.
- Catalog reconciliation previously retained contracts whose team ownership no longer matched the editable roster. A new/edited team could therefore exist in the catalog while the market still had a stale or incomplete grid; the race preflight would then fail before a result could be committed.
- `F1ManagerApp.participants()` replayed the AI technical/development simulation again immediately after `syncAiWeeklyState()` had already computed each AI team's physical garage for the same week. This duplicated a costly simulation pass as the number of teams increased.

## Changes
- Catalog roster is now authoritative for active grid ownership: stale unbound contracts are released to the free market, drivers assigned in the editable roster are contracted to that team, and contract terms for rostered drivers are retained when their team ID changes.
- Added a preflight diagnostic for teams with fewer than two active contracts in `DynamicGridEngine.validate`, instead of allowing an opaque failure later inside race startup.
- Reuse AI physical garages calculated by the weekly development pass for the race grid, with fallback simulation only when the cache does not match the current season/week.
- Added regression coverage for a 41-team/82-driver catalog, stale roster contracts, and free-agent consistency.

## Validation limits
- ZIP structure is checked in this environment.
- Android Gradle build, full JUnit suite, device profiling and a two-season end-to-end simulation were not executed here. The 41-team scenario still needs the repository's CI build and device test before this release can be called fully validated.
