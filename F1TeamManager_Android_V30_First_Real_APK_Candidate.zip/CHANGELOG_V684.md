# V684 — correção de compilação do painel de investimento

Base: V683
VersionCode: 684
VersionName: 0.684.0

## Correção
- Corrigida a referência não resolvida `managerState` no composable `Team` de `MainActivity.kt`.
- A Activity agora passa explicitamente `managerState.car.nextSeasonInvestment` para a tela da equipe.
- O composable `Team` calcula uma única vez o valor consolidado comprometido e o utiliza no texto, na barra de progresso, na cor do indicador e no saldo disponível.
- Eliminada a dependência de estado externo dentro do composable, evitando os erros Kotlin em cascata vistos no GitHub Actions (`Unresolved reference managerState` e o erro secundário de `compareTo`).

## Economia preservada
- Mantida integralmente a reformulação econômica da V683: curva do Centro Comercial, duração de contratos, envelope anual técnico de €200M e política de reserva da IA.
- Nenhuma alteração no nome público do jogo ou no nome padrão do ZIP.

## Validação
- Incluído teste estático de regressão para a passagem explícita do investimento no próximo carro à tela da equipe.
- A compilação APK precisa ser confirmada pelo GitHub Actions; este ambiente não possui Gradle/Gradle Wrapper executável.
