# Auditoria V433 — Checkpoints monotônicos da virada

## Correções
- `markSeasonTransitionStage` agora usa uma lista ordenada única de checkpoints.
- Uma chamada pode repetir o checkpoint atual (idempotência), avançar exatamente um estágio ou falhar; saltos e regressões são rejeitados.
- Corrigido o teste legado `SeasonTransitionV431IntegrationContractTest.kt`, que continha literais Kotlin com aspas internas sem escape.
- Adicionado `SeasonTransitionV433StageOrderTest.kt` para auditar a ordem e as regras de progressão.

## Limitações
- Não foi possível executar Gradle/JUnit completo ou build Android neste ambiente porque não há `gradlew` no projeto nem comando `gradle` instalado.
- Os testes novos são contratos estáticos e precisam ser executados na suíte real.
- A recuperação integral entre SharedPreferences e histórico/armazenamentos separados ainda exige teste de falha em dispositivo/emulador.
