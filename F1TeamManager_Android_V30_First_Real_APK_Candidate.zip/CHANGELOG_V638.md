# V638 (0.638.0) — Correção do bloqueio de troca de equipe no modo Team Principal

- Corrigido o bloqueio de avanço de temporada após aceitar uma proposta externa: a validação de elenco não exige que a equipe de destino já tenha dois contratos para a próxima temporada antes de executar o mercado de pré-temporada.
- A equipe contratante permanece pendente até a virada transacional; no rollover, o mercado de pilotos resolve contratos vencidos e preenche as vagas da equipe de destino durante a mesma transição persistente da temporada.
- O preenchimento automático fica restrito ao handoff Team Principal confirmado. Carreiras comuns continuam bloqueadas se o elenco projetado não tiver exatamente dois pilotos, sem atribuições artificiais.
- O mercado tenta completar o elenco da equipe entrante. Se o orçamento ou as negociações impedirem o preenchimento total, a virada ainda é concluída e uma notificação orienta o novo Team Principal a completar as vagas manualmente; a carreira não fica presa por falta de pilotos.
- Adicionados testes para o gate de elenco, conclusão automática do elenco entrante e aplicação do contrato somente na temporada seguinte.

