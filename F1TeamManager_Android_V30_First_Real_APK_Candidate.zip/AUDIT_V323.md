# Auditoria V323

## Problemas identificados na V322
1. O diálogo de instalação de uma peça podia aparecer antes do aviso de fabricação, pois a fila de avisos era bloqueada enquanto existia uma instalação pendente.
2. A Central de Notícias filtrava explicitamente os eventos `FABRICAÇÃO CONCLUÍDA`.
3. A Home e o painel do mercado reconheciam apenas títulos antigos de respostas; o motor atual publica títulos como `CONTRAPROPOSTA RECEBIDA`, `PROPOSTA RECUSADA` e `CONTRATO ASSINADO`.
4. O painel `OFERTAS RECEBIDAS` usava `emptyList()` e nunca mostrava as ofertas da IA.
5. O tick semanal da IA também enviava ofertas recebidas pelo jogador ao resolvedor automático de respostas, o que podia assinar/recusar uma oferta sem decisão do jogador.

## Correções em V323
- A notificação da peça é exibida primeiro; a decisão de instalação fica bloqueada até o aviso ser marcado como lido.
- A notificação de fabricação permanece disponível na Central de Notícias.
- Eventos de negociação atuais são reconhecidos na Home e no mercado, e recebem ilustração genérica específica.
- Ofertas de equipes da IA direcionadas a pilotos da equipe do jogador ficam pendentes para ação explícita do jogador.
- As quatro ilustrações foram incorporadas em `app/src/main/res/drawable-nodpi/` como WebP.

## Verificações realizadas
- ZIP de origem V322 aberto e integridade original verificada antes das alterações.
- Conferência estática dos caminhos de geração e apresentação das notificações.
- Conferência de referências aos quatro novos recursos drawable.
- Conferência de `versionCode = 323` e `versionName = 0.323.0`.
- Teste de integridade do ZIP de entrega executado após empacotamento.

## Limitação
A compilação Android e o teste de execução no aparelho não foram executados nesta sessão. Portanto, esta entrega não deve ser considerada compilada nem validada em dispositivo.
