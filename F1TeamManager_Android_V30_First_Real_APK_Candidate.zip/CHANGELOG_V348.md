# V348 — Ledger persistente de liquidação de GP

- `TeamFinanceState` agora mantém `raceSettlementKeys` separado do histórico limitado de transações.
- O fechamento financeiro do jogador e das equipes de IA consulta o ledger persistente, sem depender de marcadores ainda visíveis no histórico.
- O ledger do jogador é serializado no armazenamento de carreira.
- O snapshot das equipes de IA exporta/restaura o ledger como campo adicional, mantendo compatibilidade com snapshots antigos.
- Incluído teste unitário para repetição do mesmo GP após o histórico de transações ultrapassar 100 itens e para chaves distintas de GP.
- Nenhuma alteração de interface.

Validação realizada nesta entrega: inspeção estática e integridade do ZIP. Build Android e execução JUnit não foram realizados neste ambiente.
