# V593 — Mapeamento e refinamento do menu principal

- Mantida a integração na tela real `MainMenuScreen.kt`, chamada pelo fluxo `Screen.MAIN_MENU` em `MainActivity.kt`.
- Substituído o ícone genérico de bandeira por um ícone quadriculado desenhado em Canvas, mais próximo da referência aprovada.
- Aplicado recorte angular consistente aos cards para aproximar o desenho da referência sem alterar os callbacks existentes.
- Ajustado o comportamento de texto em largura limitada: o conteúdo usa o espaço flexível disponível e sinaliza truncamento com reticências, evitando corte abrupto.
- Mantidos os três cards com pesos iguais, dimensões responsivas, estado real `hasCareer`, navegação já existente e rolagem vertical desativada no menu principal.
- Versão do aplicativo elevada para `0.593.0` / código 593.
