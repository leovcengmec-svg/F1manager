# CHANGELOG V593 — Modo Time Principal

Base: V592 oficial (`versionCode 592`, `versionName 0.592.0`).
Nova versão: V593 (`versionCode 593`, `versionName 0.593.0`).

## Correções

- A aceitação de uma oferta de Team Principal agora agenda o contrato para a próxima temporada, sem trocar a equipe ativa durante a temporada atual.
- A ativação do contrato e a gravação do estado inicial da nova equipe acontecem dentro do diário transacional da virada de temporada. Falhas anteriores ao ponto de commit restauram a identidade anterior, os dados persistidos e a oferta pendente.
- Foi adicionado um snapshot transacional para operações de aceitação de oferta, com recuperação no início de `CareerPreferences` e rollback dos registros persistidos se houver falha.
- O painel distingue força inicial, última classificação confirmada e posição atual. Antes da primeira temporada usa o ranking inicial canônico; na pré-temporada seguinte preserva a classificação confirmada da equipe, inclusive depois de uma contratação externa, até a primeira corrida.
- `Melhor resultado` fica como `— / Aguardando resultado` até existir resultado registrado, em vez de usar a posição de força inicial como resultado esportivo.
- O estado serializado da carreira do Team Principal avançou para o esquema 2; a leitura do esquema 1 foi mantida, migrando saves antigos para calcular o melhor resultado a partir dos resultados de temporada disponíveis.
- A recuperação da virada passa a recompor o estado em memória da equipe realmente restaurada pelo diário, e consulta seu orçamento inicial pelo ID restaurado.

## Arquivos de código alterados

- `app/build.gradle.kts`
- `app/src/main/java/com/f1teammanager/CareerPreferences.kt`
- `app/src/main/java/com/f1teammanager/MainActivity.kt`
- `app/src/main/java/com/f1teammanager/core/manager/TeamPrincipalCareerEngine.kt`
- `app/src/test/java/com/f1teammanager/core/manager/V586TeamPrincipalCareerEngineTest.kt`
- `README.md` (versão atual documentada)

## Validação executada

- Os 13 métodos `@Test` de `V586TeamPrincipalCareerEngineTest.kt` foram compilados e executados com o motor `TeamPrincipalCareerEngine.kt` real, usando tipos auxiliares e uma implementação mínima compatível com as asserções JUnit apenas para rodar o teste sem o Gradle do projeto. Resultado: **PASS — 13 testes de regressão do motor** cobrindo modo ativo, estado inicial, round-trip de serialização, ranking inicial versus melhor resultado, compatibilidade com esquema 1, avaliação bienal, prestígio, idempotência, ofertas, contrato futuro sem reescrever identidade atual, histórico por equipe e renovação contratual.
- Verificação estática confirmou que a função de aceitação não grava o novo `teamId` ativo e que `activatePendingTeamPrincipalOffer` é chamada no caminho `PREPARED` da transação de virada.
- O ZIP final foi verificado estruturalmente com `unzip -t`.

## Limitação de validação

A compilação Android completa, a execução da suíte JUnit do Gradle e o teste integrado em emulador **não foram executados**: o pacote-base não inclui `gradlew`/Gradle Wrapper e o ambiente não disponibiliza `gradle` nem `adb`. Portanto, V593 é candidata corrigida; ainda não deve ser chamada de build Android homologada.
