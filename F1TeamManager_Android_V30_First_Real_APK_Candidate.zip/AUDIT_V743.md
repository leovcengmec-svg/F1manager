# Auditoria V743 — desenvolvimento de pilotos, P&D da IA, versões e mercado

## 1. Desenvolvimento de pilotos

`DriverDevelopmentState.normalized()` limpa `reservePoints`, preservando o campo apenas para compatibilidade com dados serializados antigos. `advanceWeeks()` utiliza apenas `DriverDevelopmentProgram.points`, distribui em atributos e descarta pontos bloqueados. O `Completion` sempre registra `reservedPoints = 0`. A lista de candidatos evita repetição de atributo dentro de cada passagem. O Overall não recebe escrita direta.

## 2. P&D da IA

`simulatePhysicalSeason()` mantém um estado de lote (`V1`, `V2`, fabricação). `beginBatch()` seleciona três componentes distintos, calcula duas rodadas de pesquisa e fabricação final para duas unidades (depois tenta uma) e só inicia quando o caixa e o teto técnico conseguem cobrir o compromisso estimado. A função não abre um novo lote até pesquisas, designs prontos e ordens de fábrica do lote atual serem concluídos. A fabricação alterna Carro 1/Carro 2 para ordens com duas unidades.

Resultados de pesquisa agora são persistidos no projeto: falha não gera design; sucesso parcial produz ganho reduzido; falha no V2 usa o V1 válido como fallback. Falha no V1 remove aquele componente do lote.

## 3. Reset de versão

`CarDevelopmentEngine.buildAiNextSeasonGarage()` reinicia a numeração de cada peça instalada para V0 nos dois carros, sem substituir performance, confiabilidade ou identidade de peça. `AITeamDevelopmentEngine` também normaliza checkpoints e simulações antigas para V0 no início da temporada. As transições do jogador já aplicam `baselineVersions` a ambos os carros.

## 4. Regulamento anual

`AnnualCarRegulationEngine.generate()` sorteia 1 mudança em 80% dos resultados ou 2 em 20%. A temporada 1 permanece isenta. A revolução decenal permanece exclusiva e substitui as mudanças anuais.

## 5. Taxas de contratação

Os fluxos normais de negociação continuam centralizados em `DriverMarketFinancialPolicy`. `applySeasonTransition()` passou a aceitar `teamFinances` e `teamFacilities`; os dois chamadores de transição (ManagerSeasonEngine e CareerPreferences) montam e passam esses mapas. `resolveExpiredAndVacancies()` calcula a taxa automática com o financeiro completo (incluindo obrigações) e instalações reais da equipe, em vez de classificar apenas pelo caixa.

## 6. Testes e limitações

Foram adicionados/atualizados testes para: exatamente dois pontos de nível 1 em dois atributos distintos; descarte de reservas legadas; ausência de reaproveitamento de pontos bloqueados; limites de orçamento e teto técnico da fabricação; distribuição de duas peças entre os dois carros; reset V0; e distribuição anual de regulamento.

**Limitação de validação:** não há Gradle instalado nem Gradle Wrapper no ZIP. A compilação Android completa e a suíte JUnit devem ser executadas no GitHub Actions. A integridade do ZIP e as auditorias estáticas locais serão verificadas antes da entrega.
