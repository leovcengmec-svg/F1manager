# V499 (0.499.0) — Swipe em toda a tela de gerenciamento de equipe

- Restaurado o gesto horizontal em toda a tela de gerenciamento de equipe, não apenas no card de cabeçalho.
- Arrastar para a esquerda seleciona a próxima equipe no ranking; arrastar para a direita seleciona a equipe anterior.
- O detector horizontal foi movido para o contêiner da tela e removido do card de cabeçalho, evitando duplicação do gesto.
- Mantidos os botões de navegação e a rolagem vertical da lista.
- Validação estrutural do código concluída; compilação Android não executada neste ambiente.
