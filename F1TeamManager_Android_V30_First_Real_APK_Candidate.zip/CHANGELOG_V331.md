# V331 — Modal de peça pronta padronizado

- Substituído o AlertDialog compacto por um modal Jetpack Compose personalizado alinhado à referência aprovada.
- Adicionada imagem genérica horizontal da fábrica/peça em `app/src/main/res/drawable-nodpi/factory_generic_piece.webp`.
- Reutilizado `TeamCarCompact` para manter a imagem real de cada equipe nos cards Carro 1 e Carro 2.
- Exibidos desempenho e confiabilidade da peça nova e os valores atuais correspondentes de cada carro.
- Padronizados os dois cards de carro e os dois botões de instalação.
- Sem rolagem vertical interna; layout compacto para a tela do POCO X7 Pro.
- Mantidos o fluxo obrigatório de instalação e os callbacks existentes `installPendingPiece`.
