# Auditoria V308

- [x] Nome oficial do ZIP preservado.
- [x] versionCode 308 / versionName 0.308.0.
- [x] Cabeçalho compacto e texto de equipe em uma linha.
- [x] Removido texto do país e do modelo do carro no cabeçalho.
- [x] Card Overall com altura mínima para valores.
- [x] Removida linha duplicada de limite técnico disponível.
- [x] Indicadores de temporada com ícones.
- [x] Histórico usa registros arquivados existentes e calcula pódios a partir das corridas registradas.
- [x] Histórico apresenta tabela horizontal incluindo nome da equipe.
- [ ] Build Debug APK no GitHub Actions.
- [ ] Teste visual no dispositivo.
