# V612 — Correção visual das imagens da tela de fim de temporada

- Banner “TEMPORADA ENCERRADA”: a fotografia genérica agora preenche todo o card, usando recorte proporcional (`ContentScale.Crop`) e uma camada escura em gradiente para preservar a leitura do texto.
- “OS GRANDES ACONTECIMENTOS”: as quatro imagens preenchem integralmente sua área visual, sem deformação; o excedente é recortado mantendo a proporção.
- As artes existentes foram mapeadas ao assunto correspondente: títulos/chegada, vitórias, abandonos sob bandeira amarela e luzes do grid/pole position. Nenhuma imagem nova foi criada e nenhum asset foi removido.
- Nenhuma alteração nos motores de simulação, dados de temporada, resultados ou processamento da corrida. A V609 permanece a referência de desempenho.
- Versão: `versionCode = 612`, `versionName = 0.612.0`.
