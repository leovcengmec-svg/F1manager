# Auditoria V539 — Instalações

## Correção nesta versão

O Centro de P&D, Túnel de Vento e Simulador tinham fórmulas centrais, mas a janela de pesquisa e o início do projeto não usavam o mesmo cálculo integral. Agora as opções usam `ResearchEngine.options(facilities, component, ranking)`, e o projeto iniciado calcula sua duração e custo a partir do mesmo estado de instalações.

## Caminhos verificados estaticamente

- Fábrica: `FactoryEngine` usa `FactorySpecification` para capacidade paralela, unidades por ordem, prazo e custo; conclusão gera peças pendentes de instalação, sem instalar automaticamente.
- P&D: duração e custo integram Centro de P&D, Túnel de Vento e Simulador; limite de pesquisas simultâneas continua ligado ao nível de P&D.
- Túnel de Vento e Simulador: modificadores são aplicados em `DynamicGridEngine` ao montar os participantes da simulação, sem alterar os valores físicos salvos das peças.
- Scouting: precisão altera a margem de erro gravada no relatório.
- Desenvolvimento de pilotos: a instalação alimenta a eficiência da evolução semanal e o nível determina capacidade, duração e pontos dos programas.
- Marketing: nível é passado para ofertas de patrocínio e determina a faixa de receita comercial semanal.
- Todas as instalações: manutenção semanal é cobrada por nível e possui controle de idempotência por temporada/semana.

## Limitações da validação

O ambiente desta sessão não dispõe de Gradle/Gradle Wrapper executável; não foi possível executar compilação Android nem testes JUnit. Não declarar o build validado até executar essas etapas em ambiente compatível.
