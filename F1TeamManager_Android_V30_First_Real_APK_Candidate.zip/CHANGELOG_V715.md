# V715 — correção de compilação do painel do último GP

Base: V714 / 0.714.0. Nome público F1 Team Manager V30 e nome original do ZIP preservados.

## Correção Kotlin
- O GitHub Actions da V714 falhou em `:app:compileDebugKotlin` porque `lastCompletedRace` é uma propriedade delegada por Compose (`by remember { mutableStateOf(...) }`) e o compilador não permite smart cast de propriedade delegada.
- Capturado o valor atual em `val completedRace = lastCompletedRace` antes da construção dos cards da Home.
- Todas as verificações de nulo e leituras do card Último Grande Prêmio usam a referência local imutável, eliminando os erros reportados nas linhas 3698–3699 e usos relacionados.
- A atualização assíncrona continua escrevendo em `lastCompletedRace`; a recomposição relê o estado e atualiza `completedRace`, sem alterar a lógica do histórico.

## Escopo preservado
- Nenhuma alteração nas regras de construtores, pilotos, finanças, histórico ou Acesso Rápido da V714.
- Nenhuma alteração em saves, backups ou motores de corrida.

## Validação
- Teste isolado do padrão Kotlin: smart cast através de propriedade delegada reproduz o erro; captura em local `val` compila.
- Auditoria estrutural da Home e contrato geral de release executados após a correção.
- A compilação Android integral e a suíte JUnit permanecem dependentes do GitHub Actions; o ambiente de edição não possui Gradle nem Android SDK.

- VersionCode 715 / VersionName 0.715.0; base V714.
