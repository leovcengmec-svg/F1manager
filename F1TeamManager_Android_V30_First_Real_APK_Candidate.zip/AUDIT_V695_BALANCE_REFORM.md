# Auditoria v695 — equilíbrio geral

## Diagnóstico que motivou a revisão
Os dados de teste mostraram carros com Overall muito elevado sem conversão proporcional em vitórias, alta concentração de pilotos Overall 90–100, ausência/insuficiência de notícias de regressão, equipes historicamente fortes no fundo do grid e saltos excessivamente rápidos de força entre temporadas.

## Alterações verificáveis no código

### Corrida
- `core/race/CarComponentInfluence.kt`: interpolação contínua para os seis componentes físicos, com diferenças graduais ao longo de 40–100.
- `core/race/PitwallPaceModel.kt`: os seis componentes entram no ritmo-base e cada circuito recebe uma sensibilidade distinta para potência, aerodinâmica, mecânica, frenagem e energia.
- `core/race/RaceModels.kt`: mistura de desempenho passa a 70/30 carro/piloto no seco, 60/40 em chuva leve/média e 55/45 em chuva forte.
- Resultado: carros superiores têm uma vantagem mais perceptível, mas classificação e corrida continuam afetadas por pilotos, pneus, clima, estratégia, confiabilidade e incidentes.

### Pilotos
- `core/season/DriverEvolutionEngine.kt`: idade sintética determinística por piloto, progressão de idade por temporada, redução do crescimento no auge e regressão natural de veteranos.
- A idade é derivada e não exige um novo campo serializado no save.
- `FREE_DRIVER_GROWTH_RATE` permanece em 0.45.
- `CareerPreferences.kt`: compara Overall anterior e posterior com `!=`; portanto, uma regressão também é publicada na Central de Notícias. A outbox durável impede que o evento seja perdido entre a gravação dos atributos e a publicação.
- `ManagerSeasonEngine.kt`: a simulação Team Principal também emite `DRIVER_EVOLUTION` ao detectar aumento ou queda.
- `DriverProfileCatalog.kt`: potenciais estimados para novos perfis têm ganhos menores; potenciais individuais explícitos não são sobrescritos.

### Equipes e finanças
- `TechnicalInvestmentEngine.kt`: ranking baseado em Overall físico atual, com fallback para o perfil inicial apenas quando ainda não há leitura dinâmica.
- `AITeamDevelopmentEngine.kt` e `AITeamFinancialEngine.kt`: registram/consultam a força atual para a estratégia financeira.
- `TeamSponsorshipEngine.kt`: utiliza ranking técnico vivo ao calcular a posição de força comercial.
- `CareerPreferences.kt`: limpa o registro global de Overall ao iniciar nova carreira ou modo Team Principal.
- Envelopes da v694 são preservados, sem aumentar os limites: €200M carro atual/instalações e €150M carro seguinte.

### Evolução técnica
- `CarDevelopmentEngine.kt`: desenvolvimento atual limitado por faixa de Overall e ganho reduzido à medida que a peça se aproxima de 100.
- `NextSeasonCarGrowthPolicy.kt`: ganho máximo anual do próximo carro limitado progressivamente (+7/+5/+2/+1 conforme Overall inicial).
- `ResearchEngine.kt`: ganhos de P&D sofrem retornos decrescentes por valor atual do componente.
- `FactoryEngine.kt` e `ResearchEngine.kt`: descontos de custo por ranking foram reduzidos para conter vantagens financeiras artificiais das equipes de baixa classificação.

## Limitações da validação
Esta revisão não foi executada em uma simulação integral de 10 temporadas com 40 equipes e várias sementes, nem compilada como APK Debug neste ambiente. Os módulos Kotlin puros de corrida e evolução foram compilados isoladamente e o smoke test de idade/regressão passou. A validação final de Android, JUnit e simulação longa permanece necessária no GitHub Actions.
