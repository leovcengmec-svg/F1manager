# Auditoria focada — mercado e desenvolvimento de pilotos V703

## Propostas da IA aos pilotos do jogador
- Candidato do jogador entra no pool quando `canReceiveProposals` é verdadeiro (contrato em último ano).
- Contrato plurianual do jogador não entra no pool; a IA não pode abordar no meio do contrato.
- A proposta é gravada como pendente com `fromTeamId` igual à equipe do jogador, `toTeamId` e `proposerTeamId` iguais à equipe IA e `relatedTeamId` igual à equipe do jogador.
- O prazo não representa resposta automática: vencimento remove a proposta e gera notícia de expiração; decisão continua com o jogador.

## Duração de contratos
- 1 a 5 anos continuam sendo o intervalo obrigatório.
- Potencial tem precedência sobre Overall atual nos grupos jovens/em desenvolvimento.
- 26–29 anos com potencial ≥90: 3–5 anos.
- 26–29 anos com potencial ≥85: 2–4 anos.
- A idade mais avançada reduz progressivamente a duração esperada.

## Desenvolvimento da IA
- Programas são armazenados por equipe. `reservePoints` passou a ser serializado no mesmo campo canônico.
- Saves V702 são lidos sem migração destrutiva: reservas ausentes iniciam vazias.
- Na transferência/saída, o programa ativo é removido da fila da equipe anterior; a vaga fica disponível e uma notícia é criada.
- Há limpeza defensiva antes do processamento de semanas, para cobrir mudanças de elenco que não passaram pelo fluxo normal de virada.
- Pontos reservados permanecem associados à fila/equipe e não são apagados ao cancelar um programa.

## Pendências de confirmação
- Executar a suíte JUnit e a compilação Android no GitHub Actions.
- Simular pelo menos 5 temporadas, conferindo propostas recebidas, contratos plurianuais, filas de desenvolvimento e transferências com programas ativos.
