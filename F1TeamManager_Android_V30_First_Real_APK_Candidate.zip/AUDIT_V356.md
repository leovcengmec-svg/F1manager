# Auditoria V356 — contratos de patrocínio

## Base
ZIP oficial recebido da V355; mantido o nome do pacote.

## Alterações
- Versão Android atualizada para 0.356.0 (versionCode 356).
- Adicionadas chaves de idempotência por equipe/temporada/rodada em `TeamSponsorshipEngine`.
- Chaves persistidas no snapshot, com compatibilidade de leitura para snapshots anteriores que não tenham o cabeçalho `@V356`.
- Testes adicionados para replay após snapshot restore e avanço da rodada seguinte.

## Limites de validação
- ZIP será verificado estruturalmente após empacotamento.
- Build Android e JUnit não foram executados: o pacote não contém `gradlew`/wrapper Gradle.
- Esta alteração impede replay duplicado quando a chave processada já foi persistida no snapshot. Não garante atomicidade se o processo morrer depois de alterar o estado em memória e antes de persistir o snapshot; isso exige uma transação durável no ponto de integração da carreira.
- Não foi executada simulação de temporadas completas.
