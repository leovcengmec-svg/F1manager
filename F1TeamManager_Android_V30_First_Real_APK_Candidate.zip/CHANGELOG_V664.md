# V664 — correções integradas após auditoria V663

- Unificado o cálculo do risco projetado exibido na carreira com a mesma função e os mesmos fatores usados no fechamento da temporada.
- A projeção agora considera posição, corridas, classificação, saldo efetivo após obrigações, P&D, peças fabricadas na temporada, instalações e metas já cumpridas.
- Incluídas obrigações pendentes de manutenção de instalações no saldo financeiro efetivo, junto aos salários pendentes.
- Corrigida a meta de evolução para equipes líderes: a equipe em P1 recebe objetivo de defender a liderança, e as demais recebem uma melhoria limitada às posições realmente disponíveis.
- Corrigido o crédito de investimento em instalações: cumprir a única meta disponível conta como entrega integral; upgrades em andamento recebem crédito parcial a partir de 50% de progresso.
- O desenvolvimento técnico agora reconhece pesquisa em andamento com progresso mínimo de 50%, além de pesquisa concluída e peça fabricada na temporada.
- Peças fabricadas passam a registrar a temporada de fabricação; saves antigos recebem migração única do campo, evitando que peças antigas contem como evolução nova em temporadas futuras.
- A renovação com a mesma diretoria preserva a confiança acumulada; a entrada em uma nova equipe mantém o piso de confiança inicial da nova diretoria.
- Atualizados manifesto, README, etiqueta do aplicativo e nome do artefato do GitHub Actions para V664.
- Otimizadas as consultas de histórico por temporada para abrir apenas os shards da temporada solicitada, preservando fallback para o arquivo legado.
- Fechamento do Team Principal utiliza a classificação oficial arquivada, respeitando desempates por pontos, vitórias, poles e voltas mais rápidas.
- Objetivos antigos impossíveis para equipes em P1 são normalizados mesmo quando a temporada já havia sido preparada no save.
- A falha consecutiva agora só é aplicada quando as duas temporadas ruins ocorreram na mesma equipe; a troca de equipe inicia uma avaliação esportiva separada.
- A auditoria automatizada antiga de contratos foi atualizada para as regras atuais de 1–2 anos, propostas de contingência e demissão probabilística.
