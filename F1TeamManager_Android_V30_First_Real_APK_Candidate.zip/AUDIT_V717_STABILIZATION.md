# Auditoria V717 — Ranking das Equipes

## Resultado
Implementação integrada sobre a V716, com VersionCode 717 e VersionName 0.717.0.

## Interface
- Nova entrada `RANKING DAS EQUIPES` na Central de Gestão.
- Lista única das equipes disponíveis em `WorldDatabase.teams` (esperado: 40), com posição 01–40, logotipo oficial, nome e indicador.
- Modos `FORÇA`, `CAIXA` e `PRÓXIMO CARRO`; todos ordenam do maior para o menor.
- O modo próximo carro apresenta Overall projetado e variação versus força atual; ordena pelo Overall projetado.
- Equipe controlada pelo jogador recebe destaque. Tocar em qualquer linha abre a Visão da Equipe existente e o retorno volta ao ranking.

## Fontes de dados
- Força atual: `TeamGarage.teamAverageOverall`, média dos dois carros físicos.
- Caixa: `TeamManagerState.finance.budget` para a equipe do jogador e os ledgers de `AITeamFinancialEngine` para as equipes controladas pela IA.
- Próximo carro: `CarDevelopmentEngine.buildNextSeasonGarage` / `buildAiNextSeasonGarage`, seguido de `AnnualCarRegulationEngine.applyToGarage`, reutilizando a mesma regra de construção física e regulamento usada no cálculo oficial do mercado.
- Variação: Overall projetado menos Overall atual.

## Desempenho e invalidação
- Snapshot criado em `Dispatchers.Default`, fora da thread de interface.
- Uma simulação de desenvolvimento atual por equipe de IA; a garagem resultante alimenta tanto a força atual quanto a projeção.
- Snapshot completo de 40 equipes armazenado em cache de memória.
- Chave do cache inclui equipe do jogador, temporada, semana, fingerprint do estado do jogador, fingerprint do snapshot financeiro/IA e seed regulamentar.
- Alternar os três modos apenas ordena o mesmo snapshot, sem novas simulações.

## Compatibilidade
- Nenhuma alteração no formato dos saves ou backups.
- Nenhuma alteração nas classificações oficiais de pilotos/construtores.
- Nenhum campo persistente novo.
- V716 permanece como base; nome público e nome original do ZIP preservados.

## Limitação de validação
O pacote contém o projeto Android, mas esta sessão não dispõe de Gradle/Gradle Wrapper nem Android SDK configurado. Portanto, a compilação Android integral e a suíte JUnit oficial devem ser confirmadas pelo GitHub Actions. As verificações estáticas e de contrato do release são executáveis localmente.
