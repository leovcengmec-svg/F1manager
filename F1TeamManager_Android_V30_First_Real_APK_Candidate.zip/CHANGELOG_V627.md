# V627 (0.627.0)

- Corrigida a exportação para gerar um snapshot fresco da carreira ativa, com todos os sistemas persistidos, mesmo que a semana/GP não tenha mudado.
- O autosave usa um caminho canônico por carreira/equipe/temporada, reduzindo risco de selecionar cópias datadas antigas.
- Save schema 3 adiciona manifesto e verificações SHA-256 das preferências e do arquivo histórico.
- Importação rejeita dados centrais ausentes ou vinculados à equipe errada; valida após gravar e reverte em caso de divergência.
- Jornais de recuperação locais não podem sobrescrever o save importado após reiniciar o app.
- Após carregar um save, a interface invalida o estado em memória e os caches da carreira mesmo quando equipe e temporada são iguais.
- A exportação também reconhece pelo ID um arquivo antigo/incompleto da carreira ativa e o substitui por um snapshot live completo.
- A verificação pós-importação considera a normalização de identidade para saves legados e compara o histórico binário byte a byte.
