# V460 — Carregamento, importação e exportação de saves

- O botão “Continuar Jogo” do menu inicial abre a lista de saves.
- Ao abrir a tela, a carreira ativa é salva localmente usando `NomeDaEquipe_Temporada_Data`.
- Cada save contém os valores de SharedPreferences da carreira e o arquivo do histórico de corridas.
- Exportação usa o seletor de destino do Android para criar um arquivo JSON portátil.
- Importação usa o seletor de documentos, valida formato, esquema, equipe e temporada antes de adicionar o arquivo à lista.
- Ao selecionar um save, o sistema restaura preferências e histórico, com tentativa de rollback das preferências caso a restauração do arquivo de histórico falhe.
- Após carregar, a navegação respeita os eventos pendentes de fim de temporada, regulamento e início de temporada.
- Não foi possível executar a compilação Android neste ambiente; testes de runtime ainda são necessários.
