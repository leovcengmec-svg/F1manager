# V481 — Teste do aporte efetivo da IA

- Extraída para `SeasonInvestmentPolicy` a regra que limita o aporte real por caixa disponível, espaço sob os tetos e saldo da meta escolhida.
- `AITeamFinancialEngine` usa a mesma regra testada, reduzindo o risco de o valor debitado ultrapassar a meta de evolução do carro.
- Adicionados cenários para limite de caixa, teto progressivo, saldo final da meta e meta já atingida.
- Mantidos separados o teto de €150M do carro da próxima temporada e o orçamento de P&D técnico.
