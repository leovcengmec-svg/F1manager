# Auditoria V451

- Base: V450.
- Escopo: apenas layout dos cards na tela `TeamSelect` e incremento da versão.
- O card foi reorganizado em duas faixas: cabeçalho (logo/equipe/nível/botão) e métricas em largura total (Overall, confiabilidade, piloto 1, piloto 2).
- Altura do card: 132 dp; rolagem da lista de equipes preservada.
- Valores dos pilotos continuam derivados de `WorldDatabase.drivers` e `driverOverall`.
- `InitialMetric` agora usa `TextOverflow.Ellipsis` nos valores, evitando corte abrupto.
- Filtros, ordenação e callback `onSelect(t.id)` preservados.
- `versionCode=451`, `versionName=0.451.0`.
- ZIP testado com `ZipFile.testzip()`; compilação Gradle e teste no POCO X7 Pro não executados neste ambiente.
