# Auditoria V533 — remoção do bônus por pontos

- `FinanceEngine.settleRaceFinance`: removida a transação `Bônus por pontos GP N`.
- `FinanceEngine.settleRaceWithoutMarker`: removida a parcela `pointsBonus * teamPoints`.
- Preservados os pagamentos fixos de patrocínio, bônus por metas de corrida/qualificação, premiações e despesas de GP.
- Compatibilidade: `pointsBonus` continua no modelo serializado para evitar quebra de saves antigos, mas não é usado no cálculo financeiro.
- Teste de regressão atualizado para garantir ausência de lançamento de bônus por pontos.
- ZIP validado estruturalmente. Build Gradle não executado neste ambiente.
