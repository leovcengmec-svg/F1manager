# V543 — investimento contínuo da IA nos carros

- Reserva real de caixa para investimento no carro da temporada seguinte, separada do orçamento discricionário do P&D.
- O simulador financeiro do P&D da IA passa a respeitar essa reserva, reduzindo o risco de consumir todo o caixa disponível antes da decisão de investimento.
- A decisão de investimento continua sendo individual por equipe e reavaliada após cada GP; não injeta dinheiro artificial.
- Mantidos teto absoluto, custos reais, persistência do investimento acumulado e aplicação na transição de temporada.
- Adicionado teste de regressão para reserva, caixa baixo e orçamento de P&D.
- Seed de desenvolvimento já varia por temporada via `season * 101`; a decisão financeira não fica presa a uma única rolagem aleatória.
