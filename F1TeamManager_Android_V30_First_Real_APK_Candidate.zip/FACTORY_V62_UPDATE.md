# V62 — Fábrica / Peças físicas

## Cadeia
P&D cria um `ResearchDesign`. O desenho concluído é enviado para a Fábrica. A Fábrica cria uma ou mais unidades físicas `CarPiece`. As unidades entram no estoque e não são instaladas automaticamente.

## Dois carros
Cada equipe mantém Carro 1 e Carro 2 independentes. Cada carro possui seis componentes oficiais e seu próprio Overall.

## Persistência
Ordens de fabricação, estoque e carros são persistidos por equipe.

## Compatibilidade
O modelo legado permanece como ponte temporária para não quebrar os sistemas de temporada já existentes enquanto P&D/Fábrica/Corrida são migrados para o modelo físico.

## Próxima etapa
Definir e implementar a instalação física de uma unidade no Carro 1 ou Carro 2 e, depois, conectar completamente a corrida ao desempenho de cada carro.
