# Auditoria V408

- Alteração localizada no formulário de proposta do mercado de pilotos, logo abaixo do campo de salário anual.
- A formatação usa a função existente `formatMoney(Long)`, mantendo uma única convenção de moeda no app.
- O valor bruto continua sendo lido com `toLongOrNull()` ao enviar a proposta; a prévia é apenas apresentação.
- ZIP deve ser validado; compilação Android ainda precisa ser executada no ambiente de build.
