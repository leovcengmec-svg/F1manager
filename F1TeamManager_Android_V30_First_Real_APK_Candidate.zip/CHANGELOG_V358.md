# V358 — Integridade do diário de finalização

## Alterações
- `CareerPreferences.markRaceFinalizationStepDone` agora retorna o resultado do `commit()` síncrono, em vez de descartar silenciosamente a falha de persistência.
- O fechamento do GP verifica o retorno ao marcar cada etapa como concluída. Em caso de falha, interrompe a finalização e não avança silenciosamente para a próxima etapa.
- O marcador final `complete` também é verificado antes de exibir o resultado como finalizado.
- Versão Android atualizada para `0.358.0`.
- Nenhuma alteração de layout, botões ou assets externos.

## Limite conhecido
A gravação do marcador e os efeitos de domínio não formam uma transação atômica. Se o processo parar depois de um efeito e antes do marcador, a recuperação depende da idempotência específica desse subsistema. Esta versão evita ignorar falhas explícitas de commit, mas não afirma resolver toda janela de interrupção.
