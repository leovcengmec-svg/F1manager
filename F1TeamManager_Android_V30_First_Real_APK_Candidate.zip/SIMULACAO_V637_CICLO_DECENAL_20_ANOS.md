# Simulação V637 — ciclo tecnológico e revolução decenal em 20 anos

## Conclusão

A recalibração atinge o ciclo proposto nos dois cenários determinísticos testados, com 40 equipes: carros financiados chegam a **Overall 80–100 antes da revolução decenal**; a regra decenal então os leva novamente para **Overall 40–60**. O padrão se repete nas entradas de **2036** e **2046**.

- **Semente 20261005:** em 2036, Overall médio construído antes da regra **91.30** (faixa 89–94; 40/40 equipes entre 80–100), caindo para **51.50** após a regra (faixa 49–55; 40/40 entre 40–60). Em 2046, média construída **92.60** (92–94) e média após a regra **52.68** (50–56).
- **Semente 42:** em 2036, média construída **90.18** (86–94; 40/40 entre 80–100), caindo para **50.93** (47–55; 40/40 entre 40–60). Em 2046, média construída **92.40** (92–94) e média após a regra **52.40** (50–55).

## Regra aplicada na V637

**Construção:** a tabela investimento × Overall da V636 continua sendo a fonte universal; o bônus de construção de +10% continua sendo aplicado uma única vez. Nenhum ganho foi adicionado diretamente ao carro: a IA apenas passou a definir metas de investimento mais ambiciosas. A contribuição real continua limitada pelo dinheiro disponível, reservas operacionais e teto de €150 milhões.

**Ambição de construção da IA:**

| Overall atual | Ganho-alvo máximo |
|---:|---:|
| 0–69 | +7 |
| 70–89 | +5 |
| 90–96 | +2 |
| 97–100 | +1 |

Isso compensa parte da perda anual normal e aproxima o grid da faixa 80–100, sem forçar o Overall a 100 em todas as equipes.

**Revolução regulamentar decenal:**

| Componente | Redução |
|---|---:|
| Motor | 40% |
| Chassi | 35% |
| Asa dianteira | 45% |
| Asa traseira | 45% |
| Freios | 35% |
| Unidade elétrica | 40% |
| **Média dos seis componentes** | **40%** |

Com essa distribuição, uma construção homogênea entre Overall 80 e 100 é reduzida para uma faixa física entre aproximadamente 44 e 60, antes de considerar arredondamentos. A penalidade de adaptação da equipe continua entre 0% e 8%, e a revolução substitui a regra anual naquele ano em vez de se acumular com ela.

## Marcos da simulação

| Semente | Construção para | Faixa construída antes da regra | Equipes em 80–100 | Pós-regulamento decenal | Equipes em 40–60 |
|---:|---|---:|---:|---:|---:|
| 20261005 | 2036 | 89–94 (média 91.30) | 40/40 | 49–55 (média 51.50) | 40/40 |
| 20261005 | 2046 | 92–94 (média 92.60) | 40/40 | 50–56 (média 52.68) | 40/40 |
| 42 | 2036 | 86–94 (média 90.18) | 40/40 | 47–55 (média 50.93) | 40/40 |
| 42 | 2046 | 92–94 (média 92.40) | 40/40 | 50–55 (média 52.40) | 40/40 |

Após o primeiro reset, a progressão também retoma a faixa alta. Na transição para 2042, as 40 construções atingem 80–100 nos dois testes (semente 20261005: 80–83; semente 42: 80–84).

## Teste de investimento insuficiente

O padrão não dá bônus gratuito a quem não investe. No cenário artificial com teto de €25 milhões por construção, a média construída antes da entrada em 2036 fica em 55 e a média após a regra cai para 30.73; com teto de €35 milhões, a média pós-regulamento é 34.08. Isso é coerente com a regra universal: a meta pós-reset de 40–60 pressupõe que a equipe tenha chegado à faixa técnica 80–100 antes de aplicar a redução percentual. Equipes com caixa insuficiente podem ficar abaixo.

## Método e limitações

- 40 perfis canônicos de equipes e o construtor físico real `CarDevelopmentEngine` do projeto.
- Motor real `AnnualCarRegulationEngine`, incluindo eventos anuais, as duas revoluções decenais e a adaptação variável por equipe.
- 20 transições, de 2026→2027 até 2045→2046, com sementes determinísticas 20261005 e 42.
- Cenários adicionais com tetos de €25M, €35M e investimento zero para testar a sensibilidade ao investimento.
- O cenário principal “Meta IA sem limite financeiro” é um **teste de meta de construção plenamente financiada**, não uma simulação integral do livro-caixa. Não executa a carreira completa com receitas e despesas reais, P&D, fábrica, mercado de pilotos ou corridas. No jogo, dinheiro disponível, reservas e o teto financeiro podem reduzir o investimento efetivamente realizado; portanto, a simulação comprova a calibragem técnica quando a meta é financiável, mas não garante que todas as equipes conseguirão pagar esses valores em uma carreira real.

## Artefatos

- Dados por temporada, política e semente: `SIMULACAO_V637_CICLO_DECENAL_20_ANOS.csv`.
- Harness determinístico: `tools/race_sim_test/V637TwentyYearCarConstructionSimulation.kt`.
- Auditoria estática: `tools/race_sim_test/v637_decennial_cycle_audit.py`.
