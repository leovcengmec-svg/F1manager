# Auditoria do clima — V631

## Conclusão

**Sim: a lógica atual tende a produzir chuva em excesso.** O principal problema está na combinação entre a transição meteorológica da classificação e a reutilização desse clima como condição de largada da corrida. Há também um erro de temporização entre Q1/Q2/Q3 e falta um perfil climático por circuito/época.

## Evidências no código

### 1. Classificação tem alta probabilidade de chuva

Arquivo: `app/src/main/java/com/f1teammanager/core/race/CareerWeekendEngine.kt`, função `updateQualifyingWeatherAndTyres()` (linhas 417–430).

- O motor consulta o clima a cada intervalo de pelo menos 120 segundos.
- Em cada consulta, há 18% de probabilidade de mudar de estado.
- Quando ocorre uma mudança, `DRY` pode ir diretamente para `LIGHT_RAIN` em metade dos casos; `CLOUDY` também pode ir para `LIGHT_RAIN` em metade dos casos.
- A chuva pode evoluir para média e forte.

Uma simulação Monte Carlo de 500.000 trajetórias do processo de transição, usando 14 checkpoints em Q1 e as probabilidades encontradas no código, estimou:

| Indicador de Q1 | Frequência estimada |
|---|---:|
| Chuva em algum momento da classificação | 73,4% |
| Estado de chuva ao fim de Q1 | 53,5% |
| Chuva forte ao fim de Q1 | 5,2% |

São estimativas do modelo de transição, não resultados de 500.000 execuções do aplicativo Android; a sequência RNG e o tempo exato entre voltas podem alterar ligeiramente os números.

### 2. O clima final da classificação é levado para a largada

`finishQualifyingPhase()` (linhas 544–578) não reinicializa `weather` quando a classificação avança. No fim de Q3, `rebuildRaceStartPlansForCurrentWeather()` usa o clima acumulado e prepara os pneus da largada de acordo com ele (linhas 581–605).

Portanto, a frequência de chuva gerada na classificação afeta diretamente o clima da corrida seguinte. Não se trata apenas de um ícone de chuva: a condição também influencia os pneus iniciais e o desempenho.

### 3. Temporizador da previsão não é reiniciado entre Q1, Q2 e Q3

`lastQualifyingWeatherCheckMs` é zerado no início do GP (`start()`, linha 280), mas `finishQualifyingPhase()` zera `qualifyingElapsedMs` ao iniciar Q2/Q3 (linha 553) sem zerar `lastQualifyingWeatherCheckMs`.

Como o valor da última verificação de Q1 normalmente está perto de 28 minutos, o relógio de Q2 (20 minutos) e Q3 (10 minutos) não consegue alcançar esse valor mais 120 segundos. Assim, **o clima deixa de evoluir em Q2 e Q3**. O estado climático alcançado em Q1 fica praticamente congelado até a largada e entra na corrida.

Isso também significa que o comportamento não está representando corretamente três sessões meteorológicas consecutivas.

### 4. O modelo da corrida não tem checkpoints fixos como o comentário sugere

Na função principal de corrida (`advance()`, linhas 723–745), a condição é `lap - lastWeatherChangeLap >= 6`. Quando não ocorre mudança, `lastWeatherChangeLap` não é atualizado. Como consequência, depois de atingir a volta elegível, a condição continua verdadeira nas voltas seguintes e o motor tenta sortear uma mudança em **cada volta** até que uma aconteça — não apenas uma vez a cada seis voltas.

As chances por tentativa são pequenas, mas a repetição aumenta a chance acumulada de mudança ao longo da corrida. O comentário atual, que descreve mudanças com baixa frequência, não corresponde exatamente a esse comportamento.

### 5. Nenhum perfil de clima específico para cada GP

`RaceCircuit` (`core/race/RaceModels.kt`) tem ID, nome, voltas, tempo-base e riscos de acidente, confiabilidade e Safety Car; não tem probabilidade-base de chuva, clima regional ou estação. Todos os GPs começam com `Weather.DRY` e passam pelo mesmo processo aleatório, sem diferenciar circuito, região ou época do ano.

### 6. Os testes atuais validam pneus e respostas à chuva, não a frequência

Há quatro arquivos de teste relacionados a clima/chuva encontrados em `app/src/test`, mas eles verificam principalmente composto correto, penalidade dos pneus e resposta ao fim da chuva. Não foi encontrado um teste de distribuição estatística que detecte uma taxa de chuva excessiva ao longo de uma temporada.

## Recomendação

1. Corrigir a temporização de Q1/Q2/Q3, com checkpoints por fase ou um relógio contínuo deliberado; não simplesmente zerar o marcador sem recalibrar as chances, porque isso aumentaria o número total de verificações.
2. Reduzir a taxa de transição na classificação. A título de calibração inicial, 5–6% por checkpoint de dois minutos resultou, neste modelo simplificado, em chuva em cerca de 30–35% das classificações e condição chuvosa no fim de Q1 em cerca de 26–29%, antes de aplicar o perfil do circuito.
3. Separar a probabilidade de chuva na classificação da probabilidade de chuva na corrida; a largada não deve herdar automaticamente uma condição aleatória excessivamente molhada sem uma previsão/condição de GP coerente.
4. Adicionar um perfil climático por circuito (ou região/estação) para circuitos normalmente secos, mistos e propensos à chuva.
5. Fazer a transição da corrida ocorrer em checkpoints definidos ou usar uma probabilidade acumulada calibrada para o período, em vez de repetir a tentativa em cada volta elegível.
6. Adicionar testes de distribuição sobre muitos seeds e um teste de persistência Q1 → Q2 → Q3 → largada, medindo percentuais de classificação molhada, largadas molhadas e corridas com chuva.

Como metas iniciais de equilíbrio — não regras meteorológicas universais — eu sugeriria que um calendário misto tivesse chuva em algum momento de aproximadamente 25–40% dos fins de semana, e largadas sob chuva com frequência menor; circuitos de perfil chuvoso poderiam superar esses valores. A taxa deveria ser ajustável por circuito.

## Escopo desta auditoria

A análise foi feita sobre o código-fonte V631. O pacote ZIP foi testado quanto à integridade e `app/build.gradle.kts` confirma `versionCode = 631` e `versionName = "0.631.0"`. Não foi executado `assembleDebug` nem uma simulação end-to-end no ambiente Android; as probabilidades acima vêm de simulação Monte Carlo simplificada da máquina de estados climáticos.
