# Auditoria V692 — exportação do save explicitamente selecionado

## Causa reproduzida no vídeo

A tela mantinha `selectedSavePath`, mas o botão `EXPORTAR SAVE COMPLETO` extraía o `careerId` do save selecionado e comparava com `store.careerSaveId()`. Quando os dois IDs coincidiam, o código escolhia `store.exportCareerBackup()` em vez do conteúdo do arquivo selecionado. Isso é incorreto porque uma mesma carreira pode ter snapshots diferentes em equipes e temporadas distintas (por exemplo, após troca de equipe no modo Team Principal).

## Correção

- `SaveExportTargetPolicy.shouldExportLiveCareer(selectedPath)` considera a carreira ativa somente quando não existe seleção explícita.
- Com seleção, o caminho absoluto é resolvido na lista disponível e o conteúdo é lido diretamente desse arquivo.
- O save selecionado é validado sem alteração e seu nome-base é usado para o seletor de destino.
- Se o caminho selecionado não estiver mais disponível, a operação falha de forma explícita; não usa outro save como fallback.
- Sem seleção explícita, a exportação da carreira ativa permanece disponível e cria/atualiza seu snapshot canônico.

## Regressões cobertas

- Save selecionado com mesmo `careerId` da carreira carregada: exportar o arquivo selecionado.
- Save selecionado com outro `careerId`: exportar o arquivo selecionado.
- Nenhum save selecionado: usar a carreira ativa.

## Validação

- Auditoria estática dedicada: 8 verificações.
- Teste unitário Kotlin adicionado: `SaveExportTargetPolicyV692Test`.
- ZIP íntegro e nome canônico preservado.
- A compilação Android e a suíte JUnit completa precisam ser confirmadas pelo GitHub Actions; este ambiente não contém Gradle Wrapper.
