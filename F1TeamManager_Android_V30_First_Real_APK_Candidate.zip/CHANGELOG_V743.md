# V743 — correções de desenvolvimento, IA e regulamento

## Desenvolvimento de pilotos
- Cada programa aplica somente os pontos definidos pelo nível da instalação.
- Pontos bloqueados por teto de classe, potencial, limite anual ou atributo 100 são descartados ao encerrar o programa; não são guardados nem somados ao próximo.
- Reservas legadas V703–V742 são descartadas durante normalização e leitura dos codecs, preservando apenas os programas ativos.
- A distribuição seleciona atributos sem repetição dentro de cada passagem; um programa de 2 pontos afeta dois atributos distintos quando ambos são elegíveis.
- Overall continua sendo derivado da média dos sete atributos, sem premiação direta.

## P&D e fabricação da IA
- A IA opera em lotes de até três componentes distintos.
- Cada lote conclui a rodada V1 dos componentes selecionados antes de iniciar a rodada V2 para esses mesmos componentes.
- Só os designs finais V2 (ou V1 válido como fallback quando o V2 falha) entram na fábrica.
- Antes do lote, a IA estima os seis projetos de pesquisa e o custo das peças finais, tenta quantidades de duas e depois uma unidade, e só inicia quando caixa disponível e teto técnico anual comportam o compromisso total.
- A IA não inicia outro lote enquanto os designs finais e as ordens de fabricação do lote atual não forem concluídos; depois reavalia o caixa.
- Falha de pesquisa gera evento de falha e não cria design fabricável; sucesso parcial cria design com ganho reduzido.
- Quando duas unidades são fabricadas, uma é instalada no Carro 1 e outra no Carro 2. Se só uma unidade couber no orçamento, ela vai para o carro com o componente mais fraco.

## Virada de temporada e regulamento
- Todas as peças instaladas dos dois carros da IA reiniciam sua numeração em V0 na virada; desempenho, confiabilidade e identidade física são preservados.
- A construção pública do carro da IA também aplica o reset V0, inclusive fora do simulador completo.
- Temporadas anuais normais (exceto temporada 1 e revolução técnica decenal) sorteiam sempre 1 ou 2 mudanças: 80% para uma e 20% para duas.
- A revolução decenal continua substituindo, e não acumulando, a regra anual comum.

## Mercado de pilotos
- O preenchimento automático de vagas na virada recebe a estrutura financeira completa e os níveis reais de instalações de cada equipe.
- A IA utiliza a mesma política de classificação e taxa que as negociações normais, incluindo dívidas e obrigações pendentes.

## Verificação
- Incluídos testes de regressão para pontos exatos e ausência de reserva, taxas de fabricação/orçamento, distribuição das peças entre os dois carros, reset V0 e regulamento anual 80/20.
- A compilação Android completa deve ser executada no GitHub Actions; este ambiente não possui Gradle nem Gradle Wrapper.
