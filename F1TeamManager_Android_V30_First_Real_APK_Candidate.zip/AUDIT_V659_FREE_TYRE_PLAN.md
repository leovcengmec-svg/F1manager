# Auditoria V659 — Plano Livre de Pneus

## Escopo

Base: V658 (`versionCode 658`, `versionName 0.658.0`).
Entrega: V659 (`versionCode 659`, `versionName 0.659.0`).

## Implementação

1. **Editor de Plano Livre**
   - Criar/editar plano antes da largada para cada piloto da equipe.
   - Criar/editar plano durante a corrida a partir do diálogo de box.
   - Cada stint tem composto selecionável e quantidade de voltas configurável.
   - Limite de 1 a 6 stints.

2. **Validação 100% do GP**
   - Compara a soma das voltas planejadas à distância total ou restante.
   - Identifica cobertura incompleta ou excesso de voltas.
   - Verifica a janela de desgaste do composto com a postura atual e o atributo de gestão de pneus do piloto, usando o limite automático de 85%.
   - Verifica a compatibilidade de composto com a condição climática atual.
   - Separa visualmente cobertura de distância e segurança do plano.

3. **Execução**
   - Antes da largada, o plano validado se torna o plano ativo e define o primeiro composto.
   - Durante a corrida, salvar o editor cria um plano pendente sem alterar o plano atualmente executado.
   - A confirmação da parada revalida o plano para as voltas restantes, executa a entrada no box e ativa o primeiro stint do Plano Livre.
   - O motor já percorre a sequência até o último stint sem depender de um limite de quatro entradas.

## Verificação executada

- `TyreModel.kt` compilado com as classes reais `RaceModels.kt` e `RaceControlModels.kt`, isolando apenas `TyrePlan` para não exigir a compilação de todo o motor.
- Harness Kotlin: **8/8** verificações do Plano Livre aprovadas, incluindo seis stints em pista seca, chuva leve e chuva forte.
- Regressão dos planos A/B/C/D: 58 voltas exatas verificadas em pista seca, chuva leve, chuva média e chuva forte.
- Auditoria estática de integração: **14/14** verificações aprovadas (versionamento, UI, limites, validação, callbacks, execução e preservação A/B/C/D).
- ZIP validado com `unzip -t`; nenhum arquivo temporário de verificação foi incluído.

## Limitações

- Gradle Wrapper não está presente no pacote e o ambiente não disponibiliza Gradle/Android SDK; não foi possível executar build Android nem a suíte JUnit/Compose completa.
- A validação do Plano Livre usa o clima atual no momento da criação/aplicação. Mudanças posteriores de clima continuam sob as rotinas já existentes do motor, que corrigem o composto adequado e podem exigir intervenção do manager.
