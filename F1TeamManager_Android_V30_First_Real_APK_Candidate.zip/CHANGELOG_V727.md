# V727 — Correção de compilação do ledger de fases etárias

**VersionCode:** 727  
**VersionName:** 0.727.0  
**Base:** V726 / 0.726.0  
**Nome público:** F1 Team Manager V30  
**ZIP:** `F1TeamManager_Android_V30_First_Real_APK_Candidate.zip`

## Correção

- Corrigido o erro Kotlin em `CareerPreferences.kt` durante a transição de ciclo etário: a lista de pares `driverId:phase` não pode ser convertida diretamente com `toMutableMap()`; agora a conversão passa primeiro por `toMap()` dentro de `DriverEvolutionPhaseCodec`.
- O tipo de saída é explicitamente `MutableMap<Int, String>`, eliminando também os erros em cascata de inferência de `K`, `V`, `T` e referências a `key`/`value` durante a serialização ordenada.
- Leitura, escrita e persistência na virada de temporada usam o mesmo codec. O formato existente `id:fase;id:fase` permanece compatível, incluindo fases cujo valor contém `:`.
- Adicionado teste de regressão para tokens inválidos, ordenação estável e round-trip do ledger.

## Preservado

- Nenhuma alteração nas metas esportivas da V726: elas continuam baseadas exclusivamente na força do carro, sem misturar atributos ou Overall dos pilotos.
- Pesos 40% classificação / 60% corrida, tolerância ±3, avaliação de desempenho, evolução/regressão, política financeira, construção do carro e demais sistemas foram preservados.
- Nome público e nome original do ZIP mantidos.

## Validação

- Kotlin compiler probe do codec: aprovado.
- Teste de regressão adicionado à suíte JUnit: 3 casos.
- Validador estático do contrato de release: executar após empacotamento.
- Build Android completo / `assembleDebug` ainda precisa ser confirmado pelo GitHub Actions; o ambiente local não possui Gradle nem Android SDK.
