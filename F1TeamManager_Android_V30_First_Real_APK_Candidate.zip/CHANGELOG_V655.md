# CHANGELOG V655 — Correção de compilação da tela de gerenciamento de saves

## Correção
- Corrigido o acesso anulável a `CareerSaveMetadata` no callback de carregamento de saves em `SaveManagementScreen.kt`.
- O callback agora captura os metadados em uma variável local e verifica explicitamente `null` antes de chamar `modeLabel()` ou iniciar a importação.
- Quando os metadados não existem, a interface informa que o save não possui metadados válidos e não tenta carregá-lo.
- Não foi utilizado operador `!!`; a proteção de runtime complementa o estado `enabled` do botão.

## Versionamento
- `versionCode = 655`
- `versionName = "0.655.0"`
- Nome externo do produto mantido: F1 Team Manager V30.
- Nome do pacote ZIP mantido exatamente como o original: `F1TeamManager_Android_V30_First_Real_APK_Candidate.zip`.

## Escopo
Esta revisão corrige o erro de compilação informado pelo GitHub Actions em `SaveManagementScreen.kt:247:57`. Não altera as regras de carreira, o histórico de campeões, os três modos de jogo nem a estrutura de saves.
