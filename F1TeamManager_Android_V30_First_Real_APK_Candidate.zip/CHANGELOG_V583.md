# V583

- Corrigida a rolagem vertical da tela “Próximo carro”, permitindo visualizar o card de efeito até as faixas acima de 120% e 150%.
- A tela explicita que 100% da referência depende do Overall atual e do investimento de referência correspondente.
- Mantido o cálculo dinâmico de proporção entre investimento acumulado e referência específica do carro.
- Verificação estática concluída; build e testes Android ainda pendentes.
