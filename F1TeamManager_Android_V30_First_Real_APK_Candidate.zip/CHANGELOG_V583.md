# V583 — Pacote limpo e fonte única do projeto

- Removida do pacote de entrega a pasta aninhada `v552_work`, que continha uma cópia antiga do projeto (versionCode 564).
- Comparação prévia: todos os 1.140 arquivos dessa cópia possuem caminho correspondente na raiz oficial; nenhum arquivo era exclusivo da cópia antiga. A raiz contém as versões mais recentes em 38 caminhos divergentes, inclusive configuração de build, código de domínio, telas, testes e catálogo de áudio.
- Os 125 documentos em `docs` da cópia antiga eram idênticos aos da raiz. Os assets da cópia antiga também existem na raiz; a raiz mantém as versões atuais do catálogo/README de áudio.
- Preservados o histórico de versões na raiz, os códigos atuais do projeto, os assets e as ferramentas de auditoria mais recentes. Nenhum arquivo da raiz oficial foi removido.
- Alterado somente o número da versão para `versionCode 583` / `versionName 0.583.0` para identificar o pacote limpo.
- Esta é uma limpeza de empacotamento; não declara compilação Android ou testes de UI executados.
