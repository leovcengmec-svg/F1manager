# V523 — imagens nos componentes instalados nos carros

- Os cards das seis peças atuais de cada carro agora usam os mesmos assets específicos do P&D.
- A imagem preenche o card inteiro com recorte proporcional (`ContentScale.Crop`).
- Gradiente escuro aplicado por cima para preservar contraste dos dados de versão, desempenho e confiabilidade.
- Nenhuma regra de desempenho, confiabilidade, versão de peça, instalação ou save foi alterada.
- Versionamento atualizado para 523 / 0.523.0, partindo da V522.
- Teste estático adicionado para verificar o vínculo da imagem e a presença dos seis assets.
- A compilação Android e a execução JUnit ainda precisam ocorrer no runner com Gradle.
