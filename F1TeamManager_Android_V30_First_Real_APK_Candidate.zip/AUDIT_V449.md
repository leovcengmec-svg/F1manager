# Auditoria V449

## Correções aplicadas
- `MainActivity.kt`: adicionada a ramificação `Screen.NEXT_CAR` ao `when` exaustivo do `BackHandler`.
- `MainActivity.kt`: corrigida a sintaxe da chamada `Modifier.background(...)` na tabela de efeito do investimento.
- `app/build.gradle.kts`: versão elevada para 449 (`0.449.0`).

## Verificações realizadas
- Confirmada a presença das duas regiões corrigidas no código-fonte.
- Confirmado que `Screen.NEXT_CAR` é uma opção do enum `Screen` e possui rota de entrada e saída.
- ZIP será verificado após o empacotamento.

## Limitação
A compilação real não foi executada nesta sessão: o projeto não contém Gradle Wrapper e não há executável `gradle` nem SDK Android detectável no ambiente. Portanto, esta versão não deve ser considerada APK compilado/aprovado até a execução do build no ambiente Android do usuário.
