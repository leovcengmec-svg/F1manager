# V639 (0.639.0) — Contratos Team Principal de 1 a 3 anos e apoio da diretoria

- O contrato inicial do Team Principal passa a durar uma temporada na equipe escolhida.
- Ao término do contrato, o mercado abre uma única janela no fim da temporada: até quatro propostas totais (renovação da equipe atual + até três equipes externas), conforme o prestígio.
- Cada proposta persiste sua duração específica: 1, 2 ou 3 anos. Aceitar proposta externa agenda a troca para o início da próxima temporada; renovar mantém a equipe atual.
- Prestígio de 0–19 não desbloqueia propostas externas; 20–39 desbloqueia uma, 40–59 duas e 60–100 até três. A proposta da equipe atual permanece quando a diretoria não demite.
- Criado Apoio da Diretoria (0–100), atualizado a cada temporada por objetivos, classificação e variação de prestígio. O painel exibe o apoio e o risco estimado de demissão; a demissão é probabilística no fim da temporada e libera oportunidades externas.
- O evento de propostas/demissão usa o modal oficial aprovado e direciona o usuário à tela de decisões contratuais. Os avisos ficam registrados na Central de Notícias.
- O save Team Principal migra do schema 4 para o 5 preservando histórico e estados antigos; quando um save legado está em janela de revisão, a renovação atual é reconstruída, e saves ainda ativos recebem o prazo de um ano a partir da próxima temporada ainda não processada para não pular o mercado.

