# V682 — equilíbrio carro/piloto e robustez climática

Base: V681  
VersionCode: 682  
VersionName: 0.682.0

## Equilíbrio por clima

| Condição | Carro | Piloto |
|---|---:|---:|
| Seco | 65% | 35% |
| Nublado | 65% | 35% |
| Chuva fraca | 55% | 45% |
| Chuva moderada | 55% | 45% |
| Chuva forte | 50% | 50% |

Os pesos são aplicados ao ritmo-base de classificação e corrida. As influências específicas de pneu, consistência, estratégia, ERS, DRS e habilidade em pista molhada continuam separadas para evitar que sejam somadas duas vezes no mesmo componente.

## Correção complementar

- Centralizado o cálculo de penalidade por chuva em `RaceWeatherPerformance`.
- Habilidade em pista molhada limitada a 0–100 e consistência a 40–100 antes do cálculo. Isso impede dados inválidos/importados fora da faixa de produzirem efeitos artificiais.
- Condições seco/nublado retornam penalidade de chuva zero.
- Mantida a aleatoriedade da classificação: a análise estática identificou variação relevante, mas não demonstrou distorção; não foi reduzida sem simulação estatística de temporadas.

## Testes adicionados/atualizados

- Matriz 65/35, 55/45 e 50/50 em todos os cinco estados climáticos.
- Soma dos pesos sempre igual a 100%.
- Fórmula da combinação em chuva forte.
- Clamping de habilidade e consistência fora da faixa.
- Monotonicidade da influência de habilidade em pista molhada.
- Ausência de penalidade de chuva no seco e nublado.

## Limitações de validação

- Auditoria estática e verificações locais executadas nesta revisão.
- Testes JUnit/Gradle e compilação APK precisam ser confirmados no GitHub Actions: o ZIP não inclui Gradle Wrapper e este ambiente não possui Gradle instalado.

ZIP oficial preservado: `F1TeamManager_Android_V30_First_Real_APK_Candidate.zip`.
