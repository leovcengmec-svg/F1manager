# v688 — correção de compilação e integração dos cards da Home

- Corrigido o erro Kotlin `Unresolved reference: relatedTeamId` adicionando o vínculo opcional de equipe ao modelo `MarketNotification`, com valor padrão nulo para manter compatibilidade com construtores antigos.
- Persistência das notificações passou a gravar e restaurar `relatedTeamId`; linhas antigas com seis campos continuam compatíveis.
- A Home e o contador de alertas usam a mesma política: contrato assinado, renovação e transferência confirmada continuam sendo notícias globais; proposta, recusa, contraproposta e expiração permanecem exclusivas da equipe do jogador.
- Os eventos de P&D também usam a identificação da equipe para evitar mostrar falhas ou conclusões de outras equipes na Home do jogador.
- Ao reconhecer um card de negociação próprio, o fechamento do evento encaminha o jogador ao Mercado de Pilotos.
- Preservadas as alterações de mercado e as regras de mobilidade de pilotos introduzidas na v687.
