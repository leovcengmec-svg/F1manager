# V59 — Auditoria dos valores iniciais das equipes

A V59 torna o perfil inicial canônico para a primeira temporada.

- Forte: nível 2, seis componentes entre 56 e 60.
- Médio: nível 1, seis componentes entre 48 e 55.
- Fraco: nível 0, seis componentes entre 40 e 47.
- Overall inicial = média dos seis componentes oficiais.
- Jogador e IA usam `InitialTeamProfile.carState(team)` no início.
- A definição de força usada para metas iniciais usa os mesmos seis componentes, sem `baseCar` e sem oitavo componente.
- A grade da primeira corrida usa o carro inicial canônico da IA/jogador.
- As instalações iniciais são todas 0/1/2 conforme o nível escolhido.

A classificação das 40 equipes permanece exatamente a definida pelo usuário.
