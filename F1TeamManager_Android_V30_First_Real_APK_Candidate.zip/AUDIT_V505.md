# Auditoria financeira — V505

## Escopo desta etapa
Comparação entre `FinanceEngine` (jogador) e `AITeamFinancialEngine` (IA), com foco em objetivos de patrocinadores no acerto do GP.

## Correções
- Bônus de qualificação da IA agora usa a mesma faixa inclusiva (`qualifyingTargetMin..qualifyingTargetMax`) do jogador, aplicando os mesmos valores padrão quando os limites não são definidos.
- Bônus de meta de corrida da IA agora segue a regra do jogador: paga quando não há DNF e a colocação final é menor ou igual a `raceTarget`. Os limites `raceTargetMin/raceTargetMax` não são aplicados nesse lançamento, pois isso criava divergência entre os dois motores.
- Adicionado teste unitário para a faixa de qualificação e para impedir que uma meta de corrida P5 pague indevidamente por P8.

## Limites de validação
A alteração e o teste foram adicionados ao código-fonte. A execução do Gradle/testes e a compilação Android não foram realizadas nesta etapa; portanto, a correção ainda precisa de validação de build.

## Próxima área pendente
Auditar contratação/renovação e taxas de assinatura, investimentos de temporada, patrocínios upfront, obrigações sem saldo e persistência dos estados financeiros da IA após salvar/carregar.
