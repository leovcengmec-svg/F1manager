# CHANGELOG V657 — Metas individuais de evolução e crescimento dos pilotos livres

## Evolução dos pilotos contratados

- As expectativas de classificação e corrida agora são calculadas separadamente para cada piloto, usando a força atual do carro combinada com a habilidade individual.
- Classificação considera 55% de força do carro e 45% de atributo de qualificação.
- Corrida considera 60% de força do carro e 40% de Overall do piloto.
- Companheiros de equipe com o mesmo carro recebem metas diferentes quando suas habilidades são diferentes.
- As metas deixam de ser posições fixas e passam a ter faixas de tolerância: ±2 posições no top 10, ±3 entre P11–P30, ±4 entre P31–P60 e ±5 do P61 em diante.
- Resultados dentro da faixa são considerados compatíveis com a expectativa e recebem a taxa normal de evolução (índice 105); recompensas e penalizações só ocorrem fora dela.
- As metas são recalculadas a cada GP com a força atual do carro e os atributos atualizados dos pilotos, acompanhando melhorias durante a temporada.
- Carreira e Team Principal usam o mesmo motor de metas individuais.
- Saves antigos com metas de equipe fixas são migrados para o novo formato sem alterar contratos, atributos ou histórico de corridas.

## Pilotos livres

- Multiplicador de desenvolvimento natural dos pilotos sem contrato alterado de 0,90 para 1,20 (120%).
- Mantidos o potencial individual, os limites flexíveis de classe, o limite anual por atributo e a ausência de resultados esportivos fictícios para pilotos livres.

## Versionamento

- `versionCode = 657`
- `versionName = "0.657.0"`
- Identidade pública preservada: **F1 Team Manager V30**.
- Nome padrão do ZIP preservado: `F1TeamManager_Android_V30_First_Real_APK_Candidate.zip`.
