# V522 — imagens exclusivas para componentes de P&D

- Corrigida a tela Nova Pesquisa: cada um dos seis componentes usa uma imagem própria (motor ICE, chassi, asa dianteira, asa traseira, freios e MGU-K/ERS).
- A imagem ocupa o card inteiro, com camada escura sobreposta para preservar contraste do texto e dos botões.
- Designs concluídos e peças na fábrica também usam a imagem correspondente ao componente, mantendo o layout de card já existente.
- Recursos WebP otimizados em 640×360 para limitar o crescimento do ZIP.
- Adicionado teste de mapeamento dos seis recursos e do uso da imagem em tela cheia.
- Versionamento atualizado para 522 / 0.522.0. Nenhum fluxo de pesquisa, fabricação, instalação ou dados do save foi alterado.
