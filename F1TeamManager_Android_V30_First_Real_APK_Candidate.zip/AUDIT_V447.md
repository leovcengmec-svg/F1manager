# Auditoria V447 — Layout do próximo carro

## Alterações verificadas
- `Screen.NEXT_CAR` continua apontando para `NextSeasonCarScreen`.
- `NextSeasonCarScreen` usa os valores do `CarDevelopmentEngine`, sem fabricar dados de componentes.
- A tela não usa `LazyColumn`, `verticalScroll` ou outro mecanismo de rolagem vertical.
- A referência de investimento é a específica do Overall atual; a previsão de classe vem de `nextSeasonForecast`.
- Aportes verificam teto, limite da fase e caixa protegido na interface, além da validação final do motor de domínio.
- O card de entrada para o próximo carro está no fim da lista `Car` e usa `team_card_generic_bg.webp` como fundo genérico.
- A lógica de pesquisa de componentes e a navegação existente foram preservadas.

## Versão e pacote
- `versionCode = 447`
- `versionName = "0.447.0"`
- Nome fixo do pacote: `F1TeamManager_Android_V30_First_Real_APK_Candidate.zip`

## Limitações de validação
- Revisão estática concluída.
- Integridade do ZIP será verificada após empacotamento.
- APK não compilado; não declarar validação em dispositivo.
