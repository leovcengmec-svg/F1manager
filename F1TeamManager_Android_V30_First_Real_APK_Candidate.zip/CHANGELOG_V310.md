# V310 — Restaurar posição da equipe pelo ranking de força

- Corrigida a posição no card da equipe para usar o ranking atual de força das 40 equipes, ordenado pelo overall médio do carro/garagem.
- Removida a classificação por pontos, vitórias, pódios, poles e voltas rápidas como fonte da posição do cabeçalho.
- O ranking é recalculado a partir dos snapshots atuais de força; assim a posição pode mudar quando o overall da garagem evolui durante a temporada.
- Em caso de empate no overall, a ordem usa o ID estável da equipe; pontos do campeonato não influenciam a posição de força.
- Mantidas separadas as estatísticas e a classificação de campeonato exibidas nas áreas de temporada/histórico.
- Nenhuma outra regra de negócio foi intencionalmente alterada. Nome oficial do ZIP preservado.

Validação: alteração estática e integridade do ZIP verificadas. Build Android e teste no dispositivo pendentes.
