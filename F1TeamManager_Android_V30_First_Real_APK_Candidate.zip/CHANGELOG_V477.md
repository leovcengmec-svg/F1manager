# V477 — Resposta de propostas do mercado de pilotos

- O processamento de respostas pendentes agora ocorre antes da verificação de abertura do mercado, evitando que uma proposta fique indefinidamente sem resposta quando o calendário avança para uma semana fora da janela de negociações.
- A resposta continua sendo processada no prazo gravado na oferta (2 ou 3 semanas), gerando a notificação de contrato assinado, contraproposta recebida, recusa ou proposta não concluída.
- Adicionado teste de regressão para resposta após fechamento da janela do mercado.
- Não foi possível executar a compilação Android neste ambiente: não há Gradle instalado nem Gradle Wrapper no pacote.
