# Auditoria V349

## Corrigido
- Removida a ambiguidade da chave de resultado que usava apenas o número do GP.
- Uma rodada da temporada 2 não é bloqueada só porque existe uma chave legada da mesma rodada da temporada 1.
- Leitura e gravação priorizam a identidade temporada + rodada.

## Compatibilidade e limites
- A chave antiga `race_<rodada>` é mantida como alias para leitores antigos, mas não é usada como marcador de duplicidade após a temporada 1.
- A migração não consegue reconstruir temporadas históricas a partir de uma chave legada isolada; por isso ela não inventa essa informação.
- O fechamento global ainda não é uma transação atômica entre todos os subsistemas.
- Build Android/JUnit e simulação de temporadas completas permanecem pendentes.
- Nenhuma alteração de layout ou botões.
