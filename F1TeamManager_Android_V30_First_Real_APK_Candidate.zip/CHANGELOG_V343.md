# V343 — API integrada de fim de semana instantâneo

Base: V342; versão 0.343.0; versionCode 343.

- Adicionado `simulateWeekendInstantly()` como entrada única do motor de domínio.
- Executa Q1/Q2/Q3 antes da corrida e retorna snapshots da qualificação e corrida mais o `RaceResult`.
- Valida grid, conclusão da corrida e distância programada.
- Nenhuma tela, botão ou layout foi alterado.
- Adicionado teste unitário para o fim de semana completo.
- A persistência na carreira (recordRace, finanças, evolução e calendário) continua pendente e não é declarada concluída.
