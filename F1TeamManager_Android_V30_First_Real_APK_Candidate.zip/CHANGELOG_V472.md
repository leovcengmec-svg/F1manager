# V472 — Valores financeiros compactos em eventos

- Eventos anuais e notícias passam a exibir valores financeiros em milhões ou mil, com símbolo de euro.
- Crise financeira: a perda é formatada como valor legível (por exemplo, € 1,1 milhões).
- Aquisição por investidores: a entrada de € 100 milhões é exibida sem número inteiro bruto.
- Atualização de versão para 0.472.0.
