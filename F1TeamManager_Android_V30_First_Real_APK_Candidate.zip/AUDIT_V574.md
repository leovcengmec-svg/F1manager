# Auditoria V574

## Escopo

Continuação direta da V573. A alteração cobre a passagem da detecção de inconsistências para a interface de cadastros, mantendo o comportamento não destrutivo.

## Alterações

1. `CustomWorldCatalog.diagnosticSnapshot()` reúne as mensagens de validação e os três valores persistidos originais, sem regravá-los.
2. `recheckIntegrity()` reexecuta a leitura/validação sem efetuar gravações.
3. `InitialSettingsScreen` informa o modo de proteção, limita a lista visível de problemas, permite copiar o diagnóstico por ação explícita e bloqueia os botões de gravação/edição enquanto existirem problemas.
4. A auditoria verifica faixas de atributos e nomes de arquivos de assets.
5. O pacote de diagnóstico é construído somente quando o usuário toca em **Exportar diagnóstico**; contém os dados cadastrados no dispositivo, então deve ser compartilhado apenas com destino confiável.

## Segurança e preservação

- Não há exclusão automática, migração destrutiva ou tentativa de adivinhar como corrigir registros inválidos.
- As pastas de assets e o histórico de versões foram mantidos no ZIP integral.
- A exportação para clipboard é explícita e não envia dados pela rede.

## Verificações executadas

- Conferência da versão declarada: `versionCode = 574`, `versionName = 0.574.0`.
- Verificação de integridade do ZIP com `unzip -t`.
- Testes de contrato adicionados, mas não executados.
- Não foi possível confirmar compilação ou testes Android: sem Gradle Wrapper e sem Gradle instalado.

## Limitação conhecida

Esta versão não modifica automaticamente registros inválidos. Ela preserva a fonte e permite exportar diagnóstico/dados brutos para uma recuperação posterior controlada, sem risco de “corrigir” silenciosamente nomes, IDs ou vínculos.
