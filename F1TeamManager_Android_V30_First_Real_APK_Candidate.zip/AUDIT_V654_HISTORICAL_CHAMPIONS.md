# Auditoria V654 — Persistência do campeão de pilotos

## Escopo

Correção aplicada sobre a fonte completa da V653. O nome externo **F1 Team Manager V30** e a estrutura do pacote foram preservados. A revisão interna foi elevada para `versionCode=654` e `versionName=0.654.0`.

## Causa corrigida

A versão anterior tratava a presença de qualquer linha `SD` como prova de que a temporada estava arquivada. A tela de campeões, porém, dependia de uma linha independente `C`. Assim, um shard parcial que tivesse `SD` e não tivesse `C` impedia a rotina de finalização de reconstruir o campeão.

Além disso, a leitura do histórico permitia que um shard anual substituísse por completo as linhas anuais do arquivo legado. Um shard parcial podia, portanto, ocultar o campeão ou outras linhas válidas que ainda existissem no legado. A lista de pilotos também dependia exclusivamente da lista de contratos quando um objeto de mercado estava presente, mesmo que essa lista estivesse vazia/incompleta.

## Correções aplicadas

1. **Critério real de finalização:** `isSeasonFinalized()` agora exige as duas tabelas anuais completas, identificadores/posições sem duplicação, um campeão de pilotos (`C`) e um campeão de construtores (`K`), ambos coerentes com o primeiro colocado das respectivas tabelas e com todos os GPs previstos registrados.
2. **Merge legado + shard:** os registros `SD`, `SK`, `C` e `K` são combinados por identidade. A linha do shard prevalece para a mesma identidade; linhas válidas ausentes no shard são recuperadas do arquivo legado. Linhas malformed não substituem registros válidos.
3. **Recuperação automática:** na inicialização e após confirmar a importação do arquivo histórico, temporadas com todos os GPs registrados são verificadas. Se o resumo estiver incompleto, seus pontos são reconstruídos a partir dos resultados persistidos e o snapshot é regravado atomicamente.
4. **Grid robusto:** a finalização une pilotos de contratos ativos, resultados de corrida e mapa de pontuação. Um objeto de mercado com contratos incompletos não causa mais um quadro de pilotos vazio/incompleto.
5. **Sem campeão fictício:** a reconstrução e a finalização são bloqueadas quando falta qualquer GP do calendário. Um mapa de pontos isolado não encerra uma temporada parcial.
6. **Transferências:** `recordRace()` prioriza o contrato vigente para identificar a equipe histórica; o nome da equipe no resultado e a equipe-base do piloto são apenas fallbacks.
7. **Idempotência e custo controlado:** temporadas completas e coerentes não são duplicadas em replays. Um resumo incompleto é substituído por um snapshot completo. A consulta de finalização lê apenas as tabelas e as corridas da temporada solicitada; a verificação periódica de recuperação ocorre uma vez na inicialização/importação.

## Testes executados

### Harness de runtime do código real

O `HistoricalDatabase.kt` foi compilado com `kotlinc` contra stubs isolados de `Context`, `AtomicFile`, modelos de corrida/mercado/calendário e JSON. O harness executou a classe real e aprovou:

- Persistência de campeões distintos em duas temporadas consecutivas (2026 e 2027).
- Exatamente um campeão de pilotos por temporada após finalização/reabertura.
- Shard parcial (`SD` sem `C`/`K`) mesclado com registros válidos do arquivo legado.
- Recuperação automática de campeão ausente nos dois arquivos, usando os 30 GPs gravados.
- Identificação correta da equipe de um piloto transferido pelo contrato ativo.
- Repetição da finalização sem duplicar o registro do campeão.
- Temporada com 29 de 30 GPs não recebe campeão nem é marcada como finalizada.

Resultado: **PASS**. Log: `v654_checks/champion_runtime.log`.

### Testes de regressão da revisão

Cinco verificações adicionais de contrato/fonte Kotlin aprovadas: critério de finalização, merge legado/shard, recuperação com calendário completo, união de participantes e equipe resolvida pelo contrato.

Resultado: **5/5**. Log: `v654_checks/static_tests.log`.

### Auditorias gerais

- `validate_project.py`: **45/45**.
- `final_release_audit.py`: **25/25**.
- Diferença em relação à V653: somente `HistoricalDatabase.kt`, `app/build.gradle.kts`, o novo teste `HistoricalDatabaseChampionV654Test.kt` e os documentos V654.
- ZIP final validado com `unzip -t`.

## Limites da validação

A execução isolada compila e executa o `HistoricalDatabase.kt` real, mas usa stubs para dependências Android. As verificações JUnit adicionadas ao projeto foram executadas em harness Kotlin isolado; não representam a suíte Android completa.

**O APK não foi compilado e não houve teste no aparelho.** A sessão não dispõe de Gradle/Gradle Wrapper nem Android SDK. O pacote V654 está pronto para a compilação do APK no GitHub Actions.
