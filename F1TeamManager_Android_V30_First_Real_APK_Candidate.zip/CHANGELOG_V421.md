# V421 — Overall do carro ligado à classe e à referência financeira

- O Overall geral do carro agora é calculado pelos seis componentes reais: motor, chassi, asa dianteira, asa traseira, freios e unidade de potência elétrica.
- Quando existe garagem física, a classificação usa o Overall médio dos dois carros.
- O Overall válido para essa classificação é limitado à faixa de 40 a 100.
- Faixas e referências de investimento para manter a força no próximo ano:
  - Overall 40–49 — Fim de pelotão — € 8.000.000
  - Overall 50–59 — Ruim — € 25.000.000
  - Overall 60–69 — Médio — € 45.000.000
  - Overall 70–79 — Bom — € 70.000.000
  - Overall 80–89 — Excelente — € 110.000.000
  - Overall 90–100 — Briga pelo título — € 150.000.000
- Adicionado teste cobrindo limites e valores de referência de todas as classes.
- Não houve alteração de layout nem inclusão de botões.
