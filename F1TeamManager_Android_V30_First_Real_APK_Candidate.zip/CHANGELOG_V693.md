# v693 — Inteligência financeira dinâmica e envelopes independentes

- Separados os limites anuais: €200M para carro atual/P&D/fabricação/instalações e €150M para o carro da próxima temporada.
- Investimento no próximo carro deixou de consumir o envelope técnico de €200M.
- Investimentos técnicos do jogador e da IA continuam contabilizados no envelope próprio de €200M.
- Introduzidas quatro mentalidades estratégicas: padrão (50/50; dentro do pool 60/40), carro dominante (30/70; dentro do pool 30/70), disputa pelo título (60/40; dentro do pool 70/30) e reconstrução após GP20 concluído (decisões a partir do GP21) (40/60; instalações/próximo carro).
- Seleção da estratégia considera ranking técnico, Overall, diferença estimada para o segundo melhor e fase da temporada.
- Mantida proteção do caixa operacional e limite absoluto de €150M no projeto do próximo carro.
- Incluídos testes unitários para envelopes e seleção das mentalidades.

## Interface
- Tela de investimento técnico agora mostra apenas consumo/disponibilidade do envelope de €200M.
- Próximo carro aparece separadamente, com progresso contra seu próprio teto de €150M.
- Aplicação da proporção interna de caixa: a IA direciona a parcela de P&D/carro atual e a parcela de instalações conforme a mentalidade; ao atingir a meta do próximo carro, a reserva desse destino é liberada.
