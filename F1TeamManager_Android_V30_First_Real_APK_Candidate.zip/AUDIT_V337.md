# Auditoria V337 — Eventos de corrida

## Implementado
- Colisão: sorteio global por volta, ajustado ao risco do circuito, evitando sorteios independentes por piloto.
- Furo de pneu: agendado uma vez por GP, máximo um evento por corrida, com parada emergencial e perda de 21 segundos.
- Pane elétrica: novo evento MECHANICAL_FAILURE que registra DNF, zera ERS e desativa o ERS ativo. A probabilidade aumenta quando a confiabilidade elétrica média é menor.
- Interface: registry associa `puncture` e `electric_failure` às imagens dedicadas.

## Arquivos
- `CareerWeekendEngine.kt`
- `MainActivity.kt`
- `RaceEventImageRegistry.kt`
- `res/drawable-nodpi/event_electric_failure.webp`
- `res/drawable-nodpi/event_puncture.webp`

## Limitações
ZIP validado e verificações estáticas concluídas. Não houve compilação Gradle, teste em dispositivo nem simulação multi-temporada nesta sessão.
