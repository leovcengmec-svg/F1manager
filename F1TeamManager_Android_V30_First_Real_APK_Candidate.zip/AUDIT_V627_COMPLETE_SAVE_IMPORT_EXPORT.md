# V627 — Save completo, importação/exportação íntegra

## Problema encontrado
- O botão de exportação lia o JSON escolhido na lista. Esse arquivo podia estar desatualizado porque o autosave só era acionado por temporada/rodada/semana, e não por mudanças de finanças, instalações, garagem ou P&D.
- A validação anterior confirmava modo/equipe/temporada, mas não exigia dados-base para os principais subsistemas; JSON parcial podia passar e carregar valores padrão.

## Correções
- Exportação do save ativo gera um snapshot novo a partir do estado persistido atual; se nenhum arquivo estiver selecionado, exporta a carreira ativa. Selecionar um arquivo de outra carreira ainda permite exportar aquele arquivo.
- O autosave na tela de gerenciamento atualiza um arquivo canônico por carreira/equipe/temporada, em vez de criar versões datadas que podem ficar obsoletas.
- Schema 3 adiciona manifesto com quantidade de preferências, SHA-256 das preferências, SHA-256 do histórico e lista dos sistemas incluídos.
- O validador verifica que carro, garagem, finanças, instalações, P&D, fábrica, desenvolvimento de pilotos, patrocinadores, mercado de pilotos e atributos estejam presentes e associados à equipe correta. Um save incompleto é recusado com indicação do campo ausente.
- A importação agora verifica os dados depois de gravar as preferências e o arquivo de histórico; em divergência, faz rollback da carreira, do histórico e dos journals de recuperação.
- Jornais de recuperação locais de outra carreira são limpos depois de uma importação bem-sucedida. Saves capturados durante uma virada de temporada incompleta são recusados para evitar mistura de estado com o snapshot local do dispositivo.
- Arquivos com schema 1/2 permanecem aceitos se contiverem todos os sistemas centrais necessários; não são aceitos silenciosamente se estiverem incompletos.

## Dados cobertos
- Modo, identidade da carreira, temporada, semana/rodada e seeds.
- Carro/força e investimento da próxima temporada; garagem física dos dois carros, peças instaladas, versões e confiabilidade.
- Caixa, receitas, despesas, transações, salários, taxas, patrocínios e metas financeiras.
- Níveis e melhorias de instalações; projeto ativo de melhoria.
- P&D, projetos, projetos concluídos, cooldowns, fábrica, fila de peças e peças aguardando instalação.
- Mercado de pilotos, contratos, agentes livres, transferências futuras, negociações, scouting, notificações, decisões de renovação e atributos/evolução dos pilotos.
- Objetivos e estado do Team Principal, calendário, resultados e marcadores de eventos persistidos nas preferências.
- Banco histórico de corridas/classificações/poles/temporadas, incluído como arquivo binário Base64 com digest.

## Verificações
- Revisão estática da consistência entre serialização, validação e restauração.
- ZIP íntegro e metadados da versão verificados.
- Os hashes dos assets foram comparados com a V626.
- Build Android/assembleDebug não foi executado neste ambiente; a aprovação de compilação ainda depende do pipeline Android.

## Correção adicional após vistoria do fluxo de carregamento
- O identificador `careerLoadRevision` foi acrescentado como chave dos estados `remember(...)` que dependem da carreira ativa. Depois da importação, a revisão incrementa mesmo quando a equipe/temporada é igual, forçando a reconstrução do `managerState` com carro, garagem, instalações e finanças lidos das preferências restauradas. Também invalida caches de AI finance/sponsorship/development, resultados, eventos e ranking de abertura.
- Ao exportar um arquivo selecionado, a tela verifica primeiro o `careerId` bruto do JSON. Se for o save da carreira ativa, exporta um snapshot novo das preferências atuais mesmo que o arquivo selecionado esteja antigo/incompleto; isso evita que cópias antigas impeçam a geração do backup completo.
- A exportação ativa valida o manifesto e todos os sistemas centrais antes de abrir o seletor de arquivo. A importação verifica novamente os hashes após gravar e preserva rollback se qualquer dado não for restaurado.

## Compatibilidade e última revisão
- A verificação de ida e volta normaliza `activeGameMode` e `careerId` no snapshot esperado, permitindo a migração intencional dos saves antigos sem relaxar a conferência das demais preferências.
- O banco histórico restaurado é comparado byte a byte com o conteúdo decodificado do backup, sem depender de uma codificação Base64 textual idêntica.
- A exportação repara arquivo antigo da mesma carreira usando o `careerId` bruto mesmo quando o JSON já não passa pela validação completa.
