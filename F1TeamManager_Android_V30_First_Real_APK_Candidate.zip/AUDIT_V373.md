# Auditoria V373 — Simulação instantânea e integridade da carreira

## Correção principal
O método de carreira chamava `completeStartedWeekend()` diretamente, mas o motor só era inicializado pelo fluxo interativo `startWeekend()`. Ao invocar a simulação instantânea a partir do calendário sem uma sessão prévia, o método falhava porque o circuito ainda não estava configurado.

Agora `simulateWeekendInstantly(...)` é um ponto de entrada completo: valida os 80 participantes, inicia uma sessão limpa para o circuito atual e executa o fim de semana usando o motor de produção e o validador existente. A integração da carreira foi direcionada para esse método e rejeita chamadas fora da semana do GP prevista no calendário.

## Correção sazonal adicional
O fallback de histórico `race_<round>` não contém temporada. O acesso foi limitado à temporada 1 para evitar exibir um resultado de uma temporada anterior quando faltar a chave canônica da temporada atual.

## Cobertura adicionada
- Teste do ponto de entrada instantâneo sem chamada prévia de `engine.start()`.
- Testes de chaves sazonais e fallback legado.
- Teste de contrato do diário de finalização ao longo de 60 GPs, com callbacks repetidos e retry de etapa interrompida.

## Validação executada
- Harness Kotlin executado para `RaceResultStoragePolicy`, `RaceFinalizationPlan` e `RaceFinalizationJournal`: aprovado em 60/60 GPs, callbacks repetidos, prêmio apenas no GP 30 e retry de falha simulada.
- Verificações estáticas de versão e integração: aprovadas.
- JUnit/Gradle oficial: pendente; o pacote não contém Gradle Wrapper e não há Gradle instalado neste ambiente.
- Build Android: pendente.
- A execução de 60 fins de semana com o motor de corrida permanece coberta pelo teste existente `InstantSimulationTwoSeasonChainTest`, mas a suíte oficial ainda não foi executada neste ambiente.

## Preservação
Sem alterações de layout, botões, assets externos ou remoção do histórico de versões.
