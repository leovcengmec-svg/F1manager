# V426 — auditoria da virada de temporada

- Atualizado `versionCode` para 426 e `versionName` para `0.426.0`.
- Adicionados testes de contrato para pré-condição de temporada encerrada, reset de calendário, recálculo do teto anual após criação do carro e persistência dos estados canônicos.
- Documentada a pendência de recuperação após interrupção em `AUDIT_V426.md`.
- Sem mudanças de layout; histórico e assets preservados.
- Compilação e testes não executados.
