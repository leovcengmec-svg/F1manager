# V542 — Correção do investimento da IA no próximo carro

- Corrigida a base do limite cumulativo de investimento do próximo carro da IA.
- A capacidade de investimento agora é recalculada conforme a receita real da temporada entra, em vez de ficar congelada no primeiro GP.
- A base nunca diminui, evitando que despesas posteriores apaguem capacidade já conquistada.
- Mantidos o caixa real, a reserva operacional, os salários, os custos de GP, o limite absoluto de €150M e a decisão independente por equipe/temporada.
- Nenhum dinheiro é criado artificialmente e o investimento continua sendo debitado do caixa da equipe.
