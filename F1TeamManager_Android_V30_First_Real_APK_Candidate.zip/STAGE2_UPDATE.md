# F1 Team Manager — Etapa 2

## Características dos pilotos e impacto na corrida

A Etapa 2 mantém os sete atributos de 40 a 100 e cria uma camada de 10 níveis de influência:

40-45, 46-51, 52-57, 58-63, 64-69, 70-75, 76-81, 82-87, 88-93, 94-100.

Cada atributo agora possui uma tabela própria de influência, sem transformar o atributo em resultado determinístico.

- Velocidade: modifica o ritmo de volta.
- Classificação: influencia o qualifying.
- Ultrapassagem: influencia recuperação/duelos de posição.
- Defesa: entra no confronto contra ataques.
- Consistência: reduz/amplia oscilação e risco de erro.
- Chuva: influencia o desempenho relativo em pista molhada.
- Pneus: modifica a degradação do composto e o ritmo durante o stint.

O carro, circuito, pneus, estratégia, clima e aleatoriedade continuam participando do resultado.

## Tabelas aprovadas

Velocidade/Classificação/Consistência: -3.0%, -2.3%, -1.7%, -1.1%, -0.5%, 0%, +0.5%, +1.1%, +1.7%, +2.3%.

Ultrapassagem: -25%, -19%, -14%, -9%, -4%, 0%, +5%, +11%, +17%, +23%.

Defesa: -23%, -17%, -11%, -6%, -3%, 0%, +5%, +10%, +16%, +22%.

Chuva/Pneus: -8%, -6.5%, -5%, -3.5%, -2%, 0%, +2%, +4%, +6%, +8%.

## V45 — Mercado de Pilotos: layout mestre

Atualização visual da tela Mercado de Pilotos para reproduzir a referência aprovada com alta fidelidade, mantendo a lógica existente do mercado.

- Cabeçalho e branding F1 MANAGER.
- Título, subtítulo e indicadores 100/80/20/transferências.
- Faixa de mensagem/scouting em destaque.
- Área visual de pilotos selecionados para substituição.
- Filtros: Todos, Livres, Contratados, Minha Equipe e Negociações.
- Busca por piloto/equipe e alternância de ordenação.
- Cards de pilotos com foto, status, Overall, Classe, Evolução, equipe, contrato, salário e situação futura.
- Os 7 atributos passaram a ser exibidos em microcards: VEL, CLA, ULT, DEF, CON, CHU, PNE.
- Ações SCOUT, NEGOCIAR e RENOVAR preservadas.
- Contrapropostas e ofertas recebidas continuam funcionais.
- Nenhuma regra do motor de mercado foi removida.
