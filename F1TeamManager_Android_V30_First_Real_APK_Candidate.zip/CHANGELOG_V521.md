# V521 — correção integrada do encerramento de temporada

- Mantidas as ilustrações genéricas próprias para o banner de encerramento e para os quatro destaques.
- O banner usa troféu/pódio/bandeira quadriculada, sem depender da imagem de um carro de equipe.
- Os cards usam imagens dedicadas: títulos, vitórias, abandono e pole position.
- Títulos padronizados: `Títulos`, `+ Vitórias`, `GP + Abandonos`, `+ Poles`, sempre em uma linha.
- Atualizados os testes para verificar a presença dos cinco arquivos de imagem e sua ligação ao Compose.
- Versionamento do aplicativo atualizado para 521 / 0.521.0.
- Preservados os demais arquivos, assets e histórico do projeto.
