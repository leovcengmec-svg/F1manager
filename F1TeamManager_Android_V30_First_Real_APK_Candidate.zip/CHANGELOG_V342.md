# V342 — Simulação instantânea de qualificação e corrida

- Adicionada API de domínio `simulateQualifyingInstantly()` para processar Q1, Q2 e Q3 com o mesmo motor, relógio virtual, regras de voltas descartadas, clima e geração de grid da sessão normal.
- Adicionada API `simulateRaceInstantly()` para processar todas as voltas programadas pelo motor normal, mantendo pneus, estratégia, pit stops, clima, incidentes, confiabilidade, neutralizações e classificação.
- Decisões que normalmente pausam a corrida recebem escolhas padrão somente no caminho instantâneo; o fluxo interativo existente permanece inalterado.
- Incluídos testes automatizados de conclusão das três fases de qualificação, grid completo e respeito à distância total da corrida.
- Nenhum botão, tela, componente visual ou layout foi alterado nesta versão, conforme solicitado.
- Validação desta entrega: ZIP e verificações estáticas; a compilação Android depende de execução no ambiente Gradle do projeto.
