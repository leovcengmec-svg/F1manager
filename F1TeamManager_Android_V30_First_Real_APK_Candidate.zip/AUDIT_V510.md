# Auditoria financeira V510

## Unificações aplicadas

- Débitos de P&D, pesquisa, fabricação, investimento do carro futuro, melhorias, fornecedores, contratação de pessoal e scouting usam o mecanismo financeiro compartilhado.
- O replay determinístico de desenvolvimento da IA usa a mesma política de saldo debitável para seus cálculos de capacidade.
- Jogador e IA consultam o mesmo cálculo de saldo efetivo no encerramento da temporada, incluindo salários pendentes.
- Bônus de qualificação, liquidação de GP, patrocínios, receita comercial, manutenção, salários, taxas de contratação e premiação de construtores têm regras compartilhadas ou ledgers canônicos.
- A manutenção e receita comercial mantêm chaves de idempotência independentes do histórico visual de transações.

## Preservação

- Mantidos os assets externos, o histórico de versões, a estrutura Android e o nome fixo do ZIP de entrega.
- Não foram alterados layouts, botões, ícones, imagens ou mecânicas de corrida nesta rodada.

## Validação executada

- `tools/race_sim_test/validate_project.py`: validação estrutural do projeto.
- `tools/race_sim_test/final_release_audit.py`: validação estrutural de entrega.
- `tools/race_sim_test/v498_ai_persistence_audit.py`: validação do formato de persistência e coerência de versão.
- Teste de integridade do ZIP após empacotamento.

## Limitações conhecidas

A compilação Android, a suíte JUnit e testes em dispositivo não foram executados: não há Gradle nem Gradle Wrapper no ambiente. Portanto, esta auditoria não declara compilação aprovada. A IA mantém decisões estratégicas próprias (quando pesquisar, investir ou contratar), mas as regras de débito, elegibilidade financeira e contabilização compartilhadas são comuns.
