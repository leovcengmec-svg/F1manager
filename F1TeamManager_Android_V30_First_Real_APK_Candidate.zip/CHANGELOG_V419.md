# V419 — Manter Força para o próximo carro

- Classificação dinâmica do carro atual em seis classes de desempenho.
- Referência financeira de Manter Força varia conforme a classe atual.
- Previsão de classe do carro seguinte baseada no investimento acumulado relativo à referência.
- Cartão de investimento adicionado à tela Carro/P&D, com contribuições rápidas de 25%, 50% e 100% da referência.
- Limite persistido de investimento ampliado para acomodar equipes de maior classe.
- Mantidos os bônus existentes de foco técnico e a continuidade anual dos atributos.
