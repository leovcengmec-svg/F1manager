# Regra oficial do projeto — Nova carreira em cada atualização

A partir da V602, toda atualização funcional do F1 Team Manager deve ser verificada usando uma **nova carreira iniciada pelo fluxo Novo Jogo**, nunca continuando um save criado em uma versão anterior.

## Como aplicar
- Validar alterações de calendário, pilotos, evolução, economia, P&D, fabricação e Team Principal com uma carreira nova.
- Não usar save antigo como base para aprovar uma atualização nem como única evidência de funcionamento.
- Preservar os recursos de salvar/exportar/importar no jogo. Esta regra de desenvolvimento não autoriza apagar saves do usuário automaticamente.
- Se um bug depender de um save legado específico, usar esse save somente para reproduzir/diagnosticar; a aprovação final também exige teste em nova carreira.
- Registrar no relatório o estado de validação: testes estáticos, testes de engine, build Android e teste no aparelho, sem afirmar etapas que não foram executadas.
