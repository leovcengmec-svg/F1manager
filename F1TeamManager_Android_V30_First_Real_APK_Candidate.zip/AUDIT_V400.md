# Auditoria V400

## Alteração
Ajuste de proporção do diálogo de fabricação em `MainActivity.kt`.

## Verificações estáticas
- Cards de ordem usam altura fixa de 112 dp em vez de `weight(1f, fill = true)`.
- Diálogo usa altura máxima de 760 dp, sem exigir 92% da altura disponível.
- Lógica de seleção, preço, orçamento e fabricação não foi alterada.
- `versionCode=400`, `versionName=0.400.0`.

## Limitação
A compilação Android e a validação visual no POCO X7 Pro ainda precisam ser executadas no ambiente de build do projeto.
