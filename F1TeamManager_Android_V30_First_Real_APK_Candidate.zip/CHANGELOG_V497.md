# V497 — Correção de reconstrução da visão geral na virada de temporada

- Corrigida a visão geral das equipes: a condição `currentWeek <= 1` estava substituindo os carros físicos e níveis de instalações pela configuração inicial também no início de TODAS as temporadas seguintes.
- O baseline inicial agora só é usado na abertura da carreira (temporada inicial). Nas temporadas seguintes, a visão geral usa o estado atual do jogador e simula o carro/garagem da IA com os níveis de instalações persistidos.
- Adicionado teste de contrato para impedir regressão na seleção do estado inicial versus estado de temporada já progredida.
- Preservados o histórico, os assets e o nome fixo do ZIP de entrega.
- Validação Gradle/APK não declarada: este ambiente não tem Gradle wrapper nem instalação Gradle disponível.
