# CHANGELOG V719 — Correções de compilação e navegação

## Correções

1. **Voltar do Ranking das Equipes:** adicionada a rota explícita `TEAM_RANKING` ao `BackHandler`, retornando ao Hub de Gestão de onde a tela é aberta. Isso torna o `when(screen)` exaustivo.
2. **Arquivo de Temporadas — escopo Compose:** movidos os `remember` que filtravam registros de pilotos e construtores para o corpo composable de `SeasonArchive`, antes do `LazyColumn`. O DSL `LazyListScope` agora apenas consome as listas preparadas por `remember`, sem invocar APIs composables fora de um contexto composable.
3. **Dados e comportamento preservados:** os filtros por temporada, alternância Pilotos/Construtores, ordenação e linhas apresentadas continuam usando os mesmos registros do snapshot histórico.

## Versão

- `versionCode`: 719
- `versionName`: `0.719.0`
- Nome público: `F1 Team Manager V30`
- ZIP: `F1TeamManager_Android_V30_First_Real_APK_Candidate.zip`
- Base: V718

## Validação

A revisão estática confirma os três pontos apontados no log de compilação. O ambiente de edição não dispõe de Gradle Wrapper/Gradle instalado nem Android SDK; portanto, o build Android e a suíte JUnit não foram executados localmente. A validação definitiva deverá ocorrer no GitHub Actions com `:app:testDebugUnitTest :app:assembleDebug`.
