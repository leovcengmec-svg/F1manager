# V509 — Débitos financeiros centralizados

- O caminho de débito financeiro compartilhado agora é utilizado também nas despesas do jogador em P&D direto, pesquisa, fabricação, investimento no carro da próxima temporada e melhorias de instalações.
- Bônus de contratação de pessoal e contrato de fornecedor do jogador também usam o débito canônico; a contratação de fornecedor agora verifica saldo suficiente antes de registrar a despesa.
- As regras estratégicas (o que investir e quando) permanecem próprias de cada equipe; o registro contábil do débito usa o mesmo motor.
- Preservadas as validações de saldo e de limite técnico existentes, bem como as descrições dos lançamentos.
- ZIP verificado após empacotamento. Não foi possível executar a compilação Android nem a suíte JUnit por ausência de Gradle/Gradle Wrapper neste ambiente.
