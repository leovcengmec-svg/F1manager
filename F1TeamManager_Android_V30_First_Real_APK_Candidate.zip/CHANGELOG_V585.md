# V585 — Correções dos erros do GitHub Actions

- Corrigida a referência a `round.round` usada antes da declaração local `round` em `MainActivity.kt`; a chave de deduplicação de áudio usa o índice de rodada já disponível no escopo.
- Removido o argumento `installedPieceVersions` de `TeamCarState.copy`, tipo que não declara esse campo. As versões dos componentes continuam sendo mantidas nos dois objetos `PhysicalCar` (`regulatedGarage.car1` e `regulatedGarage.car2`), que são os tipos que suportam esse atributo.
- Versão Android incrementada para 0.585.0.
- Nome externo do ZIP de entrega mantido fixo.

Validação: erros apontados nas imagens corrigidos por inspeção de código. O build Android completo ainda precisa ser reexecutado no GitHub Actions; não declarar compilação aprovada antes do resultado.
