# V585

- Adicionada opção `MENU INICIAL` no diálogo de retorno da HOME.
- Voltar da seleção de equipe retorna ao menu inicial, sem tratar a ação como saída do aplicativo.
- A carreira salva é preservada ao retornar ao menu.
