# V120 — Qualificação: fluxo sequencial e UI compacta

## Correções
- Q3 não é mais considerado concluído apenas porque seus 20 pilotos foram preparados.
- A conclusão real é reconhecida somente quando o grid final contém 80 pilotos.
- Após Q1: permanece visualmente em Q1 e exibe `SIMULAR Q2`.
- O clique em `SIMULAR Q2` muda para Q2 e inicia a simulação.
- Após Q2: permanece em Q2 e exibe `SIMULAR Q3`.
- O clique em `SIMULAR Q3` muda para Q3 e inicia a simulação.
- Após Q3: exibe `INICIAR CORRIDA`.
- O botão final faz parte da rolagem vertical; não fica fixo na tela.
- Os cards de pilotos foram compactados para aumentar a área visível de troca de posições.
- A lista inteira da qualificação usa rolagem vertical.
- 4x acelera também o relógio virtual: 20 s virtuais por tick, em vez de 5 s.

## Validação de motor
`V120_QUALIFYING_SEQUENCE_OK`

O teste confirmou:
1. Q1 gera 50 sobreviventes.
2. Q2 é preparado com 20 pilotos sem marcar Q3 como concluído.
3. Q3 é preparado com 20 pilotos sem marcar o grid final como concluído.
4. Somente após a simulação de Q3 o grid final contém 80 pilotos.
