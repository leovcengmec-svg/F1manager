# Auditoria V405

## Alterações
- `MainActivity.kt`: a classificação da tela `Result` passou de `take(5)` para todos os registros ordenados de `RaceResult.classification`.
- O painel de classificação usa `LazyColumn` com peso disponível, de modo que somente a lista role verticalmente; os controles e resumos da tela permanecem fixos.
- Ordem visual do pódio ajustada para P2, P1, P3.
- `app/build.gradle.kts`: versionCode 405, versionName 0.405.0.

## Validação
- Revisão estática do trecho Kotlin alterado realizada.
- Compilação Gradle/Android e teste visual no POCO X7 Pro não executados neste ambiente; não declarar build aprovado até validar no CI/dispositivo.
