# V620 — Correção de compilação Kotlin/Compose pós-V619

- Removida a anotação `@Composable` duplicada em `HomeEventImageCard`, que causava `This annotation is not repeatable`.
- Adicionada a anotação `@Composable` que faltava em `Home`, corrigindo os erros em cascata de chamadas Compose dentro da HOME.
- Adicionado o import explícito de `androidx.compose.ui.graphics.graphicsLayer` em `SeasonEndEventScreen.kt`.
- Confirmada a assinatura de `SeasonCarRevealScreen` com `teamRank` e `totalTeams`, e o envio dos dois argumentos nomeados pelo chamador em `MainActivity.kt`.
- Preservadas integralmente as regras de patrocínio, decisões financeiras da IA, mercado de pilotos, saves, assets e histórico da V619.
- O build Android completo precisa ser confirmado no pipeline Gradle: este ambiente não contém Gradle nem Android SDK instalados e o projeto não inclui `gradlew`.
