# Auditoria V314 — Tela de qualificação

- versionCode=314 / versionName=0.314.0.
- Inspeção estática confirmou remoção da linha de botões Q1/Q2/Q3 e dos indicadores PILOTOS/ELIMINADOS.
- A ação de simulação foi movida junto aos controles de velocidade e conserva os ramos de simular, pausar e iniciar corrida.
- O texto “Regressivo” e o rótulo “RELÓGIO” foram removidos; o contador segue visível.
- O fundo genérico do GP foi substituído por arte sem texto.
- Não foi executada compilação Android nesta sessão; revisão de código e integridade do ZIP são verificações estáticas.
