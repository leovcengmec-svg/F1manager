# Auditoria V602 — ANR na virada da segunda temporada

## Evidência do usuário
Após concluir a segunda temporada no modo Team Principal, o Android mostrou "F1 Team Manager não está respondendo" na tela de encerramento e novamente na avaliação contratual. Fechar e reabrir o app normalizou a navegação.

## Causa provável identificada no código
O ramo `Screen.SEASON_END` executava diretamente durante a composição:
- `recordTeamPrincipalSeason()`;
- `markSeasonEndEventSeen()`;
- `buildSeasonEndSummary()`, que consulta múltiplas coleções históricas (resultados de pilotos/equipes, corridas, poles, campeões e temporada anterior).

Essas consultas e gravações ocorriam na thread principal e podiam ser repetidas durante recomposições. A tela de encerramento é imediatamente seguida pela avaliação contratual, o que combina com os dois ANRs observados.

## Correção V602
- Move o registro e a agregação do resumo para `withContext(Dispatchers.IO)`.
- Usa `LaunchedEffect` keyed pela temporada e contador de retry, executando uma única preparação por temporada em condições normais.
- Armazena o resumo em estado Compose e reutiliza-o durante recomposições.
- Mostra carregamento e erro recuperável com botão de nova tentativa.

## Limitações
Esta é uma correção orientada à causa provável e à evidência observada; a confirmação final exige repetir o encerramento da segunda temporada em Android. O build Android, JUnit e teste no aparelho ainda não foram executados.
