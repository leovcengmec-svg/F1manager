# V392

- Na tela de equipe, o rótulo “Investimento Anual” foi abreviado para “Invest. Anual”.
- Nenhuma alteração funcional ou de layout além desse texto.
