# V487 — Correções dos erros de compilação confirmados no Build Debug

- Corrigido o callback do botão de notificação de contraproposta: a tela `Home` agora chama `onMarket()` em vez de tentar acessar o estado `screen`, que pertence a outro escopo.
- Corrigido o receiver do conteúdo de `MarketNegotiationFrame` de `Column` (símbolo inexistente) para `ColumnScope`, compatível com o escopo de conteúdo do Jetpack Compose.
- Não alterada a lógica financeira, a simulação ou o layout fora dessas correções.

Validação local: conferência dos trechos alterados e teste de integridade do ZIP. Compilação Gradle completa não executada neste ambiente.
