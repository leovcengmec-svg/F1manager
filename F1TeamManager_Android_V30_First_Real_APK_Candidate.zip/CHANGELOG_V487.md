# V487 — Ranking inicial consistente no perfil da equipe

- Corrigido o ranking de força na primeira semana da temporada: a equipe do jogador agora usa a mesma garagem inicial canônica (`TeamGarageFactory.fromInitial`) utilizada para classificar as equipes no seletor do Modo Difícil.
- Evita que o Overall arredondado a partir do estado legado `TeamCarState` coloque a equipe em uma posição diferente daquela calculada no seletor.
- Após a primeira semana, o ranking continua usando os carros/garagens atuais, refletindo o desenvolvimento da temporada.
- Não altera o ranking por pontos nem a ordem de força durante o restante da temporada.
- Validação realizada: inspeção do código alterado e teste de integridade do ZIP. Compilação Gradle Android não executada neste ambiente.
