import com.f1teammanager.core.manager.*
import com.f1teammanager.core.season.WorldDatabase

fun main() {
    var strong=0; var medium=0; var weak=0
    WorldDatabase.teams.forEach { t ->
        val v=InitialTeamProfile.values(t)
        val g=TeamGarageFactory.fromInitial(t)
        require(v.overall in 40..60)
        require(g.car1.overall in 40..100 && g.car2.overall in 40..100)
        require(g.teamAverageOverall in 40..100)
        require(g.car1.componentReliabilities.values.all { it in 1..100 })
        require(g.car2.componentReliabilities.values.all { it in 1..100 })
        when(t.initialLevel){InitialTeamProfile.FORTE->strong++;InitialTeamProfile.MEDIO->medium++;else->weak++}
    }
    require(strong+medium+weak==40)
    println("INTEGER_CAR_AUDIT_OK teams=40 strong=$strong medium=$medium weak=$weak")
}
