# Auditoria V333 — nomes Motor - ICE e MGU-K - ERS

## Escopo
Atualização global de rótulos visíveis para os componentes de potência, a partir do ZIP V332.

## Alterações
- Motor: `Motor - ICE`.
- Unidade elétrica: `MGU-K - ERS`.
- Atualizados os rótulos em pesquisa/P&D, desenvolvimento do carro, fábrica, eventos e resumos de equipe.
- Preservados enums, persistência e regras mecânicas.
- Mantidos aliases de nomes antigos no parser de notícias para compatibilidade com registros históricos.

## Verificações
- Verificada a presença dos novos nomes nos pontos de apresentação conhecidos.
- Verificado que os nomes antigos permanecem apenas em compatibilidade/histórico/documentação de versões anteriores.
- Integridade do ZIP será testada após empacotamento.
- Compilação Android e teste no dispositivo não foram executados nesta etapa.
