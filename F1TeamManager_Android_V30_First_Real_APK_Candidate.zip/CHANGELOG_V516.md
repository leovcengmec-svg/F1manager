# V516 — Gerenciamento de saves

- Adicionada seleção explícita de um save na lista.
- A ação EXPORTAR SAVE exporta o arquivo selecionado, não necessariamente a carreira ativa.
- Adicionado botão dedicado para carregar cada save, separado da seleção.
- Adicionada exclusão de saves com confirmação e atualização da lista.
- Ao excluir o save selecionado, a seleção é limpa para impedir exportar acidentalmente outro arquivo.
- Mantida a validação existente durante importação e restauração.
- Versionamento Android atualizado para 516 / 0.516.0.
