# V506 — Auditoria financeira: parcelas pendentes de contratação

- Corrigido o ledger compartilhado de taxas de contratação: quando falta saldo na data prevista, a parcela permanece pendente e é tentada novamente nos GPs seguintes, em ordem cronológica.
- O pagamento atrasado identifica o GP de origem e o GP em que foi liquidado.
- Mantida a idempotência por parcela/GP, evitando cobrar duas vezes uma parcela já quitada.
- Incluído teste de regressão para saldo insuficiente, recuperação de caixa e repetição do mesmo GP.
- A alteração usa o mesmo `SignatureFeeAccounting` para jogador e IA.
- Compilação e execução dos testes Android ainda precisam ser realizadas em ambiente Gradle.
