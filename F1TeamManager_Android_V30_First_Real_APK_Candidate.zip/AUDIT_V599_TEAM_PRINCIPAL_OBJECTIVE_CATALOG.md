# Auditoria V599 — Catálogo de objetivos Team Principal

## Alterações
- Um objetivo principal fixo de posição no campeonato, baseado na força/posição da equipe.
- Cinco objetivos adicionais escolhidos deterministicamente por equipe e temporada, sem objetivo financeiro secundário obrigatório.
- Opções esportivas/financeiras, conclusão de pesquisa, peça fabricada disponível e evolução de cada uma das sete instalações.
- Avaliação das instalações compara o nível persistido com a meta; pesquisa consulta designs concluídos na temporada; fabricação consulta peças fabricadas aguardando instalação.
- Prestígio inicial 1, +4 no objetivo principal, +1 nos demais, fracassos penalizam e teto de ganho +8 por temporada.

## Validação
- Teste de contrato estático: executado separadamente; consultar saída do teste no registro da tarefa.
- ZIP: verificação de integridade executada após empacotamento.
- **Não** declarar compilação Android/JUnit/emulador: não foram executados neste ambiente.
- A meta de fabricação considera peças físicas pendentes de instalação no fechamento; se forem instaladas antes do fechamento, a meta não é contada como concluída. Isso é uma limitação funcional a avaliar numa simulação integrada.
