# V716 — Fluidez de navegação e propostas comerciais

Base: V715 / 0.715.0  
VersionCode: 716  
VersionName: 0.716.0

## 1. Desempenho e navegação
- O arquivo histórico combinado agora é mantido em cache imutável em memória.
- A projeção estruturada do livro histórico é construída uma vez e compartilhada por História, Hall da Fama, Recordes e Visão da Equipe.
- Leituras e gravações do arquivo usam a mesma sincronização; qualquer escrita concluída invalida os caches e incrementa a revisão.
- O resumo histórico ganhou índices por equipe, equipe/temporada, temporadas, poles e circuitos. Listas de vitórias/voltas rápidas também são preparadas durante a leitura do snapshot.
- O Hall da Fama calcula os 12 conjuntos de métricas em duas passagens compartilhadas e mantém os rankings finais em cache, em vez de recalcular o histórico a cada troca de métrica.
- A Central de Recordes executa reconstrução da carreira, temporadas e circuitos em segundo plano.
- A troca de equipe reutiliza os 40 snapshots preparados; os snapshots também ficam em cache entre visitas quando a carreira não mudou.
- Enquanto os dados avançados são preparados, os controles anterior/próxima equipe continuam disponíveis.
- Preparação das equipes e agregações históricas ocorrem fora da thread visual.

## 2. Centro Comercial nível 2
- Cada slot mostra três propostas distintas.
- A primeira proposta preserva o patamar Básico.
- As outras duas têm sorteios independentes e determinísticos entre as categorias desbloqueadas; no nível 2 podem apresentar categoria Regional.
- Reabrir a mesma carreira/semana/slot não troca as propostas; uma mudança real de estado comercial gera outra combinação determinística.
- Nomes de patrocinadores continuam sem duplicidade dentro da seleção e em relação aos contratos ativos.

## 3. Preservação
- Mantidos os contratos de patrocínio, regras de pagamento e duração existentes.
- Mantidas as telas e os dados de História, Hall da Fama e Recordes; a mudança é de cache/indexação e execução em background, não de regras estatísticas.
- Mantida a identidade pública F1 Team Manager V30 e o nome original do ZIP.

## 4. Validação
- Auditoria estática dedicada V716.
- Contrato de release atualizado.
- Teste de estabilidade das propostas ampliado para verificar a oferta Básica garantida e a possibilidade de propostas Regionais independentes no nível 2.
- A compilação Android completa deve ser confirmada pelo GitHub Actions; este ambiente não possui Gradle/Android SDK.
