# V724 — Ranking determinístico e correção de projeções

Base: V723 / 0.723.0  
VersionCode: 724  
VersionName: 0.724.0

## Correções

1. Simulações de consulta deixaram de publicar Overalls no registro global por padrão. A publicação ficou restrita ao avanço semanal canônico.
2. `AITeamFinancialEngine.developmentCapacity` agora recebe snapshots opcionais de ranking e Overalls. Quando fornecidos, a política financeira não consulta um ranking mutável durante o processamento.
3. `syncAiWeeklyState` congela ranking técnico e grade de Overalls antes de processar as 39 equipes da IA e usa as mesmas referências durante o lote.
4. Visão das Equipes, Ranking e snapshot individual usam referências congeladas para capacidade e simulação.
5. O Overall oficial do próximo carro no Ranking das Equipes usa somente investimento comprometido. O valor projetado continua disponível em campo separado para exibição informativa.
6. Continuar Jogo fica habilitado sem carreira carregada, permitindo abrir a tela de gerenciamento/importação de backup.

## Preservação

- Nome público e nome do ZIP preservados.
- Regras de investimento técnico anual, tabela Overall × investimento, limite de perda anual e pipeline de desenvolvimento preservados.
- Nenhum histórico financeiro, esportivo ou de carreira removido.

## Limitações de validação

A correção reduz as causas de mutação cruzada e de reconstrução inconsistente. Não representa ainda um redesenho completo do simulador físico para checkpoint por semana com persistência de todas as filas internas. A simulação física ainda contém um loop desde a semana 1 em chamadas sem checkpoint exato. Isso exige uma etapa estrutural própria e testes de equivalência antes de ser declarada resolvida. Não foi possível certificar desempenho em dispositivo sem benchmark Android.
