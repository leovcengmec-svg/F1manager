# Auditoria V556

- Base utilizada: pacote oficial entregue como V555.
- Inspecionados: `CustomWorldCatalog.kt`, `ExternalAssets.kt`, `MainMenuScreen.kt` e `app/build.gradle.kts`.
- Alteração funcional: cadastro persistente País → arquivo de bandeira, exposto na tela de cadastros e priorizado na resolução do asset; a busca de aliases anterior continua como fallback.
- Compatibilidade: `countryFlags` usa chave de preferência própria com padrão `[]`, então registros antigos de pilotos/equipes continuam legíveis.
- Validação estática: verificadas referências do novo cadastro e incremento de versão para 556.
- Não verificado: compilação Android, testes instrumentados e simulação completa em dispositivo; não declarar runtime validado.
