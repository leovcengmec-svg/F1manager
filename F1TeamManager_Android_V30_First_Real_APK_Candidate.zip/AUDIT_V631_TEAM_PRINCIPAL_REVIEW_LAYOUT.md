# V631 — Avaliação do Team Principal

## Escopo
Reformulada apenas a interface `TeamPrincipalReviewScreen` em `MainActivity.kt`, usando como referência o mockup aprovado.

## Alterações
- Cabeçalho compacto com retorno ao menu.
- Card principal da equipe com retrato `team_principal_manager_portrait`, opacidade baixa e gradiente de proteção de contraste.
- Prestígio, barra de progresso, meta contratual e última classificação organizados no card principal.
- Dois resultados mais recentes dispostos lado a lado.
- Ação de renovação destacada em vermelho.
- Até três propostas exibidas em cards padronizados com escudo externo carregado por `TeamLogo`, ranking inicial/atual e botão Aceitar.
- Botão de retorno ao menu fixo na parte inferior.
- Removida a rolagem vertical desta tela; componentes dimensionados conforme a altura útil e modo compacto para telas baixas.
- Callbacks e regras de renovação/aceite preservados.

## Limitações da validação
O código foi revisado estaticamente e o ZIP será verificado. Build `assembleDebug` e teste visual real precisam ser executados no pipeline Android antes de declarar compilação aprovada.
