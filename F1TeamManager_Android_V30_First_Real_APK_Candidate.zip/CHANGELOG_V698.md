# V698 — piso universal de atributos em 40 pontos


- Todos os sete atributos permanentes dos pilotos passam a respeitar a faixa 40–100, assim como o potencial individual do piloto.
- Todos os atributos permanentes do carro passam a respeitar 40–100: motor, chassi, asas dianteira/traseira, freios, unidade elétrica, aerodinâmica agregada e confiabilidade.
- O mesmo limite vale para confiabilidade individual de cada componente, peças fabricadas, projetos e designs de P&D, pedidos de fábrica, carros físicos, snapshots do Team Principal, carros da IA e dados migrados de saves antigos.
- Atributos carregados abaixo de 40 são corrigidos ao normalizar/ler os dados e as próximas gravações persistem a faixa corrigida.
- Corrigida a migração de carros legados zerados para que a identificação do save antigo aconteça antes da normalização, preservando a restauração existente.
- Fornecedores de motor e pneus também passam a respeitar 40–100, pois alimentam os índices de desempenho e confiabilidade das peças.
- Estados transitórios de corrida permanecem separados: desgaste de pneus/chassi e confiabilidade instantânea durante uma pane podem variar até 0; isso não altera o piso dos atributos-base permanentes.
- Preservado o nome público F1 Team Manager V30 e o nome padrão do ZIP.


- Corrigida a penalidade financeira de encerramento: a redução técnica de 20% por saldo negativo respeita o piso de 40 nos atributos do carro, na confiabilidade geral e nas confiabilidades dos componentes; garagem normalizada ao final do processo.
