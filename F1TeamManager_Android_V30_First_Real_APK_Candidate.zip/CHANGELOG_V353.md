# V353 — Serialização do fechamento do GP

- O ponto único `finalizeCompletedRace` agora é sincronizado na instância de `MainActivity`, impedindo que callbacks concorrentes processem simultaneamente o mesmo fechamento.
- Mantido o preflight de `RaceResultValidator` antes dos efeitos persistentes.
- Mantido o diário persistente por temporada/GP/etapa.
- Nenhum botão, layout, asset, nome de desenvolvedor ou histórico de versões foi alterado.

## Limitação conhecida
A sincronização não transforma as gravações de subsistemas distintos em uma transação atômica. Para recuperação exata após encerramento do processo no intervalo entre um efeito e seu marcador, cada subsistema precisa garantir idempotência durável. Isso permanece como próxima etapa de auditoria.
