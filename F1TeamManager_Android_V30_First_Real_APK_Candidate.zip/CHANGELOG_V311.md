# V311 — Reestruturação visual da tela Carro / P&D

- Reorganizada a tela real `CARRO / P&D` em torno dos cards funcionais de Carro 1 e Carro 2.
- A imagem externa do carro da equipe passa a aparecer dentro de cada card de carro, acima da grade dos seis componentes; removido o banner isolado do topo.
- Mantidos valores, versões instaladas, desempenho, confiabilidade, Overall, estados de pesquisa, limites de pesquisa simultânea, cooldowns, diálogos de pesquisa, fabricação e instalação.
- Melhorada a leitura das médias de desempenho e confiabilidade e das informações dos componentes.
- Inserida imagem já existente `facility_factory` no painel Fábrica, sem substituir os estados ou ações reais.
- Mantidos os fluxos de pesquisa, design concluído, fabricação de peças e instalação em cada carro.
- Nenhuma alteração intencional às regras de corrida, dados, contratos, estatísticas ou regras de negócio.


## Atualização complementar — tela Qualificação (layout aprovado)

- Reestruturado o cabeçalho do GP em card compacto com imagem existente, round/semana, nome do GP, circuito, volta, distância e clima dinâmico.
- Compactados os seletores Q1/Q2/Q3, mantendo a disponibilidade por fase e o botão funcional de simulação/início da corrida.
- Reorganizado o resumo da sessão com estado, relógio regressivo, média do GP, melhor volta da sessão e progresso.
- Controles de velocidade e contadores de pilotos/eliminados alinhados na mesma faixa responsiva.
- Classificação reorganizada para mostrar equipe, carro, piloto, pneu, tempo e diferença para o líder; destaque visual dos pilotos da equipe do jogador preservado.
- Mantidos o motor de qualificação, temporizador, pneus, eliminação, resultados e callbacks existentes.
- Não foram geradas imagens novas.
