# Auditoria V415

- Alterado `CareerWeekendEngine`: a seleção de pilotos afetados pela largada ruim usa um único sorteio de ocorrência por GP (18%) e seleciona 2 a 5 pilotos quando ocorre.
- A perda de tempo individual permanece entre 150 ms e 600 ms.
- Atualizados `versionCode=415` e `versionName=0.415.0`.
- Não foi possível executar compilação Android neste ambiente; validação de runtime permanece pendente.
