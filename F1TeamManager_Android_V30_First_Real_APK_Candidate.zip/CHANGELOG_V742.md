# V742 — Correção de compilação das taxas de contratação

- Corrigida a ordem de declaração da função local `signatureFeeForTeam` em `MainActivity.kt`.
- A função agora é declarada antes de `advanceFreeWeeksSegment` e de todos os fluxos locais que calculam taxas de contratação.
- Mantida integralmente a lógica V741: taxa baseada no Overall atual e nível financeiro da equipe contratante, sem pagamento à equipe anterior.
- Corrigidos os erros derivados de `Unresolved reference: signatureFeeForTeam`, incluindo a inferência do operador na parcela da taxa.
- Nenhuma regra de negociação, tabela de valor/salário, classe financeira ou prioridade do Centro Comercial foi alterada.
