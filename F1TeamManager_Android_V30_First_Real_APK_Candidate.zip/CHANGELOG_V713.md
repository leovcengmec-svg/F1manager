# V713 — Central Livro de Recordes

Base: V712 / 0.712.0. Nome público F1 Team Manager V30 e nome original do ZIP preservados.

## Central de Recordes implementada
- Substituída a tela vazia por cinco áreas: Visão Geral, Pilotos, Equipes, Circuitos e Temporadas.
- Recordes apresentados em cards individuais com valor, recordista, equipe, temporada e contexto quando disponível.
- Categorias de Pilotos e Equipes oferecem filtros Todos os Tempos e Por Temporada, usando somente temporadas oficialmente finalizadas no segundo modo.
- Circuitos são selecionados pelo nome próprio da pista; GPs homônimos em locais diferentes não são agrupados.
- Fichas de circuitos exibem vitórias, pódios, poles, voltas rápidas, melhor volta de corrida e melhor tempo de classificação quando os dados existem.
- Temporadas exibem recordes anuais de pilotos e construtores, aproveitamento de vitórias/poles, média de pontos por GP e vantagem do campeão de construtores.
- Visão Geral destaca recordes de carreira e marcas históricas superadas ao longo dos resultados arquivados.

## Reconstrução e integridade
- Os recordes são reconstruídos a partir do arquivo oficial de GPs, poles e resumos de temporadas concluídas; não há contadores paralelos que possam duplicar estatísticas.
- A Central utiliza um snapshot consistente com uma única leitura do arquivo combinado, reduzindo I/O em carreiras longas; a lista de temporadas finalizadas é validada no próprio snapshot.
- Lançamentos antigos de campeões só contam para títulos de carreira se a temporada correspondente passar na validação de conclusão.
- Percentuais anuais de poles utilizam o número oficial registrado na tabela final, e não uma contagem parcial dos registros de classificação.
- Recordes de carreira de pilotos que passaram por equipes diferentes mostram “Múltiplas equipes”, sem atribuição arbitrária à última equipe registrada.
- Empates são preservados: todos os recordistas com o mesmo valor aparecem no card.
- Sequências consecutivas verificam a continuidade real dos rounds e contam cada GP de construtores uma única vez, mesmo com dois pilotos registrados.
- Temporadas parciais não entram nos recordes anuais definitivos.
- Circuitos ausentes em registros legados não são presumidos; a pista só é exibida quando o arquivo ou o calendário persistido permite identificá-la.
- Exportação/importação de saves e do arquivo histórico continuam usando os mecanismos existentes.

## Testes adicionados
- Agregação de recordes individuais e preservação de empates.
- Sequências de vitórias de equipes sem duplicar GP por piloto.
- Separação de circuitos que compartilham o mesmo nome de GP.
- Filtragem de recordes por temporada concluída.
- Reconstrução determinística de marcos históricos sem gravações duplicadas.
- Recordes de carreira com piloto que passou por mais de uma equipe.

- VersionCode 713 / VersionName 0.713.0.
