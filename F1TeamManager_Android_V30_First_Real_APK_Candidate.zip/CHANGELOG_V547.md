# V547 — Correção da semente da simulação e limpeza do contador DNF

- A instância de corrida usada pela tela principal agora recebe uma semente aleatória por instância, em vez de reutilizar a constante fixa 20261003.
- A semente permanece fixa dentro da instância da corrida, permitindo que a sequência daquela simulação continue coerente enquanto ela está em andamento.
- Removidos `dnfLimit` e `dnfCount`, que eram sorteados/atualizados mas não participavam de nenhuma decisão. Isso não cria um teto artificial nem altera as probabilidades originais de acidentes, colisões ou falhas mecânicas.
- Mantido o motor compartilhado entre simulação instantânea e normal.
- Versão 0.547.0 (versionCode 547).

Validação: ZIP validado estruturalmente. Gradle/JUnit não executados neste ambiente.
