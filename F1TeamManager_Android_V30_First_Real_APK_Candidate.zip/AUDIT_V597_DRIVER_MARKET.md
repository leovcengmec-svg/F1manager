# Auditoria V597 — Mercado de pilotos

## Alteração
`DriverMarketEngine.interestScore` agora considera a diferença entre a força da equipe atual e a de destino. Uma queda esportiva gera penalidade de até 32 pontos.

A remuneração excepcional é calculada em relação ao salário atual do piloto (ou ao salário-base de mercado se não houver contrato): bônus de 5, 10, 18, 28 ou 35 pontos para proporções a partir de 1,25x, 1,5x, 2x, 3x e 4x. Isso torna uma mudança para uma equipe bem mais fraca improvável por salário comum, sem proibi-la quando a compensação financeira for muito alta.

## Preservação
- Base usada: V596.
- Alteração funcional limitada ao cálculo de interesse do piloto.
- Ativos, dados e histórico existentes não foram editados intencionalmente.

## Limites de validação
A inspeção do código e a verificação de integridade do ZIP não equivalem à compilação Android. Build Gradle, testes integrados e simulação completa ainda precisam ser executados no ambiente Android do projeto.
