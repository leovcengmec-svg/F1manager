# Auditoria V318 — Layout da simulação

## Estrutura verificada no código
- `Race()` em `app/src/main/java/com/f1teammanager/MainActivity.kt` continua sendo o componente principal.
- `LazyColumn` usa `s.classification`, sem limite artificial de 10 itens, com rolagem independente.
- A lista contém cabeçalho próprio e as linhas são identificadas por `driverId`.
- Os dois cards dos pilotos do jogador ficam fora da `LazyColumn`, fixos na parte inferior.
- Ambos os cards usam `animateScrollToItem(index + 1)` para compensar o item de cabeçalho e levar a lista ao piloto correto.
- A linha da velocidade foi reduzida de 30dp para 23dp e os botões de 27dp para 21dp.
- Cards fixos reduzidos para altura entre 78dp e 90dp; mantidos os indicadores de pneus, combustível, ERS, DRS, posição/diferença e botão BOX.

## Preservação
- Nenhuma alteração no motor de corrida, cálculo de classificação, tempos, estratégias, pneus ou avanço da simulação.
- Nenhuma remoção dos assets externos ou do histórico de versões.
- Nome oficial do ZIP preservado.

## Validação
- Verificação estática dos trechos modificados e integridade do arquivo ZIP.
- Compilação Android e teste físico não executados neste ambiente.
