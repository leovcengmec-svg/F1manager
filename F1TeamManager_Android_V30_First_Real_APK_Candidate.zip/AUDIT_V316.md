# Auditoria V316 — Plano de Início da Corrida

- [x] Preservados nomes, identificadores e fontes de dados dos pilotos.
- [x] Preservados `setRacePlan` e callbacks de cancelar/confirmar.
- [x] Os compostos e voltas vêm do plano ativo (`sequence` e `stintLaps`); não foram introduzidos valores de stints fictícios.
- [x] A grade usa `chunked(2)` e acomoda 1–4 stints, mantendo a ordem da sequência do motor.
- [x] A seleção A–D continua usando o callback já existente.
- [x] Removida apenas a seção visual de postura; enum/modelo e callback não foram apagados.
- [x] Versão atualizada para code 316 / name 0.316.0.
- [ ] Build Android/compilação: não confirmada neste ambiente.
- [ ] Teste em POCO X7 Pro físico: não realizado neste ambiente.
