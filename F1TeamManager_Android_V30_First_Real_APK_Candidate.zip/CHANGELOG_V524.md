# V524 — controle financeiro da temporada

- Adicionado acesso direto a um controle financeiro da temporada (56 semanas) dentro de Finanças.
- Exibe saldo, receitas e despesas reais da temporada, lançamentos semanais identificáveis e movimentações por GP.
- Não inventa valores previstos para semanas futuras ou para períodos sem registros.
- Preserva o limite de histórico existente e informa a limitação quando lançamentos antigos não estão mais disponíveis.
- Mantidos os sistemas financeiros existentes e os assets; versionCode 524 / versionName 0.524.0.
