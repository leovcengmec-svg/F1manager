# V433 — Robustez do diário de virada

- Tornado o avanço dos checkpoints monotônico: só aceita a etapa atual (repetição idempotente) ou a próxima etapa da sequência.
- Rejeita saltos, regressões e estados desconhecidos no diário de virada.
- Corrigidas duas strings com aspas mal escapadas no teste legado V431, que poderiam impedir a compilação da suíte de testes.
- Adicionado teste-fonte para a ordem e monotonicidade dos checkpoints.
- Layout e assets externos não foram alterados.
