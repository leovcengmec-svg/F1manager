# V572 — Persistência confiável do catálogo personalizado

- Catálogo de equipes, pilotos e bandeiras é gravado em uma única transação síncrona de `SharedPreferences`.
- Falha de persistência agora é reportada explicitamente em vez de ser ignorada silenciosamente.
- Em caso de falha, o catálogo em memória é reidratado a partir do último estado durável para evitar divergência até reiniciar o aplicativo.
- IDs, chaves existentes, formato JSON e localização dos assets foram preservados.
- Adicionado teste de contrato para gravação síncrona e recuperação em falha.

## Validação

O ZIP foi validado estruturalmente. O teste JUnit e a compilação Android não foram executados neste ambiente; o projeto não inclui `gradlew`.
