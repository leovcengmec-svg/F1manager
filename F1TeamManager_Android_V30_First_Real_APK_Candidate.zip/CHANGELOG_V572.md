# V572 — Resolução canônica de fotos de Heikki Kovalainen e Bruce McLaren

- Corrigida a identificação protegida pelo nome canônico, independentemente do ID salvo.
- Variações/typos que contenham `Kovalainen` agora resolvem para `Heikki Kovalainen`.
- Bruce McLaren é reconhecido pela combinação dos termos `Bruce` e `McLaren`.
- Para esses dois pilotos, o carregador usa somente o nome canônico (incluindo o prefixo `driver_`); não usa nomes numéricos nem aliases de outros pilotos.
- A chave do cache usa o nome canônico para evitar reaproveitamento de bitmap de outro cadastro.
- Mantida a estratégia anterior para os demais pilotos.
