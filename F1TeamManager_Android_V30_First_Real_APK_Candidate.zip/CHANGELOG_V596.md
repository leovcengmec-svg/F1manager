# V596 — Correção de compilação no resumo de equipes

- Corrigida a referência não resolvida `store` em `teamOverviewSnapshot()`, adicionando `CareerPreferences` como parâmetro explícito da função.
- Mantidas as validações de save por modo da V595; nenhuma alteração nos assets externos ou no histórico de versões anterior.
- Versão Android: `versionCode 596` / `versionName 0.596.0`.
- Validação Android completa ainda depende da execução do workflow com Gradle/SDK; não declarar APK compilado até obter resultado verde.

