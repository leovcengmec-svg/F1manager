# Auditoria V679 — clima independente por GP

## Causa identificada na V678

`MainActivity` mantém uma única instância de `CareerWeekendEngine` durante a carreira. Entretanto, `CareerWeekendEngine.start()` reinicializava `qualifyingRandom` e `raceWeatherRandom` usando somente a semente imutável do construtor. Como esses fluxos eram reiniciados com os mesmos valores em todos os GPs, a primeira condição meteorológica podia se repetir etapa após etapa. Em uma sequência de circuitos, o mesmo primeiro número aleatório podia cair abaixo do limiar de chuva de cada perfil e reproduzir chuva forte de modo anormal.

## Correção

- Criado `RaceWeekendSeed.forWeekend(careerSeed, season, round, circuitName)` com hash determinístico estável.
- A identidade da semente inclui a semente persistida da carreira, temporada, etapa e nome do circuito.
- `CareerWeekendEngine.start()` recebe a semente da etapa e reinicializa os fluxos isolados de qualificação e clima a partir dela.
- O início interativo e a simulação instantânea usam a mesma semente derivada para o GP atual.
- O fluxo headless de `ManagerSeasonEngine` também deriva a semente com temporada, etapa e circuito.
- Repetir/reabrir o mesmo GP mantém os mesmos sorteios; etapas diferentes deixam de reutilizar a sequência inicial.
- Mantidas as probabilidades de chuva por perfil de circuito e as regras de duração/transição da V669.

## Verificação executada

- Compilação Kotlin isolada de `RaceWeekendSeed`, `RaceModels`, `CircuitWeatherModel`, `SeasonModels` e `SeasonCalendar`: aprovada.
- Probe com o calendário real de 30 etapas: 30 sementes distintas.
- No conjunto controlado de 30 etapas: 5 estados meteorológicos iniciais distintos; 4 largadas chuvosas e 26 secas/nubladas. Não houve repetição global de chuva forte.
- Auditoria estática específica: 19/19 verificações aprovadas.
- Testes JUnit de regressão adicionados para unicidade das sementes, reprodução do mesmo GP após reload, variação entre corridas e isolamento entre qualificação/corrida.
- Integridade estrutural do ZIP: conferida após empacotamento.

## Limitações da validação

- O ambiente não possui Gradle/Gradle Wrapper disponível; a suíte JUnit completa e a compilação Android não foram executadas localmente.
- O workflow GitHub Actions está atualizado para publicar o artefato `F1-Team-Manager-V30-V679-debug-apk`. A aprovação final do APK depende da execução desse workflow.

## Versionamento

- `versionCode = 679`
- `versionName = "0.679.0"`
- Base: V678.
- Nome público preservado: **F1 Team Manager V30**.
- Nome original do ZIP preservado: `F1TeamManager_Android_V30_First_Real_APK_Candidate.zip`.
