# Auditoria de correção — Modo Time Principal V593

## Base e versão

- Base oficial usada: V592, `versionCode 592`, `versionName 0.592.0`.
- SHA-256 do ZIP da base: `6f709691af1fea57f0522a4c87d861ef2e8d276327806096f84eb03ea678ce04`.
- Candidato de correção: V593, `versionCode 593`, `versionName 0.593.0`.
- A auditoria manteve o nome de pacote/ZIP definido pelo projeto.

## Correções implementadas

### 1. Ranking inicial separado do resultado esportivo

Quando não há temporadas registradas, o painel usa `InitialTeamProfile.openingRanking(WorldDatabase.teams)` e rotula a informação como **Força inicial**. Depois da primeira temporada concluída, usa a classificação do campeonato de construtores. Na pré-temporada de temporadas seguintes — inclusive após troca de equipe, quando os pontos reiniciam — preserva a última classificação confirmada até surgirem pontos na nova temporada.

### 2. Melhor resultado sem valor inventado

Antes do primeiro resultado, a interface apresenta `—` e `Aguardando resultado`. O estado serializado usa o esquema 2. Saves no esquema 1 continuam aceitos; seu melhor resultado é migrado a partir dos registros de temporada disponíveis, e saves sem resultados ficam sem resultado esportivo (sentinela interna 40, não exibida como resultado).

### 3. Oferta externa entra em vigor na próxima temporada

`prepareAndAcceptTeamPrincipalOffer` já não grava a equipe de destino como equipe ativa no momento da assinatura. A proposta futura é persistida separadamente (`teamPrincipalPendingTeamId`/`teamPrincipalPendingCareer`). A carreira atual continua vinculada à equipe de origem até a virada. A nova equipe é ativada apenas no caminho `PREPARED` do diário de virada e somente se o contrato estiver marcado para a temporada que está começando.

### 4. Rollback e recuperação

A preparação de uma oferta registra um snapshot transacional das preferências antes de salvar handoff, estado da equipe e snapshot financeiro comercial. Se uma etapa falhar, as preferências são restauradas e os snapshots financeiros/comerciais em memória retornam ao estado anterior. Se o processo cair durante a preparação, `CareerPreferences` recupera o snapshot no próximo carregamento.

A ativação da nova equipe ocorre depois que o diário da virada cria seu próprio snapshot. Se a virada falhar antes do estado final persistido, o diário restaura a temporada e a identidade de equipe anteriores. O caminho de erro recarrega a equipe pelo ID que o save restaurou, inclusive seu orçamento-base.

## Evidências de verificação

| Verificação | Resultado | Escopo |
|---|---|---|
| SHA-256 do ZIP base | Confirmado | ZIP original V592 |
| Testes lógicos Kotlin isolados do motor de carreira | **PASS — 13 testes de regressão** | `TeamPrincipalCareerEngine.kt` real; tipos de apoio substituídos só para o harness |
| Verificação estática do contrato pendente | **PASS** | A aceitação não altera o `teamId` ativo; ativação apenas na transação de virada |
| Verificação estática do painel inicial | **PASS** | Ranking de abertura distinto do ranking após resultados; melhor resultado ausente até existir registro |
| Integridade do ZIP de saída | **PASS**, `unzip -t` sem erros | Arquivo de entrega |
| Compilação Android / suíte JUnit do Gradle | **NÃO EXECUTADA** | Sem Gradle, Wrapper no ZIP ou `adb` neste ambiente |
| Jornada real em emulador | **NÃO EXECUTADA** | Requer build Android e ambiente de execução |

## Limitações e riscos restantes

A lógica foi corrigida e os caminhos críticos foram inspecionados, mas a ausência de compilação Android impede afirmar que toda a aplicação está sem erros de integração. A simulação real de contratação deve ser validada numa instalação executável, cobrindo: assinatura na avaliação bienal, continuidade da equipe antiga até fechar a temporada, ativação da equipe contratante, continuidade do carro físico, falha induzida durante a virada e restauração do save.

**Conclusão:** V593 corrige as quatro falhas identificadas no código. A versão é candidata à validação integrada; não está homologada até passar pelo build Android, suíte JUnit e teste em emulador.
