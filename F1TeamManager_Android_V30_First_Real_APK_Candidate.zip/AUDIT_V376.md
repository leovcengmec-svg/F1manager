# Auditoria V376 — Finalização retomável na sessão

## Alterações
- `finalizeCompletedRace` captura falhas durante a finalização e evita propagar a exceção até derrubar a Activity ou marcar visualmente o GP como concluído.
- A mensagem de calendário identifica a temporada/rodada e informa que a finalização ficou pendente.
- `simulateWeekendInstantlyForCareer` verifica se já existe um snapshot concluído em memória com resultado e tenta retomar a finalização desse mesmo resultado antes de iniciar outra simulação.
- O diário `RaceFinalizationJournal` continua sendo a autoridade de ordem e replay das etapas confirmadas.

## Limites conhecidos
- Esta atualização protege retomadas na mesma sessão do processo. O snapshot completo da corrida ainda não é armazenado como payload de recuperação independente antes da primeira etapa; recuperação automática após encerramento forçado do processo antes de `race_record` continua pendente para o bloco de integração.
- A execução JUnit/Gradle e o build Android não foram executados neste ambiente: não há Gradle nem Gradle Wrapper disponível no projeto recebido.

## Preservação
- Nenhuma alteração de interface ou botões.
- Nenhuma remoção de assets externos, dados de assets ou histórico de versões.
