# Auditoria V669 — frequência e duração da chuva

## Problema observado
A calibração anterior permitia que a chuva começasse com probabilidades altas em circuitos variáveis/chuvosos, mas a chance de qualquer transição durante a prova era muito baixa (1,0% a 3,4% a cada seis voltas). Assim, quando a corrida começava molhada, uma sequência comum de verificações sem mudança mantinha a pista molhada quase até a bandeirada.

## Correções
- A chance de largada chuvosa foi recalibrada por perfil: 2% em circuitos áridos, 4% em circuitos secos, 7,5% no perfil padrão, 12% em circuitos variáveis e 20% nos circuitos mais propensos à chuva.
- As chances de uma nova frente durante a corrida ficam entre 1,2% e 4% por verificação, sem salto direto de seco para chuva.
- Enquanto a pista está molhada, a chance de uma transição em cada verificação de seis voltas passa a 52%, independentemente do baixo percentual de formação de uma nova frente.
- Cada episódio contínuo de chuva tem limite rígido de 18 voltas. Ao alcançar o limite, o clima passa obrigatoriamente para nublado.
- A saída da chuva é gradual: chuva forte pode enfraquecer para média/leve; chuva leve tende a passar para nublado.
- A sequência climática segue isolada do RNG de desempenho, incidentes e desenvolvimento dos pilotos.
- A lógica de decisão manual de pneus introduzida na V668 permanece intacta.

## Validação
- 10/10 testes de perfil e equilíbrio climático aprovados, incluindo Monte Carlo sobre os 50 circuitos em 1.000 sementes por circuito.
- 6/6 testes direcionados de integração do motor e regressão da V668 aprovados após recompilar `CareerWeekendEngine.kt` e `TyreModel.kt` com o modelo V669.
- O teste de duração verifica 2.000 sequências determinísticas e confirma que nenhum episódio contínuo ultrapassa 18 voltas.
- A auditoria estática do pacote verifica versão, reset do marcador de chuva, cap de duração, probabilidades e preservação do fluxo de escolha dos pneus.
- O ZIP foi conferido estruturalmente. O build Android/Gradle completo não foi executado neste ambiente: não há Gradle/Gradle Wrapper utilizável nem Android SDK disponível. O workflow GitHub Actions existente foi preservado; não declarar APK local como compilado.
