# V566 — Reconhecimento de bandeiras: China, Coreia do Sul e Estônia

## Alterações
- Expandido o registro de bandeiras em `ExternalAssets.kt` para aceitar códigos ISO-2 e ISO-3 e nomes comuns dos três países.
- China: `CN`, `CHN`, `China`, `Chinese`, com candidatos de arquivo prefixados `flag_` e `flags_`.
- Coreia do Sul: `KR`, `KOR`, `South Korea`, `Korea`, `Republic of Korea`, `Coreia do Sul` e variantes normalizadas.
- Estônia: `EE`, `EST`, `Estonia`, `Eesti` e variantes normalizadas.
- Atualizada a lista de países reconhecidos no componente `DriverFlag`, para não bloquear a tentativa de carregamento desses nomes.
- Mantido o carregamento de imagens externas em `Pictures/F1Manager/Assets/countries/` e nas pastas alternativas `Countries`, `flags` e `Flags`; nenhuma imagem foi incorporada ou removida.

## Validação
- Conferidas as entradas de aliases, normalização e candidatos de arquivo por verificações estáticas.
- Integridade do ZIP verificada após empacotamento.
- Não foi executada compilação Android nem teste em dispositivo nesta sessão.
