# Auditoria V395

## Correção
A linha do card “Próximo GP” dentro de `Home` referenciava `roundIndex`, variável local de `F1ManagerApp` e fora do escopo da função. A referência foi trocada por `store.roundIndex`, propriedade já usada no projeto para persistir a rodada atual.

## Verificações executadas
- Confirmado que a ocorrência problemática foi substituída uma única vez.
- Versão do app atualizada para 0.395.0 / versionCode 395.
- Integridade do arquivo ZIP verificada após empacotamento.

## Limitação
A compilação Android não foi executada neste ambiente; o build deve ser refeito no workflow Android para confirmar ausência de outros erros.
