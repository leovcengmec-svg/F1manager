# Auditoria de estabilização V712

## Escopo
Correção baseada no pacote V711 enviado: motivo das notícias de Overall, estabilidade das propostas de patrocínio e identificação do circuito no histórico.

## Verificações estáticas
- Notícias são criadas somente quando o Overall inteiro muda; texto não enumera atributos individuais.
- A causa é derivada do mesmo TickResult que atualizou os atributos e é anexada ao texto.
- Normalização da Central preserva o sufixo `Motivo:` e continua descartando delta zero.
- Semente de propostas não usa mais `Random.nextLong()` na composição da tela; depende do estado comercial da carreira.
- Cards de proposta ocupam a largura disponível e exibem as informações em linhas ampliadas.
- Novos registros `R` acrescentam o circuito ao final do registro, mantendo leitura de arquivos antigos sem o campo.
- A tela de histórico exibe o circuito; para registros antigos, o nome só é reconstruído quando a semente original daquela temporada foi persistida e restaurada. Não se inventa circuito quando a semente não existe.

## Limites
O pacote recebido não contém Gradle Wrapper e o ambiente não disponibiliza Gradle/Android SDK. A compilação Android e a suíte JUnit completa devem ser executadas no GitHub Actions. Esta auditoria não declara APK compilado.
