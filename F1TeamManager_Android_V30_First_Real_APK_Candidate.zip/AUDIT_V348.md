# Auditoria V348

## Corrigido nesta versão
- A idempotência de liquidação financeira não depende mais da lista limitada de transações (100 itens em memória / 500 persistidos).
- O ledger é mantido no estado financeiro e sobrevive à serialização normal do jogador e ao snapshot exportado das equipes de IA.
- Snapshots anteriores que não contêm o novo campo restauram ledger vazio, preservando compatibilidade estrutural.

## Ainda pendente
- O fechamento completo da carreira ainda não é uma transação atômica entre finanças, salários, patrocínios, pontuação, evolução, notícias, premiações e calendário.
- A rotina `recordRace` ainda usa a chave legada por rodada (`race_$round`); deve ser migrada com segurança para chave explícita temporada + rodada e validação de migração.
- É necessária simulação de temporadas e execução de build Android/JUnit em ambiente com Gradle disponível.
- Nenhuma alteração de interface nesta fase.
