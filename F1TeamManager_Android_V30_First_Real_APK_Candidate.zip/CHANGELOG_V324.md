# V324 — Compactação e padronização do modal de P&D

Base oficial: ZIP V323. Nome externo do ZIP preservado.

## Alterações de interface
- Reduzida a altura do cabeçalho ilustrado e o espaçamento interno do modal.
- Reduzida a altura dos três cards de foco e padronizados os ícones com Material Icons.
- Cards de complexidade com altura fixa idêntica (68 dp), ícones de barras desenhados com geometria uniforme e radio buttons nativos padronizados.
- Título e metadados em uma linha, com tamanhos menores e política de não quebra; textos longos são truncados de forma controlada em vez de empurrar os outros elementos.
- Reduzidas as alturas dos botões de ação para aproximar o conjunto da referência aprovada.
- Modal usa até 96% da altura disponível e mantém rolagem vertical como fallback para telas pequenas.

## Regras preservadas
- Não foram alterados o motor de pesquisa, duração, custos, risco, callbacks de início/cancelamento, seleção do foco/complexidade ou persistência.
- O componente e as opções continuam vindo dos dados reais do motor.

## Validação
- Inspeção estática do diff e integridade do ZIP.
- Não foi executada compilação Android nem teste em aparelho nesta sessão.
