# V622 — Redesenho compacto da tela Minha Carreira

- Nova implementação visual em `app/src/main/java/com/f1teammanager/TeamPrincipalCareerScreen.kt`.
- Cards padronizados, margens e gaps menores, cabeçalho centralizado, objetivos e conquistas em grade de duas colunas e resumo de carreira adaptado à área útil disponível em dp.
- A tela principal não possui rolagem vertical/horizontal. O card “Minha Trajetória” começa recolhido com até três temporadas; ao expandir, somente a lista interna de temporadas pode rolar, permitindo acessar um histórico longo sem movimentar o restante da página.
- A trajetória apresenta Ano, Escudo, Equipe, POS, VIT, POLE e POD com escudo carregado pelos assets reais e estatísticas provenientes do histórico salvo.
- Ícones Material substituem glifos Unicode na seção, mantendo a paleta escura/dourada e a cor verde para estados positivos.
- Preservados callbacks de HOME, avaliação contratual, dados da carreira e assets. Nenhuma estatística fictícia do mockup é gravada.
- Verificação estática e de pacote; compilação Android completa ainda precisa ser executada no pipeline, pois este ambiente não possui Gradle/Android SDK instalados.
