# V511 — Catálogo de designs concluídos

- A seção **DESIGNS CONCLUÍDOS / AGUARDANDO FÁBRICA** mantém visível somente o design de maior versão por componente, igual ao catálogo da fábrica.
- A lista de exibição não remove nem altera o histórico de P&D salvo.
- Em salvamentos legados com duplicatas da mesma versão, a seleção usa temporada e semana de conclusão como desempate determinístico.
- Versão Android atualizada para `versionCode 511` / `versionName 0.511.0`.
- Preservados ordens de fabricação, peças físicas existentes e os demais dados do jogo.
