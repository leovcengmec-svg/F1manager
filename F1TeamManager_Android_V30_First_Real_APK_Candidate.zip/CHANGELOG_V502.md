# V502 — Imagens das instalações

- Substituídos os glifos/ícones da lista de instalações por imagens de instalações já incluídas nos assets do projeto.
- Centralizado o mapeamento de cada tipo de instalação para sua imagem, reutilizado na tela de gestão e no resumo da equipe.
- Mantidos níveis, custos, descrição, barra de progresso, botões de melhoria e callbacks sem alteração de lógica.
- Desenvolvimento de pilotos usa temporariamente a imagem do simulador até existir arte específica.
- Não foram removidos nem renomeados assets externos.
- Validação executada: inspeção do patch e integridade do ZIP. Compilação Android não executada neste ambiente.
