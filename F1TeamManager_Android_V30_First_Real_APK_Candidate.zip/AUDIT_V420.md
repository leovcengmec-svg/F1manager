# Auditoria V420

- Classes de referência: € 8M, € 25M, € 45M, € 70M, € 110M e € 150M.
- Teto do projeto: € 150M.
- Testes atualizados no código-fonte; não executados neste ambiente.
- ZIP íntegro será verificado após empacotamento.
- Compilação Android pendente.
