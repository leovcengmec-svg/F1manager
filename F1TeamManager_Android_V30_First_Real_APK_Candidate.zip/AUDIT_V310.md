# Auditoria V310

- Conferido o código do card da tela Equipe.
- Posição do cabeçalho agora deriva de `ranking.indexOfFirst { it.team.id == selectedTeam.id } + 1`.
- `ranking` ordena `TeamOverviewSnapshot.garage.teamAverageOverall` em ordem decrescente, com ID da equipe como desempate estável; não usa pontos do campeonato.
- Como snapshots são recompostos com estado da garagem e desenvolvimento de IA, a classificação acompanha atualizações de força.
- Estatísticas de temporada e histórico continuam em seus caminhos próprios.
- versionCode 310 / versionName 0.310.0.
- Não foi possível executar Gradle/Android build neste ambiente; build e teste visual ainda pendentes.
