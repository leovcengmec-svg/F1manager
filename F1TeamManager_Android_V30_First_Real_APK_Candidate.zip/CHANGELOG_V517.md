# V517 — Correção do bloqueio de P&D na virada da temporada

- Corrigido o vazamento de cooldowns de pesquisa entre temporadas. Os cooldowns usam semanas do calendário da temporada atual; quando o calendário reiniciava na semana 1, valores como semana 29/31 deixavam componentes bloqueados por dezenas de semanas.
- Na virada oficial de temporada, todos os cooldowns expiram; projetos em andamento e designs concluídos permanecem preservados.
- Atualizada a versão Android para `versionCode = 517` e `versionName = 0.517.0`.
- Adicionados testes de regressão para expiração dos cooldowns e preservação de projetos/designs.
- Compilação Android e execução JUnit ainda dependem de ambiente com Gradle.
