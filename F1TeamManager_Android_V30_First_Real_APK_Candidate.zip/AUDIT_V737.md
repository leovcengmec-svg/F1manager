# Auditoria de entrega — V737

## Base e integridade
- Base de trabalho: pacote V736 anteriormente corrigido.
- Nome público mantido: F1 Team Manager V30.
- Nome do ZIP mantido: F1TeamManager_Android_V30_First_Real_APK_Candidate.zip.
- VersionCode: 737. VersionName: 0.737.0.

## Alterações verificadas no código
1. Margem de evolução: 95/100/105/110/115 libera +1/+2/+3/+4/+5, com mínimo de cinco GPs.
2. Recordes: removidas somente as duas categorias solicitadas; demais recordes não foram alterados.
3. Mercado: filtro de faixa Overall substitui o filtro de classe; faixas numéricas implementadas; linha de contagem removida; direção da ordenação identificada por texto.
4. Home: componente estruturado de transferência reaproveitado quando há metadados que correspondem à notificação; mensagem original permanece no modal.
5. Instalações da IA: metas diferenciadas por força competitiva; limites financeiros e reservas existentes permanecem ativos.

## Finanças
A V737 não força despesas iguais entre jogador e IA. O saldo é acumulado e depende de caixa inicial, receitas, salários, operação de GP, manutenção e investimentos. A implementação mantém os ledgers/idempotência existentes. Uma correção de valores sem rastrear os lançamentos da carreira poderia apagar custos legítimos.

## Validação pendente
- Build Debug APK no GitHub Actions.
- Testes unitários Android/Gradle.
- Simulação de 10 temporadas para confirmar diferenciação sustentável das instalações.
- Reconciliação de transações financeiras em saves reais da Bagos, Ferrari e McLaren.
