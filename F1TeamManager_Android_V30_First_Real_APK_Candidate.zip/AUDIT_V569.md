# V569 Audit

Scope: durable constructors standings derived from the V568 per-season/per-round point snapshots.

- No second aggregate is persisted; standings rebuild from round snapshots to avoid drift.
- Deterministic order: points descending, team ID ascending.
- Competition ranking preserves tied positions (1, 1, 3).
- Existing keys and old save format are unchanged.

Not verified: Kotlin/Android compilation, automated test execution, Compose screen integration, real device restart, or two full seasons. The new API is available to consumers; wiring it into a visible standings screen remains a subsequent integration task if no such screen exists in the current UI.
