# Auditoria V366

## Escopo

Este bloco acrescenta uma auditoria de domínio que combina o motor de fim de semana instantâneo, o ledger financeiro de GP e o snapshot persistente de patrocínios.

## Cobertura adicionada

- 60 fins de semana simulados, 30 por temporada em 2026 e 2027.
- Cada resultado passa por `InstantSimulationService.completeStartedWeekend`, incluindo validação de grid, fases de qualificação, classificação e distância.
- A liquidação financeira é aplicada duas vezes com a mesma chave temporada/GP; o estado financeiro deve ser idêntico na repetição.
- O snapshot de patrocínios é exportado/restaurado em cada GP; repetir a mesma rodada não pode consumir contrato novamente.
- No fim, são exigidas 60 chaves financeiras e 60 chaves de processamento de patrocínios.

## Estado da validação

- Inspeção estática da alteração: concluída.
- Teste JUnit V366: adicionado, não executado.
- Teste manual do motor V364: anteriormente reportado como aprovado, mas não repetido nesta etapa.
- JUnit oficial via Gradle: pendente; o pacote não inclui `gradlew` e `gradle` não está instalado.
- Build Android: pendente.
- Teste da persistência Android real (SharedPreferences/Activity): pendente.

## Limitações conhecidas

Este teste verifica os motores de domínio e o snapshot serializado de patrocínios; não substitui uma execução do fluxo `MainActivity` com `CareerPreferences`, nem prova atomicidade global entre todos os subsistemas. Nenhuma mudança visual foi feita.
