# Auditoria V419

## Alterações
- `CarDevelopmentEngine.kt`: classes, referências financeiras por classe, previsão de classe e cap dinâmico.
- `ManagerModels.kt`: teto de persistência de investimento ampliado para €75M.
- `MainActivity.kt`: painel Manter Força na tela Carro/P&D.
- `NextSeasonCarInvestmentV419Test.kt`: testes de referência adaptativa, manutenção e investimento insuficiente.

## Limitações verificadas
- Valores de referência são uma calibração inicial e devem ser balanceados após simulações de temporadas completas.
- O resultado mostrado é uma previsão de classe, não uma garantia; o carro final ainda incorpora continuidade, conhecimento e regulamentos existentes.
- APK/Gradle não compilado neste ambiente. ZIP será validado separadamente.
