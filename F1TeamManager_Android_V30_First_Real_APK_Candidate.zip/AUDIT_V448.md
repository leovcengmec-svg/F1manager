# Auditoria V448 — Ciclo geral do jogo

## Correção aplicada
O investimento do próximo carro anteriormente chamava `saveCar(...)` e `saveFinance(...)` separadamente, ambos com `apply()`. Uma interrupção do processo entre as gravações podia persistir o investimento sem seu débito. A V448 grava os campos do carro e do financeiro em uma única transação síncrona de SharedPreferences e só atualiza `managerState` após sucesso.

## Escopo validado estaticamente
- Versão/manifesto e estrutura Android.
- Journal da virada de temporada e ordem de construção do carro, aplicação do regulamento, recálculo técnico e persistência.
- Pré-validação da simulação instantânea e validação de classificação.
- Finalização idempotente de GP, pagamentos e contadores de patrocínio.
- Avanço semanal e aplicação de eventos anuais.
- Teto, limites por fase, caixa protegido, referência por Overall e coerência entre previsão e transição do carro.
- Preservação de assets e histórico.

## Limitações
Os testes Python são auditorias de contrato/fonte e cenários modelados; não substituem compilação Gradle, JUnit nem execução em Android. O ambiente não dispõe de Gradle Wrapper nem SDK Android configurado, então não se declara APK compilado ou validado em aparelho.
