# Auditoria V610 — diagnóstico de desempenho

## O que muda
V610 acrescenta log de duração por etapa do `finalizationJournal`, mantendo os logs existentes de preparação, montagem do grid, motor instantâneo e liquidação total. Isso permite identificar se os 15 segundos estão em preparação, motor ou em uma etapa específica de finalização.

## Correção de consistência
O cache de desenvolvimento de IA em V608/V609 usava somente temporada, semana e ID da equipe como chave. Porém a função recebe também capacidade, instalações e investimentos; esses valores podem mudar depois da sincronização financeira semanal. A chave agora inclui as entradas efetivas para não reutilizar uma projeção incompatível. As entradas antigas de outras semanas são descartadas.

## Relação com objetivos V598/V599
A comparação estática não encontrou chamada do gerador de objetivos no loop de voltas ou no `InstantSimulationService`. O catálogo pode gerar custo pontual na leitura/migração de uma carreira Team Principal, mas não há evidência de que explique por si só o atraso repetido de 15–20 segundos.

## Próximo diagnóstico com Logcat
Filtrar pela tag `F1TM_PERF`. As linhas `finalizationStep name=... ms=...` indicarão exatamente qual etapa domina a liquidação. Comparar `instantPreparation`, `instantEngine`, cada `finalizationStep` e `instantSettlement`.

## Limitações
Sem Android SDK/aparelho, esta auditoria não consegue executar benchmark nem confirmar ANR. A V597 independente não estava disponível para diff binário; comparação central feita com V595/V600/V609.
