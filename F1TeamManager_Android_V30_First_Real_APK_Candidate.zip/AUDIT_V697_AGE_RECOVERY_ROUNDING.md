# Auditoria v697 — recuperação agregada no ciclo etário

## Escopo
Correção pontual da ressalva registrada na auditoria v696: o uso de `toInt()` por atributo descartava individualmente frações de recuperação e podia fazer a recuperação total ficar muito abaixo de 50%.

## Implementação
1. Soma somente as perdas registradas de velocidade, ultrapassagem e defesa.
2. Calcula `round(totalPerdas × 0,50)` uma única vez.
3. Aplica primeiro a parte inteira individual e distribui os pontos restantes pelos maiores restos fracionários.
4. Usa ordem determinística para empates (maior perda e depois índice do atributo).
5. Limita a alocação ao menor valor entre a perda registrada e a distância atual até o pico histórico.
6. Preserva os ledgers dos atributos não físicos e o fluxo de persistência existente.

## Casos cobertos
- Perdas físicas ímpares 1 + 1 + 1: meta agregada arredondada para 2 pontos, e não zero.
- Capacidade histórica menor que a meta: recuperação limitada ao espaço disponível.
- Perdas pares do teste anterior: resultado anterior permanece igual.
- Atributos não físicos permanecem inalterados no teste de recuperação.

## Versão e pacote
- `app/build.gradle.kts`: versionCode 697 / versionName 0.697.0.
- `package_manifest.txt`: 697 / 0.697.0, base V696.
- Workflow: artefato identificado como `F1-Team-Manager-V30-V697-debug-apk`.
- Nome público e nome original do ZIP preservados.

## Situação da validação
- Compilação isolada de `DriverEvolutionEngine.kt`, `SeasonModels.kt`, `DriverProfileCatalog.kt` e do arquivo de testes com `kotlinc`: aprovada.
- Execução direcionada: 6/6 testes passaram, incluindo os dois novos cenários de perdas ímpares e limite do pico histórico. Foi necessário apenas um substituto temporário para a referência `RaceParticipant` não utilizada nesse teste e um shim da API JUnit; o motor, os modelos de temporada e o catálogo são os arquivos reais do projeto.
- Essa verificação valida o núcleo alterado, mas não substitui a suíte JUnit/compilação Gradle da aplicação completa.
- Compilação Android integral e suíte JUnit completa: não executadas neste ambiente. O ZIP não contém Gradle Wrapper e não há Gradle/Android SDK disponíveis; o GitHub Actions continua sendo a validação integral pendente.
