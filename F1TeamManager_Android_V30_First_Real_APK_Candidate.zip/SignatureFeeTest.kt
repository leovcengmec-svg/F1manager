import com.f1teammanager.core.manager.*

fun main() {
    val engine = DriverMarketEngine(77)
    val base = engine.initialState(2026)
    val own = base.contracts.first()
    val ownState = base.copy(contracts = base.contracts.map { if (it.driverId == own.driverId) it.copy(marketValue = 48_000_000L, years = 1, seasonSigned = 2026) else it })
    check(engine.signatureFeeForRenewal(ownState, own.driverId, own.teamId, 2026) == 24_000_000L)
    check(engine.signatureFeeFor(ownState, own.driverId, (own.teamId % 40) + 1, 2026) == 33_600_000L)
    val freeId = 101
    val freeState = ownState.copy(contracts = ownState.contracts.filterNot { it.driverId == freeId }, freeAgents = (ownState.freeAgents + freeId).distinct())
    val freeValue = engine.marketValueFor(freeId)
    check(engine.signatureFeeFor(freeState, freeId, 1, 2026) == kotlin.math.round(freeValue * .30).toLong())
    println("SignatureFeeTest: PASS")
}
