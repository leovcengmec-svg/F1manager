# Auditoria V312 — Central de Notícias

## Causa corrigida
O parser anterior retornava um único `entityId` e priorizava qualquer nome de equipe encontrado na mensagem. Em uma notícia de evolução de piloto, o ID da equipe podia então ser usado como ID de piloto, provocando foto/equipe incompatíveis quando os espaços de IDs coincidiam.

## Correção
- `NewsParsed` agora distingue `driverId`, `teamId` e `teamName`.
- `DRIVER_EVOLUTION` resolve o piloto e a equipe do evento separadamente.
- O card não deriva a equipe do piloto a partir do `teamId` estático do piloto.
- As resoluções genéricas usam correspondência por nome mais longo primeiro.

## Limites da validação
A correção foi validada por inspeção estática e checagem estrutural do arquivo/ZIP. Não foi possível confirmar compilação ou comportamento visual em execução Android neste ambiente.
