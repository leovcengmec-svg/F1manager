# V441 — Testes de invariantes do modelo financeiro

- Atualizada a versão para `versionCode 441` / `versionName 0.441.0`.
- Adicionados testes Kotlin/JUnit para verificar os 40 níveis de premiação de construtores (valores únicos, decrescentes e limites), os custos operacionais por nível de todas as equipes e a existência de orçamento inicial válido para as 40 equipes.
- Adicionada auditoria determinística de fonte para os invariantes financeiros.
- Não houve alteração de layout, exclusão de assets ou remoção do histórico.
- Limitação: os testes JUnit e a compilação Android ainda precisam ser executados em ambiente Gradle/Android.
