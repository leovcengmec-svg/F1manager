# V463 — Navegação por gesto entre equipes

- Deslizar para a esquerda no card superior seleciona a próxima equipe no ranking.
- Deslizar para a direita seleciona a equipe anterior.
- Os botões de navegação existentes continuam funcionando.
- O gesto é limitado ao card de cabeçalho, preservando o gesto de voltar do Android nas bordas e o botão Voltar da tela.
- Versão: 0.463.0 (versionCode 463).
