# V134 correction — target ranges P1..P80

Correction applied on top of V134.

- The game has 40 teams and 80 active driver positions.
- Sponsorship sporting targets now use the same opening-car ranking source as the sporting system.
- Team rank is converted to the best expected driver slot: `2 * teamRank - 1` (P1, P3, P5, ... P79).
- A two-position margin is applied on both sides and clipped to P1..P80.
- Examples:
  - Team rank 1: P3 a P1
  - Team rank 2: P5 a P1
  - Team rank 3: P7 a P3
  - Team rank 20: P41 a P37
  - Team rank 40: P80 a P77
- Qualifying and race sponsor targets use the same range.
- No other gameplay systems were changed.
