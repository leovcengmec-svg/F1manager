# V677 — auditoria da correção de compilação

## Falha reportada pelo GitHub Actions na V676
`ManagerSeasonEngine.kt:585:45 — Unresolved reference: aiFacilities`.

## Causa
`aiFacilities` é um mapa local criado em `ManagerSeasonEngine.runRound`. O método `applyDriverEvolution` tentava acessar o nome diretamente, fora do escopo onde ele foi declarado.

## Correção
- `runRound` passa o mapa `aiFacilities` ao chamar `applyDriverEvolution`.
- `applyDriverEvolution` recebe `Map<Int, TeamFacilitiesState>` como parâmetro.
- O valor padrão `emptyMap()` preserva a compatibilidade de chamadas diretas em testes e ferramentas.
- O snapshot passado é o mesmo calculado para os participantes daquele GP, então a evolução da IA usa as instalações correspondentes àquele fim de semana.

## Verificações
- Auditoria estática de integração das instalações V676 adaptada para a versão V677.
- Auditoria específica do escopo `aiFacilities`.
- Auditoria estrutural geral.
- Integridade do ZIP.

## Limitação
As verificações estáticas não substituem `:app:testDebugUnitTest` nem `:app:assembleDebug`. A compilação oficial deve ser confirmada pelo GitHub Actions.
