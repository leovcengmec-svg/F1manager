# Auditoria V381

## Escopo
Alteração visual localizada na Home, conforme solicitação do usuário.

## Conferências estáticas
- O card `CALENDÁRIO` foi removido da lista de itens da Home.
- A seção `EQUIPE` e o card `PILOTOS TITULARES` foram removidos da lista de itens da Home.
- Os atalhos rápidos e a seção `PRÓXIMA CORRIDA` foram preservados.
- Versão do aplicativo atualizada para 0.381.0 (versionCode 381).
- Não foram alterados intencionalmente os assets externos nem a lógica de simulação.

## Limitações
Build Android e testes oficiais não executados neste ambiente; esta auditoria confirma as alterações no código-fonte, não a validação visual em dispositivo.
