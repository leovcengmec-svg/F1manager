# Auditoria V354

## Alterações
- Adicionado `RaceFinalizationLocks`, com chave estável por temporada e rodada e lock compartilhado entre instâncias de Activity no processo.
- `finalizeCompletedRace` delega para um método interno executado sob o lock e revalida o marcador `complete` dentro da seção crítica.

## Escopo preservado
- Interface e botões inalterados.
- Assets e histórico de versões preservados.
- Nome físico oficial do ZIP preservado.

## Validação
- ZIP inspecionado e será verificado após empacotamento.
- Build Android e testes JUnit não executados: este pacote não contém `gradlew` e não há evidência de build executado.
- Simulação de temporadas completas pendente.

## Limitações
- O lock vale apenas dentro do mesmo processo e não substitui transações duráveis.
- A janela entre aplicar um efeito e marcar a etapa concluída continua exigindo idempotência persistente própria em cada subsistema. Esta versão não declara recuperação crash-safe completa.
