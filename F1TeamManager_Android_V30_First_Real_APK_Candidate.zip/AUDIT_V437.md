# AUDIT V437 — Teste econômico e limites de investimento

## Alterações verificadas
- Política de investimento antecipado compartilhada: `SeasonInvestmentPolicy`.
- Limites acumulados por fase de campeonato: 10%, 15%, 25%, 35%.
- Reserva de caixa protegida com piso de €2 milhões quando o caixa permite.
- Baseline do orçamento congelado na primeira aplicação do investimento, para impedir que o teto acumulado encolha a cada compra.
- IA: gastos discricionários de P&D e melhorias de instalações respeitam caixa protegido.
- Teste de cenário reproduzível em `tools/finance_test/v437_finance_stress_test.py`.

## Resultados
- Teste determinístico da política: aprovado.
- Cenário de 40 equipes por cinco temporadas: sem insolvência no cenário modelado.
- Resultado negativo importante: equipes grandes acumulam mais caixa que equipes médias e pequenas; a política de limite de investimento não resolve sozinha o desequilíbrio de receita/despesa.
- Auditorias estruturais: 32/32 e 9/9 de transição; release audit atualizado para V437.
- Integridade do ZIP: verificada após empacotamento.

## Limitações
O cenário de estresse usa as faixas de orçamento inicial, custos de GP e prêmios presentes no código, mas salários e receitas de patrocínio são hipóteses representativas explícitas. Não é uma simulação real do runtime Android. Compilação Gradle, suíte JUnit e teste em dispositivo continuam pendentes porque este ambiente não tem Gradle/Gradle Wrapper nem Kotlin compiler.
