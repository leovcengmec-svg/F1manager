# V668 — escolha obrigatória de pneus após o fim da chuva

- Corrigido o comportamento em que, após uma corrida começar com chuva e a pista secar, o motor podia executar uma troca automática para HARD (ou outro slick) sem consultar o jogador.
- Toda transição de chuva para pista seca/nublada agora pausa a corrida e solicita decisão para cada piloto do jogador que ainda esteja com INTERMEDIATE/WET.
- A ação BOX abre o seletor de pneus; em pista seca ele apresenta SOFT, MEDIUM e HARD, com recomendação visual sem aplicar o composto antes da confirmação.
- O plano automático do piloto é colocado em modo manual após a transição, impedindo que a sequência A/B/C/D faça uma troca silenciosa depois do aviso.
- Pilotos que já estão com slicks não recebem uma decisão de chuva desnecessária.
- A estratégia independente dos pilotos da IA foi preservada; a mudança afeta somente os dois pilotos da equipe do jogador.
- O fluxo de simulação instantânea sem interface usa MEDIUM como fallback neutro, nunca escolhe HARD automaticamente no fim da chuva.
- Adicionado teste de regressão para largada molhada, transição para seco, fila de decisões dos dois pilotos e aplicação dos compostos escolhidos.
