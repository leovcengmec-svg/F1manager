# Auditoria V617 — Apresentação técnica da virada de temporada

## Escopo

Implementação da apresentação visual acionada após a ação existente de iniciar a próxima temporada. A mudança é concentrada no fluxo da virada, na persistência do snapshot de apresentação e na nova tela Compose.

## Integração conferida no código

- `app/build.gradle.kts`: `versionCode = 617`, `versionName = "0.617.0"`.
- `MainActivity.kt`: `Screen.SEASON_CAR_REVEAL` é selecionada depois da transição persistida e também na recuperação de uma transição concluída.
- `SeasonCarRevealSnapshotBuilder`: constrói os valores de apresentação com os mesmos helpers de investimento e herança técnica usados pelo sistema de carro; o estágio final recebe a garagem real após aplicação do regulamento.
- O snapshot inclui temporada, equipe, overall inicial, estágio após investimento, estágio após herança, overall final, confiabilidade inicial/final, investimento e etapas aplicadas.
- `CareerPreferences.kt`: o snapshot é persistido por temporada e a exibição é marcada como vista de forma persistente; a tela não executa novamente a virada.
- `SeasonCarRevealScreen.kt`: apresenta o carro da equipe, barra animada de força, fatores em sequência, desempenho, confiabilidade e ranking. O botão de pular vai diretamente à revelação final; continuar segue o fluxo de regulamento e início de temporada.
- Ranking usa o cálculo compartilhado/cacheado da abertura para evitar executar a simulação das equipes de IA uma segunda vez.
- `SeasonCarRevealSnapshotV617Test.kt`: teste adicionado para conferir que os valores apresentados correspondem aos cálculos canônicos de investimento, herança e regulamento.

## Proteções

- A animação é apenas apresentação; não reaplica investimentos nem altera o resultado persistido.
- Não foram adicionados assets de imagem. O carro da equipe é carregado dos assets já existentes.
- Não houve alteração intencional nos cálculos de corrida, no mercado, nas finanças ou no balanceamento de desempenho.
- A V609 continua sendo a referência de desempenho do projeto.

## Limitações

O pacote não contém Gradle Wrapper e não há instalação de `gradle` neste ambiente. Portanto, não foi possível executar o build Android completo, a suíte JUnit oficial ou um teste visual em dispositivo/emulador. O ZIP e a versão serão verificados após o empacotamento; não se declara build Android aprovado.
