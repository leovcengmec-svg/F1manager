# V583 — Correção de visualização do efeito do investimento

## Problema
O painel de desenvolvimento ocupava a altura disponível sem rolagem vertical. Em telas menores, as últimas faixas do card “EFEITO DO INVESTIMENTO NA CLASSE” ficavam cortadas, dando a impressão de que a escala terminava em 120%.

## Correção
- Habilitada rolagem vertical na tela de desenvolvimento do próximo carro.
- Mantidas as faixas de efeito: 0–<50%, 50–<80%, 80–<120%, 120–<150% e >=150%.
- Adicionado texto explícito de que as porcentagens são calculadas sobre a referência do Overall atual, cujo valor varia por carro.
- A projeção continua usando `forecast.ratio = investimento / referenceInvestmentForOverall(overall)`, sem teto de 120% para o cálculo de faixa.

## Estado de validação
- Inspeção estática do código e confirmação das cinco faixas: realizada.
- Compilação Android e testes Kotlin/Compose: não executados neste ambiente.
- Teste visual em dispositivo: pendente.
