# V653 — Atratividade esportiva e fechamento do mercado de pilotos

**Base:** V652  
**Nome externo preservado:** V30  
**Version code:** 653  
**Version name:** 0.653.0

## Alterações

### 1. Atratividade dinâmica das equipes
- A classificação atual do campeonato passou a influenciar a força esportiva da equipe de forma progressiva, conforme a temporada acumula pontos.
- O peso da classificação cresce de 20% até 80%; o perfil inicial não desaparece, mas deixa de impedir que uma equipe reconstruída e vencedora seja percebida como projeto de ponta.
- Prestígio e histórico também acompanham o desempenho atual, com pesos mais conservadores para evitar que uma única corrida reescreva toda a reputação.
- O cálculo de posição usa ordenação determinística por pontos e, em caso de empate, força inicial.

### 2. Renovações reavaliadas em checkpoints
- A decisão de renovar não fica mais bloqueada por uma única tentativa durante toda a temporada.
- Cada piloto em fim de contrato pode ser reconsiderado em janelas de oito semanas.
- As chances aumentam nas semanas finais (a partir das semanas 32, 40 e 48), sem criar uma rolagem nova a cada semana.
- Pilotos que já possuem contrato futuro assinado deixam de ser avaliados novamente.

### 3. Fechamento antecipado dos elencos da IA
- A partir da semana 52, o mercado passa a verificar as vagas projetadas da próxima temporada.
- A IA tenta fechar cada vaga por meio do fluxo normal de proposta, resposta, contraproposta e assinatura futura.
- Na semana 56, propostas legadas ainda pendentes são resolvidas no último checkpoint e contrapropostas financeiramente razoáveis podem ser aceitas.
- A equipe do jogador permanece fora do fechamento automático.
- Não existe atribuição artificial de pilotos: uma vaga sem acordo continua explicitamente identificada.

### 4. Proteção contra duas negociações reservarem a mesma vaga
- `makeOffer()` agora rejeita uma proposta que tente usar uma vaga já reservada por contrato futuro ou por outra negociação pendente.
- A seleção de assentos de substituição ignora vagas já comprometidas por renovações, transferências ou contrapropostas.
- `projectedRosterForSeason()` considera pilotos que saem, pilotos que entram e titulares explicitamente substituídos.

### 5. Prazo das propostas
- O prazo normal de resposta de duas a três semanas foi preservado durante a maior parte da temporada.
- Na reta final, o prazo passa a uma semana; na última semana, a resposta é processada no próprio checkpoint para não descartar uma negociação válida na virada.

## Arquivos alterados
- `app/src/main/java/com/f1teammanager/core/manager/DriverMarketEngine.kt`
- `app/src/main/java/com/f1teammanager/core/manager/DriverMarketModels.kt`
- `app/src/test/kotlin/com/f1teammanager/core/manager/DriverMarketRenewalRealismV618Test.kt`
- `app/src/test/kotlin/com/f1teammanager/core/manager/DriverMarketCareerRealismV653Test.kt` (novo)
- `app/build.gradle.kts`

## Validação
- Compilação Kotlin direcionada do motor de mercado, modelos, banco real de equipes/pilotos, calendário e testes selecionados: concluída.
- Regressões dirigidas executadas no harness Kotlin: 9/9 aprovadas.
- Simulação de cinco temporadas com o `WorldDatabase`, `SeasonCalendar` e `DriverProfileCatalog` da base: antes e depois de cada uma das cinco viradas, 40/40 equipes mantiveram dois pilotos projetados/contratados; sem vagas abertas, propostas pendentes para a temporada seguinte ou duplicidade de pilotos/assentos.
- Auditorias estática e estrutural de release: registradas em `AUDIT_V653_DRIVER_MARKET.md` e no log `tools/race_sim_test/v653_driver_market_audit.log`.

## Limitações
- O ambiente não possui Gradle/Gradle Wrapper nem Android SDK; não foi gerado APK nem executado o conjunto oficial de testes Gradle/Android.
- Os testes Kotlin dirigidos foram compilados e executados com um substituto leve de JUnit e stubs apenas para dependências Android não usadas no fluxo de mercado. O banco de equipes, pilotos, catálogo e calendário usados na simulação foram os arquivos reais do projeto.
- O ledger financeiro Android não foi executado como aplicação. As assinaturas futuras continuam sujeitas ao débito e à validação financeira já existentes nos fluxos de `MainActivity` e `AITeamFinancialEngine`.
