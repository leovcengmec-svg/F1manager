# V134 — Metas por Faixa de Posição

## Alterações
- O ranking inicial da equipe para patrocínios passou a usar a força real do carro inicial (média dos 6 componentes), alinhado ao ranking esportivo.
- Metas de classificação e corrida de patrocinadores passaram de posição fixa para faixa de posições.
- Faixas adotadas:
  - Ranking 1: P1–P3
  - Ranking 2: P1–P4
  - Ranking 3: P1–P5
  - Ranking 4–10: ranking ±2
  - Ranking 11–80: ranking ±5, limitado a P1–P80
- Bônus de classificação/corrida são pagos somente quando o resultado estiver dentro da faixa.
- Persistência de contratos foi atualizada com compatibilidade para contratos antigos de posição única.
- UI das ofertas/contratos mostra a faixa no formato “P3 a P1”.
- Não foram alterados motor de corrida, pneus, P&D, evolução, orçamento ou demais sistemas.
