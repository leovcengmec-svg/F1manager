# Auditoria V563

## Escopo
Premiação de construtores em campeonatos com equipes personalizadas além do limite histórico de 40 posições.

## Alteração
`SeasonPrizeEngine.prizeForPosition` aceita qualquer posição positiva. Os valores de P1–P40 permanecem inalterados; a curva histórica continua após P40 até atingir o piso de €30M. Posições zero ou negativas continuam inválidas.

## Verificações adicionadas
- Valores históricos P1–P40 preservados.
- Prêmios não crescentes de P1 a P100.
- P41 continua em €39,75M.
- P100 atinge o piso de €30M.
- Posição inválida rejeitada.

## Limitações
Não houve compilação Android nem execução do conjunto de testes; não declarar simulação completa de temporadas como validada.
