# Auditoria V355 — retomada financeira

## Base
Partida do ZIP oficial V354 recebido nesta conversa. Nome físico do pacote preservado.

## Alterações
- `versionCode = 355`, `versionName = 0.355.0`.
- Novo `RaceFinalizationRecoveryV355Test`: verifica que o ledger `AI_GP_SETTLEMENT` impede repetir a liquidação após exportar e restaurar o snapshot do motor financeiro de equipes IA.
- Novo teste verifica que `seasonPrizesPaid` impede duplicar premiação de construtores após restauração.

## Resultado da inspeção
- Código e testes incluídos no pacote.
- ZIP validado estruturalmente após empacotamento.
- Build Android e JUnit não executados; não há `gradlew` no pacote nem evidência de instalação do wrapper.
- Não declarar crash-safety integral: o avanço dos contratos de patrocínio, evolução dos pilotos e outros efeitos ainda requer testes próprios de replay após processo morto.
- Interface/layout e assets não alterados.
