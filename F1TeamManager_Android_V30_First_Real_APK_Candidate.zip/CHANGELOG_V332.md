# V332 — Correção de eventos repetidos e notificações lidas

- A identidade de leitura das notícias passa a ser estável por temporada, título e mensagem, sem depender da semana em que o aviso foi gerado. Isso impede que o mesmo evento reapareça quando o motor o republica numa semana posterior.
- Mantida compatibilidade com as chaves antigas que incluem a semana, para que avisos já lidos em versões anteriores continuem reconhecidos como lidos.
- Ao abrir a Central de Notícias, são marcados como lidos todos os avisos que a Central pode exibir (temporada atual e anteriores), não apenas os da temporada atual.
- Os contadores de notícias e P&D na Home usam o mesmo critério de leitura e deixam de contar notificações históricas já vistas.
- O modal de evento na Home respeita as chaves estáveis e as chaves antigas; fechar/continuar/ver notícia marca o evento como lido.
- Aumentada a retenção de chaves de leitura de 300 para 5.000, evitando que notícias antigas voltem a aparecer após um volume elevado de eventos.
- Preservados o histórico de notícias, as categorias, os assets e a lógica de gameplay.
- versionCode 332 / versionName 0.332.0.
