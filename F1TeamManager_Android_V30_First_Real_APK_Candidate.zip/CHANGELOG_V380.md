# V380 — Reorganização da Home e do calendário

## Alterações
- Removido do Calendário o card destacado de semana atual, incluindo os botões de avanço.
- Reposicionado o resumo da semana atual na Home, acima de “Situação do Campeonato”.
- Adicionado à Home o “Quadro de Semanas”, exibindo a semana atual e as três seguintes, identificando semanas livres e semanas com GP.
- Reposicionado “Próxima Corrida” para depois do Quadro de Semanas.
- Os botões de avançar uma semana e até o próximo GP continuam ligados aos callbacks já existentes.
- Nenhuma alteração nos motores de simulação, regras de carreira, assets ou histórico anterior.
- Versão Android: `versionCode = 380`, `versionName = 0.380.0`.

## Validação
- Revisão estática das regiões Compose alteradas e das referências aos callbacks.
- Integridade do ZIP verificada após empacotamento.
- Build Android completo não executado neste ambiente; a alteração visual precisa ser validada em dispositivo/emulador.
