# Auditoria V623 — modal único para eventos da Home

## Problema observado

A Home apresentava três avisos operacionais como cards grandes dentro da lista vertical: conclusão de instalação, abertura da janela de transferência e conclusão de desenvolvimento de piloto. Isso divergia do padrão aprovado na terceira captura, onde o evento aparece em um diálogo centralizado com arte, faixa vermelha, categoria, título, temporada/semana, mensagem e ações.

## Alterações

- Removido o composable `HomeEventImageCard` e as três chamadas inline no `LazyColumn` da Home.
- Reaproveitado o diálogo existente `activeAnnualEvent` / `Dialog` de `MainActivity.kt`, evitando criar um segundo estilo visual de evento.
- Incluída a notificação de conclusão de instalação apenas quando a política `FacilityUpgradeNotificationPolicy.isPlayerCompletionNotice(...)` a identifica como pertencente à equipe do jogador; avisos de outras equipes não são indevidamente mostrados como conclusão do jogador.
- Incluída a abertura do mercado apenas quando a notificação persistida corresponde à equipe do jogador.
- A conclusão do programa de desenvolvimento é filtrada por nome de piloto da equipe atual; notificações de desenvolvimento de pilotos de outras equipes não são apresentadas como evento do jogador.
- Preservados os assets de evento existentes: `event_annual_facility_upgrade`, `notice_market_offer` e `notice_driver_development`.
- O modal mantém a estrutura aprovada: arte no topo, faixa de destaque, categoria, título, temporada/semana, texto, nota de Central de Notícias e ações CONTINUAR / ação principal.
- O botão principal de abertura da janela passou a mostrar `ABRIR MERCADO` e abrir diretamente Mercado de Pilotos. As conclusões mostram `VER NOTÍCIA`.
- Ao fechar, o evento atual é marcado como lido; eventos ainda não lidos continuam na fila modal e permanecem na Central de Notícias.
- Reconhecimento da conclusão de instalação preserva compatibilidade com o título legado, sem perder a arte/categoria no modal.

## Arquivo principal

`app/src/main/java/com/f1teammanager/MainActivity.kt`

A correção é somente de apresentação/roteamento de avisos; não altera os motores de instalações, mercado ou desenvolvimento, os cálculos, os dados do save ou os assets.

## Validação

- Busca estática confirma que `HomeEventImageCard` não tem definição nem chamadas restantes.
- Busca estática confirma que os três tipos de evento são selecionados para o diálogo existente e que a janela de transferência abre o mercado diretamente.
- O ZIP foi verificado estruturalmente e com `unzip -t`; os assets são comparados por SHA-256 com a V622.
- A compilação Android completa não foi executada neste ambiente porque não há `gradle` nem `gradlew` no projeto/ambiente disponível. O pipeline do usuário deve executar `assembleDebug` para confirmar a compilação.
