# Auditoria dos sistemas de pilotos — V702

## 1. Idade e ciclo de carreira
- A idade-base de 2026 vem do catálogo `DriverAgeCatalog` (a relação oficial do usuário).
- A idade avança uma unidade por temporada. Ao completar 43 anos, o ciclo seguinte reinicia aos 18, sem trocar o ID/identidade do piloto.
- Fatores de crescimento natural por idade: até 21 = 1,15x; 22–25 = 1,05x; 26–29 = 0,90x; 30–32 = 0,70x; 33–35 = 0,48x; 36–38 = 0,24x; 39+ = 0,10x.
- Pressão de regressão etária por GP: até 33 = 0; 34–35 = 0,08; 36–38 = 0,20; 39–41 = 0,38; 42+ = 0,55.
- O envelhecimento afeta somente velocidade, ultrapassagem e defesa. As perdas são guardadas em ledger separado. No reinício de ciclo, recupera-se 50% das perdas etárias acumuladas, limitado ao pico histórico e às perdas registradas.

## 2. Evolução por desempenho
- Titulares são avaliados por expectativa individual de classificação e corrida, derivada da competitividade do carro e da habilidade individual. O grid de pilotos usa posições 1–80; o de construtores, 1–40.
- As metas usam faixa de tolerância de ±3 posições, em vez de uma posição fixa.
- Índice de desempenho por GP converte-se em taxa: 115+ = +1,30; 105–114,99 = +1,00; 98–104,99 = +0,50; 92–97,99 = +0,20; 85–91,99 = 0; 75–84,99 = -0,20; 60–74,99 = -0,45; abaixo de 60 = -0,70.
- Pilotos livres usam baseline neutro 105, sem resultado de GP inventado nem amostra de classe, mas continuam sujeitos a idade, potencial e limite anual.
- Crescimento e regressão por desempenho usam banco fracionário próprio. Regressão não é confundida com envelhecimento e respeita piso global Overall 40/atributos 40.

## 3. Perfil de evolução e limites anuais
Limite positivo por atributo e por temporada:
| Perfil | Máximo por atributo/temporada |
|---|---:|
| Prodígio | 15 |
| Auge rápido | 13 |
| Auge moderado | 11 |
| Auge tardio | 10 |
| Normal | 8 |
| Demorado | 6 |

O perfil determina a velocidade/teto de crescimento, não a idade nem a classe. A idade multiplica a taxa natural; o potencial individual é o limite pessoal absoluto (junto de 100 por atributo).

## 4. Classe competitiva
- Escada: Médio (Overall 60–69), Forte (70–79), Pro (80–89), Lenda (90–100).
- A classe inicial vem do catálogo; a classe não é recalculada a cada GP.
- Revisão acontece a cada duas temporadas completas (2027, 2029, 2031...).
- Promoção requer evidência mínima de 80% das corridas em ambas as temporadas, índice médio de duas temporadas ≥105, cada temporada ≥100 e Overall ao menos 1 ponto acima da entrada da classe seguinte.
- Rebaixamento exige índice ≤80 em ambas as temporadas, média ≤80 e Overall pelo menos 2 pontos abaixo da entrada da classe atual.
- Para Pro → Lenda é obrigatório ter ao menos um título de pilotos na carreira. O ID do campeão é persistido em `driverCareerTitles` em toda virada, inclusive quando não há revisão de classe naquele ano. Lenda nunca é rebaixado.

## 5. Margem de Overall acima do teto da classe
- A evolução natural por desempenho pode exceder o teto da classe apenas quando a média de desempenho da temporada justificar: 110–119,99 = +1; 120–129,99 = +2; 130+ = +3.
- A margem é temporária/condicional ao desempenho da temporada; não muda a classe automaticamente.
- O potencial individual e Overall 100 continuam como limites absolutos.
- Programas explícitos das instalações podem ultrapassar o teto de classe sem essa margem de desempenho, mas respeitam potencial, 100 por atributo e limite anual do perfil.

## 6. Instalação de desenvolvimento — jogador e IA
- Bônus passivo foi removido. O nível da instalação não multiplica a evolução natural de ninguém.
- Benefícios são exclusivamente programas individuais:
| Nível | Semanas | Pontos | Vagas simultâneas |
|---:|---:|---:|---:|
| 1 | 12 | 2 | 1 |
| 2 | 11 | 3 | 1 |
| 3 | 10 | 4 | 1 |
| 4 | 9 | 5 | 1 |
| 5 | 8 | 6 | 2 |
| 6 | 7 | 7 | 2 |
| 7 | 6 | 8 | 2 |
| 8 | 5 | 9 | 2 |
| 9 | 4 | 10 | 2 |
| 10 | 3 | 12 | 2 |
- A IA tem fila persistente por equipe dentro do estado de mercado, serializada no save. A fila guarda piloto, semana de início, duração, semanas restantes e pontos. Também persiste o último tick absoluto de calendário.
- A IA usa o mesmo `DriverDevelopmentEngine` do jogador, com a mesma capacidade, duração, pontos, potencial e limite anual. Preenche todas as vagas disponíveis, prioriza maior diferença potencial–Overall, idade favorável e Prodígio, e evita começar programa quando todos os atributos já consumiram o limite anual.
- A fila é avançada pelo número de semanas reais entre GPs e é processada antes da simulação do próximo GP, para o ganho concluído entrar na corrida correta.
- Se o piloto sai da equipe antes da conclusão, a fila antiga deixa de encontrá-lo no elenco daquela equipe e o programa é descartado na próxima progressão; não transfere o programa automaticamente para outra equipe.

## 7. Contratos da IA
- Duração agora é planejada entre 1 e 5 anos em contratos iniciais, propostas, renovações, transferências e preenchimento de vagas.
- Jovens com alto potencial podem receber 4–5 anos; pilotos de alto Overall em idade de auge normalmente 2–5; pilotos em idade mais avançada tendem a 1–2. A escolha é determinística por piloto/temporada/semana para evitar resultados inconsistentes em replay.
- O contrato não é sempre 1 ano: smoke test da lista de 100 pilotos encontrou durações 1, 2, 3, 4 e 5.

## 8. Persistência e idempotência
- A fila de programas da IA e o último tick são serializados por `CareerPreferences.saveDriverMarket` e recuperados por `loadDriverMarket`.
- A virada de temporada preserva a fila; o serializador continua compatível com saves anteriores sem as novas chaves (inicializa mapas vazios).
- A evolução por GP mantém chave de idempotência `season:round`; replay não aplica o tick duas vezes.
- Os limites anuais são zerados na virada da temporada; bancos de evolução, idade e histórico permanecem.

## 9. Validação executada
- Contrato de lançamento: 28/28 verificações aprovadas.
- Núcleo Kotlin (fontes `core`, excluindo telas Compose/recursos Android): compilado com Kotlin K2.
- Smoke test: programa completou e aplicou pontos; estado de fila normalizado; contratos cobriram 1–5 anos; temporada excepcional levou Pro 89 até 92; bônus passivo permaneceu 1,0.
- Testes JUnit adicionados para filas, contratos, programas e margem de classe. A suíte JUnit integral e o APK Android ainda dependem do GitHub Actions com Android SDK.
