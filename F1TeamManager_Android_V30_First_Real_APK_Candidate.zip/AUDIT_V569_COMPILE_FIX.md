# Auditoria V569 — erro `externalAudio`

## Causa
`Race` é uma função composable separada de `F1ManagerApp`; por isso não pode acessar a variável local `externalAudio` diretamente.

## Correção
`Race` recebe `onBoxAudio: () -> Unit`. O chamador passa `{ externalAudio.playEvent("box_audio") }`, e a ação BOX chama `onBoxAudio()`.

## Checagens estáticas
- A referência direta a `externalAudio` dentro de `Race` foi removida.
- O callback foi adicionado à assinatura de `Race` e ao seu único ponto de chamada.
- O efeito `box_audio` permanece dentro da ação explícita `ManagerDecisionAction.BOX`.
- versionCode `569`, versionName `0.569.0`.

Não foi executada compilação Android nesta sessão; a confirmação definitiva depende do pipeline de build.
