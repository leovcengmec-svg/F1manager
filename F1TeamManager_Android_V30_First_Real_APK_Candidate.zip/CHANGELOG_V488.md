# V488 — Preservar piloto de substituição na contraproposta

- Corrigido o fluxo de contraproposta do mercado de pilotos: quando a negociação original já continha `replaceDriverId`, uma nova rodada agora reutiliza esse piloto se o usuário não selecionar explicitamente outro.
- O botão ENVIAR da contraproposta também usa o piloto salvo na oferta como fallback, evitando que o estado local vazio da tela apague a seleção feita anteriormente.
- A seleção explícita de outro piloto continua tendo prioridade.
- Validação estática: conferidos os dois caminhos de fallback e a passagem do identificador para `makeOffer`. Compilação Gradle integral não executada neste ambiente.
