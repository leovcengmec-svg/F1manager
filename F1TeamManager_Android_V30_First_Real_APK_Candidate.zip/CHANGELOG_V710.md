# V710 — correção definitiva de save, backup e importação após remoção do Scouting

**VersionCode:** 710  
**VersionName:** 0.710.0  
**Base:** V709  
**Nome público:** F1 Team Manager V30

## Problema corrigido

A V708 removeu o sistema de Scouting e a preferência `marketScouting`, mas a validação de integridade dos saves continuou exigindo essa chave como dado obrigatório. Como consequência, a exportação completa falhava com `Save incompleto: dado obrigatório ausente (marketScouting)`.

## Correções

- `marketScouting` foi removido da lista de preferências obrigatórias para uma carreira completa.
- Toda exportação nova sanitiza o snapshot e elimina `marketScouting` legado antes de validar o estado, contar preferências e calcular o SHA-256.
- Backups antigos com a chave `marketScouting` continuam aceitos: o aplicativo valida primeiro o payload original e seu checksum original, sem adulterar a evidência de integridade.
- Na importação, o payload validado é normalizado em uma cópia; somente a chave residual `marketScouting` é descartada antes de gravar as preferências.
- A verificação pós-importação compara o snapshot normalizado, garantindo que nenhum dado ativo necessário seja perdido e que o relatório antigo de Scouting não seja reativado.
- Os demais sistemas do mercado permanecem obrigatórios e preservados: contratos, pilotos livres, transferências, funções, pendências, notificações, avaliações de renovação e desenvolvimento de pilotos da IA.
- Não foi recriada nenhuma tela, instalação, relatório, custo ou lógica de Scouting.

## Testes e verificações

- Teste estático de exportação sem a chave antiga.
- Teste estático de importação de backup legado com a chave antiga e remoção após leitura.
- Verificação da ordem: validação/checksum original antes da normalização; gravação apenas após validação integral.
- Validação do contrato do release, versão, nome do ZIP e workflow Android.

## Limites

A compilação Android e a suíte JUnit/Gradle dependem do GitHub Actions com Android SDK. Esta revisão não declara APK compilado localmente.
