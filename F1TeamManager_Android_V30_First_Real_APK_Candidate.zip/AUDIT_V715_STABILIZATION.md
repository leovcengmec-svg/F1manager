# Auditoria de estabilização V715 — correção de smart cast da Home

## Erro reportado
O workflow V714 falhou durante `:app:compileDebugKotlin` com `Smart cast to 'HomeLastRaceSummary' is impossible, because 'lastCompletedRace' is a delegated property`, nos acessos do card de último GP.

## Correção
- `lastCompletedRace` permanece como estado Compose delegado e continua sendo atualizado por `LaunchedEffect`.
- A Home captura o valor em `val completedRace = lastCompletedRace` na mesma composição.
- O bloco de apresentação usa apenas `completedRace`, que é uma referência local estável e pode ser smart-cast após a verificação de nulo.
- Quando o estado assíncrono mudar, Compose agenda nova recomposição e o snapshot local recebe o valor atualizado.

## Verificações
- Auditoria focada da Home V714 mantida e executada com expectativa atualizada para o snapshot local.
- Teste de compilação Kotlin mínimo executado para demonstrar o padrão de correção.
- Contrato de release atualizado e executado.

## Limitações
O build Android completo não foi executado localmente: o ZIP não contém Gradle Wrapper e o ambiente não disponibiliza Gradle/Android SDK. A confirmação final de `assembleDebug` e JUnit depende da execução do workflow.
