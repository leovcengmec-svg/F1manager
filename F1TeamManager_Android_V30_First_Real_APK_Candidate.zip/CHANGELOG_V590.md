# V590 — Integração dinâmica consolidada

- Corrigida a reconciliação do mercado: pilotos vinculados pelo roster são selecionados diretamente para a própria equipe, sem depender da lista genérica de agentes livres.
- Corrigida a reconstrução final do mercado, que podia reintroduzir pilotos vinculados ao roster como agentes livres após a primeira filtragem.
- A lista final de agentes livres inclui apenas pilotos conhecidos, sem contrato/transferência agendada e realmente sem vínculo de equipe.
- IDs de pilotos declarados em dois rosters diferentes agora geram erro explícito em vez de uma atribuição ambígua.
- Mantidos contratos e transferências já salvos; a migração permanece idempotente e compatível com carreiras existentes.
- Adicionados testes de regressão para equipe nova, piloto vinculado sem vaga disponível, ausência de duplicação e colisão de roster.
- Preservados assets externos e histórico de versões; nome do ZIP oficial não foi alterado.

## Limites de validação

A integridade estrutural do ZIP e verificações estáticas podem ser executadas neste ambiente. Não há Gradle instalado nem Gradle Wrapper no projeto, portanto a compilação Android e a suíte JUnit não podem ser declaradas aprovadas aqui. Os testes adicionados precisam ser executados em CI/GitHub Actions e o jogo ainda precisa de validação ponta a ponta em dispositivo (interface, corrida, temporada e persistência).
