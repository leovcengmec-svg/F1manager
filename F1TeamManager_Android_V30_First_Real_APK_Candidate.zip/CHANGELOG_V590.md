# V590 — Garantir mudança no ranking visível ao reabrir Novo Jogo

## Correção
- A V589 já gerava uma nova semente, mas sementes distintas ainda podiam produzir exatamente a mesma ordem de equipes ou as mesmas três equipes mais fracas.
- Ao preparar a seleção, o sistema agora compara o ranking anterior com candidatos novos e continua sorteando até a ordem completa e a lista das três piores mudarem, sempre que os dados permitirem.
- A prévia continua isolada da carreira salva: somente confirmar a escolha da equipe consome a semente e a transforma na semente oficial da nova carreira.
- Teste de regressão verifica que tanto a ordem completa quanto as três escolhas do Modo Desafio diferem da seleção anterior.

## Validação
- A compilação Android/Gradle completa não está disponível neste ambiente; não afirmar que o APK foi compilado nem que o teste JUnit oficial foi executado.
