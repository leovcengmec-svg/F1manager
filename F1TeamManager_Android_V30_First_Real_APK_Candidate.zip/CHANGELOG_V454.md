# V454 — Auditoria financeira e custos por GP

- Custos operacionais por GP ajustados: equipe forte €2.500.000, média €1.500.000 e fraca €800.000; valor centralizado para jogador e IA.
- Corrigido o histórico de liquidação da IA: os lançamentos de patrocínio, premiação e custo operacional do GP não são mais substituídos pelo extrato anterior ao gravar o marcador de idempotência.
- Obrigações salariais pendentes agora entram no saldo efetivo de encerramento da temporada; caixa zerado com salários em aberto não evita a penalidade financeira.
- Mantida a proteção contra pagamentos duplicados e preservado o histórico de transações existente.
- Validação estática e integridade do ZIP realizadas. Build Android/JUnit não executados neste ambiente.
