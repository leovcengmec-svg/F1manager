# V708 — auditoria de estabilização

## Escopo
Substituição integral da instalação Scouting por Centro de Operações de Corrida, atualização de telas e disponibilização dos atributos dos pilotos.

## Pontos verificados
- [x] `FacilityType` contém sete instalações e não expõe Scouting como instalação ativa.
- [x] O decodificador migra `SCOUTING` legado para `RACE_OPERATIONS`, preservando nível e melhoria em andamento.
- [x] Jogador e IA usam o mesmo modelo de pit stop no motor compartilhado.
- [x] Redução do tempo-base, chance de atraso e reparo variam monotonamente por nível.
- [x] Atraso tem chave determinística por GP/equipe/piloto/parada.
- [x] Reparo de asa usa a mesma parada e adiciona apenas o tempo complementar.
- [x] A IA compara atributos/Overall atuais e não usa mais precisão de Scouting.
- [x] O mercado mostra sete atributos exatos vindos do perfil vigente do piloto.
- [x] UI resumo e lista de instalações apontam para nova imagem.
- [x] Relatórios antigos `marketScouting` são eliminados na migração.
- [x] versionCode/versionName, manifesto, changelog e audit apontam para V708.

## Limitação de build
A validação real de `:app:testDebugUnitTest` e `:app:assembleDebug` depende de Gradle 9.5.0, Java 17 e Android SDK 36; registrar a execução apenas quando feita no ambiente de build.
