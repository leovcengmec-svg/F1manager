# V737 — Inteligência Financeira, Instalações Dinâmicas e Interface 2.1

## Implementado nesta revisão
- Calibração de margem extra de Overall ajustada para +1 a partir de média 95, +2 em 100, +3 em 105, +4 em 110 e +5 em 115, mantendo amostra mínima de 5 GPs e teto de +5.
- Testes de regressão da calibração V734 atualizados para os novos limites.
- Recordes de carreira: removidas apenas as categorias “GPs disputados” (pilotos) e “GPs com participação” (equipes); os históricos de corridas permanecem intactos.
- Mercado: removida a linha de contagem de pilotos/equipes/temporada; removido o filtro de classe; adicionado filtro de faixas de Overall (40–60, 61–70, 71–80, 81–90, 91–100).
- Mercado: direção da ordenação agora mostra explicitamente “MENOR” ou “MAIOR”; o comparador mantém crescente para menor→maior e decrescente para maior→menor.
- Home: quando a notificação de transferência possui metadados estruturados correspondentes, usa o mesmo cartão visual de transferência da Central de Notícias, preservando o texto integral do evento.
- IA: prioridades e metas de instalações passam a variar conforme a força competitiva atual (equipes de ponta, meio do grid e reconstrução), mantendo as travas de caixa e os limites de investimento já existentes.
- Versionamento atualizado para VersionCode 737 / VersionName 0.737.0.

## Auditoria financeira
A revisão preserva a contabilização existente e não altera valores de despesas sem prova de lançamento duplicado. O ledger já mantém descrições de transações e controles de idempotência para salários, acertos de corrida e manutenção. A diferença observada entre equipes precisa ser reconciliada por categoria usando os lançamentos efetivos da carreira; não é seguro equalizar despesas apenas pela comparação de saldos.

## Limitações de validação
Não foi possível executar uma compilação Android completa nesta sessão porque o pacote não contém Gradle Wrapper e o ambiente não disponibiliza Android SDK. A atualização foi inspecionada estaticamente; o workflow GitHub Actions deve confirmar a compilação e os testes instrumentados.
