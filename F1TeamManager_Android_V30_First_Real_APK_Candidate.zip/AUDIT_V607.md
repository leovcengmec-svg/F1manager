# V607 — auditoria estática e correção de ANR

## Sintoma reportado
O Android mostrou “F1 Team Manager não está respondendo” ao avançar a carreira até a semana 8, antes de iniciar o GP. O catálogo já pode conter 41 equipes, ampliando o custo de operações que iteram todas as equipes.

## Causa estrutural encontrada
Em `app/src/main/java/com/f1teammanager/MainActivity.kt`, `advanceFreeWeeks()` percorre cada semana do intervalo. Para cada semana, chamava `syncAiWeeklyState()`, que para cada equipe da IA executava `AITeamDevelopmentEngine.simulateFinancial()` desde o início da temporada até a semana corrente. Em seguida, `advanceFreeWeeks()` fazia outra simulação histórica completa para cada equipe para produzir eventos e estado físico. Isso repetia os mesmos prefixos de temporada e resultava em custo próximo de O(equipes × semanas²) na thread que atende a interface.

## Correção V607
- A passagem semanal continua aplicando receita comercial, manutenção, patrocínios e demais ticks semanais para cada equipe da IA.
- Durante o loop de semanas, a simulação histórica completa de P&D físico é adiada.
- O fluxo que já simula a evolução física para a semana-alvo passa a ser a única simulação de desenvolvimento nesse avanço e alimenta `aiGarageCache` para a semana/temporada alvo.
- `startWeekend()` reutiliza o cache quando ele corresponde à semana atual, evitando repetir a simulação imediatamente antes da corrida.
- O cache não é apagado quando uma passagem semanal intencionalmente não recalcula a garagem.
- `versionCode` e `versionName` avançam para 607 / 0.607.0; nome do ZIP oficial mantido.

## Inventário dos arquivos de código analisados (varredura estática)
Foram listados e pesquisados os arquivos Kotlin de `app/src/main/java/com/f1teammanager` e `core/{manager,race,season}` para chamadas de simulação, loops, inicialização do mercado, grid, avanço semanal e operações de persistência. Os arquivos centrais no caminho que explica o ANR são:
- `MainActivity.kt`: coordenação de avanço semanal, sincronização da IA, cache de garagens e entrada de corrida.
- `core/manager/AITeamDevelopmentEngine.kt`: simulação determinística de desenvolvimento que repete as semanas desde o baseline.
- `core/manager/AITeamFinancialEngine.kt`: estado financeiro persistente e operações semanais.
- `core/manager/DriverMarketEngine.kt` e `DriverMarketCatalogMigrationV560.kt`: catálogo de contratos e sincronização de pilotos/equipes.
- `core/manager/ManagerSeasonEngine.kt`: simulação headless de temporada.
- `core/race/DynamicGridEngine.kt` e `ChampionshipGridRules.kt`: criação do grid a partir dos dados dinâmicos.
- `core/season/CustomWorldCatalog.kt`, `WorldDatabase.kt` e `CustomCatalogIdentityRules.kt`: persistência e identidade do catálogo.
- `CareerPreferences.kt`: persistência do calendário, carreira e resultados.

## Limites desta auditoria
A revisão estática não equivale a uma revisão semântica exaustiva de cada linha do aplicativo. Não foi possível executar a compilação Android, JUnit ou a simulação no dispositivo neste ambiente: o pacote não contém `gradlew` e não há Gradle/SDK Android configurado aqui. O ZIP foi verificado estruturalmente após empacotamento. A aprovação final requer Build Debug APK e teste no aparelho com avanço até semana 8, corrida concluída e resultado/pontuação persistidos.
