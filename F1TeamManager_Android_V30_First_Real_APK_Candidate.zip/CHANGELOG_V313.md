# V313 — Garantia de notícias de evolução de Overall

- O tick oficial de evolução por GP agora gera notícia somente quando o Overall inteiro do piloto aumenta, usando a mesma fórmula de média inteira do perfil. Mudanças em atributos que não alteram o Overall e regressões não geram card.
- Mantida a regra de um evento por piloto por GP, com prevenção de duplicação e mensagem contendo piloto, equipe do evento, GP, Overall anterior/novo e ganho.
- Aumentada a retenção da Central de Notícias de 200 para 1000 eventos para evitar que notícias de evolução sejam removidas prematuramente por outras categorias. O limite de scouting continua inalterado.
- Mantidos os dados, assets externos, histórico e demais sistemas.

Validação: inspeção estática das condições de geração, deduplicação e persistência, além de teste de integridade do ZIP. Compilação Android e teste em dispositivo não disponíveis neste ambiente.
