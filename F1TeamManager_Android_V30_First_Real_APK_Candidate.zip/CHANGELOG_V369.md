# V369 — Bloco integrado de pré-validação da simulação

- O `CareerWeekendEngine.start` valida roster e circuito antes de alterar qualquer estado: 80 pilotos, IDs únicos e positivos, nomes presentes, equipes válidas, circuito com distância/tempo-base positivos e equipe do jogador presente.
- `InstantSimulationService` valida posições e tempos por fase e reconcilia listas de eliminados de Q1/Q2 com os classificados para a fase seguinte.
- O ponto de entrada da carreira captura falhas da simulação antes de aplicar bônus de qualificação ou gravar o resultado; informa a falha no calendário sem avançar a carreira.
- Adicionados testes JUnit para IDs duplicados, circuito inválido e início válido.
- Atualizada a versão Android para 0.369.0.
- Nenhuma alteração na interface, botões ou assets externos.
