# V125 — Headless race-plan audit

## Approved rules validated
- Dry tyre life: Soft 15, Medium 22, Hard 30 laps.
- Four dry plans are generated with valid total capacity for the GP.
- Consecutive stints cannot use the same compound.
- Manager-selected dry plan executes automatically while active.
- At the planned stint boundary, the next compound is applied without a Manager dialog.
- Critical tyre wear while a dry plan is active triggers the next planned compound automatically.
- Manual BOX permanently changes that driver to MANUAL mode.
- Rain still abandons the dry plan and subsequent tyre choices remain manual.
- Attack/Balanced/Defense remain Manager-controlled.
- Live GAP UI now references the race leader, avoiding a changing reference after each overtake.

## 56-lap headless test
Generated plans:
- A: MEDIUM -> SOFT -> MEDIUM
- B: SOFT -> HARD -> SOFT
- C: SOFT -> MEDIUM -> HARD
- D: SOFT -> HARD -> MEDIUM

Selecting Plan D produced automatic changes at the planned windows:
- Start: SOFT
- after 15 laps: HARD
- after 30 hard-stint laps: MEDIUM
- race finishes on the planned final stint

Result: race completed 56/56 laps with 2 automatic pit stops and no manual tyre decision required in dry conditions.
