# Auditoria V572 — fotos dos pilotos

## Alteração
A busca estrita para Heikki Kovalainen e Bruce McLaren agora é ativada tanto pelo nome normalizado quanto pelos IDs permanentes 57 e 66. Isso evita que uma tela com nome antigo/alias faça o carregador voltar a usar nomes de arquivos numéricos.

## Limitação importante
As fotos permanecem externas. Os arquivos corretos precisam existir em `Pictures/F1Manager/Assets/drivers/` com nomes identificáveis como `Heikki Kovalainen.png` e `Bruce McLaren.png`. Se os arquivos nomeados não existirem, o carregador retorna sem foto em vez de exibir deliberadamente uma foto de outro piloto.

## Validação
- Confirmada a condição estrita por ID e nome no código.
- Confirmada versão `0.572.0` / código `572`.
- ZIP validado com `unzip -t`.
- Não foi executada compilação Android nem teste visual no aparelho.
