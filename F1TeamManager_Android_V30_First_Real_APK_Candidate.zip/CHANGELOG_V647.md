# V647 (0.647.0) — Interpolação correta da posição ordinal

- Causa raiz dos erros anteriores: `$objectiveRankº` é analisado pelo Kotlin como nome de identificador completo, não como variável seguida de ordinal.
- Corrigido para `${objectiveRank}º`; varredura nos arquivos Kotlin/KTS não encontrou mais ocorrências de `$identificadorº`.
- Sem alterações de regras do jogo.
- ZIP/validações estáticas podem ser conferidos; build Android requer confirmação de Gradle/SDK no pipeline.
