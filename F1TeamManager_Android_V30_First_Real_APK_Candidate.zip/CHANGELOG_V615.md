# V615 — Card persistente de abertura da janela de transferência

- A abertura do mercado gera uma notificação persistente na semana em que a regra do mercado passa a permitir negociações.
- A HOME renderiza o card a partir da notificação não lida da temporada atual, em vez de depender somente de uma condição visual temporária por semana.
- Saves em que o mercado já está aberto, mas a notificação nunca foi gravada, são reparados de forma idempotente ao carregar a carreira.
- A mensagem identifica a equipe do jogador; o card reutiliza a arte `notice_market_offer`.
- Ao selecionar `ABRIR MERCADO`, o aviso é marcado como lido e a navegação leva diretamente à tela de negociações.
- A Central de Notícias classifica o evento como `MERCADO DE PILOTOS`.
- Não foi criada imagem nova nem alterada a regra de elegibilidade do mercado. A condição continua centralizada em `DriverMarketEngine.marketOpen`.
- Validação isolada da política e smoke tests de idempotência aprovados. Build Android completo e teste no dispositivo não executados neste ambiente.
