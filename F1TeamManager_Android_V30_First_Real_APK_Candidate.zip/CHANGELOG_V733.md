# F1 Team Manager V30 — V733

Base: V732  
VersionCode: 733  
VersionName: 0.733.0

## Correção de compilação Android

- Adicionado o import explícito de `com.f1teammanager.core.manager.NextSeasonCarProjectionEngine` em `MainActivity.kt`.
- A classe já estava presente em `core/manager/NextSeasonCarProjectionEngine.kt`; a falha do GitHub Actions era a ausência do import na Activity.
- Os erros de inferência de tipos próximos às chamadas do motor eram erros em cascata causados pela referência não resolvida.
- Nenhuma regra de construção do próximo carro, regulamento, penalidade financeira ou inteligência financeira foi alterada nesta correção.

## Versão

- `versionCode = 733`
- `versionName = "0.733.0"`

## Validação

- Conferida a declaração do pacote da classe e sua localização no módulo `app`.
- Conferidas as cinco referências da classe em `MainActivity.kt`.
- Build Android completo não executado neste ambiente (Gradle/Android SDK indisponíveis).
