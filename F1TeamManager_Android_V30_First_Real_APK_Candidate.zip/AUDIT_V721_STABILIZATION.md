# V721 — Stabilization audit

## Scope

V721 combines the two V720 audit tracks: next-season car projection at the beginning/middle/end of a season, and the timing/persistence of annual team events that affect facilities, finances, and cars.

## Findings addressed

1. The old ranking projected AI next-car construction using only investment committed so far, applying the season-end shortfall before the season's remaining investment runway had elapsed.
2. The player's Team Ranking path built directly from current committed investment. At zero investment this mapped to the physical 40-point floor, while AI used a different planned-car path.
3. Multi-week free-calendar advancement processed all scheduled annual events only after the whole range's AI development had already run.
4. In-flight facility upgrades retained stale target levels when an earthquake/fire damaged a facility or a free annual event upgraded it.
5. AI facility maps were only persisted within the AI finance snapshot. A missing/corrupt facility row could silently fall back to the team's initial facility level.
6. The legacy annual-event scheduler duplicated weighted-selection and event-resolution logic, including an incomplete path for facility-upgrade slots.

## V721 changes

### Next-season investment projection

- `CarDevelopmentEngine.projectedNextSeasonInvestment()` is a pure projection; it never mutates the actual financial ledger.
- The forecast is bounded by the planned target, remaining GP runway, current discretionary cash, and the €150M independent next-car annual cap.
- A season-opening forecast can include the full planned investment if current cash supports it. The estimate progressively converges to actual invested value and equals actual investment after 30 completed GPs.
- `buildMarketNextSeasonCarStrengths`, `buildTeamRankingSnapshot`, and `TeamOverviewNextSeasonInvestment` now call the same helper.
- Actual season rollover still uses actual investment only and retains the €1M-per-point/per-component shortfall rule capped at 10 points per component.
- Ranking rows show both actual and projected investment for clarity.

### Annual-event processing and persistence

- `advanceFreeWeeks()` finds pending event weeks and splits the range at those boundaries. `advanceFreeWeeksSegment()` commits the event before any later segment runs.
- Player facility events rebase `managerState.facilityUpgrade`; AI facility events go through `applyAnnualEventFacilities()` and rebase the AI upgrade ledger.
- `FacilityUpgradeState.afterExternalLevelChange()` preserves the paid remaining increment after event damage or a free facility upgrade, while cancelling a project that no longer has a valid physical target.
- `saveCareerStepBundle()` commits player state, annual-event keys, per-team event car states, AI snapshots, AI budget balances, the AI facility mirror, and current week in one editor commit.
- `saveAiFinanceSnapshot()` also updates an independent facility-row mirror. `loadAiFinanceSnapshot()` merges only facility rows missing from the canonical snapshot. Canonical valid rows win.
- The legacy scheduler delegates to the shared annual event batch resolver and shared 50/35/15 weighting.

## Regression tests added

- `NextSeasonProjectionRunwayV721Test`
- `AnnualFacilityEventContinuityV721Test`

These are source-level test additions. They are not reported as executed unless the Android/Gradle test task actually runs.

## Known limits / honest status

- No V720 user save was supplied for direct replay, so V721 does not fabricate or retroactively subtract installation levels from the Benetton. If an older save already overwrote the earthquake damage, recovery requires that save's backup or an event log sufficient to reconstruct the exact state.
- The projection is a forecast from current committed investment, current discretionary cash, and remaining GP runway. Actual sponsorship, prizes, expenses, and future cash changes can cause the eventual investment to differ. The season-rollover rule remains based on actual committed investment.
- This static audit does not substitute for a full Android build, JUnit run, multi-season save/reload replay, or Poco X7 Pro test.


## Superseded by V722
The V721 €1M-per-component underinvestment behavior was identified as inconsistent with the official Overall × Investment table. V722 removes that conversion and applies the table plus the annual maximum 10-Overall loss to both player and AI.
