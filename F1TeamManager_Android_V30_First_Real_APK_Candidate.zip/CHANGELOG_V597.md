# V597 — Correção de compilação da recuperação do catálogo

- Corrigida referência fora de escopo em `CustomWorldCatalog.prepareRecovery()`: a próxima identidade de piloto recuperado agora considera `validPilotRows`, a coleção local de pilotos válidos já normalizados.
- A correção elimina o erro Kotlin `Unresolved reference: parsedPilots` e o erro derivado de inferência de `it` na linha de recuperação.
- Mantido o comportamento não destrutivo: a proposta usa os pilotos válidos reconhecidos antes de atribuir novos IDs a cópias de pilotos oficiais.
- Nome oficial do ZIP preservado.

Validação desta atualização: inspeção estática da variável corrigida e verificação estrutural do ZIP. Compilação Android e testes JUnit devem ser confirmados no GitHub Actions; não declarar build aprovado antes do resultado.
