# V597 — Balanceamento de decisões do mercado de pilotos

- A avaliação de propostas agora compara a força da equipe de destino com a equipe atual do piloto.
- Mudanças esportivamente desfavoráveis recebem penalidade, especialmente quando o piloto sai de uma equipe forte para uma equipe significativamente mais fraca.
- A remuneração é comparada ao salário atual do contrato (quando disponível); aumentos excepcionais podem compensar a perda esportiva. Aumentos normais não anulam automaticamente a penalidade.
- Mantida a estrutura existente de propostas, contrapropostas e transferências para a temporada seguinte.
- Base: V596.

Validação: revisão estática da alteração e integridade do ZIP. Compilação Android e simulação integrada não foram executadas neste ambiente.
