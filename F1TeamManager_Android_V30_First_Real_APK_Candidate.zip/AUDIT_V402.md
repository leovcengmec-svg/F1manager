# Auditoria V402

- Arquivo alterado: `app/src/main/java/com/f1teammanager/MainActivity.kt`.
- Card GERAL na identificação do piloto do modal de plano de pneus: altura 48 dp → 60 dp; largura permanece 46 dp.
- Linhas de texto com alturas explícitas para evitar clipping vertical.
- Versão: `versionCode=402`, `versionName=0.402.0`.
- Não foi executada compilação Android neste ambiente; requer build e validação visual no POCO X7 Pro.
