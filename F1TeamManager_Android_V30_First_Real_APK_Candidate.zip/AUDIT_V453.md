# V453 — Investimento da IA no próximo carro com travas equivalentes

## Diagnóstico
- O card de investimento lia `simulated.car.nextSeasonInvestment`, mas o motor de desenvolvimento da IA nunca preenchia esse campo.
- A IA não tinha uma decisão financeira dedicada para o carro da temporada seguinte.

## Correções
- Criado ledger persistente de investimento da próxima temporada por equipe/temporada no `AITeamFinancialEngine`.
- Decisão automática no fechamento de cada GP, no máximo uma vez por GP, com investimento gradual (~0,5% da liquidez disponível por decisão), sem consumir a reserva operacional.
- Reutiliza `SeasonInvestmentPolicy`: limite acumulado de 10% (GPs 1–8), 15% (9–15), 25% (16–22), 35% (GP 23+), proteção de 20% do caixa/mínimo €2M e teto absoluto €150M.
- Reserva adicional de operação da IA para salários e custos de corridas; os custos de P&D/instalações da temporada atual continuam sendo debitados antes da decisão de investimento.
- O investimento da temporada anterior é aplicado na construção do carro seguinte, preservando a continuidade anual e a regulamentação existente.
- O ledger é exportado/restaurado no snapshot financeiro da IA e o card exibe o valor persistido.
- O ano da projeção no card agora acompanha a próxima temporada, sem ficar fixo em 2027.

## Validação
- Inspeção estática das chamadas e do formato do snapshot realizada.
- Não foi possível compilar neste ambiente: o projeto não inclui `gradlew` e não há Gradle instalado. A compilação Android deve ser validada no Android Studio.
