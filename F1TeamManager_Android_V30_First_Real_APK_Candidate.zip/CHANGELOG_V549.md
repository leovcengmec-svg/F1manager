# V549 — Revolução decenal sem empilhamento e adaptação por equipe

- Nos anos de revolução decenal (temporadas 11, 21, 31...), a regra anual comum deixa de ser sorteada/aplicada; a regra decenal é exclusiva daquele ano.
- Mantidas as reduções decenais definidas para os seis componentes.
- Adicionada redução adicional aleatória de 0% a 8%, determinística por equipe e temporada, aplicada a todos os componentes apenas no ano da revolução decenal. Isso permite que equipes tenham níveis diferentes de adaptação no primeiro ano do novo regulamento.
- A mesma penalidade específica de equipe é aplicada ao carro legado e aos dois carros físicos, tanto para a equipe do jogador quanto para IA.
- Confiabilidade, probabilidades de corrida, P&D, orçamento e regras fora do regulamento decenal não foram alterados.
- Testes-fonte atualizados para exclusividade decenal e aleatoriedade estável/limitada. Compilação e execução da suíte não foram realizadas neste ambiente.
