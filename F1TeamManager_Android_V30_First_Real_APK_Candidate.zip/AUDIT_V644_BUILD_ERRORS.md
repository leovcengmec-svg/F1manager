# Auditoria V644 — Erros de compilação reportados

## Evidência recebida
O pipeline `:app:compileDebugKotlin` falhou com duas referências não resolvidas em `MainActivity.kt`:
- linha 2533: `currentTeamRank`
- linha 4693: `projectedOverall`

## Correções aplicadas
1. Na tela de carreira Team Principal, foi criada uma referência local explícita `objectiveCurrentTeamRank` e ela é usada como chave de `remember` e dentro do cálculo/descrição dos objetivos.
2. Na tela de construção do próximo carro, `projectedOverall` é definido explicitamente a partir de `forecast.projectedOverall` antes de ser usado no texto explicativo.
3. A versão do aplicativo foi incrementada para `versionCode = 644`, `versionName = "0.644.0"`.

## Escopo e limitações
- A correção é direcionada exatamente aos dois erros reportados nas capturas.
- O ambiente de trabalho não contém `gradlew` nem uma instalação `gradle` disponível, portanto não foi possível executar `:app:compileDebugKotlin` aqui.
- O ZIP deve ser validado pelo pipeline Android; não se declara build APK bem-sucedido sem esse resultado.
