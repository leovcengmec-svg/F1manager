# F1 Team Manager — V355

- Versão Android atualizada para `0.355.0`.
- Adicionados testes de regressão para replay de liquidação financeira de equipes IA após exportação/restauração do snapshot.
- Coberta também a prevenção de pagamento duplicado de premiação de construtores após restauração.
- Sem alterações de interface, botões, assets externos ou histórico anterior.

## Limitação conhecida
Os testes foram adicionados, mas não executados neste ambiente: o ZIP não contém `gradlew` nem o wrapper Gradle. A recuperação integral de todos os subsistemas do fechamento ainda exige validação de evolução de pilotos, avanço de patrocínios, notícias e fluxo completo de temporada.
