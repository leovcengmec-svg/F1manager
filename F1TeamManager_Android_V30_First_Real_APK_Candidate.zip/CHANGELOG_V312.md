# V312 — Correção de identidade na Central de Notícias

- Corrigida a resolução de identidade dos cards de evolução de piloto: o ID do piloto e o ID da equipe agora são campos separados.
- A foto/cabeçalho do piloto usa exclusivamente o ID do piloto; o escudo e o nome inferiores usam o ID/nome da equipe resolvidos separadamente.
- Nas notícias de evolução, a equipe é lida do texto do evento (formato `Piloto — Equipe — Overall...`), preservando a equipe registrada quando o evento aconteceu em vez de depender do `teamId` estático/atual do piloto.
- A busca por nomes de equipes e pilotos prioriza nomes mais longos para reduzir colisões por correspondência parcial.
- Mantidos os dados, assets externos, histórico de versões, layout e demais categorias/funcionalidades não relacionadas.

Validação realizada: inspeção estática das referências atualizadas, confirmação de ausência do antigo `parsed.entityId` na Central de Notícias e verificação de integridade do ZIP. Build Android e teste em dispositivo não executados neste ambiente.
