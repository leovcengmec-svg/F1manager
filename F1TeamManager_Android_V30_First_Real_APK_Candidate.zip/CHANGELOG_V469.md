# V469 — Correção de compilação da tela de saves

- Movida a declaração do estado `refresh` para antes do `LaunchedEffect` que o incrementa.
- Corrige o erro Kotlin de inferência de tipo e a referência não resolvida `refresh` em `SaveManagementScreen.kt`.
- Atualizada a versão Android para `versionCode 469` / `versionName 0.469.0`.
- Mantidos os recursos e os demais arquivos do ZIP de origem.
- A compilação Android ainda precisa ser confirmada no GitHub Actions.
