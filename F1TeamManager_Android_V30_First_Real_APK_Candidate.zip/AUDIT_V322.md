# Auditoria V322

## Alteração
O fluxo de avanço semanal já calculava IDs de projetos que desapareceram, mas não publicava aviso para falhas. Agora compara a lista de projetos ativos antes/depois do avanço com os novos designs criados e publica uma notificação de falha para cada projeto removido sem design correspondente.

## Efeito esperado
A notificação entra no mesmo repositório persistente de notícias do mercado usado pela Home, com temporada/semana, título e mensagem. Não altera o motor de probabilidade, os custos, o tempo, a tecnologia anterior ou o fluxo de fabricação.

## Verificações realizadas
- Conferência estática da lógica de conclusão/falha e dos campos de MarketNotification.
- Conferência do versionCode/versionName.
- Teste de integridade do ZIP.
- Compilação Android e teste no dispositivo não executados nesta sessão.
