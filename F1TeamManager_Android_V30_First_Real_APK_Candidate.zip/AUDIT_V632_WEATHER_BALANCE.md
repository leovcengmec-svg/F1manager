# V632 — Correção do clima de classificação e corrida

## Causas corrigidas
- Q1/Q2/Q3 usavam chance de mudança de 18% a cada checkpoint de 2 minutos; o novo modelo usa checkpoints de 5 minutos e probabilidades por perfil do circuito.
- O relógio meteorológico não era reiniciado entre sessões: agora `lastQualifyingWeatherCheckMs` volta a zero ao iniciar cada nova sessão, mantendo o relógio virtual sem congelar Q2/Q3.
- Na corrida, um sorteio sem mudança deixava `lastWeatherChangeLap` antigo e fazia a tentativa repetir na volta seguinte. O novo marcador `lastWeatherCheckLap` avança em cada avaliação, com tentativas somente a cada 6 voltas.
- A corrida agora sorteia seu clima inicial independentemente do clima final da classificação, uma única vez ao acionar Iniciar Corrida. O sorteio é idempotente e os planos de pneus são reconstruídos com esse clima. A simulação headless prepara o clima automaticamente no primeiro `advance()`.
- O clima é específico por circuito, com perfis árido, seco, padrão, variável e chuvoso inferidos do nome canônico usado no calendário de 50 circuitos.
- O RNG meteorológico da corrida é isolado do RNG de desempenho/incidentes; alterar o clima não desloca a sequência determinística de eventos da corrida.

## Calibração inicial
Probabilidade de chuva na largada da corrida: 2,5% em circuitos áridos, 5% secos, 10,5% padrão, 19% variáveis e 29% em circuitos chuvosos. A qualificação tem probabilidades separadas e menores. São parâmetros de equilíbrio do jogo, não previsões meteorológicas reais.

## Verificações
- Testes direcionados do perfil climático, determinismo, diferenças entre circuitos e transições adicionados em `V632CircuitWeatherModelTest.kt`.
- Testes de integração do motor adicionados em `V632RaceWeatherPreparationTest.kt`: preparação única após Q3, pneus compatíveis e inicialização automática da simulação headless.
- Execução de Monte Carlo do modelo de clima com 1.000 sementes em cada um dos 50 circuitos: 37,2% dos GPs tiveram chuva em algum momento entre classificação/corrida nesse modelo simplificado (25,4% na classificação; 17,5% na corrida, com sobreposição entre grupos). É uma calibração interna determinística do modelo, não uma previsão meteorológica real nem uma execução de 50.000 corridas completas do motor.
- Compilação Kotlin direcionada do `CareerWeekendEngine.kt` e dos testes com dependências de validação existentes: aprovada; 6 testes de perfil/modelo e 2 testes de integração passaram.
- Build Android completo e testes oficiais dependem do pipeline Gradle/Android; não marcar como aprovados sem executar o workflow.
