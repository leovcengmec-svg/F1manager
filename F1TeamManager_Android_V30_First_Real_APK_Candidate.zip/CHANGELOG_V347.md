# V347 — Idempotência do fechamento financeiro por GP

- O fechamento financeiro do time do jogador recebe a identidade temporada/GP e registra um marcador de liquidação no histórico financeiro. Repetir o callback após salvar/restaurar o estado retorna sem reaplicar pagamentos, prêmios, custos ou consumir novamente os contratos de patrocínio.
- O motor financeiro das equipes de IA registra marcador equivalente no snapshot financeiro exportado. A repetição da mesma liquidação é ignorada.
- O fluxo legado sem identidade de temporada/GP permanece compatível.
- Nenhuma tela, botão ou layout foi alterado.

## Validação
- Revisão estática dos pontos de chamada e das estruturas de persistência.
- ZIP será verificado quanto à integridade.
- Build Android e testes JUnit não foram executados neste ambiente.

## Limitação conhecida
Os marcadores ficam no histórico de transações limitado a 100 entradas do modelo financeiro. O snapshot de IA mantém até 500 entradas na exportação, mas o modelo também limita as transações ao adicionar entradas. Portanto, a proteção é voltada à repetição imediata/normal do fechamento; ainda não constitui uma transação atômica recuperável após qualquer interrupção entre subsistemas.
