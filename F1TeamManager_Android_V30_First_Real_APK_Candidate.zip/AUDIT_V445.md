# Auditoria V445 — Regulamento anual/decenal

## Resultado
- 18 IDs anuais únicos; três eventos por componente; reduções anuais de 5% a 10%.
- Revolução decenal prevista nas temporadas 11, 21, 31, 41, 51… e cobre os seis componentes.
- Temporada 1 isenta de evento anual.
- Regulamento salvo por ano de calendário e compartilhado por jogador/IA por meio da semente comum `20261005`.
- Ordem do código de transição: construção/evolução do carro, aplicação do regulamento, recriação do investimento técnico e persistência da garagem.
- Modelo matemático de 60 temporadas × 40 perfis: limites dos componentes preservados e reduções aplicadas aos componentes afetados.

## Resultado automatizado
`python3 tools/audit_v445_regulation.py` — PASS: 4.770/4.770 asserções.

## Limitações
- O modelo matemático é uma auditoria independente e não substitui teste de integração real.
- JUnit e compilação Android não foram executados porque não há Gradle/Gradle Wrapper disponível neste ambiente.
- Nenhuma afirmação de APK compilado foi feita.

## Complemento visual dos cards (mesma V445)
- `AnnualCarRegulationEventArt` resolve todos os 18 eventos a seis assets genéricos já existentes, um por componente.
- `AnnualCarRegulationEventCard` replica dimensões e hierarquia do `AnnualTeamEventCard` (imagem 164 dp, título, texto e linha de temporada), exibindo o percentual regulamentar.
- Nenhum arquivo de imagem foi criado ou alterado.
- Teste JUnit de cobertura adicionado, ainda não executado por indisponibilidade de Gradle neste ambiente.


## Complemento de prioridade de exibição
- Ordem na primeira semana: mudança de regulamento (se existir regra anual/decenal) → início da temporada → Home.
- Temporada 1 sem regra não mostra card de regulamento.
- A apresentação regulamentar é persistida como vista por temporada.
- Verificação estática concluída; não substitui compilação Android nem teste em dispositivo.
