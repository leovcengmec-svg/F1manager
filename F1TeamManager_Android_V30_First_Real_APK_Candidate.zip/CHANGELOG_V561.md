# V561 — Correções de cadeia sistêmica e estado do carro

- O carro inicial da equipe do jogador começa com seis componentes em 0 e sem peças instaladas.
- As equipes da IA preservam seu perfil Forte/Médio/Fraco com hardware-base instalado, evitando um grid inteiro de carros com desempenho zero.
- O modelo legado e a projeção física mantêm desempenho 0 sem pisos artificiais de 1/40.
- Eventos anuais, regulamento e penalidades não fabricam desempenho em componentes vazios.
- V0 na virada de temporada fica restrito a componentes instalados; a persistência respeita V0 intencional e limpa versões órfãs.
- Corrigidas associações entre perfil inicial da IA e sua projeção compatível para eventos anuais.
- Reforçada a migração de garagens legadas e o reset do núcleo ao iniciar nova carreira.
- P&D/design/fábrica/garagem/finanças; avanço semanal; instalação e melhorias de instalações agora salvam snapshots correlatos em um único `commit()`.
- O painel financeiro separa operações bloqueadas como obrigações pendentes.
- Ordenação da seleção usa o ranking oficial inicial em vez do Overall físico zerado.
- Adicionadas regressões para carro vazio do jogador versus hardware inicial da IA.
- Fortalecidos os contratos de P&D/fábrica para garantir que o desempenho físico não mude antes da instalação.
- A auditoria da virada de temporada agora exige que chaves V0 correspondam exatamente às peças instaladas.

## Limites
Validações estáticas e cenários Python passam conforme `docs/V561_SYSTEM_CHAIN_AUDIT.md`. A build Android e os testes Kotlin/JUnit continuam pendentes porque esta sessão não dispõe de Gradle/Android SDK.
