# V561 — integração da migração ao carregamento real da carreira

## Implementado
- `CareerPreferences.loadDriverMarket()` agora executa a reconciliação V560 no ponto real de carregamento do mercado, depois de desserializar contratos, agentes livres, transferências agendadas, preferências, propostas, scouting e notificações.
- O resultado migrado é persistido imediatamente somente quando difere do estado carregado, mantendo a rotina idempotente e evitando escritas desnecessárias.
- Transferências agendadas e propostas pendentes são carregadas antes da reconciliação e permanecem preservadas; pilotos comprometidos com transferência não são adicionados ao mercado livre pela migração.
- Versão Android atualizada para `561` / `0.561.0`.
- Adicionado teste de regressão para transferências agendadas, propostas pendentes e repetição idempotente.

## Limites de validação
- O ZIP foi verificado estruturalmente.
- Compilação Android e testes não foram executados neste ambiente; não há declaração de aprovação de build ou de simulação integral de temporada.
- A participação ponta a ponta de grids expandidos em qualificação, corrida, classificação, premiações e transição de temporada continua exigindo auditoria integrada.
