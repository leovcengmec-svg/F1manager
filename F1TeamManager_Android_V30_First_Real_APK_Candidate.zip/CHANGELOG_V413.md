# V413 — Ícones de pneus circulares

- Corrigido o ícone de composto na janela de escolha de pneus para o box.
- Substituído o cartão quadrado com aro simples por um símbolo circular com borracha escura, flanco, anel colorido do composto e letra central.
- Mantidos os compostos, cores, textos, estimativas de voltas, seleção, botões e layout geral da janela.
- Build Android não executado neste ambiente.
