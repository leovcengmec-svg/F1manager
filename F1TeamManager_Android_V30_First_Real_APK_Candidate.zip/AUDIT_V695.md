# v695 — implementação e validação das correções

## Diagnóstico confirmado no código v694
- `CareerWeekendEngine` sorteava um acidente coletivo com 2% de chance por volta e marcava o piloto selecionado como DNF automaticamente. Em 60 voltas, a probabilidade de pelo menos um evento era aproximadamente 70%, antes de ponderar bandeiras e pilotos já abandonados.
- A chance de DNF em colisões secundárias era de 40%.
- O peso de carro/ piloto era 65/35 em seco, 55/45 em chuva leve/média e 50/50 em chuva forte.
- `CarDevelopmentEngine.MAX_SEASON_DEVELOPMENT_GAIN` permitia até 72 pontos de atributos por temporada, independentemente do Overall atual.

## Alterações v695
- Incidente global reduzido para 0,6% por volta como referência, ajustado pelo risco do circuito e limitado a 0,2–0,9%.
- Seleção do piloto ponderada por consistência e habilidade em pista molhada.
- Apenas acidentes graves provocam DNF direto; incidentes recuperáveis causam perda de tempo e desgaste adicional.
- DNF secundário em colisão reduzido para 20%, com limite de abandonos por incidente.
- Peso do carro elevado para 70/30 em seco, 60/40 em chuva leve/média e 55/45 em chuva forte.
- Desenvolvimento anual do carro agora tem limite progressivo: 42 pontos (Overall 0–59), 36 (60–74), 30 (75–84), 24 (85–92) e 18 (93–100).

## Correções complementares incorporadas no pacote v695
- Curva de idade sintética e estável por perfil de desenvolvimento, crescimento desacelerado após o auge e regressão natural em idade avançada, sem exigir migração de save.
- Crescimento de agentes livres reduzido para 45% da taxa natural, sem fabricar resultados esportivos.
- Notícias de evolução e perda de Overall com valor anterior/novo e motivo, incluindo agentes livres; quedas recebem título explícito “REGRESSÃO DE PILOTO” tanto na carreira quanto no modo Team Principal.
- Mantidos potencial individual e expectativas individualizadas no grid de 80 pilotos, sem misturar a escala 1–80 com o ranking de construtores 1–40.
- Snapshot físico dinâmico de Overall publicado pela simulação técnica da IA e utilizado pelas mentalidades financeiras quando disponível; os envelopes de €200M e €150M permanecem independentes.
- Interpolação contínua dos seis componentes e demanda específica por circuito no cálculo de ritmo.

## Limitações
- Não foi executada simulação de dez temporadas nesta execução.
- Não foi possível confirmar compilação Android local sem Gradle wrapper/instalação Gradle e SDK Android. A compilação final deve ser confirmada pelo GitHub Actions.
