# Auditoria V588 — Isolamento do painel Team Principal

## Objetivo
Garantir que o painel de prestígio, objetivos, conquistas e histórico da carreira Team Principal não apareça nos modos Livre ou Difícil.

## Achados na V587
A HOME mostrava o card quando `teamPrincipalCareer()` retornava estado. O estado era normalmente removido ao começar uma carreira nova, mas a visibilidade não era vinculada a um marcador explícito de modo ativo.

## Correção
- `CareerPreferences` agora persiste `activeGameMode` (`FREE`, `HARD`, `TEAM_PRINCIPAL`).
- `isTeamPrincipalMode()` exige um estado serializado válido e o modo ativo Team Principal. Para saves antigos sem o marcador, migra o modo quando existe estado Team Principal válido.
- `teamPrincipalCareer()` retorna estado somente no modo correto, protegendo também as telas de carreira e avaliação.
- A HOME verifica explicitamente `isTeamPrincipalMode()` antes de inserir o card.
- `startNewCareer()` limpa `teamPrincipalCareer` e handoffs antigos e volta o marcador para `FREE`; a seleção grava o modo escolhido, e a inicialização Team Principal grava o marcador definitivo.
- Adicionado teste em `V586TeamPrincipalCareerEngineTest.careerPanelIsRestrictedToTeamPrincipalMode`.

## Resultado das verificações
- Inspeção estática: as condições de persistência, migração e renderização foram verificadas.
- Teste Kotlin isolado do predicado: 6/6 cenários passaram (Team Principal válido; Livre; Difícil; modo Team Principal sem estado; save antigo sem marcador com estado; ausência de estado).
- Integridade do ZIP: verificada após a criação.
- Não foi executada build Android nem suíte oficial Gradle/JUnit. Este ambiente não contém o wrapper `gradlew` e não tem Gradle instalado.
