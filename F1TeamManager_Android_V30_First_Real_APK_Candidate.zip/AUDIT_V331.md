# Auditoria V331

## Arquivos alterados
- `app/src/main/java/com/f1teammanager/MainActivity.kt`
- `app/src/main/res/drawable-nodpi/factory_generic_piece.webp`
- `app/build.gradle.kts`
- `CHANGELOG_V331.md`
- `AUDIT_V331.md`

## Verificações estáticas
- Versão interna atualizada para `versionCode 331` / `versionName 0.331.0`.
- O modal usa um `Dialog` customizado, sem `verticalScroll`/`LazyColumn` internos.
- Os valores atuais de desempenho e confiabilidade são obtidos do estado da garagem para ambos os carros.
- A imagem do carro continua usando `TeamCarCompact` e os assets externos já existentes.
- A seleção de instalação continua chamando `installPendingPiece` para o carro escolhido.
- O ZIP foi verificado com `ZipFile.testzip()` após empacotamento.

## Limitações
A compilação Android e a inspeção visual no dispositivo não foram executadas neste ambiente. O encaixe final deve ser confirmado no POCO X7 Pro.
