# F1 Team Manager — V365

## Bloco: integração do fechamento da corrida e retomada por etapa

- Extraído o diário de finalização por temporada/GP para `RaceFinalizationJournal`, usado pelo fluxo real de `MainActivity`.
- Mantida semântica at-least-once: a etapa só é marcada depois da ação; falha de ação ou de persistência é propagada. Cada subsistema continua responsável pela própria idempotência no intervalo entre efeito e marcador.
- O fechamento resolve uma definição estável do GP a partir da temporada/rodada capturadas no início, em vez de depender do objeto de rodada atual da interface para gravar o histórico e gerar notícias.
- O pagamento de construtores e a penalidade de fim de temporada usam a identidade de temporada capturada pelo fechamento.
- Adicionados cinco testes de regressão para repetição, isolamento por temporada/rodada, falha de ação, falha de commit do marcador e rodada inválida.
- Atualizados `versionCode=365` e `versionName=0.365.0`.
- Nenhuma alteração de interface, botões ou assets externos.

## Limitações

- Os testes JUnit e o build Android completo ainda precisam ser executados via Gradle/Android SDK.
- O diário não transforma efeitos de subsistemas diferentes em uma única transação; os marcadores locais de finanças, salários, patrocínios, evolução e premiação continuam necessários.
