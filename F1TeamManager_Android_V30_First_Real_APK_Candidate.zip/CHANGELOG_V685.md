# V685 — duração de patrocínios por nível do Centro Comercial

Base: V684  
VersionCode: 685  
VersionName: 0.685.0

## Duração dos contratos
- Níveis 0, 1 e 2: restaurada a duração anterior de 3 a 10 GPs.
- Níveis 3 a 10: mantida a duração atual de 8 a 16 GPs introduzida na V683.
- A faixa é definida pelo nível comercial vigente no momento em que a proposta é gerada e assinada.
- Contratos já assinados em saves existentes mantêm integralmente sua duração negociada; upgrades de Centro Comercial não alteram contratos ativos.
- A geração inicial de contratos, ofertas do jogador, renovações automáticas da IA e projeções financeiras respeitam a política por nível.
- A avaliação da IA considera a duração efetiva de cada proposta, sem forçar contratos curtos dos níveis 0–2 para a faixa 8–16.

## Testes e auditoria
- Testes adicionados para todos os níveis 0–10, contratos iniciais, renovações e preservação de acordos já assinados.
- Auditoria de três temporadas atualizada para validar a faixa correta por nível em cada equipe e GP.
- Mantidos o reequilíbrio econômico V683 e a correção de compilação V684.

## Validação
- Verificações estáticas de política, geração, renovações, testes e metadados realizadas localmente.
- A execução JUnit e a compilação APK ainda devem ser confirmadas pelo GitHub Actions, pois este ambiente não inclui Gradle Wrapper nem Gradle instalado.

ZIP oficial preservado: `F1TeamManager_Android_V30_First_Real_APK_Candidate.zip`.
