# V646 (0.646.0) — Correção robusta do escopo do ranking de objetivos

- O cálculo dos objetivos Team Principal resolve a posição atual localmente dentro do próprio bloco `remember`, usando o mapa de classificações e o fallback persistido da carreira.
- Eliminadas as referências a `currentTeamRank` dentro do cálculo dos objetivos, que continuavam falhando no pipeline reportado. A variável permanece somente para alimentar o painel de carreira fora desse cálculo.
- `projectedOverall` permanece declarado antes do primeiro uso na tela de construção.
- A compilação Android completa ainda deve ser confirmada no pipeline; não declarar o APK validado até o build terminar com sucesso.
