# Auditoria V401

- Alterado somente o tamanho dos dois cards de carro no diálogo `PEÇA PRONTA`.
- Altura anterior: 122 dp. Nova altura: 150 dp.
- Ambos os cards usam a mesma altura e mantêm imagem do carro, desempenho e confiabilidade.
- `versionCode=401`, `versionName=0.401.0`.
- Não foi executada compilação Android neste ambiente; validar o APK e o layout no dispositivo.
