# V736 — Correção do Build Debug APK

## Erro reportado

O GitHub Actions falhou em `:app:compileDebugKotlin`, reportando em `MainActivity.kt` que `Modifier.align(Alignment.BottomCenter)` não podia ser chamado com receiver implícito.

## Causa

O `SnackbarHost` havia sido colocado dentro da `Column` de conteúdo, enquanto `Alignment.BottomCenter` requer `BoxScope.align`.

## Correção aplicada

O `SnackbarHost` foi movido para ser irmão da `Column`, diretamente dentro do `Box` externo do `DriverMarket`. Com isso, `Modifier.align(Alignment.BottomCenter)` recebe o escopo correto. Preservados largura, padding, alinhamento e snackbar temporária de aproximadamente três segundos.

## Validação

- Inspeção do escopo do Compose após a movimentação: concluída.
- Validador de contrato da release: 135/137; duas falhas preexistentes da base V735 e não relacionadas ao patch permanecem documentadas em `AUDIT_V736.md`.
- Build Android: precisa ser reexecutado no GitHub Actions; este ambiente não possui Gradle/Gradle Wrapper nem Android SDK instalados. Não declarar APK compilado até o workflow terminar com sucesso.
