# V436 — Correção automática de pneus em transições climáticas

- Corrigido o plano automático dos pilotos da equipe do jogador: agora corrige o composto incompatível assim que o clima muda, sem aguardar a próxima janela de pit planejada.
- Escolhas manuais de pneus continuam sob controle do jogador.
- Encontrado por simulação determinística de corridas com clima variável (seeds 8 e 9).
- Validação runtime em progresso; build Android/JUnit depende de ambiente Gradle/SDK.
- A auditoria de pneus foi refinada para distinguir planos realmente automáticos de planos explicitamente colocados em modo manual após decisão do jogador.
- Resultado final no núcleo Kotlin: 25 corridas determinísticas concluídas com cobertura de todas as condições climáticas; 60 GPs em duas temporadas; 3.066 assertions de eventos anuais sem falhas.
