# V466 — Diálogo de saída e retorno ao menu inicial

- Adicionada a opção **TELA INICIAL** ao diálogo de saída quando o jogador está na Home da carreira.
- A ação retorna a `Screen.MAIN_MENU` e reinicia a navegação visual em `Nav.HOME`, sem apagar ou reiniciar a carreira salva.
- Reestilizado o diálogo com o tema escuro, painéis grafite, texto branco/cinza e vermelho `Red` do F1 Team Manager.
- Mantidos os comandos de continuar jogando e sair do aplicativo.
- A compilação Android precisa ser executada no ambiente de build para validação final.
