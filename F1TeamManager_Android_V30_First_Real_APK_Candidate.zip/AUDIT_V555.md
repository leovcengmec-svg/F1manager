# V555 — Auditoria das substituições de pilotos

## Alterações
- Leonardo Vicente — Brasil — Pro — Prodígio (substitui Brando Badoer)
- Daniel Ricciardo — Austrália — Pro — Prodígio (substitui Roman Bilinski)
- Felipe Drugovich — Brasil — Forte — Prodígio (substitui Carlos Pace no mercado de reservas)
- Lyam Vicente — Brasil — Pro — Prodígio (substitui Pedro Clerot)

## Verificações estáticas
- Nomes atualizados na base inicial e no catálogo de perfis.
- Países atualizados na base mundial.
- JSONs de cadastro de pilotos atualizados.
- Referências antigas removidas dos arquivos de runtime e assets de cadastro.
- versionCode 555 / versionName 0.555.0.
- Não foi executada compilação Android; este relatório não declara o APK validado.
