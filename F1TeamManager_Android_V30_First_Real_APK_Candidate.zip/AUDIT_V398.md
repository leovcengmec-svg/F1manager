# Auditoria V398

## Causa confirmada
`SeasonCalendar.forSeason()` cria `crashRisk` até 1,17, `reliabilityRisk` até 1,12 e `safetyCarRisk` até 1,20. `InstantSimulationService` rejeitava qualquer valor acima de 1,00. Isso fazia a simulação instantânea falhar em calendários válidos, antes de `engine.start()`.

## Correção
A validação aceita multiplicadores finitos de 0,00 a 1,25. Os valores gerados pelo calendário e a semântica de multiplicador do motor são preservados.

## Validação executada
- Inspeção estática do gerador do calendário e dos pontos de consumo dos multiplicadores.
- Verificação da alteração e dos metadados da versão.
- Build Android e testes automatizados ainda não executados neste ambiente.
