# Histórico recente

## V468
- Corrige a chamada de diálogo incompatível que impedia `compileDebugKotlin`.
- Mantém as opções CONTINUAR, TELA INICIAL e SAIR no padrão visual do jogo.

## V467
- Reforço do salvamento local antes de sair ou retornar ao menu inicial.
