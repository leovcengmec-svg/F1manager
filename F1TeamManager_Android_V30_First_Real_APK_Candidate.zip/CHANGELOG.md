# V715 — correção de compilação do painel do último GP

- Corrigido o erro Kotlin de smart cast da propriedade Compose delegada `lastCompletedRace`: o valor é capturado em `val completedRace` e todas as leituras do card usam a referência local estável.
- A atualização assíncrona continua gravando no estado delegado; novas recomposições refletem o resultado atualizado.
- Nenhuma regra de campeonato, finanças, histórico, atalhos, save ou motor de corrida foi alterada.
- VersionCode 715 / VersionName 0.715.0; base V714.

# V714 — Home reformulada e painel dinâmico da carreira

Base: V713 / 0.713.0. Nome público F1 Team Manager V30 e nome original do ZIP preservados.

## Situação do Campeonato
- Reformulado o painel da Home com classificação de construtores, posição e pontos dos dois pilotos, situação financeira e resultado do último GP.
- Construtores usam a mesma tabela oficial de pontos e ordenação da tela Campeonato; o painel mostra equipe imediatamente acima/abaixo e a diferença de pontos.
- Pilotos usam contratos ativos da temporada e a mesma ordenação da tela Campeonato; nomes completos, posição individual e pontos são exibidos para os dois titulares.
- Financeiro separa caixa atual, limite técnico restante e capacidade técnica imediata após a reserva operacional; não confunde saldo com teto anual.
- Último GP usa o arquivo histórico oficial, exibindo GP, circuito, temporada/round, posição e pontos dos dois pilotos da equipe e total de pontos da equipe. Inclui fallback para resultado legado em SharedPreferences quando o arquivo histórico ainda não foi reconstruído.
- Leitura do arquivo histórico é feita em Dispatchers.IO e armazenada para a entrada/estado corrente da Home, evitando I/O em cada recomposição.

## Acesso Rápido
- Reorganizado em três grupos: Competição (4), Gestão da Equipe (6) e História e Estatísticas (3).
- Os 13 atalhos existentes abrem suas telas funcionais: Fim de Semana, Calendário, Campeonato, Temporada, Equipe/Instalações, Pilotos, Mercado, Carro/P&D, Finanças, Central de Notícias, História, Hall da Fama e Recordes.
- Cards de construtores e pilotos abrem a aba correta da tela Campeonato; Financeiro e Último GP abrem Finanças e História, respectivamente.
- Preservados card do próximo GP, navegação inferior e rotas originais.

## Integridade e testes
- Nenhuma fórmula esportiva, financeira ou de temporada foi alterada; a mudança é de apresentação e navegação.
- Contrato de release V714 inclui verificações estáticas do painel, dados oficiais, circuito do último GP, 13 atalhos e destinos.
- Compilação Android integral e suíte JUnit dependem do Gradle/Android SDK no GitHub Actions; este ZIP não inclui Gradle Wrapper e o ambiente de edição não possui essas ferramentas.

- VersionCode 714 / VersionName 0.714.0; base V713.

# V713 — Central Livro de Recordes

- Implementada a Central de Recordes com Visão Geral, Pilotos, Equipes, Circuitos e Temporadas.
- Cards individuais, filtros por carreira/temporada e preservação de empates.
- Reconstrução automática e somente de leitura a partir do arquivo oficial de GPs, poles, campeões e temporadas concluídas.
- A tela usa um snapshot obtido com uma única leitura do arquivo combinado, validando as temporadas finalizadas no próprio snapshot para evitar múltiplos acessos a shards em carreiras longas.
- Recordes por circuito usam a pista exata; GPs homônimos em circuitos diferentes permanecem separados.
- Temporadas parciais não entram nos recordes anuais definitivos; percentuais de poles usam os resumos oficiais de temporada; sequências de construtores contam cada GP uma vez.
- Pilotos com histórico em mais de uma equipe são identificados como “Múltiplas equipes” nos recordes de carreira, sem atribuição arbitrária a uma única escuderia.
- VersionCode 713 / VersionName 0.713.0; base V712.

# V712 — notícias com motivo, propostas estáveis e histórico por circuito

- Central de Notícias mantém o feed restrito a mudanças reais de Overall, mas volta a exibir o motivo da evolução/regressão: desempenho esportivo, declínio natural da idade, evolução natural ou recuperação parcial do ciclo etário. Os sete atributos continuam sendo processados internamente e nunca são listados na notícia.
- Normalização de notícias legadas mantém um motivo explícito V712, remove referências a atributos e continua descartando alterações de atributos sem mudança de Overall.
- Propostas de patrocínio passam a usar semente determinística vinculada à equipe, temporada, GP, nível do Centro Comercial e portfólio ativo. Sair e reabrir Finanças não altera as três propostas; elas só mudam quando o estado comercial que define o mercado muda.
- Cards de propostas passam de três colunas estreitas para cards empilhados em largura total. Fontes, valores, metas, quantidade de corridas e botão foram ampliados; linhas de detalhe não são truncadas por limite de uma linha.
- Histórico de corridas passa a gravar o circuito junto ao nome do GP em cada registro. A interface exibe GP + circuito + equipe/piloto, diferenciando por exemplo os vários GPs dos EUA. Registros antigos tentam recuperar o circuito pelo calendário persistido; se não houver dado, mostram “Circuito não registrado”.
- Mantidos compatibilidade com registros históricos antigos, saves, backups, nome público e nome original do ZIP.
- VersionCode 712 / VersionName 0.712.0; base V711.

# V711 — Central de Notícias mostra apenas evolução/regressão de Overall

- A categoria Evolução de Pilotos agora publica cartões apenas quando o Overall exibido realmente muda; alterações em atributos individuais que mantêm o mesmo Overall não geram notícia.
- Cards mostram somente piloto, equipe, GP e Overall anterior → novo com delta, sem códigos/nome de atributos ou explicações de alterações internas.
- Aplicado à carreira e ao modo Team Principal, incluindo contratados e agentes livres.
- A outbox antiga é saneada na publicação: notícias legadas de delta zero são descartadas e as demais são normalizadas sem detalhes dos atributos.
- O motor continua evoluindo/regredindo os sete atributos internamente; apenas a Central fica limitada ao Overall.
- VersionCode 711 / VersionName 0.711.0; base V710.

# V710 — correção de save, backup e importação após remoção do Scouting

- Corrigido erro `Save incompleto: dado obrigatório ausente (marketScouting)`: a preferência removida deixou de ser obrigatória no snapshot completo.
- Novas exportações removem a preferência residual de Scouting antes de contar e calcular o checksum dos dados.
- Backups antigos com `marketScouting` são validados integralmente com seu checksum original e normalizados durante a importação, descartando apenas o relatório obsoleto.
- A verificação pós-importação considera o snapshot normalizado. As demais preferências do mercado e o histórico completo continuam protegidos por validação e checksum.

# V709 — envelhecimento completo, pilotos livres e trava de Overall do próximo carro

- Envelhecimento natural e recuperação parcial de ciclo abrangem VEL, CLA, ULT, DEF, CON, CHU e PNE, com piso 40 e limite nos picos históricos.
- Pilotos sem equipe evoluem naturalmente além do teto de classe até o potencial individual; regressão esportiva é desativada para agentes livres e saldos negativos herdados de contrato são descartados.
- Notícias detalham causa e atributos realmente alterados, separando envelhecimento, desenvolvimento natural, desempenho esportivo e recuperação de ciclo.
- Próximo carro trava aportes na meta anual de Overall/investimento e o motor rejeita valores excedentes; a UI oferece apenas o aporte exato restante.
- Base V708; VersionCode 709 / VersionName 0.709.0.

---

# V703 — correções do mercado de pilotos e persistência de desenvolvimento

## Mercado de pilotos da IA
- Corrigido o filtro que removia pilotos da equipe do jogador antes de chegar ao ramo de criação de propostas recebidas. A IA agora pode abordar pilotos do jogador somente quando estão no último ano de contrato; contratos plurianuais continuam protegidos contra abordagens no meio do vínculo.
- O conjunto de candidatos é compartilhado entre as janelas de contratação e a análise de renovações, evitando regras divergentes. Propostas recebidas continuam pendentes de decisão manual do Team Principal e não assinam automaticamente.
- Rebalanceada a duração dos contratos: o potencial individual agora é considerado antes do Overall atual. Pilotos de 26–29 anos com potencial ≥90 recebem planos de 3–5 anos; potenciais altos não caem automaticamente no ramo genérico de um ano apenas por ainda estarem abaixo do Overall de auge.

## Desenvolvimento de pilotos da IA
- A persistência da fila agora grava e restaura também `reservePoints`, além dos programas ativos. O codec lê registros V702 antigos sem pontos reservados e converte para reserva vazia, sem quebrar saves existentes.
- Na virada de temporada, programas de pilotos que deixaram a equipe são cancelados imediatamente, a vaga é liberada e a Central de Notícias registra o piloto, a equipe de origem e o destino.
- Foi adicionada uma proteção no processamento antes do GP para remover qualquer programa órfão que apareça por alteração de elenco fora do fluxo normal de virada. Pontos reservados permanecem persistidos no estado da equipe.

## Testes adicionados
- Round-trip do codec de filas e pontos reservados.
- Compatibilidade com filas de save V702.
- Elegibilidade de pilotos do jogador no último ano de contrato e bloqueio durante contrato plurianual.
- Cancelamento de programa e liberação da vaga após transferência.
- Contrato plurianual para piloto de alto potencial mesmo com Overall atual baixo.

## Limites de validação
- A validação estática e a integridade do ZIP são executáveis neste ambiente. A compilação Android integral e a suíte JUnit completa continuam dependendo do Gradle/Android SDK no GitHub Actions.

---

## Histórico — V702

- VersionCode 702 / VersionName 0.702.0; base V701.
- IA passa a manter filas persistentes de programas individuais de desenvolvimento por equipe, usando o mesmo DriverDevelopmentEngine, vagas, pontos, duração, potencial e limite anual do jogador; os programas são processados antes do GP e avançam pelas semanas reais do calendário.
- Removido crescimento passivo de atributos por nível da instalação para jogador e IA; a instalação agora só oferece capacidade e programas explícitos.
- Progresso dos programas da IA avança pelo número real de semanas do calendário entre GPs, com estado de fila e último tick persistidos no save de mercado.
- IA seleciona pilotos próprios com maior potencial ainda não realizado, priorizando idade de desenvolvimento e perfil, e inicia programas quando há vaga.
- Contratos iniciais, renovações, transferências e fechamento de elenco da IA passam a usar duração estratégica de 1 a 5 anos conforme idade, Overall e potencial; nenhuma rota força 1 ano.
- Temporadas com desempenho médio excepcional podem ultrapassar o teto de Overall da classe em até 3 pontos (margens de +1/+2/+3), ainda limitadas pelo potencial individual e Overall 100.
- Adicionados testes de fila persistente, igualdade de especificação do programa, distribuição de contratos e margem de desempenho.

## Revisão atual — V700

- VersionCode 700 / VersionName 0.700.0; base V699.
- Idade numérica do piloto agora aparece na tela Equipe, nos cartões de pilotos/perfis da equipe, no histórico individual e em cada cartão do Mercado de Pilotos. A idade também aparece na confirmação de proposta.
- A interface exibe somente a idade em anos; não cria rótulos como jovem, meia-idade ou veterano.
- Todas as telas usam `DriverEvolutionEngine.careerAge(driver, store.season)`, garantindo a mesma idade da temporada ativa em todos os pontos.
- Adicionado teste cobrindo os 100 pilotos titulares/mercado, estabilidade da idade e avanço anual independente dos atributos.
- Geradas as relações `PILOT_AGES_V700.md` e `.csv` para os 80 titulares e 20 reservas/mercado, com os valores atualmente calculados para 2026.
- A idade inicial continua sendo sintética e determinística (perfil de evolução + ID), sem data de nascimento. Nenhuma idade-base foi corrigida nesta etapa; a lista destaca os casos que merecem revisão posterior.

## Revisão atual — V699

- VersionCode 699 / VersionName 0.699.0; base V698.
- Workflow Android valida a versão corrente, não exige mais V685 e rotula o APK pelo VersionCode real.
- Roster normalizado também nos limites de CareerWeekendEngine e InstantSimulationService; piso 40 aplicado a todos os atributos permanentes antes da simulação.
- Penalidade de chuva normaliza habilidade molhada para 40–100 mesmo em chamadas diretas.
- Notificações de P&D registram a semana real de conclusão, inclusive em avanço de várias semanas.
- Contratos de construção de carro atualizados para refletir Overall físico e componentes mínimos em 40.
- Imagens externas mantidas como comportamento previsto do jogo.

## V698 — piso universal de atributos em 40 pontos

- Todos os sete atributos permanentes dos pilotos passam a respeitar a faixa 40–100, assim como o potencial individual do piloto.
- Todos os atributos permanentes do carro passam a respeitar 40–100: motor, chassi, asas dianteira/traseira, freios, unidade elétrica, aerodinâmica agregada e confiabilidade.
- O mesmo limite vale para confiabilidade individual de cada componente, peças fabricadas, projetos e designs de P&D, pedidos de fábrica, carros físicos, snapshots do Team Principal, carros da IA e dados migrados de saves antigos.
- Atributos carregados abaixo de 40 são corrigidos ao normalizar/ler os dados e as próximas gravações persistem a faixa corrigida.
- Overall derivado, mercado de pilotos, evolução anual, desenvolvimento individual e geração do grid normalizam os sete atributos antes do cálculo ou da gravação.
- Corrigida a migração de carros legados zerados para que a identificação do save antigo aconteça antes da normalização, preservando a restauração existente.
- Fornecedores de motor e pneus também passam a respeitar 40–100, pois alimentam os índices de desempenho e confiabilidade das peças.
- Penalidade financeira por saldo negativo continua reduzindo 20%, mas nunca leva um componente ou confiabilidade permanente abaixo de 40; os dois carros físicos são normalizados após a penalidade.
- Estados transitórios de corrida permanecem separados: desgaste de pneus/chassi e confiabilidade instantânea durante uma pane podem variar até 0; isso não altera o piso dos atributos-base permanentes.
- Preservado o nome público F1 Team Manager V30 e o nome padrão do ZIP.

## Revisão atual — V697

- VersionCode 697 / VersionName 0.697.0.
- Correção do reinício etário: a meta de recuperação de 50% é calculada uma única vez sobre a soma das perdas de velocidade, ultrapassagem e defesa, em vez de arredondar cada atributo para baixo isoladamente.
- Distribuição dos pontos inteiros pelo método dos maiores restos, com desempate determinístico; a recuperação continua limitada às perdas registradas e ao pico histórico de cada atributo.
- Qualificação, consistência, chuva e gestão de pneus permanecem fora da recuperação etária; perdas por desempenho ruim continuam em ledger separado.
- Orçamentos financeiros atuais confirmados no código: €200 milhões anuais independentes para P&D/fabricação/instalações e €150 milhões anuais independentes para construção do próximo carro. Ambos continuam sujeitos ao caixa disponível e à reserva operacional.
- A sequência de carreira da v696 permanece preservada: pilotos não se aposentam, reiniciam a idade em 18 após os 43 anos e mantêm identidade, histórico, perfil de evolução e classe competitiva.

# V690 (0.690.0) — orçamento dinâmico da IA

A divisão 40/40/20 foi convertida em prioridade estratégica flexível. O saldo anual não utilizado por uma categoria pode ser aproveitado pelas demais, sem ultrapassar €200 milhões no conjunto. O carro seguinte pode receber mais de €80 milhões quando houver capacidade liberada, até €150 milhões por projeto. Instalações podem ultrapassar €40 milhões na temporada, desde que o orçamento global permita.

## V691 — prioridade de investimento, premiação e rollover financeiro

- Proteção inicial de €80M para o próximo carro calculada sobre o envelope anual original; os €200M continuam sendo o teto global e o projeto do próximo carro mantém o limite absoluto de €150M.
- P&D atual e instalações continuam compartilhando o saldo não protegido, sem limites individuais rígidos; saldo realmente não utilizado pode ser redirecionado na janela do GP25.
- Abertura explícita de um ledger técnico novo de €200M para as 39 equipes de IA na virada, mesmo em snapshots legados com o ano já atualizado e débitos técnicos residuais; caixa e histórico financeiro são preservados.
- Classificação de premiação congelada antes dos créditos, com fallback para os pontos oficiais da carreira quando o arquivo histórico de corridas estiver incompleto. Pagamentos parciais podem ser reconciliados sem duplicidade.
- Painel e previsões sincronizam a temporada financeira antes de mostrar o saldo técnico.

## V692 — exportação do save selecionado

- Exportar Save Completo agora respeita obrigatoriamente o arquivo selecionado na lista.
- A igualdade de `careerId` não pode mais substituir snapshots históricos por outro save da carreira atualmente carregada.
- Saves da mesma carreira, mas de equipes/temporadas diferentes, são exportados individualmente.
- A carreira ativa só é exportada automaticamente quando nenhum arquivo estiver selecionado.
- Testes de regressão adicionados para seleção explícita e fallback da carreira ativa.

## v694
- Correção de compilação Kotlin: substituídas chamadas `.copy()` inválidas em `AIInvestmentMindset` (enum) por cálculo explícito da prioridade efetiva do próximo carro.
- VersionCode 694 / VersionName 0.694.0.


## v695 — equilíbrio esportivo e progressão controlada
- Rebalanceado o sistema de acidentes: probabilidade global por volta reduzida, risco ponderado por consistência/habilidade na chuva e acidentes recuperáveis deixam de gerar DNF automático.
- Chance de DNF em colisões secundárias reduzida de 40% para 20%, com limite de abandonos por incidente.
- Influência do carro aumentada para 70/30 em seco, 60/40 em chuva leve/média e 55/45 em chuva forte.
- Limite anual de desenvolvimento do carro passa a diminuir conforme o Overall: 42, 36, 30, 24 ou 18 pontos de atributos por temporada.
- Quedas de Overall passam a usar o título explícito “REGRESSÃO DE PILOTO” na Central de Notícias, tanto na carreira quanto no modo Team Principal.
- VersionCode 695 / VersionName 0.695.0.


## v696 — ciclo de carreira e recuperação parcial
- Sem aposentadoria ou remoção de pilotos: ao completar o ciclo etário (até 43 anos), o piloto reinicia em 18 anos e permanece no elenco/mercado com a mesma identidade e histórico.
- Recuperação no reinício: recupera 50% das perdas físicas atribuídas exclusivamente ao envelhecimento, limitadas ao pico histórico de cada atributo físico.
- Envelhecimento passa a afetar somente velocidade, ultrapassagem e defesa; regressões por desempenho continuam separadas e não são recuperadas no reinício do ciclo.
- Perfil/tabela de evolução (Prodígio, Auge Rápido, Auge Moderado, Auge Tardio etc.) permanece imutável e continua determinando o limite/taxa natural de evolução; idade não converte um perfil em outro.
- Pilotos livres voltam a evoluir a 100% da taxa natural dos pilotos contratados, sem gerar amostras artificiais para promoção/rebaixamento de classe.
- Classe competitiva continua independente da idade e é revista com base nas duas últimas temporadas completas de desempenho, preservando as regras Pro→Lenda somente com título e Normal/Médio como piso.
- Os novos bancos de envelhecimento, perdas físicas, picos e ciclos são persistidos separadamente para compatibilidade com saves existentes.
- VersionCode 696 / VersionName 0.696.0.

## V701
- Idades iniciais oficiais de 2026 importadas do CSV com 100 pilotos.
- Idade anual e reinício do ciclo aos 18 após completar 43, com notícia de temporada.
- Classe Lenda permanente e histórico de títulos por piloto.
- Teto de classe aplicado à evolução natural; programas da instalação podem ultrapassá-lo dentro do potencial individual.
- Pendente: programas individuais persistentes de desenvolvimento para equipes controladas pela IA.
- Revisão de classe em cadência estritamente bienal (a cada duas temporadas completas).
