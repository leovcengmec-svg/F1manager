# V735 — progressão de pilotos e refinamento visual

- Recalibra a margem adicional de classe em degraus de +1 a +5 a partir de índices 105/110/115/120/125, mantendo amostra mínima de cinco GPs e high-water mark da temporada.
- Eleva o potencial estimado mínimo às faixas adicionais das classes Médio/Forte/Pro (74/84/94), preservando o teto individual acima desses mínimos quando existir.
- Corrige a promoção Pro→Lenda para consultar todo o histórico de títulos do piloto, em vez de exigir o título da última temporada avaliada.
- O gráfico mostra apenas o ciclo etário atual, usa curva cúbica suave com snapshots reais e somente dois marcadores visíveis; os ciclos anteriores permanecem arquivados.
- Formata os percentuais de todas as descrições de instalações com uma casa decimal e locale pt-BR.


## V739
Correção dos cards de atributos do mercado e precificação progressiva de patrocínios por categoria. Ver `CHANGELOG_V739.md` e `AUDIT_V739.md`.
