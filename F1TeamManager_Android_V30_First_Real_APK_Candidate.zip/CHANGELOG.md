# V734 — correção do GP30 e progressão dos pilotos

A V734 corrige a etapa ausente de congelamento das garagens canônicas na finalização do GP30 e o desbloqueio da faixa adicional de +5 Overall. A evolução normal continua usando metas definidas exclusivamente pela força do carro, tolerância de ±3 e pesos de 40%/60%; o índice de desbloqueio é separado e exige cinco GPs reais.

Consulte `CHANGELOG_V734.md` e `AUDIT_V734_EVOLUTION_GP30.md`.
