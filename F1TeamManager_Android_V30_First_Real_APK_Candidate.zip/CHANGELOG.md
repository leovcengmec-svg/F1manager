# V731 — Evolução e progressão de classe dos pilotos

Atualização das regras finais: margem de até cinco pontos acima do teto normal para Médio, Forte e Pro; condições por classe e situação contratual; liberação progressiva por média de desempenho da temporada; promoção/regressão esportiva bienal; e rebaixamento por temporadas completas sem equipe. Jogador e IA compartilham os mesmos critérios.

Consulte `CHANGELOG_V731.md` e `AUDIT_V731_STABILIZATION.md`.
