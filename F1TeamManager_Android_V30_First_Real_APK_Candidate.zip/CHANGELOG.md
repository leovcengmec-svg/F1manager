# V581 — Evolução visível também para pilotos livres

- Agentes livres continuam evoluindo fora do grid com fator próprio, sem bônus de desempenho de corrida.
- A Central de Notícias identifica o status de agente livre e registra aumentos de atributos mesmo quando o Overall arredondado não muda.
- Adicionados cinco testes de contrato para os cenários de evolução de pilotos livres.
- Build Android integral e suíte JUnit oficial pendentes de ambiente Gradle/Android; consulte `CHANGELOG_V581.md` e `AUDIT_V581.md`.

# V473 — Contraproposta do piloto com exigências completas e acesso direto

- A notificação de contraproposta passa a informar salário anual exigido, duração, papel na equipe e temporada de início, usando valores monetários em milhões ou mil.
- O botão do aviso na Home passa a abrir diretamente o Mercado de Pilotos quando se trata de contraproposta.
- Ao entrar no Mercado de Pilotos, uma contraproposta pendente do jogador é aberta automaticamente; o card persistente continua disponível para reabrir e decidir.
- O diálogo mantém as três decisões: aceitar os termos, recusar ou enviar nova contraproposta, incluindo salário, duração e papel.
- Atualizada a versão Android para `versionCode 473` / `versionName 0.473.0`.
- ZIP verificado quanto à integridade; build Android ainda precisa ser confirmado no GitHub Actions.

# V472 — Valores financeiros de eventos em milhões e mil

Eventos de crise financeira e aquisição por investidores agora exibem valores monetários compactos, em vez de números inteiros sem separadores.

# V470 — Redução da altura dos cards do menu inicial

- Reduzido o espaço vertical reservado aos três cards principais do menu inicial para deixá-los menos altos no POCO X7 Pro.
- Reduzidos espaçamentos entre cards, padding vertical, ícones e tipografia secundária para manter a leitura e os alvos de toque.
- Mantidos os textos, estados habilitado/desabilitado, callbacks e fundo aprovado; não foi adicionada rolagem.
- Atualizada a versão Android para `versionCode 470` / `versionName 0.470.0`.
- ZIP verificado quanto à integridade; build Android ainda precisa ser confirmado no GitHub Actions.

# V469 — Correção de compilação da tela de saves

- Movida a declaração do estado `refresh` para antes do `LaunchedEffect` que o incrementa.
- Corrige o erro Kotlin de inferência de tipo e a referência não resolvida `refresh` em `SaveManagementScreen.kt`.
- Atualizada a versão Android para `versionCode 469` / `versionName 0.469.0`.
- Mantidos os recursos e os demais arquivos do ZIP de origem.
- A compilação Android ainda precisa ser confirmada no GitHub Actions.

# V462 — Ranking inicial consistente no Modo Difícil

- Corrigido o ranking de força mostrado na abertura da carreira: na semana inicial, as 40 equipes são comparadas usando os mesmos carros iniciais determinísticos usados pela seleção do Modo Difícil.
- Evita que simulações/cache de desenvolvimento da IA alterem o ranking antes do início efetivo da temporada.
- Após a primeira semana, o ranking volta a refletir os carros evoluídos pela simulação da IA.
- Build Android não executado neste ambiente; validar no GitHub Actions.

# V461 — Nomes completos dos pilotos na seleção de equipe

- A seleção de equipe agora apresenta o nome completo de cada piloto nos campos PILOTO 1 e PILOTO 2, sem reduzir para o sobrenome.
- Ajustada a tipografia e permitidas até duas linhas para acomodar nomes longos no espaço existente.
- Nenhuma regra de força inicial, modo difícil ou seleção de equipe foi alterada.
- Compilação Android não executada neste ambiente.

# V457 — Notícias do Mercado de Pilotos na Home
- Contrapropostas ligadas à equipe do jogador agora podem gerar card de evento na Home.
- Renovações e assinaturas/fechamentos de contrato aparecem na Home tanto para a equipe do jogador quanto para equipes da IA.
- Contagem e prioridade do aviso de Mercado na Home alinhadas às novas regras; histórico do Central de Notícias preservado.

# V456 — Retorno à Home após fim de temporada
- Botão do evento de fim de temporada retorna à Home; não inicia a próxima temporada.

# V455 — Manutenção semanal e continuidade financeira

- Implementada manutenção semanal por nível de cada instalação, para jogador e IA.
- A cobrança percorre todas as semanas do calendário até o GP atual e usa chaves persistentes temporada:semana para impedir duplicidade.
- Manutenções sem caixa ficam como obrigações pendentes e são quitadas em ordem cronológica quando houver saldo, sem perder histórico.
- Persistência ampliada para salvar semanas cobradas e obrigações pendentes no estado financeiro do jogador e no snapshot da IA.
- Preservadas regras de custo por GP: forte €2,5M, média €1,5M e fraca €0,8M.

# V454 — Auditoria financeira e custos por GP

- Custos operacionais por GP ajustados: equipe forte €2.500.000, média €1.500.000 e fraca €800.000; valor centralizado para jogador e IA.
- Corrigido o histórico de liquidação da IA: os lançamentos de patrocínio, premiação e custo operacional do GP não são mais substituídos pelo extrato anterior ao gravar o marcador de idempotência.
- Obrigações salariais pendentes agora entram no saldo efetivo de encerramento da temporada; caixa zerado com salários em aberto não evita a penalidade financeira.
- Mantida a proteção contra pagamentos duplicados e preservado o histórico de transações existente.
- Validação estática e integridade do ZIP realizadas. Build Android/JUnit não executados neste ambiente.

# V368 — Teste ponta a ponta da simulação instantânea

- Adicionado teste JUnit para executar o serviço de simulação instantânea com o motor real, 80 pilotos e distância programada.
- Verificadas as fases Q1/Q2/Q3 (80/50/20), a classificação final e a rejeição de circuito divergente sem avançar o motor.
- Versão Android atualizada para 0.368.0.
- Execução JUnit e build Android seguem pendentes: o pacote não contém Gradle Wrapper e o ambiente não tem Gradle instalado; a tentativa de compilação isolada de todo o domínio excedeu o tempo disponível.

# V341 — Correção de compilação

- Corrigida referência inválida `team.name` na filtragem de notificações da Home; `team` já é uma `String`.
- Mantida a regra de pontuação aprovada na V340.
- Validação estática e integridade do ZIP; compilação Android ainda precisa ser executada no ambiente Gradle.

## V269
- Corrigido o resolvedor anual em lote: cada ocorrência de evento de equipe agora seleciona uma única equipe de forma determinística, evitando multiplicar uma ocorrência por todas as equipes. Aquisições usam ponderação que favorece equipes mais fracas.

## V268
- Revisão do calendário anual: a semente de criação permanece fixa e o calendário persistido é reutilizado entre avanços e recargas.
- Mantidos os limites de eventos por temporada e a agenda de semanas únicas.

## V267
- Corrigida a semente do calendário anual de eventos para ser estável entre avanços semanais e recargas.

## V443
- Motor de catálogo e sorteio persistente de regulamento anual/decenal do carro (Etapa 1). Ver `CHANGELOG_V443.md`.


## V444 — Regulamento integrado à virada de temporada
- O carro é construído primeiro, recebe a regra da nova temporada depois, e o ranking/metas são preparados com os valores regulados.
- Regra compartilhada para IA e jogador; confiabilidade não é penalizada.


## V458
- Menu inicial Compose com três cards funcionais e fundo de garagem.


## V459
- Novo Jogo permite escolher Modo Livre (40 equipes) ou Modo Difícil (as 3 equipes de menor força inicial).

## V460 — Sistema de saves
Consulte `CHANGELOG_V460.md` para lista de saves, exportação/importação JSON e restauração do histórico.


## V463 — Navegação por gesto entre equipes
- O card superior da Central de Equipes aceita deslizar para a esquerda/direita para selecionar a próxima/anterior equipe no ranking.
- Os botões de seta continuam disponíveis.
- O gesto fica restrito ao card para preservar o gesto lateral do sistema Android e o botão Voltar existente.


## V573 — Integridade do catálogo personalizado
- Auditoria não destrutiva do catálogo de equipes, pilotos e bandeiras; diagnósticos para JSON inválido, IDs/nomes duplicados e referências de pilotos ausentes.
- Escritas bloqueadas quando os dados persistidos estão inconsistentes, evitando sobrescrita silenciosa.
- Validação de nome de arquivo de escudo aplicada também na edição de equipe.

## V574 — Diagnóstico e proteção operacional do catálogo
- Tela de cadastros passa a explicar inconsistências, bloquear gravações e oferecer exportação manual de diagnóstico com os valores brutos persistidos.
- Revalidação somente de leitura e checagens adicionais de atributos/nomes de arquivos de assets.
- Nenhum dado é corrigido ou descartado automaticamente; histórico, carreiras e assets permanecem preservados. Ver `CHANGELOG_V574.md` e `AUDIT_V574.md`.


## V575 — Recuperação controlada do catálogo
- Prévia não destrutiva, confirmação explícita e backup integral das fontes originais antes da recuperação.
- Revalidação final com restauração dos valores originais se a proposta continuar inconsistente.
- Carreiras, contratos, histórico e assets externos preservados. Consulte `CHANGELOG_V575.md` e `AUDIT_V575.md`.


## V576 — Grande integração de carreira e temporada
- Reconciliador de mercado passa a priorizar os pilotos registrados para cada equipe personalizada antes de distribuir agentes livres, evitando que um piloto recém-cadastrado seja atribuído a uma equipe antiga apenas pela ordem dos IDs.
- Vagas remanescentes usam pilotos sem vínculo fixo ou vinculados à própria equipe; contratos e transferências agendadas existentes não são reatribuídos.
- A reconciliação permanece idempotente e registra o marcador V576 uma única vez.
- Removida duplicação da mesma ocorrência de erro no validador do grid.
- Adicionados testes de integração para equipe/pilotos personalizados, preservação de contratos/transferências, idempotência, mercado/grade dinâmicos, calendário de 30 GPs e seis instalações.
- Áudio: `pit_call` e `player_driver_events` conectados aos eventos de box e pilotos, com fallback para `box_audio`/`driver_warning`; Safety Car, VSC e bandeira vermelha também roteados. Repetição do mesmo evento ao reabrir a tela é evitada.
- Preservados os arquivos anteriores, o histórico, as chaves de save e todos os assets existentes.


## V577 — Fechamento integrado e grade dinâmica
- Corrigido defeito de compilação em `InstantSimulationService.completeStartedWeekend`: a validação passa a usar o roster efetivamente configurado no motor.
- Roster original do GP separado da lista temporária de classificados da qualificação; verificação da identidade exata dos pilotos entre grid, qualificação e resultado; Q2/Q3 proporcionais ao grid real.
- Adicionados testes de integração para grids pequenos/expandidos e adaptados contratos da auditoria de temporada para o catálogo dinâmico.
- Auditores vivos de ciclo de jogo e premiação atualizados para não exigir os antigos limites fixos de 80 pilotos/40 posições.
- Consulte `CHANGELOG_V577.md` e `AUDIT_V577.md`.


## V578 — Integridade de IDs e roster personalizado
- Bloqueadas colisões entre IDs personalizados e faixas oficiais de equipes/pilotos; detectados pilotos reutilizados entre equipes e vínculos cruzados.
- O roster declarado pela equipe passa a ser autoritativo para resolver pilotos personalizados legados sem `teamId` persistido; mercado e grade mantêm o vínculo correto.
- Adicionados testes e harnesses de regressão. Build Android completo e simulação de duas temporadas ainda não executados. Consulte `CHANGELOG_V578.md` e `AUDIT_V578.md`.


## V579 — Integração dinâmica de catálogo e mercado
- Alvos de patrocínio/evolução e contadores da interface passam a acompanhar o tamanho real do grid e do catálogo.
- O motor de mercado reconhece pilotos adicionados após sua instanciação.
- Incluídos testes de grid expandido e harness de cadastro→reconciliação→proposta. Consulte `CHANGELOG_V579.md` e `AUDIT_V579.md`.


## V580 — Fechamento integrado do motor dinâmico
- Ranking de investimento técnico, pesquisa e fabricação escalado ao tamanho real do campeonato, preservando as faixas originais no grid de 40 equipes.
- Avaliação sazonal de pilotos agora recebe o tamanho real do grid.
- Executados teste funcional de cadastro→mercado→grid expandido→construtores/premiações/patrocínios/economia/evolução e simulação headless de 60 GPs em duas temporadas.
- Build Android integral e suíte JUnit oficial permanecem pendentes de ambiente Gradle/Android. Consulte `CHANGELOG_V580.md` e `AUDIT_V580.md`.


## V582 — Integração de eventos anuais e virada de temporada

Catálogo vivo sincronizado no mercado e no início dos GPs; agentes livres recém-cadastrados reconhecidos; roster anual inclui todos os pilotos conhecidos, inclusive os fora do grid; testes de contrato adicionados. Ver `CHANGELOG_V582.md` e `AUDIT_V582.md`.


## V583 — Pacote limpo e fonte única
- Removida apenas a cópia aninhada antiga `v552_work`, após comparação de todos os caminhos e hashes contra a raiz oficial; nenhum arquivo era exclusivo dela. Mantida a versão mais recente de cada caminho, o histórico e os assets. Consulte `CHANGELOG_V583.md` e `AUDIT_V583.md`.


## V584 — Correção de compilação APK

Corrigida a chamada do mercado de agentes livres para usar uma instância de `DriverMarketEngine` e tipagem explícita do conjunto de IDs.
