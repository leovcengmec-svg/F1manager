## V740
Contratos da IA passam a refletir Overall e desempenho; contratos longos podem ser abertos para negociação por baixo rendimento; eventos anuais agora priorizam crises em equipes ricas, aportes em equipes fracas e preservam limite acumulado de perda de 18% do caixa de referência. Ver `CHANGELOG_V740.md` e `AUDIT_V740.md`.

# V735 — progressão de pilotos e refinamento visual

- Recalibra a margem adicional de classe em degraus de +1 a +5 a partir de índices 105/110/115/120/125, mantendo amostra mínima de cinco GPs e high-water mark da temporada.
- Eleva o potencial estimado mínimo às faixas adicionais das classes Médio/Forte/Pro (74/84/94), preservando o teto individual acima desses mínimos quando existir.
- Corrige a promoção Pro→Lenda para consultar todo o histórico de títulos do piloto, em vez de exigir o título da última temporada avaliada.
- O gráfico mostra apenas o ciclo etário atual, usa curva cúbica suave com snapshots reais e somente dois marcadores visíveis; os ciclos anteriores permanecem arquivados.
- Formata os percentuais de todas as descrições de instalações com uma casa decimal e locale pt-BR.


## V739
Correção dos cards de atributos do mercado e precificação progressiva de patrocínios por categoria. Ver `CHANGELOG_V739.md` e `AUDIT_V739.md`.

### Correção complementar V740 — desenvolvimento de pilotos
- Pontos da instalação e margem extra de classe são tratados exclusivamente como evolução dos sete atributos individuais; Overall permanece um valor derivado, nunca recebe pontos diretos.
- Notícia de conclusão passa a mostrar os atributos alterados e seus deltas, evitando a interpretação de que o programa concede pontos diretos de Overall.
- Adicionado teste de regressão para programa de 5 pontos e margem de classe extra.

## V741
Contratos negociados sem faixa de Overall, valores e salários por tabela de Overall atual, taxas de contratação de 100%/50%/20% pelo nível financeiro sem compensação à equipe anterior, e prioridade da IA para elevar o Centro Comercial ao nível 3 e buscar o nível 4 quando sustentável. Ver `CHANGELOG_V741.md` e `AUDIT_V741.md`.

## V742
Correção da visibilidade local de `signatureFeeForTeam`: a função foi movida para antes de `advanceFreeWeeksSegment` e de todos os seus chamadores, eliminando a referência não resolvida que interrompia `compileDebugKotlin` na V741. Mantidas sem alteração as regras de mercado, taxas e instalações da V741. Ver `CHANGELOG_V742.md` e `AUDIT_V742_STABILIZATION.md`.


## V743
Correção do limite exato de pontos no desenvolvimento de pilotos; P&D da IA em lotes de três componentes com V1/V2, orçamento e fabricação reservados; reset universal das peças da IA para V0 na virada; regulamento anual 80% uma alteração e 20% duas; classificação financeira completa nas contratações automáticas. Ver `CHANGELOG_V743.md` e `AUDIT_V743.md`.
