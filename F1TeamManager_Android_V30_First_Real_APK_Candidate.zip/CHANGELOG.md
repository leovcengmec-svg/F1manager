## Revisão atual — V690

- VersionCode 690 / VersionName 0.690.0.
- Reformulada a inteligência financeira das equipes da IA: 40/40/20 passa a ser prioridade de planejamento, não teto fixo por categoria.
- O orçamento técnico anual consolidado permanece limitado a €200 milhões, somando P&D/fabricação, instalações e investimento no próximo carro.
- O investimento no próximo carro pode ultrapassar a referência inicial de €80 milhões quando as demais categorias deixam capacidade livre, respeitando o teto absoluto de €150 milhões por projeto e o envelope anual compartilhado.
- P&D do carro atual e instalações compartilham a capacidade flexível restante depois da prioridade dinâmica do próximo carro; não há teto separado de €80M ou €40M para essas categorias.
- Ao atingir o alvo calculado do próximo carro, sua reserva é liberada às demais categorias; o status é persistido em snapshots e volta a ser reservado se o alvo aumentar.
- Instalações deixam de ser bloqueadas por uma reserva anual de €40 milhões. Podem consumir a capacidade compartilhada livre, desde que haja caixa, previsão financeira e orçamento anual.
- Reserva de instalações mantida apenas como referência estratégica de planejamento, com saldo acumulado limitado ao custo da maior melhoria atual (€120 milhões); não cria dinheiro nem altera o teto anual.
- Proteção de caixa operacional, despesas obrigatórias e compatibilidade com saves existentes preservadas.

# V690 (0.690.0) — orçamento dinâmico da IA

A divisão 40/40/20 foi convertida em prioridade estratégica flexível. O saldo anual não utilizado por uma categoria pode ser aproveitado pelas demais, sem ultrapassar €200 milhões no conjunto. O carro seguinte pode receber mais de €80 milhões quando houver capacidade liberada, até €150 milhões por projeto. Instalações podem ultrapassar €40 milhões na temporada, desde que o orçamento global permita.

## V691 — prioridade de investimento, premiação e rollover financeiro

- Proteção inicial de €80M para o próximo carro calculada sobre o envelope anual original; os €200M continuam sendo o teto global e o projeto do próximo carro mantém o limite absoluto de €150M.
- P&D atual e instalações continuam compartilhando o saldo não protegido, sem limites individuais rígidos; saldo realmente não utilizado pode ser redirecionado na janela do GP25.
- Abertura explícita de um ledger técnico novo de €200M para as 39 equipes de IA na virada, mesmo em snapshots legados com o ano já atualizado e débitos técnicos residuais; caixa e histórico financeiro são preservados.
- Classificação de premiação congelada antes dos créditos, com fallback para os pontos oficiais da carreira quando o arquivo histórico de corridas estiver incompleto. Pagamentos parciais podem ser reconciliados sem duplicidade.
- Painel e previsões sincronizam a temporada financeira antes de mostrar o saldo técnico.

## V692 — exportação do save selecionado

- Exportar Save Completo agora respeita obrigatoriamente o arquivo selecionado na lista.
- A igualdade de `careerId` não pode mais substituir snapshots históricos por outro save da carreira atualmente carregada.
- Saves da mesma carreira, mas de equipes/temporadas diferentes, são exportados individualmente.
- A carreira ativa só é exportada automaticamente quando nenhum arquivo estiver selecionado.
- Testes de regressão adicionados para seleção explícita e fallback da carreira ativa.

## v694
- Correção de compilação Kotlin: substituídas chamadas `.copy()` inválidas em `AIInvestmentMindset` (enum) por cálculo explícito da prioridade efetiva do próximo carro.
- VersionCode 694 / VersionName 0.694.0.
