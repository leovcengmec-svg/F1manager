# V704 — correção de compilação e postura automática

A V704 corrige a expressão `when` não exaustiva em `CareerWeekendEngine.choose()`, cobrindo os três valores legados de relargada. Eles não se tornam comandos manuais: cada piloto continua escolhendo automaticamente entre Ataque, Equilibrado e Poupar durante a corrida.

Também foram alinhados README e manifesto ao versionamento Android 704 / 0.704.0. Nome público e nome original do ZIP permanecem inalterados.
