# V600 — Correção de identidade de pilotos e plano de pneus\n\n- Corrige identificação no plano de início para usar o elenco atual da carreira.\n- Corrige colisão de atributos/evolução de Felipe Drugovich em saves afetados.\n\n# V599 — Catálogo ampliado de objetivos Team Principal

- O objetivo principal continua sendo a posição no Mundial de Equipes e é recalculado pela posição atual.
- O objetivo secundário deixa de ser sempre financeiro: ele é o primeiro dos cinco objetivos sazonais sorteados do catálogo.
- Catálogo ampliado para 16+ tipos/opções, incluindo caixa, pontuação, evolução de posição, competitividade, progresso de pontos, pesquisa concluída, peça fabricada disponível e melhoria de cada uma das sete instalações.
- As metas de instalações são criadas conforme o nível atual e só aparecem quando há nível para evoluir; a conclusão verifica o nível real persistido.
- Pesquisa concluída é verificada pelo registro de designs concluídos na temporada. Fabricação verifica peças físicas aguardando instalação.
- Prestígio inicial 1, principal vale 4, outros objetivos valem 1; fracassos descontam e o ganho líquido continua limitado a +8 por temporada.
- Adicionado teste de contrato estático para catálogo, seleção, métricas e versionamento. Build Android e simulação integrada ainda pendentes.
- Versão Android: `versionCode 599` / `versionName 0.599.0`.

## V598 — Objetivos dinâmicos e prestígio equilibrado
- Prestígio inicial do modo Team Principal passa de 10 para 1.
- Objetivo principal é recalculado a cada temporada conforme a força/posição atual da equipe.
- Novo conjunto variável de seis objetivos: 1 principal, 1 secundário financeiro e 4 objetivos sazonais.
- Cumprir objetivos dá prestígio; fracassar desconta pontos. Ganho positivo por temporada limitado a 8.
- Saves Team Principal passam ao schema 3 com migração de leitura dos schemas antigos.
- Auditoria: `AUDIT_V598_TEAM_PRINCIPAL_OBJECTIVES.md`. Compilação Android ainda pendente.

# V597 — Balanceamento de decisões do mercado de pilotos

Ver `CHANGELOG_V597.md` e `AUDIT_V597_DRIVER_MARKET.md`.

# V596 — Correção de compilação no resumo de equipes

- Corrigida a referência não resolvida `store` em `teamOverviewSnapshot()`, adicionando `CareerPreferences` como parâmetro explícito da função.
- Mantidas as validações de save por modo da V595; nenhuma alteração nos assets externos ou no histórico de versões anterior.
- Versão Android: `versionCode 596` / `versionName 0.596.0`.
- Validação Android completa ainda depende da execução do workflow com Gradle/SDK; não declarar APK compilado até obter resultado verde.

# V595 — Saves identificados por modo e carreira

- Novo schema 2 com modo explícito (`FREE`, `HARD`, `TEAM_PRINCIPAL`) e ID único persistente da carreira no cabeçalho e nas preferências.
- Salvamento automático usa modo/equipe/temporada/ID da carreira no nome do arquivo, evitando colisões entre carreiras diferentes.
- Exportação valida o save selecionado; importação valida schema, tipos, modo, equipe, temporada, identidade, estado Team Principal e arquivo histórico antes de substituir o save ativo.
- A tela mostra o modo em cada save e bloqueia carregar/exportar arquivos inválidos ou com metadados divergentes.
- Mantida a compatibilidade com schema 1; saves antigos recebem modo explícito e ID estável ao importar quando os dados permitem identificar a carreira.
- Escritas locais protegidas por `AtomicFile`; falha na restauração do histórico tenta reverter preferências e arquivo anterior.
- Testes de contrato estático: 26/26; auditoria estrutural: 40/40; auditoria de release: 25/25. Build Android/JUnit/emulador não executados por ausência de Gradle/SDK/ADB.
- Versão Android: `versionCode 595` / `versionName 0.595.0`.

# V562 — Desempenho inicial da equipe e versão-base V0

- Corrigida a interpretação de V0: é a versão da peça, não o desempenho do componente.
- Jogador e IA começam com desempenho-base coerente com o nível Forte/Médio/Fraco da equipe selecionada.
- Os seis componentes iniciais são registrados como hardware-base V0; o primeiro novo design pesquisado é V1.
- O desempenho físico permanece inalterado ao iniciar pesquisa e só muda quando a peça melhorada é fabricada e instalada.
- Carreiras geradas incorretamente pela V561 com os dois carros em zero são migradas para o perfil-base da equipe; starter antigo INIT-* mantém seu desempenho e passa a V0.
- Adicionados testes de regressão para desempenho inicial, versão V0, criação do design V1 e preservação do desempenho na pesquisa.
- Versão Android: `versionCode 562` / `versionName 0.562.0`.
- ZIP verificado quanto à integridade; build Android e execução JUnit continuam pendentes neste ambiente.

# V473 — Contraproposta do piloto com exigências completas e acesso direto

- A notificação de contraproposta passa a informar salário anual exigido, duração, papel na equipe e temporada de início, usando valores monetários em milhões ou mil.
- O botão do aviso na Home passa a abrir diretamente o Mercado de Pilotos quando se trata de contraproposta.
- Ao entrar no Mercado de Pilotos, uma contraproposta pendente do jogador é aberta automaticamente; o card persistente continua disponível para reabrir e decidir.
- O diálogo mantém as três decisões: aceitar os termos, recusar ou enviar nova contraproposta, incluindo salário, duração e papel.
- Atualizada a versão Android para `versionCode 473` / `versionName 0.473.0`.
- ZIP verificado quanto à integridade; build Android ainda precisa ser confirmado no GitHub Actions.

# V472 — Valores financeiros de eventos em milhões e mil

Eventos de crise financeira e aquisição por investidores agora exibem valores monetários compactos, em vez de números inteiros sem separadores.

# V470 — Redução da altura dos cards do menu inicial

- Reduzido o espaço vertical reservado aos três cards principais do menu inicial para deixá-los menos altos no POCO X7 Pro.
- Reduzidos espaçamentos entre cards, padding vertical, ícones e tipografia secundária para manter a leitura e os alvos de toque.
- Mantidos os textos, estados habilitado/desabilitado, callbacks e fundo aprovado; não foi adicionada rolagem.
- Atualizada a versão Android para `versionCode 470` / `versionName 0.470.0`.
- ZIP verificado quanto à integridade; build Android ainda precisa ser confirmado no GitHub Actions.

# V469 — Correção de compilação da tela de saves

- Movida a declaração do estado `refresh` para antes do `LaunchedEffect` que o incrementa.
- Corrige o erro Kotlin de inferência de tipo e a referência não resolvida `refresh` em `SaveManagementScreen.kt`.
- Atualizada a versão Android para `versionCode 469` / `versionName 0.469.0`.
- Mantidos os recursos e os demais arquivos do ZIP de origem.
- A compilação Android ainda precisa ser confirmada no GitHub Actions.

# V462 — Ranking inicial consistente no Modo Difícil

- Corrigido o ranking de força mostrado na abertura da carreira: na semana inicial, as 40 equipes são comparadas usando os mesmos carros iniciais determinísticos usados pela seleção do Modo Difícil.
- Evita que simulações/cache de desenvolvimento da IA alterem o ranking antes do início efetivo da temporada.
- Após a primeira semana, o ranking volta a refletir os carros evoluídos pela simulação da IA.
- Build Android não executado neste ambiente; validar no GitHub Actions.

# V461 — Nomes completos dos pilotos na seleção de equipe

- A seleção de equipe agora apresenta o nome completo de cada piloto nos campos PILOTO 1 e PILOTO 2, sem reduzir para o sobrenome.
- Ajustada a tipografia e permitidas até duas linhas para acomodar nomes longos no espaço existente.
- Nenhuma regra de força inicial, modo difícil ou seleção de equipe foi alterada.
- Compilação Android não executada neste ambiente.

# V457 — Notícias do Mercado de Pilotos na Home
- Contrapropostas ligadas à equipe do jogador agora podem gerar card de evento na Home.
- Renovações e assinaturas/fechamentos de contrato aparecem na Home tanto para a equipe do jogador quanto para equipes da IA.
- Contagem e prioridade do aviso de Mercado na Home alinhadas às novas regras; histórico do Central de Notícias preservado.

# V456 — Retorno à Home após fim de temporada
- Botão do evento de fim de temporada retorna à Home; não inicia a próxima temporada.

# V455 — Manutenção semanal e continuidade financeira

- Implementada manutenção semanal por nível de cada instalação, para jogador e IA.
- A cobrança percorre todas as semanas do calendário até o GP atual e usa chaves persistentes temporada:semana para impedir duplicidade.
- Manutenções sem caixa ficam como obrigações pendentes e são quitadas em ordem cronológica quando houver saldo, sem perder histórico.
- Persistência ampliada para salvar semanas cobradas e obrigações pendentes no estado financeiro do jogador e no snapshot da IA.
- Preservadas regras de custo por GP: forte €2,5M, média €1,5M e fraca €0,8M.

# V454 — Auditoria financeira e custos por GP

- Custos operacionais por GP ajustados: equipe forte €2.500.000, média €1.500.000 e fraca €800.000; valor centralizado para jogador e IA.
- Corrigido o histórico de liquidação da IA: os lançamentos de patrocínio, premiação e custo operacional do GP não são mais substituídos pelo extrato anterior ao gravar o marcador de idempotência.
- Obrigações salariais pendentes agora entram no saldo efetivo de encerramento da temporada; caixa zerado com salários em aberto não evita a penalidade financeira.
- Mantida a proteção contra pagamentos duplicados e preservado o histórico de transações existente.
- Validação estática e integridade do ZIP realizadas. Build Android/JUnit não executados neste ambiente.

# V368 — Teste ponta a ponta da simulação instantânea

- Adicionado teste JUnit para executar o serviço de simulação instantânea com o motor real, 80 pilotos e distância programada.
- Verificadas as fases Q1/Q2/Q3 (80/50/20), a classificação final e a rejeição de circuito divergente sem avançar o motor.
- Versão Android atualizada para 0.368.0.
- Execução JUnit e build Android seguem pendentes: o pacote não contém Gradle Wrapper e o ambiente não tem Gradle instalado; a tentativa de compilação isolada de todo o domínio excedeu o tempo disponível.

# V341 — Correção de compilação

- Corrigida referência inválida `team.name` na filtragem de notificações da Home; `team` já é uma `String`.
- Mantida a regra de pontuação aprovada na V340.
- Validação estática e integridade do ZIP; compilação Android ainda precisa ser executada no ambiente Gradle.

## V269
- Corrigido o resolvedor anual em lote: cada ocorrência de evento de equipe agora seleciona uma única equipe de forma determinística, evitando multiplicar uma ocorrência por todas as equipes. Aquisições usam ponderação que favorece equipes mais fracas.

## V268
- Revisão do calendário anual: a semente de criação permanece fixa e o calendário persistido é reutilizado entre avanços e recargas.
- Mantidos os limites de eventos por temporada e a agenda de semanas únicas.

## V267
- Corrigida a semente do calendário anual de eventos para ser estável entre avanços semanais e recargas.

## V443
- Motor de catálogo e sorteio persistente de regulamento anual/decenal do carro (Etapa 1). Ver `CHANGELOG_V443.md`.


## V444 — Regulamento integrado à virada de temporada
- O carro é construído primeiro, recebe a regra da nova temporada depois, e o ranking/metas são preparados com os valores regulados.
- Regra compartilhada para IA e jogador; confiabilidade não é penalizada.


## V458
- Menu inicial Compose com três cards funcionais e fundo de garagem.


## V459
- Novo Jogo permite escolher Modo Livre (40 equipes) ou Modo Difícil (as 3 equipes de menor força inicial).

## V460 — Sistema de saves
Consulte `CHANGELOG_V460.md` para lista de saves, exportação/importação JSON e restauração do histórico.


## V463 — Navegação por gesto entre equipes
- O card superior da Central de Equipes aceita deslizar para a esquerda/direita para selecionar a próxima/anterior equipe no ranking.
- Os botões de seta continuam disponíveis.
- O gesto fica restrito ao card para preservar o gesto lateral do sistema Android e o botão Voltar existente.

## V586 — Modo Team Principal (primeira implementação)
- Terceiro modo de carreira com prestígio, objetivos, avaliações contratuais bienais, propostas de outras equipes e possível demissão.
- Prestígio persiste entre empregadores; histórico profissional registra a equipe de cada temporada.
- Livre e Difícil são mantidos. Build Android e testes completos ponta a ponta ainda pendentes.
- Detalhes: `CHANGELOG_V586.md` e `AUDIT_V586_TEAM_PRINCIPAL.md`.


## V588 — Modo Team Principal restrito à carreira correta
- Adicionado marcador persistente `activeGameMode` (`FREE`, `HARD`, `TEAM_PRINCIPAL`).
- O card “Team Principal • Minha Carreira” só é renderizado quando o modo ativo é Team Principal e há estado de carreira válido.
- Iniciar qualquer nova carreira limpa os dados antigos de Team Principal; a escolha do modo é salva explicitamente.
- Saves Team Principal antigos, sem marcador, recebem migração compatível. Saves Livre/Difícil não exibem nem usam painel/avaliação de Team Principal.
- Teste de regressão cobre modo Livre, Difícil, Team Principal, estado ausente e saves antigos.
- Testes Kotlin/Gradle e build Android completos continuam pendentes neste ambiente.


## V590 — Ranking visivelmente renovado ao reabrir Novo Jogo
- Não basta a semente ser diferente: agora a seleção procura outro ranking completo e outras três equipes mais fracas, repetindo o sorteio quando o resultado visível coincidir com a seleção anterior.
- A prévia continua sem alterar a semente da carreira salva; ao confirmar equipe, ranking e carro permanecem sincronizados.
- Teste de regressão adicional. Build Android/Gradle completo não executado neste ambiente.
- Detalhes: `CHANGELOG_V590.md` e `AUDIT_V590_NEW_GAME_RANKING.md`.
