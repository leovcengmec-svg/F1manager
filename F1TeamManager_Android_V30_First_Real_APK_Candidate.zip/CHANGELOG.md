## V645 (0.645.0)
- Corrigida referência Kotlin `objectiveCurrentTeamRank` na tela Team Principal, unificando com `currentTeamRank`.
- Mantida a correção de escopo `projectedOverall` e documentada a validação pendente no pipeline Android.

# V644 (0.644.0) — Correções de compilação Kotlin

- Corrigidas duas referências não resolvidas reportadas no build Debug: `currentTeamRank` na tela de carreira Team Principal e `projectedOverall` na previsão de construção do carro.
- Incrementada a versão para 0.644.0; mantidas as regras e correções da V643.
- A compilação Android completa deve ser confirmada no pipeline com Gradle/Android SDK.

# V643 (0.643.0) — Contagem correta de GPs concluídos no perfil do piloto

- Corrigido o significado de GP no perfil: contabiliza corridas concluídas pelo piloto, excluindo os resultados DNF, que aparecem separadamente.
- Aplicada a mesma regra às estatísticas da temporada atual, ao histórico por temporada e ao total da carreira.
- Ao exibir históricos arquivados, os valores GP/DNF são recalculados a partir dos resultados de corrida disponíveis, corrigindo resumos antigos que incluíam DNFs na contagem de GPs concluídos.
- Mantida a contagem de corridas de construtores por GP quando pelo menos um dos pilotos termina a corrida.
- Adicionado teste de regressão para 30 provas inscritas com 3 DNFs: 27 GPs concluídos e 3 DNFs.
- Build Android completa e teste no dispositivo pendentes neste ambiente.

# V642 (0.642.0) — Meta comercial mínima obrigatória para a IA

- Tornado explícito o bloqueio estratégico: a IA não inicia melhorias de outras instalações enquanto o Centro Comercial estiver abaixo do nível 3.
- Se a melhoria não couber no caixa após as reservas operacionais ou no teto de investimento técnico anual, a IA aguarda e conserva o dinheiro; não cria saldo artificial e não desvia a prioridade para outra instalação.
- Após chegar ao nível 3, volta a aplicar a hierarquia normal, com Scouting como última prioridade.
- Incluído teste de regressão para cenário em que uma instalação mais barata caberia no caixa, mas o upgrade comercial violaria a reserva.
- Patrocínios V641 continuam usando o mesmo gerador de três ofertas e a mesma contabilização financeira compartilhada para jogador e IA.
- Correção ANR: simulação instantânea e avanço de semanas executam fora da thread principal, com modal de progresso e trava contra cliques duplicados.
- Histórico de corrida/qualificação passou a persistir incrementalmente por GP e resumos por temporada, mantendo leitura do arquivo legado e reduzindo o I/O crescente em saves longos.
- A auditoria do histórico passou por harness Kotlin isolado; a compilação Android completa ainda depende de um ambiente com Gradle/SDK.

# V641 (0.641.0) — Hierarquia da IA comercial e paridade do mercado de patrocínios

- O Centro de Scouting passou à última posição explícita da hierarquia de instalações da IA; a ordenação não usa mais o nível atual como critério principal, evitando que Scouting nível 0 ultrapasse instalações estratégicas de nível mais alto.
- O Centro Comercial/Marketing é meta estratégica mínima de nível 3 para a IA. Enquanto estiver abaixo do nível 3, a construção comercial lidera as decisões de instalação sempre que puder ser financiada sem violar o caixa protegido e o limite técnico compartilhado. Acima do nível 3, o crescimento volta a depender de fluxo de caixa e liquidez.
- A auditoria de patrocínio confirmou que jogador e IA já compartilhavam catálogo, regras por nível, fórmula monetária de contrato e liquidação financeira por GP.
- Corrigida a diferença de decisão do mercado: ao vencer um contrato, a IA agora gera as mesmas três ofertas de uma vaga, pela mesma seleção de categoria, catálogo, preços, metas esportivas e duração; ela escolhe automaticamente a melhor pelo retorno esperado, priorizando receita garantida e ponderando conservadoramente os bônus por metas. O bônus por pontos não entra no cálculo porque a liquidação canônica não o paga.
- Reposições simultâneas em slots diferentes reservam nomes já ativos ou escolhidos no mesmo GP, evitando duplicação acidental de marca. Mantida a persistência existente e a liquidação idempotente.
- Adicionados testes focados para a meta nível 3, hierarquia de Scouting, escolha da IA entre três ofertas e compartilhamento do cálculo financeiro por GP.

# V640 (0.640.0) — Correção dos nomes das instalações na visão geral da equipe

- Corrigido o mapeamento da faixa horizontal de instalações na tela central de equipes: o nível MARKETING é exibido como "Centro Comercial" (uma única instalação comercial, que também concentra o marketing/patrocínios).
- A instalação SCOUTING passa a ser identificada como "Scouting", compatível com sua arte e sua função real de precisão das informações do mercado de pilotos.
- O rótulo compacto Centro Comercial usa fonte de 9sp para caber melhor no cartão horizontal sem alterar o layout de toda a faixa.
- Alteração restrita à apresentação: não cria nem remove instalações, não altera os níveis persistidos, custos, manutenção, receitas comerciais, patrocínios ou saves existentes.

# V639 (0.639.0) — Contratos Team Principal de 1 a 3 anos e apoio da diretoria

- O contrato inicial do Team Principal passa a durar uma temporada na equipe escolhida.
- Ao término do contrato, o mercado abre uma única janela no fim da temporada: até quatro propostas totais (renovação da equipe atual + até três equipes externas), conforme o prestígio.
- Cada proposta persiste sua duração específica: 1, 2 ou 3 anos. Aceitar proposta externa agenda a troca para o início da próxima temporada; renovar mantém a equipe atual.
- Prestígio de 0–19 não desbloqueia propostas externas; 20–39 desbloqueia uma, 40–59 duas e 60–100 até três. A proposta da equipe atual permanece quando a diretoria não demite.
- Criado Apoio da Diretoria (0–100), atualizado a cada temporada por objetivos, classificação e variação de prestígio. O painel exibe o apoio e o risco estimado de demissão; a demissão é probabilística no fim da temporada e libera oportunidades externas.
- O evento de propostas/demissão usa o modal oficial aprovado e direciona o usuário à tela de decisões contratuais. Os avisos ficam registrados na Central de Notícias.
- O save Team Principal migra do schema 4 para o 5 preservando histórico e estados antigos; quando um save legado está em janela de revisão, a renovação atual é reconstruída.

# V638 (0.638.0) — Correção do bloqueio de troca de equipe no modo Team Principal

- Corrigido o bloqueio de avanço de temporada após aceitar uma proposta externa: a validação de elenco não exige que a equipe de destino já tenha dois contratos para a próxima temporada antes de executar o mercado de pré-temporada.
- A equipe contratante permanece pendente até a virada transacional; no rollover, o mercado de pilotos resolve contratos vencidos e tenta preencher as vagas da equipe de destino.
- Se o mercado não conseguir completar o elenco por limitação financeira ou contratual, a temporada ainda avança e a nova equipe exibe uma notificação para completar o elenco manualmente; o Team Principal não fica preso na tela de virada.
- O preenchimento automático fica restrito ao handoff Team Principal confirmado. Carreiras comuns continuam bloqueadas se o elenco projetado não tiver exatamente dois pilotos, sem atribuições artificiais.
- Adicionados testes de regressão para o gate de elenco, conclusão automática do elenco entrante e aplicação do contrato somente na temporada seguinte.

# V637 (0.637.0) — Ciclo decenal 80–100 → 40–60

- Recalibrada a ambição de investimento da IA: carros financiados evoluem de forma mais forte, com ganho planejado de até +7 Overall abaixo de 70, +5 de 70 a 89, +2 de 90 a 96 e +1 acima disso. O alvo é alcançar 80–100 antes da revolução decenal, sem bônus adicional além da tabela.
- Recalibrada a revolução regulamentar a cada dez temporadas: redução média de 40% nos seis componentes (motor 40%, chassi 35%, asas 45%, freios 35%, unidade elétrica 40%). Uma construção entre 80 e 100 volta à faixa de 40–60 quando aplicada a regra.
- Preservada a tabela universal investimento × Overall, o bônus único de 10%, o limite de investimento de €150M, os limites de caixa/reservas da IA, as identidades das peças e as confiabilidades.
- Estendido o teste de estresse para 20 transições e duas revoluções decenais (2036 e 2046), com testes automatizados da faixa pré/pós-regulamento.

# V636 (0.636.0) — Construção por investimento também com valor zero

- Corrigida a exceção que mantinha a força do carro anterior quando o investimento era zero. Todos os valores, incluindo €0, agora atravessam a regra universal investimento × Overall.
- Estendida a faixa abaixo de €8M de modo que €0 corresponde a Overall-base 0 e €8M a Overall-base 40; a tabela aprovada entre €8M e €150M segue intacta.
- Atualizadas a construção física, a rota legado, as previsões e o painel-resumo; peças ausentes continuam ausentes e as identidades/confiabilidades físicas são preservadas.

# V635 (0.635.0) — Construção do carro do próximo ano por investimento

- A tabela de investimento define o Overall-base do carro novo; o bônus de 10% só é aplicado uma vez.
- Recalibrada a meta da IA para inverter o bônus de construção: até +3 Overall abaixo de 60, até +2 de 60 a 79 e manutenção a partir de 80, sempre limitada por caixa e reservas reais.
- Previsões refletem o resultado físico alcançável e não contam peças ausentes como instaladas.
- Foco e conhecimento técnico especializam componentes sem aumentar novamente a média; regras anuais/decenais continuam aplicadas após a construção.

# V633 (0.633.0) — Objetivos da diretoria recalibrados pelo carro novo

# V632 (0.632.0) — Clima por circuito

- Corrigido o excesso de mudanças climáticas, os relógios de Q1/Q2/Q3 e tentativas repetidas de clima na corrida.
- Criados perfis climáticos específicos por circuito e sorteio de clima da largada independente da classificação.

# V631 (0.631.0) — Redesign da avaliação do Team Principal

# V630 (0.630.0) — Dashboard Team Principal

- Novo resumo de carreira com imagem de chefe de equipe e estatísticas agregadas.
- Card de prestígio ampliado para exibir todo o conteúdo.
- Conquistas movidas para painel aberto por botão.
- Objetivos interativos com estado ao vivo baseado nos dados da temporada.

# V629 (0.629.0) — Altura dos cards da carreira

## V628 (0.628.0)
- Corrige referência não resolvida `careerLoadRevision` na tela Home, passando a revisão de carregamento como parâmetro.
- Mantém a correção V627 de exportação/importação de save completo.

# V627 (0.627.0) — Save completo e importação/exportação verificadas

# V626 (0.626.0) — Minha Carreira: rolagem e objetivos interativos

# V625 (0.625.0)
- Corrigido import Compose inacessível de `weight` em `TeamPrincipalCareerScreen.kt`.

# V624 — Correção da tela de regulamento e padronização do modal de renovação

- A tela de mudança de regulamento agora respeita as áreas seguras do Android, usando padding de barra de status e navegação para impedir que o título encoste nos ícones do telefone ou que o botão inferior fique atrás da navegação.
- Os cards de regulamento foram padronizados com fundo grafite, contorno discreto e raio de 16 dp.
- A imagem regulamentar mantém a proporção original 600×330, deixando visível a faixa/banner já embutida nas artes e evitando que a imagem seja cortada ou pareça ficar atrás do texto.
- O modal de notificações agora garante explicitamente a arte `notice_market_signed` para renovação, assinatura/fechamento de contrato e transferência confirmada; a arte de mercado usa proporção panorâmica para não desaparecer nem ser excessivamente recortada.
- O modal de evento respeita as áreas seguras e tem altura máxima com rolagem interna para que título, mensagem e botões não sejam cortados em telas menores.
- Preservados os dados, a lógica de regulamentação, os estados de contratos, a Central de Notícias e todos os assets existentes.
- Validação de pacote e análise estática concluídas; compilação Android completa ainda precisa ser confirmada no pipeline, pois este ambiente não tem Gradle/gradlew.

# V623 — Eventos operacionais usam o modal oficial

- Corrigida a apresentação na Home para que “INSTALAÇÃO CONCLUÍDA”, “JANELA DE TRANSFERÊNCIA ABERTA” e “PROGRAMA DE DESENVOLVIMENTO CONCLUÍDO” deixem de ocupar cards inline grandes e usem o mesmo modal centralizado dos demais eventos.
- Reutilizada a arte já existente de cada evento, com categoria, título, temporada/semana, descrição, botão CONTINUAR e ação principal.
- O botão da abertura do mercado agora se chama “ABRIR MERCADO” e navega diretamente ao Mercado de Pilotos.
- Filtragem ajustada para priorizar avisos da equipe do jogador e o desenvolvimento dos pilotos atuais, evitando mostrar desenvolvimento de piloto de outra equipe como evento do jogador.
- Removido o composable de card inline que não será mais utilizado.
- Preservados motores de jogo, regras, saves e os 195 assets existentes.
- Build Android completo ainda precisa ser confirmado pelo pipeline; este ambiente não possui Gradle instalado e o pacote não contém `gradlew`.

# V622 — Redesenho compacto da tela Minha Carreira

- Tela separada em `TeamPrincipalCareerScreen.kt`, reduzindo acoplamento com `MainActivity.kt` e deixando a implementação visual mais fácil de manter.
- Layout adaptativo para largura/altura em dp: margem horizontal de 8–11 dp, espaçamento entre seções de 5–6 dp e cards externos padronizados com raio de 14 dp e borda de 1 dp.
- Cabeçalho centralizado, card de prestígio com hierarquia visual consistente, objetivos em grade de duas colunas, conquistas em grade de duas colunas e a tabela de trajetória com Ano, Escudo, Equipe, POS, VIT, POLE e POD.
- Cards dimensionados por pesos de altura disponíveis; a página principal não usa `verticalScroll` nem rolagem horizontal. Quando houver mais de três temporadas, o card de trajetória alterna entre as três mais recentes e todo o histórico, com rolagem limitada à lista interna para não mover o restante da tela.
- Ícones de interface trocados de glifos Unicode por ícones Material, e escudos recuperados pelo `TeamLogo` a partir do sistema de assets existente. Estatísticas ausentes aparecem como “—”; nenhum resultado ilustrativo é gravado no save.
- Preservados os callbacks da carreira, avaliação contratual, saída para HOME e leitura dos dados históricos; assets e motores de jogo não foram modificados.
- O layout foi revisado estaticamente para o formato estreito de um Poco X7 Pro. Compilação Android completa e verificação visual em dispositivo ainda dependem do pipeline, indisponível neste ambiente.

# V621 — Correção da interpolação do ranking da revelação do carro

- Corrigida a string do ranking em `SeasonCarRevealScreen`: `${teamRank}º` delimita explicitamente a variável antes do símbolo ordinal, evitando que Kotlin procure o identificador inexistente `teamRankº`.
- Mantidas as correções Compose e os arquivos Gradle de raiz incluídos na V620.
- Sem mudanças nas regras de patrocínio, mercado de pilotos, finanças, assets ou saves.
- Build Android completo ainda precisa ser confirmado pelo pipeline; este ambiente não dispõe do Gradle instalado.

# V620 — Correção de compilação Kotlin/Compose pós-V619

- Removida a anotação `@Composable` duplicada em `HomeEventImageCard`.
- Adicionada a anotação `@Composable` que faltava em `Home`, corrigindo os erros em cascata de chamadas Compose na HOME.
- Importado `graphicsLayer` explicitamente em `SeasonEndEventScreen.kt`.
- Mantida a assinatura de `SeasonCarRevealScreen` com `teamRank` e `totalTeams`; conferir novamente no pipeline Android para confirmar que o erro reportado não reaparece.
- Sem alterações nas regras de patrocínio, investimentos, contratos de pilotos, assets ou saves da V619.
- A compilação Android completa precisa ser confirmada no pipeline Gradle, pois este ambiente não tem o Gradle instalado e o ZIP não contém `gradlew`.

# V619 — Contratos com entrada + pagamento por GP e IA investindo no Centro Comercial

- Todos os 180 perfis de patrocínio agora usam valor de entrada e pagamento garantido por GP; a regra vale para Master e slots secundários, sem alterar as faixas monetárias por categoria ou os bônus de desempenho.
- Saves existentes são migrados sem apagar o valor já negociado: contratos antigos que tinham somente entrada ou somente valor por GP recebem o componente que faltava, de forma determinística e idempotente.
- A IA passa a priorizar o Centro Comercial até o nível 2, que abre acesso a oportunidades Regionais, desde que consiga pagar a obra e preservar pelo menos €15M de liquidez operacional. Níveis seguintes dependem de saldo e fluxo de caixa, evitando investimentos agressivos quando a operação está no vermelho. Se a melhoria comercial não couber na reserva, a IA pode investir em outra instalação mais barata, em vez de travar todos os upgrades.
- A seleção de contratos da IA agora acompanha o nível real do Centro Comercial persistido, inclusive depois de melhorias, para que novos patrocínios possam usar categorias mais altas.
- A simulação de temporada também credita a receita semanal das lojas para equipes de IA; a chave de idempotência existente impede pagamento duplicado em replay ou restauração.
- Adicionado teste direcionado para os dois pagamentos em todos os níveis/slots, migração de contratos antigos, prioridade de investimento, proteção de caixa e idempotência da receita.
- Preservados os assets, calendário, histórico de versões e os demais sistemas. Build Android completo e teste em dispositivo permanecem pendentes neste ambiente.

# V618 — Redução de renovações automáticas e prioridade a pilotos melhores

- Cada renovação de IA é avaliada uma única vez por piloto/equipe/temporada; a avaliação é persistida nos saves para evitar que a probabilidade seja repetida toda semana.
- Reduzidas as probabilidades-base de renovação para 40%, 28%, 16% ou 6%, conforme o encaixe esportivo.
- Se houver um piloto disponível pelo menos 8 pontos melhor, com interesse forte pela equipe e sem interesse significativamente inferior ao titular pela equipe, a IA não renova o titular automaticamente e prioriza buscar a melhoria no mercado.
- Persistência compatível com saves existentes: saves antigos começam a registrar as avaliações a partir da primeira semana em que o mercado já estiver aberto, sem apagar contratos, histórico ou assets.
- Adicionado teste direcionado para uma única avaliação e para não renovar um piloto fraco diante de alternativa claramente superior.
- Build Android completo e teste em dispositivo permanecem pendentes neste ambiente.

# V617 — Apresentação animada da força do carro na virada de temporada

- Tela de revelação técnica após iniciar a próxima temporada: carro da equipe, barra animada de força, investimento, herança técnica e regulamento.
- Revela desempenho, confiabilidade e ranking de força; pular animação não altera os resultados.
- Snapshot persistido por temporada para impedir que a apresentação repita cálculos ou aplique alterações duas vezes.
- Reutiliza assets existentes; sem novas imagens.
- Build Android completo e teste em dispositivo pendentes neste ambiente.

# V615 — Card persistente de abertura da janela de transferência
- A abertura do mercado gera uma notificação persistente na semana em que a regra do mercado passa a permitir negociações.
- A HOME renderiza o card a partir da notificação não lida, em vez de depender somente de uma condição visual temporária por semana.
- Saves em que o mercado já está aberto, mas a notificação nunca foi gravada, são reparados de forma idempotente ao carregar a carreira.
- O card reutiliza a arte `notice_market_offer`; ao abrir o mercado, marca o aviso como lido e navega para a tela de negociações.
- Acrescentado teste direcionado para janela fechada, criação, idempotência e mudança de temporada.
- Build Android completo e teste visual no dispositivo não foram executados neste ambiente.

# V614 — Correção do card de conclusão de instalação na HOME

- A HOME agora identifica somente eventos de instalação realmente concluídos; o aviso de início não é confundido com conclusão.
- O evento de conclusão ganhou título e mensagem próprios, identificados explicitamente para a equipe do jogador.
- Removida a exclusão que impedia exibir upgrades da instalação de Desenvolvimento de Pilotos.
- Filtragem de ownership corrigida: eventos de evolução das equipes de IA não podem alimentar o card exclusivo da carreira do jogador.
- Adicionada recuperação idempotente para saves em que a instalação já atingiu o nível-alvo mas a notificação de conclusão não foi persistida.
- Preservados os assets existentes, histórico, lógica financeira e motores de simulação; sem imagens novas.
- Testes direcionados adicionados para eventos de início/conclusão, eventos legados, upgrades da instalação de Desenvolvimento de Pilotos, isolamento por equipe e recuperação sem duplicidade.
- Validação do build Android completo e execução no dispositivo permanecem pendentes neste ambiente.

# V609 — Correção de compilação da tela do próximo carro

- Corrigida referência Kotlin inexistente `investableBudget` em `MainActivity.kt`, responsável por falhar em `:app:compileDebugKotlin`.
- O cartão de orçamento agora exibe o caixa disponível após a reserva operacional, enquanto o teto absoluto permanece sendo o limite acumulado de €150M.
- Removida a variável redundante `investableRemaining`; os botões e o valor disponível para aporte continuam respeitando o saldo após reserva e o limite acumulado restante.
- Sem alterações nas regras de mercado de pilotos, nos dados de carreira, nos assets ou nos saves.
- Validação de fonte e empacotamento executada. A compilação Gradle/Android completa não pôde ser repetida neste ambiente porque o pacote não inclui `gradlew` e não há `gradle` instalado.

# V608 — Mercado de pilotos realista e virada sem atribuição forçada

- Eliminada a atribuição direta de pilotos na virada: a IA só fecha vaga por oferta aceita ou contraproposta dentro do limite financeiro/negocial, com histórico e notícia próprios.
- A equipe do jogador não recebe pilotos automaticamente. A ação de iniciar temporada verifica os dois contratos antes de abrir o diário persistente e indica como resolver uma vaga pendente sem alterar a carreira.
- Atratividade dos pilotos considera desempenho/classificação atual da equipe e posição/pontos do piloto, além da força/prestígio de base e dos atributos evoluídos.
- Candidato ao título tem resistência esportiva para trocar uma equipe competitiva por uma equipe muito inferior; remuneração extraordinária pode compensar, mas a decisão não é tratada como normal.
- A IA compara titulares e candidatos, prioriza contratos que vencem e só quebra contrato plurianual quando a melhoria esportiva é expressiva.
- Removida a barreira global 55/45 entre renovação e transferência. A IA pode renovar quando não há alternativa melhor, mas a proporção não impede uma substituição estrategicamente necessária.
- Ofertas concorrentes são comparadas antes da assinatura; múltiplas equipes podem disputar o mesmo piloto.
- As taxas de assinatura das contratações resolvidas na virada agora entram no ledger financeiro parcelado da IA, com registro idempotente persistido.
- Preservados os assets, o histórico de versões e os saves existentes. Validar dentro do jogo em uma carreira nova via **Novo Jogo**.
- Validação realizada: 59 fontes Kotlin do núcleo compiladas; 10 testes direcionados, 17 verificações específicas de mercado, 40 verificações gerais e 25 verificações finais aprovadas; 12 transições de temporada em 3 sementes mantiveram o grid completo.
- Limite: compilação Android/Gradle completa, JUnit oficial e validação em emulador/dispositivo não foram executadas neste ambiente.

# V607 — Evolução dos pilotos Normal para Auge moderado

- Todos os pilotos cadastrados com evolução `Normal` no catálogo inicial passam para `Auge moderado` (53 perfis).
- A alteração muda somente o tipo de evolução; classes e os sete atributos permanecem preservados.
- Removido o ajuste legado que forçava a evolução `Normal` para perfis da classe Fraco, para não desfazer a configuração solicitada.
- Demais tipos de evolução e o ciclo de carreira 5/2/5 permanecem inalterados.
- Validar a alteração em uma carreira criada pelo fluxo **Novo Jogo**; saves existentes não são apagados nem alterados automaticamente.

# V606 — Prioridade equilibrada de investimentos

- A IA distribui o caixa discricionário entre carro atual e próximo carro por tabela de prioridade: 10%, 15%, 25% e 35% para o próximo carro conforme a fase da temporada.
- A parcela do próximo carro fica protegida do gasto técnico corrente; o desenvolvimento do carro atual continua ativo com o restante do orçamento, respeitando a reserva operacional.
- Mantidos o teto técnico compartilhado de €200M/temporada e o teto independente de €150M para o próximo carro.
- Adicionados testes da tabela de prioridade e da proteção do caixa operacional.

# V605 — Correção dos limites de investimento

- Corrigido o bloqueio visual do próximo carro causado por uma referência de caixa congelada.
- Uniformizado o teto técnico anual de €200M e compartilhado entre P&D, fabricação e instalações.
- Migração de gastos legados sem apagar transações ou histórico.

# V604 — Calibração de desempenho versus evolução dos pilotos

- Corrigido cálculo de desempenho por GP: 40% qualificação, 60% corrida, desvio de posições em torno de índice neutro 100.
- Desempenho esperado passa a sustentar a trajetória normal; resultados abaixo desaceleram e resultados acima aceleram.
- Dados de quali/corrida ausentes usam a meta como valor neutro.
- Mesma lógica aplicada à carreira normal e ao modo Team Principal.
- Curva 5/2/5 e limites anuais por classe de evolução preservados.

# V603 — Auditoria e correção de integridade dos pilotos

- Ciclo 5/2/5 preservado entre temporadas.
- Regressão limitada ao piso Overall da classe.
- Catálogo de pilotos montado com uma leitura de atributos/classe.
- Heurística ineficaz específica do Felipe removida; novas carreiras usam perfis canônicos.

# V602 — Regra de nova carreira e proteção do calendário

- Cada atualização funcional deve ser validada em uma carreira nova; saves antigos não são apagados automaticamente.
- A simulação instantânea só roda na semana programada e não adianta semanas.
- Início/finalização da corrida bloqueiam rodadas/semana incompatíveis com o calendário persistido.
- Build Android ainda pendente; ver `AUDIT_V602_CALENDAR_FRESH_START.md`.

# V601 — Ciclo de evolução de pilotos 5/2/5

- Fases fixas de 5 anos de evolução, 2 de auge e 5 de regressão.
- Remove regressão antecipada por pressão de desempenho.
- Persiste limite anual de ganhos por atributo.

# V600 — Correção de identidade de pilotos e plano de pneus\n\n- Corrige identificação no plano de início para usar o elenco atual da carreira.\n- Corrige colisão de atributos/evolução de Felipe Drugovich em saves afetados.\n\n# V599 — Catálogo ampliado de objetivos Team Principal

- O objetivo principal continua sendo a posição no Mundial de Equipes e é recalculado pela posição atual.
- O objetivo secundário deixa de ser sempre financeiro: ele é o primeiro dos cinco objetivos sazonais sorteados do catálogo.
- Catálogo ampliado para 16+ tipos/opções, incluindo caixa, pontuação, evolução de posição, competitividade, progresso de pontos, pesquisa concluída, peça fabricada disponível e melhoria de cada uma das sete instalações.
- As metas de instalações são criadas conforme o nível atual e só aparecem quando há nível para evoluir; a conclusão verifica o nível real persistido.
- Pesquisa concluída é verificada pelo registro de designs concluídos na temporada. Fabricação verifica peças físicas aguardando instalação.
- Prestígio inicial 1, principal vale 4, outros objetivos valem 1; fracassos descontam e o ganho líquido continua limitado a +8 por temporada.
- Adicionado teste de contrato estático para catálogo, seleção, métricas e versionamento. Build Android e simulação integrada ainda pendentes.
- Versão Android: `versionCode 599` / `versionName 0.599.0`.

## V598 — Objetivos dinâmicos e prestígio equilibrado
- Prestígio inicial do modo Team Principal passa de 10 para 1.
- Objetivo principal é recalculado a cada temporada conforme a força/posição atual da equipe.
- Novo conjunto variável de seis objetivos: 1 principal, 1 secundário financeiro e 4 objetivos sazonais.
- Cumprir objetivos dá prestígio; fracassar desconta pontos. Ganho positivo por temporada limitado a 8.
- Saves Team Principal passam ao schema 3 com migração de leitura dos schemas antigos.
- Auditoria: `AUDIT_V598_TEAM_PRINCIPAL_OBJECTIVES.md`. Compilação Android ainda pendente.

# V597 — Balanceamento de decisões do mercado de pilotos

Ver `CHANGELOG_V597.md` e `AUDIT_V597_DRIVER_MARKET.md`.

# V596 — Correção de compilação no resumo de equipes

- Corrigida a referência não resolvida `store` em `teamOverviewSnapshot()`, adicionando `CareerPreferences` como parâmetro explícito da função.
- Mantidas as validações de save por modo da V595; nenhuma alteração nos assets externos ou no histórico de versões anterior.
- Versão Android: `versionCode 596` / `versionName 0.596.0`.
- Validação Android completa ainda depende da execução do workflow com Gradle/SDK; não declarar APK compilado até obter resultado verde.

# V595 — Saves identificados por modo e carreira

- Novo schema 2 com modo explícito (`FREE`, `HARD`, `TEAM_PRINCIPAL`) e ID único persistente da carreira no cabeçalho e nas preferências.
- Salvamento automático usa modo/equipe/temporada/ID da carreira no nome do arquivo, evitando colisões entre carreiras diferentes.
- Exportação valida o save selecionado; importação valida schema, tipos, modo, equipe, temporada, identidade, estado Team Principal e arquivo histórico antes de substituir o save ativo.
- A tela mostra o modo em cada save e bloqueia carregar/exportar arquivos inválidos ou com metadados divergentes.
- Mantida a compatibilidade com schema 1; saves antigos recebem modo explícito e ID estável ao importar quando os dados permitem identificar a carreira.
- Escritas locais protegidas por `AtomicFile`; falha na restauração do histórico tenta reverter preferências e arquivo anterior.
- Testes de contrato estático: 26/26; auditoria estrutural: 40/40; auditoria de release: 25/25. Build Android/JUnit/emulador não executados por ausência de Gradle/SDK/ADB.
- Versão Android: `versionCode 595` / `versionName 0.595.0`.

# V562 — Desempenho inicial da equipe e versão-base V0

- Corrigida a interpretação de V0: é a versão da peça, não o desempenho do componente.
- Jogador e IA começam com desempenho-base coerente com o nível Forte/Médio/Fraco da equipe selecionada.
- Os seis componentes iniciais são registrados como hardware-base V0; o primeiro novo design pesquisado é V1.
- O desempenho físico permanece inalterado ao iniciar pesquisa e só muda quando a peça melhorada é fabricada e instalada.
- Carreiras geradas incorretamente pela V561 com os dois carros em zero são migradas para o perfil-base da equipe; starter antigo INIT-* mantém seu desempenho e passa a V0.
- Adicionados testes de regressão para desempenho inicial, versão V0, criação do design V1 e preservação do desempenho na pesquisa.
- Versão Android: `versionCode 562` / `versionName 0.562.0`.
- ZIP verificado quanto à integridade; build Android e execução JUnit continuam pendentes neste ambiente.

# V473 — Contraproposta do piloto com exigências completas e acesso direto

- A notificação de contraproposta passa a informar salário anual exigido, duração, papel na equipe e temporada de início, usando valores monetários em milhões ou mil.
- O botão do aviso na Home passa a abrir diretamente o Mercado de Pilotos quando se trata de contraproposta.
- Ao entrar no Mercado de Pilotos, uma contraproposta pendente do jogador é aberta automaticamente; o card persistente continua disponível para reabrir e decidir.
- O diálogo mantém as três decisões: aceitar os termos, recusar ou enviar nova contraproposta, incluindo salário, duração e papel.
- Atualizada a versão Android para `versionCode 473` / `versionName 0.473.0`.
- ZIP verificado quanto à integridade; build Android ainda precisa ser confirmado no GitHub Actions.

# V472 — Valores financeiros de eventos em milhões e mil

Eventos de crise financeira e aquisição por investidores agora exibem valores monetários compactos, em vez de números inteiros sem separadores.

# V470 — Redução da altura dos cards do menu inicial

- Reduzido o espaço vertical reservado aos três cards principais do menu inicial para deixá-los menos altos no POCO X7 Pro.
- Reduzidos espaçamentos entre cards, padding vertical, ícones e tipografia secundária para manter a leitura e os alvos de toque.
- Mantidos os textos, estados habilitado/desabilitado, callbacks e fundo aprovado; não foi adicionada rolagem.
- Atualizada a versão Android para `versionCode 470` / `versionName 0.470.0`.
- ZIP verificado quanto à integridade; build Android ainda precisa ser confirmado no GitHub Actions.

# V469 — Correção de compilação da tela de saves

- Movida a declaração do estado `refresh` para antes do `LaunchedEffect` que o incrementa.
- Corrige o erro Kotlin de inferência de tipo e a referência não resolvida `refresh` em `SaveManagementScreen.kt`.
- Atualizada a versão Android para `versionCode 469` / `versionName 0.469.0`.
- Mantidos os recursos e os demais arquivos do ZIP de origem.
- A compilação Android ainda precisa ser confirmada no GitHub Actions.

# V462 — Ranking inicial consistente no Modo Difícil

- Corrigido o ranking de força mostrado na abertura da carreira: na semana inicial, as 40 equipes são comparadas usando os mesmos carros iniciais determinísticos usados pela seleção do Modo Difícil.
- Evita que simulações/cache de desenvolvimento da IA alterem o ranking antes do início efetivo da temporada.
- Após a primeira semana, o ranking volta a refletir os carros evoluídos pela simulação da IA.
- Build Android não executado neste ambiente; validar no GitHub Actions.

# V461 — Nomes completos dos pilotos na seleção de equipe

- A seleção de equipe agora apresenta o nome completo de cada piloto nos campos PILOTO 1 e PILOTO 2, sem reduzir para o sobrenome.
- Ajustada a tipografia e permitidas até duas linhas para acomodar nomes longos no espaço existente.
- Nenhuma regra de força inicial, modo difícil ou seleção de equipe foi alterada.
- Compilação Android não executada neste ambiente.

# V457 — Notícias do Mercado de Pilotos na Home
- Contrapropostas ligadas à equipe do jogador agora podem gerar card de evento na Home.
- Renovações e assinaturas/fechamentos de contrato aparecem na Home tanto para a equipe do jogador quanto para equipes da IA.
- Contagem e prioridade do aviso de Mercado na Home alinhadas às novas regras; histórico do Central de Notícias preservado.

# V456 — Retorno à Home após fim de temporada
- Botão do evento de fim de temporada retorna à Home; não inicia a próxima temporada.

# V455 — Manutenção semanal e continuidade financeira

- Implementada manutenção semanal por nível de cada instalação, para jogador e IA.
- A cobrança percorre todas as semanas do calendário até o GP atual e usa chaves persistentes temporada:semana para impedir duplicidade.
- Manutenções sem caixa ficam como obrigações pendentes e são quitadas em ordem cronológica quando houver saldo, sem perder histórico.
- Persistência ampliada para salvar semanas cobradas e obrigações pendentes no estado financeiro do jogador e no snapshot da IA.
- Preservadas regras de custo por GP: forte €2,5M, média €1,5M e fraca €0,8M.

# V454 — Auditoria financeira e custos por GP

- Custos operacionais por GP ajustados: equipe forte €2.500.000, média €1.500.000 e fraca €800.000; valor centralizado para jogador e IA.
- Corrigido o histórico de liquidação da IA: os lançamentos de patrocínio, premiação e custo operacional do GP não são mais substituídos pelo extrato anterior ao gravar o marcador de idempotência.
- Obrigações salariais pendentes agora entram no saldo efetivo de encerramento da temporada; caixa zerado com salários em aberto não evita a penalidade financeira.
- Mantida a proteção contra pagamentos duplicados e preservado o histórico de transações existente.
- Validação estática e integridade do ZIP realizadas. Build Android/JUnit não executados neste ambiente.

# V368 — Teste ponta a ponta da simulação instantânea

- Adicionado teste JUnit para executar o serviço de simulação instantânea com o motor real, 80 pilotos e distância programada.
- Verificadas as fases Q1/Q2/Q3 (80/50/20), a classificação final e a rejeição de circuito divergente sem avançar o motor.
- Versão Android atualizada para 0.368.0.
- Execução JUnit e build Android seguem pendentes: o pacote não contém Gradle Wrapper e o ambiente não tem Gradle instalado; a tentativa de compilação isolada de todo o domínio excedeu o tempo disponível.

# V341 — Correção de compilação

- Corrigida referência inválida `team.name` na filtragem de notificações da Home; `team` já é uma `String`.
- Mantida a regra de pontuação aprovada na V340.
- Validação estática e integridade do ZIP; compilação Android ainda precisa ser executada no ambiente Gradle.

## V269
- Corrigido o resolvedor anual em lote: cada ocorrência de evento de equipe agora seleciona uma única equipe de forma determinística, evitando multiplicar uma ocorrência por todas as equipes. Aquisições usam ponderação que favorece equipes mais fracas.

## V268
- Revisão do calendário anual: a semente de criação permanece fixa e o calendário persistido é reutilizado entre avanços e recargas.
- Mantidos os limites de eventos por temporada e a agenda de semanas únicas.

## V267
- Corrigida a semente do calendário anual de eventos para ser estável entre avanços semanais e recargas.

## V443
- Motor de catálogo e sorteio persistente de regulamento anual/decenal do carro (Etapa 1). Ver `CHANGELOG_V443.md`.


## V444 — Regulamento integrado à virada de temporada
- O carro é construído primeiro, recebe a regra da nova temporada depois, e o ranking/metas são preparados com os valores regulados.
- Regra compartilhada para IA e jogador; confiabilidade não é penalizada.


## V458
- Menu inicial Compose com três cards funcionais e fundo de garagem.


## V459
- Novo Jogo permite escolher Modo Livre (40 equipes) ou Modo Difícil (as 3 equipes de menor força inicial).

## V460 — Sistema de saves
Consulte `CHANGELOG_V460.md` para lista de saves, exportação/importação JSON e restauração do histórico.


## V463 — Navegação por gesto entre equipes
- O card superior da Central de Equipes aceita deslizar para a esquerda/direita para selecionar a próxima/anterior equipe no ranking.
- Os botões de seta continuam disponíveis.
- O gesto fica restrito ao card para preservar o gesto lateral do sistema Android e o botão Voltar existente.

## V586 — Modo Team Principal (primeira implementação)
- Terceiro modo de carreira com prestígio, objetivos, avaliações contratuais bienais, propostas de outras equipes e possível demissão.
- Prestígio persiste entre empregadores; histórico profissional registra a equipe de cada temporada.
- Livre e Difícil são mantidos. Build Android e testes completos ponta a ponta ainda pendentes.
- Detalhes: `CHANGELOG_V586.md` e `AUDIT_V586_TEAM_PRINCIPAL.md`.


## V588 — Modo Team Principal restrito à carreira correta
- Adicionado marcador persistente `activeGameMode` (`FREE`, `HARD`, `TEAM_PRINCIPAL`).
- O card “Team Principal • Minha Carreira” só é renderizado quando o modo ativo é Team Principal e há estado de carreira válido.
- Iniciar qualquer nova carreira limpa os dados antigos de Team Principal; a escolha do modo é salva explicitamente.
- Saves Team Principal antigos, sem marcador, recebem migração compatível. Saves Livre/Difícil não exibem nem usam painel/avaliação de Team Principal.
- Teste de regressão cobre modo Livre, Difícil, Team Principal, estado ausente e saves antigos.
- Testes Kotlin/Gradle e build Android completos continuam pendentes neste ambiente.


## V590 — Ranking visivelmente renovado ao reabrir Novo Jogo
- Não basta a semente ser diferente: agora a seleção procura outro ranking completo e outras três equipes mais fracas, repetindo o sorteio quando o resultado visível coincidir com a seleção anterior.
- A prévia continua sem alterar a semente da carreira salva; ao confirmar equipe, ranking e carro permanecem sincronizados.
- Teste de regressão adicional. Build Android/Gradle completo não executado neste ambiente.
- Detalhes: `CHANGELOG_V590.md` e `AUDIT_V590_NEW_GAME_RANKING.md`.

## V613 — Balanceamento do ritmo de carro e piloto
- Ritmo-base em seco/nublado ponderado em 65% carro e 35% piloto.
- Em chuva leve, média e forte, a ponderação passa a 60% carro e 40% piloto.
- Componentes do carro e velocidade do piloto entram uma única vez no ritmo-base; consistência, pneus, corrida lado a lado, chuva, DRS/ERS e confiabilidade mantêm suas influências específicas.
- Classificação interativa usa o mesmo cálculo compartilhado do modelo principal.
- Validação isolada do núcleo e smoke test aprovados; compilação Android completa ainda pendente.
- Detalhes: `CHANGELOG_V613.md` e `AUDIT_V613_PERFORMANCE_BALANCE.md`.

## V616 — Agrupamento do pelotão sob Safety Car
- Todos os caminhos de deploy do Safety Car (espontâneo e após acidente) passam a acionar agrupamento progressivo real, em vez de apenas atualizar posições visuais.
- Gaps são reduzidos por meio dos tempos das voltas neutralizadas, sem reescrever tempos já acumulados; sob SC, o motor suprime 90% da variação normal de ritmo para os carros seguirem um pace controlado, com limite de fechamento por volta e piso de tempo plausível.
- DRS e ultrapassagens ficam desativados sob SC/VSC; o motor interativo registra início/fim e usa duração explícita da neutralização.
- Teste integrado confirmou redução da dispersão temporal do pelotão de 27.015 ms para 20.242 ms após deploy forçado em cenário de teste.
- Compilação Android completa/JUnit oficial/emulador pendentes. Detalhes em `CHANGELOG_V616.md` e `AUDIT_V616_SAFETY_CAR_PELOTON.md`.
