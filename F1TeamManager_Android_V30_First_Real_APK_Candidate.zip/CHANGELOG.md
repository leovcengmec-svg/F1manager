# V469 — Correção de compilação da tela de saves

- Movida a declaração do estado `refresh` para antes do `LaunchedEffect` que o incrementa.
- Corrige o erro Kotlin de inferência de tipo e a referência não resolvida `refresh` em `SaveManagementScreen.kt`.
- Atualizada a versão Android para `versionCode 469` / `versionName 0.469.0`.
- Mantidos os recursos e os demais arquivos do ZIP de origem.
- A compilação Android ainda precisa ser confirmada no GitHub Actions.

# V462 — Ranking inicial consistente no Modo Difícil

- Corrigido o ranking de força mostrado na abertura da carreira: na semana inicial, as 40 equipes são comparadas usando os mesmos carros iniciais determinísticos usados pela seleção do Modo Difícil.
- Evita que simulações/cache de desenvolvimento da IA alterem o ranking antes do início efetivo da temporada.
- Após a primeira semana, o ranking volta a refletir os carros evoluídos pela simulação da IA.
- Build Android não executado neste ambiente; validar no GitHub Actions.

# V461 — Nomes completos dos pilotos na seleção de equipe

- A seleção de equipe agora apresenta o nome completo de cada piloto nos campos PILOTO 1 e PILOTO 2, sem reduzir para o sobrenome.
- Ajustada a tipografia e permitidas até duas linhas para acomodar nomes longos no espaço existente.
- Nenhuma regra de força inicial, modo difícil ou seleção de equipe foi alterada.
- Compilação Android não executada neste ambiente.

# V457 — Notícias do Mercado de Pilotos na Home
- Contrapropostas ligadas à equipe do jogador agora podem gerar card de evento na Home.
- Renovações e assinaturas/fechamentos de contrato aparecem na Home tanto para a equipe do jogador quanto para equipes da IA.
- Contagem e prioridade do aviso de Mercado na Home alinhadas às novas regras; histórico do Central de Notícias preservado.

# V456 — Retorno à Home após fim de temporada
- Botão do evento de fim de temporada retorna à Home; não inicia a próxima temporada.

# V455 — Manutenção semanal e continuidade financeira

- Implementada manutenção semanal por nível de cada instalação, para jogador e IA.
- A cobrança percorre todas as semanas do calendário até o GP atual e usa chaves persistentes temporada:semana para impedir duplicidade.
- Manutenções sem caixa ficam como obrigações pendentes e são quitadas em ordem cronológica quando houver saldo, sem perder histórico.
- Persistência ampliada para salvar semanas cobradas e obrigações pendentes no estado financeiro do jogador e no snapshot da IA.
- Preservadas regras de custo por GP: forte €2,5M, média €1,5M e fraca €0,8M.

# V454 — Auditoria financeira e custos por GP

- Custos operacionais por GP ajustados: equipe forte €2.500.000, média €1.500.000 e fraca €800.000; valor centralizado para jogador e IA.
- Corrigido o histórico de liquidação da IA: os lançamentos de patrocínio, premiação e custo operacional do GP não são mais substituídos pelo extrato anterior ao gravar o marcador de idempotência.
- Obrigações salariais pendentes agora entram no saldo efetivo de encerramento da temporada; caixa zerado com salários em aberto não evita a penalidade financeira.
- Mantida a proteção contra pagamentos duplicados e preservado o histórico de transações existente.
- Validação estática e integridade do ZIP realizadas. Build Android/JUnit não executados neste ambiente.

# V368 — Teste ponta a ponta da simulação instantânea

- Adicionado teste JUnit para executar o serviço de simulação instantânea com o motor real, 80 pilotos e distância programada.
- Verificadas as fases Q1/Q2/Q3 (80/50/20), a classificação final e a rejeição de circuito divergente sem avançar o motor.
- Versão Android atualizada para 0.368.0.
- Execução JUnit e build Android seguem pendentes: o pacote não contém Gradle Wrapper e o ambiente não tem Gradle instalado; a tentativa de compilação isolada de todo o domínio excedeu o tempo disponível.

# V341 — Correção de compilação

- Corrigida referência inválida `team.name` na filtragem de notificações da Home; `team` já é uma `String`.
- Mantida a regra de pontuação aprovada na V340.
- Validação estática e integridade do ZIP; compilação Android ainda precisa ser executada no ambiente Gradle.

## V269
- Corrigido o resolvedor anual em lote: cada ocorrência de evento de equipe agora seleciona uma única equipe de forma determinística, evitando multiplicar uma ocorrência por todas as equipes. Aquisições usam ponderação que favorece equipes mais fracas.

## V268
- Revisão do calendário anual: a semente de criação permanece fixa e o calendário persistido é reutilizado entre avanços e recargas.
- Mantidos os limites de eventos por temporada e a agenda de semanas únicas.

## V267
- Corrigida a semente do calendário anual de eventos para ser estável entre avanços semanais e recargas.

## V443
- Motor de catálogo e sorteio persistente de regulamento anual/decenal do carro (Etapa 1). Ver `CHANGELOG_V443.md`.


## V444 — Regulamento integrado à virada de temporada
- O carro é construído primeiro, recebe a regra da nova temporada depois, e o ranking/metas são preparados com os valores regulados.
- Regra compartilhada para IA e jogador; confiabilidade não é penalizada.


## V458
- Menu inicial Compose com três cards funcionais e fundo de garagem.


## V459
- Novo Jogo permite escolher Modo Livre (40 equipes) ou Modo Difícil (as 3 equipes de menor força inicial).

## V460 — Sistema de saves
Consulte `CHANGELOG_V460.md` para lista de saves, exportação/importação JSON e restauração do histórico.


## V463 — Navegação por gesto entre equipes
- O card superior da Central de Equipes aceita deslizar para a esquerda/direita para selecionar a próxima/anterior equipe no ranking.
- Os botões de seta continuam disponíveis.
- O gesto fica restrito ao card para preservar o gesto lateral do sistema Android e o botão Voltar existente.
