# V461 — Correção de compilação da tela de saves
- Estado `refresh` declarado antes do `LaunchedEffect` em `SaveManagementScreen.kt`.

# V457 — Notícias do Mercado de Pilotos na Home
- Contrapropostas ligadas à equipe do jogador agora podem gerar card de evento na Home.
- Renovações e assinaturas/fechamentos de contrato aparecem na Home tanto para a equipe do jogador quanto para equipes da IA.
- Contagem e prioridade do aviso de Mercado na Home alinhadas às novas regras; histórico do Central de Notícias preservado.

# V456 — Retorno à Home após fim de temporada
- Botão do evento de fim de temporada retorna à Home; não inicia a próxima temporada.

# V455 — Manutenção semanal e continuidade financeira

- Implementada manutenção semanal por nível de cada instalação, para jogador e IA.
- A cobrança percorre todas as semanas do calendário até o GP atual e usa chaves persistentes temporada:semana para impedir duplicidade.
- Manutenções sem caixa ficam como obrigações pendentes e são quitadas em ordem cronológica quando houver saldo, sem perder histórico.
- Persistência ampliada para salvar semanas cobradas e obrigações pendentes no estado financeiro do jogador e no snapshot da IA.
- Preservadas regras de custo por GP: forte €2,5M, média €1,5M e fraca €0,8M.

# V454 — Auditoria financeira e custos por GP

- Custos operacionais por GP ajustados: equipe forte €2.500.000, média €1.500.000 e fraca €800.000; valor centralizado para jogador e IA.
- Corrigido o histórico de liquidação da IA: os lançamentos de patrocínio, premiação e custo operacional do GP não são mais substituídos pelo extrato anterior ao gravar o marcador de idempotência.
- Obrigações salariais pendentes agora entram no saldo efetivo de encerramento da temporada; caixa zerado com salários em aberto não evita a penalidade financeira.
- Mantida a proteção contra pagamentos duplicados e preservado o histórico de transações existente.
- Validação estática e integridade do ZIP realizadas. Build Android/JUnit não executados neste ambiente.

# V368 — Teste ponta a ponta da simulação instantânea

- Adicionado teste JUnit para executar o serviço de simulação instantânea com o motor real, 80 pilotos e distância programada.
- Verificadas as fases Q1/Q2/Q3 (80/50/20), a classificação final e a rejeição de circuito divergente sem avançar o motor.
- Versão Android atualizada para 0.368.0.
- Execução JUnit e build Android seguem pendentes: o pacote não contém Gradle Wrapper e o ambiente não tem Gradle instalado; a tentativa de compilação isolada de todo o domínio excedeu o tempo disponível.

# V341 — Correção de compilação

- Corrigida referência inválida `team.name` na filtragem de notificações da Home; `team` já é uma `String`.
- Mantida a regra de pontuação aprovada na V340.
- Validação estática e integridade do ZIP; compilação Android ainda precisa ser executada no ambiente Gradle.

## V269
- Corrigido o resolvedor anual em lote: cada ocorrência de evento de equipe agora seleciona uma única equipe de forma determinística, evitando multiplicar uma ocorrência por todas as equipes. Aquisições usam ponderação que favorece equipes mais fracas.

## V268
- Revisão do calendário anual: a semente de criação permanece fixa e o calendário persistido é reutilizado entre avanços e recargas.
- Mantidos os limites de eventos por temporada e a agenda de semanas únicas.

## V267
- Corrigida a semente do calendário anual de eventos para ser estável entre avanços semanais e recargas.

## V443
- Motor de catálogo e sorteio persistente de regulamento anual/decenal do carro (Etapa 1). Ver `CHANGELOG_V443.md`.


## V444 — Regulamento integrado à virada de temporada
- O carro é construído primeiro, recebe a regra da nova temporada depois, e o ranking/metas são preparados com os valores regulados.
- Regra compartilhada para IA e jogador; confiabilidade não é penalizada.


## V458
- Menu inicial Compose com três cards funcionais e fundo de garagem.


## V459
- Novo Jogo permite escolher Modo Livre (40 equipes) ou Modo Difícil (as 3 equipes de menor força inicial).

## V460 — Sistema de saves
Consulte `CHANGELOG_V460.md` para lista de saves, exportação/importação JSON e restauração do histórico.
