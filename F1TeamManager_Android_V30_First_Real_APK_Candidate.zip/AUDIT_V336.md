# Auditoria V336 — Instalações das equipes IA

## Resultado
Causa confirmada por inspeção: a tela de equipe construía `TeamOverviewSnapshot.facilities` a partir de uma simulação sem o estado persistido das instalações. O valor padrão era `FacilityEngine.initial(team.initialLevel)`, portanto o card podia mostrar o nível inicial mesmo após progresso salvo em `AITeamFinancialEngine`.

## Arquivos alterados
- `app/src/main/java/com/f1teammanager/MainActivity.kt`
- `app/src/main/java/com/f1teammanager/core/manager/ManagerSeasonEngine.kt`
- `app/build.gradle.kts`

## Regras preservadas
- Instalações independentes por equipe e categoria.
- Uma melhoria por equipe por vez, com prazo de 12 semanas.
- Custos, orçamento técnico anual e persistência do snapshot financeiro da IA.
- Instalações passadas ao motor de corrida continuam sendo as persistidas, sem resetar para `initialLevel`.

## Checagens estáticas
- Chamadas de simulação na tela de equipe usam `aiFinance.facilities(teamId)`.
- Chamadas do motor de temporada usam o mesmo estado persistido.
- Versão 0.336.0 / código 336.
- Integridade do ZIP verificada.

## Limitações
Não foi executada compilação Gradle nem simulação completa de temporadas; a validação em dispositivo continua necessária.
