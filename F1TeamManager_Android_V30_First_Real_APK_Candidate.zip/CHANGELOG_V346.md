# V346 — fechamento de corrida usa snapshot canônico

- O finalizador compartilhado agora usa o `SessionSnapshot` concluído recebido como argumento para persistir a qualificação, em vez de depender do estado mutável `snapshot` da tela.
- O resultado da corrida é capturado uma única vez em uma variável local e reutilizado no processamento financeiro, pontuação e notícia de resultado, evitando leituras inconsistentes de estado durante o fechamento.
- Mantida a proteção existente contra fechamento duplicado após o registro do GP.
- Nenhuma alteração de interface ou botões.

Validação: integridade do ZIP e inspeção estática. Build Android e JUnit não executados neste ambiente.
