# V399 — Botões do card Próxima Corrida

- Substituído o rótulo `IR PARA CALENDÁRIO` por `ABRIR FIM DE SEMANA`.
- Padronizada a cor de fundo dos dois botões do card e mantido texto branco.
- Na semana do GP, os dois botões ficam vermelhos com texto branco; fora da semana da corrida, ambos usam o mesmo tom escuro.
- Mantido o comportamento de habilitação do botão de abrir/retomar e do botão de pular fim de semana.
- Nome oficial do ZIP de entrega preservado.
