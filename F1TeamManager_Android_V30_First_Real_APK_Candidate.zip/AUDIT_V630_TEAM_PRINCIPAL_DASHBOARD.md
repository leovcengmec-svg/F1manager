# V630 (0.630.0) — Dashboard Team Principal

## Mudanças
- Corrigido o espaço do card de prestígio: o layout interno e os dados originais foram mantidos; a altura aumentou para que nome/categoria, pontos, barra de progresso, melhor resultado, equipe e classificação não sejam cortados.
- Novo card compacto no topo com retrato genérico de um chefe de equipe de automobilismo em baixa opacidade, sem marcas reais. Mostra títulos de pilotos, títulos de construtores, vitórias, poles e pódios agregados das temporadas/equipes da trajetória do Team Principal.
- A seção de conquistas no corpo principal foi reduzida a um botão. O toque abre um diálogo próprio, rolável, com as oito conquistas e suas descrições.
- Os objetivos da diretoria seguem interativos. Os estados ao vivo são calculados por tipo de objetivo: classificação, caixa, pontos, melhoria de posição, progresso de pontos, projetos de P&D concluídos, peças aguardando instalação e níveis de instalações. Verde significa atingido; vermelho significa ainda não atingido; cinza é usado somente quando a fonte do progresso não está disponível ou ainda não há resultado esportivo.
- As cores esportivas atualizam conforme a semana/rodada e os dados de carreira mudam, sem aguardar o fechamento da temporada.
- A rolagem vertical da página foi preservada.

## Dados e segurança
- As estatísticas agregadas usam o histórico oficial da carreira e restringem os resultados aos pares temporada/equipe registados na trajetória do Team Principal, acrescidos da temporada/equipe atual.
- Vitórias/pódios excluem classificações com status DNF; poles vêm do registro de poles da base histórica. Títulos de pilotos e construtores vêm do arquivo oficial de campeões.
- O retrato foi adicionado como um novo recurso em `app/src/main/res/drawable-nodpi/team_principal_manager_portrait.png`; os arquivos de `app/src/main/assets` foram deixados intocados.
- Não foram alteradas regras de simulação, finanças, carreira ou save; somente apresentação e cálculo de status para a interface.

## Validação
- `versionCode = 630`, `versionName = 0.630.0`.
- ZIP será verificado após empacotamento.
- Build Android/assembleDebug e teste visual no dispositivo ainda precisam ser executados no pipeline Android; não declarar como aprovados sem esse resultado.
