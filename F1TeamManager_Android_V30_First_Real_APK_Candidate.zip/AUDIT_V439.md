# Auditoria V439

## Correção desta etapa

A simulação financeira anterior simplificava a premiação de construtores como um valor fixo por categoria de equipe. Isso não refletia o código real, que paga valores distintos conforme a posição final de P1 a P40. O cenário foi corrigido para usar a curva oficial completa, bem como as faixas de premiação por resultado de GP e os custos operacionais por nível.

## Limites

Este teste de cenário não instancia os motores Kotlin, o mercado de pilotos ou os contratos reais de patrocínio. Salários e receitas de patrocínio permanecem hipóteses representativas. Portanto, seus saldos servem para detectar tendências e inconsistências no modelo, não para certificar o comportamento runtime do jogo.

## Validação de ambiente

A compilação Android e os testes JUnit não foram executados porque o ambiente não dispõe de Gradle/Android SDK. Não considerar as auditorias estáticas como validação de APK.
