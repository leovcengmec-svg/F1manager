# V733 — Auditoria da correção de build

## Erro reportado

O GitHub Actions falhou em `:app:compileDebugKotlin` com `Unresolved reference: NextSeasonCarProjectionEngine` em `MainActivity.kt` (linhas 467 e 1348 no log fornecido). O arquivo da classe existia em `app/src/main/java/com/f1teammanager/core/manager/NextSeasonCarProjectionEngine.kt`, com pacote `com.f1teammanager.core.manager`.

## Causa raiz

`MainActivity.kt` importa explicitamente diversos motores de `com.f1teammanager.core.manager`, mas não importava `NextSeasonCarProjectionEngine`. A referência não resolvida também impedia o compilador de inferir tipos esperados nas expressões seguintes (incluindo o `emptyMap()` da chamada de abertura e as expressões `remember` da interface).

## Correção aplicada

Incluído:

`import com.f1teammanager.core.manager.NextSeasonCarProjectionEngine`

As cinco chamadas existentes em `MainActivity.kt` passam a resolver para o objeto já existente. A implementação da classe não foi modificada.

## Escopo preservado

Nenhuma mudança em regras de jogo, snapshots GP30, construção física, regulamentos, investimentos, IA financeira, patrocínios ou evolução de pilotos.

## Validação e limitação

- Presença do arquivo e declaração do pacote conferidas.
- Import e referências conferidos estaticamente.
- O erro de inferência reportado na mesma cadeia é esperado como cascata do símbolo não resolvido e deve ser reavaliado no build.
- O erro adicional reportado em `MainActivity.kt:12757:26` foi associado à chamada `remember` que contém a mesma referência não resolvida; será confirmado pelo próximo build.
- Não foi possível executar `assembleDebug` neste ambiente porque não há Gradle/Gradle Wrapper ou Android SDK disponível.
