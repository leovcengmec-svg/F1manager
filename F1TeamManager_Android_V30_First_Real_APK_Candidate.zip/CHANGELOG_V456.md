# V456 — Retorno à Home após evento de fim de temporada

- O botão do card de fim de temporada agora retorna à interface Home.
- A tela de fim de temporada não inicia automaticamente a temporada seguinte.
- O avanço para a próxima temporada permanece no botão próprio da Home, depois dos 30 GPs.
- Sem alterações no layout além do texto do botão; assets e histórico preservados.
- Validação estática realizada; compilação Android não executada neste ambiente.
