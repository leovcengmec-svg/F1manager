# V474 — Limite de investimento e preços de P&D

- Ajustado o teto anual de investimento técnico por ranking para a faixa de €250M a €350M, mantendo cinco níveis: €250M, €275M, €300M, €325M e €350M.
- Adicionadas funções de desconto de P&D conforme a faixa de ranking técnico: 0%, 20%, 40% e 60%. Os custos-base e prazos de pesquisa foram preservados.
- A cobrança de novos projetos de P&D usa o custo ajustado e registra esse valor no projeto e no financeiro. Projetos já iniciados não são recalculados.
- Incluídos testes unitários para as faixas de desconto e os novos tetos de investimento.

Validação: testes não executados neste ambiente, pois o ZIP-fonte não contém `gradlew` e não há instalação de `gradle` disponível. A atualização programada do ranking a cada 10 GPs ainda requer integração explícita ao fluxo de avanço do calendário; esta versão calcula o ranking técnico ao iniciar a pesquisa e não deve ser considerada validada quanto ao gatilho de 10 GPs.
