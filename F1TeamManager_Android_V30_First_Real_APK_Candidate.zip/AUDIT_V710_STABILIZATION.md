# Auditoria estrutural — V710: save/backup/importação

## Identificação
- Público: F1 Team Manager V30
- VersionCode: 710
- VersionName: 0.710.0
- Base: V709
- ZIP: `F1TeamManager_Android_V30_First_Real_APK_Candidate.zip` (nome preservado)

## Causa-raiz
A validação `assertCompleteSystemSnapshot` ainda listava `marketScouting` como obrigatório depois que V708 removeu o armazenamento de relatórios pagos de Scouting. Carreiras novas, corretamente sem essa preferência, falhavam ao exportar o save completo.

## Correção
- O campo legado não integra mais a lista de requisitos do snapshot.
- A exportação remove a chave antiga em uma cópia serializada, antes da validação e dos metadados de integridade.
- O inspetor de backups continua verificando o payload original, incluindo contagem e SHA-256 originais de schemas 3/4.
- Depois da validação, o importador copia as preferências e remove somente `marketScouting` antes da gravação.
- O snapshot esperado para verificação de round-trip também é normalizado, de modo que o dado antigo não seja regravado nem considerado perda de dados.
- As demais preferências do mercado permanecem obrigatórias e são restauradas normalmente.

## Compatibilidade
- Saves novos sem `marketScouting`: exportação e importação compatíveis.
- Backups antigos com `marketScouting`: aceitos quando íntegros; relatório obsoleto descartado na importação.
- Backups antigos sem `marketScouting`: aceitos, pois o campo não é mais obrigatório.
- Dados essenciais ausentes, tipos inválidos, checksum incorreto ou histórico corrompido continuam sendo rejeitados.

## Limites de validação
Testes estáticos de contrato e verificação do pacote executáveis localmente. Gradle/Android SDK não estão instalados neste ambiente; APK e suíte JUnit integral precisam ser confirmados no GitHub Actions.
