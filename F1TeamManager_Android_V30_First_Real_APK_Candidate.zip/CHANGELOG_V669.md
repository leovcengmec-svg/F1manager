# V669 — equilíbrio da chuva nas corridas

- Reduzida a probabilidade de largada com chuva em todos os perfis de circuito. A diferença climática entre pistas áridas, secas, variáveis e chuvosas foi preservada.
- Reduzida a chance de uma nova frente de chuva surgir durante uma corrida que começou seca.
- A chuva agora tem chance significativamente maior de perder intensidade e passar para nublado a cada verificação de seis voltas.
- Uma frente contínua de chuva não pode permanecer ativa por mais de 18 voltas: ao atingir esse limite, o clima obrigatoriamente avança para nublado.
- Chuva forte pode enfraquecer para chuva média ou leve antes de terminar; chuva leve normalmente evolui para nublado.
- Mantida a escolha obrigatória de pneus da V668 quando a pista seca. As decisões SOFT/MEDIUM/HARD não foram removidas nem automatizadas.
- O fluxo de clima continua usando RNG isolado, sem alterar sorteios de desempenho, incidentes ou evolução de pilotos.
- Adicionados testes de frequência por circuito, frequência de chuva no conjunto de 50 pistas, chance de dissipação e limite de duração de uma frente chuvosa.
