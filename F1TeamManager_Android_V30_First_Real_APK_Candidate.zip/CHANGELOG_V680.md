# V680 — cards de assinatura do mercado na Home

Base: V679

- Centralizada a emissão do evento padrão após cada assinatura futura concluída pela IA: renovação, contratação ou transferência conforme equipe de origem/destino.
- Corrigidos os caminhos de contraproposta aceita pela IA, fechamento da janela e formação de elenco; nenhum desses caminhos gera card se `signFuture` falhar.
- Evitadas notificações duplicadas para o mesmo piloto, equipe de destino e temporada-alvo.
- A fila de popups da Home passa a apresentar os eventos de mercado em ordem cronológica, um por vez, respeitando a marcação de leitura.
- Removido o limite arbitrário de dez cards no resumo de contratos assinados do mercado.
- Negociações pendentes, propostas recusadas e contrapropostas ainda não assinadas continuam fora dos cards da Home.

VersionCode: 680
VersionName: 0.680.0
ZIP: F1TeamManager_Android_V30_First_Real_APK_Candidate.zip (nome preservado)
