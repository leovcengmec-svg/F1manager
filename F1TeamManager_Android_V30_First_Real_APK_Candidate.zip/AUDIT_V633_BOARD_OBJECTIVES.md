# V633 — Correção dos objetivos da diretoria

## Causas corrigidas
- Os objetivos eram gerados no fim da temporada antes do ranking efetivo do carro da temporada seguinte.
- A recalibração agora acontece somente depois de montar o ranking de força de abertura com o carro construído e o regulamento aplicado.
- A recalibração é idempotente e persiste `objectivesPreparedForSeason` no estado da carreira (schema 4); saves antigos continuam decodificáveis.
- O objetivo principal combina 80% da força real de abertura do carro com 20% do resultado esportivo anterior e exige uma melhora adicional. A expectativa aumenta conforme o nível médio das instalações.
- A pontuação-alvo combina a faixa da força do carro, os pontos da temporada anterior e o nível médio das instalações.
- Os objetivos de instalação usam os níveis reais da equipe e ao menos um objetivo de instalação aparece quando há instalações elegíveis; para organizações com média de nível 7+, são escolhidos até dois objetivos de instalação.
- Renovação e mudança de equipe passam os níveis das instalações, a posição, os pontos e o caixa conhecidos para a geração provisória; o ranking do carro novo ainda refina o objetivo no início da temporada.
- O objetivo de reserva financeira é avaliado contra `loadFinance(...).budget` da equipe controlada, não `aiTeamBudget()`, que é o saldo da IA.
- Foram mantidos os IDs por temporada, a avaliação de objetivos ao encerrar a temporada e os resultados históricos; apenas os objetivos da temporada seguinte são calibrados na abertura.

## Fórmulas de balanceamento
- Ranking projetado: 80% ranking real de força de abertura + 20% posição final anterior.
- Meta principal: projeção menos 3 posições, mais um incremento de exigência por média de instalação elevada; mínimo 1º lugar.
- Meta de construtores: pisos maiores por faixa de força (260 / 220 / 160 / 85 / 40 / 15) e ajuste pelos pontos anteriores e níveis de instalação.
- Meta financeira: referência por faixa de força, ajustada para cima para equipes com caixa alto e instalações avançadas.
- Evolução no grid: pelo menos 1 posição e até 3 para equipes com instalações avançadas; para carros de força no fundo do grid, preserva um desafio de pelo menos 2 posições.

## Validação
- O motor de objetivos e os testes direcionados foram compilados com `kotlinc` num harness local; 17 testes passaram (13 regras de carreira existentes + 4 de calibração V633). O harness usou stubs mínimos para os tipos auxiliares de garagem/instalações que não fazem parte da lógica de objetivos; não substitui o build do app.
- Os quatro novos testes cobrem metas por força/instalações/pontos/caixa, idempotência por temporada e migração de saves schemas 1–3.
- Assets comparados por SHA-256 com V632: `app/src/main/assets` 195/195 idênticos; `app/src/main/res` 85/85 idênticos.
- O ZIP de entrega passa em `unzip -t`; Gradle da raiz e metadados 633 verificados.
- `assembleDebug` Android ainda precisa ser executado no pipeline; este ambiente não tem Gradle/Android SDK.
