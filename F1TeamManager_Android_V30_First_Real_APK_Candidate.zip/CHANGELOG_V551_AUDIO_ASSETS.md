# V551 — Slots de áudio externo

- Expandido `app/src/main/assets/audio/catalog.json` para 13 slots, incluindo box, aviso dos pilotos, bandeira vermelha, Safety Car e vitória de Max Verstappen.
- Adicionados dois slots de interface (`interface_2`, `interface_3`), formando uma sequência de três faixas que toca em ordem e repete a lista.
- Roteamento da tela de resultado prioriza a faixa de vitória de Max Verstappen quando o nome do vencedor corresponde; mantém a faixa de vitória brasileira e o resultado genérico como fallback.
- `ExternalAudio` ganhou reprodução de sequência e reprodução one-shot de evento (`playEvent`) para permitir chamadas pelos eventos da corrida.
- Áudios reais continuam externos, conforme a arquitetura existente. Arquivos ausentes são ignorados; não foram adicionados arquivos de áudio falsos ou silenciosos.
