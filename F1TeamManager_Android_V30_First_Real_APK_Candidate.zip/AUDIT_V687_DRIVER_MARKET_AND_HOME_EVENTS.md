# Auditoria V687 — mercado de pilotos e cards da Home

## Escopo
- Eventos detalhados de negociação: exclusivos da equipe do jogador.
- Desfechos de contrato: notícias globais para todas as equipes.
- Mercado de IA: manter mobilidade entre equipes também após a primeira temporada.

## Alterações verificadas no código
- `DriverMarketHomeNotificationPolicy` separa assinaturas concluídas de etapas de negociação.
- A Home e o contador de eventos usam a mesma política de filtragem.
- `recordCompletedSignature` gera eventos canônicos para renovação, transferência e contratação.
- A virada de temporada usa o mesmo evento canônico e evita duplicação.
- Rejeições/expirações de propostas dirigidas ao jogador incluem a equipe do jogador no texto.
- A IA prioriza busca por transferências antes da avaliação final de renovações.
- Renovações são avaliadas uma vez na fase final e aguardam propostas rivais pendentes.
- Abordagens durante contrato vigente são seletivas e exigem vantagem esportiva; a equipe do jogador permanece excluída desse mecanismo automático.
- Teste multi-temporada cobre 3 seeds e ciclos de 2026 a 2030, verificando transferências recorrentes e elencos completos.

## Simulação de mercado
Executado `market-sim-v687.jar` com cinco seeds e temporadas 2026–2030.
Em todas as temporadas simuladas houve transferências entre equipes, inclusive após a temporada inaugural.

## Limitações
- A simulação isolada do motor de mercado foi executada.
- Não foi possível executar o Gradle/JUnit completo nem gerar APK neste ambiente, pois o projeto não inclui Gradle Wrapper e o executável Gradle não está instalado.
- A compilação final deve ser confirmada pelo GitHub Actions.
