# Auditoria V690 — orçamento dinâmico de investimento da IA

## Alterações

1. 40/40/20 passa a representar prioridades de planejamento, não três limites cumulativos independentes.
2. O envelope anual técnico continua único e limitado a €200.000.000, contabilizando desenvolvimento/fabricação, instalações e carro da próxima temporada.
3. A prioridade inicial do próximo carro é fixa em €80M do envelope original e não sofre decaimento geométrico quando P&D/instalações utilizam parte do saldo. A prioridade é liberada depois de financiada; na janela do GP25, saldo não comprometido pode ser redirecionado ao próximo carro.
4. P&D do carro atual e instalações compartilham a capacidade restante após a prioridade dinâmica do próximo carro. Nenhum dos dois possui teto próprio dentro desse conjunto; uma categoria pode usar a capacidade que a outra não consumir.
5. O próximo carro mantém teto absoluto de €150.000.000 por projeto.
6. A escolha de instalações não compara mais o custo do upgrade com a reserva anual de 20%. O investimento pode exceder €40M se houver caixa, previsão e saldo na parcela compartilhada de P&D/instalações.
7. Quando o alvo calculado do próximo carro é atingido, a reserva de 40% é liberada para P&D/instalações; se a evolução posterior do carro elevar o alvo, a prioridade é reativada no próximo GP.
8. O estado de alvo satisfeito é persistido em campo opcional no registro `I`, preservando compatibilidade com saves antigos.
9. O saldo legado da reserva de instalações é mantido para compatibilidade, limitado ao custo máximo de upgrade atual (€120M), mas não funciona como condição para autorizar investimentos.
10. Reservas de caixa, salários, custos de corrida, manutenção e previsão financeira continuam aplicáveis.

## Testes adicionados/atualizados

- Próximo carro: depois de €80M consumidos por P&D/instalações, e com €120M restantes no envelope, a prioridade inicial do próximo carro continua protegendo €80M; depois de o próprio próximo carro receber €80M, a reserva inicial é liberada.
- Próximo carro não pode investir além do teto absoluto ou do saldo global restante.
- Instalações podem executar um upgrade de €66M mesmo que a referência anual de 20% seja €40M, desde que caixa e o pool compartilhado de P&D/instalações comportem o custo.
- P&D e instalações somados respeitam a capacidade restante após a prioridade inicial fixa do próximo carro; isso preserva a prioridade sem criar travas individuais por categoria.
- Soma de categorias continua limitada a €200M por temporada.

## Verificações executadas

- Compilação isolada da política `SeasonInvestmentPolicy.kt` com stub mínimo de `TechnicalInvestmentState`: aprovada.
- Smoke test das regras de prioridade dinâmica, teto absoluto, flexibilidade das instalações e envelope global: aprovado (`POLICY_SMOKE_OK`).
- Conferência estática dos três caminhos de débito: P&D, instalações e carro seguinte consultam o saldo anual consolidado.
- P&D e instalações agora compartilham explicitamente o saldo técnico que sobra depois da reserva dinâmica do próximo carro.
- A reserva de próximo carro é liberada quando o alvo de construção é alcançado e o estado é gravado/restaurado pelo snapshot financeiro.
- APK/Gradle e suíte JUnit completa: pendentes de validação no GitHub Actions; este ambiente não possui Gradle nem Gradle Wrapper.
