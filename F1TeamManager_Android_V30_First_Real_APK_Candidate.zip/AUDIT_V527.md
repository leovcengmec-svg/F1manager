# Auditoria V527

- Base: ZIP oficial recebido na conversa (versao 0.526.0).
- Corrigida a apresentacao do controle: lancamentos financeiros sem semana e sem GP explicito passam a aparecer numa secao propria, em vez de ficarem invisiveis na visao semanal.
- Sem atribuicao artificial de semana.
- Versao: 0.527.0 (versionCode 527).
- Validacao estrutural do ZIP: executada.
- Compilacao Gradle e testes Android: nao executados neste ambiente.
- Pendente para contabilizacao semanal integral: instrumentar cada fluxo financeiro para registrar temporada/semana junto da operacao, sem reconstruir dados antigos por suposicao.
