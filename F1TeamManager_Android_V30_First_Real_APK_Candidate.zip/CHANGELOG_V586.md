# V586 — Modo Team Principal (primeira implementação)

- Adicionado terceiro modo de carreira: Team Principal.
- Início com prestígio baixo e escolha entre as três equipes de menor força inicial.
- Metas de campeonato, reputação anual e avaliação após duas temporadas de contrato.
- Tela de avaliação com renovação, propostas externas e cenário de demissão.
- Elegibilidade das propostas baseada em prestígio e ranking atual do campeonato.
- Histórico de carreira identifica a equipe empregadora por temporada.
- Transição de equipe grava o estado físico do carro/equipe que passa a ser controlada pela IA.
- Mantidos os modos Livre e Difícil existentes.
- Testes isolados do motor cobrem as principais regras; build Android e simulação ponta a ponta continuam pendentes.

Consulte `AUDIT_V586_TEAM_PRINCIPAL.md` para escopo, regras e limitações da validação.
