# Auditoria V325

## Alterações
- Controle PAUSAR/INICIAR movido para a linha de velocidade, no espaço anterior do rótulo.
- Dimensões do controle: 58 dp de largura × 21 dp de altura, com texto de linha única.
- Cabeçalho EQUIPE ampliado para 37 dp, com 6 sp e softWrap=false.

## Preservação
- A lógica do estado `running` e do início da corrida não foi substituída; o botão permanece desabilitado enquanto `raceStarted` for falso.
- Os quatro níveis de velocidade e os demais elementos da tela foram preservados.
- Os assets existentes e o histórico de versões foram mantidos.

## Limites da verificação
- ZIP testado quanto à integridade.
- Não foi executada compilação Gradle/Android nem teste visual em dispositivo nesta sessão.
