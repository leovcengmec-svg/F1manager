# Auditoria V675 — Demissão Team Principal

- Corrigido o empilhamento de penalidades que permitia demissão apesar de meta principal atingida e boa taxa de conclusão.
- A proteção é aplicada no cálculo oficial usado por `recordSeason`, após avaliação dos objetivos da temporada.
- A regra mantém risco residual de até 5% em temporadas fortes e risco de até 12% quando a meta principal e ao menos 40% das demais metas são cumpridas.
- Se a meta principal não for atingida, mas 80% das metas forem cumpridas, o risco fica limitado a 25%.
- Temporadas globalmente ruins ainda podem resultar em demissão.
- Testes de regressão adicionados em `TeamPrincipalContractCycleV639Test`.
- Versão: 675 / 0.675.0; base: V674.
