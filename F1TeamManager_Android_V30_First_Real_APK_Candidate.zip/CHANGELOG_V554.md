# V554 — Cadastros extensíveis iniciais

- Criado armazenamento persistente local para cadastros adicionados de pilotos e equipes.
- Configurações agora permite cadastrar piloto livre e equipe com dois pilotos, país e nome de asset do escudo.
- IDs novos são append-only e não substituem os IDs históricos: equipes novas começam após o maior ID existente; pilotos novos usam IDs posteriores ao mercado/reservas.
- WorldDatabase passa a incluir registros personalizados nos getters de equipes, pilotos titulares e mercado de pilotos.
- Cadastros são guardados em SharedPreferences locais do aplicativo.

## Limitações conhecidas
- Esta etapa cobre inclusão de novos registros; edição/exclusão de registros existentes e importação/exportação de catálogo ainda não estão implementadas.
- A integração em sistemas com pressupostos fixos de 40 equipes/80 titulares ainda precisa de auditoria completa. Não considerar garantida a participação de grids acima do tamanho suportado por todos os fluxos.
- Não foi possível executar compilação Android nem testes automatizados neste ambiente. O ZIP foi verificado estruturalmente após empacotamento.
