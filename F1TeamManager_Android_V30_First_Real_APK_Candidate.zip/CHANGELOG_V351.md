# V351 — Validação prévia do resultado oficial

- Adicionado `RaceResultValidator`, uma validação pura e reutilizável antes de qualquer efeito persistente no fechamento da corrida.
- O fechamento agora rejeita resultados vazios, IDs de piloto duplicados/inválidos, voltas fora da distância programada, ausência de um piloto que completou a distância, pontuação associada a piloto ausente, volta mais rápida associada a piloto ausente e pontuação negativa.
- Incluídos testes unitários de regressão para resultado válido e cenários inválidos.
- Nenhuma alteração de layout, botão ou navegação.
