# V491 — Origem e destino no evento de contrato assinado

- Eventos de contrato assinado e contrato fechado agora exibem a equipe atual do piloto e a equipe de destino no formato “Equipe atual → Equipe de destino”.
- A equipe atual é obtida do contrato vigente antes de registrar a transferência futura; se o piloto não tiver contrato atual, o evento informa “sem equipe atual”.
- Mantém a temporada de destino e não altera a lógica de negociação ou transferência.
- Verificação: alterações de código conferidas e ZIP testado quanto à integridade; compilação Android completa não executada neste ambiente.
