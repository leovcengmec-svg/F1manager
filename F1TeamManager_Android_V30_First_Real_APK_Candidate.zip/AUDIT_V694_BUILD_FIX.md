# Auditoria v694 — correção de compilação Kotlin

## Erro reportado no GitHub Actions

O build Debug da v693 falhou em `AITeamFinancialEngine.kt`:

- Linha 253: `selectedFacilityMindset.copy(...)` — referência `copy` não encontrada.
- Linha 666: `selectedMindset.copy(...)` — referência `copy` não encontrada.

## Causa

`SeasonInvestmentPolicy.selectAiMindset()` retorna `AIInvestmentMindset`, declarado como `enum class`. Enums Kotlin não oferecem a operação `.copy()`, que pertence a data classes.

## Correção

- Adicionada `SeasonInvestmentPolicy.effectiveNextCarPriorityPercent(mindset, nextCarAlreadyInvested)`.
- Quando o ledger independente do próximo carro alcança €150 milhões (ou o método de prioridade já sinaliza meta cumprida pelo valor sentinela), a prioridade de caixa para o próximo carro passa a 0%.
- A pontuação de instalações continua usando diretamente o mindset selecionado e sua proporção de instalações.
- O cálculo de capacidade de desenvolvimento usa o percentual efetivo, sem tentar copiar o enum.
- Adicionado teste de regressão para percentuais antes e depois do teto anual de €150 milhões.

## Preservado

- Envelope independente de €200 milhões para carro atual/P&D/fabricação e instalações.
- Envelope independente de €150 milhões para o carro seguinte.
- Quatro mentalidades estratégicas e seus percentuais.
- Reserva operacional e validação de caixa.
- Comportamento de metas e liberação de prioridade existente.

## Versionamento

- VersionCode: 694
- VersionName: 0.694.0
- Nome físico do ZIP preservado: `F1TeamManager_Android_V30_First_Real_APK_Candidate.zip`

## Validação

- Verificação estática: as duas chamadas inválidas `.copy()` foram removidas.
- Verificação estática: os dois caminhos usam a função de prioridade efetiva.
- Verificação estática: teste de regressão incluído.
- ZIP: teste de integridade CRC.
- Limitação: este pacote não contém Gradle Wrapper e o ambiente não possui Gradle instalado; APK Debug e suíte JUnit precisam ser confirmados pelo GitHub Actions.
