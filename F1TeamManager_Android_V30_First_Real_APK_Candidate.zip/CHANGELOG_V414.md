# V414 — Posições antes e depois dos eventos

- Eventos de corrida passam a carregar a posição do piloto antes do processamento da volta e a posição após a classificação daquela volta.
- O diálogo universal apresenta a variação no formato `P8 → P11`, mantendo a perda de tempo separada.
- Eventos sem posição registrada continuam usando a posição disponível como fallback.
- Sem alterações de layout ou na lógica de simulação.
