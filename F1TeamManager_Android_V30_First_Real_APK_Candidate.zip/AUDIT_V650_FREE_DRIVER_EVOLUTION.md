# Auditoria V650 — Pilotos livres

## Alteração aplicada
A V649 excluía os IDs sem contrato antes de chamar o motor de evolução. A V650 corrige os dois pontos de entrada: `CareerPreferences.applyDriverRaceEvolution()` e `ManagerSeasonEngine.applyDriverEvolution()`.

Os agentes livres agora usam `DriverEvolutionEngine.applyFreeDriverTick()`: o tick usa uma referência neutra (sem avaliação de corrida) e aplica `FREE_DRIVER_GROWTH_RATE = 0.90`. Isso equivale exatamente a 90% do banco de crescimento natural no tick de referência. A evolução continua sob o potencial, o fator flexível da classe e o limite anual por atributo.

Nenhuma amostra de desempenho de temporada é adicionada para pilotos livres. Portanto, o desenvolvimento durante a condição de agente livre não pode, por si só, gerar promoção ou rebaixamento após duas temporadas.

## Testes executados
- `FreeDriverEvolutionTest`: PASS — 100 pilotos / 80 contratados / 20 livres; comparação determinística confirmou banco de evolução livre exatamente igual a 90% do banco natural de referência.
- `FreeDriverEvolutionV650Test`: PASS — simulação de 30 GPs; os 20 pilotos livres receberam evolução, um tick por GP, e nenhum deles gerou amostra de desempenho para revisão de classe.
- `DriverClassProgressionV649Test`: PASS — regras de duas temporadas mantidas.
- `DriverEvolutionPerformanceV604Test`: PASS — evolução baseada em desempenho, potencial e tetos anuais preservados.
- `DriverEvolutionSafetyV603Test`: PASS — faixas, potencial e piso global preservados.
- Núcleo alterado (`DriverEvolutionEngine.kt` e `ManagerSeasonEngine.kt`) compilado com `kotlinc`: PASS, com avisos preexistentes não impeditivos.

## Limitações da validação
- A tentativa de compilar todo o conjunto de fontes puras excedeu o limite de execução; por isso, os dois arquivos alterados do núcleo foram compilados isoladamente contra o núcleo V649 previamente compilado.
- A simulação ampla `FullSeasonIntegrationTest` excedeu o limite de execução nesta sessão. O teste direcionado de 30 GPs dos pilotos livres concluiu com sucesso.
- `CareerPreferences.kt` pertence à camada Android e não pôde ser compilado isoladamente sem Gradle/Android SDK neste ambiente. A chamada foi revisada estaticamente; a validação de compilação Android ainda deve ocorrer no GitHub Actions.
- APK e teste em aparelho Android não foram executados nesta sessão.
