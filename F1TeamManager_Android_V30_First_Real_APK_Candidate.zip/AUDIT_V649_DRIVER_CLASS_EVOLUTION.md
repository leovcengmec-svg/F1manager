# Auditoria V649 — Classe, Overall, potencial e evolução dos pilotos

## Resultado

A V649 substitui as regras conflitantes encontradas na V648 por um fluxo centralizado de progressão e revisão de classe. Os testes de motor e a simulação determinística de dez temporadas passaram. A auditoria estrutural do projeto também passou após inclusão destas notas de versão.

## Correções verificadas

1. `DriverProfileCatalog` normaliza o Overall inicial de cada perfil para a faixa da classe e limita o potencial inicial a até duas classes acima.
2. A distribuição dos sete atributos preserva, tanto quanto possível, as características individuais; não utiliza um Overall fictício separado dos atributos.
3. `DriverEvolutionEngine` remove as fases temporizadas 5/2/5 e utiliza índice de desempenho por GP, banco fracionário, teto flexível de classe, potencial individual e limites anuais por atributo.
4. A regressão não é acionada por tempo de carreira. Só resultados ruins acumulados reduzem atributos; a faixa global de segurança permanece 40–100.
5. `DriverDevelopmentEngine` usa o mesmo limite anual e reavalia a dificuldade flexível da classe a cada ponto aplicado.
6. `CareerPreferences` registra desempenho por piloto/temporada, exige registros de pista reais e avalia a classe somente em `startNextSeason`.
7. `ManagerSeasonEngine` usa o motor comum e aplica a mesma decisão de classe na virada da temporada no fluxo alternativo de simulação.
8. Eventos anuais aleatórios de ganho, perda e mudança de classe deixaram de ser agendados. Slots de calendários antigos são encerrados como no-op.
9. Saves V648 e anteriores recebem migração única dos atributos e overrides; histórico de corridas não é apagado.

## Critérios de classe

- Faixas: Fraco 40–59; Médio 60–69; Forte 70–79; Pro 80–89; Lenda 90–100.
- Evidência mínima: ceil(80% dos GPs previstos em cada uma das duas temporadas consecutivas).
- Promoção: média de cada temporada >=100, média conjunta >=105 e Overall >= início da próxima classe +1.
- Rebaixamento: média de cada temporada <=80, média conjunta <=80 e Overall <= início da classe atual −2.
- Uma mudança de classe por avaliação.

## Testes executados

- `DriverEvolutionSafetyV649Test`: PASS.
- `DriverEvolutionPerformanceV649Test`: PASS, incluindo evolução acima da faixa, potencial individual, regressão e Centro de Desenvolvimento.
- `DriverClassProgressionV649Test`: PASS, incluindo duas temporadas, evidência insuficiente, lacuna de temporada, promoção e rebaixamento.
- `Stage1Initial75PercentTest`: PASS para 100 perfis e elenco real (`WorldDatabase`), confirmando Overall e potencial iniciais compatíveis.
- Simulação determinística de dez temporadas com 100 pilotos: PASS; nenhum atributo fora de 40–100, nenhum Overall acima do potencial, distribuição final entre as cinco classes (25 Lenda, 37 Pro, 19 Forte, 18 Médio e 1 Fraco no cenário de desempenho sintético utilizado).
- `tools/race_sim_test/validate_project.py`: 45/45 verificações estruturais (incluindo changelog V649).

## Limitações da validação

Não foi possível compilar o APK nesta sessão: o pacote não contém Gradle Wrapper e o ambiente não tem Gradle instalado nem Android SDK. Os testes Kotlin puros dos motores citados foram compilados e executados com `kotlinc`; isso não substitui um build Android completo nem teste em aparelho.

A simulação de dez temporadas é um teste determinístico de coerência do motor, não uma calibração final de equilíbrio com milhares de seeds ou uma carreira real. Os limiares de promoção/rebaixamento devem ser observados em temporadas reais e refinados se necessário.

## Auditoria complementar do pacote V649

- `tools/race_sim_test/v649_driver_class_evolution_audit.py`: 28/28 verificações específicas da reestruturação (incluindo migração em importação de backup e avaliação de classe por duas temporadas).
- `tools/race_sim_test/validate_project.py`: 45/45 verificações estruturais.
- `tools/race_sim_test/final_release_audit.py`: 25/25 verificações estruturais de release.
- Compilação Kotlin dos 68 arquivos puros do núcleo concluída anteriormente com `kotlinc`; os testes direcionados V649 foram recompilados nesta revisão.
- Execução dos testes direcionados: evolução/segurança PASS; motor de evolução e Centro de Desenvolvimento PASS; promoção/rebaixamento PASS; simulação de dez temporadas PASS; catálogo e elenco inicial (100 pilotos) PASS.

A ausência de Gradle, Gradle Wrapper e Android SDK neste ambiente impede a compilação do APK. A validação acima cobre código Kotlin puro, regras de domínio e estrutura do pacote, mas não substitui build Android oficial ou teste em dispositivo.
