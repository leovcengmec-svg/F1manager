# V362 — Bloco integrado da simulação instantânea

## Escopo implementado
- Criado `InstantSimulationService` como contrato único entre o motor de fim de semana e a camada da carreira.
- O caminho de simulação instantânea da carreira agora usa esse serviço antes de aplicar bônus de qualificação e efeitos de fechamento.
- A validação exige grid de 80 pilotos únicos, posições contínuas, Q1/Q2/Q3 com 80/50/20 pilotos, progressão coerente entre fases, classificação final de 80 pilotos, posições sem lacunas/duplicações e distância de corrida válida.
- `RaceResultValidator` agora rejeita posições duplicadas.
- Adicionados testes integrados do contrato da simulação instantânea.
- Versão Android: `0.362.0`.

## Limites de validação
- O build Android, JUnit e simulação de 30 GPs por temporada não foram executados neste ambiente porque o pacote não inclui Gradle Wrapper e não há Gradle instalado no PATH.
- O método de simulação instantânea permanece sem botão/alteração de layout, conforme a ordem definida pelo usuário.
