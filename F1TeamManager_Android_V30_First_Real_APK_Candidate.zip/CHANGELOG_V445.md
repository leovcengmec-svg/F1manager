# V445 — Validação de regulamento anual e decenal

- Acrescentado `tools/audit_v445_regulation.py` para auditoria estrutural do catálogo, calendário anual/decenal, persistência, semente compartilhada entre jogador/IA e ordem da virada de temporada.
- Auditoria matemática cobrindo 60 temporadas e 40 perfis de equipe por temporada, com verificações de limites e componentes afetados.
- Mantida a ordem de virada: fechar temporada anterior → construir/evoluir carro novo → aplicar regra ao carro novo/garagem → recalcular investimento técnico e metas → persistir garagem.
- Incrementada a versão do app para 445 (0.445.0).
- Sem alterações de layout, assets, histórico anterior ou sistemas alheios ao regulamento.

Validação: `python3 tools/audit_v445_regulation.py` passou em 4.770 asserções de auditoria estrutural/matemática. Esta auditoria não equivale a executar JUnit ou compilar o APK.

## Complemento V445 — Imagens dos cards de regulamento
- Criado `AnnualCarRegulationEventArt` para associar os 18 eventos anuais às ilustrações genéricas já existentes no projeto (uma ilustração por componente, reutilizada nos três eventos daquele componente).
- Criado `AnnualCarRegulationEventCard` usando a mesma estrutura visual de `AnnualTeamEventCard`: imagem de 164 dp, título, descrição do componente, percentual e temporada/ID.
- Não foram geradas nem adicionadas novas imagens; foram reutilizados os assets já presentes.
- Adicionado teste JUnit para verificar cobertura dos 18 IDs e reutilização consistente por componente.
- Versão mantida em 445 (0.445.0), conforme solicitado.

Validação desta alteração: inspeção estática dos seis recursos referenciados e integridade do ZIP. JUnit/build Android não executados neste ambiente.


## Complemento V445 — prioridade dos cards na primeira semana
- Adicionada uma apresentação de mudança de regulamento antes do card de início de temporada, quando houver regra anual e/ou revolução decenal naquela temporada.
- A apresentação do regulamento é marcada como vista por temporada e persiste a confirmação, evitando reaparecer ao reabrir o jogo.
- A temporada 1 permanece sem card de regulamento, conforme a regra do calendário.
- O botão de continuidade leva ao card de início de temporada; depois dele, o fluxo segue para a Home.
- Versão mantida em 445 (0.445.0); nenhuma imagem nova foi criada.
- Validação estática do fluxo e do código realizada; compilação Android/JUnit continuam pendentes por falta de Gradle e Android SDK neste ambiente.
