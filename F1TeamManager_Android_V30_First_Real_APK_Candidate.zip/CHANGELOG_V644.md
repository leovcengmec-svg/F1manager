# V644 (0.644.0) — Correções de compilação Kotlin

- Corrigida a referência a `projectedOverall` no texto de previsão de construção do carro, usando explicitamente o valor calculado em `forecast.projectedOverall`.
- Tornada explícita a variável local usada pelo cálculo dos objetivos do Team Principal (`objectiveCurrentTeamRank`) para evitar referência não resolvida no bloco de `remember` e nos textos de posição.
- Mantida a lógica funcional da V643 para contagem de GPs concluídos e DNFs; esta versão corrige os erros de compilação reportados pelo pipeline.
- A compilação Android completa ainda precisa ser confirmada no pipeline com Gradle/Android SDK.
