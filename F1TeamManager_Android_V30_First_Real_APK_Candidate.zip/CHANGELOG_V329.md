# V329 — Modal compacto de decisão do manager

- Mapeado o modal de decisão em `app/src/main/java/com/f1teammanager/MainActivity.kt`, dentro de `Race()`, na renderização de `s.decision`.
- Removida a rolagem vertical do conteúdo do modal.
- Limitada a altura do modal a 690 dp e reduzidos margens, espaçamentos, cabeçalho e tipografia.
- Padronizado o card de piloto e os dois cards informativos com alturas controladas.
- Os cards de pneu atual e voltas restantes agora ocupam a mesma altura e largura.
- Padronizadas as opções de decisão em cards de 64 dp, com ícone, título e descrição compactos.
- Preservados os dados dinâmicos: posição, piloto, equipe, composto, desgaste, vida estimada do pneu, voltas restantes, condição da pista e opções de decisão.
- Preservado o fluxo funcional de BOX: resolve a decisão pendente e abre a seleção de pneus.
- Incrementados `versionCode` e `versionName` para 329 / 0.329.0.

## Validação

O ZIP foi validado estruturalmente. Não foi possível executar a compilação Android nem o teste visual em dispositivo nesta sessão; portanto, a ausência de rolagem e o encaixe final ainda precisam de confirmação no POCO X7 Pro.
