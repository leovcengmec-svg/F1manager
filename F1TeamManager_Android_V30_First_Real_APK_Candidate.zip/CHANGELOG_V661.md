# CHANGELOG V661 — Integração e integridade das propostas do Team Principal

## Mercado de pilotos
- O tick semanal real da `MainActivity` agora calcula e envia a projeção física do carro da próxima temporada para o mercado de pilotos, usando investimento, foco, desenvolvimento, continuidade da IA e regulamento anual.
- Propostas de equipes da IA por pilotos do jogador agora têm prazo funcional: ao vencer, expiram sem decisão automática do piloto e geram notificação própria.
- A aceitação de uma proposta recebida não cobra taxa do Team Principal vendedor. A equipe de destino é debitada pela taxa de transferência (40% do valor de mercado) e o time do jogador recebe o mesmo valor como compensação.
- A aceitação verifica se a equipe interessada possui caixa para a primeira parcela antes de confirmar a transferência.
- A tela de negociações em análise agora lista apenas ofertas de IA relativas a pilotos do elenco do jogador.
- A IA não cria ofertas simultâneas duplicadas da mesma equipe pelo mesmo piloto e temporada; a criação manual também bloqueia duplicatas ativas.
- Uma proposta recebida não pode ser aceita após o prazo.

## Testes
- Adicionados testes para expiração sem decisão automática e preservação da oferta antes do prazo.

## Versionamento
- `versionCode = 661`
- `versionName = "0.661.0"`
- Nome público preservado: **F1 Team Manager V30**.
- Nome padrão do ZIP preservado: `F1TeamManager_Android_V30_First_Real_APK_Candidate.zip`.

## Limitação conhecida
- A contraproposta de transferência entre equipes (valor de compensação negociado diretamente entre os dois times) não foi adicionada nesta revisão. O modelo atual persiste salário, duração e papel do piloto, mas ainda não possui um campo próprio de indenização/transfer fee negociável. Reaproveitar o salário do piloto para representar indenização criaria inconsistência contratual.
