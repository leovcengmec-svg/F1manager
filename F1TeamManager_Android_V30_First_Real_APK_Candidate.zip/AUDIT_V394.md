# Auditoria V394

- Alteração pontual em `MainActivity.kt`: imagem principal do diálogo de fabricação agora usa o asset existente `facility_factory.webp`.
- Asset genérico já presente no projeto; nenhum asset externo removido.
- Versão Android atualizada para `versionCode 394` / `versionName 0.394.0`.
- Integridade do ZIP verificada após empacotamento.
- Compilação Android não executada neste ambiente.
