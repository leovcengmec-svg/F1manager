# V672 — Restrições de evolução de classe dos pilotos

- A classe Normal (representada no código oficial como `Médio`) passa a ser a classe mínima. Pilotos `Médio` não podem ser rebaixados para `Fraco`.
- `Fraco` e `Normal` são tratados como rótulos legados/alternativos de `Médio`; a escada oficial de classe passa a ser Médio → Forte → Pro → Lenda.
- Um piloto `Pro` só pode subir para `Lenda` se tiver sido campeão mundial de pilotos na temporada recém-concluída. A exigência esportiva anterior de duas temporadas completas, média mínima e Overall continua obrigatória.
- A verificação de campeão é aplicada tanto na carreira principal quanto no motor de temporada do modo Team Manager.
- O helper legado de eventos anuais também respeita o piso `Médio` e bloqueia `Pro` → `Lenda` sem título.
- A promoção entre as demais classes e os critérios de rebaixamento acima da classe mínima permanecem iguais.
- Preservados os componentes financeiros, comerciais, climáticos, de pneus, de UI e demais correções da V671.
- Versão Android: `versionCode = 672`, `versionName = "0.672.0"`.
