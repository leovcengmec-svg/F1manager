# Auditoria V609 — Desempenho da qualificação manual e simulação instantânea

## Evidência do vídeo do usuário
A tela de qualificação manual mantém o cronômetro avançando e a lista de 80 pilotos atualizando enquanto a pessoa rola. O resultado é exibido posteriormente, mas o Android ainda mostra aviso de aplicativo sem resposta em gravações anteriores. O tempo da simulação instantânea continua na faixa de 16 segundos segundo o usuário.

## Causa confirmada no código
`simulateQualifying(sliceMs)` chamava `engine.advanceQualifyingTimeSlice(sliceMs)` diretamente no callback da interface. Essa operação avança a simulação da qualificação e monta o estado de classificação dos pilotos; portanto, ela era executada na thread principal a cada tick visual. Isso explica a rolagem pesada durante a qualificação manual.

## Alterações V609
- O avanço da qualificação manual ocorre em `Dispatchers.Default`; o snapshot é atribuído ao estado Compose após retornar à Main.
- A callback da tela `Qualifying` agora é suspensa e permanece chamada pelo `LaunchedEffect`.
- A liquidação pós-corrida, que executa journal e commits de persistência, usa `Dispatchers.IO` em vez de ocupar o pool de CPU.
- A liquidação da corrida manual também usa IO; a simulação por volta continua em Default.
- Métricas `F1TM_PERF` registram duração por slice de qualificação, volta manual e liquidação instantânea/manual.
- `CareerWeekendEngine.kt` e `InstantSimulationService.kt` não foram modificados.

## Limitações e próximos dados
Esta mudança corrige um bloqueio claro na qualificação manual, mas não prova que a simulação instantânea retornará a menos de 5 segundos. Os logs V608 não foram fornecidos, então a contribuição exata da preparação, motor e liquidação para os 16 segundos ainda precisa ser medida. Após instalar a V609, filtrar Logcat por `F1TM_PERF` e comparar `instantPreparation`, `instantEngine` e `instantSettlement` permite localizar o restante do gargalo.

## Build
Build Android, JUnit e benchmark em dispositivo não executados neste ambiente.
