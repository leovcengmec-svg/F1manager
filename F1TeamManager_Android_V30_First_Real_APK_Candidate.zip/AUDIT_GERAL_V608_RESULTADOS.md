# F1 Team Manager V608 — auditoria geral e correções verificadas

## Identificação e proteção
- Base: `F1TeamManager_Android_V30_First_Real_APK_Candidate.zip` (V608 / 0.608.0).
- SHA-256 da cópia original preservada: `46497e0fbad7c7020ff060c88bd0ff765776c969e17e8fa42627b4c507092161`.
- O ZIP original foi mantido sem sobrescrita. O pacote de entrega contém as correções abaixo e o mesmo nome oficial.
- Cabeçalho do README sincronizado com V608; entradas históricas antigas foram preservadas.

## Defeitos concretos encontrados e corrigidos
1. **Mercado/grid — piloto deixava de ser contabilizado após abertura do mercado.** A validação do grid contava contratos e agentes livres, mas ignorava pilotos com transferência futura assinada. A validação agora inclui o ledger de transferências futuras e informa os IDs ausentes se a cobertura estiver incompleta.
2. **Mercado — pilotos explicitamente liberados continuavam presos ao roster antigo.** `freeAgents()` excluía qualquer piloto citado no roster editável, mesmo quando uma transferência assinada o havia liberado para preencher a vaga deixada na equipe de origem. Agora distingue pilotos recém-descobertos vinculados a uma equipe de pilotos explicitamente liberados pelo mercado.
3. **Migração de catálogo — pilotos adicionais em equipes com dois titulares podiam desaparecer do rastreamento.** A reconciliação agora mantém no pool de livres pilotos conhecidos que não tenham contrato atual nem transferência futura, mesmo quando ainda constam no roster legado.
4. Foi acrescentado um teste de regressão para equipe com dois titulares e um terceiro piloto declarado no roster: o terceiro piloto deve continuar rastreável como agente livre, sem criar um terceiro contrato ativo.
5. O teste de duas temporadas passou a mostrar mais contexto quando a contagem de pilotos ativos falha, facilitando a localização do defeito em futuras regressões.

## Verificações executadas após as correções
- `validate_project.py`: **32/32** verificações aprovadas.
- `final_release_audit.py`: **34/34** verificações estruturais aprovadas.
- `v577_final_integration_audit.py`: **13/13** verificações aprovadas.
- `run_catalog_live_market_audit_v580.sh`: **PASS**, catálogo → mercado → grid de 82 pilotos → premiação/patrocínios → investimento técnico/P&D/fábrica/evolução.
- `TwoSeasonChainRuntimeAudit`: **PASS — 60/60 GPs**, temporadas 2026 e 2027 concluídas; transições anuais confirmadas; próximo estado 2028 GP1; 82 pilotos ativos no grid, 102 pilotos no catálogo, equipe personalizada e pilotos 101/102 preservados, 102 pilotos com evolução e 60 marcadores de evolução. Pontos somados na simulação: 65.340; prêmios de construtores liquidados em 2026 e 2027.
- Auditorias estáticas adicionais anteriormente executadas: ciclo do jogo V448 18/18, persistência de IA V498 8/8, áudio V576 12/12 (roteamento estático; som real não testado), auditoria V429 9/9 e regulamentação V445 4772/4772.
- A inspeção de conteúdo confirmou assets externos preservados: 100 pilotos, 40 equipes, 50 circuitos, 2 arquivos de carros e 590 documentos de histórico/auditoria na contagem do projeto.

## Limites ainda não comprovados
- A suíte JUnit oficial não foi executada porque o pacote não inclui `gradlew`/`gradle-wrapper.jar` e o ambiente não tem Gradle/Android SDK instalados.
- A compilação final do APK, instalação, inicialização em aparelho/emulador, persistência real após fechar/reabrir e ANR ainda precisam de validação em ambiente Android.
- Algumas auditorias históricas V578/V579/V580 ainda verificam expectativas próprias dessas versões antigas; suas falhas não foram automaticamente classificadas como defeitos atuais nem usadas como prova de aprovação.

## Conclusão
Foram corrigidos defeitos concretos no rastreamento de pilotos e na transição de mercado, e a simulação headless de duas temporadas concluiu 60/60 GPs após as correções. Isso é evidência de integração dos sistemas de catálogo/mercado/grid/transição anual, mas **não certifica o APK nem substitui testes oficiais e em dispositivo Android**.


## Atualização posterior: causa-raiz do catálogo (2026-10-15)
Foi feita uma revisão direcionada de `CustomWorldCatalog.kt`, `MainMenuScreen.kt` e `DriverMarketCatalogMigrationV560.kt`. Encontrados dois defeitos concretos e corrigidos: edição de equipe oficial não persistia o próprio override alvo; e a migração do mercado podia reintroduzir um piloto ainda vinculado ao roster como agente livre. A auditoria integrada catálogo/mercado/grid passou novamente. A exclusão de equipes/pilotos personalizados não está implementada pelas APIs atuais e continua pendente. Ver `AUDIT_ROOT_CAUSE_V608_CATALOG.md`. A compilação Android/dispositivo continua sem validação.
