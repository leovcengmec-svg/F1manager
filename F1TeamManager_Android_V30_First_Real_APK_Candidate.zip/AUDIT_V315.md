# V315 — Atualização do layout real de P&D

- Base de trabalho: ZIP oficial V314; nome do pacote de entrega preservado.
- Atualizada a janela real de seleção de pesquisa em `app/src/main/java/com/f1teammanager/MainActivity.kt`.
- Adicionado cabeçalho com o asset existente `drawable-nodpi/facility_research.webp`, overlay escuro e tipografia ajustada.
- Refinados espaçamentos, proporção dos cards de foco, bordas de seleção e altura dos cards de complexidade.
- Preservados `ResearchEngine`, enums `ResearchFocus` e `ResearchComplexity`, cálculo de custo, verificação de orçamento e callback `develop(component, selectedFocus, selectedComplexity)`.
- Não foram removidos nem alterados sistemas de corrida, dados, contratos, estatísticas ou assets externos.
- versionCode=315 / versionName=0.315.0.
- Verificação executada: revisão estática das alterações e integridade ZIP. Não foi possível executar build Android nesta sessão (ZIP não fornece Gradle Wrapper executável).
