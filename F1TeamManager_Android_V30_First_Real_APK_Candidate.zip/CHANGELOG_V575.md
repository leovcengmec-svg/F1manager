# V575 — Recuperação controlada do catálogo

- A tela de cadastros agora permite preparar uma prévia de recuperação antes de qualquer gravação.
- A prévia preserva apenas registros que passam nas validações básicas, detecta vínculos com pilotos/equipes não recuperáveis e informa os itens que ficarão fora da proposta.
- A recuperação exige confirmação explícita; antes de alterar o catálogo ativo, salva os três valores JSON brutos originais em chaves de backup locais exclusivas.
- A proposta é revalidada pelo carregador normal depois de gravada. Se a validação final falhar, os valores originais são restaurados e a proteção permanece ativa.
- A aplicação aborta se os dados mudarem entre a prévia e a confirmação ou se não for possível confirmar o backup.
- Nenhuma rotina altera carreiras, contratos, resultados, calendário, histórico de temporadas ou assets externos.

## Validação

- ZIP verificado com `unzip -t`.
- Conferência estática da versão: `versionCode = 575`, `versionName = 0.575.0`.
- Testes de contrato adicionados, mas não executados.
- Compilação Android não executada: não há Gradle Wrapper nem Gradle instalado neste ambiente.
