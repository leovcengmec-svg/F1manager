# V575 — construção do próximo carro

- Mantém a tabela unitária de referência de investimento por Overall (40–100), com €8M no Overall 40 e €150M no Overall 100.
- Mantém a referência individual de cada equipe calculada pelo Overall atual; investimento e foco técnico continuam usando a função de investimento existente.
- Adiciona transferência técnica de 10% do valor de cada atributo do carro anterior, arredondada individualmente, na construção do carro do jogador.
- Aplica a transferência separadamente ao Carro 1 e ao Carro 2; não calcula a herança usando uma média dos dois veículos.
- Aplica a mesma transferência de 10% na construção anual dos carros de IA.
- A transferência é somada antes do ajuste de regulamento da próxima temporada.
- Não reintroduz regressão anual de 70%.
- Atualiza versão para 0.575.0.
