# V424 — Validação da virada de temporada para referência dinâmica

- Centralizada a conversão de investimento em efeito de temporada em `nextSeasonInvestmentSteps(overall, invested)`.
- A previsão e a construção real do carro da próxima temporada passam a compartilhar a mesma regra e a mesma tabela de Overall 40–100.
- O efeito é calculado no momento da virada com o Overall do carro anterior; após a construção, o investimento reservado é zerado para evitar reaproveitamento na nova temporada.
- Testes-fonte adicionados para provar que €8M corresponde a 5 passos em Overall 40 e 2 passos em Overall 49, e que cada referência exata aplicada equivale à faixa de manutenção (5 passos).
- Sem alterações de layout.
- Compilação Android e execução dos testes não realizadas neste ambiente.
