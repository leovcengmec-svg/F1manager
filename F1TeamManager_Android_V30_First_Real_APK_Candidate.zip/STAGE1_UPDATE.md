# F1 Team Manager — Stage 1

## Evolução de pilotos — versão atualizada

- 100 pilotos oficiais possuem Classe fixa e Tipo de Evolução fixo.
- Não existe idade e não existe aposentadoria.
- Os 7 atributos permanecem: Velocidade, Classificação, Ultrapassagem, Defesa, Consistência, Chuva e Pneus.
- Atributos ficam entre 40 e 100.
- Overall é a média aritmética simples dos 7 atributos.
- Tetos absolutos por Classe: Fraco 59, Médio 69, Forte 79, Pro 89, Lenda 100.
- Evolução ocorre durante a temporada, após cada GP; o GP30 não executa uma segunda evolução.

## Limite positivo por atributo / temporada

- Prodígio: +12
- Auge rápido: +10
- Auge moderado: +8
- Auge tardio: +8
- Normal: +6
- Demorado: +5

O limite é individual por atributo. Não existe mais um único banco de ganho compartilhado pelos 7 atributos.

## Redistribuição do teto

A cada ponto de evolução positiva, um atributo é escolhido aleatoriamente. Se ele estiver no teto da Classe, em 100 ou já tiver consumido seu limite anual, o ponto é redirecionado para outro atributo elegível. O ganho não é perdido enquanto existir espaço em algum atributo.

Exemplo: uma Lenda com Velocidade 100 que receberia +8 não perde esses 8 pontos; eles são distribuídos entre os demais atributos que ainda possam evoluir.

Regressão não usa redistribuição: cada perda é aplicada ao atributo sorteado e limitada pelo piso 40.

## Persistência

Os atributos atuais e o consumo anual de ganho de cada atributo são persistidos por temporada e reaproveitados nas corridas seguintes.

## Validação

Foi validada a lógica de redistribuição, teto Pro/Lenda, preservação do ganho enquanto houver espaço e piso 40 na regressão.

O ambiente usado nesta atualização não possui Android Gradle/SDK; portanto não é declarado um APK compilado.

V44.1 — correção de compilação do fluxo de evolução
- Corrigido o import ausente de `DriverProfileCatalog` em `CareerPreferences.kt`.
- Removida a dependência indevida de `DriverDefinition.ratings()` privado de outro arquivo em `CareerPreferences.kt`; o cálculo agora monta explicitamente os 7 atributos.
- A correção elimina os `Unresolved reference` reportados no build em `CareerPreferences.kt` (linhas 381/404).
- Núcleo `core` recompilado com `kotlinc`: sucesso, somente warnings existentes.
