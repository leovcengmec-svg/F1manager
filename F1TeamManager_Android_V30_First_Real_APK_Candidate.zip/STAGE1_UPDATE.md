# F1 Team Manager — Stage 1

## Driver evolution and fixed profiles

- 100 official drivers have a fixed Class and fixed Evolution type.
- No age field and no retirement mechanic were introduced.
- Seven attributes remain the only driver attributes: Speed, Qualifying, Overtaking, Defense, Consistency, Wet, Tyres.
- Attributes are constrained to 40–100.
- Overall is the arithmetic mean of the seven attributes.
- Class ceilings are absolute: Fraco 59, Medio 69, Forte 79, Pro 89, Lenda 100.
- Initial attributes were adjusted where necessary so no driver starts above the ceiling of his assigned class.
- Seasonal performance is evaluated after the 30th GP using the agreed IDT weights.
- Targets are created at season start and frozen for that season.
- Evolution is applied to individual attributes and then Overall is recalculated.
- Evolution type remains fixed for the entire career.
- The peak phase does not force immediate decline; regression can later bring a driver into the recovery zone around Overall 40–49.
- Evolution is persisted between seasons and affects subsequent race participants.

## Important

This is a source update. The environment used to validate this package does not contain the Android Gradle wrapper/SDK required to produce a release APK, so no APK build is claimed here.
