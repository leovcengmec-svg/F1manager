# V308 — Ajustes finos na interface da equipe

- Cabeçalho: nome da equipe centralizado no topo em uma única linha; removidos o nome do país e o nome/modelo textual do carro.
- Bandeira exibida apenas como imagem em card compacto; pontos ficam em uma linha e posição funcional aparece abaixo.
- Card Overall com altura ampliada para evitar corte dos números e rótulo simplificado para “OVERALL”.
- Removida duplicação da linha “Limite técnico disponível” no orçamento.
- Título de Desempenho Geral reduzido para caber sem reticências.
- Adicionados ícones aos indicadores de desempenho da temporada.
- Histórico por temporada redesenhado como tabela horizontal no padrão de referência, incluindo equipe, posição, pontos, vitórias, pódios, poles, melhores voltas, GPs e DNFs. Pódios são calculados a partir dos resultados históricos por equipe/temporada.
- O histórico continua alimentado pelo arquivamento de temporada existente em HistoricalDatabase.finalizeSeason; não foram criados dados fictícios.
- Mantidos os assets externos, demais telas, funcionalidades e arquivos de histórico anteriores.

Validação: ZIP íntegro e inspeção estática dos trechos alterados. Build Android e teste visual em dispositivo pendentes.
