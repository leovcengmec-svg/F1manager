# V640 (0.640.0) — Correção dos nomes das instalações na visão geral da equipe

- Corrigido o mapeamento da faixa horizontal de instalações na tela central de equipes: o nível MARKETING é exibido como "Centro Comercial" (uma única instalação comercial, que também concentra o marketing/patrocínios).
- A instalação SCOUTING passa a ser identificada como "Scouting", compatível com sua arte e sua função real de precisão das informações do mercado de pilotos.
- O rótulo compacto Centro Comercial usa fonte de 9sp para caber melhor no cartão horizontal sem alterar o layout de toda a faixa.
- Alteração restrita à apresentação: não cria nem remove instalações, não altera os níveis persistidos, custos, manutenção, receitas comerciais, patrocínios ou saves existentes.

