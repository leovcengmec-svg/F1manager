# V490 — Desconto de fabricação por ranking técnico

- Adicionado desconto de fabricação menor que o desconto de P&D: posições 1–10 = 0%; 11–20 = 10%; 21–30 = 20%; 31–40 = 30%.
- O custo de fabricação compartilhado aplica primeiro o multiplicador do nível da fábrica e depois o desconto do ranking técnico.
- A interface do jogador apresenta os custos já descontados e a confirmação recalcula/valida o valor usando o ranking atual.
- A IA usa o mesmo cálculo compartilhado tanto ao estimar quanto ao pagar a fabricação, evitando discrepâncias no orçamento e no teto anual técnico.
- Não altera o desconto do P&D (0/20/40/60%) nem o teto anual de investimento técnico.
- Validação estática das chamadas e das quatro faixas; compilação Gradle/Android completa não executada neste ambiente.
