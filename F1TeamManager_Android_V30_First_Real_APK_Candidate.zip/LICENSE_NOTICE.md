# License / attribution notice

This Android project is a clean Kotlin reimplementation of game-domain behavior inspired by public descriptions of the Pitwall F1 Manager project.

No Pitwall source files are packaged as the Android race engine.

Reference project: https://github.com/domhnallmorr/Pitwall
Reference repository license/status should be checked before any future direct code reuse.
