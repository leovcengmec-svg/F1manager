# V692 — correção da exportação do save selecionado

Base: V691 (`versionCode 691`).
Nova revisão: V692 (`versionCode 692`, `versionName 0.692.0`).

- Corrigida a seleção da origem da exportação: quando existe um save explicitamente selecionado, o aplicativo exporta exatamente aquele arquivo.
- Removida a comparação de `careerId` entre o save selecionado e a carreira carregada como critério para substituir a origem da exportação.
- Snapshots diferentes da mesma carreira (por exemplo, após troca de equipe e mudança de temporada) deixam de ser confundidos com o estado atualmente carregado.
- O arquivo selecionado é lido e validado diretamente; não é atualizado com os dados da carreira ativa.
- A exportação da carreira ativa continua disponível quando nenhum save foi selecionado.
- Se o arquivo selecionado desaparecer antes da exportação, o sistema informa o problema e solicita nova seleção, sem trocar silenciosamente para outro save.
- Adicionados testes para seleção explícita com mesmo ID de carreira, outra carreira e ausência de seleção.
- Nome público do aplicativo e nome canônico do ZIP preservados.
