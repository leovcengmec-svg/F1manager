# Auditoria V329 — Decisão do Manager

## Mapeamento
- Arquivo: `app/src/main/java/com/f1teammanager/MainActivity.kt`
- Composable: `Race(...)`
- Condição de exibição: `if (activeRaceEventCard == null) s.decision?.let { d -> ... }`
- Modal: `Dialog` com `Surface` de fundo `#080D14`, borda `Line`, cantos de 24 dp.
- Cards: card de piloto/posição; card `PNEU ATUAL`; card `VOLTAS RESTANTES`/`PISTA`; cards de ação gerados por `d.request.options`.
- Dados: `s.classification`, `statusById`, `s.totalLaps`, `s.lap`, `s.weather`, `d.request.message`, `d.request.options`.
- Ícones: bandeira/alerta no cabeçalho, `TyreCompoundIcon`, símbolos das ações BOX/MANTER/ESTENDER STINT.
- Imagens: o modal mostrado não usa imagens de arquivo; utiliza emoji/símbolos e componentes Compose.

## Ajustes
- Retirada a rolagem vertical do modal.
- Altura máxima de 690 dp; padding 8 dp; espaçamento vertical 6 dp.
- Card de piloto com altura de 62 dp.
- Cards de informação com altura uniforme de 112 dp e largura dividida igualmente.
- Cards de ação com altura de 64 dp e textos compactos de uma linha.

## Risco residual
Mensagens de evento excepcionalmente longas ou listas de opções maiores do que o padrão podem exceder o espaço disponível. A compilação e o teste de screenshot no dispositivo ainda são necessários.
