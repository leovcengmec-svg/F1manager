# Auditoria dirigida V709 — envelhecimento, pilotos livres e próximo carro

## Regras aprovadas para esta revisão
- Envelhecimento natural pode reduzir qualquer um dos sete atributos e respeita o piso 40.
- Recuperação no reinício do ciclo abrange os sete atributos, recupera 50% das perdas naturais agregadas e nunca ultrapassa o pico histórico individual.
- Pilotos sem equipe evoluem com o índice neutro de 105 até o potencial individual, inclusive acima do teto de classe.
- Pilotos livres não sofrem regressão esportiva; um saldo negativo vindo do período em que eram contratados é zerado ao entrar no fluxo livre.
- Pilotos livres podem perder atributos apenas pelo envelhecimento natural.
- Notícias identificam causas e atributos alterados, não usam a expressão ambígua “declínio natural/forma esportiva”.
- O próximo carro bloqueia novos investimentos assim que atingir o Overall máximo anual ou seu investimento-meta. O núcleo financeiro também rejeita qualquer excesso.

## Exemplos determinísticos cobertos por testes
- Piloto livre Médio/Overall 67/Potencial 90 ultrapassa Overall 69 com progressão natural.
- Piloto livre com saldo esportivo legado negativo não sofre regressão esportiva.
- Piloto de 43 anos tem perdas naturais possíveis nos sete atributos.
- Overall 46 tem teto 53; investimento-meta €31M. Após €31M, aporte adicional de €1M é rejeitado. Com €30M, aporte de €2M é rejeitado e o aporte exato de €1M é aceito.

## Compatibilidade
As chaves persistidas antigas `driverAgePhysicalLosses` e `driverAgePhysicalPeaks` não foram renomeadas. A lista tem sete posições desde a estrutura existente, e a implementação V709 amplia o uso do ledger sem quebrar os saves anteriores.
