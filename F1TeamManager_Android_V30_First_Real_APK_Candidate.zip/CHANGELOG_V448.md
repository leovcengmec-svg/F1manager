# V448 — Auditoria do ciclo e persistência atômica do próximo carro

- Corrigida uma janela de falha na qual o investimento do próximo carro e o débito financeiro eram gravados em duas operações separadas.
- Adicionado `CareerPreferences.saveCarAndFinance(...)`, que persiste os atributos serializados do carro e o estado financeiro em um único `SharedPreferences.Editor.commit()`.
- O callback de investimento agora só atualiza o estado em memória depois que a persistência combinada é confirmada; falha de gravação é informada ao jogador.
- Corrigido o teste de auditoria financeira V441 para validar a consistência da versão atual, em vez de exigir permanentemente V442.
- Acrescentada auditoria estrutural do ciclo do jogo: transição de temporada, regulamento, corrida instantânea, finalização idempotente, patrocínios, calendário, investimento anual e preservação de assets/histórico.
- Versão atualizada para `448` (`0.448.0`). Nome fixo do ZIP preservado.

## Validação
- Auditorias estruturais e scripts de estresse executados após a alteração.
- Compilação Android, testes JUnit e teste no dispositivo continuam pendentes porque o ambiente não contém Gradle Wrapper/SDK Android executável.
