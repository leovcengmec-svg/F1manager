# V671 — Commercial Center and sponsorship economy

- Corrected new sponsorship contract pricing: Commercial Center levels 0/1/2 now grant +60%/+40%/+20% respectively; level 3 onward continues at +2.5 percentage points per level from the level-2 baseline, reaching +40% at level 10.
- Put `FacilityEngine.marketingQuality()` into sponsorship offer generation: higher marketing quality shifts the deterministic category draw toward the stronger tier already unlocked, without unlocking categories early.
- Fixed the AI facilities allocation: the 20% annual facilities share (currently €40M of the €200M annual envelope) now accumulates across seasons when unused. Legacy saves receive only the unspent balance for the first credited season. Reserve and credited-through season are persisted and restored.
- Kept the shared €200M annual technical ceiling, cash protection, next-season car reserve, mandatory obligations, and 12-week one-at-a-time facility construction safeguards.
- Standardized race sponsorship objectives to use the exact displayed position range, just like qualifying objectives. AI sponsor valuation now estimates the same bounded range.
- Removed the unused per-point bonus from newly generated offers (`pointsBonus = 0`). The serialized field remains solely for backward save compatibility; it is not part of new offer value or race settlement.
- Preserved the V670 recent-results card height improvements and the 40% / 40% / 20% AI strategic split.
