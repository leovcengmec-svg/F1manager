# Auditoria V699 — estabilização seguindo a auditoria V698

## Identificação
- Nome público: F1 Team Manager V30
- VersionCode: 699
- VersionName: 0.699.0
- Base: V698 / 0.698.0
- ZIP: `F1TeamManager_Android_V30_First_Real_APK_Candidate.zip`

## Correções aplicadas
1. **GitHub Actions:** removida a etapa que exigia versionCode 685 e executava o script histórico v685_contract_duration_audit.py. O workflow agora executa `tools/validate_release_contract.py` e identifica o APK pelo VersionCode extraído do Gradle.
2. **Piso global na corrida:** `CareerWeekendEngine.start()` normaliza o roster imediatamente após a validação estrutural, cobrindo chamadas diretas e headless. `InstantSimulationService` também normaliza o roster antes da inicialização.
3. **Chuva:** a rotina direta de penalidade aplica wetSkill em 40..100, não 0..100.
4. **Notificações P&D:** notícias de sucesso usam `ResearchDesign.completedWeek`; falhas usam a semana calculada por projeto a partir do contador de semanas restantes antes do avanço. A semana do evento não depende mais de `targetWeek` quando o usuário salta diversas semanas.
5. **Construção do próximo carro:** atualizados contratos de teste v636 que ainda esperavam Overall e atributos físicos 0/1. O piso físico é 40; peça ausente permanece marcada pela falta de `installedPieces`/`installedPieceVersions`.
6. **Assets externos:** confirmação do usuário de que o jogo utiliza imagens externas foi incorporada à documentação. Não é defeito e nenhuma regra de carregamento foi alterada.

## Testes adicionados/atualizados
- `RaceEngineAttributeFloorV699Test`: compara uma sessão iniciada com atributos legados baixos à mesma sessão iniciada com roster normalizado; os resultados Q1 devem coincidir.
- `RaceWeatherPerformanceV682Test`: inclui teste explícito de piso 40 na habilidade de chuva.
- `ResearchCompletionWeekPolicyV699Test`: cobre conclusão em avanços de múltiplas semanas e limite do calendário.
- `NextSeasonCarConstructionV636Test`: expectativas de Overall/componentes atualizadas para o mínimo permanente 40.

## Validação
- A validação de contrato V699 está disponível em `tools/validate_release_contract.py` e é executada no GitHub Actions antes da suíte e do APK.
- A compilação integral Android e a execução da suíte JUnit dependem da execução do workflow GitHub Actions. Este ambiente não possui Gradle nem Android SDK; não se declara APK compilado localmente.

## Verificações executadas nesta sessão
- `tools/validate_release_contract.py`: **19/19** verificações aprovadas.
- `tools/race_sim_test/final_release_audit.py`: **25/25** verificações estruturais aprovadas.
- Kotlin standalone smoke test de RaceParticipant/RaceWeatherPerformance: `RACE_ATTRIBUTE_FLOOR_SMOKE_OK`.
- Kotlin standalone smoke test de ResearchCompletionWeekPolicy: `RESEARCH_COMPLETION_WEEK_SMOKE_OK`.
- Compilação sintática dos testes alterados de chuva e semana do P&D com stubs mínimos de JUnit: aprovada.
- YAML do workflow parseado com sucesso; Python validator passou em `py_compile`.
- A tentativa de compilar todo o núcleo Kotlin de uma vez excedeu a memória disponível do ambiente. A compilação Android completa e a suíte JUnit continuam pendentes no GitHub Actions.

## Não é defeito
O jogo carrega as imagens da pasta externa `Pictures/F1Manager/Assets`. O usuário confirmou que essa é a arquitetura esperada e que a leitura funciona. Nenhuma alteração de carregamento de imagens é necessária; o mecanismo foi preservado.
