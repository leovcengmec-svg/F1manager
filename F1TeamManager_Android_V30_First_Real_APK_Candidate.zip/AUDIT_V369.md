# Auditoria V369

## Bloco implementado
Pré-validação do grid/circuito, validação ampliada das fases de qualificação e tratamento de falhas no ponto de entrada da simulação instantânea.

## Alterações principais
- `CareerWeekendEngine.start` agora rejeita dados inválidos antes de modificar o estado interno.
- O serviço instantâneo valida consistência entre os participantes, posições, tempos de volta e eliminados das fases.
- `MainActivity.simulateWeekendInstantlyForCareer()` só aplica bônus e publica o resultado após o serviço retornar um fim de semana validado; exceções anteriores são informadas sem aplicar efeitos da carreira.

## Validação
- Inspeção estática dos pontos alterados: realizada.
- Testes JUnit adicionados: 3.
- JUnit/Gradle: não executado, pois o pacote não contém Gradle Wrapper e o ambiente não tem Gradle instalado.
- Build Android: pendente.
- Simulação persistente de 60 GPs: pendente; este bloco não deve ser descrito como prova de duas temporadas completas.
