# Auditoria da virada de temporada — V426

## Escopo
Revisão estática do fluxo manual `MainActivity.startNextSeason()` e da persistência em `CareerPreferences.startNextSeason()`.

## Conferências de contrato adicionadas
- A temporada só avança depois de `isSeasonEnded()`.
- A virada incrementa a temporada, reinicia a rodada e a semana e gera nova semente de calendário.
- O carro novo é criado antes de recalcular o teto anual de investimento técnico.
- O controlador anual recalculado é persistido junto de carro, garagem, finanças, mercado de pilotos e patrocinadores.
- Foram adicionados testes de contrato de código-fonte em `SeasonTransitionV426AuditTest.kt`.

## Pendência crítica
A virada ainda executa múltiplas gravações em sequência, sem um diário transacional com retomada automática. Se o processo for encerrado entre a mudança do número da temporada e a conclusão de todas as gravações, o estado pode ficar parcialmente atualizado. Não declarar a virada à prova de interrupção até implementar e testar recuperação idempotente.

## Validação
Esta é uma auditoria estática e testes-fonte. A compilação Android e os testes JUnit **não foram executados** neste ambiente; portanto, a correção não foi validada em execução.
