# V725 — Evolução de pilotos, construção de carros e inteligência financeira

Base: V724 / 0.724.0  
VersionCode: 725  
VersionName: 0.725.0  
Nome público preservado: F1 Team Manager V30

## 1. Próximo carro e confiabilidade

- O construtor canônico do próximo carro agora aplica simultaneamente o piso `Overall anterior - 10` (respeitando o piso absoluto 40) e o teto de crescimento permitido pela política existente.
- Projeções, ranking, ficha da equipe, mercado e virada efetiva podem utilizar os mesmos limites, evitando que uma projeção permita perda de 25 pontos enquanto a virada real permite apenas 10.
- Desempenho e confiabilidade continuam sendo dimensões independentes. A confiabilidade carregada para o carro seguinte vem da confiabilidade real dos componentes instalados e fabricados/pesquisados; não é criado um bônus artificial de confiabilidade a partir do orçamento Overall.
- IDs, versões e confiabilidade individual das peças instaladas são preservados. A pesquisa com foco em confiabilidade continua usando seu próprio fluxo de P&D e fabricação.

## 2. Ciclo etário e regressão

- O ciclo etário agora vai de 18 a 45 anos, inclusive. O piloto completa a temporada inteira aos 45; o novo ciclo começa na virada seguinte.
- No reinício, cada um dos sete atributos recebe `floor(valor × 70 / 100)`, com piso absoluto 40. O Overall é recalculado a partir dos atributos resultantes.
- A recuperação automática de 50% foi retirada. O reinício não restaura os picos históricos nem modifica classe, identidade ou perfil fixo de evolução.
- A regressão natural é debitada separadamente do desenvolvimento esportivo, com intensidade crescente dos 34 aos 45 anos. Ganhos de desempenho não apagam o registro da regressão etária.
- As notícias distinguem crescimento esportivo, regressão etária e reinício de ciclo.
- Saves V724 são migrados sem executar um corte extra de 30% durante a migração. O calendário é alinhado ao limite de 45 anos; atributos já modificados por uma versão anterior são preservados para não inventar nem reconstruir dados que o save não contém.

## 3. Inteligência financeira da IA

- A política passa a distinguir caixa bruto de caixa livre após reserva operacional e obrigações.
- Equipes fracas (ranking 25–40, Overall até 65) e com pelo menos €30M de capital discricionário podem iniciar a reconstrução antes do GP 21.
- O perfil de reconstrução direciona 60% de prioridade ao próximo carro; da liquidez restante protegida para o envelope técnico, o plano favorece carro atual (70%) e instalações (30%).
- A contribuição do próximo carro usa uma meta progressiva por GP ligada ao custo de Overall × dinheiro, sem ultrapassar o caixa livre, a previsão financeira ou o teto independente de €150M.
- O envelope de €200M para carro atual/fábrica/instalações continua independente do envelope de €150M do próximo carro.
- Cada decisão de investimento registra o motivo: investimento realizado, meta atingida, limite anual, reserva operacional, obrigações futuras, previsão sem margem ou caixa insuficiente. O registro acompanha o snapshot exportado/restaurado da IA.

## 4. Histórico e gráfico de evolução

- Criado o modelo de snapshot persistente por piloto: ID, temporada, idade, ciclo, Overall, sete atributos e tipo de evento.
- São registrados o primeiro ponto disponível, encerramentos de temporada e reinícios de ciclo.
- A ficha do piloto ganhou gráfico com alternância entre Overall e os sete atributos, eixo etário 18–45 e ciclos desenhados separadamente.
- O gráfico não reconstrói retroativamente temporadas sem snapshots reais e não liga artificialmente 45 a 18 anos.
- O histórico é salvo nas preferências da carreira, incluído no backup completo e restaurado junto ao save. O importador também aplica a migração V725 a backups V724 sem alterar o checksum do payload validado.

## Validação executada

- Compilação K2 das 77 fontes Kotlin puras do núcleo: aprovada, com avisos preexistentes de nulabilidade/Locale e aviso de linguagem 2.0 experimental.
- Bateria direcionada de testes de construção, envelopes financeiros, envelhecimento, ciclo de 45 anos, regressão, crescimento de pilotos livres e persistência do modelo de snapshot: **46 testes aprovados, 0 reprovados**.
- Smoke test de calendário de idade, corte de 30%, piso 40, limite de perda anual de Overall, confiabilidade de peça instalada e reconstrução antecipada da IA: aprovado.
- O ambiente não possui Gradle/Gradle Wrapper nem Android SDK. Portanto, não foi possível executar a compilação Android/Compose, gerar APK, executar JUnit via Gradle ou validar instalação em dispositivo.
- As simulações longas de 5, 10, 15 e 20 temporadas não foram executadas nesta sessão e continuam obrigatórias antes de uma aprovação de equilíbrio de longo prazo.
