# V672 — Auditoria de restrições de classe

## Regras aprovadas
- Classe oficial mínima: `Médio` (também conhecida como Normal).
- `Fraco` e `Normal` entram no motor como aliases legados de `Médio`, inclusive nas faixas de Overall e de potencial inicial.
- Não existe rebaixamento de `Médio` para `Fraco`.
- `Pro` só evolui para `Lenda` quando `isChampion=true` na temporada recém-concluída.
- A promoção continua exigindo evidência em duas temporadas consecutivas, pelo menos 80% dos GPs em cada temporada, médias esportivas de pelo menos 100 em ambas, média combinada de pelo menos 105 e Overall pelo menos um ponto acima da faixa de entrada da classe seguinte.
- A classe abaixo de `Médio` não faz mais parte da escada oficial.
- A carreira principal deriva o campeão do registro histórico oficial da temporada; o motor Team Manager deriva-o da tabela de pontos do campeonato concluído.
- O helper legado `AnnualTeamEventEngine.adjacentDriverClass` também bloqueia o downgrade abaixo de `Médio` e exige o título para `Pro` → `Lenda`.

## Compatibilidade
- Saves com rótulo `Fraco` ou `Normal` são interpretados como `Médio` sem gerar notícia falsa de promoção/rebaixamento.
- Valores e atributos de pilotos não são redefinidos por esta alteração; apenas a classe/limite lógico legado é normalizado quando necessário.
