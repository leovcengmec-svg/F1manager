# Auditoria V665 — desempenho da projeção financeira da IA

## Regressão tratada
O caminho de finanças da IA solicita repetidamente `financialOutlook` durante o avanço semanal, investimentos de instalações, custo de P&D e fechamento de GP. Cada chamada acionava `TeamSponsorshipEngine.projectCashflowForMarketingPlan`, que criava outro motor e reexecutava a projeção de renovações por até 60 rodadas (temporada atual restante + temporada seguinte), inclusive quando nada relevante havia mudado.

## Correção
- Cache memoizado e limitado a 256 projeções por instância.
- Fingerprint cobre equipe/temporada, GPs concluídos, níveis comerciais, hashes das carteiras da temporada atual e seguinte, ledger de corridas e ranking competitivo usado para estimar bônus.
- Alterações relevantes produzem chave diferente; a restauração de snapshot limpa o cache.
- Ranking competitivo calculado uma vez por instância, eliminando ordenações repetidas das 39 equipes.
- Projeção permanece isolada: não modifica contratos, eventos ou chaves de idempotência da carreira ativa.

## Limites da validação
A correção reduz trabalho repetido no caminho financeiro, mas não prova por si só que todo o aplicativo recuperou o desempenho da V655. É necessário medir avanço semanal, início do GP e fechamento de GP no mesmo aparelho e no mesmo save. Não houve build Android oficial nem teste de dispositivo neste ambiente.
