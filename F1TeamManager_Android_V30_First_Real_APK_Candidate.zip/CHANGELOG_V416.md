# V416 — Front-end da apresentação de temporada

- Criado `SeasonStartEventScreen.kt` com banner, quatro cards de equipes, cinco cards de pilotos, painel de expectativa e botão de início.
- Componentes reaproveitam `ExternalAssets` para escudos, carros, fotografias e bandeiras.
- Layout usa cartões padronizados, texto com quebra de linha e não inclui rolagem vertical ou horizontal.
- Adicionada especificação objetiva em `SEASON_START_UI_SPEC_V416.md`.
- A integração à navegação e à persistência da exibição única não foi feita nesta versão.
- Build Android não executado neste ambiente.
