# Auditoria V723 — Correção do build Kotlin

## Falhas reportadas pelo GitHub Actions na V722

1. `MainActivity.kt:559:5` — `private` aplicado a função local.
2. `MainActivity.kt:981:15` e `:981:21` — erros de parsing causados pelo fechamento incorreto da expressão `check`.
3. `MainActivity.kt:991:48` — lambda de mensagem de `check` interpretada como argumento extra de `saveCareerStepBundle` porque faltava fechar `check(...)`.

## Correções

- `advanceFreeWeeksSegment` continua local a `F1ManagerApp`, mas sem o modificador `private`.
- A chamada foi corrigida para fechar `saveCareerStepBundle(...)` e `check(...)` separadamente antes da mensagem lazy: `committedCurrentWeek = targetWeek)) { ... }`.
- A assinatura de `CareerPreferences.saveCareerStepBundle` foi conferida: `committedCurrentWeek` é o último argumento opcional e a função retorna `Boolean`; não recebe lambda adicional.
- Os demais pontos de chamada de `saveCareerStepBundle` foram inspecionados e mantidos.

## Resultado

- Auditoria focada V723: 15/15 verificações estáticas aprovadas.
- ZIP: integridade verificada com `unzip -t`.
- Gradle/Kotlin Android build: não executado localmente por ausência de Gradle/Wrapper e Android SDK.
- O GitHub Actions deve confirmar `:app:compileDebugKotlin`, `:app:testDebugUnitTest` e `:app:assembleDebug`.
