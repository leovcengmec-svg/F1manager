# F1 Team Manager — V29 APK GitHub Ready

Projeto Android nativo do F1 Team Manager.

## Primeiro build
O repositório foi preparado para usar GitHub Actions. O workflow está em:

`.github/workflows/main.yml`

Ele instala/seleciona JDK 17, Gradle 9.5.0 e os componentes Android SDK necessários e executa `assembleDebug`.

## APK esperado

`app/build/outputs/apk/debug/app-debug.apk`

O APK é publicado como artifact `F1TeamManager-debug-apk-v29`.

## Importante
Este pacote não afirma que o APK foi compilado neste ambiente. A compilação Android real deve ser feita pelo GitHub Actions ou por um ambiente com Android SDK.

## Núcleo
A lógica de carreira, temporada, corrida, decisões estratégicas e catálogo de carros por equipe está em `app/src/main/java/com/f1teammanager/core`.
