package com.f1teammanager

import android.content.Context

/** Small, dependency-free persistence for career metadata. Race engine state remains in memory for the active weekend. */
class CareerPreferences(context: Context) {
    private val prefs = context.getSharedPreferences("f1tm_career", Context.MODE_PRIVATE)

    var hasCareer: Boolean
        get() = prefs.getBoolean("hasCareer", false)
        private set(value) = prefs.edit().putBoolean("hasCareer", value).apply()

    var teamId: Int
        get() = prefs.getInt("teamId", 1)
        private set(value) = prefs.edit().putInt("teamId", value).apply()

    var roundIndex: Int
        get() = prefs.getInt("roundIndex", 0)
        private set(value) = prefs.edit().putInt("roundIndex", value.coerceIn(0, 23)).apply()

    var season: Int
        get() = prefs.getInt("season", 2026)
        private set(value) = prefs.edit().putInt("season", value).apply()

    fun startNewCareer(selectedTeamId: Int) {
        teamId = selectedTeamId
        roundIndex = 0
        season = 2026
        hasCareer = true
    }

    fun advanceRound() {
        if (roundIndex < 23) roundIndex += 1 else {
            season += 1
            roundIndex = 0
        }
    }
}
