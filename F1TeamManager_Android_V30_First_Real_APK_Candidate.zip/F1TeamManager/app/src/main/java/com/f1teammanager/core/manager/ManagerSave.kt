package com.f1teammanager.core.manager

import java.io.File

object ManagerSave {
    fun save(file:File,state:TeamManagerState){
        file.parentFile?.mkdirs()
        val f=state.finance
        file.writeText(buildString {
            appendLine("F1TM_MANAGER_V7")
            appendLine("season=${state.season}"); appendLine("round=${state.round}"); appendLine("team=${state.playerTeamId}")
            appendLine("budget=${f.budget}"); appendLine("aero=${state.car.aerodynamics}"); appendLine("chassis=${state.car.chassis}"); appendLine("engine=${state.car.engine}"); appendLine("reliability=${state.car.reliability}")
            appendLine("reputation=${state.manager.reputation}"); appendLine("experience=${state.manager.experience}")
            appendLine("facilities=${state.car.facilities.entries.joinToString(","){it.key.name+":"+it.value}}")
        })
    }
    fun load(file:File):TeamManagerState?=runCatching {
        val m=file.readLines().filter{it.contains('=')}.associate{val p=it.split('=',limit=2);p[0] to p[1]}
        require(file.readLines().firstOrNull()=="F1TM_MANAGER_V7")
        val raw=m["facilities"].orEmpty().split(',').mapNotNull { part -> part.split(':',limit=2).takeIf{it.size==2}?.let{it[0] to it[1].toIntOrNull()} }.toMap()
        val facilities=Facility.values().associateWith { raw[it.name] ?: 1 }
        TeamManagerState(m["season"]!!.toInt(),m["round"]!!.toInt(),m["team"]!!.toInt(),TeamCarState(m["aero"]!!.toInt(),m["chassis"]!!.toInt(),m["engine"]!!.toInt(),m["reliability"]!!.toInt(),facilities),TeamFinanceState(m["budget"]!!.toLong()),ManagerProfile(reputation=m["reputation"]!!.toInt(),experience=m["experience"]!!.toInt()))
    }.getOrNull()
}
