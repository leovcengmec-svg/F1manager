package com.f1teammanager.core.race

import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

/** V13: full-field interactive race weekend. Qualifying -> race -> manager decisions -> result. */
class CareerWeekendEngine(private val seed: Int = 20261003) {
    data class DriverPlan(var mode: DriverStrategyMode = DriverStrategyMode.BALANCED, var tyre: Tyre = Tyre.MEDIUM)
    data class Decision(val request: ManagerDecisionRequest, val driverName: String)
    data class SessionSnapshot(
        val phase: String, val lap: Int, val totalLaps: Int,
        val grid: QualifyingResult?, val classification: List<FinishEntry>,
        val events: List<LapEvent>, val neutral: Neutralisation,
        val decision: Decision?, val plans: Map<Int, DriverPlan>, val completed: Boolean
    )
    private data class S(val p: RaceParticipant, val grid: Int, var total: Long = 0, var last: Long = 0,
                         var best: Long = Long.MAX_VALUE, var laps: Int = 0, var stint: Int = 0,
                         var stops: Int = 0, var dnf: Boolean = false, var wear: Int = 0,
                         var tyre: Tyre = Tyre.MEDIUM, var fuel: Double = 110.0,
                         var lastPos: Int = Int.MAX_VALUE)

    private val random = Random(seed)
    private var circuit: RaceCircuit? = null
    private var states = mutableMapOf<Int, S>()
    private var grid: QualifyingResult? = null
    private var lap = 0
    private var neutral = Neutralisation.GREEN
    private var neutralEnd = 0
    private var weather = Weather.DRY
    private var pending: Decision? = null
    private var events = mutableListOf<LapEvent>()
    private var finished = false
    private var fastestId: Int? = null
    private var fastest = Long.MAX_VALUE
    private val plans = mutableMapOf<Int, DriverPlan>()

    fun start(participants: List<RaceParticipant>, c: RaceCircuit, playerTeamId: Int): SessionSnapshot {
        require(participants.size >= 2) { "Grid insuficiente" }
        circuit = c; lap = 0; neutral = Neutralisation.GREEN; neutralEnd = 0; weather = Weather.DRY
        pending = null; events = mutableListOf(); finished = false; fastestId = null; fastest = Long.MAX_VALUE
        grid = RaceWeekendEngine(seed).qualify(participants, c)
        states = participants.associate { p ->
            val g = grid!!.grid.first { it.driverId == p.driverId }.position
            p.driverId to S(p, g)
        }.toMutableMap()
        plans.clear(); participants.filter { it.teamId == playerTeamId }.forEach { plans[it.driverId] = DriverPlan() }
        return snapshot("QUALIFYING", emptyList())
    }

    fun setPlan(driverId: Int, mode: DriverStrategyMode? = null, tyre: Tyre? = null): SessionSnapshot {
        val plan = plans[driverId] ?: error("Piloto não pertence à equipe do jogador")
        if (mode != null) plan.mode = mode
        if (tyre != null) plan.tyre = tyre
        states[driverId]?.tyre = plan.tyre
        return snapshot("RACE", emptyList())
    }

    fun advance(): SessionSnapshot {
        check(!finished) { "Fim de semana concluído" }
        check(pending == null) { "Resolva a decisão pendente" }
        val c = circuit ?: error("Circuito não iniciado")
        if (lap == 0) lap = 1 else lap++
        if (lap > c.laps) return finish()
        val before = events.size
        if (neutral != Neutralisation.GREEN && lap > neutralEnd) {
            events += LapEvent(lap, null, if (neutral == Neutralisation.SAFETY_CAR) EventType.SAFETY_CAR_ENDED else EventType.VSC_ENDED, "Neutralização encerrada")
            neutral = Neutralisation.GREEN
        }
        if (neutral == Neutralisation.GREEN) {
            val r = random.nextDouble()
            if (r < .009 * c.safetyCarRisk) {
                neutral = Neutralisation.SAFETY_CAR; neutralEnd = min(c.laps, lap + random.nextInt(2,5))
                events += LapEvent(lap, null, EventType.SAFETY_CAR_DEPLOYED, "Safety Car")
                if (pauseForPlayer("Safety Car na pista. O que deseja fazer?", ManagerDecisionType.SAFETY_CAR)) return snapshot("RACE", events.drop(before))
            } else if (r < .024 * c.safetyCarRisk) {
                neutral = Neutralisation.VSC; neutralEnd = min(c.laps, lap + random.nextInt(1,3))
                events += LapEvent(lap, null, EventType.VSC_DEPLOYED, "VSC")
                if (pauseForPlayer("VSC ativo. Aproveitar a janela estratégica?", ManagerDecisionType.VSC)) return snapshot("RACE", events.drop(before))
            } else if (r < .026 && lap > 5) {
                events += LapEvent(lap, null, EventType.RED_FLAG_DEPLOYED, "Bandeira vermelha")
                if (pauseForPlayer("Bandeira vermelha. Escolha pneus e postura para a relargada.", ManagerDecisionType.RED_FLAG)) return snapshot("RACE", events.drop(before))
            }
        }
        val active = states.values.filterNot { it.dnf }.sortedWith(compareBy<S>{it.total}.thenBy{it.grid})
        for (s in active) {
            val plan = plans[s.p.driverId]
            if (plan != null) {
                val fuelCritical = s.fuel <= 18.0
                val tyreCritical = s.stint >= 18
                if (fuelCritical && pauseForDriver(s, "Combustível baixo. Precisamos administrar ou ir para o box.", ManagerDecisionType.FUEL_CRITICAL)) return snapshot("RACE", events.drop(before))
                if (tyreCritical && pauseForDriver(s, "Pneu perdendo desempenho. Recomendo avaliar o box.", ManagerDecisionType.TYRE_CRITICAL)) return snapshot("RACE", events.drop(before))
            }
            if (plan != null && s.stint >= 20 && s.stops < 2) pit(s, plan.tyre)
            val pace = PitwallPaceModel(random)
            val remainingFuel = max(1.0, s.fuel)
            var lapMs = pace.lapTime(s.p, c, remainingFuel, s.stint, s.tyre, false)
            val posture = plan?.mode ?: DriverStrategyMode.BALANCED
            lapMs += when(posture) { DriverStrategyMode.ATTACK -> -90; DriverStrategyMode.BALANCED -> 0; DriverStrategyMode.DEFENSE -> 70 }
            lapMs += when(neutral) { Neutralisation.SAFETY_CAR -> 9000; Neutralisation.VSC -> 4500; Neutralisation.GREEN -> 0 }
            if (weather != Weather.DRY) lapMs += 700
            s.total += lapMs.coerceAtLeast(45000); s.last = lapMs; s.laps = lap; s.stint++; s.fuel = max(0.0, s.fuel - 110.0 / c.laps)
            s.wear = min(100, s.wear + max(1, (100-s.p.tyreWear)/20+1))
            if (lapMs < s.best) { s.best = lapMs; if (lapMs < fastest) { fastest = lapMs; fastestId = s.p.driverId } }
        }
        val after = states.values.filterNot { it.dnf }.sortedWith(compareBy<S>{it.total}.thenBy{it.grid})
        after.forEachIndexed { i, s -> if (s.lastPos != Int.MAX_VALUE && s.lastPos > i+1) events += LapEvent(lap,s.p.driverId,EventType.OVERTAKE,"Ganhou ${s.lastPos-(i+1)} posição(ões)"); s.lastPos=i+1 }
        return snapshot("RACE", events.drop(before))
    }

    fun choose(action: ManagerDecisionAction): SessionSnapshot {
        val d = pending ?: error("Nenhuma decisão pendente")
        require(d.request.type != ManagerDecisionType.RED_FLAG) { "Bandeira vermelha exige escolher pneu e postura juntos" }
        val s = states[d.request.driverId]
        if (s != null) when(action) {
            ManagerDecisionAction.BOX, ManagerDecisionAction.CHANGE_STRATEGY -> pit(s, plans[s.p.driverId]?.tyre ?: nextTyre(s.tyre))
            ManagerDecisionAction.EXTEND_STINT, ManagerDecisionAction.STAY_OUT -> Unit
            ManagerDecisionAction.RESTART_ATTACK -> plans[s.p.driverId]?.mode = DriverStrategyMode.ATTACK
            ManagerDecisionAction.RESTART_BALANCED -> plans[s.p.driverId]?.mode = DriverStrategyMode.BALANCED
            ManagerDecisionAction.RESTART_DEFENSE -> plans[s.p.driverId]?.mode = DriverStrategyMode.DEFENSE
            ManagerDecisionAction.CHANGE_TYRE_SOFT -> pit(s, Tyre.SOFT)
            ManagerDecisionAction.CHANGE_TYRE_MEDIUM -> pit(s, Tyre.MEDIUM)
            ManagerDecisionAction.CHANGE_TYRE_HARD -> pit(s, Tyre.HARD)
            ManagerDecisionAction.CHANGE_TYRE_INTERMEDIATE -> pit(s, Tyre.INTERMEDIATE)
            ManagerDecisionAction.CHANGE_TYRE_WET -> pit(s, Tyre.WET)
        }
        pending = null
        return snapshot("RACE", emptyList())
    }

    fun chooseRedFlag(tyre: Tyre, posture: DriverPosture): SessionSnapshot {
        val d = pending ?: error("Nenhuma decisão pendente")
        require(d.request.type == ManagerDecisionType.RED_FLAG) { "Não há bandeira vermelha pendente" }
        val s = states[d.request.driverId]
        if (s != null) {
            s.tyre = tyre
            s.wear = 0
            s.stint = 0
            plans[s.p.driverId]?.let { it.mode = posture.toMode() ; it.tyre = tyre }
            events += LapEvent(lap, s.p.driverId, EventType.PIT_STOP, "Relargada: $tyre / $posture")
        }
        pending = null
        neutral = Neutralisation.GREEN
        return snapshot("RACE", emptyList())
    }

    fun snapshotForUi(): SessionSnapshot = snapshot(if (finished) "RESULT" else "RACE", emptyList())

    fun result(): RaceResult {
        check(finished) { "Corrida ainda não terminou" }
        val classification = states.values.sortedWith(compareByDescending<S>{it.laps}.thenBy{it.total}).mapIndexed { i,s ->
            FinishEntry(i+1,s.p.driverId,s.p.driverName,s.p.teamName,s.laps,s.total,"FINISHED",s.tyre,s.stops)
        }
        val base = RaceResult(classification, events, fastestId, weather, emptyMap(), events.count{it.type==EventType.SAFETY_CAR_DEPLOYED}, events.count{it.type==EventType.VSC_DEPLOYED})
        return base.copy(points = ChampionshipEngine.award(base))
    }

    private fun DriverPosture.toMode(): DriverStrategyMode = when (this) {
        DriverPosture.ATTACK -> DriverStrategyMode.ATTACK
        DriverPosture.BALANCED -> DriverStrategyMode.BALANCED
        DriverPosture.DEFENSE -> DriverStrategyMode.DEFENSE
    }

    private fun pauseForPlayer(message: String, type: ManagerDecisionType): Boolean {
        val s = states.values.filter { plans.containsKey(it.p.driverId) && !it.dnf }.minByOrNull { it.total } ?: return false
        pending = Decision(ManagerDecisionRequest(lap,type,s.p.driverId,message,options(type)),s.p.driverName); return true
    }
    private fun pauseForDriver(s:S,message:String,type:ManagerDecisionType):Boolean { pending=Decision(ManagerDecisionRequest(lap,type,s.p.driverId,message,options(type)),s.p.driverName); return true }
    private fun options(t:ManagerDecisionType)=when(t){ManagerDecisionType.RED_FLAG->listOf(ManagerDecisionAction.CHANGE_TYRE_SOFT,ManagerDecisionAction.CHANGE_TYRE_MEDIUM,ManagerDecisionAction.CHANGE_TYRE_HARD,ManagerDecisionAction.RESTART_ATTACK,ManagerDecisionAction.RESTART_BALANCED,ManagerDecisionAction.RESTART_DEFENSE);else->listOf(ManagerDecisionAction.BOX,ManagerDecisionAction.STAY_OUT,ManagerDecisionAction.EXTEND_STINT)}
    private fun pit(s:S, tyre:Tyre){ s.stops++; s.stint=0; s.tyre=tyre; events += LapEvent(lap,s.p.driverId,EventType.PIT_STOP,"Pit stop ${s.stops}: $tyre") }
    private fun nextTyre(t:Tyre)=when(t){Tyre.SOFT->Tyre.MEDIUM;Tyre.MEDIUM->Tyre.HARD;Tyre.HARD->Tyre.MEDIUM;Tyre.INTERMEDIATE->Tyre.WET;Tyre.WET->Tyre.INTERMEDIATE}
    private fun finish():SessionSnapshot{finished=true; return snapshot("RESULT", emptyList())}
    private fun snapshot(phase:String,newEvents:List<LapEvent>):SessionSnapshot=SessionSnapshot(phase,lap,circuit?.laps?:0,grid,if(finished)resultClass() else emptyList(),newEvents,neutral,pending,plans.mapValues{it.value.copy()},finished)
    private fun resultClass()=states.values.sortedWith(compareByDescending<S>{it.laps}.thenBy{it.total}).mapIndexed{i,s->FinishEntry(i+1,s.p.driverId,s.p.driverName,s.p.teamName,s.laps,s.total,"FINISHED",s.tyre,s.stops)}
}
