package com.f1teammanager

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.f1teammanager.core.race.*
import com.f1teammanager.core.season.CarCatalog
import com.f1teammanager.core.season.RoundDefinition
import com.f1teammanager.core.season.WorldDatabase
import com.f1teammanager.core.season.toParticipant

private val Bg = Color(0xFF08090C)
private val Panel = Color(0xFF14161B)
private val Panel2 = Color(0xFF1B1E24)
private val Red = Color(0xFFE10600)
private val Muted = Color(0xFF8D929C)
private val Line = Color(0xFF2B2F36)
private val Green = Color(0xFF38C878)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { F1ManagerApp(CareerPreferences(this)) }
    }
}

private enum class Screen { HOME, TEAM, DRIVERS, CAR, CALENDAR, STANDINGS, FINANCE, WEEKEND, QUALIFYING, RACE, RESULT, SELECT_TEAM }
private enum class Nav { HOME, TEAM, CAR, CALENDAR, STANDINGS }

@Composable
private fun F1ManagerApp(store: CareerPreferences) {
    var hasCareer by remember { mutableStateOf(store.hasCareer) }
    var teamId by remember { mutableIntStateOf(store.teamId) }
    var roundIndex by remember { mutableIntStateOf(store.roundIndex) }
    var screen by remember { mutableStateOf(if (hasCareer) Screen.HOME else Screen.SELECT_TEAM) }
    var nav by remember { mutableStateOf(Nav.HOME) }
    var selectedMode by remember { mutableStateOf(DriverStrategyMode.BALANCED) }
    var selectedTyre by remember { mutableStateOf(Tyre.MEDIUM) }
    var snapshot by remember { mutableStateOf<CareerWeekendEngine.SessionSnapshot?>(null) }
    var result by remember { mutableStateOf<RaceResult?>(null) }
    val engine = remember { CareerWeekendEngine(20261003) }
    val team = WorldDatabase.teams.firstOrNull { it.id == teamId } ?: WorldDatabase.teams.first()
    val drivers = WorldDatabase.drivers.filter { it.teamId == team.id }
    val round = WorldDatabase.rounds.getOrElse(roundIndex) { WorldDatabase.rounds.first() }

    fun participants() = WorldDatabase.drivers.map { d ->
        val t = WorldDatabase.teams.first { it.id == d.teamId }
        d.toParticipant(t)
    }
    fun circuit() = RaceCircuit(round.round, round.circuit, round.laps, round.baseLapTimeMs, round.powerFactor, round.overtakingFactor, round.crashRisk, round.reliabilityRisk, round.safetyCarRisk)
    fun startWeekend() { snapshot = engine.start(participants(), circuit(), team.id); result = null; screen = Screen.QUALIFYING }
    fun startRace() { drivers.forEach { engine.setPlan(it.id, selectedMode, selectedTyre) }; snapshot = engine.advance(); screen = Screen.RACE }
    fun advanceRace() { snapshot = engine.advance(); if (snapshot?.completed == true) { result = engine.result(); screen = Screen.RESULT } }
    fun nextRound() { store.advanceRound(); roundIndex = store.roundIndex; screen = Screen.HOME; nav = Nav.HOME }
    fun selectTeam(id: Int) { store.startNewCareer(id); teamId = id; roundIndex = 0; hasCareer = true; screen = Screen.HOME; nav = Nav.HOME }

    MaterialTheme(colorScheme = darkColorScheme(background = Bg, surface = Panel, primary = Red)) {
        Surface(Modifier.fillMaxSize(), color = Bg) {
            when (screen) {
                Screen.SELECT_TEAM -> TeamSelect(::selectTeam)
                Screen.HOME -> AppScaffold("${team.name.uppercase()} • 2026", nav, { nav = it; screen = when(it){Nav.HOME->Screen.HOME;Nav.TEAM->Screen.TEAM;Nav.CAR->Screen.CAR;Nav.CALENDAR->Screen.CALENDAR;Nav.STANDINGS->Screen.STANDINGS} }, onMore={ screen=Screen.FINANCE }) { Home(team.name, CarCatalog.forTeam(team.id), drivers, round, onStart=::startWeekend, onDrivers={screen=Screen.DRIVERS}) }
                Screen.TEAM -> AppScaffold("EQUIPE", nav, { nav=it; screen=when(it){Nav.HOME->Screen.HOME;Nav.TEAM->Screen.TEAM;Nav.CAR->Screen.CAR;Nav.CALENDAR->Screen.CALENDAR;Nav.STANDINGS->Screen.STANDINGS} }, onMore={screen=Screen.FINANCE}) { Team(team.name, team.engine, team.reliability, drivers, onDrivers={screen=Screen.DRIVERS}) }
                Screen.DRIVERS -> DetailScaffold("PILOTOS", {screen=Screen.TEAM}) { Drivers(drivers) }
                Screen.CAR -> AppScaffold("CARRO", nav, { nav=it; screen=when(it){Nav.HOME->Screen.HOME;Nav.TEAM->Screen.TEAM;Nav.CAR->Screen.CAR;Nav.CALENDAR->Screen.CALENDAR;Nav.STANDINGS->Screen.STANDINGS} }, onMore={screen=Screen.FINANCE}) { Car(CarCatalog.forTeam(team.id), team.engine, team.reliability) }
                Screen.CALENDAR -> AppScaffold("CALENDÁRIO", nav, { nav=it; screen=when(it){Nav.HOME->Screen.HOME;Nav.TEAM->Screen.TEAM;Nav.CAR->Screen.CAR;Nav.CALENDAR->Screen.CALENDAR;Nav.STANDINGS->Screen.STANDINGS} }, onMore={screen=Screen.FINANCE}) { Calendar(roundIndex) }
                Screen.STANDINGS -> AppScaffold("CAMPEONATO", nav, { nav=it; screen=when(it){Nav.HOME->Screen.HOME;Nav.TEAM->Screen.TEAM;Nav.CAR->Screen.CAR;Nav.CALENDAR->Screen.CALENDAR;Nav.STANDINGS->Screen.STANDINGS} }, onMore={screen=Screen.FINANCE}) { Standings(team.id) }
                Screen.FINANCE -> DetailScaffold("FINANÇAS", {screen=Screen.HOME}) { Finance() }
                Screen.WEEKEND -> DetailScaffold("FIM DE SEMANA", {screen=Screen.HOME}) { Weekend(round, ::startWeekend) }
                Screen.QUALIFYING -> DetailScaffold("QUALIFICAÇÃO", {}) { Qualifying(snapshot!!, selectedMode, selectedTyre, {selectedMode=it}, {selectedTyre=it}, ::startRace) }
                Screen.RACE -> DetailScaffold("PIT WALL", {}) { Race(snapshot!!, drivers.map{it.name}, ::advanceRace) { snapshot=engine.choose(it) } }
                Screen.RESULT -> DetailScaffold("RESULTADO", {}) { Result(result!!, ::nextRound) }
            }
        }
    }
}

@Composable private fun AppScaffold(title:String, nav:Nav, select:(Nav)->Unit, onMore:()->Unit, content:@Composable ColumnScope.()->Unit) {
    Column(Modifier.fillMaxSize()) { TopBar(title, onMore); Column(Modifier.weight(1f)) { content() }; BottomNav(nav, select) }
}
@Composable private fun DetailScaffold(title:String, back:()->Unit, content:@Composable ColumnScope.()->Unit) { Column(Modifier.fillMaxSize()) { TopBar(title, back); Column(Modifier.weight(1f)) { content() } } }
@Composable private fun TopBar(title:String, action:()->Unit) { Row(Modifier.fillMaxWidth().padding(horizontal=16.dp,vertical=12.dp), verticalAlignment=Alignment.CenterVertically, horizontalArrangement=Arrangement.SpaceBetween) { Text("F1 MANAGER",color=Red,fontWeight=FontWeight.Black,letterSpacing=1.sp); Text(title,color=Color.White,fontWeight=FontWeight.Bold,maxLines=1,overflow=TextOverflow.Ellipsis); Text("⋮",color=Color.White,fontSize=25.sp,modifier=Modifier.clickable{action()}) } }
@Composable private fun BottomNav(selected:Nav, select:(Nav)->Unit) { Row(Modifier.fillMaxWidth().background(Color(0xFF101216)).padding(6.dp), horizontalArrangement=Arrangement.SpaceEvenly) { listOf(Nav.HOME to "⌂",Nav.TEAM to "♟",Nav.CAR to "▰",Nav.CALENDAR to "▦",Nav.STANDINGS to "≡").forEach{(n,l)-> Column(horizontalAlignment=Alignment.CenterHorizontally,modifier=Modifier.weight(1f).clickable{select(n)}.padding(5.dp)){Text(l,color=if(selected==n)Red else Muted,fontSize=20.sp);Text(n.name,color=if(selected==n)Color.White else Muted,fontSize=9.sp,fontWeight=FontWeight.Bold)}} } }

@Composable private fun Home(team:String, car:com.f1teammanager.core.season.CarSpec, drivers:List<com.f1teammanager.core.season.DriverDefinition>, round:RoundDefinition, onStart:()->Unit, onDrivers:()->Unit) {
    LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
        item { Text("DASHBOARD",color=Color.White,fontSize=26.sp,fontWeight=FontWeight.Black); Text("Temporada 2026 • Round ${round.round}/24",color=Muted) }
        item { HeroCard(team,car.model) }
        item { SectionTitle("PRÓXIMA CORRIDA"); RaceHero(round,onStart) }
        item { Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){ StatCard("CAMPEONATO","P${team.hashCode().mod(10)+1}","Construtores",Modifier.weight(1f)); StatCard("PONTOS","0","Temporada",Modifier.weight(1f)); StatCard("ORÇAMENTO","€ 41,5M","Saldo",Modifier.weight(1f)) } }
        item { SectionTitle("EQUIPE"); Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(Panel)){Column(Modifier.padding(14.dp)){Text("PILOTOS",color=Red,fontWeight=FontWeight.Bold); drivers.forEach{Text(it.name,color=Color.White,fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=7.dp))}; Text("Ver perfil completo →",color=Muted,modifier=Modifier.clickable{onDrivers()}.padding(top=8.dp))}} }
        item { Button(onClick=onStart,modifier=Modifier.fillMaxWidth().height(54.dp),shape=RoundedCornerShape(8.dp)){Text("INICIAR FIM DE SEMANA",fontWeight=FontWeight.Black)} }
    }
}
@Composable private fun HeroCard(team:String, model:String){ Box(Modifier.fillMaxWidth().height(180.dp).clip(RoundedCornerShape(12.dp)).background(Panel)){Column(Modifier.fillMaxSize().padding(18.dp),verticalArrangement=Arrangement.Bottom){Text(team.uppercase(),color=Color.White,fontSize=25.sp,fontWeight=FontWeight.Black);Text(model,color=Red,fontWeight=FontWeight.Bold);Text("MODELO ESPECÍFICO DA EQUIPE",color=Muted,fontSize=11.sp)}} }
@Composable private fun RaceHero(r:RoundDefinition,onStart:()->Unit){Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(Panel)){Column(Modifier.padding(16.dp)){Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Column{Text("ROUND ${r.round}",color=Red,fontWeight=FontWeight.Bold);Text(r.grandPrix,color=Color.White,fontSize=21.sp,fontWeight=FontWeight.Black);Text(r.circuit,color=Muted)};Text("${r.laps} LAPS",color=Color.White,fontWeight=FontWeight.Bold)};Spacer(Modifier.height(12.dp));Button(onClick=onStart,modifier=Modifier.fillMaxWidth()){Text("ABRIR FIM DE SEMANA")}}}}
@Composable private fun SectionTitle(t:String){Text(t,color=Color.White,fontWeight=FontWeight.Black,fontSize=13.sp,letterSpacing=1.sp)}
@Composable private fun StatCard(a:String,b:String,c:String,m:Modifier){Card(m,colors=CardDefaults.cardColors(Panel)){Column(Modifier.padding(11.dp)){Text(a,color=Muted,fontSize=10.sp,fontWeight=FontWeight.Bold);Text(b,color=Color.White,fontSize=19.sp,fontWeight=FontWeight.Black);Text(c,color=Muted,fontSize=10.sp)}}}

@Composable private fun Team(name:String,engine:Int,reliability:Int,drivers:List<com.f1teammanager.core.season.DriverDefinition>,onDrivers:()->Unit){LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){item{HeaderBlock(name,"GESTÃO DA EQUIPE")};item{MetricPanel("FORNECEDOR / MOTOR","Engine",engine,"Confiabilidade",reliability)};item{SectionTitle("PILOTOS TITULARES")};items(drivers){DriverMini(it)};item{Button(onClick=onDrivers,modifier=Modifier.fillMaxWidth()){Text("ABRIR PERFIS")}};item{SectionTitle("INSTALAÇÕES")};item{Facility("FÁBRICA",72)};item{Facility("CENTRO DE P&D",68)};item{Facility("TÚNEL DE VENTO",61)};item{Facility("SIMULADOR",75)}}}
@Composable private fun Drivers(ds:List<com.f1teammanager.core.season.DriverDefinition>){LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){item{HeaderBlock("PILOTOS","PERFIS E ATRIBUTOS")};items(ds){d->Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(Panel)){Column(Modifier.padding(14.dp)){Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text(d.name,color=Color.White,fontWeight=FontWeight.Black,fontSize=18.sp);Text("${d.speed}",color=Red,fontSize=20.sp,fontWeight=FontWeight.Black)};Text("Velocidade  ${d.speed} • Classificação  ${d.qualifying}",color=Muted);Text("Ultrapassagem ${d.overtaking} • Defesa ${d.defense} • Consistência ${d.consistency}",color=Muted);Text("Chuva ${d.wet} • Pneus ${d.tyre}",color=Muted)}}}}}
@Composable private fun DriverMini(d:com.f1teammanager.core.season.DriverDefinition){Row(Modifier.fillMaxWidth().background(Panel,RoundedCornerShape(8.dp)).padding(13.dp),horizontalArrangement=Arrangement.SpaceBetween){Text(d.name,color=Color.White,fontWeight=FontWeight.Bold);Text("OVR ${((d.speed+d.qualifying+d.overtaking+d.defense+d.consistency+d.wet+d.tyre)/7)}",color=Red,fontWeight=FontWeight.Black)}}
@Composable private fun Facility(name:String,v:Int){Column(Modifier.fillMaxWidth().background(Panel,RoundedCornerShape(8.dp)).padding(12.dp)){Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text(name,color=Color.White,fontWeight=FontWeight.Bold);Text("Nível ${v/10}",color=Muted)};LinearProgressIndicator(progress={v/100f},modifier=Modifier.fillMaxWidth().padding(top=8.dp),color=Red,trackColor=Line)}}
@Composable private fun MetricPanel(title:String,a:String,av:Int,b:String,bv:Int){Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(Panel)){Column(Modifier.padding(14.dp)){Text(title,color=Red,fontWeight=FontWeight.Bold);MetricLine(a,av);MetricLine(b,bv)}}}
@Composable private fun MetricLine(l:String,v:Int){Column(Modifier.padding(top=9.dp)){Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text(l,color=Muted);Text(v.toString(),color=Color.White,fontWeight=FontWeight.Bold)};LinearProgressIndicator(progress={v/100f},modifier=Modifier.fillMaxWidth().padding(top=4.dp),color=Red,trackColor=Line)}}
@Composable private fun Car(c:com.f1teammanager.core.season.CarSpec,engine:Int,reliability:Int){LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){item{HeaderBlock(c.model,"CARRO DA EQUIPE")};item{Text("DESEMPENHO",color=Color.White,fontWeight=FontWeight.Black)};item{MetricPanel("PACOTE", "Velocidade máxima",c.topSpeed,"Aceleração",c.acceleration)};item{MetricPanel("CURVAS", "Baixa velocidade",c.lowSpeed,"Alta velocidade",c.highSpeed)};item{MetricPanel("CONTROLE", "Frenagem",c.braking,"Consistência",c.consistency)};item{MetricPanel("OPERAÇÃO","Motor",engine,"Confiabilidade",reliability)};item{SectionTitle("DESENVOLVIMENTO ATIVO")};item{Project("AERODINÂMICA",74,"12 dias")};item{Project("CHASSI",58,"21 dias")};item{Project("UNIDADE DE POTÊNCIA",41,"34 dias")}}}
@Composable private fun Project(n:String,v:Int,time:String){Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(Panel)){Column(Modifier.padding(13.dp)){Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text(n,color=Color.White,fontWeight=FontWeight.Bold);Text("$v%",color=Red,fontWeight=FontWeight.Black)};LinearProgressIndicator(progress={v/100f},modifier=Modifier.fillMaxWidth().padding(vertical=7.dp),color=Red,trackColor=Line);Text("Conclusão estimada: $time",color=Muted,fontSize=11.sp)}}}
@Composable private fun Calendar(idx:Int){LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(5.dp)){item{HeaderBlock("CALENDÁRIO 2026","24 GRAND PRIX")};items(WorldDatabase.rounds){r->Row(Modifier.fillMaxWidth().background(if(r.round-1==idx) Color(0xFF2A1010) else Panel,RoundedCornerShape(7.dp)).padding(12.dp),horizontalArrangement=Arrangement.SpaceBetween){Column{Text("ROUND ${r.round}",color=if(r.round-1==idx)Red else Muted,fontSize=10.sp,fontWeight=FontWeight.Bold);Text(r.grandPrix,color=Color.White,fontWeight=FontWeight.Bold);Text(r.circuit,color=Muted)};Text("${r.laps}v",color=Color.White,fontWeight=FontWeight.Bold)}}}}
@Composable private fun Standings(teamId:Int){LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(4.dp)){item{HeaderBlock("CAMPEONATO","PILOTOS • CONSTRUTORES")};items(WorldDatabase.drivers.take(60).sortedByDescending{it.speed}){d->Row(Modifier.fillMaxWidth().background(if(d.teamId==teamId) Color(0xFF201111) else Panel,RoundedCornerShape(5.dp)).padding(10.dp),horizontalArrangement=Arrangement.SpaceBetween){Text("${WorldDatabase.drivers.indexOf(d)+1}. ${d.name}",color=Color.White,fontWeight=if(d.teamId==teamId)FontWeight.Bold else FontWeight.Normal);Text("0 PTS",color=Muted)}}}}
@Composable private fun Finance(){LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){item{HeaderBlock("FINANÇAS","TEMPORADA 2026")};item{StatCard("ORÇAMENTO","€ 41,5M","Disponível",Modifier.fillMaxWidth())};item{MetricPanel("MOVIMENTAÇÃO","Receitas",8_400,"Despesas",3_100)};item{SectionTitle("ÚLTIMAS MOVIMENTAÇÕES")};items(listOf("Bônus de participação +€2,4M","Operação do GP -€0,8M","Desenvolvimento -€1,1M","Patrocínio +€4,0M")){Text(it,color=Color.White,modifier=Modifier.fillMaxWidth().background(Panel,RoundedCornerShape(7.dp)).padding(13.dp))}}}

@Composable private fun HeaderBlock(a:String,b:String){Column{Text(a,color=Color.White,fontSize=25.sp,fontWeight=FontWeight.Black);Text(b,color=Red,fontSize=11.sp,fontWeight=FontWeight.Bold,letterSpacing=1.sp)}}
@Composable private fun TeamSelect(onSelect:(Int)->Unit){Column(Modifier.fillMaxSize().padding(16.dp)){HeaderBlock("NOVA CARREIRA","ESCOLHA SUA EQUIPE");Spacer(Modifier.height(12.dp));LazyColumn(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(6.dp)){items(WorldDatabase.teams){t->val car=CarCatalog.forTeam(t.id);Row(Modifier.fillMaxWidth().background(Panel,RoundedCornerShape(8.dp)).clickable{onSelect(t.id)}.padding(13.dp),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(t.name,color=Color.White,fontWeight=FontWeight.Black);Text(car.model,color=Red,fontSize=12.sp);Text("Motor ${t.engine} • Confiabilidade ${t.reliability}",color=Muted,fontSize=11.sp)};Text("›",color=Red,fontSize=30.sp)}}}}}

@Composable private fun Weekend(r:RoundDefinition,start:()->Unit){LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){item{HeaderBlock(r.grandPrix,"ROUND ${r.round} • ${r.circuit}")};item{RaceHero(r,start)};item{InfoPanel("QUALIFICAÇÃO","Define o grid de largada");InfoPanel("ESTRATÉGIA","Postura + pneu inicial");InfoPanel("CORRIDA","Decisões VSC, SC e bandeira vermelha")};item{Button(onClick=start,modifier=Modifier.fillMaxWidth()){Text("COMEÇAR QUALIFICAÇÃO")}}}}
@Composable private fun InfoPanel(a:String,b:String){Row(Modifier.fillMaxWidth().background(Panel,RoundedCornerShape(8.dp)).padding(14.dp),horizontalArrangement=Arrangement.SpaceBetween){Column{Text(a,color=Color.White,fontWeight=FontWeight.Bold);Text(b,color=Muted,fontSize=11.sp)};Text("›",color=Red,fontSize=24.sp)}}
@Composable private fun Qualifying(s:CareerWeekendEngine.SessionSnapshot,mode:DriverStrategyMode,tyre:Tyre,onMode:(DriverStrategyMode)->Unit,onTyre:(Tyre)->Unit,start:()->Unit){
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("GRID",color=Color.White,fontSize=24.sp,fontWeight=FontWeight.Black)
        Text("Escolha a postura e o pneu antes da corrida",color=Muted)
        Spacer(Modifier.height(10.dp))
        ChoiceRow("POSTURA",mode.name,DriverStrategyMode.entries.toList(),onMode)
        ChoiceRow("PNEU",tyre.name,Tyre.entries.toList(),onTyre)
        LazyColumn(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(3.dp)) {
            items(s.grid?.grid.orEmpty()) { e ->
                Row(Modifier.fillMaxWidth().background(Panel,RoundedCornerShape(5.dp)).padding(9.dp),horizontalArrangement=Arrangement.SpaceBetween) {
                    Text("P${e.position}",color=Red,fontWeight=FontWeight.Black)
                    Text(WorldDatabase.drivers.firstOrNull { it.id == e.driverId }?.name ?: "Piloto ${e.driverId}",color=Color.White)
                    Text(formatMs(e.lapTimeMs),color=Muted)
                }
            }
        }
        Button(onClick=start,modifier=Modifier.fillMaxWidth().height(52.dp)) { Text("INICIAR CORRIDA") }
    }
}
@Composable private fun <T> ChoiceRow(title:String,current:String,values:List<T>,select:(T)->Unit){Column{Text(title,color=Muted,fontSize=10.sp,fontWeight=FontWeight.Bold);Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(6.dp)){values.forEach{v->FilterChip(selected=v.toString()==current,onClick={select(v)},label={Text(v.toString())})}}}}
@Composable private fun Race(s:CareerWeekendEngine.SessionSnapshot,names:List<String>,advance:()->Unit,decision:(ManagerDecisionAction)->Unit){Column(Modifier.fillMaxSize().padding(16.dp)){Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Column{Text("PIT WALL",color=Color.White,fontSize=25.sp,fontWeight=FontWeight.Black);Text("VOLTA ${s.lap}/${s.totalLaps}",color=Red,fontWeight=FontWeight.Bold)};Text(statusLabel(s.neutral),color=if(s.neutral==Neutralisation.GREEN)Green else Red,fontWeight=FontWeight.Black)};Spacer(Modifier.height(10.dp));names.forEachIndexed{i,n->Row(Modifier.fillMaxWidth().background(Panel,RoundedCornerShape(7.dp)).padding(11.dp),horizontalArrangement=Arrangement.SpaceBetween){Text(n,color=Color.White,fontWeight=FontWeight.Bold);Text(s.plans.values.elementAtOrNull(i)?.mode?.name?:"EQUILIBRADO",color=Red)}};Spacer(Modifier.height(10.dp));Card(Modifier.fillMaxWidth().weight(1f),colors=CardDefaults.cardColors(Panel)){LazyColumn(Modifier.padding(12.dp)){items(s.events.takeLast(12)){e->Text("${e.lap} • ${e.detail}",color=Color.White,modifier=Modifier.padding(vertical=3.dp))}}};Spacer(Modifier.height(10.dp));Button(onClick=advance,enabled=s.decision==null&&!s.completed,modifier=Modifier.fillMaxWidth().height(52.dp)){Text(if(s.completed)"CORRIDA FINALIZADA" else "AVANÇAR VOLTA")};s.decision?.let{d->AlertDialog(onDismissRequest={},title={Text(d.request.type.name.replace('_',' '))},text={Text("${d.driverName}: ${d.request.message}")},confirmButton={Column(Modifier.fillMaxWidth()){d.request.options.forEach{a->Button(onClick={decision(a)},modifier=Modifier.fillMaxWidth().padding(2.dp)){Text(actionLabel(a))}}})}}}}
@Composable private fun Result(r:RaceResult,next:()->Unit){Column(Modifier.fillMaxSize().padding(16.dp)){HeaderBlock("RESULTADO","CORRIDA FINALIZADA");LazyColumn(Modifier.weight(1f),contentPadding=PaddingValues(vertical=12.dp),verticalArrangement=Arrangement.spacedBy(3.dp)){items(r.classification){f->Row(Modifier.fillMaxWidth().background(if(f.position<=3)Color(0xFF251414) else Panel,RoundedCornerShape(5.dp)).padding(10.dp),horizontalArrangement=Arrangement.SpaceBetween){Text("P${f.position}",color=if(f.position<=3)Red else Muted,fontWeight=FontWeight.Black);Text(f.driverName,color=Color.White);Text(f.status,color=Muted)}}};Text("Safety Car ${r.safetyCarLaps} • VSC ${r.vscLaps}",color=Muted);Button(onClick=next,modifier=Modifier.fillMaxWidth()){Text("PRÓXIMO GP")}}}
private fun statusLabel(n:Neutralisation)=when(n){Neutralisation.GREEN->"GREEN FLAG";Neutralisation.VSC->"VSC";Neutralisation.SAFETY_CAR->"SAFETY CAR"}
private fun actionLabel(a:ManagerDecisionAction)=when(a){ManagerDecisionAction.BOX->"BOX";ManagerDecisionAction.STAY_OUT->"MANTER";ManagerDecisionAction.EXTEND_STINT->"ESTENDER STINT";ManagerDecisionAction.CHANGE_STRATEGY->"MUDAR ESTRATÉGIA";ManagerDecisionAction.RESTART_ATTACK->"RELARGADA • ATAQUE";ManagerDecisionAction.RESTART_BALANCED->"RELARGADA • EQUILIBRADO";ManagerDecisionAction.RESTART_DEFENSE->"RELARGADA • DEFESA";ManagerDecisionAction.CHANGE_TYRE_SOFT->"SOFT";ManagerDecisionAction.CHANGE_TYRE_MEDIUM->"MEDIUM";ManagerDecisionAction.CHANGE_TYRE_HARD->"HARD";ManagerDecisionAction.CHANGE_TYRE_INTERMEDIATE->"INTERMEDIÁRIO";ManagerDecisionAction.CHANGE_TYRE_WET->"WET"}
private fun formatMs(ms:Long)="%d:%02d.%03d".format(ms/60000,(ms/1000)%60,ms%1000)
