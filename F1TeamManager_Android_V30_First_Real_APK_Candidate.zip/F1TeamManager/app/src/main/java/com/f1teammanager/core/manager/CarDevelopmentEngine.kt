package com.f1teammanager.core.manager

class CarDevelopmentEngine {
    fun start(state:TeamManagerState, component:CarComponent):TeamManagerState {
        require(state.car.activeProject == null) { "Já existe um projeto em desenvolvimento" }
        val facility = when(component) {
            CarComponent.AERODYNAMICS -> Facility.WIND_TUNNEL
            CarComponent.CHASSIS -> Facility.FACTORY
            CarComponent.ENGINE -> Facility.TESTING
            CarComponent.RELIABILITY -> Facility.TESTING
        }
        val level = state.car.facilities[facility] ?: 1
        val cost = 450_000L + level * 150_000L
        require(state.finance.budget >= cost) { "Orçamento insuficiente" }
        val project = DevelopmentProject(component, remainingRounds=maxOf(1, 4-level/3), level=level)
        val finance = state.finance.transact(-cost, "P&D ${component.name}")
        return state.copy(car=state.car.copy(activeProject=project), finance=finance)
    }

    fun advanceRound(state:TeamManagerState):TeamManagerState {
        val p = state.car.activeProject ?: return state
        if (p.remainingRounds > 1) return state.copy(car=state.car.copy(activeProject=p.copy(remainingRounds=p.remainingRounds-1)))
        val bonus = 1 + p.level/2
        val c = when(p.component) {
            CarComponent.AERODYNAMICS -> state.car.copy(aerodynamics=state.car.aerodynamics+bonus, activeProject=null)
            CarComponent.CHASSIS -> state.car.copy(chassis=state.car.chassis+bonus, activeProject=null)
            CarComponent.ENGINE -> state.car.copy(engine=state.car.engine+bonus, activeProject=null)
            CarComponent.RELIABILITY -> state.car.copy(reliability=state.car.reliability+bonus, activeProject=null)
        }.normalized()
        return state.copy(car=c, history=state.history+"Projeto concluído: ${p.component}")
    }

    fun upgradeFacility(state:TeamManagerState, facility:Facility):TeamManagerState {
        val current=state.car.facilities[facility] ?: 1
        require(current < 10) { "Instalação já está no nível máximo" }
        val cost=1_000_000L*current
        require(state.finance.budget >= cost) { "Orçamento insuficiente" }
        val facilities=state.car.facilities.toMutableMap(); facilities[facility]=current+1
        return state.copy(car=state.car.copy(facilities=facilities), finance=state.finance.transact(-cost,"Upgrade ${facility.name} para ${current+1}"))
    }
}
