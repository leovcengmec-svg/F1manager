package com.f1teammanager.core.game

import com.f1teammanager.core.manager.*
import com.f1teammanager.core.career.CareerRaceIntegration
import com.f1teammanager.core.race.*
import com.f1teammanager.core.season.*

/** V23: single source of truth for career state, management and the playable race weekend. */
class UnifiedGameEngine(
    val seed:Int = 20261003,
    initialManager:TeamManagerState? = null,
    initialSeason:SeasonState = SeasonState()
) {
    private val driverMarket = DriverMarketEngine(seed)
    private val actions = ManagerActions()
    private val development = CarDevelopmentEngine()
    private val finance = FinanceEngine()
    private val market = ManagerMarketEngine()
    private var manager:TeamManagerState = initialManager ?: defaultManager()
    private var season:SeasonState = initialSeason
    private var weekend:CareerRaceIntegration? = null
    private var raceFinishedApplied = false
    private var messages = mutableListOf<String>()

    init { require(manager.season == season.season) { "Temporada do manager e campeonato divergentes" }; ensureGrid() }

    fun snapshot():InterfaceSnapshot {
        val team = WorldDatabase.teams.first { it.id == manager.playerTeamId }
        val race = weekend?.snapshot()?.let { s ->
            val player = s.classification.firstOrNull { it.teamName == team.name }
            val plan = s.plans[player?.driverId]
            RaceCard(s.phase,s.lap,s.totalLaps,player?.position,player?.tyre, null, null,
                plan?.let { when(it.mode){DriverStrategyMode.ATTACK->DriverPosture.ATTACK;DriverStrategyMode.BALANCED->DriverPosture.BALANCED;DriverStrategyMode.DEFENSE->DriverPosture.DEFENSE}},
                s.neutral, s.decision?.request?.let { PendingManagerDecision(it.type,it.lap,it.driverId,it.message) }, emptyList(), s.completed)
        }
        val cards=WorldDatabase.rounds.mapIndexed { i,r -> CalendarCard(r.round,r.grandPrix,r.circuit,r.laps,r.round==season.currentRound,r.round<season.currentRound) }
        val rows=WorldDatabase.drivers.map { d ->
            val t=WorldDatabase.teams.first { it.id==d.teamId }
            StandingCard(0,d.id,d.name,t.name,season.standings[d.id]?:0,season.wins[d.id]?:0,season.podiums[d.id]?:0)
        }.sortedWith(compareByDescending<StandingCard>{it.points}.thenByDescending{it.wins}.thenByDescending{it.podiums}.thenBy{it.driverId})
            .mapIndexed { i,r -> r.copy(position=i+1) }
        val drivers=WorldDatabase.drivers.filter { it.teamId==manager.playerTeamId }.map { d ->
            val overall=((d.speed+d.qualifying+d.overtaking+d.defense+d.consistency+d.wet+d.tyre)/7)
            DriverCard(d.id,d.name,team.name,overall,"Piloto")
        }
        val c=manager.car
        return InterfaceSnapshot(manager.season,manager.round,team.id,team.name,manager.manager.name,manager.manager.reputation,
            cards.getOrElse((manager.round-1).coerceIn(0,23)){cards.last()},cards,rows,
            FinanceCard(manager.finance.budget,manager.finance.seasonIncome,manager.finance.seasonExpenses,manager.finance.seasonIncome-manager.finance.seasonExpenses),
            CarCard(c.aerodynamics,c.chassis,c.engine,c.reliability,(c.aerodynamics+c.chassis+c.engine+c.reliability)/4,c.activeProject?.component?.name),drivers,race,messages.takeLast(20))
    }

    fun startWeekend():InterfaceSnapshot {
        check(weekend==null) { "Fim de semana já aberto" }
        check(manager.round in 1..24) { "Temporada encerrada" }
        val rd=WorldDatabase.rounds[manager.round-1]
        val team=WorldDatabase.teams.first { it.id==manager.playerTeamId }
        val perf=AIManagerEngine().performanceModifier(manager.staff,manager.sponsor,manager.engineSupplier,manager.tyreSupplier)
        val participants=DynamicGridEngine().participants(manager.driverMarket,manager.car,manager.playerTeamId,perf)
        val circuit=RaceCircuit(rd.round,rd.circuit,rd.laps,rd.baseLapTimeMs,rd.powerFactor,rd.overtakingFactor,crashRisk=rd.crashRisk,reliabilityRisk=rd.reliabilityRisk,safetyCarRisk=rd.safetyCarRisk)
        weekend=CareerRaceIntegration(manager.season,circuit,participants,team.id,seed+manager.round)
        weekend!!.begin(); messages += "${rd.grandPrix}: classificação concluída"
        return snapshot()
    }

    fun setStrategy(driverId:Int,posture:DriverPosture,tyre:Tyre):InterfaceSnapshot { requireWeekend(); weekend!!.setStrategy(driverId,posture,tyre); return snapshot() }
    fun advanceRace():InterfaceSnapshot { requireWeekend(); weekend!!.advance(); return snapshot() }
    fun choose(action:ManagerDecisionAction):InterfaceSnapshot { requireWeekend(); weekend!!.choose(action); return snapshot() }
    fun chooseRedFlag(tyre:Tyre,posture:DriverPosture):InterfaceSnapshot { requireWeekend(); weekend!!.chooseRedFlag(tyre,posture); return snapshot() }

    fun finishWeekend():InterfaceSnapshot {
        val w=weekend ?: error("Nenhum fim de semana aberto")
        val summary=w.summary()
        check(summary.status==SessionStatus.FINISHED) { "A corrida ainda não terminou" }
        if (!raceFinishedApplied) {
            val result=w.result()
            val points=season.standings.toMutableMap(); val wins=season.wins.toMutableMap(); val pods=season.podiums.toMutableMap(); val starts=season.starts.toMutableMap()
            result.classification.forEach { f ->
                if(f.status!="DNF") starts[f.driverId]=(starts[f.driverId]?:0)+1
                points[f.driverId]=(points[f.driverId]?:0)+(result.points[f.driverId]?:0)
                if(f.status!="DNF" && f.position==1) wins[f.driverId]=(wins[f.driverId]?:0)+1
                if(f.status!="DNF" && f.position<=3) pods[f.driverId]=(pods[f.driverId]?:0)+1
            }
            val teamName=WorldDatabase.teams.first{it.id==manager.playerTeamId}.name
            val player=result.classification.filter{it.teamName==teamName}
            val teamPoints=player.sumOf{result.points[it.driverId]?:0}
            val best=player.minOfOrNull{if(it.status=="DNF")999 else it.position}?:999
            val allDnf=player.isNotEmpty() && player.all{it.status=="DNF"}
            manager=finance.applyRace(manager,best,teamPoints,allDnf)
            manager=development.advanceRound(manager)
            manager=manager.copy(round=manager.round+1,manager=manager.manager.copy(experience=manager.manager.experience+1,reputation=(manager.manager.reputation+if(teamPoints>0)1 else 0).coerceAtMost(100)))
            season=season.copy(currentRound=season.currentRound+1,standings=points,wins=wins,podiums=pods,starts=starts)
            messages += "GP concluído: P${best.coerceAtMost(99)} | ${teamPoints} ponto(s)"
            raceFinishedApplied=true
        }
        weekend=null
        return snapshot()
    }

    fun applyManagement(action:ManagementAction):InterfaceSnapshot { manager=actions.apply(manager,action); messages += "Ação: ${action.name}"; return snapshot() }
    fun hireStaff(member:StaffMember):InterfaceSnapshot { manager=market.hireStaff(manager,member); messages += "Contratado: ${member.name}"; return snapshot() }
    fun replaceSupplier(supplier:SupplierContract):InterfaceSnapshot { manager=market.replaceSupplier(manager,supplier); return snapshot() }
    fun replaceSponsor(sponsor:SponsorContract):InterfaceSnapshot { manager=market.replaceSponsor(manager,sponsor); return snapshot() }
    fun managerState():TeamManagerState=manager
    fun seasonState():SeasonState=season

    private fun ensureGrid(){
        if(manager.driverMarket.contracts.isEmpty()) manager=manager.copy(driverMarket=driverMarket.initialState(manager.season))
        require(DynamicGridEngine().validate(manager.driverMarket).isEmpty()) { DynamicGridEngine().validate(manager.driverMarket).joinToString("; ") }
    }
    private fun defaultManager():TeamManagerState {
        val t=WorldDatabase.teams.first()
        val car=TeamCarState(t.baseCar,t.baseCar,t.engine,t.reliability)
        return TeamManagerState(playerTeamId=t.id,car=car,finance=TeamFinanceState(35_000_000),driverMarket=driverMarket.initialState(2026))
    }
    private fun requireWeekend(){ check(weekend!=null){"Inicie o fim de semana antes"} }
}
