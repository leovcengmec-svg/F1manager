package com.f1teammanager.core.manager

class ManagerMarketEngine(private val market: StaffMarketEngine = StaffMarketEngine()) {
    fun hireStaff(state: TeamManagerState, member: StaffMember): TeamManagerState {
        val normalized=member.normalized()
        val existing=state.staff.filterNot { it.role==normalized.role }
        val cost=normalized.salary/2
        require(state.finance.budget >= cost) { "Orçamento insuficiente" }
        val finance=state.finance.transact(-cost,"Bônus de contratação: ${normalized.name}")
        return state.copy(staff=existing+(normalized.copy(teamId=state.playerTeamId)),finance=finance,
            history=(state.history+"Contratado ${normalized.name}").takeLast(100))
    }

    fun replaceSponsor(state: TeamManagerState, sponsor: SponsorContract): TeamManagerState {
        require(state.manager.reputation >= sponsor.minimumReputation) { "Reputação insuficiente para o patrocinador" }
        return state.copy(sponsor=sponsor,finance=state.finance.transact(sponsor.upfront,"Novo patrocinador: ${sponsor.name}"),
            history=(state.history+"Patrocinador ${sponsor.name}").takeLast(100))
    }

    fun replaceSupplier(state: TeamManagerState, supplier: SupplierContract): TeamManagerState {
        val normalized=supplier.normalized()
        val finance=state.finance.transact(-normalized.annualCost,"Contrato fornecedor: ${normalized.name}")
        return when(normalized.type) {
            SupplierType.ENGINE -> state.copy(engineSupplier=normalized,finance=finance)
            SupplierType.TYRE -> state.copy(tyreSupplier=normalized,finance=finance)
        }
    }

    fun availableStaff(state: TeamManagerState): List<ContractOffer> = market.staffPool().map { market.generateOffer(it,state) }
}
