package com.f1teammanager.core.season

import com.f1teammanager.core.race.RaceParticipant

data class TeamDefinition(val id:Int,val name:String,val driverIds:List<Int>,val baseCar:Int,val engine:Int,val reliability:Int)
data class DriverDefinition(val id:Int,val name:String,val teamId:Int,val speed:Int,val qualifying:Int,val overtaking:Int,val defense:Int,val consistency:Int,val wet:Int,val tyre:Int,val experience:Int)
data class RoundDefinition(val round:Int,val grandPrix:String,val circuit:String,val laps:Int,val baseLapTimeMs:Long,val powerFactor:Double,val overtakingFactor:Double,val crashRisk:Double=1.0,val reliabilityRisk:Double=1.0,val safetyCarRisk:Double=1.0)
data class ChampionshipRow(val driverId:Int,val driverName:String,val teamId:Int,val teamName:String,val points:Int,val wins:Int,val podiums:Int,val starts:Int)
data class SeasonState(val season:Int=2026,val currentRound:Int=1,val standings:Map<Int,Int> = emptyMap(),val wins:Map<Int,Int> = emptyMap(),val podiums:Map<Int,Int> = emptyMap(),val starts:Map<Int,Int> = emptyMap())

fun DriverDefinition.toParticipant(team: TeamDefinition)=RaceParticipant(id,name,team.id,team.name,speed,qualifying,overtaking,defense,consistency,team.baseCar,team.engine,tyre,tyre,experience,team.reliability,0)
