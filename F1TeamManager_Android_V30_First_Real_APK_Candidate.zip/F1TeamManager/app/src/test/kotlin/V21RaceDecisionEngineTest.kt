import com.f1teammanager.core.race.*

fun main() {
    val engine = RaceDecisionEngine()
    var s = RaceState(0, 30, 100, 0, 0, Tyre.MEDIUM, RacePosture.BALANCED)
    repeat(8) { s = engine.advance(s) }
    check(s.lap == 8 && !s.paused)
    s = engine.advance(s)
    check(s.event == RaceEvent.VSC && s.paused)
    s = engine.resolve(s, ManagerAction.BOX)
    check(!s.paused && s.pitStops == 1 && s.tyreAge == 0)
    repeat(9) {
        if (!s.paused) s = engine.advance(s)
        if (s.event == RaceEvent.SAFETY_CAR) s = engine.resolve(s, ManagerAction.MAINTAIN)
        if (s.event == RaceEvent.TYRE_DEGRADATION || s.event == RaceEvent.FUEL_LOW) s = engine.resolve(s, ManagerAction.EXTEND)
        if (s.event == RaceEvent.RED_FLAG) s = engine.restartAfterRedFlag(s, RedFlagRestart(Tyre.HARD, RacePosture.DEFENSE))
    }
    while (!s.finished) {
        if (s.paused) {
            s = if (s.event == RaceEvent.RED_FLAG)
                engine.restartAfterRedFlag(s, RedFlagRestart(Tyre.MEDIUM, RacePosture.ATTACK))
            else engine.resolve(s, ManagerAction.MAINTAIN)
        } else s = engine.advance(s)
    }
    check(s.finished && s.lap == 30)
    println("V21_SMOKE_OK lap=${s.lap} stops=${s.pitStops}")
}
