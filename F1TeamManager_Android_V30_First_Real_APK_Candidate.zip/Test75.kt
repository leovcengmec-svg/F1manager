import com.f1teammanager.core.season.DriverProfileCatalog
fun main(){
    val names = DriverProfileCatalog.profiles.keys.toList()
    check(names.size == 100) { "Expected 100 profiles, got ${names.size}" }
    val counts = mutableMapOf<String,Int>()
    for (name in names) {
        val p=DriverProfileCatalog.profile(name)
        val ceiling=DriverProfileCatalog.ceiling(p.driverClass)
        val overall=p.ratings.sum()/7
        val target=kotlin.math.round(ceiling*0.75).toInt()
        check(overall==target) { "$name overall=$overall target=$target attrs=${p.ratings.contentToString()}" }
        check(p.ratings.all{it in 40..ceiling}) { "$name invalid attrs=${p.ratings.contentToString()} ceiling=$ceiling" }
        counts[p.driverClass]=(counts[p.driverClass]?:0)+1
        println("$name|${p.driverClass}|${p.ratings.joinToString(",")}|Overall=$overall")
    }
    println("COUNTS=$counts")
}
