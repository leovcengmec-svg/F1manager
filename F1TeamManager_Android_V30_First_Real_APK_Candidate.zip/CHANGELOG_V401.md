# V401 — Cards dos carros no diálogo de instalação

- Aumentada a altura dos cards CARRO 1 e CARRO 2 de 122 dp para 150 dp.
- Mantida a mesma altura para os dois cards.
- O espaço adicional permite exibir integralmente os valores de Desempenho e Confiabilidade, sem alterar a lógica de instalação.
- Nome fixo do ZIP de entrega preservado.
