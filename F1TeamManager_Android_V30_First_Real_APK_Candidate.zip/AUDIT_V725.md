# Auditoria de entrega — V725

## Identificação

- Base recebida: V724 (`VersionCode 724`, `VersionName 0.724.0`).
- Entrega: V725 (`VersionCode 725`, `VersionName 0.725.0`).
- Nome público: F1 Team Manager V30.
- Nome do ZIP: `F1TeamManager_Android_V30_First_Real_APK_Candidate.zip` (preservado).

## Resultado por módulo

| Módulo | Resultado da implementação |
|---|---|
| Limite de Overall do próximo carro | Piso e teto unificados no construtor compartilhado, inclusive em projeções |
| Confiabilidade | Mantida por componente instalado; ganhos continuam no fluxo independente de pesquisa/fabricação |
| Idade | 18–45; transição para 18 antes do primeiro GP da nova temporada |
| Reinício | Corte inteiro de 30% em cada atributo, piso 40; sem recuperação de 50% |
| Regressão natural | Débito independente do desenvolvimento esportivo, com notícias distintas |
| Política da IA | Caixa livre, reservas/obrigações, meta progressiva, teto de €150M e motivos persistidos |
| Gráfico | Overall/sete atributos, snapshots reais, ciclos separados, sem retroconstrução |
| Backup | Preferências com snapshots incluídas no pacote de backup e restauração; migração pós-importação V724 |

## Testes direcionados

- Compilação de fontes puras do núcleo com Kotlin K2: aprovada.
- 46 testes direcionados: aprovados (inclui a suíte AITeamInvestmentV652Test).
- Smoke test: aprovado.

## Limitações e pendências

- Não foi possível fazer build Android oficial porque o ambiente não contém `gradle`, `gradlew` nem Android SDK.
- A tela Compose e `CareerPreferences` dependem do Android SDK e não foram compilados oficialmente nesta sessão.
- Nenhum APK foi gerado.
- As simulações longas (5, 10, 15 e 20 temporadas), teste de instalação em Android e verificação visual em dispositivo ainda precisam ser executados em ambiente Android/GitHub Actions.
- Em saves V724 nos quais uma versão anterior já aplicou uma recuperação etária aos 43 anos, a migração corrige o calendário sem tentar reconstituir os atributos anteriores, pois não há garantia de um snapshot íntegro que permita desfazer essa alteração sem inventar valores.

## Veredito

A implementação V725 e a validação disponível no ambiente estão concluídas. A versão está pronta como pacote de código-fonte para build no ambiente Android, mas **não deve ser declarada APK aprovada nem equilíbrio de longo prazo certificado** até passar pelo build oficial, testes de integração Android e simulações extensas.
