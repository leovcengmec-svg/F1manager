# Auditoria V364

## Bloco validado

V364 adiciona `InstantSimulationTwoSeasonChainTest`, teste JUnit destinado a executar 60 fins de semana completos pela API real `InstantSimulationService.completeStartedWeekend`: 30 GPs em 2026 e 30 em 2027.

Durante a verificação executável do motor, foi encontrado e corrigido um erro de compilação preexistente em `CareerWeekendEngine.simulateQualifyingInstantly()`: o código tentava ler `finalGrid.entries`, embora `QualifyingResult` exponha a propriedade `grid`. A verificação agora consulta `finalGrid.grid`.

## Verificação executada nesta sessão

- Compilação Kotlin do pacote de domínio `core/race` com `kotlinc`: **aprovada**.
- Execução de harness contra as classes reais do motor: **60/60 fins de semana instantâneos concluídos** em aproximadamente 2,4 segundos.
- Por GP, o harness verificou 80 IDs no grid, fases de qualificação 80/50/20, posições finais 1–80, distância programada e ausência de erros em `RaceResultValidator`.
- ZIP após empacotamento: verificado separadamente.

## Limitações

- O harness executado valida o motor de qualificação/corrida, não a persistência Android de finanças, patrocínios, notificações e evolução.
- O teste JUnit novo foi incluído, mas o Gradle/JUnit não foi executado: não há `gradlew` no pacote nem Gradle instalado no ambiente.
- Build Android e teste de integração da interface/carreira continuam pendentes.
