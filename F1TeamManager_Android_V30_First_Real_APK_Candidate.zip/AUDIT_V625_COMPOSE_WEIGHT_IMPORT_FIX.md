# Auditoria V625 — correção de compilação Compose

## Erro observado
O pipeline falhou em `TeamPrincipalCareerScreen.kt:22:43` porque `androidx.compose.foundation.layout.weight` não pode ser acessado diretamente: o membro é interno na biblioteca Compose.

## Correção
Removido o import explícito `androidx.compose.foundation.layout.weight`. As chamadas `Modifier.weight(...)` permanecem dentro dos escopos `RowScope`/`ColumnScope` correspondentes, onde a extensão é disponibilizada pelo receiver de escopo.

## Escopo preservado
- Nenhuma regra de jogo alterada.
- Nenhum asset alterado.
- `versionCode = 625`, `versionName = "0.625.0"`.

## Limitação
A correção corresponde ao erro exibido no pipeline. A compilação Android completa deve ser reexecutada para verificar possíveis erros subsequentes.
