# V741 — Mercado de pilotos, taxas financeiras e Centro Comercial

## Contratos
- Removida a associação fixa entre Overall/potencial e duração contratual. A duração não consulta mais esses atributos.
- A duração resulta da preferência do piloto (fase etária/carreira) combinada com o planejamento-base da equipe. A negociação continua permitindo de 1 a 5 anos, respeitando o limite de idade já existente.
- Contratos de 1 e 5 anos têm menor peso na distribuição-base; 2, 3 e 4 anos são mais frequentes. Propostas, contrapropostas, avaliação de resposta e renovação consideram a duração negociada.
- O padrão inicial da proposta do jogador passa a ser 3 anos, evitando privilegiar 1 ano apenas por ser o valor inicial do formulário.

## Referência econômica por Overall
- Criada `DriverMarketReferenceTable`, com uma entrada explícita para cada Overall inteiro de 40 a 100.
- Valor-base de mercado: Overall × €500 mil (Overall 40 = €20M; Overall 100 = €50M).
- Salário-base anual: €300 mil + Overall × €228 mil (Overall 40 = €9,42M; Overall 100 = €23,10M).
- Contratação, renovação e transferências consultam o Overall atual do piloto e seus atributos persistidos; classe/evolução não substituem nem congelam a referência.
- Os salários de contratos já assinados não são reescritos retroativamente; a tabela orienta novas propostas e valores-base.

## Taxas por nível financeiro
- Milionária: 100% do valor de mercado atual.
- Estável: 50% do valor de mercado atual.
- Ruim: 20% do valor de mercado atual.
- A classificação compara caixa disponível líquido de obrigações pendentes com a despesa obrigatória projetada para um ano: Milionária cobre 100% ou mais; Estável cobre pelo menos 25%; Ruim fica abaixo de 25%.
- As antigas taxas fixas por tipo de operação (piloto livre/renovação/transferência) deixam de determinar o percentual. A mesma regra de nível financeiro vale para as modalidades de assinatura.
- Removido o crédito de compensação à equipe anterior ao aceitar uma transferência. Somente a equipe contratante registra a despesa de assinatura; a equipe de origem recebe zero.
- A contratação automática para completar vagas na virada da temporada também deixa de usar taxa fixa de 20% e consulta a mesma política financeira.
- Mercado de pilotos passa a exibir Overall, valor de mercado, salário-base e estimativa da taxa para o nível financeiro da equipe.

## Centro Comercial da IA
- Centro Comercial (MARKETING) abaixo do nível 3 torna-se prioridade bloqueante: a IA não inicia outra melhoria enquanto não puder financiar o próximo nível comercial, respeitando reservas operacionais e limites anuais.
- Ao atingir nível 3, o nível 4 passa a ser meta estratégica para equipes Milionárias e Estáveis quando o retorno líquido estimado em duas temporadas for positivo. Equipes Ruins consolidam a situação financeira antes de tentar o nível 4.
- Após atingir nível 3/4, a IA retoma a distribuição estratégica normal das demais instalações.

## Testes e compatibilidade
- Testes adicionados para a tabela Overall 40–100, valores/salários monotônicos e extremos, percentuais 100/50/20, classificação financeira/obrigações, variação por Overall sem alterar duração contratual, distribuição de duração e metas do Centro Comercial.
- Testes anteriores atualizados para a nova referência de salário e para a independência do Overall na duração.
- Carreiras existentes mantêm contratos e salários já assinados; as novas regras são aplicadas a operações futuras.

VersionCode 741 · VersionName 0.741.0 · Base V740.
