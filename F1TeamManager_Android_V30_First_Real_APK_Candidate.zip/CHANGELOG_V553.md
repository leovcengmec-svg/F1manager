# V553 — qualificação proporcional ao tamanho do grid

## Alterações implementadas
- O `CareerWeekendEngine` não exige mais exatamente 80 participantes para iniciar: exige grid válido, IDs únicos e dois pilotos por equipe.
- As vagas para Q2 e Q3 passam a ser calculadas proporcionalmente ao tamanho do grid, mantendo 50 e 20 classificados para o grid original de 80.
- A montagem do grid final calcula as posições das eliminatórias com base nos tamanhos reais das fases, em vez de usar os deslocamentos fixos 21 e 51.
- `InstantSimulationService` valida os tamanhos de grid, fases e resultado a partir do número de participantes recebido.
- A tela de qualificação deixa de considerar 80 como único tamanho válido para reconhecer uma sessão concluída.
- Versão do projeto atualizada para `versionCode 553` / `versionName 0.553.0`.

## Limitação importante
Esta é uma etapa de preparação do motor de corrida e qualificação. **Não conclui ainda o cadastro dinâmico de equipes e pilotos**: `WorldDatabase`, mercado de pilotos, `DynamicGridEngine`, evolução de temporada, histórico, premiações e outras áreas ainda contêm pressupostos sobre 40 equipes/80 titulares/100 pilotos rastreados. Portanto, cadastrar uma equipe nova ainda não está habilitado de ponta a ponta e esta versão não deve ser descrita como tendo essa funcionalidade concluída.

## Validação
- Alterações de código inspecionadas após a edição.
- ZIP será validado estruturalmente.
- Não foi possível executar Gradle/Android build ou testes automatizados neste ambiente; não declarar compilação nem runtime aprovados.
