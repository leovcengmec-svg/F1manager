# Auditoria V345

## Alterações verificadas estaticamente
- Fluxo interativo `advanceRace()` chama `finalizeCompletedRace()` após a conclusão do motor.
- O caminho interno `simulateWeekendInstantlyForCareer()` chama `engine.simulateWeekendInstantly()`, atribui o snapshot/resultado e encaminha para o mesmo finalizador.
- O finalizador central mantém no mesmo fluxo: finanças do jogador, salários, finanças/patrocínios de IA, registro de resultado/histórico, evolução de pilotos, notícia de resultado, premiações de temporada e persistência final.
- Nenhuma UI foi modificada e nenhum botão foi adicionado.
- ZIP precisa preservar o nome oficial.

## Limitações conhecidas
- O marcador persistente do GP é gravado por `store.recordRace()` depois de parte dos efeitos de fechamento. A proteção evita reexecução após o registro, mas ainda não é uma transação atômica contra encerramento do processo no meio do fechamento.
- A simulação instantânea está integrada ao finalizador de carreira como entrada interna, ainda sem controle de UI, conforme a restrição atual.
- Build Android e testes JUnit não foram executados neste ambiente; esta auditoria é estática.
