# V652 — Gestão financeira das IAs e continuidade do carro seguinte

Base: V651. Versão externa preservada: V30. Código interno: `652` (`0.652.0`).

## Correções

- Corrigida a reconstrução financeira da IA: o replay de temporadas históricas usa o orçamento-base canônico de cada temporada histórica, mas não sobrescreve o orçamento/capacidade real fornecido para a temporada corrente.
- A cadeia de desenvolvimento técnico conserva o limite de caixa real e o teto técnico anual compartilhado. A quantidade de fabricação é recalculada antes da conclusão do projeto: quando duas unidades não cabem no caixa/capacidade, a IA reduz para uma unidade; só cancela se nem uma unidade for viável.
- A quantidade aprovada no planejamento é preservada até a conclusão do design, evitando divergência entre a decisão de P&D e o pedido enviado à fábrica. A checagem inclui o custo do design recém-reservado no teto técnico anual e é repetida quando o design termina, considerando o preço real da fábrica naquele momento. Assim, se duas unidades deixarem de caber, a IA ainda tenta fabricar uma em vez de cancelar o projeto inteiro.
- Complexidade de pesquisa e velocidade de fábrica passam a considerar o Overall físico atual, e não somente a força inicial do perfil da equipe.
- Refeita a escolha de instalações da IA: não existe mais bloqueio obrigatório do Centro Comercial até o nível 3. Pesquisa e Fábrica ganham prioridade crescente quando a equipe perde desempenho; Marketing depende mais da saúde financeira e da liquidez disponível.
- As decisões de instalação protegem obrigações salariais e de manutenção, reserva operacional e a contribuição planejada para o carro seguinte antes de iniciar uma obra.
- A decisão de investimento do carro seguinte considera o custo de preservação da força atual e as reservas operacionais reais. A reserva de caixa usa o custo por GP correspondente à equipe.
- Adicionado piso de continuidade ao carro da IA: subinvestimento ainda pode reduzir o desempenho, mas a construção financeira isolada não pode causar uma perda superior a 8 pontos de Overall em uma única virada. O piso é progressivamente removido conforme o financiamento cobre o custo de manutenção da força atual. Não concede crescimento automático.
- A penalidade financeira da IA passa a usar a rotina canônica: redução de 20% nos seis componentes e nas métricas de confiabilidade, preservando componentes ausentes.
- A atualização é aplicada nos fluxos de carreira normal e Team Principal que chamam o motor compartilhado; a trilha Team Principal preserva também o histórico de aportes nas reconstruções.
- Testes antigos que exigiam prioridade obrigatória do Centro Comercial foram atualizados para validar a nova política adaptativa, sem remover os testes de patrocínio e receita comercial.

## Testes adicionados

`AITeamInvestmentV652Test.kt` cobre a preservação do orçamento corrente após replay histórico, o piso progressivo do próximo carro, fallback de fabricação de duas para uma unidade, penalidade nos seis componentes e prioridade de recuperação técnica.

## Limitações da validação nesta entrega

- Auditorias estruturais e verificações estáticas do código foram executadas.
- O teste Kotlin/JUnit foi adicionado ao projeto, mas não foi executado nesta sessão: o ambiente não contém Gradle nem Gradle Wrapper utilizável.
- Não foi produzido APK e não houve teste em dispositivo Android.
- A trajetória específica da Red Bull só pode ser reproduzida de forma conclusiva com o save da simulação original. A V652 corrige os mecanismos identificados no código, mas não valida aquele save sem recebê-lo.
