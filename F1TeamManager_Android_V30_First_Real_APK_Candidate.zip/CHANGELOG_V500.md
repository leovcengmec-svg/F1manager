# V500 — Receita semanal do Centro Comercial

- Added level-based weekly revenue ranges for team merchandise stores, from €50k–€100k at level 1 to €1.0m–€1.6m at level 10.
- Added an automatic, deterministic, idempotent weekly cash entry for player and AI teams.
- Persisted the season/week revenue ledger so save/reload or duplicate weekly callbacks do not double-credit sales.
- Added a Finance screen card showing the minimum and maximum weekly store-sales revenue based on the current Commercial Center level.
- Existing sponsor income remains separate from merchandise store sales.
- Added focused unit tests for ranges and deterministic revenue.
- Android build/device verification remains pending because this environment has no Gradle executable or wrapper.
