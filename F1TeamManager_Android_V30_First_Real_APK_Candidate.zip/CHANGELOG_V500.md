# V500 — Bônus de complexidade no P&D

- A pesquisa agora soma ao ganho-base do nível da instalação o bônus sorteado pela complexidade: Simples +1–2; Média +2–3; Avançada +3–4; Experimental +4–5.
- Resultado parcial aplica 50% do ganho total (base + bônus); falha concede 0.
- A prévia de P&D mostra os ganhos estimados já com o bônus de complexidade.
- IA e jogador usam a mesma faixa de bônus; risco, duração, custo e limite de 100 pontos por atributo foram preservados.
- Adicionado/atualizado teste unitário para as faixas de bônus e a prévia.
- Validação: inspeção do código e integridade do ZIP; compilação/testes Android não executados neste ambiente (o ZIP não contém `gradlew` e não há `gradle` instalado).
