# F1 Team Manager V571 — 0.571.0

- Fixed external team-logo cache identity: it now includes the registered custom asset and normalized team name, so editing a custom team's shield/name won't keep returning the previous cached bitmap under the same team ID.
- Fixed car-visual cache identity to include the normalized team name, preventing stale visuals when a custom team is renamed while the ID remains stable.
- Kept permanent team IDs, asset filename resolution, external asset folders, driver/country/GP assets, save formats, and historical version records unchanged.
- Added source-contract regression tests for both cache keys and explicit cache clearing.

Validation: ZIP structure and source diffs reviewed. Android build and JUnit execution were not run in this environment.
