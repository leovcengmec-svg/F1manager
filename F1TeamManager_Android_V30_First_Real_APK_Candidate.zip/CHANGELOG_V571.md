# V571 — Correção definitiva das fotos de Heikki Kovalainen e Bruce McLaren

- A busca dessas fotos agora é estritamente pelo nome normalizado do piloto, independentemente do ID do cadastro.
- Para esses dois nomes, a busca não usa nomes numéricos, evitando que arquivos de Daniel Ricciardo ou Leonardo Vicente sejam escolhidos por engano.
- A chave do cache de fotos inclui ID e nome do piloto, impedindo que um ID reutilizado entregue uma imagem armazenada para outro nome.
- Os demais pilotos mantêm a estratégia anterior de busca.
