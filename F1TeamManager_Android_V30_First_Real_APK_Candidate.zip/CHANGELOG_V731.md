# V731 — Regras finais de evolução, potencial e classe dos pilotos

## 1. Margem de Overall por classe

- Médio: teto normal 69, margem adicional de até +5, máximo 74. A faixa adicional não exige desempenho e não reduz a velocidade natural de crescimento, com ou sem equipe.
- Forte: teto normal 79, margem adicional de até +5, máximo 84. Piloto livre acessa a margem sem exigência adicional; piloto contratado precisa de desempenho médio da temporada.
- Pro: teto normal 89, margem adicional de até +5, máximo 94. Piloto livre ou contratado precisa de desempenho médio da temporada.
- Lenda: teto absoluto 100, sem faixa adicional.
- Potencial individual, Overall 100 e limites anuais por atributo continuam sendo limites absolutos. A margem de classe não promove automaticamente o piloto.

## 2. Desempenho exigido para a faixa adicional

Para Forte contratado e Pro (livre ou contratado), a média real de desempenho da temporada libera progressivamente a margem: 110–119,99 = +1; 120–129,99 = +2; 130–139,99 = +3; 140–149,99 = +4; 150 ou mais = +5. Uma corrida isolada não substitui a média da temporada.

O desempenho é medido contra as metas de classificação e corrida calculadas exclusivamente pela força do carro. A habilidade do piloto afeta o resultado real, mas não a meta.

## 3. Velocidade acima do teto normal

- Médio e Forte livre mantêm a taxa natural normal ao utilizar a faixa adicional.
- Forte contratado e Pro têm desaceleração progressiva do crescimento acima do teto normal: 0,90x até +2; 0,80x entre +3 e +4; 0,70x no quinto ponto.
- A margem é compartilhada pelo motor de evolução natural e pelo Centro de Desenvolvimento. Programas respeitam a mesma exigência de desempenho, potencial e limite anual; pontos sem espaço elegível ficam reservados.

## 4. Promoção e regressão esportiva de classe

- Revisão na virada a cada duas temporadas completas (2027, 2029, 2031...).
- Promoção: evidência de pelo menos 80% dos GPs previstos em ambas as temporadas; média de cada temporada >=100; média combinada >=105; Overall pelo menos um ponto acima do início da próxima classe. Uma classe por avaliação. Pro -> Lenda continua exigindo ao menos um título de pilotos na carreira.
- Regressão: evidência mínima equivalente; média de cada temporada <=80; média combinada <=80; Overall pelo menos dois pontos abaixo do início da classe atual. Uma classe por avaliação. Lenda também pode cair para Pro por desempenho ruim.
- A classe não muda no meio da temporada. Ganhos e perdas de atributos continuam ocorrendo por GP, separadamente da revisão de classe.

## 5. Regressão por temporadas sem equipe

Contagem independente da avaliação esportiva, feita a cada temporada completa sem contrato ativo: Forte -> Médio após 2 temporadas; Pro -> Forte após 3; Lenda -> Pro após 5. Médio não tem rebaixamento adicional por ausência. Ao cumprir o limite, ocorre apenas uma mudança de classe e o contador é zerado para começar o período exigido pela nova classe. Qualquer outra mudança de classe também inicia um novo contador. Assinar contrato interrompe e zera a sequência.

Saves V730 começam a contar ausência a partir das temporadas completas concluídas após a atualização; o sistema não inventa temporadas anteriores sem registro confiável. O contador é salvo em SharedPreferences e incluído automaticamente no backup completo.

## 6. Preservações

- Escada oficial: Médio 60–69, Forte 70–79, Pro 80–89, Lenda 90–100. Fraco/Normal legado é normalizado para Médio.
- Overall continua sendo a média dos sete atributos reais.
- Perfil de evolução e limites anuais por atributo permanecem.
- Regressão por idade, ciclo 18–45 e redução de 30% no reinício permanecem independentes.
- Jogador e IA usam os mesmos motores e critérios.
- As notificações de promoção/rebaixamento permanecem em Eventos de Pilotos, com motivo completo.
- Metas de classificação e corrida continuam sendo exclusivamente baseadas na força do carro.
- Central de Notícias e patrocínios V730 permanecem inalterados.

## Versão

- `versionCode = 731`
- `versionName = 0.731.0`
- Base: V730 / 0.730.0
