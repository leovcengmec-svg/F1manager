# V562 — evolução esportiva compatível com grid expandido

## Implementado
- O cálculo de desempenho por GP aceita o tamanho real do grid como parâmetro, mantendo 80 como padrão para compatibilidade com chamadas e testes históricos.
- Os alvos de evolução de temporada são calculados a partir da quantidade de equipes do catálogo, com duas vagas por equipe, em vez de limitar posições a P80.
- Os dois fluxos de evolução (motor de temporada e evolução anual) passam a informar o tamanho dinâmico do grid ao cálculo de desempenho.
- Versão Android atualizada para 562 / 0.562.0.
- Os arquivos de histórico e assets foram preservados.

## Limites de validação
- ZIP validado estruturalmente.
- Build Android e testes automatizados não executados neste ambiente.
- Esta alteração remove limites no cálculo de expectativa/evolução, mas não comprova sozinha que qualificação, classificação, premiações e simulação de corrida aceitam grids expandidos ponta a ponta.
