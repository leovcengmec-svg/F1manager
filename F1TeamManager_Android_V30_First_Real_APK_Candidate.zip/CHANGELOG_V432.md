# V432 — Fechamento da auditoria de contratos da virada

- Corrigido erro de sintaxe Kotlin no teste de contrato V431: as aspas de `STATE_PERSISTED` estavam sem escape, impedindo a compilação dos testes.
- Renomeado o teste para `SeasonTransitionV432IntegrationContractTest`.
- Acrescentado contrato estático para exigir snapshot confirmado antes da publicação da etapa `PREPARED`.
- Acrescentado contrato estático para verificar que a limpeza do backup precede a remoção do diário após `STATE_PERSISTED`.
- Mantida a tabela individual de referência para os 61 Overall entre 40 e 100 e a mesma função de referência no cálculo real de transição.
- Nenhuma alteração de layout; histórico e assets preservados.
