# Auditoria V711 — Central de Notícias Overall-only

## Escopo
Correção da categoria “Evolução de Pilotos” na Central de Notícias, sem alterar a evolução real dos atributos.

## Resultado esperado
- Um cartão somente quando `overallAfter - overallBefore != 0`.
- Delta positivo: título “EVOLUÇÃO DE PILOTO”.
- Delta negativo: título “REGRESSÃO DE PILOTO”.
- Mensagem contém piloto, equipe no momento do evento, GP, Overall anterior, Overall novo e delta; não contém códigos de atributos, nomes de atributos ou causa detalhada.
- O comportamento é igual na carreira normal e no modo Team Principal.

## Compatibilidade de outbox
Mensagens antigas ainda pendentes da V709/V710 são normalizadas antes de serem convertidas em notificações. Delta zero é descartado. Delta diferente de zero é preservado e reescrito no formato Overall-only.

## Integridade
A escrita dos atributos, bancos de evolução, bancos de idade, limites anuais e desenvolvimento continua independente da criação da notícia. A alteração não modifica o motor que determina quais atributos evoluem ou regridem.

## Limite de validação
Testes focados e validações estáticas podem ser executados localmente. Gradle/Android SDK não estão instalados no ambiente para compilar o APK e executar a suíte Android completa.
