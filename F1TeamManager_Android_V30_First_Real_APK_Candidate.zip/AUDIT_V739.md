# Auditoria V739 — correção após testes visuais da V738

## Achados confirmados
1. Os cards dos sete atributos foram reduzidos a 42 dp e a captura mostrava os valores cortados. Corrigido para 58 dp, com tipografia maior e sem truncamento vertical.
2. O card exibia uma linha inferior redundante (“CONTRATO EM VIGOR OU JANELA FECHADA”) e espaço reservado mesmo quando nenhuma ação estava disponível. A linha foi removida e a área de ação agora só existe quando RENOVAR ou NEGOCIAR pode ser oferecido. Os dados úteis do contrato foram preservados.
3. O teto uniforme aplicado depois de multiplicadores tornava os valores de categorias intermediárias muito próximos dos limites máximos. Em exemplos da imagem, Regional aparecia com €799–800 mil/GP e €400 mil por meta, praticamente igualando uma oferta Global.

## Correção de patrocínios
Implementada uma escala final por categoria, aplicada ao valor efetivamente mostrado e contratado. Básico é a menor faixa e Global é a maior. Marketing e Master ajustam o ponto dentro da faixa, mas não cruzam para outra categoria. Os máximos continuam em €800.000/GP, €400.000 por meta de qualificação e €400.000 por meta de corrida.

| Categoria | €/GP | Qualificação | Corrida |
|---|---:|---:|---:|
| Básico | 120–220 mil | 50–100 mil | 50–100 mil |
| Regional | 220–340 mil | 100–160 mil | 100–160 mil |
| Nacional | 340–460 mil | 160–220 mil | 160–220 mil |
| Internacional | 460–580 mil | 220–280 mil | 220–280 mil |
| Premium | 580–700 mil | 280–340 mil | 280–340 mil |
| Global | 700–800 mil | 340–400 mil | 340–400 mil |

## Compatibilidade
- Contratos que já foram assinados não são alterados retroativamente.
- Migração de save não necessária; os campos persistidos continuam iguais.
- Jogador e IA usam `TeamSponsorshipEngine.buildContract`, portanto a mesma tabela vale para ambos.

## Validação
- Verificação estrutural do código realizada.
- Testes JUnit adicionados, mas não executados porque o projeto não contém Gradle Wrapper e o Gradle/Android SDK não estão disponíveis nesta sessão.
- A V738 foi preservada no histórico do projeto; esta correção é V739.
