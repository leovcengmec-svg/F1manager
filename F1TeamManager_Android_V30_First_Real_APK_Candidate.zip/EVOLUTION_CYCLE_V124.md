# V124 — Driver Evolution Career Cycle

- GP performance is 40% qualifying + 60% race.
- Progression: good performance accelerates the climb.
- Regression: good performance slows the fall; poor performance accelerates it.
- Performance can reach the class ceiling/floor before nominal phase duration.
- Reaching the ceiling early does not skip the 2 full peak seasons.
- Reaching the floor early does not skip the remaining scheduled regression phase time.
- Very poor repeated performance accumulates pressure and may trigger early regression before the nominal ascent duration.
- Ascent seasons: Prodigy 5, Fast 6, Moderate 7, Late 8, Normal 9, Slow 10.
- Regression seasons: Prodigy 5, Fast 5, Moderate 6, Late 6, Normal 7, Slow 7.
- Minimum Overall floors: Weak 40, Medium 45, Strong 50, Pro 55, Legend 60.
- Peak duration: 2 seasons.
- The phase budget is frozen at phase start; it is not recalculated every GP.
- Driver news is emitted only when displayed Overall increases, one card per pilot, with pilot, team, GP and Overall before/after.
