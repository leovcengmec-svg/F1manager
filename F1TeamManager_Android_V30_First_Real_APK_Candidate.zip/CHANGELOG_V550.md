# V550 — integração do regulamento no motor alternativo de temporadas

- Corrigido o caminho `ManagerSeasonEngine` para aplicar o regulamento anual/decenal após a construção do carro da nova temporada, nos dois carros físicos e no estado legado sincronizado.
- A aplicação decenal mantém a exclusividade sobre os eventos anuais e usa a margem de adaptação individual de 0% a 8% fornecida por `AnnualCarRegulationEngine`.
- As versões instaladas são reiniciadas para V0 na garagem e no estado de compatibilidade após a construção da nova temporada.
- Todas as instâncias de `AITeamDevelopmentEngine` dentro de `ManagerSeasonEngine` agora recebem explicitamente a mesma semente de regulamento, separada da semente de desenvolvimento/simulação.
- Atualizado o teste de integração de duas temporadas para verificar que a transição alternativa registra a aplicação do regulamento e reinicia as versões físicas.
- Atualizado `tools/audit_v445_regulation.py` para validar a semente compartilhada persistida e ambos os caminhos de integração, em vez de exigir a antiga semente fixa.
- Preservados os assets externos, o histórico de versões e as regras de desempenho/acidentes não relacionadas.

## Validação

- `tools/audit_v429.py`: 9/9.
- `tools/audit_v445_regulation.py`: 4.772/4.772 asserções de fonte/modelo.
- `tools/finance_test/v440_financial_continuity_audit.py`: 13/13.
- `tools/finance_test/v441_financial_model_audit.py`: 7/7.
- `tools/race_sim_test/validate_project.py`: 32/32.
- `tools/race_sim_test/v448_game_cycle_audit.py`: 18/18.
- `tools/race_sim_test/v498_ai_persistence_audit.py`: 8/8.
- A compilação Android e a suíte JUnit não foram executadas: o ambiente não tem Gradle instalado nem Gradle Wrapper no pacote.
