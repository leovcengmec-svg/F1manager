# V493 — Correção definitiva do ranking do Modo Difícil

- Corrigido o desempate das três equipes oferecidas no Modo Difícil.
- A seleção agora deriva das últimas três posições do mesmo ranking de overall inicial usado na tela de equipe (overall do conjunto de carros, desempate por ID crescente no ranking).
- O resultado é apresentado da mais fraca para a menos fraca dentro do trio, sem escolher equipes diferentes por causa de empates.
- Adicionado teste de regressão `InitialTeamRankingV493Test` para comparar o trio oferecido com as posições 38–40 do ranking inicial.
- Nenhum asset externo, bandeira, escudo, GPS, piloto, carro ou histórico de versões foi removido.
