# Auditoria V361 — fechamento do GP e arquivo histórico

## Inspeção estática
- O caminho `isRaceRecorded(round)` reconcilia `HistoricalDatabase` quando `seasonRound` é informado, em vez de retornar imediatamente.
- A reconciliação acontece antes de qualquer soma de pontos; portanto, o caminho repetido não aplica a pontuação do campeonato novamente.
- `HistoricalDatabase.recordRace()` remove registros históricos existentes da mesma temporada/rodada antes de gravar os novos, tornando a repetição idempotente para R/P/Q.
- No GP final, `finalizeSeason()` é chamado novamente; seu próprio marcador `SD|season|` impede duplicar o snapshot já concluído.
- `app/build.gradle.kts`: `versionCode = 361`, `versionName = "0.361.0"`.

## Testes/ambiente
- Verificações estáticas automatizadas abaixo: pendentes até executar o script local de validação do pacote.
- Build Android e JUnit não executados: o ZIP não contém Gradle Wrapper e Gradle não está disponível no PATH deste ambiente.
- Simulação integrada de duas temporadas não executada.

## Limites conhecidos
- A recuperação é acionada por nova chamada de `recordRace()` com `seasonRound`.
- Não há transação atômica entre SharedPreferences e o arquivo histórico; a reconciliação corrige a janela de falha no próximo callback, não instantaneamente na inicialização.
