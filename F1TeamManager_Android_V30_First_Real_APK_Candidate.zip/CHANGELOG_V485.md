# V485 — Premiação do Mundial de Construtores

- Atualizada a premiação de fim de temporada para variar de €100 milhões (1º) a €40 milhões (40º).
- Diferenças maiores entre as primeiras 10 posições: 1º €100M, 2º €92M, 3º €86M, 4º €81M, 5º €77M, 6º €73M, 7º €69M, 8º €65M, 9º €62M, 10º €60M.
- Do 11º ao 20º, redução gradual de €1,5M por posição; do 21º ao 40º, redução de €250 mil por posição.
- A regra permanece centralizada em SeasonPrizeEngine para uso compartilhado no acerto financeiro da equipe do jogador e das equipes de IA.
- Atualizados testes de auditoria para validar os 40 valores, a ordem estritamente decrescente, os extremos e os intervalos do top 10.
