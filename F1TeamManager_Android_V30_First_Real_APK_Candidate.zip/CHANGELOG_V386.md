# V386 — Ajuste da Home

- Removido o bloco visual "QUADRO DE SEMANAS" da tela Home.
- Movido o card "PRÓXIMA CORRIDA" para antes de "SITUAÇÃO DO CAMPEONATO".
- Ajustada a área da imagem do GP para proporção quadrada (altura igual à largura disponível do card).
- Mantidos os botões de fim de semana normal e simulação instantânea e suas ações existentes.
- Nenhuma alteração intencional em assets externos ou no fluxo de corrida.
