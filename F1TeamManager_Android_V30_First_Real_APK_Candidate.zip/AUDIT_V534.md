# Auditoria V534 — Hall da Fama

## Causa
O método `hallValues` calculava títulos, vitórias, poles, voltas rápidas, pontos e GPs repetindo filtros e contagens sobre o histórico completo para cada piloto e construtor. Conforme temporadas e registros cresciam, o custo aumentava de forma desnecessária.

## Correção
Os dados são agregados por ID uma vez por cálculo de ranking; os valores de cada linha passam a ser obtidos por mapas. Isso reduz as varreduras repetidas e melhora a escalabilidade do Hall da Fama sem descartar histórico.

## Limites da validação
ZIP validado estruturalmente. Não houve execução de Gradle, testes unitários ou teste de desempenho no dispositivo nesta sessão. Comparação funcional de todos os rankings ainda precisa ser confirmada em build/testes Android.
