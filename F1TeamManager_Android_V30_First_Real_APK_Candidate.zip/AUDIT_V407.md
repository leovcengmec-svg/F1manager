# Auditoria V407

## Corrigido
- `MainActivity.kt`: a seleção de eventos da Home omitia `PROPOSTA ENVIADA` e `CONTRATO FECHADO`; os títulos agora entram no filtro e na prioridade de exibição.
- `DriverMarketEngine.kt`: a resposta positiva podia remover a proposta e falhar ao assinar sem registrar qualquer evento. Agora a falha gera `PROPOSTA NÃO CONCLUÍDA`.
- Testes adicionados para validar o evento imediato e a resolução da proposta durante o avanço de semanas.

## Verificação
- Código e versão inspecionados estaticamente.
- Compilação Android e execução dos testes ainda precisam ser executadas num ambiente com Gradle/Android SDK configurado.
