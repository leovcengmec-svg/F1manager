# V671 — Commercial economy audit

## Requested commercial bonus
- Center level 0: 1.60x (+60%).
- Center level 1: 1.40x (+40%).
- Center level 2: 1.20x (+20%).
- Center level 3..10: 1.20x + 2.5 percentage points for every level above level 2; level 10 = 1.40x.
- Existing signed contracts are not repriced; incomplete legacy contracts receive only their missing payment component at base category value.

## Marketing quality
- `FacilityEngine.marketingQuality()` (0..80) now feeds the category draw.
- Each 8 quality points shifts the deterministic draw by one percentage point toward the stronger category already available at that level.
- Category unlock thresholds remain unchanged; quality cannot unlock a future category early.

## AI facilities reserve
- Annual facilities allocation = 20% of €200M = €40M.
- Unused balance accumulates across seasons; a €52M level-5 upgrade becomes financeable after at least two €40M annual grants.
- The shared technical ceiling, cash protection, operating reserve, next-season car reserve, outlook and one-upgrade-at-a-time rules remain active.
- Reserve balance and credited-through season use an optional `A|team|balance|season` persistence row; old snapshots remain readable.

## Sponsorship settlement
- Qualifying and race bonuses both require finishing inside the exact displayed min..max position window.
- AI expected-bonus valuation uses the same bounded race window.
- New offers set the obsolete per-point bonus to zero. The serialized field is retained only to read historical saves; no per-point payment is settled.

## Regression coverage
- `CommercialCenterV71Test` updated for the 60/40/20% schedule and zero new point bonuses.
- `CommercialEconomyV671Test` covers exact pricing, marketing-quality category shift, exact race target range, and AI facility reserve accumulation/persistence/level-6 upgrade funding.
