# V560 — reconciliação segura do catálogo do mercado

## Implementado
- Criada `DriverMarketCatalogMigrationV560` para reconciliar saves existentes com o catálogo de pilotos/equipes carregado pelo jogo.
- Contratos existentes são preservados; pilotos novos descobertos no catálogo entram no mercado livre.
- Vagas de equipe são preenchidas apenas com agentes livres disponíveis, sem duplicar contratos nem inventar pilotos.
- A migração informa equipes que continuam com vagas se o catálogo não tiver pilotos suficientes.
- Preferências de função deixam de ser limitadas ao intervalo fixo `1..100`; a normalização aceita os IDs presentes no catálogo atual.
- A migração pode ser executada novamente sem duplicar contratos, vagas preenchidas ou a anotação de histórico da V560.
- Versão atualizada para `560` / `0.560.0`.

## Preservação e validação
- Mantidos os documentos de versões anteriores, assets e estrutura do projeto.
- Adicionados testes de preservação de contratos, repetição segura e integridade dos IDs.
- A compilação Android e a suíte de testes não foram executadas neste ambiente; o ZIP foi verificado estruturalmente após empacotamento.
