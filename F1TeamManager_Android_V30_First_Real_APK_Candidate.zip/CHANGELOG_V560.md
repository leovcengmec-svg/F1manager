# V560 — P&D e desempenho inicial do carro

- Carros físicos novos iniciam com desempenho 0 nos seis componentes.
- Peças de pesquisa não são consideradas instaladas até a conclusão do fluxo de projeto, fabricação e instalação.
- Garagens iniciais antigas que ainda possuem somente peças sintéticas `INIT-*` são migradas para zero; garagens com peças reais instaladas são preservadas.
- A escala de influência dos componentes na corrida cobre o intervalo de desempenho 0–100.
- Teste estrutural executado: `validate_project.py` passou em 32/32 verificações.
- A compilação Gradle/Android e o teste em dispositivo permanecem pendentes por falta de Gradle Wrapper/Gradle no pacote/ambiente.
