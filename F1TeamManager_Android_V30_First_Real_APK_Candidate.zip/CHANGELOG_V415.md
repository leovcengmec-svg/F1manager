# V415

- Corrigida a definição do evento de largada ruim: agora é um incidente coletivo, com um único sorteio por corrida e possibilidade de afetar de 2 a 5 pilotos na mesma largada.
- Cada piloto afetado recebe sua própria perda de tempo entre 0,15 s e 0,60 s; não há punição automática.
- A largada ruim continua sendo processada no motor da corrida, sem sorteios independentes por piloto.
