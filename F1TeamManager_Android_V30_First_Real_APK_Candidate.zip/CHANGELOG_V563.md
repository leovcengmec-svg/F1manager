# F1 Team Manager V563 — 0.563.0

- Corrigida a limitação do motor de premiação de construtores que rejeitava posições acima da 40ª.
- Mantidos exatamente os valores históricos das posições 1–40.
- A curva de premiação continua para grids expandidos e aplica piso de €30 milhões, sem valores negativos.
- Teste de auditoria ampliado para validar preservação histórica, monotonicidade, P41, P100 e posição inválida.
- Atualizado versionCode para 563 e versionName para 0.563.0.

Validação: revisão estática e integridade do ZIP. Compilação Android e execução dos testes não realizadas neste ambiente.
