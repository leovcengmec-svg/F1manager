# V563 — Roteamento de áudio dos boxes e rotação da interface

## Áudios exclusivos dos pilotos do jogador

- `driver_warning` toca apenas para alerta de pneu crítico/recomendação de pit stop de um piloto pertencente à equipe do jogador.
- `box_audio` toca apenas quando o jogador seleciona explicitamente a ação BOX na decisão da corrida.
- Removido o acionamento de `box_audio` por qualquer evento genérico `PIT_STOP`, que também poderia representar paradas automáticas/da IA.
- Removido o acionamento de `driver_warning` por falha mecânica ou desgaste genérico; a origem agora é o alerta que recomenda a entrada nos boxes.
- Safety Car e bandeira vermelha mantêm seus roteamentos independentes.

## Áudio de interface

- A interface toca uma faixa por vez, em loop: `interface`, `interface_2`, `interface_3`.
- Ao retornar à interface depois de um resultado de GP, avança para a próxima faixa e reinicia o ciclo após a terceira.
- Navegações comuns entre telas da interface não avançam o ciclo; a rotação é vinculada ao retorno após GP concluído.

## Validação

- Revisão estática das condições de disparo e da sequência de rotação.
- Integridade do ZIP verificada após empacotamento.
- Build Android/JUnit não executados neste ambiente.
