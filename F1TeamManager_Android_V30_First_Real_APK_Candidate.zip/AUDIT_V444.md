# Auditoria V444

## Fluxo de virada
1. Encerrar e arquivar a temporada anterior.
2. Construir o novo carro com continuidade e investimento.
3. Obter a regra persistida da temporada nova (ou criar uma vez).
4. Aplicar a regra aos dois carros físicos e ao estado-resumo, sem alterar confiabilidade.
5. Só então recalcular investimento técnico e metas de pilotos com o carro regulado.

## Regras
- Temporada 1 sem eventos.
- A partir da temporada 2: um ou dois componentes diferentes afetados.
- Temporadas 11, 21, 31...: revolução decenal nos seis componentes, além do sorteio anual.
- Semente 20261005 partilhada para que a regra seja igual entre equipes.
- A regra é persistida pela carreira; carregamento não sorteia novamente.

## Testes adicionados
- AnnualCarRegulationApplicationTest: efeito anual, revolução decenal, identidade e confiabilidade dos carros.
- AnnualCarRegulationEngineTest: catálogo, determinismo, temporada 1, revolução e round-trip.

## Não verificado
Compilação Android, JUnit e APK não executados por ausência de Gradle disponível no ambiente.
