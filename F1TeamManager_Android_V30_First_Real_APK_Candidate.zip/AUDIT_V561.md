# Auditoria V561 — carregamento e reconciliação do mercado

- Ponto de integração: `CareerPreferences.loadDriverMarket()`.
- Ordem: desserialização do save existente → normalização → reconciliação com catálogo atual → persistência condicional.
- Preservação: os campos carregados (contratos, agentes livres, transferências agendadas, preferências de função, propostas pendentes, scouting e notificações) são entregues à migração em conjunto.
- Idempotência: estado só é gravado novamente se houver diferença estrutural em relação ao estado carregado.
- Risco residual: a rotina de migração preenche vagas disponíveis no catálogo; esta versão ainda não prova que todos os sistemas de campeonato aceitam qualquer tamanho de grid. Build e suíte não executados.
