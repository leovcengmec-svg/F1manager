# Auditoria V511 — Visibilidade de designs

- [x] A seção de designs concluídos usa `FactoryEngine.latestAvailableDesigns`.
- [x] A seleção apresenta uma única versão por `CarComponent`.
- [x] A versão mais alta é prioritária; temporada/semana/ID desempata entradas legadas.
- [x] O método filtra para exibição sem mutar a lista original de histórico.
- [x] A lista de fabricação continua usando a mesma função de seleção.
- [x] `versionCode=511`, `versionName=0.511.0`.
- [ ] Compilação Android e testes JUnit: não executados neste ambiente sem Gradle/Gradle Wrapper.
