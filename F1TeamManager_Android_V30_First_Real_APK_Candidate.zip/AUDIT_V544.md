# Auditoria V544

- Ajustado ResearchEngine.start para obter a última versão apenas dos designs da temporada atual.
- A primeira pesquisa do ano é V1; o carro recém-construído é exibido como baseline V0.
- Na virada de temporada, o número visual das peças físicas é reiniciado para V0, sem alterar desempenho ou confiabilidade.
- Persistência aceita versão 0.
- Paleta determinística distinta para V0–V10.
- ZIP validado estruturalmente. Compilação Gradle/JUnit não executada neste ambiente.
