# F1 Team Manager — V656

## Estratégia financeira da IA: gerar receita antes de investir

### Centro Comercial
- A decisão de expansão do Centro Comercial passou a comparar o custo da melhoria com a receita incremental realista das lojas e dos novos contratos de patrocínio.
- O retorno considera o prazo de construção de 12 semanas, a receita das semanas restantes da temporada e a temporada seguinte.
- O cálculo desconta a manutenção adicional da instalação e favorece melhorias com retorno mais rápido.
- A IA só inicia a melhoria quando o caixa disponível comporta o investimento e as projeções das duas temporadas preservam a reserva operacional.

### Patrocínios
- A seleção passou a priorizar receita garantida equivalente por GP (55%) e receita garantida total (20%).
- O multiplicador de Marketing dos novos contratos foi corrigido para ser monotônico: cada nível aumenta moderadamente o valor dos novos termos, sem o comportamento anterior em que subir do nível 0 para o 1 reduzia a receita ofertada.
- Bônus são estimados conforme a força esportiva da equipe, ponderados pela probabilidade de cumprimento e submetidos a desconto adicional de risco (55% do valor esperado; peso de 10% na seleção).
- A flexibilidade de renegociação de contratos mais curtos continua relevante (15%), mas não supera uma diferença material em receita garantida.
- A projeção simula renovações e novos contratos sem modificar o estado real dos saves, das equipes ou do histórico de eventos.

### Planejamento de caixa
- Novo panorama financeiro projeta receitas e despesas obrigatórias da temporada atual e da seguinte.
- A projeção inclui lojas, patrocínios fixos e bônus ponderados, salários, operação por GP, manutenção, parcelas futuras de contratação e obrigações vencidas.
- P&D, melhorias de instalações e contribuição para o próximo carro passam a respeitar o caixa imediatamente disponível e o resultado projetado das duas temporadas.
- Obrigações de salários e manutenção em aberto também são protegidas antes de novos gastos de P&D.
- Nenhuma receita artificial, subsídio ou transferência de dinheiro foi criada para salvar equipes em dificuldades.

### Integração e versão
- O nome externo **F1 Team Manager V30** permanece inalterado.
- `versionCode = 656`.
- `versionName = "0.656.0"`.
- ZIP de distribuição mantém o nome padrão original: `F1TeamManager_Android_V30_First_Real_APK_Candidate.zip`.
