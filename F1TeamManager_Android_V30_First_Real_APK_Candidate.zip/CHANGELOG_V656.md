# CHANGELOG V656 — Estratégia individual de pneus para pilotos da IA

## Estratégia de corrida da IA

- Os 78 pilotos adversários agora recebem planos de pneus A/B/C/D gerados pelo mesmo `TyreModel` usado pela equipe do jogador.
- Cada equipe calcula uma preferência estratégica-base considerando circuito, distância da prova, clima e desempenho médio do carro.
- Cada piloto avalia os planos de forma individual, considerando conservação de pneus, velocidade, aderência, consistência e posição de largada.
- Os dois carros de uma mesma equipe evitam usar o mesmo plano quando há alternativas válidas; a equipe pode dividir estratégias entre os companheiros.
- As janelas de stint são distribuídas para cobrir exatamente a distância restante sem exceder a vida-base dos compostos.
- A IA executa as paradas no momento planejado e pode antecipá-las conforme o desgaste real e a capacidade individual de conservação.
- Mudanças entre pista seca, chuva intermediária e chuva forte fazem a equipe recalcular os planos e os compostos necessários.
- A relargada após bandeira vermelha recalcula planos individuais para a distância restante, sem cobrar pit stop adicional.
- A simulação interativa e a simulação instantânea continuam usando o mesmo `CareerWeekendEngine`, portanto a estratégia nova vale para os dois modos.

## Integridade e escopo

- Mantida a física comum de pit stop: troca de pneus, reinício do desgaste/stint e perda de 21 segundos.
- Não foi alterado o modelo de combustível; pit stop continua sem reabastecimento.
- Os planos dos adversários ficam separados dos controles do jogador e não aparecem como opções manuais na interface.
- Atualizados os testes de regressão e adicionados testes para distribuição dos stints, compostos em chuva, diversidade entre companheiros e preferência de equipe.

## Versionamento

- `versionCode = 656`
- `versionName = "0.656.0"`
- Nome público preservado: **F1 Team Manager V30**.
- Nome padrão do ZIP preservado: `F1TeamManager_Android_V30_First_Real_APK_Candidate.zip`.

## Validação

- Compilação isolada do planejador Kotlin: aprovada.
- Smoke tests do planejador para corridas de 20, 30, 58, 70 e 90 voltas: aprovados.
- Simulação integral do `CareerWeekendEngine` com 80 pilotos e 58 voltas: concluída; a IA largou com Soft (20 carros), Medium (46) e Hard (12), e registrou estratégias de 1, 2 e 3 paradas (distribuição observada: 12 pilotos com 1 parada, 64 com 2 e 2 com 3).
- Diversidade da preferência-base entre 20 equipes: 4 planos distintos observados.
- Teste de integração adicionado para confirmar planos divididos entre companheiros e execução de diferentes quantidades de pit stops.
- Testes Gradle/JUnit e compilação Android completa: não executados neste ambiente, pois o pacote não contém Gradle Wrapper e o ambiente não disponibiliza Gradle/Android SDK.
