# Auditoria V730 — Central de Notícias e renovação de patrocínios

## Escopo aplicado sobre V729

A V730 implementa o plano aprovado sem alterar o catálogo, os valores base, os bônus, a notificação existente ou a liquidação do GP final.

## 1. Central de Notícias

A interface usa `MarketNewsCategory.CENTRAL_DISPLAY_ORDER` com a sequência:

1. Mercado
2. Evolução de Pilotos
3. Evolução de Equipes
4. Eventos de Pilotos
5. Eventos Anuais

Os nomes/ordinais já existentes do enum foram preservados para não alterar a compatibilidade dos registros salvos. A categoria Eventos de Pilotos continua ativa; somente sua posição de apresentação foi alterada.

## 2. Sorteio de patrocínios

`TeamSponsorshipEngine.generateOffersAtLevel()` agora deriva o sorteio do estado da negociação: equipe, temporada, GP, slot e conjunto de marcas atualmente excluídas. O gerador escolhe três marcas distintas, sorteia os dados financeiros e sorteia a duração dentro da faixa inclusiva da instalação.

Para o mesmo estado de negociação, a mesma proposta permanece estável ao sair e reabrir Finanças. Quando uma negociação é encerrada e o estado muda, o conjunto de exclusões/identidade do ciclo muda e uma nova seleção é produzida.

### Prevenção de repetição imediata sem histórico

- Jogador: depois do último GP, `FinanceEngine.applyRace()` mantém apenas o registro inativo do contrato que acabou de terminar no respectivo slot. `Finance()` inclui essa marca nas exclusões da negociação seguinte. Ao assinar, `ManagerMarketEngine.signSponsor()` sobrescreve o registro do slot.
- IA: em `TeamSponsorshipEngine.advanceRace()`, a marca do contrato que expirou é adicionada ao conjunto transitório de exclusões antes da nova geração e escolha automática.
- Não foi criado ledger, lista histórica ou tabela de patrocinadores utilizados. O registro inativo é o estado corrente do slot, não um arquivo de contratos anteriores; é substituído na assinatura seguinte.
- Marcas ativas em outros espaços continuam excluídas; as três propostas da mesma negociação não repetem marca.

## 3. Duração e condições

- Centro Comercial níveis 0–2: duração sorteada em `3..10` GPs.
- Centro Comercial níveis 3–10: duração sorteada em `8..14` GPs, inclusivamente.
- O sorteio usa `Random` com seed da negociação e limites inclusivos (`nextInt(first, last + 1)`).
- Contratos já assinados não são recalculados ou encurtados.
- Jogador e IA passam pelo mesmo gerador de proposta e pelas mesmas faixas; muda apenas quem escolhe a proposta.

## 4. Financeiro e notificação

O pagamento final e os bônus do GP continuam sendo liquidados com o contrato antigo antes da expiração. A renovação da IA continua após a liquidação, sem pagar o novo contrato no GP anterior. A notificação existente de espaço de patrocínio livre foi mantida; nenhuma notificação duplicada foi criada.

## 5. Arquivos principais alterados

- `app/src/main/java/com/f1teammanager/core/manager/DriverMarketModels.kt`
- `app/src/main/java/com/f1teammanager/MainActivity.kt`
- `app/src/main/java/com/f1teammanager/core/manager/FinanceEngine.kt`
- `app/src/main/java/com/f1teammanager/core/manager/TeamSponsorshipEngine.kt`
- Testes de estabilidade, expiração e ordem das categorias.
- Metadados de release, changelog e validador do pacote.

## 6. Validação

O validador de contrato do pacote verifica metadados, ordem das categorias, sorteio por estado da negociação, exclusão do patrocinador expirado, preservação de estado estável e faixas de duração.

A suíte JUnit e `:app:assembleDebug` não foram executadas neste ambiente porque o pacote não contém Gradle Wrapper e não há Gradle/Android SDK local disponível. O GitHub Actions contém os passos para `:app:testDebugUnitTest` e `:app:assembleDebug`; o resultado da execução remota continua sendo necessário antes de declarar o APK aprovado.
