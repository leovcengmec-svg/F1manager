# V338 — Padronização dos rótulos do orçamento da equipe

- Renomeados os cinco itens do card de orçamento da tela Equipe para: Salário Anual, Receitas, Despesas, Investimento Anual e Invest. Disponível.
- Ícone de Investimento Anual alterado para 📊 (investimentos).
- Ícone de Invest. Disponível alterado para 💵 (dinheiro).
- Mantidos os valores, fontes de dados, cálculos, cores e comportamento financeiro existentes.
- Versão Android: versionCode 338 / versionName 0.338.0.
- Base: V337. Nome oficial do ZIP preservado.
