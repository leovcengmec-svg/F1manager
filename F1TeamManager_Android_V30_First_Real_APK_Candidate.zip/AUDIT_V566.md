# Auditoria V566

- [x] Base utilizada: V565.
- [x] Android versionCode 566 / versionName 0.566.0.
- [x] Tabela oficial de pontos preservada, sem alterar as regras históricas.
- [x] Testes adicionados para posições 51 e 100, posições históricas 1 e 50 e bônus de volta mais rápida fora da tabela.
- [x] Assets e histórico de versões existentes mantidos no pacote.
- [x] Integridade do ZIP verificada após empacotamento.
- [ ] Testes JUnit executados: pendente.
- [ ] Compilação Android: pendente.
- [ ] Simulação completa de duas temporadas com equipes extras: pendente.
