# V394

- Substituída a imagem específica de peça no diálogo de fabricação por `R.drawable.facility_factory`, uma imagem genérica da fábrica adequada a diferentes tipos de componentes.
- Atualizada a descrição acessível da imagem para refletir o uso genérico.
- Mantidos intactos os dados, custos, prazos, seleção de quantidade e fluxo de fabricação.
- Nome oficial do ZIP de entrega preservado.
