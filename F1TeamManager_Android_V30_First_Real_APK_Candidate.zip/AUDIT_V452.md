# Auditoria V452

- Alteração visual isolada na tela de visão geral da equipe.
- Card inserido imediatamente após os atributos dos carros e antes do desempenho da temporada.
- Investimento conectado ao campo persistido `TeamCarState.nextSeasonInvestment` da equipe selecionada.
- Referência calculada por `CarDevelopmentEngine.referenceInvestmentForOverall` usando o Overall médio da garagem.
- Teto absoluto exibido: €150M, coerente com `nextSeasonInvestmentCap`.
- Verificação de integridade do ZIP realizada após empacotamento.
- Build Android não executado: não há `gradlew` no arquivo e o ambiente não possui o comando `gradle` instalado. Portanto, compilação permanece pendente de validação no Android Studio.
