# Auditoria V434 — Recuperação de falha na virada de temporada

## Correção implementada
O rollback pré-commit restaura o snapshot completo da preferência `f1tm_career`; após confirmação, limpa o backup. O tratamento de erro também recria o estado gerencial em memória usando os dados restaurados. O checkpoint `STATE_PERSISTED` permanece não reversível e só permite finalização/limpeza.

## Limites da validação
- Inspeção estrutural e validação do ZIP são possíveis neste ambiente.
- Não há `gradlew` no projeto nem executável `gradle`/Android SDK disponível para compilar o APK ou executar JUnit real. Não afirmar build Android aprovado.
- Os testes de integração e a simulação persistente de duas temporadas ainda precisam ser executados em ambiente Android/Gradle.
