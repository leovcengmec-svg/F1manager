from pathlib import Path
import re, sys
root = Path(__file__).resolve().parent
checks = []
def check(name, condition):
    checks.append((name, bool(condition)))

build = (root / 'app/build.gradle.kts').read_text()
engine = (root / 'app/src/main/java/com/f1teammanager/core/race/CareerWeekendEngine.kt').read_text()
main = (root / 'app/src/main/java/com/f1teammanager/MainActivity.kt').read_text()
instant = (root / 'app/src/main/java/com/f1teammanager/core/race/InstantSimulationService.kt').read_text()
manager = (root / 'app/src/main/java/com/f1teammanager/core/manager/ManagerSeasonEngine.kt').read_text()
seed = (root / 'app/src/main/java/com/f1teammanager/core/race/RaceWeekendSeed.kt').read_text()
test = (root / 'app/src/test/java/com/f1teammanager/core/race/V679RaceWeekendWeatherSeedTest.kt').read_text()
workflow = (root / '.github/workflows/android-apk.yml').read_text()
manifest = (root / 'package_manifest.txt').read_text()

check('versionCode 679', 'versionCode = 679' in build)
check('versionName 0.679.0', 'versionName = "0.679.0"' in build)
check('stable career-season-round-circuit seed derivation', all(x in seed for x in ['careerSeed', 'season', 'round', 'circuitName']))
check('deterministic byte hashing (no runtime random)', 'Random(' not in seed and 'toByteArray(Charsets.UTF_8)' in seed)
check('engine accepts per-weekend seed', re.search(r'weekendSeed:\s*Int\s*=\s*seed', engine) is not None)
check('qualifying RNG uses weekend seed', 'Random(weekendSeed xor 0x5A17C0DE)' in engine)
check('race weather RNG uses weekend seed', 'Random(weekendSeed xor 0x6327EA71)' in engine)
check('interactive path derives seed per career season round', 'RaceWeekendSeed.forWeekend(' in main and 'season = store.season' in main and 'round = round.round' in main)
check('interactive start passes per-GP seed', 'engine.start(participants(), circuit(), team.id, raceWeekendSeed())' in main)
check('instant path accepts explicit per-GP seed', 'weekendSeed: Int? = null' in instant and 'engine.start(participants, circuit, playerTeamId, weekendSeed)' in instant)
check('instant Home action passes same per-GP seed', 'engine, participants(), circuit(), team.id, raceWeekendSeed()' in main)
check('headless season path derives seed from season and round', 'RaceWeekendSeed.forWeekend(' in manager and 'season = season' in manager and 'round = round' in manager)
check('30-round uniqueness test added', '30, seeds.toSet().size' in test)
check('reload determinism test added', 'Reloading the same weekend must reproduce' in test)
check('same-weather-all-rounds regression test added', 'thirtyRaceCalendarDoesNotReuseOneIdenticalOpeningWeatherDraw' in test)
check('independent qualifying/race streams test added', 'qualifyingAndRaceWeatherUseIndependentStreamsForEachWeekend' in test)
check('existing rain-balance logic preserved', 'MAX_CONTINUOUS_RAIN_LAPS' in (root / 'app/src/main/java/com/f1teammanager/core/race/CircuitWeatherModel.kt').read_text())
check('GitHub artifact label V679', 'F1-Team-Manager-V30-V679-debug-apk' in workflow)
check('package manifest preserved ZIP name and version', 'F1TeamManager_Android_V30_First_Real_APK_Candidate.zip' in manifest and 'Version: 679 / 0.679.0' in manifest)

for name, ok in checks:
    print(f"{'PASS' if ok else 'FAIL'} | {name}")
print(f"RESULT: {sum(ok for _, ok in checks)}/{len(checks)}")
sys.exit(0 if all(ok for _, ok in checks) else 1)
