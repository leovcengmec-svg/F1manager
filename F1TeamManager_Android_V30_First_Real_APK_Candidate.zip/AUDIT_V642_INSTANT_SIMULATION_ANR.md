# V642 — Auditoria de travamento em carreiras longas (ANR)

## Sintoma reportado

Na V641, depois de várias temporadas, o Android passou a exibir **“F1 Team Manager não está respondendo”** durante o avanço da carreira. O relato diferencia a simulação instantânea — que começou a travar por volta da transição da 4ª para a 5ª temporada — da corrida manual, que permaneceu utilizável por mais tempo. A captura também mostra a tela inicial na semana 38/56, com o próximo GP marcado para a semana 39; portanto, a vistoria cobriu tanto a simulação instantânea de GP quanto o avanço do calendário entre corridas.

## Causas verificadas no código V641

1. **Simulação instantânea síncrona no callback de interface.** O caminho de clique chamava o serviço instantâneo, que executa classificação e corrida completas, e finalizava parte da carreira no mesmo fluxo da UI. Esse trabalho CPU-bound podia monopolizar a thread principal e disparar o watchdog ANR.
2. **Avanço de semanas também síncrono.** `PULAR 1 SEMANA` e `PULAR ATÉ PRÓXIMO GP` executavam diretamente o processamento semanal, que reproduz instalações/P&D, mercado, eventos anuais e finanças de múltiplas equipes. Isso corresponde ao estado mostrado na captura (semana 38, próximo GP na 39) e era um segundo caminho independente para bloquear a UI.
3. **Histórico com custo crescente por GP.** `HistoricalDatabase.recordRace()` lia todas as linhas do histórico da carreira, filtrava uma corrida e regravava todo o arquivo em cada GP. `finalizeSeason()` também relia/regravava o arquivo monolítico no encerramento anual. O custo de I/O crescia com a duração do save e era executado durante o processamento da carreira.

A persistência de histórico acumulado e o processamento de semanas forneciam, portanto, trabalho crescente no mesmo fluxo que a UI precisava atender. Isso explica tecnicamente o sintoma compatível com ANR, embora a confirmação definitiva de tempo de CPU/stack trace exigisse um profiler ou log Android do dispositivo.

## Correções V642

- A simulação instantânea e a montagem do grid foram movidas para `Dispatchers.Default`; o commit durável do resultado e a atualização final da UI retornam ao dispatcher principal.
- Adicionado modal não dispensável de progresso para simulação instantânea e avanço do calendário. Os botões relevantes ficam desabilitados enquanto há trabalho, impedindo cliques duplicados e concorrência sobre o estado da carreira.
- `PULAR 1 SEMANA` e `PULAR ATÉ PRÓXIMO GP` agora executam o processador de semanas em `Dispatchers.Default`, com as alterações em estado Compose agrupadas por `Snapshot.withMutableSnapshot`. O caminho de validação do calendário e suas barreiras para não ultrapassar um GP não concluído continuam presentes.
- Corrida e classificação passaram a ser gravadas em shards atômicos individuais por temporada/round; o fechamento da temporada grava resumos em arquivo próprio. GP novo não lê nem regrava o arquivo de carreira inteiro.
- O histórico monolítico legado é preservado como fonte de leitura. O leitor combina dados antigos com shards novos e usa somente os shards que correspondem ao GP/temporada para ocultar linhas legadas, evitando perda de histórico durante a migração. A rotina de exclusão de save limpa as duas pastas de shards.
- Mantida a versão de código 642 e a melhoria prévia do alvo de Centro Comercial nível 3 para IA; a V641 original fica preservada em arquivo separado.

## Testes executados

- Auditoria estática V642 para simulação instantânea, avanço de calendário e histórico incremental.
- Validador geral do projeto.
- Auditoria V642 de hierarquia comercial/patrocínios.
- Harness Kotlin isolado contra o `HistoricalDatabase.kt` real, usando stubs mínimos para `Context`, `AtomicFile` e modelos: migração/leitura histórica legada, substituição atômica/idempotente de um GP, resumos de temporada/idempotência, preservação do legado e limpeza dos shards.
- Testes existentes para `InstantSimulationService` mantidos no projeto.

## Limitações

Não foi possível executar uma compilação Android completa neste ambiente porque não há uma configuração Gradle/SDK utilizável. Também não há log ANR/stack trace obtido do aparelho nem uma reprodução instrumentada do save real. A correção foi verificada por auditoria estática e testes isolados; a confirmação final deve ser feita no dispositivo com a mesma carreira longa, incluindo avanço de semanas e simulação instantânea.

## Resultado final desta execução

- Auditoria estática de ANR/simulação/calendário/histórico: **24/24 verificações aprovadas**.
- Validação geral do projeto: **45/45 verificações aprovadas**.
- Auditoria comercial e de patrocínios já incorporada à V642: **20/20 verificações aprovadas**.
- Harness de runtime do `HistoricalDatabase.kt` recompilado contra o código atual e executado: **PASS** — migração legada, substituição de GP, idempotência de resumos, preservação do arquivo antigo e limpeza dos shards.
- A pasta V641 foi mantida em ZIP separado antes de atualizar o pacote canônico.
- Teste de estresse isolado do arquivo histórico: **10 temporadas / 300 GPs / 600 linhas de corrida / 600 linhas de classificação / 300 poles / 10 resumos de temporada em 484 ms** no harness local. Esse tempo mede apenas o arquivo histórico em ambiente de teste com modelos/dependências Android mínimos simulados, não a simulação completa no celular.
