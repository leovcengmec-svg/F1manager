# Auditoria V603 — objetivos sazonais ausentes

## Evidência
A captura da tela Minha Carreira exibe apenas o objetivo principal. O código da tela percorre `state.objectives`; portanto, a ausência das cinco metas sazonais indica que o save carregado não possui o catálogo completo. As conquistas 0/8 são um sistema separado e não representam os objetivos sazonais.

## Causa
A V598/V599 ampliou o catálogo de objetivos, mas saves Team Principal criados antes dessa alteração podem continuar serializando um conjunto antigo (vazio ou somente com o objetivo principal). O decodificador mantém compatibilidade, mas não atualizava automaticamente o catálogo incompleto.

## Correção
V603 adiciona `ensureCurrentObjectives`. Ao carregar uma carreira Team Principal, verifica o catálogo persistido; se incompleto, recria o objetivo principal e cinco objetivos sazonais a partir do catálogo atual, considerando a última posição e instalações. O catálogo completo existente é preservado. A migração é gravada no save.

## Distinção importante
`CONQUISTAS 0/8` é o painel de conquistas de carreira, independente das seis metas de temporada V598/V599. O contador “METAS CUMPRIDAS” refere-se a temporadas dentro da meta contratual, não à quantidade de objetivos sazonais concluídos.

## Limitação
A correção foi verificada por inspeção/testes estáticos; build Android e validação no aparelho ainda pendentes.
