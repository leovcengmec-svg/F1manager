# Auditoria V418

## Implementado
- Eventos `SEASON_START` e `SEASON_END` adicionados à navegação.
- Início aparece na primeira semana de cada temporada, após seleção da equipe ou após transição para nova temporada.
- Final aparece depois que a última corrida é reconhecida e a temporada está arquivada.
- Marcadores persistentes por temporada em CareerPreferences impedem repetição após reabertura do app.
- Estatísticas da retrospectiva são derivadas dos registros históricos disponíveis; destaques limitados aos fatos verificáveis.
- Versão Android atualizada para 418 / 0.418.0.

## Pendente
- Compilação Android não executada: o projeto não contém Gradle Wrapper no ambiente.
- Não foi possível confirmar renderização no POCO X7 Pro. As telas usam layout sem Scroll containers, mas o ajuste sem corte depende de teste no dispositivo.
