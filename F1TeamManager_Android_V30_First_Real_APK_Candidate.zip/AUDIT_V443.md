# Auditoria V443 — Etapa 1

Implementado: catálogo de 18 eventos (3 por componente), sorteio reproduzível por semente+temporada, exceção para a temporada 1, revolução decenal nas temporadas 11/21/31..., codificação/decodificação validada e API de persistência no CareerPreferences.

Não implementado nesta etapa: aplicação dos percentuais às peças físicas e ao TeamCarState, ajuste de ranking/IA, P&D e integração no fluxo da virada. Isso fica para a etapa 2.

Ordem exigida para a próxima etapa: 1) encerrar ano; 2) construir carro da próxima temporada com a evolução normal; 3) aplicar uma única vez o regulamento sorteado ao carro novo (sem alterar confiabilidade); 4) atualizar garagem física e projeção TeamCarState de forma consistente; 5) calcular ranking de força após o regulamento; 6) persistir regra e carro para não repetir após reinício.

Build Android e testes JUnit dependem do ambiente Gradle/Android SDK; serão reportados conforme efetivamente executados.
