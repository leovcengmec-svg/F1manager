# Auditoria V601 — Identidade e evolução dos pilotos

## Correção geral
O mecanismo anterior corrigia Felipe por uma regra específica de Overall. A V601 remove essa abordagem e usa um ledger persistente de identidade para todos os pilotos.

- Chave persistida: `driverId -> nome normalizado`.
- Se um save já tem ledger e o nome associado a um ID mudar, os sete atributos desse ID voltam ao perfil canônico e os mapas de fase, banco, pressão, alvos, rounds processados, ganhos e baselines daquele ID são removidos.
- Outros IDs permanecem intactos.
- Saves antigos sem ledger são migrados de forma conservadora: atributos válidos são preservados porque Overall baixo pode ser uma regressão legítima; o ledger atual é criado para prevenir colisões futuras.
- Os 20 ratings dedicados a reservas agora são usados diretamente na construção do elenco, em vez de usar inadvertidamente só o catálogo de perfis.
- O plano de pneus continua usando o catálogo de carreira atual, inclusive transferências.

## Limitação importante
Não é possível reconstruir com certeza a identidade histórica de cada ID num save legado que nunca guardou nomes junto dos atributos. Não resetamos dados válidos por suposição. Para corrigir colisões já existentes nesses saves, é necessária uma tabela de migração explícita com os pares ID/nome antes e depois da alteração.

## Validação
- Testes estáticos dedicados: executados após empacotamento.
- Auditorias estruturais do projeto e release: executadas.
- Compilação Android/JUnit/emulador: não executados neste ambiente.
