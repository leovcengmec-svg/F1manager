# V734 — correção do GP30 e progressão da faixa adicional de Overall

Base: V733. Público: F1 Team Manager V30.

## 1. Finalização do GP30
- Adicionada a etapa `ai_canonical_next_season_garages` ao `RaceFinalizationPlan`, somente na última corrida da temporada.
- A etapa fica depois de `season_prizes` e antes de `persist_final_state`.
- O `MainActivity` utiliza a constante oficial do plano, evitando divergência entre o nome solicitado e o nome registrado.
- Saves V733 com GP30 pendente podem retomar a finalização a partir do último marcador concluído; não é necessário simular outra corrida.
- O checkpoint canônico usa fingerprint determinístico e gravação atômica por equipe/temporada, permitindo repetição segura se o processo cair antes do marcador do diário.

## 2. Faixa adicional de +5 Overall
- Mantido o índice esportivo normal: metas exclusivamente pela força do carro, tolerância de ±3 e pesos 40% classificação / 60% corrida.
- Criado um índice separado, usado apenas para liberar a faixa adicional da classe. Ele mede a diferença em relação ao centro da meta do carro e reconhece pole position e vitória como resultados excepcionais.
- Um piloto de equipe líder cuja meta já é P1 pode conquistar margem adicional por poles e vitórias, sem alterar sua meta nem o cálculo normal de evolução/regressão.
- Exigida amostra mínima de cinco GPs reais antes de liberar qualquer ponto adicional.
- Mantidos os níveis de liberação: média 110/120/130/140/150 libera +1/+2/+3/+4/+5.
- A margem conquistada é um máximo acumulado da temporada; uma oscilação posterior da média não retira margem já conquistada.
- Pilotos Pro sem equipe usam apenas a evidência real da última temporada completa. Nenhum resultado é inventado durante o período sem contrato.
- O Centro de Desenvolvimento recebe média, quantidade de GPs e margem já conquistada; pontos reservados são reaplicados quando a margem fica disponível.
- Jogador e IA usam os mesmos critérios nos fluxos de carreira e Team Manager.

## 3. Migração e compatibilidade
- Migração única V734 reprocessa resultados reais salvos e metas congeladas exclusivamente por força do carro para reconstruir a evidência da margem adicional.
- Para o GP corrente não processado, a migração exclui a corrida atual para evitar contabilização dupla; se o GP já foi processado, inclui o resultado salvo e respeita o marcador de idempotência.
- Mantidos os registros antigos de evolução normal para a avaliação bienal de classe.
- Preservados os limites de potencial, a desaceleração acima do teto normal, as regras de idade, o piso de atributo e os limites anuais.

## 4. Testes focados
- 10 testes Kotlin focados passaram: pole/vitória de equipe líder, pesos 40/60, amostra mínima, persistência monotônica, piloto Pro contratado/livre, reserva do Centro de Desenvolvimento e retomada/idempotência do GP30.
- A compilação Kotlin do núcleo de evolução/desenvolvimento e do diário de finalização passou.
- A compilação integral do projeto Android, a suíte JUnit completa e `assembleDebug` não foram concluídos neste ambiente; não se declara APK compilado.
