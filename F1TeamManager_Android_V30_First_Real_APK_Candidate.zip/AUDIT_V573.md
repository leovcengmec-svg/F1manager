# Auditoria V573 — catálogo personalizado

## Causa raiz
O carregamento anterior convertia falhas de parsing em listas vazias por meio de `getOrDefault(emptyList())`. Isso ocultava corrupção e permitia que uma edição subsequente persistisse um catálogo incompleto. Além disso, `editTeam` aceitava nomes de asset sem a validação aplicada na criação.

## Correção
O carregamento agora analisa os três conjuntos em snapshots temporários e publica o snapshot somente quando não há erros de parsing ou inconsistências estruturais. A API `integrityIssues()` expõe os problemas detectados. Operações de escrita são bloqueadas enquanto a origem estiver inconsistente, evitando sobrescrita destrutiva automática. A edição de equipe aplica validação estrita ao nome do asset.

## Limitações
A versão expõe os diagnósticos no domínio, mas não introduz ainda uma tela interativa de reparo. Dados inválidos permanecem no armazenamento original e não são descartados; um fluxo de recuperação explícito deverá ser implementado antes de permitir edição novamente.

## Testes
Foram adicionados testes de contrato. Eles não foram executados neste ambiente. A compilação Android também permanece pendente.
