# Auditoria de correção — V591 — Mercado de pilotos

Base oficial recebida: V590 (`versionCode 590`, `versionName 0.590.0`).
Entrega: V591 (`versionCode 591`, `versionName 0.591.0`).

## Alterações aplicadas

1. **Renovação da IA:** `processAiMarketWeek` agora chama `makeOffer` para renovações, preservando prazo de 2–3 semanas e resposta por `expireOffers`. A renovação fica pendente, permitindo ofertas concorrentes até uma assinatura válida.
2. **Evitar duplicação semanal:** a IA não recria a mesma proposta de renovação enquanto houver negociação pendente/contraproposta para o mesmo piloto, equipe e temporada-alvo.
3. **Classificação de aceite:** aceite da proposta para a própria equipe gera evento `RENOVAÇÃO DE CONTRATO`; contratação por equipe diferente gera `CONTRATO ASSINADO`.
4. **Taxa de movimentação:** contagem passa a derivar dos compromissos assinados em `scheduled`, filtrados por `signedSeason` e `startSeason`, em vez de contar títulos de notificações. O tipo é determinado por `fromTeamId == toTeamId`.
5. **Faixa configurável:** removidos os clamps degenerados `coerceIn(55, 55)` e substituídos por faixa válida `coerceIn(40, 60)`. O alvo corrente continua em 55% renovações / 45% trocas.
6. **Agentes livres na virada:** o fallback de ocupação consulta o orçamento da equipe e aplica taxa de assinatura de 20% do valor de mercado, com dedução cumulativa do orçamento disponível. Se um mapa de orçamento foi fornecido e a taxa não cabe, não contrata sem cobertura. Para chamadas antigas que não fornecem mapa, mantém-se a compatibilidade anterior.
7. **Teste de equilíbrio:** `MarketMovementMixTest` agora mede compromissos assinados na temporada, e não só notificações; exige dados suficientes antes de validar a banda.

## Limitações / pontos para validação posterior

- A regra de 55/45 continua sendo uma meta de mercado com tolerância, não uma garantia matemática por temporada: elegibilidade, qualidade de ofertas, concorrência, orçamento e disponibilidade podem afetar a amostra.
- A contratação emergencial na virada continua sendo um fallback de integridade do grid; como a transição de temporada é atômica, o prazo de 2–3 semanas é simulado internamente, sem exibir semanas intermediárias na carreira. O fallback usa proposta e resposta do motor, consulta o orçamento explícito e desconta taxas cumulativamente.
- A suíte Gradle/JUnit e uma simulação Android completa de duas temporadas não puderam ser executadas neste ambiente. Os testes foram adicionados ao projeto, mas não se afirma que foram executados ou que o APK foi validado.
