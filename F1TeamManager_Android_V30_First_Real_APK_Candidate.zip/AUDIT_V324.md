# Auditoria V324 — Modal de P&D

## Comparação objetiva com a referência aprovada (imagem 2)

- **Dimensões:** referência mostra o modal quase preenchendo a área útil, com quatro opções de complexidade e os dois botões visíveis. A versão atual tinha cards de foco mais altos, cabeçalho mais alto e só parte da terceira opção visível na captura. V324 reduz os blocos e usa 96% da altura útil, com rolagem de segurança.
- **Margens e espaçamentos:** atual tinha 14 dp horizontais, 12 dp verticais e 11 dp entre elementos; referência tem ritmo mais compacto. V324 passa para 12 dp, 9 dp e 7 dp.
- **Cores:** mantém fundo escuro, superfície azul-carvão, contorno cinza e destaque vermelho aprovados; a seleção continua com preenchimento vermelho escuro e borda vermelha.
- **Tipografia:** reduz título do componente de 19 para 17 sp, subtítulo de 12 para 11 sp, rótulos de foco para 11 sp e metadados para 9 sp. Títulos e metadados têm uma linha para impedir quebra que altere alturas.
- **Alinhamento:** ícones do foco agora usam a mesma família Material Icons, com tamanho fixo de 25 dp. Ícones de complexidade são barras vetoriais de dimensões consistentes; seleção usa RadioButton nativo.
- **Proporções:** cards de foco ficam em 112 dp; cada card de complexidade tem exatamente 68 dp; ícone interno de complexidade tem 40 dp; botões passam para 48 dp e 44 dp.
- **Comportamento:** seleção e ações existentes preservadas. Conteúdo longo é truncado de forma controlada em vez de criar alturas variáveis; rolagem permanece como fallback para telas menores.

## Limitações conhecidas
- A aparência final depende da densidade e da área útil do dispositivo; a referência foi fornecida como imagem, não como especificação de dp.
- ZIP verificado estruturalmente; não houve build Gradle nem teste visual no aparelho.
