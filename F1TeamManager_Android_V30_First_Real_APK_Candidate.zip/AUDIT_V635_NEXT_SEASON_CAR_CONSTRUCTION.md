# Auditoria V635 — Construção do carro do próximo ano

## Base e preservação

- Base de trabalho: ZIP V634 fornecido nesta conversa.
- A versão V634 fornecida permaneceu intacta. A entrega V635 foi criada na cópia extraída e recebeu um novo nome de pacote.
- `app/build.gradle.kts` declara `versionCode = 635` e `versionName = "0.635.0"`.
- Nenhum arquivo de assets foi removido intencionalmente. O histórico de versões foi preservado.

## Regras verificadas no código

1. Investimento positivo: selecionar a maior referência da tabela coberta pelo caixa reservado, aplicar +10% uma vez, arredondar e limitar o Overall a 100.
2. Investimento zero: reutilizar o carro físico anterior sem bônus.
3. Construção física: preservar identidades de peças, versões presentes no objeto durante a construção, confiabilidade e componentes ausentes; não gerar hardware por investimento.
4. Foco/P&D: alterar o perfil relativo dos componentes sem somar novamente esses ganhos à média-alvo.
5. Caminho legado: usar a mesma tabela e resetar os marcadores de investimento após a virada.
6. IA: inverter a fórmula de +10% para escolher a referência da construção final. O ganho-alvo é até +3 para Overall abaixo de 60, até +2 entre 60 e 79 e manutenção do Overall alcançável a partir de 80; caixa, reserva operacional, alocação da fase e teto de €150M continuam como limites.
7. Previsão: calcular pelo mesmo caminho físico/legado da virada, para exibir um resultado alcançável em situações-limite.
8. Regulamento anual/decenal: mantido fora da construção e aplicado pela etapa de virada existente.

## Verificações executadas

- Harness Kotlin isolado do `CarDevelopmentEngine`: 29 verificações aprovadas para os exemplos de €43M, €50M, €70M, €100M, €130M e €150M; inversão do bônus para metas da IA; zero investimento; construção física; confiabilidade; identidade de peças; especialização; caminho legado; previsão; e transição de temporada.
- Foram incluídos 8 métodos de teste de regressão em `NextSeasonCarConstructionV635Test.kt`; todos os 8 foram compilados/executados com um runner Kotlin e stubs JUnit locais, fora do ZIP do projeto.
- Auditoria estática `tools/race_sim_test/validate_project.py`: 40/40 verificações aprovadas.
- Auditoria específica `tools/race_sim_test/v635_next_season_car_construction_audit.py`: 13/13 verificações aprovadas.
- Stress test determinístico do mapeamento de construção, assumindo caixa ilimitado e sem aplicar P&D/regulamento: metas antigas de investimento na linha `Overall atual +3` levavam um carro em Overall 80 a 100 em duas viradas; investir sempre na referência do Overall atual levava um carro 80 a 100 em três viradas. A política invertida com ganho até +2 abaixo de 80 e manutenção a partir de 80 não empurra mecanicamente carros em 80 ou 90 para 100. Este teste isola apenas a fórmula; não é uma simulação financeira end-to-end da carreira.

## Limitação de execução

O ZIP recebido não contém `gradlew` e o ambiente de trabalho não dispõe de uma instalação Gradle acessível. Portanto, não foi possível executar `assembleDebug` nem a suíte JUnit Android completa. A compilação isolada valida o motor central com stubs mínimos; ela não substitui uma build Android completa nem uma simulação end-to-end dentro do aplicativo.

## Decisões de projeto

- A previsão pode ser inferior à meta matemática se a garagem estiver com peças ausentes ou se os limites de componente tornarem a meta impossível; nesse caso, a interface mostra o resultado alcançável, sem criar peças virtuais.
- A política da IA desacelera o crescimento gratuito por construção; equipes fortes ainda podem evoluir com P&D real, e equipes com caixa insuficiente podem terminar abaixo da meta. Uma simulação financeira end-to-end com todos os 40 times continua necessária para validar resultados de carreira completos.
