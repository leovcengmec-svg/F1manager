# Auditoria V661 — Mercado de pilotos no modo Team Principal

## Base
- Base recebida: V660 (`versionCode 660`, `versionName 0.660.0`).
- Revisão: V661 (`versionCode 661`, `versionName 0.661.0`).
- Identidade e nome do ZIP preservados.

## Correções
1. Ligação da projeção de carro futuro ao tick semanal usado pela carreira Android em `MainActivity`.
2. Expiração real de ofertas externas recebidas pelo elenco do jogador, sem aceitar/recusar automaticamente em nome do Team Principal.
3. Compensação financeira na saída de piloto: débito da taxa de transferência no destino IA e crédito equivalente na equipe vendedora.
4. Filtro correto para exibir apenas propostas de IA dirigidas a pilotos do elenco do jogador.
5. Bloqueio de duplicatas ativas por equipe/piloto/temporada.
6. Validação de prazo ao aceitar oferta recebida.

## Integridade financeira
- A taxa de transferência usa a regra existente de 40% do valor de mercado.
- O destino IA deve ter caixa suficiente para a primeira parcela; caso contrário, a oferta não é confirmada.
- A taxa é registrada no cronograma financeiro do destino e a mesma quantia é creditada ao time do jogador.
- A equipe que libera o piloto não paga taxa de contratação.

## Verificações e limitações
- ZIP validado com `unzip -t`.
- Conferidos estaticamente os pontos de integração, persistência, expiração e versionamento.
- Testes JUnit adicionados, mas não executados neste ambiente.
- Não foi possível executar build Android: o pacote não contém Gradle Wrapper e o ambiente não disponibiliza Gradle/Android SDK.
- A contraproposta de indenização entre equipes permanece fora do escopo desta revisão; requer extensão persistente do modelo de negociação.
