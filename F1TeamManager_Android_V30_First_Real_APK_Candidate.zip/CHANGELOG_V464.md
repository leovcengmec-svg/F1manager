# V464 — Atualização imediata dos atributos após desenvolvimento de piloto

- Corrigido o estado derivado da lista de pilotos: após a conclusão do programa e a persistência dos sete atributos, a lista `DriverDefinition` é reconstruída para refletir os novos valores imediatamente na interface.
- Isso atualiza OVR, atributos e telas dependentes sem exigir reinício da carreira.
- Preservados os pontos do programa, a distribuição por atributo e o salvamento já existente.
- Build Android ainda precisa ser executado no ambiente de compilação.
