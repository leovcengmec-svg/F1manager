# V623 — Eventos operacionais usam o modal oficial

- Corrigida a apresentação na Home para que “INSTALAÇÃO CONCLUÍDA”, “JANELA DE TRANSFERÊNCIA ABERTA” e “PROGRAMA DE DESENVOLVIMENTO CONCLUÍDO” deixem de ocupar cards inline grandes e usem o mesmo modal centralizado dos demais eventos.
- Reutilizada a arte já existente de cada evento, com categoria, título, temporada/semana, descrição, botão CONTINUAR e ação principal.
- O botão da abertura do mercado agora se chama “ABRIR MERCADO” e navega diretamente ao Mercado de Pilotos.
- Filtragem ajustada para priorizar avisos da equipe do jogador e o desenvolvimento dos pilotos atuais, evitando mostrar desenvolvimento de piloto de outra equipe como evento do jogador.
- Removido o composable de card inline que não será mais utilizado.
- Preservados motores de jogo, regras, saves e os 195 assets existentes.
- Build Android completo ainda precisa ser confirmado pelo pipeline; este ambiente não possui Gradle instalado e o pacote não contém `gradlew`.
