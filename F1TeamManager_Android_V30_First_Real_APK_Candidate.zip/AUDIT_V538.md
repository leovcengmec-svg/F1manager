# Auditoria V538

## Alterações
- MainActivity roteia as seis faixas pelos estados reais da tela.
- A faixa de vitória brasileira é selecionada pelo país do piloto em primeiro lugar na classificação final e pelos dados atuais do catálogo de pilotos.
- Catálogo e instruções limitados aos seis assets pedidos.
- Versionamento atualizado para 538 / 0.538.0.

## Limitações de validação
- ZIP validado estruturalmente.
- Não há Gradle instalado nem wrapper Gradle incluído neste pacote; compilação Android e teste em dispositivo não executados neste ambiente.
- Não inclui gravações de áudio reais. A reprodução exige arquivos válidos na pasta externa e permissão do Android.
