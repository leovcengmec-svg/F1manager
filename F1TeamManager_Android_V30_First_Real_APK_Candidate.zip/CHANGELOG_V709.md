# V709 — envelhecimento completo, progressão dos pilotos livres e trava de investimento

**VersionCode:** 709  
**VersionName:** 0.709.0  
**Base:** V708  
**Nome público:** F1 Team Manager V30

## Evolução e envelhecimento dos pilotos

- A curva de envelhecimento agora pode reduzir todos os sete atributos individuais: VEL, CLA, ULT, DEF, CON, CHU e PNE. A seleção permanece distribuída e reproduzível pela semente do GP, sem ficar restrita a três índices.
- O piso permanente de 40 continua aplicado a cada atributo.
- O histórico de perdas por idade e os picos históricos são mantidos nos campos e nas chaves de save já existentes (`driverAgePhysicalLosses` e `driverAgePhysicalPeaks`) para preservar compatibilidade; os vetores continuam com sete posições, mas agora representam os sete atributos.
- Ao reiniciar o ciclo etário, 50% do total de perdas naturais acumuladas é recuperado, com arredondamento agregado por maiores restos e limite no pico histórico de cada atributo. A recuperação não reverte perdas esportivas.
- As notícias mostram os códigos dos atributos efetivamente alterados e identificam separadamente envelhecimento, recuperação de ciclo e desempenho esportivo.

## Pilotos sem equipe

- Pilotos livres recebem o índice neutro de progressão (105) e a mesma taxa natural-base de crescimento que pilotos contratados.
- A evolução pode ultrapassar o teto de classe e continuar até o potencial individual, respeitando perfil de evolução, limite anual por atributo e Overall 100.
- Pilotos sem equipe não recebem penalidade por posição de classificação/corrida nem regressão por desempenho esportivo fictício.
- Ao entrar no fluxo de agente livre, saldo fracionário negativo herdado de um período contratado é zerado; saldo positivo é preservado. Daí em diante, perdas de atributos no período sem equipe só vêm da curva natural de envelhecimento.
- O motor de mercado continua usando Overall atual, potencial, perfil de evolução e interesse da equipe para considerar propostas/contratações.

## Próximo carro — proteção financeira

- A previsão calcula o Overall máximo permitido para a temporada a partir da regra por faixa.
- O investimento-alvo é calculado pelo valor mínimo da tabela necessário para alcançar esse Overall.
- A interface limita os botões ao saldo exato que falta para a meta e os desativa quando a meta de Overall/investimento é alcançada, quando o limite anual financeiro termina ou quando a reserva operacional impede novo aporte.
- `CarDevelopmentEngine.investNextSeason` valida a mesma regra no núcleo: não aceita aportes depois da meta, acima do saldo restante, acima do limite anual ou que consumam a reserva operacional.
- Caso a configuração física impeça atingir o teto nominal, o motor bloqueia novos aportes ao alcançar o investimento-meta e informa que a configuração não converte mais investimento em Overall.

## Testes adicionados/atualizados

- Distribuição de perdas de envelhecimento entre os sete atributos.
- Recuperação agregada de 50% nos sete atributos, limitada aos picos históricos.
- Crescimento de piloto livre além do teto de classe até o potencial individual.
- Proibição de regressão esportiva para piloto livre, inclusive ao receber saldo negativo legado.
- Mensagens de notícia com causa e atributos individualizados.
- Bloqueio de investimento em Overall 46 → 53 no aporte-alvo de €31M; rejeição de excesso e aceitação somente do valor exato que falta.

## Limites de validação

A auditoria estática e os testes auxiliares executáveis no ambiente foram realizados. A compilação Android integral e a suíte JUnit/Gradle completa dependem do GitHub Actions/Android SDK, que não estão disponíveis no ambiente local desta revisão.
