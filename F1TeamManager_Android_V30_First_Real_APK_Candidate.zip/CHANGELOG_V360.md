# V360 — Persistência resiliente do histórico da carreira

## Bloco implementado
- O arquivo `f1tm_historical_v2.db` passa a ser lido e gravado por `android.util.AtomicFile`.
- Gravações usam arquivo temporário gerenciado pelo Android, `flush()`, `fd.sync()` e `finishWrite()`; falhas chamam `failWrite()` e são propagadas.
- A leitura não converte falha de I/O em arquivo vazio, evitando que um problema temporário de leitura seja interpretado como ausência de histórico e sobrescreva dados antigos.
- `recordRace()` e `finalizeSeason()` são sincronizados na instância para impedir gravações concorrentes que leiam o mesmo estado e descartem atualizações umas das outras.
- A operação `clear()` usa `AtomicFile.delete()` para limpar também os arquivos auxiliares gerenciados.
- Versão Android incrementada para `0.360.0`.

## Escopo preservado
- Nenhuma alteração de interface ou botões.
- Nenhum asset externo ou arquivo do histórico de versões foi removido.
- O nome oficial do ZIP permanece `F1TeamManager_Android_V30_First_Real_APK_Candidate.zip`.
