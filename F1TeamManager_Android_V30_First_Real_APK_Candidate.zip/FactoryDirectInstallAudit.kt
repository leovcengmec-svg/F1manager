import com.f1teammanager.core.manager.*
import com.f1teammanager.core.season.WorldDatabase

fun main() {
    val team = WorldDatabase.teams.first { it.name == "Red Bull Racing" }
    val garage = TeamGarageFactory.fromInitial(team)
    val design = ResearchDesign("AUDIT-DESIGN", CarComponent.ENGINE, 2, garage.car1.engine + 4, 90, 2026, 1)
    val state = TeamManagerState(
        season = 2026, round = 1, playerTeamId = team.id,
        car = InitialTeamProfile.carState(team), garage = garage,
        facilities = InitialTeamProfile.teamFacilities(team.initialLevel),
        research = TeamResearchState(completedDesigns = listOf(design)),
        finance = TeamFinanceState(100_000_000L)
    )
    val engine = FactoryEngine()
    val option = engine.options(design, state.facilities).first()
    var current = engine.start(state, design, option, 1)
    current = engine.advanceWeeks(current, option.weeks, 1)
    val pending = current.factory.pendingInstallations
    check(pending.size == 1) { "expected one manufactured piece awaiting manager assignment" }
    val unchangedGarage = current.garage ?: error("garage missing")
    check(unchangedGarage.car1.engine == garage.car1.engine && unchangedGarage.car2.engine == garage.car2.engine) { "factory auto-installed the piece" }
    val piece = pending.first()
    val assigned = unchangedGarage.install(piece, GarageCarId.CAR_2)
    val finalFactory = current.factory.copy(pendingInstallations = pending.drop(1))
    check(assigned.car2.engine == design.performance)
    check(finalFactory.pendingInstallations.isEmpty())
    println("V112_NO_STOCK_FACTORY_OK pending=1 autoInstall=false manualTarget=CAR_2")
}
