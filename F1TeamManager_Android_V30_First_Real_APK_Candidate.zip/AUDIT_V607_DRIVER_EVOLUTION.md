# Auditoria V607 — pilotos com evolução Normal

## Alteração aplicada
- O catálogo contém 100 perfis oficiais.
- Foram alterados 53 perfis cujo tipo de evolução era `Normal`, passando para `Auge moderado`.
- Após a alteração, 73 perfis estão configurados como `Auge moderado` e nenhum permanece como `Normal`.
- As classes e os sete atributos de cada piloto foram preservados; somente o campo de evolução foi modificado nos 53 perfis selecionados.
- Removida a exceção antiga que forçava o tipo `Normal` para pilotos originalmente cadastrados na classe `Fraco`, impedindo que a configuração solicitada fosse revertida por essa regra. A normalização da classe continua preservada.

## Verificações
- `audit_v607_driver_evolution.py`: PASS — 100 perfis, 0 evoluções `Normal`, sete atributos por perfil.
- `validate_project.py`: PASS — 40/40 verificações.
- Build Android, suíte JUnit completa e execução em dispositivo/emulador não foram realizados neste ambiente.

## Validação funcional obrigatória
Testar criando uma carreira nova pelo fluxo **Novo Jogo**. A atualização do catálogo é aplicada a novas carreiras; saves existentes não são apagados nem alterados automaticamente.
