# Auditoria V424

## Escopo
Garantir que a tabela individual de referência financeira por Overall seja usada na criação do carro da temporada seguinte, e não somente na apresentação da previsão.

## Verificações no código
- `nextSeasonForecast` obtém `referenceInvestmentForOverall(overall)`.
- `startNextSeason` calcula o Overall do carro antigo e usa `nextSeasonInvestmentSteps(overall, old.nextSeasonInvestment)`.
- A função comum `nextSeasonInvestmentSteps` usa a mesma tabela individual 40–100 e os mesmos limiares de efeito.
- O carro novo é criado com `nextSeasonInvestment = 0L`, impedindo que o saldo investido seja reaplicado na próxima virada.
- `ManagerSeasonEngine` chama `development.startNextSeason` ao fechar a temporada; o fluxo manual de início da temporada também chama a mesma função.
- Testes-fonte verificam referências estritamente crescentes, uso real da referência por Overall e zeragem do investimento depois da virada.

## Limitações
A inspeção estática do código e a integridade do arquivo ZIP podem ser verificadas aqui. Não há Gradle wrapper no pacote e o comando `gradle` não está disponível neste ambiente; portanto, compilação Android e testes automatizados permanecem pendentes.
