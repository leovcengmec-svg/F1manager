# Auditoria V403

## Escopo
Aleatoriedade do sistema de eventos anuais que afetam pilotos e equipes.

## Verificações estáticas
- Não restam usos de `20261010` no `MainActivity.kt`.
- A semente anual é gerada com `Random.nextInt()`, persistida em `annualEventSeed_<temporada>` e reutilizada no carregamento.
- Nova carreira limpa as chaves `annualEventCalendar_*`, `annualEventProcessed_*` e `annualEventSeed_*` antes de criar eventos novos.
- `versionCode=403`, `versionName=0.403.0`.

## Limitação
O ZIP pode ser verificado estruturalmente, mas compilação Android e testes integrados precisam ser executados no ambiente Gradle do projeto.
