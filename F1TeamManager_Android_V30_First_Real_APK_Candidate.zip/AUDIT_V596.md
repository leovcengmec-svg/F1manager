# V596 — Auditoria de layout e baseline técnico

## Alterações
- Menu principal: logotipo e bloco de navegação alinhados no topo da área útil, deixando a marca mais alta na área escura.
- Os três cards passaram a ter altura explícita e compacta (62/70/78 dp conforme altura disponível), com espaçamento reduzido e distribuição centralizada no espaço restante. Não foi introduzida rolagem vertical.
- Estrutura e ícones dos três cards foram mantidos; somente dimensões, respiros e hierarquia vertical foram ajustados.
- `TeamGarageFactory.fromCarState` e `TeamGarageFactory.fromInitial` inicializam todas as versões de componentes em V0.
- `AITeamDevelopmentEngine` considera V0 como baseline quando a versão do componente não está presente. A primeira pesquisa de cada componente continua sendo V1, conforme `ResearchEngine`.

## Verificações estáticas
- `versionCode = 596`, `versionName = 0.596.0`.
- Busca estática não encontrou mais defaults de versão física inicial `associateWith { 1 }` nem fallback `installedPieceVersions[component] ?: 1` no código de produção.
- Assets e histórico existentes não foram removidos.

## Limitações
A compilação Android, JUnit e inspeção visual no Poco X7 Pro não foram executadas neste ambiente. A integridade do ZIP é verificada separadamente após empacotamento.
