# V703 — correções do mercado de pilotos e persistência de desenvolvimento

## Mercado de pilotos da IA
- Corrigido o filtro que removia pilotos da equipe do jogador antes de chegar ao ramo de criação de propostas recebidas. A IA agora pode abordar pilotos do jogador somente quando estão no último ano de contrato; contratos plurianuais continuam protegidos contra abordagens no meio do vínculo.
- O conjunto de candidatos é compartilhado entre as janelas de contratação e a análise de renovações, evitando regras divergentes. Propostas recebidas continuam pendentes de decisão manual do Team Principal e não assinam automaticamente.
- Rebalanceada a duração dos contratos: o potencial individual agora é considerado antes do Overall atual. Pilotos de 26–29 anos com potencial ≥90 recebem planos de 3–5 anos; potenciais altos não caem automaticamente no ramo genérico de um ano apenas por ainda estarem abaixo do Overall de auge.

## Desenvolvimento de pilotos da IA
- A persistência da fila agora grava e restaura também `reservePoints`, além dos programas ativos. O codec lê registros V702 antigos sem pontos reservados e converte para reserva vazia, sem quebrar saves existentes.
- Na virada de temporada, programas de pilotos que deixaram a equipe são cancelados imediatamente, a vaga é liberada e a Central de Notícias registra o piloto, a equipe de origem e o destino.
- Foi adicionada uma proteção no processamento antes do GP para remover qualquer programa órfão que apareça por alteração de elenco fora do fluxo normal de virada. Pontos reservados permanecem persistidos no estado da equipe.

## Testes adicionados
- Round-trip do codec de filas e pontos reservados.
- Compatibilidade com filas de save V702.
- Elegibilidade de pilotos do jogador no último ano de contrato e bloqueio durante contrato plurianual.
- Cancelamento de programa e liberação da vaga após transferência.
- Contrato plurianual para piloto de alto potencial mesmo com Overall atual baixo.

## Limites de validação
- A validação estática e a integridade do ZIP são executáveis neste ambiente. A compilação Android integral e a suíte JUnit completa continuam dependendo do Gradle/Android SDK no GitHub Actions.
