# V635 — Construção do carro do próximo ano por investimento

## Modelo de construção

- A tabela investimento → Overall passa a ser a referência única da construção do próximo carro.
- Um investimento positivo seleciona o maior Overall cuja referência é coberta pelo valor reservado e aplica o bônus de construção de 10% uma única vez, arredondando para inteiro e limitando a 100.
- Sem investimento, o carro físico anterior é reaproveitado sem bônus de construção.
- A construção física preserva as diferenças relativas entre componentes, a confiabilidade e a identidade das peças instaladas; hardware ausente não é criado artificialmente.
- Foco e conhecimento técnico podem especializar componentes, mas o deslocamento de normalização impede que esses pontos sejam somados novamente ao Overall médio.
- O caminho legado de `TeamCarState` segue a mesma conversão, mantendo saves compatíveis.

## IA e previsão

- A IA inverte a fórmula de +10% para definir o investimento de referência do resultado final: até +3 Overall quando está abaixo de 60, até +2 entre 60 e 79 e manutenção do Overall alcançável a partir de 80. As contribuições continuam limitadas pelo caixa real, reservas operacionais, alocação da fase e o teto acumulado de €150M.
- A previsão da tela do carro e o resumo da equipe usam o resultado alcançável da construção física, em vez de prometer uma meta teórica quando existem componentes ausentes ou limites físicos.
- O painel do próximo carro armazena em memória a previsão enquanto os dados que influenciam a construção não mudarem, reduzindo recálculos durante recomposições da interface.
- P&D e foco especializam o carro sem duplicar o bônus; as regras anuais e decenais permanecem em suas etapas existentes, depois da construção e uma única vez.

## Versionamento e compatibilidade

- `versionCode = 635`, `versionName = "0.635.0"`.
- Mantida a sequência histórica de versões, os assets externos, as bandeiras, os escudos, os GPs, os carros, os retratos, as peças e os saves existentes.
- O ZIP oficial recebido como V634 não foi alterado; esta é uma nova cópia de trabalho/release.
