# Auditoria v688 — correção do erro de compilação reportado

## Erro reportado no GitHub Actions

O build v687 falhou em `PlayerHomeNotificationPolicy.kt` porque o modelo `MarketNotification` não disponibilizava `relatedTeamId`, embora a política e os pontos de emissão/persistência já tentassem utilizá-lo.

## Correção conferida no código-fonte v688

- `MarketNotification` declara `val relatedTeamId: Int? = null`, mantendo compatibilidade com chamadas antigas que não informam equipe.
- A leitura de `marketNotifications` aceita registros antigos com seis campos e lê o sétimo campo opcional quando presente.
- A gravação persiste `relatedTeamId` no sétimo campo.
- A política de Home mantém eventos de assinatura, renovação e transferência confirmada como notícias globais; propostas, recusas, contrapropostas e expirações são filtradas pela equipe do jogador.
- O nome do artefato APK no workflow foi atualizado para v688.

## Limite da validação

O ambiente desta execução não tem Gradle instalado nem Gradle Wrapper no repositório. Portanto, a compilação Android/JUnit não foi executada localmente. A confirmação final depende do workflow GitHub Actions.
