# F1 Team Manager V30 — V723

VersionCode: 723  
VersionName: 0.723.0  
Base: V722 / 0.722.0

## Correções de compilação Kotlin

- Removido o modificador `private` da função local `advanceFreeWeeksSegment` dentro de `F1ManagerApp`; funções locais Kotlin não aceitam modificadores de visibilidade.
- Corrigido o fechamento de parênteses na persistência do avanço semanal: `saveCareerStepBundle(...)` agora é fechado antes do bloco de mensagem de falha de `check(...)`.
- Preservado o salvamento atômico do estado semanal, dos eventos anuais processados, dos snapshots financeiros e da semana atual.
- Conferidos os demais pontos de chamada de `saveCareerStepBundle` em `MainActivity.kt`; os outros usos já tinham a estrutura correta e foram preservados.

## Preservação funcional

- Mantidas as regras V722 da tabela Overall × investimento e do limite anual de perda de 10 pontos de Overall.
- Mantidos áudio individual do jogo, ranking das equipes, eventos anuais, persistência de instalações e otimizações de escalabilidade.
- Nenhuma alteração retroativa em saves ou histórico de carreira.

## Validação

- Verificação estática focada V723: ver resultado em `AUDIT_V723_BUILD_FIX.md`.
- Validação do contrato de release e auditorias de regressão preservadas executadas no pacote.
- A compilação Android/Gradle e os testes JUnit precisam ser confirmados pelo GitHub Actions; este ambiente não dispõe de Android SDK, Gradle Wrapper ou instalação Gradle configurada.
