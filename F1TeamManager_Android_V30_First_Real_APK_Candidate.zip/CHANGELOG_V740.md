# V740 — Mercado Contratual Realista e Eventos Econômicos Dinâmicos

## Contratos de pilotos
- Duração padrão da IA passa a priorizar Overall atual e desempenho esportivo; potencial é apenas um modificador secundário quando o piloto já demonstra nível competitivo.
- Pilotos com Overall abaixo de 65 ficam limitados a contratos curtos; faixas intermediárias recebem 1–3 anos; atletas de elite podem justificar 4–5 anos. Os limites etários 16–45 permanecem obrigatórios.
- Contrapropostas passam a utilizar a mesma política de duração, evitando exigências aleatórias de quatro ou cinco anos por pilotos fracos.
- Equipes controladas pela IA avaliam contratos longos a partir da terceira temporada: 3/4 exige desempenho significativamente abaixo do companheiro; 4/5 aceita uma diferença sustentada menor. O piloto é colocado em contrato aberto, sem rescisão automática.
- O jogador pode colocar manualmente um piloto de sua equipe em contrato aberto durante a janela de mercado. O contrato atual continua válido até uma transferência futura ser assinada.
- O estado de contrato aberto, temporada e semana de abertura é persistido; saves antigos sem esses campos continuam sendo carregados como contratos fechados.

## Eventos financeiros anuais
- Crises anuais: distribuição de 15% sem crise, 45% com uma, 30% com duas e 10% com três; 85% de probabilidade de ao menos uma crise.
- A seleção de alvos financeiros dá maior peso ao quartil com maior caixa real. A crise debita entre 5% e 12% do saldo atual, limitada a 18% do caixa de referência da temporada por equipe.
- O limite acumulado de crise é persistido para jogador e IA e aplicado após cada ocorrência, evitando perdas em cascata acima do teto.
- Aquisição por investidores aumenta de 30% para 45% de chance anual.
- Novo evento de aporte financeiro estratégico: 65% de chance de um ou dois aportes anuais; créditos diretos de €25M a €100M, priorizando equipes fracas e com pouco caixa. O aporte não amplia os limites anuais de P&D.
- Calendários antigos já salvos não são regenerados; os novos sorteios valem para calendários futuros ainda não criados.

## Compatibilidade e validação
- Novos campos de contrato e de contabilidade financeira são opcionais no carregamento; saves antigos mantêm o comportamento anterior até eventos/negociações novas.
- Testes adicionados para duração por Overall, abertura manual/automática de contratos, frequência de crises/aportes, seleção de alvos e limite de 18% de perdas acumuladas.
- Compilação isolada Kotlin do motor de eventos e smoke tests determinísticos aprovados. A compilação Android completa e a suíte Gradle devem ser confirmadas pelo GitHub Actions; o pacote não contém Gradle Wrapper.

VersionCode 740 · VersionName 0.740.0 · Base V739.

## Correção complementar — Desenvolvimento de pilotos (V740)
- Confirmado e reforçado o contrato funcional: pontos da instalação são convertidos exclusivamente em incrementos de atributos individuais (Velocidade, Classificação, Ultrapassagem, Defesa, Consistência, Chuva e Pneus); não existe atribuição direta de pontos ao Overall.
- A margem extra de classe (+1 a +5) funciona somente como limite de progressão permitido pela categoria/desempenho; não é crédito de Overall.
- A notícia de conclusão deixou de exibir apenas `Overall X → Y`, que podia sugerir concessão direta de Overall. Agora apresenta cada atributo efetivamente alterado e seu delta.
- Teste de regressão V740: programa de 5 pontos deve somar exatamente +5 na soma dos sete atributos, sem ganho direto de Overall e sem pontos reservados quando há margem elegível.
