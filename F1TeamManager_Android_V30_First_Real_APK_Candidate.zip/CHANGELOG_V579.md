# V579 — Tabela oficial de investimento por Overall

- Corrigida a tabela central de investimento de referência para coincidir com os 61 valores aprovados, de Overall 40 a 100.
- Overall 42 agora usa €10M (antes €11,4M), eliminando a divergência que aparecia como aproximadamente €11M na interface.
- A função central continua sendo usada pela previsão/UI e pela lógica de investimento da IA e da transição de temporada.
- Adicionado teste de regressão que compara cada Overall (40–100) com a tabela aprovada e confirma os passos de investimento na referência integral.
- Versão: 579 / 0.579.0.
