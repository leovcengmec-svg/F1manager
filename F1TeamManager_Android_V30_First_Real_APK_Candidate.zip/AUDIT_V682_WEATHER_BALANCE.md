# Auditoria V682 — carro × piloto por clima

Base: V681  
Revisão: V682 (`versionCode 682`, `versionName 0.682.0`)

## Regras confirmadas no código

| Estado | Peso do carro | Peso do piloto |
|---|---:|---:|
| `DRY` | 0.65 | 0.35 |
| `CLOUDY` | 0.65 | 0.35 |
| `LIGHT_RAIN` | 0.55 | 0.45 |
| `MEDIUM_RAIN` | 0.55 | 0.45 |
| `HEAVY_RAIN` | 0.50 | 0.50 |

`RacePerformanceWeights.combinedTimeMultiplier` continua a ser a única combinação do ritmo-base nos métodos `lapTime` e `qualifyingLapTime`, portanto as novas proporções valem para corrida e classificação. O peso do carro e do piloto é definido explicitamente em cada condição, e os testes garantem que a soma é 1,0.

## Correção defensiva complementar

O cálculo de penalidade por chuva foi extraído para `RaceWeatherPerformance.rainPenaltyMs`. Antes de consultar tabelas de influência, `wetSkill` é limitado a 0–100 e `consistency` a 40–100, a mesma faixa mínima/máxima usada no modelo de atributos. Seco e nublado não recebem penalidade de chuva.

## Sistemas preservados

- Perfil de chuva por circuito e probabilidades de transição da V681.
- Sementes aleatórias independentes de classificação e corrida.
- Adequação dos pneus, degradação, estratégia, DRS, ERS e eventos de pista.
- Metas de evolução de pilotos da V681.

A variação aleatória de volta da classificação foi mantida. O código mostra dispersão relativamente larga, mas não foi feita simulação multitemporada suficiente para justificar a alteração do seu modelo.

## Validação

Testes adicionados/atualizados cobrem os cinco estados de clima, soma dos pesos, aplicação 50/50 na chuva forte, limites de atributos inválidos e penalidade nula no seco/nublado. A suíte Gradle completa e o APK não foram executados localmente (sem Gradle Wrapper/Gradle instalado); devem ser confirmados no workflow GitHub Actions.
