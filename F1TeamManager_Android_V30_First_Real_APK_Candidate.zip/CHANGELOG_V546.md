# V546 — Reversão da alteração de DNFs

- Revertidos os ajustes de probabilidade de acidentes e colisões introduzidos na V545.
- Restaurada a lógica original de `CareerWeekendEngine` conforme a V544.
- Mantidas as demais alterações anteriores do projeto.
- Nenhuma redução de DNF faz parte desta versão.
- Build Android e testes automatizados precisam ser executados no ambiente Android/Gradle.
