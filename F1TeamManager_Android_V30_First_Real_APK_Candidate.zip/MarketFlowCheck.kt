import com.f1teammanager.core.manager.*
import com.f1teammanager.core.season.WorldDatabase
fun main(){
 val e=DriverMarketEngine(20261003); var s=e.initialState(2026); val playerTeam=1; val driver=s.freeAgents.first()
 val week=WorldDatabase.rounds.first{it.weekOfSeason>25}.weekOfSeason
 val (s1,o)=e.makeOffer(s,driver,2,2,e.salaryFor(driver),DriverTeamRole.EQUAL,2026,week,1,s.contracts.first{it.teamId==2}.driverId,playerTeam)
 println("created status=${o.status} due=${o.expiresAfterWeek} proposer=${o.proposerTeamId} pending=${s1.pending.size}")
 var x=s1
 for(w in week..(o.expiresAfterWeek+1)) { x=e.processAiMarketWeek(x,2026,w,playerTeam); println("w=$w pending="+x.pending.map{"${it.status}:${it.round}:due${it.expiresAfterWeek}:prop${it.proposerTeamId}"}+" sched="+x.scheduled.size+" notices="+x.notifications.takeLast(3).map{it.title+":"+it.message}) }
}
