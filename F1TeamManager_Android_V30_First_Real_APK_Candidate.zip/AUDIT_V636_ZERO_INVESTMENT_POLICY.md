# Auditoria V636 — Construção universal por investimento

## Regra corrigida

A V635 reaproveitava o carro antigo sem bônus quando o investimento era zero. Isso criava uma exceção que contrariava a regra de que a tabela investimento × Overall determina a construção. A V636 remove essa exceção.

- €0 → Overall-base 0 → alvo de construção 0; com peças instaladas, o piso físico produz Overall 1.
- €1M → Overall-base 5 → alvo após +10% = 6.
- €4M → Overall-base 20 → alvo = 22.
- €7,8M → Overall-base 39 → alvo = 43.
- €8M → Overall-base 40 → alvo = 44.
- Exemplos aprovados a partir de €43M seguem inalterados (por exemplo, €43M → base 59 → 65).

## Continuidade física

A regra não cria hardware inexistente. Em cada carro físico, peças instaladas mantêm seus IDs e versões e preservam os níveis de confiabilidade; o valor de desempenho é normalizado para a meta de investimento alcançável. Componentes ausentes continuam ausentes. O caminho legado segue a mesma meta, e as telas de previsão deixam de mostrar o Overall antigo como se fosse o carro novo.

## Resultado da verificação

- **10/10** métodos de regressão do motor passaram na compilação Kotlin isolada com stubs mínimos, incluindo construção com €0, transição de temporada, previsão, inversão da tabela pela IA, identidade/versão/confiabilidade das peças e monotonicidade física em diferentes perfis de garagem.
- **16/16** verificações do auditor da construção passaram, incluindo monotonicidade de €0 a €150M, os 61 valores da tabela aprovada e o stress de trajetória simplificado da IA.
- **40/40** verificações gerais estáticas do projeto passaram; 195 assets locais verificados, além dos registros históricos V286 e V288.
- A auditoria específica não altera nem elimina os artefatos V635; a auditoria anterior e o teste anterior foram arquivados/preservados no projeto.

## Limites

O ZIP não inclui `gradlew` e este ambiente não tem Gradle/Android configurado. Portanto, **a build Android/assembleDebug e a simulação completa da carreira dentro do aplicativo não foram executadas**. A validação aqui é de código-fonte, testes focados e regras determinísticas, não de uma carreira end-to-end.
