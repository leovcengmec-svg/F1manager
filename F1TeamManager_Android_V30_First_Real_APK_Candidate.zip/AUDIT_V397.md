# Auditoria V397

## Alterações
- `MainActivity.kt`: mensagem de diagnóstico dedicada à Home para falhas da simulação instantânea, persistência e recuperação da finalização.
- `app/build.gradle.kts`: versionCode 397 / versionName 0.397.0.

## Limitação de validação
- A compilação Gradle/Android não foi executada; não afirmar que o APK compila até o workflow externo confirmar.
- Próxima validação funcional: tocar em “PULAR FIM DE SEMANA”. Se a corrida ainda falhar, a Home exibirá a causa devolvida pela simulação em vez de falhar silenciosamente.
