# V434 — Rollback integral e sincronização do estado em memória

- Adicionado `rollbackSeasonTransitionJournal()`, permitido somente antes do checkpoint `STATE_PERSISTED`.
- Se a virada falhar antes do commit durável, a carreira volta ao snapshot anterior e o backup é removido somente após a restauração ser confirmada.
- A tela de carreira reconstrói o `managerState` a partir dos dados restaurados, evitando retry com dados de temporada misturados entre memória e SharedPreferences.
- Se a falha ocorrer depois de `STATE_PERSISTED`, o diário é preservado para que a próxima tentativa apenas finalize a limpeza, sem repetir salário, investimento ou transição.
- Sem alterações de layout, botões ou assets externos.
