# Auditoria V436

## Defeito encontrado
A simulação de clima variável encontrou pneus INTERMEDIATE em pista seca/nublada em carros do jogador com estratégia automática (seeds 8 e 9). A troca só ocorria na próxima janela do plano.

## Correção
O motor da corrida agora normaliza o pneu para as condições atuais antes de executar a janela de stint, quando a estratégia não é manual.

## Regressão
Executar `TargetedAudit.kt` com vários seeds e validar que corridas concluem, transições seco/chuva e chuva/seco ocorrem e estratégias automáticas não ficam com pneu de chuva em pista seca.

## Resultados runtime executados no ambiente disponível
- Compilação Kotlin dos módulos puros de manager/race/season e dos harnesses de auditoria: PASS (warnings de parâmetros/variáveis não usados permanecem).
- Cadeia de duas temporadas (60 GPs, 80 classificados, qualificação Q1/Q2/Q3, mercado, evolução, orçamento, contratos, prêmios e garagem): PASS.
- Eventos anuais: 3.066 assertions, 0 falhas; stress de 200 temporadas, 1.148 slots e 865 resultados de equipe: PASS.
- Auditoria de corrida com clima e combustível em 25 seeds: 25/25 corridas concluídas; transições seco→chuva e chuva→seco cobertas; nenhum alerta repetido após SAVE_FUEL; PASS.
- Auditoria estrutural do projeto: 32/32; auditoria estrutural de release: 21/21; contrato de virada: 9/9.
- Limitação: o ambiente não contém Gradle/Gradle Wrapper nem Android SDK. Portanto, não foi possível executar build Android ou JUnit oficial; a compilação executada é do núcleo Kotlin sem APIs Android/Compose.
