# Auditoria V438

## Alteração financeira

A causa identificada no cenário de estresse foi uma despesa fixa de apenas €850 mil por GP para todas as equipes, independentemente do nível. A regra foi substituída por custo operacional por GP: Forte €2,2M, Médio €1,7M e Fraco €1,2M. A mesma política é usada nos motores financeiro do jogador e da IA. DNF continua acrescentando €450 mil no motor do jogador.

## Verificações

- A tabela de custos é monotônica por nível e tem teste Kotlin dedicado.
- O script de estresse modela cinco temporadas para 40 equipes, mas usa hipóteses explícitas para salários e patrocínios.
- As auditorias estruturais verificam os arquivos, os assets, o histórico e a versão.

## Não confirmado

Não foi possível executar compilação Android, JUnit ou corrida de duas temporadas dentro do motor Kotlin porque Gradle/Android SDK não estão disponíveis no ambiente. A aprovação estrutural não deve ser confundida com aprovação de runtime.
