# V663 — risco real de demissão no Team Principal

Base: V662. Nome público e nome original do pacote preservados.

## Alterações
- A confiança inicial de 75/100 deixou de funcionar como proteção quase absoluta: a tabela de risco agora mantém probabilidade-base positiva em todas as faixas de confiança.
- O risco de demissão no fechamento da temporada passa a combinar confiança da diretoria, posição final versus objetivo, repetição de temporadas ruins, média de posições nas corridas, média de posições nas classificações, estresse financeiro, avanço de pesquisa/fabricação, investimento em instalações e percentual de objetivos cumpridos.
- O histórico de corridas e classificações da equipe é usado para calcular o desempenho esportivo; se não houver dados arquivados, o componente fica neutro, sem inventar resultados.
- Crise financeira, ausência de evolução técnica e ausência de investimento em instalações aumentam o risco de forma independente.
- O risco é limitado a 98%, mantendo a possibilidade de sobrevivência mesmo em cenários muito ruins.
- A notificação de demissão não afirma mais que o apoio caiu quando isso pode não ter acontecido.
- O texto do modo Team Principal foi corrigido para informar contratos de 1 ou 2 anos.
- Versão interna atualizada para versionCode 663 / versionName 0.663.0.

## Validação
- Compilação isolada do núcleo Kotlin de TeamPrincipalCareerEngine concluída com sucesso.
- Testes unitários novos/adaptados adicionados para risco inicial positivo e influência independente de corrida, classificação, finanças, desenvolvimento e instalações.
- Não foi executada a suíte Android/JUnit nem gerado APK neste ambiente: o pacote não inclui Gradle Wrapper e não há Gradle/Android SDK configurado.
