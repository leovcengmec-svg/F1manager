# V581

- Corrigida a fonte dos dados do card de abertura da temporada para usar os dois carros físicos reais de cada equipe.
- Incluída reconstrução da garagem da IA pela cadeia de desenvolvimento e regulamentação da temporada, com investimentos de próximo carro e deltas de eventos anuais.
- Mantido o elenco atual da carreira para classificar pilotos e calcular favoritos ao título.
- Atualizado versionCode/versionName para 581 / 0.581.0.
- Validação: integridade do ZIP; build Gradle/Android ainda pendente.
