# V581 — Evolução visível também para pilotos livres

- Tornada explícita a política de evolução fora do grid: pilotos sem contrato ativo continuam evoluindo com fator de desenvolvimento próprio (0,70), sem receber bônus de desempenho de corrida.
- O fluxo de evolução carrega o estado de mercado uma vez por GP e identifica agentes livres a partir do mercado normalizado.
- Notícias de evolução agora identificam explicitamente `Agente livre` quando o piloto não está contratado.
- Se um agente livre ganhar atributo(s), mas o Overall inteiro permanecer igual, a Central de Notícias registra os atributos que melhoraram; isso evita ocultar evolução real devido ao arredondamento do Overall.
- Ganhos de Overall de agentes livres também são anunciados. Pilotos contratados mantêm a regra anterior de notícia quando o Overall sobe.
- Adicionados cinco testes de contrato para ganho de Overall, ganho de atributo sem alteração de Overall, ausência de falso positivo, tratamento de contratados e fator fora do grid.
- Atualizada a versão para `versionCode 581` / `versionName 0.581.0`.
- Build Android integral e suíte JUnit oficial não executados neste ambiente; os testes novos foram adicionados ao projeto e não são declarados como executados.
