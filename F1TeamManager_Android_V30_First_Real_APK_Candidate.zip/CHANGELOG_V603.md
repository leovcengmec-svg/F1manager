# V603 — proteção contra crash de catálogo duplicado

- `DriverMarketEngine.initialState` não lança mais `IllegalArgumentException` ao encontrar um piloto em dois rosters persistidos.
- A montagem inicial atribui um único contrato por piloto; prioriza equipes personalizadas em conflitos, sem sobrescrever o catálogo armazenado.
- Conflitos restantes de assentos devem ser reconciliados pelo editor; a correção evita o fechamento na inicialização, mas não comprova simulação com grid completo.
- Sem execução de Gradle ou testes Android neste ambiente.
