# V603 — Auditoria e correção de integridade dos pilotos

## Corrigido
- A virada de temporada não apaga mais `driverEvolutionPhases`, `driverEvolutionPhaseGps`, `driverEvolutionPhaseStart`, `driverEvolutionPhaseTarget` ou `driverEvolutionPhasePressure`. O ciclo contínuo de 5/2/5 anos agora sobrevive às temporadas.
- O progresso fracionário da evolução é transportado para a próxima temporada, enquanto os limites anuais de ganho e as marcas de GP processados continuam isolados por temporada.
- A duração 5/2/5 está centralizada no `DriverEvolutionEngine` e é compartilhada pela carreira normal e pelo caminho de Team Principal. Fases persistidas inválidas ou incompletas voltam com segurança para `GROWING`.
- Mudanças de classe/objetivo ajustam o alvo de evolução sem zerar o tempo já cumprido na fase.
- A regressão agora respeita o Overall mínimo por classe (Fraco 40, Médio 45, Forte 50, Pro 55, Lenda 60), além do limite individual mínimo 40 dos atributos.
- Removida a heurística específica de Felipe Drugovich da V600: ela comparava valores já normalizados a 75% e não podia cumprir seu teste de identidade para um perfil Forte. Em nova carreira, os atributos vêm do perfil canônico da build atual.
- `currentDrivers()` lê e mescla os 100 atributos uma única vez por montagem do catálogo, evitando trabalho quadrático e reduzindo custo em telas de pilotos/estratégia.
- Preservadas a resolução dos pilotos atuais no plano de pneus e as proteções de calendário da V602.

## Regra de validação
As atualizações são validadas a partir de uma carreira criada pelo fluxo **Novo Jogo**. Saves de versões anteriores não são a referência de aceitação; os recursos de save continuam disponíveis e nenhum save é apagado automaticamente.

## Testes executados
- Teste Kotlin isolado do motor de evolução: passou, cobrindo 5 tetos de classe, 5 pisos de Overall, estresse de regressão, duração 5/2/5 e perfis iniciais de Max/Felipe.
- Auditoria estática V603: 19/19 verificações passaram.
- Validação estrutural geral: 40/40 verificações.
- Auditoria estrutural de release: 25/25 verificações.
- Cadastro: 40 equipes, 80 titulares, 20 reservas, 100 nomes únicos e 100 perfis presentes.
- Assets: 195 arquivos comparados por hash, 0 diferenças. Documentos históricos anteriores à V603: 581 comparados por hash, 0 diferenças.

## Limites
Não foi executado o build Android completo, JUnit completo ou teste em dispositivo/emulador neste ambiente. A V603 é candidata até o workflow Build Debug APK e o teste de carreira nova serem aprovados.
