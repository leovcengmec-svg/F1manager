# V603 — Objetivos Team Principal visíveis e layout adaptável

- Destaca o catálogo completo de objetivos na tela Minha Carreira.
- Exibe o objetivo principal e cada meta complementar em cards individuais, com descrição e valor de prestígio.
- O cabeçalho informa a quantidade real de objetivos carregados.
- A tela explica que as metas complementares já ficam definidas durante a pré-temporada.
- Preserva a migração `ensureCurrentObjectives` para saves antigos ou carreiras sem catálogo completo, e mantém os objetivos completos existentes.
- Não altera regras de pontuação/prestígio nem os critérios de avaliação do contrato.
