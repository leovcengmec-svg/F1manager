# CHANGELOG V681 — Metas de evolução ancoradas na força dos construtores

Base: V680

## Correção das expectativas individuais

- Removido o ranking global que misturava diretamente força do carro e Overall do piloto para ordenar os 80 pilotos.
- As 40 equipes agora são ordenadas pela força média real do carro disponível no início da temporada. No modo Carreira, o carro do jogador usa o estado atual e as equipes da IA usam snapshots anuais por equipe quando disponíveis, com o perfil inicial como fallback; no Team Principal, são usadas as garagens físicas simuladas para a abertura da temporada.
- Cada equipe ocupa duas posições-base no campeonato de pilotos: P(2 × posição dos construtores − 1) e P(2 × posição dos construtores).
- Exemplo: construtores P22 passa a ancorar seus dois pilotos em P43/P44, antes do ajuste individual.
- Habilidade de corrida e classificação ajusta a meta individual em no máximo três posições; não consegue transformar um carro de meio/fundo de grid em carro de ponta nas expectativas.
- Validação rígida: exatamente 40 equipes, dois pilotos ativos por equipe e 80 pilotos no campeonato. As escalas 1–40 e 1–80 permanecem separadas.
- Faixa de tolerância padronizada em ±3 posições para todos os pilotos.

## Proteção contra meta móvel

- Carreira: metas V680 existentes (versão 2) são recalculadas uma vez após a atualização e gravadas como versão 3; permanecem congeladas durante a temporada.
- Team Principal: metas são geradas com as garagens reais preparadas para a primeira etapa e reutilizadas nas demais corridas.
- Evolução do piloto e melhorias no carro afetam os resultados, mas não elevam retroativamente a própria meta no meio da temporada. A nova expectativa é calculada na próxima temporada.

## Efeito esperado no exemplo de equipe P22

- Base do carro: P43/P44 no campeonato de 80 pilotos.
- Ajuste individual limitado: centros dentro de P40–P47.
- Um piloto que termina repetidamente em P35, com classificação razoável, passa a superar a meta de forma clara e recebe índice de desempenho acima do patamar normal de evolução.

## Testes e validação

- Atualizados testes de regressão para 40 equipes / 80 pilotos, dois pilotos por equipe e ajuste individual entre companheiros.
- Adicionado cenário de equipe P22 com desempenho repetido P35 para provar que o resultado é considerado acima da expectativa.
- Adicionada validação da tolerância fixa de ±3 posições.
- Compilação isolada Kotlin dos motores de evolução e dependências será registrada na auditoria.
- Testes Gradle completos e APK Android dependem do GitHub Actions; não declarar APK compilado até o workflow concluir.

## Versionamento

- `versionCode = 681`
- `versionName = "0.681.0"`
- Nome público preservado: **F1 Team Manager V30**.
- ZIP preservado: `F1TeamManager_Android_V30_First_Real_APK_Candidate.zip`.
