# V642 (0.642.0) — Meta comercial mínima obrigatória para a IA

- Tornado explícito o bloqueio estratégico: a IA não inicia melhorias de outras instalações enquanto o Centro Comercial estiver abaixo do nível 3.
- Se a melhoria não couber no caixa após as reservas operacionais ou no teto de investimento técnico anual, a IA aguarda e conserva o dinheiro; não cria saldo artificial e não desvia a prioridade para outra instalação.
- Após chegar ao nível 3, volta a aplicar a hierarquia normal, com Scouting como última prioridade.
- Incluído teste de regressão para cenário em que uma instalação mais barata caberia no caixa, mas o upgrade comercial violaria a reserva.
- Patrocínios V641 continuam usando o mesmo gerador de três ofertas e a mesma contabilização financeira compartilhada para jogador e IA.



## Correção adicional — travamento em carreiras longas (ANR)

- Movida a simulação instantânea de classificação/corrida para `Dispatchers.Default`, com modal de progresso e bloqueio contra execução duplicada.
- Movido o avanço de semana e o salto até o próximo GP para execução em segundo plano; os botões ficam indisponíveis até o processamento terminar.
- Substituída a regravação de todo o histórico a cada GP por arquivos atômicos individuais por temporada/round, com arquivos separados para resumos de temporada.
- Mantida compatibilidade de leitura com o histórico monolítico anterior e preservada a rotina de limpeza dos saves.
- Adicionada auditoria específica de ANR e teste em execução isolada do arquivo de histórico.
- A compilação Android completa e a reprodução no dispositivo continuam pendentes por indisponibilidade de Gradle/SDK neste ambiente.
