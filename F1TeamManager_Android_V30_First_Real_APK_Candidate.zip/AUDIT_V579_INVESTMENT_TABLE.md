# Auditoria V579 — Tabela de investimento por Overall

## Correção aplicada
- A função `CarDevelopmentEngine.referenceInvestmentForOverall` foi atualizada com os 61 valores aprovados para Overall 40–100.
- O erro reportado está corrigido na fonte: Overall 42 retorna €10.000.000, em vez de €11.400.000.
- A função central é chamada pelo forecast da temporada seguinte e pelo cálculo de efeito do investimento; `AITeamFinancialEngine` também a utiliza para determinar referências de preservação/melhoria da IA. A UI em `MainActivity.kt` consulta a mesma função.
- A construção de carro jogador/IA não foi reescrita nesta versão; o escopo desta correção é a tabela central de referência e sua cobertura de testes.

## Teste adicionado
- `approvedReferenceTableMatchesEveryOverallFrom40Through100`: verifica todos os 61 valores, confere Overall 42 = €10M e Overall 53 = €31M e valida que o investimento exatamente igual à referência gera 5 passos em cada Overall.

## Estado da validação
- [x] Inspeção da fonte da tabela e dos pontos de chamada da UI/IA.
- [x] Atualização da tabela e inclusão de teste de regressão.
- [ ] Testes Kotlin/Gradle executados: não executados nesta etapa.
- [ ] Compilação Android/APK: não executada nesta etapa.
- [ ] Teste visual no Android: pendente.

Não declarar build Android nem teste funcional como aprovados sem executar essas verificações.
