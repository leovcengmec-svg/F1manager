# V573 — Integridade do catálogo personalizado (grande atualização)

- Auditoria do carregamento de equipes, pilotos e bandeiras personalizados.
- Registros JSON inválidos, IDs duplicados, nomes duplicados e referências de pilotos ausentes passam a gerar diagnósticos explícitos.
- O catálogo em memória só é substituído quando todos os conjuntos são lidos sem inconsistências; dados inválidos não são convertidos silenciosamente em listas vazias.
- Escritas são bloqueadas enquanto houver inconsistências de origem, evitando que a próxima edição sobrescreva silenciosamente os dados persistidos.
- A edição do escudo de uma equipe agora aplica a mesma validação de nome de arquivo da criação, impedindo caminhos de pasta e caracteres inválidos.
- IDs existentes, chaves de SharedPreferences, formato JSON, assets externos e histórico de versões foram preservados.
- Adicionados testes de contrato para diagnósticos, bloqueio seguro de escrita e validação de assets.

## Validação

- Inspeção estática do código e integridade do ZIP realizadas.
- Testes JUnit e compilação Android não executados: o projeto não inclui `gradlew` e não há Gradle disponível neste ambiente.
