# V573 — Reconhecimento de bandeiras da Espanha e do Paraguai

- Corrigido o mapeamento de nomes de países em português para os códigos ISO: `Espanha`/`Spain` → `es`; `Paraguai`/`Paraguay` → `py`.
- Ampliados os aliases aceitos para arquivos externos: `es`, `esp`, `spain`, `espana`, `espanha`, `py`, `pry`, `paraguay`, `paraguai` e `paraguayan`, inclusive com prefixos `flag_` e `flags_`.
- Atualizada a lista de países reconhecidos pela interface para que os cards solicitem o carregamento das duas bandeiras.
- Mantida a pasta externa `Pictures/F1Manager/Assets/countries/`; o carregador também procura a pasta `flags` via fallback existente.
