# Auditoria V640 — Nomes das instalações na visão geral da equipe

## Problema confirmado

Na função `TeamOverviewFacilities`, o tipo `FacilityType.SCOUTING` estava sendo mostrado incorretamente como `Centro Comercial`, embora `facilityArtworkRes(SCOUTING)` use a arte de Scouting e `FacilityEngine.description(SCOUTING)` defina sua função como precisão das informações do mercado de pilotos. Ao mesmo tempo, `FacilityType.MARKETING` já representa a instalação unificada `Centro Comercial / Marketing` e controla os efeitos comerciais/patrocínios.

## Correção

- `FacilityType.MARKETING` → rótulo curto `Centro Comercial`.
- `FacilityType.SCOUTING` → rótulo `Scouting`.
- O nome `Centro Comercial` usa tamanho de fonte ligeiramente menor no cartão compacto para evitar truncamento desnecessário sem aumentar o espaço ocupado pelo carrossel.
- Mantidas as seis instalações reais da visão geral e suas chaves, níveis e artes.
- Nenhuma alteração a enum, cálculo financeiro, upgrade, migração de save ou identidade de instalações.

## Critérios de validação

1. A visão geral não deve mostrar cartões separados `Marketing` e `Centro Comercial`.
2. A instalação comercial deve aparecer uma única vez, como `Centro Comercial`.
3. O cartão com arte de scouting deve dizer `Scouting`.
4. `FacilityEngine.label(MARKETING)` continua a representar a instalação unificada; `SCOUTING` permanece independente no motor, pois afeta o mercado de pilotos.
5. A versão do app deve ser 640 / 0.640.0.
