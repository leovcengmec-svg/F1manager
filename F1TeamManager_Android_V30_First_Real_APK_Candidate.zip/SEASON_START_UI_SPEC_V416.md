# V416 — Especificação objetiva da interface de início de temporada

Referência aprovada: mockup vertical enviado em 12/10/2026. Dispositivo de referência: POCO X7 Pro.

## Diferenças objetivas a reproduzir

- **Dimensões:** ocupar a área útil da tela; sem `verticalScroll`, `horizontalScroll`, `LazyColumn` ou paginação. Layout adaptativo por altura disponível para telas compactas e altas.
- **Margens:** margem externa estreita e constante; seções com espaçamento regular; cartões com gutters iguais; cantos arredondados e bordas finas.
- **Cores:** fundo quase preto `#070B10`; painéis azul-carvão `#0D141D` / `#121C27`; bordas `#243342`; vermelho de ação `#F20D22`; texto branco `#F5F7FA`; secundário `#B0BDCC`; acentos secundários azul, verde e laranja.
- **Tipografia:** família padrão Android/Roboto; títulos em peso Black/Bold; títulos de seção compactos e maiúsculos; subtítulos com menor contraste; texto dos cards deve quebrar linha e usar toda a largura interna, sem truncar por reticências.
- **Alinhamento:** cabeçalho horizontal; hero alinhado à esquerda; títulos de seção com ícone à esquerda e texto de contexto à direita; grades com alturas e larguras uniformes.
- **Proporções:** hero como maior bloco individual; quatro cards iguais para equipes; cinco cards iguais para pilotos; painel de expectativa compacto; botão primário de largura total no rodapé.
- **Comportamento dos cards:** equipes ordenadas pela força estimada combinando carro e dupla de pilotos; pilotos ordenados por desempenho esperado combinado com força do carro. Posição numerada, cor de acento, barra comparativa e texto de expectativa.
- **Ícones:** usar Material Icons (`EmojiEvents`, `SportsMotorsports`, `BarChart`), não emojis como substitutos. Escudos, carros, fotos e bandeiras são carregados pelos `ExternalAssets` existentes.
- **Botão:** “COMEÇAR A TEMPORADA”, altura consistente, fundo vermelho, largura total; a ação de navegação e o controle de exibição única ficam a cargo de `MainActivity`/`CareerPreferences`.

## Arquivo criado

`app/src/main/java/com/f1teammanager/SeasonStartEventScreen.kt`

Componente Compose independente `SeasonStartEventScreen(...)`. Nesta etapa ele implementa a camada de interface; ainda não foi ligado ao fluxo de criação de carreira/semana 1. A integração de navegação e persistência é uma etapa separada para não modificar o ciclo de temporada inadvertidamente.
