# F1 Team Manager — V354

- Reforçada a serialização do fechamento de GP com um registro de locks por temporada/rodada compartilhado entre instâncias de `MainActivity` no mesmo processo.
- A verificação do marcador durável de conclusão é feita dentro da seção crítica, após adquirir o lock do GP.
- Mantida a validação estrutural do resultado antes de efeitos persistentes.
- Sem alterações de interface, botões ou assets.
- Android: `versionCode = 354`, `versionName = 0.354.0`.
