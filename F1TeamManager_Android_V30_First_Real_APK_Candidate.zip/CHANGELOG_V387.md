# V387 — Correção do botão PULAR FIM DE SEMANA

- O botão na Home fica disponível antes da semana do próximo GP, desde que a corrida não esteja em andamento nem finalizada.
- Ao acionar a simulação instantânea antes da semana do GP, o calendário processa as semanas intermediárias até a semana da corrida usando `advanceFreeWeeks`, preservando P&D, instalações, contratos e eventos programados.
- A simulação só começa depois de confirmar que o calendário chegou à semana exata do GP; em caso de falha, a corrida não é simulada e o usuário recebe uma mensagem.
- O modo normal e seu botão permanecem inalterados.
