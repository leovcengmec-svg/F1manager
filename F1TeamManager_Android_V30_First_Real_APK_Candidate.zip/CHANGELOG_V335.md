# V335 — Planos de pneus de chuva coerentes com o clima

- Planos A/B/C/D em chuva fraca ou moderada usam somente pneus INTERMEDIÁRIOS.
- Planos A/B/C/D em chuva forte usam somente pneus WET.
- Os quatro planos continuam disponíveis, variando número e distribuição dos stints sem sugerir o composto inadequado.
- Mantidos os planos de pista seca, regras de desgaste, ritmo, pit stop manual e demais sistemas.
