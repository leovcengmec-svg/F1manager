# Auditoria V564

## Alteração
Corrigido o limite fixo em `SeasonPrizeEngine.prizeForPosition`, que ainda rejeitava posições acima de 40 apesar da descrição da auditoria anterior. Posições 1–40 preservam a fórmula histórica. Posições 41–100 continuam a redução linear até €30M; a partir de 100, o valor permanece no piso de €30M.

## Verificações estáticas
- Fonte confirma `require(position >= 1)`.
- A fórmula de P1–P40 permanece idêntica à versão anterior.
- P41 calcula €39,75M; P100 calcula €30M; posições acima de 100 mantêm €30M.
- `rankTeams` continua ordenando as equipes cadastradas e atribuindo prêmio por posição.

## Limitações
Não foi executada compilação Android nem suíte de testes. A simulação integrada de duas temporadas continua pendente.
