# V340 — Nova pontuação do campeonato

Base: V339
Versão: 0.340.0
versionCode: 340

## Regras aprovadas
- 50 posições pontuam por colocação.
- P1=100, P2=85; distribuição equilibrada aprovada até P35.
- P36–P40: 3 pontos cada.
- P41–P45: 2 pontos cada.
- P46–P50: 1 ponto cada.
- P51 em diante: 0 ponto por colocação.
- Volta mais rápida: +1 ponto extra para o piloto registrado com a volta mais rápida.
- Construtores: soma dos pontos dos dois pilotos, incluindo o bônus da volta mais rápida.

## Implementação
A tabela central fica em `ChampionshipEngine.pointsTable`. `ChampionshipEngine.award` adiciona o bônus de volta mais rápida ao piloto designado em `RaceResult.fastestLapDriverId`. Como o sistema de construtores soma `result.points` por piloto, o bônus também é atribuído à equipe correta.

## Validação
A tabela contém exatamente 50 valores; os blocos finais são 5×3, 5×2 e 5×1. O bônus de volta mais rápida é adicionado uma única vez ao piloto registrado. Integridade do ZIP verificada. Compilação Android e simulação de temporada não executadas.
