# Auditoria V359 — persistência integrada do resultado

## Alteração verificada
`CareerPreferences.recordRace()` passou a gravar os mapas `previousDriverPositions`, `previousConstructorPositions`, `driverPoints`, `constructorPoints` e as chaves de resultado do GP no mesmo editor e com `commit()` síncrono. A função agora é `@Synchronized` para serializar chamadas concorrentes na mesma instância.

## Por que este bloco é maior
Antes, os mapas de pontuação eram gravados por chamadas independentes a `apply()` e o resultado era gravado depois. Uma interrupção entre essas operações podia deixar uma pontuação parcialmente atualizada sem um registro canônico do GP. A nova transação remove essa janela para esses dados de SharedPreferences.

## Limites restantes
- `history.recordRace()` e `history.finalizeSeason()` usam o subsistema de histórico separado e não participam da mesma transação SharedPreferences.
- Efeitos de finanças, evolução, patrocínios e pagamentos seguem exigindo chaves idempotentes próprias; esta alteração não os torna atomicamente transacionais.
- Build Android e JUnit não foram executados: não há Gradle Wrapper no ZIP nem Gradle instalado no ambiente. A tentativa de compilar o conjunto de fontes Kotlin puras excedeu o limite de execução disponível, portanto não conta como teste aprovado.
- A simulação de 60 GPs / duas temporadas permanece pendente de execução concluída.

## Integridade
A estrutura do código foi inspecionada após a alteração. Integridade do ZIP será verificada no empacotamento final.
