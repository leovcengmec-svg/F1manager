# V738 — Auditoria de estabilização e correção de build

## Correção aplicada
O GitHub Actions reportou erro de inferência do tipo genérico `K` na chamada `DriverMarketOrdering.sort` em `MainActivity.kt`. O seletor retornava tipos heterogêneos (`String` para Nome e `Int` para Idade/Classe/Overall), enquanto a função requer uma chave comparável única.

O seletor foi normalizado para retornar `String` em todos os ramos. Idade e Overall são convertidos para texto com preenchimento de três posições (`padStart(3, '0')`) para preservar ordenação numérica. Nome permanece alfabético. A ordenação secundária por nome e ID permanece estável.

## Verificações
- `DriverMarketOrdering.kt` + harness Kotlin: compilação aprovada.
- Execução do harness: Overall crescente, Overall decrescente, idade e nome aprovados.
- Teste de regressão adicionado para garantir que os ramos do `when` compartilhem um tipo comparável homogêneo.
- Versão confirmada: `versionCode=738`, `versionName=0.738.0`.
- Nome do ZIP preservado.

## Limitações
A validação completa do release contract ainda aponta duas verificações herdadas da base (prioridade da IA para Operações de Corrida e pipeline físico de projeção do próximo carro), não relacionadas a esta correção. Gradle e Android SDK não estão instalados neste ambiente; portanto, a compilação Android final deve ser confirmada pelo workflow do GitHub Actions.
