# F1 Team Manager — V367

## Bloco: integridade do circuito e execução da simulação instantânea

- A fronteira `InstantSimulationService` agora confere a definição completa do circuito recebido com o circuito usado para iniciar `CareerWeekendEngine` antes de consumir o estado da sessão.
- A comparação inclui ID, nome, voltas, tempo-base e parâmetros de risco, por igualdade do modelo `RaceCircuit`.
- `CareerWeekendEngine.configuredCircuit()` expõe uma cópia de referência imutável do valor configurado (o modelo é `data class` imutável), sem expor o estado mutável da corrida.
- Adicionado teste de regressão que passa um circuito diferente e exige rejeição antes de mudar fase, volta ou grid da sessão.
- Mantidos os fluxos de interface e os assets externos sem alterações.
- Atualizados `versionCode=367` e `versionName=0.367.0`.

## Limites de validação

O código foi alterado e inspecionado estaticamente. O teste JUnit ainda não foi executado e o build Android não foi executado: o ZIP não inclui `gradlew` e não há Gradle instalado no ambiente. Não declarar esta etapa como validada em runtime até executar a suíte oficial.
