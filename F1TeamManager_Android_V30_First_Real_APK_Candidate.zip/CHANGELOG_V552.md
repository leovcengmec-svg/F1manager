# V552 — preparação segura de identidade de assets

- Corrigido `TeamAssetRegistry`: IDs acima de 40 deixam de ser reduzidos para `40`, evitando colisões entre assets de equipes distintas.
- IDs de equipe inválidos (zero ou negativos) agora falham explicitamente, em vez de serem convertidos silenciosamente.
- Mantida a nomenclatura atual dos IDs 1–40, preservando os nomes dos assets existentes.
- Adicionados testes unitários para IDs existentes, IDs acima do limite atual e IDs inválidos.

## Limitação conhecida — cadastro dinâmico ainda não concluído

Esta alteração é uma correção de pré-requisito, não habilita por si só equipes/pilotos novos no campeonato. A base ainda contém pressupostos fixos de 40 equipes/80 titulares em `WorldDatabase`, `CareerWeekendEngine`, `InstantSimulationService`, `DynamicGridEngine`, `ManagerSeasonEngine`, classificação e premiação. O cadastro editável integrado precisa migrar esses fluxos em conjunto antes de ser considerado pronto.

## Validação

- ZIP de origem verificado antes da edição.
- A compilação Android e a suíte de testes precisam ser executadas num ambiente com Gradle/Android SDK configurados; não declarar runtime/build aprovado sem essa execução.
