# V570 Audit

Scope: connect the V569 durable constructors standings API to the visible championship screen.

- Standings now read per-round durable snapshots when available.
- Team IDs are unioned from the static catalog, live constructor point map, and durable snapshots.
- Custom/unknown team IDs are rendered rather than silently omitted.
- Legacy saves without snapshots continue using the existing aggregate constructor points.
- The existing driver standings path is unchanged.

Not verified: Android/Kotlin compilation, automated test execution, physical-device restart, or two complete seasons.
