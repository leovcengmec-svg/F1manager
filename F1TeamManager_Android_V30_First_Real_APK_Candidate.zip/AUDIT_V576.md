# Auditoria V576 — integração de carreira, temporada e áudio

## Alterações auditadas
1. Reconciliador do mercado atualizado para usar o catálogo carregado no dispositivo e disponibilizar uma entrada de teste para catálogos expandidos.
2. Pilotos novos vinculados a uma equipe personalizada ocupam primeiro as vagas dessa equipe; não são consumidos por uma vaga de equipe antiga apenas pela ordem dos IDs.
3. Vagas restantes podem usar pilotos sem equipe de origem ou vinculados à própria equipe. Pilotos vinculados a outra equipe não são movidos implicitamente.
4. Contratos e transferências agendadas existentes permanecem intactos; a reconciliação é idempotente.
5. Removida uma mensagem duplicada no validador da grade.
6. Áudio conectado aos eventos de box, pilotos, Safety Car/VSC e bandeira vermelha. `pit_call` e `player_driver_events` são os IDs canônicos e mantêm fallback para `box_audio` e `driver_warning`.
7. A chave do último evento evita repetir o mesmo áudio ao sair e voltar para a tela da corrida.
8. Adicionados testes JUnit de integração para equipe/pilotos personalizados, preservação de contratos/transferências, idempotência, mercado/grade, calendário de 30 GPs e seis instalações.

## Preservação
- V575 foi a base oficial desta entrega.
- Nenhum arquivo preexistente foi removido.
- Os 195 arquivos de `app/src/main/assets/` permanecem presentes. O catálogo e o README de áudio foram atualizados; nenhum slot legado foi removido.
- Histórico de versões e diretórios de trabalho históricos foram preservados.
- Não foram alteradas as chaves de armazenamento de carreira, finanças, contratos, calendário ou histórico.

## Validações realmente executadas
- `tools/race_sim_test/final_release_audit.py`: **32/32** verificações estruturais aprovadas.
- `tools/race_sim_test/validate_project.py`: **32/32** verificações estáticas aprovadas.
- `tools/race_sim_test/audio_routing_v576_audit.py`: **12/12** verificações de catálogo/roteamento de áudio aprovadas.
- `tools/finance_test/v440_financial_continuity_audit.py`: **13/13** contratos de fonte financeira aprovados.
- `tools/finance_test/v439_finance_stress_test.py`: executado com sucesso; o próprio script esclarece que usa cenários determinísticos ilustrativos, não o motor real.
- `tools/finance_test/v438_finance_stress_test.py`: executado com sucesso; também é cenário ilustrativo, não execução real da IA Android.
- `tools/audit_v429.py`: **9/9** verificações de transição aprovadas.
- `tools/audit_v445_regulation.py`: **4.772/4.772** verificações matemáticas/estáticas aprovadas.
- `tools/race_sim_test/v498_ai_persistence_audit.py`: **8/8** verificações aprovadas.
- Compilação e execução Kotlin isolada do reconciliador V576 com cenários de equipe personalizada: **PASS**.
- ZIP final verificado com `unzip -t`; inventário comparado com V575.

## Limites e achados legados
- A compilação completa Android e a suíte JUnit do aplicativo não foram executadas: não há Gradle nem Gradle Wrapper disponível neste ambiente.
- O áudio foi validado estaticamente; os arquivos reais são externos e a reprodução precisa de confirmação em dispositivo Android.
- Dois auditores históricos não representam o contrato atual: `v448_game_cycle_audit.py` ainda exige grid fixo de 80 pilotos e `v441_financial_model_audit.py` ainda exige tabela de premiação limitada a 40 posições. Eles falham nesses pressupostos antigos, enquanto as versões atuais suportam grid dinâmico e posições adicionais. Os scripts históricos foram preservados sem alteração.
