# AUDITORIA V587 — PAINEL DE CARREIRA TEAM PRINCIPAL

## Problema confirmado na V586

A V586 possuía um pequeno card resumido na HOME e uma tela de avaliação bienal, mas não oferecia um painel central completo para consultar conquistas e toda a trajetória profissional. Isso dificultava acompanhar os objetivos, o prestígio e o histórico do Team Principal.

## Correção aplicada

- Criada a tela `TEAM_PRINCIPAL_CAREER`, acessível ao tocar no card Team Principal da HOME.
- Prestígio de 0 a 100, nível profissional, barra visual, melhor posição e quantidade de temporadas registradas.
- Objetivo atual da diretoria e comparação com a posição atual no Mundial de Equipes.
- Informação sobre janela de contrato e avaliação bienal pendente.
- Atalho à avaliação contratual e às propostas quando o estado da carreira indica que a avaliação está disponível.
- Lista de oito conquistas, calculadas a partir dos dados realmente persistidos da carreira; conquistas sem evidência continuam bloqueadas.
- Histórico cronológico inverso com temporada, equipe empregadora, posição, meta e ganho/perda de prestígio.
- Navegação de retorno no botão da tela e no botão Voltar do Android.

## Dados utilizados

A interface deriva as informações de `TeamPrincipalCareerState` e `TeamPrincipalSeasonRecord`, persistidos em `CareerPreferences`. Não adiciona um segundo armazenamento paralelo para prestígio, conquistas ou histórico.

## Preservação

- Não modifica os critérios de simulação de temporada dos modos Livre e Difícil.
- Não altera o cálculo de prestígio, as metas ou as condições de revisão existentes no motor da V586.
- Conquistas e painel são leitura dos registros gravados e não concedem prestígio adicional.

## Validação e limitações

- Conferência estática: a rota da tela nova existe no enum, há despacho de tela, o card HOME abre o painel e os botões de retorno estão definidos.
- Integridade do ZIP: verificada após o empacotamento.
- Build Android/Compose e teste visual no aparelho: não executados. O pacote não inclui `gradlew`/`gradle-wrapper.properties` e o comando `gradle` não está instalado neste ambiente.
- Ainda é necessária a validação ponta a ponta da carreira em dispositivo para confirmar visualização, recomposição e navegação em runtime.
