# Auditoria V365

## Alterações

O fluxo de finalização em `MainActivity` agora usa `RaceFinalizationJournal`, classe pura e testável. A identidade do GP é capturada e usada para resolver os metadados de histórico/notícia e o fechamento financeiro da temporada.

## Testes adicionados

`RaceFinalizationJournalV365Test` cobre:

1. Ignorar uma etapa já marcada ao reabrir o mesmo GP.
2. Isolar marcadores por temporada e rodada.
3. Não marcar etapa quando a ação falha.
4. Propagar falha ao gravar o marcador e permitir retry.
5. Rejeitar rodada fora de 1..30.

O teste da janela entre a ação e o marcador deixa explícito que a ação pode ser repetida e precisa ter idempotência própria; não afirma garantia exactly-once onde não existe transação comum.

## Validação nesta etapa

- Revisão estática dos pontos alterados: realizada.
- Testes JUnit via Gradle: pendentes (não há `gradlew` no ZIP nem instalação de Gradle confirmada).
- Build Android: pendente.
- Cadeia de duas temporadas com persistência Android: pendente.
