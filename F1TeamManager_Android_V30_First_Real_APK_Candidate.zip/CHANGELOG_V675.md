# V675 — Ajuste da avaliação do Team Principal

## Problema observado
A tela de avaliação mostrava duas temporadas com metas principais cumpridas (P18 contra meta P21; P33 contra meta P35), além de ganhos de prestígio, mas o contrato foi encerrado. A soma de risco por apoio, desempenho de corrida/classificação, finanças, desenvolvimento e instalações podia produzir demissão mesmo com entrega esportiva central positiva.

## Correção
- Meta principal atingida + pelo menos 60% das metas: risco máximo de demissão de 5%.
- Meta principal atingida + pelo menos 40% das metas: risco máximo de 12%.
- Meta principal não atingida, mas pelo menos 80% das metas cumpridas: risco máximo de 25%.
- Temporadas com baixa entrega global continuam sujeitas a risco elevado; não foi removida a possibilidade de demissão.

## Testes adicionados
- Proteção de temporada com meta principal e maioria das metas cumpridas.
- Redução do risco quando há alta entrega secundária mesmo sem atingir a meta principal.

Base: V674. Versão interna: 675 / 0.675.0.
