# V326 — Compactacao do painel de qualificacao

- Compactado o segundo card da tela de qualificacao para remover espaco vertical sobrando.
- Mantidos somente o cronometro da fase, a media do GP com o dado de voltas por piloto e o status (PRONTA, SIMULANDO ou CONCLUIDA).
- Removidos do card o bloco de melhor volta e a barra de progresso.
- Mantida a logica existente de simulacao, fases, cronometro e calculo da media do GP.
- Base: V325. Nome oficial do ZIP preservado.

Validacao: verificacoes estaticas e integridade do ZIP. Compilacao Android e teste em dispositivo nao executados.
