# V393 — Novo layout do diálogo de fabricação

- Substituído o AlertDialog antigo por um diálogo Compose customizado e responsivo.
- Cabeçalho compacto com título em uma linha e controle de fechar.
- Área de imagem usa o asset existente `factory_generic_piece.webp`; desempenho e confiabilidade permanecem ligados aos dados do design selecionado.
- Opções de fabricação padronizadas em cards com quantidade, prazo, custo unitário, total e seleção explícita.
- Ações CANCELAR e CONFIRMAR alinhadas em botões de dimensões consistentes.
- Removida rolagem vertical do diálogo; conteúdo dimensionado para caber na área útil de um telefone como o POCO X7 Pro.
- Mantidos callbacks e validações de orçamento/capacidade da fábrica.
