# V526 — Correção de compilação

- Corrigida a declaração duplicada `private private` em `componentImageResource` no `MainActivity.kt`, causa do erro `Repeated 'private'` em `:app:compileDebugKotlin`.
- Preservadas as funcionalidades e os arquivos da V525; versão incrementada para 526.
