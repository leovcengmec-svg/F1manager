# V470 — Redução da altura dos cards do menu inicial

- Reduzido o espaço vertical reservado aos três cards principais do menu inicial para deixá-los menos altos no POCO X7 Pro.
- Reduzidos espaçamentos entre cards, padding vertical, ícones e tipografia secundária para manter a leitura e os alvos de toque.
- Mantidos os textos, estados habilitado/desabilitado, callbacks e fundo aprovado; não foi adicionada rolagem.
- Atualizada a versão Android para `versionCode 470` / `versionName 0.470.0`.
- ZIP verificado quanto à integridade; build Android ainda precisa ser confirmado no GitHub Actions.

