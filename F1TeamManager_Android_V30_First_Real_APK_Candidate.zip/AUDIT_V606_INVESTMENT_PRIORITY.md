# Auditoria V606 — Prioridade equilibrada de investimento

## Objetivo
Evitar os dois extremos: a IA gastar todo o caixa no carro atual e ignorar o carro do ano seguinte, ou concentrar recursos no próximo carro e deixar de desenvolver o carro que ainda disputa a temporada.

## Tabela de prioridade do caixa discricionário
| Etapa | GPs | Parcela priorizada para o próximo carro | Parcela remanescente para desenvolvimento técnico atual |
|---|---:|---:|---:|
| 1 | 1–8 | 10% | 90% |
| 2 | 9–15 | 15% | 85% |
| 3 | 16–22 | 25% | 75% |
| 4 | 23–30 | 35% | 65% |

As parcelas são calculadas sobre o caixa disponível no momento, antes da reserva operacional. O valor efetivamente gasto continua limitado ao caixa real, à reserva de salários/corrida e aos limites de projeto. A porcentagem não é um teto cumulativo do investimento do próximo carro.

## Guardas preservadas
- Reserva operacional: pelo menos 20% do caixa ou €2M, quando aplicável.
- Reserva para salários e próxima corrida, calculada pela política financeira da IA.
- Teto técnico anual compartilhado de €200M para P&D/design, fabricação e instalações.
- Teto independente de €150M para o próximo carro.
- Aporte só acontece uma vez por GP concluído, com proteção contra duplicação no ledger.
- Migração preserva despesas e investimentos já registrados.

## Testes adicionados
- As quatro faixas de prioridade e seus limites de GP.
- A entrada de caixa não reduz o teto absoluto do próximo carro.
- O carro atual mantém orçamento discricionário nas quatro etapas.
- A parcela do próximo carro não pode consumir o caixa protegido para operações.

## Limitações
A compilação Android completa, os testes JUnit via Gradle e o teste em aparelho/emulador dependem de ambiente com Gradle/Android SDK e não são declarados como executados aqui.
