# V512 — Cards visuais de componentes

- Os cards de **DESIGNS CONCLUÍDOS / AGUARDANDO FÁBRICA** e da lista de fabricação agora compartilham o mesmo padrão visual.
- Adicionada imagem genérica de componente à esquerda, com transparência de 34% para não competir com o texto.
- Nome, versão, desempenho, confiabilidade e ação de fabricação permanecem à direita, sem alterar os dados ou as regras funcionais.
- A seleção continua mostrando somente a versão mais recente por componente; histórico de P&D e peças existentes permanecem preservados.
- Versão Android atualizada para `versionCode 512` / `versionName 0.512.0`.
