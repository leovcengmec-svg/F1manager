# V744 — correção de compilação

- Corrigido `Unresolved reference: FacilityEngine` em `CareerPreferences.kt` por meio da inclusão do import explícito de `com.f1teammanager.core.manager.FacilityEngine`.
- Mantidas todas as mudanças funcionais da V743.
- Versionamento atualizado para `versionCode 744` / `versionName 0.744.0`.
- Preservado o nome oficial e o nome original do ZIP.
- Compilação Android completa pendente de execução no GitHub Actions.
