# V559 — validações do grid e evolução proporcionais ao catálogo

## Implementado
- `DynamicGridEngine.validate` calcula o grid esperado como duas vagas por equipe cadastrada.
- O mercado valida cobertura do catálogo e quantidade de agentes livres dinamicamente, mantendo os valores 80/100/20 no mundo original de 40 equipes.
- `ManagerSeasonEngine.applyDriverEvolution` valida os pilotos ativos conforme o catálogo e deixa de usar posição 80 como fallback universal.
- Versão atualizada para `559` / `0.559.0`.

## Preservação e limites
- Nenhum ID histórico, save, asset, pasta de assets externos ou documento de versão foi removido.
- Esta etapa corrige duas validações centrais, mas não declara concluída a participação de equipes extras em todos os fluxos do campeonato. Ainda há pressupostos fixos em outros sistemas que exigem migração coordenada e teste de carreira completa.
- ZIP verificado após empacotamento. Compilação Android e suíte de testes não executadas: o ambiente não dispõe de Gradle/Gradle Wrapper no pacote.
