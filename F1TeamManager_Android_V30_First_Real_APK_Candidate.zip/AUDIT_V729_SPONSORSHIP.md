# Auditoria de implementação V729 — Patrocínios

## Resultado

A V729 aplica as alterações solicitadas ao sistema de patrocínio da V728. A estrutura compartilhada de geração e as regras de pagamento não foram substituídas.

## 1. Duração das propostas

- Marketing nível 0, 1 ou 2: intervalo inclusivo `3..10`.
- Marketing nível 3 a 10: intervalo inclusivo `8..14`.
- A seleção usa `durationRange.first + floorMod(cycle, durationRange.count())`, portanto todos os sete valores 8, 9, 10, 11, 12, 13 e 14 são elegíveis.
- O limite superior novo é 14; as propostas novas não podem oferecer 15 ou 16.
- Contratos V728 de 15–16 GP continuam armazenando sua duração original. O cálculo de valor da IA não os trunca para 14.

## 2. Paridade jogador/IA

O jogador continua recebendo três propostas de `TeamSponsorshipEngine.offersForSlot()` e assina pela tela Finanças. A IA usa `generateOffersForSlot()` para o mesmo conjunto de três propostas e `selectBestAiSponsorOffer()` para a escolha automática. Ambos recebem o Marketing level vigente, e o gerador central aplica a nova faixa.

## 3. Liquidação do GP de expiração

### Fluxo Android principal

- Jogador: `FinanceEngine.applyRace()` liquida pagamentos fixos e bônus usando contratos com `racesRemaining > 0`, depois decrementa e remove contratos que chegaram a zero.
- IA: `MainActivity` executa `aiFinance.applyRace()` com `aiSponsorship.forTeam()` e, em uma etapa de finalização posterior, chama `advanceAllTeams()`.
- A ordem no caminho principal já estava correta e foi preservada.

### Motor alternativo de temporadas

Antes da correção, `ManagerSeasonEngine` chamava `advanceAllTeams()` antes de `aiFinance.applyRace()`. Isso substituía um contrato com uma corrida restante antes da liquidação e podia adiantar a elegibilidade financeira do substituto.

A V729 adiciona `TeamSponsorshipEngine.settleRaceThenAdvance()`, que recebe a carteira ativa para aquele GP, executa primeiro a liquidação callback e só depois chama `advanceRace()`. `ManagerSeasonEngine` passa a usar esse fluxo. O novo contrato fica disponível após a corrida que encerrou o anterior e recebe seu primeiro pagamento por GP na corrida seguinte.

## 4. Notificação

A notificação existente `SLOT DE PATROCÍNIO LIVRE` foi mantida sem duplicação. O fluxo atual direciona o jogador a Finanças para ver as novas ofertas. Não foi criada uma segunda notificação de encerramento nem um segundo CTA na Home.

## 5. Arquivos alterados

- `app/src/main/java/com/f1teammanager/core/manager/TeamSponsorshipEngine.kt`
- `app/src/main/java/com/f1teammanager/core/manager/ManagerSeasonEngine.kt`
- `app/src/test/kotlin/com/f1teammanager/core/manager/SponsorshipContractDurationV685Test.kt`
- `app/src/test/kotlin/com/f1teammanager/core/manager/SponsorshipExpirySettlementV729Test.kt` (novo)
- `app/src/test/kotlin/ThreeSeasonCommercialAuditTest.kt`
- `app/build.gradle.kts`, `package_manifest.txt`, README e changelogs

`MainActivity.kt` não foi alterado; a notificação existente e o fluxo principal de liquidação permanecem como estavam.

## 6. Validação executada nesta sessão

Verificações estáticas: 13/13 aprovadas, incluindo a presença da faixa 8..14, uso de `floorMod` sobre o tamanho inclusivo do intervalo, preservação dos contratos legados, uso do novo fluxo no `ManagerSeasonEngine`, manutenção única da notificação existente e confirmação de que a sequência determinística cobre todos os sete valores.

Os testes JUnit foram adicionados/atualizados, mas não foram executados nesta sessão: o pacote não inclui Gradle Wrapper e o ambiente não possui Gradle nem Android SDK. Portanto, a compilação Android e `assembleDebug` continuam pendentes da execução pelo GitHub Actions.
