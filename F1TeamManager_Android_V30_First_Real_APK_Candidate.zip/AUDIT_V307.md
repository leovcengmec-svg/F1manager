# Auditoria V307

- Versão: 307 (0.307.0).
- Mudanças concentradas em MainActivity.kt e metadados de versão/documentação.
- O card de posição usa a posição atual na ordenação das equipes (1..40).
- Bandeira carregada via DriverFlag e ExternalAssets; imagem do carro via TeamCarCompact.
- Limite técnico disponível lido de TechnicalInvestmentState.available para equipe do jogador e equipes IA.
- Histórico usa registros históricos existentes da equipe; nenhum registro é inventado.
- ZIP validado estruturalmente. Compilação e teste visual no Android não foram executados neste ambiente.


Revisão complementar de layout V307: removida rolagem horizontal da tabela histórica e usadas larguras proporcionais para exibir TEMP./EQUIPE/POS/PTS/VIT/PÓD/POL/MV/GP/DNF na largura disponível. Os dados vêm de constructorSeasonRecords() e dos registros de corrida por equipe; temporadas em andamento não são inventadas como temporadas encerradas. A compilação Android ainda precisa ser executada no workflow.
