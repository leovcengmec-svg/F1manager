# V704 — classificação determinística e pilotagem automática

## Classificação manual e instantânea
- O avanço cronológico manual e instantâneo usa a mesma linha do tempo, em quanta de 1 segundo e checkpoints climáticos alinhados.
- Os pneus iniciais respeitam o clima: seco usa composto seco; chuva leve/moderada usa intermediário; chuva forte usa pneu de chuva.

## Pilotagem automática: Ataque, Equilibrado e Poupar
- Os dois pilotos da equipe do jogador e os pilotos da IA usam a mesma política automática, recalculada a cada volta com combustível projetado para pista seca, reserva de segurança, desgaste dos pneus, clima, fase da prova, habilidade individual e proximidade de adversários.
- Poupar é acionado quando a margem de combustível ou o desgaste exige preservação; Equilibrado é usado quando a margem é limitada; Ataque só é usado quando pneu e combustível permitem e há oportunidade razoável.
- Combustível crítico deixou de interromper a corrida para pedir ao jogador uma escolha de ritmo. O piloto decide automaticamente e emite um aviso de rádio.
- Removidos da interface os callbacks de alteração manual de ritmo. As APIs legadas `setStrategy` e o parâmetro `mode` de `setPlan` também não conseguem mais sobrescrever o ritmo automático. Permanecem editáveis os planos de pneus, os boxes e as decisões de compostos.
- Na relargada após bandeira vermelha, o jogador escolhe plano/composto, mas nunca a postura. A simulação instantânea usa um plano de relargada válido. O texto da interface foi ajustado para deixar explícita essa separação.
- O perfil antes identificado como Defesa passa a ser apresentado como Poupar. O identificador interno legado `DEFENSE` permanece para compatibilidade; o atributo técnico Defesa do piloto mantém o significado original.

## Versão
- `versionCode = 704`
- `versionName = 0.704.0`

## Validação
- Incluídos testes direcionados para decisões por combustível, desgaste dos pneus, oportunidade de disputa e bloqueio dos antigos controles manuais de ritmo.
- A compilação Android completa e a suíte JUnit dependem da configuração Gradle/Android SDK disponível no GitHub Actions.
