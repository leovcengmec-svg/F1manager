# V492 — Correção dos botões da contraproposta

- Corrigida a largura do botão RECUSAR no rodapé do diálogo de contraproposta.
- Os botões RECUSAR, ACEITAR e ENVIAR agora dividem igualmente a largura disponível, com padding horizontal reduzido.
- Os rótulos permanecem em uma única linha para evitar quebra de texto em telas estreitas.
- Não altera o fluxo nem a lógica da negociação.
- ZIP verificado; compilação Android completa não executada neste ambiente.
