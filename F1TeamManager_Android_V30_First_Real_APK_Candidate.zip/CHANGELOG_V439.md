# V439 — auditoria contábil de premiação

- Corrigido o cenário de estresse financeiro para utilizar a curva oficial de premiação de construtores para as 40 posições, em vez de valores fixos por nível de equipe.
- O cenário agora aplica a lógica oficial de prêmio por posição do piloto/equipe em cada GP e custos operacionais por nível.
- Adicionadas asserções para confirmar que os prêmios de construtores são estritamente decrescentes do P1 ao P40 e preservam os valores extremos oficiais.
- Mantida a distinção entre cenário determinístico de referência e execução integrada real: salários e patrocínios continuam como hipóteses explicitadas.
