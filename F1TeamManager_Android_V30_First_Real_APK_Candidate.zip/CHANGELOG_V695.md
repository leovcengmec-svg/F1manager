# v695 — race incident rebalance and controlled car progression

## Corrections
- Reduced field-wide accident roll from 2.0% to a 0.6% baseline per green-flag lap (bounded by circuit risk). The previous probability created an accident in roughly 70% of 60-lap races before considering neutralisation.
- An accident is no longer an automatic DNF. Severe incidents are selected using driver consistency and wet-weather skill; survivable incidents cause a time loss and tyre wear.
- Reduced collision-caused retirement chance from 40% to 20%, and bounded the number of DNFs caused by one incident.
- Added deterministic weighted incident selection so lower consistency and weak wet-weather skill increase exposure in the appropriate conditions.
- Increased car contribution to race pace: dry/cloudy 70/30, light/medium rain 60/40, heavy rain 55/45. The driver remains important, while a materially superior car now has a clearer sporting advantage.
- Reduced the player's annual current-car development allowance and introduced diminishing annual headroom by current Overall: 42/36/30/24/18 attribute points from weakest to elite cars. This slows rapid jumps into the top tier while preserving faster rebuilding for weaker teams.

## Complementary career and AI balance included in this revision
- Added a synthetic but stable career-age curve based on each driver's development profile, slowing growth after the peak and introducing natural regression in later career stages without requiring a save-schema migration.
- Reduced unsigned/free-agent growth to 45% of the natural baseline and kept free-agent development independent of fabricated race results.
- Added/retained per-GP news for both Overall increases and decreases, including the before/after value and the reason. Overall drops now use the distinct headline “REGRESSÃO DE PILOTO” in both Career and Team Principal modes.
- Kept the individualized 1–80 driver expectation model, tolerance bands, personal potential, and separate 1–40 constructor ranking.
- AI car simulations publish live physical Overall snapshots; AI financial mindsets use current ranking/strength when the snapshot is available. The €200M technical envelope and independent €150M next-car cap remain unchanged.
- Race pace uses continuous component interpolation and circuit-demand profiles, rather than coarse ten-point buckets or a single generic track profile.
- Preserved the exact public ZIP filename and the F1 Team Manager V30 identity.

## Validation
- Added unit tests for incident probability, consistency/wet-skill risk weighting, deterministic selection, and annual development caps.
- Updated race pace weighting expectations.
- Source-level checks and ZIP integrity will be performed for this package. A full Android build/JUnit run requires Gradle/Android SDK or GitHub Actions; no local Gradle wrapper is included in the source package.
