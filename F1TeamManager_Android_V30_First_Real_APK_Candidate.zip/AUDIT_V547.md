# Auditoria V547

## Alterações
1. MainActivity cria CareerWeekendEngine com SecureRandom().nextInt() em vez da constante 20261003.
2. Removidos os campos dnfLimit/dnfCount e suas atribuições, pois não eram consultados para decidir o resultado de um incidente.
3. Nenhuma probabilidade de acidente, colisão ou falha mecânica foi modificada.

## Limitações
A semente é gerada por instância do motor da tela. Não foi implementada persistência da semente em savegame; isso evita sequências fixas entre novas instâncias, mas não promete reproduzir exatamente a mesma corrida após reiniciar o aplicativo.

## Testes
- Inspeção estática dos locais alterados e confirmação de que não há referências a dnfLimit/dnfCount no motor.
- ZIP testado com ZipFile.testzip().
- Build Gradle e testes JUnit pendentes, pois não há wrapper Gradle no pacote.
