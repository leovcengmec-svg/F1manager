# Auditoria de áudio — V564

## Alteração
O `F1ManagerApp` observa os eventos de ciclo de vida `ON_STOP` e `ON_START`. Ao sair do primeiro plano, `ExternalAudio.setForeground(false)` pausa o player ativo; ao retornar, `setForeground(true)` tenta retomar a mesma reprodução. O callback de preparação assíncrona só inicia a reprodução se o jogo estiver em primeiro plano.

## Escopo
Aplica-se às faixas e aos efeitos que passam pelo gerenciador `ExternalAudio`. Não altera os arquivos de áudio externos nem a lógica de corrida.

## Limitação de validação
A inspeção estática não substitui build Gradle, teste em aparelho ou teste de alternância entre aplicativos/tela bloqueada.
