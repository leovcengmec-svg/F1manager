# Auditoria V362 — simulação instantânea integrada

## Alterações verificadas no código
- `MainActivity.simulateWeekendInstantlyForCareer()` chama `InstantSimulationService.completeStartedWeekend()` antes de aplicar bônus de qualificação e finalizar a corrida.
- O serviço reutiliza `CareerWeekendEngine.simulateWeekendInstantly()`; não introduz um segundo modelo de corrida.
- O serviço valida Q1/Q2/Q3 (80/50/20), grid final (80), classificação final (80), identidade dos pilotos, posições e distância programada.
- O validador comum também rejeita posições duplicadas.
- Interface e botões não foram alterados.

## Resultado do ambiente
- Inspeção estática e consistência do pacote: executadas após empacotamento.
- Build Android: não executado (sem `gradlew` no ZIP e sem Gradle no PATH).
- JUnit: não executado pelo mesmo limite de ambiente.
- Duas temporadas completas: ainda pendentes; não são declaradas como aprovadas.
