# V541

- Substituidas as ilustracoes artificiais da tela de fim de temporada por fotografias genericas realistas de automobilismo, sem marcas/equipes identificaveis.
- Padronizadas as cinco imagens em 640x400 WebP.
- Os quatro cards de grandes acontecimentos agora usam a mesma altura fixa de imagem em todos os cards, evitando diferencas de tamanho causadas pela distribuicao proporcional do layout.
- Mantidos os dados, textos, campeoes, estatisticas e demais fluxos da tela.
- Versionamento: 541 / 0.541.0.
