# Auditoria V432 — revisão final estática da virada

## Correção encontrada
O teste de contrato adicionado na V431 tinha duas strings Kotlin com aspas internas não escapadas em comparações com `STATE_PERSISTED`. Isso impedia compilar esse arquivo de teste. A sintaxe foi corrigida e o teste foi renomeado para V432.

## Contratos reforçados
- Ordem de regressão, avanço da temporada, construção do carro e recálculo do teto técnico.
- Referência de investimento individual para Overall 40–100 compartilhada pelo cálculo da previsão e pela transição efetiva.
- Persistência dos estados canônicos antes de `STATE_PERSISTED` e limpeza do diário depois do commit.
- Snapshot salvo antes da publicação da etapa `PREPARED`.
- Limpeza do snapshot antes da remoção do diário de transição, preservando caminho de finalização após commit.
- Recuperação diferenciada para estado já confirmado e para estado parcial.

## Limitações
- O teste foi verificado por análise estática e compilação isolada do arquivo de teste com stubs locais de JUnit; isso não substitui Gradle/JUnit real nem o build Android.
- O projeto não inclui `gradlew` e o ambiente não tem comando `gradle`; portanto, build Android e suíte completa não foram executados.
- Ainda é necessário teste integrado em dispositivo/emulador, incluindo morte do processo em cada checkpoint e duas temporadas consecutivas.
- O snapshot do arquivo de carreira não transforma automaticamente arquivos históricos separados numa transação atômica. A consistência do histórico deve ser confirmada em runtime.

## Veredito
A V432 corrige um defeito de compilação no teste da V431 e fortalece os contratos de ordem do diário. O código não deve ser considerado plenamente validado até build Android, suíte completa e teste integrado de duas temporadas passarem.
