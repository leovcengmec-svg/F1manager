# V418 — Integração dos eventos de temporada

- Conectada a apresentação de início de temporada ao início de carreira e ao começo de cada nova temporada.
- Conectada a retrospectiva ao fechamento arquivado do GP 30.
- Persistência por temporada para impedir repetição de cada apresentação.
- Dados da retrospectiva calculados a partir de HistoricalDatabase: campeões, pontos, vitórias, pódios, poles, abandonos e evolução de equipes.
- Telas continuam independentes e sem rolagem vertical; validação real de dimensões e compilação Android pendentes.
