# V564 — Pausar áudio em segundo plano

- O áudio do jogo é pausado quando a Activity deixa o primeiro plano (`ON_STOP`).
- A reprodução é retomada quando o jogo volta ao primeiro plano (`ON_START`).
- A regra vale para música ambiente e efeitos de áudio geridos por `ExternalAudio`.
- Se uma faixa ainda estiver carregando quando o jogo for minimizado, ela não começa a tocar em segundo plano; inicia quando estiver preparada e o jogo estiver em primeiro plano.
- O ciclo das músicas de interface e os gatilhos de áudio da V563 foram preservados.

## Validação
- Verificações estáticas do código e integridade do ZIP executadas.
- Compilação Android e teste em dispositivo não executados nesta entrega.
