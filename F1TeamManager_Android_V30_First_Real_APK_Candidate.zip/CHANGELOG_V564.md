# F1 Team Manager V564

- Mantém os valores históricos de premiação de construtores nas posições 1–40.
- Remove o limite fixo de 40 posições no cálculo da premiação.
- Para posições 41 em diante, continua a curva a partir do valor da posição 40, reduzindo gradualmente até o piso de €30 milhões na posição 100 e mantendo esse piso nas posições seguintes.
- Rejeita posições zero ou negativas.
- Atualiza versão Android para 564 (0.564.0).

## Validação
ZIP validado estruturalmente. Não foi possível confirmar compilação Android nem executar a suíte de testes neste ambiente.
