# V406 — Ajuste visual dos cards do pódio

- Removidas as informações adicionais dos cards P1, P2 e P3.
- Foto do piloto ampliada para preencher o card.
- Faixa inferior escura contém somente posição à esquerda e escudo da equipe à direita.
- Removidos os títulos internos duplicados “RESULTADO” e “F1 MANAGER”; o cabeçalho do scaffold permanece.
- Classificação completa e rolagem própria da lista de 80 pilotos preservadas.
