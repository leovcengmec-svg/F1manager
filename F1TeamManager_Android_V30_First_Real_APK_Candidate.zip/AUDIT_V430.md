# Auditoria V430 — recuperação da virada

## Corrigido nesta versão
1. Snapshot síncrono do estado `f1tm_career` antes de registrar a virada.
2. Restauração do snapshot para estados pendentes anteriores a `STATE_PERSISTED`.
3. Bloqueio explícito se a virada parcial não tiver snapshot de recuperação válido.
4. O retry usa a temporada de origem persistida, não o valor possivelmente avançado em memória.
5. Limpeza do backup antes do diário, preservando `STATE_PERSISTED` caso a remoção do backup falhe.

## Sequência esperada
- Temporada encerrada -> snapshot durável -> diário `PREPARED`.
- Falha antes de `STATE_PERSISTED` -> restaurar snapshot -> criar diário novo -> reexecutar desde a origem.
- Todos os estados canônicos persistidos -> marcar `STATE_PERSISTED` -> apagar backup -> apagar diário.
- Falha ao apagar backup -> manter diário para repetir a limpeza sem executar novamente os motores.

## Limitações que permanecem
- A cópia abrange `f1tm_career`; não cria transação atômica com banco histórico, assets ou outras preferências.
- A recuperação de uma falha após mudanças em outros armazenamentos requer verificação separada desses armazenamentos.
- Não houve compilação Gradle nem execução JUnit: o projeto não contém `gradlew` e o comando `gradle` não está disponível neste ambiente.
- O teste de cadeia de duas temporadas continua sendo teste-fonte, não uma execução do jogo.
