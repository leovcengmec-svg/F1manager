# V440 — Auditoria de continuidade financeira entre temporadas

- Versão Android atualizada para `versionCode 440` / `versionName 0.440.0`.
- Adicionada auditoria de contratos de continuidade financeira: idempotência de acertos por GP, persistência dos marcadores de liquidação, pagamentos salariais por rodada, premiação anual de construtores e duração de patrocínios.
- Incluída verificação da existência e dos critérios principais da auditoria de cadeia de duas temporadas (60 GPs).
- Nenhuma remoção de assets, telas ou histórico foi realizada.
- Esta entrega adiciona verificações de contrato de código; não declara execução do motor Kotlin completo nem compilação Android.
