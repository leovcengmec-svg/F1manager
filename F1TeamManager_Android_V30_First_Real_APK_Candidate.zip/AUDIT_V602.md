# Auditoria V602 — crash após fechar e reabrir

## Causa estrutural identificada

`CustomWorldCatalog.load()` mantinha `pilots`, `teams`, `flags` e overrides somente se `issues.isEmpty()`. Em uma instalação fria, um único problema semântico podia fazer a visão em memória permanecer vazia, embora as preferências contivessem uma equipe personalizada usada pela carreira salva. Componentes posteriores que procuravam essa equipe por ID com `first { ... }` podiam lançar `NoSuchElementException`, fechando o aplicativo.

## Correção

A carga publica registros estruturalmente parseáveis na visão runtime, deduplicados por identidade, mesmo quando existem alertas de integridade. O JSON persistido permanece intacto e `ensureWritable()` continua bloqueando gravações até resolver os alertas. Isso permite abrir a carreira e acessar a tela de diagnóstico/recuperação sem descartar silenciosamente os dados.

## Validação

- Inspeção estática do caminho de carga a frio e bloqueio de gravação.
- ZIP testado estruturalmente após empacotamento.
- Compilação Android, JUnit completo e reprodução no dispositivo ainda precisam ser executados. A imagem de crash não contém stack trace; a hipótese foi derivada do caminho de inicialização do catálogo e deve ser confirmada com o resumo de falha do Android se persistir.
