# Auditoria V578 — IDs de catálogo e vínculo de roster

## Defeito de raiz tratado
Os registros personalizados são persistidos em SharedPreferences e projetados para `WorldDatabase`. Antes desta versão, a validação verificava IDs duplicados entre os registros personalizados, mas não rejeitava explicitamente um ID personalizado na faixa oficial. Isso poderia fazer `associateBy(id)` no reconciliador do mercado escolher o registro errado. Também havia dependência exclusiva de `Pilot.teamId` para reconhecer pilotos de uma equipe, apesar de o roster da equipe já declarar `driver1Id`/`driver2Id`.

## Alterações
- Adicionada classe pura `CustomCatalogIdentityRules` para validar colisões e consistência dos vínculos.
- Integrada a validação ao carregamento real do catálogo; inconsistências continuam bloqueando gravações e não provocam regravação automática dos dados.
- Tornado o roster de equipe a fonte autoritativa para projetar pilotos legados cujo `teamId` salvo seja zero.
- Atualizada a migração de mercado para respeitar a declaração de roster e impedir que um piloto ligado a uma equipe seja utilizado para outra.

## Defeitos adicionais encontrados na compilação de domínio e corrigidos
- O compilador apontou chamadas incompatíveis com a assinatura local de `base(component)` em `CarDevelopmentEngine.startNextSeason`; corrigidas para o componente correto.
- `ManagerSeasonEngine` tentava copiar `installedPieceVersions` para `TeamCarState`, que não declara esse campo. O baseline foi mantido nos dois `PhysicalCar` do `TeamGarage`, onde a propriedade realmente existe.
- A projeção legada `aerodynamics` do carro novo agora usa o maior valor reconstruído entre asa dianteira e traseira.

## Verificações realmente executadas
- Harness Kotlin da regra de identidade: **4/4 cenários passaram**.
- Harness Kotlin de projeção de `WorldDatabase`: **5/5 asserções passaram**, com 41 equipes e 103 pilotos no cenário de teste.
- Harness Kotlin da migração de mercado: **4/4 asserções passaram**, com os dois pilotos personalizados alocados à equipe 41.
- Harness de construção do próximo carro: **aprovado**, preservando Carro 1/Carro 2 e a projeção legada de aerodinâmica.
- Simulação headless reproduzível (`tools/race_sim_test/run_two_season_headless_audit.sh`): **60/60 GPs passaram**, duas temporadas completas (2026 e 2027), grid expandido com 41 equipes/82 pilotos ativos e 102 pilotos no catálogo; mercado, evolução, classificação, premiação e transição para 2028 GP1 permaneceram sincronizados.
- Regressões do mercado V576: **3/3 passaram**; testes de contrato V578: **4/4 passaram**.
- Auditor estático V578: **20/20 verificações de integração e 13/13 verificações de catálogo passaram no pacote extraído**.
- Auditores estruturais genéricos, financeiros, ciclo de jogo, persistência da IA e roteamento de áudio: executados localmente; não equivalem a runtime Android.

## Não executado / não comprovado
- Build Android completo e suíte JUnit oficial.
- Fluxos de UI/Compose e persistência real por SharedPreferences em dispositivo Android durante as duas temporadas.
- Reprodução de áudio em dispositivo real. A simulação headless de 60 GPs foi executada com o motor de domínio real e um stub para a camada Android persistente do catálogo.

## Preservação
V577 foi a base direta. A comparação do inventário do ZIP V578 com V577 foi executada: 2.345 arquivos na base, 2.356 na entrega, 11 adicionados, 0 removidos. Os 390 arquivos de assets existentes nos caminhos de assets (incluindo o diretório histórico preservado) têm caminhos e conteúdos idênticos. Não foram removidos saves, contratos, finanças, calendário ou histórico.
