# V422 — Referência financeira variável pelo Overall exato

- A classe continua determinada por faixas de Overall, mas a referência de investimento não é mais fixa por classe.
- Referência interpolada entre âncoras: Overall 40 = €8M; 50 = €25M; 60 = €45M; 70 = €70M; 80 = €110M; 100 = €150M.
- Exemplos: Overall 40 = €8M; Overall 49 = €23,3M; Overall 65 = €57,5M; Overall 90 = €130M; Overall 100 = €150M.
- A previsão de investimento e a conversão do investimento na virada de temporada usam a mesma referência variável.
- Botões e layout permanecem inalterados; seus valores percentuais passam a acompanhar a referência dinâmica.
- Testes atualizados para garantir que pontuações diferentes dentro da mesma classe produzam referências diferentes.
