# V690 — Inteligência financeira dinâmica da IA

- Os percentuais 40% carro seguinte, 40% carro atual e 20% instalações permanecem como referências de prioridade, não como limites rígidos por categoria.
- P&D do carro atual e instalações compartilham o pool flexível após a prioridade dinâmica do carro seguinte; qualquer um pode usar o saldo não consumido pelo outro.
- O carro seguinte não fica limitado a €80 milhões acumulados por temporada. Os €80 milhões são a prioridade protegida inicial calculada sobre o envelope original (não 40% do saldo decrescente); após a prioridade ser financiada, ou a partir da janela de liberação no GP25, o saldo realmente não utilizado por P&D/instalações pode ser redirecionado ao próximo carro, até o teto de €150 milhões.
- O teto absoluto do projeto do carro seguinte permanece em €150 milhões.
- Instalações podem utilizar qualquer saldo disponível do envelope técnico compartilhado, sem exigir que a melhoria caiba em uma reserva anual de €40 milhões.
- A reserva histórica de instalações é apenas uma referência contábil/estratégica, limitada a €120 milhões, sem aumentar orçamento real ou permitir gastos fora do teto anual.
- Todos os débitos continuam respeitando caixa disponível, reserva operacional, previsão financeira e saldo do orçamento técnico global.
