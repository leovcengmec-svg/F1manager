# Auditoria V706 — carreira Team Principal

## Escopo

Correção da probabilidade de demissão, proteção do primeiro ano de contrato de dois anos, avaliação no ano final e calibração das metas de posição no Mundial de Construtores.

## Implementação inspecionada

- `TeamPrincipalCareerEngine.kt`: objetivos passam a persistir `rangeMax`; schema do estado evolui para 6 e decodifica schemas anteriores 1–5. Metas principais antigas são migradas para a tolerância correspondente.
- A tolerância é fixa no Top 10, +1 lugar entre 11º e 20º, e +2 lugares entre 21º e 40º. A colocação melhor que o alvo continua válida. Exemplo 25º aceita 25º–27º.
- `primaryObjectiveDescription()` corrige P1 para “Ser campeão (1º lugar no Mundial de Equipes)”; o restante do Top 10 continua sem faixa adicional.
- `firstYearProtectionApplies()` exige simultaneamente contrato 2 anos, ano 1/2, ao menos três metas concluídas e apoio final acima de 50. A condição retorna risco zero e também bloqueia a liquidação de demissão.
- `dismissalProbabilityPercent()` avalia explicitamente a perda da meta principal no ano final (1/1 ou 2/2), com penalidade variável conforme apoio. A falha não é garantia de demissão; o valor continua probabilístico e limitado.
- `recordSeason()` usa a mesma faixa de posição para o resultado principal, apoio da diretoria, repetição de falhas e risco efetivo.
- `CareerPreferences.teamPrincipalLiveBoardAssessment()` passa ano e duração de contrato, quantidade de metas concluídas e status da meta principal ao mesmo avaliador usado na liquidação.
- `MainActivity.kt` e `TeamPrincipalCareerScreen.kt` exibem a faixa atual, sinalizam as metas com o mesmo limite e consultam o resultado persistido no histórico.

## Cenários Kotlin executados

Harness compilado com `kotlinc` utilizando o arquivo de motor de produção `TeamPrincipalCareerEngine.kt` e stubs mínimos de garagem/instalações para isolar dependências de tipos:

1. Meta 25º, faixa 25º–27º: posição 27 cumpre e 28 não cumpre.
2. Meta 10º: posição 10 cumpre e 11 não cumpre.
3. Meta 1º: texto diz “Ser campeão (1º lugar)”, sem “1º ou melhor”.
4. Contrato 1/2: três metas cumpridas, apoio projetado 64 e meta principal perdida por uma posição; mesmo com rolagem de demissão 0, não demite e não abre avaliação antecipada.
5. Contrato 1/1 com falha esportiva/financeira extrema: rolagem 0 ativa avaliação/demissão.
6. Contrato 2/2 com falha esportiva/financeira extrema: rolagem 0 ativa avaliação/demissão.
7. Save antigo V705 com objetivo P25 é migrado para faixa P25–P27; encode/decode no schema 6 preserva o estado.
8. Histórico identifica o cumprimento real da meta principal pelo resultado persistido, inclusive quando o resultado foi atingido dentro da faixa.

Resultado do harness: **todos os cenários passaram**. Além disso, os 24 métodos da classe de regressão V639 e os 8 métodos V706 foram compilados e executados no runner isolado (32 métodos; 32 passaram). O runner usou uma pequena compatibilidade JUnit temporária porque as dependências Gradle/JUnit oficiais não estão instaladas; isso não substitui a execução oficial da suíte.

## Compatibilidade e versão

- `versionCode = 706`; `versionName = 0.706.0`.
- `package_manifest.txt`, README e changelog sincronizados.
- ZIP continua `F1TeamManager_Android_V30_First_Real_APK_Candidate.zip`.
- Nome público preservado: F1 Team Manager V30.

## Limitações

Gradle/Gradle Wrapper e Android SDK não estão disponíveis neste ambiente, portanto não foi possível executar `:app:assembleDebug` nem a suíte JUnit completa. O harness real do motor e as verificações estáticas não substituem essa validação Android; a compilação final permanece a cargo do GitHub Actions.
