# CHANGELOG V662 — Regras de contrato do Team Principal

## Confiança da diretoria
- Um contrato novo começa com 75% de apoio da diretoria, o mesmo patamar inicial usado pelo jogo para uma nova carreira.
- A confiança começa em pelo menos 75% ao renovar com a equipe atual ou ao assinar com uma nova equipe; se a confiança já for superior, ela é preservada. O histórico e o prestígio do Team Principal também são preservados.
- Na mudança de equipe, o novo apoio já vale no primeiro ano do contrato com a nova diretoria.

## Propostas externas
- O Team Principal passa a receber pelo menos uma proposta externa a partir de prestígio 0.
- Prestígio 0–39: 1 proposta externa; 40–59: 2; 60–100: 3.
- Com prestígio abaixo de 20, a primeira oportunidade vem da equipe elegível de pior classificação, sem deixar o mercado vazio.

## Duração contratual e condições
- Contratos de Team Principal agora duram somente 1 ou 2 temporadas, tanto na renovação quanto na mudança de equipe.
- O limite também é aplicado ao carregar e salvar carreiras antigas: contratos e ofertas legados de 3 anos são migrados para no máximo 2 anos.
- Não foram adicionados salário, bônus ou remuneração ao contrato de Team Principal, conforme a regra definida para o modo.

## Virada da temporada
- A virada fica bloqueada enquanto houver avaliação contratual pendente. O jogador precisa renovar ou aceitar uma proposta externa.
- A proteção está na interface e também na camada persistente, impedindo que outros caminhos iniciem a temporada sem resolver o contrato.

## Testes
- Atualizados os testes de quantidade de propostas por prestígio e do ciclo contratual.
- Adicionados testes para apoio inicial de 75%, piso de apoio ao assinar uma nova equipe, limite de 2 anos inclusive em saves antigos e bloqueio da virada com decisão pendente.

## Versionamento
- `versionCode = 662`
- `versionName = "0.662.0"`
- Nome público preservado: **F1 Team Manager V30**.
- Nome padrão do ZIP preservado: `F1TeamManager_Android_V30_First_Real_APK_Candidate.zip`.

## Validação
- ZIP validado estruturalmente após empacotamento.
- Testes JUnit e compilação Android não executados neste ambiente: Gradle/Gradle Wrapper e Android SDK não estão disponíveis.
