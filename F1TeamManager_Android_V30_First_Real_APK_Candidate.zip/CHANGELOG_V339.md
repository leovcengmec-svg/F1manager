# V339 — Sincronização global do mercado de pilotos

- Corrigido o adaptador `CareerPreferences.currentDrivers()`: a equipe atual de cada piloto agora vem do contrato ativo do mercado na temporada atual.
- Pilotos sem contrato ativo e registrados como agentes livres deixam de aparecer como integrantes da equipe anterior.
- As telas que consomem `currentDrivers()` passam a refletir a transferência executada na virada da temporada, em vez de usar o `teamId` imutável do banco de dados base.
- Mantido `WorldDatabase` como fonte de identidade e atributos base dos pilotos; contratos persistidos continuam sendo a fonte de verdade para vínculo com equipes.
- Nome oficial do ZIP preservado.
