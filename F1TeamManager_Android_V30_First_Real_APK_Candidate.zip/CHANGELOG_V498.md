# V498 — Correção estrutural da persistência de equipes de IA

- Corrigido o parser do snapshot financeiro da IA: o registro `S` contém 32 campos e não pode ser dividido com limite de 30, que mesclava os campos finais e descartava parte do estado da temporada.
- A persistência de instalações agora possui registros `F` independentes dos registros financeiros `S`; upgrades de instalações também possuem registros `U` independentes. Isso impede que alterações de instalações/eventos desapareçam quando a equipe ainda não possui um estado financeiro materializado.
- Mantida compatibilidade de leitura com snapshots antigos `S` e `I`; registros novos são aplicados depois dos antigos para que o ledger explícito prevaleça.
- Acrescentados testes de regressão para instalação sem registro financeiro e round-trip do snapshot estendido.
- Versão Android: 0.498.0 (versionCode 498).
- Limitação: testes Kotlin e compilação Android precisam ser executados em ambiente Gradle/Android; este pacote não contém Gradle Wrapper e o ambiente não disponibiliza o comando `gradle`.
