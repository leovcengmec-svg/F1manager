# V599 — Catálogo ampliado de objetivos Team Principal

- O objetivo principal continua sendo a posição no Mundial de Equipes e é recalculado pela posição atual.
- O objetivo secundário deixa de ser sempre financeiro: ele é o primeiro dos cinco objetivos sazonais sorteados do catálogo.
- Catálogo ampliado para 16+ tipos/opções, incluindo caixa, pontuação, evolução de posição, competitividade, progresso de pontos, pesquisa concluída, peça fabricada disponível e melhoria de cada uma das sete instalações.
- As metas de instalações são criadas conforme o nível atual e só aparecem quando há nível para evoluir; a conclusão verifica o nível real persistido.
- Pesquisa concluída é verificada pelo registro de designs concluídos na temporada. Fabricação verifica peças físicas aguardando instalação.
- Prestígio inicial 1, principal vale 4, outros objetivos valem 1; fracassos descontam e o ganho líquido continua limitado a +8 por temporada.
- Adicionado teste de contrato estático para catálogo, seleção, métricas e versionamento. Build Android e simulação integrada ainda pendentes.
- Versão Android: `versionCode 599` / `versionName 0.599.0`.

