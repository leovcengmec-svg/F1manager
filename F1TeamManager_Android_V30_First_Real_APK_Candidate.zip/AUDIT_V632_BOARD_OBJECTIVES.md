# Auditoria V632 — Objetivos da Diretoria no modo Team Principal

**Escopo:** análise estática da geração, atualização e avaliação dos objetivos. Nenhum código de jogo foi alterado nesta auditoria.

## Conclusão executiva

A impressão do jogador é explicada pelo código: os objetivos da próxima temporada são gerados no fechamento da temporada anterior, antes de terminar a construção do carro novo e aplicar o regulamento. Depois disso, o sistema não recalibra os objetivos usando a classificação de força do carro recém-construído. Além disso, os caminhos de renovação e contratação geram objetivos sem passar os dados reais de instalações e pontos anteriores, tornando algumas metas indevidamente fáceis.

Há também um erro de fonte de dados: o objetivo de reserva financeira é avaliado com `aiTeamBudget(teamId)`, mesmo no modo Team Principal do jogador, em vez de usar o saldo financeiro real da equipe ativa.

## Achados

### P1 — Objetivos da nova temporada não são recalibrados depois da construção do carro

- `CareerPreferences.kt:292–315`: `recordTeamPrincipalSeason()` chama `TeamPrincipalCareerEngine.recordSeason()` no evento de encerramento da temporada.
- `TeamPrincipalCareerEngine.kt:208–214`: `recordSeason()` imediatamente cria os objetivos da próxima temporada chamando `generateObjectives(... rank, nextObjectiveRank, constructorPoints, facilityLevels)`.
- `MainActivity.kt:1368 em diante`: só depois, na virada de temporada, é construído o carro da próxima temporada; então o regulamento anual é aplicado e o estado do carro/garagem é persistido. A classificação de força inicial é calculada posteriormente pelo fluxo de revelação/início da temporada.

Consequência: a meta principal usa a posição final do campeonato anterior, não a força real do novo carro após investimento, herança técnica e regulamento. Se o carro novo melhorar bastante, a meta continua permissiva; se piorar, pode ficar desajustada para cima.

### P1 — Renovação e troca de equipe recriam objetivos com instalações zeradas e pontos anteriores iguais a zero

- `TeamPrincipalCareerEngine.kt:234–241`: `renew()` chama `generateObjectives(..., 0)` e não passa `facilityLevels`.
- `TeamPrincipalCareerEngine.kt:243–255`: `acceptOffer()` faz o mesmo.
- `generateObjectives()` usa `facilityLevels[facility] ?: 0` em `TeamPrincipalCareerEngine.kt:140–146`; portanto, sem mapa, o texto da meta presume que as instalações começam no nível 0 e a meta vira nível 1, ainda que a equipe tenha instalações de nível 5, 7 ou 9.
- `points_gain` em `TeamPrincipalCareerEngine.kt:127` tem seu alvo construído a partir do argumento `points`; em `renew()`/`acceptOffer()` esse valor é sempre 0. A avaliação em `recordSeason()` exige apenas `constructorPoints > goal.target` (linha 184), então qualquer pontuação positiva cumpre essa meta.

Consequência: logo após renovar ou aceitar outra equipe, o conjunto de objetivos pode ficar artificialmente mais fácil e desconectado do parque técnico da equipe.

### P1 — A meta de caixa é avaliada com o ledger de IA

- `CareerPreferences.kt:302–308`: `recordTeamPrincipalSeason()` passa `cashBalance = aiTeamBudget(state.teamId)`.
- `CareerPreferences.kt:502–506`: `aiTeamBudget()` lê a preferência `aiTeamBudgets` e, se não encontrar o registro, usa o orçamento inicial da equipe.
- `TeamPrincipalCareerEngine.kt:181`: a meta `cash` é considerada cumprida se esse valor for maior ou igual ao alvo.

Consequência: o objetivo “Reserva financeira” pode ser marcado como cumprido ou fracassado com um saldo que não representa o caixa atual da carreira do jogador. A fonte correta deve ser o `loadFinance(teamId, fallback).budget` da equipe ativa, consistente com a tela de finanças.

### P2 — A dificuldade dos objetivos é baseada em faixas muito amplas e não leva em conta a nova força do carro

- `TeamPrincipalCareerEngine.kt:99–105`: `targetRank()` dá uma margem fixa por faixa. Para posições de 31º a 40º, a meta é sempre 36º–40º e para equipes em 35º a 40º fica no limite 40º.
- `TeamPrincipalCareerEngine.kt:119–129`: pontuação alvo fixa por posição anterior (5 pontos para 31º–40º; 20 para 21º–30º; 50 para 11º–20º; 100 para 6º–10º; 180 para 1º–5º).
- `TeamPrincipalCareerEngine.kt:148–154`: até cinco objetivos secundários são selecionados por hash determinístico, não por uma avaliação de desempenho previsto, instalações existentes, compromissos financeiros ou projetos em andamento.

Exemplo: uma equipe que terminou em 40º recebe meta principal 40º ou melhor; se o carro novo subir para o top 20, a meta continua baseada no 40º lugar até outro ciclo de geração. A meta financeira para o fundo do grid é €5 milhões e a de pontos é 5 — metas que podem ser triviais dependendo do carro, calendário e receitas.

### P2 — A classificação pré-temporada não alimenta o estado vivo dos objetivos

- `MainActivity.kt` calcula `SeasonOpeningCarRankings` depois da construção/regulamento do carro e usa esse ranking na tela de revelação e no evento de início da temporada.
- Na tela de carreira, porém, `currentTeamRank` é obtido com `teamPrincipalRankings(store, principal)`, que se baseia nos pontos do campeonato; antes de qualquer ponto da nova temporada, a função volta ao ranking padrão/última posição confirmada. A lógica `hasCurrentSeasonResults` (determinada por round/points) mantém metas de classificação sem status mesmo que o ranking de força do novo carro já esteja disponível.

Consequência: a classificação de força que o jogador vê no evento do carro novo não é usada para atualizar a meta ou o estado ao entrar na temporada.

### P2 — Alguns dados de objetivos vivos podem ficar temporariamente desatualizados

Em `MainActivity.kt` no ramo `TEAM_PRINCIPAL_CAREER`, `currentFinance`, `currentFacilities`, `currentResearch` e `currentFactory` são carregados usando `remember(teamId, currentWeek, season)`. Se caixa, nível de instalação, projeto ou fila de fábrica mudar dentro da mesma semana sem mudança de chave, o estado carregado pode permanecer antigo até a tela recompor com outra chave ou ser reaberta. Isso prejudica a atualização imediata das cores dos cards.

### P2 — Testes Team Principal estão desalinhados com a regra atualmente implementada

`app/src/test/java/com/f1teammanager/core/manager/V586TeamPrincipalCareerEngineTest.kt` contém expectativas que divergem do motor atual:

- `startsAtMinimumPrestigeAndSetsReachableBottomGridObjective`: espera prestígio 10 e meta 37 para ranking 40; o motor atual inicia com prestígio 1 e `targetRank(40)` devolve 40.
- `renewalMovesEvaluationWindowAndResetsContractObjective`: espera meta 32 para posição 35; `targetRank(35)` devolve 40.

Isso demonstra deriva entre a política documentada pelos testes antigos e a implementação corrente. Antes de ajustar a dificuldade, os testes precisam ser atualizados para refletir regras de negócio explicitamente aprovadas; não se deve simplesmente apagar essas expectativas.

## Recomendação de correção

1. Manter o resultado da temporada anterior como baseline histórico, mas **finalizar/calibrar os objetivos da nova temporada só após** o carro novo, garagem e regulamento serem aplicados e a classificação real de força de abertura estar disponível.
2. Introduzir um único ponto de geração/recalibração, idempotente por `teamId + season`, persistindo os objetivos finais para que abrir a tela/recarregar o jogo não sorteie metas diferentes.
3. Criar contexto explícito de geração: posição final anterior, força inicial do carro novo, nível real de todas as instalações, pontos anteriores, orçamento atual real, pesquisa/fábrica em andamento e eventuais upgrades planejados.
4. Usar a mesma função/contexto em início de carreira, fechamento de temporada, renovação e mudança de equipe. Nunca usar `emptyMap()` nem `points=0` como dados implícitos para equipe existente.
5. Definir metas dinâmicas e proporcionais: meta de classificação próxima, mas mais exigente que a projeção de força; pontos calculados sobre a pontuação provável e o calendário; metas financeiras relativas a salários, despesas, reservas e nível comercial; metas de instalação considerando o nível atual e custo viável, evitando pedir nível 1 a uma instalação de nível alto.
6. Calcular a meta financeira usando o ledger financeiro verdadeiro da equipe do jogador. Manter o ledger de IA só para equipes de IA.
7. Atualizar os valores observados ao entrar/retornar à tela e após ações da mesma semana, sem depender apenas de `currentWeek` mudar.
8. Adicionar testes unitários para rank inicial pós-carro, melhoria/recuo de ranking, todos os níveis de instalação, renovação, troca de equipe, saldo financeiro real, persistência/idempotência e objetivos ao longo da temporada.

## Estado desta auditoria

- Fonte examinada: V632, `versionCode=632`, `versionName=0.632.0`.
- Escopo: análise estática dos caminhos de geração, avaliação e apresentação de objetivos.
- Não foram alterados arquivos de jogo nem gerado novo ZIP nesta etapa.
- Não foi executado `assembleDebug` ou simulação completa Android.
