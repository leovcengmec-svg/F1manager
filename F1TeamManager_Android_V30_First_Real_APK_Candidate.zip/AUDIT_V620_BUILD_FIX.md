# Auditoria V620 — correções reportadas pelo pipeline Android

## Erros do log e correções

1. `MainActivity.kt:2450:1 — This annotation is not repeatable` — removida uma das duas anotações `@Composable` consecutivas antes de `HomeEventImageCard`.
2. `MainActivity.kt:2485:13 — Functions which invoke @Composable functions must be marked with the @Composable annotation` — adicionada a anotação `@Composable` antes da função `Home`.
3. `MainActivity.kt:2519`, `2522`, `2596`, `2767 — @Composable invocations can only happen from the context of a @Composable function` — erros em cascata decorrentes de `Home` não estar marcado como composable; `Home` foi corrigido.
4. `SeasonCarRevealScreen.kt:199:50 — Unresolved reference: teamRank` — a versão do código empacotado para V620 declara `teamRank: Int` e `totalTeams: Int` na assinatura da tela, e `MainActivity.kt` fornece os dois argumentos nomeados. O erro não é reproduzível por inspeção da fonte atual.
5. `SeasonEndEventScreen.kt:234:102 — Unresolved reference: graphicsLayer` — adicionado `import androidx.compose.ui.graphics.graphicsLayer`.

## Integridade e escopo

- `app/build.gradle.kts`: `versionCode = 620`, `versionName = "0.620.0"`.
- Projeto e pastas `app`, `docs`, `tools` e `validation` foram preservados.
- Assets externos incluídos em `app/src/main/assets`: 195 arquivos, verificados por hash contra os arquivos correspondentes no ZIP V619 original.
- Não houve alteração deliberada em regras do jogo, contratos, decisões financeiras, nem formato de save.

## Limitações

O ambiente que produziu este pacote não possui Gradle nem Android SDK instalados; o ZIP também não contém `gradlew`. Por isso, esta entrega corrige os erros explícitos do log e verifica a integridade do código empacotado, mas não declara que a compilação Android completa foi aprovada. Rodar `assembleDebug` no pipeline Android continua sendo necessário para confirmar e revelar eventuais erros adicionais.
