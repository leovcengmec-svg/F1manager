# Auditoria V421

## Alteração
A classificação e o investimento de referência de Manter Força agora derivam diretamente do Overall do carro na escala 40–100. O Overall considera os seis componentes de desempenho. Quando a garagem física está disponível, é usada a média dos Overall dos carros 1 e 2.

## Mapeamento
| Overall | Classe | Referência |
|---:|---|---:|
| 40–49 | Fim de pelotão | € 8.000.000 |
| 50–59 | Ruim | € 25.000.000 |
| 60–69 | Médio | € 45.000.000 |
| 70–79 | Bom | € 70.000.000 |
| 80–89 | Excelente | € 110.000.000 |
| 90–100 | Briga pelo título | € 150.000.000 |

## Validação
- Incluído teste automatizado para os limites de cada faixa e as referências financeiras.
- ZIP submetido à verificação estrutural após empacotamento.
- Não foi executada compilação Android nem suíte de testes nesta etapa; não declarar APK compilado.
