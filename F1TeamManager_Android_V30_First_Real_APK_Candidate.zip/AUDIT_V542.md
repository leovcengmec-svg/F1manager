# Auditoria V542

## Causa corrigida
`AITeamFinancialEngine.considerNextSeasonInvestment` congelava `nextSeasonBudgetBases` na primeira chamada do GP. Se a equipe começasse com liquidez temporariamente protegida por salários, manutenção ou custos operacionais, o teto cumulativo permanecia preso a essa fotografia inicial, mesmo após entradas financeiras reais.

## Correção
O teto agora usa o maior valor entre a base previamente persistida e o caixa atual não negativo somado ao investimento já acumulado. A base não diminui com despesas posteriores. Os limites de caixa disponível, reserva operacional, alvo de investimento e teto absoluto de €150M continuam sendo aplicados antes do débito.

## Limitações de validação
ZIP e código-fonte podem ser verificados estruturalmente; a compilação Gradle e a simulação longa de múltiplas temporadas precisam ser executadas no ambiente Android/Gradle do projeto. Não declarar build validado até esses testes passarem.
