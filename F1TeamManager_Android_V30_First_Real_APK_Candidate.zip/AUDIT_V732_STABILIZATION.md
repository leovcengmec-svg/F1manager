# Auditoria V732 — consistência do próximo carro e inteligência financeira da IA

## Base e versão
- Base: V731 / 0.731.0.
- Versão resultante: V732 / 0.732.0 (`versionCode = 732`).
- Nome público preservado: F1 Team Manager V30.
- Nome original do ZIP preservado: `F1TeamManager_Android_V30_First_Real_APK_Candidate.zip`.
- V731 foi mantida intacta; os saves do usuário não foram modificados.

## 1. Próximo carro: fonte única de construção
- Criado `NextSeasonCarProjectionEngine` como fonte comum do construtor físico.
- Ranking, ficha da equipe, mercado e transição utilizam a mesma construção física, a tabela de investimento e os limites anuais do carro.
- O Overall oficial utiliza somente investimento confirmado. O runway de caixa futuro aparece como cenário condicional e não altera o ranking oficial.
- Regulamento e penalidade financeira são aplicados uma vez sobre o resultado físico oficial.
- A virada do carro do jogador chama o mesmo construtor físico sem regulamento; a coordenação da virada aplica regulamento e penalidade depois, na mesma ordem da projeção oficial.

## 2. Fotografia canônica após GP30
- O fluxo de encerramento da carreira salva a fotografia das garagens das equipes de IA depois da liquidação do GP30, prêmios de construtores e penalidades financeiras.
- O motor de simulação de temporadas também persiste o checkpoint canônico.
- `AITeamDevelopmentEngine` consulta o checkpoint canônico antes de tentar reconstruir temporadas por replay histórico. Isso impede que o orçamento inicial sintético reescreva a garagem que acabou de ser projetada.
- O armazenamento de checkpoint avançou para schema 3 e continua lendo schema 2; saves sem checkpoint canônico permanecem compatíveis e usam o replay legado até o próximo GP30.

## 3. Estratégia financeira da IA
- O cálculo da diferença para o carro mais forte agora é assinado. Uma equipe atrás por 16 pontos permanece com gap -16; o valor negativo não é transformado em zero.
- Disputa pelo título exige posição entre as cinco primeiras e distância absoluta de até quatro pontos para o carro mais forte.
- Uma função compartilhada seleciona a mentalidade usada nas decisões de instalações, carro atual e próximo carro.
- Prioridades orientativas dentro do envelope técnico compartilhado de €200M:
  - Padrão/meio do grid: 55% carro atual e 45% instalações.
  - Carro dominante: 60% carro atual e 40% instalações.
  - Disputa pelo título: 65% carro atual e 35% instalações.
  - Reconstrução: 65% carro atual e 35% instalações.
- O próximo carro mantém envelope independente de €150M.
- Percentuais são prioridades e não cotas rígidas que causem dinheiro parado; caixa livre, obrigações, previsão e envelope anual continuam sendo guardrails.

## 4. Desenvolvimento das sete instalações
- Metas estratégicas: P&D, Fábrica e Túnel de Vento nível 6; Centro Comercial, Simulador, Desenvolvimento de Pilotos e Operações de Corrida nível 5.
- A lacuna até o nível-alvo é o sinal principal da seleção, em vez de uma pontuação fixa que favorecia sempre P&D.
- Reavaliação a cada quatro semanas; uma obra de 12 semanas pode iniciar a próxima melhoria imediatamente quando termina.
- A parcela destinada às instalações fica protegida do simulador de P&D/fabricação até que todas as sete instalações alcancem nível 10. Depois disso, a parcela não utilizada pode ser reutilizada para o carro atual.
- As obras continuam limitadas por caixa disponível, reserva operacional, compromissos futuros e envelope compartilhado de €200M.

## 5. Contabilidade técnica
- O pipeline físico envia os totais acumulados de pesquisa/desenvolvimento e fabricação separadamente.
- `applyDevelopmentCost` calcula incrementos a partir dos registros anteriores e debita `RESEARCH_DESIGN` e `FABRICATION` nas categorias corretas.
- O valor total permanece limitado ao caixa disponível e ao envelope técnico anual.

## 6. Testes e validação executados
- Núcleo Kotlin: 79 arquivos do conjunto core compilados com Kotlin 2.0/K2 por `kotlinc`; apenas avisos preexistentes de nulidade/Locale.
- Auditoria estática V732: `tools/race_sim_test/v732_ai_car_finance_audit.py`, 39/39 verificações aprovadas.
- Runner direcionado de asserções: 29 testes aprovados e zero falhas nas execuções incluídas. Uma asserção antiga de renovação de patrocínio foi deliberadamente excluída desta bateria: `TeamSponsorshipEngine.kt` tem SHA-256 idêntico ao arquivo da V731 e não foi alterado pela V732; a divergência observada nesse teste é externa ao escopo da atualização.
- Consistência de abertura: teste automatizado para as 40 equipes confirmou que o snapshot oficial persistido é exatamente o mesmo que a garagem carregada na abertura da temporada, mesmo que o ranking técnico da nova temporada mude.
- Smoke de construção: confirmou projeção canônica, checkpoint de GP30, gap de disputa pelo título, metas das sete instalações e separação do ledger de P&D/fabricação.
- Distribuição de instalações: simulação de 80 semanas em uma equipe financeiramente saudável iniciou obras em cinco tipos diferentes, em vez de concentrar todas as decisões em P&D.
- Smoke de cinco temporadas/280 semanas: as sete instalações receberam melhorias; níveis finais no cenário sintético: Fábrica 4, P&D 3, Túnel de Vento 4, Simulador 3, Operações de Corrida 3, Desenvolvimento de Pilotos 3 e Centro Comercial 3. O saldo da equipe permaneceu positivo.

## 7. Limitações
- Não foi executada a suíte JUnit completa do Gradle.
- Não foi possível executar `compileDebugKotlin` nem `assembleDebug` neste ambiente, que não tem Gradle Wrapper, Gradle ou Android SDK instalados. Não declarar APK compilado até o GitHub Actions concluir com sucesso.
- A simulação de cinco temporadas exercita o escalonador de instalações para uma equipe com orçamento e fluxo anual sintéticos; não substitui uma simulação econômica completa de 40 equipes por 5, 10, 15 e 20 temporadas com todos os salários, receitas, dívidas e corridas.
