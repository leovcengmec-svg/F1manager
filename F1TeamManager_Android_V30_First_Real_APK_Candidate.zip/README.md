# F1 Team Manager V30 — V706

**VersionCode:** 706  
**VersionName:** 0.706.0

V706 recalibra a carreira Team Principal: proteção no primeiro ano de contrato de dois anos quando o gestor entrega ao menos três metas e mantém apoio acima de 50, avaliação de demissão mais contextualizada no último ano, e metas esportivas com faixa moderada fora do Top 10. Corrige também a apresentação da meta de campeão.

Nome público preservado: **F1 Team Manager V30**.

## Revisão atual — V706

- VersionCode 706 / VersionName 0.706.0; base V705.
- Contrato 1/2: se ao menos três metas forem cumpridas e o apoio da diretoria terminar acima de 50, não há demissão no primeiro ano, mesmo que a meta principal não seja atingida.
- Contratos 1/1 e 2/2: a meta principal é avaliada explicitamente na temporada de encerramento, aumentando ou reduzindo a chance de demissão conforme o apoio, a distância esportiva e os demais indicadores; falhar a meta não causa demissão automática.
- Meta principal fora do Top 10 recebe tolerância proporcional: +1 posição para metas entre 11º e 20º e +2 posições para metas entre 21º e 40º. Exemplo: meta 25º aceita 25º–27º (e qualquer colocação melhor).
- Metas Top 10 não recebem margem adicional. A meta de 1º lugar aparece como “Ser campeão (1º lugar)”, nunca “1º ou melhor”.
- O limite superior da faixa é persistido no objetivo. Saves antigos V705 são migrados sem perder contrato, apoio, histórico ou metas em andamento.
- UI, previsão de risco, liquidação final, conquistas e histórico consultam a mesma definição de meta principal.
- Testes direcionados V706 e harness Kotlin com o motor real cobrem proteção contratual, avaliação no último ano, faixas de posição e migração de save.

## Histórico preservado — V700

- VersionCode 700 / VersionName 0.700.0; base V699.
- Idade numérica em anos exibida na tela Equipe, na lista/perfil da equipe, no histórico individual, no desenvolvimento de pilotos, na Central de Equipes e em todos os cartões do Mercado de Pilotos.
- As telas leem a idade do motor da carreira para a temporada ativa; a regra de ciclo e envelhecimento não foi alterada.
- A interface mostra apenas o número de anos, sem rótulos como jovem, meia-idade ou veterano. A relação dos 100 pilotos de 2026 está em `PILOT_AGES_V700.md` e `PILOT_AGES_V700.csv`.
- A idade inicial ainda é sintética e determinística; esta versão não altera a idade-base gerada, apenas a torna visível para revisão.
- Estabilização da cadeia de corrida: toda entrada em CareerWeekendEngine e InstantSimulationService normaliza atributos permanentes para 40–100.
- Cálculo de penalidade por chuva também respeita o piso 40 na chamada direta.
- Notificações de P&D usam a semana real de conclusão do projeto, inclusive em avanços de várias semanas.
- Workflow não exige mais metadados obsoletos da v685 e gera o artefato APK com o código da versão atual.
- Testes históricos de construção atualizados para validar Overall físico mínimo 40.
- Imagens externas em Pictures/F1Manager/Assets são o funcionamento esperado do jogo e permanecem suportadas.

## V698 — piso universal 40–100

- Piso mínimo de 40 para os sete atributos permanentes dos pilotos, potencial individual, atributos de todos os componentes do carro e confiabilidade geral/por componente.
- A regra cobre dados de carreira antigos, IA, garagem física, P&D, designs, fabricação, peças, snapshots de Team Principal e fornecedores de motor/pneus.
- Penalidades financeiras, evolução, regressão, P&D, fabricação e migração de saves respeitam o mesmo piso permanente de 40.
- Desgaste e confiabilidade instantânea durante incidentes de corrida são estados transitórios e continuam podendo chegar a zero; os atributos-base permanentes nunca ficam abaixo de 40.

## V697 — correção da recuperação física no ciclo etário

- A recuperação de 50% é calculada sobre o total combinado das perdas de envelhecimento em velocidade, ultrapassagem e defesa.
- Os pontos inteiros são distribuídos por maiores restos, evitando recuperação zero quando cada atributo perde apenas um ponto.
- O limite de cada atributo continua sendo o pico histórico e a quantidade de perda física por envelhecimento registrada.
- Preservados os limites financeiros independentes: €200M para P&D/fabricação/instalações e €150M para o próximo carro.
- Nome público mantido: F1 Team Manager V30.

## Regras comerciais da v685 preservadas

- Níveis 0, 1 e 2: contratos de 3–10 GPs.
- Níveis 3 a 10: contratos de 8–16 GPs.
- Contratos existentes não têm sua duração alterada.

## V684 — correção de compilação e reequilíbrio econômico

- Centro Comercial: níveis 0–3 preservados; níveis 4–10 passam a ter crescimento incremental menor nas vendas, multiplicador comercial com retornos decrescentes e manutenção progressiva.
- Patrocínios: novos contratos passam a durar 8–16 GPs; contratos já assinados em saves existentes permanecem inalterados.
- Investimento técnico: P&D, fabricação, instalações e carro da próxima temporada compartilham o limite anual de €200 milhões. A IA pode reaproveitar alocação não utilizada, mantendo reservas operacionais.
- Painel financeiro: “Caixa Atual” substitui o rótulo incorreto “Salário Anual”; investimento no carro seguinte e saldo consolidado são exibidos separadamente.

## Correção V684 — compilação do painel de investimento

- Corrigida a referência fora de escopo a `managerState` na tela Equipe. O investimento no carro seguinte é passado explicitamente ao composable e contabilizado junto do envelope anual.
- Corrigidos os erros Kotlin em cascata na barra de progresso e nas comparações de limite.

## V682 — equilíbrio carro/piloto por condição climática

- Seco e nublado: carro 65% / piloto 35%.
- Chuva fraca e moderada: carro 55% / piloto 45%.
- Chuva forte: carro 50% / piloto 50%.
- A mesma distribuição é aplicada à volta de classificação e ao ritmo-base de corrida.
- O cálculo de penalidade por chuva limita habilidade em pista molhada a 0–100 e consistência a 40–100.

## Versão

- `versionCode`: 706
- `versionName`: 0.706.0

## Compilação

Abra esta pasta no Android Studio e execute a tarefa `assembleDebug`. O projeto usa Kotlin, Jetpack Compose e Gradle Kotlin DSL.

O workflow `.github/workflows/android-apk.yml` valida os contratos da versão atual, executa os testes unitários e `:app:assembleDebug` no GitHub Actions, publicando o APK de depuração como artefato identificado dinamicamente pela versão. O pipeline configura Java 17, Android SDK 36 e Gradle 9.5.0, compatível com o Android Gradle Plugin 9.3.0 usado pelo projeto.

## Estrutura mantida

- `app/src/main`: aplicação, recursos visuais e bases locais usadas pelo jogo.
- `app/src/test`: testes de regressão e auditoria do motor.
- `tools`: utilitários de auditoria/teste.
- `docs`: documentação técnica ainda agrupada separadamente.

O jogo utiliza imagens externas em `Pictures/F1Manager/Assets/` no armazenamento do dispositivo, conforme os nomes aceitos pelo registro de assets do aplicativo. Esse é o funcionamento previsto; o ZIP/APK não precisa conter essas imagens.

## Limpeza V243

Removidos do ZIP os históricos de alteração antigos soltos na raiz, páginas HTML de apoio não usadas pelo APK, a folha de contato de imagens e a lista `corefiles.txt` que apontava para caminhos absolutos de outra máquina. Código Kotlin, testes, recursos do aplicativo e ferramentas foram preservados nesta etapa; não foram apagadas classes apenas por suspeita de uso.


## Auditoria V245

- Corrigida a versão declarada neste README para corresponder ao build.gradle.kts.
- Revisão estática dos recursos Android: todos os 41 recursos em res/ têm ocorrência textual pelo nome no código/configuração.
- Preservados os 124 arquivos documentais/históricos encontrados no pacote, os testes de regressão e todos os Assets em app/src/main/assets.
- Nenhuma classe Kotlin, imagem, base JSON ou documentação histórica foi excluída nesta etapa. Classes sem referência textual direta permanecem para validação por compilação e análise de carregamento dinâmico.
- Limitação: o ZIP não inclui gradlew/gradle-wrapper.jar; não foi possível executar compilação Gradle local nesta auditoria.


## Auditoria V246 — navegação e acesso aos históricos

- O card de identidade da equipe na Home abre a Central de Equipes.
- O escudo na tela Equipe abre a mesma Central de Equipes.
- Os cards dos pilotos na Central de Equipes abrem o histórico individual do piloto selecionado.
- O botão Voltar do Android agora é tratado pela navegação interna; na Home, solicita confirmação antes de sair, em vez de encerrar o jogo imediatamente.
- O retorno da Central de Equipes preserva a origem (Home ou Equipe), e o retorno do histórico do piloto volta à Central de Equipes.
- Preservados os Assets, as bases, os testes e a documentação histórica existente.
- Limitação desta etapa: compilação Android não executada porque não há Gradle/Gradle Wrapper disponível neste ambiente.


## Correções V247 — avisos e decisões da corrida

- Todos os diálogos ativos da corrida mantêm a simulação pausada; o modo automático é retomado quando todas as pendências forem resolvidas.
- O diálogo de evento exige o botão explícito `CONTINUAR CORRIDA`; toque externo e botão Voltar não o dispensam.
- Removido o botão de fechar que executava `STAY_OUT` implicitamente na decisão do manager.
- Diálogos informativos aguardam a conclusão da decisão do manager e da etapa de box, evitando sobreposição.
- A fila informativa mantém o teto de oito cards por GP; decisões obrigatórias continuam controladas pelo motor, independentemente desse teto.
- Preservados Assets, histórico de versões, testes e demais sistemas.
- Compilação Android não executada: este pacote não inclui Gradle Wrapper e não há Gradle instalado no ambiente de vistoria.


## Correção V499 — previsão visível no diálogo de P&D

- Movido o card GANHO TECNOLÓGICO ESTIMADO para antes da lista de complexidade, para que a previsão apareça logo após a seleção do foco e não fique escondida abaixo das opções e dos botões em telas menores.
- Mantidas as fórmulas existentes do ResearchEngine, seletores de foco/complexidade e ações de iniciar/cancelar pesquisa.
- ZIP validado quanto à integridade; compilação Android não executada neste ambiente.


## V598 — Objetivos dinâmicos do Team Principal
Objetivos de temporada variáveis por força da equipe, prestígio inicial 1 e pontuação limitada a +8 por temporada. Ver `CHANGELOG_V598.md` e `AUDIT_V598_TEAM_PRINCIPAL_OBJECTIVES.md`.



## V604 — Calibração de evolução dos pilotos
- Desempenho por GP compara quali/corrida contra a meta esportiva de equipe sem punir excessivamente uma posição de diferença.
- Crescimento calibrado para cerca de 1,0 na meta esperada; categoria de evolução continua definindo o teto anual por atributo.
- Teste isolado confirma crescimento de Overall até GP6 em desempenho perto da meta.

## V603 — Auditoria e integridade dos pilotos

- O ciclo de carreira é fixo em 5 anos de evolução, 2 de auge e 5 de regressão, persistindo entre temporadas.
- Regressão respeita o Overall mínimo da classe; Lenda mantém teto 100 e mínimo 60.
- A virada de temporada preserva fase, contador do ciclo e progresso fracionário, reiniciando apenas os limites anuais e os registros de idempotência da temporada anterior.
- `currentDrivers()` monta o catálogo com uma única leitura dos mapas de atributos e classe, evitando a leitura/mesclagem do conjunto inteiro uma vez por piloto.
- A correção nominal específica do Felipe foi removida: cada nova carreira reinicializa os 100 pilotos pelos perfis canônicos da versão atual, conforme a regra de início do zero.

## Regra de validação de atualizações (V602)
Toda atualização funcional deve ser validada a partir de uma nova carreira iniciada por **Novo Jogo**, sem continuar um save de versão anterior. Os recursos de salvar/exportar/importar permanecem disponíveis; saves antigos não devem ser apagados automaticamente. Consulte `REGRA_NOVA_CARREIRA_A_CADA_ATUALIZACAO.md`.


## Correção V675 — avaliação da diretoria

- Atingir o objetivo principal de classificação e cumprir pelo menos 60% das metas limita o risco de demissão a 5%, mesmo quando indicadores secundários isolados estejam ruins.
- Atingir o objetivo principal e cumprir pelo menos 40% das metas limita o risco a 12%.
- Mesmo sem atingir o objetivo principal, cumprir pelo menos 80% das metas limita o risco a 25%.
- Demissões continuam possíveis em temporadas de desempenho global insuficiente; o ajuste impede que penalidades secundárias acumuladas anulem uma temporada esportivamente bem-sucedida.


## V701 — idade, carreira e evolução de pilotos

Consulte `CHANGELOG_V701.md` e `PILOT_AGES_V701.csv` para as regras e as 100 idades iniciais oficiais de 2026.


## V702 — desenvolvimento explícito da IA, contratos e margem de classe

- Filas individuais da IA são persistidas por equipe no estado canônico do mercado, incluindo programas ativos e semana absoluta do último avanço; a conclusão é processada antes do GP que recebe o benefício.
- IA e jogador usam o mesmo `DriverDevelopmentEngine`: duração, pontos, capacidade, potencial individual e limite anual por perfil.
- Não há bônus passivo de crescimento por nível de instalação. O nível define apenas os programas disponíveis, sua capacidade, duração e pontos.
- IA escolhe pilotos do próprio elenco para programas individuais, priorizando potencial ainda não realizado e idade favorável, preenchendo todas as vagas e evitando iniciar programa quando os limites anuais já foram consumidos.
- Contratos iniciais e decisões posteriores da IA usam durações de 1 a 5 anos de acordo com idade, Overall e potencial; a contratação emergencial não força mais 1 ano.
- Uma média de desempenho excepcional na temporada libera margem temporária de +1 a +3 Overall acima do teto da classe, sempre limitada pelo potencial e Overall 100.
