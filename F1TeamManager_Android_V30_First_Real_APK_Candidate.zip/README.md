# F1 Team Manager — código-fonte Android

Projeto Android nativo do F1 Team Manager.

## Versão

- `versionCode`: 609
- `versionName`: 0.609.0

## Compilação

Abra esta pasta no Android Studio e execute a tarefa `assembleDebug`. O projeto usa Kotlin, Jetpack Compose e Gradle Kotlin DSL.

## Estrutura mantida

- `app/src/main`: aplicação, recursos visuais e bases locais usadas pelo jogo.
- `app/src/test`: testes de regressão e auditoria do motor.
- `tools`: utilitários de auditoria/teste.
- `docs`: documentação técnica ainda agrupada separadamente.

Assets externos opcionais podem ser colocados em `Pictures/F1Manager/Assets/` no armazenamento do dispositivo, conforme os nomes aceitos pelo registro de assets do aplicativo.

## Limpeza V243

Removidos do ZIP os históricos de alteração antigos soltos na raiz, páginas HTML de apoio não usadas pelo APK, a folha de contato de imagens e a lista `corefiles.txt` que apontava para caminhos absolutos de outra máquina. Código Kotlin, testes, recursos do aplicativo e ferramentas foram preservados nesta etapa; não foram apagadas classes apenas por suspeita de uso.


## Auditoria V245

- Corrigida a versão declarada neste README para corresponder ao build.gradle.kts.
- Revisão estática dos recursos Android: todos os 41 recursos em res/ têm ocorrência textual pelo nome no código/configuração.
- Preservados os 124 arquivos documentais/históricos encontrados no pacote, os testes de regressão e todos os Assets em app/src/main/assets.
- Nenhuma classe Kotlin, imagem, base JSON ou documentação histórica foi excluída nesta etapa. Classes sem referência textual direta permanecem para validação por compilação e análise de carregamento dinâmico.
- Limitação: o ZIP não inclui gradlew/gradle-wrapper.jar; não foi possível executar compilação Gradle local nesta auditoria.


## Auditoria V246 — navegação e acesso aos históricos

- O card de identidade da equipe na Home abre a Central de Equipes.
- O escudo na tela Equipe abre a mesma Central de Equipes.
- Os cards dos pilotos na Central de Equipes abrem o histórico individual do piloto selecionado.
- O botão Voltar do Android agora é tratado pela navegação interna; na Home, solicita confirmação antes de sair, em vez de encerrar o jogo imediatamente.
- O retorno da Central de Equipes preserva a origem (Home ou Equipe), e o retorno do histórico do piloto volta à Central de Equipes.
- Preservados os Assets, as bases, os testes e a documentação histórica existente.
- Limitação desta etapa: compilação Android não executada porque não há Gradle/Gradle Wrapper disponível neste ambiente.


## Correções V247 — avisos e decisões da corrida

- Todos os diálogos ativos da corrida mantêm a simulação pausada; o modo automático é retomado quando todas as pendências forem resolvidas.
- O diálogo de evento exige o botão explícito `CONTINUAR CORRIDA`; toque externo e botão Voltar não o dispensam.
- Removido o botão de fechar que executava `STAY_OUT` implicitamente na decisão do manager.
- Diálogos informativos aguardam a conclusão da decisão do manager e da etapa de box, evitando sobreposição.
- A fila informativa mantém o teto de oito cards por GP; decisões obrigatórias continuam controladas pelo motor, independentemente desse teto.
- Preservados Assets, histórico de versões, testes e demais sistemas.
- Compilação Android não executada: este pacote não inclui Gradle Wrapper e não há Gradle instalado no ambiente de vistoria.


## Correção V499 — previsão visível no diálogo de P&D

- Movido o card GANHO TECNOLÓGICO ESTIMADO para antes da lista de complexidade, para que a previsão apareça logo após a seleção do foco e não fique escondida abaixo das opções e dos botões em telas menores.
- Mantidas as fórmulas existentes do ResearchEngine, seletores de foco/complexidade e ações de iniciar/cancelar pesquisa.
- ZIP validado quanto à integridade; compilação Android não executada neste ambiente.


## V559 — validações proporcionais ao catálogo

- O validador do grid agora calcula duas vagas por equipe cadastrada e o total de pilotos a partir do catálogo ativo.
- O mercado deixa de exigir exatamente 80 pilotos no grid, 100 pilotos rastreados e 20 agentes livres. Para o mundo histórico de 40 equipes, os números continuam sendo 80/100/20.
- A evolução de temporada valida a quantidade de pilotos ativos em função das equipes cadastradas e usa a posição final do grid como fallback, em vez de fixar 80.
- Histórico de versões, IDs existentes, formato dos saves e referências aos assets externos foram preservados.
- Limitação: a adaptação do restante dos fluxos de temporada e a validação ponta a ponta com equipe personalizada ainda não estão concluídas.

## Versão atual — V573

Esta entrega acrescenta auditoria não destrutiva do catálogo personalizado, diagnóstico de JSON/IDs/nomes/referências inconsistentes e bloqueio de gravações quando a origem contém dados inválidos. Também valida os nomes de arquivos de escudos ao editar equipes. Consulte `CHANGELOG_V573.md` e `AUDIT_V573.md`.

## Versão atual — V574

Esta entrega integra os diagnósticos da V573 à tela de cadastros, com modo de proteção visível, exportação manual de dados brutos/diagnóstico e revalidação sem gravação. A auditoria adiciona verificações de atributos e nomes de arquivos de assets. Os dados inconsistentes não são corrigidos nem descartados automaticamente. Consulte `CHANGELOG_V574.md` e `AUDIT_V574.md`.


## V575 — Recuperação controlada do catálogo

- Prévia explícita de recuperação de pilotos, equipes e bandeiras inconsistentes.
- Backup integral dos valores brutos antes de qualquer substituição e revalidação pelo carregador de produção.
- Consulte `CHANGELOG_V575.md` e `AUDIT_V575.md`.


## Versão atual — V576

Grande atualização integrada de consistência de carreira: a reconciliação do mercado agora respeita os vínculos de pilotos com equipes personalizadas antes de preencher vagas genéricas, preserva contratos/transferências existentes e mantém a operação idempotente. A grade continua derivada do catálogo ativo e foi removida uma mensagem de validação duplicada. O roteamento de áudio foi conectado a paradas nos boxes, eventos dos pilotos, Safety Car/VSC e bandeira vermelha, mantendo fallback para os nomes legados. Foram adicionados testes de integração do catálogo, mercado, grade, calendário de 30 GPs e seis instalações, além de auditor estático do áudio. Consulte `CHANGELOG_V576.md` e `AUDIT_V576.md`.


## Versão atual — V577

Correção integrada do caminho de simulação instantânea: a conclusão agora usa o roster capturado pelo motor, valida a identidade exata dos pilotos e mantém os cortes proporcionais da qualificação em grids personalizados. Testes de integração para grids de 4 e 6 pilotos foram adicionados; os contratos de auditoria de temporada e os auditores vivos foram alinhados ao catálogo dinâmico. A compilação Android/JUnit completa ainda depende de ambiente com Gradle/Android SDK. Consulte `CHANGELOG_V577.md` e `AUDIT_V577.md`.


## Versão atual — V578

Correção integrada de identidade/roster e dos bloqueios reais de compilação no ciclo de construção do carro da próxima temporada. A compilação Kotlin isolada dos módulos reais de domínio passou; a simulação headless de 60 GPs passou com 41 equipes, 82 pilotos ativos e dois pilotos personalizados legados; testes isolados de catálogo, mercado e garagem passaram. A simulação headless reproduzível está em `tools/race_sim_test/run_two_season_headless_audit.sh`. A compilação Android integral, JUnit oficial e teste em dispositivo permanecem pendentes de ambiente Android/Gradle. Consulte `CHANGELOG_V578.md` e `AUDIT_V578.md`.


## Versão atual — V579

Integração dinâmica de ponta a ponta para o catálogo ampliado: alvos de patrocinadores e evolução acompanham o tamanho real do grid, o motor de mercado reconhece novos pilotos mesmo quando já estava instanciado, e os contadores das telas são derivados dos dados reais. Inclui teste funcional reproduzível de equipe/pilotos adicionados em runtime. O build Android integral e a suíte JUnit oficial ainda exigem ambiente Android/Gradle. Consulte `CHANGELOG_V579.md` e `AUDIT_V579.md`.


## Versão atual — V580

Fechamento integrado do motor de catálogo dinâmico: a classificação econômica de investimento técnico, P&D e fabricação acompanha o tamanho atual do grid; a evolução de pilotos usa o tamanho real da competição. O teste funcional verificou cadastro, reconciliação de mercado, grid de 82 pilotos, construtores, premiações, patrocínios e economia. A simulação headless concluiu 60 GPs de duas temporadas com 41 equipes e 82 pilotos ativos. A compilação Android integral, JUnit oficial e testes em dispositivo ainda exigem ambiente Android/Gradle. Consulte `CHANGELOG_V580.md` e `AUDIT_V580.md`.


## V581 — Evolução de pilotos livres

Pilotos livres também evoluem fora do grid; ganhos de atributos são agora visíveis na Central de Notícias mesmo quando o Overall arredondado não muda. Veja `CHANGELOG_V581.md` e `AUDIT_V581.md`.


## V582 — Integração de catálogo e eventos anuais

A V582 atualiza a sincronização do catálogo vivo nos limites de mercado, grid, GP e virada de temporada. Eventos anuais de pilotos consideram o catálogo completo, incluindo agentes livres, com deduplicação determinística. Consulte `AUDIT_V582.md` para escopo e limitações de validação.


## Versão atual — V583
Pacote limpo com uma única árvore oficial do projeto. A cópia antiga `v552_work` foi excluída do pacote após comprovar que seus 1.140 arquivos tinham correspondentes na raiz; a raiz contém as versões atuais nos caminhos divergentes. Histórico e assets preservados. Esta limpeza não certifica a compilação Android nem testes em dispositivo. Consulte `AUDIT_V583.md`.

## V588
- `versionCode`: 598
- `versionName`: 0.588.0
- Etapa 1 parcial: base dinâmica de cadastros personalizados, seleção de pilotos livres, edição de atributos/asset e tela dividida em seções. Ver `CHANGELOG_V588.md` para limitações e validação pendente.

## V588 — Edição da base
A tela de cadastros permite editar os 40 registros oficiais de equipe e os pilotos oficiais mantendo os IDs históricos. As alterações ficam em overrides locais persistentes e são aplicadas ao ler o WorldDatabase. A compilação Android deve ser confirmada pelo workflow do GitHub Actions.


## V589 — Integração dinâmica do motor
A reconciliação do mercado remove pilotos vinculados ao grid do conjunto de agentes livres antes do preenchimento de vagas. Os contratos anteriores permanecem preservados. Ver `CHANGELOG_V589.md` para escopo e limitações de validação.


## V590 — Integração dinâmica consolidada
A reconciliação do mercado usa o roster declarado como fonte de atribuição para novos pilotos vinculados e impede que esses IDs retornem ao mercado de agentes livres. Consulte `CHANGELOG_V590.md` e `AUDIT_V590.md`.


## V592 — Menu principal responsivo

Redesenho do menu inicial com cards padronizados, tipografia adaptável, uso completo da linha e rolagem vertical desativada. Detalhes em `CHANGELOG_V592.md` e `AUDIT_V592.md`.

### V593 — Menu principal

A tela inicial real foi mapeada em `AUDIT_V593.md`. O redesenho mantém os callbacks existentes, padroniza os cards, aproxima o formato da referência e desativa a rolagem vertical no menu principal.

## V594 — Integração de rankings com catálogo dinâmico
- Corrigidos fallbacks de ranking que consultavam somente `WorldDatabase.drivers`, deixando pilotos adicionados fora da lista quando não havia mercado salvo.
- Ranking de pilotos agora cruza `allDrivers` com IDs de equipes conhecidas.
- Incluído `AUDIT_V594.md` com mapa da cadeia de execução e limites de validação.
- Não foi possível executar compilação Android/JUnit ou simulação em dispositivo neste ambiente.

## V595 — Persistência e backup dos cadastros
- Exportar/importar catálogo completo em JSON para recuperação após reinstalação.
- Validar a importação antes de substituir os dados e manter cópia local dos valores anteriores.
- Formulários de inclusão sempre vazios; país selecionável; asset de pilotos oficiais preenchido por padrão.


### V596
Menu principal mais compacto, logotipo elevado e baseline inicial dos componentes dos carros em V0.


## Atualização atual — V598
- `versionCode`: 598
- `versionName`: 0.598.0
- Corrige atribuição de pilotos do mercado e transferências de equipe; padroniza botões da tela de cadastros.


## V600 — Correção do V0 dos carros
O salvamento agora preserva V0 e normaliza saves antigos somente para peças de baseline `INIT-*`/`SEASON-*`. Ver `AUDIT_V600.md`.

## V601 — Grid expandido e desempenho
O catálogo editável passa a ser a fonte de verdade para a propriedade das vagas no grid; contratos obsoletos de pilotos sem vínculo no roster são liberados, e pilotos declarados no roster são vinculados à equipe correta. A preparação da corrida reutiliza a garagem de IA calculada na atualização semanal para evitar repetir o pipeline de desenvolvimento. Consulte `AUDIT_V601.md` para limites de validação.


Versão de código atual: V602 (0.602.0). Consulte `AUDIT_V602.md` para a limitação de validação do crash pós-reinicialização.

## V604 — recuperação do catálogo dinâmico
A V604 evita que conflitos legados de roster encerrem a inicialização do mercado, escolhe um único proprietário por piloto para contratos iniciais e remove pilotos vinculados do conjunto de agentes livres. A reconciliação persistente do catálogo deve ser confirmada em build e teste Android.

### V605 — catálogo dinâmico resiliente
Rosters são a fonte de verdade para vínculos; conflitos legados são reconciliados deterministicamente pelo mercado em vez de derrubar a inicialização. Ver `AUDIT_V605.md`.

## V606
Correção de transferência de pilotos: a edição de equipe atualiza o elenco de origem e o destino numa única transação persistida, com reconciliação de vínculos duplicados antigos e rollback em falha de gravação. Consulte `AUDIT_V606.md`.

### V607 — ANR no avanço semanal
A simulação histórica de P&D da IA foi retirada do loop de cada semana e consolidada na semana-alvo. Ticks financeiros e comerciais continuam sendo processados semanalmente. Veja `AUDIT_V607.md` para causa, arquivos centrais analisados e limites de validação.

### V608 — grid inicial dinâmico
O mercado inicial completa vagas de equipes cadastradas usando pilotos não atribuídos, com propriedade única por piloto e sem limitar o grid aos 40 times oficiais. Ver `AUDIT_V608.md`. A compilação Android e a suíte JUnit ainda precisam ser executadas no CI.
