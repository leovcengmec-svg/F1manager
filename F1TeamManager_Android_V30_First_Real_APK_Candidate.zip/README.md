# F1 Team Manager — V34 Refinamento

Projeto Android nativo do F1 Team Manager.

## Build

O repositório usa GitHub Actions em `.github/workflows/main.yml` para instalar JDK/Gradle/Android SDK e executar `assembleDebug`.

APK esperado: `app/build/outputs/apk/debug/app-debug.apk`.

## V34 — refinamento após teste real

- 40 equipes e 80 pilotos titulares permanecem como grid oficial.
- Mercado passa a trabalhar com 100 pilotos: 80 titulares + 20 pilotos de mercado/reserva.
- Corrida avança automaticamente por volta e pausa somente quando existe decisão do manager.
- Classificação ao vivo completa dos 80 pilotos.
- Soft/Medium/Hard têm desempenho e degradação diferentes.
- Combustível tem consumo por postura e decisão explícita de poupar combustível.
- Condição crítica ignorada pode causar perda de desempenho e DNF.
- DRS e ERS são executados automaticamente pelo piloto e aparecem apenas como telemetria para o manager.
- Resultado mostra os pontos conquistados pela equipe e o campeonato continua gravado no armazenamento da carreira.
- Home identifica corrida em andamento e oferece `RETOMAR PIT WALL`.
- Central de Gestão reúne as funções que antes ficavam espalhadas/escondidas.
- Ações principais usam vermelho com texto branco.

## Validação

O núcleo Kotlin foi compilado localmente e os testes V21, V22 e V34 passaram. A compilação física do APK continua sendo feita pelo GitHub Actions, porque este ambiente não possui o Android SDK/Gradle completo do projeto.


## V35
- 30 GPs / 56 semanas.
- Q1/Q2/Q3 para 80 pilotos.
- Seis componentes de carro e P&D por semanas.
- Histórico de classificação por GP.
- ERS automático com recuperação e DRS automático condicionado a 1 segundo.

## Assets externos persistentes

O jogo pode ler imagens fora do APK para que elas permaneçam no aparelho após desinstalar/reinstalar o aplicativo.

Coloque os arquivos em:

`Armazenamento interno/Pictures/F1Manager/Assets/`

Estrutura:

- `teams/` — escudos das 40 equipes
- `drivers/` — fotos dos pilotos
- `countries/` — bandeiras dos países

Para equipes, são aceitos nomes como `01.png`, `team_01.png` ou o nome normalizado da equipe (`ferrari.png`, `mclaren.png`, etc.).

Na primeira instalação/reinstalação, o Android solicitará acesso às imagens. Conceda a permissão para o jogo localizar os Assets externos.

## V36 — unificação definitiva da cadeia de temporada
- GP30 usa a mesma `SeasonSettlementEngine` no fluxo Android e na simulação headless.
- As 40 equipes são liquidadas, inclusive equipes com 0 pontos.
- Ledger persistente de premiação por equipe/temporada impede duplicação após reabertura.
- Saldos de premiação das equipes IA são persistidos no armazenamento da carreira.
- A versão Android passa a `0.36.0` / `versionCode 36`.
- Auditoria de 60 GPs continua PASS: 2 temporadas completas + GP1 da terceira.
