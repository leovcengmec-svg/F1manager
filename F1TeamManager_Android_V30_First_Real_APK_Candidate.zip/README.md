F1 TEAM MANAGER — V66

V66 — Sistema oficial de 7 instalações (níveis 0–10), integrado à cadeia P&D → Fábrica → Peça Física → Carro.

Instalações:
1. Fábrica
2. Centro de P&D
3. Túnel de Vento
4. Simulador
5. Scouting
6. Desenvolvimento de Pilotos
7. Centro Comercial / Marketing

Custos de upgrade: €10M a €120M por nível, níveis 0–10.

# F1 Team Manager — V50 Correção de Build e Consolidação

Projeto Android nativo do F1 Team Manager.

## Build

O repositório usa GitHub Actions em `.github/workflows/main.yml` para instalar JDK/Gradle/Android SDK e executar `assembleDebug`.

APK esperado: `app/build/outputs/apk/debug/app-debug.apk`.

## V50 — correção de build e consolidação estrutural

- 40 equipes e 80 pilotos titulares permanecem como grid oficial.
- Mercado passa a trabalhar com 100 pilotos: 80 titulares + 20 pilotos de mercado/reserva.
- Corrida avança automaticamente por volta e pausa somente quando existe decisão do manager.
- Classificação ao vivo completa dos 80 pilotos.
- Soft/Medium/Hard têm desempenho e degradação diferentes.
- Combustível tem consumo por postura e decisão explícita de poupar combustível.
- Condição crítica ignorada pode causar perda de desempenho e DNF.
- DRS e ERS são executados automaticamente pelo piloto e aparecem apenas como telemetria para o manager.
- Resultado mostra os pontos conquistados pela equipe e o campeonato continua gravado no armazenamento da carreira.
- Home identifica corrida em andamento e oferece `RETOMAR PIT WALL`.
- Central de Gestão reúne as funções que antes ficavam espalhadas/escondidas.
- Ações principais usam vermelho com texto branco.

## Validação

O núcleo Kotlin foi compilado localmente e os testes V21, V22 e V34 passaram. A compilação física do APK continua sendo feita pelo GitHub Actions, porque este ambiente não possui o Android SDK/Gradle completo do projeto.


## V35
- 30 GPs / 56 semanas.
- Q1/Q2/Q3 para 80 pilotos.
- Seis componentes de carro e P&D por semanas.
- Histórico de classificação por GP.
- ERS automático com recuperação e DRS automático condicionado a 1 segundo.

## Assets externos persistentes

O jogo pode ler imagens fora do APK para que elas permaneçam no aparelho após desinstalar/reinstalar o aplicativo.

Coloque os arquivos em:

`Armazenamento interno/Pictures/F1Manager/Assets/`

Estrutura:

- `teams/` — escudos das 40 equipes
- `drivers/` — fotos dos pilotos
- `countries/` — bandeiras dos países

Para equipes, são aceitos nomes como `01.png`, `team_01.png` ou o nome normalizado da equipe (`ferrari.png`, `mclaren.png`, etc.).

Na primeira instalação/reinstalação, o Android solicitará acesso às imagens. Conceda a permissão para o jogo localizar os Assets externos.

## V36 — unificação definitiva da cadeia de temporada
- GP30 usa a mesma `SeasonSettlementEngine` no fluxo Android e na simulação headless.
- As 40 equipes são liquidadas, inclusive equipes com 0 pontos.
- Ledger persistente de premiação por equipe/temporada impede duplicação após reabertura.
- Saldos de premiação das equipes IA são persistidos no armazenamento da carreira.
- A versão Android passa a `0.36.0` / `versionCode 36`.
- Auditoria de 60 GPs continua PASS: 2 temporadas completas + GP1 da terceira.


## V51 — Central de Notícias / Evolução de Pilotos
- Corrigida a atualização do estado em memória após cada GP.
- A Central de Notícias agora registra evolução por alteração real de atributo, sem depender da mudança do Overall inteiro.
- Adicionada auditoria retroativa para carreiras antigas, permitindo verificar evolução já ocorrida antes da V51.
- `versionCode 51` / `versionName 0.51.0`.


## V52 — Central de Notícias: layout unificado

- Base oficial: V51, incluindo a correção funcional da evolução de pilotos.
- Layout unificado para Mercado, Evolução de Pilotos, Evolução de Equipes e Eventos Anuais.
- Cards com hierarquia visual consistente, antes → depois e indicadores de variação.
- Evolução de equipes usa exclusivamente os 6 componentes oficiais do jogo e ícones vetoriais internos.
- Escudos/fotos locais continuam sendo usados quando disponíveis.
- Android versionCode 52 / versionName 0.52.0.

## V53 — Driver targets by team strength ranking
- Seasonal driver targets now derive from the opening-season ranking of team strength.
- Driver Overall is no longer used to establish the target.
- The previous 60/40 target formula and legacy baseCar-to-position target path were removed.
- Both career target initialization and in-season manager evolution use the same target rule.


## V54 — Mercado de pilotos: negociação em ciclos de 2–3 semanas
- Propostas deixaram de receber resposta imediata. O piloto responde após 2 ou 3 semanas de calendário.
- A resposta do piloto pode ser aceite, recusada ou contraproposta.
- Contrapropostas voltam para a equipe proponente, que pode aceitar, recusar ou fazer nova contraproposta.
- A negociação possui no máximo 3 respostas do piloto/ciclos; na contraproposta final a equipe apenas aceita ou recusa.
- Uma negociação ativa por piloto impede duplicação de propostas e reduz a acumulação artificial de mensagens.
- Cada resposta gera card/notícia na Central de Notícias, incluindo aceite, recusa e contraproposta.
- A Home passa a destacar respostas de mercado não lidas.
- A conclusão de um projeto de P&D gera notificação própria na Home/Central de Notícias.
- Taxa de assinatura de uma contratação feita pelo jogador é cobrada somente quando o piloto efetivamente aceita, e não no envio da proposta.
- Persistência de propostas foi estendida para guardar a equipe proponente, mantendo compatibilidade com dados antigos.
- Android versionCode 55 / versionName 0.55.0.


### V55 — Correção do mercado de pilotos
- Permite propostas simultâneas de várias equipes para o mesmo piloto.
- Mantém cada negociação independente.
- Ao fechar uma contratação, as demais negociações do piloto são encerradas.


### V56 — Calendário visual
- Calendário Android redesenhado para reproduzir o layout aprovado: hierarquia de temporada, meta-resumo, card de semana atual, semanas livres compactas e cards de GP com proporções consistentes.
- Mantida a cadeia funcional existente de calendário, P&D, resultados e navegação.
- Android `versionCode 56` / `versionName 0.56.0`.


### V57 — Base de países para bandeiras
- Adicionado `country` na raiz de `TeamDefinition` e `DriverDefinition`.
- Cadastrados os países das 40 equipes e dos 100 pilotos.
- A informação fica preparada para o futuro sistema de bandeiras, sem criar/exibir um sistema de nacionalidade.
- Nenhuma lógica de mercado, corrida, evolução ou calendário foi alterada.
- Android `versionCode 57` / `versionName 0.57.0`.


# V59 — Garantia dos valores iniciais das 40 equipes

A V58 passa a usar a classificação inicial oficial definida para as 40 equipes em uma nova carreira.

- Forte: carro inicial entre 56 e 60; instalações iniciais nível 2.
- Médio: carro inicial entre 48 e 55; instalações iniciais nível 1.
- Fraco: carro inicial entre 40 e 47; instalações iniciais nível 0, sem instalações.
- Os seis componentes oficiais recebem valores individuais dentro da faixa da equipe; o Overall inicial é a média desses seis componentes.
- A confiabilidade inicial é derivada da média dos seis componentes e não cria um sétimo componente de desempenho.
- As quatro instalações existentes no modelo recebem o mesmo nível inicial 0/1/2 nesta etapa. A evolução detalhada das instalações será tratada na próxima atualização.
- A classificação definida para as 40 equipes foi incorporada à base oficial.
- V58 mantém o nome oficial do ZIP e parte diretamente da V57.


## V59 — Auditoria de início de carreira
- O início da carreira usa um único perfil canônico para jogador e IA.
- Metas e cálculo de força inicial deixaram de usar a estrutura antiga de 8 componentes.
- O carro inicial é sempre derivado dos 6 componentes oficiais.
- `versionCode 59` / `versionName 0.59.0`.

## V60 — Novo modelo de garagem e dois carros
- Primeira etapa da reconstrução estrutural do carro/P&D/Fábrica.
- Cada equipe passa a possuir `Carro 1` e `Carro 2` físicos independentes.
- Cada carro possui os 6 componentes oficiais e Overall próprio pela média dos 6.
- Foi criado o modelo de peça física (`CarPiece`) para que uma futura fabricação possa ser direcionada a um carro específico.
- O modelo de garagem possui inventário de peças e instalação por carro.
- O modelo antigo permanece temporariamente como ponte de compatibilidade enquanto o novo P&D e a nova Fábrica são reconstruídos.
- `versionCode 60` / `versionName 0.60.0`.


## V61 — Novo conceito de P&D: projeto não altera o carro
- Mantida a V60 como base oficial.
- O P&D passa a criar `ResearchProject` e, ao concluir, `ResearchDesign`; nenhum projeto altera diretamente Carro 1 ou Carro 2.
- Os desenhos concluídos ficam aguardando a futura etapa de fabricação na Fábrica.
- Carro 1 e Carro 2 começam idênticos; a diferença de desempenho será criada pelas peças físicas instaladas individualmente.
- Persistência adicionada para projetos, desenhos, estoque e peças instaladas.
- A tela CARRO/P&D passa a mostrar os dois carros, Overalls individuais e projetos tecnológicos.
- O modelo antigo de P&D permanece somente como ponte de compatibilidade para os demais fluxos enquanto a Fábrica e o motor de corrida são migrados.
- `versionCode 61` / `versionName 0.61.0`.

## V62 — Fábrica: conversão de desenhos em peças físicas
- Base oficial: V61.
- Adicionada a cadeia física `P&D → desenho tecnológico → Fábrica → peça física → estoque → Carro 1/Carro 2`.
- Criado `TeamFactoryState` com ordens de fabricação persistentes.
- Uma fabricação nunca instala automaticamente a peça em nenhum carro.
- Ao concluir, as unidades entram no estoque físico da equipe.
- O jogador pode produzir unidades de um mesmo desenho e posteriormente decidir em qual carro instalar cada unidade.
- Carro 1 e Carro 2 continuam com Overalls independentes calculados exclusivamente pelos seis componentes oficiais.
- O P&D não altera diretamente nenhum carro.
- O sistema antigo permanece apenas como ponte de compatibilidade durante a migração.
- `versionCode 62` / `versionName 0.62.0`.


- V63: peças físicas agora podem ser instaladas explicitamente no Carro 1 ou Carro 2; a corrida do jogador passa a usar os dois carros físicos. Android versionCode 63 / versionName 0.63.0.

- V65: equipes AI passam a ter dois carros físicos independentes na corrida, com mapeamento determinístico piloto 1 → Carro 1 e piloto 2 → Carro 2. O modelo mantém os seis componentes oficiais e reliability por carro. Android versionCode 64 / versionName 0.65.0.


## V67 — Fábrica detalhada
A Fábrica agora possui progressão explícita de nível 0–10, ordens simultâneas, limite de peças por ordem, tempo, custo e capacidade de estoque.

## V68 — Centro de P&D detalhado
- Centro de P&D agora controla custo, duração e qualidade tecnológica dos projetos conforme o nível 0–10.
- O projeto continua sem alterar qualquer carro físico diretamente.
- O desenho só fica disponível para fabricação após a conclusão.
- Corrigida a numeração inicial de projetos: o primeiro desenho de cada componente é V1.
- O custo efetivamente debitado passa a ser o custo após o modificador do Centro de P&D.
- A duração efetiva também é calculada pelo nível da instalação.
- O ganho tecnológico adicional é aplicado somente ao desenho futuro.

## V68 — Centro de P&D completo

Implementado após definição e aprovação integral do sistema de P&D.

- 6 componentes oficiais.
- 3 focos: Performance, Confiabilidade e Balanceada.
- 4 complexidades: Simples, Média, Avançada e Experimental.
- Custos-base: €5M / €10M / €18M / €28M.
- Tempos-base: 2 / 4 / 6 / 8 semanas.
- Redução de tempo por nível P&D: 100%, 97%, 94%, 91%, 88%, 85%, 82%, 79%, 76%, 72%, 68%, com arredondamento para semanas inteiras e mínimo de 1 semana.
- Faixas de melhoria por nível: 0; +1–2; +1–3; +2–4; +2–5; +3–6; +4–7; +5–8; +6–9; +7–10; +8–12.
- Capacidade simultânea: níveis 0–3 = 1, 4–7 = 2, 8–10 = 3.
- Foco distribui o ganho em 70/30, 30/70 ou 50/50.
- Resultado persistido no projeto: sucesso, parcial (50%) ou falha (0%).
- Falha não cria design e permite nova tentativa imediata.
- Sucesso/parcial criam novo Design Tecnológico e aplicam cooldown de 4 semanas naquele componente.
- Versões seguem V1 → V2 → V3..., sem regressão e com teto 100.
- P&D nunca altera diretamente o carro.
- Designs permanecem disponíveis no histórico e podem gerar múltiplas peças na Fábrica.
- Carros iniciais possuem seis peças físicas e confiabilidade individual por componente, dentro das faixas oficiais Forte 75–85, Médio 65–78 e Fraco 55–70.
- Persistência ampliada para múltiplas pesquisas, cooldowns, foco/complexidade/resultado e confiabilidade individual das peças.
- Interface de CARRO/P&D atualizada para o fluxo Pesquisa → Design → Fábrica → Peça → Carro 1/2.
