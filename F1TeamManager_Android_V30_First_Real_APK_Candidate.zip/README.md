# Atualização V736 — Mercado de Pilotos 2.0 e Ciclo de Carreira 16–45

A V736 consolida a revisão de interface e inteligência do mercado de pilotos, preserva o estado da navegação ao consultar fichas, remove notícias de contratação duplicadas na lista do mercado e apresenta assinaturas com foto, equipes de origem/destino, temporada de início e duração contratual.

O ciclo de carreira passa a operar de 16 a 45 anos. O piloto conclui a temporada aos 45, não pode assinar ou renovar contratos para a temporada seguinte e reinicia aos 16. Jogador e IA usam a mesma validação central de duração contratual, incluindo a limitação de contratos antigos na virada.

O gerenciador de saves mantém a importação de backups e a exportação completa da carreira ativa ou do save histórico explicitamente selecionado, com botões padronizados.

Consulte `CHANGELOG_V736.md`, `AUDIT_V736.md` e `AUDIT_V736_BUILD_FIX.md` para o escopo, as verificações e a correção do erro de compilação reportado no primeiro Build Debug APK. A V735 permanece documentada em `CHANGELOG_V735.md` e `AUDIT_V735.md`.


## V737
V737 — Inteligência Financeira, Instalações Dinâmicas e Interface 2.1. Ver `CHANGELOG_V737.md` e `AUDIT_V737.md`.


## V738
Correções de ordenação e compactação do Mercado de Pilotos, limites de novos patrocínios e recalibração da margem extra de evolução. Consulte `CHANGELOG_V738.md` e `AUDIT_V738.md`.
