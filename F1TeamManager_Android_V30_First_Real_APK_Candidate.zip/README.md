# Atualização V731 — evolução e progressão de classe dos pilotos

A V731 aplica as regras finais de faixa adicional de Overall (+5 para Médio, Forte e Pro), exigência de desempenho por classe, revisão bienal de promoção/regressão e rebaixamento por temporadas completas sem equipe. Preserva a progressão por sete atributos, potencial individual, metas baseadas apenas na força do carro, idade, patrocinadores e Central de Notícias da V730.

Consulte `CHANGELOG_V731.md` e `AUDIT_V731_STABILIZATION.md`.
