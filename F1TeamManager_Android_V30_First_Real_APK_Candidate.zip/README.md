## V688 — correção de compilação e integração das notificações da Home

- Corrigido o campo `relatedTeamId` ausente no modelo `MarketNotification`, incluindo persistência compatível com saves antigos.
- A Home e o contador usam a mesma política: etapas detalhadas de negociação são exclusivas da equipe do jogador.
- Propostas recebidas, recusas, contrapropostas, expirações e cancelamentos ligados à equipe do jogador carregam seu ID explicitamente.
- Contratos assinados, renovações e transferências concluídas de equipes da IA continuam aparecendo como notícias globais.
- Eventos de P&D da equipe do jogador são identificados pelo mesmo vínculo de equipe.
- O botão do card de negociação direciona ao Mercado de Pilotos.
- A regra de mercado multitemporada da v687 foi preservada; simulação isolada em três sementes verificou trocas recorrentes após a temporada inicial.

## Regras comerciais da v685 preservadas

- Níveis 0, 1 e 2: contratos de 3–10 GPs.
- Níveis 3 a 10: contratos de 8–16 GPs.
- Contratos existentes não têm sua duração alterada.

## V684 — correção de compilação e reequilíbrio econômico

- Centro Comercial: níveis 0–3 preservados; níveis 4–10 passam a ter crescimento incremental menor nas vendas, multiplicador comercial com retornos decrescentes e manutenção progressiva.
- Patrocínios: novos contratos passam a durar 8–16 GPs; contratos já assinados em saves existentes permanecem inalterados.
- Investimento técnico: P&D, fabricação, instalações e carro da próxima temporada compartilham o limite anual de €200 milhões. A IA pode reaproveitar alocação não utilizada, mantendo reservas operacionais.
- Painel financeiro: “Caixa Atual” substitui o rótulo incorreto “Salário Anual”; investimento no carro seguinte e saldo consolidado são exibidos separadamente.

## Correção V684 — compilação do painel de investimento

- Corrigida a referência fora de escopo a `managerState` na tela Equipe. O investimento no carro seguinte é passado explicitamente ao composable e contabilizado junto do envelope anual.
- Corrigidos os erros Kotlin em cascata na barra de progresso e nas comparações de limite.

## V682 — equilíbrio carro/piloto por condição climática

- Seco e nublado: carro 65% / piloto 35%.
- Chuva fraca e moderada: carro 55% / piloto 45%.
- Chuva forte: carro 50% / piloto 50%.
- A mesma distribuição é aplicada à volta de classificação e ao ritmo-base de corrida.
- O cálculo de penalidade por chuva limita habilidade em pista molhada a 0–100 e consistência a 40–100.

## Versão

- `versionCode`: 688
- `versionName`: 0.688.0

## Compilação

Abra esta pasta no Android Studio e execute a tarefa `assembleDebug`. O projeto usa Kotlin, Jetpack Compose e Gradle Kotlin DSL.

O workflow `.github/workflows/android-apk.yml` executa os testes unitários e `:app:assembleDebug` no GitHub Actions, publicando o APK de depuração como artefato da execução. O pipeline configura Java 17, Android SDK 36 e Gradle 9.5.0, compatível com o Android Gradle Plugin 9.3.0 usado pelo projeto.

## Estrutura mantida

- `app/src/main`: aplicação, recursos visuais e bases locais usadas pelo jogo.
- `app/src/test`: testes de regressão e auditoria do motor.
- `tools`: utilitários de auditoria/teste.
- `docs`: documentação técnica ainda agrupada separadamente.

Assets externos opcionais podem ser colocados em `Pictures/F1Manager/Assets/` no armazenamento do dispositivo, conforme os nomes aceitos pelo registro de assets do aplicativo.

## Limpeza V243

Removidos do ZIP os históricos de alteração antigos soltos na raiz, páginas HTML de apoio não usadas pelo APK, a folha de contato de imagens e a lista `corefiles.txt` que apontava para caminhos absolutos de outra máquina. Código Kotlin, testes, recursos do aplicativo e ferramentas foram preservados nesta etapa; não foram apagadas classes apenas por suspeita de uso.


## Auditoria V245

- Corrigida a versão declarada neste README para corresponder ao build.gradle.kts.
- Revisão estática dos recursos Android: todos os 41 recursos em res/ têm ocorrência textual pelo nome no código/configuração.
- Preservados os 124 arquivos documentais/históricos encontrados no pacote, os testes de regressão e todos os Assets em app/src/main/assets.
- Nenhuma classe Kotlin, imagem, base JSON ou documentação histórica foi excluída nesta etapa. Classes sem referência textual direta permanecem para validação por compilação e análise de carregamento dinâmico.
- Limitação: o ZIP não inclui gradlew/gradle-wrapper.jar; não foi possível executar compilação Gradle local nesta auditoria.


## Auditoria V246 — navegação e acesso aos históricos

- O card de identidade da equipe na Home abre a Central de Equipes.
- O escudo na tela Equipe abre a mesma Central de Equipes.
- Os cards dos pilotos na Central de Equipes abrem o histórico individual do piloto selecionado.
- O botão Voltar do Android agora é tratado pela navegação interna; na Home, solicita confirmação antes de sair, em vez de encerrar o jogo imediatamente.
- O retorno da Central de Equipes preserva a origem (Home ou Equipe), e o retorno do histórico do piloto volta à Central de Equipes.
- Preservados os Assets, as bases, os testes e a documentação histórica existente.
- Limitação desta etapa: compilação Android não executada porque não há Gradle/Gradle Wrapper disponível neste ambiente.


## Correções V247 — avisos e decisões da corrida

- Todos os diálogos ativos da corrida mantêm a simulação pausada; o modo automático é retomado quando todas as pendências forem resolvidas.
- O diálogo de evento exige o botão explícito `CONTINUAR CORRIDA`; toque externo e botão Voltar não o dispensam.
- Removido o botão de fechar que executava `STAY_OUT` implicitamente na decisão do manager.
- Diálogos informativos aguardam a conclusão da decisão do manager e da etapa de box, evitando sobreposição.
- A fila informativa mantém o teto de oito cards por GP; decisões obrigatórias continuam controladas pelo motor, independentemente desse teto.
- Preservados Assets, histórico de versões, testes e demais sistemas.
- Compilação Android não executada: este pacote não inclui Gradle Wrapper e não há Gradle instalado no ambiente de vistoria.


## Correção V499 — previsão visível no diálogo de P&D

- Movido o card GANHO TECNOLÓGICO ESTIMADO para antes da lista de complexidade, para que a previsão apareça logo após a seleção do foco e não fique escondida abaixo das opções e dos botões em telas menores.
- Mantidas as fórmulas existentes do ResearchEngine, seletores de foco/complexidade e ações de iniciar/cancelar pesquisa.
- ZIP validado quanto à integridade; compilação Android não executada neste ambiente.


## V598 — Objetivos dinâmicos do Team Principal
Objetivos de temporada variáveis por força da equipe, prestígio inicial 1 e pontuação limitada a +8 por temporada. Ver `CHANGELOG_V598.md` e `AUDIT_V598_TEAM_PRINCIPAL_OBJECTIVES.md`.



## V604 — Calibração de evolução dos pilotos
- Desempenho por GP compara quali/corrida contra a meta esportiva de equipe sem punir excessivamente uma posição de diferença.
- Crescimento calibrado para cerca de 1,0 na meta esperada; categoria de evolução continua definindo o teto anual por atributo.
- Teste isolado confirma crescimento de Overall até GP6 em desempenho perto da meta.

## V603 — Auditoria e integridade dos pilotos

- O ciclo de carreira é fixo em 5 anos de evolução, 2 de auge e 5 de regressão, persistindo entre temporadas.
- Regressão respeita o Overall mínimo da classe; Lenda mantém teto 100 e mínimo 60.
- A virada de temporada preserva fase, contador do ciclo e progresso fracionário, reiniciando apenas os limites anuais e os registros de idempotência da temporada anterior.
- `currentDrivers()` monta o catálogo com uma única leitura dos mapas de atributos e classe, evitando a leitura/mesclagem do conjunto inteiro uma vez por piloto.
- A correção nominal específica do Felipe foi removida: cada nova carreira reinicializa os 100 pilotos pelos perfis canônicos da versão atual, conforme a regra de início do zero.

## Regra de validação de atualizações (V602)
Toda atualização funcional deve ser validada a partir de uma nova carreira iniciada por **Novo Jogo**, sem continuar um save de versão anterior. Os recursos de salvar/exportar/importar permanecem disponíveis; saves antigos não devem ser apagados automaticamente. Consulte `REGRA_NOVA_CARREIRA_A_CADA_ATUALIZACAO.md`.


## Correção V675 — avaliação da diretoria

- Atingir o objetivo principal de classificação e cumprir pelo menos 60% das metas limita o risco de demissão a 5%, mesmo quando indicadores secundários isolados estejam ruins.
- Atingir o objetivo principal e cumprir pelo menos 40% das metas limita o risco a 12%.
- Mesmo sem atingir o objetivo principal, cumprir pelo menos 80% das metas limita o risco a 25%.
- Demissões continuam possíveis em temporadas de desempenho global insuficiente; o ajuste impede que penalidades secundárias acumuladas anulem uma temporada esportivamente bem-sucedida.
