# Atualização V728 — notícias de Overall

A V728 restaura o feed de evolução dos pilotos para publicar apenas alterações reais de Overall e mantém o campo `Motivo:` completo. Notícias antigas de alterações isoladas de atributos são ocultadas; os sete atributos continuam sendo processados e persistidos normalmente. Promoções/rebaixamentos de classe e eventos de programas permanecem na aba separada **Eventos de Pilotos**. Consulte `CHANGELOG_V728.md`.

## V727 — correção de compilação do ledger etário

**VersionCode:** 727  
**VersionName:** 0.727.0  
**Base desta revisão:** V726 / 0.726.0  
**Nome público preservado:** F1 Team Manager V30

- Corrigido o erro Kotlin na conversão do registro de fases etárias; leitura, gravação e virada usam `DriverEvolutionPhaseCodec` com mapa tipado.
- Preservado o formato de save existente `id:fase;id:fase`.
- Incluído teste de regressão para leitura, ordenação e round-trip.
- As metas seguem exclusivamente a força do carro; nenhuma regra esportiva da V726 foi alterada.

Consulte `CHANGELOG_V727.md` e `AUDIT_V727_STABILIZATION.md` para o diagnóstico e os limites de validação.

## V726 — Metas esportivas baseadas exclusivamente na força do carro

**VersionCode:** 726  
**VersionName:** 0.726.0  
**Base desta revisão:** V725 / 0.725.0  
**Nome público preservado:** F1 Team Manager V30

- Metas de classificação e corrida calculadas somente pelo ranking de força dos carros das 40 equipes.
- Os dois pilotos de cada equipe recebem a mesma meta-base; Overall, atributos, classe e potencial do piloto não alteram a expectativa.
- Metas antigas da V725 são recalibradas para a nova regra na abertura da carreira, antes da próxima avaliação esportiva.
- A geração prematura na virada foi removida: em nova temporada, as metas são criadas depois da construção e aplicação do regulamento ao carro novo.
- Ficha individual exibe as metas centrais e as faixas de tolerância de classificação e corrida.
- A avaliação de evolução/regressão mantém os resultados reais de cada piloto contra a expectativa do carro.

Consulte `CHANGELOG_V726.md` e `AUDIT_V726.md` para o detalhamento da regra e os limites de validação.

## V725 — Evolução de pilotos, construção de carros e inteligência financeira

**VersionCode:** 725  
**VersionName:** 0.725.0  
**Base desta revisão:** V724 / 0.724.0  
**Nome público preservado:** F1 Team Manager V30

- Limite anual de perda de Overall unificado no construtor do próximo carro e em suas projeções.
- Confiabilidade preservada por peça instalada e desenvolvida pelo fluxo próprio de pesquisa/fabricação.
- Ciclo dos pilotos estendido até 45 anos, reinício na temporada seguinte com corte de 30% por atributo e piso 40.
- Regressão etária independente dos ganhos esportivos, com notícias separadas.
- IA financeira passa a antecipar reconstrução de equipes fracas solventes, registrar o motivo de cada decisão e respeitar envelopes de €150M/€200M.
- Histórico real de Overall e sete atributos persistido por piloto; gráfico com ciclos separados e sem inventar temporadas anteriores.
- Backups passam a transportar o histórico V725 e aplicar migração compatível para saves V724.
- Validação disponível na V725: núcleo Kotlin K2 compilado, 46 testes direcionados aprovados e smoke test aprovado. Build Android, APK e simulações de 5–20 temporadas ainda dependem do ambiente Android/GitHub Actions.

Consulte `CHANGELOG_V725.md` e `AUDIT_V725.md` para o detalhamento e os limites de validação.
---

## V724 — Ranking determinístico e correção de projeções

**VersionCode:** 724  
**VersionName:** 0.724.0  
**Base desta revisão:** V723 / 0.723.0  
**Nome público preservado:** F1 Team Manager V30

- Simulações e projeções de leitura não publicam mais Overalls no registro global por padrão; somente o processamento semanal canônico publica o resultado.
- `developmentCapacity` aceita snapshots explícitos e imutáveis de ranking e Overall, evitando que uma equipe processada altere a estratégia financeira das equipes seguintes no mesmo lote.
- O avanço semanal captura ranking e Overalls antes do lote e reutiliza essas referências em todas as equipes.
- Visão das Equipes e Ranking usam snapshots congelados ao calcular capacidade e simular garagens.
- O Ranking do Próximo Carro calcula a força oficial somente com o investimento efetivamente comprometido. A projeção de investimento futuro permanece separada e informativa.
- O botão Continuar Jogo permanece habilitado mesmo sem carreira carregada e encaminha para gerenciamento/importação de saves.
- Mantidos os limites anuais, a tabela Overall × investimento, os eventos regulatórios e a persistência histórica.
- Auditoria estática não equivale a compilação Android ou benchmark de dispositivo; essas validações precisam ser executadas no ambiente Android/GitHub Actions.

## V718 — Estabilização e escalabilidade de longo prazo

**VersionCode:** 718  
**VersionName:** 0.718.0  
**Base desta revisão:** V717 / 0.717.0  
**Nome público preservado:** F1 Team Manager V30

- Desenvolvimento da IA usa checkpoints de abertura de temporada com fingerprint de carreira, equipe, seed, regulamento, ranking técnico, investimentos e penalidades.
- O modo Team Principal também avança a partir de checkpoints do handoff, evitando reconstruir repetidamente todas as temporadas posteriores à troca de dirigente.
- Visão das Equipes e Ranking compartilham os mesmos snapshots de garagem e chaves de invalidação, incluindo eventos anuais e estado financeiro.
- Processamentos em lote congelam o ranking técnico antes de percorrer as equipes, mantendo resultados independentes da ordem de processamento.
- Histórico: reparo lazy, última corrida lida do shard mais recente, cache legado limitado e snapshots carregados fora da thread visual.
- Ledgers financeiros grandes da IA usam compressão GZIP retrocompatível; nenhuma transação histórica foi removida.
- A auditoria estrutural não substitui benchmarks Android: testes reais de 10, 15 e 20 temporadas continuam necessários.

## V717 — Ranking das Equipes

**VersionCode:** 717  
**VersionName:** 0.717.0  
**Base desta revisão:** V716 / 0.716.0  
**Nome público preservado:** F1 Team Manager V30

A Central de Gestão agora possui o **Ranking das Equipes**, com as 40 equipes e três classificações independentes do campeonato: força atual, dinheiro em caixa e projeção do próximo carro. O modo próximo carro mostra o Overall projetado e a diferença para a força atual, ordenando pelo Overall projetado em ordem decrescente. Cada equipe abre sua Visão da Equipe. O snapshot é calculado em segundo plano, com uma única simulação de garagem da IA por equipe e cache compartilhado entre os três modos.

## V716 — Fluidez, histórico e Centro Comercial

Esta revisão usa cache histórico compartilhado e índices por equipe para reduzir I/O e trabalho repetido durante a navegação. A preparação pesada da Visão da Equipe é feita fora da thread visual. No Centro Comercial nível 2, há sempre uma proposta Básica e duas propostas independentes com chance de categoria Regional, mantendo estabilidade ao reabrir a mesma situação da carreira.

# F1 Team Manager V30 — V715

**VersionCode:** 715  
**VersionName:** 0.715.0  
**Base desta revisão:** V714 / 0.714.0  
**Nome público preservado:** F1 Team Manager V30

## Revisão atual — V715

## Correção de compilação da Home — V715

- Corrigidos os erros Kotlin `Smart cast to HomeLastRaceSummary is impossible` causados pelo acesso direto à propriedade delegada Compose `lastCompletedRace`.
- O valor delegado agora é capturado uma vez em `completedRace`, uma referência local imutável usada em todas as verificações e leituras do card do último GP.
- O snapshot é atualizado a cada recomposição disparada pelo `mutableStateOf`, preservando a atualização assíncrona do último GP sem alterar seu conteúdo ou regras.

## Home e Central de Navegação — V714

- Situação do Campeonato passa a apresentar a classificação de construtores, os dois pilotos, dados financeiros com rótulos separados e o resultado do último GP com circuito.
- Os dados são derivados das fontes oficiais já usadas pelo Campeonato, Finanças e arquivo histórico.
- O Acesso Rápido foi dividido em Competição, Gestão da Equipe e História e Estatísticas, com 13 atalhos que abrem telas existentes.
- Cards de classificação abrem a aba correta (Pilotos ou Construtores).


- Implementa a Central de Recordes na interface já existente, com Visão Geral, Pilotos, Equipes, Circuitos e Temporadas.
- Cards individuais com recordistas empatados preservados e filtros de todos os tempos/por temporada.
- Reconstrói automaticamente as marcas usando o histórico oficial já armazenado; não cria contadores paralelos nem duplica GPs.
- Reconstrução separa circuitos pela identidade exata da pista, e não apenas pelo nome do GP.
- Temporadas incompletas ficam fora dos recordes anuais definitivos; a conclusão é validada junto com as tabelas e campeões.
- Um snapshot obtido em uma única leitura do histórico reduz acessos repetidos aos arquivos de GPs em carreiras longas.
- Pilotos com recordes acumulados em mais de uma equipe são identificados como “Múltiplas equipes”, sem atribuição arbitrária.

O ZIP continua usando exatamente `F1TeamManager_Android_V30_First_Real_APK_Candidate.zip`. O workflow GitHub publica o APK com o versionCode vigente.

## Revisões anteriores

## Revisão atual — V710

- Correção do save completo: `marketScouting` não é mais um campo obrigatório, pois a instalação foi removida na V708.
- Exportações novas removem a preferência residual de Scouting antes de validar, calcular o manifesto e gerar o checksum.
- Backups antigos que ainda contêm `marketScouting` são validados com o conteúdo/checksum original e, durante a importação, têm apenas essa preferência obsoleta descartada.
- A verificação pós-importação compara o snapshot já normalizado, sem exigir nem restaurar dados de Scouting.

## Revisão anterior — V709

- Envelhecimento natural passa a distribuir regressões pelos sete atributos: VEL, CLA, ULT, DEF, CON, CHU e PNE, respeitando o piso 40.
- Reinício do ciclo de idade recupera 50% do conjunto de perdas por envelhecimento nos mesmos sete atributos, limitado aos picos históricos; o saldo esportivo não é recuperado.
- Pilotos sem equipe continuam evoluindo pela curva natural e podem ultrapassar o teto de classe até o potencial individual, sem evidência esportiva sintética nem regressão esportiva por resultados inexistentes.
- Ao entrar no mercado livre, qualquer saldo fracionário negativo herdado de desempenho enquanto contratado é descartado; saldo positivo é preservado. Pilotos livres perdem atributos apenas pela curva natural de envelhecimento.
- Notícias de evolução detalham os atributos que realmente mudaram e separam desenvolvimento natural, desempenho esportivo, envelhecimento e recuperação do ciclo.
- Investimento no próximo carro é bloqueado quando a meta anual de Overall é alcançada ou financiada; o motor rejeita qualquer aporte excedente e a interface oferece somente o valor exato que ainda falta.
- Mantidos o teto anual financeiro de €150M, a reserva operacional e a tabela de ganho de Overall por faixa. Atualizados testes específicos para os sete atributos, pilotos livres e trava de investimento.

O ZIP continua usando exatamente `F1TeamManager_Android_V30_First_Real_APK_Candidate.zip`. O workflow GitHub publica o APK com o versionCode vigente.

## Histórico preservado — V708

- Substitui Scouting pelo **Centro de Operações de Corrida**, mantendo sete instalações.
- Aplica ao jogador e às 39 equipes da IA: pit stop de 21,0 s até 19,0 s; chance de atraso de 8% até 2%; reparo adicional de 8,0 s até 5,0 s.
- Atrasos são reproduzíveis por GP, equipe, piloto e número da parada; reparo da asa ocorre dentro da mesma parada, sem duplicação.
- Mercado exibe VEL, CLA, ULT, DEF, CON, CHU e PNE com valores reais e exatos na escala 40–100.
- Remove botão/custo/relatórios Scout e elimina a redução artificial de atributos nas decisões de mercado da IA.
- Migra os níveis e obras ativas de Scouting dos saves V707 para o Centro de Operações.
- Atualiza a lista de instalações, o resumo da Equipe e a imagem da instalação.

O ZIP continua usando exatamente `F1TeamManager_Android_V30_First_Real_APK_Candidate.zip`. O workflow GitHub permanece preparado para executar testes e gerar o APK com o versionCode vigente.

## Histórico preservado — V700

- VersionCode 700 / VersionName 0.700.0; base V699.
- Idade numérica em anos exibida na tela Equipe, na lista/perfil da equipe, no histórico individual, no desenvolvimento de pilotos, na Central de Equipes e em todos os cartões do Mercado de Pilotos.
- As telas leem a idade do motor da carreira para a temporada ativa; a regra de ciclo e envelhecimento não foi alterada.
- A interface mostra apenas o número de anos, sem rótulos como jovem, meia-idade ou veterano. A relação dos 100 pilotos de 2026 está em `PILOT_AGES_V700.md` e `PILOT_AGES_V700.csv`.
- A idade inicial ainda é sintética e determinística; esta versão não altera a idade-base gerada, apenas a torna visível para revisão.
- Estabilização da cadeia de corrida: toda entrada em CareerWeekendEngine e InstantSimulationService normaliza atributos permanentes para 40–100.
- Cálculo de penalidade por chuva também respeita o piso 40 na chamada direta.
- Notificações de P&D usam a semana real de conclusão do projeto, inclusive em avanços de várias semanas.
- Workflow não exige mais metadados obsoletos da v685 e gera o artefato APK com o código da versão atual.
- Testes históricos de construção atualizados para validar Overall físico mínimo 40.
- Imagens externas em Pictures/F1Manager/Assets são o funcionamento esperado do jogo e permanecem suportadas.

## V698 — piso universal 40–100

- Piso mínimo de 40 para os sete atributos permanentes dos pilotos, potencial individual, atributos de todos os componentes do carro e confiabilidade geral/por componente.
- A regra cobre dados de carreira antigos, IA, garagem física, P&D, designs, fabricação, peças, snapshots de Team Principal e fornecedores de motor/pneus.
- Penalidades financeiras, evolução, regressão, P&D, fabricação e migração de saves respeitam o mesmo piso permanente de 40.
- Desgaste e confiabilidade instantânea durante incidentes de corrida são estados transitórios e continuam podendo chegar a zero; os atributos-base permanentes nunca ficam abaixo de 40.

## V697 — correção da recuperação física no ciclo etário

- A recuperação de 50% é calculada sobre o total combinado das perdas de envelhecimento em velocidade, ultrapassagem e defesa.
- Os pontos inteiros são distribuídos por maiores restos, evitando recuperação zero quando cada atributo perde apenas um ponto.
- O limite de cada atributo continua sendo o pico histórico e a quantidade de perda física por envelhecimento registrada.
- Preservados os limites financeiros independentes: €200M para P&D/fabricação/instalações e €150M para o próximo carro.
- Nome público mantido: F1 Team Manager V30.

## Regras comerciais da v685 preservadas

- Níveis 0, 1 e 2: contratos de 3–10 GPs.
- Níveis 3 a 10: contratos de 8–16 GPs.
- Contratos existentes não têm sua duração alterada.

## V684 — correção de compilação e reequilíbrio econômico

- Centro Comercial: níveis 0–3 preservados; níveis 4–10 passam a ter crescimento incremental menor nas vendas, multiplicador comercial com retornos decrescentes e manutenção progressiva.
- Patrocínios: novos contratos passam a durar 8–16 GPs; contratos já assinados em saves existentes permanecem inalterados.
- Investimento técnico: P&D, fabricação, instalações e carro da próxima temporada compartilham o limite anual de €200 milhões. A IA pode reaproveitar alocação não utilizada, mantendo reservas operacionais.
- Painel financeiro: “Caixa Atual” substitui o rótulo incorreto “Salário Anual”; investimento no carro seguinte e saldo consolidado são exibidos separadamente.

## Correção V684 — compilação do painel de investimento

- Corrigida a referência fora de escopo a `managerState` na tela Equipe. O investimento no carro seguinte é passado explicitamente ao composable e contabilizado junto do envelope anual.
- Corrigidos os erros Kotlin em cascata na barra de progresso e nas comparações de limite.

## V682 — equilíbrio carro/piloto por condição climática

- Seco e nublado: carro 65% / piloto 35%.
- Chuva fraca e moderada: carro 55% / piloto 45%.
- Chuva forte: carro 50% / piloto 50%.
- A mesma distribuição é aplicada à volta de classificação e ao ritmo-base de corrida.
- O cálculo de penalidade por chuva limita habilidade em pista molhada a 0–100 e consistência a 40–100.

## Versão

- `versionCode`: 710
- `versionName`: 0.710.0

## Compilação

Abra esta pasta no Android Studio e execute a tarefa `assembleDebug`. O projeto usa Kotlin, Jetpack Compose e Gradle Kotlin DSL.

O workflow `.github/workflows/android-apk.yml` valida os contratos da versão atual, executa os testes unitários e `:app:assembleDebug` no GitHub Actions, publicando o APK de depuração como artefato identificado dinamicamente pela versão. O pipeline configura Java 17, Android SDK 36 e Gradle 9.5.0, compatível com o Android Gradle Plugin 9.3.0 usado pelo projeto.

## Estrutura mantida

- `app/src/main`: aplicação, recursos visuais e bases locais usadas pelo jogo.
- `app/src/test`: testes de regressão e auditoria do motor.
- `tools`: utilitários de auditoria/teste.
- `docs`: documentação técnica ainda agrupada separadamente.

O jogo utiliza imagens externas em `Pictures/F1Manager/Assets/` no armazenamento do dispositivo, conforme os nomes aceitos pelo registro de assets do aplicativo. Esse é o funcionamento previsto; o ZIP/APK não precisa conter essas imagens.

## Limpeza V243

Removidos do ZIP os históricos de alteração antigos soltos na raiz, páginas HTML de apoio não usadas pelo APK, a folha de contato de imagens e a lista `corefiles.txt` que apontava para caminhos absolutos de outra máquina. Código Kotlin, testes, recursos do aplicativo e ferramentas foram preservados nesta etapa; não foram apagadas classes apenas por suspeita de uso.


## Auditoria V245

- Corrigida a versão declarada neste README para corresponder ao build.gradle.kts.
- Revisão estática dos recursos Android: todos os 41 recursos em res/ têm ocorrência textual pelo nome no código/configuração.
- Preservados os 124 arquivos documentais/históricos encontrados no pacote, os testes de regressão e todos os Assets em app/src/main/assets.
- Nenhuma classe Kotlin, imagem, base JSON ou documentação histórica foi excluída nesta etapa. Classes sem referência textual direta permanecem para validação por compilação e análise de carregamento dinâmico.
- Limitação: o ZIP não inclui gradlew/gradle-wrapper.jar; não foi possível executar compilação Gradle local nesta auditoria.


## Auditoria V246 — navegação e acesso aos históricos

- O card de identidade da equipe na Home abre a Central de Equipes.
- O escudo na tela Equipe abre a mesma Central de Equipes.
- Os cards dos pilotos na Central de Equipes abrem o histórico individual do piloto selecionado.
- O botão Voltar do Android agora é tratado pela navegação interna; na Home, solicita confirmação antes de sair, em vez de encerrar o jogo imediatamente.
- O retorno da Central de Equipes preserva a origem (Home ou Equipe), e o retorno do histórico do piloto volta à Central de Equipes.
- Preservados os Assets, as bases, os testes e a documentação histórica existente.
- Limitação desta etapa: compilação Android não executada porque não há Gradle/Gradle Wrapper disponível neste ambiente.


## Correções V247 — avisos e decisões da corrida

- Todos os diálogos ativos da corrida mantêm a simulação pausada; o modo automático é retomado quando todas as pendências forem resolvidas.
- O diálogo de evento exige o botão explícito `CONTINUAR CORRIDA`; toque externo e botão Voltar não o dispensam.
- Removido o botão de fechar que executava `STAY_OUT` implicitamente na decisão do manager.
- Diálogos informativos aguardam a conclusão da decisão do manager e da etapa de box, evitando sobreposição.
- A fila informativa mantém o teto de oito cards por GP; decisões obrigatórias continuam controladas pelo motor, independentemente desse teto.
- Preservados Assets, histórico de versões, testes e demais sistemas.
- Compilação Android não executada: este pacote não inclui Gradle Wrapper e não há Gradle instalado no ambiente de vistoria.


## Correção V499 — previsão visível no diálogo de P&D

- Movido o card GANHO TECNOLÓGICO ESTIMADO para antes da lista de complexidade, para que a previsão apareça logo após a seleção do foco e não fique escondida abaixo das opções e dos botões em telas menores.
- Mantidas as fórmulas existentes do ResearchEngine, seletores de foco/complexidade e ações de iniciar/cancelar pesquisa.
- ZIP validado quanto à integridade; compilação Android não executada neste ambiente.


## V598 — Objetivos dinâmicos do Team Principal
Objetivos de temporada variáveis por força da equipe, prestígio inicial 1 e pontuação limitada a +8 por temporada. Ver `CHANGELOG_V598.md` e `AUDIT_V598_TEAM_PRINCIPAL_OBJECTIVES.md`.



## V604 — Calibração de evolução dos pilotos
- Desempenho por GP compara quali/corrida contra a meta esportiva de equipe sem punir excessivamente uma posição de diferença.
- Crescimento calibrado para cerca de 1,0 na meta esperada; categoria de evolução continua definindo o teto anual por atributo.
- Teste isolado confirma crescimento de Overall até GP6 em desempenho perto da meta.

## V603 — Auditoria e integridade dos pilotos

- O ciclo de carreira é fixo em 5 anos de evolução, 2 de auge e 5 de regressão, persistindo entre temporadas.
- Regressão respeita o Overall mínimo da classe; Lenda mantém teto 100 e mínimo 60.
- A virada de temporada preserva fase, contador do ciclo e progresso fracionário, reiniciando apenas os limites anuais e os registros de idempotência da temporada anterior.
- `currentDrivers()` monta o catálogo com uma única leitura dos mapas de atributos e classe, evitando a leitura/mesclagem do conjunto inteiro uma vez por piloto.
- A correção nominal específica do Felipe foi removida: cada nova carreira reinicializa os 100 pilotos pelos perfis canônicos da versão atual, conforme a regra de início do zero.

## Regra de validação de atualizações (V602)
Toda atualização funcional deve ser validada a partir de uma nova carreira iniciada por **Novo Jogo**, sem continuar um save de versão anterior. Os recursos de salvar/exportar/importar permanecem disponíveis; saves antigos não devem ser apagados automaticamente. Consulte `REGRA_NOVA_CARREIRA_A_CADA_ATUALIZACAO.md`.


## Correção V675 — avaliação da diretoria

- Atingir o objetivo principal de classificação e cumprir pelo menos 60% das metas limita o risco de demissão a 5%, mesmo quando indicadores secundários isolados estejam ruins.
- Atingir o objetivo principal e cumprir pelo menos 40% das metas limita o risco a 12%.
- Mesmo sem atingir o objetivo principal, cumprir pelo menos 80% das metas limita o risco a 25%.
- Demissões continuam possíveis em temporadas de desempenho global insuficiente; o ajuste impede que penalidades secundárias acumuladas anulem uma temporada esportivamente bem-sucedida.


## V701 — idade, carreira e evolução de pilotos

Consulte `CHANGELOG_V701.md` e `PILOT_AGES_V701.csv` para as regras e as 100 idades iniciais oficiais de 2026.


## V702 — desenvolvimento explícito da IA, contratos e margem de classe

- Filas individuais da IA são persistidas por equipe no estado canônico do mercado, incluindo programas ativos e semana absoluta do último avanço; a conclusão é processada antes do GP que recebe o benefício.
- IA e jogador usam o mesmo `DriverDevelopmentEngine`: duração, pontos, capacidade, potencial individual e limite anual por perfil.
- Não há bônus passivo de crescimento por nível de instalação. O nível define apenas os programas disponíveis, sua capacidade, duração e pontos.
- IA escolhe pilotos do próprio elenco para programas individuais, priorizando potencial ainda não realizado e idade favorável, preenchendo todas as vagas e evitando iniciar programa quando os limites anuais já foram consumidos.
- Contratos iniciais e decisões posteriores da IA usam durações de 1 a 5 anos de acordo com idade, Overall e potencial; a contratação emergencial não força mais 1 ano.
- Uma média de desempenho excepcional na temporada libera margem temporária de +1 a +3 Overall acima do teto da classe, sempre limitada pelo potencial e Overall 100.
