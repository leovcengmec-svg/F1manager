# Auditoria V618 — Realismo de renovações e mercado de pilotos

## Base e escopo

- Base de trabalho: V617 (0.617.0).
- Versão entregue nesta atualização: V618 (0.618.0).
- Escopo funcional: decisão de renovação da IA, critério de alternativa esportiva e persistência da decisão no save.
- Não foram alterados assets, perfis/catálogos de pilotos, regras financeiras de taxas de assinatura, regras de corrida, calendário, histórico de versões ou fluxo da temporada V617.

## Causa identificada

A avaliação de renovação acontecia a cada semana em que o contrato continuava elegível. Mesmo quando a chance individual era moderada, repetir o sorteio ao longo de muitas semanas acumulava probabilidade e levava a uma taxa de renovação artificialmente alta.

Além disso, a existência de uma alternativa melhor apenas diminuía a chance de renovar; não impedia que a equipe mantivesse um piloto claramente inferior.

## Correções aplicadas

1. A IA agora registra uma chave `temporada:equipe:piloto` quando avalia uma renovação. Cada combinação é avaliada uma única vez por temporada, mesmo se a proposta não for enviada, for recusada ou terminar sem acordo.
2. O registro é salvo em `marketRenewalEvaluations` e carregado junto com o restante do mercado de pilotos. Saves antigos sem essa chave continuam sendo aceitos; a chave passa a ser preenchida quando o mercado abre. O backup completo inclui a preferência automaticamente pelo mecanismo existente de exportação.
3. A probabilidade-base por encaixe foi reduzida para 40%, 28%, 16% ou 6%, respectivamente, e agora é uma chance de avaliação única — não uma chance semanal acumulativa.
4. Se existir um candidato disponível pelo menos 8 pontos acima do titular, com interesse de 70 ou mais e interesse esportivo não muito inferior ao do titular, a IA não propõe renovação automática para o piloto inferior e prioriza procurar a melhoria no mercado.

## Testes direcionados

- `DriverMarketRenewalRealismV618Test`: os dois casos passaram — decisão avaliada uma única vez por temporada e bloqueio de renovação quando existe alternativa claramente superior e interessada.
- `V591DriverMarketNegotiationRegressionTest`: 2/2 casos passaram; propostas de renovação continuam seguindo a negociação com resposta atrasada e permanecem disputáveis por equipes rivais até a assinatura.
- `MarketMovementMixTest`: aprovado; o mercado ainda produz renovações e transferências, e não deixou propostas pendentes vencidas sem resolução.
- Simulação direcionada de 2 temporadas em 4 sementes: 8/8 transições mantiveram as 40 equipes com dois pilotos após a virada. Na temporada inicial, houve 5–9 renovações para 36 contratos expirando. Na temporada seguinte, houve 15–26 renovações entre 59–63 contratos expirando. A taxa deixa de se aproximar do padrão de 50 renovações em 60 contratos observado no problema reportado.

## Limitações da validação

O código do motor de mercado, os modelos de mercado, o banco de pilotos, o calendário e os testes direcionados foram compilados/executados em uma verificação Kotlin localizada. Para testar sem Gradle, a verificação usou substitutos locais apenas para os métodos auxiliares de força inicial de equipe e precisão de scouting; a função de força substituída usa a mesma tabela oficial de níveis (Forte 100, Médio 75, Fraco 50). A compilação Android/Gradle completa e o teste dentro de emulador/dispositivo não foram executados, pois este pacote não contém `gradlew` e não há `gradle` instalado no ambiente.
