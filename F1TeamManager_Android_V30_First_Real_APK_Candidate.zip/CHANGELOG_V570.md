# V570 — Continuidade das músicas

- Música do menu permanece contínua entre as telas do menu; a navegação não reinicia a faixa.
- Música da interface da carreira permanece contínua ao trocar entre telas internas.
- A sequência `interface` → `interface_2` → `interface_3` avança somente quando há um resultado de GP e o jogo retorna à interface da carreira.
- Mantidos os roteamentos específicos de classificação/corrida, resultado e eventos.
- Versão Android: `0.570.0` (versionCode 570).

Validação estática: verificadas as chaves dos efeitos Compose e os gatilhos da rotação. Build Android/dispositivo não executado nesta validação.
