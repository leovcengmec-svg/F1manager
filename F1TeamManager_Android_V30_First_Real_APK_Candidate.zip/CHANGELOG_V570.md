# F1 Team Manager V570 — 0.570.0

- Integrates durable per-round constructor standings into the visible championship screen.
- Unions catalog team IDs, current aggregate IDs, and durable history IDs so custom teams are not omitted.
- Uses durable round-derived points when snapshots exist; falls back to the legacy aggregate for old careers without snapshots.
- Unknown team IDs remain visible with a stable `EQUIPE <ID>` label instead of being dropped.
- Keeps driver standings, movement indicators, historical keys, and external assets unchanged.

Validation: ZIP integrity and source-level checks performed. Android compilation, unit tests, and device-level restart/two-season simulations were not run.
