# v694 — Kotlin build fix for dynamic AI investment

- Fixed two invalid `.copy()` calls on `AIInvestmentMindset`, which is an enum and does not expose data-class copy semantics.
- Added `SeasonInvestmentPolicy.effectiveNextCarPriorityPercent()` to calculate the released/active next-car cash priority explicitly.
- Updated facility investment and development-capacity paths to use the effective priority percentage.
- Preserved all v693 investment rules: independent €200M current-car/facilities envelope and €150M next-car envelope, four strategic mindsets, and cash/operating-reserve checks.
- Incremented Android VersionCode to 694 and VersionName to 0.694.0.
- Added regression coverage for priority release at the €150M next-car annual cap.

Validation: source-level checks and ZIP integrity performed. Full Android APK build and JUnit execution must be confirmed by GitHub Actions because this package has no Gradle wrapper and the local environment has no Gradle installation.
