# V626 — Minha Carreira: rolagem e objetivos interativos

- A página Minha Carreira agora permite rolagem vertical integral.
- Cards receberam alturas explícitas para evitar comprimir/ocultar Contrato e Metas Cumpridas.
- Objetivos podem ser tocados para expandir/recolher os detalhes.
- Objetivos de classificação mostram estado provisório verde/vermelho com base na posição atual quando há resultados da temporada. Objetivos sem dados de progresso nesta tela permanecem neutros para não inventar um estado.
- Versão 626 / 0.626.0.

Build Android e teste visual em aparelho ainda precisam de execução real; não declarados como aprovados.
