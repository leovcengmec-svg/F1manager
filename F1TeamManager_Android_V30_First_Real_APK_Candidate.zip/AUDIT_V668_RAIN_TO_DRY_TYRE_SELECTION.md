# Auditoria V668 — escolha de pneus após chuva

## Causa encontrada na V667

A rotina de transição chuva→seco percorria os pilotos do jogador e, quando o plano A/B/C ainda estava automático, chamava `dryCompoundForRemainingLaps()` seguido de `pit()`. Em uma corrida preparada com chuva desde a largada, `weatherManualMode` ainda podia estar `false`; por isso o composto (inclusive HARD) era montado antes de qualquer diálogo.

## Correções

1. Extraído `requestPlayerTyreChoiceAfterRain()`, chamado pelo evento de transição climática.
2. O handler seleciona somente carros do jogador que ainda usam INTERMEDIATE/WET.
3. O handler invalida o plano automático para esses pilotos, limpa o plano livre pendente, mantém o pneu atual e enfileira uma decisão obrigatória `WEATHER_CHANGE`.
4. O primeiro botão `BOX` continua interceptado pela interface e abre a etapa `ESCOLHER PNEU PARA O BOX`. A confirmação do jogador chega a `pitNow(driverId, selectedTyre)` e preserva exatamente o composto selecionado.
5. Em pista seca, o seletor mostra somente SOFT/MEDIUM/HARD. O MEDIUM aparece como recomendação inicial, mas não é montado sem confirmação.
6. O fluxo sem interface (`simulateRaceInstantly`) usa MEDIUM neutro como fallback, em vez de selecionar HARD pela quantidade de voltas restantes.
7. A IA mantém seu fluxo independente de replanejamento; somente os pilotos que possuem plano editável do jogador entram nesta fila.

## Testes adicionados

- Corrida iniciada com chuva e pista secando: exige decisão e não executa pit stop automático.
- Seleção distinta dos dois pilotos (SOFT e HARD) é preservada pelo motor.
- Piloto que já está com slick não recebe uma decisão desnecessária; apenas o companheiro ainda em pneu de chuva é enfileirado.
- Transições que não sejam chuva→seco não geram decisão indevida.

## Limitação de build

A compilação Android completa requer Gradle/Gradle Wrapper e Android SDK. O pacote desta revisão mantém o workflow existente para compilação no GitHub Actions; nenhum APK é declarado como compilado localmente.
