# V584 - Ajuste dos cards Grandes Acontecimentos

- Base: pacote V583 recebido nesta conversa.
- Reduzida a janela das imagens para 34 dp em modo compacto e 42 dp em modo normal.
- Imagens exibidas com ContentScale.Fit dentro de uma janela padronizada, preservando proporcao e evitando cortes agressivos.
- Descricoes agora usam rolagem vertical dentro de cada card e nao sao limitadas a oito linhas.
- Os quatro cards continuam com largura e area de imagem padronizadas.
- Adicionado teste de regressao para tamanho, escala e rolagem.
- ZIP criado e verificado estruturalmente; compilacao Android/testes Kotlin e validacao visual em dispositivo nao foram executados neste ambiente.
