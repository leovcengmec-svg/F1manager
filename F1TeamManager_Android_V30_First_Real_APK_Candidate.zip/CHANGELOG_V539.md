# V539 — Integração dos benefícios das instalações

- Pesquisa agora calcula o prazo real usando os níveis de Centro de P&D, Túnel de Vento e Simulador para o componente escolhido.
- O modal de pesquisa apresenta opções com os mesmos prazos efetivamente usados ao iniciar o projeto.
- O Centro de P&D reduz também o custo do projeto (2% por nível), acumulado com o desconto do ranking técnico.
- O início de pesquisa grava custo e duração derivados do estado real das instalações, evitando diferença entre prévia e execução.
- Criado teste de regressão para duração/custo de pesquisa e limites dos benefícios centrais das sete instalações.
- Preservadas as rotinas existentes de fábrica, desempenho de pista, scouting, evolução de pilotos, marketing e manutenção.

Validação desta entrega: verificação estática e integridade ZIP. Build Gradle/testes automatizados dependem de ambiente Android/Gradle, indisponível nesta sessão.
