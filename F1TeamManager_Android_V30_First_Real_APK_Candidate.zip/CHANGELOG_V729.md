# V729 — Contratos de patrocínio com duração 8–14 GP e liquidação correta

**VersionCode:** 729  
**VersionName:** 0.729.0  
**Base:** V728 / 0.728.0  
**Nome público:** F1 Team Manager V30  
**ZIP:** `F1TeamManager_Android_V30_First_Real_APK_Candidate.zip`

## Alterações

- Centro Comercial níveis 0–2 mantém a duração original de **3 a 10 GPs**.
- Centro Comercial nível 3 em diante passa a oferecer exatamente **8, 9, 10, 11, 12, 13 ou 14 GPs**, inclusive. O sorteio determinístico percorre todo o intervalo inteiro; não usa saltos de dois ou mais GPs.
- Duração é fixada no momento da assinatura. Evoluir o Centro Comercial não altera contratos já assinados.
- Contratos V728 já assinados com 15 ou 16 GPs são preservados até expirarem; a mudança de faixa vale somente para novas propostas e renovações.
- Criado o fluxo `TeamSponsorshipEngine.settleRaceThenAdvance()`: liquida o GP com a carteira de contratos que estava ativa naquele GP e só depois decrementa a duração e gera substituições.
- `ManagerSeasonEngine` agora usa o mesmo ordenamento: pagamento/bônus do GP final do contrato antigo primeiro; substituição depois; novo pagamento por GP somente a partir do GP seguinte.
- O fluxo principal Android já liquidava primeiro e avançava a duração depois; esse comportamento foi mantido. Assim, jogador e IA usam as mesmas regras de liquidação do GP final.
- A notificação existente **SLOT DE PATROCÍNIO LIVRE** foi preservada. Nenhuma notificação adicional ou duplicada foi criada; o fluxo atual da Home/central continua direcionando o jogador à tela Finanças para escolher uma das propostas.
- A IA continua selecionando automaticamente a melhor das três propostas geradas pelo mesmo catálogo e pelo mesmo nível comercial disponível ao jogador.

## Testes adicionados/atualizados

- Duração por nível atualizada para 3–10 (níveis 0–2) e 8–14 (níveis 3–10).
- Teste de cobertura confirma que todos os inteiros de 8 a 14 podem ser gerados e que 15/16 não aparecem em novas propostas.
- Auditoria de três temporadas usa a faixa nova para propostas e renovações.
- Testes de liquidação confirmam que tanto o jogador quanto a IA recebem o último pagamento do contrato antigo antes de sua remoção e que o novo contrato só recebe pagamento por GP no GP seguinte.
- Verificada a preservação de contratos V728 e da notificação já existente; nenhuma interface ou texto de notificação foi duplicado.

## Preservado

- Categorias e valores definidos pelo nível do Centro Comercial.
- Três propostas por espaço, seleção manual para jogador e seleção automática para IA.
- Pagamento inicial, pagamento por GP, bônus de classificação e bônus de corrida.
- Cinco espaços de patrocínio, exclusão de marcas já ativas e duração fixa dos contratos assinados.
- Notificação de encerramento existente e tela de propostas em Finanças.

## Limites de validação

A execução integral Android/JUnit e `assembleDebug` depende do Gradle/Android SDK ou do GitHub Actions. Não declarar APK aprovado sem o resultado do workflow.
