# V167 — Ajustes cirúrgicos na visão geral da equipe

- V167 sucede oficialmente a V166 e passa a ser a única base oficial para a próxima atualização.
- Removido o banner adicional com imagem do carro no topo da visão geral da equipe; os carros permanecem na seção inferior “CARROS DA EQUIPE”.
- Cards de Orçamento e Desempenho Geral recebem altura igual e o desempenho é organizado em grade, reduzindo a diferença visual entre os cards.
- Nomes dos pilotos podem ocupar até duas linhas para evitar corte desnecessário em nomes mais longos.
- Histórico por temporada permanece diretamente abaixo do título, exibindo a tabela no próprio card; foram incluídas colunas de pódios e os cabeçalhos ficaram mais explícitos.
- Preservadas as funcionalidades e o restante da estrutura anterior.
- Versionamento Android: versionCode 167, versionName 0.167.0.
- A compilação Android e a validação visual em dispositivo ainda precisam ser executadas antes da homologação.
- Nome externo obrigatório preservado: `F1TeamManager_Android_V30_First_Real_APK_Candidate.zip`.
