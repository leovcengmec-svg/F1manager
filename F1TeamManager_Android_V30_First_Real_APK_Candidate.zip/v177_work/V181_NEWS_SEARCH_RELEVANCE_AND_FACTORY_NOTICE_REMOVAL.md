# V181 — Central de Notícias

- Added a search field below the Central de Notícias title. It filters the currently selected category by team/entity/message, e.g. Ferrari.
- Team evolution news within each season/week is ordered by relevance: overall change, installed part, design ready for factory.
- Stopped creating factory-completed / physical-part-ready notifications for player and AI teams. Existing saved notifications of that type are hidden from the feed as well. The underlying P&D → factory → installation gameplay pipeline remains unchanged.
- Version: 181 / 0.181.0.
