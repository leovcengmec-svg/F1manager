# V172 — Melhorias de instalações com prazo de 12 semanas

Base: V171.

## Regras
- Uma melhoria ativa por equipe, para jogador e IA.
- Custos existentes por instalação e nível são mantidos.
- O custo é cobrado uma vez no início e respeita o caixa e o teto anual de investimento técnico.
- O nível permanece inalterado durante a obra e sobe apenas ao concluir 12 avanços semanais.
- Não há cancelamento.
- Estado da obra é persistido no save do jogador e no snapshot da IA; snapshots antigos continuam sendo aceitos.
- Interface exibe a instalação em obra, nível-alvo, progresso e semanas restantes e bloqueia novos inícios.

## Arquivos alterados
- `FacilityModels.kt`: estado de obra, início e conclusão idempotente.
- `ManagerModels.kt`: obra ativa no estado da carreira.
- `CareerPreferences.kt`: persistência da obra do jogador.
- `AITeamFinancialEngine.kt`: mesma regra para IA e persistência compatível no snapshot.
- `MainActivity.kt`: integração com avanço semanal, notícias de conclusão e UI.
- `FacilityUpgradeV172Test.kt`: testes de prazo, custo, limite simultâneo e saldo insuficiente.

## Validação
- ZIP original V171 validado antes da alteração.
- A compilação Gradle completa deve ser executada em ambiente Android SDK/Gradle; se ausentes no ambiente, a V172 permanece código-fonte preparado, sem homologação de APK.
