# V246 — Navegação da Central de Equipes

- Home: toque no card/escudo da equipe para abrir a Central de Equipes.
- Equipe: toque no escudo para abrir a Central de Equipes.
- Central de Equipes: toque no card de um piloto para abrir seu histórico individual.
- Histórico do piloto: voltar retorna à Central de Equipes.
- Botão Voltar do Android: navegação interna nas telas; na Home, exibe confirmação de saída para evitar encerramento acidental.

Nenhum Asset, banco de dados, classe ou histórico anterior foi removido.
