# Auditoria V299 — Artes genéricas para tela de equipe

## Base
- Atualização aplicada sobre o ZIP V298 fornecido como base, preservando seu código e histórico.
- Nome oficial do ZIP mantido.

## Mapeamento
- Tela real: `MainActivity.kt`, composable `TeamOverviewScreen`.
- Banner superior da equipe: `Card`/`Box` dentro da `LazyColumn`.
- Instalações: composable `TeamOverviewFacilities`.
- Dados e regras são derivados de `TeamOverviewSnapshot`, `TeamFacilitiesState`, `TeamGarage` e do estado de carreira; não foram alterados.

## Implementação visual
- `team_card_generic_bg.webp`: fundo genérico cinematográfico para o card da equipe, sem escudo, nome ou carro específico; funciona com todas as equipes.
- Seis artes genéricas para instalações: fábrica, P&D, túnel de vento, simulador, marketing e centro comercial/scouting.
- As imagens são WebP, carregadas com `painterResource` e exibidas com `ContentScale.Crop`.
- Aplicada sobreposição escura para preservar contraste dos textos.
- Mantidos controles anterior/próximo, nome/país/posição/desempenho/pontos e todos os dados funcionais.
- Mantidos nível e barra de progresso das instalações; apenas o placeholder de ícone foi substituído por imagem.

## Comparação objetiva com o layout aprovado
- Fundo do banner: substitui gradiente plano por imagem genérica com textura de fibra de carbono e luzes vermelhas.
- Instalações: substitui ícones monocromáticos em caixas de 48dp por imagens fotográficas em caixas de 66dp.
- Cartões, ordem da tela, rolagem vertical e dados permanecem inalterados nesta atualização.

## Verificação
- Recursos criados e referências `R.drawable.*` verificadas estaticamente.
- ZIP verificado com `ZipFile.testzip()`.
- Build Android e validação visual no dispositivo não foram executados neste ambiente.
