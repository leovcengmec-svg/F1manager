# F1 Team Manager V212 — Auditoria das mutações de tempo de corrida

- Auditoria do motor `CareerWeekendEngine`: tempo acumulado deve mudar apenas na aplicação da grelha inicial, ao concluir uma volta ou pela perda de tempo de um pit stop.
- Mantidas as correções V207 (Safety Car/bandeira vermelha não reescrevem o tempo acumulado), V210 (falha da asa dianteira na última volta não cria pit stop retroativo) e V211 (classificação ao vivo e final usam a mesma base cronológica).
- Adicionado teste estático de regressão para proteger essas três regras e impedir reintrodução de uma atribuição artificial do tempo durante neutralizações.
- O teste é uma verificação estática do código-fonte; não equivale a executar uma corrida completa.
- Build Android e simulação real de várias temporadas ainda precisam ser executados em ambiente Gradle/Android.
