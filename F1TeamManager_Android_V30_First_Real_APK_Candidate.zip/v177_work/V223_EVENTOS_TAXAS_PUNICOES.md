# V223 — Especificação de eventos, probabilidades e punições

## Parâmetros aprovados
- Perfil de incidentes: REALISTA.
- Confiabilidade: NORMAL.
- Aplicação de punições: RIGOROSA e proporcional à infração comprovada.
- Cards: TODOS os eventos relevantes do motor, sem transformar evento informativo em decisão obrigatória.
- Referência visual: componente/modal universal aprovado na imagem do projeto; manter fundo de corrida escurecido/desfocado, painel central escuro, detalhes vermelhos, cabeçalho, narração, consequências condicionais e botão CONTINUAR CORRIDA.

> As probabilidades abaixo são parâmetros iniciais de calibração por GP (20 carros), não estatísticas oficiais. Devem ser validadas em simulações antes de serem consideradas calibradas.

## Catálogo e taxa inicial por GP
| Evento | Taxa inicial | Unidade/limite | Efeito real obrigatório |
|---|---:|---|---|
| Toque leve sem dano | 20–45% | por GP; múltiplos possíveis | perda de tempo pequena e localizada, sem dano se não sorteado |
| Colisão com dano | 5–15% | por GP | aplicar dano ao componente do carro atingido; perda de tempo coerente |
| Rodada | 5–12% | por GP | perda de tempo/posições; dano somente se houver consequência secundária |
| Saída de pista | 10–25% | por GP | perda de tempo; vantagem indevida gera obrigação de devolver posição ou sanção |
| Pneu furado | 2–6% | por GP | degradação/ritmo afetado e pit obrigatório assim que seguro; não duplicar o mesmo furo |
| Falha mecânica não terminal | 3–8% | por GP | aplicar perda de desempenho ao componente identificado |
| Abandono mecânico | 2–6% | por GP | marcar DNF, excluir de execução competitiva futura e preservar classificação/voltas |
| Erro de pit stop | 5–12% | por GP | adicionar atraso real ao tempo de parada; card não inventa segundos |
| Infração investigada | 10–25% | por GP | investigação não é punição automática; requer causa e evidência simulada |
| VSC | 10–25% | por GP | neutralizar ritmo/tempos conforme regra; manter decisão estratégica existente |
| Safety Car | 15–35% | por GP | neutralizar corrida e aplicar agrupamento coerente; manter decisão estratégica existente |
| Bandeira vermelha | 1–5% | por GP | suspender corrida e usar fluxo de relargada existente |
| Chuva durante o GP | 5–20% | por GP, apenas se clima variável habilitado | alterar aderência, pneus elegíveis e ritmo; nunca só texto de card |

As faixas são probabilidades de que ocorra ao menos um evento da categoria no GP, não probabilidades independentes repetidas por carro e por volta. Os eventos relacionados devem compartilhar uma cadeia causal: por exemplo, colisão → dano → investigação → possível punição/neutralização.

## Modificadores probabilísticos
Aplicar como multiplicadores limitados à taxa-base e normalizar o resultado final para 0–1. Não multiplicar novamente quando a mesma causa já foi contabilizada.

### Incidentes de piloto
- Consistência/controle baixos (atributo 40–49): ×1,25; 50–69: ×1,00; 70–84: ×0,85; 85–100: ×0,70.
- Agressividade alta durante disputa: ×1,15 para toque/colisão; não aumenta falha mecânica.
- Tráfego denso/duelo roda a roda: ×1,20; pista estreita ou poucas áreas de escape: ×1,15.
- Chuva e pneu inadequado: ×1,30; chuva com pneu apropriado: ×1,05.
- Desgaste crítico: ×1,20 para erro/perda de controle; não aplicar se carro já está DNF.
- Limitar multiplicador agregado de risco de incidente a 0,50–2,00 antes da taxa final.

### Falhas mecânicas
- Confiabilidade do componente 90–100: ×0,70; 75–89: ×1,00; 60–74: ×1,35; abaixo de 60: ×1,75.
- Desgaste/temperatura críticos: ×1,25 por fator aplicável, mas limite agregado ×2,00.
- Cada componente tem no máximo uma falha terminal por corrida; componente já quebrado não pode gerar falha duplicada.
- A probabilidade é calculada por exposição/volta e calibrada para alcançar a faixa-alvo por GP. Não sortear a taxa do GP inteira a cada volta.

### Pit stop
- Equipe/instalação de pit fraca: ×1,20 para atraso; forte: ×0,85.
- Condições de Safety Car podem afetar oportunidade estratégica, não devem tornar o trabalho mecânico automaticamente perfeito ou defeituoso.

## Matriz de punições — aplicação rigorosa e proporcional
| Infração comprovada | Resposta padrão | Agravantes |
|---|---|---|
| Limites de pista sem vantagem | advertência; reincidência: 5 s | repetição após advertências: 10 s |
| Ganho de posição/tempo fora da pista | devolver vantagem se possível | recusa/impossibilidade: 5–10 s |
| Colisão leve com culpa clara | advertência ou 5 s | dano/recorrência: 10 s ou drive-through |
| Colisão grave causada por imprudência | 10 s ou drive-through | abandono de rival/dano grave: stop-and-go ou sanção pós-corrida |
| Bloqueio perigoso | 5 s | repetição/perigo elevado: 10 s ou drive-through |
| Liberação insegura no pit lane | 5–10 s | contato/risco grave: drive-through ou sanção pós-corrida |
| Excesso de velocidade no pit lane | 5 s | excesso elevado/reincidência: 10 s |
| Ignorar bandeira/ordem de direção de prova | drive-through | bandeira vermelha ou perigo grave: stop-and-go/desclassificação conforme regra simulada |
| Componente/condição técnica ilegal | desclassificação | não usar por falha mecânica comum sem violação técnica |

Punições temporais devem ser adicionadas ao tempo total ou cumpridas nos boxes conforme o tipo, nunca aplicadas nos dois formatos. A punição não é sorteada: primeiro se identifica uma infração e sua responsabilidade; depois a tabela determina a sanção. Se a culpa for inconclusiva, registrar incidente sem penalidade automática.

## Política de cards
1. Todos os eventos relevantes geram card; avisos repetitivos de degradação só geram card ao cruzar um novo nível de gravidade.
2. Um card contém tipo, volta, GP, piloto/equipe envolvidos, narrativa e apenas consequências confirmadas pelo motor.
3. Mostrar campos condicionais: punição só quando aplicada; dano só quando registrado; tempo perdido só quando medido; imagem opcional.
4. Fechar card retoma a corrida automaticamente se não houver decisão de gestor pendente.
5. Eventos que requerem decisão (VSC, Safety Car, bandeira vermelha, combustível/pneu crítico e mudança estratégica de clima) mantêm o fluxo de decisão existente; não substituir por botão informativo.
6. Deduplicar por identificador causal: um mesmo incidente não pode gerar cards duplicados nem aplicar dano/punição duas vezes.
7. Evento em carro DNF não gera novas ocorrências competitivas. Evento visual não pode alterar classificação sem mutação correspondente no motor.

## Auditoria de calibração obrigatória
Executar pelo menos 1.000 GPs simulados com seeds registradas, 20 carros e variedade de circuitos/climas. Medir por 100 GPs: eventos por categoria, DNFs, penalidades, VSC, Safety Car, bandeiras vermelhas, tempos de pit e distribuição por piloto. Ajustar taxas até a média cair nas faixas definidas, sem usar a taxa por GP como sorteio independente por volta. Verificar também: ausência de eventos duplicados, punição aplicada uma única vez, DNF terminal, ordenação/tempos consistentes e retomada automática dos cards informativos.

## Estado da implementação
Este arquivo define a especificação aprovada para orientar o código. A presença de um tipo em `EventType` não comprova que sua geração probabilística, consequência mecânica, punição e card estejam implementados. Cada linha deve ter teste unitário/integrado antes de marcar como concluída. Layout aprovado deve ser preservado.
