# V224 — Especificação de eventos da corrida
- Consolidado catálogo, taxas iniciais, modificadores, punições e testes.
- Incluídos Largada Ruim (3% por piloto/largada) e Perda de Controle na Chuva Forte (8% por piloto elegível/volta somente com chuva forte).
- Perfil: incidentes realistas, falhas mecânicas normais, punições rigorosas, cards para todos os eventos relevantes.
- Mantida a referência visual aprovada da V222; nenhuma alteração de layout nesta etapa.
- Importante: esta versão documenta as regras; não declara implementação do motor, compilação ou homologação.
