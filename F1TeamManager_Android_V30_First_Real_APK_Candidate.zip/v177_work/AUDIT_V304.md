# Auditoria V304 — Ajustes visuais Home e Equipe

- `TeamHeroCard`: fundo genérico aplicado com `Image` e `ContentScale.Crop`; ilustração de carro removida; nome da equipe em uma linha.
- `TeamOverviewScreen`: arte de carro removida; navegação reduzida e movida aos cantos superiores do card; nome da equipe em uma linha.
- `TeamOverviewBudgetCard`: layout em linhas com ícones, labels e valores alinhados; limite técnico, receita, despesa e saldo mantidos.
- `TeamOverviewGeneralCard`: estatísticas preservadas; Overall aparece em linha compacta em vez de cartão interno; cada estatística tem ícone e valor alinhado.
- Integridade de recursos: nenhuma imagem externa de escudos, pilotos, GPs, carros ou bandeiras foi removida.
- Verificação estática somente. Compilação Gradle/APK e teste em dispositivo precisam ser executados no GitHub Actions/dispositivo.
