# V289 — Correções de compilação Kotlin

- Corrigido o uso de `takeLast` em conjuntos ordenados convertendo explicitamente o conjunto em lista antes de limitar o histórico de chaves de eventos.
- Adicionados os imports explícitos de `AnnualEventGarageAdapter` e `AnnualTeamEventEngine` usados em `MainActivity.kt`.
- Corrigida a referência ao tipo aninhado `AnnualTeamEventEngine.TeamSnapshot`, que era referenciado pelo alias local do objeto e não resolvia no compilador Kotlin.
- Atualizada a versão Android para `versionCode 289` / `versionName 0.289.0`.
- Preservados os assets, dados e histórico das versões anteriores.
