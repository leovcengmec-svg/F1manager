# V270 — Integração dos eventos anuais

- Calendário anual materializado e processado no avanço normal de semanas, incluindo saltos de várias semanas.
- Efeitos de eventos de equipe aplicados a uma equipe-alvo por ocorrência e persistidos para jogador/IA.
- Eventos de atributos de piloto e mudança de classe usam armazenamento persistente.
- Notícias publicadas na Central de Notícias com categoria `ANNUAL_EVENTS`.
- Chaves de idempotência gravadas após efeitos e notícias, evitando repetição após recarregar a carreira.
- Stats de carro da IA em eventos anuais persistidos por equipe, sem sobrescrever o slot de carro do jogador.
