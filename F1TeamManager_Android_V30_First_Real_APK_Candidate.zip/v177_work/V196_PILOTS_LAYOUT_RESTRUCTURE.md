# V196 — Reestruturação da tela Pilotos

Base: último ZIP entregue (manifesto interno 0.195.0). Nome físico oficial do ZIP preservado.

## Alterações reais no código ativo
- `app/src/main/java/com/f1teammanager/MainActivity.kt`: reestruturado `DriverSeasonCard`, usado diretamente pela tela Pilotos.
- Aumentada a presença do retrato e reorganizada a área de identificação, OVR e sete atributos em grade 4+3.
- Recriada a faixa de temporada com seis indicadores principais, sem comprimir estatísticas redundantes em uma segunda faixa. Média de chegada e DNFs continuam disponíveis no comparativo.
- Reestruturados os painéis de evolução e melhores ganhos de atributos, com mais espaço e contraste.
- Mantido `DriverSeasonComparisonCard` e seu uso dos resumos reais de temporada entre os cards dos dois pilotos.
- Atualizados `versionCode=196` e `versionName=0.196.0`.

## Validação
- ZIP de origem íntegro antes da edição.
- A validação final de integridade do ZIP e inspeção estática serão executadas antes da entrega.
- Build Gradle e captura de execução precisam ser informados conforme disponibilidade do ambiente; a integridade do ZIP, isoladamente, não certifica compilação nem fidelidade visual renderizada.
