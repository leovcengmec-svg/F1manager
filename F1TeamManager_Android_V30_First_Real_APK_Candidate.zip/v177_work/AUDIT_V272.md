# Auditoria V272 — instalações de equipes de IA

## Falha encontrada
`participants()` usava `aiState.facilities`, retornado pela simulação técnica reconstruída a partir das instalações padrão. Isso podia ignorar as instalações modificadas por eventos anuais e persistidas em `AITeamFinancialEngine`, deixando o estado de carreira diferente do enviado à grade.

## Correção
A grade passa a consumir `aiFinance.facilities(aiTeam.id)`, a mesma fonte usada ao resolver e persistir os eventos anuais. O carro físico continua recebendo os deltas anuais por `AnnualEventGarageAdapter`, separadamente.

## Verificações executadas
- Conferência de versão: `versionCode=272`, `versionName=0.272.0`.
- Teste estático: único ponto de atribuição `aiFacilities[aiTeam.id]` agora usa a fonte persistida.
- O motor de eventos e os testes/harnesses da V271 foram preservados.

## Limitação
Não foi possível executar build Android completo porque o pacote não contém Gradle Wrapper e não há instalação Gradle disponível. A correção não deve ser considerada validada em dispositivo até o build e a simulação in-app.
