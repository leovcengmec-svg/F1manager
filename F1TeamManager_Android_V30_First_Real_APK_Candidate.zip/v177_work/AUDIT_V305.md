# Auditoria V305

- Verificado estaticamente o filtro do modal da Home para “P&D CONCLUÍDO”: compara o início da mensagem com o nome da equipe do jogador (`$team `), ignorando maiúsculas/minúsculas.
- Eventos da categoria `ANNUAL_EVENTS` continuam sendo aceitos independentemente da equipe, exceto os avisos já excluídos de resultado de GP e nova temporada.
- A alteração afeta a exibição do modal, não remove itens do histórico da Central de Notícias.
- Integridade do ZIP verificada após empacotamento. Compilação Android e teste em dispositivo pendentes.
