# Auditoria V282 — persistência anual de pilotos

## Correção
A função `commitAnnualDriverStateAndKeys` não chama mais `driverAttributes()` para obter o estado anterior. Essa chamada podia acionar uma reparação com gravação assíncrona (`apply`) antes da gravação transacional do lote, criando risco de concorrência entre gravações.

A função agora lê a string persistida e usa `DriverAttributePersistence.merge(...).first` apenas para reconstruir o estado anterior em memória. A gravação conjunta de atributos, classes e chaves processadas continua concentrada no único `commit()` da transação.

## Verificações estáticas
- Leitura do estado anterior sem invocar `driverAttributes()` dentro da função transacional.
- Preservação do processamento por elenco conhecido e fallback para dados existentes/atributos-base.
- Persistência de atributos, classes e chaves de eventos no mesmo editor.
- Metadados atualizados para versionCode 282 / versionName 0.282.0.
- Integridade estrutural do ZIP validada após empacotamento.

## Limitação
Não foi executado build Android/Gradle nem teste instrumentado do aplicativo nesta execução. Esta auditoria não declara validação funcional em runtime.
