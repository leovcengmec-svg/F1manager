# V144 — Android Build Fix (sem legado)

Base: V143 oficial.

## Correções

1. `CareerPreferences.kt`
   - Corrigido o armazenamento dos 7 atributos atuais de evolução.
   - `ratingsForEvolution()` já retorna `IntArray`; removido o `.toList()` que produzia incompatibilidade `List<Int>` → `IntArray`.
   - Nenhum helper de evolução legado foi restaurado.

2. `MainActivity.kt`
   - Adicionado o import da estrutura atual `TeamGarage`.
   - `participants()` passou a declarar explicitamente `List<RaceParticipant>`, mantendo a cadeia atual do grid → corrida.
   - Corrigida a chamada de `drawLine` no `SponsorUiIcon` para a assinatura atual do Compose (`color, start, end, strokeWidth`).
   - Nenhuma API antiga de garagem ou corrida foi reintroduzida.

3. Versão
   - `versionCode = 144`
   - `versionName = "0.144.0"`

## Validação

- Compilação completa do núcleo Kotlin: PASS.
- Nenhuma referência reintroduzida a `simulatorEfficiency`.
- Nenhuma referência reintroduzida a `phaseFor`.
- Nenhuma restauração de `baseCar`.
- ZIP validado após empacotamento.

A validação `assembleDebug` depende do ambiente Gradle/Android externo usado para gerar o APK.
