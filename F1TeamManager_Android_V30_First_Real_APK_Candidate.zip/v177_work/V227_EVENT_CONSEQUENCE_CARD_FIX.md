# V227 — Consequências dos cards de eventos

- Versão Android: 0.227.0 / versionCode 227.
- Mantém o componente visual universal aprovado e o registro das imagens V225/V226.
- O bloco CONSEQUÊNCIAS deixou de repetir a narração `event.detail` e agora apresenta explicações por categoria de evento.
- Os textos distinguem acidente, falha mecânica, reparo de asa com +21 s, perda de DRS/ERS, Safety Car/VSC, bandeira vermelha, abandono, mudança climática, pit stop e eventos informativos.
- Quando o motor não fornece uma perda numérica estruturada, o card não inventa segundos; informa que o efeito depende do estado/classificação do motor.
- O fluxo próprio das decisões obrigatórias do gestor não foi alterado.

## Validação
- Integridade do ZIP verificada com `ZipFile.testzip()` (sem erros).
- Contagem de recursos de imagem preservada: 30 arquivos event_*.webp.
- Compilação Android e testes instrumentados não executados neste ambiente (Gradle/gradlew não disponível).
- As taxas de largada ruim e perda de controle na chuva forte ainda não foram implementadas no motor nesta etapa.
