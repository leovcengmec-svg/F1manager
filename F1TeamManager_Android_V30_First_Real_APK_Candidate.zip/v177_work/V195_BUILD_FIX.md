V195 — Correção dos erros de compilação identificados no teste da V194

Base exclusiva: V194.
- Adicionado import de CircleShape usado nos retratos do comparativo.
- Corrigidas chamadas de SeasonStat para respeitar a assinatura existente (icon, label, value), preservando o peso e layout definidos dentro do componente.
- Incrementado versionCode/versionName para 195/0.195.0.
- Nome do ZIP preservado.
- ZIP validado estruturalmente; build Gradle não executado neste ambiente.
