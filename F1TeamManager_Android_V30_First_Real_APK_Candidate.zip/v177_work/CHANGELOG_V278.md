# V278 — Preservação de evolução em dados parciais

- Corrigida perda potencial de evolução: uma linha ausente/corrompida no armazenamento de atributos não reinicializa mais todos os pilotos.
- A leitura agora repara apenas os registros inválidos/ausentes, preserva linhas válidas, descarta IDs desconhecidos e limita valores ao intervalo 1–100.
- A serialização usa a mesma validação de sete atributos por piloto.
- Adicionados testes de regressão para armazenamento parcial, linha malformada e estado completo.
- Versão Android: `0.278.0` (código 278).
