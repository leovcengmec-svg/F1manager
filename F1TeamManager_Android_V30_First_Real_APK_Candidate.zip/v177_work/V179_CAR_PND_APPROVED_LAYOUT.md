# V179 — Reconstrução visual da tela Carro / P&D

- Reorganizada a hierarquia da tela para se aproximar da referência aprovada: banner do carro, cards dos dois carros com componentes em grade 3×2, indicadores de desempenho/confiabilidade, painel de Centro de P&D, pesquisa, designs concluídos e Fábrica.
- Os cards dos componentes exibem desempenho, confiabilidade e barras proporcionais azul/verde de forma mais legível.
- O Centro de P&D e a Fábrica receberam painéis escuros com acento vermelho e maior hierarquia de título/texto, sem criar ou substituir imagens.
- Pesquisa, fabricação, instalação, orçamento, limites simultâneos e demais regras do jogo continuam conectados aos motores existentes.
- Versão Gradle: 179 / 0.179.0.
- Verificação estática concluída; compilação Android e inspeção visual em dispositivo pendentes.
