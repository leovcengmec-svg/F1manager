# V159 — Atomicidade financeira e obrigações salariais

- Salários são obrigações integrais por temporada/GP; nunca são debitados parcialmente e descartados.
- Quando o caixa não cobre uma parcela, ela permanece em `salaryOutstanding`, persistida no save do jogador e no snapshot da IA.
- As obrigações pendentes são liquidadas em ordem cronológica assim que houver caixa; o marcador de GP pago só é gravado após quitação integral.
- Taxas de assinatura são tudo-ou-nada: saldo insuficiente não debita parcialmente nem registra cronograma de amortização. O fluxo de interface já verifica saldo antes de confirmar renovação/aceitação.
- Os lançamentos contábeis de amortização permanecem sem nova saída de caixa.
- Versão 0.159.0.
