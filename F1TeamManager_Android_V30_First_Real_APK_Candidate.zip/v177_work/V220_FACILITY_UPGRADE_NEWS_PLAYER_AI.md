# V220 — Notícias de melhoria de instalações para jogador e IA

- A equipe do jogador publica a notícia ao iniciar a obra e ao concluir as 12 semanas.
- As equipes IA publicam início e conclusão da obra, sem confundir início com aumento de nível concluído.
- Os eventos usam a categoria EVOLUÇÃO DE EQUIPES e o título uniforme `MELHORIA DE INSTALAÇÃO`.
- Mantido o calendário e o prazo de 12 semanas.
- Verificação estática apenas; build Android e teste de temporada ainda pendentes.
