# Auditoria V280

## Falha identificada
O commit atômico da V279/V276 ainda aceitava IDs de pilotos desconhecidos, arrays de atributos com tamanho inesperado e valores fora do limite, o que poderia corromper o estado persistido.

## Correção
- Validar IDs pela lista fixa de pilotos.
- Exigir sete atributos por piloto e limitar cada valor a 1–100.
- Persistir apenas overrides de classe válidos e associados a IDs conhecidos.
- Ignorar chaves de processamento vazias.
- Manter a gravação de atributos, classes e idempotência em uma transação.

## Verificações estáticas
- Verificado o guard `require(a.size == 7)`.
- Verificados limites `1..100`.
- Verificada filtragem por IDs conhecidos.
- Verificado um único `commit()` para os três campos.
- Compilação Android e teste instrumentado ainda pendentes.
