# V258 — Calendário anual de eventos

- Substitui a tentativa comum semanal por um calendário determinístico sorteado para a temporada.
- Sorteia a quantidade de eventos comuns dentro de limites moderados e atribui semanas específicas entre 2 e 56.
- Eventos especiais de investidor e mudança de classe, quando sorteados, recebem semana no calendário em vez de serem obrigatoriamente verificados na semana 1.
- Mantém o bloqueio das telas de classificação/corrida e as chaves de idempotência já existentes.
- O calendário é reproduzível com a mesma temporada e semente; a integração de persistência do calendário no repositório principal da carreira ainda precisa ser ligada para sobreviver a mudanças de seed no salvamento.
