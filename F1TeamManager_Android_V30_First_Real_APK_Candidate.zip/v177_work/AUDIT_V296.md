# Auditoria V296 — Cabeçalho da corrida e card de qualificação

- O clima foi separado do grupo que contém título, status e botão de pausa. Assim, mudanças de texto/clima não alteram a posição horizontal/vertical do botão.
- O botão de pausa ganhou margem superior fixa e altura constante.
- O selo de semana no banner da qualificação foi movido para uma linha própria abaixo do nome/circuito, evitando sobreposição com texto que aparece na imagem de fundo.
- A informação meteorológica continua sendo renderizada a partir de `s.weather` através de `weatherLabel`, para refletir o estado atual do motor.
- Verificações estáticas realizadas; build Android não executado neste ambiente.
