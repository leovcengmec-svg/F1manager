# Changelog V285

- Amplia a validação do fluxo de eventos anuais no avanço de calendário.
- Adiciona teste de acumulação de múltiplos slots para a mesma equipe.
- Adiciona testes de contrato para processamento semana a semana, ledger, persistência e Central de Notícias.
- Mantém o nome oficial do ZIP; versionCode 285 / versionName 0.285.0.
