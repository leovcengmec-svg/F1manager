# Auditoria V273 — ordem de persistência e idempotência

## Falha encontrada
O fluxo anual salvava carro, instalações e finanças antes de gravar as chaves de idempotência, mas a garagem física do jogador era salva somente depois de marcar as ocorrências. Um encerramento inesperado nesse intervalo poderia deixar a ocorrência marcada como concluída sem preservar os deltas nos dois carros físicos.

## Correção
`advanceFreeWeeks` agora chama `saveGarage` dentro da fase de persistência dos eventos, antes de publicar o ledger de ocorrências processadas. O salvamento final normal continua existindo como proteção adicional.

## Verificações executadas
- Conferida a ordem: `saveGarage` ocorre antes de `markAnnualEventKeysProcessed`.
- Conferidos `versionCode=273` e `versionName=0.273.0`.
- ZIP validado com `unzip -t` após empacotamento.

## Limitação
Não há Gradle instalado nem wrapper no pacote, então não foi possível executar build Android completo nem teste de execução no dispositivo.
