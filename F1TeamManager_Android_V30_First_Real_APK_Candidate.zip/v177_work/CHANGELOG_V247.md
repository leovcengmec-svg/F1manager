# V247 — Controle de pausa e decisões da corrida

- Todo diálogo ativo de corrida (decisão do manager, aviso de evento ou etapa de box) mantém a simulação pausada.
- Avisos de evento não podem ser fechados tocando fora nem pelo botão Voltar do Android; exigem o botão explícito de continuação.
- Removido o botão de fechar que escolhia `STAY_OUT` implicitamente no diálogo de decisão do manager.
- Decisões do manager têm prioridade visual sobre avisos informativos, evitando sobreposição de diálogos.
- A simulação retoma automaticamente depois que não há decisão, aviso enfileirado ou etapa de box pendente, caso estivesse em modo automático antes da interrupção.
- O limite de oito cards informativos por GP permanece; decisões obrigatórias do motor continuam independentes desse limite.
- Preservados os Assets, os históricos e as funcionalidades fora do escopo.
- Compilação Android não executada: o pacote não inclui Gradle Wrapper e não há Gradle instalado neste ambiente.
