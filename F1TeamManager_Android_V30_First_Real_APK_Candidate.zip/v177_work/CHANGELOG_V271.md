# V271 — Auditoria e integração efetiva dos eventos anuais

- Corrigida a contabilização de toda ocorrência vencida, inclusive evento sem efeito aplicável por limite de instalação; a ocorrência não fica pendente indefinidamente.
- Integrados os deltas de carro dos eventos anuais às duas unidades físicas do jogador, preservando peças instaladas e metadados do carro.
- Integrados os deltas persistidos de eventos anuais às duas unidades físicas das equipes de IA antes de montar a grade da corrida; antes, as alterações da IA ficavam apenas no armazenamento auxiliar e não chegavam ao motor de corrida.
- Adicionados testes unitários para propagação de deltas, confiabilidade, preservação de metadados e caso sem alteração.
- Versão do aplicativo: 0.271.0 (versionCode 271).
