# F1 Team Manager — V202 atualizado
- Front-end da tela de perfil do piloto revisado sobre a base fornecida.
- Preservados os dados reais do piloto, fotografia, logotipo da equipe, estatísticas de carreira,
  dados da temporada e histórico persistido.
- Sem alteração intencional no motor de simulação ou nos dados de domínio.
