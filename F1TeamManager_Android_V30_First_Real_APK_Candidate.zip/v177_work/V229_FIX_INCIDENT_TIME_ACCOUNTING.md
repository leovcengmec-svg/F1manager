# V229 — Correção da contabilização do tempo dos incidentes

Corrigido um problema de ordem de processamento identificado na revisão da V228: o motor recalcula `s.last` ao finalizar o tempo da volta. Por isso, aplicar a perda diretamente em `s.last` antes do cálculo não garantia que a volta exibida refletisse a penalidade.

Agora, as perdas por largada ruim e saída de pista na chuva forte são acumuladas em `incidentLossMs` e adicionadas ao tempo efetivo da volta antes de atualizar `s.total` e `s.last`. Se os dois incidentes ocorrerem na mesma volta, as perdas são somadas. Os eventos continuam associados ao piloto e usam as chaves de imagem já previstas.

Versão Android: 229 / 0.229.0.

Validação realizada: inspeção estática do fluxo e integridade do ZIP. Build Gradle/compilação e simulação estatística ainda não foram executados neste ambiente.
