# V170 — Correção do painel financeiro das equipes controladas pela IA

- Base: V169 oficial.
- Versionamento Android: `versionCode 170`, `versionName 0.170.0`.
- Causa raiz: `TeamOverviewBudgetCard` recebia `0L` para receita e despesa sempre que a equipe selecionada não era a equipe do jogador, apesar de `AITeamFinancialEngine` manter `seasonIncome` e `seasonExpenses` corretamente no ledger.
- Correção: `TeamOverviewSnapshot` agora carrega saldo, receita da temporada e despesa da temporada tanto para o jogador quanto para equipes IA. O card usa os valores do snapshot sem substituir os valores da IA por zero.
- Atualização de estado: a lista de estados financeiros da IA foi incluída nas chaves de `remember`, para que mudanças do ledger invalidem o snapshot e a tela não mantenha valores antigos.
- Preservação: nenhuma regra de receitas, despesas, P&D, salários, patrocínios, pesquisa, carros, calendário ou corrida foi alterada. Apenas a propagação e invalidação dos dados financeiros exibidos.
- Teste de regressão: incluído teste para garantir que o ledger da IA acumula receitas/despesas de corrida e reconhece o gasto de desenvolvimento.
- Limitação: validação Android completa depende do ambiente Gradle/Android; o pacote de origem não inclui Gradle Wrapper.
