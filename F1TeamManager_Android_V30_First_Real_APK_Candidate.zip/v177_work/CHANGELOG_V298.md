# Changelog V298
- Mentalidade de corrida agora é automática para pilotos da equipe do jogador e da IA.
- Interface substitui os botões manuais por indicador da mentalidade atual.
- Versão interna 0.298.0.
