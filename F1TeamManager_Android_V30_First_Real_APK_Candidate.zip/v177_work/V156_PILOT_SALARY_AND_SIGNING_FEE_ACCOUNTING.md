# V156 — Salários e taxa de assinatura dos pilotos

- Mantida a cobrança de salário por GP concluído: salário anual dividido por 30, com o resíduo no GP 30.
- Mantida a proteção contra saldo negativo: salários/taxas não pagos são registrados como bloqueados, nunca como caixa negativo.
- Taxa de assinatura continua sendo saída de caixa imediata e única; equipes de IA só registram a taxa como paga quando há saldo para quitá-la.
- Adicionado reconhecimento contábil informativo da taxa de assinatura em 30 GPs da temporada-alvo. O reconhecimento aumenta despesas contábeis, mas não reduz o caixa novamente. Os lançamentos usam marcadores de GP para impedir repetição.
- Histórico financeiro e marcadores de amortização agora são salvos/restaurados no save do jogador e no snapshot financeiro da IA, mantendo a idempotência após reiniciar o jogo.
- Atualização interna: versionCode 156 / versionName 0.156.0.

Validação realizada nesta entrega: inspeção estática das rotas de cobrança, integridade do ZIP e verificação dos metadados. Não foi possível afirmar compilação Android completa nem simulação integrada de 60 GPs nesta execução.
