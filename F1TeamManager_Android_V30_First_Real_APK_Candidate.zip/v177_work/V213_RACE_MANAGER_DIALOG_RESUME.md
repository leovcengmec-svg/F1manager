# V213 — Corrida retoma após seleção de BOX no Manager

- Corrigido o fluxo em que uma decisão do Manager oferecia a opção BOX e abria o seletor de pneus sem resolver a decisão pendente.
- Como a simulação só avança quando `s.decision == null`, fechar o seletor podia deixar a corrida parada apesar de `running = true`.
- Agora a opção BOX resolve primeiro a decisão pendente com `STAY_OUT` (sem executar pit stop automático) e abre o seletor para o usuário escolher plano/pneu manualmente. A seleção manual continua aplicando o pit stop normalmente.
- Incremento do app: versionCode 213, versionName 0.213.0.

Validação executada: inspeção do fluxo-fonte e teste de integridade do ZIP. Build Android e teste de corrida no dispositivo não foram executados neste ambiente.
