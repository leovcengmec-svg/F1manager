# Auditoria V292 — Cards de eventos anuais na Home

## Alteração
- A tela Home identifica notificações não lidas da categoria `ANNUAL_EVENTS`.
- Eventos anuais (incluindo regressão/evolução de piloto, alterações de equipe, instalações e eventos de gestão) aparecem num `AlertDialog` com aparência de card de aviso.
- Resultados de GP e aviso de nova temporada ficam excluídos deste modal para não duplicar os fluxos já existentes.
- O evento continua armazenado na Central de Notícias.
- Ações `CONTINUAR` e `VER NOTÍCIA` marcam apenas o evento atual como lido; a segunda abre a Central de Notícias.
- O modal aguarda a conclusão de instalação obrigatória da fábrica, evitando competir com esse diálogo.
- Preservados motores, dados, estatísticas, contratos e navegação existentes.

## Validação estática
- O Home consulta notificações `ANNUAL_EVENTS` e as chaves persistidas de leitura.
- O modal apresenta temporada, semana, título e mensagem reais da notificação.
- O estado de leitura é persistido via `CareerPreferences.markNewsRead`.
- ZIP íntegro e assets preservados.

## Limitação
A compilação Android e testes Kotlin/JUnit ainda precisam ser executados no ambiente Android/Gradle.
