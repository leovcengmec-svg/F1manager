# V233 — Pit stop exige decisão explícita

## Correção
- O seletor de pneus não pode ser fechado acidentalmente por toque fora ou botão Voltar do Android.
- Removido o X de fechamento que cancelava a parada sem confirmação.
- Mantida a opção explícita **SAIR • NÃO IR AO BOX**, para permitir ao usuário desistir conscientemente da parada.
- Mantidos os botões de confirmação de composto e de plano.

## Validação
- Foi adicionado `V233PitStopDialogRegressionTest`, com verificações automatizadas do contrato de não-dismiss e da opção explícita de cancelamento.
- O código ainda precisa ser compilado e o teste executado em ambiente com Gradle/Android SDK; não declarar validação de execução até isso ocorrer.
