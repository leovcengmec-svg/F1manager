# Auditoria V300 — Refinamento responsivo da tela Equipe

## Alterações no front-end real
- Orçamento: cards de receita/despesa mais compactos, com valores em uma linha e rótulos reduzidos para evitar colunas estreitas com quebras excessivas.
- Desempenho geral: métricas mantidas, com tipografia compacta e truncagem segura dos rótulos para evitar que o card fique excessivamente alto.
- Desempenho da temporada: substituída a faixa horizontal que cortava os últimos indicadores por uma grade responsiva de 4 colunas e 2 linhas, mantendo Posição, Pontos, Vitórias, Pódios, Poles, Voltas + rápidas, Corridas e DNFs visíveis.
- Mantido o fundo genérico da equipe e as seis imagens das instalações adicionadas na atualização anterior.
- Mantidos os dados, cálculos, ordem das seções, controles de navegação, histórico e rolagem vertical.

## Mapeamento
- Tela: `MainActivity.kt` / `TeamOverviewScreen`.
- Cards: `TeamOverviewBudgetCard`, `TeamOverviewGeneralCard`, `TeamOverviewSeason`.
- Imagens: `drawable-nodpi/team_card_generic_bg.webp` e `facility_*.webp`.

## Verificação
- Referências de drawable verificadas estaticamente.
- ZIP validado com `ZipFile.testzip()`.
- Build Android e validação visual no aparelho não executados neste ambiente.
