V202 — PERFIL DO PILOTO: REFINO VISUAL
Base oficial: V201.
- Aplicado o conjunto de ícones Material Icons Extended aos sete atributos, mantendo rótulos e valores ligados aos dados reais do piloto.
- Ajustado o alinhamento do título ATRIBUTOS à esquerda conforme o layout aprovado.
- Mantidos os cálculos, callbacks, histórico de temporada, fotografias, bandeiras e logos existentes.
- Atualizado versionCode para 202 e versionName para 0.202.0.
- O ZIP foi validado estruturalmente; a compilação Android precisa ser executada em ambiente com Gradle/Android SDK.
