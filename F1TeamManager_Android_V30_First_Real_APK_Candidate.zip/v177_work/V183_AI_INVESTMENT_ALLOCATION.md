# V183 — Política de investimento da IA

- Distribuição do teto anual: 80% para P&D/projeto e fabricação de componentes; até 20% para melhorias de instalações.
- A IA não inicia melhoria de instalação se ultrapassar o limite de 20%, o teto técnico compartilhado ou o caixa disponível.
- Obras já iniciadas continuam até a conclusão, respeitando 12 semanas e uma obra por equipe.
- Preservados os limites anuais por ranking e a contabilização existente. O limite não força gastos sem oportunidade adequada.
