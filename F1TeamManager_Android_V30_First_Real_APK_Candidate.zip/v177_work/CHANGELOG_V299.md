# Changelog V299
- Aplicado fundo genérico de equipe na tela real de visão da equipe.
- Criadas seis imagens genéricas para as instalações.
- Mantidos dados, navegação, níveis e regras funcionais.
- Versão interna 0.299.0.
