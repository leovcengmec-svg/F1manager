# F1 Team Manager V206 — classificação final e Central de Notícias
- A classificação usada para gerar a notícia do GP passa a ser reconstruída a partir das voltas concluídas e do tempo acumulado de corrida.
- A notícia de vencedor e pódio usa a mesma lista ordenada, com posições recalculadas, evitando divergência causada por posição desatualizada.
- Critério: mais voltas concluídas primeiro; em igualdade, menor tempo acumulado; desempate estável por ID do piloto.
- Mantém as regras anteriores e a identidade/nome permanente do ZIP.
- versionCode 206; versionName 0.206.0.
