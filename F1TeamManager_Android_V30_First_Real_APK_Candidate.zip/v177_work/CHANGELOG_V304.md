# Changelog V304

- Remove as ilustrações genéricas de carros dos cards Home e Equipe, incluindo a função Canvas sem uso.
- Aplica a imagem genérica `team_card_generic_bg` como fundo do card da equipe na Home.
- No card de Equipe, reduz os botões anterior/próximo para 28 dp e os posiciona nos cantos superiores esquerdo/direito.
- O nome da equipe usa uma linha e a largura disponível, sem quebra.
- Reorganiza Orçamento e Desempenho Geral: remove o bloco visual de Overall separado e apresenta Overall como linha compacta.
- Alinha labels e valores e inclui ícones em cada linha de orçamento e estatísticas gerais.
- Atualiza para `versionCode 304` / `versionName 0.304.0`.
