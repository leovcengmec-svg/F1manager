# V163 — Race root-cause fixes

Base: official V162 package. Official ZIP filename remains unchanged.

## Fixes
- Treat DRY and CLOUDY as dry-track conditions for AI tyre correction. AI cars found on INTERMEDIATE/WET in dry or cloudy conditions are moved to an appropriate slick compound at their next automatic tyre decision.
- Persist the manager's SAVE_FUEL decision for the current race driver state. Once selected, the fuel-critical intervention and recurring low-fuel card/alert are suppressed, while fuel simulation continues and strategy stays in DEFENSE.
- Calculate race gap by laps first. If a driver has completed fewer laps than the leader, store/display a lap deficit instead of subtracting total elapsed times and showing values such as thousands of seconds.
- Guard historical UI against absurd legacy gap values from earlier records.
- Correct low-fuel alert threshold to compare fuel percentage, not raw fuel kilograms.

## Regression tests added
- `V163WeatherFuelRootFixTest`: cloudy is dry and automatic slick selection returns only dry compounds.
- `V163GapDisplayTest`: different laps show lap deficit; same lap shows time gap.

## Validation status
Source-level changes and ZIP integrity can be checked in this environment. Android/Gradle build execution is not available because the ZIP does not include Gradle Wrapper and no Gradle installation is present; do not treat this package as an APK build-tested release until run through Android Gradle build/test.
