# V190 — Auditoria de layout e revisão interna

Base oficial: V189. Nome físico do ZIP preservado.

## Revisão de versão
- Corrigido o descompasso encontrado na auditoria: o pacote que se apresentava como V189 ainda declarava `versionCode = 183` e `versionName = 0.183.0`.
- Atualizado para `versionCode = 190` e `versionName = 0.190.0`.

## Conferência do código de UI

### Decisão do manager (V187/V188/V189)
- O código customizado está presente em `MainActivity.kt`: `Dialog` com conteúdo rolável, banner de Safety Car, card de piloto, composto/desgaste do pneu, voltas restantes e cards de ação.
- A ação BOX encaminha para o estado/fluxo de parada existente; outras ações chamam o manipulador de decisão existente.
- As referências de paleta usam os identificadores existentes `Red`, `Line` e `Panel2`; a pista seca usa `Weather.DRY`, que existe no enum do motor.

### Escolha de pneus no pit stop (V186)
- O registro da alteração existe e o código deve continuar sendo validado visualmente no dispositivo. Integridade de arquivo não comprova fidelidade geométrica à imagem aprovada.

### Plano de início da corrida (V185)
- O registro da alteração existe e o código deve continuar sendo validado visualmente no dispositivo. Integridade de arquivo não comprova fidelidade geométrica à imagem aprovada.

## Limites da auditoria
- O pacote não contém Gradle Wrapper (`gradlew`/`gradlew.bat`) e não há instalação local de Gradle disponível neste ambiente; portanto não foi possível executar `assembleDebug`.
- Não há screenshot novo de execução desta versão neste ambiente. A correspondência visual pixel a pixel com as referências não está certificada.
- Não declarar layout concluído somente com base na presença do código ou na integridade do ZIP.
