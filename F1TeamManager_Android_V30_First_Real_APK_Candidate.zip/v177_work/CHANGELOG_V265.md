# V265 — Scheduled team-event resolution

- Added a single deterministic resolver for scheduled team events affecting team snapshots: investor acquisition, financial crisis, car attributes, reliability, fire, earthquake and facility upgrade.
- Resolver is pure: it returns a result without mutating persistence. The caller must save the result before marking the slot processed.
- Driver attribute/class events remain delegated to driver-specific career state and are not handled by this team-snapshot resolver.
- Added unit tests for non-negative budget, facility bounds and driver-event delegation.
- This resolver is not yet wired into MainActivity's weekly career flow; no claim of end-to-end event execution.
- Android build and unit tests were not run.
