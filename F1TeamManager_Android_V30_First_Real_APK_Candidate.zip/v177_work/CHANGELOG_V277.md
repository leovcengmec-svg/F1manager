# V277 — Integração de classe de piloto na evolução

- Corrigido o desenvolvimento semanal para usar `store.currentDrivers()`, incluindo substituições de classe persistidas por eventos anuais.
- Corrigida a evolução pós-GP para calcular piso/teto usando a classe efetiva persistida, em vez da classe original da base.
- Mantidos o nome oficial do ZIP, assets e histórico de versões.

## Verificações
- As duas rotinas de evolução agora recebem/constroem definições com a classe efetiva.
- `versionCode=277`, `versionName=0.277.0`.
- Integridade do ZIP verificada após empacotamento.
- A compilação Android completa não foi executada neste ambiente.
