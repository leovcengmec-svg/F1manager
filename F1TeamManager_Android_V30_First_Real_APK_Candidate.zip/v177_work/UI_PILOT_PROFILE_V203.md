V203 — PADRONIZAÇÃO VISUAL DA TELA DE PILOTO
Base oficial: V202.
- Preservado o nome oficial do ZIP.
- Atualizado versionCode para 203 e versionName para 0.203.0.
- Padronizados tokens de cores de superfícies escuras e bordas no código da interface.
- Mantidos o estilo escuro/vermelho, dados dinâmicos e funcionalidades preexistentes.
- Integridade do ZIP verificada. Build Android não validado neste ambiente.
