# Auditoria V301 — Alertas anuais exclusivos da equipe do jogador

## Correção
- A Home agora só promove um evento anual a card/modal quando a notificação identifica a equipe do jogador ou um dos pilotos atuais dessa equipe.
- Os eventos das equipes de IA continuam sendo processados e armazenados na Central de Notícias, mas não aparecem como avisos prioritários na Home do jogador.
- Os avisos operacionais de P&D, fabricação, peça pronta, desenvolvimento de piloto e slot de patrocínio mantêm seus filtros existentes.
- Mantida a exclusão dos avisos de resultado de GP e nova temporada deste modal.

## Implementação
- Arquivo: `app/src/main/java/com/f1teammanager/MainActivity.kt`.
- Composable: `Home`.
- Versão: 0.301.0.

## Validação
- Verificação estática confirmou o filtro por nome da equipe e pilotos do jogador.
- ZIP validado com `ZipFile.testzip()`.
- Não foi possível compilar APK nem executar teste Android neste ambiente.
