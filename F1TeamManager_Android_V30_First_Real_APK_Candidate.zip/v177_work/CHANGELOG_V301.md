# Changelog V301
- Corrigida a exibição de avisos de eventos anuais na Home: apenas eventos da equipe/pilotos do jogador geram card.
- Eventos da IA continuam no histórico da Central de Notícias, sem modal na Home.
