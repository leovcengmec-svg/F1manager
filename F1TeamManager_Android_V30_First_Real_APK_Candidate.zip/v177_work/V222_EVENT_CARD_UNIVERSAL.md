# V222 — Card universal de eventos da corrida

- Base: pacote V221 (versionCode 221 / versionName 0.221.0).
- Incrementada a versão para 222 / 0.222.0.
- Criado componente visual reutilizável para eventos reais do motor: colisão, falha mecânica, desgaste, pit stop, ultrapassagem, volta rápida, VSC, Safety Car, bandeira vermelha, clima, abandono e volta invalidada.
- Eventos novos são enfileirados; a corrida pausa para leitura e o botão CONTINUAR CORRIDA fecha o card e retoma automaticamente quando não houver outra decisão ou modal bloqueante.
- Mantidos os diálogos de decisão do gestor e o fluxo de escolha de pneus existente.
- Validação: fonte e ZIP revisados; compilação Android não executada porque o pacote não contém Gradle Wrapper e não foi confirmado Gradle instalado neste ambiente. Teste visual em dispositivo ainda necessário.
