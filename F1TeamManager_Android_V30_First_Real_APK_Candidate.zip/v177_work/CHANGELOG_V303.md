# Changelog V303

- Corrige erro de compilação Kotlin no `when` que seleciona a arte das instalações.
- Adiciona ramo explícito `FacilityType.DRIVER_DEVELOPMENT`, usando a arte do simulador como fallback visual até existir arte dedicada.
- Preserva as categorias e funcionalidades existentes.
- Atualiza versão Android para `versionCode 303` / `versionName 0.303.0`.
