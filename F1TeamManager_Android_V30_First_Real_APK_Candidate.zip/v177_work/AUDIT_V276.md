# Auditoria V276

## Falha encontrada

A V275 persistia a substituição de classe de piloto imediatamente (`saveDriverClassOverride`) e só registrava as chaves dos eventos no fim da semana. Se o processo fosse encerrado entre essas operações, o evento continuaria pendente e poderia aplicar uma segunda mudança de classe no próximo avanço.

## Correção

A rotina de avanço mantém as mudanças de classe em memória até o fim do lote. `commitAnnualDriverStateAndKeys` persiste o mapa completo de atributos, as substituições de classe e o ledger de idempotência na mesma transação de SharedPreferences. Os efeitos de equipe e as notícias continuam sendo salvos antes desse commit final.

## Verificações executadas

- Verificação estática: nenhum `saveDriverClassOverride` chamado diretamente pelo fluxo de avanço anual.
- Verificação estática: o fluxo anual usa a transação conjunta para persistir atributos/classes/chaves.
- Verificação estática: `versionCode=276` e `versionName=0.276.0`.
- Integridade do ZIP verificada após empacotamento.

## Limitação

Não foi executada compilação completa Android nem teste instrumentado de encerramento forçado do processo. A correção é baseada em inspeção do caminho de persistência e verificações estáticas.
