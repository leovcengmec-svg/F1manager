# V174 — Qualification screen layout and reusable GP artwork

- Based on the official V173 project; kept the official ZIP filename unchanged.
- Updated the qualification GP card to use a reusable generic circuit/checkered-flag background image stored locally in `res/drawable-nodpi/qualifying_gp_background.jpg`.
- Kept the GP name, circuit, round, week, lap count and distance bound to the existing round data.
- Replaced the placeholder `GP` condition label with a readable weather-style status (`Tempo seco`) and sun symbol.
- Preserved the existing Q1/Q2/Q3 phase selectors, simulation/pause action, race-start action, simulation-speed controls, timer/progress logic and results table callbacks.
- Incremented Android version to 174 / 0.174.0.
- Archive integrity and static source checks are performed for this delivery. Android compilation/device tests are not claimed unless run in an Android SDK + Gradle environment.
