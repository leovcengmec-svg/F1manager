# V164 — Race root audit

- Centralized automatic tyre eligibility in `TyreModel.compoundForWeather`: cloudy/dry rejects wet compounds; light/medium rain corrects non-intermediate compounds to intermediate; heavy rain corrects non-Wet compounds to Wet.
- Both AI and automatic player tyre-plan pit choices apply the same canonical weather rule. Interactive session dry-start setup also corrects rain tyres.
- Nublado now uses the same fuel-weather factor as dry conditions.
- AI pit decisions no longer trigger a pit stop solely because fuel is low; this game does not support refuelling.
- Fuel-critical manager options no longer imply a pointless fuel-only pit stop.
- Interactive race engine no longer mislabels VSC/Safety Car as cloudy weather; neutralisation affects consumption through its own multiplier.
- Interactive fuel-low alert is latched and emitted once per session/driver, preventing repeated identical alerts every lap.
- Live Gap compares completed laps as well as cumulative times, and implausible time gaps are not shown as normal time deltas.
- Regression tests added for weather compound normalization, dry/cloudy fuel consistency, and no-refuel strategy.

Build/test execution still requires a Gradle installation and Android SDK; no claim of successful Android compilation is made here.
