# V226 — Integração visual das imagens de eventos

- Mantém as 30 imagens genéricas em `app/src/main/res/drawable-nodpi`.
- O card universal passa a exibir uma imagem no padrão escuro/vermelho aprovado.
- A imagem é escolhida por tipo de evento e por palavras-chave do detalhe já emitido pelo motor; o texto e as consequências continuam vindo do evento real.
- Mantém o botão de continuar e o fluxo atual de fechamento do card.
- Versão Android: 0.226.0 / versionCode 226.
- Ainda exige compilação e testes em dispositivo para homologação.
