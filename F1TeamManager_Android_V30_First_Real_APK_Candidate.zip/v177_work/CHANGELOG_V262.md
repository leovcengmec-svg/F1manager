# V262 — Inicialização do calendário anual no avanço semanal

- Base: V261.
- O fluxo de avanço semanal agora garante que o calendário anual de eventos esteja materializado antes de processar semanas.
- A semente é estável por temporada e a persistência existente evita novo sorteio ao carregar a carreira.
- Saltos de várias semanas não geram calendários alternativos.
- Não marca eventos como processados nem publica notícias sem aplicar efeitos.
- Pendência explícita: integrar a aplicação transacional dos efeitos a todas as equipes e a apresentação dos cartões na carreira.
- Testes de compilação e execução Android não realizados neste ambiente.
