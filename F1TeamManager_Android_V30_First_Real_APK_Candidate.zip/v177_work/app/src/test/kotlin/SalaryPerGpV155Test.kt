import com.f1teammanager.core.manager.*
import org.junit.Assert.*
import org.junit.Test

class SalaryPerGpV155Test {
    @Test fun salaryIsPaidInThirtyInstallmentsAndRemainderOnGp30() {
        val market = DriverMarketEngine().initialState(2026)
        val state = TeamManagerState(
            season=2026, round=1, playerTeamId=1,
            car=TeamCarState(50, 50, 50, 50),
            finance=TeamFinanceState(100_000_000L), driverMarket=market
        )
        val noContracts = state.copy(driverMarket=market.copy(contracts=emptyList()))
        assertEquals(100_000_000L, FinanceEngine().applyDriverSalariesForRace(noContracts, 2026, 1).finance.budget)
    }

    @Test fun salaryDebitNeverMakesPlayerCashNegative() {
        val market = DriverMarketEngine().initialState(2026)
        val state = TeamManagerState(
            season=2026, round=1, playerTeamId=1,
            car=TeamCarState(50, 50, 50, 50),
            finance=TeamFinanceState(0L), driverMarket=market
        )
        assertTrue(FinanceEngine().applyDriverSalariesForRace(state, 2026, 1).finance.budget >= 0L)
    }
}
