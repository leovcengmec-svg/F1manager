import com.f1teammanager.core.manager.DriverMarketEngine
import com.f1teammanager.core.manager.DriverTeamRole
import com.f1teammanager.core.manager.NegotiationStatus
import com.f1teammanager.core.season.WorldDatabase
import org.junit.Assert.assertTrue
import org.junit.Test

class DriverMarketProposalEventsV407Test {
    @Test fun `player proposal creates visible sent event and later response event`() {
        val engine = DriverMarketEngine(4072026)
        var state = engine.initialState(2026)
        val playerTeamId = WorldDatabase.teams.first().id
        val driverId = WorldDatabase.allDrivers.first { engine.canReceiveProposals(state, it.id, 2026) }.id

        val (afterOffer, offer) = engine.makeOffer(
            state = state,
            driverId = driverId,
            toTeamId = playerTeamId,
            years = 2,
            salary = engine.salaryFor(driverId),
            role = DriverTeamRole.EQUAL,
            season = 2026,
            currentWeek = 10,
            proposerTeamId = playerTeamId
        )
        state = afterOffer
        assertTrue(state.notifications.any { it.title == "PROPOSTA ENVIADA" && it.week == 10 })

        state = engine.expireOffers(state, offer.expiresAfterWeek, 2026, playerTeamId)
        assertTrue(
            "A resposta da proposta precisa virar notícia persistida",
            state.notifications.any {
                it.week == offer.expiresAfterWeek && it.title in setOf(
                    "CONTRATO ASSINADO", "CONTRAPROPOSTA RECEBIDA", "PROPOSTA RECUSADA", "PROPOSTA NÃO CONCLUÍDA"
                )
            }
        )
        assertTrue("A proposta não pode continuar pendente depois de uma resposta terminal/counteroffer", state.pending.none {
            it.driverId == driverId && it.toTeamId == playerTeamId && it.status == NegotiationStatus.PENDING
        })
    }

    @Test fun `weekly market processing expires player proposals while jumping multiple weeks`() {
        val engine = DriverMarketEngine(4072027)
        var state = engine.initialState(2026)
        val playerTeamId = WorldDatabase.teams.first().id
        val driverId = WorldDatabase.allDrivers.first { engine.canReceiveProposals(state, it.id, 2026) }.id
        val (offered, offer) = engine.makeOffer(
            state, driverId, playerTeamId, 2, engine.salaryFor(driverId), DriverTeamRole.EQUAL,
            2026, 10, 1, null, playerTeamId
        )
        state = offered
        for (week in 11..offer.expiresAfterWeek) state = engine.processAiMarketWeek(state, 2026, week, playerTeamId)
        assertTrue("O salto semanal precisa processar a resposta dentro do prazo", state.notifications.any {
            it.week <= offer.expiresAfterWeek && it.title in setOf(
                "CONTRATO ASSINADO", "CONTRAPROPOSTA RECEBIDA", "PROPOSTA RECUSADA", "PROPOSTA NÃO CONCLUÍDA"
            )
        })
    }
}
