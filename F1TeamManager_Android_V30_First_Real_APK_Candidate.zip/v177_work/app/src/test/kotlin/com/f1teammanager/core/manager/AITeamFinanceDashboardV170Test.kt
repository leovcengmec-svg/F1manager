package com.f1teammanager.core.manager

import com.f1teammanager.core.season.WorldDatabase
import org.junit.Test
import kotlin.test.assertTrue

class AITeamFinanceDashboardV170Test {
    @Test
    fun `AI race and development transactions are reflected in seasonal ledger`() {
        val team = WorldDatabase.teams.first()
        val market = DriverMarketState()
        val engine = AITeamFinancialEngine(170)
        val initial = engine.beginSeason(team.id, 2026, market).finance
        val sponsorship = TeamSponsorshipEngine.TeamSponsorshipState(
            teamId = team.id,
            season = 2026,
            sponsors = emptyList(),
            annualGuaranteedIncome = 0L
        )

        val afterRace = engine.applyRace(team.id, 2026, 1, sponsorship, market, bestFinish = 5, points = 0).finance
        assertTrue(afterRace.seasonIncome > initial.seasonIncome, "Premiação de corrida deve entrar em receitas")
        assertTrue(afterRace.seasonExpenses > initial.seasonExpenses, "Custos de corrida devem entrar em despesas")

        val beforeDevelopmentExpenses = afterRace.seasonExpenses
        val capacity = engine.developmentCapacity(team.id, 2026)
        val requestedSpend = minOf(2_000_000L, capacity)
        if (requestedSpend > 0L) {
            engine.applyDevelopmentCost(team.id, 2026, capacity - requestedSpend, capacity)
            val afterDevelopment = engine.state(team.id, 2026).finance
            assertTrue(afterDevelopment.seasonExpenses > beforeDevelopmentExpenses, "Gasto de P&D deve entrar em despesas da temporada")
        }
    }
}
