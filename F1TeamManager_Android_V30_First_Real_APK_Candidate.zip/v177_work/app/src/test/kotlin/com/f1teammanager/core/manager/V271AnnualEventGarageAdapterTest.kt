package com.f1teammanager.core.manager

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNotEquals

class V271AnnualEventGarageAdapterTest {
    @Test fun eventDeltasReachBothPhysicalCarsAndPreservePieceMetadata() {
        val team = com.f1teammanager.core.season.WorldDatabase.teams.first()
        val before = InitialTeamProfile.carState(team)
        val garage = TeamGarageFactory.fromCarState(before, team.id, 1)
        val after = before.copy(engine = (before.engine + 3).coerceAtMost(100), reliability = (before.reliability - 2).coerceAtLeast(1))
        val changed = AnnualEventGarageAdapter.applyDelta(garage, before, after)
        assertEquals((garage.car1.engine + 3).coerceAtMost(100), changed.car1.engine)
        assertEquals((garage.car2.engine + 3).coerceAtMost(100), changed.car2.engine)
        assertEquals((garage.car1.reliability - 2).coerceAtLeast(1), changed.car1.reliability)
        assertEquals(garage.car1.installedPieces, changed.car1.installedPieces)
        assertEquals(garage.car2.installedPieceVersions, changed.car2.installedPieceVersions)
    }

    @Test fun noDeltaLeavesGarageUnchanged() {
        val team = com.f1teammanager.core.season.WorldDatabase.teams.first()
        val car = InitialTeamProfile.carState(team)
        val garage = TeamGarageFactory.fromCarState(car, team.id, 1)
        assertEquals(garage, AnnualEventGarageAdapter.applyDelta(garage, car, car))
    }
}
