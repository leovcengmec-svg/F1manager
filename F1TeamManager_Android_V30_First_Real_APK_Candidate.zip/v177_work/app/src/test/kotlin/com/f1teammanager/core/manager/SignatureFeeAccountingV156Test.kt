package com.f1teammanager.core.manager

object SignatureFeeAccountingV156Test {
    @JvmStatic fun main(args: Array<String>) {
        val starting = TeamFinanceState(
            budget = 50_000_000L,
            transactions = listOf("-12000000:Taxa de assinatura — transferência de Piloto 42 — 2027")
        )
        val gp1 = SignatureFeeAccounting.recognizeForRace(starting, 2027, 1)
        check(gp1.budget == starting.budget) { "Amortization must not debit cash a second time" }
        check(gp1.transactions.any { it.contains("€400000") && it.contains("sem nova saída de caixa") })
        val repeatedGp1 = SignatureFeeAccounting.recognizeForRace(gp1, 2027, 1)
        check(repeatedGp1.transactions.size == gp1.transactions.size) { "Same GP amortization must be idempotent" }
        val gp2 = SignatureFeeAccounting.recognizeForRace(gp1, 2027, 2)
        check(gp2.budget == starting.budget)
        check(gp2.transactions.count { it.contains("AMORTIZAÇÃO TAXA ASSINATURA") } == 2)
        val wrongSeason = SignatureFeeAccounting.recognizeForRace(starting, 2026, 1)
        check(wrongSeason.transactions.none { it.contains("AMORTIZAÇÃO TAXA ASSINATURA") })
        println("PASS: signing fee accounting recognizes one installment per GP without another cash debit")
    }
}
