package com.f1teammanager.core.manager

import org.junit.Assert.*
import org.junit.Test

class FinancialObligationV159Test {
    private fun state(cash: Long) = TeamManagerState(
        season = 2027,
        round = 1,
        playerTeamId = 7,
        car = TeamCarState(60, 60, 60, 60),
        finance = TeamFinanceState(cash),
        driverMarket = DriverMarketState(contracts = listOf(
            DriverDeal(driverId = 1, teamId = 7, years = 2, salary = 30_000_000L, marketValue = 10_000_000L, seasonSigned = 2027)
        ))
    )

    @Test fun unpaidSalaryIsNotPartiallyChargedOrMarkedPaidAndCanBeSettledLater() {
        val engine = FinanceEngine()
        val unpaid = engine.applyDriverSalariesForRace(state(500_000L), 2027, 1)
        assertEquals(500_000L, unpaid.finance.budget)
        assertFalse("2027:1" in unpaid.finance.salaryPaidRounds)
        assertEquals(1_000_000L, unpaid.finance.salaryOutstanding["2027:1"])

        val funded = unpaid.copy(finance = unpaid.finance.copy(budget = 1_500_000L))
        val paid = engine.applyDriverSalariesForRace(funded, 2027, 1)
        assertEquals(500_000L, paid.finance.budget)
        assertTrue("2027:1" in paid.finance.salaryPaidRounds)
        assertFalse("2027:1" in paid.finance.salaryOutstanding)
        val repeated = engine.applyDriverSalariesForRace(paid, 2027, 1)
        assertEquals(paid.finance.budget, repeated.finance.budget)
    }

    @Test fun signatureFeeIsAtomicWhenCashIsInsufficient() {
        val initial = TeamFinanceState(500_000L)
        val after = FinanceEngine().applySignatureFee(initial, 1_000_000L, "Taxa de assinatura — transferência — 2028")
        assertEquals(500_000L, after.budget)
        assertTrue(after.signatureFeeSchedules.isEmpty())
        assertFalse(after.transactions.any { it.startsWith("-1000000:") })
    }

    @Test fun signatureFeeIsChargedOnceAndAmortizedWithoutCashDebit() {
        val initial = TeamFinanceState(5_000_000L)
        val signed = FinanceEngine().applySignatureFee(initial, 3_000_000L, "Taxa de assinatura — transferência — 2028")
        assertEquals(2_000_000L, signed.budget)
        assertEquals(1, signed.signatureFeeSchedules.size)
        val gp1 = SignatureFeeAccounting.recognizeForRace(signed, 2028, 1)
        val repeated = SignatureFeeAccounting.recognizeForRace(gp1, 2028, 1)
        assertEquals(2_000_000L, repeated.budget)
        assertEquals(setOf(1), repeated.signatureFeeSchedules.single().recognizedRounds)
    }
}
