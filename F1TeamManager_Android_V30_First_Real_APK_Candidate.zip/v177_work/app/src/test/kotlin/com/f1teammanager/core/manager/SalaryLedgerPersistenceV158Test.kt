package com.f1teammanager.core.manager

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

class SalaryLedgerPersistenceV158Test {
    @Test fun salaryIdempotencyDoesNotDependOnBoundedTransactionHistory() {
        val oldHistory = (1..120).map { "-1:old transaction $it" }
        val initial = TeamManagerState(
            season = 2027,
            round = 1,
            playerTeamId = 7,
            car = TeamCarState(aerodynamics = 60, chassis = 60, engine = 60, reliability = 60),
            finance = TeamFinanceState(budget = 100_000_000L, transactions = oldHistory),
            driverMarket = DriverMarketState(contracts = listOf(
                DriverDeal(driverId = 1, teamId = 7, years = 2, salary = 30_000_000L, marketValue = 10_000_000L, seasonSigned = 2027)
            ))
        )
        val engine = FinanceEngine()
        val first = engine.applyDriverSalariesForRace(initial, 2027, 1)
        assertEquals(99_000_000L, first.finance.budget)
        assertTrue("2027:1" in first.finance.salaryPaidRounds)
        val repeated = engine.applyDriverSalariesForRace(first, 2027, 1)
        assertEquals(first.finance.budget, repeated.finance.budget)
        assertEquals(first.finance.transactions, repeated.finance.transactions)
        assertEquals(first.finance.salaryPaidRounds, repeated.finance.salaryPaidRounds)
    }

    @Test fun distinctRaceKeysAreRecordedIndependently() {
        val base = TeamManagerState(
            season = 2027, round = 1, playerTeamId = 7,
            car = TeamCarState(aerodynamics = 60, chassis = 60, engine = 60, reliability = 60),
            finance = TeamFinanceState(budget = 100_000_000L),
            driverMarket = DriverMarketState(contracts = listOf(
                DriverDeal(driverId = 1, teamId = 7, years = 2, salary = 30_000_000L, marketValue = 10_000_000L, seasonSigned = 2027)
            ))
        )
        val engine = FinanceEngine()
        val gp1 = engine.applyDriverSalariesForRace(base, 2027, 1)
        val gp2 = engine.applyDriverSalariesForRace(gp1, 2027, 2)
        assertEquals(setOf("2027:1", "2027:2"), gp2.finance.salaryPaidRounds)
        assertEquals(98_000_000L, gp2.finance.budget)
    }
}
