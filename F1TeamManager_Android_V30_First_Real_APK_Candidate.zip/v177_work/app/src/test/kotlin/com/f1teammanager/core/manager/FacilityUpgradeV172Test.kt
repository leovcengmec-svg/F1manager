package com.f1teammanager.core.manager

import org.junit.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith
import kotlin.test.assertNull

class FacilityUpgradeV172Test {
    private fun state(): TeamManagerState {
        val car = TeamCarState(aerodynamics=70, chassis=70, engine=70, reliability=90)
        val finance = TeamFinanceState(budget=200_000_000L)
        return TeamManagerState(car=car, facilities=FacilityEngine.initial(2), finance=finance,
            playerTeamId=1, technicalInvestment=TechnicalInvestmentEngine.create(2026, 40))
    }

    @Test fun levelDoesNotIncreaseUntilWeekTwelveAndCostIsChargedOnce() {
        val initial = state()
        val started = FacilityEngine.upgrade(initial, FacilityType.FACTORY, 5)
        assertEquals(2, started.facilities.level(FacilityType.FACTORY))
        assertEquals(178_000_000L, started.finance.budget)
        assertEquals(12, started.facilityUpgrade?.remainingWeeks)
        val eleven = FacilityEngine.advanceUpgrade(started, 11).first
        assertEquals(2, eleven.facilities.level(FacilityType.FACTORY))
        assertEquals(1, eleven.facilityUpgrade?.remainingWeeks)
        val (completed, didComplete) = FacilityEngine.advanceUpgrade(eleven, 1)
        assertEquals(true, didComplete)
        assertEquals(3, completed.facilities.level(FacilityType.FACTORY))
        assertNull(completed.facilityUpgrade)
        assertEquals(178_000_000L, completed.finance.budget)
    }

    @Test fun onlyOneFacilityUpgradeCanBeActiveAndItCannotBeCancelledThroughEngine() {
        val started = FacilityEngine.upgrade(state(), FacilityType.FACTORY, 1)
        assertFailsWith<IllegalArgumentException> { FacilityEngine.upgrade(started, FacilityType.RESEARCH, 1) }
        assertEquals(FacilityType.FACTORY, started.facilityUpgrade?.facility)
    }

    @Test fun insufficientCashOrTechnicalCapBlocksStartWithoutChangingLevel() {
        val lowCash = state().copy(finance=TeamFinanceState(budget=1L))
        assertFailsWith<IllegalArgumentException> { FacilityEngine.upgrade(lowCash, FacilityType.FACTORY, 1) }
        assertEquals(2, lowCash.facilities.level(FacilityType.FACTORY))
    }
}
