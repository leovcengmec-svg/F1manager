package com.f1teammanager.core.manager

import org.junit.Assert.*
import org.junit.Test

class FinancialObligationV160Test {
    @Test fun signatureFeesAreAtomicAndRepeatedRegistrationDoesNotDebitCashAgain() {
        val engine = FinanceEngine()
        val start = TeamFinanceState(10_000_000L)
        val first = engine.applySignatureFee(start, 6_000_000L, "Taxa de assinatura piloto A — 2028")
        assertEquals(4_000_000L, first.budget)
        val rejected = engine.applySignatureFee(first, 5_000_000L, "Taxa de assinatura piloto B — 2028")
        assertEquals(4_000_000L, rejected.budget)
        assertTrue(rejected.signatureFeeSchedules.none { it.amount == 5_000_000L })
        val repeated = engine.applySignatureFee(first, 6_000_000L, "Taxa de assinatura piloto A — 2028")
        assertEquals(4_000_000L, repeated.budget)
    }

    @Test fun salaryObligationSurvivesInsufficientCashAndIsSettledOnceWhenFunded() {
        val state = TeamManagerState(
            season = 2027, round = 1, playerTeamId = 7,
            car = TeamCarState(60, 60, 60, 60),
            finance = TeamFinanceState(500_000L),
            driverMarket = DriverMarketState(contracts = listOf(
                DriverDeal(driverId = 1, teamId = 7, years = 2, salary = 30_000_000L, marketValue = 10_000_000L, seasonSigned = 2027)
            ))
        )
        val engine = FinanceEngine()
        val unpaid = engine.applyDriverSalariesForRace(state, 2027, 1)
        assertEquals(1_000_000L, unpaid.finance.salaryOutstanding["2027:1"])
        assertFalse("2027:1" in unpaid.finance.salaryPaidRounds)
        val funded = unpaid.copy(finance = unpaid.finance.copy(budget = 1_500_000L))
        val paid = engine.applyDriverSalariesForRace(funded, 2027, 1)
        assertEquals(500_000L, paid.finance.budget)
        assertTrue("2027:1" in paid.finance.salaryPaidRounds)
        assertFalse("2027:1" in paid.finance.salaryOutstanding)
        assertEquals(paid.finance.budget, engine.applyDriverSalariesForRace(paid, 2027, 1).finance.budget)
    }
}
