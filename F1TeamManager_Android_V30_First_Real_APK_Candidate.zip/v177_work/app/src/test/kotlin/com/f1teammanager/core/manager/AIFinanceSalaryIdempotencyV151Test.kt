package com.f1teammanager.core.manager

import com.f1teammanager.core.season.WorldDatabase

object AIFinanceSalaryIdempotencyV151Test {
    @JvmStatic fun main(args: Array<String>) {
        val team = WorldDatabase.teams.first()
        val other = WorldDatabase.teams.first { it.id != team.id }
        val market = DriverMarketState(contracts = listOf(
            DriverDeal(driverId = 1, teamId = other.id, years = 3, salary = 12_000_000L, marketValue = 20_000_000L, seasonSigned = 2026)
        ))
        val engine = AITeamFinancialEngine(151)
        val first = engine.beginSeason(other.id, 2026, market)
        val second = engine.beginSeason(other.id, 2026, market)
        check(first.finance.budget == second.finance.budget) { "Annual salary charged more than once in same season" }
        check(second.finance.transactions.count { it.contains("Salários anuais") } == 1)
        val restored = AITeamFinancialEngine(151).also { it.restoreSnapshot(engine.exportSnapshot()) }
        val third = restored.beginSeason(other.id, 2026, market)
        check(third.finance.budget == second.finance.budget) { "Annual salary repeated after snapshot restore" }
        check(third.finance.budget == second.finance.budget) { "Salary ledger was not restored" }
        val next = restored.beginSeason(other.id, 2027, market)
        check(next.finance.budget == third.finance.budget - 12_000_000L) { "Salary must be charged once again in new active season" }
        println("PASS: annual salary once per team-season; snapshot restore idempotent; new season charged once")
    }
}
