package com.f1teammanager.core.manager

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SignatureFeeAccountingV157Test {
    @Test fun registeredScheduleSurvivesTransactionHistoryTruncation() {
        val fee = 12_000_000L
        val signed = FinanceEngine().applySignatureFee(
            TeamFinanceState(50_000_000L), fee,
            "Taxa de assinatura — transferência de Piloto 42 — 2027"
        )
        assertEquals(38_000_000L, signed.budget)
        assertEquals(1, signed.signatureFeeSchedules.size)
        val agedHistory = signed.copy(transactions=(1..150).map { "0:evento $it" }.takeLast(100))
        val first = SignatureFeeAccounting.recognizeForRace(agedHistory, 2027, 1)
        assertEquals(38_000_000L, first.budget)
        assertTrue(first.transactions.any { it.contains("€400000") })
        assertEquals(setOf(1), first.signatureFeeSchedules.single().recognizedRounds)
    }

    @Test fun installmentsAreIdempotentAndReconcileToFullFee() {
        val signed = FinanceEngine().applySignatureFee(
            TeamFinanceState(50_000_000L), 12_000_017L,
            "Taxa de assinatura — transferência de Piloto 42 — 2027"
        )
        var state = signed
        var recognized = 0L
        for (gp in 1..30) {
            state = SignatureFeeAccounting.recognizeForRace(state, 2027, gp)
            val line = state.transactions.last { it.contains("AMORTIZAÇÃO TAXA ASSINATURA") && it.contains("GP $gp/30") }
            recognized += Regex("€(\\d+)").find(line)?.groupValues?.get(1)?.toLong() ?: 0L
            val repeat = SignatureFeeAccounting.recognizeForRace(state, 2027, gp)
            assertEquals(state.signatureFeeSchedules.single().recognizedRounds, repeat.signatureFeeSchedules.single().recognizedRounds)
            assertEquals(state.budget, repeat.budget)
            state = repeat
        }
        assertEquals(12_000_017L, recognized)
        assertEquals(38_000_000L, state.budget)
    }

    @Test fun scheduleOnlyRecognizesItsTargetSeason() {
        val signed = FinanceEngine().applySignatureFee(
            TeamFinanceState(50_000_000L), 9_000_000L,
            "Taxa de assinatura de Piloto — 2028"
        )
        val wrongSeason = SignatureFeeAccounting.recognizeForRace(signed, 2027, 1)
        assertTrue(wrongSeason.signatureFeeSchedules.single().recognizedRounds.isEmpty())
        val rightSeason = SignatureFeeAccounting.recognizeForRace(wrongSeason, 2028, 1)
        assertEquals(setOf(1), rightSeason.signatureFeeSchedules.single().recognizedRounds)
    }
}
