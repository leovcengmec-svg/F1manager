package com.f1teammanager.core.manager

import com.f1teammanager.core.season.WorldDatabase

object AIFinanceGuardV152Test {
    @JvmStatic fun main(args: Array<String>) {
        val teams = WorldDatabase.teams
        val playerTeam = teams.first().id
        val aiTeams = teams.filter { it.id != playerTeam }
        val market = DriverMarketEngine().initialState(2026)
        val finance = AITeamFinancialEngine(152)

        finance.ensureAllTeams(2026, playerTeam, market)
        check(finance.allStates().all { it.finance.budget >= 0L })

        // Force annual obligations to exceed the opening cash: the ledger must never go negative.
        val poorTeam = aiTeams.first().id
        val hugeSalaryMarket = DriverMarketState(contracts = listOf(
            DriverDeal(driverId = 999, teamId = poorTeam, years = 3, salary = 500_000_000L, marketValue = 1L, seasonSigned = 2026)
        ))
        val salaryGuard = AITeamFinancialEngine(153)
        val afterSalary = salaryGuard.beginSeason(poorTeam, 2026, hugeSalaryMarket)
        check(afterSalary.finance.budget >= 0L) { "Salary debit caused negative cash" }
        check(afterSalary.finance.transactions.any { it.contains("BLOQUEADO/INSUFICIENTE") })

        // Across all AI teams, cumulative annual technical investment must stay under the frozen rank cap.
        aiTeams.forEach { team ->
            val s = finance.state(team.id, 2026)
            val investment = finance.technicalInvestment(team.id, 2026)
            check(investment.totalSpent <= investment.annualCap) { "Annual cap exceeded for ${team.id}" }
            check(s.finance.budget >= 0L) { "Negative cash for ${team.id}" }
        }

        // Race expenses and repeated development requests cannot drive the ledger below zero
        // or exceed the rank-specific annual cap.
        val sponsorship = TeamSponsorshipEngine.TeamSponsorshipState(teamId = poorTeam, season = 2026, sponsors = emptyList(), annualGuaranteedIncome = 0L)
        repeat(60) { round ->
            val afterRace = finance.applyRace(poorTeam, 2026, round + 1, sponsorship, hugeSalaryMarket, 80, 0)
            check(afterRace.finance.budget >= 0L) { "Race costs caused negative cash" }
            val capacity = finance.developmentCapacity(poorTeam, 2026)
            val simulatedAfter = (capacity - 50_000_000L).coerceAtLeast(0L)
            finance.applyDevelopmentCost(poorTeam, 2026, simulatedAfter, capacity)
            val afterDev = finance.state(poorTeam, 2026)
            val investment = finance.technicalInvestment(poorTeam, 2026)
            check(afterDev.finance.budget >= 0L) { "Development caused negative cash" }
            check(investment.totalSpent <= investment.annualCap) { "Annual technical cap exceeded" }
        }

        val restored = AITeamFinancialEngine(152).also { it.restoreSnapshot(finance.exportSnapshot()) }
        aiTeams.forEach { team ->
            val state = restored.state(team.id, 2026)
            val investment = restored.technicalInvestment(team.id, 2026)
            check(state.finance.budget >= 0L)
            check(investment.totalSpent <= investment.annualCap)
        }
        println("PASS: AI cash never negative; salary/race/development guards; annual technical cap and snapshot persistence")
    }
}
