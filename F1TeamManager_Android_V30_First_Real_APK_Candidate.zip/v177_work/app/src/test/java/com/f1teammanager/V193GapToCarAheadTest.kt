package com.f1teammanager

import org.junit.Assert.assertEquals
import org.junit.Test

class V193GapToCarAheadTest {
    @Test fun gapIsComputedAgainstImmediateCarAhead() {
        // P2 vs P1: +1.250s, not the cumulative gap to P1 if this were P10.
        assertEquals(1_250L, raceGapMs(50, 10_001_250L, 50, 10_000_000L))
        // P10 vs P9 and P4 vs P3 use the same adjacent-car rule.
        assertEquals(420L, raceGapMs(50, 10_000_420L, 50, 10_000_000L))
        assertEquals(85L, raceGapMs(50, 10_000_085L, 50, 10_000_000L))
    }

    @Test fun adjacentCarOneLapAheadShowsLapDifference() {
        assertEquals(-1L, raceGapMs(49, 10_000_000L, 50, 9_500_000L))
        assertEquals("+1 VOLTA", formatGap(-1L))
    }
}
