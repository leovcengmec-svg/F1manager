package com.f1teammanager.core.manager

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class V259AnnualCalendarStressRegressionTest {
    @Test fun manySeedsAndSeasonsRespectAnnualEventLimits() {
        for (season in 2026..2035) {
            for (seed in 0..100) {
                val slots = AnnualTeamEventSeasonCalendar.generate(season, seed)
                assertTrue("week outside season: $season/$seed", slots.all { it.week in 1..56 })
                assertEquals("duplicate week: $season/$seed", slots.size, slots.map { it.week }.distinct().size)
                assertTrue(slots.count { it.kind == AnnualTeamEventEngine.Kind.FINANCIAL_CRISIS } <= 2)
                assertTrue(slots.count { it.kind in setOf(AnnualTeamEventEngine.Kind.FIRE, AnnualTeamEventEngine.Kind.EARTHQUAKE) } <= 1)
                assertTrue(slots.count { it.kind == AnnualTeamEventEngine.Kind.INVESTOR_ACQUISITION } <= 1)
                assertTrue(slots.count { it.kind == AnnualTeamEventEngine.Kind.DRIVER_CLASS_CHANGE } <= 1)
                assertTrue(slots.count { it.kind in setOf(AnnualTeamEventEngine.Kind.CAR_GAIN, AnnualTeamEventEngine.Kind.CAR_LOSS, AnnualTeamEventEngine.Kind.RELIABILITY_GAIN, AnnualTeamEventEngine.Kind.RELIABILITY_LOSS) } in 1..3)
                assertTrue(slots.count { it.kind == AnnualTeamEventEngine.Kind.FACILITY_UPGRADE } <= 2)
                assertTrue(slots.count { it.kind in setOf(AnnualTeamEventEngine.Kind.DRIVER_GAIN, AnnualTeamEventEngine.Kind.DRIVER_LOSS) } <= 2)
                assertEquals(slots, AnnualTeamEventSeasonCalendar.generate(season, seed))
            }
        }
    }
}
