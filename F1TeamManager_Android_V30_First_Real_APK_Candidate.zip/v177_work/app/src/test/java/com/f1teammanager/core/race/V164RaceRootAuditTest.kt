package com.f1teammanager.core.race

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class V164RaceRootAuditTest {
    @Test fun cloudyAlwaysRejectsWetCompoundsInAutomaticSelection() {
        assertEquals(Tyre.MEDIUM, TyreModel.compoundForWeather(Weather.CLOUDY, Tyre.WET, 20))
        assertEquals(Tyre.SOFT, TyreModel.compoundForWeather(Weather.DRY, Tyre.INTERMEDIATE, 8))
    }

    @Test fun heavyRainCorrectsDryCompoundForAutomaticSelection() {
        assertEquals(Tyre.WET, TyreModel.compoundForWeather(Weather.HEAVY_RAIN, Tyre.MEDIUM, 20))
        assertEquals(Tyre.INTERMEDIATE, TyreModel.compoundForWeather(Weather.LIGHT_RAIN, Tyre.HARD, 20))
        assertEquals(Tyre.WET, TyreModel.compoundForWeather(Weather.HEAVY_RAIN, Tyre.INTERMEDIATE, 20))
        assertEquals(FuelModel.weatherFactor(Weather.DRY, Tyre.MEDIUM), FuelModel.weatherFactor(Weather.CLOUDY, Tyre.MEDIUM), 0.0)
    }

    @Test fun lowFuelDoesNotJustifyRefuellingPitInNoRefuelModel() {
        // The AI pit branch is intentionally wear-only; fuel is handled by posture/alerts.
        val source = java.io.File("app/src/main/java/com/f1teammanager/core/race/CareerWeekendEngine.kt").readText()
        assertTrue(source.contains("else if (s.wear >= (90 + s.aiPitBias).coerceIn(82, 96))"))
        assertTrue(!source.contains("s.fuel <= FuelModel.TANK_CAPACITY_KG * 0.10) {"))
    }
}
