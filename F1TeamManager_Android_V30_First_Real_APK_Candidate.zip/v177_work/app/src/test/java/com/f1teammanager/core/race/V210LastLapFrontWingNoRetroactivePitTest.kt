package com.f1teammanager.core.race

import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * V210 regression guard: a front-wing failure detected after the final lap time
 * was accumulated must not add an invisible, retroactive 21-second pit stop.
 */
class V210LastLapFrontWingNoRetroactivePitTest {
    @Test fun lastLapFrontWingFailureDoesNotCallPitAfterFinishLine() {
        val source = java.io.File(
            "app/src/main/java/com/f1teammanager/core/race/CareerWeekendEngine.kt"
        ).readText()
        val start = source.indexOf("com.f1teammanager.core.manager.CarComponent.FRONT_WING -> {")
        assertTrue("Front-wing failure branch missing", start >= 0)
        val end = source.indexOf("com.f1teammanager.core.manager.CarComponent.REAR_WING -> {", start)
        assertTrue("Front-wing branch terminator missing", end > start)
        val branch = source.substring(start, end)
        assertTrue("Repair pit must only happen before the final lap", branch.contains("if (lap < c.laps)"))
        assertTrue("Last-lap path must explicitly avoid retroactive pit", branch.contains("sem pit-stop retroativo"))
        assertTrue("Pit call must be inside the guarded branch", branch.indexOf("if (lap < c.laps)") < branch.indexOf("pit(s, tyreBefore)"))
    }
}
