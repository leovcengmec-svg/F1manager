package com.f1teammanager.core.manager

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class V264AnnualEventDueWeekTest {
    @Test fun calendarOnlyContainsValidUniqueWeeks() {
        repeat(200) { seed ->
            val slots = AnnualTeamEventSeasonCalendar.generate(2026, seed + 1)
            assertTrue(slots.all { it.week in 1..56 })
            assertEquals(slots.size, slots.map { it.week }.toSet().size)
        }
    }

    @Test fun eventIdentityIncludesWeekKindAndOrdinal() {
        val a = AnnualTeamEventSeasonCalendar.Slot(12, AnnualTeamEventEngine.Kind.CAR_GAIN, 1)
        val b = AnnualTeamEventSeasonCalendar.Slot(12, AnnualTeamEventEngine.Kind.CAR_GAIN, 2)
        assertEquals(2, setOf("${a.week}:${a.kind.name}:${a.ordinal}", "${b.week}:${b.kind.name}:${b.ordinal}").size)
    }

    @Test fun invalidWeeksCannotBeProcessed() {
        assertTrue(!AnnualTeamEventEngine.canApplyWeeklyEvent(2026, 0, false))
        assertTrue(!AnnualTeamEventEngine.canApplyWeeklyEvent(2026, 57, false))
        assertTrue(!AnnualTeamEventEngine.canApplyWeeklyEvent(2026, 12, true))
        assertTrue(AnnualTeamEventEngine.canApplyWeeklyEvent(2026, 12, false))
    }
}
