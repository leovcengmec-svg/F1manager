package com.f1teammanager.core.race

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class V212RaceTimingMutationAuditTest {
    private val source by lazy {
        java.io.File("app/src/main/java/com/f1teammanager/core/race/CareerWeekendEngine.kt").readText()
    }

    @Test fun accumulatedTimeHasOnlyGridInitializationLapAndPitLossWriters() {
        // Guard the three legitimate timing mutations. A neutralisation, cached
        // position update, or result adapter must never rewrite elapsed race time.
        assertTrue(source.contains("state.total = index.toLong() * STARTING_GRID_GAP_MS"))
        assertTrue(source.contains("s.total += lapMs.coerceAtLeast(45000)"))
        assertTrue(source.contains("s.total += 21_000L"))
        assertFalse(source.contains("car.total = index.toLong() * STARTING_GRID_GAP_MS"))
    }

    @Test fun lastLapFrontWingFailureCannotAddPostFinishPitLoss() {
        val failureBlock = source.indexOf("// Falhas com consequência específica")
        assertTrue("Mechanical failure block missing", failureBlock >= 0)
        val start = source.indexOf("CarComponent.FRONT_WING ->", failureBlock)
        assertTrue("Front wing failure branch missing", start >= 0)
        val end = source.indexOf("CarComponent.REAR_WING ->", start)
        assertTrue("Could not isolate front wing failure branch", end > start)
        val section = source.substring(start, end)
        assertTrue(section.contains("if (lap < c.laps)"))
        assertTrue(section.contains("pit(s, tyreBefore)"))
        assertTrue(section.contains("sem pit-stop retroativo"))
    }

    @Test fun finalClassificationUsesCompletedLapsThenAccumulatedTime() {
        val start = source.indexOf("private fun currentClassification()")
        assertTrue("Classification function missing", start >= 0)
        val end = source.indexOf("private fun currentCarStatus()", start)
        assertTrue("Could not isolate classification function", end > start)
        val section = source.substring(start, end)
        assertTrue(section.contains("compareByDescending<S> { it.laps }.thenBy { it.total }.thenBy { it.grid }"))
        assertTrue(section.contains("val running = states.values.filterNot { it.dnf }"))
        assertTrue(section.contains("val dnfs = states.values.filter { it.dnf }"))
    }
}
