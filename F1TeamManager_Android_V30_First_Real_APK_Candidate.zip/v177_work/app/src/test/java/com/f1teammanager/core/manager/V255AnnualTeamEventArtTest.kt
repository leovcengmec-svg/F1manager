package com.f1teammanager.core.manager

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class V255AnnualTeamEventArtTest {
    @Test
    fun everyAnnualEventKindHasAValidDedicatedDrawableMapping() {
        val kinds = AnnualTeamEventEngine.Kind.values()
        val resources = kinds.map(AnnualTeamEventArt::drawableFor)
        assertEquals("Every event kind must have exactly one mapping", kinds.size, resources.size)
        assertTrue("No event may map to resource ID 0", resources.all { it > 0 })
        assertEquals("Each event kind should have its own generic illustration", resources.size, resources.toSet().size)
    }
}
