package com.f1teammanager.core.race

import org.junit.Assert.assertTrue
import org.junit.Test

class V199ClassificationOrderRegressionTest {
    @Test fun lapClassificationUsesAccumulatedTimeNotPreviousPosition() {
        val source = java.io.File("app/src/main/java/com/f1teammanager/core/race/CareerWeekendEngine.kt").readText()
        val marker = "Recalcula posições após a volta usando o tempo total."
        val markerIndex = source.indexOf(marker)
        assertTrue("Missing final lap classification correction", markerIndex >= 0)
        val section = source.substring(markerIndex, (markerIndex + 900).coerceAtMost(source.length))
        assertTrue(section.contains("sortedWith(compareBy<S> { it.total }.thenBy { it.grid })"))
        assertTrue(section.contains("car.position = index + 1"))
    }
}
