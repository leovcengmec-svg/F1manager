package com.f1teammanager.core.manager

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class V257AnnualTeamEventSchedulerRegressionTest {
    @Test fun sameSeedProducesSameSeasonCalendar() {
        assertEquals(AnnualTeamEventSeasonCalendar.generate(2026, 12345), AnnualTeamEventSeasonCalendar.generate(2026, 12345))
    }

    @Test fun seasonCalendarStaysWithinModerateLimits() {
        val slots = AnnualTeamEventSeasonCalendar.generate(2026, 12345)
        assertTrue(slots.all { it.week in 1..56 })
        assertTrue(slots.map { it.week }.distinct().size == slots.size)
        assertTrue(slots.count { it.kind == AnnualTeamEventEngine.Kind.FINANCIAL_CRISIS } <= 2)
        assertTrue(slots.count { it.kind == AnnualTeamEventEngine.Kind.FIRE || it.kind == AnnualTeamEventEngine.Kind.EARTHQUAKE } <= 1)
        assertTrue(slots.count { it.kind == AnnualTeamEventEngine.Kind.INVESTOR_ACQUISITION } <= 1)
        assertTrue(slots.count { it.kind == AnnualTeamEventEngine.Kind.DRIVER_CLASS_CHANGE } <= 1)
        assertTrue(slots.count { it.kind in setOf(AnnualTeamEventEngine.Kind.CAR_GAIN, AnnualTeamEventEngine.Kind.CAR_LOSS, AnnualTeamEventEngine.Kind.RELIABILITY_GAIN, AnnualTeamEventEngine.Kind.RELIABILITY_LOSS) } in 1..3)
    }

    @Test fun differentSeasonChangesCalendar() {
        assertTrue(AnnualTeamEventSeasonCalendar.generate(2026, 12345) != AnnualTeamEventSeasonCalendar.generate(2027, 12345))
    }
}
