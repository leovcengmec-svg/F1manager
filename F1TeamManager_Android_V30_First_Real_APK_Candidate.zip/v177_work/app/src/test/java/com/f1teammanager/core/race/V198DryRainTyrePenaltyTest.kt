package com.f1teammanager.core.race

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class V198DryRainTyrePenaltyTest {
    @Test fun rainTyresAreMuchSlowerOnDryTrack() {
        assertEquals(1.180, TyreModel.performanceMultiplier(Tyre.INTERMEDIATE, Weather.DRY), 0.0)
        assertEquals(1.280, TyreModel.performanceMultiplier(Tyre.WET, Weather.DRY), 0.0)
        assertTrue(TyreModel.performanceMultiplier(Tyre.INTERMEDIATE, Weather.DRY) - TyreModel.performanceMultiplier(Tyre.HARD, Weather.DRY) >= 0.18)
        assertTrue(TyreModel.performanceMultiplier(Tyre.WET, Weather.DRY) - TyreModel.performanceMultiplier(Tyre.HARD, Weather.DRY) >= 0.28)
    }

    @Test fun rainTyresWearExtremelyFastOnDryTrackAndCloudyConditions() {
        assertEquals(4.00, TyreModel.tyreWeatherWearFactor(Tyre.INTERMEDIATE, Weather.DRY), 0.0)
        assertEquals(4.00, TyreModel.tyreWeatherWearFactor(Tyre.WET, Weather.DRY), 0.0)
        assertEquals(3.00, TyreModel.tyreWeatherWearFactor(Tyre.INTERMEDIATE, Weather.CLOUDY), 0.0)
        assertEquals(3.00, TyreModel.tyreWeatherWearFactor(Tyre.WET, Weather.CLOUDY), 0.0)
    }
}
