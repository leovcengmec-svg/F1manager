package com.f1teammanager.core.race

import org.junit.Assert.assertTrue
import org.junit.Test

/** Static regression guards for the new incident timing and presentation path. */
class V231IncidentAndCardFlowRegressionTest {
    private val engine by lazy {
        java.io.File("app/src/main/java/com/f1teammanager/core/race/CareerWeekendEngine.kt").readText()
    }
    private val activity by lazy {
        java.io.File("app/src/main/java/com/f1teammanager/MainActivity.kt").readText()
    }

    @Test fun bothIncidentsAccumulateIntoTheEffectiveLapTime() {
        val start = engine.indexOf("var incidentLossMs = 0L")
        val end = engine.indexOf("s.laps = lap", start)
        assertTrue("Incident timing block missing", start >= 0 && end > start)
        val block = engine.substring(start, end)
        assertTrue(block.contains("lap == 1 && s.laps == 0"))
        assertTrue(block.contains("random.nextDouble() < 0.03"))
        assertTrue(block.contains("weather == Weather.HEAVY_RAIN"))
        assertTrue(block.contains("random.nextDouble() < 0.08"))
        assertTrue(block.contains("incidentLossMs += lossMs"))
        assertTrue(block.contains("lapMs = (lapMs + incidentLossMs)"))
        assertTrue(block.contains("s.total += lapMs"))
        assertTrue(block.contains("s.last = lapMs"))
    }

    @Test fun incidentCardsUseDedicatedImagesAndResumeOnlyAfterQueueClears() {
        assertTrue(activity.contains("event.detail.contains(\"largada\", ignoreCase = true) -> \"start_bad\""))
        assertTrue(activity.contains("event.detail.contains(\"chuva forte\", ignoreCase = true) -> \"heavy_rain_offtrack\""))
        assertTrue(activity.contains("val remainingCards = pendingRaceEventCards.drop(1)"))
        assertTrue(activity.contains("if (remainingCards.isEmpty() && s.decision == null && pitDriver <= 0 && raceStarted && !s.completed) running = true"))
    }

    @Test fun eventQueueComparesBatchesRatherThanOnlyTheirSizes() {
        assertTrue(activity.contains("if (s.events != lastRaceEventBatch)"))
        assertTrue(activity.contains("pendingRaceEventCards = pendingRaceEventCards + freshEvents"))
    }
}
