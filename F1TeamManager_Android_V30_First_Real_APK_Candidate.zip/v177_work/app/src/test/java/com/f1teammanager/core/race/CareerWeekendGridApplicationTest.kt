package com.f1teammanager.core.race

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Test

class CareerWeekendGridApplicationTest {
    @Test
    fun finalQualifyingGridIsAppliedToActualRacePositions() {
        val circuit = RaceCircuit(
            id = 991,
            name = "Grid Application Audit",
            laps = 10,
            baseLapTimeMs = 90_000L,
            crashRisk = 0.0,
            reliabilityRisk = 0.0,
            safetyCarRisk = 0.0
        )
        val participants = (1..80).map { id ->
            RaceParticipant(
                driverId = id,
                driverName = "Driver $id",
                teamId = ((id - 1) / 2) + 1,
                teamName = "Team ${((id - 1) / 2) + 1}",
                driverSpeed = 40 + ((id * 17) % 61),
                qualifying = 40 + ((id * 29) % 61),
                overtaking = 70,
                defense = 70,
                consistency = 70,
                enginePerformance = 40 + ((id * 13) % 61),
                chassisPerformance = 40 + ((id * 7) % 61),
                frontWingPerformance = 40 + ((id * 11) % 61),
                rearWingPerformance = 40 + ((id * 19) % 61),
                brakesPerformance = 70,
                electricPowerUnitPerformance = 70
            )
        }

        val engine = CareerWeekendEngine(seed = 1912026)
        engine.start(participants, circuit, playerTeamId = 1)
        repeat(3) { engine.simulateQualifyingPhase() }

        val snapshot = engine.snapshotForUi()
        val finalGrid = snapshot.grid!!.grid
        assertEquals(80, finalGrid.size)

        val gridPositions = finalGrid.associate { it.driverId to it.position }
        snapshot.classification.forEach { result ->
            assertEquals(
                "Live race position for driver ${result.driverId} must match Q3 grid before lap 1",
                gridPositions[result.driverId],
                result.position
            )
        }

        // The test setup varies qualifying ability; make sure this is not a
        // trivial ID-ordered grid accidentally passing the assertions.
        assertNotEquals((1..80).toList(), finalGrid.map { it.driverId })
    }
}
