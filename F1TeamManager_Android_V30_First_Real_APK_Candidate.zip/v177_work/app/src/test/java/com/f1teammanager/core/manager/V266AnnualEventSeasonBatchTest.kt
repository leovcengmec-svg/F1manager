package com.f1teammanager.core.manager

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class V266AnnualEventSeasonBatchTest {
    private fun snap(id: Int) = AnnualTeamEventEngine.TeamSnapshot(
        teamId=id, strengthRank=id, teamCount=40, budget=500_000_000L,
        facilities=FacilityType.values().associateWith { 5 },
        car=TeamCarState(aerodynamics=70, chassis=70, engine=70, reliability=70)
    )

    @Test fun scheduledTeamEventTargetsExactlyOneTeamPerOccurrence() {
        val slot = AnnualTeamEventSeasonCalendar.Slot(12, AnnualTeamEventEngine.Kind.FINANCIAL_CRISIS, 1)
        val batch = AnnualTeamEventEngine.resolveSeasonBatch(2026, listOf(slot), listOf(snap(2), snap(1)), 99)
        assertEquals(1, batch.teamResults.size)
        assertTrue(batch.teamResults.single().second.event!!.teamId in setOf(1, 2))
        assertTrue(batch.teamResults.single().second.budget in 0L..500_000_000L)
    }

    @Test fun investorAcquisitionOnlySelectsTeamWithTwoEligibleFacilities() {
        val slot = AnnualTeamEventSeasonCalendar.Slot(12, AnnualTeamEventEngine.Kind.INVESTOR_ACQUISITION, 1)
        val full = snap(1).copy(facilities = FacilityType.values().associateWith { 10 })
        val eligible = snap(2).copy(facilities = FacilityType.values().associateWith { 10 }.toMutableMap().apply {
            this[FacilityType.FACTORY] = 9
            this[FacilityType.RESEARCH] = 8
        })
        val batch = AnnualTeamEventEngine.resolveSeasonBatch(2026, listOf(slot), listOf(full, eligible), 99)
        assertEquals(1, batch.teamResults.size)
        assertEquals(2, batch.teamResults.single().second.event!!.teamId)
        assertEquals(100_000_000L, batch.teamResults.single().second.budget - eligible.budget)
        assertEquals(2, batch.teamResults.single().second.facilities.count { (type, level) -> level > (eligible.facilities[type] ?: 0) })
    }

    @Test fun investorAcquisitionDoesNotTargetIneligibleTeams() {
        val slot = AnnualTeamEventSeasonCalendar.Slot(12, AnnualTeamEventEngine.Kind.INVESTOR_ACQUISITION, 1)
        val full = snap(1).copy(facilities = FacilityType.values().associateWith { 10 })
        val batch = AnnualTeamEventEngine.resolveSeasonBatch(2026, listOf(slot), listOf(full), 99)
        assertTrue(batch.teamResults.isEmpty())
    }

    @Test fun multipleSlotsAccumulateEffectsForSameTeamWithinOneBatch() {
        val team = snap(1)
        val crisis = AnnualTeamEventSeasonCalendar.Slot(10, AnnualTeamEventEngine.Kind.FINANCIAL_CRISIS, 1)
        val carGain = AnnualTeamEventSeasonCalendar.Slot(11, AnnualTeamEventEngine.Kind.CAR_GAIN, 2)
        val batch = AnnualTeamEventEngine.resolveSeasonBatch(2026, listOf(crisis, carGain), listOf(team), 99)
        assertEquals(2, batch.teamResults.size)
        val afterCrisis = batch.teamResults.first { it.first == crisis }.second
        val afterCarGain = batch.teamResults.first { it.first == carGain }.second
        assertEquals(team.budget * 90L / 100L, afterCrisis.budget)
        assertEquals(afterCrisis.budget, afterCarGain.budget)
        assertTrue(afterCarGain.car != team.car)
        assertTrue(batch.teamResults.map { it.first }.toSet().size == 2)
    }

    @Test fun driverEventsAreReturnedForDedicatedResolver() {
        val slot = AnnualTeamEventSeasonCalendar.Slot(30, AnnualTeamEventEngine.Kind.DRIVER_GAIN, 2)
        val batch = AnnualTeamEventEngine.resolveSeasonBatch(2026, listOf(slot), listOf(snap(1)), 99)
        assertTrue(batch.teamResults.isEmpty())
        assertEquals(listOf(slot), batch.driverSlots)
    }
}
