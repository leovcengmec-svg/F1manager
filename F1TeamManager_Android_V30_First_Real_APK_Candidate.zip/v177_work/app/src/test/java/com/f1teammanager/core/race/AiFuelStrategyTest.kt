package com.f1teammanager.core.race

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class AiFuelStrategyTest {
    @Test
    fun attackConsumesMoreThanBalancedAndDefenseSavesFuel() {
        val attack = FuelModel.consumptionPerLap(58, DriverStrategyMode.ATTACK, Weather.DRY, Tyre.MEDIUM)
        val balanced = FuelModel.consumptionPerLap(58, DriverStrategyMode.BALANCED, Weather.DRY, Tyre.MEDIUM)
        val defense = FuelModel.consumptionPerLap(58, DriverStrategyMode.DEFENSE, Weather.DRY, Tyre.MEDIUM)
        assertTrue(attack > balanced)
        assertTrue(balanced > defense)
    }

    @Test
    fun fullTankSupportsAttackReferenceAndLeavesSafetyReserve() {
        val laps = 58
        val perLap = FuelModel.consumptionPerLap(laps, DriverStrategyMode.ATTACK, Weather.DRY, Tyre.MEDIUM)
        val remainingAfterRace = FuelModel.TANK_CAPACITY_KG - perLap * laps
        assertTrue("No-refuelling safety reserve should remain", remainingAfterRace > 0.0)
        assertEquals(FuelModel.TANK_CAPACITY_KG / (laps + FuelModel.SAFETY_LAPS),
            perLap, 0.000001)
    }
}
