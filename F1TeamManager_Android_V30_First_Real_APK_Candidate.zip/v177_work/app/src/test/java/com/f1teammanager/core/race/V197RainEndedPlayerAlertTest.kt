package com.f1teammanager.core.race

import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class V197RainEndedPlayerAlertTest {
    @Test fun rainEndingMustCreateManagerDecisionAndDryTyreBoxMustChooseSlick() {
        val source = File("src/main/java/com/f1teammanager/core/race/CareerWeekendEngine.kt")
        val text = source.readText()
        assertTrue("Rain ending must call pauseForPlayers", text.contains("A chuva encerrou ou diminuiu") && text.contains("pauseForPlayers("))
        assertTrue("BOX after rain must select a dry compound", text.contains("TyreModel.isDryTrack(weather) && s.tyre in TyreModel.wetCompounds"))
        assertTrue("Radio event must recommend switching to dry tyres", text.contains("Troca para pneu de seco disponível"))
    }
}
