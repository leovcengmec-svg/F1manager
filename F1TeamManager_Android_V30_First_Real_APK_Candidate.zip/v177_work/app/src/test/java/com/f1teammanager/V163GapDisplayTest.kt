package com.f1teammanager

import org.junit.Assert.assertEquals
import org.junit.Test

class V163GapDisplayTest {
    @Test fun gapUsesLapsWhenDriverHasCompletedFewerLaps() {
        assertEquals(-2L, raceGapMs(48, 7_000_000L, 50, 10_000_000L))
        assertEquals("+2 VOLTAS", formatGap(-2L))
        assertEquals("+1 VOLTA", formatGap(-1L))
    }

    @Test fun gapUsesTimeOnlyOnSameLap() {
        assertEquals(1_250L, raceGapMs(50, 10_001_250L, 50, 10_000_000L))
        assertEquals("+1.250s", formatGap(1_250L))
    }
}
