package com.f1teammanager.core.race

import org.junit.Assert.assertTrue
import org.junit.Test

/** Regression guard for manager decisions raised after some cars have completed a lap. */
class V209MidLapResumeRegressionTest {
    @Test fun raceLapResumesWithoutIncrementingOrReprocessingCompletedCars() {
        val source = java.io.File(
            "app/src/main/java/com/f1teammanager/core/race/CareerWeekendEngine.kt"
        ).readText()
        assertTrue("Lap progress state missing", source.contains("private var lapInProgress = false"))
        assertTrue("Lap counter must advance only when starting a new lap", source.contains("if (!lapInProgress) {\n            if (lap == 0) lap = 1 else lap++"))
        assertTrue("Completed drivers must be skipped on resume", source.contains(".filter { it.p.driverId !in processedDriverIdsThisLap }"))
        assertTrue("Driver must be marked processed after completing the lap", source.contains("s.laps = lap\n            processedDriverIdsThisLap += s.p.driverId"))
        assertTrue("Preparation must not rerun after an in-loop pause", source.contains("if (!lapPreparationDone) {"))
        assertTrue("Lap state must reset after all active drivers are processed", source.contains("lapInProgress = false\n        lapPreparationDone = false\n        processedDriverIdsThisLap.clear()"))
    }
}
