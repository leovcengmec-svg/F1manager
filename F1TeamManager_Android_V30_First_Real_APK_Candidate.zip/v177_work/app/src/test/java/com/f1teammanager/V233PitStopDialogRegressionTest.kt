package com.f1teammanager

import org.junit.Assert.assertTrue
import org.junit.Test

/** Regression guards: a pit stop cannot be dismissed accidentally. */
class V233PitStopDialogRegressionTest {
    private val activity by lazy {
        java.io.File("app/src/main/java/com/f1teammanager/MainActivity.kt").readText()
    }

    @Test fun pitTyreDialogRequiresAnExplicitChoice() {
        val start = activity.indexOf("// V233: a escolha de pneus é uma etapa explícita do pit stop.")
        val end = activity.indexOf("if (activePlan != null)", start)
        assertTrue("Pit dialog guard missing", start >= 0 && end > start)
        val block = activity.substring(start, end)
        assertTrue(block.contains("onDismissRequest = { /* exige uma escolha explícita */ }"))
        assertTrue(block.contains("dismissOnBackPress = false"))
        assertTrue(block.contains("dismissOnClickOutside = false"))
        assertTrue("Explicit cancel option must remain available", activity.contains("SAIR  •  NÃO IR AO BOX"))
    }
}
