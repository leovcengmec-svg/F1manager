package com.f1teammanager.core.manager

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class V256AnnualTeamEventSchedulerRegressionTest {
    @Test fun refusesSportsScreensAndAlreadyProcessedWeeks() {
        val sports = context(isSports = true)
        assertNull(AnnualTeamEventScheduler.plan(sports))
        val key = AnnualTeamEventEngine.weekLedgerKey(2026, 12)
        assertNull(AnnualTeamEventScheduler.plan(context(processedWeeks = setOf(key))))
    }

    @Test fun planIsDeterministicForSameWeekContext() {
        val context = context()
        assertEquals(AnnualTeamEventScheduler.plan(context), AnnualTeamEventScheduler.plan(context))
    }

    @Test fun annualSpecialsAreScheduledInTheirSeasonCalendarWeek() {
        val calendar = AnnualTeamEventSeasonCalendar.generate(2026, 12345)
        assertTrue(calendar.filter { it.kind == AnnualTeamEventEngine.Kind.INVESTOR_ACQUISITION || it.kind == AnnualTeamEventEngine.Kind.DRIVER_CLASS_CHANGE }.all { it.week in 1..56 })
        assertTrue(calendar.filter { it.kind == AnnualTeamEventEngine.Kind.INVESTOR_ACQUISITION || it.kind == AnnualTeamEventEngine.Kind.DRIVER_CLASS_CHANGE }.map { it.kind }.distinct().size <= 2)
    }

    @Test fun invalidWeeksAreRejected() {
        assertNull(AnnualTeamEventScheduler.plan(context(week = 0)))
        assertNull(AnnualTeamEventScheduler.plan(context(week = 57)))
    }

    private fun snapshot() = AnnualTeamEventEngine.TeamSnapshot(1, 1, 10, 50_000_000L, emptyMap(), TeamCarState(aerodynamics=50,chassis=50,engine=50,reliability=50,frontWing=50,rearWing=50,brakes=50,electricPowerUnit=50))

    private fun context(
        isSports: Boolean = false,
        week: Int = 12,
        processedWeeks: Set<String> = emptySet(),
        teams: List<AnnualTeamEventEngine.TeamSnapshot> = emptyList()
    ) = AnnualTeamEventScheduler.WeekContext(
        season = 2026,
        week = week,
        isQualifyingOrRaceScreen = isSports,
        seed = 12345,
        teams = teams,
        processedWeekKeys = processedWeeks,
        processedEventIds = emptySet(),
        acquisitionUsedThisSeason = false,
        classChangeUsedThisSeason = false
    )
}
