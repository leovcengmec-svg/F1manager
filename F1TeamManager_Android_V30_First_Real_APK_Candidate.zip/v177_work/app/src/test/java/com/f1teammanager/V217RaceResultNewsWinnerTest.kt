package com.f1teammanager

import org.junit.Assert.assertEquals
import org.junit.Test

class V217RaceResultNewsWinnerTest {
    @Test
    fun winnerExtractionDoesNotChooseAnotherDriverFromPodiumText() {
        val message = "Miami International: vencedor Michael Schumacher. Pódio: 1º Michael Schumacher • 2º Ayrton Senna • 3º Lando Norris."
        val winner = Regex("vencedor\\s+(.+?)(?:\\.\\s*Pódio:|$)", RegexOption.IGNORE_CASE)
            .find(message)?.groupValues?.getOrNull(1)?.trim()
        assertEquals("Michael Schumacher", winner)
    }

    @Test
    fun winnerExtractionHandlesSingleWinnerMessage() {
        val message = "Long Beach: vencedor Michael Schumacher. Pódio: 1º Michael Schumacher • 2º Ayrton Senna • 3º Max Verstappen."
        val winner = Regex("vencedor\\s+(.+?)(?:\\.\\s*Pódio:|$)", RegexOption.IGNORE_CASE)
            .find(message)?.groupValues?.getOrNull(1)?.trim()
        assertEquals("Michael Schumacher", winner)
    }
}
