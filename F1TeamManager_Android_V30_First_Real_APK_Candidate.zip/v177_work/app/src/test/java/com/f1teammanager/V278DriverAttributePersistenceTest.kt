package com.f1teammanager

import com.f1teammanager.core.season.DriverDefinition
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class V278DriverAttributePersistenceTest {
    private val roster = listOf(
        DriverDefinition(1, "Piloto A", 1, 60, 61, 62, 63, 64, 65, 66),
        DriverDefinition(2, "Piloto B", 2, 70, 71, 72, 73, 74, 75, 76),
        DriverDefinition(3, "Piloto C", 3, 80, 81, 82, 83, 84, 85, 86)
    )

    @Test fun partialStoragePreservesValidProgressAndRepairsOnlyMissingDriver() {
        val (merged, repaired) = DriverAttributePersistence.merge("1:90,91,92,93,94,95,96", roster)
        assertTrue(repaired)
        assertEquals(listOf(90,91,92,93,94,95,96), merged.getValue(1).toList())
        assertEquals(listOf(70,71,72,73,74,75,76), merged.getValue(2).toList())
        assertEquals(listOf(80,81,82,83,84,85,86), merged.getValue(3).toList())
    }

    @Test fun malformedRowDoesNotEraseOtherDriversAndValuesAreBounded() {
        val (merged, repaired) = DriverAttributePersistence.merge("1:101,0,2,3,4,5,6;2:1,2,3", roster)
        assertTrue(repaired)
        assertEquals(listOf(100,1,2,3,4,5,6), merged.getValue(1).toList())
        assertEquals(listOf(70,71,72,73,74,75,76), merged.getValue(2).toList())
    }

    @Test fun completeValidStorageDoesNotTriggerRepair() {
        val raw = "1:60,61,62,63,64,65,66;2:70,71,72,73,74,75,76;3:80,81,82,83,84,85,86"
        val (_, repaired) = DriverAttributePersistence.merge(raw, roster)
        assertFalse(repaired)
    }
}
