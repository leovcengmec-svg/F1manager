package com.f1teammanager.core.race

import org.junit.Assert.assertTrue
import org.junit.Test

class V211LiveFinalClassificationConsistencyTest {
    @Test fun liveAndFinalClassificationUseSameTimingComparator() {
        val source = java.io.File(
            "app/src/main/java/com/f1teammanager/core/race/CareerWeekendEngine.kt"
        ).readText()
        val start = source.indexOf("private fun currentClassification()")
        assertTrue("currentClassification missing", start >= 0)
        val end = source.indexOf("\n    private fun currentCarStatus()", start)
        assertTrue("Could not isolate currentClassification", end > start)
        val section = source.substring(start, end)
        assertTrue(section.contains("compareByDescending<S> { it.laps }.thenBy { it.total }.thenBy { it.grid }"))
        assertTrue("Live ranking must not use cached position", !section.contains("compareBy<S> { it.position }"))
    }
}
