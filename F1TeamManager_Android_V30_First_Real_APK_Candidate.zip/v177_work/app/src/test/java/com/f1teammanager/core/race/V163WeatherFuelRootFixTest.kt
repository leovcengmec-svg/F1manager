package com.f1teammanager.core.race

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class V163WeatherFuelRootFixTest {
    @Test fun cloudyIsDryTrack() {
        assertTrue(TyreModel.isDryTrack(Weather.CLOUDY))
        assertTrue(TyreModel.isDryTrack(Weather.DRY))
    }

    @Test fun automaticDryTyreChoiceNeverReturnsRainCompound() {
        assertEquals(Tyre.HARD, TyreModel.dryCompoundForRemainingLaps(30))
        assertEquals(Tyre.MEDIUM, TyreModel.dryCompoundForRemainingLaps(20))
        assertEquals(Tyre.SOFT, TyreModel.dryCompoundForRemainingLaps(8))
        assertTrue(TyreModel.dryCompoundForRemainingLaps(8) in TyreModel.dryCompounds)
    }
}
