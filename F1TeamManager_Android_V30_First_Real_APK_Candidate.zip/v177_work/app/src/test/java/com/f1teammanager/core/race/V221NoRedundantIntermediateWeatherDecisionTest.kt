package com.f1teammanager.core.race

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class V221NoRedundantIntermediateWeatherDecisionTest {
    private fun decisionRequired(current: Tyre, weather: Weather): Boolean {
        val required = when (weather) {
            Weather.LIGHT_RAIN, Weather.MEDIUM_RAIN -> Tyre.INTERMEDIATE
            Weather.HEAVY_RAIN -> Tyre.WET
            Weather.DRY, Weather.CLOUDY -> return current == Tyre.INTERMEDIATE || current == Tyre.WET
        }
        return current != required
    }

    @Test fun lightToMediumRainDoesNotAskAgainWhenAlreadyOnIntermediate() = assertFalse(decisionRequired(Tyre.INTERMEDIATE, Weather.MEDIUM_RAIN))
    @Test fun mediumToLightRainDoesNotAskAgainWhenAlreadyOnIntermediate() = assertFalse(decisionRequired(Tyre.INTERMEDIATE, Weather.LIGHT_RAIN))
    @Test fun heavyRainAsksIntermediateTyreToChangeToWet() = assertTrue(decisionRequired(Tyre.INTERMEDIATE, Weather.HEAVY_RAIN))
    @Test fun rainToDryAsksRainTyresButNotSlicks() {
        assertTrue(decisionRequired(Tyre.INTERMEDIATE, Weather.DRY))
        assertFalse(decisionRequired(Tyre.MEDIUM, Weather.DRY))
    }
}
