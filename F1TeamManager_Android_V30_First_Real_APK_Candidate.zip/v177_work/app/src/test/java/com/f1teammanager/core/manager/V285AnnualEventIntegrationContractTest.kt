package com.f1teammanager.core.manager

import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/**
 * Source-contract regression checks for the annual event integration boundary.
 * These checks complement (but do not replace) runtime tests of Android persistence.
 */
class V285AnnualEventIntegrationContractTest {
    @Test fun eventCalendarIsProcessedWeekByWeekDuringFreeCalendarAdvance() {
        val main = source("app/src/main/java/com/f1teammanager/MainActivity.kt")
        assertTrue(main.contains("for (eventWeek in (currentWeek + 1)..targetWeek)"))
        assertTrue(main.contains("pendingAnnualEventsForWeek(store.season, eventWeek"))
        assertTrue(main.contains("commitAnnualDriverStateAndKeys(store.season"))
    }

    @Test fun annualEventNewsUsesDedicatedCategoryAndIsSaved() {
        val main = source("app/src/main/java/com/f1teammanager/MainActivity.kt")
        assertTrue(main.contains("MarketNewsCategory.ANNUAL_EVENTS"))
        assertTrue(main.contains("store.saveDriverMarket(managerState.driverMarket)"))
        assertTrue(main.contains("EVENTOS ANUAIS"))
    }

    @Test fun pendingEventLedgerIsSeparateFromStableSeasonCalendar() {
        val prefs = source("app/src/main/java/com/f1teammanager/CareerPreferences.kt")
        assertTrue(prefs.contains("annualEventCalendar_$seasonNumber"))
        assertTrue(prefs.contains("annualEventProcessed_$seasonNumber"))
        assertTrue(prefs.contains("slot.week == week"))
    }

    private fun source(relativePath: String): String {
        val candidates = generateSequence(File(System.getProperty("user.dir"))) { it.parentFile }
            .map { File(it, relativePath) }
            .firstOrNull { it.isFile }
        return requireNotNull(candidates) { "Source not found: $relativePath" }.readText()
    }
}
