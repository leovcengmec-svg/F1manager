package com.f1teammanager.core.race

import org.junit.Assert.assertTrue
import org.junit.Test

class V204WetStartAndRedFlagPlansTest {
    @Test fun lightAndMediumRainStartPlansOfferIntermediateAndWet() {
        listOf(Weather.LIGHT_RAIN, Weather.MEDIUM_RAIN).forEach { weather ->
            val plans = TyreModel.buildPlansForWeather(58, weather)
            val tyres = plans.values.flatMap { it.sequence }.toSet()
            assertTrue("$weather deve oferecer intermediários", Tyre.INTERMEDIATE in tyres)
            assertTrue("$weather deve oferecer WET", Tyre.WET in tyres)
            assertTrue("$weather não pode incluir slicks", tyres.none { it in TyreModel.dryCompounds })
        }
    }

    @Test fun heavyRainStartPlansOfferWetAndIntermediateWithoutSlicks() {
        val plans = TyreModel.buildPlansForWeather(58, Weather.HEAVY_RAIN)
        val tyres = plans.values.flatMap { it.sequence }.toSet()
        assertTrue(Tyre.WET in tyres)
        assertTrue(Tyre.INTERMEDIATE in tyres)
        assertTrue(tyres.none { it in TyreModel.dryCompounds })
    }

    @Test fun dryWeatherKeepsDryPlans() {
        val plans = TyreModel.buildPlansForWeather(58, Weather.DRY)
        assertTrue(plans.values.flatMap { it.sequence }.all { it in TyreModel.dryCompounds })
    }
}
