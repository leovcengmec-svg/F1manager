package com.f1teammanager.core.race

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class V207SafetyCarTimingPreservationTest {
    @Test fun safetyCarPelotonDoesNotOverwriteAccumulatedRaceTime() {
        val source = java.io.File(
            "app/src/main/java/com/f1teammanager/core/race/CareerWeekendEngine.kt"
        ).readText()
        val start = source.indexOf("private fun groupPeloton()")
        assertTrue("groupPeloton implementation missing", start >= 0)
        val end = source.indexOf("\n    private fun pit(", start)
        assertTrue("Could not isolate groupPeloton implementation", end > start)
        val section = source.substring(start, end)
        assertFalse(
            "Safety Car / red flag must not replace elapsed time with artificial grid gaps",
            section.contains("car.total = index.toLong() * STARTING_GRID_GAP_MS")
        )
        assertTrue("Classification order should be based on accumulated race time",
            section.contains("compareBy<S> { it.total }.thenBy { it.grid }"))
    }
}
