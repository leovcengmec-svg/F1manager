package com.f1teammanager

import org.junit.Assert.assertEquals
import org.junit.Test

class V219RaceNewsWinnerRegressionTest {
    private fun canonicalWinner(message: String): String? {
        val podiumText = Regex("Pódio:\\s*(.+)$", RegexOption.IGNORE_CASE)
            .find(message)?.groupValues?.getOrNull(1)
        val podiumWinner = podiumText?.let {
            Regex("(?:^|[•\\s])1º\\s+(.+?)(?=\\s*[•.]|$)", RegexOption.IGNORE_CASE)
                .find(it)?.groupValues?.getOrNull(1)?.trim()
        }
        return podiumWinner ?: Regex("vencedor\\s+(.+?)(?:\\.\\s*Pódio:|$)", RegexOption.IGNORE_CASE)
            .find(message)?.groupValues?.getOrNull(1)?.trim()
    }

    @Test fun podiumWinnerWinsOverConflictingHeadlineSentence() {
        val message = "Miami International: vencedor Lando Norris. Pódio: 1º Michael Schumacher • 2º Ayrton Senna • 3º Lando Norris."
        assertEquals("Michael Schumacher", canonicalWinner(message))
    }

    @Test fun legacyMessageWithoutPodiumUsesAnnouncedWinner() {
        assertEquals("Michael Schumacher", canonicalWinner("Miami: vencedor Michael Schumacher."))
    }
}
