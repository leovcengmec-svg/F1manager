package com.f1teammanager.core.manager

import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class V265AnnualEventResolutionTest {
    private fun snapshot() = AnnualTeamEventEngine.TeamSnapshot(
        teamId = 1, strengthRank = 20, teamCount = 40, budget = 500_000_000L,
        facilities = FacilityType.values().associateWith { 5 },
        car = TeamCarState(aerodynamics=70, chassis=70, engine=70, reliability=70,
            frontWing=70, rearWing=70, brakes=70, electricPowerUnit=70)
    )

    @Test fun financialCrisisNeverCreatesNegativeBudget() {
        val slot = AnnualTeamEventSeasonCalendar.Slot(14, AnnualTeamEventEngine.Kind.FINANCIAL_CRISIS, 1)
        val result = AnnualTeamEventEngine.resolveScheduledTeamEvent(slot, 2026, snapshot(), 123)
        assertNotNull(result)
        assertTrue(result!!.budget >= 0L)
        assertTrue(result.event != null)
    }

    @Test fun facilityUpgradeIsBoundedByLevelTen() {
        val levels = FacilityType.values().associateWith { 10 }
        val snap = snapshot().copy(facilities = levels)
        val slot = AnnualTeamEventSeasonCalendar.Slot(22, AnnualTeamEventEngine.Kind.FACILITY_UPGRADE, 1)
        val result = AnnualTeamEventEngine.resolveScheduledTeamEvent(slot, 2026, snap, 123)
        assertNotNull(result)
        assertTrue(result!!.facilities.values.all { it in 0..10 })
    }

    @Test fun driverEventsAreDelegatedToDriverResolver() {
        val slot = AnnualTeamEventSeasonCalendar.Slot(35, AnnualTeamEventEngine.Kind.DRIVER_GAIN, 1)
        assertNull(AnnualTeamEventEngine.resolveScheduledTeamEvent(slot, 2026, snapshot(), 123))
    }
}
