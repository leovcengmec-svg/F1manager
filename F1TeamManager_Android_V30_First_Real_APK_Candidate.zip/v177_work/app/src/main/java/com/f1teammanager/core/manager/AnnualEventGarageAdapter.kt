package com.f1teammanager.core.manager

/** Bridges annual-event car deltas into the physical two-car race model. */
object AnnualEventGarageAdapter {
    fun applyDelta(garage: TeamGarage, before: TeamCarState, after: TeamCarState): TeamGarage {
        fun apply(car: PhysicalCar): PhysicalCar {
            val reliabilityDelta = after.reliability - before.reliability
            val reliabilities = car.componentReliabilities.mapValues { (_, value) ->
                (value + reliabilityDelta).coerceIn(1, 100)
            }
            return car.copy(
                engine = (car.engine + after.engine - before.engine).coerceIn(1, 100),
                chassis = (car.chassis + after.chassis - before.chassis).coerceIn(1, 100),
                frontWing = (car.frontWing + after.frontWing - before.frontWing).coerceIn(1, 100),
                rearWing = (car.rearWing + after.rearWing - before.rearWing).coerceIn(1, 100),
                brakes = (car.brakes + after.brakes - before.brakes).coerceIn(1, 100),
                electricPowerUnit = (car.electricPowerUnit + after.electricPowerUnit - before.electricPowerUnit).coerceIn(1, 100),
                reliability = (car.reliability + reliabilityDelta).coerceIn(1, 100),
                componentReliabilities = reliabilities
            )
        }
        return garage.copy(car1 = apply(garage.car1), car2 = apply(garage.car2))
    }
}
