package com.f1teammanager.core.manager

class FinanceEngine {
    /**
     * Salary is paid after each completed GP, never at season opening.
     * Integer remainder is settled on GP 30 so annual salary totals exactly match the contract.
     */
    fun applyDriverSalariesForRace(state: TeamManagerState, season: Int, round: Int): TeamManagerState {
        if (round !in 1..30) return state
        val ledgerKey = "$season:$round"
        if (ledgerKey in state.finance.salaryPaidRounds) return state
        val active = state.driverMarket.contracts.filter { it.teamId == state.playerTeamId && it.activeIn(season) }
        val total = active.sumOf { contract ->
            val annual = contract.salary.coerceAtLeast(0L)
            annual / 30L + if (round == 30) annual % 30L else 0L
        }
        var finance = SalaryLedger.apply(state.finance, season, round, total)
        finance = SignatureFeeAccounting.recognizeForRace(finance, season, round)
        return state.copy(finance=finance)
    }

    /** Signature fees are paid immediately; a short cash balance blocks confirmation and never creates a negative balance. */
    fun applySignatureFee(finance: TeamFinanceState, fee: Long, description: String): TeamFinanceState {
        if (fee <= 0L) return finance
        if (finance.budget.coerceAtLeast(0L) < fee) {
            val marker = "BLOQUEADO/INSUFICIENTE: €$fee de taxa de assinatura; contrato não confirmado — $description"
            return finance.copy(transactions=(finance.transactions + marker).takeLast(100), budget=finance.budget.coerceAtLeast(0L))
        }
        val next = finance.transact(-fee, description)
        return SignatureFeeAccounting.register(next, fee, description)
    }

    fun applySeasonConstructorsPrize(state: TeamManagerState, season: Int, position: Int): TeamManagerState {
        if (season in state.finance.seasonPrizesPaid) return state
        val prize = SeasonPrizeEngine.prizeForPosition(position)
        val f = state.finance.transact(prize, "Premiação de construtores — $season — ${position}º lugar")
            .copy(seasonPrizesPaid = state.finance.seasonPrizesPaid + season)
        return state.copy(finance = f)
    }

    fun applyQualifying(state:TeamManagerState, bestQualifyingPosition:Int):TeamManagerState {
        if (bestQualifyingPosition <= 0) return state
        val sponsors = state.sponsors.filter { it.active && it.racesRemaining > 0 }.ifEmpty { listOf(state.sponsor).filter { it.active && it.racesRemaining > 0 } }
        val bonus = sponsors.sumOf { s -> if (s.qualifyingTarget > 0 && bestQualifyingPosition >= (if(s.qualifyingTargetMin>0) s.qualifyingTargetMin else 1) && bestQualifyingPosition <= (if(s.qualifyingTargetMax>0) s.qualifyingTargetMax else s.qualifyingTarget)) s.qualifyingBonus else 0L }
        return if (bonus > 0) state.copy(finance=state.finance.transact(bonus,"Bônus por meta de qualificação")) else state
    }

    fun applyRace(state:TeamManagerState, finishPosition:Int, teamPoints:Int, isDnf:Boolean):TeamManagerState {
        val sponsors = state.sponsors.filter { it.active && it.racesRemaining > 0 }.ifEmpty { listOf(state.sponsor).filter { it.active && it.racesRemaining > 0 } }
        val sponsorRace = sponsors.sumOf { it.racePayment }
        val pointsBonus = sponsors.sumOf { it.pointsBonus } * teamPoints
        val objectiveBonus = sponsors.sumOf { sponsor ->
            var bonus = 0L
            if (sponsor.raceTarget > 0 && !isDnf && finishPosition <= sponsor.raceTarget) bonus += sponsor.raceTargetBonus
            bonus
        }
        val prize=when {
            isDnf -> 250_000L
            finishPosition<=3 -> 2_500_000L
            finishPosition<=10 -> 1_500_000L
            finishPosition<=20 -> 900_000L
            else -> 500_000L
        }
        val raceCost=850_000L + if(isDnf) 450_000L else 0L
        val f=state.finance
            .transact(sponsorRace,"Patrocínios fixos GP")
            .transact(pointsBonus,"Bônus por pontos")
            .transact(objectiveBonus,"Bônus por meta de corrida")
            .transact(prize,"Premiação GP")
            .transact(-raceCost,"Custos GP")
        val updatedSponsors = state.sponsors.mapNotNull { s ->
            if (!s.active) s
            else {
                val remaining = (s.racesRemaining - 1).coerceAtLeast(0)
                if (remaining == 0) null else s.copy(racesRemaining = remaining)
            }
        }
        val primary = updatedSponsors.firstOrNull { it.slot == 1 }
            ?: SponsorContract("Patrocinador Base",0,0,0,1,0,1,0,0,0,0,false)
        return state.copy(finance=f, sponsors=updatedSponsors, sponsor=primary)
    }
}
