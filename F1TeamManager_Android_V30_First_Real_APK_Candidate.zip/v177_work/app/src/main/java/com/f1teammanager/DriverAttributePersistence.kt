package com.f1teammanager

import com.f1teammanager.core.season.DriverDefinition

/** Pure parser/repair logic for the persisted seven-attribute roster. */
internal object DriverAttributePersistence {
    private const val ATTRIBUTE_COUNT = 7

    /** Returns (complete roster, wasRepaired). Unknown IDs are discarded; valid rows survive. */
    fun merge(raw: String, roster: List<DriverDefinition>): Pair<Map<Int, IntArray>, Boolean> {
        val allowedIds = roster.map { it.id }.toSet()
        val parsed = linkedMapOf<Int, IntArray>()
        var hadInvalidData = false
        raw.split(';').forEach { token ->
            val parts = token.split(':', limit = 2)
            if (parts.size != 2) { hadInvalidData = true; return@forEach }
            val id = parts[0].toIntOrNull() ?: run { hadInvalidData = true; return@forEach }
            if (id !in allowedIds) { hadInvalidData = true; return@forEach }
            val values = parts[1].split(',').map { it.toIntOrNull() }
            if (values.size != ATTRIBUTE_COUNT || values.any { it == null }) { hadInvalidData = true; return@forEach }
            if (values.any { it!! !in 1..100 }) hadInvalidData = true
            parsed[id] = values.map { it!!.coerceIn(1, 100) }.toIntArray()
        }
        val result = linkedMapOf<Int, IntArray>()
        roster.forEach { driver ->
            result[driver.id] = parsed[driver.id] ?: intArrayOf(
                driver.speed, driver.qualifying, driver.overtaking, driver.defense,
                driver.consistency, driver.wet, driver.tyre
            ).map { it.coerceIn(1, 100) }.toIntArray()
        }
        val repaired = hadInvalidData || result.size != parsed.size || roster.any { driver ->
            val existing = parsed[driver.id]
            existing == null || !existing.contentEquals(result[driver.id])
        }
        return result to repaired
    }

    fun serialize(values: Map<Int, IntArray>): String = values.toSortedMap().entries.joinToString(";") { (id, attrs) ->
        require(attrs.size == ATTRIBUTE_COUNT) { "Cada piloto deve ter exatamente sete atributos." }
        "$id:${attrs.joinToString(",") { it.coerceIn(1, 100).toString() }}"
    }
}
