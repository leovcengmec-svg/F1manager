package com.f1teammanager.core.manager

import kotlin.random.Random

/** Pure, deterministic rules for annual team events. Integration into the weekly save flow remains explicit. */
object AnnualTeamEventEngine {
    enum class Kind { INVESTOR_ACQUISITION, FINANCIAL_CRISIS, CAR_GAIN, CAR_LOSS, RELIABILITY_GAIN, RELIABILITY_LOSS, FIRE, EARTHQUAKE, FACILITY_UPGRADE, DRIVER_GAIN, DRIVER_LOSS, DRIVER_CLASS_CHANGE }
    data class Event(val id:String,val season:Int,val week:Int,val teamId:Int,val kind:Kind,val title:String,val description:String)
    data class TeamSnapshot(val teamId:Int,val strengthRank:Int,val teamCount:Int,val budget:Long,val facilities:Map<FacilityType,Int>,val car:TeamCarState)
    data class TeamResult(val budget:Long,val facilities:Map<FacilityType,Int>,val car:TeamCarState,val event:Event?)

    fun shouldRollAcquisition(season:Int,seed:Int)=Random(seed.toLong()+season*1009L+0x1A11).nextInt(100)<30

    /** Reliability-only event; keeps all other car attributes unchanged. */
    fun applyReliabilityEvent(s:TeamSnapshot, season:Int, week:Int, gain:Boolean, seed:Int):TeamResult {
        val amount=Random(seed.toLong()+season*61L+s.teamId*29L+week*7L).nextInt(2,5)
        val delta=if(gain) amount else -amount
        val updated=s.car.copy(reliability=(s.car.reliability+delta).coerceIn(1,100)).normalized()
        val kind=if(gain) Kind.RELIABILITY_GAIN else Kind.RELIABILITY_LOSS
        return TeamResult(s.budget,s.facilities,updated,
            Event("annual:$season:${kind.name.lowercase()}:${s.teamId}",season,week,s.teamId,kind,
                if(gain) "CONFIABILIDADE MELHORADA" else "PROBLEMA DE CONFIABILIDADE",
                "Confiabilidade ${if(gain) "+" else ""}$delta pontos (limitada à faixa 1–100)."))
    }

    /** Maps the fixed driver-class ladder without touching current attributes. */
    fun adjacentDriverClass(current:String, promote:Boolean, seed:Int):String? {
        val ladder=listOf("Fraco","Médio","Forte","Pro","Lenda")
        val index=ladder.indexOf(current)
        if(index<0) return null
        val next=index+(if(promote) 1 else -1)
        if(next !in ladder.indices) return null
        // Seed parameter is accepted to keep call signatures compatible with seeded event resolution.
        @Suppress("UNUSED_VARIABLE") val deterministicSeed=seed
        return ladder[next]
    }

    /** Annual special event rolls once per season; 15% occurrence means 85% no event. */
    fun shouldRollDriverClassChange(season:Int,seed:Int):Boolean =
        Random(seed.toLong()+season*2027L+0xD12).nextInt(100)<15


    data class DriverResult(val attributes: List<Int>, val event: Event?)

    /** Applies an annual driver event to one of the seven persistent attributes, clamped to the driver's current class limits. */
    fun applyDriverAttributeEvent(
        driverId: Int, driverName: String, currentAttributes: List<Int>, driverClass: String,
        season: Int, week: Int, gain: Boolean, seed: Int
    ): DriverResult {
        if (currentAttributes.size != 7) return DriverResult(currentAttributes, null)
        val limits = when (driverClass) {
            "Fraco" -> 40..59
            "Médio" -> 40..79
            "Forte" -> 40..89
            "Pro" -> 40..94
            "Lenda" -> 40..100
            else -> 40..100
        }
        val rng = Random(seed.toLong() + season * 811L + week * 37L + driverId * 101L)
        val attributeIndex = rng.nextInt(currentAttributes.size)
        val amount = rng.nextInt(1, 4)
        val delta = if (gain) amount else -amount
        val updated = currentAttributes.toMutableList()
        updated[attributeIndex] = (updated[attributeIndex] + delta).coerceIn(limits.first, limits.last)
        if (updated == currentAttributes) return DriverResult(currentAttributes, null)
        val kind = if (gain) Kind.DRIVER_GAIN else Kind.DRIVER_LOSS
        val names = listOf("Velocidade", "Classificação", "Ultrapassagem", "Defesa", "Consistência", "Chuva", "Pneus")
        return DriverResult(updated, Event("annual:$season:${kind.name.lowercase()}:$driverId", season, week, 0, kind,
            if (gain) "EVOLUÇÃO EXTRAORDINÁRIA DE PILOTO" else "REGRESSÃO DE PILOTO",
            "$driverName: ${names[attributeIndex]} ${currentAttributes[attributeIndex]}→${updated[attributeIndex]} (classe $driverClass)."))
    }

    /** A season/week ledger key prevents a caller from processing the same week twice. */
    fun weekLedgerKey(season: Int, week: Int): String = "annual-events:$season:$week"

    /** Legacy helper retained for compatibility. New scheduling uses AnnualTeamEventSeasonCalendar
     * so event frequency is controlled per season rather than rolled every week.
     */
    fun shouldRollCommonEvent(season: Int, week: Int, seed: Int): Boolean {
        if (season < 1 || week !in 1..56) return false
        return Random(seed.toLong() + season * 3253L + week * 127L + 0xC011).nextInt(100) < 3
    }

    /** Stable unique key for an occurrence; persistence must enforce uniqueness. */
    fun eventLedgerKey(event: Event): String = "annual-event:${event.season}:${event.week}:${event.id}"

    /** Explicit guard for processing only during normal weekly management, not sports sessions. */
    fun canApplyWeeklyEvent(season: Int, week: Int, isQualifyingOrRaceScreen: Boolean): Boolean =
        season >= 1 && week in 1..56 && !isQualifyingOrRaceScreen

    /** Relative weights: weak 50, middle 35, strong 15. */
    fun selectionWeight(rank:Int,teamCount:Int):Int {
        if(teamCount<=0 || rank !in 1..teamCount) return 0
        val percentile=rank.toDouble()/teamCount
        return when { percentile>0.66 -> 50; percentile>0.33 -> 35; else -> 15 }
    }
    fun applyAcquisition(s:TeamSnapshot,season:Int,week:Int,seed:Int):TeamResult {
        val levels=s.facilities.toMutableMap()
        val eligible=FacilityType.values().filter { (levels[it]?:0)<10 }
        if(eligible.size<2) return TeamResult(s.budget,s.facilities,s.car,null)
        val chosen=eligible.shuffled(Random(seed.toLong()+season*31L+s.teamId*97L)).take(2)
        chosen.forEach { levels[it]=((levels[it]?:0)+1).coerceAtMost(10) }
        return TeamResult((s.budget+100_000_000L).coerceAtLeast(0L),levels.toMap(),s.car,
            Event("annual:$season:acquisition:${s.teamId}",season,week,s.teamId,Kind.INVESTOR_ACQUISITION,"AQUISIÇÃO POR INVESTIDORES",
                "Entrada de 100.000.000 no orçamento; instalações melhoradas: ${chosen.joinToString { FacilityEngine.label(it) }}."))
    }
    fun applyFinancialCrisis(s:TeamSnapshot,season:Int,week:Int):TeamResult {
        val loss=(s.budget.coerceAtLeast(0L)*10L/100L).coerceAtMost(100_000_000L)
        return TeamResult((s.budget-loss).coerceAtLeast(0L),s.facilities,s.car,
            Event("annual:$season:crisis:${s.teamId}",season,week,s.teamId,Kind.FINANCIAL_CRISIS,"CRISE FINANCEIRA","Perda direta de orçamento: $loss."))
    }
    fun applyFacilityDamage(s:TeamSnapshot,season:Int,week:Int,earthquake:Boolean,seed:Int):TeamResult {
        val levels=s.facilities.toMutableMap()
        val eligible=FacilityType.values().filter { (levels[it]?:0)>0 }
        if(eligible.isEmpty()) return TeamResult(s.budget,s.facilities,s.car,null)
        val affected=if(earthquake) eligible else listOf(eligible.random(Random(seed.toLong()+season*41L+s.teamId*13L)))
        affected.forEachIndexed { i,f ->
            val loss=Random(seed.toLong()+season*71L+s.teamId*17L+week*3L+i).nextInt(1,3)
            levels[f]=((levels[f]?:0)-loss).coerceAtLeast(0)
        }
        val kind=if(earthquake) Kind.EARTHQUAKE else Kind.FIRE
        val title=if(earthquake) "TERREMOTO NA REGIÃO DA SEDE" else "INCÊNDIO NA INSTALAÇÃO"
        val details=affected.joinToString { "${FacilityEngine.label(it)} ${(s.facilities[it]?:0)}→${levels[it]}" }
        return TeamResult(s.budget,levels.toMap(),s.car,Event("annual:$season:${kind.name.lowercase()}:${s.teamId}",season,week,s.teamId,kind,title,"Instalações afetadas: $details."))
    }
    fun applyCarEvent(s:TeamSnapshot,season:Int,week:Int,gain:Boolean,seed:Int):TeamResult {
        val component=CarComponent.values().random(Random(seed.toLong()+season*43L+s.teamId*19L+week))
        val amount=Random(seed.toLong()+season*59L+component.ordinal*23L+week).nextInt(2,5)
        val delta=if(gain) amount else -amount
        val car=when(component) {
            CarComponent.ENGINE -> s.car.copy(engine=(s.car.engine+delta).coerceIn(1,100))
            CarComponent.CHASSIS -> s.car.copy(chassis=(s.car.chassis+delta).coerceIn(1,100))
            CarComponent.FRONT_WING -> s.car.copy(frontWing=(s.car.frontWing+delta).coerceIn(1,100))
            CarComponent.REAR_WING -> s.car.copy(rearWing=(s.car.rearWing+delta).coerceIn(1,100))
            CarComponent.BRAKES -> s.car.copy(brakes=(s.car.brakes+delta).coerceIn(1,100))
            CarComponent.ELECTRIC_POWER_UNIT -> s.car.copy(electricPowerUnit=(s.car.electricPowerUnit+delta).coerceIn(1,100))
        }.normalized()
        val kind=if(gain) Kind.CAR_GAIN else Kind.CAR_LOSS
        return TeamResult(s.budget,s.facilities,car,Event("annual:$season:${kind.name.lowercase()}:${s.teamId}",season,week,s.teamId,kind,
            if(gain) "MELHORIA NO CARRO" else "DEFEITO NO CARRO","${component.name}: ${if(gain) "+" else ""}$delta pontos."))
    }


    /**
     * V266: resolves scheduled team-level slots across all supplied team snapshots in stable order.
     * Driver-specific events are returned separately for a dedicated roster-aware resolver.
     * This function is pure; persistence remains the caller's responsibility.
     */
    data class SeasonBatchResult(
        val teamResults: List<Pair<AnnualTeamEventSeasonCalendar.Slot, TeamResult>>,
        val driverSlots: List<AnnualTeamEventSeasonCalendar.Slot>
    )

    fun resolveSeasonBatch(
        season: Int,
        slots: List<AnnualTeamEventSeasonCalendar.Slot>,
        snapshots: List<TeamSnapshot>,
        seed: Int
    ): SeasonBatchResult {
        if (season < 1) return SeasonBatchResult(emptyList(), emptyList())
        val orderedSlots = slots.filter { it.week in 1..56 }
            .distinctBy { "${it.week}:${it.kind.name}:${it.ordinal}" }
            .sortedWith(compareBy<AnnualTeamEventSeasonCalendar.Slot> { it.week }.thenBy { it.ordinal })
        // Keep a live in-memory snapshot for this batch. Multiple events may target the
        // same team in one multi-week advance; each event must see the effects of earlier
        // events rather than reusing the original snapshot and overwriting prior changes.
        val currentSnapshots = snapshots.distinctBy { it.teamId }.associateBy { it.teamId }.toMutableMap()
        val resolved = mutableListOf<Pair<AnnualTeamEventSeasonCalendar.Slot, TeamResult>>()
        val driver = mutableListOf<AnnualTeamEventSeasonCalendar.Slot>()
        orderedSlots.forEach { slot ->
            when (slot.kind) {
                Kind.DRIVER_GAIN, Kind.DRIVER_LOSS, Kind.DRIVER_CLASS_CHANGE -> driver += slot
                else -> {
                    // One calendar occurrence targets one team, not every team in the grid.
                    // This prevents a single scheduled crisis/car/facility event from being
                    // multiplied across all 40 teams. Selection is deterministic and favors
                    // weaker teams for investor acquisitions using the existing weighting rule.
                    val orderedTeams = currentSnapshots.values.sortedBy { it.teamId }
                    if (orderedTeams.isNotEmpty()) {
                        val occurrenceSeed = seed.toLong() + season * 65537L + slot.week * 4099L + slot.ordinal * 1009L
                        val rng = Random(occurrenceSeed)
                        val target = if (slot.kind == Kind.INVESTOR_ACQUISITION) {
                            // An investor event must be able to improve two distinct facilities.
                            // Exclude teams with fewer than two facilities below level 10 before
                            // applying the weak/mid-team weighting; otherwise the slot could be
                            // consumed by an ineligible team and silently grant no acquisition.
                            val eligibleTeams = orderedTeams.filter { snapshot ->
                                FacilityType.values().count { (snapshot.facilities[it] ?: 0) < 10 } >= 2
                            }
                            if (eligibleTeams.isEmpty()) null else {
                                val weighted = eligibleTeams.flatMap { snapshot ->
                                    List(selectionWeight(snapshot.strengthRank, snapshot.teamCount).coerceAtLeast(1)) { snapshot }
                                }
                                weighted[rng.nextInt(weighted.size)]
                            }
                        } else orderedTeams[rng.nextInt(orderedTeams.size)]
                        if (target != null) {
                            val teamSeed = seed + target.teamId * 104729 + slot.ordinal * 1009
                            val result = resolveScheduledTeamEvent(slot, season, target, teamSeed)
                            if (result?.event != null) {
                                resolved += slot to result
                                currentSnapshots[target.teamId] = target.copy(
                                    budget = result.budget,
                                    facilities = result.facilities,
                                    car = result.car
                                )
                            }
                        }
                    }
                }
            }
        }
        return SeasonBatchResult(resolved, driver)
    }

    /**
     * V265: deterministic team-event resolution entry point used by career integration.
     * It resolves one scheduled team event against the supplied snapshot and never mutates
     * persistence itself; the caller must save TeamResult before marking the occurrence.
     */
    fun resolveScheduledTeamEvent(
        slot: AnnualTeamEventSeasonCalendar.Slot,
        season: Int,
        snapshot: TeamSnapshot,
        seed: Int
    ): TeamResult? {
        if (season < 1 || slot.week !in 1..56) return null
        return when (slot.kind) {
            Kind.INVESTOR_ACQUISITION -> applyAcquisition(snapshot, season, slot.week, seed)
            Kind.FINANCIAL_CRISIS -> applyFinancialCrisis(snapshot, season, slot.week)
            Kind.CAR_GAIN -> applyCarEvent(snapshot, season, slot.week, true, seed)
            Kind.CAR_LOSS -> applyCarEvent(snapshot, season, slot.week, false, seed)
            Kind.RELIABILITY_GAIN -> applyReliabilityEvent(snapshot, season, slot.week, true, seed)
            Kind.RELIABILITY_LOSS -> applyReliabilityEvent(snapshot, season, slot.week, false, seed)
            Kind.FIRE -> applyFacilityDamage(snapshot, season, slot.week, false, seed)
            Kind.EARTHQUAKE -> applyFacilityDamage(snapshot, season, slot.week, true, seed)
            Kind.FACILITY_UPGRADE -> {
                val levels = snapshot.facilities.toMutableMap()
                val eligible = FacilityType.values().filter { (levels[it] ?: 0) < 10 }
                if (eligible.isEmpty()) TeamResult(snapshot.budget, snapshot.facilities, snapshot.car, null)
                else {
                    val facility = eligible.random(Random(seed.toLong() + season * 47L + snapshot.teamId * 13L + slot.week))
                    val before = levels[facility] ?: 0
                    levels[facility] = (before + 1).coerceAtMost(10)
                    TeamResult(snapshot.budget, levels.toMap(), snapshot.car,
                        Event("annual:$season:facility_upgrade:${snapshot.teamId}:$facility", season, slot.week,
                            snapshot.teamId, Kind.FACILITY_UPGRADE, "MELHORIA DE INSTALAÇÃO",
                            "${FacilityEngine.label(facility)}: nível $before → ${levels[facility]}."))
                }
            }
            Kind.DRIVER_GAIN, Kind.DRIVER_LOSS, Kind.DRIVER_CLASS_CHANGE -> null
        }
    }

}
