package com.f1teammanager

/** V225: imagens genéricas de eventos para o card universal da corrida. */
object RaceEventImageRegistry {
    /** Retorna o drawable correspondente; use painterResource(id) no card de evento. */
    fun drawableFor(eventKey: String): Int = when (eventKey.trim().lowercase()) {
        "start_bad" -> R.drawable.event_start_bad
        "collision" -> R.drawable.event_collision
        "off_track" -> R.drawable.event_off_track
        "spin" -> R.drawable.event_spin
        "light_contact" -> R.drawable.event_light_contact
        "front_wing_damage" -> R.drawable.event_front_wing_damage
        "suspension_damage" -> R.drawable.event_suspension_damage
        "puncture" -> R.drawable.event_puncture
        "engine_failure" -> R.drawable.event_engine_failure
        "gearbox_failure" -> R.drawable.event_gearbox_failure
        "overheating" -> R.drawable.event_overheating
        "pit_stop_problem" -> R.drawable.event_pit_stop_problem
        "slow_tyre_change" -> R.drawable.event_slow_tyre_change
        "unsafe_release" -> R.drawable.event_unsafe_release
        "loose_part" -> R.drawable.event_loose_part
        "penalty" -> R.drawable.event_penalty
        "safety_car" -> R.drawable.event_safety_car
        "virtual_safety_car" -> R.drawable.event_virtual_safety_car
        "red_flag" -> R.drawable.event_red_flag
        "heavy_rain" -> R.drawable.event_heavy_rain
        "light_rain" -> R.drawable.event_light_rain
        "drying_track" -> R.drawable.event_drying_track
        "weather_change" -> R.drawable.event_weather_change
        "track_limits" -> R.drawable.event_track_limits
        "illegal_overtake" -> R.drawable.event_illegal_overtake
        "blocking" -> R.drawable.event_blocking
        "low_fuel" -> R.drawable.event_low_fuel
        "critical_degradation" -> R.drawable.event_critical_degradation
        "heavy_rain_offtrack" -> R.drawable.event_heavy_rain_offtrack
        "retirement" -> R.drawable.event_retirement
        "start", "bad_start", "largada_ruim" -> R.drawable.event_start_bad
        "collision", "colisao", "toque" -> R.drawable.event_collision
        "rain_offtrack", "heavy_rain_loss_control" -> R.drawable.event_heavy_rain_offtrack
        "mechanical_failure" -> R.drawable.event_engine_failure
        else -> R.drawable.event_collision
    }
}
