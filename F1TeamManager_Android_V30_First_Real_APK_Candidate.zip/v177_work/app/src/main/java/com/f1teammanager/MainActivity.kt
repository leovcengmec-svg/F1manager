package com.f1teammanager

import android.os.Bundle
import android.os.Build
import android.Manifest
import androidx.activity.ComponentActivity
import androidx.core.view.WindowCompat
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt
import java.util.Locale
import com.f1teammanager.core.race.*
import com.f1teammanager.core.manager.CarComponent
import com.f1teammanager.core.manager.CarDevelopmentEngine
import com.f1teammanager.core.manager.ResearchEngine
import com.f1teammanager.core.manager.ResearchFocus
import com.f1teammanager.core.manager.ResearchComplexity
import com.f1teammanager.core.manager.GarageCarId
import com.f1teammanager.core.manager.CarPiece
import com.f1teammanager.core.manager.TeamGarage
import com.f1teammanager.core.manager.TeamGarageFactory
import com.f1teammanager.core.manager.FactoryEngine
import com.f1teammanager.core.manager.FinancialSeasonClosureEngine
import com.f1teammanager.core.manager.DevelopmentIntensity
import com.f1teammanager.core.manager.CarDevelopmentFocus
import com.f1teammanager.core.manager.TeamCarState
import com.f1teammanager.core.manager.InitialTeamProfile
import com.f1teammanager.core.manager.TeamManagerState
import com.f1teammanager.core.manager.TeamFacilitiesState
import com.f1teammanager.core.manager.FacilityType
import com.f1teammanager.core.manager.FacilityEngine
import com.f1teammanager.core.manager.TechnicalInvestmentEngine
import com.f1teammanager.core.manager.TechnicalInvestmentState
import com.f1teammanager.core.manager.TeamFinanceState
import com.f1teammanager.core.manager.FinanceEngine
import com.f1teammanager.core.manager.AITeamFinancialEngine
import com.f1teammanager.core.manager.AITeamDevelopmentEngine
import com.f1teammanager.core.manager.TeamSponsorshipEngine
import com.f1teammanager.core.manager.SeasonSettlementEngine
import com.f1teammanager.core.manager.ManagerMarketEngine
import com.f1teammanager.core.manager.SponsorContract
import com.f1teammanager.core.manager.DynamicGridEngine
import com.f1teammanager.core.manager.DriverMarketEngine
import com.f1teammanager.core.manager.DriverMarketState
import com.f1teammanager.core.manager.DriverDevelopmentEngine
import com.f1teammanager.core.manager.MarketNewsCategory
import com.f1teammanager.core.manager.MarketNotification
import com.f1teammanager.core.manager.DriverTeamRole
import com.f1teammanager.core.manager.NegotiationStatus
import com.f1teammanager.core.season.CarCatalog
import com.f1teammanager.core.season.RoundDefinition
import com.f1teammanager.core.season.WorldDatabase
import com.f1teammanager.core.season.SeasonCalendar

private val Bg = Color(0xFF08090C)
private val Panel = Color(0xFF14161B)
private val Panel2 = Color(0xFF1B1E24)
private val Red = Color(0xFFE10600)
private val Muted = Color(0xFF8D929C)
private val Line = Color(0xFF2B2F36)
private val Green = Color(0xFF38C878)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, true)
        setContent { F1ManagerApp(CareerPreferences(this)) }
        window.decorView.post { requestExternalAssetPermissionIfNeeded() }
    }

    private fun requestExternalAssetPermissionIfNeeded() {
        runCatching {
            val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_IMAGES else Manifest.permission.READ_EXTERNAL_STORAGE
            if (androidx.core.content.ContextCompat.checkSelfPermission(this, permission) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(permission), 4101)
            }
        }
    }
}

private enum class Screen { HOME, TEAM, TEAM_OVERVIEW, DRIVERS, DRIVER_HISTORY, DRIVER_DEVELOPMENT, TECHNICAL_INVESTMENT, CAR, CALENDAR, STANDINGS, FINANCE, MARKET, WEEKEND, QUALIFYING, RACE, RESULT, HISTORY, HISTORY_CENTER, NEWS, HALL_OF_FAME, RECORDS, SEASON, MANAGEMENT, SELECT_TEAM }
private enum class Nav { HOME, TEAM, CAR, CALENDAR, STANDINGS }

@Composable
private fun F1ManagerApp(store: CareerPreferences) {
    // V151: do not synthesize retroactive pilot-evolution news by comparing
    // against base-driver data. News is emitted only by the actual GP evolution tick.
    var hasCareer by remember { mutableStateOf(store.hasCareer) }
    var teamId by remember { mutableIntStateOf(store.teamId) }
    var roundIndex by remember { mutableIntStateOf(store.roundIndex) }
    var currentWeek by remember { mutableIntStateOf(store.currentWeek) }
    var screen by remember { mutableStateOf(if (hasCareer) Screen.HOME else Screen.SELECT_TEAM) }
    var nav by remember { mutableStateOf(Nav.HOME) }
    var selectedMode by remember { mutableStateOf(DriverStrategyMode.BALANCED) }
    var selectedTyre by remember { mutableStateOf(Tyre.MEDIUM) }
    var snapshot by remember { mutableStateOf<CareerWeekendEngine.SessionSnapshot?>(null) }
    var result by remember { mutableStateOf<RaceResult?>(null) }
    var marketDriverId by remember { mutableIntStateOf(-1) }
    var driverHistoryId by remember { mutableIntStateOf(-1) }
    var driverHistoryOrigin by remember { mutableStateOf(Screen.TEAM) }
    var teamOverviewSelectedId by remember(teamId) { mutableIntStateOf(teamId) }
    var marketMessage by remember { mutableStateOf("") }
        var managerState by remember(teamId) { mutableStateOf(store.loadCar(teamId)?.let { val base=TeamManagerState(season=store.season, round=store.roundIndex+1, car=it, garage=store.loadGarage(teamId) ?: TeamGarageFactory.fromCarState(it, teamId, store.season), facilities=store.loadFacilities(teamId) ?: InitialTeamProfile.teamFacilities(WorldDatabase.teams.first { it.id == teamId }.initialLevel), facilityUpgrade=store.loadFacilityUpgrade(teamId), research=store.loadResearch(teamId) ?: com.f1teammanager.core.manager.TeamResearchState(), factory=store.loadFactory(teamId) ?: com.f1teammanager.core.manager.TeamFactoryState(), finance=TeamFinanceState(InitialTeamProfile.initialBudget(WorldDatabase.teams.first { it.id == teamId })), playerTeamId=teamId, driverDevelopment=store.loadDriverDevelopment(teamId), technicalInvestment=store.loadTechnicalInvestment(teamId) ?: TechnicalInvestmentEngine.forTeam(store.season, teamId, teamId, it)); run { val sponsors=store.loadSponsors(teamId); base.copy(finance=store.loadFinance(teamId,base.finance), sponsor=sponsors.firstOrNull { it.slot==1 } ?: store.loadSponsor(teamId,base.sponsor), sponsors=sponsors, driverMarket=store.loadDriverMarket() ?: DriverMarketEngine(20261003).initialState(store.season)) } } ?: initialManagerState(teamId,store)) }
    var historyRound by remember { mutableIntStateOf(-1) }
    var historyResult by remember { mutableStateOf<RaceResult?>(null) }
    var carMessage by remember { mutableStateOf("") }
    var calendarMessage by remember { mutableStateOf("") }
    var facilityMessage by remember { mutableStateOf("") }
    var sponsorMessage by remember { mutableStateOf("") }
    val marketEngine = remember { DriverMarketEngine(20261003) }
    val engine = remember { CareerWeekendEngine(20261003) }
    val team = WorldDatabase.teams.firstOrNull { it.id == teamId } ?: WorldDatabase.teams.first()
    val drivers = store.currentDrivers().filter { it.teamId == team.id }
    val seasonRounds = SeasonCalendar.forSeason(store.season)
    val round = seasonRounds.getOrElse(roundIndex) { seasonRounds.first() }
    val development = remember { CarDevelopmentEngine() }
    val researchEngine = remember { ResearchEngine() }
    val factoryEngine = remember { FactoryEngine() }
    // The interactive Android path shares the same AI commercial/financial engines
    // used by the season orchestrator. This prevents the UI simulation from silently
    // bypassing AI cash flow, sponsorship turnover and end-of-season debt penalties.
    val aiFinance = remember { AITeamFinancialEngine(20261006).also { it.restoreSnapshot(store.loadAiFinanceSnapshot()) } }
    val aiSponsorship = remember { TeamSponsorshipEngine(20261006).also { it.restoreSnapshot(store.loadAiSponsorshipSnapshot()) } }
    val aiDevelopment = remember { AITeamDevelopmentEngine(20261005) }

    fun persistAiState() {
        store.saveAiFinanceSnapshot(aiFinance.exportSnapshot())
        store.saveAiSponsorshipSnapshot(aiSponsorship.exportSnapshot())
    }

    fun syncAiWeeklyState(week: Int) {
        aiFinance.ensureAllTeams(store.season, team.id, managerState.driverMarket)
        WorldDatabase.teams.filter { it.id != team.id }.forEach { aiTeam ->
            // IA usa o mesmo caixa real do restante da economia. A capacidade técnica
            // reconstruída é apenas cash atual + P&D já pago, nunca uma carteira nova.
            val capacity = aiFinance.developmentCapacity(aiTeam.id, store.season)
            val virtual = aiDevelopment.simulateFinancial(aiTeam, (week - 1).coerceAtLeast(0), store.season, capacity)
            aiFinance.applyDevelopmentCost(aiTeam.id, store.season, virtual.budget, capacity)
            aiFinance.applySponsorshipSignings(aiTeam.id, store.season, aiSponsorship.forTeam(aiTeam.id, store.season))
        }
        persistAiState()
    }

    fun participants(): List<RaceParticipant> {
        val aiGarages = mutableMapOf<Int, TeamGarage>()
        val aiFacilities = mutableMapOf<Int, TeamFacilitiesState>()
        WorldDatabase.teams.filter { it.id != team.id }.forEach { aiTeam ->
            val capacity = aiFinance.developmentCapacity(aiTeam.id, store.season)
            val aiState = aiDevelopment.simulateFinancial(aiTeam, (currentWeek - 1).coerceAtLeast(0), store.season, capacity)
            aiGarages[aiTeam.id] = aiState.garage ?: TeamGarageFactory.fromInitial(aiTeam)
            aiFacilities[aiTeam.id] = aiState.facilities
        }
        return DynamicGridEngine().participants(
            market = managerState.driverMarket,
            playerTeamId = managerState.playerTeamId,
            seasonRound = roundIndex + 1,
            season = store.season,
            elapsedWeeks = (currentWeek - 1).coerceAtLeast(0),
            driverOverrides = store.currentDrivers().associateBy { it.id },
            playerGarage = managerState.garage ?: TeamGarageFactory.fromCarState(managerState.car, team.id, store.season),
            facilities = managerState.facilities,
            aiGarages = aiGarages,
            aiFacilities = aiFacilities
        )
    }
    fun circuit() = RaceCircuit(round.round, round.circuit, round.laps, round.baseLapTimeMs, crashRisk=round.crashRisk, reliabilityRisk=round.reliabilityRisk, safetyCarRisk=round.safetyCarRisk)
    fun startWeekend() {
        if (snapshot != null && snapshot?.completed == false && snapshot?.phase == "RACE") { screen = Screen.RACE; return }
        if (currentWeek != round.weekOfSeason) {
            calendarMessage = "A próxima corrida é na semana ${round.weekOfSeason}. Use PULAR 1 SEMANA ou PULAR ATÉ A PRÓXIMA CORRIDA."
            screen = Screen.CALENDAR
            return
        }
        syncAiWeeklyState(currentWeek)
        snapshot = engine.start(participants(), circuit(), team.id); result = null; screen = Screen.QUALIFYING
    }
    fun advanceFreeWeeks(weeks: Int, targetWeek: Int) {
        val delta = (targetWeek - currentWeek).coerceAtLeast(0)
        if (delta == 0) return
        val upgradeBeforeAdvance = managerState.facilityUpgrade
        val (facilityAdvancedState, facilityCompleted) = FacilityEngine.advanceUpgrade(managerState, delta)
        managerState = facilityAdvancedState
        store.saveFacilities(teamId, managerState.facilities)
        store.saveFacilityUpgrade(teamId, managerState.facilityUpgrade)
        if (facilityCompleted && upgradeBeforeAdvance != null) {
            val activeLabel = "${FacilityEngine.label(upgradeBeforeAdvance.facility)} concluída: nível ${upgradeBeforeAdvance.previousLevel} → ${upgradeBeforeAdvance.targetLevel} após 12 semanas."
            val notice = com.f1teammanager.core.manager.MarketNotification(store.season, targetWeek, "MELHORIA DE INSTALAÇÃO CONCLUÍDA", activeLabel, true, com.f1teammanager.core.manager.MarketNewsCategory.TEAM_EVOLUTION)
            managerState = managerState.copy(driverMarket = managerState.driverMarket.copy(notifications = (managerState.driverMarket.notifications + notice).takeLast(200)).normalized())
            store.saveDriverMarket(managerState.driverMarket)
        }
        // Novo P&D: as semanas avançam o projeto tecnológico, mas NUNCA alteram diretamente o carro.
        val beforeDesignIds = managerState.research.completedDesigns.map { it.designId }.toSet()
        val beforeActiveIds = managerState.research.activeProjects.map { it.projectId }.toSet()
        val beforePieceIds = managerState.factory.pendingInstallations.map { it.pieceId }.toSet()
        val driverAttributesBeforeDevelopment = store.driverAttributes()
        managerState = researchEngine.advanceWeeks(managerState, delta, store.season, currentWeek)
        managerState = factoryEngine.advanceWeeks(managerState, delta, currentWeek)
        val developmentResult = DriverDevelopmentEngine.advanceWeeks(
            managerState.driverDevelopment, delta, targetWeek,
            WorldDatabase.allDrivers.associateBy { it.id },
            store.driverAttributes(),
            20261007 + store.season * 101
        )
        managerState = managerState.copy(driverDevelopment = developmentResult.state)
        if (developmentResult.completed.isNotEmpty()) {
            store.saveDriverAttributes(developmentResult.attributes)
            val marketBeforeDevelopment = managerState.driverMarket
            val developmentNotices = developmentResult.completed.mapNotNull { completion ->
                val driverId = completion.driverId
                val driver = WorldDatabase.allDrivers.firstOrNull { it.id == driverId } ?: return@mapNotNull null
                val before = driverAttributesBeforeDevelopment[driverId] ?: intArrayOf(driver.speed, driver.qualifying, driver.overtaking, driver.defense, driver.consistency, driver.wet, driver.tyre)
                val after = developmentResult.attributes[driverId] ?: completion.attributes
                val beforeOverall = before.sum() / 7
                val afterOverall = after.sum() / 7
                if (beforeOverall == afterOverall) return@mapNotNull null
                val teamName = marketBeforeDevelopment.contracts.firstOrNull { it.driverId == driverId && it.activeIn(store.season) }
                    ?.let { deal -> WorldDatabase.teams.firstOrNull { it.id == deal.teamId }?.name } ?: "Sem equipe"
                val delta = afterOverall - beforeOverall
                com.f1teammanager.core.manager.MarketNotification(
                    store.season, targetWeek,
                    if (delta > 0) "EVOLUÇÃO DE PILOTO" else "REGRESSÃO DE PILOTO",
                    "${driver.name} — $teamName — Overall $beforeOverall → $afterOverall (${if (delta > 0) "+" else ""}$delta) após desenvolvimento.",
                    true, com.f1teammanager.core.manager.MarketNewsCategory.DRIVER_EVOLUTION
                )
            }
            if (developmentNotices.isNotEmpty()) managerState = managerState.copy(driverMarket = managerState.driverMarket.copy(
                notifications = (managerState.driverMarket.notifications + developmentNotices).takeLast(200)
            ).normalized())
        }
        // V181: do not publish a notification when a physical part is merely ready to install.
        val newDesigns = managerState.research.completedDesigns.filter { it.designId !in beforeDesignIds }
        val failedIds = beforeActiveIds - managerState.research.activeProjects.map { it.projectId }.toSet() - newDesigns.map { it.designId }.toSet()
        if (newDesigns.isNotEmpty() || failedIds.isNotEmpty()) {
            val notices = newDesigns.map { design -> com.f1teammanager.core.manager.MarketNotification(store.season, targetWeek, "P&D CONCLUÍDO", "${team.name} concluiu ${componentLabel(design.component)} V${design.version}. Design pronto para a Fábrica: P${design.performance} / C${design.reliability}.", true, com.f1teammanager.core.manager.MarketNewsCategory.TEAM_EVOLUTION) }
            managerState = managerState.copy(driverMarket = managerState.driverMarket.copy(notifications = (managerState.driverMarket.notifications + notices).takeLast(100)).normalized())
        }
        // IA: publicar a cadeia física real (P&D -> Design -> Fábrica -> Instalação).
        // A notícia de evolução só existe quando o desempenho físico/Overall realmente aumenta.
        val aiDev = com.f1teammanager.core.manager.AITeamDevelopmentEngine(20261005 + store.season)
        val beforeWeeks = (currentWeek - 1).coerceAtLeast(0)
        val afterWeeks = (targetWeek - 1).coerceAtLeast(0)
        WorldDatabase.teams.filter { it.id != team.id }.forEach { aiTeam ->
            val facilityNotices = mutableListOf<com.f1teammanager.core.manager.MarketNotification>()
            for (elapsedWeek in (beforeWeeks + 1)..afterWeeks) {
                val beforeFacilities = aiFinance.facilities(aiTeam.id)
                val afterFacilityState = aiFinance.advanceFacilityDevelopment(aiTeam.id, store.season, elapsedWeek)
                val afterFacilities = aiFinance.facilities(aiTeam.id)
                com.f1teammanager.core.manager.FacilityType.values().forEach { type ->
                    val beforeLevel = beforeFacilities.level(type)
                    val afterLevel = afterFacilities.level(type)
                    if (afterLevel > beforeLevel) {
                        facilityNotices += com.f1teammanager.core.manager.MarketNotification(
                            store.season, (elapsedWeek + 1).coerceAtMost(56), "MELHORIA DE INSTALAÇÃO",
                            "${aiTeam.name} melhorou ${com.f1teammanager.core.manager.FacilityEngine.label(type)} do nível $beforeLevel para o nível $afterLevel.",
                            true, com.f1teammanager.core.manager.MarketNewsCategory.TEAM_EVOLUTION
                        )
                    }
                }
            }
            val capacity = aiFinance.developmentCapacity(aiTeam.id, store.season)
            val after = aiDev.simulateFinancial(aiTeam, afterWeeks, store.season, capacity, aiFinance.facilities(aiTeam.id))
            aiFinance.setFacilities(aiTeam.id, after.facilities)
            aiFinance.applyDevelopmentCost(aiTeam.id, store.season, after.budget, capacity)
            val events = after.events.filter { it.week > beforeWeeks && it.week <= afterWeeks }
            val notices = facilityNotices + events.flatMap { event ->
                val displayWeek = (event.week + 1).coerceAtMost(56)
                val component = componentLabel(event.component)
                when (event.type) {
                    com.f1teammanager.core.manager.AITeamDevelopmentEngine.DevelopmentEvent.Type.DESIGN_COMPLETED -> listOf(
                        com.f1teammanager.core.manager.MarketNotification(
                            store.season, displayWeek, "P&D CONCLUÍDO",
                            "${aiTeam.name} concluiu $component V${event.version}. Design pronto para a Fábrica: P${event.performance} / C${event.reliability}.",
                            true, com.f1teammanager.core.manager.MarketNewsCategory.TEAM_EVOLUTION
                        )
                    )
                    com.f1teammanager.core.manager.AITeamDevelopmentEngine.DevelopmentEvent.Type.FACTORY_COMPLETED -> emptyList()
                    com.f1teammanager.core.manager.AITeamDevelopmentEngine.DevelopmentEvent.Type.PIECE_INSTALLED -> {
                        val target = event.target?.let { if (it == com.f1teammanager.core.manager.GarageCarId.CAR_1) "Carro 1" else "Carro 2" } ?: "carro"
                        val installation = listOf(
                            com.f1teammanager.core.manager.MarketNotification(
                                store.season, displayWeek, "PEÇA INSTALADA",
                                "${aiTeam.name} instalou $component V${event.version} no $target.",
                                true, com.f1teammanager.core.manager.MarketNewsCategory.TEAM_EVOLUTION
                            )
                        )
                        if ((event.afterOverall ?: 0) > (event.beforeOverall ?: 0)) {
                            installation + com.f1teammanager.core.manager.MarketNotification(
                                store.season, displayWeek, "EVOLUÇÃO DE EQUIPE",
                                "${aiTeam.name} evoluiu o desempenho. Overall da equipe subiu de ${event.beforeOverall} para ${event.afterOverall}.",
                                true, com.f1teammanager.core.manager.MarketNewsCategory.TEAM_EVOLUTION
                            )
                        } else installation
                    }
                }
            }
            if (notices.isNotEmpty()) {
                val existingKeys = managerState.driverMarket.notifications
                    .filter { it.season == store.season && it.category == com.f1teammanager.core.manager.MarketNewsCategory.TEAM_EVOLUTION }
                    .map { "${it.week}|${it.title}|${it.message}" }.toSet()
                val uniqueNotices = notices.distinctBy { "${it.week}|${it.title}|${it.message}" }
                    .filter { "${it.week}|${it.title}|${it.message}" !in existingKeys }
                if (uniqueNotices.isNotEmpty()) managerState = managerState.copy(driverMarket = managerState.driverMarket.copy(
                    notifications = (managerState.driverMarket.notifications + uniqueNotices).takeLast(200)
                ).normalized())
            }
        }
        // O mercado da IA funciona durante toda a temporada: cada semana realmente
        // transcorrida precisa ter seu próprio tick para expirar propostas, scouting
        // e permitir novas negociações. Não podemos processar apenas a semana-alvo.
        for (week in (currentWeek + 1)..targetWeek) {
            syncAiWeeklyState(week)
            val beforeMarket = managerState.driverMarket
            val afterMarket = marketEngine.processAiMarketWeek(beforeMarket, store.season, week, team.id)
            val newPlayerDeals = afterMarket.scheduled.filter { deal ->
                deal.startSeason == store.season + 1 &&
                    beforeMarket.scheduled.none { old -> old.driverId == deal.driverId && old.startSeason == deal.startSeason } &&
                    beforeMarket.pending.any { offer -> offer.driverId == deal.driverId && offer.proposerTeamId == team.id && offer.seasonTarget == deal.startSeason }
            }
            // Reserve cash cumulatively for every newly scheduled player-team deal.
            // Comparing each fee against the same opening balance allowed several individually
            // affordable fees to exceed the team's total cash when processed together.
            var playerCashAvailable = managerState.finance.budget.coerceAtLeast(0L)
            val rejectedPlayerDeals = mutableListOf<com.f1teammanager.core.manager.FutureDriverDeal>()
            newPlayerDeals.sortedWith(compareBy({ it.driverId }, { it.startSeason })).forEach { deal ->
                val fee = marketEngine.signatureFeeFor(afterMarket, deal.driverId, deal.toTeamId, store.season)
                if (fee > playerCashAvailable) {
                    rejectedPlayerDeals += deal
                } else {
                    playerCashAvailable -= fee.coerceAtLeast(0L)
                }
            }
            var committedMarket = afterMarket
            if (rejectedPlayerDeals.isNotEmpty()) {
                val rejectedKeys = rejectedPlayerDeals.map { "${it.driverId}:${it.startSeason}:${it.toTeamId}" }.toSet()
                committedMarket = committedMarket.copy(
                    scheduled = committedMarket.scheduled.filterNot { "${it.driverId}:${it.startSeason}:${it.toTeamId}" in rejectedKeys },
                    pending = committedMarket.pending.filterNot { offer -> rejectedPlayerDeals.any { it.driverId == offer.driverId && offer.proposerTeamId == team.id && offer.seasonTarget == it.startSeason } },
                    history = (committedMarket.history + rejectedPlayerDeals.map { "Negociação não confirmada: taxa de assinatura sem saldo para piloto ${it.driverId} (${store.season + 1})" }).takeLast(300),
                    notifications = (committedMarket.notifications.filterNot { n -> rejectedPlayerDeals.any { d -> n.message.contains("${d.driverId}") && n.season == store.season } }).takeLast(200)
                )
            }
            managerState = managerState.copy(driverMarket = committedMarket)
            newPlayerDeals.filterNot { it in rejectedPlayerDeals }.forEach { deal ->
                val fee = marketEngine.signatureFeeFor(committedMarket, deal.driverId, deal.toTeamId, store.season)
                if (fee > 0L) {
                    val driverName = WorldDatabase.allDrivers.firstOrNull { it.id == deal.driverId }?.name ?: "Piloto ${deal.driverId}"
                    managerState = managerState.copy(finance = FinanceEngine().applySignatureFee(managerState.finance, fee, "Taxa de assinatura de $driverName — ${store.season + 1}"))
                }
            }
            // AI transfers are also filtered by available cash before their commitments are persisted.
            var aiCommittedMarket = committedMarket
            val aiCashAvailable = mutableMapOf<Int, Long>()
            val unaffordableAiDeals = mutableListOf<com.f1teammanager.core.manager.FutureDriverDeal>()
            aiCommittedMarket.scheduled.filter { deal ->
                deal.startSeason == store.season + 1 && beforeMarket.scheduled.none { it.driverId == deal.driverId && it.startSeason == deal.startSeason } && deal.toTeamId != team.id
            }.sortedBy { it.driverId }.forEach { deal ->
                val cash = aiCashAvailable.getOrPut(deal.toTeamId) { aiFinance.state(deal.toTeamId, store.season).finance.budget.coerceAtLeast(0L) }
                val fee = marketEngine.signatureFeeFor(aiCommittedMarket, deal.driverId, deal.toTeamId, store.season)
                if (fee > cash) unaffordableAiDeals += deal else aiCashAvailable[deal.toTeamId] = cash - fee
            }
            if (unaffordableAiDeals.isNotEmpty()) {
                val rejectedIds = unaffordableAiDeals.map { it.driverId }.toSet()
                aiCommittedMarket = aiCommittedMarket.copy(
                    scheduled = aiCommittedMarket.scheduled.filterNot { it.driverId in rejectedIds && it.startSeason == store.season + 1 },
                    pending = aiCommittedMarket.pending.filterNot { it.driverId in rejectedIds && it.toTeamId in unaffordableAiDeals.map { deal -> deal.toTeamId } && it.seasonTarget == store.season + 1 },
                    history = (aiCommittedMarket.history + unaffordableAiDeals.map { "Negociação IA cancelada por saldo insuficiente: piloto ${it.driverId}, equipe ${it.toTeamId}, temporada ${it.startSeason}" }).takeLast(300)
                )
                managerState = managerState.copy(driverMarket = aiCommittedMarket)
            }
            WorldDatabase.teams.filter { it.id != team.id }.forEach { aiTeam ->
                aiFinance.applyNewDeals(aiTeam.id, store.season, beforeMarket, aiCommittedMarket, marketEngine)
            }
        }
        store.saveCar(teamId, managerState.car)
        store.saveGarage(teamId, managerState.garage ?: TeamGarageFactory.fromCarState(managerState.car, team.id, store.season)); store.saveFacilities(teamId, managerState.facilities)
        store.saveResearch(teamId, managerState.research)
        store.saveFactory(teamId, managerState.factory)
        store.saveDriverDevelopment(teamId, managerState.driverDevelopment)
        store.saveDriverMarket(managerState.driverMarket)
        store.saveFinance(teamId, managerState.finance)
        currentWeek = targetWeek
        store.jumpToWeek(targetWeek)
        calendarMessage = "${delta} semana(s) de calendário processada(s). P&D avançou junto com o calendário, incluindo semanas de GP."
    }
    fun skipOneWeek() {
        if (currentWeek >= 56) return
        if (currentWeek == round.weekOfSeason) {
            calendarMessage = "Esta é a semana do GP. Não é possível pular a corrida."
            return
        }
        advanceFreeWeeks(1, currentWeek + 1)
    }
    fun jumpToNextRace() {
        if (currentWeek == round.weekOfSeason) {
            calendarMessage = "Você está na semana do GP. Primeiro simule e conclua esta corrida; só depois poderá avançar para o próximo GP."
            screen = Screen.CALENDAR
            return
        }
        val target = if (currentWeek < round.weekOfSeason) {
            round.weekOfSeason
        } else {
            seasonRounds.getOrNull(roundIndex + 1)?.weekOfSeason
        }
        if (target == null) { calendarMessage = "Você já está na última corrida da temporada."; return }
        advanceFreeWeeks((target-currentWeek).coerceAtLeast(0), target)
    }
    fun simulateQualifying(sliceMs: Long = 5_000L) {
        // A velocidade escolhida pela interface controla tanto o intervalo visual
        // quanto o avanço do relógio virtual. Assim 4x realmente termina a sessão
        // mais rapidamente, sem alterar o resultado determinístico da qualificação.
        snapshot = engine.advanceQualifyingTimeSlice(sliceMs)
    }
    fun startRace() {
        if (!engine.qualifyingComplete()) return
        val grid = engine.snapshotForUi().grid
        val bestQualifyingPosition = grid?.phases?.getOrNull(2)?.entries
            ?.filter { entry -> store.currentDrivers().firstOrNull { it.id == entry.driverId }?.teamId == team.id }
            ?.minOfOrNull { it.position } ?: 0
        managerState = managerState.copy(finance = store.applyQualifyingBonusOnce(teamId, store.season, round.round, managerState.finance, managerState.sponsors, bestQualifyingPosition))
        snapshot = engine.snapshotForUi()
        screen = Screen.RACE
    }
    fun advanceRace() {
        snapshot = engine.advance()
        if (snapshot?.completed == true) {
            result = engine.result()
            val teamName = team.name
            val mine = result!!.classification.filter { it.teamName == teamName }
            val teamPoints = mine.sumOf { result!!.points[it.driverId] ?: 0 }
            val best = mine.minOfOrNull { if (it.status.startsWith("DNF")) 999 else it.position } ?: 999
            managerState = FinanceEngine().applyRace(managerState,best,teamPoints,mine.all { it.status.startsWith("DNF") })
            managerState = managerState.copy(finance = store.applyDriverSalaryForRaceOnce(teamId, store.season, round.round, managerState.finance, managerState.driverMarket))
            aiFinance.ensureAllTeams(store.season, team.id, managerState.driverMarket)
            WorldDatabase.teams.filter { it.id != team.id }.forEach { aiTeam ->
                val entries = result!!.classification.filter { entry ->
                    WorldDatabase.allDrivers.firstOrNull { it.name == entry.driverName }?.teamId == aiTeam.id || entry.teamName == aiTeam.name
                }
                val aiBest = entries.minOfOrNull { if (it.status.startsWith("DNF")) 999 else it.position } ?: 999
                val aiPoints = entries.sumOf { result!!.points[it.driverId] ?: 0 }
                val sponsorState = aiSponsorship.forTeam(aiTeam.id, store.season)
                aiFinance.applyRace(aiTeam.id, store.season, round.round, sponsorState, managerState.driverMarket, aiBest, aiPoints)
            }
            aiSponsorship.advanceAllTeams(store.season, round.round, team.id)
            persistAiState()
            store.recordRace(round.round, result!!, round, snapshot?.grid)
            store.applyDriverRaceEvolution(round.round)
            // CareerPreferences persists the canonical evolution/news state. Refresh
            // the in-memory UI state immediately; otherwise the News screen keeps
            // the pre-GP notification list until the app is recreated.
            store.loadDriverMarket()?.let { persistedMarket ->
                managerState = managerState.copy(driverMarket = persistedMarket)
            }

            val classifiedFinishers = result!!.classification.filterNot { it.status.startsWith("DNF") }.sortedBy { it.position }
            val winner = classifiedFinishers.firstOrNull()?.driverName ?: "Sem vencedor"
            val podium = classifiedFinishers.take(3).joinToString(" • ") { "${it.position}º ${it.driverName}" }
            val raceEvent = com.f1teammanager.core.manager.MarketNotification(
                store.season, round.weekOfSeason, "RESULTADO DO GP ${round.round}",
                "${round.circuit}: vencedor ${winner}. Pódio: ${podium.ifBlank { "sem classificação" }}.",
                true, com.f1teammanager.core.manager.MarketNewsCategory.ANNUAL_EVENTS
            )
            val existingRaceEvent = managerState.driverMarket.notifications.any {
                it.season == store.season && it.week == round.weekOfSeason && it.title == raceEvent.title && it.message == raceEvent.message
            }
            if (!existingRaceEvent) managerState = managerState.copy(driverMarket = managerState.driverMarket.copy(
                notifications = (managerState.driverMarket.notifications + raceEvent).takeLast(200)
            ).normalized())

            // GP30 is the single settlement point of the season. The real UI flow
            // must use exactly the same constructors' ranking/prize rules as the
            // audited season engine. The FinanceEngine has an idempotency guard and
            // the paid-season set is persisted, so reopening the app cannot pay twice.
            if (round.round == seasonRounds.size) {
                // V36: the Android flow and the headless season engine now share
                // one settlement authority. All 40 teams are settled here, not
                // only the player's team. The store's paid-team ledger prevents
                // duplicate payment after process death/reopening.
                store.settleConstructorsSeason(store.season)
                managerState = managerState.copy(finance = store.loadFinance(teamId, managerState.finance))
                SeasonSettlementEngine.settleAll(store.constructorPoints()).forEach { settlement ->
                    if (settlement.teamId != team.id) {
                        aiFinance.applySeasonConstructorsPrize(settlement.teamId, store.season, settlement.position)
                        aiFinance.applyEndOfSeasonFinancialPenalty(settlement.teamId, store.season)
                    }
                }
            }

            store.saveCar(teamId, managerState.car); store.saveFinance(teamId, managerState.finance); store.saveSponsors(teamId, managerState.sponsors)
            store.saveDriverMarket(managerState.driverMarket)
            screen = Screen.RESULT
        }
    }
    fun returnToCalendarAfterRace() {
        // O avanço do calendário já consumiu todas as semanas que realmente
        // transcorreram. A semana do GP só entra no P&D depois que a corrida
        // é concluída e o jogador avança para a semana seguinte.
        store.completeCurrentRace()
        roundIndex = store.roundIndex
        currentWeek = store.currentWeek

        snapshot = null
        result = null
        if (store.isSeasonEnded()) {
            screen = Screen.HOME
            nav = Nav.HOME
            calendarMessage = "TEMPORADA ${store.season} ENCERRADA. As 30 corridas foram concluídas e o histórico foi arquivado."
        } else {
            screen = Screen.CALENDAR
            nav = Nav.CALENDAR
            calendarMessage = "Corrida concluída. A semana ${currentWeek} continua sendo a semana atual; avance o calendário manualmente até o próximo GP."
        }
    }

    fun startNextSeason() {
        runCatching {
            val closingSeason = store.season
            // Close the old season first: regression belongs to the season that just ended.
            store.applySeasonEndRegression(closingSeason)
            store.startNextSeason()
            managerState = development.startNextSeason(managerState, store.season)
            managerState = managerState.copy(technicalInvestment = store.loadTechnicalInvestment(teamId) ?: TechnicalInvestmentEngine.forTeam(store.season, teamId, teamId, managerState.car))
            managerState = FinancialSeasonClosureEngine.applyPlayerPenalty(managerState)
            store.initializeDriverSeasonTargets(managerState.car)
            managerState = managerState.copy(driverMarket = store.loadDriverMarket() ?: marketEngine.initialState(store.season))
            val seasonNotice = com.f1teammanager.core.manager.MarketNotification(
                store.season, 1, "NOVA TEMPORADA",
                "A temporada ${store.season} começou. Contratos, desenvolvimento, instalações e orçamento foram atualizados.",
                true, com.f1teammanager.core.manager.MarketNewsCategory.ANNUAL_EVENTS
            )
            managerState = managerState.copy(driverMarket = managerState.driverMarket.copy(
                notifications = (managerState.driverMarket.notifications + seasonNotice).takeLast(200)
            ).normalized())

            // The market transition defines the contracts active in the new season.
            // Charge annual salaries only after that transition and exactly once.
            val resetFinance = managerState.finance.resetForNewSeason()
            val newFinance = resetFinance
            managerState = managerState.copy(finance = newFinance)

            // Persist every canonical state changed by the season boundary. In particular,
            // the physical garage must survive process death and remain the race source.
            store.saveCar(teamId, managerState.car)
            store.saveGarage(teamId, managerState.garage ?: TeamGarageFactory.fromCarState(managerState.car, team.id, store.season))
            store.saveFacilities(teamId, managerState.facilities)
            store.saveTechnicalInvestment(teamId, managerState.technicalInvestment)
            store.saveResearch(teamId, managerState.research)
            store.saveFactory(teamId, managerState.factory)
            store.saveDriverDevelopment(teamId, managerState.driverDevelopment)
            store.saveDriverMarket(managerState.driverMarket)
            store.saveFinance(teamId, managerState.finance)
            store.saveSponsors(teamId, managerState.sponsors)

            roundIndex = store.roundIndex
            currentWeek = store.currentWeek
            calendarMessage = "Nova temporada ${store.season} iniciada. Carro físico, P&D, fábrica, contratos e salários foram sincronizados."
            screen = Screen.HOME
            nav = Nav.HOME
        }.onFailure {
            calendarMessage = it.message ?: "Não foi possível iniciar a nova temporada."
        }
    }
    fun startDriverDevelopment(driverId: Int) {
        runCatching {
            val level = managerState.facilities.level(FacilityType.DRIVER_DEVELOPMENT)
            val teamDriverIds = store.currentDrivers().filter { it.teamId == team.id }.map { it.id }.toSet()
            managerState = managerState.copy(driverDevelopment = DriverDevelopmentEngine.start(managerState.driverDevelopment, level, driverId, currentWeek, teamDriverIds))
            store.saveDriverDevelopment(teamId, managerState.driverDevelopment)
            calendarMessage = "Desenvolvimento iniciado para ${WorldDatabase.allDrivers.first { it.id == driverId }.name}: ${DriverDevelopmentEngine.weeks(level)} semana(s), +${DriverDevelopmentEngine.points(level)} ponto(s)."
            screen = Screen.DRIVER_DEVELOPMENT
        }.onFailure { calendarMessage = it.message ?: "Não foi possível iniciar o desenvolvimento do piloto." }
    }

    fun manufactureDesign(design: com.f1teammanager.core.manager.ResearchDesign, quantity: Int, weeks: Int, costPerUnit: Long) {
        runCatching {
            managerState = factoryEngine.start(managerState, design, FactoryEngine.ManufacturingOption(quantity,weeks,costPerUnit), currentWeek)
            store.saveResearch(teamId, managerState.research); store.saveFactory(teamId, managerState.factory); store.saveTechnicalInvestment(teamId, managerState.technicalInvestment); store.saveGarage(teamId, managerState.garage ?: TeamGarageFactory.fromCarState(managerState.car, team.id, store.season)); store.saveFinance(teamId, managerState.finance)
            carMessage = "Fábrica: ${componentLabel(design.component)} V${design.version} x$quantity em produção. Ao concluir, você escolherá Carro 1 ou Carro 2."
        }.onFailure { carMessage = it.message ?: "Não foi possível iniciar a fabricação." }
    }

    fun installPendingPiece(piece: CarPiece, target: GarageCarId) {
        runCatching {
            require(managerState.factory.pendingInstallations.any { it.pieceId == piece.pieceId }) { "Peça física não está aguardando instalação." }
            val garage = managerState.garage ?: TeamGarageFactory.fromCarState(managerState.car, team.id, store.season)
            val beforeCarOverall = garage.car(target).overall
            val beforeTeamOverall = garage.teamAverageOverall
            val updatedGarage = garage.install(piece, target)
            val targetLabel = if (target == GarageCarId.CAR_1) "Carro 1" else "Carro 2"
            val installationNotice = com.f1teammanager.core.manager.MarketNotification(
                store.season, currentWeek, "PEÇA INSTALADA",
                "${team.name} instalou ${componentLabel(piece.component)} V${piece.version} no $targetLabel.",
                true, com.f1teammanager.core.manager.MarketNewsCategory.TEAM_EVOLUTION
            )
            val notices = mutableListOf(installationNotice)
            val afterTeamOverall = updatedGarage.teamAverageOverall
            if (afterTeamOverall != beforeTeamOverall) {
                val delta = afterTeamOverall - beforeTeamOverall
                notices += com.f1teammanager.core.manager.MarketNotification(
                    store.season, currentWeek, "EVOLUÇÃO DE EQUIPE",
                    "${team.name}: Overall médio da equipe ${if (delta > 0) "subiu" else "caiu"} de $beforeTeamOverall para $afterTeamOverall após instalação no $targetLabel.",
                    true, com.f1teammanager.core.manager.MarketNewsCategory.TEAM_EVOLUTION
                )
            }
            managerState = managerState.copy(
                garage = updatedGarage,
                factory = managerState.factory.copy(pendingInstallations = managerState.factory.pendingInstallations.filterNot { it.pieceId == piece.pieceId }),
                driverMarket = managerState.driverMarket.copy(notifications = (managerState.driverMarket.notifications + notices).takeLast(200)).normalized()
            )
            store.saveDriverMarket(managerState.driverMarket)
            store.saveGarage(teamId, updatedGarage)
            store.saveFactory(teamId, managerState.factory)
            carMessage = "${componentLabel(piece.component)} V${piece.version} instalada no $targetLabel (Overall do carro $beforeCarOverall → ${updatedGarage.car(target).overall})."
        }.onFailure { carMessage = it.message ?: "Não foi possível instalar a peça." }
    }
    fun startDevelopment(component: CarComponent, focus: ResearchFocus, complexity: ResearchComplexity) {
        runCatching {
            managerState = researchEngine.start(managerState, component, focus, complexity, currentWeek)
            val project = managerState.research.activeProjects.lastOrNull() ?: error("Projeto não criado")
            store.saveResearch(teamId, managerState.research); store.saveFactory(teamId, managerState.factory); store.saveTechnicalInvestment(teamId, managerState.technicalInvestment); store.saveFinance(teamId, managerState.finance)
            carMessage = "P&D ${componentLabel(component)} V${project.version} iniciado: ${project.totalWeeks} semana(s), ${researchEngine.focusLabel(focus)}. O carro NÃO muda até uma peça ser fabricada."
        }.onFailure { carMessage = it.message ?: "Não foi possível iniciar o projeto de P&D." }
    }
    fun investNextSeason(amount: Long) {
        runCatching { managerState = development.investNextSeason(managerState, amount); store.saveCar(teamId, managerState.car); store.saveFinance(teamId, managerState.finance); carMessage = "€ ${amount/1_000_000}M investidos no carro ${store.season + 1}." }
            .onFailure { carMessage = it.message ?: "Não foi possível investir no próximo carro." }
    }
    fun setNextSeasonFocus(focus: CarDevelopmentFocus) {
        managerState = development.setNextSeasonFocus(managerState, focus)
        store.saveCar(teamId, managerState.car)
    }
    fun openHistory(r:Int) { historyRound=r; historyResult=store.raceHistory(r); screen=Screen.HISTORY }
    fun makeMarketProposal(driverId: Int, replacementDriverId: Int?, years: Int, salary: Long, role: DriverTeamRole) {
        val driver = WorldDatabase.allDrivers.first { it.id == driverId }
        runCatching {
            val (next, offer) = marketEngine.makeOffer(managerState.driverMarket, driverId, team.id, years, salary, role, store.season, currentWeek = currentWeek, replaceDriverId = replacementDriverId)
            managerState = managerState.copy(driverMarket=next)
            store.saveDriverMarket(managerState.driverMarket)
            store.saveFinance(teamId, managerState.finance)
            marketMessage = "Proposta enviada para ${driver.name}. O piloto responderá em 2 ou 3 semanas."
        }.onFailure { marketMessage = it.message ?: "Não foi possível negociar agora." }
    }

    fun makeMarketInterest(driverId: Int, replacementDriverId: Int?) {
        makeMarketProposal(driverId, replacementDriverId, 1, marketEngine.salaryFor(driverId), DriverTeamRole.EQUAL)
    }

    fun renewMarketDriver(driverId: Int, years: Int, salary: Long, role: DriverTeamRole) {
        val driver = WorldDatabase.allDrivers.first { it.id == driverId }
        runCatching {
            val signatureFee = marketEngine.signatureFeeForRenewal(managerState.driverMarket, driverId, team.id, store.season)
            if (signatureFee > managerState.finance.budget.coerceAtLeast(0L)) { marketMessage = "Saldo insuficiente para pagar a taxa de assinatura."; return@runCatching }
            managerState = managerState.copy(driverMarket = marketEngine.renew(managerState.driverMarket, driverId, team.id, years, salary, role, store.season, currentWeek))
            managerState = managerState.copy(finance=FinanceEngine().applySignatureFee(managerState.finance, signatureFee, "Taxa de assinatura — renovação de ${driver.name} — ${store.season + 1}"))
            store.saveDriverMarket(managerState.driverMarket)
            store.saveFinance(teamId, managerState.finance)
            marketMessage = "Renovação de ${driver.name} preparada para ${store.season + 1}. Taxa de assinatura: € ${signatureFee/1_000_000.0}. O salário começa a ser cobrado em ${store.season + 1}."
        }.onFailure { marketMessage = it.message ?: "Não foi possível renovar o piloto." }
    }

    fun acceptIncomingMarketOffer(offer: com.f1teammanager.core.manager.DriverOffer) {
        runCatching {
            val signatureFee = marketEngine.signatureFeeFor(managerState.driverMarket, offer.driverId, team.id, store.season)
            if (signatureFee > managerState.finance.budget.coerceAtLeast(0L)) { marketMessage = "Saldo insuficiente para pagar a taxa de assinatura."; return@runCatching }
            managerState = managerState.copy(driverMarket = marketEngine.acceptIncomingOffer(managerState.driverMarket, offer, store.season, currentWeek))
            managerState = managerState.copy(finance=FinanceEngine().applySignatureFee(managerState.finance, signatureFee, "Taxa de assinatura — transferência de ${WorldDatabase.allDrivers.firstOrNull { it.id == offer.driverId }?.name ?: "Piloto"} — ${offer.seasonTarget}"))
            store.saveDriverMarket(managerState.driverMarket)
            store.saveFinance(teamId, managerState.finance)
            marketMessage = "Oferta aceita. ${WorldDatabase.allDrivers.firstOrNull { it.id == offer.driverId }?.name ?: "Piloto"} irá para ${WorldDatabase.teams.firstOrNull { it.id == offer.toTeamId }?.name ?: "a nova equipe"} em ${offer.seasonTarget}. Taxa de assinatura: € ${signatureFee/1_000_000.0}M."
        }.onFailure { marketMessage = it.message ?: "Não foi possível aceitar a proposta." }
    }

    fun rejectIncomingMarketOffer(offer: com.f1teammanager.core.manager.DriverOffer) {
        runCatching {
            managerState = managerState.copy(driverMarket = marketEngine.rejectIncomingOffer(managerState.driverMarket, offer, store.season, currentWeek))
            store.saveDriverMarket(managerState.driverMarket)
            marketMessage = "Proposta recusada."
        }.onFailure { marketMessage = it.message ?: "Não foi possível recusar a proposta." }
    }

    fun acceptMarketCounter(offer: com.f1teammanager.core.manager.DriverOffer) {
        runCatching {
            val signatureFee = marketEngine.signatureFeeFor(managerState.driverMarket, offer.driverId, team.id, store.season)
            if (signatureFee > managerState.finance.budget.coerceAtLeast(0L)) { marketMessage = "Saldo insuficiente para pagar a taxa de assinatura."; return@runCatching }
            managerState = managerState.copy(driverMarket = marketEngine.acceptCounterOffer(managerState.driverMarket, offer, store.season, currentWeek))
            managerState = managerState.copy(finance=FinanceEngine().applySignatureFee(managerState.finance, signatureFee, "Taxa de assinatura de ${WorldDatabase.allDrivers.firstOrNull { it.id == offer.driverId }?.name ?: "Piloto"} — ${offer.seasonTarget}"))
            store.saveDriverMarket(managerState.driverMarket)
            store.saveFinance(teamId, managerState.finance)
            marketMessage = "Contraproposta aceita. ${WorldDatabase.allDrivers.firstOrNull { it.id == offer.driverId }?.name ?: "Piloto"} assinou para ${offer.seasonTarget}. Taxa de assinatura: € ${signatureFee/1_000_000.0}. Salário começa em ${offer.seasonTarget}."
        }.onFailure { marketMessage = it.message ?: "Não foi possível aceitar a contraproposta." }
    }

    fun rejectMarketCounter(offer: com.f1teammanager.core.manager.DriverOffer) {
        runCatching {
            managerState = managerState.copy(driverMarket = marketEngine.rejectCounterOffer(managerState.driverMarket, offer, store.season, currentWeek))
            store.saveDriverMarket(managerState.driverMarket)
            marketMessage = "Contraproposta recusada."
        }.onFailure { marketMessage = it.message ?: "Não foi possível recusar a contraproposta." }
    }

    fun makeMarketCounter(previous: com.f1teammanager.core.manager.DriverOffer, replacementDriverId: Int?, years: Int, salary: Long, role: DriverTeamRole) {
        val driver = WorldDatabase.allDrivers.first { it.id == previous.driverId }
        runCatching {
            val (next, offer) = marketEngine.counterOffer(managerState.driverMarket, previous, store.season, currentWeek, salary, years, role, replacementDriverId)
            managerState = managerState.copy(driverMarket=next)
            store.saveDriverMarket(managerState.driverMarket); store.saveFinance(teamId, managerState.finance)
            marketMessage = when(offer.status) {
                NegotiationStatus.ACCEPTED -> "${driver.name} aceitou a contraproposta. Pré-contrato para ${store.season+1} assinado."
                NegotiationStatus.COUNTER -> "${driver.name} apresentou uma nova contraproposta. Rodada ${offer.round}/3."
                NegotiationStatus.REJECTED -> "${driver.name} recusou a proposta após a rodada ${offer.round}/3."
                else -> "Negociação atualizada."
            }
        }.onFailure { marketMessage = it.message ?: "Não foi possível continuar a negociação." }
    }

    fun runScouting(driverId:Int) {
        runCatching {
            val (next, report)=marketEngine.scout(managerState.driverMarket,driverId,team.id,currentWeek,store.season,managerState.facilities.level(FacilityType.SCOUTING))
            managerState=managerState.copy(driverMarket=next,finance=managerState.finance.transact(-report.cost,"Scouting de piloto ${driverId}"))
            store.saveDriverMarket(managerState.driverMarket); store.saveFinance(teamId,managerState.finance)
            marketMessage="Scouting concluído: salário ${formatMoney(report.expectedSalary)} • valor ${formatMoney(report.marketValue)} • interesse ${report.interest}/100."
        }.onFailure { marketMessage=it.message ?: "Não foi possível realizar o scouting." }
    }

    fun signSponsor(sponsor:SponsorContract) {
        runCatching { managerState=ManagerMarketEngine().signSponsor(managerState,sponsor,sponsor.slot); store.saveFinance(teamId,managerState.finance); store.saveSponsors(teamId,managerState.sponsors); sponsorMessage="Contrato ${sponsor.name} aceito por ${sponsor.races} ${if(sponsor.races==1) "corrida" else "corridas"}." }
            .onFailure { sponsorMessage=it.message ?: "Não foi possível aceitar o contrato." }
    }

    fun selectTeam(id: Int) { store.startNewCareer(id); marketMessage = ""; calendarMessage = ""; facilityMessage = ""; managerState=initialManagerState(id,store); teamId = id; roundIndex = 0; currentWeek = store.currentWeek; hasCareer = true; screen = Screen.HOME; nav = Nav.HOME }

    fun upgradeFacility(type: FacilityType) {
        runCatching {
            val next = FacilityEngine.upgrade(managerState, type, currentWeek)
            managerState = next
            store.saveFacilityUpgrade(teamId, next.facilityUpgrade)
            store.saveTechnicalInvestment(teamId, next.technicalInvestment)
            store.saveFinance(teamId, next.finance)
            facilityMessage = "Melhoria de ${FacilityEngine.label(type)} iniciada: nível ${next.facilityUpgrade?.previousLevel} → ${next.facilityUpgrade?.targetLevel}. Prazo: 12 semanas. Não pode ser cancelada."
        }.onFailure {
            facilityMessage = it.message ?: "Não foi possível iniciar a melhoria de ${FacilityEngine.label(type)}."
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(background = Bg, surface = Panel, primary = Red, onPrimary = Color.White, onSurface = Color.White)) {
        Surface(Modifier.fillMaxSize(), color = Bg) {
            fun newsKey(n: com.f1teammanager.core.manager.MarketNotification): String =
        "${n.season}|${n.week}|${n.title}|${n.message}"

    fun unreadNewsCount(): Int {
        val read = store.loadReadNewsKeys()
        return managerState.driverMarket.notifications.count { it.season == store.season && newsKey(it) !in read }
    }

    fun markNewsRead() {
        val current = managerState.driverMarket.notifications.filter { it.season == store.season }
        store.markNewsRead(current.map(::newsKey))
        managerState = managerState.copy(driverMarket = store.loadDriverMarket() ?: managerState.driverMarket)
    }

    managerState.factory.pendingInstallations.firstOrNull()?.let { pendingPiece ->
        val garage = managerState.garage ?: TeamGarageFactory.fromCarState(managerState.car, team.id, store.season)
        AlertDialog(
            onDismissRequest = { /* A decisão é obrigatória para concluir a instalação. */ },
            title = { Text("PEÇA PRONTA • ${componentLabel(pendingPiece.component).uppercase()} V${pendingPiece.version}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("A Fábrica concluiu a peça. Agora você decide em qual carro ela será instalada.", color = Muted, fontSize = 11.sp)
                    Text("Desempenho ${pendingPiece.performance} • Confiabilidade ${pendingPiece.reliability}", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 10.sp)
                    Text("Carro 1: ${garage.car1.componentValue(pendingPiece.component)} • Carro 2: ${garage.car2.componentValue(pendingPiece.component)}", color = Muted, fontSize = 10.sp)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = { installPendingPiece(pendingPiece, GarageCarId.CAR_1) },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = Red, contentColor = Color.White)
                        ) { Text("CARRO 1", fontWeight = FontWeight.Black, fontSize = 10.sp) }
                        Button(
                            onClick = { installPendingPiece(pendingPiece, GarageCarId.CAR_2) },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = Panel2, contentColor = Color.White)
                        ) { Text("CARRO 2", fontWeight = FontWeight.Black, fontSize = 10.sp) }
                    }
                }
            },
            confirmButton = {}
        )
    }

    when (screen) {
                Screen.SELECT_TEAM -> TeamSelect(::selectTeam)
                Screen.HOME -> AppScaffold("${team.name.uppercase()} • ${store.season}", nav, { nav = it; screen = when(it){Nav.HOME->Screen.HOME;Nav.TEAM->Screen.TEAM;Nav.CAR->Screen.CAR;Nav.CALENDAR->Screen.CALENDAR;Nav.STANDINGS->Screen.STANDINGS} }, onMore={ screen=Screen.MANAGEMENT }) { Home(team.name, CarCatalog.forTeam(team.id), drivers, round, currentWeek, store, managerState, snapshot?.phase == "RACE" && snapshot?.completed == false, onStart=::startWeekend, onDrivers={screen=Screen.DRIVERS}, onWeekend={screen=Screen.WEEKEND}, onMarket={screen=Screen.MARKET}, onFinance={screen=Screen.FINANCE}, onStandings={screen=Screen.STANDINGS}, onNews={markNewsRead(); screen=Screen.NEWS}, onCar={nav=Nav.CAR;screen=Screen.CAR}, onSkipWeek=::skipOneWeek, onStartNextSeason=::startNextSeason, onJumpNextRace=::jumpToNextRace) }
                Screen.TEAM_OVERVIEW -> {
                    TeamOverviewScreen(
                        store = store,
                        playerTeamId = teamId,
                        playerManagerState = managerState,
                        selectedTeamId = teamOverviewSelectedId,
                        currentWeek = currentWeek,
                        aiFinance = aiFinance,
                        aiDevelopment = aiDevelopment,
                        onBack = { screen = Screen.MANAGEMENT },
                        onSelectTeam = { teamOverviewSelectedId = it }
                    )
                }
                Screen.TEAM -> AppScaffold("EQUIPE", nav, { nav=it; screen=when(it){Nav.HOME->Screen.HOME;Nav.TEAM->Screen.TEAM;Nav.CAR->Screen.CAR;Nav.CALENDAR->Screen.CALENDAR;Nav.STANDINGS->Screen.STANDINGS} }, onMore={screen=Screen.MANAGEMENT}) {
                    val teamGarage = managerState.garage ?: TeamGarageFactory.fromInitial(team)
                    val teamPerformance = teamGarage.teamAverageOverall
                    val teamReliability = ((teamGarage.car1.reliability + teamGarage.car2.reliability) / 2).coerceIn(1,100)
                    Team(team.name, teamPerformance, teamReliability, drivers, managerState.facilities, managerState.technicalInvestment, facilityMessage, managerState.facilityUpgrade, onDrivers={screen=Screen.DRIVERS}, onDriverProfile={ driverHistoryId = it; driverHistoryOrigin = Screen.TEAM; screen = Screen.DRIVER_HISTORY }, onDriverDevelopment={screen=Screen.DRIVER_DEVELOPMENT}, onMarket={screen=Screen.MARKET}, onTechnicalInvestment={screen=Screen.TECHNICAL_INVESTMENT}, onUpgrade=::upgradeFacility)
                }
                Screen.DRIVERS -> DetailScaffold("PILOTOS", {screen=Screen.TEAM}) { Drivers(drivers, store) }
                Screen.DRIVER_HISTORY -> {
                    val back = driverHistoryOrigin
                    DetailScaffold("PILOTO", { screen = back }) { DriverHistory(driverHistoryId, store, managerState.driverMarket) }
                }
                Screen.DRIVER_DEVELOPMENT -> DetailScaffold("DESENVOLVIMENTO DE PILOTOS", {screen=Screen.TEAM}) { DriverDevelopmentScreen(drivers, managerState, currentWeek, ::startDriverDevelopment) }
                 Screen.TECHNICAL_INVESTMENT -> DetailScaffold("INVESTIMENTO TÉCNICO", {screen=Screen.TEAM}) { TechnicalInvestmentScreen(managerState.technicalInvestment, store.season) }
                Screen.CAR -> AppScaffold("CARRO / P&D", nav, { nav=it; screen=when(it){Nav.HOME->Screen.HOME;Nav.TEAM->Screen.TEAM;Nav.CAR->Screen.CAR;Nav.CALENDAR->Screen.CALENDAR;Nav.STANDINGS->Screen.STANDINGS} }, onMore={screen=Screen.MANAGEMENT}) { Car(CarCatalog.forTeam(team.id), managerState, currentWeek, carMessage, ::startDevelopment, ::manufactureDesign, ::investNextSeason, ::setNextSeasonFocus) }
                Screen.CALENDAR -> AppScaffold("CALENDÁRIO", nav, { nav=it; screen=when(it){Nav.HOME->Screen.HOME;Nav.TEAM->Screen.TEAM;Nav.CAR->Screen.CAR;Nav.CALENDAR->Screen.CALENDAR;Nav.STANDINGS->Screen.STANDINGS} }, onMore={screen=Screen.MANAGEMENT}) { Calendar(roundIndex, store.roundIndex, currentWeek, store.season, calendarMessage, ::openHistory, { store.raceHistory(it) != null }, ::skipOneWeek, ::jumpToNextRace) }
                Screen.STANDINGS -> AppScaffold("CAMPEONATO", nav, { nav=it; screen=when(it){Nav.HOME->Screen.HOME;Nav.TEAM->Screen.TEAM;Nav.CAR->Screen.CAR;Nav.CALENDAR->Screen.CALENDAR;Nav.STANDINGS->Screen.STANDINGS} }, onMore={screen=Screen.MANAGEMENT}) { Standings(team.id, store) }
                Screen.FINANCE -> DetailScaffold("FINANÇAS", {screen=Screen.HOME}) { Finance(store, team.id, managerState, sponsorMessage, ::signSponsor) }
                Screen.MARKET -> DetailScaffold("MERCADO DE PILOTOS", {screen=Screen.TEAM}) { DriverMarket(store, team.id, currentWeek, marketDriverId, managerState.driverMarket, marketMessage, { marketDriverId = it }, { driverHistoryId = it; driverHistoryOrigin = Screen.MARKET; screen = Screen.DRIVER_HISTORY }, ::makeMarketInterest, ::makeMarketProposal, ::makeMarketCounter, ::acceptMarketCounter, ::rejectMarketCounter, ::renewMarketDriver, ::acceptIncomingMarketOffer, ::rejectIncomingMarketOffer, ::runScouting) }
                Screen.WEEKEND -> DetailScaffold("FIM DE SEMANA", {screen=Screen.HOME}) { Weekend(round, currentWeek, ::startWeekend) }
                Screen.QUALIFYING -> DetailScaffold("QUALIFICAÇÃO", { screen = Screen.HOME }) {
                    Qualifying(
                        snapshot!!,
                        round,
                        simulate = ::simulateQualifying,
                        start = ::startRace
                    )
                }
                Screen.RACE -> DetailScaffold(round.grandPrix, { screen = Screen.CALENDAR; nav = Nav.CALENDAR }) { Race(round.grandPrix, snapshot!!, drivers, ::advanceRace, { id, mode -> snapshot = engine.setStrategy(id, mode) }, { id, tyre -> snapshot = engine.pitNow(id, tyre) }, { id, plan -> snapshot = engine.pitWithPlan(id, plan) }, { id, plan -> snapshot = engine.setTyrePlan(id, plan) }, { action -> snapshot = engine.choose(action) }) }
                Screen.RESULT -> DetailScaffold("RESULTADO", { returnToCalendarAfterRace() }) { Result(result!!, team.id, store, ::returnToCalendarAfterRace) }
                Screen.HISTORY -> DetailScaffold("CLASSIFICAÇÃO ARQUIVADA", { screen = Screen.CALENDAR }) { HistoryResult(historyRound, historyResult) }
                Screen.HISTORY_CENTER -> DetailScaffold("HISTÓRIA", { screen = Screen.HOME }) { HistoryScreen(store) }
                Screen.NEWS -> DetailScaffold("NOTÍCIAS", { screen = Screen.HOME }) { MarketNews(managerState.driverMarket, store.season, ::markNewsRead) }
                Screen.HALL_OF_FAME -> DetailScaffold("HALL DA FAMA", { screen = Screen.HOME }) { HallOfFameScreen(store) }
                Screen.RECORDS -> DetailScaffold("RECORDES", { screen = Screen.HOME }) { RecordsScreen(store) }
                Screen.SEASON -> DetailScaffold("TEMPORADA", { screen = Screen.HOME }) { SeasonArchive(store) }
                Screen.MANAGEMENT -> DetailScaffold("GESTÃO", { screen = Screen.HOME }) { ManagementHub(snapshot?.phase == "RACE" && snapshot?.completed == false, onDrivers={screen=Screen.DRIVERS}, onMarket={screen=Screen.MARKET}, onFinance={screen=Screen.FINANCE}, onSeason={screen=Screen.SEASON}, onCar={screen=Screen.CAR}, onStandings={screen=Screen.STANDINGS}, onCalendar={screen=Screen.CALENDAR}, onWeekend={screen=Screen.WEEKEND}, onTeams={teamOverviewSelectedId=teamId; screen=Screen.TEAM_OVERVIEW}, onRace={screen=Screen.RACE}, onHistory={screen=Screen.HISTORY_CENTER}, onNews={markNewsRead(); screen=Screen.NEWS}, onHallOfFame={screen=Screen.HALL_OF_FAME}, onRecords={screen=Screen.RECORDS}) }
            }
        }
    }
}

@Composable private fun AppScaffold(title:String, nav:Nav, select:(Nav)->Unit, onMore:()->Unit, content:@Composable ColumnScope.()->Unit) {
    Column(Modifier.fillMaxSize().statusBarsPadding()) { TopBar(title, onMore); Column(Modifier.weight(1f)) { content() }; BottomNav(nav, select) }
}
@Composable private fun DetailScaffold(title:String, back:()->Unit, content:@Composable ColumnScope.()->Unit) { Column(Modifier.fillMaxSize().statusBarsPadding()) { BackTopBar(title, back); Column(Modifier.weight(1f)) { content() } } }
@Composable private fun BackTopBar(title:String, back:()->Unit) { Row(Modifier.fillMaxWidth().padding(horizontal=14.dp,vertical=10.dp),verticalAlignment=Alignment.CenterVertically){Text("‹",color=Color.White,fontSize=34.sp,modifier=Modifier.clickable{back()}.padding(horizontal=6.dp));Text(title,color=Color.White,fontWeight=FontWeight.Bold,maxLines=1,overflow=TextOverflow.Ellipsis,modifier=Modifier.weight(1f));Text("F1 MANAGER",color=Red,fontWeight=FontWeight.Black,fontSize=12.sp)}}
@Composable private fun TopBar(title:String, action:()->Unit) { Row(Modifier.fillMaxWidth().padding(horizontal=16.dp,vertical=12.dp), verticalAlignment=Alignment.CenterVertically, horizontalArrangement=Arrangement.SpaceBetween) { Text("F1 MANAGER",color=Red,fontWeight=FontWeight.Black,letterSpacing=1.sp); Text(title,color=Color.White,fontWeight=FontWeight.Bold,maxLines=1,overflow=TextOverflow.Ellipsis); Text("⋮",color=Color.White,fontSize=25.sp,modifier=Modifier.clickable{action()}) } }
@Composable private fun BottomNav(selected:Nav, select:(Nav)->Unit) { Row(Modifier.fillMaxWidth().navigationBarsPadding().background(Color(0xFF101216)).padding(6.dp), horizontalArrangement=Arrangement.SpaceEvenly) { listOf(Nav.HOME to "⌂",Nav.TEAM to "♟",Nav.CAR to "▰",Nav.CALENDAR to "▦",Nav.STANDINGS to "≡").forEach{(n,l)-> Column(horizontalAlignment=Alignment.CenterHorizontally,modifier=Modifier.weight(1f).clickable{select(n)}.padding(5.dp)){Text(l,color=if(selected==n)Red else Muted,fontSize=20.sp);Text(n.name,color=if(selected==n)Color.White else Muted,fontSize=9.sp,fontWeight=FontWeight.Bold)}} } }

@Composable
private fun Home(
    team: String,
    car: com.f1teammanager.core.season.CarSpec,
    drivers: List<com.f1teammanager.core.season.DriverDefinition>,
    round: RoundDefinition,
    currentWeek: Int,
    store: CareerPreferences,
    managerState: TeamManagerState,
    raceInProgress: Boolean,
    onStart: () -> Unit,
    onDrivers: () -> Unit,
    onWeekend: () -> Unit,
    onMarket: () -> Unit,
    onFinance: () -> Unit,
    onStandings: () -> Unit,
    onNews: () -> Unit,
    onCar: () -> Unit,
    onSkipWeek: () -> Unit,
    onJumpNextRace: () -> Unit,
    onStartNextSeason: () -> Unit
) {
    val teamId = WorldDatabase.teams.first { it.name == team }.id
    val teamPoints = store.constructorPoints()[teamId] ?: 0
    val atRaceWeek = currentWeek == round.weekOfSeason

    LazyColumn(
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        if (store.isSeasonEnded()) {
            item {
                Card(
                    Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(Panel),
                    border = BorderStroke(1.dp, Red)
                ) {
                    Column(
                        Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(7.dp)
                    ) {
                        Text(
                            "TEMPORADA ${store.season} ENCERRADA",
                            color = Red,
                            fontWeight = FontWeight.Black,
                            fontSize = 15.sp
                        )
                        Text(
                            "As 30 corridas foram concluídas e o histórico foi arquivado.",
                            color = Color.White,
                            fontSize = 10.sp
                        )
                        Button(
                            onClick = onStartNextSeason,
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Red,
                                contentColor = Color.White
                            )
                        ) {
                            Text("IR PARA NOVA TEMPORADA", fontWeight = FontWeight.Black)
                        }
                    }
                }
            }
        }

        item { TeamHeroCard(team, car.model) }

        item {
            val readNewsKeys = store.loadReadNewsKeys()
            val unread = managerState.driverMarket.notifications.filter { it.season == store.season && "${it.season}|${it.week}|${it.title}|${it.message}" !in readNewsKeys }
            val marketNewsCount = unread.size
            val marketResponseCount = unread.count { it.title == "RESPOSTA DO PILOTO" || it.title == "DECISÃO DA EQUIPE" || it.title == "CONTRAPROPOSTA DA EQUIPE" }
            val rdCompletionCount = unread.count { it.title == "P&D CONCLUÍDO" }
            val sponsorshipSlotsFree = managerState.sponsors.count { it.active } < 5
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (marketResponseCount > 0) {
                    Button(onClick = onNews, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Red, contentColor = Color.White), contentPadding = PaddingValues(vertical = 8.dp)) {
                        Text("📨 MERCADO $marketResponseCount", fontWeight = FontWeight.Black, fontSize = 9.sp)
                    }
                } else if (marketNewsCount > 0) {
                    Button(onClick = onNews, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Red, contentColor = Color.White), contentPadding = PaddingValues(vertical = 8.dp)) {
                        Text("📰 NOTÍCIAS $marketNewsCount", fontWeight = FontWeight.Black, fontSize = 9.sp)
                    }
                }
                if (rdCompletionCount > 0) {
                    Button(onClick = onNews, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Panel2, contentColor = Color.White), border = BorderStroke(1.dp, Red), contentPadding = PaddingValues(vertical = 8.dp)) {
                        Text("🔧 P&D CONCLUÍDO $rdCompletionCount", fontWeight = FontWeight.Black, fontSize = 9.sp)
                    }
                } else if (sponsorshipSlotsFree) {
                    Button(onClick = onFinance, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Panel2, contentColor = Color.White), border = BorderStroke(1.dp, Red), contentPadding = PaddingValues(vertical = 8.dp)) {
                        Text("💰 PATROCÍNIO DISPONÍVEL", fontWeight = FontWeight.Black, fontSize = 9.sp)
                    }
                }
            }
        }

        item {
            SectionTitle("SITUAÇÃO DO CAMPEONATO")
            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(Panel)) {
                Row(
                    Modifier.fillMaxWidth().padding(8.dp),
                    horizontalArrangement = Arrangement.spacedBy(7.dp)
                ) {
                    StatCard("CONSTRUTORES", "P${constructorPosition(teamId, store)}", "$teamPoints PTS", Modifier.weight(1f))
                    StatCard("PILOTO 1", drivers.firstOrNull()?.name ?: "—", "titular", Modifier.weight(1f))
                    StatCard("ORÇAMENTO", formatMoney(managerState.finance.budget), "disponível", Modifier.weight(1f))
                }
            }
        }

        item {
            SectionTitle(if (store.isSeasonEnded()) "TEMPORADA ENCERRADA" else "PRÓXIMA CORRIDA")
            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(Panel)) {
                Column(Modifier.padding(13.dp)) {
                    if (store.isSeasonEnded()) {
                        Text("${store.season} concluída", color = Red, fontSize = 21.sp, fontWeight = FontWeight.Black)
                        Text(
                            "O calendário de ${store.season} foi encerrado e o histórico está arquivado.",
                            color = Muted,
                            fontSize = 10.sp,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    } else {
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("ROUND ${round.round}", color = Red, fontWeight = FontWeight.Black)
                            Text("SEMANA ${round.weekOfSeason}", color = Color.White, fontWeight = FontWeight.Black, fontSize = 11.sp)
                        }
                        RaceImage(round, Modifier.fillMaxWidth().aspectRatio(1f).padding(top = 8.dp))
                        Text(round.grandPrix, color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(top = 7.dp))
                        Text(round.circuit, color = Muted, fontSize = 12.sp)
                        Row(
                            Modifier.fillMaxWidth().padding(top = 9.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("${round.laps} VOLTAS", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Text(seasonDateLabel(round, store.season), color = Muted, fontSize = 10.sp)
                        }
                        Button(
                            onClick = onStart,
                            enabled = raceInProgress || atRaceWeek,
                            modifier = Modifier.fillMaxWidth().padding(top = 9.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Red,
                                contentColor = Color.White,
                                disabledContainerColor = Panel2,
                                disabledContentColor = Muted
                            )
                        ) {
                            Text(
                                if (raceInProgress) "RETOMAR PIT WALL"
                                else if (atRaceWeek) "ABRIR FIM DE SEMANA"
                                else "IR PARA CALENDÁRIO",
                                fontWeight = FontWeight.Black
                            )
                        }
                    }
                }
            }
        }

        item {
            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(Panel)) {
                Column(Modifier.padding(12.dp)) {
                    Text("CALENDÁRIO", color = Red, fontWeight = FontWeight.Black, fontSize = 11.sp)
                    Text(
                        "O P&D avança com as semanas do calendário, inclusive semanas de GP. Nunca é possível ultrapassar um GP sem simular a corrida.",
                        color = Muted,
                        fontSize = 9.sp,
                        modifier = Modifier.padding(top = 3.dp)
                    )
                    Row(
                        Modifier.fillMaxWidth().padding(top = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(7.dp)
                    ) {
                        Button(
                            onClick = onSkipWeek,
                            enabled = currentWeek < 56 && !atRaceWeek,
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Panel2,
                                contentColor = Color.White,
                                disabledContainerColor = Color(0xFF101116),
                                disabledContentColor = Muted
                            ),
                            contentPadding = PaddingValues(vertical = 8.dp)
                        ) { Text("PULAR 1 SEMANA", fontSize = 8.sp, fontWeight = FontWeight.Black) }

                        Button(
                            onClick = onJumpNextRace,
                            enabled = currentWeek < round.weekOfSeason,
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Red,
                                contentColor = Color.White,
                                disabledContainerColor = Color(0xFF3A0D0D),
                                disabledContentColor = Muted
                            ),
                            contentPadding = PaddingValues(vertical = 8.dp)
                        ) { Text("PULAR ATÉ PRÓXIMO GP", fontSize = 8.sp, fontWeight = FontWeight.Black) }
                    }
                }
            }
        }

        item {
            SectionTitle("ACESSO RÁPIDO")
            val shortcuts = listOf(
                "FIM DE SEMANA" to onWeekend,
                "PILOTOS" to onDrivers,
                "MERCADO" to onMarket,
        "CENTRAL DE NOTÍCIAS" to onNews,
                "FINANÇAS" to onFinance,
                "CAMPEONATO" to onStandings,
                "CARRO / P&D" to onCar
            )
            Column(
                verticalArrangement = Arrangement.spacedBy(7.dp),
                modifier = Modifier.padding(top = 3.dp)
            ) {
                shortcuts.chunked(3).forEach { row ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        row.forEach { (label, action) ->
                            Button(
                                onClick = action,
                                modifier = Modifier.weight(1f).height(48.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Panel2, contentColor = Color.White),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 4.dp)
                            ) {
                                Text(label, fontSize = 8.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                            }
                        }
                    }
                }
            }
        }

        item {
            SectionTitle("EQUIPE")
            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(Panel)) {
                Column(Modifier.padding(12.dp)) {
                    Text("PILOTOS TITULARES", color = Red, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    Row(
                        Modifier.fillMaxWidth().padding(top = 7.dp),
                        horizontalArrangement = Arrangement.spacedBy(7.dp)
                    ) {
                        drivers.take(2).forEachIndexed { index, d ->
                            Column(
                                Modifier.weight(1f).background(Panel2, RoundedCornerShape(8.dp)).padding(10.dp)
                            ) {
                                Text(d.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text("#${index + 1} • Titular", color = Muted, fontSize = 9.sp)
                                Text("P${driverChampionshipPosition(d.id, store)}", color = Color.White, fontWeight = FontWeight.Black, fontSize = 15.sp, modifier = Modifier.padding(top = 4.dp))
                            }
                        }
                    }
                    Button(
                        onClick = onDrivers,
                        modifier = Modifier.fillMaxWidth().padding(top = 7.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Panel2, contentColor = Color.White)
                    ) { Text("VER PERFIL COMPLETO →", fontWeight = FontWeight.Black, fontSize = 9.sp) }
                }
            }
        }
    }
}

@Composable private fun TeamHeroCard(team:String,model:String){Box(Modifier.fillMaxWidth().height(138.dp).clip(RoundedCornerShape(12.dp)).background(Panel).border(1.dp,Red,RoundedCornerShape(12.dp))){Row(Modifier.fillMaxSize().padding(16.dp),verticalAlignment=Alignment.CenterVertically){TeamLogo(team,WorldDatabase.teams.firstOrNull{it.name.equals(team,ignoreCase=true)}?.id ?: 0,Modifier.size(86.dp));Spacer(Modifier.width(14.dp));Column(Modifier.weight(1f)){Text(team.uppercase(),color=Color.White,fontSize=23.sp,fontWeight=FontWeight.Black);Text(model,color=Red,fontSize=17.sp,fontWeight=FontWeight.Black);Text("MODELO ESPECÍFICO DA EQUIPE",color=Muted,fontSize=10.sp,modifier=Modifier.padding(top=4.dp))}}}}

@Composable
private fun Team(
    name: String,
    performance: Int,
    reliability: Int,
    drivers: List<com.f1teammanager.core.season.DriverDefinition>,
    facilities: TeamFacilitiesState,
    technicalInvestment: TechnicalInvestmentState,
    facilityMessage: String,
    facilityUpgrade: com.f1teammanager.core.manager.FacilityUpgradeState?,
    onDrivers: () -> Unit,
    onDriverProfile: (Int) -> Unit,
    onDriverDevelopment: () -> Unit,
    onMarket: () -> Unit,
    onTechnicalInvestment: () -> Unit,
    onUpgrade: (FacilityType) -> Unit
) {
    LazyColumn(
        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Cabeçalho da tela: o nome da equipe aparece somente aqui.
        item {
            Column(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 2.dp)) {
                Text(name, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Black, maxLines = 1)
                Text("GESTÃO DA EQUIPE", color = Red, fontSize = 10.sp, fontWeight = FontWeight.Black)
            }
        }

        // Card aprovado: logo + dados da equipe, sem repetir o nome da equipe.
        item {
            Card(
                Modifier.fillMaxWidth().height(96.dp),
                colors = CardDefaults.cardColors(containerColor = Panel)
            ) {
                Row(
                    Modifier.fillMaxSize().padding(horizontal = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TeamLogo(
                        name,
                        WorldDatabase.teams.firstOrNull { it.name.equals(name, ignoreCase = true) }?.id ?: 0,
                        Modifier.size(108.dp, 76.dp)
                    )
                    Spacer(Modifier.width(12.dp))
                    Box(Modifier.width(1.dp).height(60.dp).background(Line))
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("DESEMPENHO", color = Muted, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                        Text(performance.toString(), color = Red, fontSize = 21.sp, fontWeight = FontWeight.Black)
                    }
                    Box(Modifier.width(1.dp).height(60.dp).background(Line))
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("CONFIABILIDADE", color = Muted, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                        Text(
                            reliability.toString(),
                            color = if (reliability >= 76) Green else Red,
                            fontSize = 21.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                }
            }
        }

        item { SectionTitle("PILOTOS TITULARES") }
        items(drivers.take(2), key = { it.id }) { driver ->
            TeamDriverCard(driver, onClick = { onDriverProfile(driver.id) })
        }
        item {
            Button(
                onClick = onDrivers,
                modifier = Modifier.fillMaxWidth().height(48.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Red, contentColor = Color.White),
                shape = RoundedCornerShape(24.dp),
                contentPadding = PaddingValues(horizontal = 12.dp)
            ) {
                Text("ABRIR PERFIS DOS PILOTOS", fontWeight = FontWeight.Black, fontSize = 11.sp)
            }
        }

        item { SectionTitle("GESTÃO") }
        item {
            Card(
                Modifier.fillMaxWidth().clickable { onTechnicalInvestment() },
                colors = CardDefaults.cardColors(containerColor = Panel)
            ) {
                Column(Modifier.fillMaxWidth().padding(12.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("INVESTIMENTO TÉCNICO ${technicalInvestment.season}", color = Color.White, fontWeight = FontWeight.Black, fontSize = 12.sp)
                            Text("Ranking ${technicalInvestment.ranking} • Nível ${technicalInvestment.level}", color = Muted, fontSize = 9.sp)
                        }
                        Text("€${technicalInvestment.totalSpent / 1_000_000}M / €${technicalInvestment.annualCap / 1_000_000}M", color = Red, fontWeight = FontWeight.Black, fontSize = 11.sp)
                    }
                    LinearProgressIndicator(
                        progress = { (technicalInvestment.totalSpent.toFloat() / technicalInvestment.annualCap.toFloat()).coerceIn(0f,1f) },
                        modifier = Modifier.fillMaxWidth().height(5.dp).padding(top = 6.dp),
                        color = if (technicalInvestment.usedPercent >= 90) Red else if (technicalInvestment.usedPercent >= 75) Color.Yellow else Green,
                        trackColor = Line
                    )
                    Row(Modifier.fillMaxWidth().padding(top = 5.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Disponível €${technicalInvestment.available / 1_000_000}M", color = Muted, fontSize = 8.sp)
                        Text("VER CONTROLE ›", color = Red, fontWeight = FontWeight.Black, fontSize = 9.sp)
                    }
                }
            }
        }
        item {
            Row(
                Modifier.fillMaxWidth()
                    .height(78.dp)
                    .background(Panel, RoundedCornerShape(9.dp))
                    .clickable { onMarket() }
                    .padding(horizontal = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("♟", color = Color.White, fontSize = 30.sp, modifier = Modifier.width(38.dp))
                Column(Modifier.weight(1f)) {
                    Text("MERCADO DE PILOTOS", color = Color.White, fontWeight = FontWeight.Black, fontSize = 12.sp)
                    Text("Contratos, salários e disponibilidade.", color = Muted, fontSize = 10.sp)
                }
                Text("›", color = Red, fontSize = 31.sp, fontWeight = FontWeight.Black)
            }
        }

        item {
            if (facilityMessage.isNotBlank()) {
                Text(
                    facilityMessage,
                    color = if (facilityMessage.contains("melhorada:", ignoreCase = true)) Green else Red,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 2.dp)
                )
            }
        }
        item { SectionTitle("INSTALAÇÕES") }
        item {
            val active = facilityUpgrade
            if (active != null) {
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Panel2)) {
                    Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Text("OBRA EM ANDAMENTO", color = Red, fontWeight = FontWeight.Black, fontSize = 11.sp)
                        Text("${FacilityEngine.label(active.facility)} · Nível ${active.previousLevel} → ${active.targetLevel}", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        LinearProgressIndicator(progress = { (active.totalWeeks - active.remainingWeeks).coerceAtLeast(0) / active.totalWeeks.toFloat() }, modifier = Modifier.fillMaxWidth().height(5.dp), color = Red, trackColor = Line)
                        Text("${active.remainingWeeks} semana(s) restante(s) de 12 · custo pago · obra não cancelável", color = Muted, fontSize = 9.sp)
                    }
                }
            }
        }
        items(FacilityType.values().toList(), key = { it.name }) { type ->
            val level = facilities.level(type)
            val cost = FacilityEngine.upgradeCost(level)
            Card(
                Modifier.fillMaxWidth().height(104.dp),
                colors = CardDefaults.cardColors(containerColor = Panel)
            ) {
                Row(Modifier.fillMaxSize().padding(horizontal = 10.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                    FacilityGlyph(type, Modifier.size(42.dp))
                    Spacer(Modifier.width(8.dp))
                    Column(Modifier.weight(1f).fillMaxHeight()) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(FacilityEngine.label(type).uppercase(), color = Color.White, fontWeight = FontWeight.Black, fontSize = 10.sp, maxLines = 1)
                            Text("Nível $level", color = Red, fontWeight = FontWeight.Black, fontSize = 10.sp)
                        }
                        Text(
                            FacilityEngine.description(type),
                            color = Muted,
                            fontSize = 8.sp,
                            lineHeight = 10.sp,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.padding(top = 2.dp)
                        )
                        LinearProgressIndicator(
                            progress = { level / 10f },
                            modifier = Modifier.fillMaxWidth().height(4.dp).padding(top = 5.dp),
                            color = Red,
                            trackColor = Line
                        )
                        Row(
                            Modifier.fillMaxWidth().padding(top = 5.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (level < 10) {
                                Text("Próxima: €${(cost ?: 0L) / 1_000_000}M", color = Muted, fontSize = 8.sp)
                                Row(horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.CenterVertically) {
                                    if (type == FacilityType.DRIVER_DEVELOPMENT) {
                                        Button(onClick = onDriverDevelopment, modifier = Modifier.height(30.dp), colors = ButtonDefaults.buttonColors(containerColor = Red, contentColor = Color.White), shape = RoundedCornerShape(15.dp), contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)) { Text("SELECIONAR PILOTO", fontSize = 7.sp, fontWeight = FontWeight.Black) }
                                    }
                                    Button(
                                    onClick = { onUpgrade(type) },
                                    enabled = facilityUpgrade == null,
                                    modifier = Modifier.height(30.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = Panel2, contentColor = Color.White),
                                    shape = RoundedCornerShape(15.dp),
                                    contentPadding = PaddingValues(horizontal = 11.dp, vertical = 0.dp)
                                ) { Text(if (facilityUpgrade != null) "OBRA ATIVA" else "MELHORAR", fontSize = 8.sp, fontWeight = FontWeight.Black) }
                                }
                            } else {
                                Text("NÍVEL MÁXIMO", color = Muted, fontSize = 8.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TechnicalInvestmentScreen(state: TechnicalInvestmentState, season: Int) {
    val progress = (state.totalSpent.toFloat() / state.annualCap.toFloat()).coerceIn(0f, 1f)
    val status = when {
        state.usedPercent >= 100 -> "LIMITE ATINGIDO"
        state.usedPercent >= 90 -> "ATENÇÃO • 90%+"
        state.usedPercent >= 75 -> "ATENÇÃO • 75%+"
        else -> "CONTROLE NORMAL"
    }
    LazyColumn(
        Modifier.fillMaxSize().padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Panel)) {
                Column(Modifier.padding(14.dp)) {
                    Text("CONTROLE DE INVESTIMENTO", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Black)
                    Text("TEMPORADA $season • RANKING ${state.ranking} • NÍVEL ${state.level}", color = Red, fontSize = 9.sp, fontWeight = FontWeight.Black)
                    Spacer(Modifier.height(10.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("LIMITE ANUAL", color = Muted, fontSize = 9.sp)
                        Text("€${state.annualCap / 1_000_000}M", color = Color.White, fontWeight = FontWeight.Black)
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("INVESTIDO", color = Muted, fontSize = 9.sp)
                        Text("€${state.totalSpent / 1_000_000}M", color = Red, fontWeight = FontWeight.Black)
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("DISPONÍVEL", color = Muted, fontSize = 9.sp)
                        Text("€${state.available / 1_000_000}M", color = Green, fontWeight = FontWeight.Black)
                    }
                    LinearProgressIndicator(
                        progress = { progress },
                        Modifier.fillMaxWidth().height(6.dp).padding(top = 7.dp),
                        color = if (state.usedPercent >= 90) Red else if (state.usedPercent >= 75) Color.Yellow else Green,
                        trackColor = Line
                    )
                    Text(status, color = if (state.usedPercent >= 90) Red else if (state.usedPercent >= 75) Color.Yellow else Green, fontSize = 9.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(top = 5.dp))
                }
            }
        }
        item { SectionTitle("DESTINO DO INVESTIMENTO") }
        item { TechnicalSpendCard("P&D / DESIGN", state.researchDesignSpent, state.annualCap) }
        item { TechnicalSpendCard("FABRICAÇÃO DE PEÇAS", state.fabricationSpent, state.annualCap) }
        item { TechnicalSpendCard("EVOLUÇÃO DE INSTALAÇÕES", state.facilityUpgradeSpent, state.annualCap) }
        item {
            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Panel2)) {
                Text(
                    "O limite é anual e reinicia em €0 no início da nova temporada. Projetos já iniciados continuam até a conclusão, mesmo se o limite for atingido depois.",
                    color = Muted, fontSize = 9.sp, lineHeight = 13.sp, modifier = Modifier.padding(12.dp)
                )
            }
        }
    }
}

@Composable
private fun TechnicalSpendCard(label: String, spent: Long, cap: Long) {
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Panel)) {
        Column(Modifier.padding(12.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(label, color = Color.White, fontWeight = FontWeight.Black, fontSize = 10.sp)
                Text("€${spent / 1_000_000}M", color = Red, fontWeight = FontWeight.Black, fontSize = 11.sp)
            }
            LinearProgressIndicator(
                progress = { (spent.toFloat() / cap.toFloat()).coerceIn(0f,1f) },
                Modifier.fillMaxWidth().height(4.dp).padding(top = 5.dp),
                color = Red, trackColor = Line
            )
        }
    }
}


private data class DriverHistorySeasonUi(
    val season: Int,
    val teamId: Int,
    val teamName: String,
    val position: Int,
    val points: Int,
    val wins: Int,
    val podiums: Int,
    val poles: Int,
    val fastestLaps: Int,
    val gps: Int,
    val dnf: Int
)

@Composable
private fun DriverHistory(
    driverId: Int,
    store: CareerPreferences,
    marketState: DriverMarketState
) {
    val driver = runCatching { store.driverDefinition(driverId) }.getOrNull()
        ?: WorldDatabase.allDrivers.firstOrNull { it.id == driverId }
        ?: return
    val allRaces = remember(driverId) { store.history.raceRecords().filter { it.driverId == driverId } }
    val allPoles = remember(driverId) { store.history.poleRecords().filter { it.driverId == driverId } }
    val champions = remember(driverId) { store.history.driverChampions().filter { it.driverId == driverId } }
    val completedRows = remember(driverId) { store.history.driverSeasonRecords().filter { it.driverId == driverId } }

    val currentSeasonRaces = allRaces.filter { it.season == store.season }
    val currentSeasonPoles = allPoles.count { it.season == store.season }

    fun seasonPosition(season: Int, id: Int): Int {
        val rows = store.history.raceRecords(season)
            .groupBy { it.driverId }
            .mapValues { (_, rs) -> rs.sumOf { it.points } }
        return rows.entries.sortedWith(compareByDescending<Map.Entry<Int, Int>> { it.value }.thenBy { it.key })
            .indexOfFirst { it.key == id }
            .takeIf { it >= 0 }?.plus(1) ?: 0
    }

    fun liveSeasonRow(): DriverHistorySeasonUi? {
        if (currentSeasonRaces.isEmpty()) return null
        val teamName = currentSeasonRaces.groupBy { it.teamName }.maxByOrNull { it.value.size }?.key
            ?: WorldDatabase.teams.firstOrNull { it.id == driver.teamId }?.name.orEmpty()
        val valid = currentSeasonRaces.filter { !it.status.startsWith("DNF") }
        return DriverHistorySeasonUi(
            season = store.season,
            teamId = currentSeasonRaces.groupBy { it.teamId }.maxByOrNull { it.value.size }?.key
                ?: WorldDatabase.teams.firstOrNull { it.id == driver.teamId }?.id ?: driver.teamId,
            teamName = teamName,
            position = seasonPosition(store.season, driverId),
            points = currentSeasonRaces.sumOf { it.points },
            wins = valid.count { it.position == 1 },
            podiums = valid.count { it.position in 1..3 },
            poles = currentSeasonPoles,
            fastestLaps = currentSeasonRaces.count { it.isFastestLap },
            gps = currentSeasonRaces.size,
            dnf = currentSeasonRaces.count { it.status.startsWith("DNF") }
        )
    }

    val seasonRows = remember(driverId, store.season, completedRows, currentSeasonRaces.size) {
        val historical = completedRows.map {
            DriverHistorySeasonUi(it.season, it.teamId, it.teamName, it.position, it.points, it.wins, it.poles /* temporary */, 0, it.fastestLaps, it.gps, it.dnf)
        }.toMutableList()
        // Completed-season records contain wins/poles but not podiums; reconstruct podiums from race history.
        val corrected = historical.map { row ->
            val rs = allRaces.filter { it.season == row.season }
            row.copy(podiums = rs.count { it.position in 1..3 && !it.status.startsWith("DNF") })
        }.toMutableList()
        liveSeasonRow()?.let { live ->
            corrected.removeAll { it.season == live.season }
            corrected.add(live)
        }
        corrected.sortedByDescending { it.season }
    }

    val careerWins = allRaces.count { it.position == 1 && !it.status.startsWith("DNF") }
    val careerPodiums = allRaces.count { it.position in 1..3 && !it.status.startsWith("DNF") }
    val careerPoles = allPoles.size
    val careerFastest = allRaces.count { it.isFastestLap }
    val careerStarts = allRaces.size
    val careerDnfs = allRaces.count { it.status.startsWith("DNF") }
    val overall = driverOverall(driver)
    val contract = marketState.contracts.firstOrNull { it.driverId == driverId && it.activeIn(store.season) }
    val contractEnd = contract?.let { store.season + (it.years - it.contractYear(store.season)) }

    LazyColumn(
        Modifier.fillMaxSize().background(Bg),
        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(9.dp)
    ) {
        item {
            Card(Modifier.fillMaxWidth().height(190.dp), colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(10.dp)) {
                Row(Modifier.fillMaxSize(), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.width(108.dp).fillMaxHeight().background(Color(0xFF0A0C10))) {
                        Text("${driverId.coerceIn(1, 99)}", color = Red.copy(alpha = .32f), fontSize = 48.sp, fontWeight = FontWeight.Black, modifier = Modifier.align(Alignment.TopStart).padding(7.dp))
                        DriverPhoto(driver.id, driver.name, Modifier.fillMaxSize())
                    }
                    Column(Modifier.weight(1f).padding(horizontal = 10.dp, vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            DriverFlag(driver.country, Modifier.size(28.dp, 19.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(driver.name, color = Color.White, fontSize = 16.sp, lineHeight = 19.sp, fontWeight = FontWeight.Black, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                        }
                        Text("Equipe: ${WorldDatabase.teams.firstOrNull { it.id == driver.teamId }?.name ?: "Sem equipe"}", color = Color.White, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text("Classe: ${driver.driverClass}", color = Color.White, fontSize = 10.sp)
                        Text("Evolução: ${driver.evolution}", color = Red, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                    Column(Modifier.width(88.dp).fillMaxHeight().padding(vertical = 12.dp, horizontal = 7.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.Start) {
                        Text("GERAL", color = Muted, fontSize = 9.sp, fontWeight = FontWeight.Black)
                        Text(overall.toString(), color = Red, fontSize = 29.sp, fontWeight = FontWeight.Black)
                        Spacer(Modifier.height(10.dp))
                        Text("Contrato", color = Muted, fontSize = 8.sp)
                        Text(contractEnd?.toString() ?: "—", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Black)
                        Text("Salário", color = Muted, fontSize = 8.sp, modifier = Modifier.padding(top = 6.dp))
                        Text(contract?.let { formatMoney(it.salary) } ?: "—", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Black)
                    }
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                Card(Modifier.weight(1.45f), colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp), border = BorderStroke(1.dp, Line)) {
                    Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        Text("ATRIBUTOS DO PILOTO", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Black)
                        listOf("Velocidade" to driver.speed, "Qualificação" to driver.qualifying, "Ultrapassagem" to driver.overtaking, "Defesa" to driver.defense, "Consistência" to driver.consistency, "Chuva" to driver.wet, "Pneu" to driver.tyre).forEach { (label, value) ->
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Text(label, color = Muted, fontSize = 9.sp, modifier = Modifier.width(82.dp), maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Box(Modifier.weight(1f).height(7.dp).clip(RoundedCornerShape(4.dp)).background(Line)) { Box(Modifier.fillMaxWidth((value.coerceIn(0,100)/100f)).fillMaxHeight().background(Red)) }
                                Text(value.toString(), color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Black, modifier = Modifier.width(24.dp), textAlign = TextAlign.End)
                            }
                        }
                    }
                }
                Card(Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp), border = BorderStroke(1.dp, Line)) {
                    Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        Text("DESEMPENHO GERAL", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Black)
                        listOf("Títulos" to champions.size, "Vitórias" to careerWins, "Pódios" to careerPodiums, "Poles" to careerPoles, "Melhores voltas" to careerFastest, "Corridas" to careerStarts, "DNFs" to careerDnfs).forEach { (label, value) ->
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Text(label, color = Muted, fontSize = 9.sp, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                                Text(value.toString(), color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Black)
                            }
                        }
                    }
                }
            }
        }
        item {
            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Panel)) {
                Column(Modifier.padding(10.dp)) {
                    Text("DESEMPENHO NA TEMPORADA ${store.season}", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Black)
                    val row = seasonRows.firstOrNull { it.season == store.season }
                    Row(Modifier.fillMaxWidth().padding(top = 7.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        listOf("Posição" to (row?.position?.takeIf { it > 0 }?.let { "P$it" } ?: "—"), "Pontos" to (row?.points?.toString() ?: "0"), "Vitórias" to (row?.wins?.toString() ?: "0"), "Pódios" to (row?.podiums?.toString() ?: "0")).forEach { (label, value) ->
                            Column(Modifier.weight(1f).background(Panel2, RoundedCornerShape(6.dp)).padding(7.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(label, color = Muted, fontSize = 7.sp)
                                Text(value, color = if (label == "Posição" && value != "—") Red else Color.White, fontSize = 13.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(top = 4.dp))
                            }
                        }
                    }
                    Row(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        listOf("Poles" to (row?.poles?.toString() ?: "0"), "Melhores voltas" to (row?.fastestLaps?.toString() ?: "0"), "Corridas" to (row?.gps?.toString() ?: "0"), "DNFs" to (row?.dnf?.toString() ?: "0")).forEach { (label, value) ->
                            Column(Modifier.weight(1f).background(Panel2, RoundedCornerShape(6.dp)).padding(7.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(label, color = Muted, fontSize = 7.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(value, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(top = 4.dp))
                            }
                        }
                    }
                }
            }
        }
        item {
            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Panel)) {
                Column(Modifier.padding(10.dp)) {
                    Text("HISTÓRICO POR TEMPORADA", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Black)
                    val historyWidths = listOf(58, 112, 48, 58, 48, 48, 48, 48, 48, 48)
                    Row(Modifier.fillMaxWidth().padding(top = 8.dp).horizontalScroll(rememberScrollState()).background(Panel2, RoundedCornerShape(7.dp)).padding(vertical = 8.dp)) {
                        listOf("TEMPORADA", "EQUIPE", "POS", "PONTOS", "VIT", "PÓD", "POLES", "MV", "GP", "DNF").forEachIndexed { index, header ->
                            Text(header, color = Muted, fontSize = 8.sp, fontWeight = FontWeight.Black, maxLines = 1, modifier = Modifier.width(historyWidths[index].dp).padding(horizontal = 3.dp), textAlign = if (index < 2) TextAlign.Start else TextAlign.Center)
                        }
                    }
                    seasonRows.forEach { row ->
                        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).background(if (row.season == store.season) Red.copy(alpha=.16f) else Color.Transparent).padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(row.season.toString(), color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1, modifier = Modifier.width(historyWidths[0].dp).padding(horizontal = 3.dp))
                            Row(Modifier.width(historyWidths[1].dp).padding(horizontal = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                                TeamLogo(row.teamName, row.teamId, Modifier.size(18.dp))
                                Spacer(Modifier.width(4.dp))
                                Text(row.teamName, color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Normal, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                            val values = listOf(
                                if(row.position>0) row.position.toString() else "—",
                                row.points.toString(), row.wins.toString(), row.podiums.toString(),
                                row.poles.toString(), row.fastestLaps.toString(), row.gps.toString(), row.dnf.toString()
                            )
                            values.forEachIndexed { j, value ->
                                Text(value, color = if (j == 0 && value == "1") Color(0xFFFFD32A) else Color.White, fontSize = 10.sp, fontWeight = if (j == 0) FontWeight.Bold else FontWeight.Medium, maxLines = 1, modifier = Modifier.width(historyWidths[j + 2].dp).padding(horizontal = 3.dp), textAlign = TextAlign.Center)
                            }
                        }
                        HorizontalDivider(color = Line.copy(alpha = .65f), thickness = 0.5.dp)
                    }
                    if (seasonRows.isEmpty()) Text("Nenhum histórico de temporada registrado ainda.", color = Muted, fontSize = 8.sp, modifier = Modifier.padding(top = 8.dp))
                }
            }
        }
    }
}

@Composable
private fun DriverDevelopmentScreen(
    drivers: List<com.f1teammanager.core.season.DriverDefinition>,
    state: TeamManagerState,
    currentWeek: Int,
    onStart: (Int) -> Unit
) {
    val level = state.facilities.level(FacilityType.DRIVER_DEVELOPMENT)
    LazyColumn(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(Panel)) {
                Column(Modifier.padding(12.dp)) {
                    Text("DESENVOLVIMENTO DE PILOTOS", color = Red, fontWeight = FontWeight.Black, fontSize = 14.sp)
                    Text("Selecione um piloto para acelerar sua evolução. O programa não altera potencial, classe ou tipo de evolução.", color = Muted, fontSize = 9.sp)
                    Text("Nível $level • capacidade ${DriverDevelopmentEngine.capacity(level)} • ${DriverDevelopmentEngine.weeks(level)} semanas • +${DriverDevelopmentEngine.points(level)} ponto(s)", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 9.sp, modifier = Modifier.padding(top = 6.dp))
                }
            }
        }
        if (state.driverDevelopment.programs.isNotEmpty()) {
            item { Text("EM DESENVOLVIMENTO", color = Red, fontWeight = FontWeight.Black, fontSize = 11.sp) }
            items(state.driverDevelopment.programs, key = { "active-driver-${it.driverId}" }) { program ->
                val d = drivers.firstOrNull { it.id == program.driverId }
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(Panel2)) {
                    Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        d?.let { DriverPhoto(it.id, it.name, Modifier.size(52.dp).clip(RoundedCornerShape(7.dp))) }
                        Spacer(Modifier.width(8.dp))
                        Column(Modifier.weight(1f)) {
                            Text(d?.name ?: "Piloto ${program.driverId}", color = Color.White, fontWeight = FontWeight.Black, fontSize = 11.sp)
                            Text("Semana ${program.startedWeek} • ${program.remainingWeeks}/${program.totalWeeks} restantes", color = Muted, fontSize = 8.sp)
                        }
                        Text("+${program.points}", color = Green, fontWeight = FontWeight.Black, fontSize = 15.sp)
                    }
                }
            }
        }
        item { Text("SELECIONAR PILOTO", color = Red, fontWeight = FontWeight.Black, fontSize = 11.sp) }
        items(drivers.distinctBy { it.id }, key = { "select-driver-${it.id}" }) { d ->
            val active = state.driverDevelopment.programs.any { it.driverId == d.id }
            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(Panel)) {
                Row(Modifier.fillMaxWidth().padding(9.dp), verticalAlignment = Alignment.CenterVertically) {
                    DriverPhoto(d.id, d.name, Modifier.size(58.dp).clip(RoundedCornerShape(7.dp)))
                    Spacer(Modifier.width(9.dp))
                    Column(Modifier.weight(1f)) {
                        Text(d.name, color = Color.White, fontWeight = FontWeight.Black, fontSize = 11.sp)
                        Text("OVR ${driverOverall(d)} • ${d.driverClass} • ${d.evolution}", color = Muted, fontSize = 8.sp)
                    }
                    Button(onClick = { onStart(d.id) }, enabled = level > 0 && !active && state.driverDevelopment.programs.size < DriverDevelopmentEngine.capacity(level), colors = ButtonDefaults.buttonColors(containerColor = if (active) Panel2 else Red, contentColor = Color.White), contentPadding = PaddingValues(horizontal = 9.dp, vertical = 5.dp)) { Text(if (active) "ATIVO" else "DESENVOLVER", fontSize = 7.sp, fontWeight = FontWeight.Black) }
                }
            }
        }
        item { Text("Semana atual: $currentWeek • O efeito é aplicado quando o programa termina.", color = Muted, fontSize = 8.sp) }
    }
}

@Composable
private fun TeamDriverCard(d: com.f1teammanager.core.season.DriverDefinition, onClick: () -> Unit = {}) {
    Card(
        Modifier.fillMaxWidth().height(74.dp),
        colors = CardDefaults.cardColors(containerColor = Panel)
    ) {
        Row(Modifier.fillMaxSize(), verticalAlignment = Alignment.CenterVertically) {
            DriverPhoto(
                d.id,
                d.name,
                Modifier.width(76.dp).fillMaxHeight().clip(RoundedCornerShape(topStart = 9.dp, bottomStart = 9.dp)).clickable { onClick() }
            )
            Spacer(Modifier.width(8.dp))
            DriverFlag(d.country, Modifier.size(34.dp, 22.dp))
            Spacer(Modifier.width(8.dp))
            Column(Modifier.weight(1f)) {
                Text(d.name, color = Color.White, fontWeight = FontWeight.Black, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("${d.driverClass}  •  ${d.evolution}", color = Muted, fontSize = 9.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Box(
                Modifier.padding(end = 10.dp).size(58.dp, 48.dp).background(Panel2, RoundedCornerShape(7.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text(driverOverall(d).toString(), color = Red, fontWeight = FontWeight.Black, fontSize = 21.sp)
            }
        }
    }
}

@Composable
private fun DriverFlag(country: String, modifier: Modifier = Modifier) {
    val code = when (country) {
        "Países Baixos" -> "nl"
        "França" -> "fr"
        "Reino Unido" -> "gb"
        "Austrália" -> "au"
        "Espanha" -> "es"
        "Tailândia" -> "th"
        "Itália" -> "it"
        "Brasil" -> "br"
        "Alemanha" -> "de"
        "Argentina" -> "ar"
        "Mônaco" -> "mc"
        "Bulgária" -> "bg"
        else -> ""
    }
    if (code.isEmpty()) {
        Box(modifier.background(Panel2, RoundedCornerShape(3.dp)))
        return
    }
    val context = androidx.compose.ui.platform.LocalContext.current
    var bitmap by remember(code) { mutableStateOf<android.graphics.Bitmap?>(null) }
    LaunchedEffect(code) {
        bitmap = withContext(Dispatchers.IO) { ExternalAssets.loadCountryFlag(context, code) }
    }
    if (bitmap != null) {
        Image(bitmap = bitmap!!.asImageBitmap(), contentDescription = country, modifier = modifier.clip(RoundedCornerShape(3.dp)), contentScale = androidx.compose.ui.layout.ContentScale.Fit)
    } else {
        Box(modifier.background(Panel2, RoundedCornerShape(3.dp)))
    }
}

@Composable
private fun FacilityGlyph(type: FacilityType, modifier: Modifier = Modifier) {
    val glyph = when (type) {
        FacilityType.FACTORY -> "⌂"
        FacilityType.RESEARCH -> "⚙"
        FacilityType.WIND_TUNNEL -> "≋"
        FacilityType.SIMULATOR -> "▣"
        FacilityType.SCOUTING -> "⌕"
        FacilityType.DRIVER_DEVELOPMENT -> "◉"
        FacilityType.MARKETING -> "▮"
    }
    Box(modifier, contentAlignment = Alignment.Center) {
        Text(glyph, color = Red, fontSize = 27.sp, fontWeight = FontWeight.Black)
    }
}

@Composable
private fun MetricPanel(title:String,leftLabel:String,leftValue:Int,rightLabel:String,rightValue:Int){
    Card(Modifier.fillMaxWidth(), colors=CardDefaults.cardColors(Panel)) {
        Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement=Arrangement.spacedBy(10.dp)) {
            Column(Modifier.weight(1f)) {
                Text(title, color=Muted, fontSize=9.sp, fontWeight=FontWeight.Bold)
                Text(leftLabel, color=Color.White, fontSize=10.sp)
                Text(leftValue.toString(), color=Red, fontSize=18.sp, fontWeight=FontWeight.Black)
            }
            Column(Modifier.weight(1f)) {
                Text("CONFIABILIDADE", color=Muted, fontSize=9.sp, fontWeight=FontWeight.Bold)
                Text(rightLabel, color=Color.White, fontSize=10.sp)
                Text(rightValue.toString(), color=if(rightValue >= 76) Green else Red, fontSize=18.sp, fontWeight=FontWeight.Black)
            }
        }
    }
}

@Composable
private fun DriverMini(d:com.f1teammanager.core.season.DriverDefinition){
    Card(Modifier.fillMaxWidth(), colors=CardDefaults.cardColors(Panel)) {
        Row(Modifier.fillMaxWidth().padding(11.dp), verticalAlignment=Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(d.name, color=Color.White, fontWeight=FontWeight.Bold, fontSize=12.sp)
                Text("${d.driverClass} • ${d.evolution}", color=Muted, fontSize=9.sp)
            }
            Text("${driverOverall(d)}", color=Red, fontWeight=FontWeight.Black, fontSize=18.sp)
        }
    }
}

@Composable
private fun Drivers(
    drivers: List<com.f1teammanager.core.season.DriverDefinition>,
    store: CareerPreferences
) {
    val season = store.season
    // Re-read persisted history on every recomposition. Race completion writes the
    // canonical records to CareerPreferences; caching these lists by season would
    // leave the driver cards showing the pre-GP values until the app is recreated.
    val races = store.history.raceRecords(season)
    val qualifying = store.history.qualifyingRecords(season)
    val poles = store.history.poleRecords(season)

    fun seasonSummary(driverId: Int): DriverSeasonUiSummary {
        val driverRaces = races.filter { it.driverId == driverId }
        val driverQualifying = qualifying.filter { it.driverId == driverId }
        val wins = driverRaces.count { it.position == 1 && !it.status.startsWith("DNF") }
        val podiums = driverRaces.count { it.position in 1..3 && !it.status.startsWith("DNF") }
        val validFinishes = driverRaces.filter { !it.status.startsWith("DNF") }.map { it.position }
        val avgFinish = validFinishes.takeIf { it.isNotEmpty() }?.average() ?: 0.0
        val dnf = driverRaces.count { it.status.startsWith("DNF") }
        val points = driverRaces.sumOf { it.points }
        val poleCount = poles.count { it.driverId == driverId }

        var bestChampionship = 80
        var cumulative = mutableMapOf<Int, Int>()
        for (round in 1..SeasonCalendar.forSeason(season).size) {
            races.filter { it.round == round }.forEach { r -> cumulative[r.driverId] = (cumulative[r.driverId] ?: 0) + r.points }
            if (cumulative.isNotEmpty()) {
                val order = cumulative.entries.sortedWith(compareByDescending<Map.Entry<Int,Int>> { it.value }.thenBy { it.key })
                val pos = order.indexOfFirst { it.key == driverId }
                if (pos >= 0) bestChampionship = minOf(bestChampionship, pos + 1)
            }
        }
        if (bestChampionship == 80 && points > 0) bestChampionship = 1

        val current = drivers.firstOrNull { it.id == driverId } ?: WorldDatabase.allDrivers.first { it.id == driverId }
        val opening = store.seasonStartDriverDefinition(driverId, season)
        val currentOvr = driverOverall(current)
        val openingOvr = driverOverall(opening)
        val delta = currentOvr - openingOvr
        val gains = listOf(
            "VEL" to current.speed - opening.speed,
            "QUAL" to current.qualifying - opening.qualifying,
            "ULTR" to current.overtaking - opening.overtaking,
            "DEF" to current.defense - opening.defense,
            "CONS" to current.consistency - opening.consistency,
            "CHUVA" to current.wet - opening.wet,
            "PNEU" to current.tyre - opening.tyre
        ).sortedByDescending { it.second }

        return DriverSeasonUiSummary(
            gps = driverRaces.size,
            wins = wins,
            podiums = podiums,
            poles = poleCount,
            bestResult = driverRaces.filter { !it.status.startsWith("DNF") }.minOfOrNull { it.position } ?: 0,
            points = points,
            averageFinish = avgFinish,
            bestChampionship = bestChampionship,
            dnf = dnf,
            openingOvr = openingOvr,
            currentOvr = currentOvr,
            deltaOvr = delta,
            bestGains = gains.take(4)
        )
    }

    LazyColumn(
        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text("PILOTOS DA EQUIPE", color=Red, fontWeight=FontWeight.Black, fontSize=20.sp, maxLines=1, softWrap=false)
            Text("Atributos atuais, perfil de evolução e desempenho na temporada", color=Muted, fontSize=10.sp, maxLines=1, softWrap=false)
        }
        // Exibe os dois titulares com um comparativo baseado exclusivamente
        // nos registros reais da temporada, exatamente entre os cards individuais.
        items(drivers.take(1), key = { it.id }) { d ->
            DriverSeasonCard(d, season, seasonSummary(d.id))
        }
        if (drivers.size >= 2) {
            item(key = "season-comparison-${season}-${drivers[0].id}-${drivers[1].id}") {
                DriverSeasonComparisonCard(
                    first = drivers[0],
                    firstSummary = seasonSummary(drivers[0].id),
                    second = drivers[1],
                    secondSummary = seasonSummary(drivers[1].id),
                    season = season
                )
            }
        }
        items(drivers.drop(1), key = { it.id }) { d ->
            DriverSeasonCard(d, season, seasonSummary(d.id))
        }
    }
}

private data class DriverComparisonMetric(
    val label: String,
    val left: Double,
    val right: Double,
    val displayLeft: String,
    val displayRight: String,
    val higherWins: Boolean = true
)

@Composable
private fun DriverSeasonComparisonCard(
    first: com.f1teammanager.core.season.DriverDefinition,
    firstSummary: DriverSeasonUiSummary,
    second: com.f1teammanager.core.season.DriverDefinition,
    secondSummary: DriverSeasonUiSummary,
    season: Int
) {
    val metrics = listOf(
        DriverComparisonMetric("Pontos", firstSummary.points.toDouble(), secondSummary.points.toDouble(), firstSummary.points.toString(), secondSummary.points.toString()),
        DriverComparisonMetric("Vitórias", firstSummary.wins.toDouble(), secondSummary.wins.toDouble(), firstSummary.wins.toString(), secondSummary.wins.toString()),
        DriverComparisonMetric("Pódios", firstSummary.podiums.toDouble(), secondSummary.podiums.toDouble(), firstSummary.podiums.toString(), secondSummary.podiums.toString()),
        DriverComparisonMetric("Poles", firstSummary.poles.toDouble(), secondSummary.poles.toDouble(), firstSummary.poles.toString(), secondSummary.poles.toString()),
        DriverComparisonMetric("Melhor resultado", firstSummary.bestResult.toDouble(), secondSummary.bestResult.toDouble(), if (firstSummary.bestResult > 0) "${firstSummary.bestResult}º" else "—", if (secondSummary.bestResult > 0) "${secondSummary.bestResult}º" else "—", higherWins = false),
        DriverComparisonMetric("Média de chegada", firstSummary.averageFinish, secondSummary.averageFinish, if (firstSummary.gps > 0) String.format(Locale("pt", "BR"), "%.1f", firstSummary.averageFinish) else "—", if (secondSummary.gps > 0) String.format(Locale("pt", "BR"), "%.1f", secondSummary.averageFinish) else "—", higherWins = false),
        DriverComparisonMetric("DNFs", firstSummary.dnf.toDouble(), secondSummary.dnf.toDouble(), firstSummary.dnf.toString(), secondSummary.dnf.toString(), higherWins = false)
    )
    val leftWins = metrics.count { m -> if (m.higherWins) m.left > m.right else m.left > 0 && (m.right == 0.0 || m.left < m.right) }
    val rightWins = metrics.count { m -> if (m.higherWins) m.right > m.left else m.right > 0 && (m.left == 0.0 || m.right < m.left) }
    val maxPoints = maxOf(firstSummary.points, secondSummary.points, 1).toFloat()

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF101319)),
        border = BorderStroke(1.dp, Line)
    ) {
        Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("COMPARATIVO DA TEMPORADA $season", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Black, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(first.name, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
                    Text("${firstSummary.points} pts", color = Green, fontSize = 15.sp, fontWeight = FontWeight.Black)
                }
                Text("VS", color = RedCompat, fontWeight = FontWeight.Black, fontSize = 12.sp)
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(second.name, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
                    Text("${secondSummary.points} pts", color = Green, fontSize = 15.sp, fontWeight = FontWeight.Black)
                }
            }
            HorizontalDivider(color = Line)
            metrics.forEach { metric ->
                val leftBetter = if (metric.higherWins) metric.left > metric.right else metric.left > 0 && (metric.right == 0.0 || metric.left < metric.right)
                val rightBetter = if (metric.higherWins) metric.right > metric.left else metric.right > 0 && (metric.left == 0.0 || metric.right < metric.left)
                Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text(metric.label, color = Muted, fontSize = 10.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        Text(metric.displayLeft, color = if (leftBetter) Green else Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(34.dp), textAlign = TextAlign.Center)
                        Box(Modifier.weight(1f).height(7.dp).clip(RoundedCornerShape(6.dp)).background(Panel2)) {
                            val fraction = if (metric.label == "Pontos") (metric.left / maxPoints).coerceIn(0.0, 1.0).toFloat() else {
                                val maxValue = maxOf(metric.left, metric.right, 1.0)
                                (metric.left / maxValue).coerceIn(0.0, 1.0).toFloat()
                            }
                            Box(Modifier.fillMaxWidth(fraction).fillMaxHeight().clip(RoundedCornerShape(6.dp)).background(if (leftBetter) Green else Muted))
                        }
                        Text(metric.displayRight, color = if (rightBetter) Green else Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(34.dp), textAlign = TextAlign.Center)
                        Box(Modifier.weight(1f).height(7.dp).clip(RoundedCornerShape(6.dp)).background(Panel2)) {
                            val maxValue = maxOf(metric.left, metric.right, 1.0)
                            val fraction = (metric.right / maxValue).coerceIn(0.0, 1.0).toFloat()
                            Box(Modifier.fillMaxWidth(fraction).fillMaxHeight().clip(RoundedCornerShape(6.dp)).background(if (rightBetter) Green else Muted))
                        }
                    }
                }
            }
            val verdict = when {
                firstSummary.gps == 0 && secondSummary.gps == 0 -> "Ainda não há resultados de corrida nesta temporada."
                firstSummary.points > secondSummary.points -> "Melhor campanha até agora: ${first.name}."
                secondSummary.points > firstSummary.points -> "Melhor campanha até agora: ${second.name}."
                leftWins > rightWins -> "Temporada equilibrada; ${first.name} lidera nos critérios comparados."
                rightWins > leftWins -> "Temporada equilibrada; ${second.name} lidera nos critérios comparados."
                else -> "Desempenho equilibrado na temporada até agora."
            }
            Text(verdict, color = if (firstSummary.points == secondSummary.points) Color.LightGray else Green, fontSize = 11.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
        }
    }
}

private val RedCompat = Color(0xFFE10600)

private data class DriverSeasonUiSummary(
    val gps: Int,
    val wins: Int,
    val podiums: Int,
    val poles: Int,
    val bestResult: Int,
    val points: Int,
    val averageFinish: Double,
    val bestChampionship: Int,
    val dnf: Int,
    val openingOvr: Int,
    val currentOvr: Int,
    val deltaOvr: Int,
    val bestGains: List<Pair<String,Int>>
)

@Composable
private fun DriverSeasonCard(
    d: com.f1teammanager.core.season.DriverDefinition,
    season: Int,
    summary: DriverSeasonUiSummary
) {
    // Official driver model: exactly seven attributes. The eighth grid position
    // is intentionally left empty so every visible attribute tile keeps the
    // exact same width/height across both rows.
    val stats = listOf(
        "VEL" to d.speed, "QUAL" to d.qualifying, "ULTR" to d.overtaking, "DEF" to d.defense,
        "CONS" to d.consistency, "CHUVA" to d.wet, "PNEU" to d.tyre
    )
    Card(
        Modifier.fillMaxWidth(),
        shape=RoundedCornerShape(12.dp),
        colors=CardDefaults.cardColors(Panel)
    ) {
        Column(Modifier.fillMaxWidth()) {
            // Fixed proportions: the portrait is smaller and always rendered with FIT,
            // while the information column keeps the same dimensions for every driver.
            Row(
                Modifier.fillMaxWidth().height(190.dp).padding(10.dp),
                verticalAlignment=Alignment.Top
            ) {
                Box(
                    Modifier.width(92.dp).fillMaxHeight()
                        .clip(RoundedCornerShape(8.dp)).background(Color(0xFF090B0F))
                ) {
                    Text(
                        if (d.id % 2 == 0) "2" else "1",
                        color=Red.copy(alpha=.30f),
                        fontSize=48.sp,
                        fontWeight=FontWeight.Black,
                        modifier=Modifier.align(Alignment.TopStart).padding(start=6.dp)
                    )
                    DriverPhoto(d.id, d.name, Modifier.fillMaxSize())
                }
                Spacer(Modifier.width(8.dp))
                Column(Modifier.weight(1f), verticalArrangement=Arrangement.spacedBy(6.dp)) {
                    Row(Modifier.fillMaxWidth().height(44.dp), verticalAlignment=Alignment.CenterVertically) {
                        DriverFlag(d.country, Modifier.size(width=32.dp,height=22.dp))
                        Spacer(Modifier.width(6.dp))
                        Column(Modifier.weight(1f), verticalArrangement=Arrangement.spacedBy(1.dp)) {
                            Text(
                                d.name,
                                color=Color.White,
                                fontWeight=FontWeight.Black,
                                fontSize=14.sp,
                                maxLines=1,
                                softWrap=false,
                                overflow=TextOverflow.Clip
                            )
                            Text(
                                "${d.driverClass}  •  ${d.evolution}",
                                color=Red,
                                fontSize=9.sp,
                                maxLines=1,
                                softWrap=false,
                                overflow=TextOverflow.Clip
                            )
                        }
                        Column(
                            horizontalAlignment=Alignment.CenterHorizontally,
                            verticalArrangement=Arrangement.Center,
                            modifier=Modifier.width(64.dp).height(52.dp)
                                .background(Panel2,RoundedCornerShape(7.dp)).padding(horizontal=4.dp,vertical=3.dp)
                        ) {
                            Text("OVR",color=Muted,fontSize=7.sp,fontWeight=FontWeight.Bold,maxLines=1,softWrap=false, textAlign=TextAlign.Center)
                            Text(summary.currentOvr.toString(),color=Red,fontSize=17.sp,fontWeight=FontWeight.Black,maxLines=1,softWrap=false, textAlign=TextAlign.Center)
                        }
                    }
                    Column(verticalArrangement=Arrangement.spacedBy(5.dp)) {
                        stats.chunked(4).forEach { row ->
                            Row(Modifier.fillMaxWidth().height(56.dp), horizontalArrangement=Arrangement.spacedBy(4.dp)) {
                                row.forEach { (label,value) ->
                                    val attributeIcon = when(label) {
                                        "VEL" -> "⚡"
                                        "QUAL" -> "⏱"
                                        "ULTR" -> "↔"
                                        "DEF" -> "🛡"
                                        "CONS" -> "◉"
                                        "CHUVA" -> "☔"
                                        "PNEU" -> "◉"
                                        else -> "•"
                                    }
                                    Column(
                                        Modifier.weight(1f).fillMaxHeight()
                                            .background(Panel2,RoundedCornerShape(6.dp))
                                            .padding(horizontal=4.dp,vertical=4.dp),
                                        horizontalAlignment=Alignment.CenterHorizontally,
                                        verticalArrangement=Arrangement.spacedBy(2.dp)
                                    ) {
                                        Row(horizontalArrangement=Arrangement.spacedBy(3.dp), verticalAlignment=Alignment.CenterVertically) {
                                            Text(attributeIcon,color=Color.White,fontSize=9.sp,maxLines=1,softWrap=false)
                                            Text(label,color=Muted,fontSize=7.sp,fontWeight=FontWeight.Bold,maxLines=1,softWrap=false, textAlign=TextAlign.Center)
                                        }
                                        Text(value.toString(),color=Color.White,fontSize=12.sp,fontWeight=FontWeight.Black,maxLines=1,softWrap=false, textAlign=TextAlign.Center)
                                        Box(Modifier.fillMaxWidth().height(3.dp).clip(RoundedCornerShape(3.dp)).background(Line)) {
                                            Box(Modifier.fillMaxWidth((value.coerceIn(0,100)/100f)).fillMaxHeight().background(Red))
                                        }
                                    }
                                }
                                repeat(4 - row.size) {
                                    Spacer(Modifier.weight(1f).fillMaxHeight())
                                }
                            }
                        }
                    }
                }
            }
            Column(
                Modifier.fillMaxWidth().padding(horizontal=10.dp,vertical=9.dp),
                verticalArrangement=Arrangement.spacedBy(6.dp)
            ) {
                Row(Modifier.fillMaxWidth().height(24.dp),verticalAlignment=Alignment.CenterVertically) {
                    Text("RESUMO DA TEMPORADA $season",color=Red,fontSize=14.sp,fontWeight=FontWeight.Black,modifier=Modifier.weight(1f),maxLines=1,softWrap=false)
                    Text("GPs disputados: ${summary.gps} / ${SeasonCalendar.forSeason(season).size}",color=Muted,fontSize=8.sp,maxLines=1,softWrap=false)
                }
                Row(Modifier.fillMaxWidth().height(64.dp),horizontalArrangement=Arrangement.spacedBy(5.dp)) {
                    SeasonStat("🏆","Vitórias",summary.wins.toString())
                    SeasonStat("★","Pódios",summary.podiums.toString())
                    SeasonStat("🏁","Poles",summary.poles.toString())
                    SeasonStat("★","Melhor resultado",if(summary.bestResult>0) "P${summary.bestResult}" else "—")
                }
                Row(Modifier.fillMaxWidth().height(64.dp),horizontalArrangement=Arrangement.spacedBy(5.dp)) {
                    SeasonStat("🏁","Pontos",summary.points.toString())
                    SeasonStat("▥","Média de chegada",if(summary.averageFinish>0) String.format(java.util.Locale.US,"%.1f",summary.averageFinish).replace('.',',') else "—")
                    SeasonStat("↗","Melhor posição no campeonato",if(summary.bestChampionship<80) "P${summary.bestChampionship}" else "—")
                    SeasonStat("✕","DNF",summary.dnf.toString())
                }
                Row(Modifier.fillMaxWidth().height(108.dp),horizontalArrangement=Arrangement.spacedBy(5.dp)) {
                    Column(Modifier.weight(1f).fillMaxHeight().background(Panel2,RoundedCornerShape(8.dp)).padding(7.dp)) {
                        Text("EVOLUÇÃO NA TEMPORADA",color=Red,fontSize=8.sp,fontWeight=FontWeight.Black,maxLines=1,softWrap=false)
                        Row(Modifier.fillMaxWidth().weight(1f).padding(top=8.dp),horizontalArrangement=Arrangement.SpaceEvenly,verticalAlignment=Alignment.CenterVertically) {
                            EvolutionValue("OVR início",summary.openingOvr,Color.White)
                            Text("→",color=Muted,fontSize=15.sp,maxLines=1,softWrap=false)
                            EvolutionValue("OVR atual",summary.currentOvr,Color.White)
                            EvolutionValue("Variação",if(summary.deltaOvr>=0) "+${summary.deltaOvr}" else summary.deltaOvr.toString(),if(summary.deltaOvr>=0) Green else Red)
                        }
                    }
                    Column(Modifier.weight(1f).fillMaxHeight().background(Panel2,RoundedCornerShape(8.dp)).padding(7.dp)) {
                        Text("MELHOR EVOLUÇÃO NOS ATRIBUTOS",color=Red,fontSize=8.sp,fontWeight=FontWeight.Black,maxLines=1,softWrap=false)
                        Row(Modifier.fillMaxWidth().weight(1f).padding(top=8.dp),horizontalArrangement=Arrangement.SpaceEvenly,verticalAlignment=Alignment.CenterVertically) {
                            summary.bestGains.forEach { (label,gain) ->
                                Column(horizontalAlignment=Alignment.CenterHorizontally) {
                                    Text(label,color=Muted,fontSize=7.sp,fontWeight=FontWeight.Bold,maxLines=1,softWrap=false)
                                    Text(if(gain>=0) "+$gain" else gain.toString(),color=if(gain>0) Green else if(gain<0) Red else Muted,fontSize=11.sp,fontWeight=FontWeight.Black,maxLines=1,softWrap=false)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun RowScope.SeasonStat(icon:String,label:String,value:String) {
    Column(
        Modifier.weight(1f).fillMaxHeight().background(Panel2,RoundedCornerShape(7.dp)).padding(6.dp),
        verticalArrangement=Arrangement.SpaceBetween
    ) {
        Text(icon,fontSize=11.sp,maxLines=1,softWrap=false)
        Text(label,color=Muted,fontSize=6.sp,maxLines=2,softWrap=true,overflow=TextOverflow.Ellipsis)
        Text(value,color=Color.White,fontSize=13.sp,fontWeight=FontWeight.Black,maxLines=1,softWrap=false)
    }
}

@Composable
private fun EvolutionValue(label:String,value:Any,color:Color) {
    Column(Modifier.widthIn(min=34.dp), horizontalAlignment=Alignment.CenterHorizontally, verticalArrangement=Arrangement.spacedBy(4.dp)) {
        Text(label,color=Muted,fontSize=6.sp,maxLines=1,softWrap=false)
        Text(value.toString(),color=color,fontSize=12.sp,fontWeight=FontWeight.Black,maxLines=1,softWrap=false)
    }
}

@Composable
private fun RowScope.DriverStat(label:String,value:Int){
    Column(Modifier.weight(1f).background(Panel2,RoundedCornerShape(6.dp)).padding(6.dp)) {
        Text(label,color=Muted,fontSize=7.sp,fontWeight=FontWeight.Bold)
        Text(value.toString(),color=Color.White,fontSize=12.sp,fontWeight=FontWeight.Black)
    }
}

private fun driverOverall(d:com.f1teammanager.core.season.DriverDefinition):Int =
    listOf(d.speed,d.qualifying,d.overtaking,d.defense,d.consistency,d.wet,d.tyre).average().toInt()

@Composable
private fun Car(
    c: com.f1teammanager.core.season.CarSpec,
    state: TeamManagerState,
    currentWeek: Int,
    message: String,
    develop: (CarComponent, ResearchFocus, ResearchComplexity) -> Unit,
    manufactureDesign: (com.f1teammanager.core.manager.ResearchDesign, Int, Int, Long) -> Unit,
    investNextSeason: (Long) -> Unit,
    setNextSeasonFocus: (CarDevelopmentFocus) -> Unit
) {
    var selectedComponent by remember { mutableStateOf<CarComponent?>(null) }
    var selectedDesign by remember { mutableStateOf<com.f1teammanager.core.manager.ResearchDesign?>(null) }
    var selectedFocus by remember { mutableStateOf(ResearchFocus.BALANCED) }
    var selectedComplexity by remember { mutableStateOf(ResearchComplexity.MEDIUM) }
    val researchEngine = remember { ResearchEngine() }
    val factoryEngine = remember { FactoryEngine() }
    val factorySpec = factoryEngine.specification(state.facilities)
    val garage = state.garage
    val pdLevel = state.facilities.level(FacilityType.RESEARCH)
    val simultaneousLimit = when {
        pdLevel >= 8 -> 3
        pdLevel >= 4 -> 2
        else -> 1
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 12.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item { TeamCarVisual(teamId = c.teamId, teamName = WorldDatabase.teams.firstOrNull { it.id == c.teamId }?.name ?: "Equipe" ) }

        garage?.let { g ->
            item { PhysicalCarCard("CARRO 1", g.car1) }
            item { PhysicalCarCard("CARRO 2", g.car2) }
        }

        item {
            // V179: painel P&D recupera a hierarquia da referência aprovada sem
            // substituir os fluxos reais de pesquisa, fabricação ou instalação.
            Card(
                Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(15.dp),
                colors = CardDefaults.cardColors(Color(0xFF0D121A)),
                border = BorderStroke(1.dp, Line)
            ) {
                Box {
                    Box(Modifier.fillMaxWidth().height(112.dp).background(
                        Brush.horizontalGradient(listOf(Color(0xFF171C26), Color(0xFF11151D), Color(0xFF250D12)))
                    ))
                    Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text("CENTRO DE P&D", color = Red, fontWeight = FontWeight.Black, fontSize = 14.sp)
                            Text("NÍVEL $pdLevel", color = Color.White, fontWeight = FontWeight.Black, fontSize = 10.sp,
                                modifier = Modifier.background(Panel2, RoundedCornerShape(6.dp)).padding(horizontal = 8.dp, vertical = 5.dp))
                        }
                        Text("Pesquisas ${state.research.activeProjects.size}/$simultaneousLimit em andamento", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        Text("A tecnologia desenvolvida passa por Design → Fábrica → peça física → instalação no carro.", color = Color(0xFFB8C0CD), fontSize = 9.sp, lineHeight = 13.sp)
                        Spacer(Modifier.height(2.dp))
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Box(Modifier.width(3.dp).height(18.dp).background(Red, RoundedCornerShape(2.dp)))
                            Text("CENTRO TÉCNICO • DESENVOLVIMENTO DE COMPONENTES", color = Muted, fontSize = 7.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        item { ResearchSectionTitle("NOVA PESQUISA") }

        CarComponent.values().toList().chunked(2).forEach { rowComponents ->
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    rowComponents.forEach { component ->
                        val latest = state.research.completedDesigns.filter { it.component == component }.maxByOrNull { it.version }
                        val cooldown = state.research.cooldownUntil[component] ?: 0
                        val active = state.research.activeProjects.firstOrNull { it.component == component }
                        val canResearch = state.research.activeProjects.size < simultaneousLimit && currentWeek >= cooldown && active == null
                        Card(
                            Modifier.weight(1f).height(96.dp),
                            shape = RoundedCornerShape(11.dp),
                            colors = CardDefaults.cardColors(Color(0xFF10151D)),
                            border = BorderStroke(1.dp, Line)
                        ) {
                            Row(Modifier.fillMaxSize().padding(horizontal = 7.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text(componentIcon(component), color = Color.White, fontSize = 16.sp, modifier = Modifier.width(22.dp))
                                Column(Modifier.weight(1f), verticalArrangement = Arrangement.Center) {
                                    Text(componentLabel(component), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 8.5.sp, maxLines = 2, overflow = TextOverflow.Ellipsis, lineHeight = 10.sp)
                                    val detail = when {
                                        active != null -> "Em andamento V${active.version} • ${active.remainingWeeks}/${active.totalWeeks} sem."
                                        latest == null -> "Tecnologia inicial V1"
                                        else -> "Último design V${latest.version} • P${latest.performance} • C${latest.reliability}"
                                    }
                                    Text(detail, color = Muted, fontSize = 7.sp, maxLines = 2, overflow = TextOverflow.Ellipsis, lineHeight = 9.sp)
                                    if (active != null) {
                                        LinearProgressIndicator(
                                            progress = { ((active.totalWeeks - active.remainingWeeks).toFloat() / active.totalWeeks.coerceAtLeast(1)).coerceIn(0f, 1f) },
                                            modifier = Modifier.fillMaxWidth().padding(top = 3.dp).height(3.dp).clip(RoundedCornerShape(3.dp)),
                                            color = Red, trackColor = Panel2
                                        )
                                    }
                                    if (active == null && cooldown > currentWeek) {
                                        val remaining = cooldown - currentWeek
                                        Text("🔒 ${remaining} sem. • libera S$cooldown", color = Muted, fontSize = 6.5.sp, maxLines = 1, overflow = TextOverflow.Clip)
                                    }
                                }
                                Button(
                                    onClick = { selectedComponent = component },
                                    enabled = canResearch,
                                    modifier = Modifier.width(68.dp).height(30.dp),
                                    shape = RoundedCornerShape(18.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = Red, contentColor = Color.White, disabledContainerColor = Panel2, disabledContentColor = Muted),
                                    contentPadding = PaddingValues(horizontal = 3.dp, vertical = 0.dp)
                                ) {
                                    Text(
                                        when {
                                            active != null -> "ATIVO"
                                            cooldown > currentWeek -> "BLOQUEADO"
                                            else -> "PESQUISAR"
                                        },
                                        fontSize = 6.5.sp,
                                        fontWeight = FontWeight.Black,
                                        maxLines = 1
                                    )
                                }
                            }
                        }
                    }
                    if (rowComponents.size == 1) Spacer(Modifier.weight(1f))
                }
            }
        }

        if (state.research.completedDesigns.isNotEmpty()) {
            item { Text("DESIGNS CONCLUÍDOS / AGUARDANDO FÁBRICA", color = Color.White, fontWeight = FontWeight.Black, fontSize = 11.sp) }
            items(state.research.completedDesigns.asReversed().take(12)) { design ->
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(Panel2)) {
                    Row(Modifier.fillMaxWidth().padding(9.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column(Modifier.weight(1f)) {
                            Text("${componentLabel(design.component)} V${design.version}", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 10.sp)
                            Text("Performance ${design.performance} • Confiabilidade ${design.reliability}", color = Muted, fontSize = 9.sp)
                        }
                        Text("FÁBRICA", color = Red, fontWeight = FontWeight.Black, fontSize = 8.sp)
                    }
                }
            }
        }

        item {
            Card(
                Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(Color(0xFF0D121A)),
                border = BorderStroke(1.dp, Line)
            ) {
                Box {
                    Box(Modifier.fillMaxWidth().height(94.dp).background(
                        Brush.horizontalGradient(listOf(Color(0xFF171B23), Color(0xFF11151C), Color(0xFF210D12)))
                    ))
                    Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("FÁBRICA", color = Red, fontWeight = FontWeight.Black, fontSize = 14.sp)
                        Text(
                            if (state.factory.activeOrders.isEmpty()) "Nenhuma produção em andamento"
                            else state.factory.activeOrders.joinToString(" • ") { "${componentLabel(it.component)} V${it.version} x${it.remainingUnits} • ${it.remainingWeeks}/${it.totalWeeks} semana(s)" },
                            color = Color.White, fontWeight = FontWeight.Bold, fontSize = 10.sp
                        )
                        Text("A fábrica transforma o design em peça física. Ao concluir, escolha instalar no Carro 1 ou Carro 2.", color = Color(0xFFB8C0CD), fontSize = 9.sp, lineHeight = 13.sp)
                    }
                }
            }
        }

        state.research.completedDesigns.asReversed().take(8).forEach { design ->
            item {
                val options = factoryEngine.options(design, state.facilities)
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(Panel2)) {
                    Row(Modifier.fillMaxWidth().padding(9.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("${componentLabel(design.component)} V${design.version}", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 10.sp)
                            Text("Peça ${design.performance} • confiabilidade ${design.reliability}", color = Muted, fontSize = 9.sp)
                            Text("Até ${factorySpec.maxUnitsPerOrder} unidade(s) por ordem • ${factorySpec.parallelOrders} ordem(ns) simultânea(s)", color = Muted, fontSize = 8.sp)
                        }
                        Button(onClick = { selectedDesign = design }, enabled = state.factory.activeOrders.size < factorySpec.parallelOrders, colors = ButtonDefaults.buttonColors(containerColor = Red, contentColor = Color.White), contentPadding = PaddingValues(horizontal = 8.dp, vertical = 3.dp)) { Text("FABRICAR", fontSize = 8.sp, fontWeight = FontWeight.Black) }
                    }
                }
            }
        }

        if (message.isNotBlank()) item { Text(message, color = Color.White, fontSize = 10.sp) }
    }

    selectedDesign?.let { design ->
        val options = factoryEngine.options(design, state.facilities)
        AlertDialog(
            onDismissRequest = { selectedDesign = null },
            title = { Text("FÁBRICA • ${componentLabel(design.component).uppercase()}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    options.forEach { option ->
                        Button(
                            onClick = { manufactureDesign(design, option.quantity, option.weeks, option.costPerUnit); selectedDesign = null },
                            enabled = state.finance.budget >= option.costPerUnit * option.quantity && state.factory.activeOrders.size < factorySpec.parallelOrders,
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = if (option.quantity == 1) Red else Panel2, contentColor = Color.White)
                        ) {
                            Column(Modifier.fillMaxWidth()) {
                                Text("${option.quantity} peça(s) • ${option.weeks} semana(s)", fontWeight = FontWeight.Black, fontSize = 10.sp)
                                Text("${formatMoney(option.costPerUnit)} por peça • total ${formatMoney(option.costPerUnit * option.quantity)}", fontSize = 9.sp)
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { selectedDesign = null }) { Text("CANCELAR") } }
        )
    }

    selectedComponent?.let { component ->
        val options = researchEngine.options(pdLevel)
        Dialog(
            onDismissRequest = { selectedComponent = null },
            properties = DialogProperties(
                usePlatformDefaultWidth = false,
                decorFitsSystemWindows = true
            )
        ) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth(0.96f)
                    .widthIn(max = 620.dp)
                    .heightIn(max = 840.dp)
                    .border(1.dp, Color(0xFF343944), RoundedCornerShape(24.dp)),
                shape = RoundedCornerShape(24.dp),
                color = Bg,
                tonalElevation = 8.dp
            ) {
                Column(
                    modifier = Modifier
                        .background(
                            Brush.verticalGradient(
                                listOf(Color(0xFF11151C), Bg, Color(0xFF12090D))
                            )
                        )
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 18.dp, vertical = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(13.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.Top,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(54.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .background(Color(0xFF350D14))
                                .border(1.dp, Red.copy(alpha = 0.7f), RoundedCornerShape(14.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("⚙", fontSize = 29.sp, color = Color.White)
                        }
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Text("P&D", color = Red, fontWeight = FontWeight.Black, fontSize = 14.sp)
                            Text(
                                componentLabel(component).uppercase(),
                                color = Color.White,
                                fontWeight = FontWeight.Black,
                                fontSize = 20.sp,
                                lineHeight = 23.sp
                            )
                        }
                        TextButton(
                            onClick = { selectedComponent = null },
                            contentPadding = PaddingValues(0.dp),
                            modifier = Modifier.size(38.dp)
                        ) { Text("✕", color = Color.White, fontSize = 21.sp) }
                    }

                    Text(
                        "Escolha o foco e a complexidade. O nível $pdLevel define a capacidade tecnológica.",
                        color = Color(0xFFADB6C4),
                        fontSize = 13.sp,
                        lineHeight = 19.sp
                    )

                    ResearchSectionTitle("FOCO DA PESQUISA")
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        ResearchFocus.values().forEach { focus ->
                            val selected = selectedFocus == focus
                            val (glyph, subtitle) = when (focus) {
                                ResearchFocus.PERFORMANCE -> "◉" to "Mais potência e desempenho"
                                ResearchFocus.RELIABILITY -> "⬡" to "Menos falhas e maior durabilidade"
                                ResearchFocus.BALANCED -> "⚖" to "Equilíbrio entre os dois"
                            }
                            Surface(
                                modifier = Modifier
                                    .weight(1f)
                                    .heightIn(min = 112.dp)
                                    .clip(RoundedCornerShape(15.dp))
                                    .clickable { selectedFocus = focus },
                                shape = RoundedCornerShape(15.dp),
                                color = if (selected) Color(0xFF350B12) else Color(0xFF101821),
                                border = BorderStroke(
                                    if (selected) 2.dp else 1.dp,
                                    if (selected) Red else Color(0xFF293541)
                                )
                            ) {
                                Column(
                                    modifier = Modifier.padding(horizontal = 7.dp, vertical = 12.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(7.dp)
                                ) {
                                    Text(glyph, color = if (selected) Red else Color(0xFFDCE4EF), fontSize = 25.sp)
                                    Text(
                                        researchEngine.focusLabel(focus),
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.sp,
                                        textAlign = TextAlign.Center,
                                        maxLines = 2
                                    )
                                    Text(
                                        subtitle,
                                        color = Color(0xFFADB6C4),
                                        fontSize = 9.sp,
                                        lineHeight = 12.sp,
                                        textAlign = TextAlign.Center
                                    )
                                }
                            }
                        }
                    }

                    ResearchSectionTitle("COMPLEXIDADE DA PESQUISA")
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        ResearchComplexity.values().forEachIndexed { index, complexity ->
                            val option = options.first { it.complexity == complexity }
                            val selected = selectedComplexity == complexity
                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .defaultMinSize(minHeight = 84.dp)
                                    .clip(RoundedCornerShape(17.dp))
                                    .clickable { selectedComplexity = complexity },
                                shape = RoundedCornerShape(17.dp),
                                color = if (selected) Color(0xFF300A11) else Color(0xFF101720),
                                border = BorderStroke(
                                    if (selected) 2.dp else 1.dp,
                                    if (selected) Red else Color(0xFF26313D)
                                )
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 9.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(48.dp)
                                            .clip(RoundedCornerShape(12.dp))
                                            .background(if (selected) Color(0xFF3B0B12) else Color(0xFF151E28)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            "▂▅▇".take(index + 1),
                                            color = if (selected) Red else Color(0xFFB8C5D4),
                                            fontSize = 17.sp,
                                            fontWeight = FontWeight.Black
                                        )
                                    }
                                    Column(
                                        modifier = Modifier.weight(1f),
                                        verticalArrangement = Arrangement.spacedBy(5.dp)
                                    ) {
                                        Text(
                                            researchEngine.complexityLabel(complexity),
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.sp
                                        )
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(5.dp)
                                        ) {
                                            Text("◷", color = Color(0xFFB8C5D4), fontSize = 12.sp)
                                            Text("${option.weeks} sem.", color = Color(0xFFC3CCD8), fontSize = 10.sp, maxLines = 1)
                                            Text("•", color = Color(0xFF697687), fontSize = 10.sp)
                                            Text("€ ${formatMoney(option.cost).removePrefix("€ ")}", color = Color(0xFFC3CCD8), fontSize = 10.sp, maxLines = 1)
                                            Text("•", color = Color(0xFF697687), fontSize = 10.sp)
                                            Text(
                                                "⚠ ${option.riskLabel}",
                                                color = Red,
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Medium,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                    }
                                    Text(
                                        if (selected) "⦿" else "◯",
                                        color = if (selected) Red else Color(0xFF697687),
                                        fontSize = 25.sp
                                    )
                                }
                            }
                        }
                    }

                    Spacer(Modifier.height(2.dp))
                    Button(
                        onClick = {
                            develop(component, selectedFocus, selectedComplexity)
                            selectedComponent = null
                        },
                        enabled = state.finance.budget >= researchEngine.baseCost(selectedComplexity),
                        modifier = Modifier.fillMaxWidth().height(54.dp),
                        shape = RoundedCornerShape(28.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Red,
                            contentColor = Color.White,
                            disabledContainerColor = Color(0xFF542329),
                            disabledContentColor = Color.LightGray
                        )
                    ) {
                        Text("⚗  INICIAR PESQUISA", fontWeight = FontWeight.Black, fontSize = 14.sp)
                    }
                    OutlinedButton(
                        onClick = { selectedComponent = null },
                        modifier = Modifier.fillMaxWidth().height(50.dp),
                        shape = RoundedCornerShape(28.dp),
                        border = BorderStroke(1.dp, Red),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Red)
                    ) {
                        Text("CANCELAR", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun ResearchSectionTitle(title: String) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(9.dp)
    ) {
        Box(
            Modifier
                .width(4.dp)
                .height(23.dp)
                .clip(RoundedCornerShape(3.dp))
                .background(Red)
        )
        Text(
            title,
            color = Color.White,
            fontWeight = FontWeight.Black,
            fontSize = 15.sp
        )
    }
}

@Composable
private fun TeamCarVisual(teamId: Int, teamName: String) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val bitmap by produceState<android.graphics.Bitmap?>(initialValue = null, teamId, teamName) {
        value = withContext(Dispatchers.IO) { ExternalAssets.loadTeamCarVisual(context, teamId, teamName) }
    }
    Box(
        Modifier.fillMaxWidth()
            .aspectRatio(5.15f)
            .clip(RoundedCornerShape(12.dp))
            .background(
                Brush.horizontalGradient(listOf(Color(0xFF151820), Color(0xFF190B0C), Color(0xFF241013)))
            )
    ) {
        if (bitmap != null) {
            Image(
                bitmap = bitmap!!.asImageBitmap(),
                contentDescription = "Carro da equipe $teamName",
                modifier = Modifier.fillMaxSize(),
                contentScale = androidx.compose.ui.layout.ContentScale.Crop
            )
        } else {
            // Área reservada para o Asset externo da equipe. Não ocupa espaço adicional
            // nem altera o layout quando a imagem ainda não foi colocada na pasta Cars.
            Box(Modifier.fillMaxSize().background(
                Brush.horizontalGradient(listOf(Color(0xFF111319), Color(0xFF171A20), Color(0xFF111319)))
            ))
        }
    }
}

@Composable
private fun PhysicalCarCard(title: String, car: com.f1teammanager.core.manager.PhysicalCar) {
    val parts = listOf(
        CarPartData(CarComponent.ENGINE, car.engine, car.componentReliability(CarComponent.ENGINE), car.installedPieceVersions[CarComponent.ENGINE] ?: 1),
        CarPartData(CarComponent.CHASSIS, car.chassis, car.componentReliability(CarComponent.CHASSIS), car.installedPieceVersions[CarComponent.CHASSIS] ?: 1),
        CarPartData(CarComponent.FRONT_WING, car.frontWing, car.componentReliability(CarComponent.FRONT_WING), car.installedPieceVersions[CarComponent.FRONT_WING] ?: 1),
        CarPartData(CarComponent.REAR_WING, car.rearWing, car.componentReliability(CarComponent.REAR_WING), car.installedPieceVersions[CarComponent.REAR_WING] ?: 1),
        CarPartData(CarComponent.BRAKES, car.brakes, car.componentReliability(CarComponent.BRAKES), car.installedPieceVersions[CarComponent.BRAKES] ?: 1),
        CarPartData(CarComponent.ELECTRIC_POWER_UNIT, car.electricPowerUnit, car.componentReliability(CarComponent.ELECTRIC_POWER_UNIT), car.installedPieceVersions[CarComponent.ELECTRIC_POWER_UNIT] ?: 1)
    )
    Card(
        Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(Panel),
        border = BorderStroke(1.dp, Line)
    ) {
        Column(Modifier.padding(10.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(title, color = Red, fontWeight = FontWeight.Black, fontSize = 14.sp)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Overall ", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Text("${car.overall}", color = Red, fontWeight = FontWeight.Black, fontSize = 16.sp)
                }
            }
            Spacer(Modifier.height(8.dp))
            parts.chunked(3).forEach { row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    row.forEach { part ->
                        CarPartMiniCard(part, Modifier.weight(1f))
                    }
                    repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
                }
                Spacer(Modifier.height(6.dp))
            }
            Row(Modifier.fillMaxWidth().padding(top = 2.dp), horizontalArrangement = Arrangement.spacedBy(7.dp), verticalAlignment = Alignment.CenterVertically) {
                val averagePerformance = parts.map { it.performance }.average().roundToInt()
                val averageReliability = parts.map { it.reliability }.average().roundToInt()
                MiniAverage("Desempenho médio do carro", averagePerformance, false, Modifier.weight(1f))
                Box(Modifier.width(1.dp).height(18.dp).background(Line))
                MiniAverage("Confiabilidade média do carro", averageReliability, true, Modifier.weight(1f))
            }
        }
    }
}

private data class CarPartData(val component: CarComponent, val performance: Int, val reliability: Int, val version: Int)

@Composable
private fun CarPartMiniCard(part: CarPartData, modifier: Modifier) {
    Card(
        modifier.height(104.dp),
        shape = RoundedCornerShape(11.dp),
        colors = CardDefaults.cardColors(Color(0xFF10151D)),
        border = BorderStroke(1.dp, Line)
    ) {
        Column(
            Modifier.fillMaxSize().padding(horizontal = 8.dp, vertical = 7.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(componentIcon(part.component), color = Color.White, fontSize = 14.sp)
                Spacer(Modifier.width(4.dp))
                Text(
                    "V${part.version}",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 8.sp,
                    modifier = Modifier
                        .background(if (part.version > 1) Color(0xFF1676D2) else Color(0xFF364150), RoundedCornerShape(5.dp))
                        .padding(horizontal = 4.dp, vertical = 3.dp)
                )
            }
            Text(
                componentLabel(part.component),
                color = Color.White,
                fontWeight = FontWeight.SemiBold,
                fontSize = 9.sp,
                lineHeight = 11.sp,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                minLines = 2
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Desempenho ${part.performance}", color = Color(0xFFB8C7D9), fontSize = 6.5.sp, maxLines = 1, softWrap = false)
                Text("Conf. ${part.reliability}", color = Color(0xFFB8C7D9), fontSize = 6.5.sp, maxLines = 1, softWrap = false)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                LinearProgressIndicator(
                    progress = { (part.performance / 100f).coerceIn(0f, 1f) },
                    modifier = Modifier.weight(1f).height(4.dp).clip(RoundedCornerShape(4.dp)),
                    color = Color(0xFF2196F3),
                    trackColor = Panel2
                )
                LinearProgressIndicator(
                    progress = { (part.reliability / 100f).coerceIn(0f, 1f) },
                    modifier = Modifier.weight(1f).height(4.dp).clip(RoundedCornerShape(4.dp)),
                    color = Green,
                    trackColor = Panel2
                )
            }
        }
    }
}

@Composable
private fun MiniAverage(label: String, value: Int, reliability: Boolean, modifier: Modifier) {
    Row(modifier, verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Color(0xFFB7C9E8), fontSize = 7.sp, maxLines = 1, overflow = TextOverflow.Clip, modifier = Modifier.weight(1f))
        Text(value.toString(), color = Color.White, fontWeight = FontWeight.Black, fontSize = 10.sp)
        Spacer(Modifier.width(4.dp))
        Box(Modifier.width(35.dp).height(5.dp).clip(RoundedCornerShape(3.dp)).background(Color(0xFF27303B))) {
            Box(Modifier.fillMaxHeight().fillMaxWidth(value.coerceIn(0,100) / 100f).background(if (reliability) Green else Color(0xFF168FEA)))
        }
    }
}

private fun componentIcon(component: CarComponent): String = when(component) {
    CarComponent.ENGINE -> "⚙"
    CarComponent.CHASSIS -> "▱"
    CarComponent.FRONT_WING -> "⌁"
    CarComponent.REAR_WING -> "▤"
    CarComponent.BRAKES -> "◉"
    CarComponent.ELECTRIC_POWER_UNIT -> "ϟ"
}

@Composable private fun CarComponentRow(title:String,level:Int,component:CarComponent,project:com.f1teammanager.core.manager.DevelopmentProject?,options:List<CarDevelopmentEngine.DevelopmentOption>,open:()->Unit){
    val default=options.firstOrNull { it.intensity==DevelopmentIntensity.STANDARD }
    Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(Panel)){
        Row(Modifier.fillMaxWidth().padding(9.dp),verticalAlignment=Alignment.CenterVertically){
            Column(Modifier.weight(1f)){
                Text(title,color=Color.White,fontWeight=FontWeight.Bold,fontSize=11.sp)
                Text("NÍVEL $level • ${default?.weeks ?: 2} semanas padrão • ${default?.cost?.let(::formatMoney) ?: formatMoney(0)} • +${default?.minGain ?: 0} a +${default?.maxGain ?: 0}",color=Muted,fontSize=9.sp)
            }
            Button(onClick=open,enabled=project==null,colors=ButtonDefaults.buttonColors(containerColor=Red,contentColor=Color.White,disabledContainerColor=Panel2),contentPadding=PaddingValues(horizontal=9.dp,vertical=3.dp)){
                Text(if(project==null)"DESENVOLVER" else "P&D OCUPADO",fontSize=8.sp)
            }
        }
    }
}

private fun optionLabel(i:DevelopmentIntensity)=when(i){DevelopmentIntensity.QUICK->"RÁPIDO";DevelopmentIntensity.STANDARD->"PADRÃO";DevelopmentIntensity.ADVANCED->"AVANÇADO";DevelopmentIntensity.AGGRESSIVE->"AGRESSIVO"}
private fun seasonDateLabel(round: RoundDefinition, season: Int): String =
    round.dateLabel.replace(Regex("/\\d{4}$"), "/$season")

@Composable
private fun Calendar(
    idx:Int,
    current:Int,
    currentWeek:Int,
    season:Int,
    message:String,
    openHistory:(Int)->Unit,
    hasHistory:(Int)->Boolean,
    skipOneWeek:()->Unit,
    jumpToNextRace:()->Unit
){
    val seasonRounds = SeasonCalendar.forSeason(season)
    val raceByWeek=seasonRounds.associateBy { it.weekOfSeason }
    val next=seasonRounds.getOrNull(idx) ?: seasonRounds.lastOrNull()
    LazyColumn(
        contentPadding=PaddingValues(start=16.dp,end=16.dp,top=8.dp,bottom=12.dp),
        verticalArrangement=Arrangement.spacedBy(7.dp)
    ){
        item{
            Column(Modifier.fillMaxWidth().padding(bottom=1.dp)){
                Text("CALENDÁRIO $season",color=Color.White,fontSize=24.sp,fontWeight=FontWeight.Black)
                Row(Modifier.fillMaxWidth().padding(top=5.dp),verticalAlignment=Alignment.CenterVertically){
                    CalendarMeta("▣","30 GRAND PRIX")
                    MetaDivider()
                    CalendarMeta("▤","56 SEMANAS")
                    MetaDivider()
                    CalendarMeta("⚒","26 SEMANAS LIVRES")
                }
                Spacer(Modifier.height(8.dp))
                Box(Modifier.fillMaxWidth().height(2.dp).background(Red))
            }
        }
        item{
            Card(
                Modifier.fillMaxWidth(),
                shape=RoundedCornerShape(16.dp),
                colors=CardDefaults.cardColors(containerColor=Panel),
                border=BorderStroke(1.dp,Red)
            ){
                Box(Modifier.fillMaxWidth().background(
                    Brush.horizontalGradient(listOf(Color(0xFF151820),Color(0xFF190B0C),Color(0xFF241013))),
                    RoundedCornerShape(16.dp)
                )){
                    Column(Modifier.padding(horizontal=16.dp,vertical=14.dp)){
                        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){
                            Text("SEMANA ATUAL: $currentWeek/56",color=Red,fontWeight=FontWeight.Black,fontSize=17.sp)
                            Text("TEMPORADA $season",color=Muted,fontSize=9.sp,fontWeight=FontWeight.Bold)
                        }
                        Text(
                            if(next!=null) "Próximo GP: Round ${next.round}  •  Semana ${next.weekOfSeason}  •  ${next.grandPrix}"
                            else "Temporada encerrada",
                            color=Color.White,fontWeight=FontWeight.Bold,fontSize=10.sp,
                            modifier=Modifier.padding(top=7.dp)
                        )
                        Text(
                            "As semanas sem GP são semanas livres de desenvolvimento do carro, contratações e gerenciamento da equipe.",
                            color=Muted,fontSize=9.sp,lineHeight=13.sp,
                            modifier=Modifier.padding(top=5.dp)
                        )
                        Row(Modifier.fillMaxWidth().padding(top=11.dp),horizontalArrangement=Arrangement.spacedBy(8.dp)){
                            Button(
                                onClick=skipOneWeek,
                                modifier=Modifier.weight(0.92f).height(42.dp),
                                enabled=currentWeek<56,
                                shape=RoundedCornerShape(22.dp),
                                contentPadding=PaddingValues(horizontal=8.dp),
                                colors=ButtonDefaults.buttonColors(containerColor=Panel2,contentColor=Color.White,disabledContainerColor=Panel2,disabledContentColor=Muted)
                            ){Text("PULAR 1 SEMANA",fontSize=8.sp,fontWeight=FontWeight.Black,maxLines=1)}
                            Button(
                                onClick=jumpToNextRace,
                                modifier=Modifier.weight(1.18f).height(42.dp),
                                shape=RoundedCornerShape(22.dp),
                                contentPadding=PaddingValues(horizontal=8.dp),
                                colors=ButtonDefaults.buttonColors(containerColor=Red,contentColor=Color.White)
                            ){Text("PULAR ATÉ PRÓXIMO GP",fontSize=8.sp,fontWeight=FontWeight.Black,maxLines=1)}
                        }
                        if(message.isNotBlank()) Text(message,color=Color.White,fontSize=8.sp,lineHeight=12.sp,modifier=Modifier.padding(top=7.dp))
                    }
                }
            }
        }
        items((1..56).toList()){week->
            val r=raceByWeek[week]
            val isCurrent=week==currentWeek
            if(r==null){
                Card(
                    Modifier.fillMaxWidth(),
                    shape=RoundedCornerShape(12.dp),
                    colors=CardDefaults.cardColors(containerColor=Panel)
                ){
                    Row(Modifier.fillMaxWidth().padding(horizontal=12.dp,vertical=10.dp),verticalAlignment=Alignment.CenterVertically){
                        CalendarOutlineIcon(Modifier.size(36.dp))
                        Spacer(Modifier.width(11.dp))
                        Column(Modifier.weight(1f)){
                            Text("SEMANA $week/56${if(isCurrent) " • AGORA" else ""}",color=if(isCurrent) Red else Muted,fontSize=9.sp,fontWeight=FontWeight.Black)
                            Text("SEMANA LIVRE",color=Color.White,fontWeight=FontWeight.Black,fontSize=11.sp,modifier=Modifier.padding(top=4.dp))
                            Text("P&D / DESENVOLVIMENTO",color=Color.White,fontSize=9.sp,fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=2.dp))
                            Text("Use esta semana para avançar projetos do carro.",color=Muted,fontSize=8.sp,modifier=Modifier.padding(top=2.dp))
                        }
                        Text("›",color=Color.White,fontSize=28.sp)
                    }
                }
            } else {
                Card(
                    Modifier.fillMaxWidth(),
                    shape=RoundedCornerShape(12.dp),
                    colors=CardDefaults.cardColors(containerColor=Panel)
                ){
                    Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){
                        Box(Modifier.width(5.dp).height(164.dp).background(Red, RoundedCornerShape(topStart=12.dp,bottomStart=12.dp)))
                        Column(Modifier.fillMaxWidth().padding(start=12.dp,end=12.dp,top=10.dp,bottom=10.dp)){
                            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){
                                Text("SEMANA ${r.weekOfSeason}/56${if(isCurrent) " • AGORA" else ""}",color=if(isCurrent) Color.White else Color.White,fontSize=10.sp,fontWeight=FontWeight.Black)
                                Text("ROUND ${r.round}  •  ${seasonDateLabel(r, season)}",color=Muted,fontSize=8.sp,fontWeight=FontWeight.Bold)
                            }
                            Row(Modifier.fillMaxWidth().padding(top=7.dp),verticalAlignment=Alignment.CenterVertically){
                                RaceImage(r,Modifier.size(width=130.dp,height=90.dp))
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(3.dp)){
                                    Text(r.grandPrix,color=Color.White,fontWeight=FontWeight.Black,fontSize=13.sp,maxLines=1,overflow=TextOverflow.Ellipsis)
                                    Text("⌖  ${r.circuit}",color=Muted,fontSize=10.sp,maxLines=1,overflow=TextOverflow.Ellipsis)
                                    Text("◌  ${r.laps} VOLTAS",color=Color.White,fontSize=8.sp,fontWeight=FontWeight.Bold)
                                    Text("⏱  ${formatLapTime(r.baseLapTimeMs)} / volta",color=Muted,fontSize=8.sp,maxLines=1,overflow=TextOverflow.Ellipsis)
                                    if(hasHistory(r.round)){
                                        Text("VER RESULTADOS  ›",color=Red,fontSize=8.sp,fontWeight=FontWeight.Black,modifier=Modifier.clickable{openHistory(r.round)})
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun formatLapTime(ms: Long): String {
    val safe = ms.coerceAtLeast(0L)
    val minutes = safe / 60_000L
    val seconds = (safe % 60_000L) / 1_000L
    val millis = safe % 1_000L
    return "%d:%02d.%03d".format(minutes, seconds, millis)
}

@Composable
private fun RowScope.CalendarMeta(icon:String,label:String){
    Row(verticalAlignment=Alignment.CenterVertically,modifier=Modifier.weight(1f)){
        Text(icon,color=Color.White,fontSize=12.sp,fontWeight=FontWeight.Bold)
        Spacer(Modifier.width(4.dp))
        Text(label,color=Color.White,fontSize=8.sp,fontWeight=FontWeight.Bold,maxLines=1)
    }
}

@Composable
private fun MetaDivider(){
    Box(Modifier.width(1.dp).height(15.dp).background(Line))
}

@Composable
private fun CalendarOutlineIcon(modifier:Modifier=Modifier){
    Canvas(modifier){
        val stroke=androidx.compose.ui.graphics.drawscope.Stroke(width=2.2f)
        val w=size.width
        val h=size.height
        drawRoundRect(Color.White,topLeft=androidx.compose.ui.geometry.Offset(w*0.15f,h*0.22f),size=androidx.compose.ui.geometry.Size(w*0.70f,h*0.62f),cornerRadius=androidx.compose.ui.geometry.CornerRadius(5f,5f),style=stroke)
        drawLine(Color.White,androidx.compose.ui.geometry.Offset(w*0.15f,h*0.40f),androidx.compose.ui.geometry.Offset(w*0.85f,h*0.40f),strokeWidth=2.2f)
        drawLine(Color.White,androidx.compose.ui.geometry.Offset(w*0.30f,h*0.10f),androidx.compose.ui.geometry.Offset(w*0.30f,h*0.30f),strokeWidth=2.2f)
        drawLine(Color.White,androidx.compose.ui.geometry.Offset(w*0.70f,h*0.10f),androidx.compose.ui.geometry.Offset(w*0.70f,h*0.30f),strokeWidth=2.2f)
        drawCircle(Color.White,radius=1.5f,center=androidx.compose.ui.geometry.Offset(w*0.36f,h*0.58f))
        drawCircle(Color.White,radius=1.5f,center=androidx.compose.ui.geometry.Offset(w*0.50f,h*0.58f))
        drawCircle(Color.White,radius=1.5f,center=androidx.compose.ui.geometry.Offset(w*0.64f,h*0.58f))
    }
}

@Composable private fun RaceHero(r:RoundDefinition,start:()->Unit,currentWeek:Int){
    Card(Modifier.fillMaxWidth(), colors=CardDefaults.cardColors(Panel)){
        Column(Modifier.padding(14.dp)){
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){
                Text("ROUND ${r.round}",color=Red,fontWeight=FontWeight.Black,fontSize=11.sp)
                Text("SEMANA ${r.weekOfSeason}",color=Muted,fontWeight=FontWeight.Bold,fontSize=10.sp)
            }
            Text(r.grandPrix,color=Color.White,fontSize=21.sp,fontWeight=FontWeight.Black,modifier=Modifier.padding(top=4.dp))
            Text(r.circuit,color=Muted,fontSize=11.sp)
            Text(if(currentWeek==r.weekOfSeason) "FIM DE SEMANA DISPONÍVEL" else "CORRIDA AGUARDANDO A SEMANA CORRETA",color=if(currentWeek==r.weekOfSeason) Green else Muted,fontSize=9.sp,fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=8.dp))
            Button(onClick=start,enabled=currentWeek==r.weekOfSeason,modifier=Modifier.fillMaxWidth().padding(top=8.dp),colors=ButtonDefaults.buttonColors(containerColor=Red,contentColor=Color.White,disabledContainerColor=Panel2,disabledContentColor=Muted)){Text("ABRIR FIM DE SEMANA",fontWeight=FontWeight.Black)}
        }
    }
}

@Composable private fun Weekend(r:RoundDefinition,currentWeek:Int,start:()->Unit){LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){item{HeaderBlock(r.grandPrix,"ROUND ${r.round} • ${r.circuit}")};item{RaceHero(r,start,currentWeek)};item{InfoPanel("QUALIFICAÇÃO","Define o grid de largada");InfoPanel("ESTRATÉGIA","Postura + pneu inicial");InfoPanel("CORRIDA","Decisões VSC, SC e bandeira vermelha")};item{Button(onClick=start,modifier=Modifier.fillMaxWidth()){Text("COMEÇAR QUALIFICAÇÃO")}}}}
@Composable private fun InfoPanel(a:String,b:String){Row(Modifier.fillMaxWidth().background(Panel,RoundedCornerShape(8.dp)).padding(14.dp),horizontalArrangement=Arrangement.SpaceBetween){Column{Text(a,color=Color.White,fontWeight=FontWeight.Bold);Text(b,color=Muted,fontSize=11.sp)};Text("›",color=Red,fontSize=24.sp)}}
@Composable
private fun Qualifying(
    s: CareerWeekendEngine.SessionSnapshot,
    round: RoundDefinition,
    simulate: (Long) -> Unit,
    start: () -> Unit
){
    var displayPhase by remember { mutableIntStateOf(s.qualifyingPhaseIndex.coerceIn(0, 2)) }
    var running by remember { mutableStateOf(false) }
    var speedMs by remember { mutableIntStateOf(900) }
    val phases=s.grid?.phases.orEmpty()
    val qualifyingComplete = s.grid?.grid?.size == 80
    val currentPhase=s.qualifyingPhaseIndex.coerceIn(0,2)
    val display = displayPhase.coerceIn(0,2)
    val currentName=listOf("Q1","Q2","Q3")[display]
    val durationMin=listOf(30,20,10)[display]
    val remainingSeconds=if(display == currentPhase && !qualifyingComplete) {
        (s.qualifyingRemainingMs/1000L).coerceIn(0L,durationMin*60L)
    } else if(display < currentPhase || qualifyingComplete) 0L else durationMin*60L
    val progress=if(display == currentPhase && s.qualifyingDurationMs>0) {
        (1f - s.qualifyingRemainingMs.toFloat()/s.qualifyingDurationMs.toFloat()).coerceIn(0f,1f)
    } else if(display < currentPhase || qualifyingComplete) 1f else 0f
    val referenceLap=s.qualifyingReferenceLapMs.coerceAtLeast(1L)
    val expectedLaps=(durationMin * 60_000.0 / referenceLap.toDouble()).let { kotlin.math.floor(it).toInt() }
    val selected=phases.getOrNull(display)
    val virtualSliceMs=when(speedMs){
        1500 -> 2_500L
        900 -> 5_000L
        450 -> 10_000L
        else -> 20_000L
    }

    LaunchedEffect(running, s.qualifyingPhaseIndex, s.qualifyingElapsedMs, speedMs) {
        if(running && !qualifyingComplete){
            kotlinx.coroutines.delay(speedMs.toLong())
            simulate(virtualSliceMs)
        }
    }

    LaunchedEffect(s.qualifyingPhaseIndex) { running=false }

    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal=12.dp, vertical=8.dp),
        verticalArrangement=Arrangement.spacedBy(8.dp),
        contentPadding=PaddingValues(bottom=24.dp)
    ){
        // Card de GP com arte genérica reutilizável: somente decoração; os dados continuam dinâmicos.
        item {
            Card(
                Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, Color(0xFF343B45)),
                colors = CardDefaults.cardColors(containerColor = Panel)
            ) {
                Column {
                    Box(Modifier.fillMaxWidth().height(142.dp)) {
                        Image(
                            painter = painterResource(id = com.f1teammanager.R.drawable.qualifying_gp_background),
                            contentDescription = "Imagem genérica de circuito de corrida",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = androidx.compose.ui.layout.ContentScale.Crop
                        )
                        Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(listOf(Color(0xF0000509), Color(0x99000509), Color(0x22000509)))))
                        Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.SpaceBetween) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Text("ROUND ${round.round}", color = Color.White, fontWeight = FontWeight.Black, fontSize = 10.sp, modifier = Modifier.background(Red, RoundedCornerShape(6.dp)).padding(horizontal = 8.dp, vertical = 3.dp))
                                Text("SEMANA ${round.weekOfSeason}", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 9.sp, modifier = Modifier.background(Color(0xFF111820), RoundedCornerShape(12.dp)).padding(horizontal = 8.dp, vertical = 4.dp))
                            }
                            Column {
                                Text(round.grandPrix, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Black, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(round.circuit, color = Color(0xFFD2D8E0), fontSize = 11.sp)
                            }
                        }
                    }
                    Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(0.8f)) {
                            Text("VOLTA", color = Muted, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                            Text("${round.laps}", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Black)
                        }
                        Column(Modifier.weight(1.25f)) {
                            Text("DISTÂNCIA", color = Muted, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                            Text(if(round.distanceKm > 0.0) String.format(java.util.Locale.US, "%.3f km", round.distanceKm) else "—", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Black, maxLines = 1)
                        }
                        Column(Modifier.weight(1.2f)) {
                            Text("CONDIÇÕES", color = Muted, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text("☀", color = Color(0xFFFFD429), fontSize = 17.sp)
                                Text("Tempo seco", color = Green, fontSize = 12.sp, fontWeight = FontWeight.Black, maxLines = 1)
                            }
                        }
                    }
                }
            }
        }

        item {
            Text("CLASSIFICAÇÃO",color=Color.White,fontSize=23.sp,fontWeight=FontWeight.Black)
            Text("Q1 80 → Q2 50 → Q3 20",color=Red,fontSize=10.sp,fontWeight=FontWeight.Bold)
        }

        item {
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(5.dp)){
                listOf("Q1","Q2","Q3").forEachIndexed{i,label->
                    val available=i <= displayPhase && i <= currentPhase
                    Button(
                        onClick={if(available){displayPhase=i}},
                        enabled=available,
                        modifier=Modifier.weight(1f),
                        colors=ButtonDefaults.buttonColors(
                            containerColor=if(displayPhase==i)Red else Panel2,
                            contentColor=Color.White,
                            disabledContainerColor=Panel2,
                            disabledContentColor=Muted
                        ),
                        contentPadding=PaddingValues(vertical=4.dp)
                    ){ Text(label,fontWeight=FontWeight.Black) }
                }
            }
        }

        item {
            Button(
                onClick={
                    when {
                        qualifyingComplete -> start()
                        running -> running=false
                        currentPhase > display -> { displayPhase=currentPhase; running=true }
                        else -> { displayPhase=currentPhase; running=true }
                    }
                },
                modifier=Modifier.fillMaxWidth().height(50.dp),
                colors=ButtonDefaults.buttonColors(containerColor=Red,contentColor=Color.White)
            ){
                Text(
                    when {
                        qualifyingComplete -> "INICIAR CORRIDA"
                        running -> "PAUSAR SIMULAÇÃO"
                        currentPhase > display -> "SIMULAR ${listOf("Q1","Q2","Q3")[currentPhase]}"
                        else -> "SIMULAR $currentName"
                    },
                    fontWeight=FontWeight.Black
                )
            }
        }

        item {
            Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(Panel)){
                Column(Modifier.padding(10.dp)){
                    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){
                        Text("${currentName} • ${durationMin}:00",color=Color.White,fontWeight=FontWeight.Black,fontSize=11.sp)
                        Text(when { running -> "SIMULANDO"; display < currentPhase || qualifyingComplete -> "CONCLUÍDA"; else -> "PRONTA" },color=if(running) Green else Muted,fontWeight=FontWeight.Black,fontSize=9.sp)
                    }
                    Spacer(Modifier.height(4.dp))
                    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.Bottom){
                        Column {
                            Text("TEMPO RESTANTE",color=Muted,fontSize=8.sp,fontWeight=FontWeight.Bold)
                            Text("${remainingSeconds/60}:${(remainingSeconds%60).toString().padStart(2,'0')}",color=Red,fontSize=24.sp,fontWeight=FontWeight.Black)
                        }
                        Column(horizontalAlignment=Alignment.End){
                            Text("MÉDIA DO GP",color=Muted,fontSize=8.sp,fontWeight=FontWeight.Bold)
                            Text(formatMs(referenceLap),color=Color.White,fontSize=12.sp,fontWeight=FontWeight.Black)
                            Text("≈ $expectedLaps voltas/piloto",color=Muted,fontSize=8.sp)
                        }
                    }
                    Spacer(Modifier.height(4.dp))
                    LinearProgressIndicator(progress={progress},modifier=Modifier.fillMaxWidth().height(4.dp),color=Red,trackColor=Panel2)
                    Row(Modifier.fillMaxWidth().padding(top=3.dp),horizontalArrangement=Arrangement.SpaceBetween){
                        Text("RELÓGIO REGRESSIVO",color=Muted,fontSize=8.sp)
                        Text("MELHOR VOLTA VÁLIDA",color=Muted,fontSize=8.sp)
                    }
                }
            }
        }

        item {
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(4.dp)){
                listOf(1500 to "0,5x",900 to "1x",450 to "2x",220 to "4x").forEach { (ms,label) ->
                    Button(onClick={speedMs=ms},modifier=Modifier.weight(1f),colors=ButtonDefaults.buttonColors(containerColor=if(speedMs==ms)Red else Panel2,contentColor=Color.White),contentPadding=PaddingValues(vertical=3.dp)){
                        Text(label,fontSize=8.sp,fontWeight=FontWeight.Black)
                    }
                }
            }
        }

        item {
            selected?.let{
                Text("${it.name}: ${it.entries.size} pilotos • eliminados nesta fase: ${it.eliminatedDriverIds.size}",color=Muted,fontSize=9.sp)
                Row(Modifier.fillMaxWidth().padding(top=5.dp),verticalAlignment=Alignment.CenterVertically){
                    Text("POS",color=Muted,fontSize=7.sp,fontWeight=FontWeight.Bold,modifier=Modifier.width(28.dp))
                    Text("EQUIPE",color=Muted,fontSize=7.sp,fontWeight=FontWeight.Bold,modifier=Modifier.width(36.dp))
                    Text("PILOTO",color=Muted,fontSize=7.sp,fontWeight=FontWeight.Bold,modifier=Modifier.weight(1f))
                    Text("PNEU",color=Muted,fontSize=7.sp,fontWeight=FontWeight.Bold,modifier=Modifier.width(44.dp))
                    Text("TEMPO",color=Muted,fontSize=7.sp,fontWeight=FontWeight.Bold,modifier=Modifier.width(58.dp),textAlign=TextAlign.End)
                }
            }
        }

        items(selected?.entries.orEmpty(), key={it.driverId}){e->
            val mine = e.driverId in s.plans.keys
            val driver = WorldDatabase.drivers.firstOrNull{it.id==e.driverId}
            val team = WorldDatabase.teams.firstOrNull{it.id==driver?.teamId}
            Row(
                Modifier.fillMaxWidth().background(if(mine) Color(0xFF2A1010) else Panel,RoundedCornerShape(5.dp)).padding(horizontal=7.dp,vertical=5.dp),
                verticalAlignment=Alignment.CenterVertically
            ){
                Text("${e.position}",color=if(mine) Red else Color.White,fontWeight=FontWeight.Black,fontSize=9.sp,modifier=Modifier.width(28.dp))
                if(team != null) TeamLogo(team.name,team.id,Modifier.size(28.dp)) else Spacer(Modifier.width(28.dp))
                TeamCarCompact(team?.id ?: 0,team?.name ?: "",Modifier.width(62.dp).height(24.dp))
                Text(
                    if(mine) "★ ${driver?.name ?: "Piloto ${e.driverId}"}" else (driver?.name ?: "Piloto ${e.driverId}"),
                    color=if(mine) Red else Color.White,fontWeight=if(mine) FontWeight.Black else FontWeight.Normal,fontSize=9.sp,maxLines=1,overflow=TextOverflow.Ellipsis,modifier=Modifier.weight(1f).padding(horizontal=5.dp)
                )
                val qualifyingTyre = s.qualifyingTyres[e.driverId] ?: when (s.weather) {
                    com.f1teammanager.core.race.Weather.LIGHT_RAIN, com.f1teammanager.core.race.Weather.MEDIUM_RAIN -> com.f1teammanager.core.race.Tyre.INTERMEDIATE
                    com.f1teammanager.core.race.Weather.HEAVY_RAIN -> com.f1teammanager.core.race.Tyre.WET
                    else -> when (display) { 0 -> com.f1teammanager.core.race.Tyre.HARD; 1 -> com.f1teammanager.core.race.Tyre.MEDIUM; else -> com.f1teammanager.core.race.Tyre.SOFT }
                }
                Box(Modifier.width(32.dp), contentAlignment=Alignment.Center) {
                    TyreCompoundIcon(qualifyingTyre, Modifier.size(21.dp))
                }
                Text(if(e.lapTimeMs==Long.MAX_VALUE) "—:--.---" else formatMs(e.lapTimeMs),color=if(mine) Color.White else Muted,fontSize=8.sp,fontWeight=FontWeight.Black,modifier=Modifier.width(58.dp),textAlign=TextAlign.End)
            }
        }
    }
}
@Composable private fun <T> ChoiceRow(title:String,current:String,values:List<T>,select:(T)->Unit){Column{Text(title,color=Muted,fontSize=10.sp,fontWeight=FontWeight.Bold);Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(6.dp)){values.forEach{v->FilterChip(selected=v.toString()==current,onClick={select(v)},label={Text(v.toString())})}}}}
@Composable
private fun Race(
    grandPrix: String,
    s: CareerWeekendEngine.SessionSnapshot,
    drivers: List<com.f1teammanager.core.season.DriverDefinition>,
    advance: () -> Unit,
    setStrategy: (Int, DriverStrategyMode) -> Unit,
    pitNow: (Int, Tyre) -> Unit,
    pitPlan: (Int, String) -> Unit,
    setRacePlan: (Int, String) -> Unit,
    decision: (ManagerDecisionAction) -> Unit,
) {
    var raceStarted by remember { mutableStateOf(false) }
    var running by remember { mutableStateOf(false) }
    var speedMs by remember { mutableIntStateOf(1100) }
    var pitDriver by remember { mutableIntStateOf(-1) }
    var showStartPlanDialog by remember { mutableStateOf(true) }
    val playerIds = drivers.map { it.id }.toSet()
    val playerStatus = s.carStatus.filter { it.driverId in playerIds }
    val statusById = s.carStatus.associateBy { it.driverId }
    val leaderTime = s.classification.minOfOrNull { it.totalTimeMs } ?: 0L

    LaunchedEffect(s.lap, s.decision, s.completed, running, speedMs, raceStarted) {
        if (raceStarted && running && s.decision == null && !s.completed) {
            kotlinx.coroutines.delay(speedMs.toLong())
            advance()
        }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 10.dp)) {
        Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) { Text(grandPrix.uppercase(), color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Black, maxLines = 1, overflow = TextOverflow.Ellipsis); Text("VOLTA ${s.lap}/${s.totalLaps}", color = Red, fontWeight = FontWeight.Bold) }
            if (raceStarted) {
                Button(onClick={running=!running}, modifier=Modifier.height(38.dp), shape=RoundedCornerShape(20.dp), colors=ButtonDefaults.buttonColors(containerColor=Red, contentColor=Color.White), contentPadding=PaddingValues(horizontal=12.dp, vertical=3.dp)) { Text(if(running) "Ⅱ  PAUSAR" else "▶  RETOMAR", fontWeight=FontWeight.Black, fontSize=8.sp) }
            }
            Spacer(Modifier.width(7.dp))
            Column(horizontalAlignment = Alignment.End) { Text(statusLabel(s.neutral), color = if (s.neutral == Neutralisation.GREEN) Green else Red, fontWeight = FontWeight.Black, fontSize=10.sp); Text(if (!raceStarted) "AGUARDANDO" else if (running) "AUTOMÁTICA" else "PAUSADA", color = Muted, fontSize = 8.sp); Text(weatherLabel(s.weather), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 10.sp) }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            listOf(1600 to "0,7x", 1100 to "1x", 650 to "1,7x", 300 to "3x").forEach { (ms, label) ->
                Button(onClick={speedMs=ms}, modifier=Modifier.weight(1f), colors=ButtonDefaults.buttonColors(containerColor=if(speedMs==ms) Red else Panel2, contentColor=Color.White), contentPadding=PaddingValues(vertical=2.dp)){Text(label,fontSize=9.sp)}
            }
        }

        val critical=s.alerts.firstOrNull { it.severity>=3 }
        critical?.let { Card(Modifier.fillMaxWidth().padding(vertical=3.dp), colors=CardDefaults.cardColors(containerColor=Color(0xFF3A0D0D))){Text(it.message,color=Color.White,fontWeight=FontWeight.Bold,fontSize=10.sp,modifier=Modifier.padding(7.dp))} }

        // Pit Wall cards follow the approved wide hierarchy while retaining the driver portrait.
        playerStatus.forEach { st ->
            val plan=s.plans[st.driverId]
            val ownEntry=s.classification.firstOrNull { it.driverId==st.driverId }
            val leaderEntry=s.classification.firstOrNull { it.position==1 }
            val gap=if(st.position<=1) "LÍDER" else if(ownEntry!=null && leaderEntry!=null) raceGapText(ownEntry.laps,ownEntry.totalTimeMs,leaderEntry.laps,leaderEntry.totalTimeMs) else gapToLeaderText(st.lastLapMs,leaderTime)
            val driverDef=drivers.firstOrNull { it.id==st.driverId }
            val teamDef=WorldDatabase.teams.firstOrNull { it.id==driverDef?.teamId }
            Card(Modifier.fillMaxWidth().padding(vertical=3.dp),colors=CardDefaults.cardColors(Panel)) {
                Column(Modifier.fillMaxWidth().padding(9.dp),verticalArrangement=Arrangement.spacedBy(7.dp)) {
                    Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.SpaceBetween) {
                        Text(st.driverName,color=Color.White,fontWeight=FontWeight.Black,fontSize=14.sp,maxLines=1,overflow=TextOverflow.Ellipsis,modifier=Modifier.weight(1f))
                        Text("P${st.position}  $gap",color=Red,fontWeight=FontWeight.Black,fontSize=12.sp,maxLines=1,softWrap=false)
                    }
                    Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(7.dp)) {
                        TeamCarCompact(teamDef?.id ?: 0,teamDef?.name ?: "",Modifier.weight(1f).height(52.dp))
                        DriverPhoto(st.driverId,st.driverName,Modifier.size(width=58.dp,height=62.dp).clip(RoundedCornerShape(6.dp)))
                    }
                    Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(5.dp)) {
                        Row(Modifier.weight(1f),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(4.dp)) {
                            TyreCompoundIcon(st.tyre,Modifier.size(25.dp))
                            Column { Text(tyreLabel(st.tyre).uppercase(),color=Color.White,fontSize=9.sp,fontWeight=FontWeight.Bold); Text("${st.tyreWear}% / ${st.tyre.targetLaps}v",color=Muted,fontSize=8.sp) }
                        }
                        Column(Modifier.weight(0.85f)) { Text("COMB",color=Muted,fontSize=8.sp); Text("${st.fuelPercent}%",color=Color.White,fontSize=10.sp,fontWeight=FontWeight.Bold) }
                        Column(Modifier.weight(0.8f)) { Text("ERS",color=Muted,fontSize=8.sp); Text("${st.ersPercent}%",color=Color.White,fontSize=10.sp,fontWeight=FontWeight.Bold) }
                        Column(Modifier.weight(0.7f)) { Text("DRS",color=Muted,fontSize=8.sp); Text(if(st.drsActive) "ATIVO" else "—",color=if(st.drsActive)Green else Muted,fontSize=9.sp,fontWeight=FontWeight.Bold) }
                        Button(onClick={pitDriver=st.driverId},modifier=Modifier.height(36.dp),colors=ButtonDefaults.buttonColors(containerColor=Red,contentColor=Color.White),contentPadding=PaddingValues(horizontal=14.dp,vertical=2.dp),shape=RoundedCornerShape(22.dp)){Text("BOX",fontSize=10.sp,fontWeight=FontWeight.Black)}
                    }
                    Divider(color=Line, thickness=1.dp)
                    Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.SpaceBetween) {
                        Text("ÚLTIMA ${formatMs(st.lastLapMs)}  •  PNEU ~${st.tyre.targetLaps}v",color=Muted,fontSize=9.sp)
                        Text(if(st.drsActive) "DRS ATIVO" else "DRS —",color=if(st.drsActive)Green else Muted,fontSize=9.sp,fontWeight=FontWeight.Bold)
                    }
                    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(5.dp)) {
                        DriverStrategyMode.entries.forEach { m -> Button(onClick={setStrategy(st.driverId,m)},modifier=Modifier.weight(1f).height(42.dp),shape=RoundedCornerShape(24.dp),colors=ButtonDefaults.buttonColors(containerColor=if(plan?.mode==m)Red else Panel2,contentColor=Color.White),contentPadding=PaddingValues(horizontal=4.dp,vertical=2.dp)){Text(strategyLabel(m).uppercase(),fontSize=9.sp,maxLines=1,softWrap=false)} }
                    }
                }
            }
        }

        Card(Modifier.fillMaxWidth(), colors=CardDefaults.cardColors(Panel)) {
            Column {
                Row(Modifier.fillMaxWidth().padding(horizontal=8.dp,vertical=6.dp),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){Text("CLASSIFICAÇÃO AO VIVO",color=Color.White,fontWeight=FontWeight.Black,fontSize=15.sp);Text("${s.classification.size} PILOTOS",color=Red,fontWeight=FontWeight.Black,fontSize=10.sp)}
                Row(Modifier.fillMaxWidth().padding(horizontal=8.dp),horizontalArrangement=Arrangement.SpaceBetween){Text("POS",color=Muted,fontSize=8.sp,modifier=Modifier.width(24.dp));Text("EQUIPE",color=Muted,fontSize=8.sp,modifier=Modifier.width(28.dp)); Text("CARRO",color=Muted,fontSize=8.sp,modifier=Modifier.width(58.dp)); Text("PILOTO",color=Muted,fontSize=8.sp,modifier=Modifier.weight(1f));Text("PNEU",color=Muted,fontSize=8.sp,modifier=Modifier.width(42.dp));Text("GAP",color=Muted,fontSize=8.sp,modifier=Modifier.width(54.dp))}
                Column {
                    itemsInClassification@ for (f in s.classification) {
                        val mine=f.driverId in playerIds; val st=statusById[f.driverId]
                        val leaderEntry = s.classification.firstOrNull { it.position == 1 }
                        val gap=if(f.position==1)"LÍDER" else if (leaderEntry != null) raceGapText(f.laps, f.totalTimeMs, leaderEntry.laps, leaderEntry.totalTimeMs) else gapToLeaderText(f.totalTimeMs, leaderTime)
                        val raceTeam = WorldDatabase.teams.firstOrNull { it.name.equals(f.teamName, ignoreCase = true) }
                        Row(Modifier.fillMaxWidth().background(if(mine) Color(0xFF2A1010) else Color.Transparent).padding(horizontal=6.dp,vertical=4.dp),verticalAlignment=Alignment.CenterVertically){
                            Text("${f.position}",color=if(mine)Red else Muted,fontWeight=FontWeight.Bold,modifier=Modifier.width(22.dp),fontSize=9.sp)
                            TeamLogo(f.teamName, raceTeam?.id ?: 0, Modifier.size(24.dp))
                            Spacer(Modifier.width(4.dp))
                            TeamCarCompact(raceTeam?.id ?: 0, f.teamName, Modifier.width(54.dp).height(22.dp))
                            Spacer(Modifier.width(4.dp))
                            Text(f.driverName,color=if(mine) Red else Color.White,fontWeight=if(mine) FontWeight.Black else FontWeight.Normal,modifier=Modifier.weight(1f),maxLines=1,overflow=TextOverflow.Ellipsis,fontSize=9.sp)
                            Row(Modifier.width(48.dp),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(3.dp)){TyreCompoundIcon(f.tyre,Modifier.size(16.dp)); Text(tyreLabel(f.tyre),color=if((st?.tyreWear?:0)>=80)Red else Muted,fontSize=7.sp,maxLines=1)}
                            Text(if(f.status.startsWith("DNF"))"DNF" else gap,color=if(f.status.startsWith("DNF"))Red else Muted,fontSize=8.sp,modifier=Modifier.width(52.dp))
                        }
                    }
                }
            }
        }

        if(s.events.isNotEmpty()) Text(s.events.takeLast(1).joinToString(" • "){it.detail},color=Muted,fontSize=8.sp,maxLines=1,overflow=TextOverflow.Ellipsis,modifier=Modifier.padding(vertical=2.dp))
        s.decision?.let { d ->
            val isRedFlag = d.request.type == ManagerDecisionType.RED_FLAG
            val restartPlan = s.plans[d.request.driverId]
            if (isRedFlag && restartPlan != null) {
                RaceRedFlagDialog(
                    snapshot = s,
                    restartPlan = restartPlan,
                    onDecision = { action -> decision(action); running = true }
                )
            } else if (!isRedFlag) {
                val decisionDriverId = d.request.driverId
                val decisionStatus = statusById[decisionDriverId]
                val lapsRemaining = (s.totalLaps - s.lap).coerceAtLeast(0)
                val currentTyre = decisionStatus?.tyre
                val tyreWear = decisionStatus?.tyreWear ?: 0
                val tyreLife = currentTyre?.let { (it.targetLaps - tyreWear * it.targetLaps / 100).coerceAtLeast(0) } ?: 0
                val safetyCarDecision = d.request.message.contains("Safety Car", ignoreCase = true)
                Dialog(
                    onDismissRequest = {},
                    properties = DialogProperties(usePlatformDefaultWidth = false)
                ) {
                    Surface(
                        modifier = Modifier.fillMaxWidth(0.94f).heightIn(max = 850.dp),
                        shape = RoundedCornerShape(24.dp),
                        color = Color(0xFF080D14),
                        border = BorderStroke(1.dp, Line),
                        shadowElevation = 20.dp
                    ) {
                        Column(
                            Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(if (safetyCarDecision) "🚨" else "🏁", fontSize = 34.sp)
                                Spacer(Modifier.width(10.dp))
                                Column(Modifier.weight(1f)) {
                                    Text("DECISÃO DO", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Black)
                                    Text("MANAGER", color = Red, fontSize = 24.sp, fontWeight = FontWeight.Black)
                                }
                                IconButton(onClick = { decision(ManagerDecisionAction.STAY_OUT); running = true }) {
                                    Text("×", color = Color.White, fontSize = 24.sp)
                                }
                            }
                            if (safetyCarDecision) {
                                Surface(
                                    color = Color(0xFF332600),
                                    shape = RoundedCornerShape(12.dp),
                                    border = BorderStroke(1.dp, Color(0xFFFFC928))
                                ) {
                                    Text(
                                        "SC  •  SAFETY CAR NA PISTA",
                                        modifier = Modifier.fillMaxWidth().padding(12.dp),
                                        color = Color(0xFFFFC928),
                                        fontWeight = FontWeight.Black,
                                        fontSize = 13.sp
                                    )
                                }
                            }
                            Text(
                                d.request.message,
                                color = Color(0xFFDCE5F0),
                                fontSize = 14.sp,
                                lineHeight = 20.sp
                            )
                            Surface(
                                color = Panel2,
                                shape = RoundedCornerShape(14.dp),
                                border = BorderStroke(1.dp, Line)
                            ) {
                                Row(
                                    Modifier.fillMaxWidth().padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(
                                        modifier = Modifier.size(58.dp).background(Red.copy(alpha = 0.12f), RoundedCornerShape(12.dp)),
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.Center
                                    ) {
                                        Text(
                                            s.classification.firstOrNull { it.driverId == decisionDriverId }?.let { "P${it.position}" } ?: "—",
                                            color = Red, fontWeight = FontWeight.Black, fontSize = 18.sp
                                        )
                                    }
                                    Spacer(Modifier.width(12.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text(d.driverName, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Black)
                                        Text(
                                            s.classification.firstOrNull { it.driverId == decisionDriverId }?.teamName
                                                ?: "Piloto",
                                            color = Muted, fontSize = 12.sp
                                        )
                                    }
                                }
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Surface(
                                    modifier = Modifier.weight(1f),
                                    color = Panel2,
                                    shape = RoundedCornerShape(14.dp),
                                    border = BorderStroke(1.dp, Line)
                                ) {
                                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Text("PNEU ATUAL", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            if (currentTyre != null) TyreCompoundIcon(currentTyre, Modifier.size(42.dp))
                                            Spacer(Modifier.width(8.dp))
                                            Column {
                                                Text(currentTyre?.let { tyreLabel(it).uppercase() } ?: "N/D", color = Color.White, fontWeight = FontWeight.Black, fontSize = 13.sp)
                                                Text("${tyreWear}% desgaste", color = if (tyreWear >= 80) Red else Muted, fontSize = 10.sp)
                                            }
                                        }
                                        HorizontalDivider(color = Line)
                                        Text("$tyreLife voltas estimadas", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                                Surface(
                                    modifier = Modifier.weight(1f),
                                    color = Panel2,
                                    shape = RoundedCornerShape(14.dp),
                                    border = BorderStroke(1.dp, Line)
                                ) {
                                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Text("VOLtas RESTANTES".uppercase(), color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                        Text("$lapsRemaining", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Black)
                                        Text("para o fim da corrida", color = Muted, fontSize = 10.sp)
                                        HorizontalDivider(color = Line)
                                        Text("PISTA", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                        Text(
                                            when (s.weather) {
                                                Weather.HEAVY_RAIN -> "Chuva forte"
                                                Weather.MEDIUM_RAIN -> "Chuva moderada"
                                                Weather.LIGHT_RAIN -> "Chuva leve"
                                                else -> "Seco"
                                            },
                                            color = if (s.weather == Weather.DRY) Color(0xFFFFC928) else Color(0xFF73C9FF),
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp
                                        )
                                    }
                                }
                            }
                            d.request.options.forEach { action ->
                                val isBox = action == ManagerDecisionAction.BOX
                                val title = actionLabel(action)
                                val subtitle = when (action) {
                                    ManagerDecisionAction.BOX -> "Entrar nos boxes agora"
                                    ManagerDecisionAction.STAY_OUT -> "Continuar na pista com o plano atual"
                                    ManagerDecisionAction.EXTEND_STINT -> "Permanecer na pista e estender o stint"
                                    else -> "Aplicar esta decisão à estratégia da corrida"
                                }
                                Surface(
                                    modifier = Modifier.fillMaxWidth().clickable {
                                        if (action == ManagerDecisionAction.BOX) {
                                            pitDriver = decisionDriverId
                                            running = true
                                        } else {
                                            decision(action)
                                            running = true
                                        }
                                    },
                                    color = if (isBox) Red else Panel2,
                                    shape = RoundedCornerShape(16.dp),
                                    border = BorderStroke(1.dp, if (isBox) Red else Line)
                                ) {
                                    Row(
                                        Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 13.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            when (action) {
                                                ManagerDecisionAction.BOX -> "▣"
                                                ManagerDecisionAction.STAY_OUT -> "◷"
                                                ManagerDecisionAction.EXTEND_STINT -> "»"
                                                else -> "›"
                                            },
                                            color = if (isBox) Color.White else Red,
                                            fontSize = 28.sp,
                                            fontWeight = FontWeight.Black
                                        )
                                        Spacer(Modifier.width(14.dp))
                                        Column(Modifier.weight(1f)) {
                                            Text(title, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Black)
                                            Text(subtitle, color = if (isBox) Color.White.copy(alpha = .85f) else Muted, fontSize = 11.sp)
                                        }
                                        Text("›", color = Color.White, fontSize = 26.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        if (!raceStarted && showStartPlanDialog) {
            RaceStartPlanDialog(
                snapshot = s,
                playerStatus = playerStatus,
                setRacePlan = setRacePlan,
                setStrategy = setStrategy,
                onCancel = { showStartPlanDialog = false },
                onConfirm = { showStartPlanDialog = false; raceStarted = true; running = true }
            )
        }
        if (pitDriver > 0) {
            val activeDriverId = pitDriver
            val recommended = when (s.weather) {
                Weather.HEAVY_RAIN -> Tyre.WET
                Weather.LIGHT_RAIN, Weather.MEDIUM_RAIN -> Tyre.INTERMEDIATE
                else -> Tyre.MEDIUM
            }
            val activePlan = s.plans[activeDriverId]
            var selectedTyre by remember(activeDriverId, s.lap) { mutableStateOf(recommended) }
            Dialog(
                onDismissRequest = { pitDriver = -1; running = true },
                properties = DialogProperties(usePlatformDefaultWidth = false)
            ) {
                Surface(
                    modifier = Modifier.fillMaxWidth(0.96f).heightIn(max = 850.dp),
                    shape = RoundedCornerShape(24.dp),
                    color = Color(0xFF080D14),
                    border = BorderStroke(1.dp, Line),
                    shadowElevation = 20.dp
                ) {
                    Column(
                        Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("🏁", fontSize = 38.sp)
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text("ESCOLHER PNEU", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Black)
                                Text("PARA O BOX", color = Red, fontSize = 22.sp, fontWeight = FontWeight.Black)
                            }
                            IconButton(onClick = { pitDriver = -1; running = true }) {
                                Text("×", color = Color.White, fontSize = 25.sp)
                            }
                        }
                        Surface(
                            color = Red.copy(alpha = 0.10f),
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, Red)
                        ) {
                            Text(
                                "◷  FALTAM ${(s.totalLaps - s.lap).coerceAtLeast(0)} VOLTAS PARA O FIM DA CORRIDA",
                                modifier = Modifier.fillMaxWidth().padding(12.dp),
                                color = Red, fontSize = 12.sp, fontWeight = FontWeight.Black
                            )
                        }
                        Text(
                            "A vida mostrada é a referência do composto nas condições atuais. O desgaste real também considera clima e postura.",
                            color = Muted, fontSize = 11.sp, lineHeight = 16.sp
                        )
                        Surface(
                            color = Green.copy(alpha = 0.10f),
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, Green)
                        ) {
                            Text(
                                "✓  RECOMENDADO AGORA: ${tyreLabel(recommended)}",
                                modifier = Modifier.fillMaxWidth().padding(12.dp),
                                color = Green, fontSize = 12.sp, fontWeight = FontWeight.Black
                            )
                        }
                        listOf(Tyre.SOFT, Tyre.MEDIUM, Tyre.HARD, Tyre.INTERMEDIATE, Tyre.WET).forEach { tyre ->
                            val driverTyreWear = drivers.firstOrNull { it.id == activeDriverId }?.tyre ?: 50
                            val life = tyreLifeEstimate(
                                tyre, s.weather,
                                activePlan?.mode ?: DriverStrategyMode.BALANCED,
                                driverTyreWear
                            )
                            val chosen = selectedTyre == tyre
                            Surface(
                                modifier = Modifier.fillMaxWidth().clickable { selectedTyre = tyre },
                                color = if (chosen) Red.copy(alpha = 0.18f) else Panel2,
                                shape = RoundedCornerShape(14.dp),
                                border = BorderStroke(if (chosen) 2.dp else 1.dp, if (chosen) Red else Line)
                            ) {
                                Row(
                                    Modifier.padding(horizontal = 12.dp, vertical = 9.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    TyrePlanCompoundCard(tyre, life, Modifier.size(width = 64.dp, height = 70.dp))
                                    Spacer(Modifier.width(12.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text("${tyreLabel(tyre)}  •  $life VOLTAS", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                        if (tyre == recommended) {
                                            Text("RECOMENDADO", color = Green, fontSize = 10.sp, fontWeight = FontWeight.Black)
                                        }
                                    }
                                    RadioButton(
                                        selected = chosen,
                                        onClick = { selectedTyre = tyre },
                                        colors = RadioButtonDefaults.colors(selectedColor = Red)
                                    )
                                }
                            }
                        }
                        if (activePlan != null) {
                            if (activePlan.weatherManualMode) {
                                Text("PLANO ABANDONADO PELA CHUVA", color = Red, fontWeight = FontWeight.Black, fontSize = 11.sp)
                                Text(
                                    "As trocas passam a ser manuais quando a chuva exige mudança de composto.",
                                    color = Muted, fontSize = 10.sp
                                )
                            } else {
                                val activeTyrePlan = activePlan.tyrePlans[activePlan.activePlan]
                                Surface(
                                    color = Panel2, shape = RoundedCornerShape(14.dp),
                                    border = BorderStroke(1.dp, Line)
                                ) {
                                    Column(Modifier.fillMaxWidth().padding(12.dp)) {
                                        Text("PLANO ATUAL: ${activePlan.activePlan}", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Black)
                                        Text(planDescription(activeTyrePlan), color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
                                    }
                                }
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    listOf("A", "B", "C", "D").forEach { id ->
                                        Button(
                                            onClick = { pitPlan(activeDriverId, id); pitDriver = -1; running = true },
                                            modifier = Modifier.weight(1f).heightIn(min = 42.dp),
                                            colors = ButtonDefaults.buttonColors(containerColor = if (activePlan.activePlan == id) Red else Panel2),
                                            contentPadding = PaddingValues(3.dp)
                                        ) { Text("PLANO $id", fontSize = 10.sp, fontWeight = FontWeight.Black) }
                                    }
                                }
                                Button(
                                    onClick = { pitPlan(activeDriverId, activePlan.activePlan); pitDriver = -1; running = true },
                                    modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = Red),
                                    shape = RoundedCornerShape(14.dp)
                                ) { Text("⚖  MANTER PLANO ${activePlan.activePlan}", fontWeight = FontWeight.Black) }
                            }
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            HorizontalDivider(Modifier.weight(1f), color = Line)
                            Text("  OU ESCOLHER MANUALMENTE  ", color = Muted, fontSize = 10.sp)
                            HorizontalDivider(Modifier.weight(1f), color = Line)
                        }
                        OutlinedButton(
                            onClick = { pitNow(activeDriverId, selectedTyre); pitDriver = -1; running = true },
                            modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp),
                            shape = RoundedCornerShape(14.dp),
                            border = BorderStroke(1.dp, Line)
                        ) { Text("CONFIRMAR ${tyreLabel(selectedTyre)}", color = Color.White, fontWeight = FontWeight.Black) }
                        OutlinedButton(
                            onClick = { pitDriver = -1; running = true },
                            modifier = Modifier.fillMaxWidth().heightIn(min = 50.dp),
                            shape = RoundedCornerShape(14.dp),
                            border = BorderStroke(1.dp, Line)
                        ) { Text("SAIR  •  NÃO IR AO BOX", color = Color.White, fontWeight = FontWeight.Black) }
                    }
                }
            }
        }
    }
}


@Composable
private fun RaceModalFrame(content: @Composable ColumnScope.() -> Unit) {
    Dialog(onDismissRequest = {}, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(
            modifier = Modifier.fillMaxWidth(0.96f).heightIn(max = 900.dp),
            shape = RoundedCornerShape(26.dp),
            color = Color(0xFF080D14),
            border = BorderStroke(1.dp, Color(0xFF303846)),
            shadowElevation = 18.dp
        ) {
            Column(
                Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                content = content
            )
        }
    }
}

@Composable
private fun ModalStat(title:String, value:String, accent:Color = Color.White, modifier:Modifier=Modifier) {
    Row(
        modifier.background(Color(0xFF0B121B), RoundedCornerShape(16.dp))
            .border(1.dp, Color(0xFF202B39), RoundedCornerShape(16.dp))
            .padding(horizontal=10.dp, vertical=12.dp),
        verticalAlignment=Alignment.CenterVertically,
        horizontalArrangement=Arrangement.spacedBy(9.dp)
    ) {
        val normalizedTitle = title.uppercase().replace("\n", " ")
        val icon = when {
            normalizedTitle.contains("VOLTAS") -> "◉"
            normalizedTitle.contains("COMBUSTÍVEL") -> "⛽"
            normalizedTitle.contains("CONDIÇÕES") -> "☀"
            else -> "•"
        }
        Text(icon, color=accent, fontSize=21.sp, fontWeight=FontWeight.Black)
        Column(Modifier.weight(1f)) {
            Text(normalizedTitle, color=Muted, fontSize=8.sp, fontWeight=FontWeight.Bold, maxLines=2)
            Text(value, color=accent, fontSize=17.sp, fontWeight=FontWeight.Black, modifier=Modifier.padding(top=3.dp), maxLines=1, overflow=TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun DriverStartStrategyBlock(
    st: com.f1teammanager.core.race.RaceCarStatus,
    plan: CareerWeekendEngine.DriverPlan?,
    setRacePlan: (Int,String)->Unit,
    setStrategy: (Int,DriverStrategyMode)->Unit
) {
    val driver = WorldDatabase.drivers.firstOrNull { it.id == st.driverId }
    val team = WorldDatabase.teams.firstOrNull { it.id == driver?.teamId }
    val activeTyrePlan = plan?.tyrePlans?.get(plan.activePlan)
    val accent = if (st.position % 2 == 0) Color(0xFF29A9FF) else Red
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp))
            .background(Color(0xFF0A111A))
            .border(1.dp, accent.copy(alpha=.62f), RoundedCornerShape(20.dp))
            .padding(10.dp),
        verticalArrangement=Arrangement.spacedBy(8.dp)
    ) {
        Row(Modifier.fillMaxWidth().height(96.dp), verticalAlignment=Alignment.CenterVertically) {
            Box(Modifier.width(94.dp).fillMaxHeight().clip(RoundedCornerShape(12.dp)).background(accent.copy(alpha=.16f))) {
                DriverPhoto(st.driverId, st.driverName, Modifier.fillMaxSize())
                Text(st.position.toString(), color=Color.White.copy(alpha=.95f), fontSize=16.sp, fontWeight=FontWeight.Black,
                    modifier=Modifier.align(Alignment.TopStart).padding(6.dp).background(Color(0xCC111722), RoundedCornerShape(5.dp)).padding(horizontal=6.dp, vertical=2.dp))
            }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f), verticalArrangement=Arrangement.spacedBy(4.dp)) {
                Text(st.driverName, color=Color.White, fontWeight=FontWeight.Black, fontSize=17.sp, maxLines=2, overflow=TextOverflow.Ellipsis)
                Row(verticalAlignment=Alignment.CenterVertically) {
                    if (driver != null) DriverFlag(driver.country, Modifier.size(24.dp, 16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(team?.name ?: "Equipe", color=Muted, fontSize=10.sp, maxLines=1, overflow=TextOverflow.Ellipsis)
                }
            }
            Column(Modifier.width(58.dp).clip(RoundedCornerShape(topStart=14.dp, bottomStart=14.dp)).background(Color(0xFF111B27)).padding(vertical=8.dp), horizontalAlignment=Alignment.CenterHorizontally) {
                Text("GERAL", color=Muted, fontSize=8.sp, fontWeight=FontWeight.Bold)
                Text(driver?.let { driverOverall(it).toString() } ?: "—", color=Color.White, fontWeight=FontWeight.Black, fontSize=23.sp)
            }
        }

        Text("ESTRATÉGIA DE PNEUS", color=Color(0xFFB5C0D0), fontSize=10.sp, fontWeight=FontWeight.Bold)
        Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(4.dp)) {
            listOf("A","B","C","D").forEach { id ->
                val selected = plan?.activePlan == id
                Button(
                    onClick={setRacePlan(st.driverId,id)},
                    modifier=Modifier.weight(1f).height(42.dp),
                    shape=RoundedCornerShape(11.dp),
                    colors=ButtonDefaults.buttonColors(containerColor=if(selected) Red else Color(0xFF111B27), contentColor=Color.White),
                    border=if(selected) BorderStroke(1.dp, Color(0xFFFF5555)) else BorderStroke(1.dp, Color(0xFF202B39)),
                    contentPadding=PaddingValues(horizontal=1.dp, vertical=3.dp)
                ) { Text("PLANO $id", fontSize=8.sp, fontWeight=FontWeight.Black, maxLines=1) }
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(4.dp)) {
            if (activeTyrePlan?.sequence?.isNotEmpty() == true) {
                activeTyrePlan.sequence.forEachIndexed { index, tyre ->
                    TyrePlanCompoundCard(tyre, activeTyrePlan.stintLaps.getOrElse(index) { tyre.targetLaps }, Modifier.weight(1f))
                }
            } else {
                Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(Color(0xFF111B27)).padding(10.dp)) {
                    Text("Plano indisponível", color=Muted, fontSize=9.sp)
                }
            }
        }
        Text("POSTURA DE CORRIDA", color=Color(0xFFB5C0D0), fontSize=10.sp, fontWeight=FontWeight.Bold)
        Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(5.dp)) {
            DriverStrategyMode.entries.forEach { mode ->
                val selected = plan?.mode == mode
                Button(
                    onClick={setStrategy(st.driverId,mode)},
                    modifier=Modifier.weight(1f).height(48.dp),
                    shape=RoundedCornerShape(12.dp),
                    colors=ButtonDefaults.buttonColors(containerColor=if(selected) Red else Color(0xFF111B27), contentColor=Color.White),
                    border=if(selected) BorderStroke(1.dp, Color(0xFFFF5555)) else BorderStroke(1.dp, Color(0xFF202B39)),
                    contentPadding=PaddingValues(horizontal=4.dp, vertical=4.dp)
                ) {
                    Text(when(mode) { DriverStrategyMode.ATTACK -> "»  ATAQUE"; DriverStrategyMode.BALANCED -> "⚖  EQUILIBRADO"; DriverStrategyMode.DEFENSE -> "◈  DEFESA / ECONOMIA" }, fontSize=8.sp, fontWeight=FontWeight.Bold, textAlign=TextAlign.Center, maxLines=2, overflow=TextOverflow.Ellipsis)
                }
            }
        }
    }
}

@Composable
private fun TyrePlanCompoundCard(tyre: Tyre, laps: Int, modifier: Modifier = Modifier) {
    val (label, short, color) = when(tyre) {
        Tyre.SOFT -> Triple("SOFT", "S", Color(0xFFFF3038))
        Tyre.MEDIUM -> Triple("MEDIUM", "M", Color(0xFFFFD21F))
        Tyre.HARD -> Triple("HARD", "H", Color(0xFFB8C0CB))
        Tyre.INTERMEDIATE -> Triple("INTER", "I", Color(0xFF39D779))
        Tyre.WET -> Triple("WET", "W", Color(0xFF329BFF))
    }
    Column(
        modifier.clip(RoundedCornerShape(11.dp)).background(Color(0xFF101A24))
            .border(1.dp, Color(0xFF273443), RoundedCornerShape(11.dp)).padding(6.dp),
        verticalArrangement=Arrangement.spacedBy(3.dp), horizontalAlignment=Alignment.CenterHorizontally
    ) {
        Box(Modifier.size(30.dp).border(3.dp, color, RoundedCornerShape(50)), contentAlignment=Alignment.Center) {
            Text(short, color=Color.White, fontSize=11.sp, fontWeight=FontWeight.Black)
        }
        Text(label, color=Color.White, fontSize=8.sp, fontWeight=FontWeight.Bold, maxLines=1)
        Text("$laps voltas", color=Muted, fontSize=7.sp, maxLines=1, softWrap=false)
    }
}

@Composable
private fun RaceStartPlanDialog(
    snapshot: CareerWeekendEngine.SessionSnapshot,
    playerStatus: List<com.f1teammanager.core.race.RaceCarStatus>,
    setRacePlan: (Int,String)->Unit,
    setStrategy: (Int,DriverStrategyMode)->Unit,
    onCancel:()->Unit,
    onConfirm:()->Unit
) {
    RaceModalFrame {
        Row(Modifier.fillMaxWidth(), verticalAlignment=Alignment.CenterVertically) {
            Box(Modifier.width(88.dp).height(104.dp).clip(RoundedCornerShape(topStart=14.dp, bottomStart=14.dp))
                .background(Color(0xFF251019)), contentAlignment=Alignment.Center) {
                Text("🏁", fontSize=52.sp)
            }
            Column(Modifier.weight(1f).padding(horizontal=10.dp), verticalArrangement=Arrangement.spacedBy(1.dp)) {
                Text("PLANO DE INÍCIO", color=Color.White, fontWeight=FontWeight.Black, fontSize=19.sp, maxLines=1, softWrap=false)
                Text("DA CORRIDA", color=Red, fontWeight=FontWeight.Black, fontSize=21.sp, maxLines=1, softWrap=false)
                Text("Defina o plano de pneus e a postura dos 2 pilotos para o início da corrida.", color=Color(0xFFD9E0E9), fontSize=10.sp, lineHeight=13.sp)
            }
            Button(onClick=onCancel, modifier=Modifier.size(44.dp), shape=RoundedCornerShape(12.dp), colors=ButtonDefaults.buttonColors(containerColor=Color(0xFF111B27),contentColor=Color.White), contentPadding=PaddingValues(0.dp)) { Text("×", fontSize=26.sp, fontWeight=FontWeight.Light) }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(7.dp)) {
            ModalStat("VOLTAS\nTOTAIS", "${snapshot.totalLaps}", Color.White, Modifier.weight(1f))
            ModalStat("COMBUSTÍVEL", "100%", Green, Modifier.weight(1f))
            ModalStat("CONDIÇÕES", weatherLabel(snapshot.weather).replace("☀️ ", "").uppercase(), Color.White, Modifier.weight(1f))
        }
        playerStatus.forEachIndexed { index, st ->
            DriverStartStrategyBlock(st, snapshot.plans[st.driverId], setRacePlan, setStrategy)
            if (index < playerStatus.lastIndex) HorizontalDivider(color=Line, thickness=1.dp)
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            Button(onClick=onCancel, modifier=Modifier.weight(.9f).height(54.dp), shape=RoundedCornerShape(18.dp), colors=ButtonDefaults.buttonColors(containerColor=Color(0xFF28313F), contentColor=Color.White)) {
                Text("CANCELAR", fontWeight=FontWeight.Black, fontSize=12.sp)
            }
            Button(onClick=onConfirm, modifier=Modifier.weight(1.35f).height(54.dp), shape=RoundedCornerShape(18.dp), colors=ButtonDefaults.buttonColors(containerColor=Red, contentColor=Color.White)) {
                Text("▶  CONFIRMAR E INICIAR", fontSize=11.sp, fontWeight=FontWeight.Black, textAlign=TextAlign.Center)
            }
        }
    }
}

@Composable
private fun PlanSelectorRow(
    planId: String,
    selected: Boolean,
    description: String,
    onClick: () -> Unit
) {
    val borderColor = if (selected) Red else Color(0xFF303846)
    val backgroundColor = if (selected) Color(0xFF25151A) else Color(0xFF101722)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(backgroundColor)
            .border(1.dp, borderColor, RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Box(
            modifier = Modifier
                .size(34.dp)
                .background(if (selected) Red else Color(0xFF263141), RoundedCornerShape(9.dp)),
            contentAlignment = Alignment.Center
        ) {
            Text(planId, color = Color.White, fontWeight = FontWeight.Black, fontSize = 15.sp)
        }
        Column(Modifier.weight(1f)) {
            Text("PLANO $planId", color = Color.White, fontWeight = FontWeight.Black, fontSize = 11.sp)
            Text(description, color = Muted, fontSize = 9.sp, lineHeight = 13.sp)
        }
        Text(if (selected) "SELECIONADO" else "ESCOLHER", color = if (selected) Red else Muted, fontWeight = FontWeight.Black, fontSize = 8.sp)
    }
}

@Composable
private fun RaceRedFlagDialog(
    snapshot: CareerWeekendEngine.SessionSnapshot,
    restartPlan: CareerWeekendEngine.DriverPlan,
    onDecision:(ManagerDecisionAction)->Unit
) {
    val remaining = (snapshot.totalLaps - snapshot.lap).coerceAtLeast(0)
    RaceModalFrame {
        Row(verticalAlignment=Alignment.CenterVertically) {
            Text("🚩", fontSize=36.sp)
            Spacer(Modifier.width(10.dp))
            Column {
                Text("BANDEIRA VERMELHA", color=Color.White, fontWeight=FontWeight.Black, fontSize=19.sp)
                Text("RELARGADA", color=Red, fontWeight=FontWeight.Black, fontSize=19.sp)
            }
        }
        Text("Bandeira vermelha após acidente. Escolha o plano de pneus para a relargada.", color=Color.White, fontSize=10.sp, lineHeight=15.sp, modifier=Modifier.background(Color(0xFF11151D), RoundedCornerShape(12.dp)).border(1.dp, Color(0xFF303540), RoundedCornerShape(12.dp)).padding(12.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(6.dp)) {
            ModalStat("VOLTAS\nRESTANTES", "$remaining", modifier=Modifier.weight(1f))
            ModalStat("COMBUSTÍVEL", "INTACTO", Green, Modifier.weight(1f))
            ModalStat("PLANOS", "A / B / C / D", Red, Modifier.weight(1f))
        }
        Text("NOVOS PLANOS PARA AS $remaining VOLTAS RESTANTES", color=Red, fontWeight=FontWeight.Black, fontSize=11.sp)
        Text("Os planos A/B/C/D foram recalculados para a distância restante. O combustível permanece intacto.", color=Muted, fontSize=8.sp, lineHeight=13.sp)
        listOf("A","B","C","D").forEach { id ->
            val plan=restartPlan.tyrePlans[id]
            PlanSelectorRow(id, restartPlan.activePlan==id, planDescription(plan), onClick={
                onDecision(when(id){"A"->ManagerDecisionAction.RESTART_PLAN_A;"B"->ManagerDecisionAction.RESTART_PLAN_B;"C"->ManagerDecisionAction.RESTART_PLAN_C;else->ManagerDecisionAction.RESTART_PLAN_D})
            })
        }
    }
}

private fun gapToLeaderText(time: Long, leader: Long): String {
    val gap = (time - leader).coerceAtLeast(0L)
    if (gap > 600_000L) return "DIF. VOLTAS"
    return String.format(java.util.Locale.US, "+%.3fs", gap / 1000.0)
}

private fun raceGapText(driverLaps: Int, driverTimeMs: Long, leaderLaps: Int, leaderTimeMs: Long): String {
    val gap = raceGapMs(driverLaps, driverTimeMs, leaderLaps, leaderTimeMs)
    return formatGap(gap)
}

private fun formatRaceTime(ms: Long): String {
    val totalSeconds = ms / 1000
    val hours = totalSeconds / 3600
    val minutes = (totalSeconds % 3600) / 60
    val seconds = totalSeconds % 60
    val millis = ms % 1000
    return if (hours > 0) String.format(java.util.Locale.US, "%d:%02d:%02d.%03d", hours, minutes, seconds, millis)
    else String.format(java.util.Locale.US, "%d:%02d.%03d", minutes, seconds, millis)
}

internal fun formatGap(ms: Long): String {
    // Valores negativos representam diferença de voltas, não tempo.
    if (ms < 0L) {
        val laps = -ms
        return if (laps == 1L) "+1 VOLTA" else "+$laps VOLTAS"
    }
    // Evita exibir como gap temporal valores legados absurdos que representam
    // carros em voltas diferentes e foram persistidos por versões anteriores.
    if (ms > 600_000L) return "DIF. VOLTAS"
    val seconds = ms / 1000
    val millis = ms % 1000
    return String.format(java.util.Locale.US, "+%d.%03ds", seconds, millis)
}

internal fun raceGapMs(driverLaps: Int, driverTimeMs: Long, leaderLaps: Int, leaderTimeMs: Long): Long =
    if (driverLaps < leaderLaps) -(leaderLaps - driverLaps).toLong()
    else (driverTimeMs - leaderTimeMs).coerceAtLeast(0L)

@Composable private fun Result(r:RaceResult,teamId:Int,store:CareerPreferences,onCalendar:()->Unit){
    val teamName=WorldDatabase.teams.first{it.id==teamId}.name
    val mine=r.classification.filter{it.teamName==teamName}
    val earned=mine.sumOf{r.points[it.driverId]?:0}
    val leader=r.classification.firstOrNull { !it.status.startsWith("DNF") }
    val leaderTime=leader?.totalTimeMs ?: 0L
    val dnfs=r.classification.filter { it.status.startsWith("DNF") }
    Column(Modifier.fillMaxSize().padding(16.dp)){
        HeaderBlock("RESULTADO","CORRIDA FINALIZADA")
        Card(Modifier.fillMaxWidth().padding(top=10.dp),colors=CardDefaults.cardColors(Panel)){
            Column(Modifier.padding(13.dp)){
                Text("SUA EQUIPE",color=Red,fontWeight=FontWeight.Black)
                mine.forEach{f->
                    Row(Modifier.fillMaxWidth().padding(top=6.dp),verticalAlignment=Alignment.CenterVertically){
                        Text("P${f.position}",color=if(f.position<=3)Red else Muted,fontWeight=FontWeight.Black,modifier=Modifier.width(34.dp))
                        Text(f.driverName,color=Color.White,fontWeight=FontWeight.Bold,modifier=Modifier.weight(1f),maxLines=1,overflow=TextOverflow.Ellipsis)
                        Text("${r.points[f.driverId]?:0} PTS",color=Color.White,fontWeight=FontWeight.Bold,fontSize=10.sp)
                    }
                }
                Text("PONTOS CONQUISTADOS: $earned",color=Color.White,fontWeight=FontWeight.Black,modifier=Modifier.padding(top=8.dp))
            }
        }
        if(leader!=null){
            Card(Modifier.fillMaxWidth().padding(top=8.dp),colors=CardDefaults.cardColors(Panel2)){
                Column(Modifier.padding(11.dp)){
                    Text("TEMPO DO LÍDER",color=Red,fontWeight=FontWeight.Black,fontSize=10.sp)
                    Text(formatRaceTime(leaderTime),color=Color.White,fontWeight=FontWeight.Black,fontSize=19.sp)
                    Text("${leader.driverName} • P1",color=Muted,fontSize=10.sp)
                }
            }
        }
        LazyColumn(Modifier.weight(1f),contentPadding=PaddingValues(vertical=10.dp),verticalArrangement=Arrangement.spacedBy(3.dp)){
            items(r.classification){f->
                val resultTeam=WorldDatabase.teams.firstOrNull { it.name.equals(f.teamName, ignoreCase = true) }
                val finished=!f.status.startsWith("DNF")
                val gap=if(finished && leader!=null) raceGapMs(f.laps, f.totalTimeMs, leader.laps, leaderTime) else 0L
                Row(Modifier.fillMaxWidth().background(if(f.position<=3)Color(0xFF251414) else if(!finished) Color(0xFF2A1113) else Panel,RoundedCornerShape(5.dp)).padding(9.dp),verticalAlignment=Alignment.CenterVertically){
                    Text("P${f.position}",color=if(f.position<=3)Red else if(!finished)Red else Muted,fontWeight=FontWeight.Black,modifier=Modifier.width(38.dp))
                    TeamLogo(f.teamName,resultTeam?.id ?: 0,Modifier.size(24.dp))
                    Spacer(Modifier.width(5.dp))
                    Column(Modifier.weight(1f)){
                        Text(f.driverName,color=Color.White,fontWeight=if(!finished) FontWeight.Black else FontWeight.Normal,maxLines=1,overflow=TextOverflow.Ellipsis)
                        Text(if(!finished) "ABANDONOU • ${f.laps} voltas" else if(f.position==leader?.position) "LÍDER" else "GAP ${formatGap(gap)}",color=if(!finished) Red else Muted,fontSize=8.sp)
                    }
                    Column(horizontalAlignment=Alignment.End){
                        Text("${r.points[f.driverId]?:0} PTS",color=if((r.points[f.driverId]?:0)>0) Color.White else Muted,fontSize=9.sp,fontWeight=FontWeight.Bold)
                        if(!finished) Text("DNF",color=Red,fontSize=8.sp,fontWeight=FontWeight.Black)
                    }
                }
            }
        }
        Text("ABANDONOS: ${dnfs.size} • Safety Car ${r.safetyCarLaps} • VSC ${r.vscLaps} • Campeonato: ${store.constructorPoints()[teamId]?:0} PTS",color=Muted,fontSize=9.sp)
        Button(onClick=onCalendar,modifier=Modifier.fillMaxWidth().height(48.dp),colors=ButtonDefaults.buttonColors(containerColor=Red,contentColor=Color.White)){Text("IR PARA CALENDÁRIO",fontWeight=FontWeight.Black)}
    }
}

@Composable
private fun RaceImage(round:RoundDefinition, modifier:Modifier = Modifier) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var bitmap by remember(round.round) { mutableStateOf<android.graphics.Bitmap?>(null) }
    LaunchedEffect(round.round) {
        bitmap = withContext(Dispatchers.IO) { ExternalAssets.loadGrandPrixImage(context, round.grandPrix) }
    }
    if (bitmap != null) {
        Image(bitmap = bitmap!!.asImageBitmap(), contentDescription = round.grandPrix, modifier = modifier.clip(RoundedCornerShape(8.dp)), contentScale = androidx.compose.ui.layout.ContentScale.Fit)
    } else {
        Box(modifier.clip(RoundedCornerShape(8.dp)).background(Panel2).border(1.dp, Line, RoundedCornerShape(8.dp)), contentAlignment = Alignment.Center) {
            Text("IMAGEM DO GP", color = Muted, fontWeight = FontWeight.Black, fontSize = 9.sp)
        }
    }
}

@Composable
private fun DriverPhoto(driverId:Int, driverName:String, modifier:Modifier = Modifier) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var bitmap by remember(driverId, driverName) { mutableStateOf<android.graphics.Bitmap?>(null) }
    LaunchedEffect(driverId, driverName) {
        bitmap = withContext(Dispatchers.IO) { ExternalAssets.loadDriverPhoto(context, driverId, driverName) }
    }
    if (bitmap != null) {
        Image(bitmap = bitmap!!.asImageBitmap(), contentDescription = "Foto $driverName", modifier = modifier, contentScale = androidx.compose.ui.layout.ContentScale.Crop)
    } else {
        Box(modifier.background(Panel2, RoundedCornerShape(6.dp)).border(1.dp, Line, RoundedCornerShape(6.dp)), contentAlignment = Alignment.Center) {
            Text(driverName.split(" ").mapNotNull { it.firstOrNull() }.take(2).joinToString(""), color = Muted, fontWeight = FontWeight.Black, fontSize = 9.sp)
        }
    }
}

@Composable
private fun MovementBadge(movement:Int, hasPrevious:Boolean, modifier:Modifier = Modifier) {
    val label = when {
        !hasPrevious -> "•"
        movement > 0 -> "▲$movement"
        movement < 0 -> "▼${-movement}"
        else -> "—"
    }
    val color = when {
        !hasPrevious || movement == 0 -> Muted
        movement > 0 -> Green
        else -> Red
    }
    Text(label, color=color, fontWeight=FontWeight.Black, fontSize=9.sp, modifier=modifier)
}

@Composable
private fun TeamCarCompact(teamId: Int, teamName: String, modifier: Modifier = Modifier) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var bitmap by remember(teamId, teamName) { mutableStateOf<android.graphics.Bitmap?>(null) }
    LaunchedEffect(teamId, teamName) {
        bitmap = withContext(Dispatchers.IO) { ExternalAssets.loadTeamCarVisual(context, teamId, teamName) }
    }
    if (bitmap != null) Image(bitmap = bitmap!!.asImageBitmap(), contentDescription = "Carro $teamName", modifier = modifier, contentScale = androidx.compose.ui.layout.ContentScale.Fit)
    else Box(modifier)
}

@Composable
private fun TeamLogo(teamName:String, teamId:Int, modifier:Modifier = Modifier) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var bitmap by remember(teamId, teamName) { mutableStateOf<android.graphics.Bitmap?>(null) }
    LaunchedEffect(teamId, teamName) {
        bitmap = withContext(Dispatchers.IO) { ExternalAssets.loadTeamLogo(context, teamId, teamName) }
    }
    if (bitmap != null) {
        Image(bitmap = bitmap!!.asImageBitmap(), contentDescription = "Escudo $teamName", modifier = modifier, contentScale = androidx.compose.ui.layout.ContentScale.Fit)
    } else {
        Box(modifier.background(Panel2, RoundedCornerShape(6.dp)).border(1.dp, Line, RoundedCornerShape(6.dp)), contentAlignment = Alignment.Center) {
            Text("${teamName.take(2).uppercase()}", color = Muted, fontWeight = FontWeight.Black, fontSize = 8.sp)
        }
    }
}

private fun initialManagerState(teamId:Int,store:CareerPreferences):TeamManagerState {
    val t=WorldDatabase.teams.first{it.id==teamId}
    val base=TeamManagerState(season=store.season,round=store.roundIndex+1,playerTeamId=teamId,car=InitialTeamProfile.carState(t),garage=TeamGarageFactory.fromInitial(t),facilities=InitialTeamProfile.teamFacilities(t.initialLevel),finance=TeamFinanceState(InitialTeamProfile.initialBudget(WorldDatabase.teams.first { it.id == teamId })), technicalInvestment=store.loadTechnicalInvestment(teamId) ?: TechnicalInvestmentEngine.forTeam(store.season, teamId, teamId, InitialTeamProfile.carState(t)))
    val sponsors=store.loadSponsors(teamId)
    val market=store.loadDriverMarket() ?: DriverMarketEngine(20261003).initialState(store.season)
    store.saveDriverMarket(market)
    var finance=store.loadFinance(teamId,base.finance)
    // V155: salaries are charged per completed GP, not when the season opens.
    store.saveFacilities(teamId,base.facilities)
    store.saveTechnicalInvestment(teamId, base.technicalInvestment)
    return base.copy(finance=finance,sponsor=sponsors.firstOrNull { it.slot==1 } ?: store.loadSponsor(teamId,base.sponsor),sponsors=sponsors,driverMarket=market)
}
private fun componentLabel(c:CarComponent)=when(c){CarComponent.ENGINE->"Unidade de potência";CarComponent.CHASSIS->"Chassi";CarComponent.FRONT_WING->"Asa dianteira";CarComponent.REAR_WING->"Asa traseira";CarComponent.BRAKES->"Freios";CarComponent.ELECTRIC_POWER_UNIT->"Unidade de potência elétrica"}
private fun componentDuration(c:CarComponent)=when(c){CarComponent.ENGINE->4;CarComponent.CHASSIS->3;CarComponent.FRONT_WING->2;CarComponent.REAR_WING->2;CarComponent.BRAKES->2;CarComponent.ELECTRIC_POWER_UNIT->4}
@Composable private fun HistoryResult(round:Int,result:RaceResult?){
    if(result==null){Text("Nenhuma classificação salva para o Round $round",color=Muted,modifier=Modifier.padding(16.dp));return}
    val leader=result.classification.firstOrNull { !it.status.startsWith("DNF") }
    val leaderTime=leader?.totalTimeMs ?: 0L
    Column(Modifier.fillMaxSize().padding(12.dp)){
        HeaderBlock("ROUND $round","CLASSIFICAÇÃO SALVA")
        if(leader!=null){
            Card(Modifier.fillMaxWidth().padding(top=8.dp),colors=CardDefaults.cardColors(Panel2)){
                Column(Modifier.padding(10.dp)){
                    Text("TEMPO DO LÍDER",color=Red,fontWeight=FontWeight.Black,fontSize=10.sp)
                    Text(formatRaceTime(leaderTime),color=Color.White,fontWeight=FontWeight.Black,fontSize=18.sp)
                    Text("${leader.driverName} • P1",color=Muted,fontSize=9.sp)
                }
            }
        }
        LazyColumn(Modifier.weight(1f),contentPadding=PaddingValues(vertical=8.dp),verticalArrangement=Arrangement.spacedBy(3.dp)){
            items(result.classification){f->
                val historyTeam=WorldDatabase.teams.firstOrNull { it.name.equals(f.teamName, ignoreCase = true) }
                val finished=!f.status.startsWith("DNF")
                val gap=if(finished && leader!=null) raceGapMs(f.laps, f.totalTimeMs, leader.laps, leaderTime) else 0L
                Row(Modifier.fillMaxWidth().background(if(f.position<=3)Color(0xFF251414) else if(!finished) Color(0xFF2A1113) else Panel,RoundedCornerShape(5.dp)).padding(8.dp),verticalAlignment=Alignment.CenterVertically){
                    Text("P${f.position}",color=if(f.position<=3)Red else if(!finished)Red else Muted,fontWeight=FontWeight.Black,modifier=Modifier.width(38.dp))
                    TeamLogo(f.teamName,historyTeam?.id ?: 0,Modifier.size(22.dp))
                    Spacer(Modifier.width(5.dp))
                    Column(Modifier.weight(1f)){
                        Text(f.driverName,color=Color.White,maxLines=1,overflow=TextOverflow.Ellipsis)
                        Text(if(!finished) "ABANDONOU • ${f.laps} voltas" else if(f.position==leader?.position) "LÍDER" else "GAP ${formatGap(gap)}",color=if(!finished) Red else Muted,fontSize=8.sp)
                    }
                    Text("${result.points[f.driverId]?:0} PTS",color=Muted,fontSize=9.sp)
                }
            }
        }
        Text("ABANDONOS: ${result.classification.count { it.status.startsWith("DNF") }}",color=Muted,fontSize=9.sp)
    }
}

@Composable
private fun SeasonArchive(store: CareerPreferences) {
    val db = store.history
    val seasons = db.seasons()
    var scope by remember { mutableIntStateOf(0) }
    var selectedSeason by remember(seasons) { mutableIntStateOf(seasons.firstOrNull() ?: store.season) }
    LazyColumn(
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        item { HistorySection("📅 TEMPORADA", "Registro final somente após as 30 corridas") }
        item { HistoryScopeSelector(scope) { scope = it } }
        if (seasons.isEmpty()) {
            item { EmptyHistory("A temporada atual ainda está em andamento. O registro só será criado depois do GP 30.") }
        } else {
            item {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    seasons.forEach { season ->
                        Button(
                            onClick = { selectedSeason = season },
                            colors = ButtonDefaults.buttonColors(containerColor = if (selectedSeason == season) Red else Panel2, contentColor = Color.White),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 5.dp)
                        ) { Text(season.toString(), fontSize = 8.sp, fontWeight = FontWeight.Black) }
                    }
                }
            }
            if (scope == 0) {
                val rows = db.driverSeasonRecords(selectedSeason)
                item { HistorySection("PILOTOS • $selectedSeason", "80 pilotos • Ano / Posição / Piloto / Equipe / Pontos / Vitórias / Poles / Voltas + rápidas / DNF / GPs") }
                items(rows) { SeasonDriverRow(it) }
            } else {
                val rows = db.constructorSeasonRecords(selectedSeason)
                item { HistorySection("CONSTRUTORES • $selectedSeason", "40 equipes • Ano / Posição / Equipe / Pontos / Vitórias / Poles / Voltas + rápidas / DNF / GPs") }
                items(rows) { SeasonConstructorRow(it) }
            }
        }
    }
}

@Composable
private fun HistoryScreen(store: CareerPreferences) {
    val db = store.history
    var historyScope by remember { mutableIntStateOf(0) }
    var historyCategory by remember { mutableIntStateOf(0) }

    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        item { HistorySection("📖 HISTÓRIA", "Registro atualizado imediatamente após cada GP") }
        item { HistoryScopeSelector(historyScope) { historyScope = it } }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("🏆 VITÓRIAS", "🥇 POLES", "⚡ VOLTAS + RÁPIDAS", "👑 CAMPEÕES").chunked(2).forEach { row ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        row.forEach { label ->
                            val index = listOf("🏆 VITÓRIAS", "🥇 POLES", "⚡ VOLTAS + RÁPIDAS", "👑 CAMPEÕES").indexOf(label)
                            Button(onClick = { historyCategory = index }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = if (historyCategory == index) Red else Panel2, contentColor = Color.White), contentPadding = PaddingValues(vertical = 6.dp)) {
                                Text(label, fontSize = 8.sp, fontWeight = FontWeight.Black)
                            }
                        }
                    }
                }
            }
        }
        when (historyCategory) {
            0 -> {
                val rows = db.victories()
                item { HistorySection("🏆 VITÓRIAS • ${if (historyScope == 0) "PILOTOS" else "CONSTRUTORES"}", "1 vencedor por GP") }
                items(rows) { r -> HistoryHistoryRow(r, "VENCEDOR", formatRaceTime(r.totalTimeMs), showDriver = historyScope == 0) }
            }
            1 -> {
                val rows = db.poles()
                item { HistorySection("🥇 POLES • ${if (historyScope == 0) "PILOTOS" else "CONSTRUTORES"}", "1 pole por GP") }
                items(rows) { r ->
                    HistoryPanel {
                        HistoryEventHeader(r.season, r.round, r.grandPrix, r.teamId, r.teamName, r.driverName, showDriver = historyScope == 0, driverId = r.driverId)
                        Text("TEMPO • ${formatMs(r.timeMs)}", color = Color.White, fontWeight = FontWeight.Black, fontSize = 9.sp)
                    }
                }
            }
            2 -> {
                val rows = db.fastestLaps()
                item { HistorySection("⚡ VOLTAS + RÁPIDAS • ${if (historyScope == 0) "PILOTOS" else "CONSTRUTORES"}", "1 volta mais rápida por GP") }
                items(rows) { r -> HistoryHistoryRow(r, "VOLTA MAIS RÁPIDA", formatMs(r.fastestLapTimeMs), showDriver = historyScope == 0) }
            }
            3 -> {
                if (historyScope == 0) {
                    val rows = db.driverChampions()
                    item { HistorySection("👑 CAMPEÕES • PILOTOS", "1 campeão por temporada • disponível somente após o GP 30") }
                    items(rows) { c ->
                        HistoryPanel {
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Text("${c.season}", color = Red, fontWeight = FontWeight.Black, modifier = Modifier.width(46.dp))
                                TeamLogo(c.teamName, c.teamId, Modifier.size(30.dp))
                                Column(Modifier.weight(1f).padding(start = 7.dp, end = 6.dp)) {
                                    Text(c.driverName, color = Color.White, fontWeight = FontWeight.Black, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text(c.teamName, color = Muted, fontSize = 8.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                                DriverPhoto(c.driverId, c.driverName, Modifier.size(38.dp).clip(RoundedCornerShape(6.dp)))
                                Spacer(Modifier.width(7.dp))
                                Text("${c.points} PTS", color = Color.White, fontWeight = FontWeight.Black, fontSize = 9.sp)
                            }
                        }
                    }
                } else {
                    val rows = db.constructorChampions()
                    item { HistorySection("👑 CAMPEÕES • CONSTRUTORES", "1 campeão por temporada • disponível somente após o GP 30") }
                    items(rows) { c ->
                        HistoryPanel {
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Text("${c.season}", color = Red, fontWeight = FontWeight.Black, modifier = Modifier.width(46.dp))
                                TeamLogo(c.teamName, c.teamId, Modifier.size(34.dp))
                                Column(Modifier.weight(1f).padding(start = 7.dp)) { Text(c.teamName, color = Color.White, fontWeight = FontWeight.Black) }
                                Text("${c.points} PTS", color = Color.White, fontWeight = FontWeight.Black, fontSize = 9.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun HallOfFameScreen(store: CareerPreferences) {
    val db = store.history
    var hallScope by remember { mutableIntStateOf(0) }
    var hallMetric by remember { mutableIntStateOf(0) }
    val metricLabels = if (hallScope == 0) listOf("👑 CAMPEÕES", "🏆 VITÓRIAS", "🥇 POLES", "⚡ VOLTAS + RÁPIDAS", "📊 PONTOS", "🏁 GPs")
    else listOf("👑 CAMPEÕES", "🏆 VITÓRIAS", "🥇 POLES", "⚡ VOLTAS + RÁPIDAS", "📊 PONTOS")
    val metric = when (hallMetric) { 0 -> HistoricalDatabase.HallMetric.CHAMPIONS; 1 -> HistoricalDatabase.HallMetric.WINS; 2 -> HistoricalDatabase.HallMetric.POLES; 3 -> HistoricalDatabase.HallMetric.FASTEST_LAPS; 4 -> HistoricalDatabase.HallMetric.POINTS; else -> HistoricalDatabase.HallMetric.GPS }
    val scope = if (hallScope == 0) HistoricalDatabase.HallScope.DRIVERS else HistoricalDatabase.HallScope.CONSTRUCTORS
    val rows = db.hallRanking(scope, metric).filter { it.value > 0 }
    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        item { HistorySection("🏛️ HALL DA FAMA", "Ranking histórico • atualizado sempre que uma nova informação entra no histórico") }
        item { HistoryScopeSelector(hallScope) { hallScope = it; hallMetric = 0 } }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                metricLabels.chunked(2).forEach { row ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        row.forEach { label ->
                            val index = metricLabels.indexOf(label)
                            Button(onClick = { hallMetric = index }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = if (hallMetric == index) Red else Panel2, contentColor = Color.White), contentPadding = PaddingValues(vertical = 6.dp)) { Text(label, fontSize = 8.sp, fontWeight = FontWeight.Black) }
                        }
                        if (row.size == 1) Spacer(Modifier.weight(1f))
                    }
                }
            }
        }
        item { HistorySection("RANKING", "Maior para menor • ↑ subiu • ↓ desceu • → manteve • NOVO") }
        if (rows.isEmpty()) item { EmptyHistory("Ainda não há registros suficientes para este ranking.") }
        else items(rows) { h -> HallRow(h, hallScope == 0) }
    }
}

@Composable
private fun RecordsScreen(store: CareerPreferences) {
    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        item { HistorySection("🏅 RECORDES", "Área exclusiva para os recordes históricos do jogo") }
        item { EmptyHistory("Os recordes serão definidos em uma próxima etapa. Nenhum recorde foi criado automaticamente.") }
    }
}

@Composable
private fun HistoryScopeSelector(selected: Int, onSelect: (Int) -> Unit) {
    Row(
        Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(9.dp)).padding(3.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        listOf("PILOTOS", "CONSTRUTORES").forEachIndexed { index, label ->
            Button(
                onClick = { onSelect(index) },
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = if (selected == index) Red else Panel2, contentColor = Color.White),
                contentPadding = PaddingValues(vertical = 6.dp)
            ) { Text(label, fontSize = 9.sp, fontWeight = FontWeight.Black) }
        }
    }
}

@Composable
private fun SeasonDriverRow(r: HistoricalDatabase.DriverSeasonRecord) {
    HistoryPanel {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("P${r.position}", color = if (r.position <= 3) Red else Muted, fontWeight = FontWeight.Black, modifier = Modifier.width(34.dp))
            TeamLogo(r.teamName, r.teamId, Modifier.size(30.dp))
            Column(Modifier.weight(1f).padding(start = 7.dp, end = 6.dp)) {
                Text(r.driverName, color = Color.White, fontWeight = FontWeight.Black, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(r.teamName, color = Muted, fontSize = 8.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("V ${r.wins} • P ${r.poles} • ⚡ ${r.fastestLaps} • DNF ${r.dnf} • GPs ${r.gps}", color = Muted, fontSize = 7.sp)
            }
            DriverPhoto(r.driverId, r.driverName, Modifier.size(38.dp).clip(RoundedCornerShape(6.dp)))
            Spacer(Modifier.width(7.dp))
            Text("${r.points} PTS", color = Color.White, fontWeight = FontWeight.Black, fontSize = 9.sp)
        }
    }
}

@Composable
private fun SeasonConstructorRow(r: HistoricalDatabase.ConstructorSeasonRecord) {
    HistoryPanel {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("P${r.position}", color = if (r.position <= 3) Red else Muted, fontWeight = FontWeight.Black, modifier = Modifier.width(34.dp))
            TeamLogo(r.teamName, r.teamId, Modifier.size(30.dp))
            Column(Modifier.weight(1f).padding(start = 7.dp)) {
                Text(r.teamName, color = Color.White, fontWeight = FontWeight.Black, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("V ${r.wins} • P ${r.poles} • ⚡ ${r.fastestLaps} • DNF ${r.dnf} • GPs ${r.gps}", color = Muted, fontSize = 7.sp)
            }
            Text("${r.points} PTS", color = Color.White, fontWeight = FontWeight.Black, fontSize = 9.sp)
        }
    }
}

@Composable
private fun HistoryEventHeader(season: Int, round: Int, grandPrix: String, teamId: Int, teamName: String, driverName: String, showDriver: Boolean = true, driverId: Int = 0) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text("$season • R$round", color = Red, fontWeight = FontWeight.Black, fontSize = 9.sp, modifier = Modifier.width(72.dp))
        TeamLogo(teamName, teamId, Modifier.size(30.dp))
        Column(Modifier.weight(1f).padding(start = 7.dp, end = 6.dp)) {
            Text(if (showDriver) driverName else teamName, color = Color.White, fontWeight = FontWeight.Black, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(if (showDriver) "$grandPrix • $teamName" else "$grandPrix • $driverName", color = Muted, fontSize = 8.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        if (showDriver) DriverPhoto(driverId, driverName, Modifier.size(38.dp).clip(RoundedCornerShape(6.dp)))
    }
}

@Composable
private fun HistoryHistoryRow(r: HistoricalDatabase.RaceRecord, label: String, time: String, showDriver: Boolean = true) {
    HistoryPanel {
        HistoryEventHeader(r.season, r.round, r.grandPrix, r.teamId, r.teamName, r.driverName, showDriver, r.driverId)
        Row(Modifier.fillMaxWidth().padding(top = 7.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, color = Muted, fontSize = 8.sp, fontWeight = FontWeight.Black)
            Text("TEMPO • $time", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Black)
        }
    }
}

@Composable
private fun HallRow(h: HistoricalDatabase.HallEntry, showDriverPhoto: Boolean) {
    HistoryPanel {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("#${h.position}", color = if (h.position <= 3) Red else Muted, fontWeight = FontWeight.Black, modifier = Modifier.width(36.dp))
            if (h.teamId > 0) TeamLogo(h.teamName, h.teamId, Modifier.size(30.dp))
            Column(Modifier.weight(1f).padding(start = 7.dp, end = 6.dp)) {
                Text(h.name, color = Color.White, fontWeight = FontWeight.Black, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (h.teamName.isNotBlank()) Text(h.teamName, color = Muted, fontSize = 7.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            if (showDriverPhoto) {
                DriverPhoto(h.id, h.name, Modifier.size(38.dp).clip(RoundedCornerShape(6.dp)))
                Spacer(Modifier.width(7.dp))
            }
            Column(horizontalAlignment = Alignment.End) {
                Text("${h.value}", color = Color.White, fontWeight = FontWeight.Black, fontSize = 12.sp)
                Text(
                    when {
                        h.movement == Int.MIN_VALUE -> "NOVO"
                        h.movement > 0 -> "↑${h.movement}"
                        h.movement < 0 -> "↓${-h.movement}"
                        else -> "→"
                    },
                    color = when {
                        h.movement > 0 -> Green
                        h.movement < 0 -> Red
                        else -> Muted
                    },
                    fontSize = 8.sp,
                    fontWeight = FontWeight.Black
                )
            }
        }
    }
}

@Composable
private fun HistorySection(title: String, subtitle: String) {
    Column(Modifier.padding(top = 2.dp, bottom = 2.dp)) {
        Text(title, color = Color.White, fontWeight = FontWeight.Black, fontSize = 14.sp)
        Text(subtitle, color = Muted, fontSize = 9.sp, modifier = Modifier.padding(top = 2.dp))
    }
}

@Composable
private fun HistoryPanel(content: @Composable ColumnScope.() -> Unit) {
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(Panel)) { Column(Modifier.padding(7.dp), content = content) }
}

@Composable
private fun HistoryRaceRow(r: HistoricalDatabase.RaceRecord, showPosition: Boolean, emphasizeTime: Boolean = false) {
    val finished = !r.status.startsWith("DNF")
    HistoryPanel {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            if (showPosition) Text("P${r.position}", color = if (r.position <= 3) Red else Muted, fontWeight = FontWeight.Black, modifier = Modifier.width(34.dp))
            else Text("R${r.round}", color = Red, fontWeight = FontWeight.Black, modifier = Modifier.width(34.dp))
            TeamLogo(r.teamName, r.teamId, Modifier.size(26.dp))
            Column(Modifier.weight(1f).padding(start = 7.dp)) {
                Text(r.driverName, color = Color.White, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("${r.grandPrix} • ${r.teamName} • ${r.season}", color = Muted, fontSize = 8.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(if (!finished) "ABANDONOU • ${r.laps} voltas" else if (r.position == 1) "VENCEDOR" else "GAP ${formatGap(r.gapToLeaderMs)}", color = if (!finished) Red else Muted, fontSize = 8.sp)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text("${r.points} PTS", color = Color.White, fontWeight = FontWeight.Black, fontSize = 9.sp)
                Text(formatRaceTime(r.totalTimeMs), color = if (emphasizeTime) Red else Muted, fontWeight = FontWeight.Bold, fontSize = 8.sp)
            }
        }
    }
}

@Composable
private fun EmptyHistory(message: String) {
    HistoryPanel { Text(message, color = Muted, fontSize = 10.sp) }
}

@Composable
private fun TeamSelect(onSelect: (Int) -> Unit) {
    // V101/V102 — tela inicial de seleção de equipe alinhada ao layout aprovado; atributos do carro exibidos como inteiros.
    // A fonte de dados continua sendo o perfil físico inicial: nunca usar
    // InitialTeamProfile como fonte oficial do carro de largada.
    fun levelLabel(level: Int) = when (level) {
        InitialTeamProfile.FORTE -> "FORTE"
        InitialTeamProfile.MEDIO -> "MÉDIO"
        else -> "FRACO"
    }

    fun levelColor(level: Int) = when (level) {
        InitialTeamProfile.FORTE -> Red
        InitialTeamProfile.MEDIO -> Color(0xFF1976D2)
        else -> Color(0xFF6B7280)
    }

    val teams = WorldDatabase.teams
    val strongCount = teams.count { it.initialLevel == InitialTeamProfile.FORTE }
    val mediumCount = teams.count { it.initialLevel == InitialTeamProfile.MEDIO }
    val weakCount = teams.count { it.initialLevel == InitialTeamProfile.FRACO }

    var filter by remember { mutableIntStateOf(-1) } // -1 todas, 2 forte, 1 médio, 0 fraco
    var sortExpanded by remember { mutableStateOf(false) }
    var sortMode by remember { mutableStateOf("Desempenho") }

    val visibleTeams = remember(teams, filter, sortMode) {
        val filtered = teams.filter { filter == -1 || it.initialLevel == filter }
        when (sortMode) {
            "Nome" -> filtered.sortedBy { it.name.lowercase() }
            "Nível" -> filtered.sortedWith(compareByDescending<com.f1teammanager.core.season.TeamDefinition> { it.initialLevel }.thenBy { it.name })
            else -> filtered.sortedWith(
                // A seleção usa o mesmo carro inicial que alimenta o ranking ao abrir a carreira.
                compareByDescending<com.f1teammanager.core.season.TeamDefinition> { TeamGarageFactory.fromInitial(it).teamAverageOverall }
                    .thenBy { it.id }
            )
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .background(Bg)
            .padding(horizontal = 16.dp)
    ) {
        Row(
            Modifier.fillMaxWidth().padding(top = 10.dp, bottom = 2.dp),
            verticalAlignment = Alignment.Top
        ) {
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("F1", color = Red, fontSize = 28.sp, fontWeight = FontWeight.Black)
                    Spacer(Modifier.width(5.dp))
                    Text("MANAGER", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Black)
                }
                Text("ESCOLHA SUA EQUIPE", color = Red, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 2.dp))
                Text("40 equipes  •  80 pilotos", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 7.dp))
            }

            Box {
                OutlinedButton(
                    onClick = { sortExpanded = true },
                    modifier = Modifier.width(112.dp).height(58.dp),
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, Line),
                    contentPadding = PaddingValues(horizontal = 9.dp, vertical = 5.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)
                ) {
                    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.Start) {
                        Text("Ordenar por:", color = Muted, fontSize = 8.sp, maxLines = 1)
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Text(sortMode, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), maxLines = 1)
                            Text("⌄", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Black)
                        }
                    }
                }
                DropdownMenu(expanded = sortExpanded, onDismissRequest = { sortExpanded = false }) {
                    listOf("Desempenho", "Nome", "Nível").forEach { option ->
                        DropdownMenuItem(
                            text = { Text(option, color = Color.White, fontSize = 12.sp) },
                            onClick = { sortMode = option; sortExpanded = false }
                        )
                    }
                }
            }
        }

        Row(
            Modifier.fillMaxWidth().padding(top = 12.dp, bottom = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            data class FilterChip(val id: Int, val label: String, val count: Int)
            val chips = listOf(
                FilterChip(-1, "TODAS", teams.size),
                FilterChip(InitialTeamProfile.FORTE, "FORTES", strongCount),
                FilterChip(InitialTeamProfile.MEDIO, "MÉDIAS", mediumCount),
                FilterChip(InitialTeamProfile.FRACO, "FRACAS", weakCount)
            )
            chips.forEach { chip ->
                Surface(
                    modifier = Modifier.weight(1f).height(34.dp).clickable { filter = chip.id },
                    shape = RoundedCornerShape(18.dp),
                    color = if (filter == chip.id) Red else Panel2,
                    border = if (filter == chip.id) null else BorderStroke(1.dp, Line)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text(
                            "${chip.label} (${chip.count})",
                            color = Color.White,
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Black,
                            maxLines = 1
                        )
                    }
                }
            }
        }

        LazyColumn(
            modifier = Modifier.fillMaxWidth().weight(1f),
            verticalArrangement = Arrangement.spacedBy(7.dp),
            contentPadding = PaddingValues(top = 1.dp, bottom = 14.dp)
        ) {
            items(visibleTeams, key = { it.id }) { t ->
                val initial = InitialTeamProfile.values(t)
                val initialGarage = InitialTeamProfile.carState(t)
                val physicalReliability = initialGarage.reliability.coerceIn(1, 100)
                val tierColor = levelColor(t.initialLevel)

                Card(
                    modifier = Modifier.fillMaxWidth().height(124.dp).clickable { onSelect(t.id) },
                    shape = RoundedCornerShape(15.dp),
                    colors = CardDefaults.cardColors(containerColor = Panel),
                    border = BorderStroke(1.dp, Color(0xFF191C22))
                ) {
                    Row(
                        Modifier.fillMaxSize().padding(horizontal = 10.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Box(Modifier.width(82.dp).fillMaxHeight(), contentAlignment = Alignment.Center) {
                            TeamLogo(t.name, t.id, Modifier.size(64.dp))
                        }
                        Spacer(Modifier.width(6.dp))
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.Center) {
                            Text(t.name, color = Color.White, fontWeight = FontWeight.Black, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Surface(
                                color = tierColor,
                                shape = RoundedCornerShape(7.dp),
                                modifier = Modifier.padding(top = 3.dp, bottom = 5.dp)
                            ) {
                                Text(levelLabel(t.initialLevel), color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(horizontal = 9.dp, vertical = 3.dp))
                            }
                            val teamDrivers = t.driverIds.mapNotNull { id -> WorldDatabase.drivers.firstOrNull { it.id == id } }
                            val driver1 = teamDrivers.getOrNull(0)
                            val driver2 = teamDrivers.getOrNull(1)
                            Row(
                                Modifier.fillMaxWidth().height(34.dp).padding(top = 2.dp),
                                horizontalArrangement = Arrangement.spacedBy(4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // Reserva apenas o espaço necessário para Overall/Confiabilidade e entrega
                                // o restante da linha aos nomes dos dois pilotos.
                                InitialMetric("Overall", TeamGarageFactory.fromInitial(t).teamAverageOverall.toString(), Modifier.width(34.dp))
                                InitialMetric("Conf.", physicalReliability.toString(), Modifier.width(30.dp))
                                InitialMetric("PILOTO 1", driver1?.let { "${driverOverall(it)} ${it.name.split(" ").lastOrNull().orEmpty()}" } ?: "—", Modifier.weight(1f))
                                InitialMetric("PILOTO 2", driver2?.let { "${driverOverall(it)} ${it.name.split(" ").lastOrNull().orEmpty()}" } ?: "—", Modifier.weight(1f))
                            }
                        }
                        Spacer(Modifier.width(8.dp))
                        Button(
                            onClick = { onSelect(t.id) },
                            modifier = Modifier.width(82.dp).height(42.dp).padding(top = 2.dp),
                            shape = RoundedCornerShape(11.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Red, contentColor = Color.White),
                            contentPadding = PaddingValues(horizontal = 4.dp)
                        ) {
                            Text("ESCOLHER", fontSize = 9.sp, fontWeight = FontWeight.Black, maxLines = 1)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun InitialMetric(label: String, value: String, modifier: Modifier = Modifier) {
    Column(
        modifier.height(32.dp),
        verticalArrangement = Arrangement.spacedBy(2.dp),
        horizontalAlignment = Alignment.Start
    ) {
        Text(
            label,
            color = Muted,
            fontSize = 6.sp,
            lineHeight = 7.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Text(
            value,
            color = Color.White,
            fontSize = 7.sp,
            lineHeight = 9.sp,
            fontWeight = FontWeight.Black,
            maxLines = 1,
            softWrap = false,
            overflow = TextOverflow.Clip
        )
    }
}

@Composable
private fun Standings(teamId: Int, store: CareerPreferences) {
    var tab by remember { mutableIntStateOf(0) }
    val driverPoints=store.driverPoints()
    val constructorPoints=store.constructorPoints()
    val market = store.loadDriverMarket()
    val drivers = (market?.contracts?.filter { it.activeIn(store.season) }?.mapNotNull { deal ->
        val d=WorldDatabase.allDrivers.firstOrNull { it.id==deal.driverId } ?: return@mapNotNull null
        val t=WorldDatabase.teams.firstOrNull { it.id==deal.teamId } ?: return@mapNotNull null
        Triple(d,t,driverPoints[d.id]?:0)
    } ?: WorldDatabase.drivers.map { d -> val t=WorldDatabase.teams.first{it.id==d.teamId}; Triple(d,t,driverPoints[d.id]?:0) }).sortedByDescending{it.third}
    val constructors=WorldDatabase.teams.map{t->t to (constructorPoints[t.id]?:0)}.sortedWith(compareByDescending<Pair<com.f1teammanager.core.season.TeamDefinition,Int>>{it.second}.thenBy{it.first.id})
    val previousDrivers = store.previousDriverPositions()
    val previousConstructors = store.previousConstructorPositions()
    val hasPrevious = previousDrivers.isNotEmpty() || previousConstructors.isNotEmpty()
    Column(Modifier.fillMaxSize().padding(12.dp)){
        HeaderBlock("CAMPEONATO","PILOTOS E CONSTRUTORES")
        Row(Modifier.fillMaxWidth().background(Panel,RoundedCornerShape(8.dp)).padding(4.dp),horizontalArrangement=Arrangement.spacedBy(4.dp)){
            listOf("PILOTOS","CONSTRUTORES").forEachIndexed{index,label->Button(onClick={tab=index},modifier=Modifier.weight(1f),colors=ButtonDefaults.buttonColors(containerColor=if(tab==index)Red else Panel2,contentColor=Color.White),contentPadding=PaddingValues(vertical=8.dp)){Text(label,fontWeight=FontWeight.Black,fontSize=10.sp)}}
        }
        if(tab==0){
            LazyColumn(Modifier.weight(1f),contentPadding=PaddingValues(vertical=8.dp),verticalArrangement=Arrangement.spacedBy(3.dp)){
                items(drivers){(d,t,pts)->
                    val position = drivers.indexOfFirst{it.first.id==d.id}+1
                    val previous = previousDrivers[d.id]
                    val movement = if(hasPrevious && previous != null) previous-position else 0
                    val abovePoints = if(position > 1) drivers[position-2].third else null
                    val gap = abovePoints?.let { it - pts }
                    Row(Modifier.fillMaxWidth().background(if(t.id==teamId)Color(0xFF251414)else Panel,RoundedCornerShape(5.dp)).padding(horizontal=8.dp,vertical=7.dp),verticalAlignment=Alignment.CenterVertically){
                        Text("P$position",color=if(t.id==teamId)Red else Muted,fontWeight=FontWeight.Black,modifier=Modifier.width(36.dp))
                        MovementBadge(movement,hasPrevious,Modifier.width(30.dp))
                        DriverPhoto(d.id,d.name,Modifier.size(36.dp).clip(RoundedCornerShape(6.dp)))
                        Spacer(Modifier.width(8.dp))
                        Text(d.name,color=Color.White,modifier=Modifier.weight(1f),maxLines=1,overflow=TextOverflow.Ellipsis)
                        TeamLogo(t.name,t.id,Modifier.size(24.dp))
                        Spacer(Modifier.width(7.dp))
                        Column(horizontalAlignment=Alignment.End){
                            Text("$pts PTS",color=Color.White,fontWeight=FontWeight.Black,fontSize=10.sp)
                            if(gap != null) Text("~ $gap",color=Muted,fontSize=8.sp)
                        }
                    }
                }
            }
        }else{
            LazyColumn(Modifier.weight(1f),contentPadding=PaddingValues(vertical=8.dp),verticalArrangement=Arrangement.spacedBy(3.dp)){
                items(constructors){(t,pts)->
                    val position = constructors.indexOfFirst{it.first.id==t.id}+1
                    val previous = previousConstructors[t.id]
                    val movement = if(hasPrevious && previous != null) previous-position else 0
                    val abovePoints = if(position > 1) constructors[position-2].second else null
                    val gap = abovePoints?.let { it - pts }
                    Row(Modifier.fillMaxWidth().background(if(t.id==teamId)Color(0xFF251414)else Panel,RoundedCornerShape(5.dp)).padding(horizontal=8.dp,vertical=8.dp),verticalAlignment=Alignment.CenterVertically){
                        Text("P$position",color=if(t.id==teamId)Red else Muted,fontWeight=FontWeight.Black,modifier=Modifier.width(36.dp))
                        MovementBadge(movement,hasPrevious,Modifier.width(30.dp))
                        TeamLogo(t.name,t.id,Modifier.size(28.dp))
                        Spacer(Modifier.width(7.dp))
                        Text(t.name,color=Color.White,modifier=Modifier.weight(1f),fontWeight=if(t.id==teamId)FontWeight.Black else FontWeight.Normal,maxLines=1,overflow=TextOverflow.Ellipsis)
                        Column(horizontalAlignment=Alignment.End){
                            Text("$pts PTS",color=Color.White,fontWeight=FontWeight.Black,fontSize=11.sp)
                            if(gap != null) Text("~ $gap",color=Muted,fontSize=8.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun Finance(store: CareerPreferences, teamId: Int, state:TeamManagerState, message:String, signSponsor:(SponsorContract)->Unit) {
    // Mercado vivo: cada slot vazio recebe uma nova rodada de 3 propostas.
    // A semente muda quando o estado do mercado muda, evitando ofertas fixas.
    val marketKey = remember(teamId, store.season, state.round, state.facilities.level(FacilityType.MARKETING), state.sponsors.map { "${it.slot}:${it.name}:${it.racesRemaining}" }.sorted().joinToString("|")) {
        kotlin.random.Random.nextLong()
    }
    val sponsorshipEngine = remember(marketKey) { com.f1teammanager.core.manager.TeamSponsorshipEngine(marketKey.toInt()) }
    val offers = remember(teamId, store.season, state.round, state.facilities.level(FacilityType.MARKETING), state.sponsors.map { "${it.slot}:${it.name}:${it.racesRemaining}" }.sorted().joinToString("|"), marketKey) {
        (1..5).map { slot ->
            if (state.sponsors.none { it.slot == slot && it.active && it.racesRemaining > 0 }) {
                sponsorshipEngine.offersForSlot(teamId, store.season, slot, state.facilities.level(FacilityType.MARKETING), state.round)
            } else emptyList()
        }
    }
    val marketingLevel = state.facilities.level(FacilityType.MARKETING)
    val activeCount = state.sponsors.count { it.active && it.racesRemaining > 0 }

    LazyColumn(
        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            HeaderBlock("FINANÇAS", "ORÇAMENTO, RECEITAS E PATROCÍNIOS")
            Text("Centro Comercial nível $marketingLevel • categorias definidas pela instalação", color=Muted, fontSize=8.sp)
        }
        item {
            Card(Modifier.fillMaxWidth(), colors=CardDefaults.cardColors(containerColor=Panel)) {
                Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment=Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("SALDO", color=Red, fontWeight=FontWeight.Black, fontSize=13.sp)
                        Text(formatMoney(state.finance.budget), color=Color.White, fontSize=25.sp, fontWeight=FontWeight.Black, maxLines=1)
                        Text("Receitas da temporada: ${formatMoney(state.finance.seasonIncome)}", color=Green, fontSize=8.sp)
                        Text("Despesas da temporada: ${formatMoney(state.finance.seasonExpenses)}", color=Muted, fontSize=8.sp)
                    }
                    Box(Modifier.width(1.dp).height(72.dp).background(Line))
                    Column(Modifier.width(118.dp).padding(start=12.dp), horizontalAlignment=Alignment.CenterHorizontally) {
                        SponsorUiIcon("bank", 30.dp, Red)
                        Text("Patrocínios ativos", color=Muted, fontSize=8.sp, textAlign=TextAlign.Center)
                        Text("$activeCount / 5", color=Color.White, fontSize=16.sp, fontWeight=FontWeight.Black)
                    }
                }
            }
        }
        if(message.isNotBlank()) item { Text(message, color=Green, fontWeight=FontWeight.Bold, fontSize=9.sp) }
        item { SectionTitle("5 ESPAÇOS DE PATROCÍNIO") }

        items(5) { slot ->
            val signed = state.sponsors.firstOrNull { it.slot == slot + 1 && it.active && it.racesRemaining > 0 }
            val slotOffers = offers[slot]
            Card(
                Modifier.fillMaxWidth(),
                colors=CardDefaults.cardColors(containerColor=Panel),
                shape=RoundedCornerShape(10.dp)
            ) {
                Column(Modifier.fillMaxWidth()) {
                    Box(
                        Modifier.fillMaxWidth().background(if (slot == 0) Color(0xFF331114) else Color(0xFF20242B)).padding(horizontal=12.dp, vertical=9.dp)
                    ) {
                        Text(
                            if (slot == 0) "SLOT 1  •  MASTER / PRINCIPAL" else "SLOT ${slot+1}  •  PATROCINADOR SECUNDÁRIO",
                            color=if (slot == 0) Red else Color.White,
                            fontWeight=FontWeight.Black,
                            fontSize=11.sp
                        )
                    }
                    if (signed != null) {
                        SponsorContractCard(signed, onAccept=null)
                    } else if (slotOffers.isNotEmpty()) {
                        Row(
                            Modifier.fillMaxWidth().padding(8.dp),
                            horizontalArrangement=Arrangement.spacedBy(7.dp)
                        ) {
                            slotOffers.take(3).forEach { offer ->
                                SponsorOfferCard(offer, Modifier.weight(1f), onAccept={ signSponsor(offer.sponsor) })
                            }
                        }
                    } else {
                        Box(Modifier.fillMaxWidth().padding(10.dp).height(58.dp).border(1.dp, Line, RoundedCornerShape(7.dp)), contentAlignment=Alignment.Center) {
                            Row(verticalAlignment=Alignment.CenterVertically) {
                                SponsorUiIcon("plus", 22.dp, Muted)
                                Spacer(Modifier.width(8.dp))
                                Text("Aguardando proposta...", color=Muted, fontSize=10.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SponsorOfferCard(offer: TeamSponsorshipEngine.SponsorOffer, modifier: Modifier = Modifier, onAccept: () -> Unit) {
    val sponsor = offer.sponsor
    val accent = when (offer.category) {
        com.f1teammanager.core.manager.SponsorCategory.BASICO -> Color(0xFF68707A)
        com.f1teammanager.core.manager.SponsorCategory.REGIONAL -> Color(0xFF2377E8)
        com.f1teammanager.core.manager.SponsorCategory.NACIONAL -> Color(0xFF2E9D65)
        com.f1teammanager.core.manager.SponsorCategory.INTERNACIONAL -> Color(0xFF8A5BEA)
        com.f1teammanager.core.manager.SponsorCategory.PREMIUM -> Color(0xFFD39A2E)
        com.f1teammanager.core.manager.SponsorCategory.GLOBAL -> Color(0xFFE10600)
    }
    Column(
        modifier.background(Panel2, RoundedCornerShape(8.dp)).border(1.dp, Line, RoundedCornerShape(8.dp)).padding(7.dp)
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween, verticalAlignment=Alignment.Top) {
            SponsorUiIcon(sponsorIconFor(sponsor.name), 28.dp, Red)
            Text(offer.category.name, color=Color.White, fontSize=7.sp, fontWeight=FontWeight.Black, modifier=Modifier.background(accent.copy(alpha=.8f), RoundedCornerShape(7.dp)).padding(horizontal=5.dp, vertical=2.dp), maxLines=1)
        }
        Text(sponsor.name, color=Color.White, fontSize=10.sp, fontWeight=FontWeight.Black, maxLines=2, minLines=2, overflow=TextOverflow.Ellipsis, modifier=Modifier.padding(top=5.dp))
        Spacer(Modifier.height(3.dp))
        SponsorDetailLine("entry", if(sponsor.upfront>0) "Entrada: ${formatMoney(sponsor.upfront)}" else "Sem entrada")
        SponsorDetailLine("coins", if(sponsor.racePayment>0) "${formatMoney(sponsor.racePayment)} / GP" else "Sem pagamento / GP")
        SponsorDetailLine("target", "Meta qual.: P${sponsor.qualifyingTargetMin}–P${sponsor.qualifyingTargetMax} • ${formatMoney(sponsor.qualifyingBonus)}")
        SponsorDetailLine("trophy", "Meta corrida: P${sponsor.raceTargetMin}–P${sponsor.raceTargetMax} • ${formatMoney(sponsor.raceTargetBonus)}")
        SponsorDetailLine("calendar", "${sponsor.races} corridas")
        Button(
            onClick=onAccept,
            modifier=Modifier.fillMaxWidth().padding(top=6.dp).height(31.dp),
            shape=RoundedCornerShape(16.dp),
            contentPadding=PaddingValues(horizontal=2.dp, vertical=0.dp),
            colors=ButtonDefaults.buttonColors(containerColor=Red, contentColor=Color.White)
        ) { Text("ACEITAR\n${sponsor.name}", fontWeight=FontWeight.Black, fontSize=7.sp, lineHeight=8.sp, textAlign=TextAlign.Center, maxLines=2, overflow=TextOverflow.Ellipsis) }
    }
}

@Composable
private fun SponsorContractCard(sponsor:SponsorContract, onAccept:(()->Unit)?) {
    Column(Modifier.fillMaxWidth().padding(10.dp)) {
        Text("ATIVO  •  ${sponsor.name}", color=Green, fontWeight=FontWeight.Black, fontSize=11.sp)
        Text("${sponsor.category} • ${if(sponsor.upfront>0) "Entrada ${formatMoney(sponsor.upfront)}" else "Sem entrada"} • ${if(sponsor.racePayment>0) "${formatMoney(sponsor.racePayment)}/GP" else "Sem pagamento/GP"}", color=Muted, fontSize=8.sp)
        Text("Meta quali P${sponsor.qualifyingTargetMin}–P${sponsor.qualifyingTargetMax} • Meta corrida P${sponsor.raceTargetMin}–P${sponsor.raceTargetMax} • ${sponsor.racesRemaining}/${sponsor.races} corridas", color=Muted, fontSize=8.sp, modifier=Modifier.padding(top=3.dp))
    }
}

@Composable
private fun SponsorDetailLine(icon:String, text:String) {
    Row(Modifier.fillMaxWidth().padding(top=3.dp), verticalAlignment=Alignment.CenterVertically) {
        SponsorUiIcon(icon, 13.dp, Red)
        Spacer(Modifier.width(4.dp))
        Text(text, color=Color.LightGray, fontSize=6.5.sp, lineHeight=8.sp, maxLines=2, overflow=TextOverflow.Ellipsis)
    }
}

private fun sponsorIconFor(name:String):String = when {
    name.contains("Air", true) || name.contains("Emirates", true) || name.contains("Qatar", true) -> "plane"
    name.contains("DHL", true) || name.contains("UPS", true) || name.contains("FedEx", true) -> "truck"
    name.contains("Michelin", true) || name.contains("Pirelli", true) || name.contains("Goodyear", true) -> "tire"
    name.contains("Red Bull", true) || name.contains("Monster", true) -> "bolt"
    name.contains("Garmin", true) || name.contains("Apple", true) || name.contains("Google", true) -> "signal"
    name.contains("Bank", true) || name.contains("Santander", true) || name.contains("HSBC", true) -> "bank"
    name.contains("Bosch", true) || name.contains("SKF", true) || name.contains("Mahle", true) || name.contains("Schaeffler", true) -> "gear"
    name.contains("Oracle", true) || name.contains("SAP", true) || name.contains("IBM", true) -> "chip"
    else -> "sponsor"
}

@Composable
private fun SponsorUiIcon(type:String, size:androidx.compose.ui.unit.Dp, color:Color) {
    Canvas(Modifier.size(size)) {
        val w=size.toPx(); val c=color
        val stroke=androidx.compose.ui.graphics.drawscope.Stroke(width=(w*.10f).coerceAtLeast(1.5f))
        when(type) {
            "plus" -> { drawCircle(c, w*.32f, style=stroke); drawLine(c, androidx.compose.ui.geometry.Offset(w*.18f,w*.32f), androidx.compose.ui.geometry.Offset(w*.46f,w*.32f), stroke.width); drawLine(c, androidx.compose.ui.geometry.Offset(w*.32f,w*.18f), androidx.compose.ui.geometry.Offset(w*.32f,w*.46f), stroke.width) }
            "plane" -> { drawLine(c, androidx.compose.ui.geometry.Offset(w*.10f,w*.55f), androidx.compose.ui.geometry.Offset(w*.88f,w*.20f), stroke.width); drawLine(c, androidx.compose.ui.geometry.Offset(w*.48f,w*.38f), androidx.compose.ui.geometry.Offset(w*.42f,w*.05f), stroke.width); drawLine(c, androidx.compose.ui.geometry.Offset(w*.52f,w*.40f), androidx.compose.ui.geometry.Offset(w*.62f,w*.78f), stroke.width); drawLine(c, androidx.compose.ui.geometry.Offset(w*.36f,w*.45f), androidx.compose.ui.geometry.Offset(w*.08f,w*.78f), stroke.width) }
            "truck" -> { drawRect(color=c, topLeft=androidx.compose.ui.geometry.Offset(w*.10f,w*.35f), size=androidx.compose.ui.geometry.Size(w*.52f,w*.37f), style=stroke); drawRect(color=c, topLeft=androidx.compose.ui.geometry.Offset(w*.62f,w*.46f), size=androidx.compose.ui.geometry.Size(w*.26f,w*.26f), style=stroke); drawCircle(c,w*.16f,center=androidx.compose.ui.geometry.Offset(w*.28f,w*.78f)); drawCircle(c,w*.16f,center=androidx.compose.ui.geometry.Offset(w*.73f,w*.78f)) }
            "tire" -> { drawCircle(c,w*.36f,style=stroke); drawCircle(c,w*.16f,style=stroke) }
            "bolt" -> { drawLine(c, androidx.compose.ui.geometry.Offset(w*.55f,w*.05f), androidx.compose.ui.geometry.Offset(w*.28f,w*.48f), stroke.width*1.2f); drawLine(c, androidx.compose.ui.geometry.Offset(w*.28f,w*.48f), androidx.compose.ui.geometry.Offset(w*.58f,w*.44f), stroke.width*1.2f); drawLine(c, androidx.compose.ui.geometry.Offset(w*.58f,w*.44f), androidx.compose.ui.geometry.Offset(w*.40f,w*.94f), stroke.width*1.2f) }
            "gear" -> { drawCircle(c,w*.30f,style=stroke); drawCircle(c,w*.10f); for(i in 0 until 8){val a=i*Math.PI/4; val x1=w*.48f+ kotlin.math.cos(a).toFloat()*w*.10f; val y1=w*.48f+ kotlin.math.sin(a).toFloat()*w*.10f; val x2=w*.48f+ kotlin.math.cos(a).toFloat()*w*.38f; val y2=w*.48f+ kotlin.math.sin(a).toFloat()*w*.38f; drawLine(c, androidx.compose.ui.geometry.Offset(x1,y1), androidx.compose.ui.geometry.Offset(x2,y2), stroke.width*1.2f)} }
            "chip" -> { drawRect(color=c, topLeft=androidx.compose.ui.geometry.Offset(w*.22f,w*.22f), size=androidx.compose.ui.geometry.Size(w*.56f,w*.56f), style=stroke); for(i in 0 until 4){val x=w*(.28f+i*.15f); drawLine(c, androidx.compose.ui.geometry.Offset(x,w*.08f), androidx.compose.ui.geometry.Offset(x,w*.22f), stroke.width); drawLine(c, androidx.compose.ui.geometry.Offset(x,w*.78f), androidx.compose.ui.geometry.Offset(x,w*.92f), stroke.width)} }
            "signal" -> { drawArc(c,0f,180f,false,androidx.compose.ui.geometry.Offset(w*.12f,w*.25f).let{it}, androidx.compose.ui.geometry.Size(w*.76f,w*.76f),style=stroke); drawCircle(c,w*.08f,center=androidx.compose.ui.geometry.Offset(w*.5f,w*.75f)) }
            "bank" -> { drawCircle(c,w*.30f,center=androidx.compose.ui.geometry.Offset(w*.5f,w*.38f),style=stroke); drawCircle(c,w*.30f,center=androidx.compose.ui.geometry.Offset(w*.5f,w*.62f),style=stroke); drawLine(c, androidx.compose.ui.geometry.Offset(w*.20f,w*.20f), androidx.compose.ui.geometry.Offset(w*.20f,w*.80f), stroke.width); drawLine(c, androidx.compose.ui.geometry.Offset(w*.80f,w*.20f), androidx.compose.ui.geometry.Offset(w*.80f,w*.80f), stroke.width) }
            else -> { drawCircle(c,w*.32f,style=stroke); drawLine(c, androidx.compose.ui.geometry.Offset(w*.18f,w*.68f), androidx.compose.ui.geometry.Offset(w*.82f,w*.32f), stroke.width); drawCircle(c,w*.08f,center=androidx.compose.ui.geometry.Offset(w*.72f,w*.72f)) }
        }
    }
}

@Composable
private fun DriverMarket(
    store: CareerPreferences,
    teamId: Int,
    currentWeek: Int,
    selectedDriverId: Int,
    state: DriverMarketState,
    message: String,
    onSelect: (Int) -> Unit,
    onDriverProfile: (Int) -> Unit,
    onInterest: (Int, Int?) -> Unit,
    onProposal: (Int, Int?, Int, Long, DriverTeamRole) -> Unit,
    onCounter: (com.f1teammanager.core.manager.DriverOffer, Int?, Int, Long, DriverTeamRole) -> Unit,
    onAcceptCounter: (com.f1teammanager.core.manager.DriverOffer) -> Unit,
    onRejectCounter: (com.f1teammanager.core.manager.DriverOffer) -> Unit,
    onRenew: (Int, Int, Long, DriverTeamRole) -> Unit,
    onAcceptIncoming: (com.f1teammanager.core.manager.DriverOffer) -> Unit,
    onRejectIncoming: (com.f1teammanager.core.manager.DriverOffer) -> Unit,
    onScout: (Int) -> Unit
) {
    var replacementId by remember(teamId) { mutableIntStateOf(-1) }
    var filter by remember { mutableStateOf("TODOS") }
    var search by remember { mutableStateOf("") }
    var sort by remember { mutableStateOf("Overall") }
    var showProposal by remember { mutableIntStateOf(-1) }
    var years by remember { mutableIntStateOf(1) }
    var role by remember { mutableStateOf(DriverTeamRole.EQUAL) }
    var salaryText by remember { mutableStateOf("") }
    var counterOffer by remember { mutableStateOf<com.f1teammanager.core.manager.DriverOffer?>(null) }
    var renewDriver by remember { mutableIntStateOf(-1) }
    var scoutDriver by remember { mutableIntStateOf(-1) }

    val currentDeals = state.contracts.filter { it.teamId == teamId && it.activeIn(store.season) }
    val currentIds = currentDeals.map { it.driverId }.toSet()
    val scheduledIds = state.scheduled.map { it.driverId }.toSet()
    val allDrivers = WorldDatabase.allDrivers
    val marketEngine = remember { DriverMarketEngine(20261003) }
    val visibleIds = when (filter) {
        "LIVRES" -> state.freeAgents
        "CONTRATADOS" -> state.contracts.map { it.driverId }
        "MINHA EQUIPE" -> currentIds.toList()
        "NEGOCIÁVEIS" -> allDrivers.map { it.id }.filter { marketEngine.canReceiveProposals(state, it, store.season) }
        "FECHADOS" -> state.scheduled.filter { it.signedSeason == store.season }.map { it.driverId }
        "FUTUROS" -> scheduledIds.toList()
        else -> allDrivers.map { it.id }
    }.distinct()

    val rows = visibleIds.mapNotNull { id ->
        val d = runCatching { store.driverDefinition(id) }.getOrNull() ?: return@mapNotNull null
        if (search.isNotBlank() && !d.name.contains(search, ignoreCase = true) &&
            !WorldDatabase.teams.firstOrNull { it.id == d.teamId }?.name.orEmpty().contains(search, ignoreCase = true)) return@mapNotNull null
        val deal = state.contracts.firstOrNull { it.driverId == id && it.activeIn(store.season) }
        val future = state.scheduled.firstOrNull { it.driverId == id }
        Triple(d, deal, future)
    }.sortedWith(
        when (sort) {
            "Nome" -> compareBy { it.first.name }
            else -> compareByDescending<Triple<com.f1teammanager.core.season.DriverDefinition, com.f1teammanager.core.manager.DriverDeal?, com.f1teammanager.core.manager.FutureDriverDeal?>> {
                (it.first.speed + it.first.qualifying + it.first.overtaking + it.first.defense + it.first.consistency + it.first.wet + it.first.tyre) / 7
            }.thenBy { it.first.name }
        }
    )

    Column(Modifier.fillMaxSize().background(Bg)) {
        // Cabeçalho e controles ficam fixos. Somente a lista de pilotos rola.
        Column(
            Modifier
                .fillMaxWidth()
                .background(Bg)
                .padding(start = 14.dp, end = 14.dp, top = 0.dp, bottom = 6.dp)
        ) {
            Text(
                "100 PILOTOS • 40 EQUIPES • TRANSFERÊNCIAS SOMENTE NA PRÓXIMA TEMPORADA",
                color = Red,
                fontSize = 7.sp,
                fontWeight = FontWeight.Black,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(top = 0.dp, bottom = 5.dp)
            )

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                MarketStat("100", "PILOTOS", "total", Modifier.weight(1f))
                MarketStat("80", "NO GRID", "40 equipes", Modifier.weight(1f))
                MarketStat("${state.freeAgents.size}", "LIVRES", "sem contrato", Modifier.weight(1f))
                MarketStat("${state.scheduled.count { it.startSeason == store.season + 1 }}", "TRANSFERÊNCIAS", "${store.season + 1}", Modifier.weight(1f))
            }

            if (message.isNotBlank()) {
                Card(Modifier.fillMaxWidth().padding(top = 5.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF052418)), shape = RoundedCornerShape(8.dp)) {
                    Row(Modifier.padding(horizontal = 9.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("◎", color = Green, fontSize = 17.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(end = 6.dp))
                        Text(message, color = Green, fontSize = 9.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    }
                }
            }

            Text(
                "Escolha o piloto que será substituído na próxima contratação. A seleção permanece ativa até você escolher outro.",
                color = Muted,
                fontSize = 9.sp,
                lineHeight = 13.sp,
                modifier = Modifier.padding(top = 6.dp, bottom = 5.dp)
            )

            if (currentDeals.size >= 2) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("PILOTO(S) SELECIONADO(S) PARA SUBSTITUIR", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Black, modifier = Modifier.weight(1f))
                    Text("${currentDeals.count { replacementId == it.driverId || state.scheduled.any { s -> s.toTeamId == teamId && s.replaceDriverId == it.driverId } }}/2", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Black)
                }
                Spacer(Modifier.height(4.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    currentDeals.forEach { deal ->
                        val name = allDrivers.firstOrNull { it.id == deal.driverId }?.name ?: "Piloto ${deal.driverId}"
                        val reserved = state.scheduled.any { it.toTeamId == teamId && it.replaceDriverId == deal.driverId }
                        Card(
                            Modifier.weight(1f).clickable(enabled = !reserved) { replacementId = if (replacementId == deal.driverId) -1 else deal.driverId },
                            colors = CardDefaults.cardColors(containerColor = if (replacementId == deal.driverId || reserved) Color(0xFF191D24) else Panel),
                            border = BorderStroke(1.dp, if (replacementId == deal.driverId || reserved) Red else Line),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Row(Modifier.padding(5.dp), verticalAlignment = Alignment.CenterVertically) {
                                DriverPhoto(deal.driverId, name, Modifier.size(28.dp).clip(RoundedCornerShape(50)))
                                Text(name, color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f).padding(horizontal = 4.dp))
                                Text("×", color = if (reserved) Muted else Red, fontSize = 17.sp, fontWeight = FontWeight.Black)
                            }
                        }
                    }
                }
            }

            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(top = 5.dp), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                listOf("TODOS", "LIVRES", "CONTRATADOS", "MINHA EQUIPE", "ABERTO", "FECHADO").forEach { f ->
                    val key = when (f) {
                        "ABERTO" -> "NEGOCIÁVEIS"
                        "FECHADO" -> "FECHADOS"
                        else -> f
                    }
                    Button(onClick = { filter = key }, colors = ButtonDefaults.buttonColors(containerColor = if (filter == key) Red else Bg, contentColor = Color.White), border = BorderStroke(1.dp, if (filter == key) Red else Line), shape = RoundedCornerShape(8.dp), contentPadding = PaddingValues(horizontal = 13.dp, vertical = 7.dp)) {
                        Text(f, fontSize = 8.sp, fontWeight = FontWeight.Black)
                    }
                }
            }

            Row(Modifier.fillMaxWidth().padding(top = 5.dp), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = search,
                    onValueChange = { search = it },
                    modifier = Modifier.weight(1f).height(52.dp),
                    singleLine = true,
                    placeholder = { Text("Buscar piloto, equipe ou país...", color = Muted, fontSize = 10.sp) },
                    leadingIcon = { Text("⌕", color = Muted, fontSize = 19.sp) },
                    colors = OutlinedTextFieldDefaults.colors(unfocusedBorderColor = Line, focusedBorderColor = Red, unfocusedContainerColor = Panel, focusedContainerColor = Panel, unfocusedTextColor = Color.White, focusedTextColor = Color.White),
                    shape = RoundedCornerShape(9.dp)
                )
                Box(
                    Modifier.weight(1f).height(52.dp).background(Panel, RoundedCornerShape(9.dp)).border(1.dp, Line, RoundedCornerShape(9.dp)).clickable { sort = if (sort == "Overall") "Nome" else "Overall" },
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(sort, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        Text(if (sort == "Overall") "↕" else "A–Z", color = Muted, fontSize = 9.sp)
                    }
                }
            }
        }

        LazyColumn(
            modifier = Modifier.fillMaxWidth().weight(1f),
            contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 2.dp, bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
if (rows.isEmpty()) item { Text("Nenhum piloto encontrado.", color = Muted, modifier = Modifier.padding(10.dp)) }

items(rows, key = { it.first.id }) { (d, deal, future) ->
    val selected = selectedDriverId == d.id
    val overall = (d.speed + d.qualifying + d.overtaking + d.defense + d.consistency + d.wet + d.tyre) / 7
    val canTalk = marketEngine.canReceiveProposals(state, d.id, store.season)
    val currentTeamName = deal?.let { WorldDatabase.teams.firstOrNull { t -> t.id == it.teamId }?.name } ?: "Sem equipe"
    val status = when {
        future != null -> "FUTURO"
        deal == null -> "LIVRE"
        deal.teamId == teamId -> "SUA EQUIPE"
        else -> "CONTRATO"
    }
    Card(Modifier.fillMaxWidth().clickable { onSelect(d.id) }, colors = CardDefaults.cardColors(containerColor = if (selected) Color(0xFF191317) else Panel), shape = RoundedCornerShape(14.dp), border = BorderStroke(1.dp, if (selected) Red else Color(0xFF1D222A))) {
        Column(Modifier.padding(10.dp)) {
            Row(verticalAlignment = Alignment.Top) {
                DriverPhoto(d.id, d.name, Modifier.size(72.dp).clip(RoundedCornerShape(10.dp)).clickable { onDriverProfile(d.id) })
                Column(Modifier.weight(1f).padding(start = 9.dp, end = 6.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(d.name, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Black, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                        Text(status, color = if (future != null) Green else Color.White, fontSize = 8.sp, fontWeight = FontWeight.Black, modifier = Modifier.background(Panel2, RoundedCornerShape(12.dp)).padding(horizontal = 8.dp, vertical = 5.dp))
                    }
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 2.dp)) {
                        Text("Overall $overall", color = Muted, fontSize = 10.sp)
                        Text(" • ", color = Muted, fontSize = 10.sp)
                        Text(d.driverClass, color = when(d.driverClass){"Lenda"->Color(0xFFFFD32A);"Pro"->Color(0xFF36B7FF);"Forte"->Green;else->Muted}, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        Text(" • ", color = Muted, fontSize = 10.sp)
                        Text(d.evolution, color = Color(0xFFB86CFF), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                    Row(Modifier.padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("Equipe atual:", color = Muted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.width(4.dp))
                        TeamLogo(currentTeamName, WorldDatabase.teams.firstOrNull { it.name.equals(currentTeamName, ignoreCase = true) }?.id ?: 0, Modifier.size(18.dp))
                        Spacer(Modifier.width(4.dp))
                        Text(currentTeamName, color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    if (deal != null) {
                        val year = deal.contractYear(store.season)
                        Text("Contrato ${deal.years} ano(s) • ano $year/${deal.years} • salário ${formatMoney(deal.salary)}", color = Muted, fontSize = 9.sp, modifier = Modifier.padding(top = 2.dp))
                        Text(if (deal.canReceiveProposals(store.season)) "Último ano: pode receber propostas e renovar" else "Contrato protegido até o último ano.", color = if (deal.canReceiveProposals(store.season)) Green else Muted, fontSize = 9.sp, fontWeight = if (deal.canReceiveProposals(store.season)) FontWeight.Bold else FontWeight.Normal)
                    }
                    if (future != null) {
                        val nextTeamName = WorldDatabase.teams.firstOrNull { it.id == future.toTeamId }?.name ?: "Equipe ${future.toTeamId}"
                        Row(Modifier.padding(top = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("Próxima:", color = Green, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.width(4.dp))
                            TeamLogo(nextTeamName, future.toTeamId, Modifier.size(18.dp))
                            Spacer(Modifier.width(4.dp))
                            Text(nextTeamName, color = Green, fontSize = 9.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(" • ${future.startSeason}", color = Muted, fontSize = 8.sp)
                        }
                    }
                }
            }

            val report = state.scouting.lastOrNull { it.driverId == d.id && it.teamId == teamId && it.season == store.season }
            Row(Modifier.fillMaxWidth().padding(top = 5.dp), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                val labels = listOf("VEL","CLA","ULT","DEF","CON","CHU","PNE")
                val ranges = report?.attributeRanges?.split("|").orEmpty()
                labels.forEachIndexed { index, label ->
                    Column(Modifier.weight(1f).height(52.dp).background(Panel2, RoundedCornerShape(5.dp)).border(1.dp, if (report != null) Red.copy(alpha = 0.45f) else Line, RoundedCornerShape(5.dp)).padding(vertical = 3.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                        Text(label, color = Muted, fontSize = 6.sp, fontWeight = FontWeight.Black)
                        Text(if (report == null || index >= ranges.size || ranges[index].isBlank()) "🔒" else ranges[index], color = if (report == null) Muted else Color.White, fontSize = 8.sp, fontWeight = FontWeight.Black, maxLines = 1)
                    }
                }
            }
            if (report == null) Text("Atributos ocultos • realize o Scout para obter uma estimativa.", color = Muted, fontSize = 8.sp, modifier = Modifier.padding(top = 4.dp))
            else Text("Scout ${report.season} • relatório disponível até o fim da temporada", color = Green, fontSize = 8.sp, modifier = Modifier.padding(top = 4.dp))

            Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedButton(onClick = { onScout(d.id); scoutDriver = -1 }, modifier = Modifier.weight(1f), border = BorderStroke(1.dp, Line), shape = RoundedCornerShape(10.dp), contentPadding = PaddingValues(vertical = 7.dp)) { Text("SCOUT", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Black) }
                if (d.id in currentIds && deal != null && deal.contractYear(store.season) == deal.years && future == null) {
                    Button(enabled = currentWeek > 1 && DriverMarketEngine(20261003).marketOpen(currentWeek, store.season), onClick = { salaryText = deal.salary.toString(); years = deal.years; role = deal.role; renewDriver = d.id }, modifier = Modifier.weight(1.35f), colors = ButtonDefaults.buttonColors(containerColor = Red, contentColor = Color.White), shape = RoundedCornerShape(10.dp), contentPadding = PaddingValues(vertical = 7.dp)) { Text("RENOVAR", fontSize = 9.sp, fontWeight = FontWeight.Black) }
                } else if (d.id !in currentIds && canTalk) {
                    Button(enabled = DriverMarketEngine(20261003).marketOpen(currentWeek, store.season), onClick = { salaryText = marketEngine.salaryFor(d.id).toString(); years = 1; role = DriverTeamRole.EQUAL; showProposal = d.id }, modifier = Modifier.weight(1.35f), colors = ButtonDefaults.buttonColors(containerColor = Red, contentColor = Color.White), shape = RoundedCornerShape(10.dp), contentPadding = PaddingValues(vertical = 7.dp)) { Text("NEGOCIAR", fontSize = 9.sp, fontWeight = FontWeight.Black) }
                } else {
                    Spacer(Modifier.weight(1.35f))
                }
            }
        }
    }
}

val waiting = state.pending.filter { it.status == NegotiationStatus.PENDING && it.seasonTarget == store.season + 1 }
val waitingForDriver = waiting.filter { it.proposerTeamId == teamId }
val waitingFromAi = waiting.filter { it.proposerTeamId != 0 && it.proposerTeamId != teamId }
if (waitingForDriver.isNotEmpty()) item {
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFF171B22))) {
        Column(Modifier.padding(10.dp)) {
            Text("NEGOCIAÇÕES AGUARDANDO RESPOSTA", color = Color.White, fontWeight = FontWeight.Black, fontSize = 10.sp)
            waitingForDriver.takeLast(5).forEach { offer ->
                val name = allDrivers.firstOrNull { it.id == offer.driverId }?.name ?: "Piloto ${offer.driverId}"
                Text("${name} • resposta prevista em ${offer.expiresAfterWeek - store.currentWeek.coerceAtLeast(0)} semana(s)", color = Muted, fontSize = 8.sp, modifier = Modifier.padding(top = 4.dp))
            }
        }
    }
}
if (waitingFromAi.isNotEmpty()) item {
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFF171B22))) {
        Column(Modifier.padding(10.dp)) {
            Text("PROPOSTAS EM ANÁLISE PELO PILOTO", color = Color.White, fontWeight = FontWeight.Black, fontSize = 10.sp)
            waitingFromAi.takeLast(5).forEach { offer ->
                val name = allDrivers.firstOrNull { it.id == offer.driverId }?.name ?: "Piloto ${offer.driverId}"
                val proposer = WorldDatabase.teams.firstOrNull { it.id == offer.proposerTeamId }?.name ?: "Equipe ${offer.proposerTeamId}"
                Text("${proposer} • ${name} • resposta prevista na semana ${offer.expiresAfterWeek}", color = Muted, fontSize = 8.sp, modifier = Modifier.padding(top = 4.dp))
            }
        }
    }
}
val responseCards = state.notifications.filter { it.season == store.season && (it.title == "RESPOSTA DO PILOTO" || it.title == "DECISÃO DA EQUIPE" || it.title == "CONTRAPROPOSTA DA EQUIPE") }.takeLast(5).asReversed()
if (responseCards.isNotEmpty()) item {
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFF211817))) {
        Column(Modifier.padding(10.dp)) {
            Text("RESPOSTAS DAS NEGOCIAÇÕES", color = Color.White, fontWeight = FontWeight.Black, fontSize = 10.sp)
            responseCards.forEach { n ->
                NewsNotificationCard(n)
            }
        }
    }
}

val counters = state.pending.filter { it.proposerTeamId == teamId && it.status == NegotiationStatus.COUNTER && it.seasonTarget == store.season + 1 }
if (counters.isNotEmpty()) item {
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFF211817))) { Column(Modifier.padding(10.dp)) { Text("CONTRAPROPOSTAS PENDENTES", color = Color.White, fontWeight = FontWeight.Black, fontSize = 10.sp); counters.takeLast(3).forEach { offer -> val name=allDrivers.firstOrNull { it.id==offer.driverId }?.name ?: "Piloto ${offer.driverId}"; Row(Modifier.fillMaxWidth().padding(top=5.dp), verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(name,color=Color.White,fontWeight=FontWeight.Bold,fontSize=9.sp);Text("Rodada ${offer.round}/3 • ${formatMoney(offer.salary)}/ano • ${offer.years} ano(s)",color=Muted,fontSize=8.sp)};Button(onClick={counterOffer=offer;salaryText=offer.salary.toString();years=offer.years;role=offer.role},colors=ButtonDefaults.buttonColors(containerColor=Red),contentPadding=PaddingValues(horizontal=8.dp,vertical=2.dp)){Text("VER CONTRAPROPOSTA",fontSize=8.sp)}} } } }
}
val incoming = emptyList<com.f1teammanager.core.manager.DriverOffer>()
if (incoming.isNotEmpty()) item {
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFF211817))) { Column(Modifier.padding(10.dp)) { Text("OFERTAS RECEBIDAS", color = Color.White, fontWeight = FontWeight.Black, fontSize = 10.sp); incoming.takeLast(5).forEach { offer -> val name=allDrivers.firstOrNull { it.id==offer.driverId }?.name ?: "Piloto ${offer.driverId}"; val teamName=WorldDatabase.teams.firstOrNull { it.id==offer.toTeamId }?.name ?: "Equipe ${offer.toTeamId}"; Row(Modifier.fillMaxWidth().padding(top=5.dp),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text("$name → $teamName",color=Color.White,fontWeight=FontWeight.Bold,fontSize=9.sp);Text("${offer.years} ano(s) • ${formatMoney(offer.salary)}/ano • válida até semana ${offer.expiresAfterWeek}",color=Muted,fontSize=8.sp)};TextButton(onClick={onRejectIncoming(offer)}){Text("RECUSAR",color=Muted,fontSize=8.sp)};Button(onClick={onAcceptIncoming(offer)},colors=ButtonDefaults.buttonColors(containerColor=Red),contentPadding=PaddingValues(horizontal=7.dp,vertical=2.dp)){Text("ACEITAR",fontSize=8.sp)}} } } }
        }
    }

    if (showProposal > 0) {
        val d=allDrivers.firstOrNull { it.id==showProposal }
        if (d != null) AlertDialog(onDismissRequest={showProposal=-1},title={Text("PROPOSTA • ${d.name}",fontWeight=FontWeight.Black)},text={Column(verticalArrangement=Arrangement.spacedBy(7.dp)){Text("A proposta vale para ${store.season+1}. O piloto permanece na equipe atual até o fim da temporada.",color=Muted,fontSize=10.sp);Text("Duração",color=Color.White,fontWeight=FontWeight.Bold,fontSize=10.sp);Row(horizontalArrangement=Arrangement.spacedBy(5.dp)){listOf(1,2,3,4,5).forEach{y->FilterChip(selected=years==y,onClick={years=y},label={Text("$y ano",fontSize=9.sp)})}};Text("Papel",color=Color.White,fontWeight=FontWeight.Bold,fontSize=10.sp);Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(5.dp)){listOf(DriverTeamRole.PILOT_1,DriverTeamRole.PILOT_2,DriverTeamRole.EQUAL).forEach{r->FilterChip(selected=role==r,onClick={role=r},label={Text(when(r){DriverTeamRole.PILOT_1->"Piloto 1";DriverTeamRole.PILOT_2->"Piloto 2";DriverTeamRole.EQUAL->"Iguais"},fontSize=9.sp)})}};Text("Salário anual",color=Color.White,fontWeight=FontWeight.Bold,fontSize=10.sp);OutlinedTextField(value=salaryText,onValueChange={salaryText=it.filter(Char::isDigit)},singleLine=true,label={Text("Valor")});Text("Valor de mercado e salário são referências separadas. Não existe multa contratual.",color=Muted,fontSize=8.sp)}},confirmButton={Button(onClick={val salary=salaryText.toLongOrNull()?:0L;if(salary>0){onProposal(d.id,if(currentDeals.size>=2)replacementId.takeIf{it>0} else null,years,salary,role);showProposal=-1}},colors=ButtonDefaults.buttonColors(containerColor=Red)){Text("ENVIAR PROPOSTA")}},dismissButton={TextButton(onClick={showProposal=-1}){Text("CANCELAR")}})
    }
    if (renewDriver > 0) {
        val d=allDrivers.firstOrNull { it.id==renewDriver }
        if(d!=null) AlertDialog(onDismissRequest={renewDriver=-1},title={Text("RENOVAR • ${d.name}",fontWeight=FontWeight.Black)},text={Column(verticalArrangement=Arrangement.spacedBy(7.dp)){Text("A renovação começa em ${store.season+1}. O contrato atual continua válido até o fim desta temporada.",color=Muted,fontSize=9.sp);Text("Duração",fontWeight=FontWeight.Bold,fontSize=10.sp);Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(4.dp)){listOf(1,2,3,4,5).forEach{y->FilterChip(selected=years==y,onClick={years=y},label={Text("$y ano",fontSize=8.sp)})}};Text("Papel",fontWeight=FontWeight.Bold,fontSize=10.sp);Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(4.dp)){listOf(DriverTeamRole.PILOT_1,DriverTeamRole.PILOT_2,DriverTeamRole.EQUAL).forEach{r->FilterChip(selected=role==r,onClick={role=r},label={Text(when(r){DriverTeamRole.PILOT_1->"Piloto 1";DriverTeamRole.PILOT_2->"Piloto 2";DriverTeamRole.EQUAL->"Iguais"},fontSize=8.sp)})}};Text("Salário anual",fontWeight=FontWeight.Bold,fontSize=10.sp);OutlinedTextField(value=salaryText,onValueChange={salaryText=it.filter(Char::isDigit)},singleLine=true)}},confirmButton={Button(onClick={val salary=salaryText.toLongOrNull()?:0L;if(salary>0){onRenew(d.id,years,salary,role);renewDriver=-1}},colors=ButtonDefaults.buttonColors(containerColor=Red)){Text("CONFIRMAR RENOVAÇÃO")}},dismissButton={TextButton(onClick={renewDriver=-1}){Text("CANCELAR")}})
    }
    if (counterOffer != null) {
        val offer=counterOffer!!; val d=allDrivers.firstOrNull { it.id==offer.driverId }
        if(d!=null) AlertDialog(onDismissRequest={counterOffer=null},title={Text("CONTRAPROPOSTA • ${d.name}",fontWeight=FontWeight.Black)},text={Column(verticalArrangement=Arrangement.spacedBy(7.dp)){Text("RODADA ${offer.round}/3 • início em ${offer.seasonTarget}",color=Muted,fontSize=9.sp);Text("O piloto exige:",color=Color.White,fontWeight=FontWeight.Black,fontSize=10.sp);Text("Salário exigido: ${formatMoney(offer.salary)}/ano",color=Color.White,fontSize=10.sp);Text("Duração exigida: ${offer.years} ano(s)",color=Color.White,fontSize=10.sp);Text("Papel exigido: ${when(offer.role){DriverTeamRole.PILOT_1->"Piloto 1";DriverTeamRole.PILOT_2->"Piloto 2";DriverTeamRole.EQUAL->"Pilotos iguais"}}",color=Color.White,fontSize=10.sp);Text("Você pode aceitar, fazer outra contraproposta ou recusar.",color=Muted,fontSize=9.sp);Text("Sua nova proposta",fontWeight=FontWeight.Bold,fontSize=10.sp);OutlinedTextField(value=salaryText,onValueChange={salaryText=it.filter(Char::isDigit)},singleLine=true);Text("Duração",fontWeight=FontWeight.Bold,fontSize=10.sp);Row(horizontalArrangement=Arrangement.spacedBy(4.dp)){listOf(1,2,3,4,5).forEach{y->FilterChip(selected=years==y,onClick={years=y},label={Text("$y ano",fontSize=8.sp)})}};Text("Papel",fontWeight=FontWeight.Bold,fontSize=10.sp);Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(4.dp)){listOf(DriverTeamRole.PILOT_1,DriverTeamRole.PILOT_2,DriverTeamRole.EQUAL).forEach{r->FilterChip(selected=role==r,onClick={role=r},label={Text(when(r){DriverTeamRole.PILOT_1->"Piloto 1";DriverTeamRole.PILOT_2->"Piloto 2";DriverTeamRole.EQUAL->"Iguais"},fontSize=8.sp)})}}}},confirmButton={if(offer.round<3) Button(onClick={val salary=salaryText.toLongOrNull()?:0L;if(salary>0){onCounter(offer,if(currentDeals.size>=2)replacementId.takeIf{it>0} else null,years,salary,role);counterOffer=null}},colors=ButtonDefaults.buttonColors(containerColor=Red)){Text("FAZER CONTRAPROPOSTA")}},dismissButton={Row(horizontalArrangement=Arrangement.spacedBy(4.dp)){Button(onClick={onAcceptCounter(offer);counterOffer=null},colors=ButtonDefaults.buttonColors(containerColor=Red)){Text("ACEITAR")};TextButton(onClick={onRejectCounter(offer);counterOffer=null}){Text("RECUSAR")}}})
    }
    if (scoutDriver > 0) {
        val d=allDrivers.firstOrNull { it.id==scoutDriver }
        if(d!=null) AlertDialog(onDismissRequest={scoutDriver=-1},title={Text("SCOUT • ${d.name}",fontWeight=FontWeight.Black)},text={Column(verticalArrangement=Arrangement.spacedBy(6.dp)){Text("Relatório de scouting",color=Color.White,fontSize=10.sp,fontWeight=FontWeight.Bold);Text("Custo: US$ 0,5M",color=Muted,fontSize=9.sp);Text("A precisão dos atributos será definida pelo sistema de instalações em uma atualização futura. O relatório fica disponível durante toda a temporada e não garante contratação.",color=Muted,fontSize=9.sp)}},confirmButton={Button(onClick={onScout(d.id);scoutDriver=-1},colors=ButtonDefaults.buttonColors(containerColor=Red)){Text("REALIZAR SCOUT")}},dismissButton={TextButton(onClick={scoutDriver=-1}){Text("CANCELAR")}})
    }
}
}

@Composable
private fun MarketStat(value: String, title: String, subtitle: String, modifier: Modifier = Modifier) {
    Card(modifier.height(52.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF101319)), shape = RoundedCornerShape(7.dp)) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 2.dp, vertical = 3.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Text(value, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Black, maxLines = 1)
            Text(title, color = Color.White, fontSize = 6.sp, fontWeight = FontWeight.Black, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(subtitle, color = Muted, fontSize = 4.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun MarketNews(state: DriverMarketState, season: Int, onViewed: () -> Unit) {
    LaunchedEffect(state.notifications, season) { onViewed() }
    var category by remember { mutableStateOf(MarketNewsCategory.MARKET) }
    var teamSearch by remember { mutableStateOf("") }
    val query = teamSearch.trim()
    val items = state.notifications
        .filter { it.season <= season && it.category == category }
        // Manufacturing-ready notices are intentionally retired from the feed.
        .filterNot { it.title.equals("FABRICAÇÃO CONCLUÍDA", ignoreCase = true) || it.message.contains("pronta para instalação", ignoreCase = true) }
        // Search applies to the selected news category and filters by team/entity/message.
        .filter { query.isBlank() || it.message.contains(query, ignoreCase = true) || it.title.contains(query, ignoreCase = true) }
        .sortedWith(compareByDescending<MarketNotification> { it.season }.thenByDescending { it.week })

    val labels = listOf(
        MarketNewsCategory.MARKET to "MERCADO",
        MarketNewsCategory.DRIVER_EVOLUTION to "EVOLUÇÃO DE PILOTOS",
        MarketNewsCategory.TEAM_EVOLUTION to "EVOLUÇÃO DE EQUIPES",
        MarketNewsCategory.ANNUAL_EVENTS to "EVENTOS ANUAIS"
    )

    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 12.dp),
        contentPadding = PaddingValues(top = 8.dp, bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            Text("CENTRAL DE NOTÍCIAS", color = Color.White, fontWeight = FontWeight.Black, fontSize = 24.sp)
            Text(
                "TUDO O QUE ACONTECE NA TEMPORADA",
                color = Red,
                fontWeight = FontWeight.Bold,
                fontSize = 10.sp,
                modifier = Modifier.padding(top = 3.dp, bottom = 10.dp)
            )
            OutlinedTextField(
                value = teamSearch,
                onValueChange = { teamSearch = it },
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 8.dp),
                singleLine = true,
                placeholder = { Text("Buscar equipe ou notícia (ex.: Ferrari)", color = Muted, fontSize = 12.sp) },
                leadingIcon = { Text("⌕", color = Muted, fontSize = 22.sp) },
                trailingIcon = {
                    if (teamSearch.isNotEmpty()) TextButton(onClick = { teamSearch = "" }) { Text("LIMPAR", color = Red, fontSize = 9.sp) }
                },
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    unfocusedBorderColor = Line, focusedBorderColor = Red,
                    unfocusedContainerColor = Panel, focusedContainerColor = Panel,
                    unfocusedTextColor = Color.White, focusedTextColor = Color.White,
                    cursorColor = Red
                )
            )
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(7.dp)
            ) {
                labels.forEach { (key, label) ->
                    NewsCategoryChip(label, category == key) { category = key }
                }
            }
        }

        if (items.isEmpty()) {
            item {
                Card(
                    Modifier.fillMaxWidth().padding(top = 5.dp),
                    colors = CardDefaults.cardColors(containerColor = Panel),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Column(
                        Modifier.fillMaxWidth().padding(22.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        NewsCategoryGlyph(category, Modifier.size(42.dp))
                        Text(if (query.isNotBlank()) "Nenhuma notícia encontrada para \"$query\" nesta categoria." else "Nenhuma notícia nesta categoria ainda.", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 10.dp))
                    }
                }
            }
        } else {
            val seasonWeeks = items.groupBy { it.season to it.week }
            seasonWeeks.entries.sortedWith(
                compareByDescending<Map.Entry<Pair<Int, Int>, List<MarketNotification>>> { it.key.first }
                    .thenByDescending { it.key.second }
            ).forEach { (seasonWeek, weekItems) ->
                val (newsSeason, week) = seasonWeek
                item {
                    Text(
                        "TEMPORADA $newsSeason • SEMANA $week",
                        color = Red,
                        fontWeight = FontWeight.Black,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(top = 6.dp, bottom = 2.dp)
                    )
                }
                val relevanceOrder = mapOf(
                    "EVOLUÇÃO DE EQUIPE" to 0,
                    "PEÇA INSTALADA" to 1,
                    "P&D CONCLUÍDO" to 2
                )
                items(weekItems.sortedWith(compareBy<MarketNotification> { relevanceOrder[it.title.uppercase(Locale.ROOT)] ?: 3 }.thenBy { it.title })) { n ->
                    NewsNotificationCard(n)
                }
            }
        }
    }
}

@Composable
private fun NewsCategoryChip(label: String, selected: Boolean, onClick: () -> Unit) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(12.dp),
        color = if (selected) Color(0xFF514B61) else Color.Transparent,
        border = BorderStroke(1.2.dp, if (selected) Color(0xFF514B61) else Color(0xFF8A8790))
    ) {
        Box(Modifier.padding(horizontal = 18.dp, vertical = 10.dp)) {
            Text(label, color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Medium, maxLines = 1)
        }
    }
}

private data class NewsParsed(
    val entityName: String?,
    val entityId: Int?,
    val component: CarComponent?,
    val before: Int?,
    val after: Int?,
    val delta: Int?,
    val detail: String
)

private fun parseNews(n: MarketNotification): NewsParsed {
    val component = when {
        n.message.contains("Unidade de potência elétrica", true) || n.message.contains("Unidade elétrica", true) -> CarComponent.ELECTRIC_POWER_UNIT
        n.message.contains("Unidade de potência", true) -> CarComponent.ENGINE
        n.message.contains("Asa dianteira", true) -> CarComponent.FRONT_WING
        n.message.contains("Asa traseira", true) -> CarComponent.REAR_WING
        n.message.contains("Chassi", true) -> CarComponent.CHASSIS
        n.message.contains("Freios", true) -> CarComponent.BRAKES
        n.message.contains("Suspensão", true) -> null
        else -> null
    }
    val range = Regex("(\\d+)\\s*(?:→|->)\\s*(\\d+)").find(n.message)
    val before = range?.groupValues?.getOrNull(1)?.toIntOrNull()
    val after = range?.groupValues?.getOrNull(2)?.toIntOrNull()
    val delta = if (before != null && after != null) after - before else null

    val allTeams = WorldDatabase.teams
    val allDrivers = WorldDatabase.allDrivers
    val team = allTeams.firstOrNull { n.message.contains(it.name, true) }
    val driver = allDrivers.firstOrNull { n.message.contains(it.name, true) }
    val entityName = team?.name ?: driver?.name
    val entityId = team?.id ?: driver?.id
    return NewsParsed(entityName, entityId, component, before, after, delta, n.message)
}

@Composable
private fun NewsNotificationCard(n: MarketNotification) {
    val parsed = remember(n.season, n.week, n.title, n.message) { parseNews(n) }
    val isTeam = n.category == MarketNewsCategory.TEAM_EVOLUTION
    val isDriver = n.category == MarketNewsCategory.DRIVER_EVOLUTION
    val entityTeamId = if (isTeam) parsed.entityId else if (isDriver && parsed.entityId != null) {
        WorldDatabase.allDrivers.firstOrNull { it.id == parsed.entityId }?.teamId
    } else null
    val teamName = entityTeamId?.let { id -> WorldDatabase.teams.firstOrNull { it.id == id }?.name }

    Card(
        Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1B1416)),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(Modifier.fillMaxWidth().padding(12.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
                Box(Modifier.size(58.dp), contentAlignment = Alignment.Center) {
                    when {
                        isTeam && parsed.entityId != null -> TeamLogo(parsed.entityName ?: "", parsed.entityId, Modifier.size(48.dp))
                        isDriver && parsed.entityId != null -> DriverPhoto(parsed.entityId, parsed.entityName ?: "", Modifier.size(48.dp).clip(RoundedCornerShape(10.dp)))
                        else -> NewsCategoryGlyph(n.category, Modifier.size(42.dp))
                    }
                }
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        parsed.entityName ?: newsEntityFallback(n.category),
                        color = Color.White,
                        fontWeight = FontWeight.Black,
                        fontSize = 15.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        n.title,
                        color = Red,
                        fontWeight = FontWeight.Black,
                        fontSize = 9.sp,
                        modifier = Modifier.padding(top = 2.dp),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                if (parsed.delta != null) {
                    val positive = parsed.delta >= 0
                    Column(horizontalAlignment = Alignment.End) {
                        Text(if (positive) "▲ +${parsed.delta}" else "▼ ${parsed.delta}", color = if (positive) Green else Red, fontWeight = FontWeight.Black, fontSize = 12.sp)
                        if (parsed.before != null && parsed.after != null) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(parsed.before.toString(), color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Black)
                                Text("  ${if (positive) "→" else "→"}  ", color = if (positive) Green else Red, fontSize = 17.sp, fontWeight = FontWeight.Black)
                                Text(parsed.after.toString(), color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Black)
                            }
                        }
                    }
                }
            }

            if (isTeam && parsed.component != null) {
                Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    ComponentIcon(parsed.component, Modifier.size(26.dp))
                    Spacer(Modifier.width(7.dp))
                    Text(componentLabel(parsed.component).uppercase(), color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Medium)
                    Spacer(Modifier.weight(1f))
                    Text("P&D", color = Muted, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                }
            } else if (isDriver && teamName != null) {
                Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    TeamLogo(teamName, entityTeamId ?: 0, Modifier.size(24.dp))
                    Spacer(Modifier.width(7.dp))
                    Text(teamName.uppercase(), color = Muted, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.weight(1f))
                    Text("EVOLUÇÃO", color = Muted, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                }
            }

            Text(
                n.message,
                color = Color.White,
                fontSize = 10.sp,
                lineHeight = 16.sp,
                modifier = Modifier.padding(top = 8.dp)
            )
        }
    }
}

private fun newsEntityFallback(category: MarketNewsCategory) = when (category) {
    MarketNewsCategory.MARKET -> "Mercado de pilotos"
    MarketNewsCategory.DRIVER_EVOLUTION -> "Evolução dos pilotos"
    MarketNewsCategory.TEAM_EVOLUTION -> "Evolução das equipes"
    MarketNewsCategory.ANNUAL_EVENTS -> "Temporada"
}

@Composable
private fun NewsCategoryGlyph(category: MarketNewsCategory, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val c = Red
        when (category) {
            MarketNewsCategory.MARKET -> {
                drawRoundRect(c, topLeft = androidx.compose.ui.geometry.Offset(size.width*.18f,size.height*.28f), size = androidx.compose.ui.geometry.Size(size.width*.64f,size.height*.54f), cornerRadius = androidx.compose.ui.geometry.CornerRadius(6f,6f), style = androidx.compose.ui.graphics.drawscope.Stroke(width=3f))
                drawLine(c, androidx.compose.ui.geometry.Offset(size.width*.28f,size.height*.18f), androidx.compose.ui.geometry.Offset(size.width*.72f,size.height*.18f), strokeWidth=3f)
                drawLine(c, androidx.compose.ui.geometry.Offset(size.width*.32f,size.height*.45f), androidx.compose.ui.geometry.Offset(size.width*.68f,size.height*.45f), strokeWidth=3f)
            }
            MarketNewsCategory.DRIVER_EVOLUTION -> {
                drawCircle(c, size.minDimension*.24f, androidx.compose.ui.geometry.Offset(size.width*.5f,size.height*.34f), style=androidx.compose.ui.graphics.drawscope.Stroke(width=3f))
                drawArc(color=c, startAngle=200f, sweepAngle=140f, useCenter=false, topLeft=androidx.compose.ui.geometry.Offset(size.width*.18f,size.height*.30f), size=androidx.compose.ui.geometry.Size(size.width*.64f,size.height*.58f), style=androidx.compose.ui.graphics.drawscope.Stroke(width=3f))
                drawLine(Green, androidx.compose.ui.geometry.Offset(size.width*.28f,size.height*.78f), androidx.compose.ui.geometry.Offset(size.width*.48f,size.height*.58f), strokeWidth=4f)
                drawLine(Green, androidx.compose.ui.geometry.Offset(size.width*.48f,size.height*.58f), androidx.compose.ui.geometry.Offset(size.width*.72f,size.height*.42f), strokeWidth=4f)
            }
            MarketNewsCategory.TEAM_EVOLUTION -> {
                drawRoundRect(c, topLeft=androidx.compose.ui.geometry.Offset(size.width*.18f,size.height*.30f), size=androidx.compose.ui.geometry.Size(size.width*.64f,size.height*.42f), cornerRadius=androidx.compose.ui.geometry.CornerRadius(6f,6f), style=androidx.compose.ui.graphics.drawscope.Stroke(width=3f))
                drawLine(c, androidx.compose.ui.geometry.Offset(size.width*.30f,size.height*.30f), androidx.compose.ui.geometry.Offset(size.width*.36f,size.height*.18f), strokeWidth=3f)
                drawLine(c, androidx.compose.ui.geometry.Offset(size.width*.70f,size.height*.30f), androidx.compose.ui.geometry.Offset(size.width*.64f,size.height*.18f), strokeWidth=3f)
                drawLine(Green, androidx.compose.ui.geometry.Offset(size.width*.36f,size.height*.58f), androidx.compose.ui.geometry.Offset(size.width*.50f,size.height*.44f), strokeWidth=4f)
                drawLine(Green, androidx.compose.ui.geometry.Offset(size.width*.50f,size.height*.44f), androidx.compose.ui.geometry.Offset(size.width*.68f,size.height*.58f), strokeWidth=4f)
            }
            MarketNewsCategory.ANNUAL_EVENTS -> {
                drawRoundRect(c, topLeft=androidx.compose.ui.geometry.Offset(size.width*.18f,size.height*.24f), size=androidx.compose.ui.geometry.Size(size.width*.64f,size.height*.58f), cornerRadius=androidx.compose.ui.geometry.CornerRadius(5f,5f), style=androidx.compose.ui.graphics.drawscope.Stroke(width=3f))
                drawLine(c, androidx.compose.ui.geometry.Offset(size.width*.30f,size.height*.12f), androidx.compose.ui.geometry.Offset(size.width*.30f,size.height*.34f), strokeWidth=4f)
                drawLine(c, androidx.compose.ui.geometry.Offset(size.width*.70f,size.height*.12f), androidx.compose.ui.geometry.Offset(size.width*.70f,size.height*.34f), strokeWidth=4f)
                drawLine(c, androidx.compose.ui.geometry.Offset(size.width*.22f,size.height*.40f), androidx.compose.ui.geometry.Offset(size.width*.78f,size.height*.40f), strokeWidth=3f)
            }
        }
    }
}

@Composable
private fun ComponentIcon(component: CarComponent, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val c = Color.White
        val r = Red
        when (component) {
            CarComponent.ENGINE -> {
                drawRoundRect(r, topLeft=androidx.compose.ui.geometry.Offset(size.width*.18f,size.height*.28f), size=androidx.compose.ui.geometry.Size(size.width*.64f,size.height*.44f), cornerRadius=androidx.compose.ui.geometry.CornerRadius(6f,6f), style=androidx.compose.ui.graphics.drawscope.Stroke(width=3f))
                drawLine(r, androidx.compose.ui.geometry.Offset(size.width*.08f,size.height*.50f), androidx.compose.ui.geometry.Offset(size.width*.20f,size.height*.50f), strokeWidth=4f)
                drawLine(r, androidx.compose.ui.geometry.Offset(size.width*.80f,size.height*.50f), androidx.compose.ui.geometry.Offset(size.width*.94f,size.height*.50f), strokeWidth=4f)
                drawCircle(c,size.minDimension*.10f,androidx.compose.ui.geometry.Offset(size.width*.50f,size.height*.50f))
            }
            CarComponent.CHASSIS -> {
                val p=androidx.compose.ui.graphics.Path().apply { moveTo(size.width*.12f,size.height*.70f); lineTo(size.width*.28f,size.height*.30f); lineTo(size.width*.72f,size.height*.30f); lineTo(size.width*.88f,size.height*.70f); close() }
                drawPath(p,r,style=androidx.compose.ui.graphics.drawscope.Stroke(width=3f))
                drawLine(c,androidx.compose.ui.geometry.Offset(size.width*.32f,size.height*.50f),androidx.compose.ui.geometry.Offset(size.width*.68f,size.height*.50f),strokeWidth=3f)
            }
            CarComponent.FRONT_WING -> {
                drawLine(c,androidx.compose.ui.geometry.Offset(size.width*.10f,size.height*.38f),androidx.compose.ui.geometry.Offset(size.width*.90f,size.height*.38f),strokeWidth=4f)
                drawLine(c,androidx.compose.ui.geometry.Offset(size.width*.20f,size.height*.58f),androidx.compose.ui.geometry.Offset(size.width*.80f,size.height*.58f),strokeWidth=3f)
                drawLine(r,androidx.compose.ui.geometry.Offset(size.width*.18f,size.height*.38f),androidx.compose.ui.geometry.Offset(size.width*.28f,size.height*.70f),strokeWidth=3f)
                drawLine(r,androidx.compose.ui.geometry.Offset(size.width*.82f,size.height*.38f),androidx.compose.ui.geometry.Offset(size.width*.72f,size.height*.70f),strokeWidth=3f)
            }
            CarComponent.REAR_WING -> {
                drawLine(c,androidx.compose.ui.geometry.Offset(size.width*.16f,size.height*.30f),androidx.compose.ui.geometry.Offset(size.width*.84f,size.height*.30f),strokeWidth=4f)
                drawLine(c,androidx.compose.ui.geometry.Offset(size.width*.24f,size.height*.52f),androidx.compose.ui.geometry.Offset(size.width*.76f,size.height*.52f),strokeWidth=3f)
                drawLine(r,androidx.compose.ui.geometry.Offset(size.width*.28f,size.height*.30f),androidx.compose.ui.geometry.Offset(size.width*.34f,size.height*.76f),strokeWidth=3f)
                drawLine(r,androidx.compose.ui.geometry.Offset(size.width*.72f,size.height*.30f),androidx.compose.ui.geometry.Offset(size.width*.66f,size.height*.76f),strokeWidth=3f)
            }
            CarComponent.BRAKES -> {
                drawCircle(r,size.minDimension*.32f,androidx.compose.ui.geometry.Offset(size.width*.50f,size.height*.50f),style=androidx.compose.ui.graphics.drawscope.Stroke(width=3f))
                drawCircle(c,size.minDimension*.12f,androidx.compose.ui.geometry.Offset(size.width*.50f,size.height*.50f))
                for (i in 0 until 6) {
                    val a=Math.toRadians((i*60).toDouble())
                    val x1=size.width*.50f + kotlin.math.cos(a).toFloat()*size.width*.18f
                    val y1=size.height*.50f + kotlin.math.sin(a).toFloat()*size.height*.18f
                    val x2=size.width*.50f + kotlin.math.cos(a).toFloat()*size.width*.28f
                    val y2=size.height*.50f + kotlin.math.sin(a).toFloat()*size.height*.28f
                    drawLine(c,androidx.compose.ui.geometry.Offset(x1,y1),androidx.compose.ui.geometry.Offset(x2,y2),strokeWidth=2f)
                }
            }
            CarComponent.ELECTRIC_POWER_UNIT -> {
                val p=androidx.compose.ui.graphics.Path().apply { moveTo(size.width*.56f,size.height*.10f); lineTo(size.width*.24f,size.height*.54f); lineTo(size.width*.48f,size.height*.54f); lineTo(size.width*.40f,size.height*.90f); lineTo(size.width*.78f,size.height*.42f); lineTo(size.width*.54f,size.height*.42f); close() }
                drawPath(p,Green)
                drawPath(p,r,style=androidx.compose.ui.graphics.drawscope.Stroke(width=2f))
            }
        }
    }
}


private data class TeamOverviewSnapshot(
    val team: com.f1teammanager.core.season.TeamDefinition,
    val garage: com.f1teammanager.core.manager.TeamGarage,
    val facilities: TeamFacilitiesState,
    val budget: Long,
    val seasonIncome: Long,
    val seasonExpenses: Long,
    val annualTechnicalCap: Long,
    val position: Int,
    val points: Int
)

private fun teamOverviewSnapshot(
    team: com.f1teammanager.core.season.TeamDefinition,
    playerTeamId: Int,
    playerManagerState: TeamManagerState,
    currentWeek: Int,
    season: Int,
    aiFinance: AITeamFinancialEngine,
    aiDevelopment: AITeamDevelopmentEngine
): TeamOverviewSnapshot {
    if (team.id == playerTeamId) {
        val garage = playerManagerState.garage ?: TeamGarageFactory.fromInitial(team)
        val points = playerManagerState.let { /* player points are read by caller when needed */ 0 }
        return TeamOverviewSnapshot(team, garage, playerManagerState.facilities, playerManagerState.finance.budget, playerManagerState.finance.seasonIncome, playerManagerState.finance.seasonExpenses, playerManagerState.technicalInvestment.annualCap, 40, points)
    }
    val aiState = aiFinance.allStates().firstOrNull { it.teamId == team.id && it.season == season }
    val capacity = aiFinance.developmentCapacity(team.id, season)
    val simulated = aiDevelopment.simulateFinancial(team, (currentWeek - 1).coerceAtLeast(0), season, capacity)
    return TeamOverviewSnapshot(team, simulated.garage ?: TeamGarageFactory.fromInitial(team), simulated.facilities, aiState?.finance?.budget ?: InitialTeamProfile.initialBudget(team), aiState?.finance?.seasonIncome ?: 0L, aiState?.finance?.seasonExpenses ?: 0L, aiFinance.technicalInvestment(team.id, season).annualCap, 40, 0)
}

@Composable
private fun TeamOverviewScreen(
    store: CareerPreferences,
    playerTeamId: Int,
    playerManagerState: TeamManagerState,
    selectedTeamId: Int,
    currentWeek: Int,
    aiFinance: AITeamFinancialEngine,
    aiDevelopment: AITeamDevelopmentEngine,
    onBack: () -> Unit,
    onSelectTeam: (Int) -> Unit
) {
    val constructorPoints = store.constructorPoints()
    val allTeams = WorldDatabase.teams
    val aiFinanceStates = aiFinance.allStates()
    val snapshots = remember(store.season, currentWeek, playerManagerState.garage, playerManagerState.finance, playerManagerState.facilities, aiFinanceStates) {
        allTeams.map { t ->
            if (t.id == playerTeamId) {
                val g = playerManagerState.garage ?: TeamGarageFactory.fromInitial(t)
                TeamOverviewSnapshot(t, g, playerManagerState.facilities, playerManagerState.finance.budget, playerManagerState.finance.seasonIncome, playerManagerState.finance.seasonExpenses, playerManagerState.technicalInvestment.annualCap, 0, constructorPoints[t.id] ?: 0)
            } else {
                val aiState = aiFinanceStates.firstOrNull { it.teamId == t.id && it.season == store.season }
                val capacity = aiFinance.developmentCapacity(t.id, store.season)
                val sim = aiDevelopment.simulateFinancial(t, (currentWeek - 1).coerceAtLeast(0), store.season, capacity)
                TeamOverviewSnapshot(t, sim.garage ?: TeamGarageFactory.fromInitial(t), sim.facilities, aiState?.finance?.budget ?: InitialTeamProfile.initialBudget(t), aiState?.finance?.seasonIncome ?: 0L, aiState?.finance?.seasonExpenses ?: 0L, aiFinance.technicalInvestment(t.id, store.season).annualCap, 0, constructorPoints[t.id] ?: 0)
            }
        }
    }
    val ranking = remember(snapshots, constructorPoints) {
        snapshots.sortedWith(compareByDescending<TeamOverviewSnapshot> { it.garage.teamAverageOverall }
            .thenByDescending { it.points }
            .thenBy { it.team.id })
    }
    val index = ranking.indexOfFirst { it.team.id == selectedTeamId }.coerceAtLeast(0)
    val selected = ranking[index]
    val selectedTeam = selected.team
    val teamDrivers = store.currentDrivers().filter { it.teamId == selectedTeam.id }.take(2)
    val records = store.history.constructorSeasonRecords().filter { it.teamId == selectedTeam.id }.sortedByDescending { it.season }
    val currentPosition = if (selectedTeam.id == playerTeamId) {
        val rows = constructorPoints.entries.sortedWith(compareByDescending<Map.Entry<Int,Int>> { it.value }.thenBy { it.key })
        (rows.indexOfFirst { it.key == selectedTeam.id } + 1).coerceAtLeast(1)
    } else (constructorPoints.entries.sortedWith(compareByDescending<Map.Entry<Int,Int>> { it.value }.thenBy { it.key }).indexOfFirst { it.key == selectedTeam.id } + 1).coerceAtLeast(1)
    val generalRecords = records
    val allRaceRecords = store.history.raceRecords().filter { it.teamId == selectedTeam.id }
    val titles = store.history.constructorChampions().count { it.teamId == selectedTeam.id }
    val wins = allRaceRecords.count { it.position == 1 }
    val podiums = allRaceRecords.count { it.position in 1..3 }
    val poles = store.history.poleRecords().count { it.teamId == selectedTeam.id }
    val fastest = allRaceRecords.count { it.isFastestLap }
    val gps = allRaceRecords.map { it.round to it.season }.distinct().size
    val dnfs = allRaceRecords.count { it.status.startsWith("DNF") }
    val seasonRaceRecords = allRaceRecords.filter { it.season == store.season }
    val seasonWins = seasonRaceRecords.count { it.position == 1 }
    val seasonPodiums = seasonRaceRecords.count { it.position in 1..3 }
    val seasonFastest = seasonRaceRecords.count { it.isFastestLap }
    val seasonGps = seasonRaceRecords.map { it.round }.distinct().size
    val seasonDnfs = seasonRaceRecords.count { it.status.startsWith("DNF") }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        BackTopBar("EQUIPE", onBack)
        LazyColumn(
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item {
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(10.dp)) {
                    Row(Modifier.fillMaxWidth().height(128.dp), verticalAlignment = Alignment.CenterVertically) {
                        Button(onClick = { if (index > 0) onSelectTeam(ranking[index - 1].team.id) }, enabled = index > 0,
                            modifier = Modifier.width(54.dp).fillMaxHeight().padding(6.dp), shape = RoundedCornerShape(9.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Red, disabledContainerColor = Panel2, contentColor = Color.White, disabledContentColor = Muted),
                            contentPadding = PaddingValues(0.dp)) { Text("‹", fontSize = 34.sp, fontWeight = FontWeight.Black) }
                        TeamLogo(selectedTeam.name, selectedTeam.id, Modifier.size(86.dp))
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Text(selectedTeam.name, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Black, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text("${selectedTeam.country}  •  POSIÇÃO ${index + 1}/40", color = Muted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            Text("Desempenho ${selected.garage.teamAverageOverall}", color = Red, fontSize = 11.sp, fontWeight = FontWeight.Black)
                            Text("Pontos ${selected.points}  •  Campeonato ${currentPosition}º", color = Color.White, fontSize = 9.sp)
                        }
                        Button(onClick = { if (index < ranking.lastIndex) onSelectTeam(ranking[index + 1].team.id) }, enabled = index < ranking.lastIndex,
                            modifier = Modifier.width(54.dp).fillMaxHeight().padding(6.dp), shape = RoundedCornerShape(9.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Red, disabledContainerColor = Panel2, contentColor = Color.White, disabledContentColor = Muted),
                            contentPadding = PaddingValues(0.dp)) { Text("›", fontSize = 34.sp, fontWeight = FontWeight.Black) }
                    }
                }
            }
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TeamOverviewBudgetCard("ORÇAMENTO", selected.budget, selected.seasonIncome, selected.seasonExpenses, selected.annualTechnicalCap, Modifier.weight(1f))
                    TeamOverviewGeneralCard("DESEMPENHO GERAL", titles, wins, podiums, poles, fastest, gps, dnfs, Modifier.weight(1f))
                }
            }
            item { TeamOverviewFacilities(selected.facilities) }
            item { TeamOverviewCarShowcase(selectedTeam.id, selectedTeam.name, selected.garage) }
            item { TeamOverviewDrivers(teamDrivers) }
            item { TeamOverviewCars(selected.garage) }
            item { TeamOverviewSeason(store, selectedTeam.id, constructorPoints, selectedTeam.name, seasonWins, seasonPodiums, poles, seasonFastest, seasonGps, seasonDnfs) }
            item { TeamOverviewHistory(records) }
        }
    }
}

@Composable private fun TeamOverviewBudgetCard(title:String, budget:Long, income:Long, expenses:Long, annualTechnicalCap:Long, modifier:Modifier) {
    Card(modifier, colors=CardDefaults.cardColors(containerColor=Panel), shape=RoundedCornerShape(9.dp)) {
        Column(Modifier.padding(10.dp)) {
            Text("▣  $title", color=Color.White, fontSize=12.sp, fontWeight=FontWeight.Black)
            Text("Saldo atual", color=Muted, fontSize=9.sp, modifier=Modifier.padding(top=7.dp))
            Text(formatMoney(budget), color=Color.White, fontSize=16.sp, fontWeight=FontWeight.Black)
            Text("Receita da temporada", color=Muted, fontSize=8.sp, modifier=Modifier.padding(top=5.dp))
            Text(formatMoney(income), color=Green, fontSize=10.sp, fontWeight=FontWeight.Black)
            Text("Despesa da temporada", color=Muted, fontSize=8.sp, modifier=Modifier.padding(top=4.dp))
            Text(formatMoney(expenses), color=Red, fontSize=10.sp, fontWeight=FontWeight.Black)
            Text("Limite técnico anual", color=Muted, fontSize=8.sp, modifier=Modifier.padding(top=4.dp))
            Text(formatMoney(annualTechnicalCap), color=Color.White, fontSize=10.sp, fontWeight=FontWeight.Black)
        }
    }
}

@Composable private fun TeamOverviewGeneralCard(title:String, titles:Int, wins:Int, podiums:Int, poles:Int, fastest:Int, gps:Int, dnfs:Int, modifier:Modifier) {
    Card(modifier, colors=CardDefaults.cardColors(containerColor=Panel), shape=RoundedCornerShape(9.dp)) {
        Column(Modifier.fillMaxSize().padding(10.dp), verticalArrangement=Arrangement.spacedBy(7.dp)) {
            Text("🏆  $title", color=Color.White, fontSize=12.sp, fontWeight=FontWeight.Black)
            val metrics = listOf("Títulos" to titles, "Vitórias" to wins, "Pódios" to podiums, "Poles" to poles, "Voltas + rápidas" to fastest, "Corridas" to gps, "DNFs" to dnfs, "Melhor resultado" to 0, "Média de chegada" to 0)
            metrics.chunked(3).forEach { row ->
                Row(Modifier.weight(1f).fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(4.dp)) {
                    row.forEach { (label, value) ->
                        Column(Modifier.weight(1f).fillMaxHeight().background(Panel2, RoundedCornerShape(6.dp)).padding(4.dp), horizontalAlignment=Alignment.CenterHorizontally, verticalArrangement=Arrangement.Center) {
                            Text(label, color=Muted, fontSize=7.sp, textAlign=TextAlign.Center, maxLines=2, overflow=TextOverflow.Clip)
                            Text(if (label == "Melhor resultado" || label == "Média de chegada") "–" else value.toString(), color=Color.White, fontWeight=FontWeight.Black, fontSize=10.sp, modifier=Modifier.padding(top=2.dp))
                        }
                    }
                    repeat(3-row.size) { Spacer(Modifier.weight(1f)) }
                }
            }
        }
    }
}

@Composable private fun TeamOverviewFacilities(f:TeamFacilitiesState) {
    val items = listOf(
        FacilityType.FACTORY to "Fábrica",
        FacilityType.RESEARCH to "P&D",
        FacilityType.WIND_TUNNEL to "Túnel de Vento",
        FacilityType.SIMULATOR to "Simulador",
        FacilityType.MARKETING to "Centro Comercial",
        FacilityType.SCOUTING to "Scouting"
    )
    Card(Modifier.fillMaxWidth(), colors=CardDefaults.cardColors(containerColor=Panel), shape=RoundedCornerShape(9.dp)) {
        Column(Modifier.padding(10.dp)) {
            Text("▮ INSTALAÇÕES", color=Color.White, fontSize=12.sp, fontWeight=FontWeight.Black)
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(top=7.dp), horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                items.forEach { (type,label) ->
                    val level=f.level(type)
                    Column(Modifier.width(92.dp).background(Panel2,RoundedCornerShape(7.dp)).padding(7.dp), horizontalAlignment=Alignment.CenterHorizontally) {
                        Text(label,color=Color.White,fontSize=8.sp,fontWeight=FontWeight.Black,maxLines=2,textAlign=TextAlign.Center)
                        Text("Nível $level",color=Muted,fontSize=8.sp,modifier=Modifier.padding(top=4.dp))
                        LinearProgressIndicator(progress={level/10f},modifier=Modifier.fillMaxWidth().height(4.dp).padding(top=5.dp),color=Red,trackColor=Line)
                    }
                }
            }
        }
    }
}

@Composable private fun TeamOverviewCarShowcase(teamId:Int, teamName:String, garage:TeamGarage) {
    Card(Modifier.fillMaxWidth(), colors=CardDefaults.cardColors(containerColor=Panel), shape=RoundedCornerShape(9.dp)) {
        Column(Modifier.padding(10.dp)) {
            Row(verticalAlignment=Alignment.CenterVertically, horizontalArrangement=Arrangement.spacedBy(7.dp)) {
                Text("🏎", fontSize=15.sp)
                Text("CARROS DA EQUIPE", color=Color.White, fontSize=12.sp, fontWeight=FontWeight.Black)
                Spacer(Modifier.weight(1f))
                Text("GERAL ${garage.teamAverageOverall}", color=Red, fontSize=10.sp, fontWeight=FontWeight.Black)
            }
            Row(Modifier.fillMaxWidth().padding(top=7.dp), horizontalArrangement=Arrangement.spacedBy(7.dp)) {
                listOf("CARRO 1" to garage.car1, "CARRO 2" to garage.car2).forEach { (label, car) ->
                    Column(Modifier.weight(1f).background(Panel2, RoundedCornerShape(7.dp)).border(1.dp, Line, RoundedCornerShape(7.dp)).padding(6.dp)) {
                        Row(verticalAlignment=Alignment.CenterVertically) {
                            Text(label, color=Color.White, fontSize=9.sp, fontWeight=FontWeight.Black)
                            Spacer(Modifier.weight(1f))
                            Text("${car.overall}", color=Red, fontSize=12.sp, fontWeight=FontWeight.Black)
                        }
                        TeamCarCompact(teamId, teamName, Modifier.fillMaxWidth().height(48.dp).padding(top=2.dp))
                        Text("Confiabilidade ${car.reliability}", color=Muted, fontSize=8.sp, modifier=Modifier.padding(top=2.dp))
                    }
                }
            }
        }
    }
}

@Composable private fun TeamOverviewDrivers(drivers:List<com.f1teammanager.core.season.DriverDefinition>) {
    Card(Modifier.fillMaxWidth(), colors=CardDefaults.cardColors(containerColor=Panel), shape=RoundedCornerShape(9.dp)) {
        Column(Modifier.padding(10.dp)) {
            Text("👤 PILOTOS",color=Color.White,fontSize=12.sp,fontWeight=FontWeight.Black)
            Row(Modifier.fillMaxWidth().padding(top=7.dp),horizontalArrangement=Arrangement.spacedBy(7.dp)) {
                drivers.forEach { d ->
                    Row(Modifier.weight(1f).height(76.dp).background(Panel2,RoundedCornerShape(7.dp)).padding(6.dp),verticalAlignment=Alignment.CenterVertically) {
                        DriverPhoto(d.id,d.name,Modifier.size(48.dp).clip(RoundedCornerShape(5.dp)))
                        Column(Modifier.padding(start=7.dp).weight(1f)) {
                            Text(d.name,color=Color.White,fontSize=9.sp,fontWeight=FontWeight.Black,maxLines=2,overflow=TextOverflow.Clip, lineHeight=11.sp)
                            Text("Geral ${((d.speed + d.qualifying + d.overtaking + d.defense + d.consistency + d.wet + d.tyre + 3) / 7)}",color=Muted,fontSize=8.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable private fun TeamOverviewCars(g:TeamGarage) {
    Card(Modifier.fillMaxWidth(), colors=CardDefaults.cardColors(containerColor=Panel), shape=RoundedCornerShape(9.dp)) {
        Column(Modifier.padding(10.dp)) {
            Text("⚙ ATRIBUTOS DOS CARROS",color=Color.White,fontSize=12.sp,fontWeight=FontWeight.Black)
            Row(Modifier.fillMaxWidth().padding(top=6.dp),horizontalArrangement=Arrangement.spacedBy(7.dp)) {
                listOf("CARRO 1" to g.car1, "CARRO 2" to g.car2).forEach { (label,c) ->
                    Column(Modifier.weight(1f).background(Panel2,RoundedCornerShape(7.dp)).padding(7.dp)) {
                        Text(label,color=Red,fontSize=9.sp,fontWeight=FontWeight.Black)
                        listOf("Unidade de potência" to c.engine,"Chassi" to c.chassis,"Asa dianteira" to c.frontWing,"Asa traseira" to c.rearWing,"Freios" to c.brakes,"Unidade elétrica" to c.electricPowerUnit).forEach { (n,v) ->
                            Row(Modifier.fillMaxWidth().padding(top=4.dp),verticalAlignment=Alignment.CenterVertically){ Text(n,color=Muted,fontSize=7.sp,modifier=Modifier.weight(1f)); LinearProgressIndicator(progress={v/100f},modifier=Modifier.width(55.dp).height(4.dp),color=Red,trackColor=Line); Text(v.toString(),color=Color.White,fontSize=8.sp,fontWeight=FontWeight.Black,modifier=Modifier.width(20.dp),textAlign=TextAlign.End) }
                        }
                    }
                }
            }
        }
    }
}

@Composable private fun TeamOverviewSeason(store:CareerPreferences, teamId:Int, constructorPoints:Map<Int,Int>, teamName:String, wins:Int, podiums:Int, poles:Int, fastest:Int, gps:Int, dnfs:Int) {
    val points=constructorPoints[teamId] ?: 0
    val pos=constructorPoints.entries.sortedWith(compareByDescending<Map.Entry<Int,Int>>{it.value}.thenBy{it.key}).indexOfFirst{it.key==teamId}+1
    Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=Panel),shape=RoundedCornerShape(9.dp)){
        Column(Modifier.padding(10.dp)){
            Text("▮ DESEMPENHO NA TEMPORADA ${store.season}",color=Color.White,fontSize=12.sp,fontWeight=FontWeight.Black)
            val vals=listOf("Posição" to pos.coerceAtLeast(1).toString(),"Pontos" to points.toString(),"Vitórias" to wins.toString(),"Pódios" to podiums.toString(),"Poles" to poles.toString(),"Voltas + rápidas" to fastest.toString(),"Corridas" to gps.toString(),"DNFs" to dnfs.toString())
            vals.chunked(4).forEach { row -> Row(Modifier.fillMaxWidth().padding(top=6.dp)){row.forEach{(l,v)->Column(Modifier.weight(1f),horizontalAlignment=Alignment.CenterHorizontally){Text(l,color=Muted,fontSize=7.sp,textAlign=TextAlign.Center);Text(v,color=Color.White,fontSize=13.sp,fontWeight=FontWeight.Black,modifier=Modifier.padding(top=2.dp))}}}}
        }
    }
}

@Composable private fun TeamOverviewHistory(records:List<HistoricalDatabase.ConstructorSeasonRecord>) {
    Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=Panel),shape=RoundedCornerShape(9.dp)){
        Column(Modifier.padding(10.dp)){
            Text("🏆 HISTÓRICO POR TEMPORADA",color=Color.White,fontSize=12.sp,fontWeight=FontWeight.Black)
            if(records.isEmpty()) Text("Nenhuma temporada encerrada registrada.",color=Muted,fontSize=9.sp,modifier=Modifier.padding(top=8.dp))
            else {
                Row(Modifier.fillMaxWidth().padding(top=7.dp).horizontalScroll(rememberScrollState())) {
                    listOf("TEMPORADA" to 54,"POS" to 34,"PONTOS" to 44,"VITÓRIAS" to 44,"POLES" to 38,"V+R" to 38,"CORRIDAS" to 48,"DNFs" to 34).forEach{(h,w)->Text(h,color=Muted,fontSize=7.sp,fontWeight=FontWeight.Black,modifier=Modifier.width(w.dp))}
                }
                records.forEach { r ->
                    Row(Modifier.fillMaxWidth().padding(top=5.dp).horizontalScroll(rememberScrollState())) {
                        listOf(r.season.toString(),r.position.toString(),r.points.toString(),r.wins.toString(),r.poles.toString(),r.fastestLaps.toString(),r.gps.toString(),r.dnf.toString()).forEachIndexed{idx,v->Text(v,color=if(idx==1 && r.position==1) Color(0xFFFFC400) else Color.White,fontSize=8.sp,fontWeight=if(idx==1||idx==0)FontWeight.Black else FontWeight.Normal,modifier=Modifier.width(listOf(54,34,44,44,38,38,48,34)[idx].dp))}
                    }
                }
            }
        }
    }
}

@Composable
private fun ManagementHub(
    raceActive: Boolean,
    onDrivers: () -> Unit,
    onMarket: () -> Unit,
    onFinance: () -> Unit,
    onSeason: () -> Unit,
    onCar: () -> Unit,
    onStandings: () -> Unit,
    onCalendar: () -> Unit,
    onWeekend: () -> Unit,
    onTeams: () -> Unit,
    onRace: () -> Unit,
    onHistory: () -> Unit,
    onNews: () -> Unit,
    onHallOfFame: () -> Unit,
    onRecords: () -> Unit
) {
    val actions = listOf(
        "FIM DE SEMANA" to onWeekend,
        "EQUIPES" to onTeams,
        "PILOTOS" to onDrivers,
        "MERCADO" to onMarket,
        "CENTRAL DE NOTÍCIAS" to onNews,
        "CARRO / P&D" to onCar,
        "CAMPEONATO" to onStandings,
        "CALENDÁRIO" to onCalendar,
        "FINANÇAS" to onFinance,
        "TEMPORADA" to onSeason,
        "HISTÓRIA" to onHistory,
        "HALL DA FAMA" to onHallOfFame,
        "RECORDES" to onRecords
    )
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        HeaderBlock("CENTRAL DE GESTÃO", if (raceActive) "CORRIDA ATIVA" else "TEMPORADA")
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(vertical = 10.dp)) {
            items(actions) { (label, action) ->
                Button(onClick = action, modifier = Modifier.fillMaxWidth().height(46.dp), colors = ButtonDefaults.buttonColors(containerColor = if (label == "PIT WALL" && raceActive) Red else Panel2, contentColor = Color.White)) {
                    Text(label, fontWeight = FontWeight.Black, fontSize = 11.sp)
                }
            }
        }
    }
}

private fun strategyLabel(m:DriverStrategyMode)=when(m){DriverStrategyMode.ATTACK->"ATAQUE";DriverStrategyMode.BALANCED->"EQUILIBRADO";DriverStrategyMode.DEFENSE->"DEFESA / ECONOMIA"}
@Composable
private fun TyreCompoundIcon(tyre: Tyre, modifier: Modifier = Modifier) {
    val compoundColor = when (tyre) {
        Tyre.SOFT -> Color(0xFFE50914)
        Tyre.MEDIUM -> Color(0xFFFFD21F)
        Tyre.HARD -> Color(0xFFBFC3C9)
        Tyre.INTERMEDIATE -> Color(0xFF20C56B)
        Tyre.WET -> Color(0xFF168BFF)
    }
    Box(modifier.border(2.dp, compoundColor, RoundedCornerShape(50)), contentAlignment = Alignment.Center) {
        Box(Modifier.fillMaxSize(0.62f).border(1.dp, compoundColor, RoundedCornerShape(50)))
    }
}

private fun tyreLabel(t:Tyre)=when(t){Tyre.SOFT->"SOFT";Tyre.MEDIUM->"MEDIUM";Tyre.HARD->"HARD";Tyre.INTERMEDIATE->"INTER";Tyre.WET->"WET"}
private fun weatherLabel(w:Weather)=when(w){Weather.DRY->"☀️ SOL";Weather.CLOUDY->"☁️ NUBLADO";Weather.LIGHT_RAIN->"🌦️ CHUVA FRACA • INTERMEDIÁRIO";Weather.MEDIUM_RAIN->"🌧️ CHUVA MÉDIA • INTERMEDIÁRIO";Weather.HEAVY_RAIN->"🌧️ CHUVA FORTE • WET"}
private fun statusLabel(n:Neutralisation)=when(n){Neutralisation.GREEN->"GREEN FLAG";Neutralisation.VSC->"VSC";Neutralisation.SAFETY_CAR->"SAFETY CAR"}
private fun tyreLifeEstimate(tyre:Tyre, weather:Weather, mode:DriverStrategyMode, driverTyreWear:Int = 50):Int = tyre.targetLaps

private fun actionLabel(a:ManagerDecisionAction)=when(a){ManagerDecisionAction.BOX->"BOX";ManagerDecisionAction.STAY_OUT->"MANTER";ManagerDecisionAction.EXTEND_STINT->"ESTENDER STINT";ManagerDecisionAction.SAVE_FUEL->"POUPAR COMBUSTÍVEL";ManagerDecisionAction.CHANGE_STRATEGY->"MUDAR ESTRATÉGIA";ManagerDecisionAction.RESTART_ATTACK->"RELARGADA • ATAQUE";ManagerDecisionAction.RESTART_BALANCED->"RELARGADA • EQUILIBRADO";ManagerDecisionAction.RESTART_DEFENSE->"RELARGADA • DEFESA";ManagerDecisionAction.RESTART_PLAN_A->"PLANO A • RELARGADA";ManagerDecisionAction.RESTART_PLAN_B->"PLANO B • RELARGADA";ManagerDecisionAction.RESTART_PLAN_C->"PLANO C • RELARGADA";ManagerDecisionAction.RESTART_PLAN_D->"PLANO D • RELARGADA";ManagerDecisionAction.CHANGE_TYRE_SOFT->"SOFT";ManagerDecisionAction.CHANGE_TYRE_MEDIUM->"MEDIUM";ManagerDecisionAction.CHANGE_TYRE_HARD->"HARD";ManagerDecisionAction.CHANGE_TYRE_INTERMEDIATE->"INTERMEDIÁRIO";ManagerDecisionAction.CHANGE_TYRE_WET->"WET"}
private fun constructorPosition(teamId:Int, store:CareerPreferences): Int {
    val points = store.constructorPoints()
    val rows = WorldDatabase.teams.map { it.id to (points[it.id] ?: 0) }
        .sortedWith(compareByDescending<Pair<Int,Int>> { it.second }.thenBy { it.first })
    return rows.indexOfFirst { it.first == teamId }.let { if (it >= 0) it + 1 else WorldDatabase.teams.indexOfFirst { it.id == teamId } + 1 }
}
private fun driverChampionshipPosition(driverId:Int, store:CareerPreferences): Int {
    val points = store.driverPoints()
    val rows = WorldDatabase.drivers.map { it.id to (points[it.id] ?: 0) }
        .sortedWith(compareByDescending<Pair<Int,Int>> { it.second }.thenBy { it.first })
    return rows.indexOfFirst { it.first == driverId }.let { if (it >= 0) it + 1 else WorldDatabase.drivers.indexOfFirst { it.id == driverId } + 1 }
}

private fun planDescription(plan:TyrePlan?): String = plan?.let {
    it.sequence.indices.joinToString(" → ") { i -> "${tyreLabel(it.sequence[i])} ${it.stintLaps.getOrElse(i) { 0 }}v" }
} ?: "Plano indisponível"

@Composable
private fun SectionTitle(title:String) {
    Text(
        title,
        color = Red,
        fontSize = 11.sp,
        fontWeight = FontWeight.Black,
        modifier = Modifier.padding(top = 2.dp, bottom = 1.dp)
    )
}

@Composable
private fun StatCard(title:String, value:String, subtitle:String, modifier:Modifier = Modifier) {
    Column(
        modifier = modifier
            .background(Panel2, RoundedCornerShape(8.dp))
            .padding(9.dp)
    ) {
        Text(title, color = Muted, fontSize = 8.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(value, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Black, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 3.dp))
        Text(subtitle, color = Muted, fontSize = 8.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 2.dp))
    }
}

@Composable
private fun HeaderBlock(title:String, subtitle:String) {
    Column(Modifier.fillMaxWidth().padding(bottom = 6.dp)) {
        Text(title, color=Color.White, fontSize=22.sp, fontWeight=FontWeight.Black, maxLines=1, overflow=TextOverflow.Ellipsis)
        Text(subtitle, color=Red, fontSize=10.sp, fontWeight=FontWeight.Bold)
    }
}

private fun formatMoney(value:Long):String {
    val sign = if (value < 0) "-" else ""
    val abs = kotlin.math.abs(value)
    return when {
        abs >= 1_000_000L -> {
            val millions = abs / 1_000_000L
            val thousands = (abs % 1_000_000L) / 1_000L
            if (thousands == 0L) "€ ${sign}${millions} M"
            else "€ ${sign}${millions},${(thousands / 100).coerceAtLeast(1)} M"
        }
        abs >= 1_000L -> "€ ${sign}${abs / 1_000L} mil"
        else -> "€ ${sign}${abs}"
    }
}

private fun formatMs(ms:Long)=if(ms==Long.MAX_VALUE) "—" else "%d:%02d.%03d".format(ms/60000,(ms/1000)%60,ms%1000)
