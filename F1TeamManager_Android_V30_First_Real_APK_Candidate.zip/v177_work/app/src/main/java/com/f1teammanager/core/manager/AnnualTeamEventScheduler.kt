package com.f1teammanager.core.manager

import kotlin.random.Random

/**
 * Weekly orchestration primitives for annual team events.
 * The caller must persist processedWeekKeys and event IDs in the career save transaction.
 * This scheduler deliberately returns a plan instead of mutating global career state.
 */
object AnnualTeamEventScheduler {
    data class WeekContext(
        val season: Int,
        val week: Int,
        val isQualifyingOrRaceScreen: Boolean,
        val seed: Int,
        val teams: List<AnnualTeamEventEngine.TeamSnapshot>,
        val processedWeekKeys: Set<String>,
        val processedEventIds: Set<String>,
        val acquisitionUsedThisSeason: Boolean,
        val classChangeUsedThisSeason: Boolean
    )

    data class PlannedEvent(
        val event: AnnualTeamEventEngine.Event,
        val teamResult: AnnualTeamEventEngine.TeamResult
    )

    data class WeekPlan(
        val weekKey: String,
        val shouldPersistWeekKey: Boolean,
        val events: List<PlannedEvent>,
        val acquisitionUsedThisSeason: Boolean,
        val classChangeUsedThisSeason: Boolean
    )

    /** Returns no plan for invalid weeks, sports screens, or an already-processed week. */
    fun plan(context: WeekContext): WeekPlan? {
        if (!AnnualTeamEventEngine.canApplyWeeklyEvent(
                context.season, context.week, context.isQualifyingOrRaceScreen
            )) return null
        val weekKey = AnnualTeamEventEngine.weekLedgerKey(context.season, context.week)
        if (weekKey in context.processedWeekKeys) return null

        val rng = Random(context.seed.toLong() + context.season * 4001L + context.week * 211L)
        val events = mutableListOf<PlannedEvent>()
        var acquisitionUsed = context.acquisitionUsedThisSeason
        var classChangeUsed = context.classChangeUsedThisSeason

        // Events are selected once for the season and assigned to fixed weeks. The
        // deterministic calendar prevents a fresh occurrence roll on every week.
        val seasonCalendar = AnnualTeamEventSeasonCalendar.generate(context.season, context.seed)
        val scheduled = seasonCalendar.filter { it.week == context.week }
        if (context.teams.isNotEmpty()) {
            for (slot in scheduled) {
                val team = weightedTeam(context.teams, rng) ?: context.teams[rng.nextInt(context.teams.size)]
                val result = when (slot.kind) {
                    AnnualTeamEventEngine.Kind.FINANCIAL_CRISIS -> AnnualTeamEventEngine.applyFinancialCrisis(team, context.season, context.week)
                    AnnualTeamEventEngine.Kind.FIRE -> AnnualTeamEventEngine.applyFacilityDamage(team, context.season, context.week, earthquake = false, seed = rng.nextInt())
                    AnnualTeamEventEngine.Kind.EARTHQUAKE -> AnnualTeamEventEngine.applyFacilityDamage(team, context.season, context.week, earthquake = true, seed = rng.nextInt())
                    AnnualTeamEventEngine.Kind.CAR_GAIN -> AnnualTeamEventEngine.applyCarEvent(team, context.season, context.week, true, rng.nextInt())
                    AnnualTeamEventEngine.Kind.CAR_LOSS -> AnnualTeamEventEngine.applyCarEvent(team, context.season, context.week, false, rng.nextInt())
                    AnnualTeamEventEngine.Kind.RELIABILITY_GAIN -> AnnualTeamEventEngine.applyReliabilityEvent(team, context.season, context.week, true, rng.nextInt())
                    AnnualTeamEventEngine.Kind.RELIABILITY_LOSS -> AnnualTeamEventEngine.applyReliabilityEvent(team, context.season, context.week, false, rng.nextInt())
                    else -> null // Annual special events are handled in their own branch below.
                }
                if (result != null) addIfNew(events, result, context.processedEventIds)
            }
        }

        // Acquisition: one chance per season, only on a weekly management transition.
        if (context.week == seasonCalendar.firstOrNull { it.kind == AnnualTeamEventEngine.Kind.INVESTOR_ACQUISITION }?.week && !acquisitionUsed) {
            val eligible = context.teams.filter { t -> t.facilities.values.count { it < 10 } >= 2 }
            val selected = weightedTeam(eligible, rng)
            if (selected != null) {
                val result = AnnualTeamEventEngine.applyAcquisition(selected, context.season, context.week, rng.nextInt())
                if (addIfNew(events, result, context.processedEventIds)) acquisitionUsed = true
            }
        }

        // A class-change opportunity is reserved here; actual persistent driver-class mutation
        // must be applied by the career repository, which owns the canonical 100-driver roster.
        if (context.week == seasonCalendar.firstOrNull { it.kind == AnnualTeamEventEngine.Kind.DRIVER_CLASS_CHANGE }?.week && !classChangeUsed) {
            classChangeUsed = true
            val event = AnnualTeamEventEngine.Event(
                id = "annual:${context.season}:driver-class-opportunity",
                season = context.season,
                week = context.week,
                teamId = 0,
                kind = AnnualTeamEventEngine.Kind.DRIVER_CLASS_CHANGE,
                title = "OPORTUNIDADE DE MUDANÇA DE CLASSE",
                description = "Oportunidade anual sorteada; o repositório da carreira deve selecionar um dos 100 pilotos elegíveis e persistir a nova classe sem alterar seus atributos."
            )
            if (event.id !in context.processedEventIds) events.add(
                PlannedEvent(event, AnnualTeamEventEngine.TeamResult(0L, emptyMap(), emptyCarPlaceholder(), event))
            )
        }

        return WeekPlan(weekKey, true, events, acquisitionUsed, classChangeUsed)
    }

    private fun addIfNew(
        target: MutableList<PlannedEvent>,
        result: AnnualTeamEventEngine.TeamResult,
        alreadyProcessed: Set<String>
    ): Boolean {
        val event = result.event ?: return false
        if (AnnualTeamEventEngine.eventLedgerKey(event) in alreadyProcessed || target.any { it.event.id == event.id }) return false
        target.add(PlannedEvent(event, result))
        return true
    }

    private fun weightedTeam(
        teams: List<AnnualTeamEventEngine.TeamSnapshot>,
        rng: Random
    ): AnnualTeamEventEngine.TeamSnapshot? {
        val weighted = teams.map { it to AnnualTeamEventEngine.selectionWeight(it.strengthRank, it.teamCount) }
            .filter { it.second > 0 }
        if (weighted.isEmpty()) return null
        val total = weighted.sumOf { it.second }
        var draw = rng.nextInt(total)
        for ((team, weight) in weighted) {
            draw -= weight
            if (draw < 0) return team
        }
        return weighted.last().first
    }

    // The plan for a class-change opportunity has no team mutation. The repository should ignore
    // this placeholder state and apply only the event after committing the pilot class change.
    private fun emptyCarPlaceholder(): TeamCarState = TeamCarState(
        aerodynamics = 1, chassis = 1, engine = 1, reliability = 1,
        frontWing = 1, rearWing = 1, brakes = 1, electricPowerUnit = 1
    )
}
