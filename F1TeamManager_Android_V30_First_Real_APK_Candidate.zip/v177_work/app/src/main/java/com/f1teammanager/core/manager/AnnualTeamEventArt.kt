package com.f1teammanager.core.manager

import androidx.annotation.DrawableRes
import com.f1teammanager.R

/** Generic, bundled artwork for every annual team-event kind. */
object AnnualTeamEventArt {
    @DrawableRes
    fun drawableFor(kind: AnnualTeamEventEngine.Kind): Int = when (kind) {
        AnnualTeamEventEngine.Kind.INVESTOR_ACQUISITION -> R.drawable.event_annual_investor_acquisition
        AnnualTeamEventEngine.Kind.FINANCIAL_CRISIS -> R.drawable.event_annual_financial_crisis
        AnnualTeamEventEngine.Kind.CAR_GAIN -> R.drawable.event_annual_car_gain
        AnnualTeamEventEngine.Kind.CAR_LOSS -> R.drawable.event_annual_car_loss
        AnnualTeamEventEngine.Kind.RELIABILITY_GAIN -> R.drawable.event_annual_reliability_gain
        AnnualTeamEventEngine.Kind.RELIABILITY_LOSS -> R.drawable.event_annual_reliability_loss
        AnnualTeamEventEngine.Kind.FIRE -> R.drawable.event_annual_fire
        AnnualTeamEventEngine.Kind.EARTHQUAKE -> R.drawable.event_annual_earthquake
        AnnualTeamEventEngine.Kind.FACILITY_UPGRADE -> R.drawable.event_annual_facility_upgrade
        AnnualTeamEventEngine.Kind.DRIVER_GAIN -> R.drawable.event_annual_driver_gain
        AnnualTeamEventEngine.Kind.DRIVER_LOSS -> R.drawable.event_annual_driver_loss
        AnnualTeamEventEngine.Kind.DRIVER_CLASS_CHANGE -> R.drawable.event_annual_driver_class_change
    }
}
