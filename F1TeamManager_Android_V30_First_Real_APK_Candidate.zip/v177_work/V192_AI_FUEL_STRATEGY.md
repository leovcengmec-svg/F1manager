# V192 — AI race strategy and fuel conservation

Base: V191. Official physical ZIP filename preserved.

## Changes
- Replaced the mostly position-threshold AI posture selector with a per-lap decision model.
- AI evaluates remaining laps, fuel available, projected attack consumption, reserve, tyre wear, weather, race phase, driver skill and proximity to a rival.
- Attack is selective for a realistic fight, capable drivers and adequate fuel/tyre margin.
- Balanced is the normal posture.
- Defense is selected early when fuel projection is tight, tyres are wearing, or attack has low expected value.
- The fuel projection is checked before the critical low-fuel stage, so the AI starts saving early instead of waiting until the final laps.
- Fuel remains finite; no refuelling is added. Pit stops remain tyre changes only and do not add fuel.
- Added tests covering relative consumption of Attack/Balanced/Defense and the attack-reference safety reserve.

## Validation
- Source-level assertions and ZIP integrity checked after packaging.
- Gradle/Android compilation and tests were not run in this environment. On-device and multi-seed race simulations remain required to tune thresholds empirically.
