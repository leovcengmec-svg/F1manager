# V166 — Versão oficial e continuidade do projeto

- V166 sucede oficialmente a V165; este pacote passa a ser a base obrigatória para a próxima atualização.
- Atualizados `versionCode` para 166 e `versionName` para `0.166.0`.
- Preservado o layout vertical Carro / P&D introduzido na V165, incluindo os dois carros, os seis componentes, indicadores de desempenho/confiabilidade, Centro de P&D, nova pesquisa, fábrica e navegação inferior.
- Preservado o comparativo da temporada entre os dois pilotos, além das correções e testes já presentes no pacote V165.
- Nenhuma funcionalidade anterior foi intencionalmente removida.
- A compilação Android e os testes de interface em dispositivo continuam necessários para homologação.

## Regra de versionamento

Toda entrega que altera o pacote oficial deve incrementar a versão e tornar o novo ZIP a base oficial seguinte. O nome externo do ZIP permanece exatamente `F1TeamManager_Android_V30_First_Real_APK_Candidate.zip`.
