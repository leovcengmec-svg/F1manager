# V235 — Frequência controlada dos eventos de corrida

- Eventos de largada ruim: no máximo um evento em todo o GP; chance global de 18% no primeiro processamento da largada; perda de tempo continua aplicada ao piloto selecionado.
- Saída de pista na chuva forte: sorteio global por volta, 15% de chance por volta chuvosa e no máximo um piloto afetado por volta.
- Cards: somente eventos relevantes interrompem a corrida; ultrapassagens e avisos rotineiros continuam sem modal. Prioridade para bandeira vermelha, Safety Car, VSC, acidente, DNF, falha mecânica, pit stop e mudança de clima.
- Limite visual: até 3 cards por lote de atualização; os eventos e consequências no motor não são removidos por esse limite.
- A compilação Gradle não foi executada neste ambiente. Validar build e testar corrida seca/chuvosa antes de considerar concluído.
