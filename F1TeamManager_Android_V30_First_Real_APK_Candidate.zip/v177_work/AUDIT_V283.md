# Auditoria V283 — elegibilidade de aquisição por investidores

## Falha encontrada
A seleção de alvo para `INVESTOR_ACQUISITION` ponderava todas as equipes, inclusive equipes sem duas instalações abaixo do nível 10. Se uma equipe sem capacidade de receber as duas melhorias fosse sorteada, `applyAcquisition` retornava sem evento e a ocorrência era marcada como processada, desperdiçando a aquisição.

## Correção
O motor agora filtra previamente as equipes com pelo menos duas instalações elegíveis antes de aplicar os pesos que favorecem equipes mais fracas/intermediárias. Se nenhuma equipe puder receber as duas melhorias, o slot permanece um no-op sem tentar escolher de uma lista vazia. Os demais tipos de evento mantêm a seleção existente.

## Verificações
- Verificação estática do filtro de elegibilidade e do caminho vazio.
- Verificação estática do uso dos pesos de seleção após o filtro.
- Metadados atualizados para versionCode 283 / versionName 0.283.0.
- Integridade do ZIP verificada após empacotamento.

## Limitação
Não foi executado build Android/Gradle nem simulação dentro do aplicativo nesta execução.
