# Changelog V292
- Adicionado card modal na Home para eventos anuais não lidos.
- Persistência de leitura por evento e ação para abrir a Central de Notícias.
- Mantidos os cards de eventos da corrida e a Central de Notícias.
- Versão interna 0.292.0.
