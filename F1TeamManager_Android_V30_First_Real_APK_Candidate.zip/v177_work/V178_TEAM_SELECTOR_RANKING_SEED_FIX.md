# V178 — Consistência do ranking do seletor de equipes

## Causa raiz
O seletor inicial calculava o desempenho dos carros com o seed de fallback do processo. Ao iniciar a carreira, `startNewCareer()` gerava outro seed por `newCalendarSeed()`. Como `InitialTeamProfile.values()` usa o seed para montar os componentes iniciais, os overalls mudavam entre a seleção e a abertura da carreira, alterando o ranking exibido na tela Equipe.

## Correção
- Gera e persiste `pendingCareerSeed` quando ainda não existe carreira.
- Configura `InitialTeamProfile` com esse seed antes de a tela de seleção calcular o ranking.
- `startNewCareer()` reutiliza exatamente o seed usado pelo seletor, salva-o como seed do calendário da temporada e remove a chave pendente.
- Temporadas seguintes continuam usando `newCalendarSeed()` como antes.
- Mantém o critério de ranking por overall do carro e os desempates existentes; não altera as classificações Forte/Média/Fraca nem os atributos dos pilotos.

## Validação
- Conferência estática dos caminhos de inicialização, seleção e criação da carreira.
- A compilação Android não foi executada neste ambiente.
