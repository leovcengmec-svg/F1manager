V234 — Ícones dos atributos dos pilotos

Ajuste visual restrito à área de atributos dos cards de pilotos: ícones ampliados de 12 dp para 15 dp e mantidos junto aos rótulos, com o conjunto centralizado horizontalmente em cada card de atributo. Nenhuma outra parte do layout foi alterada.

A versão do aplicativo permanece 0.234.0 (versionCode 234), conforme solicitado. A compilação Android não foi executada neste ambiente.
