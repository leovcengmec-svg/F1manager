# V280 — Validação do lote de persistência de pilotos

- A transação de eventos anuais valida IDs contra a lista fixa dos 100 pilotos.
- Cada registro persistido exige exatamente sete atributos e limita valores ao intervalo 1–100.
- Overrides de classe para IDs desconhecidos e valores inválidos são descartados.
- Chaves vazias não são adicionadas ao conjunto de eventos processados.
- A gravação continua em um único `commit()` para atributos, classes e chaves.
- Nome oficial do ZIP preservado.
