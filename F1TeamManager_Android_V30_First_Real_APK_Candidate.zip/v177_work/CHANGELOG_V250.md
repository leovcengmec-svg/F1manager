# V250 — Eventos anuais: regras adicionais

- Adicionada aplicação de eventos de atributo de piloto (+1 a +3 / -1 a -3) com seleção determinística de um dos sete atributos e limites conforme classe.
- Adicionada chave canônica de ledger por temporada/semana para deduplicação na camada de integração.
- Adicionado sorteio de evento comum raro (12% por semana elegível) como parâmetro inicial.
- Mantidos os eventos já modelados na V249: aquisição, crise, carro, confiabilidade, incêndio e terremoto.

## Limitação conhecida
O motor de regras ainda precisa ser conectado ao fluxo persistente de mudança de semana e à camada de estado das equipes. As funções de ledger e sorteio não são, isoladamente, garantia de aplicação única; a integração deve persistir a chave antes de confirmar a semana. Compilação Android e simulação de temporadas não executadas.
