# V165 — Ranking inicial e indicadores dos pilotos

- A ordenação padrão da tela de escolha de equipe usa o desempenho médio da garagem inicial, a mesma métrica de carro utilizada na visão geral da carreira, com desempate estável pelo ID da equipe.
- Os indicadores Overall e Confiabilidade ganharam larguras mais compactas para dar espaço aos dois pilotos.
- Os rótulos dos pilotos foram simplificados e o texto dos indicadores usa tamanho menor e clipping no limite do campo, evitando a reticência visual que substituía os valores.
- O escopo desta atualização fica restrito à ordenação padrão e à legibilidade dos indicadores na tela de seleção.

Validação pendente: compilação Android completa e teste visual no dispositivo. A lista permite outros modos de ordenação (Nome e Nível), que permanecem inalterados.

## V165 — Comparativo de desempenho dos dois pilotos

- Inserido um painel entre os cards dos dois pilotos titulares na tela de pilotos da equipe.
- Comparação baseada nos registros reais da temporada selecionada: pontos, vitórias, pódios, poles, melhor resultado, média de chegada e abandonos (DNF).
- Barras proporcionais e destaque visual indicam qual piloto lidera cada métrica; o resumo final prioriza a pontuação acumulada e evita declarar um vencedor antes de haver resultados.
- O comparativo é apenas visual e não modifica os dados, o motor de corrida ou as estatísticas persistidas.
- A tela mantém os cards individuais e os demais pilotos (se existirem) continuam listados após o comparativo.
