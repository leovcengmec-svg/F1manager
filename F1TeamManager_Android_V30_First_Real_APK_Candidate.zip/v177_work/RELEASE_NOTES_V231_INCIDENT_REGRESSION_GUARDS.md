# V231 — Proteções de regressão para eventos da corrida

- Adicionados testes de regressão estática para garantir que largada ruim e perda de controle sob chuva forte acumulam a perda no tempo efetivo da volta e no tempo total.
- Adicionadas verificações para o mapeamento das imagens dedicadas dos dois eventos.
- Adicionadas verificações para a fila de cards, comparação de lotes completos e retomada somente após o último card, sem decisão pendente, parada manual ou corrida concluída.
- Versão Android atualizada para 0.231.0 (versionCode 231).

Limitação: este pacote foi revisado por código-fonte. A compilação Gradle e a execução dos testes ainda precisam ser realizadas em ambiente com Gradle/Android SDK configurados.
