# Changelog V282

- Evita uma possível corrida de gravação ao reconstruir o estado anterior de atributos dentro da transação anual de pilotos.
- Mantém a leitura anterior sem efeitos colaterais e deixa a persistência final conjunta no `commit()` existente.
- Atualiza versionCode para 282 e versionName para 0.282.0.
