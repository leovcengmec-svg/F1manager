# V160 — Reserva cumulativa de caixa nas negociações

- Corrigido o fluxo semanal da equipe do jogador: taxas de assinatura para várias negociações novas são avaliadas sequencialmente, reservando o caixa já comprometido.
- Negociações sem saldo suficiente são removidas do calendário de contratos antes de salvar o estado do mercado; as demais continuam somente se couberem no saldo remanescente.
- A filtragem identifica cada negócio por piloto, temporada e equipe de destino para não cancelar contratos não relacionados.
- Adicionados testes de taxa tudo-ou-nada, prevenção de débito duplicado e liquidação de obrigação salarial pendente.
- Versão 0.160.0.
