# Auditoria V306

- Alteração limitada ao composable `TeamHeroCard` e metadados de versão.
- Imagem do carro usa o repositório externo já existente; quando ausente, mostra fallback “CARRO”.
- Mantidos escudos e fundo genérico já existentes.
- ZIP será verificado estruturalmente. Compilação Android e teste no dispositivo ainda precisam ser executados pelo workflow de build.
