# V238 — Acidentes coerentes e sem cota global de DNF

- Removido o bloqueio `dnfCount < dnfLimit` como condição para registrar abandono por acidente. `dnfLimit` continua influenciando a taxa base do motor.
- Colisões secundárias só podem envolver pilotos ativos com diferença de até duas posições no estado da corrida.
- Um acidente pode atingir até dois carros próximos além do causador.
- Cada envolvido recebe consequência individual: DNF por colisão ou dano com perda de tempo e necessidade de reparo nos boxes.
- Os cards continuam sendo uma camada de apresentação; as consequências são aplicadas no estado do motor.

Limitação: proximidade é aproximada por posições na ordem de corrida, pois este motor não dispõe de coordenadas físicas por piloto. Compilação Android e simulação estatística ainda precisam ser executadas.
