# Auditoria V286 — stress audit e inventário estático

## Alteração
- Adicionada regressão ao `AnnualEventStressAudit.kt`: uma aquisição por investidores não deve ser atribuída a uma equipe com todas as instalações no nível 10 quando outra equipe possui duas instalações elegíveis.
- Mantidos os cenários de stress já existentes para 200 temporadas, determinismo do calendário, limites de orçamento/instalações/carro e acumulação de efeitos.

## Inventário do pacote extraído
- Fontes Kotlin/Java em `app/src/main/java`: 58
- Testes Kotlin/Java em `app/src/test`: 88
- Assets em `app/src/main/assets`: 193
- Documentos de auditoria/histórico de versões já presentes antes da V286: 51

## Validação executada
- Metadados de versão conferidos.
- Estrutura do teste alterado conferida estaticamente.
- ZIP final reaberto e validado com `testzip()`.
- Nenhum arquivo de histórico anterior foi removido deliberadamente.

## Limitação
Não foi possível executar o stress audit nem os testes JUnit: não há Gradle, `gradlew` ou compilador Kotlin disponível neste ambiente. Não foi executado build Android ou simulação em runtime.
