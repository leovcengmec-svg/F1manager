# V279 — Snapshot da classe de abertura da temporada

- Corrigida a divergência entre a classe atual do piloto e a classe usada como referência de abertura da temporada.
- A classe de cada piloto agora é persistida junto dos atributos no snapshot da temporada.
- Eventos de mudança de classe durante a temporada não alteram retroativamente a referência inicial usada pela evolução.
- Compatibilidade com carreiras antigas: se não existir snapshot de classe, a leitura usa o override atual e depois a classe original.
- Nome oficial do ZIP preservado.
