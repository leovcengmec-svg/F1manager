# V185 — Race start plan dialog layout

Official base: V184 complete source ZIP.

- Revised the race-start plan dialog to better follow the approved reference hierarchy: wide hero header, title/subtitle, three summary cards, two large driver panels, tyre plan selectors and race posture selectors, then cancel/confirm actions.
- Increased the dialog's available width and driver/photo/card proportions to reduce the compressed appearance seen in the current screenshot.
- Preserved existing callbacks and state wiring for tyre plans, strategy modes, cancellation and race start.
- No race simulation or strategy calculation logic changed.
- ZIP integrity checked; Android build and device visual validation still required.
