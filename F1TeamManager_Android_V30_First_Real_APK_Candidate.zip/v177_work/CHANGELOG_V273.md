# V273 — Persistência física antes do ledger de eventos

- Corrigida a ordem de persistência dos eventos anuais do jogador: a garagem com os dois carros físicos atualizados agora é salva explicitamente antes de marcar as ocorrências como processadas.
- Evita perda dos deltas de componentes/confiabilidade em encerramento inesperado entre a gravação do ledger e o salvamento final da garagem.
- Preservados assets, histórico anterior, nome oficial do ZIP e os fluxos existentes.
- Validação estática da ordem de gravação e integridade do pacote; build Android completo ainda requer ambiente Gradle.
