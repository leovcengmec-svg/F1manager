# V234 — Correção de compilação

## Erro reportado
O build Debug falhava em `CareerWeekendEngine.kt:499:47` com `Unresolved reference: playerTeamId`. O parâmetro `playerTeamId` só existia no escopo de `start(...)`, mas era usado novamente em `rebuildRaceStartPlansForCurrentWeather()`.

## Correção
- Adicionado `activePlayerTeamId` como estado do motor.
- O valor é guardado no início da sessão em `start(...)`.
- A reconstrução dos planos após a qualificação usa esse estado guardado.
- Versão incrementada para 0.234.0 / versionCode 234.

## Validação
- Conferência estática: a referência fora do escopo foi removida e a propriedade é inicializada no início da sessão.
- ZIP validado com `ZipFile.testzip()`.
- Compilação Gradle não executada neste ambiente porque não há `gradle` nem `gradlew` disponível. É necessário executar o workflow Android novamente para confirmar se existem outros erros de compilação.
