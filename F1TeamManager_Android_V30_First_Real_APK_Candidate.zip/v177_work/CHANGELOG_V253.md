# V253 — Imagens genéricas dos eventos anuais

- Adicionadas 12 artes genéricas individuais em WebP para aquisição, crise financeira, melhorias/deteriorações de carro e confiabilidade, modernização, incêndio, terremoto, evolução/regressão de piloto e mudança de classe.
- Criado `AnnualTeamEventArt.kt`, que mapeia todos os tipos do catálogo para recursos Android locais.
- Criado `app/src/main/assets/annual_events/catalog.json` para documentar o vínculo evento-imagem.
- Assets adicionados em `res/drawable-nodpi`, sem substituir nem remover os Assets existentes de equipes, pilotos, carros, circuitos ou bandeiras.
- Versão Android: `versionCode 253`, `versionName 0.253.0`.
- Limitação: o mapeamento visual está pronto para ser usado pelo renderer dos cards, mas a integração do renderer de eventos anuais com a interface de carreira e a aplicação semanal ainda precisa ser conectada e testada. Compilação Android não executada neste ambiente.
