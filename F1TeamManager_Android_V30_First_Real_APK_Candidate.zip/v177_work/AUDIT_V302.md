# Auditoria V302 — Avisos anuais de todas as 40 equipes

## Regra corrigida
- Qualquer notificação com categoria `ANNUAL_EVENTS` pode abrir card na Home, sem filtrar por equipe ou piloto.
- Avisos operacionais (P&D, fabricação/peça pronta, slot de patrocínio, programa de desenvolvimento) mantêm os filtros próprios já existentes e continuam destinados à equipe do jogador.
- A Central de Notícias mantém o histórico integral.

## Verificações
- Confirmado que o predicado da Home aceita diretamente `MarketNewsCategory.ANNUAL_EVENTS`.
- Confirmado que o filtro por nome da equipe/piloto foi removido para eventos anuais.
- ZIP íntegro e 193 assets preservados.
- Compilação e teste no Android ainda pendentes.
