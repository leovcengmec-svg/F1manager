# V248 — Motor inicial de regras para eventos anuais

- Adicionado `AnnualTeamEventEngine` com transformações determinísticas para aquisição de investidores, crise financeira, incêndio, terremoto e eventos de carro.
- Aquisição: +100.000.000 no orçamento e duas instalações elegíveis +1 nível.
- Crise: perda de 10% do orçamento disponível, com teto de 100.000.000.
- Incêndio: uma instalação elegível sorteada uniformemente perde 1–2 níveis; terremoto: todas as elegíveis perdem 1–2 níveis individualmente.
- Eventos de carro: alteração de 2–4 pontos, com limites 1–100.
- Pesos relativos de seleção por força: fracas 50, medianas 35, fortes 15; probabilidades iniciais para aquisição (30%) e mudança de classe (15%) modeladas.
- Limitação importante: este motor é a camada de regras; a integração completa à mudança semanal, persistência/idempotência, aplicação global às equipes de IA e persistência da classe do piloto ainda não está concluída. Não considerar os eventos ativos no jogo até essa integração e os testes.
- Compilação Android e testes automatizados não executados.
