# Auditoria V277

## Falha encontrada
Os eventos anuais persistiam mudanças de classe e o grid usava `store.currentDrivers()`, mas dois caminhos de evolução ainda usavam `WorldDatabase.allDrivers` como fonte da classe. Isso deixava a classe efetiva divergente para limites de evolução e desenvolvimento semanal.

## Correção
1. `DriverDevelopmentEngine.advanceWeeks` recebe agora `store.currentDrivers().associateBy { it.id }`.
2. `applyDriverRaceEvolution` usa `driverClassOverrides()[id]` para construir a definição corrente antes de calcular os limites de classe.

## Testes estáticos
- Confirmado que o caminho semanal usa definições correntes persistidas.
- Confirmado que o caminho de evolução de corrida injeta a classe persistida no objeto usado para calcular piso/teto.
- Confirmado `versionCode=277` e `versionName=0.277.0`.
- ZIP testado com `unzip -t`.

## Limitação
Sem compilação Gradle/Android ou teste instrumentado dentro do aplicativo; portanto esta auditoria confirma a correção estrutural, não valida a execução integral no dispositivo.
