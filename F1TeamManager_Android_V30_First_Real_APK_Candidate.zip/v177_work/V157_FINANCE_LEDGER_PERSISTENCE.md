# V157 — Persistent salary and signing-fee accounting ledger

- Base: V156 official ZIP; no UI/layout changes.
- Signing fees paid in full now register a persistent schedule for the target season.
- Amortization progress is stored on the finance state, independent of the rolling transaction list; each GP installment is idempotent and does not debit cash again.
- Player finance preferences save/restore schedules, and AI snapshots serialize/restore the same ledger.
- Player per-GP salary payment continues to use persistent SharedPreferences markers keyed by team, season, and GP, and now runs the amortization recognition step after the completed GP.
- AI signature-fee debits register the same schedule.
- Insufficient cash remains blocked from confirming player contracts at the market call sites; AI deal handling still requires integrated simulation to prove all market-state rollback cases.
- Validation limitations: full Android build and two-season integrated simulation must still be run in an Android/Gradle environment. No claim of full integration approval is made.
