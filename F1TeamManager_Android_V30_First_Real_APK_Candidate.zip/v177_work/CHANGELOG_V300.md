# Changelog V300
- Ajustados orçamento e desempenho geral para reduzir quebras de texto em telas estreitas.
- Estatísticas da temporada reorganizadas em grade 4x2 sem rolagem horizontal.
- Mantidos dados e funcionalidades.
