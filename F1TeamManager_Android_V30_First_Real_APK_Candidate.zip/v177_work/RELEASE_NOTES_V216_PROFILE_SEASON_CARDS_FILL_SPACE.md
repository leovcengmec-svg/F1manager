# V216 — Cards de desempenho da temporada

- Os oito cards internos do painel “Desempenho na temporada” agora distribuem verticalmente o espaço livre do painel.
- Cada linha da grade recebe altura flexível igual, e os cards internos preenchem essa altura.
- A alteração é limitada ao conteúdo interno do painel; não modifica explicitamente o tamanho dos dois cards externos (“Desempenho geral” e “Desempenho na temporada”).
- Nenhuma métrica, regra de simulação ou dado histórico foi alterado.
- Validação feita: inspeção estática do trecho alterado e integridade do ZIP. Build Android não executado neste ambiente.
