# F1 Team Manager V211 — classificação ao vivo consistente
- A classificação ao vivo passa a usar a mesma base de ordenação da classificação final: voltas concluídas (descendente), tempo acumulado (ascendente) e grelha como desempate.
- Remove a dependência da propriedade `position` em cache para construir a classificação apresentada.
- Preserva a correção V210 contra pit-stop retroativo após falha da asa dianteira na última volta.
- Inclui teste de regressão estático para consistência entre classificação ao vivo e final.
- versionCode 211; versionName 0.211.0.
