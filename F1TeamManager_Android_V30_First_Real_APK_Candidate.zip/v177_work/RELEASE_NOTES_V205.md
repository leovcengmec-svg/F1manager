# F1 Team Manager — V205 (correção)
## Tela de detalhes do piloto
- Corrigida a grelha de atributos: os quatro cards da primeira linha mantêm pesos iguais; os três cards da segunda linha distribuem-se simetricamente por toda a largura disponível.
- Texto dos atributos mantém uma única linha, com reticências quando necessário, sem alterar as dimensões dos cards.
- Mantida a estrutura da tela e os dados reais de piloto, carreira, temporada e histórico.
- Preservadas as alterações e correções da base V204, incluindo os planos de pneus para chuva.
- Versão Android atualizada para versionCode 205 e versionName 0.205.0.
