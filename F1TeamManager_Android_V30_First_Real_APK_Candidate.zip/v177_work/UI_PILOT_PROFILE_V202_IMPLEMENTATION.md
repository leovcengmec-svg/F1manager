# Perfil do piloto — V202 atualizado

Tela de perfil integrada no `app/src/main/java/com/f1teammanager/MainActivity.kt` usando os dados reais
do motor e do histórico do jogo. A implementação preserva navegação, estatísticas, fotos dos pilotos,
logotipos das equipes e a fonte histórica existente.

## Padrão visual aplicado
- Fundo escuro e cards com borda discreta.
- Destaques vermelhos e barras de progresso.
- Card de identificação, sete atributos, desempenho geral, temporada e histórico.
- Grade com pesos iguais para indicadores e rolagem vertical para o histórico.
- Cabeçalhos e valores em português.

## Compatibilidade
A implementação permanece dentro do projeto Android/Kotlin existente. Não substitui modelos de domínio,
mecânicas de corrida, contratos, evolução ou persistência.
