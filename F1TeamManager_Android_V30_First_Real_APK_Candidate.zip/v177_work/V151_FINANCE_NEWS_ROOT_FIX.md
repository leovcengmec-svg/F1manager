# V151 — Correção financeira e Central de Notícias

- Salários anuais da IA agora são debitados uma única vez por equipe/temporada. O ledger é incluído no snapshot financeiro e restaurado após reinicialização. Snapshots antigos são tratados conservadoramente como já cobrados na temporada atual para impedir novo débito duplicado.
- A evolução de pilotos publica notificações somente quando o tick real de um GP aumenta o Overall, vinculando a mensagem à semana do GP e evitando duplicatas idênticas.
- Removida da inicialização da interface a auditoria retroativa que comparava atributos persistidos com a base inicial e apresentava alterações acumuladas como se fossem um evento recente.
- Preservados layout e demais sistemas; versão Android 0.151.0 / code 151.
- A evolução de pilotos agora tem trava persistida por GP, evitando aplicar o mesmo tick duas vezes se o fluxo de resultado for reaberto.
- Eventos reais de desenvolvimento de IA são deduplicados por semana/título/mensagem antes de entrar na Central de Notícias.
