# Auditoria V281

## Falha identificada
A V280 filtrava o lote recebido para IDs conhecidos, mas persistia somente os IDs presentes no lote. Se o lote fosse parcial, os registros omitidos voltariam aos atributos de base na próxima leitura, apagando evolução válida. A lista de overrides de classe também podia ser substituída em vez de mesclada.

## Correção
- Montar roster completo com base em todos os pilotos fixos.
- Priorizar os sete atributos recebidos quando válidos; caso contrário, preservar os sete atributos previamente salvos, com fallback à base.
- Mesclar overrides de classe existentes e recebidos.
- Manter filtros de IDs/classes válidos e gravação atômica das três estruturas.

## Verificações estáticas
- Confirmado que a serialização percorre o roster completo, não apenas a entrada parcial.
- Confirmado fallback de dados anteriores para entradas omitidas ou malformadas.
- Confirmada mesclagem dos overrides.
- ZIP será validado após empacotamento.
- Compilação Android/teste instrumentado ainda pendentes.
