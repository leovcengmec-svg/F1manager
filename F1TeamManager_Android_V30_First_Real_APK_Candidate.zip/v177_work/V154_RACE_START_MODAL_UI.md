# V154 — Race start plan modal UI

- Reworked the start-of-race dialog to match the approved dark motorsport composition.
- Added driver portrait, team/country identification, and overall rating per driver.
- Kept the four A/B/C/D plan selectors connected to the existing race-plan callback.
- Rendered each active plan's tyre sequence as compound-colored tyre badges with stint laps.
- Kept attack/balanced/defense selections connected to the existing strategy callback.
- Retained the existing cancel/confirm actions and race logic; this update is UI-only.
- Android version metadata: 154 / 0.154.0.
