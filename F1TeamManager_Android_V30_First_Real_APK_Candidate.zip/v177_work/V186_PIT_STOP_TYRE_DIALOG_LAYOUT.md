# V186 — Pit stop tyre dialog layout

Official base: V185 complete source ZIP.

- Replaced the cramped default AlertDialog layout with a near-full-width custom Compose Dialog and scrollable content.
- Added clear hierarchy for remaining laps, weather recommendation, individual tyre selection cards, current plan, plan A–D controls and explicit manual tyre confirmation.
- Preserved existing pitNow and pitPlan callbacks, weather manual-mode messaging, recommendation rules, and resume/cancel behavior.
- ZIP integrity checked; Android compilation and on-device validation still required.
