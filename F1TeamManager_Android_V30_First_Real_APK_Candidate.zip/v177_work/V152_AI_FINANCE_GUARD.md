# V152 — AI cash guard and annual technical investment cap

## Corrections
- All AI financial debits are cash-limited; the balance cannot become negative.
- Unpaid mandatory expenses are explicitly recorded as `BLOQUEADO/INSUFICIENTE` instead of creating debt.
- AI technical investment has a season-frozen rank-based cap (€200M–€400M).
- P&D/development pipeline and AI facility upgrades consume the same annual cap.
- Technical investment state is included in the AI financial snapshot and restored across app restarts.
- AI race costs, annual salaries, signing fees and facility upgrades cannot drive cash below zero.
- Development spending is limited by both available cash and the remaining annual cap.
- Salary idempotency from V151 is preserved.

## Validation
- Core Kotlin compilation: PASS (warnings only).
- `AIFinanceGuardV152Test`: PASS.
- `AIFinanceSalaryIdempotencyV151Test`: PASS.
- `TwoSeasonTeamBudgetAuditTest`: PASS, 40 teams / 60 GPs / 0 negative balance checkpoints.
- `ThreeSeasonCommercialAuditTest`: PASS.
- `TwoSeasonChainAuditTest`: PASS, 60 GPs, reached 2028 GP 1.
- `FullSeasonIntegrationTest`: PASS, 30 GPs, season transition and driver counts preserved.

## Notes
This ZIP is the updated Android source project. A full APK build/device test was not claimed because the source package does not include a Gradle wrapper in this environment.
