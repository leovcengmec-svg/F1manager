# V260 — Persistência do calendário anual de eventos

- Adicionada persistência do calendário de eventos por temporada em `CareerPreferences`.
- O calendário é gerado apenas quando ainda não existe salvo; carregar novamente preserva semanas e tipos sorteados.
- Adicionado ledger persistente de chaves processadas por temporada para suportar idempotência.
- Validação defensiva das semanas e tipos lidos do salvamento.
- Mantidos os limites e o gerador anual da V259.

## Limitações conhecidas

- A API de persistência foi adicionada, mas ainda não está ligada ao fluxo `advanceFreeWeeks` de `MainActivity`; efeitos dos eventos não são aplicados end-to-end nesta versão.
- Não foi possível executar a compilação Android nem testes automatizados neste ambiente.
