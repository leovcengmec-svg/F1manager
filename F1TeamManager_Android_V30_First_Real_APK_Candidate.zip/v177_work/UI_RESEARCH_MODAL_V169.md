# V169 — Modal de Pesquisa P&D

- Atualizado o diálogo de pesquisa para uma superfície escura com acentos vermelhos e contorno arredondado.
- Cabeçalho com ícone, identificação P&D, nome do componente e fechamento.
- Foco de pesquisa apresentado em três cards selecionáveis: Performance, Confiabilidade e Balanceada.
- Complexidade apresentada em linhas selecionáveis com duração, custo, risco e estado selecionado.
- Ações primária e secundária separadas: Iniciar Pesquisa e Cancelar.
- Conteúdo com rolagem vertical para telas menores.
- Mantida a lógica existente de `develop`, validação de orçamento, foco e complexidade.
- Versionamento Android atualizado para 169 / 0.169.0.
