# V150 — Pit Wall refinements

Based on official V149; no other approved screen layouts were intentionally changed.

- Added each player's photo only to the two player cards above the live classification.
- Rebalanced the upper cards so driver name and gap occupy separate lines and cannot wrap character-by-character.
- Reduced the car graphic width to make room for the driver photo and status details.
- Added colored tyre compound icons: Soft red, Medium yellow, Hard gray, Intermediate green, Full Wet blue.
- Added the same compact compound icon to the tyre cell in live classification. No driver photos were added to classification rows.
- App versionCode/versionName: 150 / 0.150.0.
