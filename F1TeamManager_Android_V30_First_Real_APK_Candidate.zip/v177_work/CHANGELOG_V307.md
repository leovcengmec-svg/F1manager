# V307 — Redesign da interface de equipe

- Reorganizado o cabeçalho da equipe conforme a referência visual: escudo maior, posição funcional abaixo, bandeira em card e bloco de carro no canto direito.
- Removido o texto de desempenho isolado; criado bloco compacto “Desempenho / Confiabilidade” com os valores atuais dos dois carros.
- Cards de orçamento e desempenho geral alinhados com a mesma largura e altura; removida a linha Overall do desempenho geral.
- Incluída linha funcional de limite técnico disponível com valor do motor de investimento técnico.
- Cards de instalações compactados, com títulos em uma linha e sem “Ver todas”.
- Removido “Ver histórico”; histórico da equipe agora apresenta colunas compactas de temporada, posição, pontos, vitórias, pódios, poles, melhores voltas, corridas e DNFs.
- Mantidos histórico, assets externos e funcionalidades existentes.

Validação: integridade do ZIP verificada. Build Android e teste no dispositivo ainda pendentes.
