# V305 — Alertas operacionais de P&D exclusivos da equipe do jogador

- Corrigido o filtro de alertas da Home: “P&D CONCLUÍDO” só abre modal quando a mensagem pertence à equipe selecionada pelo jogador.
- Os avisos de P&D das equipes controladas pela IA continuam no histórico da Central de Notícias, mas não são exibidos como alertas operacionais na Home.
- Eventos anuais de todas as 40 equipes continuam elegíveis para os cards da Home.
- Nenhuma notificação é apagada da Central de Notícias.
