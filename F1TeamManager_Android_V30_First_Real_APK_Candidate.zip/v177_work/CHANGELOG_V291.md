# Changelog V291

- Aplicado o monoposto genérico ao card `TeamHeroCard`.
- Removido o placeholder `MODELO ESPECÍFICO DA EQUIPE`.
- Preservados escudo, dados, clique e navegação existentes.
- Versão interna: 0.291.0.
