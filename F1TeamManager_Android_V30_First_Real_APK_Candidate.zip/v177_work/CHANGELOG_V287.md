# V287
- Adicionado `tools/race_sim_test/validate_project.py`, auditor estático sem dependências para manifest, metadados de versão, contratos dos eventos anuais, persistência/notícias, limites e inventário de assets/histórico.
- Mantidos assets, testes e histórico anterior; nenhuma funcionalidade do jogo foi removida.
- Versionamento atualizado para 287 / 0.287.0.
