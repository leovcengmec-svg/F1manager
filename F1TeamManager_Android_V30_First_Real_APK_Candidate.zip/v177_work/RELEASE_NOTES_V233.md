# Release notes V233

- Corrigido o fluxo de decisão do pit stop para impedir cancelamento acidental do seletor de pneus.
- Preservada a saída explícita para permanecer na pista.
- Incluído teste de regressão estática do diálogo.
- Mantida a base V232 e o nome oficial do pacote ZIP.
