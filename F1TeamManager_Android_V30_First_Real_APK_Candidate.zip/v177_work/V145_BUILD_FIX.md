# V145 — Build Fix

## Correção
Corrigidos os overloads de `drawRect` em `MainActivity.kt` no `SponsorUiIcon`.

O código passava dois `Offset` como se o segundo fosse `Size`, causando o erro de compilação do Compose:
`Argument type mismatch: actual type is 'Color', but 'Brush' was expected` / `Offset`, mas `Size` era esperado.

A implementação foi corrigida usando explicitamente:
- `color = c`
- `topLeft = Offset(...)`
- `size = Size(...)`

Não foi reintroduzido nenhum helper ou API legado.

## Integridade
- `simulatorEfficiency()` permanece ausente.
- `phaseFor()` permanece ausente.
- `baseCar` legado não foi reintroduzido.
