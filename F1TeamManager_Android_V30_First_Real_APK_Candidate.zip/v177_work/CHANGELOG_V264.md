# V264 — Annual event due-week retrieval

- Added a CareerPreferences query for unprocessed events scheduled for a specific week.
- Event occurrence keys include week, kind and ordinal to avoid collisions between same-kind events.
- Added regression tests for valid/unique week allocation, occurrence identity and weekly screen guards.
- Important: this exposes pending scheduled events but does not itself apply effects or mark them processed. The caller must persist all effects first, then mark keys processed.
- Android build and unit tests were not run in this environment.
