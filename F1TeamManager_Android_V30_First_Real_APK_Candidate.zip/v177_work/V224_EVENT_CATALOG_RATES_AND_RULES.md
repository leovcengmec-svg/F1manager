# V224 — Catálogo consolidado de eventos, taxas e punições

## Perfil aprovado
- Incidentes: realista.
- Falhas mecânicas: normal.
- Punições: rigorosas e proporcionais à culpa/gravidade.
- Cards: todos os eventos relevantes; sem rádio e sem histórico separado.
- Front-end: manter o componente/modal visual aprovado na V222; esta versão não redesenha o card.

## Convenções das taxas
Taxas abaixo são valores iniciais de calibração, não estatísticas oficiais da FIA. Taxa por GP significa chance de o evento ocorrer ao menos uma vez na corrida; taxa por piloto/volta é aplicada individualmente apenas quando a condição é elegível. Eventos correlacionados devem compartilhar uma causa raiz para não multiplicar incidentes artificialmente.

## Catálogo e taxa inicial
| Evento | Taxa inicial | Unidade/condição | Efeito e regra |
|---|---:|---|---|
| Largada ruim | 3% | Por piloto, por largada válida | Adiciona perda de 0,15–0,60 s na largada; chance de perder posição depende do gap. Sem punição automática. |
| Toque leve | 20–45% | Chance por GP | Perda curta de tempo; sem dano obrigatório e sem punição automática. |
| Colisão com dano | 5–15% | Chance por GP | Dano a componente e perda de tempo somente se aplicados ao estado do carro. Investigar responsabilidade. |
| Rodada | 5–12% | Chance por GP | Perda de 1–5 s, ajustada por contexto; dano opcional. |
| Saída de pista em condições normais | 10–25% | Chance por GP | Perda de tempo; retorno seguro e sem ganho indevido. |
| Perda de controle na chuva forte | 8% | Por piloto elegível/volta, somente com HEAVY_RAIN | Perda de 1–6 s; dano opcional. Vários pilotos podem ser afetados no mesmo episódio. Limitar a uma ocorrência por piloto na mesma volta. |
| Pneu furado | 2–6% | Chance por GP | Perda de tempo e parada necessária; risco maior após detritos/dano/desgaste crítico. |
| Falha mecânica relevante | 3–8% | Chance por GP | Perda de desempenho ou retirada, conforme componente/gravidade. |
| Abandono mecânico | 2–6% | Chance por GP | Subconjunto das falhas; não sortear separadamente após falha terminal. |
| Erro de pit stop | 5–12% | Chance por GP | Acréscimo de 1–5 s; magnitude depende da gravidade. |
| Infração punível | 10–25% | Chance por GP, somente após infração real | A punição depende de culpa, vantagem e reincidência; nunca sortear punição sem infração. |
| VSC | 10–25% | Chance por GP, condicionada a incidente compatível | Neutralização real; respeitar fluxo de decisão do gestor. |
| Safety Car | 15–35% | Chance por GP, condicionada a incidente grave/posição do carro | Agrupa pelotão e ativa fluxo estratégico existente. Não disparar em duplicidade com VSC pelo mesmo incidente. |
| Bandeira vermelha | 1–5% | Chance por GP, apenas incidente/clima extremo elegível | Pausa a prova e mantém escolha obrigatória de pneus/postura de relargada. |
| Chuva durante a corrida | 5–20% | Chance por GP, conforme clima sorteado | Alterar Weather do motor; não gerar apenas mensagem visual. |

## Modificadores
1. Cada evento tem uma taxa-base e uma lista explícita de condições de elegibilidade.
2. Risco de incidente aumenta com agressividade/pressão, disputa roda a roda, baixa consistência, pouca habilidade em pista molhada, aderência reduzida e pneus inadequados.
3. Experiência, consistência e habilidade em pista molhada reduzem o risco dentro de limites definidos.
4. Circuito estreito/baixa área de escape aumenta a consequência e/ou probabilidade, sem aplicar o mesmo multiplicador duas vezes.
5. Dano, desgaste, confiabilidade de cada componente e temperatura só afetam eventos mecânicos compatíveis.
6. Chuva forte precisa estar realmente ativa no estado da corrida. A taxa de saída na chuva não é avaliada em pista seca.
7. Limitar probabilidades finais para impedir valores negativos ou acima de 100%; documentar os multiplicadores em constantes nomeadas e testáveis.
8. Usar seed reproduzível nos testes. Evitar novo sorteio a cada frame/tick; avaliar uma vez no ponto determinístico da simulação.

## Punições
- Advertência: infração leve sem vantagem relevante; contabilizar reincidência.
- Devolver posição: ganho indevido recuperável.
- 5 s: infração leve/moderada com vantagem ou reincidência.
- 10 s: infração mais grave ou reincidência relevante.
- Drive-through: infração grave quando apropriado ao regulamento do simulador.
- Stop-and-go: infração muito grave.
- Penalidade pós-corrida: infração que não pôde ser cumprida durante a prova.
- Desclassificação: somente infração excepcionalmente grave.
- Colisão, rodada, falha mecânica ou saída de pista não geram punição automática sem evidência de infração/culpa.
- Uma infração tem um único identificador causal; impedir punição duplicada pelo mesmo fato.

## Cards e fluxo
- Todos os eventos relevantes que foram aplicados ao motor geram card; notificações meramente preventivas podem permanecer como alertas compactos.
- Um incidente pode gerar consequências relacionadas (dano, perda de tempo e investigação), mas devem ser agrupadas sob a mesma causa raiz para evitar cards duplicados.
- Chuva forte coletiva: cada piloto afetado recebe informação individual, podendo o mesmo episódio agrupar os cards numa fila; não pausar o motor por cada piloto antes de processar o conjunto da volta.
- Fechar card retoma a corrida automaticamente quando não houver decisão estratégica bloqueante.
- Preservar decisões existentes de VSC, Safety Car, bandeira vermelha, pneus e alertas estratégicos.
- O card só exibe perda de tempo, dano, posição ou punição depois que a consequência tiver sido aplicada ao estado real da corrida.
- Manter o front-end aprovado: overlay escurecido/desfocado, modal central, cabeçalho de evento, imagem opcional, narração, consequências e botão CONTINUAR CORRIDA.

## Testes obrigatórios antes de homologar
- Largada ruim: não pode ocorrer após a volta de largada; aplicar perda uma única vez e testar seed determinística.
- Chuva forte: nenhum evento em seco; permitir múltiplos pilotos na mesma volta; nunca duplicar para o mesmo piloto/volta; tempo perdido afeta classificação.
- Punições: sem punição quando não há infração; punição uma única vez; verificar aplicação na classificação/tempo final.
- Neutralizações: um incidente não gera VSC e Safety Car duplicados; retomar a simulação após fechar card quando não houver decisão pendente.
- Cards: sequência com múltiplos eventos sem perder, repetir ou travar eventos; verificar modal em dispositivo e layout aprovado.
- Rodar simulação estatística de 1.000 GPs e registrar frequência observada, abandonos, penalidades, saídas na chuva e eventos por GP antes de ajustar taxas.

## Status
Especificação consolidada para orientar a implementação. As taxas são propostas iniciais e não devem ser consideradas implementadas ou validadas no motor até que os testes acima passem. A compilação e o teste visual de dispositivo permanecem necessários.
