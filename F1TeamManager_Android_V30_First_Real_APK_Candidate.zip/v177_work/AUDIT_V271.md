# Auditoria V271 — eventos anuais

## Correções desta rodada
- Ocorrências agendadas da semana são fechadas no ledger após a tentativa de persistência, mesmo quando a regra retorna evento sem efeito (por exemplo, instalação já no limite). Isso evita deixar a ocorrência eternamente pendente.
- Deltas de componentes/confiabilidade passam a ser aplicados às duas unidades físicas do jogador e das equipes de IA no adaptador do grid, preservando IDs/versões das peças instaladas.

## Simulação determinística do motor de eventos
Harness Kotlin compilado com `kotlinc` usando os arquivos reais `AnnualTeamEventEngine.kt` e `AnnualTeamEventSeasonCalendar.kt`, com stubs isolados apenas para tipos de modelo não necessários à regra:

`SEASONS=4 WEEKS=224 TEAMS=40 TEAM_EVENTS=16 DRIVER_EVENTS=5 SCHEDULED_SLOTS=22 NEWS=21 NO_EFFECTS=0 DUPLICATE_KEYS=0 BOUNDS_FAILURES=0 CALENDAR_FAILURES=0`

Resultado: `ANNUAL_EVENT_SIMULATION_PASS`.

## Teste do adaptador de garagem
Harness Kotlin compilado com o arquivo real `AnnualEventGarageAdapter.kt`:
- delta de componente refletido nos dois carros;
- delta de confiabilidade refletido nos dois carros e nos componentes;
- metadados das peças/versões preservados;
- delta zero mantém a garagem idêntica.

Resultado: `GARAGE_ADAPTER_PASS`.

## Limites da validação
- O ambiente não possui Gradle wrapper nem instalação Gradle disponível; portanto, não foi possível executar o build Android completo nem a suíte JUnit do app.
- A simulação acima cobre o motor de eventos e o adaptador, não substitui uma execução de 4 temporadas dentro do aplicativo Android.
