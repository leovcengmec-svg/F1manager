# V218 — Central de Notícias: vencedor canônico

- Mantém semanas, calendário e layout inalterados.
- Para notícias de resultado, o piloto destacado é resolvido primeiro pela entrada explícita `1º` do pódio; a frase `vencedor` fica como fallback para registros antigos sem pódio legível.
- Inclui testes de regressão para divergência entre a frase do vencedor e o pódio.
- Não altera o resultado oficial da corrida nem reescreve notificações já persistidas.
- Build Android e execução dos testes ainda precisam ser confirmados no ambiente Android/Gradle.
