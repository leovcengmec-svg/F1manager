# V219 — Central de Notícias: identidade do vencedor

- Mantém o layout, semanas e calendário inalterados.
- Para cards `RESULTADO DO GP`, a entidade em destaque vem da entrada `1º` do pódio contido na notícia, que representa a classificação publicada; a frase `vencedor` é apenas fallback se não houver entrada de pódio legível.
- A resolução do nome do piloto é exata, ignorando apenas maiúsculas/minúsculas.
- Inclui teste de regressão para notícia cuja frase de vencedor diverge do primeiro lugar do pódio.
- Não altera resultados oficiais nem reescreve mensagens históricas persistidas.
- Build Android e execução dos testes Gradle não foram executados neste ambiente.
