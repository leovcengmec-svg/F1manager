# V266 — Batch resolution across teams

- Added deterministic season-batch resolution for scheduled team-level events across all supplied team snapshots, in stable team/week order.
- Driver attribute and class events are separated into a dedicated pending list instead of being silently treated as team events.
- Added tests for all-team resolution, ordering and driver-event separation.
- The batch resolver is pure and does not save results. MainActivity weekly-flow integration and notification-card publication remain pending.
- Android compilation and automated tests were not run.
