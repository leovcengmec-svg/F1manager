# V232 — Vistoria geral do F1 Team Manager

## Escopo inspecionado
- Estrutura Android/Compose, manifesto, dependências e versionamento.
- Motores de corrida, classificação, pneus, combustível, confiabilidade, neutralizações e incidentes.
- Calendário/temporada, grid, mercado/evolução de pilotos.
- Finanças, patrocínios, pesquisa/P&D, fábrica, garagem e instalações.
- Inventário de assets e suíte de testes existente.
- Fluxo visual de cards de evento e retomada da corrida.

## Inventário observado
- 51 arquivos Kotlin de produção.
- 75 arquivos Kotlin de teste.
- 40 assets de equipes, 100 de pilotos e 50 de circuitos; contagens compatíveis com o banco declarado.
- `MainActivity.kt` contém 6.534 linhas; `CareerWeekendEngine.kt`, 1.588 linhas. A concentração de UI/estado em `MainActivity` eleva o risco de regressões entre telas e fluxo da corrida.
- O projeto usa Android Gradle Plugin/Compose e declara testes JUnit, mas este pacote não contém `gradlew`/wrapper. O ambiente desta vistoria também não tem Gradle nem Android SDK configurado; portanto não foi possível compilar nem executar a suíte.

## Achados priorizados

### P1 — Calibração dos eventos de chuva
A regra atual dá 8% de chance **por piloto ativo, por volta** durante chuva forte. Com 20 pilotos, a probabilidade de pelo menos um incidente em uma volta é aproximadamente 81% (1 − 0,92²⁰), antes de outros modificadores. Isso conflita com a especificação V223, que descreve as taxas-alvo como probabilidade de ao menos um evento por GP, e pode gerar saídas de pista excessivas. Não alterei a taxa nesta vistoria para não substituir silenciosamente o parâmetro previamente usado; precisa ser recalibrada/confirmada e validada em simulação.

### P1 — Fechamento do diálogo de pit stop
O `onDismissRequest` do diálogo de pit stop limpa `pitDriver` e define `running = true`. Se o usuário fechar pelo botão Voltar do Android/toque externo, a corrida pode continuar sem confirmar a escolha de pneu. É preciso definir se o cancelamento deve ser bloqueado, tratado como decisão explícita ou manter a parada pendente.

### P1 — Testes que podem não ser executados pelo JUnit
`SeasonCalendarV75Test.kt` e `InitialTeamBudgetV131Test.kt` contêm métodos de verificação, mas não possuem anotações `@Test` nem função `main`. Esses métodos não são descobertos como testes JUnit convencionais e não devem ser considerados cobertura executada até serem integrados corretamente ao runner.

### P2 — Teste recente de incidentes é majoritariamente estático
`V231IncidentAndCardFlowRegressionTest` verifica trechos de texto do código-fonte, não executa a corrida nem comprova a alteração de classificação, a ausência de duplicação ou a retomada real no Android. Serve como guarda de regressão textual, não como teste integrado.

### P2 — UI/estado concentrados
O tamanho de `MainActivity.kt` aumenta o risco de efeitos colaterais entre cards, decisões de gestor, pit stop e temporizador. Recomenda-se separar o controlador/estado da corrida e o diálogo de evento em componentes com testes de estado, preservando o layout aprovado.

## Itens com evidência estática positiva
- O manifesto declara uma única Activity launcher.
- A versão encontrada na base era `versionCode 231` / `versionName 0.231.0`.
- O calendário mantém pool declarado de 50 circuitos e sorteia 30 por temporada; os testes existentes documentam 30 GPs e transição anual, mas não foram executados nesta vistoria.
- O código do card diferencia imagens para largada ruim e saída de pista na chuva forte.
- A fila de cards compara o lote de eventos e a condição de retomada verifica cards restantes, decisão pendente, parada manual e corrida concluída.
- O ZIP original passou na verificação de integridade (`unzip -t`).

## Limites desta vistoria
Esta é uma auditoria estática de código, estrutura, testes e assets; não equivale a um teste funcional completo. Não foi possível afirmar que o jogo compila, abre no Android ou que todos os fluxos funcionam em execução. Não foi executada simulação estatística de 1.000 GPs nem a auditoria de 4 temporadas.

## Próximas correções recomendadas
1. Resolver o cancelamento/fechamento do diálogo de pit stop.
2. Converter os dois testes sem `@Test` em testes realmente descobertos pelo runner.
3. Calibrar eventos por exposição para respeitar a taxa-alvo por GP e executar uma amostra grande com seeds registradas.
4. Executar build + suíte completa; depois simular temporadas e validar calendário, P&D em semanas livres, pneus/clima, grid, finanças, evolução, mercado, cards e transições.
5. Testar a UI no POCO X7 Pro, sobretudo cards consecutivos e retomada da corrida.
