# V171 — Central de Notícias unificada para jogador e IA

## Regras consolidadas
- A Central de Notícias usa o mesmo `DriverMarketState.notifications` para eventos do jogador e de todas as equipes IA.
- Mercado: propostas enviadas/recebidas, contrapropostas, recusas, contratos fechados, transferências confirmadas e renovações ficam na categoria `MARKET`.
- Evolução de pilotos: notícia apenas quando o Overall inteiro exibido muda, tanto para subida quanto para queda. O fluxo cobre a evolução dos 100 pilotos e também o desenvolvimento individual concluído.
- Evolução das equipes: P&D concluído, fabricação concluída, peça instalada no Carro 1 ou Carro 2, mudança efetiva do Overall médio e melhoria de instalação são eventos distintos.
- A fabricação não é descrita como instalação; a notícia de instalação é publicada somente quando a peça é realmente atribuída a um carro.
- Evento de início de temporada é publicado em `ANNUAL_EVENTS`.
- As notificações novas são persistidas no mercado da carreira e limitadas ao histórico existente, sem alterar regras de orçamento, mercado, evolução, corrida ou cadeia física.

## Correções da auditoria V170
- Corrigida a ausência de notícias de fabricação e instalação da equipe do jogador.
- Adicionadas notícias de melhoria das instalações do jogador e progressão das instalações IA durante o avanço do calendário.
- Evolução de piloto agora contempla aumentos e quedas de Overall, sem emitir notícia quando o Overall não muda.
- Mensagem de fabricação IA deixou de afirmar que a peça foi instalada antes do evento real de instalação.
- Incrementado versionCode para 171 e versionName para 0.171.0.
