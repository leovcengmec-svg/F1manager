# Changelog V284

- Auditoria consolidada do fluxo de eventos anuais e calendário.
- Atualizado o teste de lote que ainda esperava que uma ocorrência afetasse todas as equipes.
- Adicionados testes de regressão para elegibilidade, efeitos e caso sem equipes elegíveis para aquisição por investidores.
- Mantido o nome oficial do ZIP e atualizado o versionCode para 284 / versionName 0.284.0.
