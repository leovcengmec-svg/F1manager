# V274 audit report

## Bug fixed
The previous class-change event selected any driver and then selected promotion/demotion with equal probability. For `Fraco` a demotion is invalid; for `Lenda` a promotion is invalid. In those cases the slot was marked processed with no class change and no news.

## Correction
Candidates are filtered to drivers with at least one valid adjacent class. Direction is chosen only among valid transitions, so a scheduled class-change occurrence can always change class when the roster contains a recognized class.

## Executed test
Compiled and ran `AnnualEventStressAudit.kt` with Kotlin/JVM and a minimal model stub harness, exercising 200 deterministic seasons, calendar stability, weeks 1–56, unique slots, team-target uniqueness, budget floor, facility bounds 0–10, car stats bounds 1–100, and all five adjacent class transitions.

Result:
- Seasons: 200
- Scheduled slots: 1,148
- Team event results: 853
- Driver slots: 222
- Failures: 0
- `ANNUAL_EVENT_STRESS_PASS`

## Limitations
This is a JVM stress test of the pure event engine plus static review of the Android integration. It is not a full Android build or on-device simulation. The package has no Gradle wrapper and Gradle is not installed in the environment, so full application compilation remains pending.
