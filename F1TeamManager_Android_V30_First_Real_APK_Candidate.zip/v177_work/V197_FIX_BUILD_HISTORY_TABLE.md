V197 — correção de compilação do histórico por temporada

Corrigidas as referências residuais a historyWidths, substituídas pela grade historyWeights. A tabela deixa de usar rolagem horizontal e distribui as 10 colunas dentro da largura disponível. Nome do ZIP oficial preservado. Build Gradle ainda deve ser executado no ambiente Android para validação final.
