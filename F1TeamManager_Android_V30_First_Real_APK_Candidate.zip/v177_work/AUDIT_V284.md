# Auditoria consolidada V284 — eventos anuais e calendário

## Escopo desta rodada
Inspeção estática integrada do calendário de 56 semanas, geração determinística, seleção de equipes, aplicação de efeitos, persistência e chaves de idempotência, e integração com a Central de Notícias.

## Correções e endurecimentos
1. Mantida a correção V283: aquisição por investidores só sorteia equipes com pelo menos duas instalações abaixo do nível 10; a ponderação por força é aplicada depois do filtro.
2. Corrigido teste legado V266 que esperava multiplicar uma ocorrência de evento por todas as equipes. A regra atual é uma ocorrência por slot e uma equipe-alvo, evitando multiplicar crise, dano ou melhoria por todo o grid.
3. Adicionados testes de regressão para garantir que aquisição:
   - só escolha uma equipe com duas instalações elegíveis;
   - conceda o orçamento e melhore exatamente duas instalações elegíveis;
   - não gere resultado quando nenhuma equipe for elegível.
4. Mantida a integração semanal no fluxo de avanço normal, com chaves processadas por ocorrência, salvamento dos efeitos, e categoria `ANNUAL_EVENTS` nas notícias.

## Pontos verificados estaticamente
- Calendário determinístico e semanas válidas 1–56.
- Chaves incluem semana, tipo e ordinal; calendários e ledger são separados por temporada.
- Slots pendentes são filtrados contra chaves já processadas.
- Eventos de equipe usam snapshots atualizados dentro do lote para não sobrescrever efeitos anteriores da mesma semana.
- Eventos de pilotos são aplicados ao elenco persistido e classes/atributos/chaves são enviados pela função transacional.
- Eventos de equipe e piloto geram notificações na categoria anual quando há efeito.
- A seleção da aquisição exclui equipes incapazes de receber as duas melhorias.
- ZIP final verificado com `testzip()`.

## Limitações explícitas
Não há `gradlew` no pacote e não há executável `gradle` disponível neste ambiente; por isso, não foi possível executar os 87 arquivos de teste nem compilar o app. Não foi feita simulação em runtime. O teste V266 atualizado e os novos casos foram adicionados, mas precisam ser executados em ambiente Android/Gradle para confirmar compilação e resultado real.
