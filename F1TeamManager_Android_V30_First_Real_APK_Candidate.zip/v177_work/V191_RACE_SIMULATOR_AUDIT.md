# V191 — Race simulator audit and qualifying-grid root fix

Base: V190 official source package. Physical ZIP filename remains unchanged.

## Confirmed root issue
`CareerWeekendEngine.start()` initialized each race state with `grid = driverId + 1`, `position = driverId + 1`, and starting cumulative time based on that value. The Q1/Q2/Q3 pipeline later built the final qualifying grid, but `finishQualifyingPhase()` did not apply it to the actual race states. As a result, the displayed qualifying result and the race's actual starting order could diverge, making internal driver/team ID ordering affect race outcomes.

## Fix
- Made the state grid position mutable.
- Applied final Q3 grid order to each race state exactly when qualifying completes.
- Synchronized `grid`, `position`, `lastPos`, and initial cumulative start gap.
- Added `CareerWeekendGridApplicationTest` to assert that all 80 live race positions match the final qualifying grid before lap 1, with a non-ID-ordered test setup.

## Additional audit observations
- AI tyre management uses a fixed wear threshold with a per-driver bias, while the player uses explicit plans; this asymmetry should be benchmarked across multiple seeds after the grid fix.
- AI posture selection is based mainly on weather, fuel, tyre wear and current position/driver attributes. A wider strategy benchmark is still needed to measure whether this is competitive over a season.
- Car component modifiers are significant on a per-lap basis. Do not rebalance them before measuring race distributions after the grid-order fix; otherwise two causes would be mixed.

## Validation status
- ZIP archive integrity checked.
- Static checks confirm final grid application is called from the final qualifying phase and version metadata is V191 / 0.191.0.
- Added regression test source; Android/Gradle test execution is not claimed because this environment does not provide a Gradle wrapper or local Gradle installation.
- On-device screenshot comparison and multi-seed 80-car season benchmark remain pending.
