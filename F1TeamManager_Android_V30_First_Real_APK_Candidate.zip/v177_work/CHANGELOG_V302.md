# Changelog V302
- Restaurada a exibição na Home dos avisos anuais de todas as 40 equipes.
- Avisos operacionais continuam exclusivos da equipe do jogador.
- Versão interna 0.302.0.
