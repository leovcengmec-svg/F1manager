# V173 — Pit Wall layout alignment

- Reworked the two player-driver cards to follow the approved reference hierarchy: driver name and position/gap at the top, prominent car row, race-status row, last-lap separator, and full-width strategy controls.
- Kept the existing driver portrait (`DriverPhoto`) in each card, as requested.
- Preserved race state, strategy controls, pit action, tyre/fuel/ERS/DRS data, and live classification behavior.
- Based on V172; Android build and instrumentation tests require an Android/Gradle environment and are not claimed as run here.
