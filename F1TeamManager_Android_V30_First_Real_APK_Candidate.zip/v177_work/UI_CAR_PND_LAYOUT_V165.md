# V165 — Ajuste de layout da tela Carro / P&D

- Preservado o fluxo vertical em LazyColumn e todos os estados/ações de pesquisa, fabricação e instalação.
- Cards dos dois carros reorganizados em grade de três colunas por duas linhas, aproximando a composição da referência.
- Indicadores de desempenho e confiabilidade passaram a ter barras visuais azuis/verdes.
- Cards ganharam bordas, cantos e hierarquia de título/Overall mais claros.
- Cards de pesquisa receberam espaço e quebra de texto mais robustos para reduzir cortes em telas estreitas.
- Nenhuma regra de jogo ou fórmula de desempenho foi alterada.
- Compilação Android precisa ser executada no ambiente Android/Gradle para homologação.
