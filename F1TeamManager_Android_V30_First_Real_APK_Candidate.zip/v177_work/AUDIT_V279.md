# Auditoria V279

## Falha identificada
A função `seasonStartDriverDefinition` lia os atributos do início da temporada, mas consultava a classe global atual. Uma mudança de classe por evento durante a temporada podia, portanto, modificar retroativamente a referência inicial usada por cálculos de evolução.

## Correção
- Snapshot da classe gravado na mesma fronteira de temporada dos atributos.
- Leitura da classe inicial a partir do snapshot por temporada.
- Compatibilidade com saves anteriores sem a nova chave.

## Verificações
- Conferida a presença de snapshot de classe na gravação e na leitura.
- Conferida a compatibilidade de fallback para saves antigos.
- Conferida versão 0.279.0 / código 279.
- Integridade do ZIP será verificada após o empacotamento.
- Compilação Android e execução instrumentada não disponíveis nesta rodada.
