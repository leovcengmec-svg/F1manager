# V143 — Active Build Fix

## Root cause found in V142 APK build
The V142 Android build exposed two current-source compile issues in `CareerPreferences.kt` that were not covered by the core-only Kotlin compilation:

1. `InitialTeamProfile` was used without an import in `CareerPreferences.kt`.
2. `CareerPreferences.kt` called `DriverDefinition.ratings()`, but that helper is private to `DriverEvolutionEngine.kt` and therefore is not part of the public/current API.

## Correction
- Added the direct import of the active `InitialTeamProfile` source.
- Added a local `ratingsForEvolution()` projection in `CareerPreferences.kt` using the seven current driver attributes.
- Replaced all `current.ratings()` / `before.ratings()` calls in `CareerPreferences.kt` with that active projection.
- No legacy helper was restored.
- `DriverEvolutionEngine.ratings()` remains private and unchanged.
- No gameplay rule, evolution rule, P&D rule, financial rule, sponsorship rule, race rule, or UI rule was reverted.

## Validation
- Core Kotlin compilation: PASS.
- No references to removed `phaseFor()` or `simulatorEfficiency()`: PASS.
- No `baseCar` production field/reference: PASS.
- APK build environment in this workspace has no Gradle wrapper/installed Gradle, so a real Android `compileDebugKotlin` invocation cannot be executed here. The screenshot-proven compiler errors were corrected at their source.

## Version
- `versionCode = 143`
- `versionName = 0.143.0`
