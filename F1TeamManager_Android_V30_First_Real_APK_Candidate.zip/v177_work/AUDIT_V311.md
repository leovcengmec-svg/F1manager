# Auditoria V311

- Base: ZIP oficial V310.
- Alteração localizada: layout do cabeçalho em `MainActivity.kt` dentro de `TeamOverviewScreen`.
- A posição continua derivada de `ranking.indexOfFirst` sobre os snapshots ordenados pelo `garage.teamAverageOverall`.
- `versionCode`: 311; `versionName`: 0.311.0.
- Nenhuma imagem nova foi gerada.
- ZIP integrity test: pendente até empacotamento final.
- Gradle/APK e validação visual em dispositivo: não executados neste ambiente.
