# V149 — Refinamento da História do Piloto

Base: V148 oficial.

## Alteração
- Na tabela HISTÓRICO POR TEMPORADA da ficha do piloto, cada linha agora exibe a logo da equipe imediatamente antes do nome da equipe.
- A logo usa `TeamLogo` com o `teamId` histórico real.
- Tamanho compacto de 18dp para caber na mesma linha sem alterar tamanho de texto nem largura das colunas.
- Estrutura e proporções da tabela foram preservadas.

## Preservação
- Nenhum sistema de gameplay alterado.
- Nenhum código legado reintroduzido.
- Todas as interfaces recuperadas da V122–V139 permanecem na base V148.
