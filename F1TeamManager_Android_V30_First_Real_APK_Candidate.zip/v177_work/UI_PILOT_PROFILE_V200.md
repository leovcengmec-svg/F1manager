V200 — reconstrução do layout de perfil do piloto com base na imagem aprovada.
Base oficial: ZIP V199; nome canônico preservado.
- Cabeçalho do piloto mais compacto e com contorno de card.
- Atributos com tipografia de rótulo/valor compactada para caber no grid 4+3 sem cortar números.
- Desempenho geral e desempenho da temporada dispostos lado a lado, em dois cards com mesma largura.
- Histórico por temporada mantido dentro da largura útil, com dez colunas proporcionais e sem rolagem horizontal.
- Dados dinâmicos, callbacks e cálculos de estatísticas existentes foram preservados.
Versionamento: versionCode 200; versionName 0.200.0.
Validação: arquivo Kotlin revisado e ZIP testado por integridade; build Gradle não executado neste ambiente.
