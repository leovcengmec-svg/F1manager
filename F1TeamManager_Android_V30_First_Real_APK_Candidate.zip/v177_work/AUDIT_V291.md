# Auditoria V291 — Card de equipe com monoposto genérico

## Alteração
- Removido o texto provisório `MODELO ESPECÍFICO DA EQUIPE` do `TeamHeroCard`.
- Reutilizado `GenericFormulaCarArt`, o mesmo desenho vetorial Canvas genérico já presente no cabeçalho da tela de visão geral.
- Mantidos o escudo real da equipe, o nome, o modelo/motor recebido, o clique do card e os componentes existentes.
- O desenho genérico não depende do identificador ou da pintura de uma equipe, podendo ser reutilizado para todas.

## Verificações estáticas executadas
- `TeamHeroCard` usa `GenericFormulaCarArt`.
- O texto provisório foi removido do `TeamHeroCard`.
- `GenericFormulaCarArt` continua declarado e usado no cabeçalho da tela de visão geral.
- O código fonte e o ZIP foram verificados por leitura e integridade.
- Assets e histórico anteriores foram preservados.

## Limitação
A compilação Android e os testes Kotlin/JUnit não foram executados neste ambiente; portanto, esta auditoria não certifica o build completo.
