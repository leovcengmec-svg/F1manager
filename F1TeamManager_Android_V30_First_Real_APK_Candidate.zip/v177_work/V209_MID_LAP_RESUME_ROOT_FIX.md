# V209 — Correção de retomada no meio da volta

## Causa-raiz identificada
`CareerWeekendEngine.advance()` incrementava o contador global da volta no início de cada chamada. Porém, durante a volta, decisões do manager (combustível, pneu, chuva, Safety Car e bandeira vermelha) podem devolver um snapshot antes de todos os carros terem processado a volta. Ao resolver a decisão, a próxima chamada podia incrementar a volta e voltar a processar desde o início, fazendo alguns carros acumularem uma volta enquanto outros ainda estavam na anterior. Isso tornava os tempos/gaps transitórios inconsistentes e podia alterar a classificação final.

## Correção
- Mantém a volta atual aberta quando uma decisão interrompe a simulação.
- Guarda os IDs dos pilotos já processados naquela volta.
- Retoma pelos pilotos ainda não processados, sem duplicar volta/tempo para os anteriores.
- Não repete a preparação global da volta após uma pausa ocorrida dentro do processamento dos carros.
- Limpa o estado de retomada somente quando a volta inteira é concluída.
- Incrementa `versionCode` para 209 e `versionName` para `0.209.0`.

## Validação
ZIP original íntegro antes da alteração. Adicionado teste de regressão de fonte `V209MidLapResumeRegressionTest`. A compilação Gradle/Android não foi executada neste ambiente porque o pacote não inclui Gradle Wrapper e não há Gradle instalado. Portanto, não afirmar APK compilado nem teste JUnit executado; a validação final requer CI/Gradle.
