# V306 — Card da equipe com imagem do carro

- Aumentado o escudo/logo da equipe no card da Home.
- Removido o texto “MONOPOSTO UNIVERSAL”.
- Nome do modelo movido para imediatamente acima do card de imagem do carro, no canto inferior direito.
- Card do carro separado das margens externas do card da equipe, com fundo e borda próprios.
- Imagem do carro carregada pela infraestrutura existente `ExternalAssets.loadTeamCarVisual`, usando o ID permanente da equipe em `Pictures/F1Manager/Assets/Cars/`.
- Mantidos os dados, navegação, lógica de corrida e ações do card.
