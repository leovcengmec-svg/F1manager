# V217 — Correção do piloto em destaque na Central de Notícias

- Corrigido `parseNews()` para notícias cujo título começa com `RESULTADO DO GP`.
- O cabeçalho agora é associado ao nome explicitamente anunciado após `vencedor`, em vez de escolher o primeiro piloto cujo nome apareça em qualquer parte da mensagem do pódio.
- O nome do vencedor e o ID do piloto são resolvidos por correspondência exata, sem alterar semanas, calendário, conteúdo do pódio ou layout.
- Para outros tipos de notícia, o comportamento anterior de identificação de entidade foi preservado.
- Versão do app: `0.217.0` (versionCode 217).
- Validação feita: inspeção estática do patch e integridade do ZIP. Build Android e execução no dispositivo não realizados neste ambiente.
