# V183 — Correção de versionamento e continuidade

- Base: pacote oficial mais recente recebido em 09/10/2026, com `versionCode` 182.
- Corrigido o próximo pacote para V183 (`versionCode = 183`, `versionName = 0.183.0`).
- Mantida a política de investimento da IA: até 20% do teto técnico anual para instalações; P&D/projeto e fabricação de componentes usam o saldo disponível, sem ultrapassar o teto técnico total ou o caixa disponível.
- Mantidas as regras de pneus/clima da classificação já presentes na base.
- Nenhuma função ou arquivo de jogo foi removido; apenas os dois documentos de release V182 foram renomeados para V183 e o metadado de versão atualizado.
- Integridade do ZIP validada. A compilação Android e os testes de integração precisam ser executados em ambiente com Android SDK/Gradle configurado; este pacote não deve ser descrito como APK homologado sem essa validação.
