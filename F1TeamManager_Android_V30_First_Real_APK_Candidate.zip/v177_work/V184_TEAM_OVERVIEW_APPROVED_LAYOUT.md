# V184 — Team overview layout correction

Official base: complete V183 layout-corrected source ZIP.

- Revision incremented to V184 for the team overview layout update.
- The team overview now displays the existing two-car showcase between facilities and drivers.
- The approved screen sequence is: team header; budget and general performance; facilities; cars; drivers; car attributes; season performance; season history.
- The facility carousel shows Factory, R&D, Wind Tunnel, Simulator, Commercial Center, and Scouting.
- Existing business logic and prior fixes are retained; no unrelated behavior was intentionally changed.
- ZIP integrity verified. Android compilation and on-device visual validation remain to be performed.
