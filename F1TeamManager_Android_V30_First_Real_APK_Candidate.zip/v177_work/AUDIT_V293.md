# Auditoria V293 — Avisos da Home ampliados

## Escopo dos cards
- Eventos anuais de jogador e IA (`ANNUAL_EVENTS`).
- Conclusão de P&D do jogador.
- Fabricação concluída / peça pronta para instalação do jogador.
- Slot de patrocínio disponível para o jogador, emitido quando a equipe passa de 5 slots ativos para menos de 5.
- Término de programa de desenvolvimento de piloto do jogador.

## Comportamento
- Um aviso por vez na Home, com temporada, semana, título e mensagem.
- `CONTINUAR` marca somente aquele aviso como lido.
- `VER NOTÍCIA` abre a Central de Notícias.
- Resultados de GP e aviso de nova temporada permanecem fora desse modal.
- A Central de Notícias continua sendo o histórico; os cards da Home são alertas, não substitutos do registro.

## Validação estática realizada
- Verificados os filtros de categoria/títulos dos avisos.
- Verificada a criação de notificações de conclusão de fábrica e programa de piloto.
- Verificada a condição de transição para slot de patrocínio livre.
- ZIP íntegro e 193 assets mantidos.

## Limitação
A compilação Android/Gradle e os testes de interface em dispositivo ainda precisam ser executados no ambiente Android.
