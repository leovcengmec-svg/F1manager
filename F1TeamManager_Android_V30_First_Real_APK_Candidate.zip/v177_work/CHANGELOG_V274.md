# V274 — robust driver class-change event

- Corrected annual driver class-change selection so a randomly selected boundary class cannot waste the scheduled event by receiving an invalid direction (Fraco demotion or Lenda promotion).
- The event now selects from drivers with at least one valid adjacent class and selects only a valid direction. The existing class ladder and attribute values remain unchanged.
- Added a deterministic standalone stress audit for 200 seasons of annual-event calendars and team-event effects.
