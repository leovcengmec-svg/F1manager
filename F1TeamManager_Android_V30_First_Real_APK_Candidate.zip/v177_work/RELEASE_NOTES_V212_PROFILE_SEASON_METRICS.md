V212 — Ajuste visual do perfil do piloto

- Nos oito indicadores de “Desempenho na temporada”, o ícone e o nome agora ficam lado a lado.
- O valor fica abaixo, centralizado horizontalmente no quadro.
- Reduzidos o tamanho do ícone, os espaçamentos e o padding interno dos quadros para diminuir sua altura.
- “Desempenho geral” continua usando a altura compartilhada pela linha (IntrinsicSize.Min + fillMaxHeight), acompanhando o card da temporada depois da redução.
- Nenhum cálculo, dado de carreira ou regra de temporada foi alterado.

Validação: alteração de fonte conferida e ZIP verificado; build Android não executado neste ambiente.
