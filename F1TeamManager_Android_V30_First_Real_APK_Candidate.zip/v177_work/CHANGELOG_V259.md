# V259 — validação ampliada do calendário anual de eventos

- Mantém o calendário sazonal determinístico da V258 e seus limites de frequência.
- Adiciona regressão para varrer múltiplas sementes e temporadas, verificando semanas válidas, ausência de colisões de semana e limites por categoria.
- Mantém os recursos de imagem e o componente nativo de cartão dos eventos.
- Limitação conhecida: o calendário ainda precisa ser persistido no repositório principal da carreira e os efeitos precisam ser aplicados no fluxo semanal real.
- Compilação Android e execução dos testes não realizadas neste ambiente.
