# Changelog V286

- Adicionada regressão de stress para elegibilidade da aquisição por investidores.
- Inventário estático de fontes, testes, assets e histórico documentado.
- versionCode 286 / versionName 0.286.0.
