# Auditoria V303 — Correção de compilação

- Erro reportado: `MainActivity.kt:7039:51`, expressão `when` não exaustiva por ausência de `DRIVER_DEVELOPMENT`.
- Correção: ramo `FacilityType.DRIVER_DEVELOPMENT` adicionado ao seletor de arte, com fallback para `R.drawable.facility_simulator`.
- Conferência estática: todos os valores atuais de `FacilityType` são tratados no `when` da arte das instalações.
- Versão: `versionCode=303`, `versionName=0.303.0`.
- ZIP conferido quanto à integridade estrutural. Build Gradle/APK não executado neste ambiente; a compilação ainda precisa ser confirmada no GitHub Actions.
