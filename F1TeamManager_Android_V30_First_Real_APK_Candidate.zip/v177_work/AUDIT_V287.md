# Auditoria V287 — validador estático integrado

## Objetivo
Adicionar um verificador repetível e sem dependências externas para checar contratos estruturais do projeto, integração dos eventos anuais, preservação do histórico e presença de assets.

## Validação executada neste ambiente
- O script `tools/race_sim_test/validate_project.py` foi executado contra a árvore extraída do projeto.
- O teste valida estrutura e presença de contratos no código-fonte; não equivale a compilação Kotlin/Android nem a simulação em runtime.
- ZIP final verificado com `ZipFile.testzip()`.

## Limitação conhecida
Não foi possível executar Gradle/JUnit nem gerar APK neste ambiente porque o pacote não inclui `gradlew` e não há instalação de Gradle ou compilador Kotlin disponível.

Resultado observado: exit code 0.

```text
PASS | Android manifest exists
PASS | Manifest XML parses
PASS | Launcher activity exported
PASS | Version code is 287
PASS | Version name is 0.287.0
PASS | Java 17 configured
PASS | All annual event kinds exist
PASS | Calendar bounds weeks 1–56
PASS | Multi-week advancement iterates each week
PASS | Annual events only on ordinary weekly path
PASS | Annual events enter central news category
PASS | Central news label exists
PASS | Processed event ledger persisted
PASS | Investor target eligibility checked before weighting
PASS | Acquisition requires two facilities below max
PASS | Acquisition adds 100m
PASS | Budget crisis capped and nonnegative
PASS | Car stats bounded 1–100
PASS | Facility damage never below zero
PASS | Driver events require seven attributes
PASS | Existing source-level regression tests present
PASS | External/local assets directory populated | 193 files
PASS | Asset family drivers present | 100 matching files
PASS | Asset family car_assets present | 2 matching files
PASS | Asset family teams present | 40 matching files
PASS | Asset family circuits present | 50 matching files
PASS | Asset family annual_events present | 1 matching files
PASS | Version history retained | 55 root history/audit docs
PASS | V286 audit preserved
PASS | V287 audit and changelog present
RESULT: 30/30 checks passed
```
