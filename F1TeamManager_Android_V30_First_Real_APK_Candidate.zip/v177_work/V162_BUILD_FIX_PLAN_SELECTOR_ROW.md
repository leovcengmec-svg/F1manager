# V162 — correção de compilação do seletor de planos

- Base: V161.
- Erro reportado pelo build Android: `MainActivity.kt:3129` — referência não resolvida `PlanSelectorRow`.
- Correção: implementado o composable `PlanSelectorRow` usado pela janela de relargada após bandeira vermelha, mantendo a identidade visual escura/vermelha e as ações existentes.
- Metadados atualizados para versionCode 162 / versionName 0.162.0.
- Necessário confirmar com novo build Debug no ambiente Android do usuário.
