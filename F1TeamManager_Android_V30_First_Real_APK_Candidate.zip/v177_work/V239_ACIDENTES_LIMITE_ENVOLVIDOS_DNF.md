# V239 — Frequência e consequências de acidentes

- Um único sorteio global de acidente por volta, em vez de sorteios independentes para cada piloto.
- Chance base por volta: 1,2% multiplicada pelo fator de risco do circuito, limitada a 6%.
- Um evento pode envolver até 5 carros no total (causador + até 4 carros próximos na ordem de corrida).
- Máximo de 3 DNF decorrentes do mesmo acidente, contando o piloto causador.
- Os demais envolvidos podem sofrer dano, perda de tempo e necessidade de reparo nos boxes.
- O texto de cada evento continua identificando os pilotos que realmente recebem a consequência.

Validação: arquivo ZIP testado quanto à integridade. Não foi executado Gradle nem simulação estatística nesta etapa.
