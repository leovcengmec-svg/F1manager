# V290 — Redesign funcional da tela Equipe

- Atualizado o layout real em `MainActivity.kt`, não apenas a imagem de referência.
- Mantida a estrutura de dados existente para orçamento, instalações, carros, pilotos, atributos, estatísticas e histórico.
- Criado `GenericFormulaCarArt` em Canvas para o banner da equipe, reutilizável para todas as equipes.
- Melhorados dimensões, espaçamentos, hierarquia tipográfica, contrastes e bordas dos cards.
- Mantidas ações de navegação da equipe e abertura do perfil dos pilotos.
- Incrementada versão interna para 0.290.0.
