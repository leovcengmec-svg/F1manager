# V254 — Cartão nativo para eventos anuais

- Adicionado `AnnualTeamEventCard`, componente Android nativo em Jetpack Compose que apresenta a arte genérica correspondente ao tipo de evento, título, descrição, temporada e semana.
- O componente reutiliza o mapeamento `AnnualTeamEventArt` e os 12 recursos gráficos adicionados na V253; não duplica nem altera as imagens.
- Mantida a separação dos eventos anuais em relação aos diálogos de classificação/corrida.
- Atualizado `versionCode` para 254 e `versionName` para `0.254.0`.

Nota técnica: o componente está pronto para ser chamado pelo fluxo de gestão semanal, mas esta versão não declara concluída a integração ponta a ponta desse fluxo nem a persistência dos efeitos dos eventos. Build Android e testes em dispositivo não executados.
