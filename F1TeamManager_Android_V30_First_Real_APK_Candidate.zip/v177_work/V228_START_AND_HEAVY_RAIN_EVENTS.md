# V228 — Eventos de largada e chuva forte

- Versão Android: 0.228.0 / versionCode 228.
- Largada ruim: 3% por piloto elegível na primeira volta; aplica perda de 0,15 a 0,60 s ao tempo total e gera evento para o card.
- Perda de controle na chuva forte: 8% por piloto ativo por volta enquanto `Weather.HEAVY_RAIN`; aplica perda de 1,8 a 5,0 s ao tempo total e gera evento para o card. Pode atingir vários pilotos na mesma volta.
- Os dois eventos usam `EventType.CRASH` por compatibilidade com o catálogo atual de eventos e são identificados pelo texto para seleção de imagem.
- Não atribuem punição automaticamente; a punição exige infração e responsabilidade verificadas.
- Limitação: compilação e simulação estatística não foram executadas neste ambiente. A frequência observada e o efeito sobre classificação precisam ser validados em simulações.
