# Auditoria V275

## Falha encontrada
`resolveSeasonBatch` resolvia cada slot usando a lista original de snapshots. Se dois eventos no mesmo lote selecionassem a mesma equipe, o segundo resultado podia sobrescrever o primeiro: por exemplo, uma crise e uma aquisição calculadas ambas a partir do orçamento inicial, ou duas alterações de componentes calculadas a partir do mesmo carro inicial.

## Correção
O motor mantém snapshots mutáveis locais ao lote. Após cada resultado válido, atualiza o snapshot da equipe atingida (orçamento, instalações e carro). O próximo evento para essa equipe parte do estado acumulado. A persistência continua responsabilidade do chamador.

## Testes
Teste de estresse Kotlin/JVM independente do Android executado com 200 temporadas determinísticas e verificações adicionais de acúmulo de efeitos em eventos direcionados à mesma equipe. Não representa build completo do APK nem teste dentro do jogo.
