# Changelog V296
- Estabilizado o layout do cabeçalho durante mudanças climáticas.
- Clima exibido em linha separada e atualizado pelo estado da sessão.
- Selo da semana reposicionado no card da qualificação.
