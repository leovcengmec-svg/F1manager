# V252 — Orquestração semanal de eventos anuais (etapa de integração)

- Adicionado `AnnualTeamEventScheduler`, que cria um plano de eventos para uma semana de gestão e recusa processamento em Q1/Q2/Q3/corrida.
- Usa chave estável temporada/semana para permitir idempotência no repositório de carreira.
- Aplica pesos de seleção por ranking para favorecer equipes fracas e medianas.
- Limita o plano a no máximo um evento comum por semana e mantém os indicadores de aquisição e mudança de classe anual.
- A aquisição continua com entrada de 100.000.000 e duas instalações elegíveis melhoradas; crise, incêndio/terremoto e eventos de carro usam o motor existente.
- Importante: o scheduler produz um plano sem mutar diretamente o save. Ainda é necessário conectar a chamada ao fluxo real de avanço semanal e persistir os resultados/ledger em uma transação da carreira. A mudança de classe requer integração com o repositório canônico dos 100 pilotos.
- Compilação Android e testes automatizados não executados.
