# V155 — Salários por GP e proteção financeira

- Base preservada: ZIP V154, com todos os assets e atualizações anteriores.
- Android versionCode/versionName: 155 / 0.155.0.
- Salários dos pilotos deixam de ser cobrados no início da temporada. São divididos por 30 e cobrados após cada GP concluído; o resto da divisão é liquidado no GP 30.
- Cobrança salarial da IA tem chave idempotente por equipe/temporada/GP e é incluída no snapshot persistido. Snapshots legados são tratados conservadoramente para evitar cobranças retroativas duplicadas.
- Taxa de assinatura continua sendo saída de caixa imediata. A amortização pelos GPs restantes é apenas contábil/informativa e nunca gera uma segunda saída de caixa.
- Débitos da IA continuam protegidos pelo saldo disponível; taxa de assinatura da IA agora usa o mesmo debit() protegido.
- O fluxo principal Android cobra o salário do jogador após o GP e persiste a chave idempotente na preferência local.
- O fluxo headless ManagerSeasonEngine usa o mesmo cálculo por GP e protege repetição via marcador da transação.
- Corrigido o cancelamento do débito anual inicial ao substituir a regra por cobrança por GP.

## Validação

Validar compilação do core Kotlin, teste de idempotência salarial, snapshot AI V154/V155 e integração de temporada. O APK completo só deve ser declarado validado após build Android com Gradle wrapper/SDK disponível.
