# Changelog V295
- Avisos de corrida agora exibem posição do piloto envolvido (ex.: P25).
- Aplicado a eventos individuais e lotes de ocorrências.
- Versão interna 0.295.0.
