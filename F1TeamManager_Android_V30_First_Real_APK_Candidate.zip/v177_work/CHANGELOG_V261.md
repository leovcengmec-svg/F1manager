# V261 — Integração de eventos: auditoria e preparação segura

- Base: V260.
- Mantidos o calendário anual determinístico, os métodos de persistência e o registro de chaves processadas.
- Revisão do fluxo `advanceFreeWeeks`: ele avança em blocos e contém sistemas existentes de instalações, P&D, fábrica e evolução de pilotos; o motor de eventos anuais ainda não está ligado a essa transação.
- Não marcar eventos como processados nem exibir notificações como se os efeitos tivessem sido aplicados: isso evita perder eventos ou criar notícias falsas antes da integração transacional.
- Próximo passo obrigatório: construir snapshots canônicos para equipes do jogador/IA, aplicar os resultados aos repositórios oficiais (orçamento, instalações, carro e classes de piloto), persistir efeitos + ledger e emitir notícias numa operação idempotente por semana.
- Validação nesta entrega: versão atualizada e integridade do ZIP; compilação Android e testes automatizados não executados.
