# Auditoria V278

## Falha identificada
`CareerPreferences.driverAttributes()` reinicializava a lista inteira quando o número de registros parseados era diferente do número de pilotos. Uma única linha malformada podia apagar a evolução válida dos outros 99 pilotos.

## Correção
- Merge por ID contra a lista oficial de pilotos.
- Preservação dos sete atributos de cada linha válida.
- Reparo somente das linhas ausentes/malformadas; descarte de IDs desconhecidos.
- Valores persistidos limitados a 1–100.
- Serialização validada e testes de regressão adicionados.

## Verificação
- Testes unitários adicionados para estado parcial, linha malformada e estado completo.
- Versão conferida: `versionCode=278`, `versionName=0.278.0`.
- A compilação Android não foi executada neste ambiente, pois não há Gradle wrapper/distribuição configurados.
