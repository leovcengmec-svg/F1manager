# V230 — fila de cards e retomada da corrida

## Correção
- A fila de cards agora identifica o lote completo de eventos do snapshot, em vez de comparar apenas a quantidade de eventos. O motor entrega eventos por atualização, portanto um lote menor que o anterior podia ser ignorado.
- Ao fechar um card, a corrida só é retomada quando não restarem cards na fila e não houver decisão do gestor ou parada manual pendente.
- Mantidos o layout, imagens, textos e efeitos dos eventos existentes.

## Verificações realizadas
- Conferência estática dos pontos de coleta dos eventos, fila, fechamento do card e condição de retomada.
- Integridade do ZIP conferida com `unzip -t`.
- Não foi possível executar compilação Gradle nem teste de interface Android neste ambiente; a retomada visual precisa de confirmação no dispositivo.
