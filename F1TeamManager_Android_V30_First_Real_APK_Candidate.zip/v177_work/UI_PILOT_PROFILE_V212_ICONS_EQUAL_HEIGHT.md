V212 — Perfil do piloto: desempenho geral e temporada

- Os cards “Desempenho geral” e “Desempenho na temporada” compartilham a mesma altura na linha.
- Todas as linhas do desempenho geral têm ícone junto ao indicador.
- Todos os oito quadros do desempenho da temporada têm ícone próprio.
- Mantidos os valores, regras de cálculo, histórico e demais fluxos.
- Validação realizada: inspeção estática da alteração. Build Android não executado neste ambiente.
