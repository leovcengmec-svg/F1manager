# V225 — Imagens genéricas para eventos

- Adicionadas 30 imagens genéricas de eventos, padronizadas em WebP 600x330, em `app/src/main/res/drawable-nodpi`.
- Criado `RaceEventImageRegistry` para mapear chaves de evento a recursos Android.
- Incluído `EVENT_ASSETS_CONTACT_SHEET.png` para inspeção visual.
- O registro de imagens está pronto para o card universal; o card ainda precisa chamar `RaceEventImageRegistry.drawableFor(eventKey)` para exibir cada imagem.
- Não altera a lógica do motor, taxas ou punições.
