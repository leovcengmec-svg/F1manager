# V290 — Redesign da tela Equipe

## Base
- Continuidade direta da V289.
- Nome oficial do ZIP preservado.
- Nenhum motor de corrida, calendário, mercado, finanças ou persistência foi removido.

## Alterações de UI
- Aumentados espaçamentos externos e intervalos verticais para 16 dp e 12 dp.
- Card de equipe reorganizado para exibir nome/país/posição/desempenho/pontos e arte genérica de monoposto.
- Arte genérica de carro desenhada por Canvas, independente do ID/equipe e sem carregar pintura específica.
- Cards de orçamento e desempenho receberam hierarquia visual, painéis internos e barras/indicadores mais claros.
- Instalações, carros, pilotos, atributos, temporada e histórico receberam maior espaçamento, tipografia mais legível, bordas discretas e painéis arredondados.
- Estatísticas continuam vinculadas aos valores reais já calculados pela carreira; nenhuma estatística de corrida foi substituída por valor simulado.
- Rolagem vertical principal mantida; instalações e faixa de métricas usam rolagem horizontal interna.

## Validação executada
- ZIP de entrada íntegro e estrutura de projeto preservada.
- Inspeção estática das assinaturas de componentes e chamadas da tela.
- Confirmado um único `GenericFormulaCarArt` e chamada do card de desempenho com overall real.
- Não foi possível executar Gradle/Android SDK nesta sessão; compilação Android ainda requer confirmação no ambiente de build.
