## V269
- Corrigido o resolvedor anual em lote: cada ocorrência de evento de equipe agora seleciona uma única equipe de forma determinística, evitando multiplicar uma ocorrência por todas as equipes. Aquisições usam ponderação que favorece equipes mais fracas.

## V268
- Revisão do calendário anual: a semente de criação permanece fixa e o calendário persistido é reutilizado entre avanços e recargas.
- Mantidos os limites de eventos por temporada e a agenda de semanas únicas.

## V267
- Corrigida a semente do calendário anual de eventos para ser estável entre avanços semanais e recargas.
