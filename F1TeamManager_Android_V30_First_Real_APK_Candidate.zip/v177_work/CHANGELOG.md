# V368 — Teste ponta a ponta da simulação instantânea

- Adicionado teste JUnit para executar o serviço de simulação instantânea com o motor real, 80 pilotos e distância programada.
- Verificadas as fases Q1/Q2/Q3 (80/50/20), a classificação final e a rejeição de circuito divergente sem avançar o motor.
- Versão Android atualizada para 0.368.0.
- Execução JUnit e build Android seguem pendentes: o pacote não contém Gradle Wrapper e o ambiente não tem Gradle instalado; a tentativa de compilação isolada de todo o domínio excedeu o tempo disponível.

# V341 — Correção de compilação

- Corrigida referência inválida `team.name` na filtragem de notificações da Home; `team` já é uma `String`.
- Mantida a regra de pontuação aprovada na V340.
- Validação estática e integridade do ZIP; compilação Android ainda precisa ser executada no ambiente Gradle.

## V269
- Corrigido o resolvedor anual em lote: cada ocorrência de evento de equipe agora seleciona uma única equipe de forma determinística, evitando multiplicar uma ocorrência por todas as equipes. Aquisições usam ponderação que favorece equipes mais fracas.

## V268
- Revisão do calendário anual: a semente de criação permanece fixa e o calendário persistido é reutilizado entre avanços e recargas.
- Mantidos os limites de eventos por temporada e a agenda de semanas únicas.

## V267
- Corrigida a semente do calendário anual de eventos para ser estável entre avanços semanais e recargas.
