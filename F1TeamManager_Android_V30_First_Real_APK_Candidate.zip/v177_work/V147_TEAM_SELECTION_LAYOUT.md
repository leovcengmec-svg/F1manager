# V147 — Team Selection Layout Adjustment

- Kept the V146 current UI/architecture as base.
- Team selection cards retain Overall and Reliability values.
- Moved the ESCOLHER button to the upper area of the card.
- Reduced button width slightly to return horizontal space to pilot information.
- Reserved compact fixed widths for Overall and Confiabilidade.
- Allocated the remaining row width to Piloto 1 and Piloto 2 so driver names have substantially more room.
- No legacy API or old team/car model was restored.
