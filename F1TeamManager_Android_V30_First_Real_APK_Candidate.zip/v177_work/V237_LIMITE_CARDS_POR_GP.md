# V237 — Limite de cards por Grande Prêmio

- Limite visual: no máximo 8 cards de eventos relevantes por GP.
- Cada card continua agrupando os eventos relevantes do mesmo lote de atualização, inclusive ocorrências envolvendo mais de um piloto.
- Ao atingir o limite, a corrida não é interrompida por novos cards de evento naquele GP.
- O limite é somente da apresentação: não apaga nem reverte eventos, perdas de tempo, danos ou outros efeitos calculados pelo motor.
- Eventos prioritários continuam ordenados dentro de cada lote (bandeira vermelha, Safety Car, VSC, incidentes, abandono, falha mecânica, pit stop e clima).

Validação pendente: compilar APK e testar uma corrida completa, incluindo múltiplos eventos na mesma volta e passagem para o próximo GP.
