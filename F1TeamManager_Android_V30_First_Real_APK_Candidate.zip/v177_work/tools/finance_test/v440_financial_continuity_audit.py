#!/usr/bin/env python3
"""Source-contract audit for financial continuity across saves and repeated GP callbacks.
This deliberately does not claim to execute Kotlin/Android runtime behavior.
"""
from pathlib import Path
import re, sys
ROOT=Path(__file__).resolve().parents[2]
checks=[]
def check(name, ok, detail=''):
    checks.append((name,bool(ok),detail))
def read(path):
    p=ROOT/path
    return p.read_text(encoding='utf-8') if p.is_file() else ''
ai=read('app/src/main/java/com/f1teammanager/core/manager/AITeamFinancialEngine.kt')
sponsor=read('app/src/main/java/com/f1teammanager/core/manager/TeamSponsorshipEngine.kt')
finance=read('app/src/main/java/com/f1teammanager/core/manager/FinanceEngine.kt')
models=read('app/src/main/java/com/f1teammanager/core/manager/ManagerModels.kt')
prefs=read('app/src/main/java/com/f1teammanager/CareerPreferences.kt')
season_audit=read('tools/race_sim_test/TwoSeasonChainRuntimeAudit.kt')
check('AI GP settlement uses stable season/round key', 'AI_GP_SETTLEMENT:$season:$round' in ai)
check('AI GP settlement key persisted in snapshot', 'raceSettlementKeys.sorted()' in ai and 'raceSettlementKeys=if (p.size >= 27)' in ai)
check('AI snapshot restores per-GP salary keys', 'salaryPaidGps.clear()' in ai and 'salaryPaidGps += Triple(team, paidSeason, paidRound)' in ai)
check('AI salary charge checks duplicate key before charging', 'if (key in salaryPaidGps) return s' in ai)
check('AI constructors prize is once per season', 'if (season in s.finance.seasonPrizesPaid) return s' in ai)
check('Sponsor duration uses durable team/season/round key', 'val key="$teamId:$season:$round"' in sponsor and 'if (key in processedRaceKeys) return state' in sponsor)
check('Sponsor idempotency ledger included in snapshot', '@V356|' in sponsor and 'processedRaceKeys.sorted()' in sponsor)
check('Player GP settlement is idempotent when season/round supplied', 'GP_SETTLEMENT:$season:$round' in finance and 'settlementKey in state.finance.raceSettlementKeys' in finance)
check('Player constructors prize idempotency marker', 'season in state.finance.seasonPrizesPaid' in finance)
check('Finance snapshot contains race settlement ledger', 'raceSettlementKeys.sorted()' in ai and 'p[26]' in ai)
check('Two-season 60-GP integration audit source present', 'repeat(60)' in season_audit and '2028 GP1' in season_audit)
check('Two-season audit verifies salary ledger cardinality', 'salaryPaidRounds + manager.finance.salaryOutstanding.keys' in season_audit)
gradle_version = (ROOT/'app/build.gradle.kts').read_text(encoding='utf-8')
version_code = re.search(r'versionCode\s*=\s*(\d+)', gradle_version)
version_name = re.search(r'versionName\s*=\s*"([^"]+)"', gradle_version)
check('Version code/name metadata are internally consistent', bool(version_code and version_name and version_name.group(1) == f"0.{int(version_code.group(1))}.0"))
for name,ok,detail in checks:
    print(('PASS' if ok else 'FAIL')+' | '+name+((' | '+detail) if detail else ''))
failed=sum(not ok for _,ok,_ in checks)
print(f'RESULT: {len(checks)-failed}/{len(checks)} financial continuity source checks passed')
print('LIMIT: Source-contract audit only; Kotlin integration audit and Android runtime were not executed here.')
sys.exit(1 if failed else 0)
