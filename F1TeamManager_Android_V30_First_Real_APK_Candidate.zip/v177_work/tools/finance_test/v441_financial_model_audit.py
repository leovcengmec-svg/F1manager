#!/usr/bin/env python3
"""Deterministic source/data audit for 40-team financial model invariants (not Android runtime)."""
from pathlib import Path
import re, sys
ROOT = Path(__file__).resolve().parents[2]
checks=[]
def check(name, ok, detail=''):
    checks.append((name, bool(ok), detail))
def read(path):
    p=ROOT/path
    return p.read_text(encoding='utf-8') if p.is_file() else ''
prize=read('app/src/main/java/com/f1teammanager/core/manager/SeasonPrizeEngine.kt')
cost=read('app/src/main/java/com/f1teammanager/core/manager/RaceOperatingCost.kt')
profile=read('app/src/main/java/com/f1teammanager/core/manager/InitialTeamProfile.kt')
test=read('app/src/test/kotlin/com/f1teammanager/core/manager/FinancialModelV441Test.kt')
gradle=read('app/build.gradle.kts')
checks_values=[int(x.replace('_','')) for x in re.findall(r'\b(?:1|2|3|4|5|6|7|8|9|10|11|12|13|14|15|16|17|18|19|20|21|22|23|24|25|26|27|28|29|30|31|32|33|34|35|36|37|38|39|40)\s*->\s*([0-9_]+)L', prize)]
check('constructor prize has explicit rank table', len(checks_values) == 39, f'{len(checks_values)} explicit rows plus final else')
check('constructor prize endpoints retained', '100_000_000L' in prize and '10_000_000L' in prize)
check('all three canonical operating cost tiers exist', all(v in cost for v in ('2_200_000L','1_700_000L','1_200_000L')))
check('opening budgets exist for all three team levels', all(v in profile for v in ('100_000_000L','83_750_000L','67_500_000L')))
check('JUnit covers prize monotonicity and unique values', 'StrictlyDescendingAndBounded' in test and 'prizes.toSet().size' in test)
check('JUnit checks costs across all database teams', 'WorldDatabase.teams.forEach' in test and 'RaceOperatingCost.forTeam' in test)
check('current version set to V442', 'versionCode = 442' in gradle and 'versionName = "0.442.0"' in gradle)
for name,ok,detail in checks:
    print(('PASS' if ok else 'FAIL')+' | '+name+((' | '+detail) if detail else ''))
failed=sum(not ok for _,ok,_ in checks)
print(f'RESULT: {len(checks)-failed}/{len(checks)} financial model source checks passed')
print('LIMIT: Static source/data audit only; does not execute Kotlin/JUnit or compile Android.')
sys.exit(1 if failed else 0)
