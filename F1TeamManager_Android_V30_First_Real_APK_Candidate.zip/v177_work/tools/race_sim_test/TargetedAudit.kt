package com.f1teammanager.core.race

fun main() {
    val seeds = 1..200
    var completed = 0
    var weatherEvents = 0
    var weatherDecisionCount = 0
    var fuelDecisions = 0
    var dryToRainTransitions = 0
    var rainToDryTransitions = 0
    var repeatFuelAlertsAfterSave = 0
    val savedFuelDrivers = mutableSetOf<Pair<Int, Int>>()
    val weatherStates = mutableSetOf<Weather>()
    var maxSameLapGap = 0.0
    val failures = mutableListOf<String>()
    for (seed in seeds) {
        val circuit = RaceCircuit(1000 + seed, "Targeted GP", 100, 82_000L, crashRisk = 0.0, reliabilityRisk = 0.0, safetyCarRisk = 0.0)
        val base = RaceParticipant(1,"Driver",1,"Team",70,70,70,70,70,70,70,70,98,0,70,70,70,70,70,70)
        val participants = (1..80).map { id -> base.copy(driverId=id, driverName="D$id", teamId=((id-1)/2)+1, teamName="T${((id-1)/2)+1}") }
        val engine = CareerWeekendEngine(seed)
        engine.start(participants, circuit, 1)
        repeat(3) { engine.simulateQualifyingPhase() }
        var snap = engine.snapshotForUi()
        var guard = 0
        while (!snap.completed && guard++ < 200) {
            val beforeWeather = snap.weather
            weatherStates += snap.weather
            if (snap.decision != null) {
                val req = snap.decision!!.request
                when (req.type) {
                    ManagerDecisionType.WEATHER_CHANGE -> {
                        weatherDecisionCount++
                        val action = when (snap.weather) {
                            Weather.LIGHT_RAIN, Weather.MEDIUM_RAIN -> ManagerDecisionAction.CHANGE_TYRE_INTERMEDIATE
                            Weather.HEAVY_RAIN -> ManagerDecisionAction.CHANGE_TYRE_WET
                            else -> ManagerDecisionAction.CHANGE_TYRE_MEDIUM
                        }
                        snap = if (req.driverId in snap.plans.keys) engine.choose(action) else engine.choose(ManagerDecisionAction.STAY_OUT)
                    }
                    ManagerDecisionType.FUEL_CRITICAL -> {
                        fuelDecisions++
                        savedFuelDrivers += seed to (req.driverId ?: -1)
                        snap = engine.choose(ManagerDecisionAction.SAVE_FUEL)
                    }
                    else -> snap = engine.choose(ManagerDecisionAction.STAY_OUT)
                }
            } else snap = engine.advance()
            weatherEvents += snap.events.count { it.type == EventType.WEATHER_CHANGE }
            weatherStates += snap.weather
            if (beforeWeather in listOf(Weather.DRY, Weather.CLOUDY) && snap.weather in listOf(Weather.LIGHT_RAIN, Weather.MEDIUM_RAIN, Weather.HEAVY_RAIN)) dryToRainTransitions++
            if (beforeWeather in listOf(Weather.LIGHT_RAIN, Weather.MEDIUM_RAIN, Weather.HEAVY_RAIN) && snap.weather in listOf(Weather.DRY, Weather.CLOUDY)) rainToDryTransitions++
            snap.events.filter { it.type == EventType.WEAR_WARNING && it.detail.contains("combustível", ignoreCase = true) }.forEach { ev ->
                if (ev.driverId != null && (seed to ev.driverId) in savedFuelDrivers) repeatFuelAlertsAfterSave++
            }
            if (snap.weather != beforeWeather) {
                val expected = when (snap.weather) {
                    Weather.DRY, Weather.CLOUDY -> TyreModel.dryCompounds
                    Weather.LIGHT_RAIN, Weather.MEDIUM_RAIN -> TyreModel.wetCompounds
                    Weather.HEAVY_RAIN -> listOf(Tyre.WET)
                }
                // Automatic tyre plan choices must never leave the AI on an ineligible compound after a weather change.
                snap.plans.values.filter { it.activePlan != "MANUAL" }.forEach { p ->
                    if (p.tyre !in expected && snap.weather in listOf(Weather.DRY, Weather.CLOUDY)) {
                        failures += "seed=$seed dry/cloudy with rain tyre ${p.tyre}"
                    }
                }
            }
        }
        if (snap.completed) completed++ else failures += "seed=$seed did not finish"
        val result = if (snap.completed) engine.result() else null
        if (result != null) {
            if (result.classification.size != 80) failures += "seed=$seed classification=${result.classification.size}"
            val ordered = result.classification.sortedBy { it.position }
            for (i in 1 until ordered.size) {
                val a = ordered[i-1]; val b = ordered[i]
                if (a.laps == b.laps) {
                    val gap = (b.totalTimeMs - a.totalTimeMs).coerceAtLeast(0L) / 1000.0
                    if (gap > maxSameLapGap) maxSameLapGap = gap
                    if (gap > 600.0) failures += "seed=$seed suspicious gap=${gap}s"
                }
            }
        }
    }
    println("RACES=${seeds.count()} COMPLETED=$completed WEATHER_EVENTS=$weatherEvents WEATHER_DECISIONS=$weatherDecisionCount DRY_TO_RAIN=$dryToRainTransitions RAIN_TO_DRY=$rainToDryTransitions WEATHER_STATES=${weatherStates.sortedBy { it.ordinal }} FUEL_CRITICAL_DECISIONS=$fuelDecisions REPEAT_FUEL_ALERTS_AFTER_SAVE=$repeatFuelAlertsAfterSave MAX_SAME_LAP_GAP_SEC=$maxSameLapGap")
    if (repeatFuelAlertsAfterSave > 0) failures += "fuel alerts repeated after SAVE_FUEL: $repeatFuelAlertsAfterSave"
    if (dryToRainTransitions == 0 || rainToDryTransitions == 0) failures += "weather transition coverage incomplete"
    if (fuelDecisions == 0) failures += "no fuel critical decisions exercised"
    if (failures.isEmpty()) println("TARGETED_AUDIT_PASS") else { println("TARGETED_AUDIT_FAILURES=${failures.size}"); failures.take(50).forEach(::println); error("targeted audit failed") }
}
