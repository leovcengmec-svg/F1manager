#!/usr/bin/env python3
"""Final structural release audit for the current F1 Team Manager Android package.

This intentionally does not claim to replace Gradle, Android SDK, JUnit, or device tests.
"""
from pathlib import Path
import re
import sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[2]
checks = []
def check(name, condition, detail=""):
    checks.append((name, bool(condition), detail))

app_gradle = (ROOT / "app/build.gradle.kts").read_text(encoding="utf-8")
code = re.search(r"versionCode\s*=\s*(\d+)", app_gradle)
name = re.search(r'versionName\s*=\s*"([^"]+)"', app_gradle)
check("Version code is positive and readable", bool(code and int(code.group(1)) >= 1))
check("Version name matches version code", bool(code and name and name.group(1) == f"0.{int(code.group(1))}.0"))
check("Java 17 configured", "JavaVersion.VERSION_17" in app_gradle)

manifest_path = ROOT / "app/src/main/AndroidManifest.xml"
try:
    manifest = ET.parse(manifest_path).getroot()
    ns = {"a": "http://schemas.android.com/apk/res/android"}
    check("Android manifest parses", True)
    check("Application ID and namespace remain aligned", "applicationId = \"com.f1teammanager\"" in app_gradle and "namespace = \"com.f1teammanager\"" in app_gradle)
    activities = manifest.findall(".//activity")
    check("Launcher activity exists", any(
        any(x.attrib.get("{http://schemas.android.com/apk/res/android}name") == "android.intent.action.MAIN" for x in a.findall(".//intent-filter/action"))
        and any(x.attrib.get("{http://schemas.android.com/apk/res/android}name") == "android.intent.category.LAUNCHER" for x in a.findall(".//intent-filter/category"))
        for a in activities))
except Exception as exc:
    check("Android manifest parses", False, str(exc))

required = [
    "app/src/main/java/com/f1teammanager/MainActivity.kt",
    "app/src/main/java/com/f1teammanager/CareerPreferences.kt",
    "app/src/main/java/com/f1teammanager/PendingRaceFinalization.kt",
    "app/src/main/java/com/f1teammanager/core/race/InstantSimulationService.kt",
    "app/src/main/java/com/f1teammanager/core/manager/RaceFinalizationJournal.kt",
    "app/src/main/java/com/f1teammanager/core/manager/ManagerSeasonEngine.kt",
    "app/src/main/java/com/f1teammanager/core/manager/RaceOperatingCost.kt",
    "app/src/test/kotlin/com/f1teammanager/core/manager/RaceOperatingCostV438Test.kt",
    "tools/finance_test/v439_finance_stress_test.py",
    "tools/finance_test/v440_financial_continuity_audit.py",
    "app/src/test/kotlin/com/f1teammanager/core/season/TwoSeasonChainAuditTest.kt",
    "tools/race_sim_test/TwoSeasonChainRuntimeAudit.kt",
]
for rel in required:
    check(f"Required project file exists: {Path(rel).name}", (ROOT / rel).is_file())

assets = ROOT / "app/src/main/assets"
asset_files = [p for p in assets.rglob("*") if p.is_file()] if assets.exists() else []
check("External assets directory populated", len(asset_files) >= 193, f"count={len(asset_files)}")
for family, minimum in [("drivers", 80), ("teams", 40), ("circuits", 50)]:
    matches = [p for p in asset_files if family in str(p).lower()]
    check(f"Asset family {family} retained", len(matches) >= minimum, f"count={len(matches)}")

history = list(ROOT.glob("AUDIT_V*.md")) + list(ROOT.glob("CHANGELOG_V*.md"))
check("Version history retained", len(history) >= 225, f"docs={len(history)}")
for rel in [f"CHANGELOG_V{int(code.group(1))}.md" if code else "CHANGELOG_V1.md", f"AUDIT_V{int(code.group(1))}.md" if code else "AUDIT_V1.md"]:
    check(f"Audit document retained: {rel}", (ROOT / rel).is_file())

for name, ok, detail in checks:
    print(("PASS" if ok else "FAIL") + " | " + name + (f" | {detail}" if detail else ""))
failed = sum(not ok for _, ok, _ in checks)
print(f"RESULT: {len(checks)-failed}/{len(checks)} structural checks passed")
if failed:
    sys.exit(1)
print("LIMIT: This audit does not compile the Android app or execute official JUnit/device tests.")
