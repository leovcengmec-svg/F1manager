package com.f1teammanager.core.manager

enum class CarComponent { ENGINE, CHASSIS, FRONT_WING, REAR_WING, BRAKES, ELECTRIC_POWER_UNIT }
enum class FacilityType { FACTORY, RESEARCH, WIND_TUNNEL, SIMULATOR, SCOUTING, DRIVER_DEVELOPMENT, MARKETING }
data class TeamCarState(
    val aerodynamics:Int, val chassis:Int, val engine:Int, val reliability:Int,
    val frontWing:Int=aerodynamics, val rearWing:Int=aerodynamics, val brakes:Int=chassis,
    val electricPowerUnit:Int=engine
) {
    fun normalized() = copy(aerodynamics=aerodynamics.coerceIn(1,100), chassis=chassis.coerceIn(1,100), engine=engine.coerceIn(1,100), reliability=reliability.coerceIn(1,100), frontWing=frontWing.coerceIn(1,100), rearWing=rearWing.coerceIn(1,100), brakes=brakes.coerceIn(1,100), electricPowerUnit=electricPowerUnit.coerceIn(1,100))
}
object FacilityEngine { fun label(type:FacilityType)=type.name }
