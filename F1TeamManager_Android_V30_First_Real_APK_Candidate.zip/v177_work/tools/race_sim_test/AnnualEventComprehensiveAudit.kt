package com.f1teammanager.core.manager

/** Direct Kotlin runtime audit for all annual-event effects and edge bounds. */
fun main() {
    val failures = mutableListOf<String>()
    var assertions = 0
    fun expect(ok: Boolean, label: String) { assertions++; if (!ok) failures += label }
    val engine = AnnualTeamEventEngine
    val baseCar = TeamCarState(65, 64, 66, 70, 63, 62, 65, 67)
    val baseFacilities = FacilityType.values().associateWith { 5 }
    val base = AnnualTeamEventEngine.TeamSnapshot(1, 20, 40, 500_000_000L, baseFacilities, baseCar)

    // Budget crisis boundaries and investor grant / eligibility.
    val crisis = engine.applyFinancialCrisis(base.copy(budget=500_000_000L), 1, 1)
    expect(crisis.budget == 450_000_000L, "crisis must remove 10% when below cap")
    val cappedCrisis = engine.applyFinancialCrisis(base.copy(budget=2_000_000_000L), 1, 1)
    expect(cappedCrisis.budget == 1_900_000_000L, "crisis loss must cap at 100m")
    val emptyBudgetCrisis = engine.applyFinancialCrisis(base.copy(budget=0L), 1, 1)
    expect(emptyBudgetCrisis.budget == 0L, "crisis must not make budget negative")
    val acquisition = engine.applyAcquisition(base, 1, 2, 123)
    expect(acquisition.budget == base.budget + 100_000_000L, "investor grant must add 100m")
    expect(acquisition.facilities.values.sum() == base.facilities.values.sum() + 2, "investor grant must upgrade two distinct facilities")
    val full = base.copy(facilities=FacilityType.values().associateWith { 10 })
    expect(engine.applyAcquisition(full, 1, 2, 123).event == null, "investor event must no-op when no facility is eligible")

    // All car and reliability event deltas stay bounded and preserve unrelated fields.
    for (gain in listOf(true, false)) {
        val carResult = engine.applyCarEvent(base, 2, 4, gain, 77)
        val car = carResult.car
        expect(listOf(car.aerodynamics,car.chassis,car.engine,car.reliability,car.frontWing,car.rearWing,car.brakes,car.electricPowerUnit).all { it in 1..100 }, "car event stats remain 1..100 gain=$gain")
        val rel = engine.applyReliabilityEvent(base, 2, 4, gain, 77)
        expect(rel.car.reliability in 1..100, "reliability remains 1..100 gain=$gain")
        expect(rel.car.engine == base.car.engine && rel.car.chassis == base.car.chassis, "reliability event changes no unrelated component gain=$gain")
    }
    val lowReliability = engine.applyReliabilityEvent(base.copy(car=baseCar.copy(reliability=1)), 2, 4, false, 77)
    expect(lowReliability.car.reliability == 1, "reliability loss clamps at 1")
    val highReliability = engine.applyReliabilityEvent(base.copy(car=baseCar.copy(reliability=100)), 2, 4, true, 77)
    expect(highReliability.car.reliability == 100, "reliability gain clamps at 100")

    // Facility damage/upgrade bounds.
    val fire = engine.applyFacilityDamage(base, 3, 7, false, 55)
    expect(fire.facilities.values.all { it in 0..10 }, "fire facility levels stay 0..10")
    expect(fire.facilities.values.sum() < base.facilities.values.sum(), "fire damages at least one eligible facility")
    val quake = engine.applyFacilityDamage(base, 3, 7, true, 55)
    expect(quake.facilities.values.all { it in 0..10 }, "earthquake facility levels stay 0..10")
    val noDamage = engine.applyFacilityDamage(base.copy(facilities=FacilityType.values().associateWith { 0 }), 3, 7, true, 55)
    expect(noDamage.event == null, "damage event no-ops when every facility is already zero")
    val upgradeSlot = AnnualTeamEventSeasonCalendar.Slot(9, AnnualTeamEventEngine.Kind.FACILITY_UPGRADE, 1)
    val upgraded = engine.resolveScheduledTeamEvent(upgradeSlot, 3, base.copy(facilities=FacilityType.values().associateWith { 9 }), 12)
    expect(upgraded != null && upgraded.facilities.values.all { it in 0..10 }, "facility upgrade remains within cap")
    expect(upgraded!!.facilities.values.sum() == FacilityType.values().size * 9 + 1, "facility upgrade adds exactly one level")
    val noUpgrade = engine.resolveScheduledTeamEvent(upgradeSlot, 3, full, 12)
    expect(noUpgrade?.event == null, "facility upgrade no-ops at all level 10")

    // Driver attributes, class ladder and calendar invariants.
    val attrs = listOf(50, 51, 52, 53, 54, 55, 56)
    for (klass in listOf("Fraco", "Médio", "Forte", "Pro", "Lenda")) for (gain in listOf(true, false)) {
        val result = engine.applyDriverAttributeEvent(99, "Test Driver", attrs, klass, 3, 8, gain, 1)
        expect(result.attributes.size == 7, "driver event keeps seven attributes class=$klass gain=$gain")
        val limits = when(klass) { "Fraco" -> 40..59; "Médio" -> 40..79; "Forte" -> 40..89; "Pro" -> 40..94; else -> 40..100 }
        expect(result.attributes.all { it in limits }, "driver event honors class limits class=$klass gain=$gain")
        expect(result.attributes.zip(attrs).count { it.first != it.second } <= 1, "driver event changes at most one attribute class=$klass gain=$gain")
    }
    expect(engine.applyDriverAttributeEvent(1, "Bad", listOf(1,2), "Lenda", 1, 1, true, 1).event == null, "malformed driver attribute row is ignored")
    val ladder = listOf("Fraco", "Médio", "Forte", "Pro", "Lenda")
    ladder.forEachIndexed { i, current ->
        listOf(true, false).forEach { promote ->
            val next = engine.adjacentDriverClass(current, promote, 5)
            if (i == 0 && !promote || i == ladder.lastIndex && promote) expect(next == null, "class ladder rejects edge transition $current promote=$promote")
            else expect(next == ladder[i + if (promote) 1 else -1], "class ladder adjacent transition $current promote=$promote")
        }
    }
    expect(engine.adjacentDriverClass("Unknown", true, 5) == null, "unknown class is rejected")
    expect(!engine.canApplyWeeklyEvent(2026, 10, true), "sports screens reject weekly events")
    expect(!engine.canApplyWeeklyEvent(2026, 0, false) && !engine.canApplyWeeklyEvent(2026, 57, false), "invalid weeks rejected")
    expect(engine.canApplyWeeklyEvent(2026, 56, false), "week 56 accepted on normal management screen")
    for (season in 1..500) {
        val slots = AnnualTeamEventSeasonCalendar.generate(season, 20261010)
        expect(slots == AnnualTeamEventSeasonCalendar.generate(season, 20261010), "calendar deterministic season=$season")
        expect(slots.all { it.week in 1..56 }, "calendar weeks bounded season=$season")
        expect(slots.map { it.week }.distinct().size == slots.size, "calendar weeks unique season=$season")
        expect(slots.count { it.kind == AnnualTeamEventEngine.Kind.INVESTOR_ACQUISITION } <= 1, "acquisition at most once season=$season")
        expect(slots.count { it.kind == AnnualTeamEventEngine.Kind.DRIVER_CLASS_CHANGE } <= 1, "class event at most once season=$season")
        expect(slots.count { it.kind == AnnualTeamEventEngine.Kind.FINANCIAL_CRISIS } <= 2, "crises capped season=$season")
    }
    println("ASSERTIONS=$assertions FAILURES=${failures.size}")
    if (failures.isEmpty()) println("ANNUAL_EVENT_COMPREHENSIVE_PASS") else {
        failures.take(50).forEach(::println)
        error("annual event comprehensive audit failed")
    }
}
