package com.f1teammanager.core.manager

/** Deterministic stress test for the pure annual-event engine; independent of Android runtime. */
fun main() {
    val failures = mutableListOf<String>()
    var seasons = 0
    var slotsChecked = 0
    var teamEvents = 0
    var driverEvents = 0
    var noOps = 0
    for (season in 1..200) {
        val calendar = AnnualTeamEventSeasonCalendar.generate(season, 20261010)
        val again = AnnualTeamEventSeasonCalendar.generate(season, 20261010)
        if (calendar != again) failures += "season=$season calendar is not deterministic"
        if (calendar.any { it.week !in 1..56 }) failures += "season=$season week outside 1..56"
        if (calendar.map { "${it.week}:${it.kind}:${it.ordinal}" }.distinct().size != calendar.size) failures += "season=$season duplicate slot"
        slotsChecked += calendar.size
        val teams = (1..40).map { id ->
            AnnualTeamEventEngine.TeamSnapshot(id, id, 40, if (id % 4 == 0) 0L else id * 3_000_000L,
                FacilityType.values().associateWith { if (id % 5 == 0) 10 else (id % 8) },
                TeamCarState(65, 64, 66, 70, frontWing=63, rearWing=62, brakes=65, electricPowerUnit=67))
        }
        val batch = AnnualTeamEventEngine.resolveSeasonBatch(season, calendar, teams, 20261010)
        val teamSlots = batch.teamResults.map { "${it.first.week}:${it.first.kind}:${it.first.ordinal}" }
        if (teamSlots.distinct().size != teamSlots.size) failures += "season=$season duplicate team result slot"
        batch.teamResults.forEach { (slot, result) ->
            teamEvents++
            if (result.budget < 0L) failures += "season=$season week=${slot.week} negative budget"
            if (result.facilities.values.any { it !in 0..10 }) failures += "season=$season week=${slot.week} facility out of range"
            val c = result.car
            if (listOf(c.aerodynamics,c.chassis,c.engine,c.reliability,c.frontWing,c.rearWing,c.brakes,c.electricPowerUnit).any { it !in 1..100 }) failures += "season=$season week=${slot.week} car stat out of range"
            if (result.event == null) noOps++
        }
        driverEvents += batch.driverSlots.size
        // Every class on the ladder must have at least one valid direction, and a valid
        // direction must always land on the adjacent class without touching driver ratings.
        val ladder = listOf("Fraco", "Médio", "Forte", "Pro", "Lenda")
        ladder.forEachIndexed { i, current ->
            val possible = listOf(true, false).mapNotNull { AnnualTeamEventEngine.adjacentDriverClass(current, it, 20261010) }
            if (possible.isEmpty()) failures += "season=$season class=$current has no adjacent class"
            possible.forEach { next ->
                if (kotlin.math.abs(ladder.indexOf(next) - i) != 1) failures += "invalid class transition $current->$next"
            }
        }
        seasons++
    }
    // Regression: all events target the only team, so later slots must consume the
    // previous slot's result rather than the stale original snapshot.
    val singleTeam = AnnualTeamEventEngine.TeamSnapshot(
        teamId = 7, strengthRank = 1, teamCount = 1, budget = 200_000_000L,
        facilities = FacilityType.values().associateWith { 3 },
        car = TeamCarState(65, 64, 66, 70, frontWing=63, rearWing=62, brakes=65, electricPowerUnit=67)
    )
    val accumulationSlots = listOf(
        AnnualTeamEventSeasonCalendar.Slot(1, AnnualTeamEventEngine.Kind.FINANCIAL_CRISIS, 1),
        AnnualTeamEventSeasonCalendar.Slot(2, AnnualTeamEventEngine.Kind.INVESTOR_ACQUISITION, 2)
    )
    val accumulation = AnnualTeamEventEngine.resolveSeasonBatch(999, accumulationSlots, listOf(singleTeam), 20261010)
    val crisisResult = accumulation.teamResults.firstOrNull { it.first.kind == AnnualTeamEventEngine.Kind.FINANCIAL_CRISIS }?.second
    val acquisitionResult = accumulation.teamResults.firstOrNull { it.first.kind == AnnualTeamEventEngine.Kind.INVESTOR_ACQUISITION }?.second
    if (crisisResult?.budget != 180_000_000L) failures += "batch accumulation: expected crisis budget 180m, got ${crisisResult?.budget}"
    if (acquisitionResult?.budget != 280_000_000L) failures += "batch accumulation: expected acquisition budget 280m after crisis, got ${acquisitionResult?.budget}"
    if (acquisitionResult != null && (acquisitionResult.facilities.values.sum() != singleTeam.facilities.values.sum() + 2)) failures += "batch accumulation: acquisition facilities not applied after previous event"

    // Regression: an investor occurrence must skip teams without two eligible facilities.
    val fullTeam = singleTeam.copy(teamId = 8, facilities = FacilityType.values().associateWith { 10 })
    val eligibleTeam = singleTeam.copy(teamId = 9, facilities = FacilityType.values().associateWith { 10 }.toMutableMap().apply {
        this[FacilityType.FACTORY] = 9
        this[FacilityType.RESEARCH] = 8
    })
    val acquisitionOnly = listOf(AnnualTeamEventSeasonCalendar.Slot(20, AnnualTeamEventEngine.Kind.INVESTOR_ACQUISITION, 1))
    val acquisitionAudit = AnnualTeamEventEngine.resolveSeasonBatch(1000, acquisitionOnly, listOf(fullTeam, eligibleTeam), 20261010)
    if (acquisitionAudit.teamResults.size != 1) failures += "acquisition eligibility: expected exactly one result, got ${acquisitionAudit.teamResults.size}"
    if (acquisitionAudit.teamResults.firstOrNull()?.second?.event?.teamId != eligibleTeam.teamId) failures += "acquisition eligibility: ineligible team selected or event lost"
    if (acquisitionAudit.teamResults.firstOrNull()?.second?.budget != eligibleTeam.budget + 100_000_000L) failures += "acquisition eligibility: budget grant missing"

    println("SEASONS=$seasons SLOTS=$slotsChecked TEAM_RESULTS=$teamEvents DRIVER_SLOTS=$driverEvents NO_OPS=$noOps ACCUMULATION_REGRESSION=${if (failures.isEmpty()) "PASS" else "FAIL"}")
    if (failures.isEmpty()) println("ANNUAL_EVENT_STRESS_PASS") else {
        println("ANNUAL_EVENT_FAILURES=${failures.size}")
        failures.take(40).forEach(::println)
        error("annual event stress audit failed")
    }
}
