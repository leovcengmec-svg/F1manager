# Auditoria V297 — Selo dinâmico de semana na qualificação

- Removido o segundo selo dinâmico de semana que havia sido adicionado na linha inferior do banner.
- O selo dinâmico `SEMANA ${round.weekOfSeason}` foi movido para o canto superior direito do banner, substituindo visualmente a área do texto de semana que já está incorporado à imagem.
- O selo `ROUND` permanece no canto superior esquerdo.
- O valor da semana continua vindo do sistema; o texto embutido na imagem é apenas arte fixa de fundo e não é um dado funcional.
- ZIP íntegro; build Android ainda não executado.
