# V177 — Correção de compilação

- Corrigida a tela de seleção de equipe: `InitialTeamProfile.carState(t)` retorna o estado do carro, não uma garagem de dois carros.
- O Overall exibido agora é obtido por `TeamGarageFactory.fromInitial(t).teamAverageOverall`, coerente com o modelo físico de dois carros e com a ordenação da lista.
- Versão incrementada para 177 (0.177.0).
- A compilação Android precisa ser executada no ambiente de build para homologação final.
