# V272 — Persistência de instalações da IA no grid

- Corrigida a divergência entre instalações da IA salvas no estado financeiro/carreira e instalações enviadas à grade de corrida.
- A grade agora recebe os níveis persistidos por `aiFinance.facilities(teamId)`, preservando os efeitos de eventos anuais (incêndio, terremoto e melhoria) em vez de reconstruir níveis baseados apenas na simulação técnica da semana.
- Mantidos o formato e o nome oficial do ZIP, os assets, o histórico de versões e os demais sistemas.
- Validação estática de integração e simulação isolada do motor; build Android completo não disponível neste ambiente.
