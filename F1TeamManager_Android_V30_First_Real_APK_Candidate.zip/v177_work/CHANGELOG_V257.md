# V257

- Corrigida a janela de sorteio dos eventos especiais anuais: aquisição de investidor e oportunidade de mudança de classe agora só podem ser sorteadas na semana 1, evitando novas tentativas semanais que aumentavam indevidamente a probabilidade acumulada.
- Mantidos os 12 recursos gráficos de eventos e o componente nativo de cartão.
- Incluído teste de regressão para impedir sorteios especiais fora da semana 1.
- Limitação conhecida: a aplicação persistente dos efeitos e a apresentação no fluxo real da carreira ainda exigem integração; compilação/testes não executados nesta etapa.
