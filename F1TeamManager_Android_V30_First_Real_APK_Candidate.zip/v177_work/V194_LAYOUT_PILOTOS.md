V194 — Ajuste da tela Pilotos com base na referência aprovada

Base: V193. Nome externo do ZIP mantido exatamente como definido.
- Mantém cards individuais e resumo de temporada com dados dinâmicos existentes.
- Resumo reestruturado para aproximar a hierarquia da referência: seis indicadores principais em uma linha, complementados por média de chegada e abandonos.
- Comparativo recebeu cabeçalho com retratos dos dois pilotos, nomes e pontos, e passou a incluir a métrica de melhor posição no campeonato.
- Mantidos os dados de evolução, atributos, callbacks e navegação já existentes.
- Integridade do ZIP verificada. Build Android não executado neste ambiente.
