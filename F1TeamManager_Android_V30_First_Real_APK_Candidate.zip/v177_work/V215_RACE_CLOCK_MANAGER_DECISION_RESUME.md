# V215 — Race clock resumes after Manager decision cards

- Replaced the one-shot race tick effect with a lifecycle-scoped loop keyed only to running state, speed, and race-start state.
- The loop reads the latest decision/completion snapshot and waits while a Manager decision is pending.
- Once the final queued decision clears, the race clock resumes without requiring another manual Resume tap.
- Intentional pause still stops the loop; pending Manager decisions still block advancing the engine.
- Preserves prior wet-weather plan, race classification, accumulated-time, and last-lap fixes.

Validation: source-level checks and ZIP integrity only; Android build/device race simulation not executed in this environment.
