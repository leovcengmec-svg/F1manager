# V158 — Persistência da idempotência salarial

- Versão: 0.158.0 / versionCode 158.
- A cobrança de salário do motor de temporada não consulta mais o histórico limitado a 100 transações para saber se um GP já foi pago.
- `TeamFinanceState.salaryPaidRounds` mantém chaves `temporada:GP` como ledger persistente; a gravação e leitura usam SharedPreferences junto do estado financeiro.
- O caminho de pagamento da carreira registra a chave no mesmo commit que grava o financeiro e o marcador de execução.
- Adicionados testes para histórico antigo maior que 100 entradas, repetição do mesmo GP e chaves independentes por GP.
- Mantidos o nome oficial do ZIP e as telas existentes.
- Limitação de validação: sem Gradle wrapper no ZIP; a compilação Android e a simulação completa de 60 GPs precisam ser executadas em ambiente Android/Gradle.
