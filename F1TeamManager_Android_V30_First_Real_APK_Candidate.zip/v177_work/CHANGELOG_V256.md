# V256 — regressão do agendamento de eventos anuais

- Adicionados testes de regressão para bloquear processamento em telas de classificação/corrida, impedir repetição de semanas já processadas, rejeitar semanas fora de 1–56 e verificar determinismo do plano com a mesma entrada.
- Mantido o componente visual nativo e o mapeamento das 12 imagens genéricas introduzidos nas versões anteriores.
- Limitação conhecida: o scheduler ainda não está conectado ao avanço semanal persistente da carreira; esta versão não declara a integração ponta a ponta concluída.
- Não foi possível executar a suíte Android nesta etapa; os testes foram adicionados ao projeto, mas não executados.
