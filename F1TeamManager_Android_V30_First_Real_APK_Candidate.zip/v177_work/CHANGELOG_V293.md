# Changelog V293
- Ampliados os avisos modais da Home para eventos anuais de jogador e IA.
- Adicionados avisos de P&D concluído, fabricação/peça pronta, slot de patrocínio livre e conclusão de desenvolvimento de piloto.
- Mantida a Central de Notícias como histórico persistente.
- Versão interna 0.293.0.
