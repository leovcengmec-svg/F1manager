# V311 — Ajuste de altura do card da equipe

- Movida a bandeira para a linha imediatamente abaixo do nome da equipe.
- A posição funcional da equipe foi movida para logo abaixo da bandeira.
- Reduzida a altura da área principal do card e os espaçamentos internos para eliminar o excesso de espaço inferior.
- Mantida a origem da posição no ranking de força das equipes; nenhuma regra de negócio foi alterada nesta mudança visual.
- Não foram geradas nem adicionadas imagens novas.
- Validação: ZIP verificado; compilação Android e teste no dispositivo pendentes.
