# V249 — Expansão do motor de eventos anuais

- Adicionado evento de confiabilidade separado, com variação de 2–4 pontos e limites 1–100.
- Adicionada regra utilitária de promoção/rebaixamento para classes adjacentes (Fraco, Médio, Forte, Pro, Lenda), sem tocar nos atributos atuais.
- Mantida a probabilidade inicial de 15% para o evento especial de classe (85% de chance de não ocorrer).
- Mantidos os parâmetros da V248: aquisição +100.000.000, crise 10% com teto de 100.000.000, danos de instalações de 1–2 níveis, eventos comuns raros.

## Limitações conhecidas

Este avanço amplia o motor de regras, mas ainda não conecta o sorteio ao fluxo real de mudança semanal nem persiste os efeitos para todas as equipes e pilotos. Compilação e testes automatizados Android não foram executados neste ambiente.
