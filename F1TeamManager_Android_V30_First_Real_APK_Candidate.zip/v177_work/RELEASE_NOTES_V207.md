# F1 Team Manager V207 — preservar tempos sob neutralização
- Corrigido um defeito no agrupamento do pelotão: Safety Car e bandeira vermelha já não sobrescrevem o tempo acumulado de cada carro com intervalos artificiais de 55 ms.
- A classificação final continua baseada nas voltas concluídas e no tempo acumulado real; a notícia do GP usa a classificação final ordenada.
- Acrescentado teste de regressão para impedir que a rotina de agrupamento volte a apagar os tempos acumulados.
- Mantido o nome canônico do ZIP: F1TeamManager_Android_V30_First_Real_APK_Candidate.zip.
- versionCode 207; versionName 0.207.0.
