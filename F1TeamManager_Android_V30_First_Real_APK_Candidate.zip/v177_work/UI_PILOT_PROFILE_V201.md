# V201 — Aplicação do layout aprovado do perfil do piloto
Base: pacote V200 entregue imediatamente antes desta atualização.

- Reconstruído o card de identificação do piloto para aproximar a composição aprovada: fotografia destacada, bandeira, nome, equipe, classe/evolução, contrato, salário e OVR.
- Mantida a tela real `DriverHistory` e seus dados dinâmicos, cálculos, histórico, fotos, bandeiras e logos de equipes.
- Ajustado o texto dos valores dos atributos para caber nos cards sem alterar a estrutura do grid.
- Mantidos os painéis de desempenho geral e da temporada lado a lado e o histórico com dez colunas dentro da largura útil, sem rolagem horizontal.
- Versionamento atualizado para `versionCode = 201` e `versionName = 0.201.0`.

Validação: ZIP testado por integridade. Build Android não executado porque o pacote não inclui Gradle Wrapper e o ambiente não disponibiliza Gradle instalado.
