# V275 — Eventos anuais acumulativos

- Corrigido o processamento em lote: eventos consecutivos que atingem a mesma equipe agora partem do snapshot atualizado pelo evento anterior.
- O orçamento, os níveis das instalações e os componentes do carro são acumulados no estado intermediário durante a resolução do lote; resultados posteriores não sobrescrevem alterações anteriores usando um snapshot antigo.
- Mantida a seleção determinística de alvo, a distribuição ponderada para aquisições e a API pública do motor.
- Preservados o nome oficial do ZIP, o histórico de versões e os assets.
