# V255 — Validação das imagens dos eventos anuais

- Mantida a V254 como base, sem remover recursos ou histórico.
- Adicionado teste de regressão para garantir que todos os tipos de evento anual possuem ID de recurso válido e ilustração dedicada.
- Mantidos os 12 assets genéricos, o catálogo e o componente Compose `AnnualTeamEventCard` introduzidos nas versões anteriores.
- O teste valida o mapeamento de recursos; não substitui compilação Android nem validação visual em dispositivo.
- A integração do cartão com o fluxo real de avanço semanal e a persistência dos efeitos dos eventos continuam pendentes.
