# V168 — Redesign do perfil do piloto

- Base oficial: V167; incrementado o versionamento Android para `versionCode 168` e `versionName 0.168.0`.
- O cartão de perfil distribui melhor o espaço entre retrato, identidade do piloto e dados de contrato/salário.
- O nome do piloto pode ocupar até duas linhas para evitar truncamento em aparelhos estreitos.
- A seção de atributos ganhou melhor legibilidade e proporção frente ao painel de desempenho geral.
- O histórico por temporada usa larguras consistentes e rolagem horizontal, com cabeçalhos e valores legíveis em telas estreitas.
- Preservadas a origem dos dados, as estatísticas, a evolução, os contratos, os demais fluxos e a navegação existentes.
- Nenhuma imagem foi gerada ou alterada nesta atualização.
- Validação de compilação Android/dispositivo pendente.
- Nome externo obrigatório: `F1TeamManager_Android_V30_First_Real_APK_Candidate.zip`.
