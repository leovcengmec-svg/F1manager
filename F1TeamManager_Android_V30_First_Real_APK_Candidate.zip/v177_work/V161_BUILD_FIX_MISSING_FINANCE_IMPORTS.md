# V161 — correção de compilação dos imports financeiros

Base: V160.

## Erro reportado no build do usuário
`CareerPreferences.kt` usava `SignatureFeeSchedule`, `SalaryLedger` e `SignatureFeeAccounting` sem importar os tipos/objetos do pacote `com.f1teammanager.core.manager`. Isso causava referências não resolvidas e erros em cascata de inferência de tipo nas linhas 493, 527 e seguintes.

## Correção
- Importados explicitamente `SignatureFeeSchedule`, `SalaryLedger` e `SignatureFeeAccounting` em `CareerPreferences.kt`.
- Incrementados `versionCode` para 161 e `versionName` para `0.161.0`.
- Nenhuma alteração visual ou remoção de funcionalidade.

## Validação
- Confirmar o ZIP com `unzip -tq`.
- Verificar presença dos imports e metadados 161.
- Build Android completo não foi executado neste ambiente; pedir novo build do usuário para confirmar e tratar eventuais erros subsequentes.
