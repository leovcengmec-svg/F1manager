# Auditoria V298 — Mentalidade automática para todos os pilotos

## Regra alterada
- A cada volta, o motor escolhe Ataque, Equilibrado ou Defesa/Economia com `aiMode` para todos os pilotos, incluindo os pilotos da equipe do jogador.
- A escolha considera combustível projetado, margem de reserva, desgaste de pneus, fase da corrida, proximidade de rivais, habilidade do piloto e chuva forte.
- A decisão automática é refletida em `plan.mode` para manter a interface coerente com o estado atual do motor.
- Os três botões manuais foram substituídos por um indicador não interativo “MENTALIDADE AUTOMÁTICA” que mostra a escolha vigente.
- A decisão estratégica não altera resultados retroativamente; passa a influenciar as voltas seguintes pelo motor existente.

## Preservado
- Pit stops, planos A/B/C/D, pneus, ERS/DRS, combustível, incidentes, classificações e resultados.
- O comando BOX e os demais controles do Manager continuam manuais conforme as regras existentes.

## Validação
- Verificada estaticamente a seleção automática do motor e o indicador na UI.
- ZIP íntegro.
- Compilação Android e simulação real de corrida ainda não executadas neste ambiente.
