# Auditoria V295 — Posição dos pilotos nos avisos de corrida

## Alteração
- O diálogo universal de eventos de corrida recebe a classificação atual da sessão.
- A descrição de cada ocorrência mostra a posição do piloto envolvido, no formato `P25`.
- O resumo de pilotos envolvidos mostra nome + posição quando há posição disponível.
- Em lotes de eventos, cada linha usa o ID do próprio evento para associar a posição correta, sem assumir que todos os eventos envolvem o mesmo piloto.

## Preservado
- Dados do evento e detalhe original.
- Classificação e motor da corrida; não altera posições nem resultados.
- Imagens, consequências, botões e sequência de continuação do aviso.

## Verificação
- Contratos de passagem de dados e formatação de posição verificados estaticamente.
- ZIP validado com `ZipFile.testzip()`.
- A compilação Android ainda precisa ser executada.
