# Changelog V283

- Corrige a seleção de equipe para aquisição por investidores: apenas equipes com duas instalações elegíveis entram no sorteio ponderado.
- Evita consumir a aquisição em uma equipe incapaz de receber as duas melhorias.
- Mantém a ponderação favorável a equipes mais fracas/intermediárias.
- Atualiza versionCode para 283 e versionName para 0.283.0.
