# V263 — Balanceamento do calendário anual de eventos

- Incluídos no sorteio anual eventos de melhoria de instalação (0–2 por temporada).
- Incluídos no sorteio anual eventos de atributo de piloto (0–2 por temporada).
- Mantida a distribuição por semanas únicas entre 1 e 56, sem sorteio semanal irrestrito.
- Mantida a geração determinística a partir da semente da temporada.
- A integração transacional dos efeitos no fluxo de carreira continua pendente; esta versão altera o calendário, não afirma aplicação completa dos efeitos.
