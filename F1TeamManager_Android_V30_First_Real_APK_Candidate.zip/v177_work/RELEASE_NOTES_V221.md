# V221 — evitar decisões redundantes de pneus

- Chuva leve ↔ moderada mantém INTERMEDIÁRIO sem abrir novo card.
- Chuva forte solicita mudança para WET somente quando o piloto não está com WET.
- Redução/encerramento da chuva só oferece troca para seco aos pilotos que ainda usam INTERMEDIÁRIO ou WET.
- Preservados layout, calendário, semanas, lógica de classificação e tempos acumulados.
- Adicionado teste de regressão focado nas transições meteorológicas.
