# V251 — Calibração de raridade e chaves de evento

- Ajustada a probabilidade de evento comum para 3% por semana elegível (em vez de 12%), coerente com a decisão de eventos comuns raros.
- Adicionada validação de temporada/semana e bloqueio de sorteio em telas Q1/Q2/Q3/corrida por meio de `canApplyWeeklyEvent`.
- Adicionada chave estável por ocorrência (`eventLedgerKey`) para a camada de persistência impor unicidade.
- Mantidas as regras V250 e o nome oficial do ZIP.

## Limitação importante
As funções de elegibilidade e ledger ainda precisam ser chamadas pelo fluxo real de mudança de semana, e o ledger deve ser persistido no estado salvo da carreira. Esta versão não é integração ponta a ponta. Compilação Android e simulação de temporadas não foram executadas.
