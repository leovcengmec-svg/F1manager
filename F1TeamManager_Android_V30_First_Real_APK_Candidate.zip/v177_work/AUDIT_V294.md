# Auditoria V294 — Imagens genéricas nos avisos da Home

## Mapeamento encontrado
- Os 12 tipos do motor de eventos anuais já possuíam ilustrações dedicadas em `drawable-nodpi` e mapeamento em `AnnualTeamEventArt.kt`.
- O card modal da Home não mostrava imagens: a estrutura tinha apenas faixa de cor, título, metadados e mensagem.
- Avisos operacionais (P&D, peça pronta/fabricada, slot de patrocínio e desenvolvimento de piloto) não tinham artwork dedicado.

## Assets adicionados
- `notice_rd_complete.webp`
- `notice_part_manufactured.webp`
- `notice_part_install.webp`
- `notice_sponsor_slot.webp`
- `notice_driver_development.webp`

## Implementação
- O card da Home agora seleciona artwork pelos títulos/mensagens dos avisos operacionais.
- Para `ANNUAL_EVENTS`, escolhe a ilustração existente correspondente à categoria do evento (aquisição, crise, carro, confiabilidade, instalação, incêndio, terremoto, evolução/regressão/classe de piloto).
- As imagens são decorativas; a mensagem e os dados continuam sendo texto real do evento.
- Mantidos Central de Notícias, chaves de leitura, ações dos botões e motores de jogo.

## Verificações estáticas
- Todos os recursos `R.drawable.*` usados no `MainActivity.kt` existem.
- Os cinco novos WebP estão no pacote.
- ZIP passou `ZipFile.testzip()` e os 193 assets existentes foram preservados.

## Limitação
A compilação Android e o teste visual em dispositivo não foram executados neste ambiente.
