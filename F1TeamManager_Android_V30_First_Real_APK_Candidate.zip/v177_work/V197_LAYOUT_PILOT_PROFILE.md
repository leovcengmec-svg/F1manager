V197 — Reestruturação da tela de perfil do piloto

- Base: ZIP oficial recebido nesta conversa (V196, versionCode 196).
- Mantido o nome oficial do ZIP: F1TeamManager_Android_V30_First_Real_APK_Candidate.zip.
- Perfil: OVR compacto; atributos em grade uniforme de quatro colunas; desempenho geral em card de largura total.
- Histórico por temporada: colunas proporcionais à largura disponível, sem rolagem horizontal, com todos os indicadores existentes (temporada, equipe, posição, pontos, vitórias, pódios, poles, melhores voltas, GPs e DNFs).
- Preservados os modelos de dados e callbacks existentes; não foi gerada imagem.
- Build Android não executado neste ambiente; a compilação precisa ser validada no ambiente Gradle do projeto.
