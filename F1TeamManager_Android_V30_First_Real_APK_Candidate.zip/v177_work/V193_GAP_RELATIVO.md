# V193 — Gap relativo ao carro imediatamente à frente

Base oficial: V192. Nome externo do ZIP preservado exatamente.

- Classificação ao vivo: P2 compara com P1, P10 com P9, P4 com P3.
- Cards de estratégia dos pilotos usam o mesmo gap relativo.
- Resultado da corrida e classificação salva comparam cada piloto classificado com o carro imediatamente à frente.
- P1 permanece identificado como LÍDER.
- Diferença de voltas continua indicada como +1 VOLTA / +N VOLTAS.
- Não alteradas as regras de DRS, combustível, pneus, pit stops ou outras funcionalidades.
- ZIP integrity/source assertions checked. Android build not run in this environment.
