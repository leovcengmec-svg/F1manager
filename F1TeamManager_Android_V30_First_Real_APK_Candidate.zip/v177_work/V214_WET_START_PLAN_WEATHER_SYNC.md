# V214 — Sincronização do clima com os planos de largada

- Corrige a origem do problema: os planos de pneus eram gerados em `start()` quando o clima ainda estava inicializado como seco.
- Ao concluir a classificação (Q3), os planos da equipe do jogador são reconstruídos usando o clima efetivo no fim da sessão.
- O primeiro composto do Plano A também é aplicado ao estado dos dois carros antes da janela `PLANO DE INÍCIO DA CORRIDA`.
- Mantém a regra central de `TyreModel`: chuva leve/moderada oferece INTERMEDIATE e WET; chuva forte prioriza WET e também oferece INTERMEDIATE; seco/nublado usa slicks.
- Não altera pontuação, calendário, classificação, tempos acumulados, estratégia de corrida nem regras de pausa.

Validação realizada nesta atualização: inspeção do fluxo de inicialização e da geração de planos, revisão estática das alterações e verificação de integridade do ZIP. Build Android e simulação no dispositivo não foram executados neste ambiente.
