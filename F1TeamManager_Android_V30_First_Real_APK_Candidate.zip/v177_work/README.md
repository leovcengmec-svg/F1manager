# F1 Team Manager — código-fonte Android

Projeto Android nativo do F1 Team Manager.

## Versão

- `versionCode`: 243
- `versionName`: 0.243.0

## Compilação

Abra esta pasta no Android Studio e execute a tarefa `assembleDebug`. O projeto usa Kotlin, Jetpack Compose e Gradle Kotlin DSL.

## Estrutura mantida

- `app/src/main`: aplicação, recursos visuais e bases locais usadas pelo jogo.
- `app/src/test`: testes de regressão e auditoria do motor.
- `tools`: utilitários de auditoria/teste.
- `docs`: documentação técnica ainda agrupada separadamente.

Assets externos opcionais podem ser colocados em `Pictures/F1Manager/Assets/` no armazenamento do dispositivo, conforme os nomes aceitos pelo registro de assets do aplicativo.

## Limpeza V243

Removidos do ZIP os históricos de alteração antigos soltos na raiz, páginas HTML de apoio não usadas pelo APK, a folha de contato de imagens e a lista `corefiles.txt` que apontava para caminhos absolutos de outra máquina. Código Kotlin, testes, recursos do aplicativo e ferramentas foram preservados nesta etapa; não foram apagadas classes apenas por suspeita de uso.
