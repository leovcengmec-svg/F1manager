# F1 Team Manager — código-fonte Android

Projeto Android nativo do F1 Team Manager.

## Versão

- `versionCode`: 269
- `versionName`: 0.269.0

## Compilação

Abra esta pasta no Android Studio e execute a tarefa `assembleDebug`. O projeto usa Kotlin, Jetpack Compose e Gradle Kotlin DSL.

## Estrutura mantida

- `app/src/main`: aplicação, recursos visuais e bases locais usadas pelo jogo.
- `app/src/test`: testes de regressão e auditoria do motor.
- `tools`: utilitários de auditoria/teste.
- `docs`: documentação técnica ainda agrupada separadamente.

Assets externos opcionais podem ser colocados em `Pictures/F1Manager/Assets/` no armazenamento do dispositivo, conforme os nomes aceitos pelo registro de assets do aplicativo.

## Limpeza V243

Removidos do ZIP os históricos de alteração antigos soltos na raiz, páginas HTML de apoio não usadas pelo APK, a folha de contato de imagens e a lista `corefiles.txt` que apontava para caminhos absolutos de outra máquina. Código Kotlin, testes, recursos do aplicativo e ferramentas foram preservados nesta etapa; não foram apagadas classes apenas por suspeita de uso.


## Auditoria V245

- Corrigida a versão declarada neste README para corresponder ao build.gradle.kts.
- Revisão estática dos recursos Android: todos os 41 recursos em res/ têm ocorrência textual pelo nome no código/configuração.
- Preservados os 124 arquivos documentais/históricos encontrados no pacote, os testes de regressão e todos os Assets em app/src/main/assets.
- Nenhuma classe Kotlin, imagem, base JSON ou documentação histórica foi excluída nesta etapa. Classes sem referência textual direta permanecem para validação por compilação e análise de carregamento dinâmico.
- Limitação: o ZIP não inclui gradlew/gradle-wrapper.jar; não foi possível executar compilação Gradle local nesta auditoria.


## Auditoria V246 — navegação e acesso aos históricos

- O card de identidade da equipe na Home abre a Central de Equipes.
- O escudo na tela Equipe abre a mesma Central de Equipes.
- Os cards dos pilotos na Central de Equipes abrem o histórico individual do piloto selecionado.
- O botão Voltar do Android agora é tratado pela navegação interna; na Home, solicita confirmação antes de sair, em vez de encerrar o jogo imediatamente.
- O retorno da Central de Equipes preserva a origem (Home ou Equipe), e o retorno do histórico do piloto volta à Central de Equipes.
- Preservados os Assets, as bases, os testes e a documentação histórica existente.
- Limitação desta etapa: compilação Android não executada porque não há Gradle/Gradle Wrapper disponível neste ambiente.


## Correções V247 — avisos e decisões da corrida

- Todos os diálogos ativos da corrida mantêm a simulação pausada; o modo automático é retomado quando todas as pendências forem resolvidas.
- O diálogo de evento exige o botão explícito `CONTINUAR CORRIDA`; toque externo e botão Voltar não o dispensam.
- Removido o botão de fechar que executava `STAY_OUT` implicitamente na decisão do manager.
- Diálogos informativos aguardam a conclusão da decisão do manager e da etapa de box, evitando sobreposição.
- A fila informativa mantém o teto de oito cards por GP; decisões obrigatórias continuam controladas pelo motor, independentemente desse teto.
- Preservados Assets, histórico de versões, testes e demais sistemas.
- Compilação Android não executada: este pacote não inclui Gradle Wrapper e não há Gradle instalado no ambiente de vistoria.
