# Auditoria V285 — validação integrada do avanço semanal e eventos anuais

## Trabalho desta versão
A V285 amplia a auditoria para o contrato de integração entre o avanço de calendário, processamento por semana, persistência e Central de Notícias. Também adiciona um caso para a acumulação de dois eventos em uma mesma equipe dentro de um lote.

## Testes acrescentados/atualizados
- `V266AnnualEventSeasonBatchTest`: aquisição por investidores só seleciona equipes elegíveis; não concede evento a equipes totalmente inelegíveis; e múltiplos slots devem acumular efeitos sobre a mesma equipe sem apagar o efeito anterior.
- `V285AnnualEventIntegrationContractTest`: verifica no código-fonte a iteração de cada semana atravessada, consulta dos eventos pendentes, persistência de chaves, categoria de notícia e separação entre calendário e ledger de processados.

## Verificações estáticas executadas nesta preparação
- O avanço normal itera `eventWeek` de `currentWeek + 1` até `targetWeek`, permitindo processar semanas intermediárias num salto.
- Os eventos pendentes são obtidos por semana e filtrados por chaves já processadas.
- Os efeitos de equipe são salvos antes do ledger de processamento.
- Os eventos de piloto, classes e chaves são entregues à gravação conjunta de `commitAnnualDriverStateAndKeys`.
- A Central de Notícias contém o rótulo EVENTOS ANUAIS e a categoria `ANNUAL_EVENTS`.
- O ZIP foi reaberto e verificado com `testzip()` após o empacotamento.

## Limitações
Não existe Gradle executável nem wrapper no ambiente, então os testes não foram executados nem o aplicativo compilado. Os novos testes são alterações no código-fonte, não resultados de execução. Não se declara uma simulação de temporadas concluída.
