# V276 — Persistência atômica dos eventos de piloto

- Corrigida a janela de falha entre salvar uma mudança de classe de piloto e marcar o evento anual como processado.
- A integração deixa de gravar cada mudança de classe isoladamente durante a resolução; os efeitos ficam no estado local até a persistência final.
- Adicionado `commitAnnualDriverStateAndKeys`, que grava atributos, substituições de classe e chaves de idempotência em uma única transação de SharedPreferences (`commit`).
- Mantida a ordem: efeitos de equipe/garagem/finanças/notícias e estado de IA são persistidos antes da transação final de atributos/classes/chaves.
- Nome oficial do ZIP, assets e histórico de versões preservados.
