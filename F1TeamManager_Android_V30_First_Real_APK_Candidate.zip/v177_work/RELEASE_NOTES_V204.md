# F1 Team Manager V204 — planos de pneus para chuva
- Planos de início e de relargada passam a ser gerados com base no clima vigente.
- Em chuva fraca/média, os planos oferecem Intermediário e WET.
- Em chuva forte, os planos oferecem WET e Intermediário como alternativa.
- Slicks (Soft/Medium/Hard) não são incluídos nos planos gerados para pista molhada.
- Mantidos os planos secos existentes para clima seco/nublado.
- Incluído teste de regressão para geração dos planos.
