# V176 — Correções de compilação

- Corrigido o uso de `DriverDevelopmentEngine.Completion`: notificações agora obtêm `driverId` do objeto `Completion` e usam os atributos retornados pela conclusão como fallback.
- Corrigido acesso inexistente a `facilities` no retorno financeiro da IA; os níveis atualizados são lidos pelo método `aiFinance.facilities(teamId)`.
- Corrigido o overall da equipe na seleção inicial, usando `TeamGarage.teamAverageOverall`.
- Corrigido o histórico de construtores: `ConstructorSeasonRecord` não possui `podiums`; coluna removida da tabela em vez de inventar dados.
- Versão incrementada para 176 (0.176.0).
