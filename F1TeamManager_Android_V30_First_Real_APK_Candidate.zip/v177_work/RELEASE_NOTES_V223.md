# V223 — Especificação de eventos e punições

- Base preservada: V222 (versionCode 222 / versionName 0.222.0).
- Versão incrementada para 223 / 0.223.0.
- Documentada a matriz inicial de taxas por GP, modificadores, consequências e punições proporcionais.
- Definidas regras de causalidade, deduplicação, eventos terminais e auditoria estatística.
- Mantida a referência visual do card universal aprovado e preservado o fluxo de decisões obrigatórias.
- Importante: esta versão fecha a especificação; não declara todas as categorias como implementadas no motor. Implementação e testes por categoria continuam necessários.
- Compilação Android e simulação de 1.000 GPs não executadas nesta etapa.
