# Changelog V294
- Criadas cinco ilustrações genéricas para avisos operacionais da Home.
- Integradas imagens existentes de eventos anuais ao card modal.
- Mantida a lógica de eventos e persistência de leitura.
- Versão interna 0.294.0.
