# V153 — Team Overview layout refinement

- Based directly on the official V152 ZIP; V152 finance guard and salary idempotency retained.
- Added a dedicated `CARROS DA EQUIPE` showcase card immediately after `INSTALAÇÕES` and before `PILOTOS`, with both physical car slots, team-car visual assets when available, each car's Overall and reliability.
- Kept the detailed `ATRIBUTOS DOS CARROS` card after the pilots, matching the approved section order.
- Added the current annual technical-investment cap to the budget card.
- Added the team's current two-driver roster to the team header without inventing principal/headquarters data absent from the current team database.
- Kept existing navigation, financial systems, garage model, race systems, and history untouched.

## Validation
- Core Kotlin compilation and project ZIP integrity to be checked for this release.
- Full APK/device validation is not claimed because the source ZIP has no Gradle wrapper and this environment has no configured Gradle executable.
