# V236 — Eventos simultâneos agrupados

- Eventos relevantes gerados no mesmo lote da atualização da corrida são exibidos em um único card consolidado.
- O card lista cada ocorrência e os pilotos envolvidos, quando identificados.
- O motor continua recebendo e mantendo todos os eventos individualmente; o agrupamento é somente de apresentação e não elimina efeitos de corrida.
- O botão de continuar remove o card do lote e mantém a regra existente de retomada apenas quando não há outros cards, decisão pendente, pit stop bloqueando ou corrida concluída.
- Eventos rotineiros continuam fora dos cards conforme a filtragem da V236.

Validação: ZIP verificado quanto à integridade. Compilação Gradle e teste em dispositivo não executados neste ambiente.
