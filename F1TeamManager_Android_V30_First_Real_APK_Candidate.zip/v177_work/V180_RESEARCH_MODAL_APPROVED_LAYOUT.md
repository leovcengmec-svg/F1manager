# V180 — Modal de pesquisa P&D

Atualização visual baseada na referência aprovada fornecida pelo usuário.

- Mantém a lógica existente de seleção de foco, complexidade, custo, risco, duração e início/cancelamento da pesquisa.
- Reorganiza as opções de complexidade em linhas horizontais compactas, com ícone, nome, duração/custo/risco e indicador de seleção.
- Ajusta espaçamentos, largura responsiva e altura mínima dos cards de foco.
- Não foi gerada nem adicionada nova imagem.
- Versionamento: 180 / 0.180.0.

Validação: revisão estática do código e integridade do ZIP; compilação Android não executada neste ambiente.
