# Changelog V297
- Removido o selo de semana duplicado no banner de qualificação.
- Selo dinâmico movido para o canto superior direito, sobre a área da semana embutida na arte.
