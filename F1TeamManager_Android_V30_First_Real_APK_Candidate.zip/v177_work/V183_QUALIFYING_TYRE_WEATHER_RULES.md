# V183 — Pneus obrigatórios e clima dinâmico na classificação

- Q1 em pista seca: Hard obrigatório.
- Q2 em pista seca: Medium obrigatório.
- Q3 em pista seca: Soft obrigatório.
- Chuva fraca/média: Intermediário para todos os pilotos.
- Chuva forte: Wet para todos os pilotos.
- O clima é compartilhado pela sessão e pode evoluir em checkpoints controlados.
- A mudança de clima atualiza automaticamente os compostos usados na classificação.
- O cálculo de volta aplica o efeito do composto/clima e a habilidade de chuva do piloto.
- A coluna PNEU usa o mesmo ícone circular colorido empregado na corrida.
- A etiqueta da semana tem fundo opaco para evitar que elementos da imagem decorativa interfiram na leitura.
- Versão do app: 0.183.0 (versionCode 183).

Build Android e testes de integração precisam ser executados em ambiente com Android SDK/Gradle configurado antes de considerar a versão homologada.
