# V281 — Persistência parcial sem perda de evolução

- A gravação do lote de eventos anuais agora mescla atributos recebidos com os dados válidos já persistidos.
- Um lote parcial não remove a evolução dos pilotos que não aparecem no lote.
- Alterações de classe são mescladas com os overrides já existentes, evitando apagar mudanças de outros pilotos.
- IDs desconhecidos, classes inválidas e chaves vazias continuam sendo rejeitados.
- A gravação dos atributos, classes e chaves de idempotência permanece em um único commit.
- Nome oficial do ZIP preservado.
