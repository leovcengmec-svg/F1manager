# V187 — Manager decision card layout

Official base: V186 complete source ZIP.

- Replaced the compact default manager decision AlertDialog with a custom scrollable Compose Dialog following the approved visual reference.
- Added Safety Car banner when the decision message identifies a Safety Car event.
- Added driver/position card, current tyre compound and wear, estimated tyre life, remaining race laps, and weather/track-condition summary.
- Replaced plain buttons with descriptive action cards for Box, Stay Out, Extend Stint and any other actions supplied by the decision engine.
- Preserved the decision engine callback flow: BOX opens the existing pit-stop flow; other actions call the existing decision handler.
- ZIP integrity checked; Android compilation and on-device validation still required.
