# Auditoria de estabilização V713 — Central de Recordes

## Base e escopo
- Pacote base: V712 / 0.712.0.
- V713 / 0.713.0 implementa a Central de Recordes na tela já existente `Screen.RECORDS`.
- Mantém o nome público F1 Team Manager V30 e o nome original `F1TeamManager_Android_V30_First_Real_APK_Candidate.zip`.

## Fontes oficiais utilizadas
- `HistoricalDatabase.recordBookSnapshot()` fornece uma projeção consistente obtida com uma única leitura do arquivo histórico combinado (arquivo legado + shards de GPs + shards de temporadas).
- O snapshot deriva resultados por GP, posições, pontos, voltas rápidas, poles, tempos de classificação, campeões e classificações finais anuais.
- Temporadas concluídas são validadas no próprio snapshot: calendário completo, tabelas de pilotos/construtores sem duplicidade e campeões compatíveis com os líderes das tabelas.

## Verificações de implementação
- A tela de Recordes possui Visão Geral, Pilotos, Equipes, Circuitos e Temporadas.
- Cards preservam todos os líderes empatados.
- Categorias de Pilotos e Equipes têm filtros de carreira e temporada.
- Recordes anuais usam os resumos oficiais de temporadas finalizadas; percentuais de poles usam o contador oficial do resumo final, dividido pelo total de GPs registrados para aquele piloto/equipe.
- Carreiras de pilotos que passaram por várias equipes são identificadas como “Múltiplas equipes”, sem atribuir indevidamente o recorde a uma única equipe.
- Circuitos são agrupados pelo nome exato de `circuit`, nunca somente por `grandPrix`.
- Circuitos sem identificação confiável são omitidos da seleção em vez de receberem nome presumido.
- O streak de construtores agrega os dois pilotos em um único evento por GP.
- A detecção de sequência exige rounds contíguos, incluindo a transição GP 30 → GP 1 da temporada seguinte.
- A reconstrução é uma projeção somente de leitura do arquivo histórico; não grava contadores extras no save e não duplica eventos ao reabrir a tela/importar backup.
- O snapshot evita múltiplas leituras independentes do arquivo histórico ao entrar na central, reduzindo I/O em carreiras longas.
- Milestones históricos são reconstruídos deterministicamente a partir da ordem temporada/round.

## Testes criados e executados
`HistoricalRecordsEngineV713Test.kt` cobre:
- agregação de carreira e preservação de empates;
- sequência de equipe contando cada GP uma única vez;
- separação de circuitos diferentes com o mesmo nome de GP;
- isolamento de recordes anuais por temporada concluída;
- percentual de poles e média de pontos por GP;
- identificação de pilotos que passaram por múltiplas equipes;
- reconstrução determinística de marcos sem duplicação.

Resultados nesta sessão:
- Contrato de release: 70/70 verificações estruturais aprovadas.
- Motor de recordes: 7/7 testes direcionados compilados e executados isoladamente com `kotlinc` e stubs mínimos dos modelos/JUnit.
- Regressão anterior de save/backup relacionada ao Scouting: 11/11 verificações estáticas aprovadas com o versionamento atual.
- Análise sintática Kotlin (PSI): `MainActivity.kt`, `HistoricalDatabase.kt`, `HistoricalRecordsEngine.kt` e o teste V713 aprovados.

## Limites
- A compilação Android integral e a suíte JUnit oficial completa ainda dependem do Gradle e Android SDK no GitHub Actions.
- O ZIP de origem não contém Gradle Wrapper e este ambiente não tem Gradle/Android SDK instalados; portanto, esta auditoria não declara APK compilado nem teste em aparelho.
