# V412 — Equilíbrio do mercado de pilotos 55/45

- Meta fixa do mercado: 55% de renovações e 45% de trocas de equipe.
- Aumentada moderadamente a chance semanal de renovação conforme interesse (15%, 12%, 8%, 3%).
- Aumentada moderadamente a atividade de mercado: até 10 equipes por semana; 82% de atividade para equipes com contrato expirando e 10% para elencos completos sem contrato expirando.
- Corrigida a contagem das movimentações para reconhecer os títulos reais das notificações de renovação e transferência.
- Atualizado o teste de mistura do mercado para considerar os títulos realmente usados pelo motor.
- Sem alterações de layout ou assets.
