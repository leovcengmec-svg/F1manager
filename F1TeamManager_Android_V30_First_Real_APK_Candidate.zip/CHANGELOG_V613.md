# V613 (0.613.0) — Balanceamento carro/piloto

- Introduz peso explícito de 65% para o carro e 35% para o piloto no ritmo-base em seco, tanto na classificação quanto na corrida.
- Em chuva leve, média ou forte, o peso muda para 60% carro / 40% piloto.
- A contribuição técnica do carro é calculada a partir dos modificadores de motor, chassi e asa dianteira, aplicada uma única vez.
- A contribuição de ritmo do piloto é ponderada uma única vez; consistência, gestão de pneus, ultrapassagem/defesa, habilidade no molhado, pneus, combustível, DRS/ERS e confiabilidade continuam em seus subsistemas próprios.
- Classificação interativa e corrida interativa usam o mesmo cálculo de ritmo-base, evitando divergência de fórmulas entre modos.
- Não foram alteradas regras de mercado, finanças, calendário, dados de assets externos ou histórico anterior.
