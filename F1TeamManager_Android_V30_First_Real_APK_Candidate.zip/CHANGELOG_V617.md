# V617 — Apresentação animada da força do carro na virada de temporada

- Adicionada uma tela de revelação técnica após **Iniciar nova temporada**, exibindo o carro/pintura da equipe e uma barra animada de competitividade do fim do pelotão à briga pelo título.
- A apresentação revela em sequência os três fatores já existentes na virada: investimento no próximo carro, herança técnica/conhecimento e aplicação do regulamento.
- Exibe overall final de desempenho, confiabilidade e posição no ranking de força da próxima temporada.
- Os valores da apresentação são capturados e persistidos durante a transição real; assistir, reabrir ou pular a animação não reaplica investimento, herança técnica, regulamento nem a simulação de temporada.
- O ranking de força usa o cálculo compartilhado da abertura da temporada e é armazenado em cache para evitar simular as equipes de IA duas vezes na sequência de apresentação.
- Botão **PULAR ANIMAÇÃO** revela imediatamente o resultado final, sem alterar nenhum cálculo. **CONTINUAR PARA A TEMPORADA** segue para o evento de regulamento (quando aplicável) e o card inicial da temporada.
- O evento é persistido por temporada e equipe, com retomada após reinício do aplicativo. A tela não pode ser fechada acidentalmente pelo botão Voltar antes da confirmação.
- Reutiliza o asset de carro já disponível; nenhuma imagem ou asset externo novo foi gerado ou removido.
- Mantida a V609 como referência de desempenho: animação leve em Jetpack Compose, sem ciclos extras no motor de corrida.
- Teste unitário direcionado adicionado para comparar as etapas de investimento/herança com os cálculos canônicos e o carro final regulado.
- Limitação de validação: não há `gradlew`/wrapper no pacote e `gradle` não está instalado neste ambiente; a compilação Android completa, a suíte JUnit e o teste em dispositivo/emulador não foram executados aqui.
