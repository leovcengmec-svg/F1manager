# V605 — Correção de compilação da simulação instantânea

- Corrige a ordem de declaração das funções locais usadas pelo fluxo de simulação instantânea, eliminando a referência não resolvida `simulateWeekendInstantlyForCareerAsync`.
- Preserva a execução da simulação em segundo plano e as proteções contra execução duplicada da V604.
- A compilação completa Android precisa ser repetida no workflow do usuário.
