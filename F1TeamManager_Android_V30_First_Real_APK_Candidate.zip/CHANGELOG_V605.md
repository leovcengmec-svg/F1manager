# V605 — Catálogo dinâmico resiliente

- Reconciliar ownership duplicado de pilotos em vez de encerrar o app ou bloquear todo o editor.
- Priorizar elencos de equipes personalizadas, com fallback determinístico por ID.
- Tratar o roster como fonte de verdade e não bloquear por `teamId` legado desatualizado.
- Atualizar teste de regressão para piloto duplicado, contrato único e preenchimento de vagas.
