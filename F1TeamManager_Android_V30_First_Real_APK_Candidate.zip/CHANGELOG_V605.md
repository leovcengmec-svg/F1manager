# V605 — Correção do sistema de investimentos

- Próximo carro: removido o bloqueio cumulativo calculado com o caixa congelado no primeiro aporte; os aportes agora respeitam o teto absoluto de €150M, o valor já investido e o caixa real acima da reserva operacional.
- Carro atual: teto técnico anual uniforme de €200M para todas as equipes, compartilhado entre P&D/design, fabricação e melhorias de instalações.
- IA: removido o subteto exclusivo de 20% para instalações; construção continua limitada a uma melhoria ativa por equipe e ao prazo de 12 semanas.
- Migração não destrutiva de estados financeiros legados: teto anual normalizado sem apagar gastos, transações ou histórico. Se o gasto legado já ultrapassar €200M, nenhum novo gasto técnico é permitido até o próximo ciclo anual.
- Atualizados testes de regressão para os novos limites e para a recuperação da capacidade de investimento após entrada de caixa.
- Validação de carreira nova permanece obrigatória; saves antigos não são apagados automaticamente.
- Build Android completo/emulador ainda precisa de validação no ambiente Android Studio.
