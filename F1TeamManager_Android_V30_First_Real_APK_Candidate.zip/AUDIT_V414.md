# Auditoria V414

- Base utilizada: V413, ZIP oficial preservado.
- Alterações: `LapEvent` recebeu campos opcionais `positionBefore` e `positionAfter`; o motor captura posições no início da volta e anexa posições após recalcular a classificação; diálogo mostra `P antes → P depois`.
- Compatibilidade: campos novos são opcionais com valor padrão `null`, preservando chamadas existentes do construtor.
- Verificações: revisar diffs e integridade do ZIP. Build Android não executado neste ambiente.
