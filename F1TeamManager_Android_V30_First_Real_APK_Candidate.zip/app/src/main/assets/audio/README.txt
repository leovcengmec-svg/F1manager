F1 TEAM MANAGER — SLOTS DE ÁUDIO EXTERNO (V551)

PASTA EXTERNA NO ANDROID:
Pictures/F1Manager/Assets/Audio/

Formato recomendado: OGG Vorbis (.ogg). MP3 (.mp3) é aceito como alternativa.
O app procura OGG primeiro e depois MP3. Os arquivos de áudio reais não são incluídos no ZIP; coloque seus próprios arquivos nessa pasta. Arquivos ausentes não impedem o jogo.

ÁUDIO DE INTERFACE — TOCA EM SEQUÊNCIA E REPETE A LISTA:
interface.ogg / interface.mp3       — Faixa 1
interface_2.ogg / interface_2.mp3   — Faixa 2
interface_3.ogg / interface_3.mp3   — Faixa 3

EVENTOS / EFEITOS:
box_audio.ogg / box_audio.mp3                         — Comunicação/áudio de box
driver_warning.ogg / driver_warning.mp3               — Aviso ao piloto
red_flag.ogg / red_flag.mp3                           — Bandeira vermelha
safety_car.ogg / safety_car.mp3                       — Safety Car
max_verstappen_victory.ogg / max_verstappen_victory.mp3 — Vitória de Max Verstappen

OUTRAS FAIXAS JÁ EXISTENTES:
menu.ogg / menu.mp3
qualifying_race.ogg / qualifying_race.mp3
results.ogg / results.mp3
brazilian_driver_victory.ogg / brazilian_driver_victory.mp3
season_end.ogg / season_end.mp3

A faixa max_verstappen_victory é selecionada na tela de resultado quando o vencedor identificado no jogo é Max Verstappen. As três faixas de interface tocam em ordem e a sequência reinicia após a terceira. Os slots de evento estão catalogados para receber arquivos; a ativação de cada evento específico na corrida exige que o respectivo evento chame o roteador de áudio.
