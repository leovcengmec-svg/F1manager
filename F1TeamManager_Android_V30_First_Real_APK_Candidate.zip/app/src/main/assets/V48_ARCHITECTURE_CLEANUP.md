# V48 — Architecture Cleanup

- The playable race path is now `CareerWeekendEngine` only.
- Removed obsolete `RaceWeekendEngine`, `RaceDecisionEngine` and `IncidentEngine` production paths and their obsolete smoke test.
- Qualifying (Q1 80 / Q2 50 / Q3 20) is centralized inside `CareerWeekendEngine`.
- Added architecture regression coverage so removed engines cannot silently return.
- Added AI car continuity regression: a new season must derive from the completed previous-season AI car through the same 70% annual continuity rule.
- Added JUnit/kotlin-test dependencies so current unit tests can run through Gradle test infrastructure when a Gradle wrapper/build environment is present.
- Internal Android version: 0.48.0 / versionCode 48.
- Real team/driver images remain intentionally deferred until the game is finalized.
