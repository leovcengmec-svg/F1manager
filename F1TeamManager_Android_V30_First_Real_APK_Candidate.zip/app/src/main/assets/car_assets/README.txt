CAR ASSET REPOSITORY

External folder used by the Android app:
Pictures/F1Manager/Assets/Cars/

Permanent team IDs and preferred filenames:
01.png through 40.png

The filename is the stable team ID, not the team name. This keeps assets linked
correctly even if a displayed team name changes.

Accepted aliases are also supported by the app:
car_01.png, car_1.png, team_01.png, team_1.png and a normalized team name.

Recommended image format: PNG or JPG, preferably a wide side/profile render of
the team's current car. The UI reserves a low-height full-width banner area.
