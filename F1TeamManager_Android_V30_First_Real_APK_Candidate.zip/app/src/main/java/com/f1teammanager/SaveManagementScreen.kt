package com.f1teammanager

import android.util.AtomicFile
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Upload
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import org.json.JSONObject
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val SaveRed = Color(0xFFE10600)
private val SavePanel = Color(0xFF17191F)
private val SaveText = Color(0xFFF5F6F8)
private val SaveMuted = Color(0xFFB8BBC2)

private fun writeSaveAtomically(destination: File, content: ByteArray) {
    val atomic = AtomicFile(destination)
    val output = atomic.startWrite()
    try {
        output.write(content)
        atomic.finishWrite(output)
    } catch (failure: Throwable) {
        atomic.failWrite(output)
        throw failure
    }
}

@Composable
internal fun SaveManagementScreen(
    store: CareerPreferences,
    onBack: () -> Unit,
    onLoaded: () -> Unit
) {
    val context = LocalContext.current
    val saveDir = remember { File(context.filesDir, "career_saves").apply { mkdirs() } }
    var refresh by remember { mutableIntStateOf(0) }
    var message by remember { mutableStateOf("") }
    var selectedSavePath by remember { mutableStateOf<String?>(null) }
    var pendingDelete by remember { mutableStateOf<File?>(null) }
    var pendingExportPayload by remember { mutableStateOf<JSONObject?>(null) }
    var hasError by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var metadataByPath by remember { mutableStateOf<Map<String, CareerSaveMetadata>>(emptyMap()) }
    val scope = rememberCoroutineScope()
    // Entering this screen always refreshes a canonical snapshot. The old implementation
    // only overwrote an autosave when week/round changed, so purchases, facility upgrades,
    // finance transactions and car development could be absent from the file being exported.
    LaunchedEffect(store.hasCareer, store.teamId, store.season, store.roundIndex, store.currentWeek) {
        if (store.hasCareer) {
            busy = true
            runCatching {
                withContext(Dispatchers.IO) {
                    val payload = store.exportCareerBackup()
                    val metadata = store.inspectCareerBackup(payload)
                    val teamName = com.f1teammanager.core.season.WorldDatabase.teams.firstOrNull { it.id == metadata.teamId }?.name ?: "Equipe_${metadata.teamId}"
                    val safeTeam = teamName.replace(Regex("[^A-Za-z0-9_-]"), "_")
                    // One replaceable snapshot per career/team/season, not one dated stale copy per session.
                    val filename = "${metadata.mode}_${safeTeam}_${metadata.season}_${metadata.careerId}.json"
                    val destination = File(saveDir, filename)
                    writeSaveAtomically(destination, payload.toString().toByteArray(Charsets.UTF_8))
                }
            }.onSuccess { refresh++ }.onFailure {
                message = "Falha ao salvar a carreira completa: ${it.message}"
                hasError = true
            }
            busy = false
        }
    }
    val saves = remember(refresh) { saveDir.listFiles { f -> f.isFile && f.extension.equals("json", true) }.orEmpty().sortedByDescending { it.lastModified() } }
    LaunchedEffect(saves) {
        metadataByPath = withContext(Dispatchers.IO) {
            saves.mapNotNull { file ->
                runCatching { store.inspectCareerBackup(JSONObject(file.readText())) }
                    .getOrNull()?.let { file.absolutePath to it }
            }.toMap()
        }
    }
    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) scope.launch {
            busy = true
            val exportPayload = pendingExportPayload
            runCatching {
                withContext(Dispatchers.IO) {
                    val payload = exportPayload ?: error("Selecione um save para exportar.")
                    context.contentResolver.openOutputStream(uri)?.use { it.write(payload.toString(2).toByteArray(Charsets.UTF_8)) }
                        ?: error("Não foi possível gravar o arquivo.")
                }
            }.onSuccess { message = "Save selecionado exportado com sucesso."; hasError = false }
                .onFailure { message = "Falha ao exportar: ${it.message}"; hasError = true }
            busy = false
        }
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            busy = true
            val imported = runCatching {
                withContext(Dispatchers.IO) {
                    val payload = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { JSONObject(it.readText()) }
                        ?: error("Não foi possível ler o arquivo.")
                    // Validate the complete archive before making it selectable; live career is untouched.
                    val metadata = store.inspectCareerBackup(payload)
                    val teamName = com.f1teammanager.core.season.WorldDatabase.teams.firstOrNull { it.id == metadata.teamId }?.name ?: "Equipe_${metadata.teamId}"
                    val safeTeam = teamName.replace(Regex("[^A-Za-z0-9_-]"), "_")
                    val date = java.text.SimpleDateFormat("yyyyMMdd_HHmmss", java.util.Locale.ROOT).format(java.util.Date())
                    val filename = "${metadata.mode}_${safeTeam}_${metadata.season}_${metadata.careerId}_import_${date}.json"
                    val destination = File(saveDir, filename)
                    writeSaveAtomically(destination, payload.toString().toByteArray(Charsets.UTF_8))
                    metadata.modeLabel()
                }
            }
            imported.onSuccess { modeLabel ->
                message = "Save completo $modeLabel validado. Selecione-o e toque em ▶ para restaurar a carreira."
                hasError = false
                refresh++
            }.onFailure { message = "Importação recusada: ${it.message}"; hasError = true }
            busy = false
        }
    }
    pendingDelete?.let { file ->
        AlertDialog(
            onDismissRequest = { pendingDelete = null },
            title = { Text("Excluir save?") },
            text = { Text("O arquivo ${file.name} será removido permanentemente deste aparelho. Esta ação não pode ser desfeita.") },
            confirmButton = {
                TextButton(onClick = {
                    val deleted = runCatching { file.delete() }.getOrDefault(false)
                    if (deleted) {
                        if (selectedSavePath == file.absolutePath) selectedSavePath = null
                        message = "Save excluído."; hasError = false; refresh++
                    } else { message = "Não foi possível excluir o save."; hasError = true }
                    pendingDelete = null
                }) { Text("EXCLUIR", color = SaveRed) }
            },
            dismissButton = { TextButton(onClick = { pendingDelete = null }) { Text("CANCELAR") } }
        )
    }
    Box(Modifier.fillMaxSize().background(Color(0xFF08090C)).statusBarsPadding().navigationBarsPadding().padding(16.dp)) {
        Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Filled.ArrowBack, contentDescription = "Voltar", tint = SaveRed, modifier = Modifier.size(28.dp).clickable { onBack() })
                Spacer(Modifier.width(12.dp)); Text("CARREGAR JOGO", color = SaveText, fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleLarge)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedButton(onClick = { importLauncher.launch(arrayOf("application/json", "text/plain", "*/*")) }, enabled = !busy, modifier = Modifier.weight(1f)) { Icon(Icons.Filled.Download, null); Spacer(Modifier.width(6.dp)); Text("IMPORTAR") }
                Button(onClick = {
                    if (busy) return@Button
                    val selectedPath = selectedSavePath
                    val availableSaves = saves.toList()
                    busy = true
                    scope.launch {
                        val prepared = runCatching {
                            withContext(Dispatchers.IO) {
                                val chosen = availableSaves.firstOrNull { it.absolutePath == selectedPath }
                                val chosenPayload = chosen?.let { runCatching { JSONObject(it.readText()) }.getOrNull() }
                                val chosenPayloadCareerId = chosenPayload?.let { payload ->
                                    payload.optString("careerId").takeIf { it.isNotBlank() }
                                        ?: payload.optJSONObject("preferences")?.optJSONObject("careerId")?.optString("value")?.takeIf { it.isNotBlank() }
                                }
                                val liveCareerId = if (store.hasCareer) store.careerSaveId() else null
                                val exportLive = chosen == null || (liveCareerId != null && chosenPayloadCareerId == liveCareerId)
                                val payload: JSONObject
                                val fileStem: String
                                var savedPath: String? = null
                                if (exportLive) {
                                    payload = store.exportCareerBackup()
                                    val metadata = store.inspectCareerBackup(payload)
                                    val teamName = com.f1teammanager.core.season.WorldDatabase.teams.firstOrNull { it.id == metadata.teamId }?.name ?: "Equipe_${metadata.teamId}"
                                    val safeTeam = teamName.replace(Regex("[^A-Za-z0-9_-]"), "_")
                                    fileStem = "${metadata.mode}_${safeTeam}_${metadata.season}_${metadata.careerId}"
                                    val snapshotFile = File(saveDir, "$fileStem.json")
                                    writeSaveAtomically(snapshotFile, payload.toString().toByteArray(Charsets.UTF_8))
                                    savedPath = snapshotFile.absolutePath
                                } else {
                                    payload = chosenPayload ?: error("O save selecionado não pôde ser lido.")
                                    store.inspectCareerBackup(payload)
                                    fileStem = chosen!!.nameWithoutExtension
                                }
                                Triple(payload, fileStem, savedPath)
                            }
                        }
                        prepared.onSuccess { (payload, fileStem, savedPath) ->
                            pendingExportPayload = payload
                            if (savedPath != null) {
                                selectedSavePath = savedPath
                                refresh++
                                message = "Save completo atualizado com dados financeiros, carro, instalações, P&D e histórico."
                            }
                            hasError = false
                            exportLauncher.launch("$fileStem.json")
                        }.onFailure { message = "Não foi possível preparar o save completo: ${it.message}"; hasError = true }
                        busy = false
                    }
                }, enabled = !busy, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = SaveRed)) { Icon(Icons.Filled.Upload, null); Spacer(Modifier.width(6.dp)); Text("EXPORTAR SAVE COMPLETO") }
            }
            Text("SAVES DISPONÍVEIS", color = SaveMuted, fontWeight = FontWeight.Bold)
            if (saves.isEmpty()) {
                Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) { Text("Nenhum save encontrado. Importe um backup ou inicie uma carreira.", color = SaveMuted) }
            } else {
                LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(saves, key = { it.absolutePath }) { file ->
                        val metadata = metadataByPath[file.absolutePath]
                        val team = metadata?.teamId ?: -1
                        val season = metadata?.season ?: 0
                        val teamName = com.f1teammanager.core.season.WorldDatabase.teams.firstOrNull { it.id == team }?.name ?: "Save inválido"
                        val isSelected = selectedSavePath == file.absolutePath
                        Row(
                            Modifier.fillMaxWidth()
                                .background(if (isSelected) Color(0xFF24212A) else SavePanel, RoundedCornerShape(12.dp))
                                .clickable {
                                    if (metadata == null) { message = "Este save está inválido ou tem modos incompatíveis."; hasError = true }
                                    else { selectedSavePath = file.absolutePath; message = "Save ${metadata.modeLabel()} selecionado para exportação."; hasError = false }
                                }
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(if (isSelected) Icons.Filled.CheckCircle else Icons.Filled.FolderOpen, contentDescription = if (isSelected) "Selecionado" else "Selecionar save", tint = SaveRed, modifier = Modifier.size(34.dp))
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(if (metadata != null) "${metadata.modeLabel()} • ${teamName} • ${season}" else "SAVE INVÁLIDO • ${file.name}", color = SaveText, fontWeight = FontWeight.Bold)
                                Text(if (metadata != null) (if (isSelected) "SELECIONADO • " else "Toque para selecionar • ") + "${(file.length() / 1024).coerceAtLeast(1)} KB • ID ${metadata.careerId.take(8)}" else "Arquivo não validado; não será carregado nem exportado.", color = SaveMuted, style = MaterialTheme.typography.bodySmall)
                            }
                            IconButton(enabled = metadata != null && !busy, onClick = {
                                // Map.get() is nullable even when the map's value type is non-null.
                                // Keep the callback safe instead of relying on the enabled UI state
                                // to smart-cast the captured metadata value.
                                val saveMetadata = metadata
                                if (saveMetadata == null) {
                                    message = "Este save não possui metadados válidos."
                                    hasError = true
                                } else {
                                    val selectedPath = file.absolutePath
                                    val modeLabel = saveMetadata.modeLabel()
                                    busy = true
                                    scope.launch {
                                        runCatching {
                                            withContext(Dispatchers.IO) {
                                                val payload = JSONObject(File(selectedPath).readText())
                                                store.importCareerBackup(payload)
                                            }
                                        }.onSuccess {
                                            message = "Carreira $modeLabel carregada."
                                            hasError = false
                                            onLoaded()
                                        }.onFailure { message = "Não foi possível carregar: ${it.message}"; hasError = true }
                                        busy = false
                                    }
                                }
                            }) { Icon(Icons.Filled.PlayArrow, contentDescription = "Carregar save", tint = if (metadata != null) SaveText else SaveMuted) }
                            IconButton(onClick = { pendingDelete = file }) { Icon(Icons.Filled.Delete, contentDescription = "Excluir save", tint = SaveRed) }
                        }
                    }
                }
            }
            if (busy) Text("PROCESSANDO SAVE COMPLETO E HISTÓRICO…", color = SaveMuted, style = MaterialTheme.typography.bodySmall)
            if (message.isNotBlank()) Text(message, color = if (hasError) Color(0xFFFF7777) else Color(0xFF8FE3A1), style = MaterialTheme.typography.bodySmall)
            Text("O save inclui todas as preferências persistentes da carreira e o histórico de corridas. EXPORTAR SAVE COMPLETO atualiza primeiro os dados da carreira ativa; saves de outras carreiras podem ser exportados selecionando-os. Arquivos incompletos ou corrompidos são recusados.", color = SaveMuted, style = MaterialTheme.typography.bodySmall)
        }
    }
}
