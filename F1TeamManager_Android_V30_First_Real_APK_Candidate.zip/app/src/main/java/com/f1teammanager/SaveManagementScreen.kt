package com.f1teammanager

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Upload
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import org.json.JSONObject
import java.io.File

private val SaveRed = Color(0xFFE10600)
private val SavePanel = Color(0xFF17191F)
private val SaveText = Color(0xFFF5F6F8)
private val SaveMuted = Color(0xFFB8BBC2)

@Composable
internal fun SaveManagementScreen(
    store: CareerPreferences,
    onBack: () -> Unit,
    onLoaded: () -> Unit
) {
    val context = LocalContext.current
    val saveDir = remember { File(context.filesDir, "career_saves").apply { mkdirs() } }
    var refresh by remember { mutableIntStateOf(0) }
    LaunchedEffect(store.hasCareer, store.teamId, store.season, store.roundIndex) {
        if (store.hasCareer) runCatching {
            val teamName = com.f1teammanager.core.season.WorldDatabase.teams.firstOrNull { it.id == store.teamId }?.name ?: "Equipe_${store.teamId}"
            val date = java.text.SimpleDateFormat("dd-MM-yyyy", java.util.Locale.ROOT).format(java.util.Date())
            val filename = "${teamName.replace(Regex("[^A-Za-z0-9_-]"), "_")}_${store.season}_${date}.json"
            File(saveDir, filename).writeText(store.exportCareerBackup().toString(), Charsets.UTF_8)
            refresh++
        }
    }
    var message by remember { mutableStateOf("") }
    var hasError by remember { mutableStateOf(false) }
    val saves = remember(refresh) { saveDir.listFiles { f -> f.isFile && f.extension.equals("json", true) }.orEmpty().sortedByDescending { it.lastModified() } }
    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) runCatching {
            val payload = store.exportCareerBackup()
            context.contentResolver.openOutputStream(uri)?.use { it.write(payload.toString(2).toByteArray(Charsets.UTF_8)) } ?: error("Não foi possível gravar o arquivo.")
            message = "Backup exportado com sucesso."; hasError = false
        }.onFailure { message = "Falha ao exportar: ${it.message}"; hasError = true }
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) runCatching {
            val payload = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { JSONObject(it.readText()) } ?: error("Não foi possível ler o arquivo.")
            // Validate in a disposable parse before adding the save to the list.
            require(payload.optString("format") == "F1TM_SAVE" && payload.optInt("schema") == 1) { "Arquivo não é um save compatível." }
            val p = payload.optJSONObject("preferences") ?: error("Backup incompleto.")
            val team = p.optJSONObject("teamId")?.optInt("value", -1) ?: -1
            val season = p.optJSONObject("season")?.optInt("value", -1) ?: -1
            require(team in 1..40 && season >= 2026) { "Equipe ou temporada inválida." }
            val teamName = com.f1teammanager.core.season.WorldDatabase.teams.firstOrNull { it.id == team }?.name ?: "Equipe_$team"
            val filename = "${teamName.replace(Regex("[^A-Za-z0-9_-]"), "_")}_${season}_${java.text.SimpleDateFormat("dd-MM-yyyy", java.util.Locale.ROOT).format(java.util.Date())}.json"
            File(saveDir, filename).writeText(payload.toString(), Charsets.UTF_8)
            message = "Save importado para a lista. Selecione-o para carregar."; hasError = false; refresh++
        }.onFailure { message = "Importação recusada: ${it.message}"; hasError = true }
    }
    Box(Modifier.fillMaxSize().background(Color(0xFF08090C)).statusBarsPadding().navigationBarsPadding().padding(16.dp)) {
        Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Filled.ArrowBack, contentDescription = "Voltar", tint = SaveRed, modifier = Modifier.size(28.dp).clickable { onBack() })
                Spacer(Modifier.width(12.dp)); Text("CARREGAR JOGO", color = SaveText, fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleLarge)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedButton(onClick = { importLauncher.launch(arrayOf("application/json", "text/plain", "*/*")) }, modifier = Modifier.weight(1f)) { Icon(Icons.Filled.Download, null); Spacer(Modifier.width(6.dp)); Text("IMPORTAR") }
                Button(onClick = {
                    if (!store.hasCareer) { message = "Não há carreira ativa para exportar."; hasError = true }
                    else exportLauncher.launch("${com.f1teammanager.core.season.WorldDatabase.teams.firstOrNull { it.id == store.teamId }?.name ?: "Equipe"}_${store.season}_${java.text.SimpleDateFormat("dd-MM-yyyy", java.util.Locale.ROOT).format(java.util.Date())}.json")
                }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = SaveRed)) { Icon(Icons.Filled.Upload, null); Spacer(Modifier.width(6.dp)); Text("EXPORTAR") }
            }
            Text("SAVES DISPONÍVEIS", color = SaveMuted, fontWeight = FontWeight.Bold)
            if (saves.isEmpty()) {
                Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) { Text("Nenhum save encontrado. Importe um backup ou inicie uma carreira.", color = SaveMuted) }
            } else {
                LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(saves, key = { it.absolutePath }) { file ->
                        val payload = remember(file.lastModified()) { runCatching { JSONObject(file.readText()) }.getOrNull() }
                        val prefs = payload?.optJSONObject("preferences")
                        val team = prefs?.optJSONObject("teamId")?.optInt("value", -1) ?: -1
                        val season = prefs?.optJSONObject("season")?.optInt("value", 0) ?: 0
                        val teamName = com.f1teammanager.core.season.WorldDatabase.teams.firstOrNull { it.id == team }?.name ?: "Save importado"
                        Row(Modifier.fillMaxWidth().background(SavePanel, RoundedCornerShape(12.dp)).clickable {
                            runCatching { store.importCareerBackup(payload ?: error("Save inválido.")); message = "Carreira carregada."; hasError = false; onLoaded() }
                                .onFailure { message = "Não foi possível carregar: ${it.message}"; hasError = true }
                        }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.FolderOpen, contentDescription = null, tint = SaveRed, modifier = Modifier.size(34.dp))
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text("${teamName}_${season}_${java.text.SimpleDateFormat("dd-MM-yyyy", java.util.Locale.ROOT).format(java.util.Date(file.lastModified()))}", color = SaveText, fontWeight = FontWeight.Bold)
                                Text("Toque para carregar • ${(file.length() / 1024).coerceAtLeast(1)} KB", color = SaveMuted, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            }
            if (message.isNotBlank()) Text(message, color = if (hasError) Color(0xFFFF7777) else Color(0xFF8FE3A1), style = MaterialTheme.typography.bodySmall)
            Text("Os arquivos são validados antes da restauração. Guarde uma cópia exportada fora do aparelho.", color = SaveMuted, style = MaterialTheme.typography.bodySmall)
        }
    }
}
