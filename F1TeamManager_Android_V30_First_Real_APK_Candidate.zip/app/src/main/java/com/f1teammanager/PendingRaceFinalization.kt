package com.f1teammanager

import com.f1teammanager.core.race.CareerWeekendEngine
import com.f1teammanager.core.race.Neutralisation
import com.f1teammanager.core.race.RaceResult

/** A completed race result persisted before any career side effect is applied. */
data class PendingRaceFinalization(
    val season: Int,
    val round: Int,
    val totalLaps: Int,
    val result: RaceResult
) {
    fun toSnapshot(): CareerWeekendEngine.SessionSnapshot = CareerWeekendEngine.SessionSnapshot(
        phase = "RACE",
        lap = totalLaps,
        totalLaps = totalLaps,
        grid = result.qualifying,
        classification = result.classification,
        carStatus = emptyList(),
        events = result.events,
        neutral = Neutralisation.GREEN,
        decision = null,
        plans = emptyMap(),
        alerts = emptyList(),
        completed = true,
        weather = result.weather
    )
}
