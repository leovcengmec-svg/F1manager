# V320 — Ordem dos cards de evento e decisão do manager

- Corrigida a prioridade visual na simulação de corrida.
- Quando há evento informativo e decisão do manager pendentes ao mesmo tempo, o card do evento aparece primeiro.
- A decisão do manager fica temporariamente oculta enquanto houver um card de evento ativo.
- Ao tocar em CONTINUAR no card de evento, a fila avança; se houver decisão pendente, ela aparece em seguida.
- O efeito de pausa/retoma da simulação e os callbacks existentes foram preservados.
- Sem alterações no motor, na geração de eventos, nas consequências ou nas opções de decisão.
