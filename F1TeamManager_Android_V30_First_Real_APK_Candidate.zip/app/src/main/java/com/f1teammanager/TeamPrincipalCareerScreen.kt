package com.f1teammanager

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.GpsFixed
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Store
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.f1teammanager.core.manager.TeamPrincipalCareerState
import com.f1teammanager.core.manager.TeamPrincipalObjective
import com.f1teammanager.core.manager.TeamPrincipalSeasonRecord

/** Stats that can be reconstructed from the official season/race history. Null means the save has no source data. */
internal data class TeamPrincipalSeasonHistoryUi(
    val teamName: String,
    val position: Int,
    val wins: Int?,
    val poles: Int?,
    val podiums: Int?
)

private val CareerBg = Color(0xFF08090C)
private val CareerPanel = Color(0xFF14161B)
private val CareerPanelInner = Color(0xFF1B1E24)
private val CareerText = Color(0xFFF5F6FA)
private val CareerMuted = Color(0xFF9AA3B7)
private val CareerLine = Color(0xFF2B2F3A)
private val CareerGold = Color(0xFFFFC857)
private val CareerGreen = Color(0xFF38C878)
private val CareerBlue = Color(0xFF72B7F2)

private data class CareerAchievement(
    val title: String,
    val detail: String,
    val earned: Boolean
)

/**
 * Team Principal career front end, redesigned for compact portrait screens (including Poco X7 Pro).
 * The page itself never scrolls; its sections share the available height. When a long career history
 * is expanded, only the rows inside that history card scroll, so the surrounding page stays fixed.
 */
@Composable
internal fun TeamPrincipalCareerScreen(
    state: TeamPrincipalCareerState,
    currentSeason: Int,
    currentTeamName: String,
    currentTeamRank: Int,
    hasCurrentSeasonResults: Boolean,
    teamNames: Map<Int, String>,
    trajectoryStats: Map<Pair<Int, Int>, TeamPrincipalSeasonHistoryUi>,
    offerTeamNames: List<String>,
    pendingContractMessage: String? = null,
    onOpenReview: () -> Unit,
    onBackHome: () -> Unit
) {
    val achievedCount = listOf(
        state.records.isNotEmpty(),
        state.records.any { it.teamRank <= it.objectiveRank },
        state.records.any { it.teamRank <= 10 },
        state.records.any { it.teamRank <= 3 },
        state.records.any { it.teamRank == 1 },
        state.records.zipWithNext().any { (before, after) -> before.teamId == after.teamId && after.teamRank <= before.teamRank - 5 },
        state.prestige >= 75,
        state.records.size >= 5
    ).count { it }
    val achievements = listOf(
        CareerAchievement("ESTREIA PROFISSIONAL", "Conclua sua primeira temporada", state.records.isNotEmpty()),
        CareerAchievement("META CUMPRIDA", "Termine uma temporada dentro da meta", state.records.any { it.teamRank <= it.objectiveRank }),
        CareerAchievement("TOP 10 DO GRID", "Coloque uma equipe entre as dez melhores", state.records.any { it.teamRank <= 10 }),
        CareerAchievement("PÓDIO DE CONSTRUTORES", "Termine entre as três melhores equipes", state.records.any { it.teamRank <= 3 }),
        CareerAchievement("CAMPEÃO DE CONSTRUTORES", "Conquiste o Mundial de Equipes", state.records.any { it.teamRank == 1 }),
        CareerAchievement("SALTO DE QUALIDADE", "Melhore cinco posições em uma temporada", state.records.zipWithNext().any { (before, after) -> before.teamId == after.teamId && after.teamRank <= before.teamRank - 5 }),
        CareerAchievement("NOME RESPEITADO", "Alcance 75 pontos de prestígio", state.prestige >= 75),
        CareerAchievement("VETERANO DO PADDOCK", "Complete cinco temporadas", state.records.size >= 5)
    )
    val prestigeTier = when (state.prestige) {
        in 0..19 -> "NOVATO"
        in 20..39 -> "PROMESSA"
        in 40..59 -> "RESPEITADO"
        in 60..79 -> "ELITE DO PADDOCK"
        else -> "LENDÁRIO"
    }
    val contractStatus = when {
        state.dismissed -> "CONTRATO ENCERRADO"
        state.reviewPending -> "AVALIAÇÃO PENDENTE"
        currentSeason <= state.contractStartSeason -> "1ª TEMPORADA DO CONTRATO"
        currentSeason == state.contractStartSeason + 1 -> "2ª TEMPORADA • AVALIAÇÃO AO FINAL"
        else -> "CONTRATO ATIVO"
    }
    val objectiveMessage = when {
        pendingContractMessage != null -> pendingContractMessage
        !hasCurrentSeasonResults && state.records.isEmpty() -> "Pré-temporada: a força inicial define a meta; a classificação aparece após a primeira temporada."
        !hasCurrentSeasonResults -> "Pré-temporada: a última classificação confirmada vale até a primeira corrida."
        state.dismissed -> "Seu contrato foi encerrado. Confira as propostas para continuar a carreira."
        state.reviewPending -> "Sua avaliação bienal está disponível. Confira o resultado e escolha o próximo passo."
        currentTeamRank <= state.objectiveRank -> "A equipe está dentro da meta atual. Continue defendendo essa posição."
        else -> "Faltam ${currentTeamRank - state.objectiveRank} posição(ões) para alcançar a meta atual."
    }
    val historyRecords = state.records.sortedByDescending { it.season }
    var trajectoryExpanded by remember(state.teamId) { mutableStateOf(false) }

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(CareerBg)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        val compact = maxHeight < 790.dp || maxWidth < 370.dp
        val pageHorizontalPadding = if (maxWidth < 370.dp) 8.dp else 11.dp
        val sectionGap = if (compact) 5.dp else 6.dp
        val headingHeight = if (compact) 36.dp else 40.dp
        val bottomButtonHeight = if (compact) 38.dp else 42.dp

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = pageHorizontalPadding, vertical = 5.dp),
            verticalArrangement = Arrangement.spacedBy(sectionGap)
        ) {
            CareerHeader(
                currentSeason = currentSeason,
                compact = compact,
                height = headingHeight,
                onBackHome = onBackHome
            )
            PrestigeSummaryCard(
                modifier = Modifier.fillMaxWidth().weight(1.12f),
                prestige = state.prestige,
                prestigeTier = prestigeTier,
                currentTeamId = state.teamId,
                bestRank = state.bestRank,
                seasonCount = state.records.size,
                currentTeamName = currentTeamName,
                currentTeamRank = currentTeamRank,
                hasCurrentSeasonResults = hasCurrentSeasonResults,
                meetsObjective = currentTeamRank <= state.objectiveRank,
                compact = compact
            )
            ObjectivesCard(
                modifier = Modifier.fillMaxWidth().weight(2.42f),
                state = state,
                objectiveMessage = objectiveMessage,
                contractStatus = contractStatus,
                compact = compact
            )
            AchievementsCard(
                modifier = Modifier.fillMaxWidth().weight(1.9f),
                achievements = achievements,
                achievedCount = achievedCount,
                compact = compact
            )
            TrajectoryCard(
                modifier = Modifier.fillMaxWidth().weight(1.22f),
                records = historyRecords,
                teamNames = teamNames,
                trajectoryStats = trajectoryStats,
                expanded = trajectoryExpanded,
                compact = compact,
                onToggleExpanded = { trajectoryExpanded = !trajectoryExpanded }
            )
            OutlinedButton(
                onClick = if (state.reviewPending || state.dismissed) onOpenReview else onBackHome,
                modifier = Modifier.fillMaxWidth().height(bottomButtonHeight),
                border = androidx.compose.foundation.BorderStroke(1.dp, CareerGold),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = CareerText),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 0.dp)
            ) {
                if (state.reviewPending || state.dismissed) {
                    Icon(Icons.Filled.EmojiEvents, contentDescription = null, tint = CareerGold, modifier = Modifier.size(15.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(
                        if (state.dismissed) "VER PROPOSTAS E CONTINUAR" else "ABRIR AVALIAÇÃO CONTRATUAL",
                        color = CareerText, fontWeight = FontWeight.Black, fontSize = if (compact) 9.sp else 10.sp,
                        maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                } else {
                    Icon(Icons.Filled.Home, contentDescription = null, modifier = Modifier.size(15.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("VOLTAR PARA A HOME", color = CareerText, fontWeight = FontWeight.Black, fontSize = if (compact) 10.sp else 11.sp)
                }
            }
        }
    }
}

@Composable
private fun CareerHeader(
    currentSeason: Int,
    compact: Boolean,
    height: Dp,
    onBackHome: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth().height(height),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        OutlinedButton(
            onClick = onBackHome,
            modifier = Modifier.width(if (compact) 70.dp else 78.dp).height(if (compact) 32.dp else 35.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, CareerLine),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = CareerText),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 7.dp, vertical = 0.dp)
        ) {
            Icon(Icons.Filled.Home, contentDescription = null, modifier = Modifier.size(13.dp))
            Spacer(Modifier.width(3.dp))
            Text("HOME", fontSize = 8.5.sp, fontWeight = FontWeight.Black, maxLines = 1)
        }
        Box(modifier = Modifier.weight(1f).fillMaxHeight(), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Text(
                    "MINHA CARREIRA", color = CareerText, fontSize = if (compact) 19.sp else 21.sp,
                    fontWeight = FontWeight.Black, maxLines = 1, softWrap = false, overflow = TextOverflow.Clip
                )
                Text(
                    "TEAM PRINCIPAL  •  TEMPORADA $currentSeason", color = CareerGold,
                    fontSize = if (compact) 8.sp else 9.sp, fontWeight = FontWeight.Bold,
                    maxLines = 1, softWrap = false, overflow = TextOverflow.Clip
                )
            }
        }
        Spacer(Modifier.width(if (compact) 70.dp else 78.dp))
    }
}

@Composable
private fun PrestigeSummaryCard(
    modifier: Modifier,
    prestige: Int,
    prestigeTier: String,
    currentTeamId: Int,
    bestRank: Int,
    seasonCount: Int,
    currentTeamName: String,
    currentTeamRank: Int,
    hasCurrentSeasonResults: Boolean,
    meetsObjective: Boolean,
    compact: Boolean
) {
    Surface(
        modifier = modifier,
        color = CareerPanel,
        shape = RoundedCornerShape(14.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, CareerGold)
    ) {
        Column(
            modifier = Modifier.fillMaxSize().padding(if (compact) 8.dp else 10.dp),
            verticalArrangement = Arrangement.spacedBy(if (compact) 3.dp else 4.dp)
        ) {
            Row(Modifier.fillMaxWidth().weight(1f), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(1.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        Icon(Icons.Filled.EmojiEvents, contentDescription = null, tint = CareerGold, modifier = Modifier.size(if (compact) 14.dp else 17.dp))
                        Text("PRESTÍGIO DO TEAM PRINCIPAL", color = CareerMuted, fontSize = if (compact) 8.sp else 9.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                    }
                    Text("$prestige", color = CareerGold, fontSize = if (compact) 30.sp else 34.sp, lineHeight = if (compact) 31.sp else 35.sp, fontWeight = FontWeight.Black)
                    Text("$prestigeTier  •  $prestige/100 pontos", color = CareerText, fontSize = if (compact) 8.sp else 9.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                }
                Surface(color = CareerPanelInner, shape = RoundedCornerShape(9.dp), modifier = Modifier.width(if (compact) 116.dp else 130.dp)) {
                    Column(
                        Modifier.padding(horizontal = 7.dp, vertical = if (compact) 5.dp else 7.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(1.dp)
                    ) {
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.EmojiEvents, contentDescription = null, tint = CareerMuted, modifier = Modifier.size(12.dp))
                            Text("MELHOR RESULTADO", color = CareerMuted, fontSize = 7.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                        }
                        Text(if (seasonCount == 0) "—" else "${bestRank}º", color = CareerText, fontSize = if (compact) 18.sp else 21.sp, fontWeight = FontWeight.Black, lineHeight = if (compact) 19.sp else 22.sp)
                        Text(if (seasonCount == 0) "Aguardando resultado" else "$seasonCount temporada(s)", color = CareerMuted, fontSize = 7.5.sp, maxLines = 1)
                    }
                }
            }
            LinearProgressIndicator(
                progress = { prestige.coerceIn(0, 100) / 100f },
                modifier = Modifier.fillMaxWidth().height(5.dp).clip(RoundedCornerShape(5.dp)),
                color = CareerGold,
                trackColor = CareerPanelInner
            )
            HorizontalDivider(color = CareerLine, thickness = 1.dp)
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Row(Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    TeamLogo(currentTeamName, currentTeamId, Modifier.size(if (compact) 20.dp else 24.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(1.dp)) {
                        Text("EQUIPE ATUAL", color = CareerMuted, fontSize = 7.sp, fontWeight = FontWeight.Bold)
                        Text(currentTeamName, color = CareerText, fontSize = if (compact) 9.sp else 10.sp, fontWeight = FontWeight.Black, maxLines = 1, softWrap = false, overflow = TextOverflow.Ellipsis)
                    }
                }
                Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(1.dp)) {
                    Text(if (hasCurrentSeasonResults) "POSIÇÃO ATUAL" else if (seasonCount == 0) "FORÇA INICIAL" else "ÚLTIMA CLASSIFICAÇÃO", color = CareerMuted, fontSize = 7.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                    Text(
                        if (hasCurrentSeasonResults) "${currentTeamRank}º / 40" else "#${currentTeamRank} / 40",
                        color = if (meetsObjective) CareerGreen else CareerText,
                        fontSize = if (compact) 15.sp else 17.sp, fontWeight = FontWeight.Black, maxLines = 1
                    )
                }
            }
        }
    }
}

@Composable
private fun ObjectivesCard(
    modifier: Modifier,
    state: TeamPrincipalCareerState,
    objectiveMessage: String,
    contractStatus: String,
    compact: Boolean
) {
    Surface(
        modifier = modifier,
        color = CareerPanel,
        shape = RoundedCornerShape(14.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, CareerLine)
    ) {
        Column(
            modifier = Modifier.fillMaxSize().padding(if (compact) 7.dp else 8.dp),
            verticalArrangement = Arrangement.spacedBy(if (compact) 3.dp else 4.dp)
        ) {
            Row(Modifier.fillMaxWidth().height(if (compact) 19.dp else 21.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                Icon(Icons.Filled.GpsFixed, contentDescription = null, tint = CareerGold, modifier = Modifier.size(if (compact) 15.dp else 17.dp))
                Text("OBJETIVOS DA DIRETORIA", color = CareerText, fontSize = if (compact) 11.sp else 12.sp, fontWeight = FontWeight.Black, modifier = Modifier.weight(1f), maxLines = 1)
                Surface(color = CareerPanelInner, shape = RoundedCornerShape(6.dp), border = androidx.compose.foundation.BorderStroke(1.dp, CareerLine)) {
                    Text("${state.objectives.size} OBJ.", color = CareerGold, fontSize = 7.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(horizontal = 5.dp, vertical = 3.dp), maxLines = 1)
                }
            }
            val goals = state.objectives.take(6)
            Column(Modifier.fillMaxWidth().weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                goals.chunked(2).forEachIndexed { rowIndex, pair ->
                    Row(Modifier.fillMaxWidth().weight(1f), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        pair.forEachIndexed { index, goal ->
                            GoalTile(
                                goal = goal,
                                index = rowIndex * 2 + index,
                                modifier = Modifier.weight(1f).fillMaxHeight(),
                                compact = compact
                            )
                        }
                        if (pair.size == 1) Spacer(Modifier.weight(1f))
                    }
                }
            }
            Text(
                objectiveMessage,
                color = if (state.reviewPending || state.dismissed) CareerGold else CareerMuted,
                fontSize = if (compact) 7.sp else 7.5.sp,
                lineHeight = if (compact) 8.sp else 9.sp,
                maxLines = if (compact) 1 else 2,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.fillMaxWidth()
            )
            Row(Modifier.fillMaxWidth().height(if (compact) 38.dp else 42.dp), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                Surface(color = CareerPanelInner, shape = RoundedCornerShape(8.dp), border = androidx.compose.foundation.BorderStroke(1.dp, CareerLine), modifier = Modifier.weight(1f).fillMaxHeight()) {
                    Row(Modifier.fillMaxSize().padding(horizontal = 6.dp, vertical = 3.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Icon(Icons.Filled.Description, contentDescription = null, tint = CareerMuted, modifier = Modifier.size(if (compact) 15.dp else 17.dp))
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.Center) {
                            Text("CONTRATO", color = CareerMuted, fontSize = 7.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                            Text("${state.contractStartSeason}–${state.contractStartSeason + 1}", color = CareerText, fontSize = if (compact) 10.sp else 11.sp, fontWeight = FontWeight.Black, maxLines = 1)
                            if (!compact) Text(contractStatus, color = if (state.reviewPending || state.dismissed) CareerGold else CareerMuted, fontSize = 6.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
                Surface(color = CareerPanelInner, shape = RoundedCornerShape(8.dp), border = androidx.compose.foundation.BorderStroke(1.dp, CareerLine), modifier = Modifier.weight(1f).fillMaxHeight()) {
                    Row(Modifier.fillMaxSize().padding(horizontal = 6.dp, vertical = 3.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Icon(Icons.Filled.CheckCircle, contentDescription = null, tint = CareerGreen, modifier = Modifier.size(if (compact) 15.dp else 17.dp))
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.Center) {
                            Text("METAS CUMPRIDAS", color = CareerMuted, fontSize = 7.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                            Text("${state.records.count { it.teamRank <= it.objectiveRank }}", color = CareerGreen, fontSize = if (compact) 12.sp else 14.sp, fontWeight = FontWeight.Black, maxLines = 1)
                            if (!compact) Text("temporadas dentro da meta", color = CareerMuted, fontSize = 6.5.sp, maxLines = 1)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun GoalTile(goal: TeamPrincipalObjective, index: Int, modifier: Modifier, compact: Boolean) {
    val icon = when {
        index == 0 -> Icons.Filled.EmojiEvents
        goal.kind.contains("WIND_TUNNEL") -> Icons.Filled.Cloud
        goal.kind.contains("SIMULATOR") -> Icons.Filled.Build
        goal.kind.contains("MARKETING") -> Icons.Filled.Store
        goal.kind.contains("research") -> Icons.Filled.Search
        goal.kind.contains("rank") -> Icons.Filled.Flag
        else -> Icons.Filled.SwapHoriz
    }
    val category = when (index) {
        0 -> "PRINCIPAL"
        1 -> "SECUNDÁRIO"
        else -> "TEMPORADA"
    }
    val displayText = if (goal.kind == "rank") goal.detail else goal.title
    Surface(
        modifier = modifier,
        color = CareerPanelInner,
        shape = RoundedCornerShape(8.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, CareerLine)
    ) {
        Row(
            modifier = Modifier.fillMaxSize().padding(horizontal = if (compact) 4.dp else 5.dp, vertical = 3.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(icon, contentDescription = null, tint = if (index == 0) CareerGold else if (index == 1) CareerBlue else CareerMuted, modifier = Modifier.size(if (compact) 12.dp else 14.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(0.dp)) {
                Text(category, color = if (index == 0) CareerGold else if (index == 1) CareerBlue else CareerMuted, fontSize = if (compact) 6.sp else 6.5.sp, fontWeight = FontWeight.Black, maxLines = 1)
                Text(
                    displayText,
                    color = CareerText,
                    fontSize = if (compact) 7.3.sp else 8.sp,
                    lineHeight = if (compact) 8.sp else 9.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                if (!compact && goal.kind != "rank") {
                    Text(
                        goal.detail,
                        color = CareerMuted,
                        fontSize = 6.2.sp,
                        lineHeight = 6.8.sp,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
            Text("+${goal.prestige}", color = CareerGold, fontSize = if (compact) 8.sp else 9.sp, fontWeight = FontWeight.Black, maxLines = 1)
        }
    }
}

@Composable
private fun AchievementsCard(
    modifier: Modifier,
    achievements: List<CareerAchievement>,
    achievedCount: Int,
    compact: Boolean
) {
    Surface(
        modifier = modifier,
        color = CareerPanel,
        shape = RoundedCornerShape(14.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, CareerLine)
    ) {
        Column(
            Modifier.fillMaxSize().padding(if (compact) 7.dp else 8.dp),
            verticalArrangement = Arrangement.spacedBy(if (compact) 3.dp else 4.dp)
        ) {
            Row(Modifier.fillMaxWidth().height(if (compact) 18.dp else 21.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                Icon(Icons.Filled.Star, contentDescription = null, tint = CareerGold, modifier = Modifier.size(if (compact) 15.dp else 17.dp))
                Text("CONQUISTAS", color = CareerText, fontSize = if (compact) 11.sp else 12.sp, fontWeight = FontWeight.Black, modifier = Modifier.weight(1f))
                Text("$achievedCount / ${achievements.size}", color = CareerGold, fontSize = if (compact) 10.sp else 11.sp, fontWeight = FontWeight.Black)
            }
            Column(Modifier.fillMaxWidth().weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                achievements.chunked(2).forEach { pair ->
                    Row(Modifier.fillMaxWidth().weight(1f), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        pair.forEach { achievement ->
                            AchievementTile(achievement, Modifier.weight(1f).fillMaxHeight(), compact)
                        }
                        if (pair.size == 1) Spacer(Modifier.weight(1f))
                    }
                }
            }
        }
    }
}

@Composable
private fun AchievementTile(achievement: CareerAchievement, modifier: Modifier, compact: Boolean) {
    Surface(
        modifier = modifier,
        color = if (achievement.earned) Color(0xFF17251F) else CareerPanelInner,
        shape = RoundedCornerShape(8.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, if (achievement.earned) Color(0xFF2E7750) else CareerLine)
    ) {
        Row(
            modifier = Modifier.fillMaxSize().padding(horizontal = if (compact) 4.dp else 5.dp, vertical = 3.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (achievement.earned) {
                Icon(Icons.Filled.CheckCircle, contentDescription = "Conquistada", tint = CareerGreen, modifier = Modifier.size(if (compact) 13.dp else 15.dp))
            } else {
                Icon(Icons.Outlined.StarBorder, contentDescription = "Bloqueada", tint = CareerMuted, modifier = Modifier.size(if (compact) 14.dp else 16.dp))
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(1.dp)) {
                Text(
                    achievement.title,
                    color = if (achievement.earned) CareerText else CareerMuted,
                    fontSize = if (compact) 7.2.sp else 8.sp,
                    lineHeight = if (compact) 8.sp else 9.sp,
                    fontWeight = FontWeight.Black,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                if (!compact) {
                    Text(
                        achievement.detail,
                        color = CareerMuted,
                        fontSize = 7.1.sp,
                        lineHeight = 8.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
            if (!achievement.earned) {
                Icon(Icons.Filled.Lock, contentDescription = null, tint = CareerMuted, modifier = Modifier.size(9.dp))
            }
        }
    }
}

@Composable
private fun TrajectoryCard(
    modifier: Modifier,
    records: List<TeamPrincipalSeasonRecord>,
    teamNames: Map<Int, String>,
    trajectoryStats: Map<Pair<Int, Int>, TeamPrincipalSeasonHistoryUi>,
    expanded: Boolean,
    compact: Boolean,
    onToggleExpanded: () -> Unit
) {
    val columns = listOf(0.55f, 0.55f, 1.62f, 0.45f, 0.42f, 0.48f, 0.43f)
    Surface(
        modifier = modifier,
        color = CareerPanel,
        shape = RoundedCornerShape(14.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, CareerLine)
    ) {
        Column(
            Modifier.fillMaxSize().padding(if (compact) 7.dp else 8.dp),
            verticalArrangement = Arrangement.spacedBy(if (compact) 3.dp else 4.dp)
        ) {
            Row(
                Modifier.fillMaxWidth().height(if (compact) 18.dp else 21.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .clickable(enabled = records.size > 3) { onToggleExpanded() }
                    .padding(horizontal = 2.dp),
                horizontalArrangement = Arrangement.spacedBy(5.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Filled.BarChart, contentDescription = null, tint = CareerGold, modifier = Modifier.size(if (compact) 15.dp else 17.dp))
                Text("MINHA TRAJETÓRIA", color = CareerText, fontSize = if (compact) 11.sp else 12.sp, fontWeight = FontWeight.Black, modifier = Modifier.weight(1f), maxLines = 1)
                if (records.isNotEmpty()) Text("${records.size} TEMP.", color = CareerGold, fontSize = 7.sp, fontWeight = FontWeight.Black, maxLines = 1)
                if (records.size > 3) {
                    Text(if (expanded) "RECOLHER" else "VER TODAS", color = CareerGold, fontSize = 7.sp, fontWeight = FontWeight.Black, maxLines = 1)
                    Icon(if (expanded) Icons.Filled.KeyboardArrowUp else Icons.Filled.KeyboardArrowDown, contentDescription = if (expanded) "Recolher histórico" else "Expandir histórico", tint = CareerGold, modifier = Modifier.size(16.dp))
                }
            }
            if (records.isEmpty()) {
                Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Filled.Flag, contentDescription = null, tint = CareerMuted, modifier = Modifier.size(if (compact) 18.dp else 21.dp))
                        Column(verticalArrangement = Arrangement.spacedBy(1.dp)) {
                            Text("Nenhuma temporada concluída ainda.", color = CareerText, fontSize = if (compact) 8.5.sp else 9.5.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                            Text("O histórico será preenchido ao fim da primeira temporada.", color = CareerMuted, fontSize = if (compact) 7.sp else 8.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
            } else {
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(5.dp)).background(CareerPanelInner)
                        .padding(vertical = 3.dp, horizontal = 1.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    listOf("ANO", "ESCUDO", "EQUIPE", "POS", "VIT", "POLE", "POD").forEachIndexed { index, title ->
                        Text(title, color = CareerMuted, fontSize = if (compact) 6.2.sp else 7.sp, fontWeight = FontWeight.Black, textAlign = TextAlign.Center, modifier = Modifier.weight(columns[index]), maxLines = 1, softWrap = false)
                    }
                }
                Column(
                    modifier = Modifier.fillMaxWidth().weight(1f)
                        .then(if (expanded && records.size > 3) Modifier.verticalScroll(rememberScrollState()) else Modifier),
                    verticalArrangement = Arrangement.spacedBy(1.dp)
                ) {
                    val visibleRecords = if (expanded) records else records.take(3)
                    visibleRecords.forEachIndexed { index, record ->
                        val key = record.season to record.teamId
                        val history = trajectoryStats[key]
                        val teamName = history?.teamName?.takeIf { it.isNotBlank() } ?: teamNames[record.teamId] ?: "Equipe ${record.teamId}"
                        val position = history?.position ?: record.teamRank
                        val rowColor = if (index == 0) Color(0x1AFFC857) else CareerPanelInner.copy(alpha = 0.45f)
                        Row(
                            Modifier.fillMaxWidth().height(if (compact) 18.dp else 20.dp)
                                .clip(RoundedCornerShape(4.dp)).background(rowColor),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(record.season.toString(), color = CareerText, fontSize = if (compact) 7.sp else 8.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, modifier = Modifier.weight(columns[0]), maxLines = 1)
                            Box(Modifier.weight(columns[1]).fillMaxHeight(), contentAlignment = Alignment.Center) {
                                TeamLogo(teamName, record.teamId, Modifier.size(if (compact) 15.dp else 17.dp))
                            }
                            Text(teamName, color = if (index == 0) CareerGold else CareerText, fontSize = if (compact) 7.sp else 8.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Start, modifier = Modifier.weight(columns[2]).padding(start = 2.dp, end = 2.dp), maxLines = 1, softWrap = false, overflow = TextOverflow.Ellipsis)
                            val positionColor = when {
                                position == 1 -> CareerGold
                                position <= record.objectiveRank -> CareerGreen
                                else -> CareerText
                            }
                            Text("${position}º", color = positionColor, fontSize = if (compact) 7.sp else 8.sp, fontWeight = FontWeight.Black, textAlign = TextAlign.Center, modifier = Modifier.weight(columns[3]), maxLines = 1, softWrap = false)
                            listOf(history?.wins?.toString() ?: "—", history?.poles?.toString() ?: "—", history?.podiums?.toString() ?: "—").forEachIndexed { statIndex, value ->
                                Text(value, color = if (value == "—") CareerMuted else CareerText, fontSize = if (compact) 7.sp else 8.sp, fontWeight = FontWeight.Medium, textAlign = TextAlign.Center, modifier = Modifier.weight(columns[4 + statIndex]), maxLines = 1, softWrap = false)
                            }
                        }
                    }
                }
            }
        }
    }
}
