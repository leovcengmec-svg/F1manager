package com.f1teammanager

import android.content.Context
import com.f1teammanager.core.race.FinishEntry
import com.f1teammanager.core.race.QualifyingResult
import com.f1teammanager.core.race.RaceResult
import com.f1teammanager.core.race.Tyre
import com.f1teammanager.core.season.RoundDefinition
import com.f1teammanager.core.season.WorldDatabase
import java.io.File

/**
 * Persistent career archive.
 *
 * Rules:
 * - GP history is written immediately after every completed race.
 * - A season is written only after all 30 GPs have finished.
 * - Hall of Fame is derived from this archive, never from the live championship.
 */
class HistoricalDatabase(context: Context) {
    private val file = File(context.applicationContext.filesDir, "f1tm_historical_v2.db")

    data class RaceRecord(
        val season: Int,
        val round: Int,
        val grandPrix: String,
        val teamId: Int,
        val teamName: String,
        val driverId: Int,
        val driverName: String,
        val position: Int,
        val points: Int,
        val laps: Int,
        val totalTimeMs: Long,
        val gapToLeaderMs: Long,
        val status: String,
        val tyre: Tyre,
        val pitStops: Int,
        val fastestLapTimeMs: Long = 0L,
        val isFastestLap: Boolean = false
    )

    data class PoleRecord(
        val season: Int,
        val round: Int,
        val grandPrix: String,
        val teamId: Int,
        val teamName: String,
        val driverId: Int,
        val driverName: String,
        val timeMs: Long
    )

    data class DriverChampion(
        val season: Int,
        val driverId: Int,
        val driverName: String,
        val teamId: Int,
        val teamName: String,
        val points: Int
    )

    data class ConstructorChampion(
        val season: Int,
        val teamId: Int,
        val teamName: String,
        val points: Int
    )

    data class DriverSeasonRecord(
        val season: Int,
        val position: Int,
        val driverId: Int,
        val driverName: String,
        val teamId: Int,
        val teamName: String,
        val points: Int,
        val wins: Int,
        val poles: Int,
        val fastestLaps: Int,
        val dnf: Int,
        val gps: Int
    )

    data class ConstructorSeasonRecord(
        val season: Int,
        val position: Int,
        val teamId: Int,
        val teamName: String,
        val points: Int,
        val wins: Int,
        val poles: Int,
        val fastestLaps: Int,
        val dnf: Int,
        val gps: Int
    )

    enum class HallScope { DRIVERS, CONSTRUCTORS }
    enum class HallMetric { CHAMPIONS, WINS, POLES, FASTEST_LAPS, POINTS, GPS }

    data class HallEntry(
        val id: Int,
        val name: String,
        val teamId: Int,
        val teamName: String,
        val value: Int,
        val position: Int,
        /** Positive = climbed, negative = dropped, 0 = unchanged, MIN_VALUE = new entry. */
        val movement: Int
    )

    private fun readLines(): List<String> =
        if (!file.exists()) emptyList() else runCatching { file.readLines() }.getOrDefault(emptyList())

    fun recordRace(season: Int, round: RoundDefinition, result: RaceResult, qualifying: QualifyingResult?) {
        // One GP is one atomic historical entry. Re-recording the same GP replaces it,
        // preventing duplicate wins/poles/fastest laps after reopening a result screen.
        val existing = readLines()
            .filterNot { it.startsWith("R|$season|${round.round}|") || it.startsWith("P|$season|${round.round}|") }
            .toMutableList()

        val leader = result.classification.firstOrNull { !it.status.startsWith("DNF") }?.totalTimeMs ?: 0L
        result.classification.forEach { f ->
            val driver = WorldDatabase.drivers.firstOrNull { it.id == f.driverId }
            val teamId = WorldDatabase.teams.firstOrNull { it.name.equals(f.teamName, ignoreCase = true) }?.id
                ?: driver?.teamId ?: 0
            val points = result.points[f.driverId] ?: 0
            val gap = if (f.status.startsWith("DNF") || leader == 0L) 0L
            else (f.totalTimeMs - leader).coerceAtLeast(0L)
            val isFastest = f.driverId == result.fastestLapDriverId
            existing += listOf(
                "R", season, round.round, enc(round.grandPrix), teamId, enc(f.teamName), f.driverId,
                enc(f.driverName), f.position, points, f.laps, f.totalTimeMs, gap, enc(f.status),
                f.tyre.name, f.pitStops, if (isFastest) 1 else 0,
                if (isFastest) result.fastestLapTimeMs else 0L
            ).joinToString("|")
        }

        // Only one pole exists per GP. Store P1 only instead of all qualifying positions.
        qualifying?.grid?.firstOrNull { it.position == 1 }?.let { q ->
            val driver = WorldDatabase.drivers.firstOrNull { it.id == q.driverId }
            val teamId = driver?.teamId ?: 0
            val teamName = WorldDatabase.teams.firstOrNull { it.id == teamId }?.name ?: "Equipe $teamId"
            existing += listOf(
                "P", season, round.round, enc(round.grandPrix), teamId, enc(teamName),
                q.driverId, enc(driver?.name ?: "Piloto ${q.driverId}"), q.lapTimeMs
            ).joinToString("|")
        }

        write(existing)
    }

    /** True only after the final 30-race season snapshot has been written. */
    fun isSeasonFinalized(season: Int): Boolean = readLines().any { it.startsWith("SD|$season|") }

    /**
     * Archives the complete season once, and only once. The snapshot contains all 80
     * drivers and all 40 constructors, including DNF/GP totals and race achievements.
     */
    fun finalizeSeason(season: Int, driverPoints: Map<Int, Int>, constructorPoints: Map<Int, Int>) {
        if (isSeasonFinalized(season)) return
        if (driverPoints.isEmpty() && constructorPoints.isEmpty()) return

        val lines = readLines().filterNot { it.startsWith("SD|$season|") || it.startsWith("SK|$season|") || it.startsWith("C|$season|") || it.startsWith("K|$season|") }.toMutableList()
        val races = raceRecords(season)
        val poles = poleRecords(season)
        val fastest = fastestLaps(season)
        val victories = victories().filter { it.season == season }

        val driverRows = WorldDatabase.drivers.map { d ->
            val rows = races.filter { it.driverId == d.id }
            val last = rows.maxByOrNull { it.round }
            DriverSeasonRecord(
                season = season,
                position = 0,
                driverId = d.id,
                driverName = last?.driverName ?: d.name,
                teamId = last?.teamId ?: d.teamId,
                teamName = last?.teamName ?: WorldDatabase.teams.firstOrNull { it.id == d.teamId }?.name.orEmpty(),
                points = driverPoints[d.id] ?: rows.sumOf { it.points },
                wins = victories.count { it.driverId == d.id },
                poles = poles.count { it.driverId == d.id },
                fastestLaps = fastest.count { it.driverId == d.id },
                dnf = rows.count { it.status.startsWith("DNF") },
                gps = rows.count { !it.status.startsWith("DNF") }
            )
        }.sortedWith(
            compareByDescending<DriverSeasonRecord> { it.points }
                .thenByDescending { it.wins }
                .thenByDescending { it.poles }
                .thenByDescending { it.fastestLaps }
                .thenBy { it.driverId }
        ).mapIndexed { index, row -> row.copy(position = index + 1) }

        val constructorRows = WorldDatabase.teams.map { team ->
            val rows = races.filter { it.teamId == team.id }
            ConstructorSeasonRecord(
                season = season,
                position = 0,
                teamId = team.id,
                teamName = team.name,
                points = constructorPoints[team.id] ?: rows.sumOf { it.points },
                wins = victories.count { it.teamId == team.id },
                poles = poles.count { it.teamId == team.id },
                fastestLaps = fastest.count { it.teamId == team.id },
                dnf = rows.count { it.status.startsWith("DNF") },
                gps = rows.groupBy { it.round }.count { (_, gpRows) -> gpRows.any { !it.status.startsWith("DNF") } }
            )
        }.sortedWith(
            compareByDescending<ConstructorSeasonRecord> { it.points }
                .thenByDescending { it.wins }
                .thenByDescending { it.poles }
                .thenByDescending { it.fastestLaps }
                .thenBy { it.teamId }
        ).mapIndexed { index, row -> row.copy(position = index + 1) }

        driverRows.forEach { r ->
            lines += listOf("SD", r.season, r.position, r.driverId, enc(r.driverName), r.teamId, enc(r.teamName), r.points, r.wins, r.poles, r.fastestLaps, r.dnf, r.gps).joinToString("|")
        }
        constructorRows.forEach { r ->
            lines += listOf("SK", r.season, r.position, r.teamId, enc(r.teamName), r.points, r.wins, r.poles, r.fastestLaps, r.dnf, r.gps).joinToString("|")
        }

        // Keep the compact champion records for compatibility with existing UI/data readers.
        driverRows.firstOrNull()?.let { r ->
            lines += listOf("C", season, r.driverId, enc(r.driverName), r.teamId, enc(r.teamName), r.points).joinToString("|")
        }
        constructorRows.firstOrNull()?.let { r ->
            lines += listOf("K", season, r.teamId, enc(r.teamName), r.points).joinToString("|")
        }
        write(lines)
    }

    fun raceRecords(season: Int? = null): List<RaceRecord> = readLines().mapNotNull { line ->
        val p = line.split('|')
        if (p.size < 16 || p[0] != "R") return@mapNotNull null
        runCatching {
            val s = p[1].toInt()
            if (season != null && s != season) return@runCatching null
            RaceRecord(
                season = s,
                round = p[2].toInt(),
                grandPrix = dec(p[3]),
                teamId = p[4].toInt(),
                teamName = dec(p[5]),
                driverId = p[6].toInt(),
                driverName = dec(p[7]),
                position = p[8].toInt(),
                points = p[9].toInt(),
                laps = p[10].toInt(),
                totalTimeMs = p[11].toLong(),
                gapToLeaderMs = p[12].toLong(),
                status = dec(p[13]),
                tyre = Tyre.valueOf(p[14]),
                pitStops = p[15].toInt(),
                isFastestLap = p.getOrNull(16) == "1",
                fastestLapTimeMs = p.getOrNull(17)?.toLongOrNull() ?: 0L
            )
        }.getOrNull()
    }

    fun poleRecords(season: Int? = null): List<PoleRecord> = readLines().mapNotNull { line ->
        val p = line.split('|')
        if (p.size < 9 || p[0] != "P") return@mapNotNull null
        runCatching {
            val s = p[1].toInt()
            if (season != null && s != season) return@runCatching null
            PoleRecord(s, p[2].toInt(), dec(p[3]), p[4].toInt(), dec(p[5]), p[6].toInt(), dec(p[7]), p[8].toLong())
        }.getOrNull()
    }

    fun driverSeasonRecords(season: Int? = null): List<DriverSeasonRecord> = readLines().mapNotNull { line ->
        val p = line.split('|')
        if (p.size < 13 || p[0] != "SD") return@mapNotNull null
        runCatching {
            val s = p[1].toInt()
            if (season != null && s != season) return@runCatching null
            DriverSeasonRecord(s, p[2].toInt(), p[3].toInt(), dec(p[4]), p[5].toInt(), dec(p[6]), p[7].toInt(), p[8].toInt(), p[9].toInt(), p[10].toInt(), p[11].toInt(), p[12].toInt())
        }.getOrNull()
    }.sortedWith(compareBy<DriverSeasonRecord> { it.season }.thenBy { it.position })

    fun constructorSeasonRecords(season: Int? = null): List<ConstructorSeasonRecord> = readLines().mapNotNull { line ->
        val p = line.split('|')
        if (p.size < 11 || p[0] != "SK") return@mapNotNull null
        runCatching {
            val s = p[1].toInt()
            if (season != null && s != season) return@runCatching null
            ConstructorSeasonRecord(s, p[2].toInt(), p[3].toInt(), dec(p[4]), p[5].toInt(), p[6].toInt(), p[7].toInt(), p[8].toInt(), p[9].toInt(), p[10].toInt())
        }.getOrNull()
    }.sortedWith(compareBy<ConstructorSeasonRecord> { it.season }.thenBy { it.position })

    fun driverChampions(season: Int? = null): List<DriverChampion> = readLines().mapNotNull { line ->
        val p = line.split('|')
        if (p.size < 7 || p[0] != "C") return@mapNotNull null
        runCatching {
            val s = p[1].toInt()
            if (season != null && s != season) return@runCatching null
            DriverChampion(s, p[2].toInt(), dec(p[3]), p[4].toInt(), dec(p[5]), p[6].toInt())
        }.getOrNull()
    }.sortedByDescending { it.season }

    fun constructorChampions(season: Int? = null): List<ConstructorChampion> = readLines().mapNotNull { line ->
        val p = line.split('|')
        if (p.size < 5 || p[0] != "K") return@mapNotNull null
        runCatching {
            val s = p[1].toInt()
            if (season != null && s != season) return@runCatching null
            ConstructorChampion(s, p[2].toInt(), dec(p[3]), p[4].toInt())
        }.getOrNull()
    }.sortedByDescending { it.season }

    /** Only completed seasons appear here. The live season never leaks into Temporadas. */
    fun seasons(): List<Int> = (driverSeasonRecords().map { it.season } + constructorSeasonRecords().map { it.season })
        .distinct()
        .sortedDescending()

    fun victories(): List<RaceRecord> = raceRecords()
        .filter { it.position == 1 && !it.status.startsWith("DNF") }
        .sortedWith(compareByDescending<RaceRecord> { it.season }.thenBy { it.round })

    fun fastestLaps(season: Int? = null): List<RaceRecord> = raceRecords(season)
        .filter { it.isFastestLap && it.fastestLapTimeMs > 0L }
        .sortedWith(compareByDescending<RaceRecord> { it.season }.thenBy { it.round })

    fun poles(): List<PoleRecord> = poleRecords()
        .sortedWith(compareByDescending<PoleRecord> { it.season }.thenBy { it.round })

    fun hallRanking(scope: HallScope, metric: HallMetric): List<HallEntry> {
        val current = hallValues(scope, metric, includeSeason = true)
        val previous = hallValues(scope, metric, includeSeason = false)
        val previousPositions = previous.sortedByDescending { it.value }
            .mapIndexed { index, e -> e.id to index + 1 }
            .toMap()
        return current.sortedByDescending { it.value }.mapIndexed { index, e ->
            val position = index + 1
            val old = previousPositions[e.id]
            e.copy(position = position, movement = if (old == null) Int.MIN_VALUE else old - position)
        }
    }

    private fun hallValues(scope: HallScope, metric: HallMetric, includeSeason: Boolean): List<HallEntry> {
        val raceRows = raceRecords()
        val seasonYears = seasons()
        val latestRace = raceRows.maxWithOrNull(compareBy<RaceRecord> { it.season }.thenBy { it.round })
        val latestSeason = seasonYears.maxOrNull()
        val effectiveRaces = if (includeSeason || latestRace == null) raceRows else raceRows.filterNot { it.season == latestRace.season && it.round == latestRace.round }
        val effectiveSeasonYears = if (includeSeason || latestSeason == null) seasonYears else seasonYears.filter { it != latestSeason }
        val effectiveSeasonDrivers = driverSeasonRecords().filter { it.season in effectiveSeasonYears }
        val effectiveSeasonTeams = constructorSeasonRecords().filter { it.season in effectiveSeasonYears }
        val effectivePoles = poleRecords().filter { includeSeason || !(it.season == latestRace?.season && it.round == latestRace?.round) }
        val effectiveFastest = fastestLaps().filter { includeSeason || !(it.season == latestRace?.season && it.round == latestRace?.round) }
        val effectiveWins = effectiveRaces.filter { it.position == 1 && !it.status.startsWith("DNF") }

        return when (scope) {
            HallScope.DRIVERS -> {
                val ids = WorldDatabase.drivers.map { it.id }.distinct()
                ids.mapNotNull { id ->
                    val d = WorldDatabase.drivers.firstOrNull { it.id == id }
                    val sample = raceRows.lastOrNull { it.driverId == id }
                    val name = d?.name ?: sample?.driverName ?: return@mapNotNull null
                    val value = when (metric) {
                        HallMetric.CHAMPIONS -> driverChampions().count { it.driverId == id && (includeSeason || it.season != latestSeason) }
                        HallMetric.WINS -> effectiveWins.count { it.driverId == id }
                        HallMetric.POLES -> effectivePoles.count { it.driverId == id }
                        HallMetric.FASTEST_LAPS -> effectiveFastest.count { it.driverId == id }
                        HallMetric.POINTS -> effectiveSeasonDrivers.filter { it.driverId == id }.sumOf { it.points }
                        HallMetric.GPS -> effectiveSeasonDrivers.filter { it.driverId == id }.sumOf { it.gps }
                    }
                    HallEntry(id, name, sample?.teamId ?: d?.teamId ?: 0, sample?.teamName ?: WorldDatabase.teams.firstOrNull { it.id == d?.teamId }?.name.orEmpty(), value, 0, 0)
                }
            }
            HallScope.CONSTRUCTORS -> {
                WorldDatabase.teams.map { team ->
                    val value = when (metric) {
                        HallMetric.CHAMPIONS -> constructorChampions().count { it.teamId == team.id && (includeSeason || it.season != latestSeason) }
                        HallMetric.WINS -> effectiveWins.count { it.teamId == team.id }
                        HallMetric.POLES -> effectivePoles.count { it.teamId == team.id }
                        HallMetric.FASTEST_LAPS -> effectiveFastest.count { it.teamId == team.id }
                        HallMetric.POINTS -> effectiveSeasonTeams.filter { it.teamId == team.id }.sumOf { it.points }
                        HallMetric.GPS -> effectiveSeasonTeams.filter { it.teamId == team.id }.sumOf { it.gps }
                    }
                    HallEntry(team.id, team.name, team.id, team.name, value, 0, 0)
                }
            }
        }
    }

    fun clear() {
        runCatching { file.delete() }
    }

    private fun write(lines: List<String>) {
        file.parentFile?.mkdirs()
        file.writeText(lines.joinToString("\n"))
    }

    private fun enc(value: String): String = android.util.Base64.encodeToString(value.toByteArray(Charsets.UTF_8), android.util.Base64.NO_WRAP)
    private fun dec(value: String): String = runCatching { String(android.util.Base64.decode(value, android.util.Base64.NO_WRAP), Charsets.UTF_8) }.getOrDefault(value)
}
