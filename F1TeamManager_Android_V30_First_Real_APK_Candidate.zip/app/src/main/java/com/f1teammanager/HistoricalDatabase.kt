package com.f1teammanager

import android.content.Context
import com.f1teammanager.core.race.QualifyingResult
import com.f1teammanager.core.race.RaceResult
import com.f1teammanager.core.race.FinishEntry
import com.f1teammanager.core.race.Tyre
import com.f1teammanager.core.season.RoundDefinition
import com.f1teammanager.core.season.WorldDatabase
import java.io.File
import java.util.Locale

/**
 * Persistent career history. This is deliberately independent from the current-season
 * standings so old seasons are never erased when a new season starts.
 */
class HistoricalDatabase(context: Context) {
    private val file = File(context.applicationContext.filesDir, "f1tm_historical_v1.db")

    data class RaceRecord(
        val season: Int, val round: Int, val grandPrix: String,
        val teamId: Int, val teamName: String,
        val driverId: Int, val driverName: String,
        val position: Int, val points: Int, val laps: Int,
        val totalTimeMs: Long, val gapToLeaderMs: Long,
        val status: String, val tyre: Tyre, val pitStops: Int
    )
    data class PoleRecord(
        val season: Int, val round: Int, val grandPrix: String,
        val teamId: Int, val teamName: String,
        val driverId: Int, val driverName: String, val timeMs: Long
    )
    data class DriverChampion(val season: Int, val driverId: Int, val driverName: String, val teamId: Int, val teamName: String, val points: Int)
    data class ConstructorChampion(val season: Int, val teamId: Int, val teamName: String, val points: Int)

    private fun readLines(): List<String> = if (!file.exists()) emptyList() else runCatching { file.readLines() }.getOrDefault(emptyList())

    fun recordRace(season: Int, round: RoundDefinition, result: RaceResult, qualifying: QualifyingResult?) {
        val existing = readLines().filterNot { it.startsWith("R|$season|${round.round}|") || it.startsWith("P|$season|${round.round}|") }.toMutableList()
        val leader = result.classification.firstOrNull { !it.status.startsWith("DNF") }?.totalTimeMs ?: 0L
        result.classification.forEach { f ->
            val driver = WorldDatabase.drivers.firstOrNull { it.id == f.driverId }
            val teamId = WorldDatabase.teams.firstOrNull { it.name.equals(f.teamName, ignoreCase = true) }?.id ?: driver?.teamId ?: 0
            val points = result.points[f.driverId] ?: 0
            val gap = if (f.status.startsWith("DNF") || leader == 0L) 0L else (f.totalTimeMs - leader).coerceAtLeast(0L)
            existing += listOf(
                "R", season, round.round, enc(round.grandPrix), teamId, enc(f.teamName), f.driverId,
                enc(f.driverName), f.position, points, f.laps, f.totalTimeMs, gap, enc(f.status), f.tyre.name, f.pitStops
            ).joinToString("|")
        }
        qualifying?.grid?.forEach { q ->
            val driver = WorldDatabase.drivers.firstOrNull { it.id == q.driverId }
            val teamId = driver?.teamId ?: 0
            val teamName = WorldDatabase.teams.firstOrNull { it.id == teamId }?.name ?: "Equipe ${teamId}"
            existing += listOf("P", season, round.round, enc(round.grandPrix), teamId, enc(teamName), q.driverId, enc(driver?.name ?: "Piloto ${q.driverId}"), q.lapTimeMs).joinToString("|")
        }
        write(existing)
    }

    fun finalizeSeason(season: Int, driverPoints: Map<Int, Int>, constructorPoints: Map<Int, Int>) {
        if (driverPoints.isEmpty() && constructorPoints.isEmpty()) return
        val lines = readLines().filterNot { it.startsWith("C|$season|") || it.startsWith("K|$season|") }.toMutableList()
        val championDriver = driverPoints.maxWithOrNull(compareBy<Map.Entry<Int,Int>> { it.value }.thenBy { it.key })
        championDriver?.let { e ->
            val race = raceRecords(season).filter { it.driverId == e.key }.maxByOrNull { it.round }
            val driver = WorldDatabase.drivers.firstOrNull { it.id == e.key }
            val teamId = race?.teamId ?: driver?.teamId ?: 0
            val teamName = race?.teamName ?: WorldDatabase.teams.firstOrNull { it.id == teamId }?.name.orEmpty()
            val name = race?.driverName ?: driver?.name ?: "Piloto ${e.key}"
            lines += listOf("C", season, e.key, enc(name), teamId, enc(teamName), e.value).joinToString("|")
        }
        val championTeam = constructorPoints.maxWithOrNull(compareBy<Map.Entry<Int,Int>> { it.value }.thenBy { it.key })
        championTeam?.let { e ->
            val team = WorldDatabase.teams.firstOrNull { it.id == e.key }
            lines += listOf("K", season, e.key, enc(team?.name ?: "Equipe ${e.key}"), e.value).joinToString("|")
        }
        write(lines)
    }

    fun raceRecords(season: Int? = null): List<RaceRecord> = readLines().mapNotNull { line ->
        val p = line.split('|')
        if (p.size < 16 || p[0] != "R") return@mapNotNull null
        runCatching {
            val s = p[1].toInt(); if (season != null && s != season) return@runCatching null
            RaceRecord(s,p[2].toInt(),dec(p[3]),p[4].toInt(),dec(p[5]),p[6].toInt(),dec(p[7]),p[8].toInt(),p[9].toInt(),p[10].toInt(),p[11].toLong(),p[12].toLong(),dec(p[13]),Tyre.valueOf(p[14]),p[15].toInt())
        }.getOrNull()
    }

    fun poleRecords(season: Int? = null): List<PoleRecord> = readLines().mapNotNull { line ->
        val p = line.split('|')
        if (p.size < 9 || p[0] != "P") return@mapNotNull null
        runCatching {
            val s=p[1].toInt(); if (season != null && s != season) return@runCatching null
            PoleRecord(s,p[2].toInt(),dec(p[3]),p[4].toInt(),dec(p[5]),p[6].toInt(),dec(p[7]),p[8].toLong())
        }.getOrNull()
    }

    fun driverChampions(season: Int? = null): List<DriverChampion> = readLines().mapNotNull { line ->
        val p=line.split('|'); if(p.size<7 || p[0]!="C") return@mapNotNull null
        runCatching { val s=p[1].toInt(); if(season!=null&&s!=season) return@runCatching null; DriverChampion(s,p[2].toInt(),dec(p[3]),p[4].toInt(),dec(p[5]),p[6].toInt()) }.getOrNull()
    }.sortedByDescending { it.season }

    fun constructorChampions(season: Int? = null): List<ConstructorChampion> = readLines().mapNotNull { line ->
        val p=line.split('|'); if(p.size<5 || p[0]!="K") return@mapNotNull null
        runCatching { val s=p[1].toInt(); if(season!=null&&s!=season) return@runCatching null; ConstructorChampion(s,p[2].toInt(),dec(p[3]),p[4].toInt()) }.getOrNull()
    }.sortedByDescending { it.season }

    fun seasons(): List<Int> = (raceRecords().map { it.season } + driverChampions().map { it.season }).distinct().sortedDescending()

    fun victories(): List<RaceRecord> = raceRecords().filter { it.position == 1 && !it.status.startsWith("DNF") }.sortedWith(compareByDescending<RaceRecord> { it.season }.thenBy { it.round })
    fun fastestVictories(): List<RaceRecord> = victories().sortedBy { it.totalTimeMs }
    fun poles(): List<PoleRecord> = poleRecords().sortedWith(compareByDescending<PoleRecord> { it.season }.thenBy { it.round })

    data class HallEntry(val id:Int, val name:String, val teamId:Int, val teamName:String, val score:Int, val titles:Int, val wins:Int, val poles:Int, val podiums:Int, val points:Int)
    fun hallOfFame(): List<HallEntry> {
        val races = raceRecords()
        val wins = races.filter { it.position == 1 && !it.status.startsWith("DNF") }.groupingBy { it.driverId }.eachCount()
        val podiums = races.filter { it.position in 1..3 && !it.status.startsWith("DNF") }.groupingBy { it.driverId }.eachCount()
        val points = races.groupBy { it.driverId }.mapValues { (_, rows) -> rows.sumOf { it.points } }
        val poles = poleRecords().groupingBy { it.driverId }.eachCount()
        val titles = driverChampions().groupingBy { it.driverId }.eachCount()
        val ids = (WorldDatabase.drivers.map { it.id } + races.map { it.driverId }).distinct()
        return ids.mapNotNull { id ->
            val d = WorldDatabase.drivers.firstOrNull { it.id == id }
            val sample = races.lastOrNull { it.driverId == id }
            val name = d?.name ?: sample?.driverName ?: return@mapNotNull null
            val w=wins[id]?:0; val p=poles[id]?:0; val pod=podiums[id]?:0; val t=titles[id]?:0; val pts=points[id]?:0
            val score=t*500 + w*100 + p*40 + pod*20
            HallEntry(id,name,sample?.teamId ?: d?.teamId ?: 0,sample?.teamName ?: WorldDatabase.teams.firstOrNull{it.id==d?.teamId}?.name.orEmpty(),score,t,w,p,pod,pts)
        }.sortedWith(compareByDescending<HallEntry>{it.score}.thenByDescending{it.titles}.thenByDescending{it.wins}.thenBy{it.id})
    }

    fun clear() { runCatching { file.delete() } }

    private fun write(lines: List<String>) {
        file.parentFile?.mkdirs()
        file.writeText(lines.joinToString("\n"))
    }
    private fun enc(value:String):String = android.util.Base64.encodeToString(value.toByteArray(Charsets.UTF_8), android.util.Base64.NO_WRAP)
    private fun dec(value:String):String = runCatching { String(android.util.Base64.decode(value, android.util.Base64.NO_WRAP), Charsets.UTF_8) }.getOrDefault(value)
}
