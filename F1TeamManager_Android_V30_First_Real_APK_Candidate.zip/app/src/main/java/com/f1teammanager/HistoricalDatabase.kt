package com.f1teammanager

import android.content.Context
import android.util.AtomicFile
import com.f1teammanager.core.race.FinishEntry
import com.f1teammanager.core.race.QualifyingResult
import com.f1teammanager.core.race.RaceResult
import com.f1teammanager.core.race.Tyre
import com.f1teammanager.core.season.RoundDefinition
import com.f1teammanager.core.season.SeasonCalendar
import com.f1teammanager.core.manager.DriverMarketState
import com.f1teammanager.core.season.WorldDatabase
import java.io.File

/**
 * Persistent career archive.
 *
 * Rules:
 * - GP history is written immediately after every completed race.
 * - A season is written only after all 30 GPs have finished.
 * - Hall of Fame is derived from this archive, never from the live championship.
 */
class HistoricalDatabase(context: Context) {
    private val filesDir = context.applicationContext.filesDir
    // Legacy monolithic archive remains the read/migration source for existing saves.
    private val file = File(filesDir, "f1tm_historical_v2.db")
    private val atomicFile = AtomicFile(file)
    // V642: new race results are stored one atomic file per GP. The old implementation
    // read, filtered and rewrote the entire lifetime archive on every race, causing
    // quadratic I/O growth and Android ANRs in longer careers. The legacy file is never
    // deleted by this migration; shard records shadow only the matching old GP rows.
    private val raceArchiveDirectory = File(filesDir, "f1tm_historical_v3_races")
    // Season summaries are small and immutable after finalization, so keep them separate
    // too instead of rewriting all historical GP records at each season boundary.
    private val seasonArchiveDirectory = File(filesDir, "f1tm_historical_v3_seasons")
    private val raceArchiveName = Regex("^season_(\\d+)_round_(\\d+)\\.db$")
    private val seasonArchiveName = Regex("^season_(\\d+)\\.db$")
    private val archiveImportMarker = File(filesDir, "f1tm_history_import.pending")
    private val archiveImportBackup = File(filesDir, "f1tm_history_import_backup")

    init {
        // If Android killed an import between the three archive targets, restore the
        // complete pre-import image before exposing the history to any screen.
        recoverInterruptedArchiveImport()
        // V654: older builds could leave SD/SK rows without their compact champion
        // ledger (C/K). Rebuild only seasons whose complete race archive is present.
        runCatching { reconcileCompletedSeasonSummaries() }
    }


    data class RaceRecord(
        val season: Int,
        val round: Int,
        val grandPrix: String,
        val teamId: Int,
        val teamName: String,
        val driverId: Int,
        val driverName: String,
        val position: Int,
        val points: Int,
        val laps: Int,
        val totalTimeMs: Long,
        val gapToLeaderMs: Long,
        val status: String,
        val tyre: Tyre,
        val pitStops: Int,
        val fastestLapTimeMs: Long = 0L,
        val isFastestLap: Boolean = false
    )

    data class QualifyingRecord(
        val season:Int, val round:Int, val driverId:Int, val driverName:String, val teamId:Int, val teamName:String, val position:Int, val timeMs:Long
    )

    data class PoleRecord(
        val season: Int,
        val round: Int,
        val grandPrix: String,
        val teamId: Int,
        val teamName: String,
        val driverId: Int,
        val driverName: String,
        val timeMs: Long
    )

    data class DriverChampion(
        val season: Int,
        val driverId: Int,
        val driverName: String,
        val teamId: Int,
        val teamName: String,
        val points: Int
    )

    data class ConstructorChampion(
        val season: Int,
        val teamId: Int,
        val teamName: String,
        val points: Int
    )

    data class DriverSeasonRecord(
        val season: Int,
        val position: Int,
        val driverId: Int,
        val driverName: String,
        val teamId: Int,
        val teamName: String,
        val points: Int,
        val wins: Int,
        val poles: Int,
        val fastestLaps: Int,
        val dnf: Int,
        val gps: Int
    )

    data class ConstructorSeasonRecord(
        val season: Int,
        val position: Int,
        val teamId: Int,
        val teamName: String,
        val points: Int,
        val wins: Int,
        val poles: Int,
        val fastestLaps: Int,
        val dnf: Int,
        val gps: Int
    )

    enum class HallScope { DRIVERS, CONSTRUCTORS }
    enum class HallMetric { CHAMPIONS, WINS, POLES, FASTEST_LAPS, POINTS, GPS }

    data class HallEntry(
        val id: Int,
        val name: String,
        val teamId: Int,
        val teamName: String,
        val value: Int,
        val position: Int,
        /** Positive = climbed, negative = dropped, 0 = unchanged, MIN_VALUE = new entry. */
        val movement: Int
    )


    /**
     * V648: portable snapshot of the complete historical archive. V642 split new
     * records across the legacy v2 file and two v3 shard directories; exporting only
     * the legacy file silently omitted recent races and season summaries.
     */
    @Synchronized
    fun exportArchiveBundle(): org.json.JSONObject {
        val entries = collectExistingArchiveBytes()
        val files = org.json.JSONArray()
        entries.toSortedMap().forEach { (path, bytes) ->
            files.put(org.json.JSONObject()
                .put("path", path)
                .put("sha256", sha256Hex(bytes))
                .put("content", android.util.Base64.encodeToString(bytes, android.util.Base64.NO_WRAP)))
        }
        return org.json.JSONObject()
            .put("format", "F1TM_HISTORY_ARCHIVE")
            .put("version", 1)
            .put("fileCount", entries.size)
            .put("files", files)
    }

    /** Build a bundle for legacy saves that only stored the monolithic v2 archive. */
    fun legacyOnlyArchiveBundle(legacyBytes: ByteArray): org.json.JSONObject {
        val files = org.json.JSONArray()
        if (legacyBytes.isNotEmpty()) files.put(org.json.JSONObject()
            .put("path", "legacy/f1tm_historical_v2.db")
            .put("sha256", sha256Hex(legacyBytes))
            .put("content", android.util.Base64.encodeToString(legacyBytes, android.util.Base64.NO_WRAP)))
        return org.json.JSONObject().put("format", "F1TM_HISTORY_ARCHIVE")
            .put("version", 1).put("fileCount", files.length()).put("files", files)
    }

    /** Validate paths, payload sizes and per-file checksums without touching live data. */
    fun validateArchiveBundle(bundle: org.json.JSONObject): Boolean =
        runCatching { decodeArchiveBundle(bundle); true }.getOrDefault(false)

    /**
     * Replace v2 + both v3 archive locations as one recoverable operation. A small
     * filesystem journal makes a process death during replacement roll back on startup.
     */
    @Synchronized
    fun replaceArchiveBundle(bundle: org.json.JSONObject, deferCommit: Boolean = false) {
        val incoming = decodeArchiveBundle(bundle)
        val oldEntries = collectExistingArchiveBytes()
        writeBundleTree(archiveImportBackup, oldEntries)
        writeSynced(archiveImportMarker, "F1TM_HISTORY_IMPORT_V1".toByteArray(Charsets.UTF_8))
        try {
            clearArchiveTargets()
            installBundleEntries(incoming)
            val installed = collectExistingArchiveBytes()
            check(installed.keys == incoming.keys && incoming.all { (key, bytes) ->
                installed[key]?.contentEquals(bytes) == true
            }) { "A conferência do histórico após a importação falhou." }
            if (!deferCommit) finalizeArchiveBundleReplacement()
        } catch (failure: Throwable) {
            // Keep the marker until rollback has been verified. If rollback itself fails,
            // startup will retry restoring the pre-import image from the durable backup.
            runCatching {
                if (!archiveImportMarker.exists()) {
                    writeSynced(archiveImportMarker, "F1TM_HISTORY_IMPORT_V1".toByteArray(Charsets.UTF_8))
                }
                clearArchiveTargets()
                installBundleEntries(oldEntries)
                val restored = collectExistingArchiveBytes()
                check(restored.keys == oldEntries.keys && oldEntries.all { (key, bytes) ->
                    restored[key]?.contentEquals(bytes) == true
                }) { "A restauração do histórico anterior não pôde ser confirmada." }
                check(archiveImportMarker.delete() || !archiveImportMarker.exists())
                archiveImportBackup.deleteRecursively()
            }.onFailure { rollbackFailure -> failure.addSuppressed(rollbackFailure) }
            throw failure
        }
    }

    /** Complete a staged archive replacement after the enclosing career import commits. */
    @Synchronized
    fun finalizeArchiveBundleReplacement() {
        check(archiveImportMarker.delete() || !archiveImportMarker.exists()) {
            "Não foi possível confirmar a substituição do histórico."
        }
        archiveImportBackup.deleteRecursively()
        runCatching { reconcileCompletedSeasonSummaries() }
    }

    /** Roll back a staged replacement; PREPARED career imports always restore the old archive. */
    @Synchronized
    fun rollbackArchiveBundleReplacement(): Boolean = runCatching {
        if (archiveImportMarker.exists()) recoverInterruptedArchiveImport()
        else archiveImportBackup.deleteRecursively()
        !archiveImportMarker.exists()
    }.getOrDefault(false)

    private fun decodeArchiveBundle(bundle: org.json.JSONObject): Map<String, ByteArray> {
        require(bundle.optString("format") == "F1TM_HISTORY_ARCHIVE" && bundle.optInt("version") == 1) {
            "Formato do arquivo histórico não reconhecido."
        }
        val files = bundle.optJSONArray("files") ?: error("Backup sem lista de arquivos históricos.")
        require(files.length() <= 5000 && bundle.optInt("fileCount", -1) == files.length()) {
            "Quantidade de arquivos históricos inválida."
        }
        val decoded = linkedMapOf<String, ByteArray>()
        var totalBytes = 0L
        for (index in 0 until files.length()) {
            val item = files.optJSONObject(index) ?: error("Entrada histórica inválida.")
            val path = item.optString("path")
            require(path == "legacy/f1tm_historical_v2.db" ||
                Regex("^races/season_[1-9][0-9]*_round_[0-9]{2}\\.db$").matches(path) ||
                Regex("^seasons/season_[1-9][0-9]*\\.db$").matches(path)) {
                "Caminho de arquivo histórico não permitido: $path"
            }
            require(path !in decoded) { "Arquivo histórico duplicado: $path" }
            val bytes = android.util.Base64.decode(item.getString("content"), android.util.Base64.DEFAULT)
            totalBytes += bytes.size
            require(totalBytes <= 200L * 1024L * 1024L) { "O histórico excede o limite de tamanho permitido." }
            require(item.optString("sha256") == sha256Hex(bytes)) { "Arquivo histórico corrompido: $path" }
            decoded[path] = bytes
        }
        return decoded
    }

    private fun collectExistingArchiveBytes(): Map<String, ByteArray> {
        val result = linkedMapOf<String, ByteArray>()
        fun readAtomic(path: String, source: File) {
            if (source.exists() || File(source.path + ".bak").exists()) {
                result[path] = AtomicFile(source).openRead().use { it.readBytes() }
            }
        }
        readAtomic("legacy/f1tm_historical_v2.db", file)
        // AtomicFile temporarily moves the last committed image to *.bak while a new
        // shard is being written. Include that canonical base name too, so a backup
        // created during a crash never silently omits the last committed shard.
        fun committedShardFiles(directory: File, pattern: Regex): List<File> =
            directory.listFiles().orEmpty().filter { it.isFile }
                .map { it.name.removeSuffix(".bak") }
                .distinct()
                .filter(pattern::matches)
                .map { File(directory, it) }
        committedShardFiles(raceArchiveDirectory, raceArchiveName)
            .forEach { readAtomic("races/${it.name}", it) }
        committedShardFiles(seasonArchiveDirectory, seasonArchiveName)
            .forEach { readAtomic("seasons/${it.name}", it) }
        return result
    }

    private fun writeBundleTree(root: File, entries: Map<String, ByteArray>) {
        root.deleteRecursively()
        entries.forEach { (path, bytes) -> writeSynced(File(root, path), bytes) }
    }

    private fun installBundleEntries(entries: Map<String, ByteArray>) {
        entries.forEach { (path, bytes) ->
            val target = when {
                path == "legacy/f1tm_historical_v2.db" -> file
                path.startsWith("races/") -> File(raceArchiveDirectory, path.removePrefix("races/"))
                path.startsWith("seasons/") -> File(seasonArchiveDirectory, path.removePrefix("seasons/"))
                else -> error("Caminho histórico inválido: $path")
            }
            writeSynced(target, bytes)
        }
    }

    private fun clearArchiveTargets() {
        listOf(file, File(file.path + ".bak"), File(file.path + ".new")).forEach { it.delete() }
        raceArchiveDirectory.deleteRecursively()
        seasonArchiveDirectory.deleteRecursively()
    }

    private fun recoverInterruptedArchiveImport() {
        if (archiveImportMarker.exists()) {
            if (careerImportJournalStatus() == "COMMITTED") {
                // The containing career import reached its single durable commit point.
                // Keep the new archive; CareerPreferences will finish auxiliary cleanup.
                archiveImportMarker.delete()
                archiveImportBackup.deleteRecursively()
                return
            }
            val backupEntries = linkedMapOf<String, ByteArray>()
            val legacy = File(archiveImportBackup, "legacy/f1tm_historical_v2.db")
            if (legacy.exists()) backupEntries["legacy/f1tm_historical_v2.db"] = legacy.readBytes()
            File(archiveImportBackup, "races").listFiles().orEmpty()
                .filter { it.isFile && raceArchiveName.matches(it.name) }
                .forEach { backupEntries["races/${it.name}"] = it.readBytes() }
            File(archiveImportBackup, "seasons").listFiles().orEmpty()
                .filter { it.isFile && seasonArchiveName.matches(it.name) }
                .forEach { backupEntries["seasons/${it.name}"] = it.readBytes() }
            clearArchiveTargets()
            installBundleEntries(backupEntries)
            check(archiveImportMarker.delete() || !archiveImportMarker.exists()) {
                "Não foi possível concluir a recuperação do histórico anterior."
            }
        }
        archiveImportBackup.deleteRecursively()
    }

    /** The status line is shared with CareerPreferences to coordinate one import commit point. */
    private fun careerImportJournalStatus(): String? {
        val journal = File(filesDir, "f1tm_career_import.transaction")
        if (!journal.exists() && !File(journal.path + ".bak").exists()) return null
        return runCatching {
            AtomicFile(journal).openRead().bufferedReader(Charsets.UTF_8).use { it.readLine() }
        }.getOrNull()
    }

    private fun writeSynced(target: File, bytes: ByteArray) {
        target.parentFile?.mkdirs()
        java.io.FileOutputStream(target).use { output ->
            output.write(bytes)
            output.flush()
            output.fd.sync()
        }
    }

    private fun sha256Hex(bytes: ByteArray): String =
        java.security.MessageDigest.getInstance("SHA-256").digest(bytes)
            .joinToString("") { "%02x".format(it) }

    @Synchronized
    private fun readAtomicLines(source: File): List<String> = if (!source.exists() && !File(source.path + ".bak").exists()) {
        emptyList()
    } else {
        // Do not treat a read failure as an empty archive: that could erase years of history.
        AtomicFile(source).openRead().bufferedReader(Charsets.UTF_8).use { it.readLines() }
    }

    /**
     * V654: preserve the v2 monolithic archive while merging v3 incremental GP and season
     * files. Race shards still replace only their exact round. Season summaries are merged
     * by record identity, not by season: a partial SD/SK/C/K shard must never hide valid
     * records that still exist in the legacy archive.
     */
    private fun seasonRecordKey(line: String): Pair<Int, String>? {
        val p = line.split('|')
        val season = p.getOrNull(1)?.toIntOrNull() ?: return null
        val key = when (p.firstOrNull()) {
            "SD" -> {
                if (p.size < 13 || listOf(2, 3, 5, 7, 8, 9, 10, 11, 12).any { p[it].toIntOrNull() == null }) return null
                "SD:${p[3]}"
            }
            "SK" -> {
                if (p.size < 11 || listOf(2, 3, 5, 6, 7, 8, 9, 10).any { p[it].toIntOrNull() == null }) return null
                "SK:${p[3]}"
            }
            "C" -> {
                if (p.size < 7 || listOf(2, 4, 6).any { p[it].toIntOrNull() == null }) return null
                "C"
            }
            "K" -> {
                if (p.size < 5 || listOf(2, 4).any { p[it].toIntOrNull() == null }) return null
                "K"
            }
            else -> return null
        }
        return season to key
    }

    @Synchronized
    private fun readSeasonSummaryLines(season: Int): List<String> {
        val legacy = readAtomicLines(file).filter { line ->
            val p = line.split('|', limit = 4)
            p.firstOrNull() in setOf("SD", "SK", "C", "K") && p.getOrNull(1)?.toIntOrNull() == season
        }
        val shard = readAtomicLines(File(seasonArchiveDirectory, "season_${season}.db"))
        val records = linkedMapOf<String, String>()
        (legacy + shard).forEach { line ->
            val identity = seasonRecordKey(line) ?: return@forEach
            if (identity.first == season) records[identity.second] = line
        }
        return records.values.toList()
    }

    @Synchronized
    private fun readLines(): List<String> {
        val legacyLines = readAtomicLines(file)
        val raceFiles = raceArchiveDirectory.listFiles()
            ?.filter { it.isFile && raceArchiveName.matches(it.name) }
            ?.sortedBy { it.name }
            .orEmpty()
        val raceShards = raceFiles.mapNotNull { shard ->
            val match = raceArchiveName.matchEntire(shard.name) ?: return@mapNotNull null
            val season = match.groupValues[1].toIntOrNull() ?: return@mapNotNull null
            val round = match.groupValues[2].toIntOrNull() ?: return@mapNotNull null
            Triple(season, round, readAtomicLines(shard))
        }
        val shadowedRaces = raceShards.map { it.first to it.second }.toSet()

        val seasonFiles = seasonArchiveDirectory.listFiles()
            ?.filter { it.isFile && seasonArchiveName.matches(it.name) }
            ?.sortedBy { it.name }
            .orEmpty()
        val seasonShards = seasonFiles.mapNotNull { shard ->
            val match = seasonArchiveName.matchEntire(shard.name) ?: return@mapNotNull null
            val season = match.groupValues[1].toIntOrNull() ?: return@mapNotNull null
            season to readAtomicLines(shard)
        }

        // Keep the legacy row as a fallback for every identity absent from the shard.
        // Shard rows win only for their own driver/team/champion record.
        val summaryRecords = linkedMapOf<Int, LinkedHashMap<String, String>>()
        (legacyLines + seasonShards.flatMap { it.second }).forEach { line ->
            val identity = seasonRecordKey(line) ?: return@forEach
            summaryRecords.getOrPut(identity.first) { linkedMapOf() }[identity.second] = line
        }
        val filteredLegacy = legacyLines.filterNot { line ->
            val p = line.split('|', limit = 4)
            when (p.firstOrNull()) {
                "R", "P", "Q" -> {
                    val season = p.getOrNull(1)?.toIntOrNull()
                    val round = p.getOrNull(2)?.toIntOrNull()
                    season != null && round != null && (season to round) in shadowedRaces
                }
                "SD", "SK", "C", "K" -> true
                else -> false
            }
        }
        return filteredLegacy + summaryRecords.values.flatMap { it.values } + raceShards.flatMap { it.third }
    }

    private fun writeAtomicLines(target: File, lines: List<String>) {
        target.parentFile?.mkdirs()
        val targetAtomicFile = AtomicFile(target)
        val output = targetAtomicFile.startWrite()
        try {
            output.write(lines.joinToString("\n").toByteArray(Charsets.UTF_8))
            output.flush()
            output.fd.sync()
            targetAtomicFile.finishWrite(output)
        } catch (failure: Throwable) {
            targetAtomicFile.failWrite(output)
            throw failure
        }
    }

    private fun writeRaceLines(season: Int, round: Int, lines: List<String>) {
        val target = File(raceArchiveDirectory, "season_${season}_round_${round.toString().padStart(2, '0')}.db")
        writeAtomicLines(target, lines)
    }

    private fun writeSeasonLines(season: Int, lines: List<String>) {
        val target = File(seasonArchiveDirectory, "season_${season}.db")
        writeAtomicLines(target, lines)
    }

    /** Read only one season from the legacy archive and its incremental GP shards. */
    @Synchronized
    private fun readSeasonRaceLines(season: Int): List<String> {
        val legacySeasonRows = readAtomicLines(file).filter { line ->
            val p = line.split('|', limit = 4)
            (p.firstOrNull()?.let { it in setOf("R", "P", "Q") } == true) && p.getOrNull(1)?.toIntOrNull() == season
        }
        val prefix = "season_${season}_round_"
        val seasonRaceFiles = raceArchiveDirectory.listFiles()
            ?.filter { it.isFile && it.name.startsWith(prefix) && raceArchiveName.matches(it.name) }
            ?.sortedBy { it.name }
            .orEmpty()
        val seasonShards = seasonRaceFiles.mapNotNull { shard ->
            val match = raceArchiveName.matchEntire(shard.name) ?: return@mapNotNull null
            val round = match.groupValues[2].toIntOrNull() ?: return@mapNotNull null
            round to readAtomicLines(shard)
        }
        val shadowedRounds = seasonShards.map { it.first }.toSet()
        val filteredLegacy = legacySeasonRows.filterNot { line ->
            val p = line.split('|', limit = 4)
            p.getOrNull(2)?.toIntOrNull()?.let { it in shadowedRounds } == true
        }
        return filteredLegacy + seasonShards.flatMap { it.second }
    }

    @Synchronized
    fun recordRace(season: Int, round: RoundDefinition, result: RaceResult, qualifying: QualifyingResult?, market: DriverMarketState? = null) {
        // One GP is one atomic historical entry. Re-recording the same GP replaces it,
        // preventing duplicate wins/poles/fastest laps after reopening a result screen.
        // Write only this GP's rows. Replacing the GP shard is atomic and idempotent;
        // previously completed seasons are not read or rewritten on the race-finalization path.
        val raceLines = mutableListOf<String>()
        fun resolveTeamId(driverId: Int, fallbackTeamName: String): Int =
            market?.contracts?.firstOrNull { it.driverId == driverId && it.activeIn(season) }?.teamId
                ?: WorldDatabase.teams.firstOrNull { it.name.equals(fallbackTeamName, ignoreCase = true) }?.id
                ?: WorldDatabase.allDrivers.firstOrNull { it.id == driverId }?.teamId ?: 0
        fun resolveTeamName(teamId: Int, fallback: String): String =
            WorldDatabase.teams.firstOrNull { it.id == teamId }?.name ?: fallback

        val leaderEntry = result.classification.firstOrNull { !it.status.startsWith("DNF") }
        val leader = leaderEntry?.totalTimeMs ?: 0L
        result.classification.forEach { f ->
            val teamId = resolveTeamId(f.driverId, f.teamName)
            val teamName = resolveTeamName(teamId, f.teamName)
            val points = result.points[f.driverId] ?: 0
            val gap = if (f.status.startsWith("DNF") || leaderEntry == null || leader == 0L) 0L
            else if (f.laps < leaderEntry.laps) -(leaderEntry.laps - f.laps).toLong()
            else (f.totalTimeMs - leader).coerceAtLeast(0L)
            val isFastest = f.driverId == result.fastestLapDriverId
            raceLines += listOf(
                "R", season, round.round, enc(round.grandPrix), teamId, enc(teamName), f.driverId,
                enc(f.driverName), f.position, points, f.laps, f.totalTimeMs, gap, enc(f.status),
                f.tyre.name, f.pitStops, if (isFastest) 1 else 0,
                if (isFastest) result.fastestLapTimeMs else 0L
            ).joinToString("|")
        }

        // Stage 1 also keeps the full qualifying grid so average qualifying can
        // participate in the end-of-season performance index. Pole remains a
        // separate compact record for the historical UI.
        qualifying?.grid?.forEach { q ->
            val driver = WorldDatabase.allDrivers.firstOrNull { it.id == q.driverId }
            val fallbackTeamName = result.classification.firstOrNull { f -> f.driverId == q.driverId }?.teamName.orEmpty()
            val teamId = resolveTeamId(q.driverId, fallbackTeamName)
            val teamName = resolveTeamName(teamId, fallbackTeamName.ifBlank { "Equipe $teamId" })
            raceLines += listOf(
                "Q", season, round.round, enc(round.grandPrix), teamId, enc(teamName),
                q.driverId, enc(driver?.name ?: "Piloto ${q.driverId}"), q.position, q.lapTimeMs
            ).joinToString("|")
        }
        qualifying?.grid?.firstOrNull { it.position == 1 }?.let { q ->
            val driver = WorldDatabase.allDrivers.firstOrNull { it.id == q.driverId }
            val fallbackTeamName = result.classification.firstOrNull { f -> f.driverId == q.driverId }?.teamName.orEmpty()
            val teamId = resolveTeamId(q.driverId, fallbackTeamName)
            val teamName = resolveTeamName(teamId, fallbackTeamName.ifBlank { "Equipe $teamId" })
            raceLines += listOf(
                "P", season, round.round, enc(round.grandPrix), teamId, enc(teamName),
                q.driverId, enc(driver?.name ?: "Piloto ${q.driverId}"), q.lapTimeMs
            ).joinToString("|")
        }

        writeRaceLines(season, round.round, raceLines)
    }

    /**
     * A season is finalized only when both championship tables and both champion
     * ledger records agree. A partial SD row is not a completion marker.
     */
    @Synchronized
    fun isSeasonFinalized(season: Int): Boolean {
        // Keep the hot completion check bounded to this season's summary and race shards;
        // do not load/parse every historical GP whenever a career advances a week.
        val summaryLines = readSeasonSummaryLines(season)
        val raceLines = readSeasonRaceLines(season)
        val lines = summaryLines
        val drivers = lines.mapNotNull { line ->
            val p = line.split('|')
            if (p.firstOrNull() != "SD" || p.getOrNull(1)?.toIntOrNull() != season || p.size < 13) null
            else runCatching { DriverSeasonRecord(season, p[2].toInt(), p[3].toInt(), dec(p[4]), p[5].toInt(), dec(p[6]), p[7].toInt(), p[8].toInt(), p[9].toInt(), p[10].toInt(), p[11].toInt(), p[12].toInt()) }.getOrNull()
        }
        val constructors = lines.mapNotNull { line ->
            val p = line.split('|')
            if (p.firstOrNull() != "SK" || p.getOrNull(1)?.toIntOrNull() != season || p.size < 11) null
            else runCatching { ConstructorSeasonRecord(season, p[2].toInt(), p[3].toInt(), dec(p[4]), p[5].toInt(), p[6].toInt(), p[7].toInt(), p[8].toInt(), p[9].toInt(), p[10].toInt()) }.getOrNull()
        }
        val driverWinners = lines.mapNotNull { line ->
            val p = line.split('|')
            if (p.firstOrNull() != "C" || p.getOrNull(1)?.toIntOrNull() != season || p.size < 7) null
            else runCatching { DriverChampion(season, p[2].toInt(), dec(p[3]), p[4].toInt(), dec(p[5]), p[6].toInt()) }.getOrNull()
        }
        val constructorWinners = lines.mapNotNull { line ->
            val p = line.split('|')
            if (p.firstOrNull() != "K" || p.getOrNull(1)?.toIntOrNull() != season || p.size < 5) null
            else runCatching { ConstructorChampion(season, p[2].toInt(), dec(p[3]), p[4].toInt()) }.getOrNull()
        }
        val driverChampion = driverWinners.singleOrNull() ?: return false
        val constructorChampion = constructorWinners.singleOrNull() ?: return false
        val firstDriver = drivers.minByOrNull { it.position } ?: return false
        val firstConstructor = constructors.minByOrNull { it.position } ?: return false
        val expectedRounds = SeasonCalendar.forSeason(season).size
        val completedRounds = raceRecordsFrom(raceLines, season).map { it.round }.toSet()
        val allRacesPresent = (1..expectedRounds).all { it in completedRounds }
        return allRacesPresent && drivers.size >= WorldDatabase.drivers.size &&
            drivers.map { it.driverId }.distinct().size == drivers.size &&
            drivers.map { it.position }.distinct().size == drivers.size &&
            constructors.size >= WorldDatabase.teams.size &&
            constructors.map { it.teamId }.distinct().size == constructors.size &&
            constructors.map { it.position }.distinct().size == constructors.size &&
            firstDriver.position == 1 && firstConstructor.position == 1 &&
            driverChampion.driverId == firstDriver.driverId && driverChampion.points == firstDriver.points &&
            constructorChampion.teamId == firstConstructor.teamId && constructorChampion.points == firstConstructor.points
    }

    /**
     * Rebuilds a missing/partial annual snapshot only when every scheduled GP exists.
     * This repairs old saves on startup/import without manufacturing unfinished seasons.
     */
    @Synchronized
    private fun reconcileCompletedSeasonSummaries() {
        val races = raceRecordsFrom(readLines())
        races.groupBy { it.season }.forEach { (year, rows) ->
            val expectedRounds = SeasonCalendar.forSeason(year).size
            val completedRounds = rows.map { it.round }.toSet()
            if ((1..expectedRounds).all { it in completedRounds } && !isSeasonFinalized(year)) {
                val driverPoints = rows.groupBy { it.driverId }.mapValues { (_, entries) -> entries.sumOf { it.points } }
                val constructorPoints = rows.groupBy { it.teamId }.mapValues { (_, entries) -> entries.sumOf { it.points } }
                finalizeSeason(year, driverPoints, constructorPoints, null)
            }
        }
    }

    /**
     * Archives a complete season. A valid existing snapshot remains immutable; an
     * incomplete legacy/shard snapshot is repaired and atomically replaced.
     */
    @Synchronized
    fun finalizeSeason(season: Int, driverPoints: Map<Int, Int>, constructorPoints: Map<Int, Int>, market: DriverMarketState? = null) {
        if (isSeasonFinalized(season)) return

        // A season summary depends only on the target season, not the entire career.
        // Loading/rewriting every prior GP at the boundary was another source of stalls.
        val seasonRows = readSeasonRaceLines(season)
        val lines = mutableListOf<String>()
        val races = raceRecordsFrom(seasonRows, season)
        val expectedRounds = SeasonCalendar.forSeason(season).size
        val completedRounds = races.map { it.round }.toSet()
        // Do not invent a final table from a points map if one or more official GPs
        // are absent from the durable race archive.
        if (!(1..expectedRounds).all { it in completedRounds }) return
        val effectiveDriverPoints = driverPoints.ifEmpty {
            races.groupBy { it.driverId }.mapValues { (_, rows) -> rows.sumOf { it.points } }
        }
        val effectiveConstructorPoints = constructorPoints.ifEmpty {
            races.groupBy { it.teamId }.mapValues { (_, rows) -> rows.sumOf { it.points } }
        }
        val poles = poleRecordsFrom(seasonRows, season)
        val fastest = races.filter { it.isFastestLap && it.fastestLapTimeMs > 0L }
        val victories = races.filter { it.position == 1 && !it.status.startsWith("DNF") }

        // A market object can exist while its contract list is temporarily incomplete
        // (legacy import, mid-season transition, or repaired market save). Include every
        // actual championship participant and every ID represented in the points ledger.
        val activeIds = (
            market?.contracts?.filter { it.activeIn(season) }?.map { it.driverId }.orEmpty() +
                races.map { it.driverId } + effectiveDriverPoints.keys
            ).distinct().ifEmpty { WorldDatabase.drivers.map { it.id } }
        val driverRows = activeIds.mapNotNull { id ->
            val d = WorldDatabase.allDrivers.firstOrNull { it.id == id } ?: return@mapNotNull null
            val rows = races.filter { it.driverId == d.id }
            val last = rows.maxByOrNull { it.round }
            DriverSeasonRecord(
                season = season,
                position = 0,
                driverId = d.id,
                driverName = last?.driverName ?: d.name,
                teamId = last?.teamId ?: market?.contracts?.firstOrNull { it.driverId == d.id && it.activeIn(season) }?.teamId ?: d.teamId,
                teamName = last?.teamName ?: WorldDatabase.teams.firstOrNull { it.id == (market?.contracts?.firstOrNull { it.driverId == d.id && it.activeIn(season) }?.teamId ?: d.teamId) }?.name.orEmpty(),
                points = effectiveDriverPoints[d.id] ?: rows.sumOf { it.points },
                wins = victories.count { it.driverId == d.id },
                poles = poles.count { it.driverId == d.id },
                fastestLaps = fastest.count { it.driverId == d.id },
                dnf = rows.count { it.status.startsWith("DNF") },
                gps = rows.count { !it.status.startsWith("DNF", ignoreCase = true) }
            )
        }.sortedWith(
            compareByDescending<DriverSeasonRecord> { it.points }
                .thenByDescending { it.wins }
                .thenByDescending { it.poles }
                .thenByDescending { it.fastestLaps }
                .thenBy { it.driverId }
        ).mapIndexed { index, row -> row.copy(position = index + 1) }

        val constructorRows = WorldDatabase.teams.map { team ->
            val rows = races.filter { it.teamId == team.id }
            ConstructorSeasonRecord(
                season = season,
                position = 0,
                teamId = team.id,
                teamName = team.name,
                points = effectiveConstructorPoints[team.id] ?: rows.sumOf { it.points },
                wins = victories.count { it.teamId == team.id },
                poles = poles.count { it.teamId == team.id },
                fastestLaps = fastest.count { it.teamId == team.id },
                dnf = rows.count { it.status.startsWith("DNF") },
                gps = rows.groupBy { it.round }.count { (_, gpRows) -> gpRows.any { !it.status.startsWith("DNF", ignoreCase = true) } }
            )
        }.sortedWith(
            compareByDescending<ConstructorSeasonRecord> { it.points }
                .thenByDescending { it.wins }
                .thenByDescending { it.poles }
                .thenByDescending { it.fastestLaps }
                .thenBy { it.teamId }
        ).mapIndexed { index, row -> row.copy(position = index + 1) }

        driverRows.forEach { r ->
            lines += listOf("SD", r.season, r.position, r.driverId, enc(r.driverName), r.teamId, enc(r.teamName), r.points, r.wins, r.poles, r.fastestLaps, r.dnf, r.gps).joinToString("|")
        }
        constructorRows.forEach { r ->
            lines += listOf("SK", r.season, r.position, r.teamId, enc(r.teamName), r.points, r.wins, r.poles, r.fastestLaps, r.dnf, r.gps).joinToString("|")
        }

        // Keep the compact champion records for compatibility with existing UI/data readers.
        driverRows.firstOrNull()?.let { r ->
            lines += listOf("C", season, r.driverId, enc(r.driverName), r.teamId, enc(r.teamName), r.points).joinToString("|")
        }
        constructorRows.firstOrNull()?.let { r ->
            lines += listOf("K", season, r.teamId, enc(r.teamName), r.points).joinToString("|")
        }
        // Do not persist a half-summary: it would be indistinguishable from a completed
        // season to older readers and could hide a missing champion permanently.
        if (driverRows.size < WorldDatabase.drivers.size || constructorRows.size < WorldDatabase.teams.size ||
            driverRows.firstOrNull() == null || constructorRows.firstOrNull() == null) return
        writeSeasonLines(season, lines)
    }

    fun raceRecords(season: Int? = null): List<RaceRecord> =
        raceRecordsFrom(if (season == null) readLines() else readSeasonRaceLines(season), season)

    private fun raceRecordsFrom(source: List<String>, season: Int? = null): List<RaceRecord> = source.mapNotNull { line ->
        val p = line.split('|')
        if (p.size < 16 || p[0] != "R") return@mapNotNull null
        runCatching {
            val s = p[1].toInt()
            if (season != null && s != season) return@runCatching null
            RaceRecord(
                season = s,
                round = p[2].toInt(),
                grandPrix = dec(p[3]),
                teamId = p[4].toInt(),
                teamName = dec(p[5]),
                driverId = p[6].toInt(),
                driverName = dec(p[7]),
                position = p[8].toInt(),
                points = p[9].toInt(),
                laps = p[10].toInt(),
                totalTimeMs = p[11].toLong(),
                gapToLeaderMs = p[12].toLong(),
                status = dec(p[13]),
                tyre = Tyre.valueOf(p[14]),
                pitStops = p[15].toInt(),
                isFastestLap = p.getOrNull(16) == "1",
                fastestLapTimeMs = p.getOrNull(17)?.toLongOrNull() ?: 0L
            )
        }.getOrNull()
    }


    fun qualifyingRecords(season:Int? = null): List<QualifyingRecord> = (if (season == null) readLines() else readSeasonRaceLines(season)).mapNotNull { line ->
        runCatching {
            val p=line.split("|"); if(p.firstOrNull()!="Q") return@runCatching null
            val s=p[1].toInt(); if(season!=null && s!=season) return@runCatching null
            QualifyingRecord(s,p[2].toInt(),p[6].toInt(),dec(p[7]),p[4].toInt(),dec(p[5]),p[8].toInt(),p[9].toLong())
        }.getOrNull()
    }.sortedWith(compareBy<QualifyingRecord>{it.season}.thenBy{it.round}.thenBy{it.position})

    fun poleRecords(season: Int? = null): List<PoleRecord> =
        poleRecordsFrom(if (season == null) readLines() else readSeasonRaceLines(season), season)

    private fun poleRecordsFrom(source: List<String>, season: Int? = null): List<PoleRecord> = source.mapNotNull { line ->
        val p = line.split('|')
        if (p.size < 9 || p[0] != "P") return@mapNotNull null
        runCatching {
            val s = p[1].toInt()
            if (season != null && s != season) return@runCatching null
            PoleRecord(s, p[2].toInt(), dec(p[3]), p[4].toInt(), dec(p[5]), p[6].toInt(), dec(p[7]), p[8].toLong())
        }.getOrNull()
    }

    fun driverSeasonRecords(season: Int? = null): List<DriverSeasonRecord> = (if (season == null) readLines() else readSeasonSummaryLines(season)).mapNotNull { line ->
        val p = line.split('|')
        if (p.size < 13 || p[0] != "SD") return@mapNotNull null
        runCatching {
            val s = p[1].toInt()
            if (season != null && s != season) return@runCatching null
            DriverSeasonRecord(s, p[2].toInt(), p[3].toInt(), dec(p[4]), p[5].toInt(), dec(p[6]), p[7].toInt(), p[8].toInt(), p[9].toInt(), p[10].toInt(), p[11].toInt(), p[12].toInt())
        }.getOrNull()
    }.sortedWith(compareBy<DriverSeasonRecord> { it.season }.thenBy { it.position })

    fun constructorSeasonRecords(season: Int? = null): List<ConstructorSeasonRecord> = (if (season == null) readLines() else readSeasonSummaryLines(season)).mapNotNull { line ->
        val p = line.split('|')
        if (p.size < 11 || p[0] != "SK") return@mapNotNull null
        runCatching {
            val s = p[1].toInt()
            if (season != null && s != season) return@runCatching null
            ConstructorSeasonRecord(s, p[2].toInt(), p[3].toInt(), dec(p[4]), p[5].toInt(), p[6].toInt(), p[7].toInt(), p[8].toInt(), p[9].toInt(), p[10].toInt())
        }.getOrNull()
    }.sortedWith(compareBy<ConstructorSeasonRecord> { it.season }.thenBy { it.position })

    fun driverChampions(season: Int? = null): List<DriverChampion> = readLines().mapNotNull { line ->
        val p = line.split('|')
        if (p.size < 7 || p[0] != "C") return@mapNotNull null
        runCatching {
            val s = p[1].toInt()
            if (season != null && s != season) return@runCatching null
            DriverChampion(s, p[2].toInt(), dec(p[3]), p[4].toInt(), dec(p[5]), p[6].toInt())
        }.getOrNull()
    }.sortedByDescending { it.season }

    fun constructorChampions(season: Int? = null): List<ConstructorChampion> = readLines().mapNotNull { line ->
        val p = line.split('|')
        if (p.size < 5 || p[0] != "K") return@mapNotNull null
        runCatching {
            val s = p[1].toInt()
            if (season != null && s != season) return@runCatching null
            ConstructorChampion(s, p[2].toInt(), dec(p[3]), p[4].toInt())
        }.getOrNull()
    }.sortedByDescending { it.season }

    /** Only completed seasons appear here. The live season never leaks into Temporadas. */
    fun seasons(): List<Int> = (driverSeasonRecords().map { it.season } + constructorSeasonRecords().map { it.season })
        .distinct()
        .sortedDescending()

    fun victories(): List<RaceRecord> = raceRecords()
        .filter { it.position == 1 && !it.status.startsWith("DNF") }
        .sortedWith(compareByDescending<RaceRecord> { it.season }.thenBy { it.round })

    fun fastestLaps(season: Int? = null): List<RaceRecord> = raceRecords(season)
        .filter { it.isFastestLap && it.fastestLapTimeMs > 0L }
        .sortedWith(compareByDescending<RaceRecord> { it.season }.thenBy { it.round })

    fun poles(): List<PoleRecord> = poleRecords()
        .sortedWith(compareByDescending<PoleRecord> { it.season }.thenBy { it.round })

    fun hallRanking(scope: HallScope, metric: HallMetric): List<HallEntry> {
        val current = hallValues(scope, metric, includeSeason = true)
        val previous = hallValues(scope, metric, includeSeason = false)
        val previousPositions = previous.sortedByDescending { it.value }
            .mapIndexed { index, e -> e.id to index + 1 }
            .toMap()
        return current.sortedByDescending { it.value }.mapIndexed { index, e ->
            val position = index + 1
            val old = previousPositions[e.id]
            e.copy(position = position, movement = if (old == null) Int.MIN_VALUE else old - position)
        }
    }

    private fun hallValues(scope: HallScope, metric: HallMetric, includeSeason: Boolean): List<HallEntry> {
        // Aggregate once per archive snapshot. The former implementation scanned the
        // complete race/season lists once for every driver/team, becoming progressively
        // slower as the career accumulated seasons.
        val raceRows = raceRecords()
        val seasonYears = seasons()
        val latestRace = raceRows.maxWithOrNull(compareBy<RaceRecord> { it.season }.thenBy { it.round })
        val latestSeason = seasonYears.maxOrNull()
        val effectiveRaces = if (includeSeason || latestRace == null) raceRows else raceRows.filterNot { it.season == latestRace.season && it.round == latestRace.round }
        val effectiveSeasonYears = if (includeSeason || latestSeason == null) seasonYears.toSet() else seasonYears.filter { it != latestSeason }.toSet()
        val effectiveSeasonDrivers = driverSeasonRecords().filter { it.season in effectiveSeasonYears }
        val effectiveSeasonTeams = constructorSeasonRecords().filter { it.season in effectiveSeasonYears }
        val effectivePoles = poleRecords().filter { includeSeason || !(it.season == latestRace?.season && it.round == latestRace?.round) }
        val effectiveFastest = fastestLaps().filter { includeSeason || !(it.season == latestRace?.season && it.round == latestRace?.round) }
        val effectiveWins = effectiveRaces.filter { it.position == 1 && !it.status.startsWith("DNF") }

        val driverChampionsById = driverChampions().asSequence()
            .filter { includeSeason || it.season != latestSeason }.groupingBy { it.driverId }.eachCount()
        val constructorChampionsById = constructorChampions().asSequence()
            .filter { includeSeason || it.season != latestSeason }.groupingBy { it.teamId }.eachCount()
        val winsByDriver = effectiveWins.groupingBy { it.driverId }.eachCount()
        val winsByTeam = effectiveWins.groupingBy { it.teamId }.eachCount()
        val polesByDriver = effectivePoles.groupingBy { it.driverId }.eachCount()
        val polesByTeam = effectivePoles.groupingBy { it.teamId }.eachCount()
        val fastestByDriver = effectiveFastest.groupingBy { it.driverId }.eachCount()
        val fastestByTeam = effectiveFastest.groupingBy { it.teamId }.eachCount()
        val driverPointsById = effectiveSeasonDrivers.groupBy { it.driverId }.mapValues { (_, rows) -> rows.sumOf { it.points } }
        val driverGpsById = effectiveSeasonDrivers.groupBy { it.driverId }.mapValues { (_, rows) -> rows.sumOf { it.gps } }
        val teamPointsById = effectiveSeasonTeams.groupBy { it.teamId }.mapValues { (_, rows) -> rows.sumOf { it.points } }
        val teamGpsById = effectiveSeasonTeams.groupBy { it.teamId }.mapValues { (_, rows) -> rows.sumOf { it.gps } }
        val lastRaceByDriver = raceRows.groupBy { it.driverId }.mapValues { (_, rows) -> rows.maxByOrNull { it.season * 100 + it.round } }

        return when (scope) {
            HallScope.DRIVERS -> {
                WorldDatabase.drivers.asSequence().distinctBy { it.id }.mapNotNull { d ->
                    val id = d.id
                    val sample = lastRaceByDriver[id]
                    val value = when (metric) {
                        HallMetric.CHAMPIONS -> driverChampionsById[id] ?: 0
                        HallMetric.WINS -> winsByDriver[id] ?: 0
                        HallMetric.POLES -> polesByDriver[id] ?: 0
                        HallMetric.FASTEST_LAPS -> fastestByDriver[id] ?: 0
                        HallMetric.POINTS -> driverPointsById[id] ?: 0
                        HallMetric.GPS -> driverGpsById[id] ?: 0
                    }
                    HallEntry(id, d.name.ifBlank { sample?.driverName ?: return@mapNotNull null }, sample?.teamId ?: d.teamId, sample?.teamName ?: WorldDatabase.teams.firstOrNull { it.id == d.teamId }?.name.orEmpty(), value, 0, 0)
                }.toList()
            }
            HallScope.CONSTRUCTORS -> WorldDatabase.teams.map { team ->
                val id = team.id
                val value = when (metric) {
                    HallMetric.CHAMPIONS -> constructorChampionsById[id] ?: 0
                    HallMetric.WINS -> winsByTeam[id] ?: 0
                    HallMetric.POLES -> polesByTeam[id] ?: 0
                    HallMetric.FASTEST_LAPS -> fastestByTeam[id] ?: 0
                    HallMetric.POINTS -> teamPointsById[id] ?: 0
                    HallMetric.GPS -> teamGpsById[id] ?: 0
                }
                HallEntry(id, team.name, id, team.name, value, 0, 0)
            }
        }
    }

    @Synchronized
    fun clear() {
        atomicFile.delete()
        raceArchiveDirectory.deleteRecursively()
        seasonArchiveDirectory.deleteRecursively()
    }

    private fun enc(value: String): String = android.util.Base64.encodeToString(value.toByteArray(Charsets.UTF_8), android.util.Base64.NO_WRAP)
    private fun dec(value: String): String = runCatching { String(android.util.Base64.decode(value, android.util.Base64.NO_WRAP), Charsets.UTF_8) }.getOrDefault(value)
}
