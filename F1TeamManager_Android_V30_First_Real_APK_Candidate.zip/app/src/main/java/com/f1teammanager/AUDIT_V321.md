# Auditoria V321

## Erros da captura
- `MainActivity.kt:4367` — removido o acesso inválido `st.teamName`.
- `MainActivity.kt:4373` — removido o segundo acesso inválido `st.teamName`; o ID de equipa usa `driverDef?.teamId` como fallback.
- `MainActivity.kt:4819` — removida a chave de fechamento extra antes de `RaceModalFrame`.

## Verificações estáticas
- Nenhuma ocorrência de `st.teamName` permanece no `MainActivity.kt`.
- Ordem evento > decisão do manager preservada.
- versionCode 321 / versionName 0.321.0.
- Integridade do ZIP verificada.
- A compilação Android não foi executada neste ambiente.
