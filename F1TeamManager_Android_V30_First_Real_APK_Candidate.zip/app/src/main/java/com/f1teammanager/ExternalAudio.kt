package com.f1teammanager

import android.content.ContentUris
import android.content.Context
import android.media.MediaPlayer
import android.net.Uri
import android.provider.MediaStore
import java.util.Locale

/** Audio externo em Pictures/F1Manager/Assets/Audio, com fallback OGG -> MP3. */
class ExternalAudio(private val context: Context) {
    private var player: MediaPlayer? = null
    private var currentId: String? = null
    private var sequence: List<String> = emptyList()
    private var sequenceIndex = 0
    private var looping = true
    private var generation = 0
    @Volatile private var foreground = true

    /** Pausa toda a reprodução ao sair do primeiro plano e retoma ao voltar. */
    @Synchronized fun setForeground(isForeground: Boolean) {
        if (foreground == isForeground) return
        foreground = isForeground
        val active = player ?: return
        if (!isForeground) {
            runCatching { if (active.isPlaying) active.pause() }
        } else {
            // Se prepareAsync ainda estiver pendente, onPrepared fará o start.
            runCatching { if (!active.isPlaying) active.start() }
        }
    }

    @Synchronized fun play(id: String, loop: Boolean = true) {
        sequence = listOf(id)
        sequenceIndex = 0
        looping = loop
        generation++
        startCurrent(generation)
    }

    /** Toca faixas em ordem e reinicia a sequência completa ao chegar ao fim. */
    @Synchronized fun playSequence(ids: List<String>) {
        if (ids.isEmpty()) { stop(); return }
        if (sequence == ids && player?.isPlaying == true) return
        sequence = ids.toList()
        sequenceIndex = 0
        looping = true
        generation++
        startCurrent(generation)
    }

    /** Toca um evento uma vez; não altera a faixa ambiente quando o arquivo não existe. */
    @Synchronized fun playEvent(id: String) {
        val uri = findAudio(id) ?: return
        val oldGeneration = generation
        runCatching {
            val mp = MediaPlayer()
            mp.setDataSource(context, uri)
            mp.isLooping = false
            mp.setOnCompletionListener { completed ->
                runCatching { completed.release() }
                synchronized(this) {
                    if (player === completed) {
                        player = null
                        currentId = null
                        if (generation == oldGeneration) startCurrent(generation)
                    }
                }
            }
            mp.setOnErrorListener { failed, _, _ ->
                runCatching { failed.release() }
                synchronized(this) { if (player === failed) { player = null; currentId = null; if (generation == oldGeneration) startCurrent(generation) } }
                true
            }
            mp.setOnPreparedListener { prepared -> if (foreground) runCatching { prepared.start() } }
            stopPlayerOnly()
            player = mp
            currentId = id
            mp.prepareAsync()
        }
    }

    @Synchronized fun stop() {
        generation++
        sequence = emptyList()
        sequenceIndex = 0
        stopPlayerOnly()
    }

    @Synchronized private fun startCurrent(expectedGeneration: Int) {
        if (expectedGeneration != generation || sequence.isEmpty()) return
        stopPlayerOnly()
        var attempts = 0
        while (attempts < sequence.size) {
            val id = sequence[sequenceIndex]
            val uri = findAudio(id)
            if (uri != null) {
                runCatching {
                    val mp = MediaPlayer()
                    mp.setDataSource(context, uri)
                    mp.isLooping = false
                    mp.setOnCompletionListener { completed ->
                        runCatching { completed.release() }
                        synchronized(this) {
                            if (player === completed && expectedGeneration == generation) {
                                player = null
                                currentId = null
                                if (looping && sequence.isNotEmpty()) {
                                    sequenceIndex = (sequenceIndex + 1) % sequence.size
                                    startCurrent(expectedGeneration)
                                }
                            }
                        }
                    }
                    mp.setOnErrorListener { failed, _, _ ->
                        runCatching { failed.release() }
                        synchronized(this) {
                            if (player === failed && expectedGeneration == generation) {
                                player = null; currentId = null
                                if (sequence.isNotEmpty()) { sequenceIndex = (sequenceIndex + 1) % sequence.size; startCurrent(expectedGeneration) }
                            }
                        }
                        true
                    }
                    mp.setOnPreparedListener { prepared -> if (expectedGeneration == generation && foreground) runCatching { prepared.start() } }
                    player = mp
                    currentId = id
                    mp.prepareAsync()
                    return
                }
            }
            sequenceIndex = (sequenceIndex + 1) % sequence.size
            attempts++
        }
        currentId = null
    }

    @Synchronized private fun stopPlayerOnly() {
        val old = player
        player = null
        currentId = null
        if (old != null) runCatching { if (old.isPlaying) old.stop() }.also { runCatching { old.reset(); old.release() } }
    }

    private fun findAudio(id: String): Uri? {
        val resolver = context.contentResolver
        val base = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.DISPLAY_NAME, MediaStore.Audio.Media.RELATIVE_PATH)
        val wanted = listOf("$id.ogg", "$id.mp3")
        return runCatching {
            resolver.query(base, projection,
                "${MediaStore.Audio.Media.RELATIVE_PATH} LIKE ?",
                arrayOf("%F1Manager/Assets/Audio/%"), null
            )?.use { c ->
                val ix = c.getColumnIndex(MediaStore.Audio.Media._ID)
                val nx = c.getColumnIndex(MediaStore.Audio.Media.DISPLAY_NAME)
                val px = c.getColumnIndex(MediaStore.Audio.Media.RELATIVE_PATH)
                if (ix < 0 || nx < 0 || px < 0) return@use null
                val found = mutableMapOf<String, Uri>()
                while (c.moveToNext()) {
                    val path = c.getString(px).orEmpty().replace('\\','/').lowercase(Locale.ROOT)
                    if (!path.contains("f1manager/assets/audio/")) continue
                    val name = c.getString(nx).orEmpty().lowercase(Locale.ROOT)
                    if (name in wanted) found[name] = ContentUris.withAppendedId(base, c.getLong(ix))
                }
                found[wanted[0]] ?: found[wanted[1]]
            }
        }.getOrNull()
    }
}
