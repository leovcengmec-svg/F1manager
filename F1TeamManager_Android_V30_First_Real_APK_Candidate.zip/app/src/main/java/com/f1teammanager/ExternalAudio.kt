package com.f1teammanager

import android.content.ContentUris
import android.content.Context
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import java.util.Locale

/** Leitor de áudio externo em Pictures/F1Manager/Assets/Audio, com fallback OGG -> MP3. */
class ExternalAudio(private val context: Context) {
    private var player: MediaPlayer? = null
    private var currentId: String? = null

    @Synchronized fun play(id: String, loop: Boolean = true) {
        if (currentId == id && player?.isPlaying == true) return
        stop()
        val uri = findAudio(id) ?: return // ausência de arquivo nunca impede o jogo
        runCatching {
            MediaPlayer().also { mp ->
                mp.setDataSource(context, uri)
                mp.isLooping = loop
                mp.setOnErrorListener { failed, _, _ ->
                    runCatching { failed.release() }
                    synchronized(this) { if (player === failed) { player = null; currentId = null } }
                    true
                }
                mp.setOnPreparedListener { prepared -> runCatching { prepared.start() } }
                mp.prepareAsync()
                player = mp
                currentId = id
            }
        }.onFailure { stop() }
    }

    @Synchronized fun stop() {
        val old = player
        player = null
        currentId = null
        if (old != null) runCatching { if (old.isPlaying) old.stop() }.also { runCatching { old.reset(); old.release() } }
    }

    private fun findAudio(id: String): Uri? {
        val resolver = context.contentResolver
        val base = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.DISPLAY_NAME, MediaStore.Audio.Media.RELATIVE_PATH)
        val wanted = listOf("$id.ogg", "$id.mp3")
        return runCatching {
            resolver.query(base, projection,
                "${MediaStore.Audio.Media.RELATIVE_PATH} LIKE ?",
                arrayOf("%F1Manager/Assets/Audio/%"),
                null
            )?.use { c ->
                val ix = c.getColumnIndex(MediaStore.Audio.Media._ID)
                val nx = c.getColumnIndex(MediaStore.Audio.Media.DISPLAY_NAME)
                val px = c.getColumnIndex(MediaStore.Audio.Media.RELATIVE_PATH)
                if (ix < 0 || nx < 0 || px < 0) return@use null
                val found = mutableMapOf<String, Uri>()
                while (c.moveToNext()) {
                    val path = c.getString(px).orEmpty().replace('\\','/').lowercase(Locale.ROOT)
                    if (!path.contains("f1manager/assets/audio/")) continue
                    val name = c.getString(nx).orEmpty().lowercase(Locale.ROOT)
                    if (name in wanted) found[name] = ContentUris.withAppendedId(base, c.getLong(ix))
                }
                found[wanted[0]] ?: found[wanted[1]]
            }
        }.getOrNull()
    }
}
