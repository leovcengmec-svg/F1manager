package com.f1teammanager

/**
 * Export destination policy for the save-management screen.
 *
 * An explicit file selection is authoritative. Career IDs are deliberately not
 * compared here: multiple snapshots from the same career can represent different
 * teams/seasons, and exporting one of them must never silently substitute the
 * currently loaded career.
 */
internal object SaveExportTargetPolicy {
    fun shouldExportLiveCareer(selectedSavePath: String?): Boolean =
        selectedSavePath.isNullOrBlank()
}
