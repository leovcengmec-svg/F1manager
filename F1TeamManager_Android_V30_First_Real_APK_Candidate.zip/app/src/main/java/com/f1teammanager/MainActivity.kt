package com.f1teammanager

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.core.view.WindowCompat
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.f1teammanager.core.race.*
import com.f1teammanager.core.manager.CarComponent
import com.f1teammanager.core.manager.CarDevelopmentEngine
import com.f1teammanager.core.manager.DevelopmentIntensity
import com.f1teammanager.core.manager.CarDevelopmentFocus
import com.f1teammanager.core.manager.TeamCarState
import com.f1teammanager.core.manager.TeamManagerState
import com.f1teammanager.core.manager.TeamFinanceState
import com.f1teammanager.core.manager.FinanceEngine
import com.f1teammanager.core.manager.ManagerMarketEngine
import com.f1teammanager.core.manager.SponsorContract
import com.f1teammanager.core.manager.DynamicGridEngine
import com.f1teammanager.core.manager.DriverMarketEngine
import com.f1teammanager.core.manager.DriverMarketState
import com.f1teammanager.core.season.CarCatalog
import com.f1teammanager.core.season.RoundDefinition
import com.f1teammanager.core.season.WorldDatabase
import com.f1teammanager.core.season.toParticipant

private val Bg = Color(0xFF08090C)
private val Panel = Color(0xFF14161B)
private val Panel2 = Color(0xFF1B1E24)
private val Red = Color(0xFFE10600)
private val Muted = Color(0xFF8D929C)
private val Line = Color(0xFF2B2F36)
private val Green = Color(0xFF38C878)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, true)
        setContent { F1ManagerApp(CareerPreferences(this)) }
    }
}

private enum class Screen { HOME, TEAM, DRIVERS, CAR, CALENDAR, STANDINGS, FINANCE, MARKET, WEEKEND, QUALIFYING, RACE, RESULT, HISTORY, MANAGEMENT, SELECT_TEAM }
private enum class Nav { HOME, TEAM, CAR, CALENDAR, STANDINGS }

@Composable
private fun F1ManagerApp(store: CareerPreferences) {
    var hasCareer by remember { mutableStateOf(store.hasCareer) }
    var teamId by remember { mutableIntStateOf(store.teamId) }
    var roundIndex by remember { mutableIntStateOf(store.roundIndex) }
    var currentWeek by remember { mutableIntStateOf(store.currentWeek) }
    var screen by remember { mutableStateOf(if (hasCareer) Screen.HOME else Screen.SELECT_TEAM) }
    var nav by remember { mutableStateOf(Nav.HOME) }
    var selectedMode by remember { mutableStateOf(DriverStrategyMode.BALANCED) }
    var selectedTyre by remember { mutableStateOf(Tyre.MEDIUM) }
    var snapshot by remember { mutableStateOf<CareerWeekendEngine.SessionSnapshot?>(null) }
    var result by remember { mutableStateOf<RaceResult?>(null) }
    var marketDriverId by remember { mutableIntStateOf(-1) }
    var marketState by remember { mutableStateOf(DriverMarketEngine(20261003).initialState(store.season)) }
    var marketMessage by remember { mutableStateOf("") }
    var managerState by remember(teamId) { mutableStateOf(store.loadCar(teamId)?.let { val base=TeamManagerState(season=store.season, round=store.roundIndex+1, car=it, finance=TeamFinanceState(75_000_000L), playerTeamId=teamId); run { val sponsors=store.loadSponsors(teamId); base.copy(finance=store.loadFinance(teamId,base.finance), sponsor=sponsors.firstOrNull { it.slot==1 } ?: store.loadSponsor(teamId,base.sponsor), sponsors=sponsors, driverMarket=DriverMarketEngine(20261003).initialState(store.season)) } } ?: initialManagerState(teamId,store)) }
    var historyRound by remember { mutableIntStateOf(-1) }
    var historyResult by remember { mutableStateOf<RaceResult?>(null) }
    var carMessage by remember { mutableStateOf("") }
    var calendarMessage by remember { mutableStateOf("") }
    var sponsorMessage by remember { mutableStateOf("") }
    val marketEngine = remember { DriverMarketEngine(20261003) }
    val engine = remember { CareerWeekendEngine(20261003) }
    val team = WorldDatabase.teams.firstOrNull { it.id == teamId } ?: WorldDatabase.teams.first()
    val drivers = WorldDatabase.drivers.filter { it.teamId == team.id }
    val round = WorldDatabase.rounds.getOrElse(roundIndex) { WorldDatabase.rounds.first() }
    val development = remember { CarDevelopmentEngine() }

    fun participants() = DynamicGridEngine().participants(
        managerState.driverMarket, managerState.car, managerState.playerTeamId, 0, roundIndex + 1, store.season
    )
    fun circuit() = RaceCircuit(round.round, round.circuit, round.laps, round.baseLapTimeMs, round.powerFactor, round.overtakingFactor, round.crashRisk, round.reliabilityRisk, round.safetyCarRisk)
    fun startWeekend() {
        if (snapshot != null && snapshot?.completed == false && snapshot?.phase == "RACE") { screen = Screen.RACE; return }
        if (currentWeek != round.weekOfSeason) {
            calendarMessage = "A próxima corrida é na semana ${round.weekOfSeason}. Use PULAR 1 SEMANA ou PULAR ATÉ A PRÓXIMA CORRIDA."
            screen = Screen.CALENDAR
            return
        }
        snapshot = engine.start(participants(), circuit(), team.id); result = null; screen = Screen.QUALIFYING
    }
    fun advanceFreeWeeks(weeks: Int, targetWeek: Int) {
        val delta = (targetWeek - currentWeek).coerceAtLeast(0)
        if (delta == 0) return
        val raceWeeks = WorldDatabase.rounds.map { it.weekOfSeason }.toSet()
        val freeWeeks = (currentWeek until targetWeek).count { it !in raceWeeks }
        managerState = development.advanceWeeks(managerState, freeWeeks)
        store.saveCar(teamId, managerState.car)
        currentWeek = targetWeek
        store.jumpToWeek(targetWeek)
        calendarMessage = if (freeWeeks > 0) "${freeWeeks} semana(s) livre(s) processada(s). P&D avançou junto com o calendário." else "Sem semanas livres entre estes GPs."
    }
    fun skipOneWeek() {
        if (currentWeek >= 56) return
        if (currentWeek == round.weekOfSeason) {
            calendarMessage = "Esta é a semana do GP. Não é possível pular a corrida."
            return
        }
        advanceFreeWeeks(1, currentWeek + 1)
    }
    fun jumpToNextRace() {
        if (currentWeek == round.weekOfSeason) {
            calendarMessage = "Você está na semana do GP. Primeiro simule e conclua esta corrida; só depois poderá avançar para o próximo GP."
            screen = Screen.CALENDAR
            return
        }
        val target = if (currentWeek < round.weekOfSeason) {
            round.weekOfSeason
        } else {
            WorldDatabase.rounds.getOrNull(roundIndex + 1)?.weekOfSeason
        }
        if (target == null) { calendarMessage = "Você já está na última corrida da temporada."; return }
        advanceFreeWeeks((target-currentWeek).coerceAtLeast(0), target)
    }
    fun simulateQualifying() { snapshot = engine.simulateQualifyingPhase() }
    fun startRace() {
        if (!engine.qualifyingComplete()) { snapshot = engine.simulateQualifyingPhase(); return }
        snapshot = engine.snapshotForUi()
        screen = Screen.RACE
    }
    fun advanceRace() {
        snapshot = engine.advance()
        if (snapshot?.completed == true) {
            result = engine.result()
            val teamName = team.name
            val mine = result!!.classification.filter { it.teamName == teamName }
            val teamPoints = mine.sumOf { result!!.points[it.driverId] ?: 0 }
            val best = mine.minOfOrNull { if (it.status.startsWith("DNF")) 999 else it.position } ?: 999
            managerState = FinanceEngine().applyRace(managerState,best,teamPoints,mine.all { it.status.startsWith("DNF") })
            store.recordRace(round.round, result!!)
            store.saveCar(teamId, managerState.car); store.saveFinance(teamId, managerState.finance); store.saveSponsors(teamId, managerState.sponsors)
            screen = Screen.RESULT
        }
    }
    fun nextRound() {
        store.saveCar(teamId, managerState.car); store.saveFinance(teamId, managerState.finance); store.saveSponsors(teamId, managerState.sponsors)
        val nextIndex = (roundIndex + 1).coerceAtMost(WorldDatabase.rounds.lastIndex)
        if (roundIndex < WorldDatabase.rounds.lastIndex) {
            val targetWeek = WorldDatabase.rounds[nextIndex].weekOfSeason
            advanceFreeWeeks(targetWeek - currentWeek, targetWeek)
            store.advanceRound()
        } else {
            store.advanceRound()
            managerState = development.startNextSeason(managerState, store.season)
            currentWeek = store.currentWeek
            store.saveCar(teamId, managerState.car)
            store.saveFinance(teamId, managerState.finance)
            carMessage = "Novo carro ${store.season} criado. O investimento da temporada anterior foi aplicado."
        }
        roundIndex = store.roundIndex
        snapshot = null; result = null; screen = Screen.HOME; nav = Nav.HOME
    }
    fun startDevelopment(component: CarComponent, intensity: DevelopmentIntensity) {
        runCatching { managerState = development.start(managerState, component, intensity); store.saveCar(teamId, managerState.car); store.saveFinance(teamId, managerState.finance); carMessage = "${componentLabel(component)} iniciado: ${managerState.car.activeProject?.totalWeeks} semana(s) • +${managerState.car.activeProject?.expectedGain}." }
            .onFailure { carMessage = it.message ?: "Não foi possível iniciar o projeto." }
    }
    fun investNextSeason(amount: Long) {
        runCatching { managerState = development.investNextSeason(managerState, amount); store.saveCar(teamId, managerState.car); store.saveFinance(teamId, managerState.finance); carMessage = "€ ${amount/1_000_000}M investidos no carro ${store.season + 1}." }
            .onFailure { carMessage = it.message ?: "Não foi possível investir no próximo carro." }
    }
    fun setNextSeasonFocus(focus: CarDevelopmentFocus) {
        managerState = development.setNextSeasonFocus(managerState, focus)
        store.saveCar(teamId, managerState.car)
    }
    fun openHistory(r:Int) { historyRound=r; historyResult=store.raceHistory(r); screen=Screen.HISTORY }
    fun makeMarketInterest(driverId: Int) {
        val driver = WorldDatabase.allDrivers.first { it.id == driverId }
        val from = driver.teamId
        val years = if (from == 0) 2 else 1
        val salary = marketEngine.salaryFor(driverId)
        runCatching {
            val (next, offer) = marketEngine.offer(marketState, driverId, from, team.id, years, salary, season = store.season)
            marketState = next
            marketMessage = if (offer.accepted) "Negociação aceita: ${driver.name}. Pré-contrato registrado." else "Interesse registrado por ${driver.name}; negociação ainda não aceita."
        }.onFailure { marketMessage = it.message ?: "Não foi possível negociar agora." }
    }
    fun signSponsor(sponsor:SponsorContract) {
        runCatching { managerState=ManagerMarketEngine().signSponsor(managerState,sponsor,sponsor.slot); store.saveFinance(teamId,managerState.finance); store.saveSponsors(teamId,managerState.sponsors); sponsorMessage="Contrato ${sponsor.name} aceito por ${sponsor.races} ${if(sponsor.races==1) "corrida" else "corridas"}." }
            .onFailure { sponsorMessage=it.message ?: "Não foi possível aceitar o contrato." }
    }

    fun selectTeam(id: Int) { store.startNewCareer(id); marketState = marketEngine.initialState(2026); marketMessage = ""; calendarMessage = ""; managerState=initialManagerState(id,store); teamId = id; roundIndex = 0; currentWeek = store.currentWeek; hasCareer = true; screen = Screen.HOME; nav = Nav.HOME }

    MaterialTheme(colorScheme = darkColorScheme(background = Bg, surface = Panel, primary = Red, onPrimary = Color.White, onSurface = Color.White)) {
        Surface(Modifier.fillMaxSize(), color = Bg) {
            when (screen) {
                Screen.SELECT_TEAM -> TeamSelect(::selectTeam)
                Screen.HOME -> AppScaffold("${team.name.uppercase()} • ${store.season}", nav, { nav = it; screen = when(it){Nav.HOME->Screen.HOME;Nav.TEAM->Screen.TEAM;Nav.CAR->Screen.CAR;Nav.CALENDAR->Screen.CALENDAR;Nav.STANDINGS->Screen.STANDINGS} }, onMore={ screen=Screen.MANAGEMENT }) { Home(team.name, CarCatalog.forTeam(team.id), drivers, round, currentWeek, store, managerState, snapshot?.phase == "RACE" && snapshot?.completed == false, onStart=::startWeekend, onDrivers={screen=Screen.DRIVERS}, onWeekend={screen=Screen.WEEKEND}, onMarket={screen=Screen.MARKET}, onFinance={screen=Screen.FINANCE}, onStandings={screen=Screen.STANDINGS}, onCar={nav=Nav.CAR;screen=Screen.CAR}, onSkipWeek=::skipOneWeek, onJumpNextRace=::jumpToNextRace) }
                Screen.TEAM -> AppScaffold("EQUIPE", nav, { nav=it; screen=when(it){Nav.HOME->Screen.HOME;Nav.TEAM->Screen.TEAM;Nav.CAR->Screen.CAR;Nav.CALENDAR->Screen.CALENDAR;Nav.STANDINGS->Screen.STANDINGS} }, onMore={screen=Screen.MANAGEMENT}) { Team(team.name, team.engine, team.reliability, drivers, onDrivers={screen=Screen.DRIVERS}, onMarket={screen=Screen.MARKET}) }
                Screen.DRIVERS -> DetailScaffold("PILOTOS", {screen=Screen.TEAM}) { Drivers(drivers) }
                Screen.CAR -> AppScaffold("CARRO / P&D", nav, { nav=it; screen=when(it){Nav.HOME->Screen.HOME;Nav.TEAM->Screen.TEAM;Nav.CAR->Screen.CAR;Nav.CALENDAR->Screen.CALENDAR;Nav.STANDINGS->Screen.STANDINGS} }, onMore={screen=Screen.MANAGEMENT}) { Car(CarCatalog.forTeam(team.id), managerState, carMessage, ::startDevelopment, ::investNextSeason, ::setNextSeasonFocus) }
                Screen.CALENDAR -> AppScaffold("CALENDÁRIO", nav, { nav=it; screen=when(it){Nav.HOME->Screen.HOME;Nav.TEAM->Screen.TEAM;Nav.CAR->Screen.CAR;Nav.CALENDAR->Screen.CALENDAR;Nav.STANDINGS->Screen.STANDINGS} }, onMore={screen=Screen.MANAGEMENT}) { Calendar(roundIndex, store.roundIndex, currentWeek, calendarMessage, ::openHistory, ::skipOneWeek, ::jumpToNextRace) }
                Screen.STANDINGS -> AppScaffold("CAMPEONATO", nav, { nav=it; screen=when(it){Nav.HOME->Screen.HOME;Nav.TEAM->Screen.TEAM;Nav.CAR->Screen.CAR;Nav.CALENDAR->Screen.CALENDAR;Nav.STANDINGS->Screen.STANDINGS} }, onMore={screen=Screen.MANAGEMENT}) { Standings(team.id, store) }
                Screen.FINANCE -> DetailScaffold("FINANÇAS", {screen=Screen.HOME}) { Finance(store, team.id, managerState, sponsorMessage, ::signSponsor) }
                Screen.MARKET -> DetailScaffold("MERCADO DE PILOTOS", {screen=Screen.TEAM}) { DriverMarket(store, team.id, marketDriverId, marketState, marketMessage, { marketDriverId = it }, ::makeMarketInterest) }
                Screen.WEEKEND -> DetailScaffold("FIM DE SEMANA", {screen=Screen.HOME}) { Weekend(round, currentWeek, ::startWeekend) }
                Screen.QUALIFYING -> DetailScaffold("QUALIFICAÇÃO", { screen = Screen.HOME }) {
                    Qualifying(
                        snapshot!!,
                        onMode = { id, mode -> snapshot = engine.setStrategy(id, mode) },
                        onPlan = { id, plan -> snapshot = engine.setTyrePlan(id, plan) },
                        simulate = ::simulateQualifying,
                        start = ::startRace
                    )
                }
                Screen.RACE -> DetailScaffold("PIT WALL", { screen = Screen.CALENDAR; nav = Nav.CALENDAR }) { Race(snapshot!!, drivers, ::advanceRace, { id, mode -> snapshot = engine.setStrategy(id, mode) }, { id, tyre -> snapshot = engine.pitNow(id, tyre) }, { id, plan -> snapshot = engine.pitWithPlan(id, plan) }, { action -> snapshot = engine.choose(action) }) }
                Screen.RESULT -> DetailScaffold("RESULTADO", { screen = Screen.CALENDAR; nav = Nav.CALENDAR }) { Result(result!!, team.id, store) { screen = Screen.CALENDAR; nav = Nav.CALENDAR } }
                Screen.HISTORY -> DetailScaffold("CLASSIFICAÇÃO ARQUIVADA", { screen = Screen.CALENDAR }) { HistoryResult(historyRound, historyResult) }
                Screen.MANAGEMENT -> DetailScaffold("GESTÃO", { screen = Screen.HOME }) { ManagementHub(snapshot?.phase == "RACE" && snapshot?.completed == false, onDrivers={screen=Screen.DRIVERS}, onMarket={screen=Screen.MARKET}, onFinance={screen=Screen.FINANCE}, onCar={screen=Screen.CAR}, onStandings={screen=Screen.STANDINGS}, onCalendar={screen=Screen.CALENDAR}, onWeekend={screen=Screen.WEEKEND}, onRace={screen=Screen.RACE}) }
            }
        }
    }
}

@Composable private fun AppScaffold(title:String, nav:Nav, select:(Nav)->Unit, onMore:()->Unit, content:@Composable ColumnScope.()->Unit) {
    Column(Modifier.fillMaxSize().statusBarsPadding()) { TopBar(title, onMore); Column(Modifier.weight(1f)) { content() }; BottomNav(nav, select) }
}
@Composable private fun DetailScaffold(title:String, back:()->Unit, content:@Composable ColumnScope.()->Unit) { Column(Modifier.fillMaxSize().statusBarsPadding()) { BackTopBar(title, back); Column(Modifier.weight(1f)) { content() } } }
@Composable private fun BackTopBar(title:String, back:()->Unit) { Row(Modifier.fillMaxWidth().padding(horizontal=14.dp,vertical=10.dp),verticalAlignment=Alignment.CenterVertically){Text("‹",color=Color.White,fontSize=34.sp,modifier=Modifier.clickable{back()}.padding(horizontal=6.dp));Text(title,color=Color.White,fontWeight=FontWeight.Bold,maxLines=1,overflow=TextOverflow.Ellipsis,modifier=Modifier.weight(1f));Text("F1 MANAGER",color=Red,fontWeight=FontWeight.Black,fontSize=12.sp)}}
@Composable private fun TopBar(title:String, action:()->Unit) { Row(Modifier.fillMaxWidth().padding(horizontal=16.dp,vertical=12.dp), verticalAlignment=Alignment.CenterVertically, horizontalArrangement=Arrangement.SpaceBetween) { Text("F1 MANAGER",color=Red,fontWeight=FontWeight.Black,letterSpacing=1.sp); Text(title,color=Color.White,fontWeight=FontWeight.Bold,maxLines=1,overflow=TextOverflow.Ellipsis); Text("⋮",color=Color.White,fontSize=25.sp,modifier=Modifier.clickable{action()}) } }
@Composable private fun BottomNav(selected:Nav, select:(Nav)->Unit) { Row(Modifier.fillMaxWidth().navigationBarsPadding().background(Color(0xFF101216)).padding(6.dp), horizontalArrangement=Arrangement.SpaceEvenly) { listOf(Nav.HOME to "⌂",Nav.TEAM to "♟",Nav.CAR to "▰",Nav.CALENDAR to "▦",Nav.STANDINGS to "≡").forEach{(n,l)-> Column(horizontalAlignment=Alignment.CenterHorizontally,modifier=Modifier.weight(1f).clickable{select(n)}.padding(5.dp)){Text(l,color=if(selected==n)Red else Muted,fontSize=20.sp);Text(n.name,color=if(selected==n)Color.White else Muted,fontSize=9.sp,fontWeight=FontWeight.Bold)}} } }

@Composable
private fun Home(
    team:String, car:com.f1teammanager.core.season.CarSpec, drivers:List<com.f1teammanager.core.season.DriverDefinition>,
    round:RoundDefinition, currentWeek:Int, store:CareerPreferences, managerState:TeamManagerState, raceInProgress:Boolean,
    onStart:()->Unit, onDrivers:()->Unit, onWeekend:()->Unit, onMarket:()->Unit, onFinance:()->Unit,
    onStandings:()->Unit, onCar:()->Unit, onSkipWeek:()->Unit, onJumpNextRace:()->Unit
){
    val teamId=WorldDatabase.teams.first{it.name==team}.id
    val teamPoints=store.constructorPoints()[teamId]?:0
    val atRaceWeek=currentWeek==round.weekOfSeason
    LazyColumn(contentPadding=PaddingValues(horizontal=16.dp,vertical=12.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
        item{TeamHeroCard(team,car.model)}
        item{SectionTitle("SITUAÇÃO DO CAMPEONATO");Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(Panel)){Row(Modifier.fillMaxWidth().padding(8.dp),horizontalArrangement=Arrangement.spacedBy(7.dp)){StatCard("CONSTRUTORES","P${constructorPosition(teamId,store)}","$teamPoints PTS",Modifier.weight(1f));StatCard("PILOTO 1",drivers.firstOrNull()?.name?:"—","titular",Modifier.weight(1f));StatCard("ORÇAMENTO",formatMoney(managerState.finance.budget),"disponível",Modifier.weight(1f))}}}
        item{SectionTitle("PRÓXIMA CORRIDA");Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(Panel)){Column(Modifier.padding(13.dp)){Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("ROUND ${round.round}",color=Red,fontWeight=FontWeight.Black);Text("SEMANA ${round.weekOfSeason}",color=Color.White,fontWeight=FontWeight.Black,fontSize=11.sp)};Text(round.grandPrix,color=Color.White,fontSize=21.sp,fontWeight=FontWeight.Black,modifier=Modifier.padding(top=4.dp));Text(round.circuit,color=Muted,fontSize=12.sp);Row(Modifier.fillMaxWidth().padding(top=9.dp),horizontalArrangement=Arrangement.SpaceBetween){Text("${round.laps} VOLTAS",color=Color.White,fontSize=10.sp,fontWeight=FontWeight.Bold);Text(round.dateLabel,color=Muted,fontSize=10.sp)};Button(onClick=onStart,enabled=raceInProgress||atRaceWeek,modifier=Modifier.fillMaxWidth().padding(top=9.dp),colors=ButtonDefaults.buttonColors(containerColor=Red,contentColor=Color.White,disabledContainerColor=Panel2,disabledContentColor=Muted)){Text(if(raceInProgress)"RETOMAR PIT WALL" else if(atRaceWeek)"ABRIR FIM DE SEMANA" else "IR PARA CALENDÁRIO",fontWeight=FontWeight.Black)}}}}
        item{Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(Panel)){Column(Modifier.padding(12.dp)){Text("CALENDÁRIO",color=Red,fontWeight=FontWeight.Black,fontSize=11.sp);Text("As semanas livres são usadas para P&D. Nunca é possível ultrapassar um GP sem simular a corrida.",color=Muted,fontSize=9.sp,modifier=Modifier.padding(top=3.dp));Row(Modifier.fillMaxWidth().padding(top=8.dp),horizontalArrangement=Arrangement.spacedBy(7.dp)){Button(onClick=onSkipWeek,enabled=currentWeek<56&&!atRaceWeek,modifier=Modifier.weight(1f),colors=ButtonDefaults.buttonColors(containerColor=Panel2,contentColor=Color.White,disabledContainerColor=Color(0xFF101116),disabledContentColor=Muted),contentPadding=PaddingValues(vertical=8.dp)){Text("PULAR 1 SEMANA",fontSize=8.sp,fontWeight=FontWeight.Black)};Button(onClick=onJumpNextRace,enabled=currentWeek<round.weekOfSeason,modifier=Modifier.weight(1f),colors=ButtonDefaults.buttonColors(containerColor=Red,contentColor=Color.White,disabledContainerColor=Color(0xFF3A0D0D),disabledContentColor=Muted),contentPadding=PaddingValues(vertical=8.dp)){Text("PULAR ATÉ PRÓXIMO GP",fontSize=8.sp,fontWeight=FontWeight.Black)}}}}}
        item{SectionTitle("ACESSO RÁPIDO");val shortcuts=listOf("FIM DE SEMANA" to onWeekend,"PILOTOS" to onDrivers,"MERCADO" to onMarket,"FINANÇAS" to onFinance,"CAMPEONATO" to onStandings,"CARRO / P&D" to onCar);Column(verticalArrangement=Arrangement.spacedBy(7.dp),modifier=Modifier.padding(top=3.dp)){shortcuts.chunked(3).forEach{row->Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(7.dp)){row.forEach{(label,action)->Button(onClick=action,modifier=Modifier.weight(1f).height(48.dp),colors=ButtonDefaults.buttonColors(containerColor=Panel2,contentColor=Color.White),shape=RoundedCornerShape(8.dp),contentPadding=PaddingValues(horizontal=4.dp)){Text(label,fontSize=8.sp,fontWeight=FontWeight.Bold,maxLines=1)}}}}}}
        item{SectionTitle("EQUIPE");Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(Panel)){Column(Modifier.padding(12.dp)){Text("PILOTOS TITULARES",color=Red,fontWeight=FontWeight.Bold,fontSize=11.sp);Row(Modifier.fillMaxWidth().padding(top=7.dp),horizontalArrangement=Arrangement.spacedBy(7.dp)){drivers.take(2).forEachIndexed{index,d->Column(Modifier.weight(1f).background(Panel2,RoundedCornerShape(8.dp)).padding(10.dp)){Text(d.name,color=Color.White,fontWeight=FontWeight.Bold,fontSize=12.sp,maxLines=1,overflow=TextOverflow.Ellipsis);Text("#${index+1} • Titular",color=Muted,fontSize=9.sp);Text("P${driverChampionshipPosition(d.id,store)}",color=Color.White,fontWeight=FontWeight.Black,fontSize=15.sp,modifier=Modifier.padding(top=4.dp))}}};Button(onClick=onDrivers,modifier=Modifier.fillMaxWidth().padding(top=7.dp),colors=ButtonDefaults.buttonColors(containerColor=Panel2,contentColor=Color.White)){Text("VER PERFIL COMPLETO →",fontWeight=FontWeight.Black,fontSize=9.sp)}}}}
    }
}

@Composable private fun TeamHeroCard(team:String,model:String){Box(Modifier.fillMaxWidth().height(138.dp).clip(RoundedCornerShape(12.dp)).background(Panel).border(1.dp,Red,RoundedCornerShape(12.dp))){Row(Modifier.fillMaxSize().padding(16.dp),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(team.uppercase(),color=Color.White,fontSize=23.sp,fontWeight=FontWeight.Black);Text(model,color=Red,fontSize=17.sp,fontWeight=FontWeight.Black);Text("MODELO ESPECÍFICO DA EQUIPE",color=Muted,fontSize=10.sp,modifier=Modifier.padding(top=4.dp))};Text("R26",color=Red.copy(alpha=.18f),fontSize=48.sp,fontWeight=FontWeight.Black)}}}

@Composable private fun Team(name:String,engine:Int,reliability:Int,drivers:List<com.f1teammanager.core.season.DriverDefinition>,onDrivers:()->Unit,onMarket:()->Unit){LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){item{HeaderBlock(name,"GESTÃO DA EQUIPE")};item{MetricPanel("FORNECEDOR / MOTOR","Engine",engine,"Confiabilidade",reliability)};item{SectionTitle("PILOTOS TITULARES")};items(drivers){DriverMini(it)};item{Button(onClick=onDrivers,modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=Red,contentColor=Color.White)){Text("ABRIR PERFIS")}};item{SectionTitle("GESTÃO")};item{Row(Modifier.fillMaxWidth().background(Panel,RoundedCornerShape(8.dp)).clickable{onMarket()}.padding(14.dp),horizontalArrangement=Arrangement.SpaceBetween){Column{Text("MERCADO DE PILOTOS",color=Color.White,fontWeight=FontWeight.Bold);Text("Contratos, salários e disponibilidade",color=Muted,fontSize=11.sp)};Text("›",color=Red,fontSize=24.sp)}};item{SectionTitle("INSTALAÇÕES")};item{Facility("FÁBRICA",72)};item{Facility("CENTRO DE P&D",68)};item{Facility("TÚNEL DE VENTO",61)};item{Facility("SIMULADOR",75)}}}
@Composable private fun Drivers(ds:List<com.f1teammanager.core.season.DriverDefinition>){LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){item{HeaderBlock("PILOTOS","PERFIS E ATRIBUTOS")};items(ds){d->Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(Panel)){Column(Modifier.padding(14.dp)){Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text(d.name,color=Color.White,fontWeight=FontWeight.Black,fontSize=18.sp);Text("${d.speed}",color=Red,fontSize=20.sp,fontWeight=FontWeight.Black)};Text("Velocidade  ${d.speed} • Classificação  ${d.qualifying}",color=Muted);Text("Ultrapassagem ${d.overtaking} • Defesa ${d.defense} • Consistência ${d.consistency}",color=Muted);Text("Chuva ${d.wet} • Pneus ${d.tyre}",color=Muted)}}}}}
@Composable private fun DriverMini(d:com.f1teammanager.core.season.DriverDefinition){Row(Modifier.fillMaxWidth().background(Panel,RoundedCornerShape(8.dp)).padding(13.dp),horizontalArrangement=Arrangement.SpaceBetween){Text(d.name,color=Color.White,fontWeight=FontWeight.Bold);Text("CHUVA ${d.wet}",color=Red,fontWeight=FontWeight.Black,fontSize=10.sp)}}
@Composable private fun Facility(name:String,v:Int){Column(Modifier.fillMaxWidth().background(Panel,RoundedCornerShape(8.dp)).padding(12.dp)){Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text(name,color=Color.White,fontWeight=FontWeight.Bold);Text("Nível ${v/10}",color=Muted)};LinearProgressIndicator(progress={v/100f},modifier=Modifier.fillMaxWidth().padding(top=8.dp),color=Red,trackColor=Line)}}
@Composable private fun MetricPanel(title:String,a:String,av:Int,b:String,bv:Int){Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(Panel)){Column(Modifier.padding(14.dp)){Text(title,color=Red,fontWeight=FontWeight.Bold);MetricLine(a,av);MetricLine(b,bv)}}}
@Composable private fun MetricLine(l:String,v:Int){Column(Modifier.padding(top=9.dp)){Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text(l,color=Muted);Text(v.toString(),color=Color.White,fontWeight=FontWeight.Bold)};LinearProgressIndicator(progress={v/100f},modifier=Modifier.fillMaxWidth().padding(top=4.dp),color=Red,trackColor=Line)}}
@Composable private fun Car(
    c:com.f1teammanager.core.season.CarSpec,
    state:TeamManagerState,
    message:String,
    develop:(CarComponent,DevelopmentIntensity)->Unit,
    investNextSeason:(Long)->Unit,
    setNextSeasonFocus:(CarDevelopmentFocus)->Unit
){
    val car=state.car; val p=car.activeProject
    var selectedComponent by remember { mutableStateOf<CarComponent?>(null) }
    val development=remember { CarDevelopmentEngine() }
    val cap=development.nextSeasonInvestmentCap(car)
    val remaining=cap-car.nextSeasonInvestment
    LazyColumn(contentPadding=PaddingValues(12.dp),verticalArrangement=Arrangement.spacedBy(7.dp)){
        item{HeaderBlock(c.model,"CARRO ${state.season} • 6 COMPONENTES")}
        item{Text("ORÇAMENTO ${formatMoney(state.finance.budget)}",color=Green,fontWeight=FontWeight.Black);Text("FORÇA DO CARRO ${((car.engine+car.chassis+car.frontWing+car.rearWing+car.brakes+car.electricPowerUnit)/6)}",color=Red,fontWeight=FontWeight.Black);Text("EVOLUÇÃO ${car.seasonDevelopmentGain}/140 PONTOS NESTA TEMPORADA",color=Muted,fontSize=9.sp,fontWeight=FontWeight.Bold)}
        item{Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(Panel)){Column(Modifier.padding(12.dp)){Text("CARRO ${state.season}",color=Red,fontWeight=FontWeight.Black,fontSize=12.sp);Text("Desenvolva o carro atual sem perder o foco no próximo.",color=Muted,fontSize=9.sp,modifier=Modifier.padding(top=2.dp))}}}
        item{CarComponentRow("UNIDADE DE POTÊNCIA",car.engine,CarComponent.ENGINE,p,development.options(state,CarComponent.ENGINE),{selectedComponent=CarComponent.ENGINE})}
        item{CarComponentRow("CHASSI",car.chassis,CarComponent.CHASSIS,p,development.options(state,CarComponent.CHASSIS),{selectedComponent=CarComponent.CHASSIS})}
        item{CarComponentRow("ASA DIANTEIRA",car.frontWing,CarComponent.FRONT_WING,p,development.options(state,CarComponent.FRONT_WING),{selectedComponent=CarComponent.FRONT_WING})}
        item{CarComponentRow("ASA TRASEIRA",car.rearWing,CarComponent.REAR_WING,p,development.options(state,CarComponent.REAR_WING),{selectedComponent=CarComponent.REAR_WING})}
        item{CarComponentRow("FREIOS",car.brakes,CarComponent.BRAKES,p,development.options(state,CarComponent.BRAKES),{selectedComponent=CarComponent.BRAKES})}
        item{CarComponentRow("UNIDADE DE POTÊNCIA ELÉTRICA",car.electricPowerUnit,CarComponent.ELECTRIC_POWER_UNIT,p,development.options(state,CarComponent.ELECTRIC_POWER_UNIT),{selectedComponent=CarComponent.ELECTRIC_POWER_UNIT})}
        item{Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(Panel)){Column(Modifier.padding(12.dp)){Text("CARRO ${state.season+1} • INVESTIMENTO ANTECIPADO",color=Red,fontWeight=FontWeight.Black,fontSize=12.sp);Text("Investido: ${formatMoney(car.nextSeasonInvestment)} / ${formatMoney(cap)}",color=Color.White,fontWeight=FontWeight.Bold);Text("O valor investido agora vira vantagem de partida no próximo carro. O limite impede que uma equipe compre uma vantagem infinita.",color=Muted,fontSize=9.sp,modifier=Modifier.padding(top=3.dp));Row(Modifier.fillMaxWidth().padding(top=8.dp),horizontalArrangement=Arrangement.spacedBy(5.dp)){listOf(5L,10L,20L).forEach{m->val amount=m*1_000_000L;Button(onClick={investNextSeason(amount)},enabled=remaining>=amount&&state.finance.budget>=amount,modifier=Modifier.weight(1f),colors=ButtonDefaults.buttonColors(containerColor=Panel2,contentColor=Color.White)){Text("+€${m}M",fontSize=8.sp,fontWeight=FontWeight.Black)}}};Text("FOCO DO CARRO ${state.season+1}",color=Muted,fontSize=8.sp,fontWeight=FontWeight.Black,modifier=Modifier.padding(top=8.dp));Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(4.dp)){listOf(CarDevelopmentFocus.BALANCED to "EQUILÍBRIO",CarDevelopmentFocus.POWER to "POTÊNCIA",CarDevelopmentFocus.AERODYNAMICS to "AERO",CarDevelopmentFocus.CORNERING to "CURVAS").forEach{(focus,label)->Button(onClick={setNextSeasonFocus(focus)},modifier=Modifier.weight(1f),colors=ButtonDefaults.buttonColors(containerColor=if(car.nextSeasonFocus==focus) Red else Panel2,contentColor=Color.White),contentPadding=PaddingValues(horizontal=3.dp,vertical=5.dp)){Text(label,fontSize=7.sp,fontWeight=FontWeight.Black)}}}}}}
        p?.let{item{Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(Panel)){Column(Modifier.padding(10.dp)){Text("P&D EM ANDAMENTO",color=Red,fontWeight=FontWeight.Black,fontSize=10.sp);Text(componentLabel(it.component),color=Color.White,fontWeight=FontWeight.Bold);Text("${it.remainingWeeks}/${it.totalWeeks} semana(s) restantes • ganho +${it.expectedGain}",color=Muted,fontSize=10.sp)}}}}
        if(message.isNotBlank()) item{Text(message,color=Color.White,fontSize=10.sp)}
        item{Text("As melhorias entram no motor da corrida e usam semanas do calendário. O investimento do próximo carro é reservado agora e aplicado na virada da temporada.",color=Muted,fontSize=9.sp)}
    }
    selectedComponent?.let { component ->
        val options=development.options(state,component)
        AlertDialog(onDismissRequest={selectedComponent=null},title={Text("DESENVOLVER ${componentLabel(component).uppercase()}")},text={Column(verticalArrangement=Arrangement.spacedBy(6.dp)){Text("Escolha quanto acelerar o projeto. Quanto maior o investimento, maior o ganho e o tempo.",color=Muted,fontSize=11.sp);options.forEach{option->Button(onClick={develop(component,option.intensity);selectedComponent=null},enabled=state.finance.budget>=option.cost&&state.car.activeProject==null,modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=if(option.intensity==DevelopmentIntensity.STANDARD) Red else Panel2,contentColor=Color.White)){Column(Modifier.fillMaxWidth()){Text("${optionLabel(option.intensity)} • ${option.weeks} semana(s)",fontWeight=FontWeight.Black,fontSize=11.sp);Text("${formatMoney(option.cost)} • ganho aleatório +${option.minGain} a +${option.maxGain} (maior chance no máximo)",fontSize=9.sp)}}}}},confirmButton={TextButton(onClick={selectedComponent=null}){Text("CANCELAR")}})
    }
}

@Composable private fun CarComponentRow(title:String,level:Int,component:CarComponent,project:com.f1teammanager.core.manager.DevelopmentProject?,options:List<CarDevelopmentEngine.DevelopmentOption>,open:()->Unit){
    val default=options.firstOrNull { it.intensity==DevelopmentIntensity.STANDARD }
    Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(Panel)){Row(Modifier.fillMaxWidth().padding(9.dp),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(title,color=Color.White,fontWeight=FontWeight.Bold,fontSize=11.sp);Text("NÍVEL $level • ${default?.weeks ?: 2} semanas padrão • ${default?.cost?.let(::formatMoney) ?: formatMoney(0)} • +${default?.minGain ?: 0} a +${default?.maxGain ?: 0}",color=Muted,fontSize=9.sp)};Button(onClick=open,enabled=project==null,colors=ButtonDefaults.buttonColors(containerColor=Red,contentColor=Color.White,disabledContainerColor=Panel2),contentPadding=PaddingValues(horizontal=9.dp,vertical=3.dp)){Text(if(project==null)"DESENVOLVER" else "P&D OCUPADO",fontSize=8.sp)}}}
}

private fun optionLabel(i:DevelopmentIntensity)=when(i){DevelopmentIntensity.QUICK->"RÁPIDO";DevelopmentIntensity.STANDARD->"PADRÃO";DevelopmentIntensity.ADVANCED->"AVANÇADO";DevelopmentIntensity.AGGRESSIVE->"AGRESSIVO"}
@Composable
private fun Calendar(
    idx:Int,
    current:Int,
    currentWeek:Int,
    message:String,
    openHistory:(Int)->Unit,
    skipOneWeek:()->Unit,
    jumpToNextRace:()->Unit
){
    val raceByWeek=WorldDatabase.rounds.associateBy { it.weekOfSeason }
    LazyColumn(contentPadding=PaddingValues(12.dp),verticalArrangement=Arrangement.spacedBy(5.dp)){
        item{
            HeaderBlock("CALENDÁRIO 2026","30 GRAND PRIX • 56 SEMANAS • 26 SEMANAS LIVRES")
            Spacer(Modifier.height(6.dp))
            Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(Panel)){
                Column(Modifier.padding(12.dp)){
                    Text("SEMANA ATUAL: $currentWeek/56",color=Red,fontWeight=FontWeight.Black,fontSize=16.sp)
                    val next=WorldDatabase.rounds.getOrNull(idx) ?: WorldDatabase.rounds.lastOrNull()
                    Text(if(next!=null) "Próximo GP: Round ${next.round} • Semana ${next.weekOfSeason} • ${next.grandPrix}" else "Temporada encerrada",color=Color.White,fontWeight=FontWeight.Bold,fontSize=10.sp)
                    Text("As semanas sem GP são semanas livres de desenvolvimento do carro.",color=Muted,fontSize=9.sp,modifier=Modifier.padding(top=3.dp))
                    Row(Modifier.fillMaxWidth().padding(top=8.dp),horizontalArrangement=Arrangement.spacedBy(6.dp)){
                        Button(onClick=skipOneWeek,modifier=Modifier.weight(1f),enabled=currentWeek<56,colors=ButtonDefaults.buttonColors(containerColor=Panel2,contentColor=Color.White)){Text("PULAR 1 SEMANA",fontSize=9.sp,fontWeight=FontWeight.Black)}
                        Button(onClick=jumpToNextRace,modifier=Modifier.weight(1f),colors=ButtonDefaults.buttonColors(containerColor=Red,contentColor=Color.White)){Text("PULAR ATÉ PRÓXIMO GP",fontSize=9.sp,fontWeight=FontWeight.Black)}
                    }
                    if(message.isNotBlank()) Text(message,color=Color.White,fontSize=9.sp,modifier=Modifier.padding(top=7.dp))
                }
            }
        }
        items((1..56).toList()){week->
            val r=raceByWeek[week]
            val isCurrent=week==currentWeek
            Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(if(isCurrent) Color(0xFF2A1010) else Panel)){
                Row(Modifier.fillMaxWidth().padding(9.dp),verticalAlignment=Alignment.CenterVertically){
                    Column(Modifier.weight(1f)){
                        Text("SEMANA $week/56${if(isCurrent) " • AGORA" else ""}",color=if(isCurrent) Red else Muted,fontSize=9.sp,fontWeight=FontWeight.Black)
                        if(r!=null){
                            Text("ROUND ${r.round} • ${r.dateLabel} • ${r.month.uppercase()}",color=if(isCurrent) Color.White else Muted,fontSize=8.sp,fontWeight=FontWeight.Bold)
                            Text(r.grandPrix,color=Color.White,fontWeight=FontWeight.Bold,fontSize=12.sp)
                            Text(r.circuit,color=Muted,fontSize=10.sp)
                        } else {
                            Text("SEMANA LIVRE • P&D / DESENVOLVIMENTO",color=Color.White,fontWeight=FontWeight.Bold,fontSize=10.sp)
                            Text("Use esta semana para avançar projetos do carro.",color=Muted,fontSize=9.sp)
                        }
                    }
                    Column(horizontalAlignment=Alignment.End){
                        if(r!=null) Text("${r.laps}v",color=Color.White,fontWeight=FontWeight.Bold,fontSize=10.sp)
                        if(r!=null && r.round<=current+1){Text("VER RESULTADO",color=Red,fontSize=8.sp,modifier=Modifier.clickable{openHistory(r.round)})}
                    }
                }
            }
        }
    }
}

@Composable private fun RaceHero(r:RoundDefinition,start:()->Unit,currentWeek:Int){
    Card(Modifier.fillMaxWidth(), colors=CardDefaults.cardColors(Panel)){
        Column(Modifier.padding(14.dp)){
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){
                Text("ROUND ${r.round}",color=Red,fontWeight=FontWeight.Black,fontSize=11.sp)
                Text("SEMANA ${r.weekOfSeason}",color=Muted,fontWeight=FontWeight.Bold,fontSize=10.sp)
            }
            Text(r.grandPrix,color=Color.White,fontSize=21.sp,fontWeight=FontWeight.Black,modifier=Modifier.padding(top=4.dp))
            Text(r.circuit,color=Muted,fontSize=11.sp)
            Text(if(currentWeek==r.weekOfSeason) "FIM DE SEMANA DISPONÍVEL" else "CORRIDA AGUARDANDO A SEMANA CORRETA",color=if(currentWeek==r.weekOfSeason) Green else Muted,fontSize=9.sp,fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=8.dp))
            Button(onClick=start,enabled=currentWeek==r.weekOfSeason,modifier=Modifier.fillMaxWidth().padding(top=8.dp),colors=ButtonDefaults.buttonColors(containerColor=Red,contentColor=Color.White,disabledContainerColor=Panel2,disabledContentColor=Muted)){Text("ABRIR FIM DE SEMANA",fontWeight=FontWeight.Black)}
        }
    }
}

@Composable private fun Weekend(r:RoundDefinition,currentWeek:Int,start:()->Unit){LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){item{HeaderBlock(r.grandPrix,"ROUND ${r.round} • ${r.circuit}")};item{RaceHero(r,start,currentWeek)};item{InfoPanel("QUALIFICAÇÃO","Define o grid de largada");InfoPanel("ESTRATÉGIA","Postura + pneu inicial");InfoPanel("CORRIDA","Decisões VSC, SC e bandeira vermelha")};item{Button(onClick=start,modifier=Modifier.fillMaxWidth()){Text("COMEÇAR QUALIFICAÇÃO")}}}}
@Composable private fun InfoPanel(a:String,b:String){Row(Modifier.fillMaxWidth().background(Panel,RoundedCornerShape(8.dp)).padding(14.dp),horizontalArrangement=Arrangement.SpaceBetween){Column{Text(a,color=Color.White,fontWeight=FontWeight.Bold);Text(b,color=Muted,fontSize=11.sp)};Text("›",color=Red,fontSize=24.sp)}}
@Composable
private fun Qualifying(
    s: CareerWeekendEngine.SessionSnapshot,
    onMode: (Int, DriverStrategyMode) -> Unit,
    onPlan: (Int, String) -> Unit,
    simulate: () -> Unit,
    start: () -> Unit
){
    var phase by remember { mutableIntStateOf(0) }
    val phases=s.grid?.phases.orEmpty()
    val selected=phases.getOrNull(phase)
    val q3Complete=s.grid?.phases?.getOrNull(2)?.entries?.size==20

    Column(Modifier.fillMaxSize().padding(12.dp)){
        Text("CLASSIFICAÇÃO",color=Color.White,fontSize=23.sp,fontWeight=FontWeight.Black)
        Text("Q1 80 → Q2 50 → Q3 20",color=Red,fontSize=10.sp,fontWeight=FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(5.dp)){
            listOf("Q1","Q2","Q3").forEachIndexed{i,label->
                Button(onClick={phase=i},modifier=Modifier.weight(1f),colors=ButtonDefaults.buttonColors(containerColor=if(phase==i)Red else Panel2,contentColor=Color.White),contentPadding=PaddingValues(vertical=4.dp)){
                    Text(label,fontWeight=FontWeight.Black)
                }
            }
        }
        selected?.let{Text("${it.name}: ${it.entries.size} pilotos • eliminados nesta fase: ${it.eliminatedDriverIds.size}",color=Muted,fontSize=9.sp,modifier=Modifier.padding(vertical=5.dp))}

        LazyColumn(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(2.dp)){
            items(selected?.entries.orEmpty()){e->
                val mine = e.driverId in s.plans.keys
                Row(Modifier.fillMaxWidth().background(if(mine) Color(0xFF2A1010) else Panel,RoundedCornerShape(4.dp)).padding(horizontal=8.dp,vertical=5.dp),horizontalArrangement=Arrangement.SpaceBetween){
                    Text("P${e.position}",color=if(mine) Red else Muted,fontWeight=FontWeight.Black,fontSize=10.sp)
                    Text(if(mine) "★ ${WorldDatabase.drivers.firstOrNull{it.id==e.driverId}?.name?:"Piloto ${e.driverId}"}" else (WorldDatabase.drivers.firstOrNull{it.id==e.driverId}?.name?:"Piloto ${e.driverId}"),color=if(mine) Red else Color.White,fontWeight=if(mine) FontWeight.Black else FontWeight.Normal,fontSize=10.sp,modifier=Modifier.weight(1f).padding(horizontal=8.dp))
                    Text(formatMs(e.lapTimeMs),color=if(mine) Color.White else Muted,fontSize=9.sp)
                }
            }

            if(q3Complete){
                item {
                    Text("PLANO DE CORRIDA",color=Red,fontWeight=FontWeight.Black,fontSize=11.sp,modifier=Modifier.padding(top=10.dp,bottom=4.dp))
                    Text("Defina a postura de cada piloto e o plano de pneus A, B ou C para a corrida.",color=Muted,fontSize=9.sp,modifier=Modifier.padding(bottom=5.dp))
                }

                items(s.plans.entries.toList()){ entry ->
                    val driverId=entry.key
                    val driverPlan=entry.value
                    val driverName=WorldDatabase.drivers.firstOrNull{it.id==driverId}?.name ?: "Piloto $driverId"
                    Card(Modifier.fillMaxWidth().padding(bottom=5.dp),colors=CardDefaults.cardColors(Panel)){
                        Column(Modifier.padding(8.dp)){
                            Text(driverName,color=Color.White,fontWeight=FontWeight.Black,fontSize=12.sp)
                            Text("POSTURA",color=Muted,fontSize=9.sp,fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=6.dp,bottom=3.dp))
                            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(4.dp)){
                                DriverStrategyMode.entries.forEach { m ->
                                    Button(onClick={onMode(driverId,m)},modifier=Modifier.weight(1f),colors=ButtonDefaults.buttonColors(containerColor=if(driverPlan.mode==m) Red else Panel2,contentColor=Color.White),contentPadding=PaddingValues(vertical=4.dp)){
                                        Text(strategyLabel(m),fontSize=8.sp,fontWeight=FontWeight.Black,maxLines=1)
                                    }
                                }
                            }
                            Text("PLANO DE PNEUS",color=Muted,fontSize=9.sp,fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=6.dp,bottom=3.dp))
                            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(4.dp)){
                                listOf("A","B","C").forEach { id ->
                                    Button(onClick={onPlan(driverId,id)},modifier=Modifier.weight(1f),colors=ButtonDefaults.buttonColors(containerColor=if(driverPlan.activePlan==id) Red else Panel2,contentColor=Color.White),contentPadding=PaddingValues(vertical=4.dp)){
                                        Text("PLANO $id",fontSize=8.sp,fontWeight=FontWeight.Black)
                                    }
                                }
                            }
                            val active=driverPlan.tyrePlans[driverPlan.activePlan]
                            Text(planDescription(active),color=Muted,fontSize=9.sp,modifier=Modifier.padding(top=4.dp))
                        }
                    }
                }
            }
        }

        Button(onClick=if(q3Complete) start else simulate,modifier=Modifier.fillMaxWidth().height(48.dp),colors=ButtonDefaults.buttonColors(containerColor=Red,contentColor=Color.White)){
            Text(if(q3Complete) "INICIAR CORRIDA" else "SIMULAR ${listOf("Q1","Q2","Q3")[phases.indexOfFirst { it.entries.isEmpty() }.coerceAtLeast(0).coerceAtMost(2)]}",fontWeight=FontWeight.Black)
        }
    }
}
@Composable private fun <T> ChoiceRow(title:String,current:String,values:List<T>,select:(T)->Unit){Column{Text(title,color=Muted,fontSize=10.sp,fontWeight=FontWeight.Bold);Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(6.dp)){values.forEach{v->FilterChip(selected=v.toString()==current,onClick={select(v)},label={Text(v.toString())})}}}}
@Composable
private fun Race(
    s: CareerWeekendEngine.SessionSnapshot,
    drivers: List<com.f1teammanager.core.season.DriverDefinition>,
    advance: () -> Unit,
    setStrategy: (Int, DriverStrategyMode) -> Unit,
    pitNow: (Int, Tyre) -> Unit,
    pitPlan: (Int, String) -> Unit,
    decision: (ManagerDecisionAction) -> Unit,
) {
    var running by remember { mutableStateOf(true) }
    var speedMs by remember { mutableIntStateOf(1100) }
    var pitDriver by remember { mutableIntStateOf(-1) }
    val playerIds = drivers.map { it.id }.toSet()
    val playerStatus = s.carStatus.filter { it.driverId in playerIds }
    val statusById = s.carStatus.associateBy { it.driverId }
    val leaderTime = s.classification.minOfOrNull { it.totalTimeMs } ?: 0L

    LaunchedEffect(s.lap, s.decision, s.completed, running, speedMs) {
        if (running && s.decision == null && !s.completed) {
            kotlinx.coroutines.delay(speedMs.toLong())
            advance()
        }
    }

    Column(Modifier.fillMaxSize().padding(horizontal = 10.dp)) {
        Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column { Text("PIT WALL", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Black); Text("VOLTA ${s.lap}/${s.totalLaps}", color = Red, fontWeight = FontWeight.Bold) }
            Column(horizontalAlignment = Alignment.End) { Text(statusLabel(s.neutral), color = if (s.neutral == Neutralisation.GREEN) Green else Red, fontWeight = FontWeight.Black); Text(if (running) "AUTOMÁTICA" else "PAUSADA", color = Muted, fontSize = 9.sp)
            Text(weatherLabel(s.weather), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp) }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            listOf(1600 to "0,7x", 1100 to "1x", 650 to "1,7x", 300 to "3x").forEach { (ms, label) ->
                Button(onClick={speedMs=ms}, modifier=Modifier.weight(1f), colors=ButtonDefaults.buttonColors(containerColor=if(speedMs==ms) Red else Panel2, contentColor=Color.White), contentPadding=PaddingValues(vertical=2.dp)){Text(label,fontSize=9.sp)}
            }
        }

        val critical=s.alerts.firstOrNull { it.severity>=3 }
        critical?.let { Card(Modifier.fillMaxWidth().padding(vertical=3.dp), colors=CardDefaults.cardColors(containerColor=Color(0xFF3A0D0D))){Text(it.message,color=Color.White,fontWeight=FontWeight.Bold,fontSize=10.sp,modifier=Modifier.padding(7.dp))} }

        // Decision area deliberately compact: only the two team cars remain above the live classification.
        playerStatus.forEach { st ->
            val plan=s.plans[st.driverId]
            val aheadTime = if (st.position > 1) s.classification.firstOrNull { it.position == st.position - 1 }?.totalTimeMs else null
            val ownTime = s.classification.firstOrNull { it.driverId == st.driverId }?.totalTimeMs ?: st.lastLapMs
            val gap=if(st.position<=1) "LÍDER" else gapText(ownTime, aheadTime ?: ownTime, ahead=false)
            Card(Modifier.fillMaxWidth().padding(vertical=2.dp), colors=CardDefaults.cardColors(Panel)) {
                Row(Modifier.fillMaxWidth().padding(horizontal=8.dp,vertical=6.dp),verticalAlignment=Alignment.CenterVertically){
                    Column(Modifier.weight(1f)){
                        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text(st.driverName,color=Color.White,fontWeight=FontWeight.Black,fontSize=14.sp);Text("P${st.position} $gap",color=Red,fontWeight=FontWeight.Black,fontSize=12.sp)}
                        Text("${tyreLabel(st.tyre)} ${st.tyreWear}%/${st.stintLaps}v • COMB ${st.fuelPercent}% • ERS ${st.ersPercent}% ${if(st.ersActive) "(-${st.ersGainMs}ms)" else ""} • ${if(st.drsActive) "DRS ATIVO (-${st.drsGainMs}ms)" else "DRS —"} • BOX ${st.pitStops}x",color=if(st.fuelPercent<=20||st.tyreWear>=75) Red else Muted,fontSize=9.sp)
                        Text("ÚLTIMA ${formatMs(st.lastLapMs)} • PNEU ~${st.tyre.targetLaps}v",color=Muted,fontSize=8.sp)
                    }
                    Spacer(Modifier.width(5.dp))
                    Button(onClick={pitDriver=st.driverId},colors=ButtonDefaults.buttonColors(containerColor=Red,contentColor=Color.White),contentPadding=PaddingValues(horizontal=11.dp,vertical=3.dp)){Text("BOX",fontSize=9.sp,fontWeight=FontWeight.Black)}
                }
                Row(Modifier.fillMaxWidth().padding(start=8.dp,end=8.dp,bottom=5.dp),horizontalArrangement=Arrangement.spacedBy(4.dp)){
                    DriverStrategyMode.entries.forEach { m -> Button(onClick={setStrategy(st.driverId,m)},modifier=Modifier.weight(1f),colors=ButtonDefaults.buttonColors(containerColor=if(plan?.mode==m) Red else Panel2,contentColor=Color.White),contentPadding=PaddingValues(vertical=2.dp)){Text(strategyLabel(m),fontSize=8.sp,maxLines=1)} }
                }
            }
        }

        Card(Modifier.fillMaxWidth().weight(1f), colors=CardDefaults.cardColors(Panel)) {
            Column {
                Row(Modifier.fillMaxWidth().padding(horizontal=8.dp,vertical=6.dp),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){Text("CLASSIFICAÇÃO AO VIVO",color=Color.White,fontWeight=FontWeight.Black,fontSize=15.sp);Text("${s.classification.size} PILOTOS",color=Red,fontWeight=FontWeight.Black,fontSize=10.sp)}
                Row(Modifier.fillMaxWidth().padding(horizontal=8.dp),horizontalArrangement=Arrangement.SpaceBetween){Text("POS",color=Muted,fontSize=8.sp,modifier=Modifier.width(24.dp));Text("PILOTO",color=Muted,fontSize=8.sp,modifier=Modifier.weight(1f));Text("PNEU",color=Muted,fontSize=8.sp,modifier=Modifier.width(42.dp));Text("GAP",color=Muted,fontSize=8.sp,modifier=Modifier.width(54.dp))}
                LazyColumn(Modifier.weight(1f)) {
                    items(s.classification) { f ->
                        val mine=f.driverId in playerIds; val st=statusById[f.driverId]
                        val aheadTime = if (f.position > 1) s.classification.firstOrNull { it.position == f.position - 1 }?.totalTimeMs else null
                        val gap=if(f.position==1)"LÍDER" else gapText(f.totalTimeMs, aheadTime ?: f.totalTimeMs, ahead=false)
                        Row(Modifier.fillMaxWidth().background(if(mine) Color(0xFF2A1010) else Color.Transparent).padding(horizontal=8.dp,vertical=3.dp),verticalAlignment=Alignment.CenterVertically){
                            Text("${f.position}",color=if(mine)Red else Muted,fontWeight=FontWeight.Bold,modifier=Modifier.width(24.dp),fontSize=10.sp)
                            Text(f.driverName,color=if(mine) Red else Color.White,fontWeight=if(mine) FontWeight.Black else FontWeight.Normal,modifier=Modifier.weight(1f),maxLines=1,overflow=TextOverflow.Ellipsis,fontSize=10.sp)
                            Text(tyreLabel(f.tyre),color=if((st?.tyreWear?:0)>=80)Red else Muted,fontSize=8.sp,modifier=Modifier.width(42.dp))
                            Text(if(f.status.startsWith("DNF"))"DNF" else gap,color=if(f.status.startsWith("DNF"))Red else Muted,fontSize=8.sp,modifier=Modifier.width(54.dp))
                        }
                    }
                }
            }
        }

        if(s.events.isNotEmpty()) Text(s.events.takeLast(1).joinToString(" • "){it.detail},color=Muted,fontSize=8.sp,maxLines=1,overflow=TextOverflow.Ellipsis,modifier=Modifier.padding(vertical=2.dp))
        Button(onClick={running=!running},modifier=Modifier.fillMaxWidth().height(42.dp),colors=ButtonDefaults.buttonColors(containerColor=Red,contentColor=Color.White)){Text(if(running)"PAUSAR CORRIDA" else "RETOMAR CORRIDA",fontWeight=FontWeight.Black,fontSize=12.sp)}

        s.decision?.let { d ->
            AlertDialog(onDismissRequest={},title={Text("DECISÃO DO MANAGER",fontWeight=FontWeight.Black)},text={Column{Text("${d.driverName}: ${d.request.message}",color=Color.White);Spacer(Modifier.height(6.dp));d.request.options.forEach{action->Button(onClick={ if(action==ManagerDecisionAction.BOX) { pitDriver=d.request.driverId; running=true } else { decision(action); running=true } },modifier=Modifier.fillMaxWidth().padding(vertical=1.dp),colors=ButtonDefaults.buttonColors(containerColor=Red,contentColor=Color.White),contentPadding=PaddingValues(vertical=4.dp)){Text(actionLabel(action),fontSize=10.sp)}}}},confirmButton={})
        }
        if(pitDriver>0){
            val recommended = when(s.weather){
                Weather.HEAVY_RAIN -> Tyre.WET
                Weather.LIGHT_RAIN, Weather.MEDIUM_RAIN -> Tyre.INTERMEDIATE
                else -> Tyre.MEDIUM
            }
            AlertDialog(
                onDismissRequest={pitDriver=-1;running=true},
                title={Text("ESCOLHER PNEU PARA O BOX",fontWeight=FontWeight.Black)},
                text={Column{
                    val remainingLaps=(s.totalLaps-s.lap).coerceAtLeast(0)
                    Text("FALTAM $remainingLaps VOLTAS PARA O FIM DA CORRIDA",color=Red,fontWeight=FontWeight.Black,fontSize=11.sp)
                    Text("A vida mostrada é a referência do composto nas condições atuais. O desgaste real também considera clima e postura.",color=Muted,fontSize=9.sp,modifier=Modifier.padding(top=4.dp))
                    Text("RECOMENDADO AGORA: ${tyreLabel(recommended)}",color=Green,fontWeight=FontWeight.Black,fontSize=10.sp,modifier=Modifier.padding(top=6.dp,bottom=4.dp))
                    listOf(Tyre.SOFT,Tyre.MEDIUM,Tyre.HARD,Tyre.INTERMEDIATE,Tyre.WET).forEach{t->
                        val driverTyreWear = drivers.firstOrNull { it.id == pitDriver }?.tyre ?: 50
                        val life=tyreLifeEstimate(t,s.weather,s.plans[pitDriver]?.mode ?: DriverStrategyMode.BALANCED,driverTyreWear)
                        Button(onClick={pitNow(pitDriver,t);pitDriver=-1;running=true},modifier=Modifier.fillMaxWidth().padding(vertical=2.dp),colors=ButtonDefaults.buttonColors(containerColor=if(t==recommended) Red else Panel2,contentColor=Color.White)){Text("${tyreLabel(t)} • ${life} VOLTAS${if(t==recommended) " • RECOMENDADO" else ""}")}
                    }
                    val activePlan = s.plans[pitDriver]
                    if (activePlan != null) {
                        val activeTyrePlan = activePlan.tyrePlans[activePlan.activePlan]
                        Text("PLANO ATUAL: ${activePlan.activePlan}",color=Color.White,fontWeight=FontWeight.Black,fontSize=10.sp,modifier=Modifier.padding(top=6.dp))
                        Text(planDescription(activeTyrePlan),color=Muted,fontSize=9.sp,modifier=Modifier.padding(top=2.dp,bottom=4.dp))
                        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(4.dp)){
                            listOf("A","B","C").forEach { id ->
                                val p = activePlan.tyrePlans[id]
                                Button(onClick={pitPlan(pitDriver,id);pitDriver=-1;running=true},modifier=Modifier.weight(1f),colors=ButtonDefaults.buttonColors(containerColor=if(activePlan.activePlan==id) Red else Panel2,contentColor=Color.White),contentPadding=PaddingValues(vertical=3.dp)){Text("PLANO $id",fontSize=8.sp,fontWeight=FontWeight.Black)}
                            }
                        }
                        Button(onClick={pitPlan(pitDriver,activePlan.activePlan);pitDriver=-1;running=true},modifier=Modifier.fillMaxWidth().padding(top=4.dp),colors=ButtonDefaults.buttonColors(containerColor=Red,contentColor=Color.White)){Text("MANTER PLANO ${activePlan.activePlan}",fontWeight=FontWeight.Black,fontSize=9.sp)}
                    }
                    Spacer(Modifier.height(4.dp))
                    Text("OU ESCOLHER MANUALMENTE",color=Muted,fontWeight=FontWeight.Bold,fontSize=8.sp,modifier=Modifier.padding(top=2.dp,bottom=2.dp))
                    Button(
                        onClick={pitDriver=-1;running=true},
                        modifier=Modifier.fillMaxWidth().padding(top=2.dp),
                        colors=ButtonDefaults.buttonColors(containerColor=Panel2,contentColor=Color.White)
                    ){Text("SAIR • NÃO IR AO BOX",fontWeight=FontWeight.Black)}
                }},
                confirmButton={}
            )
        }
    }
}

private fun gapText(time: Long, reference: Long, ahead: Boolean = false): String {
    val gap = (time - reference).coerceAtLeast(0L)
    return "+${gap / 1000}.${(gap % 1000) / 100}s"
}

@Composable private fun Result(r:RaceResult,teamId:Int,store:CareerPreferences,onCalendar:()->Unit){
    val teamName=WorldDatabase.teams.first{it.id==teamId}.name
    val mine=r.classification.filter{it.teamName==teamName}
    val earned=mine.sumOf{r.points[it.driverId]?:0}
    Column(Modifier.fillMaxSize().padding(16.dp)){
        HeaderBlock("RESULTADO","CORRIDA FINALIZADA")
        Card(Modifier.fillMaxWidth().padding(top=10.dp),colors=CardDefaults.cardColors(Panel)){Column(Modifier.padding(13.dp)){Text("SUA EQUIPE",color=Red,fontWeight=FontWeight.Black);mine.forEach{f->Text("P${f.position} • ${f.driverName} • ${r.points[f.driverId]?:0} PTS",color=Color.White,fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=5.dp))};Text("PONTOS CONQUISTADOS: $earned",color=Color.White,fontWeight=FontWeight.Black,modifier=Modifier.padding(top=8.dp))}}
        LazyColumn(Modifier.weight(1f),contentPadding=PaddingValues(vertical=10.dp),verticalArrangement=Arrangement.spacedBy(3.dp)){items(r.classification){f->Row(Modifier.fillMaxWidth().background(if(f.position<=3)Color(0xFF251414) else Panel,RoundedCornerShape(5.dp)).padding(9.dp),horizontalArrangement=Arrangement.SpaceBetween){Text("P${f.position}",color=if(f.position<=3)Red else Muted,fontWeight=FontWeight.Black);Text(f.driverName,color=Color.White,modifier=Modifier.weight(1f).padding(horizontal=8.dp),maxLines=1,overflow=TextOverflow.Ellipsis);Text("${r.points[f.driverId]?:0} PTS",color=if((r.points[f.driverId]?:0)>0) Color.White else Muted,fontSize=10.sp)}}}
        Text("Safety Car ${r.safetyCarLaps} • VSC ${r.vscLaps} • Campeonato: ${store.constructorPoints()[teamId]?:0} PTS",color=Muted,fontSize=10.sp)
        Button(onClick=onCalendar,modifier=Modifier.fillMaxWidth().height(48.dp),colors=ButtonDefaults.buttonColors(containerColor=Red,contentColor=Color.White)){Text("IR PARA CALENDÁRIO",fontWeight=FontWeight.Black)}
    }
}
private fun initialManagerState(teamId:Int,store:CareerPreferences):TeamManagerState { val t=WorldDatabase.teams.first{it.id==teamId}; val base=TeamManagerState(season=store.season,round=store.roundIndex+1,playerTeamId=teamId,car=TeamCarState(t.baseCar,t.chassis,t.engine,t.reliability,frontWing=t.frontWing,rearWing=t.rearWing,brakes=t.brakes,electricPowerUnit=t.electricPowerUnit),finance=TeamFinanceState(75_000_000L)); val sponsors=store.loadSponsors(teamId); return base.copy(finance=store.loadFinance(teamId,base.finance),sponsor=sponsors.firstOrNull { it.slot==1 } ?: store.loadSponsor(teamId,base.sponsor),sponsors=sponsors,driverMarket=DriverMarketEngine(20261003).initialState(store.season)) }
private fun componentLabel(c:CarComponent)=when(c){CarComponent.ENGINE->"Unidade de potência";CarComponent.CHASSIS->"Chassi";CarComponent.FRONT_WING->"Asa dianteira";CarComponent.REAR_WING->"Asa traseira";CarComponent.BRAKES->"Freios";CarComponent.ELECTRIC_POWER_UNIT->"Unidade de potência elétrica"}
private fun componentDuration(c:CarComponent)=when(c){CarComponent.ENGINE->4;CarComponent.CHASSIS->3;CarComponent.FRONT_WING->2;CarComponent.REAR_WING->2;CarComponent.BRAKES->2;CarComponent.ELECTRIC_POWER_UNIT->4}
@Composable private fun HistoryResult(round:Int,result:RaceResult?){ if(result==null){Text("Nenhuma classificação salva para o Round $round",color=Muted,modifier=Modifier.padding(16.dp));return}; Column(Modifier.fillMaxSize().padding(12.dp)){HeaderBlock("ROUND $round","CLASSIFICAÇÃO SALVA");LazyColumn(Modifier.weight(1f),contentPadding=PaddingValues(vertical=8.dp)){items(result.classification){f->Row(Modifier.fillMaxWidth().background(if(f.position<=3)Color(0xFF251414) else Panel,RoundedCornerShape(5.dp)).padding(8.dp),verticalAlignment=Alignment.CenterVertically){Text("P${f.position}",color=if(f.position<=3)Red else Muted,fontWeight=FontWeight.Black,modifier=Modifier.width(38.dp));Text(f.driverName,color=Color.White,modifier=Modifier.weight(1f),maxLines=1,overflow=TextOverflow.Ellipsis);Text("${result.points[f.driverId]?:0} PTS",color=Muted,fontSize=9.sp)}}}} }



@Composable
private fun TeamSelect(onSelect: (Int) -> Unit) {
    Column(Modifier.fillMaxSize().statusBarsPadding().padding(16.dp)) {
        HeaderBlock("F1 MANAGER", "ESCOLHA SUA EQUIPE")
        Text("40 equipes • 80 pilotos", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(vertical = 8.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp), contentPadding = PaddingValues(bottom = 16.dp)) {
            items(WorldDatabase.teams.sortedWith(compareByDescending<com.f1teammanager.core.season.TeamDefinition> { it.baseCar }.thenByDescending { it.engine }.thenByDescending { it.reliability }.thenBy { it.id })) { t ->
                Card(Modifier.fillMaxWidth().clickable { onSelect(t.id) }, colors = CardDefaults.cardColors(Panel)) {
                    Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(t.name, color = Color.White, fontWeight = FontWeight.Black)
                            Text("Força ${t.baseCar} • Motor ${t.engine} • Confiabilidade ${t.reliability}", color = Muted, fontSize = 10.sp)
                        }
                        Text("ESCOLHER", color = Red, fontWeight = FontWeight.Black, fontSize = 10.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun Standings(teamId: Int, store: CareerPreferences) {
    var tab by remember { mutableIntStateOf(0) }
    val driverPoints=store.driverPoints()
    val constructorPoints=store.constructorPoints()
    val drivers=WorldDatabase.drivers.map{d->val t=WorldDatabase.teams.first{it.id==d.teamId};Triple(d,t,driverPoints[d.id]?:0)}.sortedByDescending{it.third}
    val constructors=WorldDatabase.teams.map{t->t to (constructorPoints[t.id]?:0)}.sortedWith(compareByDescending<Pair<com.f1teammanager.core.season.TeamDefinition,Int>>{it.second}.thenBy{it.first.id})
    Column(Modifier.fillMaxSize().padding(12.dp)){
        HeaderBlock("CAMPEONATO","PILOTOS E CONSTRUTORES")
        Row(Modifier.fillMaxWidth().background(Panel,RoundedCornerShape(8.dp)).padding(4.dp),horizontalArrangement=Arrangement.spacedBy(4.dp)){
            listOf("PILOTOS","CONSTRUTORES").forEachIndexed{index,label->Button(onClick={tab=index},modifier=Modifier.weight(1f),colors=ButtonDefaults.buttonColors(containerColor=if(tab==index)Red else Panel2,contentColor=Color.White),contentPadding=PaddingValues(vertical=8.dp)){Text(label,fontWeight=FontWeight.Black,fontSize=10.sp)}}
        }
        if(tab==0){
            LazyColumn(Modifier.weight(1f),contentPadding=PaddingValues(vertical=8.dp),verticalArrangement=Arrangement.spacedBy(3.dp)){items(drivers){(d,t,pts)->Row(Modifier.fillMaxWidth().background(if(t.id==teamId)Color(0xFF251414)else Panel,RoundedCornerShape(5.dp)).padding(9.dp),verticalAlignment=Alignment.CenterVertically){Text("${drivers.indexOfFirst{it.first.id==d.id}+1}",color=if(t.id==teamId)Red else Muted,fontWeight=FontWeight.Black,modifier=Modifier.width(28.dp));Text(d.name,color=Color.White,modifier=Modifier.weight(1f),maxLines=1,overflow=TextOverflow.Ellipsis);Text(t.name,color=Muted,fontSize=9.sp,modifier=Modifier.width(105.dp),maxLines=1,overflow=TextOverflow.Ellipsis);Text("$pts PTS",color=Color.White,fontWeight=FontWeight.Bold,fontSize=10.sp)}}}
        }else{
            LazyColumn(Modifier.weight(1f),contentPadding=PaddingValues(vertical=8.dp),verticalArrangement=Arrangement.spacedBy(3.dp)){items(constructors){(t,pts)->Row(Modifier.fillMaxWidth().background(if(t.id==teamId)Color(0xFF251414)else Panel,RoundedCornerShape(5.dp)).padding(10.dp),verticalAlignment=Alignment.CenterVertically){Text("${constructors.indexOfFirst{it.first.id==t.id}+1}",color=if(t.id==teamId)Red else Muted,fontWeight=FontWeight.Black,modifier=Modifier.width(30.dp));Text(t.name,color=Color.White,modifier=Modifier.weight(1f),fontWeight=if(t.id==teamId)FontWeight.Black else FontWeight.Normal,maxLines=1,overflow=TextOverflow.Ellipsis);Text("$pts PTS",color=Color.White,fontWeight=FontWeight.Black,fontSize=12.sp)}}}
        }
    }
}

@Composable
private fun Finance(store: CareerPreferences, teamId: Int, state:TeamManagerState, message:String, signSponsor:(SponsorContract)->Unit) {
    val baseOffers=listOf(
        listOf(SponsorContract("Apex Mobility",6_000_000,3_200_000,50_000,1,0,1,5,1_500_000,3,4_000_000), SponsorContract("Velocity Energy",4_500_000,2_400_000,40_000,1,0,1,7,1_000_000,5,2_500_000), SponsorContract("Atlas Global",3_000_000,1_900_000,30_000,1,0,1,10,750_000,8,1_500_000)),
        listOf(SponsorContract("Titan Motors",3_500_000,1_700_000,28_000,1,0,2,8,700_000,6,1_800_000), SponsorContract("Nova Bank",2_800_000,1_450_000,24_000,1,0,2,10,550_000,8,1_300_000), SponsorContract("Orion Tech",2_200_000,1_250_000,20_000,1,0,2,12,400_000,10,1_000_000)),
        listOf(SponsorContract("Vertex Systems",2_600_000,1_250_000,22_000,1,0,3,10,500_000,8,1_200_000), SponsorContract("Apex Fuel",2_000_000,1_050_000,18_000,1,0,3,12,350_000,10,900_000), SponsorContract("Pulse Mobile",1_600_000,900_000,15_000,1,0,3,15,250_000,12,700_000)),
        listOf(SponsorContract("Helix Finance",1_800_000,850_000,16_000,1,0,4,12,300_000,10,800_000), SponsorContract("Vector Energy",1_450_000,750_000,13_000,1,0,4,15,220_000,12,600_000), SponsorContract("Northstar",1_100_000,650_000,10_000,1,0,4,18,150_000,15,450_000)),
        listOf(SponsorContract("Falcon Media",1_250_000,550_000,9_000,1,0,5,15,180_000,12,500_000), SponsorContract("Quantum",950_000,480_000,8_000,1,0,5,18,130_000,15,350_000), SponsorContract("Velocity Labs",700_000,400_000,6_000,1,0,5,20,100_000,18,250_000))
    )
    // A duração de cada oferta é sorteada entre 1 e 10 GPs, mas permanece estável
    // enquanto a tela estiver aberta e durante a carreira atual.
    val offers = remember(teamId, store.season) {
        val rng = kotlin.random.Random(20261004 + teamId * 97 + store.season)
        baseOffers.map { slotOffers ->
            slotOffers.map { offer ->
                val duration = rng.nextInt(1, 11)
                offer.copy(races = duration, racesRemaining = duration)
            }
        }
    }
    LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
        item{
            HeaderBlock("FINANÇAS","ORÇAMENTO, RECEITAS E PATROCÍNIOS")
            Spacer(Modifier.height(4.dp))
            Text("Todos os valores usam € milhões ou € mil para facilitar a leitura.",color=Muted,fontSize=9.sp)
        }
        item{Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(Panel)){Column(Modifier.padding(14.dp)){
            Text("SALDO",color=Red,fontWeight=FontWeight.Black)
            Text(formatMoney(state.finance.budget),color=Color.White,fontSize=28.sp,fontWeight=FontWeight.Black)
            Text("Receitas da temporada: ${formatMoney(state.finance.seasonIncome)}",color=Green,fontSize=10.sp)
            Text("Despesas da temporada: ${formatMoney(state.finance.seasonExpenses)}",color=Muted,fontSize=10.sp)
            val activeCount=state.sponsors.count { it.active }
            Text("Patrocínios ativos: $activeCount/5",color=Color.White,fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=6.dp))
        }}}
        if(message.isNotBlank()) item{Text(message,color=Green,fontWeight=FontWeight.Bold,fontSize=10.sp)}
        item{SectionTitle("5 ESPAÇOS DE PATROCÍNIO")}
        items(offers.indices.toList()){slotIndex->
            val slot=slotIndex+1
            val signed=state.sponsors.firstOrNull { it.slot==slot && it.active }
            Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(Panel)){Column(Modifier.padding(12.dp)){
                Text(if(slot==1) "SLOT 1 • PRINCIPAL / MAIOR VALOR" else "SLOT $slot • PATROCINADOR SECUNDÁRIO",color=if(slot==1) Red else Color.White,fontWeight=FontWeight.Black)
                if(signed!=null) {
                    Text("ATIVO: ${signed.name}",color=Green,fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=5.dp))
                    Text("Entrada ${formatMoney(signed.upfront)} • ${formatMoney(signed.racePayment)}/GP • ${signed.racesRemaining}/${signed.races} corridas • ${formatMoney(signed.pointsBonus)}/ponto",color=Muted,fontSize=9.sp)
                    Text("Meta quali P${signed.qualifyingTarget}: +${formatMoney(signed.qualifyingBonus)} • Meta corrida P${signed.raceTarget}: +${formatMoney(signed.raceTargetBonus)}",color=Muted,fontSize=8.sp,modifier=Modifier.padding(top=3.dp))
                } else {
                    offers[slotIndex].forEach { o ->
                        Column(Modifier.padding(top=9.dp)){
                            Text(o.name,color=Color.White,fontWeight=FontWeight.Bold,fontSize=16.sp)
                            Text("Entrada ${formatMoney(o.upfront)} • ${formatMoney(o.racePayment)}/GP • ${formatMoney(o.pointsBonus)}/ponto",color=Muted,fontSize=9.sp)
                            Text("${o.races} ${if(o.races==1) "corrida" else "corridas"} • Meta quali P${o.qualifyingTarget}: +${formatMoney(o.qualifyingBonus)} • Meta corrida P${o.raceTarget}: +${formatMoney(o.raceTargetBonus)}",color=Muted,fontSize=8.sp)
                            Button(onClick={signSponsor(o)},modifier=Modifier.fillMaxWidth().padding(top=5.dp),colors=ButtonDefaults.buttonColors(containerColor=Red,contentColor=Color.White)){Text("ACEITAR ${o.name}",fontWeight=FontWeight.Black,fontSize=10.sp)}
                        }
                    }
                }
            }}
        }
        item{SectionTitle("COMO A EQUIPE GANHA DINHEIRO")}
        item{Text("Cada contrato paga a entrada no momento da assinatura, o valor por GP e os bônus de pontos/metas. Ao terminar a última corrida contratada, o espaço é liberado para um novo patrocínio.",color=Muted,fontSize=10.sp)}
    }
}

@Composable
private fun DriverMarket(
    store: CareerPreferences,
    teamId: Int,
    selectedDriverId: Int,
    state: DriverMarketState,
    message: String,
    onSelect: (Int) -> Unit,
    onInterest: (Int) -> Unit
) {
    val free = state.released.mapNotNull { id -> WorldDatabase.allDrivers.firstOrNull { it.id == id } }
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        HeaderBlock("MERCADO", "PILOTOS LIVRES")
        if (message.isNotBlank()) Text(message, color = Green, fontSize = 10.sp, modifier = Modifier.padding(vertical = 6.dp))
        if (free.isEmpty()) Text("Nenhum piloto livre no momento.", color = Muted, modifier = Modifier.padding(16.dp))
        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            items(free) { d ->
                val selected = selectedDriverId == d.id
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(if (selected) Color(0xFF251414) else Panel)) {
                    Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(d.name, color = Color.White, fontWeight = FontWeight.Bold)
                            Text("Velocidade ${d.speed} • Quali ${d.qualifying} • Chuva ${d.wet}", color = Muted, fontSize = 9.sp)
                        }
                        Button(onClick = { onSelect(d.id); onInterest(d.id) }, colors = ButtonDefaults.buttonColors(containerColor = Red, contentColor = Color.White), contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)) {
                            Text("INTERESSE", fontSize = 9.sp, fontWeight = FontWeight.Black)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ManagementHub(
    raceActive: Boolean,
    onDrivers: () -> Unit,
    onMarket: () -> Unit,
    onFinance: () -> Unit,
    onCar: () -> Unit,
    onStandings: () -> Unit,
    onCalendar: () -> Unit,
    onWeekend: () -> Unit,
    onRace: () -> Unit
) {
    val actions = listOf(
        "FIM DE SEMANA" to onWeekend,
        "PILOTOS" to onDrivers,
        "MERCADO" to onMarket,
        "CARRO / P&D" to onCar,
        "CAMPEONATO" to onStandings,
        "CALENDÁRIO" to onCalendar,
        "FINANÇAS" to onFinance
    )
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        HeaderBlock("CENTRAL DE GESTÃO", if (raceActive) "CORRIDA ATIVA" else "TEMPORADA")
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(vertical = 10.dp)) {
            items(actions) { (label, action) ->
                Button(onClick = action, modifier = Modifier.fillMaxWidth().height(46.dp), colors = ButtonDefaults.buttonColors(containerColor = if (label == "PIT WALL" && raceActive) Red else Panel2, contentColor = Color.White)) {
                    Text(label, fontWeight = FontWeight.Black, fontSize = 11.sp)
                }
            }
        }
    }
}

private fun strategyLabel(m:DriverStrategyMode)=when(m){DriverStrategyMode.ATTACK->"ATAQUE";DriverStrategyMode.BALANCED->"EQUILIBRADO";DriverStrategyMode.DEFENSE->"DEFESA / ECONOMIA"}
private fun tyreLabel(t:Tyre)=when(t){Tyre.SOFT->"SOFT";Tyre.MEDIUM->"MEDIUM";Tyre.HARD->"HARD";Tyre.INTERMEDIATE->"INTER";Tyre.WET->"WET"}
private fun weatherLabel(w:Weather)=when(w){Weather.DRY->"☀️ SOL";Weather.CLOUDY->"☁️ NUBLADO";Weather.LIGHT_RAIN->"🌦️ CHUVA FRACA • INTERMEDIÁRIO";Weather.MEDIUM_RAIN->"🌧️ CHUVA MÉDIA • INTERMEDIÁRIO";Weather.HEAVY_RAIN->"🌧️ CHUVA FORTE • WET"}
private fun statusLabel(n:Neutralisation)=when(n){Neutralisation.GREEN->"GREEN FLAG";Neutralisation.VSC->"VSC";Neutralisation.SAFETY_CAR->"SAFETY CAR"}
private fun tyreLifeEstimate(tyre:Tyre, weather:Weather, mode:DriverStrategyMode, driverTyreWear:Int = 50):Int {
    val weatherFactor=when(weather){
        Weather.DRY -> 1.00
        Weather.CLOUDY -> when(tyre){Tyre.SOFT,Tyre.MEDIUM,Tyre.HARD->0.95;Tyre.INTERMEDIATE,Tyre.WET->1.20}
        Weather.LIGHT_RAIN,Weather.MEDIUM_RAIN -> when(tyre){Tyre.SOFT,Tyre.MEDIUM,Tyre.HARD->0.72;Tyre.INTERMEDIATE,Tyre.WET->0.90}
        Weather.HEAVY_RAIN -> when(tyre){Tyre.SOFT,Tyre.MEDIUM,Tyre.HARD->0.55;Tyre.INTERMEDIATE->0.88;Tyre.WET->0.35}
    }
    val strategyFactor=when(mode){DriverStrategyMode.ATTACK->1.10;DriverStrategyMode.BALANCED->1.00;DriverStrategyMode.DEFENSE->0.90}
    val driverFactor=(1.10-((driverTyreWear.coerceIn(1,100)-50)*0.002)).coerceIn(0.90,1.10)
    return kotlin.math.floor((tyre.targetLaps/(weatherFactor*strategyFactor*driverFactor)).toDouble() + 0.000001).toInt().coerceAtLeast(1).coerceAtMost(tyre.targetLaps)
}

private fun actionLabel(a:ManagerDecisionAction)=when(a){ManagerDecisionAction.BOX->"BOX";ManagerDecisionAction.STAY_OUT->"MANTER";ManagerDecisionAction.EXTEND_STINT->"ESTENDER STINT";ManagerDecisionAction.SAVE_FUEL->"POUPAR COMBUSTÍVEL";ManagerDecisionAction.CHANGE_STRATEGY->"MUDAR ESTRATÉGIA";ManagerDecisionAction.RESTART_ATTACK->"RELARGADA • ATAQUE";ManagerDecisionAction.RESTART_BALANCED->"RELARGADA • EQUILIBRADO";ManagerDecisionAction.RESTART_DEFENSE->"RELARGADA • DEFESA";ManagerDecisionAction.CHANGE_TYRE_SOFT->"SOFT";ManagerDecisionAction.CHANGE_TYRE_MEDIUM->"MEDIUM";ManagerDecisionAction.CHANGE_TYRE_HARD->"HARD";ManagerDecisionAction.CHANGE_TYRE_INTERMEDIATE->"INTERMEDIÁRIO";ManagerDecisionAction.CHANGE_TYRE_WET->"WET"}
private fun constructorPosition(teamId:Int, store:CareerPreferences): Int {
    val points = store.constructorPoints()
    val rows = WorldDatabase.teams.map { it.id to (points[it.id] ?: 0) }
        .sortedWith(compareByDescending<Pair<Int,Int>> { it.second }.thenBy { it.first })
    return rows.indexOfFirst { it.first == teamId }.let { if (it >= 0) it + 1 else WorldDatabase.teams.indexOfFirst { it.id == teamId } + 1 }
}
private fun driverChampionshipPosition(driverId:Int, store:CareerPreferences): Int {
    val points = store.driverPoints()
    val rows = WorldDatabase.drivers.map { it.id to (points[it.id] ?: 0) }
        .sortedWith(compareByDescending<Pair<Int,Int>> { it.second }.thenBy { it.first })
    return rows.indexOfFirst { it.first == driverId }.let { if (it >= 0) it + 1 else WorldDatabase.drivers.indexOfFirst { it.id == driverId } + 1 }
}

private fun planDescription(plan:TyrePlan?): String = plan?.let {
    it.sequence.indices.joinToString(" → ") { i -> "${tyreLabel(it.sequence[i])} ${it.stintLaps.getOrElse(i) { 0 }}v" }
} ?: "Plano indisponível"

@Composable
private fun SectionTitle(title:String) {
    Text(
        title,
        color = Red,
        fontSize = 11.sp,
        fontWeight = FontWeight.Black,
        modifier = Modifier.padding(top = 2.dp, bottom = 1.dp)
    )
}

@Composable
private fun StatCard(title:String, value:String, subtitle:String, modifier:Modifier = Modifier) {
    Column(
        modifier = modifier
            .background(Panel2, RoundedCornerShape(8.dp))
            .padding(9.dp)
    ) {
        Text(title, color = Muted, fontSize = 8.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(value, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Black, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 3.dp))
        Text(subtitle, color = Muted, fontSize = 8.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 2.dp))
    }
}

@Composable
private fun HeaderBlock(title:String, subtitle:String) {
    Column(Modifier.fillMaxWidth().padding(bottom = 6.dp)) {
        Text(title, color=Color.White, fontSize=22.sp, fontWeight=FontWeight.Black, maxLines=1, overflow=TextOverflow.Ellipsis)
        Text(subtitle, color=Red, fontSize=10.sp, fontWeight=FontWeight.Bold)
    }
}

private fun formatMoney(value:Long):String {
    val sign = if (value < 0) "-" else ""
    val abs = kotlin.math.abs(value)
    return when {
        abs >= 1_000_000L -> {
            val millions = abs / 1_000_000L
            val thousands = (abs % 1_000_000L) / 1_000L
            if (thousands == 0L) "€ ${sign}${millions} M"
            else "€ ${sign}${millions},${(thousands / 100).coerceAtLeast(1)} M"
        }
        abs >= 1_000L -> "€ ${sign}${abs / 1_000L} mil"
        else -> "€ ${sign}${abs}"
    }
}

private fun formatMs(ms:Long)="%d:%02d.%03d".format(ms/60000,(ms/1000)%60,ms%1000)
