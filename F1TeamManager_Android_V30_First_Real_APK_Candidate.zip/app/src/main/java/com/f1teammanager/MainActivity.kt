package com.f1teammanager

import android.os.Bundle
import android.os.Build
import android.Manifest
import androidx.activity.ComponentActivity
import androidx.core.view.WindowCompat
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import com.f1teammanager.core.race.*
import com.f1teammanager.core.manager.CarComponent
import com.f1teammanager.core.manager.CarDevelopmentEngine
import com.f1teammanager.core.manager.ResearchEngine
import com.f1teammanager.core.manager.ResearchFocus
import com.f1teammanager.core.manager.ResearchComplexity
import com.f1teammanager.core.manager.GarageCarId
import com.f1teammanager.core.manager.TeamGarageFactory
import com.f1teammanager.core.manager.FactoryEngine
import com.f1teammanager.core.manager.FinancialSeasonClosureEngine
import com.f1teammanager.core.manager.DevelopmentIntensity
import com.f1teammanager.core.manager.CarDevelopmentFocus
import com.f1teammanager.core.manager.TeamCarState
import com.f1teammanager.core.manager.InitialTeamProfile
import com.f1teammanager.core.manager.TeamManagerState
import com.f1teammanager.core.manager.TeamFacilitiesState
import com.f1teammanager.core.manager.FacilityType
import com.f1teammanager.core.manager.FacilityEngine
import com.f1teammanager.core.manager.TeamFinanceState
import com.f1teammanager.core.manager.FinanceEngine
import com.f1teammanager.core.manager.AITeamFinancialEngine
import com.f1teammanager.core.manager.AITeamDevelopmentEngine
import com.f1teammanager.core.manager.TeamSponsorshipEngine
import com.f1teammanager.core.manager.SeasonSettlementEngine
import com.f1teammanager.core.manager.ManagerMarketEngine
import com.f1teammanager.core.manager.SponsorContract
import com.f1teammanager.core.manager.DynamicGridEngine
import com.f1teammanager.core.manager.DriverMarketEngine
import com.f1teammanager.core.manager.DriverMarketState
import com.f1teammanager.core.manager.MarketNewsCategory
import com.f1teammanager.core.manager.MarketNotification
import com.f1teammanager.core.manager.DriverTeamRole
import com.f1teammanager.core.manager.NegotiationStatus
import com.f1teammanager.core.season.CarCatalog
import com.f1teammanager.core.season.RoundDefinition
import com.f1teammanager.core.season.WorldDatabase
import com.f1teammanager.core.season.SeasonCalendar

private val Bg = Color(0xFF08090C)
private val Panel = Color(0xFF14161B)
private val Panel2 = Color(0xFF1B1E24)
private val Red = Color(0xFFE10600)
private val Muted = Color(0xFF8D929C)
private val Line = Color(0xFF2B2F36)
private val Green = Color(0xFF38C878)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, true)
        setContent { F1ManagerApp(CareerPreferences(this)) }
        window.decorView.post { requestExternalAssetPermissionIfNeeded() }
    }

    private fun requestExternalAssetPermissionIfNeeded() {
        runCatching {
            val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_IMAGES else Manifest.permission.READ_EXTERNAL_STORAGE
            if (androidx.core.content.ContextCompat.checkSelfPermission(this, permission) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(permission), 4101)
            }
        }
    }
}

private enum class Screen { HOME, TEAM, DRIVERS, CAR, CALENDAR, STANDINGS, FINANCE, MARKET, WEEKEND, QUALIFYING, RACE, RESULT, HISTORY, HISTORY_CENTER, NEWS, HALL_OF_FAME, RECORDS, SEASON, MANAGEMENT, SELECT_TEAM }
private enum class Nav { HOME, TEAM, CAR, CALENDAR, STANDINGS }

@Composable
private fun F1ManagerApp(store: CareerPreferences) {
    // V51: expose persisted evolution from careers created by older builds before
    // the first screen is rendered. The operation is idempotent.
    store.ensureDriverEvolutionAuditNews()
    var hasCareer by remember { mutableStateOf(store.hasCareer) }
    var teamId by remember { mutableIntStateOf(store.teamId) }
    var roundIndex by remember { mutableIntStateOf(store.roundIndex) }
    var currentWeek by remember { mutableIntStateOf(store.currentWeek) }
    var screen by remember { mutableStateOf(if (hasCareer) Screen.HOME else Screen.SELECT_TEAM) }
    var nav by remember { mutableStateOf(Nav.HOME) }
    var selectedMode by remember { mutableStateOf(DriverStrategyMode.BALANCED) }
    var selectedTyre by remember { mutableStateOf(Tyre.MEDIUM) }
    var snapshot by remember { mutableStateOf<CareerWeekendEngine.SessionSnapshot?>(null) }
    var result by remember { mutableStateOf<RaceResult?>(null) }
    var marketDriverId by remember { mutableIntStateOf(-1) }
    var marketMessage by remember { mutableStateOf("") }
        var managerState by remember(teamId) { mutableStateOf(store.loadCar(teamId)?.let { val base=TeamManagerState(season=store.season, round=store.roundIndex+1, car=it, garage=store.loadGarage(teamId) ?: TeamGarageFactory.fromCarState(it, teamId, store.season), facilities=store.loadFacilities(teamId) ?: InitialTeamProfile.teamFacilities(WorldDatabase.teams.first { it.id == teamId }.initialLevel), research=store.loadResearch(teamId) ?: com.f1teammanager.core.manager.TeamResearchState(), factory=store.loadFactory(teamId) ?: com.f1teammanager.core.manager.TeamFactoryState(), finance=TeamFinanceState(75_000_000L), playerTeamId=teamId); run { val sponsors=store.loadSponsors(teamId); base.copy(finance=store.loadFinance(teamId,base.finance), sponsor=sponsors.firstOrNull { it.slot==1 } ?: store.loadSponsor(teamId,base.sponsor), sponsors=sponsors, driverMarket=store.loadDriverMarket() ?: DriverMarketEngine(20261003).initialState(store.season)) } } ?: initialManagerState(teamId,store)) }
    var historyRound by remember { mutableIntStateOf(-1) }
    var historyResult by remember { mutableStateOf<RaceResult?>(null) }
    var carMessage by remember { mutableStateOf("") }
    var calendarMessage by remember { mutableStateOf("") }
    var sponsorMessage by remember { mutableStateOf("") }
    val marketEngine = remember { DriverMarketEngine(20261003) }
    val engine = remember { CareerWeekendEngine(20261003) }
    val team = WorldDatabase.teams.firstOrNull { it.id == teamId } ?: WorldDatabase.teams.first()
    val drivers = store.currentDrivers().filter { it.teamId == team.id }
    val seasonRounds = SeasonCalendar.forSeason(store.season)
    val round = seasonRounds.getOrElse(roundIndex) { seasonRounds.first() }
    val development = remember { CarDevelopmentEngine() }
    val researchEngine = remember { ResearchEngine() }
    val factoryEngine = remember { FactoryEngine() }
    // The interactive Android path shares the same AI commercial/financial engines
    // used by the season orchestrator. This prevents the UI simulation from silently
    // bypassing AI cash flow, sponsorship turnover and end-of-season debt penalties.
    val aiFinance = remember { AITeamFinancialEngine(20261006).also { it.restoreSnapshot(store.loadAiFinanceSnapshot()) } }
    val aiSponsorship = remember { TeamSponsorshipEngine(20261006).also { it.restoreSnapshot(store.loadAiSponsorshipSnapshot()) } }
    val aiDevelopment = remember { AITeamDevelopmentEngine(20261005) }

    fun persistAiState() {
        store.saveAiFinanceSnapshot(aiFinance.exportSnapshot())
        store.saveAiSponsorshipSnapshot(aiSponsorship.exportSnapshot())
    }

    fun syncAiWeeklyState(week: Int) {
        aiFinance.ensureAllTeams(store.season, team.id, managerState.driverMarket)
        WorldDatabase.teams.filter { it.id != team.id }.forEach { aiTeam ->
            val virtual = aiDevelopment.simulateFinancial(aiTeam, (week - 1).coerceAtLeast(0), store.season)
            aiFinance.applyDevelopmentCost(aiTeam.id, store.season, virtual.budget)
            aiFinance.applySponsorshipSignings(aiTeam.id, store.season, aiSponsorship.forTeam(aiTeam.id, store.season))
        }
        persistAiState()
    }

    fun participants() = DynamicGridEngine().participants(
        market = managerState.driverMarket,
        playerTeamId = managerState.playerTeamId,
        seasonRound = roundIndex + 1,
        season = store.season,
        elapsedWeeks = (currentWeek - 1).coerceAtLeast(0),
        driverOverrides = store.currentDrivers().associateBy { it.id },
        playerGarage = managerState.garage ?: TeamGarageFactory.fromCarState(managerState.car, team.id, store.season),
        facilities = managerState.facilities
    )
    fun circuit() = RaceCircuit(round.round, round.circuit, round.laps, round.baseLapTimeMs, crashRisk=round.crashRisk, reliabilityRisk=round.reliabilityRisk, safetyCarRisk=round.safetyCarRisk)
    fun startWeekend() {
        if (snapshot != null && snapshot?.completed == false && snapshot?.phase == "RACE") { screen = Screen.RACE; return }
        if (currentWeek != round.weekOfSeason) {
            calendarMessage = "A próxima corrida é na semana ${round.weekOfSeason}. Use PULAR 1 SEMANA ou PULAR ATÉ A PRÓXIMA CORRIDA."
            screen = Screen.CALENDAR
            return
        }
        syncAiWeeklyState(currentWeek)
        snapshot = engine.start(participants(), circuit(), team.id); result = null; screen = Screen.QUALIFYING
    }
    fun advanceFreeWeeks(weeks: Int, targetWeek: Int) {
        val delta = (targetWeek - currentWeek).coerceAtLeast(0)
        if (delta == 0) return
        // Novo P&D: as semanas avançam o projeto tecnológico, mas NUNCA alteram diretamente o carro.
        val beforeDesignIds = managerState.research.completedDesigns.map { it.designId }.toSet()
        val beforeActiveIds = managerState.research.activeProjects.map { it.projectId }.toSet()
        managerState = researchEngine.advanceWeeks(managerState, delta, store.season, currentWeek)
        managerState = factoryEngine.advanceWeeks(managerState, delta, currentWeek)
        val newDesigns = managerState.research.completedDesigns.filter { it.designId !in beforeDesignIds }
        val failedIds = beforeActiveIds - managerState.research.activeProjects.map { it.projectId }.toSet() - newDesigns.map { it.designId }.toSet()
        if (newDesigns.isNotEmpty() || failedIds.isNotEmpty()) {
            val notices = newDesigns.map { design -> com.f1teammanager.core.manager.MarketNotification(store.season, targetWeek, "P&D CONCLUÍDO", "${team.name} concluiu ${componentLabel(design.component)} V${design.version}. Design pronto para a Fábrica: P${design.performance} / C${design.reliability}.", true, com.f1teammanager.core.manager.MarketNewsCategory.TEAM_EVOLUTION) }
            managerState = managerState.copy(driverMarket = managerState.driverMarket.copy(notifications = (managerState.driverMarket.notifications + notices).takeLast(100)).normalized())
        }
        // AI teams use the same virtual R&D model used by the race grid. Compare
        // the previous calendar state with the new one and publish only real changes.
        val aiDev = com.f1teammanager.core.manager.AITeamDevelopmentEngine(20261005 + store.season)
        val beforeWeeks = (currentWeek - 1).coerceAtLeast(0)
        val afterWeeks = (targetWeek - 1).coerceAtLeast(0)
        WorldDatabase.teams.filter { it.id != team.id }.forEach { aiTeam ->
            val before = aiDev.simulate(aiTeam, beforeWeeks, store.season)
            val after = aiDev.simulate(aiTeam, afterWeeks, store.season)
            val beforeOverall = (before.aerodynamics + before.chassis + before.engine + before.reliability) / 4
            val afterOverall = (after.aerodynamics + after.chassis + after.engine + after.reliability) / 4
            if (afterOverall != beforeOverall) {
                val component = when {
                    after.chassis != before.chassis -> "Chassi"
                    after.engine != before.engine -> "Unidade de potência"
                    after.frontWing != before.frontWing -> "Asa dianteira"
                    after.rearWing != before.rearWing -> "Asa traseira"
                    after.brakes != before.brakes -> "Freios"
                    after.electricPowerUnit != before.electricPowerUnit -> "Unidade elétrica"
                    else -> "carro"
                }
                val direction = if (afterOverall > beforeOverall) "subiu" else "caiu"
                managerState = managerState.copy(driverMarket = managerState.driverMarket.copy(
                    notifications = managerState.driverMarket.notifications + com.f1teammanager.core.manager.MarketNotification(
                        store.season, targetWeek, "EVOLUÇÃO DE EQUIPE",
                        "${aiTeam.name} evoluiu o $component; Overall da equipe $direction de $beforeOverall para $afterOverall.",
                        true, com.f1teammanager.core.manager.MarketNewsCategory.TEAM_EVOLUTION
                    )
                ).normalized())
            }
        }
        // O mercado da IA funciona durante toda a temporada: cada semana realmente
        // transcorrida precisa ter seu próprio tick para expirar propostas, scouting
        // e permitir novas negociações. Não podemos processar apenas a semana-alvo.
        for (week in (currentWeek + 1)..targetWeek) {
            syncAiWeeklyState(week)
            val beforeMarket = managerState.driverMarket
            val afterMarket = marketEngine.processAiMarketWeek(beforeMarket, store.season, week, team.id)
            val newPlayerDeals = afterMarket.scheduled.filter { deal ->
                deal.startSeason == store.season + 1 &&
                    beforeMarket.scheduled.none { old -> old.driverId == deal.driverId && old.startSeason == deal.startSeason } &&
                    beforeMarket.pending.any { offer -> offer.driverId == deal.driverId && offer.proposerTeamId == team.id && offer.seasonTarget == deal.startSeason }
            }
            managerState = managerState.copy(driverMarket = afterMarket)
            newPlayerDeals.forEach { deal ->
                val fee = marketEngine.signatureFeeFor(afterMarket, deal.driverId, deal.toTeamId, store.season)
                if (fee > 0L) {
                    val driverName = WorldDatabase.allDrivers.firstOrNull { it.id == deal.driverId }?.name ?: "Piloto ${deal.driverId}"
                    managerState = managerState.copy(finance = managerState.finance.transact(-fee, "Taxa de assinatura de $driverName — ${store.season + 1}"))
                }
            }
            WorldDatabase.teams.filter { it.id != team.id }.forEach { aiTeam ->
                aiFinance.applyNewDeals(aiTeam.id, store.season, beforeMarket, afterMarket, marketEngine)
            }
        }
        store.saveCar(teamId, managerState.car)
        store.saveGarage(teamId, managerState.garage ?: TeamGarageFactory.fromCarState(managerState.car, team.id, store.season)); store.saveFacilities(teamId, managerState.facilities)
        store.saveResearch(teamId, managerState.research)
        store.saveFactory(teamId, managerState.factory)
        store.saveDriverMarket(managerState.driverMarket)
        store.saveFinance(teamId, managerState.finance)
        currentWeek = targetWeek
        store.jumpToWeek(targetWeek)
        calendarMessage = "${delta} semana(s) de calendário processada(s). P&D avançou junto com o calendário, incluindo semanas de GP."
    }
    fun skipOneWeek() {
        if (currentWeek >= 56) return
        if (currentWeek == round.weekOfSeason) {
            calendarMessage = "Esta é a semana do GP. Não é possível pular a corrida."
            return
        }
        advanceFreeWeeks(1, currentWeek + 1)
    }
    fun jumpToNextRace() {
        if (currentWeek == round.weekOfSeason) {
            calendarMessage = "Você está na semana do GP. Primeiro simule e conclua esta corrida; só depois poderá avançar para o próximo GP."
            screen = Screen.CALENDAR
            return
        }
        val target = if (currentWeek < round.weekOfSeason) {
            round.weekOfSeason
        } else {
            seasonRounds.getOrNull(roundIndex + 1)?.weekOfSeason
        }
        if (target == null) { calendarMessage = "Você já está na última corrida da temporada."; return }
        advanceFreeWeeks((target-currentWeek).coerceAtLeast(0), target)
    }
    fun simulateQualifying() { snapshot = engine.advanceQualifyingSimulation(12) }
    fun startRace() {
        if (!engine.qualifyingComplete()) return
        val grid = engine.snapshotForUi().grid
        val bestQualifyingPosition = grid?.phases?.getOrNull(2)?.entries
            ?.filter { entry -> store.currentDrivers().firstOrNull { it.id == entry.driverId }?.teamId == team.id }
            ?.minOfOrNull { it.position } ?: 0
        managerState = managerState.copy(finance = store.applyQualifyingBonusOnce(teamId, store.season, round.round, managerState.finance, managerState.sponsors, bestQualifyingPosition))
        snapshot = engine.snapshotForUi()
        screen = Screen.RACE
    }
    fun advanceRace() {
        snapshot = engine.advance()
        if (snapshot?.completed == true) {
            result = engine.result()
            val teamName = team.name
            val mine = result!!.classification.filter { it.teamName == teamName }
            val teamPoints = mine.sumOf { result!!.points[it.driverId] ?: 0 }
            val best = mine.minOfOrNull { if (it.status.startsWith("DNF")) 999 else it.position } ?: 999
            managerState = FinanceEngine().applyRace(managerState,best,teamPoints,mine.all { it.status.startsWith("DNF") })
            aiFinance.ensureAllTeams(store.season, team.id, managerState.driverMarket)
            WorldDatabase.teams.filter { it.id != team.id }.forEach { aiTeam ->
                val entries = result!!.classification.filter { entry ->
                    WorldDatabase.allDrivers.firstOrNull { it.name == entry.driverName }?.teamId == aiTeam.id || entry.teamName == aiTeam.name
                }
                val aiBest = entries.minOfOrNull { if (it.status.startsWith("DNF")) 999 else it.position } ?: 999
                val aiPoints = entries.sumOf { result!!.points[it.driverId] ?: 0 }
                val sponsorState = aiSponsorship.forTeam(aiTeam.id, store.season)
                aiFinance.applyRace(aiTeam.id, store.season, round.round, sponsorState, managerState.driverMarket, aiBest, aiPoints)
            }
            aiSponsorship.advanceAllTeams(store.season, round.round, team.id)
            persistAiState()
            store.recordRace(round.round, result!!, round, snapshot?.grid)
            store.applyDriverRaceEvolution(round.round)
            // CareerPreferences persists the canonical evolution/news state. Refresh
            // the in-memory UI state immediately; otherwise the News screen keeps
            // the pre-GP notification list until the app is recreated.
            store.loadDriverMarket()?.let { persistedMarket ->
                managerState = managerState.copy(driverMarket = persistedMarket)
            }

            // GP30 is the single settlement point of the season. The real UI flow
            // must use exactly the same constructors' ranking/prize rules as the
            // audited season engine. The FinanceEngine has an idempotency guard and
            // the paid-season set is persisted, so reopening the app cannot pay twice.
            if (round.round == seasonRounds.size) {
                // V36: the Android flow and the headless season engine now share
                // one settlement authority. All 40 teams are settled here, not
                // only the player's team. The store's paid-team ledger prevents
                // duplicate payment after process death/reopening.
                store.settleConstructorsSeason(store.season)
                managerState = managerState.copy(finance = store.loadFinance(teamId, managerState.finance))
                SeasonSettlementEngine.settleAll(store.constructorPoints()).forEach { settlement ->
                    if (settlement.teamId != team.id) {
                        aiFinance.applySeasonConstructorsPrize(settlement.teamId, store.season, settlement.position)
                        aiFinance.applyEndOfSeasonFinancialPenalty(settlement.teamId, store.season)
                    }
                }
            }

            store.saveCar(teamId, managerState.car); store.saveFinance(teamId, managerState.finance); store.saveSponsors(teamId, managerState.sponsors)
            screen = Screen.RESULT
        }
    }
    fun returnToCalendarAfterRace() {
        // O avanço do calendário já consumiu todas as semanas que realmente
        // transcorreram. A semana do GP só entra no P&D depois que a corrida
        // é concluída e o jogador avança para a semana seguinte.
        store.completeCurrentRace()
        roundIndex = store.roundIndex
        currentWeek = store.currentWeek

        snapshot = null
        result = null
        if (store.isSeasonEnded()) {
            screen = Screen.HOME
            nav = Nav.HOME
            calendarMessage = "TEMPORADA ${store.season} ENCERRADA. As 30 corridas foram concluídas e o histórico foi arquivado."
        } else {
            screen = Screen.CALENDAR
            nav = Nav.CALENDAR
            calendarMessage = "Corrida concluída. A semana ${currentWeek} continua sendo a semana atual; avance o calendário manualmente até o próximo GP."
        }
    }

    fun startNextSeason() {
        runCatching {
            val closingSeason = store.season
            // Close the old season first: regression belongs to the season that just ended.
            store.applySeasonEndRegression(closingSeason)
            store.startNextSeason()
            managerState = development.startNextSeason(managerState, store.season)
            managerState = FinancialSeasonClosureEngine.applyPlayerPenalty(managerState)
            store.initializeDriverSeasonTargets(managerState.car)
            managerState = managerState.copy(driverMarket = store.loadDriverMarket() ?: marketEngine.initialState(store.season))

            // The market transition defines the contracts active in the new season.
            // Charge annual salaries only after that transition and exactly once.
            val resetFinance = managerState.finance.resetForNewSeason()
            val newFinance = store.applyAnnualDriverSalariesOnce(teamId, store.season, resetFinance, managerState.driverMarket)
            managerState = managerState.copy(finance = newFinance)

            // Persist every canonical state changed by the season boundary. In particular,
            // the physical garage must survive process death and remain the race source.
            store.saveCar(teamId, managerState.car)
            store.saveGarage(teamId, managerState.garage ?: TeamGarageFactory.fromCarState(managerState.car, team.id, store.season))
            store.saveFacilities(teamId, managerState.facilities)
            store.saveResearch(teamId, managerState.research)
            store.saveFactory(teamId, managerState.factory)
            store.saveDriverMarket(managerState.driverMarket)
            store.saveFinance(teamId, managerState.finance)
            store.saveSponsors(teamId, managerState.sponsors)

            roundIndex = store.roundIndex
            currentWeek = store.currentWeek
            calendarMessage = "Nova temporada ${store.season} iniciada. Carro físico, P&D, fábrica, contratos e salários foram sincronizados."
            screen = Screen.HOME
            nav = Nav.HOME
        }.onFailure {
            calendarMessage = it.message ?: "Não foi possível iniciar a nova temporada."
        }
    }
    fun manufactureDesign(design: com.f1teammanager.core.manager.ResearchDesign, quantity: Int, weeks: Int, costPerUnit: Long) {
        runCatching {
            managerState = factoryEngine.start(managerState, design, FactoryEngine.ManufacturingOption(quantity,weeks,costPerUnit), currentWeek)
            store.saveResearch(teamId, managerState.research); store.saveFactory(teamId, managerState.factory); store.saveGarage(teamId, managerState.garage ?: TeamGarageFactory.fromCarState(managerState.car, team.id, store.season)); store.saveFinance(teamId, managerState.finance)
            carMessage = "Fábrica: ${componentLabel(design.component)} V${design.version} x$quantity em produção. Nenhum carro foi alterado."
        }.onFailure { carMessage = it.message ?: "Não foi possível iniciar a fabricação." }
    }
    fun installPiece(piece: com.f1teammanager.core.manager.CarPiece, target: com.f1teammanager.core.manager.GarageCarId) {
        runCatching {
            val garage = managerState.garage ?: TeamGarageFactory.fromCarState(managerState.car, team.id, store.season)
            require(garage.inventory.any { it.pieceId == piece.pieceId }) { "Peça não está no estoque." }
            managerState = managerState.copy(garage = garage.install(piece, target))
            store.saveGarage(teamId, managerState.garage!!); store.saveFacilities(teamId, managerState.facilities)
            carMessage = "${componentLabel(piece.component)} V${piece.version} instalada no ${if (target == com.f1teammanager.core.manager.GarageCarId.CAR_1) "Carro 1" else "Carro 2"}."
        }.onFailure { carMessage = it.message ?: "Não foi possível instalar a peça." }
    }
    fun startDevelopment(component: CarComponent, focus: ResearchFocus, complexity: ResearchComplexity) {
        runCatching {
            managerState = researchEngine.start(managerState, component, focus, complexity, currentWeek)
            val project = managerState.research.activeProjects.lastOrNull() ?: error("Projeto não criado")
            store.saveResearch(teamId, managerState.research); store.saveFactory(teamId, managerState.factory); store.saveFinance(teamId, managerState.finance)
            carMessage = "P&D ${componentLabel(component)} V${project.version} iniciado: ${project.totalWeeks} semana(s), ${researchEngine.focusLabel(focus)}. O carro NÃO muda até uma peça ser fabricada."
        }.onFailure { carMessage = it.message ?: "Não foi possível iniciar o projeto de P&D." }
    }
    fun investNextSeason(amount: Long) {
        runCatching { managerState = development.investNextSeason(managerState, amount); store.saveCar(teamId, managerState.car); store.saveFinance(teamId, managerState.finance); carMessage = "€ ${amount/1_000_000}M investidos no carro ${store.season + 1}." }
            .onFailure { carMessage = it.message ?: "Não foi possível investir no próximo carro." }
    }
    fun setNextSeasonFocus(focus: CarDevelopmentFocus) {
        managerState = development.setNextSeasonFocus(managerState, focus)
        store.saveCar(teamId, managerState.car)
    }
    fun openHistory(r:Int) { historyRound=r; historyResult=store.raceHistory(r); screen=Screen.HISTORY }
    fun makeMarketProposal(driverId: Int, replacementDriverId: Int?, years: Int, salary: Long, role: DriverTeamRole) {
        val driver = WorldDatabase.allDrivers.first { it.id == driverId }
        runCatching {
            val (next, offer) = marketEngine.makeOffer(managerState.driverMarket, driverId, team.id, years, salary, role, store.season, currentWeek = currentWeek, replaceDriverId = replacementDriverId)
            managerState = managerState.copy(driverMarket=next)
            store.saveDriverMarket(managerState.driverMarket)
            store.saveFinance(teamId, managerState.finance)
            marketMessage = "Proposta enviada para ${driver.name}. O piloto responderá em 2 ou 3 semanas."
        }.onFailure { marketMessage = it.message ?: "Não foi possível negociar agora." }
    }

    fun makeMarketInterest(driverId: Int, replacementDriverId: Int?) {
        makeMarketProposal(driverId, replacementDriverId, 1, marketEngine.salaryFor(driverId), DriverTeamRole.EQUAL)
    }

    fun renewMarketDriver(driverId: Int, years: Int, salary: Long, role: DriverTeamRole) {
        val driver = WorldDatabase.allDrivers.first { it.id == driverId }
        runCatching {
            val signatureFee = marketEngine.signatureFeeForRenewal(managerState.driverMarket, driverId, team.id, store.season)
            managerState = managerState.copy(driverMarket = marketEngine.renew(managerState.driverMarket, driverId, team.id, years, salary, role, store.season, currentWeek))
            managerState = managerState.copy(finance=managerState.finance.transact(-signatureFee, "Taxa de assinatura — renovação de ${driver.name} — ${store.season + 1}"))
            store.saveDriverMarket(managerState.driverMarket)
            store.saveFinance(teamId, managerState.finance)
            marketMessage = "Renovação de ${driver.name} preparada para ${store.season + 1}. Taxa de assinatura: € ${signatureFee/1_000_000.0}. O salário começa a ser cobrado em ${store.season + 1}."
        }.onFailure { marketMessage = it.message ?: "Não foi possível renovar o piloto." }
    }

    fun acceptIncomingMarketOffer(offer: com.f1teammanager.core.manager.DriverOffer) {
        runCatching {
            val signatureFee = marketEngine.signatureFeeFor(managerState.driverMarket, offer.driverId, team.id, store.season)
            managerState = managerState.copy(driverMarket = marketEngine.acceptIncomingOffer(managerState.driverMarket, offer, store.season, currentWeek))
            managerState = managerState.copy(finance=managerState.finance.transact(-signatureFee, "Taxa de assinatura — transferência de ${WorldDatabase.allDrivers.firstOrNull { it.id == offer.driverId }?.name ?: "Piloto"} — ${offer.seasonTarget}"))
            store.saveDriverMarket(managerState.driverMarket)
            store.saveFinance(teamId, managerState.finance)
            marketMessage = "Oferta aceita. ${WorldDatabase.allDrivers.firstOrNull { it.id == offer.driverId }?.name ?: "Piloto"} irá para ${WorldDatabase.teams.firstOrNull { it.id == offer.toTeamId }?.name ?: "a nova equipe"} em ${offer.seasonTarget}. Taxa de assinatura: € ${signatureFee/1_000_000.0}M."
        }.onFailure { marketMessage = it.message ?: "Não foi possível aceitar a proposta." }
    }

    fun rejectIncomingMarketOffer(offer: com.f1teammanager.core.manager.DriverOffer) {
        runCatching {
            managerState = managerState.copy(driverMarket = marketEngine.rejectIncomingOffer(managerState.driverMarket, offer, store.season, currentWeek))
            store.saveDriverMarket(managerState.driverMarket)
            marketMessage = "Proposta recusada."
        }.onFailure { marketMessage = it.message ?: "Não foi possível recusar a proposta." }
    }

    fun acceptMarketCounter(offer: com.f1teammanager.core.manager.DriverOffer) {
        runCatching {
            val signatureFee = marketEngine.signatureFeeFor(managerState.driverMarket, offer.driverId, team.id, store.season)
            managerState = managerState.copy(driverMarket = marketEngine.acceptCounterOffer(managerState.driverMarket, offer, store.season, currentWeek))
            managerState = managerState.copy(finance=managerState.finance.transact(-signatureFee, "Taxa de assinatura de ${WorldDatabase.allDrivers.firstOrNull { it.id == offer.driverId }?.name ?: "Piloto"} — ${offer.seasonTarget}"))
            store.saveDriverMarket(managerState.driverMarket)
            store.saveFinance(teamId, managerState.finance)
            marketMessage = "Contraproposta aceita. ${WorldDatabase.allDrivers.firstOrNull { it.id == offer.driverId }?.name ?: "Piloto"} assinou para ${offer.seasonTarget}. Taxa de assinatura: € ${signatureFee/1_000_000.0}. Salário começa em ${offer.seasonTarget}."
        }.onFailure { marketMessage = it.message ?: "Não foi possível aceitar a contraproposta." }
    }

    fun rejectMarketCounter(offer: com.f1teammanager.core.manager.DriverOffer) {
        runCatching {
            managerState = managerState.copy(driverMarket = marketEngine.rejectCounterOffer(managerState.driverMarket, offer, store.season, currentWeek))
            store.saveDriverMarket(managerState.driverMarket)
            marketMessage = "Contraproposta recusada."
        }.onFailure { marketMessage = it.message ?: "Não foi possível recusar a contraproposta." }
    }

    fun makeMarketCounter(previous: com.f1teammanager.core.manager.DriverOffer, replacementDriverId: Int?, years: Int, salary: Long, role: DriverTeamRole) {
        val driver = WorldDatabase.allDrivers.first { it.id == previous.driverId }
        runCatching {
            val (next, offer) = marketEngine.counterOffer(managerState.driverMarket, previous, store.season, currentWeek, salary, years, role, replacementDriverId)
            managerState = managerState.copy(driverMarket=next)
            store.saveDriverMarket(managerState.driverMarket); store.saveFinance(teamId, managerState.finance)
            marketMessage = when(offer.status) {
                NegotiationStatus.ACCEPTED -> "${driver.name} aceitou a contraproposta. Pré-contrato para ${store.season+1} assinado."
                NegotiationStatus.COUNTER -> "${driver.name} apresentou uma nova contraproposta. Rodada ${offer.round}/3."
                NegotiationStatus.REJECTED -> "${driver.name} recusou a proposta após a rodada ${offer.round}/3."
                else -> "Negociação atualizada."
            }
        }.onFailure { marketMessage = it.message ?: "Não foi possível continuar a negociação." }
    }

    fun runScouting(driverId:Int) {
        runCatching {
            val (next, report)=marketEngine.scout(managerState.driverMarket,driverId,team.id,currentWeek,store.season,managerState.facilities.level(FacilityType.SCOUTING))
            managerState=managerState.copy(driverMarket=next,finance=managerState.finance.transact(-report.cost,"Scouting de piloto ${driverId}"))
            store.saveDriverMarket(managerState.driverMarket); store.saveFinance(teamId,managerState.finance)
            marketMessage="Scouting concluído: salário ${formatMoney(report.expectedSalary)} • valor ${formatMoney(report.marketValue)} • interesse ${report.interest}/100."
        }.onFailure { marketMessage=it.message ?: "Não foi possível realizar o scouting." }
    }

    fun signSponsor(sponsor:SponsorContract) {
        runCatching { managerState=ManagerMarketEngine().signSponsor(managerState,sponsor,sponsor.slot); store.saveFinance(teamId,managerState.finance); store.saveSponsors(teamId,managerState.sponsors); sponsorMessage="Contrato ${sponsor.name} aceito por ${sponsor.races} ${if(sponsor.races==1) "corrida" else "corridas"}." }
            .onFailure { sponsorMessage=it.message ?: "Não foi possível aceitar o contrato." }
    }

    fun selectTeam(id: Int) { store.startNewCareer(id); marketMessage = ""; calendarMessage = ""; managerState=initialManagerState(id,store); teamId = id; roundIndex = 0; currentWeek = store.currentWeek; hasCareer = true; screen = Screen.HOME; nav = Nav.HOME }

    MaterialTheme(colorScheme = darkColorScheme(background = Bg, surface = Panel, primary = Red, onPrimary = Color.White, onSurface = Color.White)) {
        Surface(Modifier.fillMaxSize(), color = Bg) {
            fun newsKey(n: com.f1teammanager.core.manager.MarketNotification): String =
        "${n.season}|${n.week}|${n.title}|${n.message}"

    fun unreadNewsCount(): Int {
        val read = store.loadReadNewsKeys()
        return managerState.driverMarket.notifications.count { it.season == store.season && newsKey(it) !in read }
    }

    fun markNewsRead() {
        val current = managerState.driverMarket.notifications.filter { it.season == store.season }
        store.markNewsRead(current.map(::newsKey))
        managerState = managerState.copy(driverMarket = store.loadDriverMarket() ?: managerState.driverMarket)
    }

    when (screen) {
                Screen.SELECT_TEAM -> TeamSelect(::selectTeam)
                Screen.HOME -> AppScaffold("${team.name.uppercase()} • ${store.season}", nav, { nav = it; screen = when(it){Nav.HOME->Screen.HOME;Nav.TEAM->Screen.TEAM;Nav.CAR->Screen.CAR;Nav.CALENDAR->Screen.CALENDAR;Nav.STANDINGS->Screen.STANDINGS} }, onMore={ screen=Screen.MANAGEMENT }) { Home(team.name, CarCatalog.forTeam(team.id), drivers, round, currentWeek, store, managerState, snapshot?.phase == "RACE" && snapshot?.completed == false, onStart=::startWeekend, onDrivers={screen=Screen.DRIVERS}, onWeekend={screen=Screen.WEEKEND}, onMarket={screen=Screen.MARKET}, onFinance={screen=Screen.FINANCE}, onStandings={screen=Screen.STANDINGS}, onNews={markNewsRead(); screen=Screen.NEWS}, onCar={nav=Nav.CAR;screen=Screen.CAR}, onSkipWeek=::skipOneWeek, onStartNextSeason=::startNextSeason, onJumpNextRace=::jumpToNextRace) }
                Screen.TEAM -> AppScaffold("EQUIPE", nav, { nav=it; screen=when(it){Nav.HOME->Screen.HOME;Nav.TEAM->Screen.TEAM;Nav.CAR->Screen.CAR;Nav.CALENDAR->Screen.CALENDAR;Nav.STANDINGS->Screen.STANDINGS} }, onMore={screen=Screen.MANAGEMENT}) { Team(team.name, team.engine, team.reliability, drivers, managerState.facilities, onDrivers={screen=Screen.DRIVERS}, onMarket={screen=Screen.MARKET}, onUpgrade={ type -> runCatching { managerState = FacilityEngine.upgrade(managerState,type); store.saveFacilities(teamId,managerState.facilities); store.saveFinance(teamId,managerState.finance) }.onFailure { calendarMessage = it.message ?: "Não foi possível melhorar a instalação." } }) }
                Screen.DRIVERS -> DetailScaffold("PILOTOS", {screen=Screen.TEAM}) { Drivers(drivers) }
                Screen.CAR -> AppScaffold("CARRO / P&D", nav, { nav=it; screen=when(it){Nav.HOME->Screen.HOME;Nav.TEAM->Screen.TEAM;Nav.CAR->Screen.CAR;Nav.CALENDAR->Screen.CALENDAR;Nav.STANDINGS->Screen.STANDINGS} }, onMore={screen=Screen.MANAGEMENT}) { Car(CarCatalog.forTeam(team.id), managerState, currentWeek, carMessage, ::startDevelopment, ::manufactureDesign, ::installPiece, ::investNextSeason, ::setNextSeasonFocus) }
                Screen.CALENDAR -> AppScaffold("CALENDÁRIO", nav, { nav=it; screen=when(it){Nav.HOME->Screen.HOME;Nav.TEAM->Screen.TEAM;Nav.CAR->Screen.CAR;Nav.CALENDAR->Screen.CALENDAR;Nav.STANDINGS->Screen.STANDINGS} }, onMore={screen=Screen.MANAGEMENT}) { Calendar(roundIndex, store.roundIndex, currentWeek, store.season, calendarMessage, ::openHistory, { store.raceHistory(it) != null }, ::skipOneWeek, ::jumpToNextRace) }
                Screen.STANDINGS -> AppScaffold("CAMPEONATO", nav, { nav=it; screen=when(it){Nav.HOME->Screen.HOME;Nav.TEAM->Screen.TEAM;Nav.CAR->Screen.CAR;Nav.CALENDAR->Screen.CALENDAR;Nav.STANDINGS->Screen.STANDINGS} }, onMore={screen=Screen.MANAGEMENT}) { Standings(team.id, store) }
                Screen.FINANCE -> DetailScaffold("FINANÇAS", {screen=Screen.HOME}) { Finance(store, team.id, managerState, sponsorMessage, ::signSponsor) }
                Screen.MARKET -> DetailScaffold("MERCADO DE PILOTOS", {screen=Screen.TEAM}) { DriverMarket(store, team.id, currentWeek, marketDriverId, managerState.driverMarket, marketMessage, { marketDriverId = it }, ::makeMarketInterest, ::makeMarketProposal, ::makeMarketCounter, ::acceptMarketCounter, ::rejectMarketCounter, ::renewMarketDriver, ::acceptIncomingMarketOffer, ::rejectIncomingMarketOffer, ::runScouting) }
                Screen.WEEKEND -> DetailScaffold("FIM DE SEMANA", {screen=Screen.HOME}) { Weekend(round, currentWeek, ::startWeekend) }
                Screen.QUALIFYING -> DetailScaffold("QUALIFICAÇÃO", { screen = Screen.HOME }) {
                    Qualifying(
                        snapshot!!,
                        simulate = ::simulateQualifying,
                        start = ::startRace
                    )
                }
                Screen.RACE -> DetailScaffold("PIT WALL", { screen = Screen.CALENDAR; nav = Nav.CALENDAR }) { Race(snapshot!!, drivers, ::advanceRace, { id, mode -> snapshot = engine.setStrategy(id, mode) }, { id, tyre -> snapshot = engine.pitNow(id, tyre) }, { id, plan -> snapshot = engine.pitWithPlan(id, plan) }, { id, plan -> snapshot = engine.setTyrePlan(id, plan) }, { action -> snapshot = engine.choose(action) }) }
                Screen.RESULT -> DetailScaffold("RESULTADO", { returnToCalendarAfterRace() }) { Result(result!!, team.id, store, ::returnToCalendarAfterRace) }
                Screen.HISTORY -> DetailScaffold("CLASSIFICAÇÃO ARQUIVADA", { screen = Screen.CALENDAR }) { HistoryResult(historyRound, historyResult) }
                Screen.HISTORY_CENTER -> DetailScaffold("HISTÓRIA", { screen = Screen.HOME }) { HistoryScreen(store) }
                Screen.NEWS -> DetailScaffold("NOTÍCIAS", { screen = Screen.HOME }) { MarketNews(managerState.driverMarket, store.season, ::markNewsRead) }
                Screen.HALL_OF_FAME -> DetailScaffold("HALL DA FAMA", { screen = Screen.HOME }) { HallOfFameScreen(store) }
                Screen.RECORDS -> DetailScaffold("RECORDES", { screen = Screen.HOME }) { RecordsScreen(store) }
                Screen.SEASON -> DetailScaffold("TEMPORADA", { screen = Screen.HOME }) { SeasonArchive(store) }
                Screen.MANAGEMENT -> DetailScaffold("GESTÃO", { screen = Screen.HOME }) { ManagementHub(snapshot?.phase == "RACE" && snapshot?.completed == false, onDrivers={screen=Screen.DRIVERS}, onMarket={screen=Screen.MARKET}, onFinance={screen=Screen.FINANCE}, onSeason={screen=Screen.SEASON}, onCar={screen=Screen.CAR}, onStandings={screen=Screen.STANDINGS}, onCalendar={screen=Screen.CALENDAR}, onWeekend={screen=Screen.WEEKEND}, onRace={screen=Screen.RACE}, onHistory={screen=Screen.HISTORY_CENTER}, onNews={markNewsRead(); screen=Screen.NEWS}, onHallOfFame={screen=Screen.HALL_OF_FAME}, onRecords={screen=Screen.RECORDS}) }
            }
        }
    }
}

@Composable private fun AppScaffold(title:String, nav:Nav, select:(Nav)->Unit, onMore:()->Unit, content:@Composable ColumnScope.()->Unit) {
    Column(Modifier.fillMaxSize().statusBarsPadding()) { TopBar(title, onMore); Column(Modifier.weight(1f)) { content() }; BottomNav(nav, select) }
}
@Composable private fun DetailScaffold(title:String, back:()->Unit, content:@Composable ColumnScope.()->Unit) { Column(Modifier.fillMaxSize().statusBarsPadding()) { BackTopBar(title, back); Column(Modifier.weight(1f)) { content() } } }
@Composable private fun BackTopBar(title:String, back:()->Unit) { Row(Modifier.fillMaxWidth().padding(horizontal=14.dp,vertical=10.dp),verticalAlignment=Alignment.CenterVertically){Text("‹",color=Color.White,fontSize=34.sp,modifier=Modifier.clickable{back()}.padding(horizontal=6.dp));Text(title,color=Color.White,fontWeight=FontWeight.Bold,maxLines=1,overflow=TextOverflow.Ellipsis,modifier=Modifier.weight(1f));Text("F1 MANAGER",color=Red,fontWeight=FontWeight.Black,fontSize=12.sp)}}
@Composable private fun TopBar(title:String, action:()->Unit) { Row(Modifier.fillMaxWidth().padding(horizontal=16.dp,vertical=12.dp), verticalAlignment=Alignment.CenterVertically, horizontalArrangement=Arrangement.SpaceBetween) { Text("F1 MANAGER",color=Red,fontWeight=FontWeight.Black,letterSpacing=1.sp); Text(title,color=Color.White,fontWeight=FontWeight.Bold,maxLines=1,overflow=TextOverflow.Ellipsis); Text("⋮",color=Color.White,fontSize=25.sp,modifier=Modifier.clickable{action()}) } }
@Composable private fun BottomNav(selected:Nav, select:(Nav)->Unit) { Row(Modifier.fillMaxWidth().navigationBarsPadding().background(Color(0xFF101216)).padding(6.dp), horizontalArrangement=Arrangement.SpaceEvenly) { listOf(Nav.HOME to "⌂",Nav.TEAM to "♟",Nav.CAR to "▰",Nav.CALENDAR to "▦",Nav.STANDINGS to "≡").forEach{(n,l)-> Column(horizontalAlignment=Alignment.CenterHorizontally,modifier=Modifier.weight(1f).clickable{select(n)}.padding(5.dp)){Text(l,color=if(selected==n)Red else Muted,fontSize=20.sp);Text(n.name,color=if(selected==n)Color.White else Muted,fontSize=9.sp,fontWeight=FontWeight.Bold)}} } }

@Composable
private fun Home(
    team: String,
    car: com.f1teammanager.core.season.CarSpec,
    drivers: List<com.f1teammanager.core.season.DriverDefinition>,
    round: RoundDefinition,
    currentWeek: Int,
    store: CareerPreferences,
    managerState: TeamManagerState,
    raceInProgress: Boolean,
    onStart: () -> Unit,
    onDrivers: () -> Unit,
    onWeekend: () -> Unit,
    onMarket: () -> Unit,
    onFinance: () -> Unit,
    onStandings: () -> Unit,
    onNews: () -> Unit,
    onCar: () -> Unit,
    onSkipWeek: () -> Unit,
    onJumpNextRace: () -> Unit,
    onStartNextSeason: () -> Unit
) {
    val teamId = WorldDatabase.teams.first { it.name == team }.id
    val teamPoints = store.constructorPoints()[teamId] ?: 0
    val atRaceWeek = currentWeek == round.weekOfSeason

    LazyColumn(
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        if (store.isSeasonEnded()) {
            item {
                Card(
                    Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(Panel),
                    border = BorderStroke(1.dp, Red)
                ) {
                    Column(
                        Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(7.dp)
                    ) {
                        Text(
                            "TEMPORADA ${store.season} ENCERRADA",
                            color = Red,
                            fontWeight = FontWeight.Black,
                            fontSize = 15.sp
                        )
                        Text(
                            "As 30 corridas foram concluídas e o histórico foi arquivado.",
                            color = Color.White,
                            fontSize = 10.sp
                        )
                        Button(
                            onClick = onStartNextSeason,
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Red,
                                contentColor = Color.White
                            )
                        ) {
                            Text("IR PARA NOVA TEMPORADA", fontWeight = FontWeight.Black)
                        }
                    }
                }
            }
        }

        item { TeamHeroCard(team, car.model) }

        item {
            val readNewsKeys = store.loadReadNewsKeys()
            val unread = managerState.driverMarket.notifications.filter { it.season == store.season && "${it.season}|${it.week}|${it.title}|${it.message}" !in readNewsKeys }
            val marketNewsCount = unread.size
            val marketResponseCount = unread.count { it.title == "RESPOSTA DO PILOTO" || it.title == "DECISÃO DA EQUIPE" || it.title == "CONTRAPROPOSTA DA EQUIPE" }
            val rdCompletionCount = unread.count { it.title == "P&D CONCLUÍDO" }
            val sponsorshipSlotsFree = managerState.sponsors.count { it.active } < 5
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (marketResponseCount > 0) {
                    Button(onClick = onNews, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Red, contentColor = Color.White), contentPadding = PaddingValues(vertical = 8.dp)) {
                        Text("📨 MERCADO $marketResponseCount", fontWeight = FontWeight.Black, fontSize = 9.sp)
                    }
                } else if (marketNewsCount > 0) {
                    Button(onClick = onNews, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Red, contentColor = Color.White), contentPadding = PaddingValues(vertical = 8.dp)) {
                        Text("📰 NOTÍCIAS $marketNewsCount", fontWeight = FontWeight.Black, fontSize = 9.sp)
                    }
                }
                if (rdCompletionCount > 0) {
                    Button(onClick = onNews, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Panel2, contentColor = Color.White), border = BorderStroke(1.dp, Red), contentPadding = PaddingValues(vertical = 8.dp)) {
                        Text("🔧 P&D CONCLUÍDO $rdCompletionCount", fontWeight = FontWeight.Black, fontSize = 9.sp)
                    }
                } else if (sponsorshipSlotsFree) {
                    Button(onClick = onFinance, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Panel2, contentColor = Color.White), border = BorderStroke(1.dp, Red), contentPadding = PaddingValues(vertical = 8.dp)) {
                        Text("💰 PATROCÍNIO DISPONÍVEL", fontWeight = FontWeight.Black, fontSize = 9.sp)
                    }
                }
            }
        }

        item {
            SectionTitle("SITUAÇÃO DO CAMPEONATO")
            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(Panel)) {
                Row(
                    Modifier.fillMaxWidth().padding(8.dp),
                    horizontalArrangement = Arrangement.spacedBy(7.dp)
                ) {
                    StatCard("CONSTRUTORES", "P${constructorPosition(teamId, store)}", "$teamPoints PTS", Modifier.weight(1f))
                    StatCard("PILOTO 1", drivers.firstOrNull()?.name ?: "—", "titular", Modifier.weight(1f))
                    StatCard("ORÇAMENTO", formatMoney(managerState.finance.budget), "disponível", Modifier.weight(1f))
                }
            }
        }

        item {
            SectionTitle(if (store.isSeasonEnded()) "TEMPORADA ENCERRADA" else "PRÓXIMA CORRIDA")
            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(Panel)) {
                Column(Modifier.padding(13.dp)) {
                    if (store.isSeasonEnded()) {
                        Text("${store.season} concluída", color = Red, fontSize = 21.sp, fontWeight = FontWeight.Black)
                        Text(
                            "O calendário de ${store.season} foi encerrado e o histórico está arquivado.",
                            color = Muted,
                            fontSize = 10.sp,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    } else {
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("ROUND ${round.round}", color = Red, fontWeight = FontWeight.Black)
                            Text("SEMANA ${round.weekOfSeason}", color = Color.White, fontWeight = FontWeight.Black, fontSize = 11.sp)
                        }
                        RaceImage(round, Modifier.fillMaxWidth().aspectRatio(1f).padding(top = 8.dp))
                        Text(round.grandPrix, color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(top = 7.dp))
                        Text(round.circuit, color = Muted, fontSize = 12.sp)
                        Row(
                            Modifier.fillMaxWidth().padding(top = 9.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("${round.laps} VOLTAS", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Text(seasonDateLabel(round, store.season), color = Muted, fontSize = 10.sp)
                        }
                        Button(
                            onClick = onStart,
                            enabled = raceInProgress || atRaceWeek,
                            modifier = Modifier.fillMaxWidth().padding(top = 9.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Red,
                                contentColor = Color.White,
                                disabledContainerColor = Panel2,
                                disabledContentColor = Muted
                            )
                        ) {
                            Text(
                                if (raceInProgress) "RETOMAR PIT WALL"
                                else if (atRaceWeek) "ABRIR FIM DE SEMANA"
                                else "IR PARA CALENDÁRIO",
                                fontWeight = FontWeight.Black
                            )
                        }
                    }
                }
            }
        }

        item {
            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(Panel)) {
                Column(Modifier.padding(12.dp)) {
                    Text("CALENDÁRIO", color = Red, fontWeight = FontWeight.Black, fontSize = 11.sp)
                    Text(
                        "O P&D avança com as semanas do calendário, inclusive semanas de GP. Nunca é possível ultrapassar um GP sem simular a corrida.",
                        color = Muted,
                        fontSize = 9.sp,
                        modifier = Modifier.padding(top = 3.dp)
                    )
                    Row(
                        Modifier.fillMaxWidth().padding(top = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(7.dp)
                    ) {
                        Button(
                            onClick = onSkipWeek,
                            enabled = currentWeek < 56 && !atRaceWeek,
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Panel2,
                                contentColor = Color.White,
                                disabledContainerColor = Color(0xFF101116),
                                disabledContentColor = Muted
                            ),
                            contentPadding = PaddingValues(vertical = 8.dp)
                        ) { Text("PULAR 1 SEMANA", fontSize = 8.sp, fontWeight = FontWeight.Black) }

                        Button(
                            onClick = onJumpNextRace,
                            enabled = currentWeek < round.weekOfSeason,
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Red,
                                contentColor = Color.White,
                                disabledContainerColor = Color(0xFF3A0D0D),
                                disabledContentColor = Muted
                            ),
                            contentPadding = PaddingValues(vertical = 8.dp)
                        ) { Text("PULAR ATÉ PRÓXIMO GP", fontSize = 8.sp, fontWeight = FontWeight.Black) }
                    }
                }
            }
        }

        item {
            SectionTitle("ACESSO RÁPIDO")
            val shortcuts = listOf(
                "FIM DE SEMANA" to onWeekend,
                "PILOTOS" to onDrivers,
                "MERCADO" to onMarket,
        "CENTRAL DE NOTÍCIAS" to onNews,
                "FINANÇAS" to onFinance,
                "CAMPEONATO" to onStandings,
                "CARRO / P&D" to onCar
            )
            Column(
                verticalArrangement = Arrangement.spacedBy(7.dp),
                modifier = Modifier.padding(top = 3.dp)
            ) {
                shortcuts.chunked(3).forEach { row ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        row.forEach { (label, action) ->
                            Button(
                                onClick = action,
                                modifier = Modifier.weight(1f).height(48.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Panel2, contentColor = Color.White),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 4.dp)
                            ) {
                                Text(label, fontSize = 8.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                            }
                        }
                    }
                }
            }
        }

        item {
            SectionTitle("EQUIPE")
            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(Panel)) {
                Column(Modifier.padding(12.dp)) {
                    Text("PILOTOS TITULARES", color = Red, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    Row(
                        Modifier.fillMaxWidth().padding(top = 7.dp),
                        horizontalArrangement = Arrangement.spacedBy(7.dp)
                    ) {
                        drivers.take(2).forEachIndexed { index, d ->
                            Column(
                                Modifier.weight(1f).background(Panel2, RoundedCornerShape(8.dp)).padding(10.dp)
                            ) {
                                Text(d.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text("#${index + 1} • Titular", color = Muted, fontSize = 9.sp)
                                Text("P${driverChampionshipPosition(d.id, store)}", color = Color.White, fontWeight = FontWeight.Black, fontSize = 15.sp, modifier = Modifier.padding(top = 4.dp))
                            }
                        }
                    }
                    Button(
                        onClick = onDrivers,
                        modifier = Modifier.fillMaxWidth().padding(top = 7.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Panel2, contentColor = Color.White)
                    ) { Text("VER PERFIL COMPLETO →", fontWeight = FontWeight.Black, fontSize = 9.sp) }
                }
            }
        }
    }
}

@Composable private fun TeamHeroCard(team:String,model:String){Box(Modifier.fillMaxWidth().height(138.dp).clip(RoundedCornerShape(12.dp)).background(Panel).border(1.dp,Red,RoundedCornerShape(12.dp))){Row(Modifier.fillMaxSize().padding(16.dp),verticalAlignment=Alignment.CenterVertically){TeamLogo(team,WorldDatabase.teams.firstOrNull{it.name.equals(team,ignoreCase=true)}?.id ?: 0,Modifier.size(86.dp));Spacer(Modifier.width(14.dp));Column(Modifier.weight(1f)){Text(team.uppercase(),color=Color.White,fontSize=23.sp,fontWeight=FontWeight.Black);Text(model,color=Red,fontSize=17.sp,fontWeight=FontWeight.Black);Text("MODELO ESPECÍFICO DA EQUIPE",color=Muted,fontSize=10.sp,modifier=Modifier.padding(top=4.dp))}}}}

@Composable private fun Team(name:String,engine:Int,reliability:Int,drivers:List<com.f1teammanager.core.season.DriverDefinition>,facilities:TeamFacilitiesState,onDrivers:()->Unit,onMarket:()->Unit,onUpgrade:(FacilityType)->Unit){
    LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
        item { HeaderBlock(name,"GESTÃO DA EQUIPE") }
        item {
            Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(Panel)) {
                Row(Modifier.fillMaxWidth().padding(12.dp),verticalAlignment=Alignment.CenterVertically) {
                    TeamLogo(name,WorldDatabase.teams.firstOrNull{it.name.equals(name,ignoreCase=true)}?.id ?: 0,Modifier.size(120.dp))
                    Spacer(Modifier.width(14.dp))
                    Column { Text(name.uppercase(),color=Color.White,fontWeight=FontWeight.Black,fontSize=20.sp); Text("ESCUDO DA EQUIPE",color=Muted,fontSize=9.sp) }
                }
            }
        }
        item { MetricPanel("FORNECEDOR / MOTOR","Engine",engine,"Confiabilidade",reliability) }
        item { SectionTitle("PILOTOS TITULARES") }
        items(drivers) { DriverMini(it) }
        item { Button(onClick=onDrivers,modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=Red,contentColor=Color.White)){ Text("ABRIR PERFIS") } }
        item { SectionTitle("GESTÃO") }
        item { Row(Modifier.fillMaxWidth().background(Panel,RoundedCornerShape(8.dp)).clickable{onMarket()}.padding(14.dp),horizontalArrangement=Arrangement.SpaceBetween){ Column { Text("MERCADO DE PILOTOS",color=Color.White,fontWeight=FontWeight.Bold); Text("Contratos, salários e disponibilidade",color=Muted,fontSize=11.sp) }; Text("›",color=Red,fontSize=24.sp) } }
        item { SectionTitle("INSTALAÇÕES") }
        items(FacilityType.values().toList()) { type ->
            val level=facilities.level(type)
            val cost=FacilityEngine.upgradeCost(level)
            Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(Panel)) {
                    Column(Modifier.padding(12.dp)) {
                        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) {
                            Column(Modifier.weight(1f)) { Text(FacilityEngine.label(type).uppercase(),color=Color.White,fontWeight=FontWeight.Bold,fontSize=11.sp); Text(FacilityEngine.description(type),color=Muted,fontSize=9.sp) }
                            Text("Nível $level",color=Red,fontWeight=FontWeight.Black,fontSize=11.sp)
                        }
                        LinearProgressIndicator(progress={level/10f},modifier=Modifier.fillMaxWidth().padding(top=8.dp),color=Red,trackColor=Line)
                        if(level<10) {
                            Row(Modifier.fillMaxWidth().padding(top=8.dp),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically) {
                                Text("Próximo: €${(cost ?: 0L)/1_000_000}M",color=Muted,fontSize=9.sp)
                                Button(onClick={onUpgrade(type)},colors=ButtonDefaults.buttonColors(containerColor=Panel2,contentColor=Color.White),contentPadding=PaddingValues(horizontal=10.dp,vertical=3.dp)){ Text("MELHORAR",fontSize=9.sp) }
                            }
                        } else { Text("NÍVEL MÁXIMO",color=Muted,fontSize=9.sp,modifier=Modifier.padding(top=7.dp)) }
                    }
                }
            }
        }
    }
@Composable
private fun MetricPanel(title:String,leftLabel:String,leftValue:Int,rightLabel:String,rightValue:Int){
    Card(Modifier.fillMaxWidth(), colors=CardDefaults.cardColors(Panel)) {
        Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement=Arrangement.spacedBy(10.dp)) {
            Column(Modifier.weight(1f)) {
                Text(title, color=Muted, fontSize=9.sp, fontWeight=FontWeight.Bold)
                Text(leftLabel, color=Color.White, fontSize=10.sp)
                Text(leftValue.toString(), color=Red, fontSize=18.sp, fontWeight=FontWeight.Black)
            }
            Column(Modifier.weight(1f)) {
                Text("CONFIABILIDADE", color=Muted, fontSize=9.sp, fontWeight=FontWeight.Bold)
                Text(rightLabel, color=Color.White, fontSize=10.sp)
                Text(rightValue.toString(), color=if(rightValue >= 76) Green else Red, fontSize=18.sp, fontWeight=FontWeight.Black)
            }
        }
    }
}

@Composable
private fun DriverMini(d:com.f1teammanager.core.season.DriverDefinition){
    Card(Modifier.fillMaxWidth(), colors=CardDefaults.cardColors(Panel)) {
        Row(Modifier.fillMaxWidth().padding(11.dp), verticalAlignment=Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(d.name, color=Color.White, fontWeight=FontWeight.Bold, fontSize=12.sp)
                Text("${d.driverClass} • ${d.evolution}", color=Muted, fontSize=9.sp)
            }
            Text("${driverOverall(d)}", color=Red, fontWeight=FontWeight.Black, fontSize=18.sp)
        }
    }
}

@Composable
private fun Drivers(drivers:List<com.f1teammanager.core.season.DriverDefinition>){
    LazyColumn(contentPadding=PaddingValues(16.dp), verticalArrangement=Arrangement.spacedBy(8.dp)) {
        item {
            Text("PILOTOS DA EQUIPE", color=Red, fontWeight=FontWeight.Black, fontSize=16.sp)
            Text("Atributos atuais e perfil de evolução", color=Muted, fontSize=10.sp)
        }
        items(drivers) { d ->
            Card(Modifier.fillMaxWidth(), colors=CardDefaults.cardColors(Panel)) {
                Column(Modifier.padding(12.dp), verticalArrangement=Arrangement.spacedBy(6.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween) {
                        Column(Modifier.weight(1f)) {
                            Text(d.name, color=Color.White, fontWeight=FontWeight.Black, fontSize=15.sp)
                            Text("${d.driverClass} • ${d.evolution}", color=Red, fontSize=9.sp)
                        }
                        Text("OVR ${driverOverall(d)}", color=Color.White, fontWeight=FontWeight.Black, fontSize=13.sp)
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                        DriverStat("VEL",d.speed); DriverStat("QUAL",d.qualifying); DriverStat("ULTR",d.overtaking); DriverStat("DEF",d.defense)
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                        DriverStat("CONS",d.consistency); DriverStat("CHUVA",d.wet); DriverStat("PNEU",d.tyre); DriverStat("EXP",d.experience)
                    }
                }
            }
        }
    }
}

@Composable
private fun RowScope.DriverStat(label:String,value:Int){
    Column(Modifier.weight(1f).background(Panel2,RoundedCornerShape(6.dp)).padding(6.dp)) {
        Text(label,color=Muted,fontSize=7.sp,fontWeight=FontWeight.Bold)
        Text(value.toString(),color=Color.White,fontSize=12.sp,fontWeight=FontWeight.Black)
    }
}

private fun driverOverall(d:com.f1teammanager.core.season.DriverDefinition):Int =
    listOf(d.speed,d.qualifying,d.overtaking,d.defense,d.consistency,d.wet,d.tyre).average().toInt()

@Composable
private fun Car(
    c: com.f1teammanager.core.season.CarSpec,
    state: TeamManagerState,
    currentWeek: Int,
    message: String,
    develop: (CarComponent, ResearchFocus, ResearchComplexity) -> Unit,
    manufactureDesign: (com.f1teammanager.core.manager.ResearchDesign, Int, Int, Long) -> Unit,
    installPiece: (com.f1teammanager.core.manager.CarPiece, GarageCarId) -> Unit,
    investNextSeason: (Long) -> Unit,
    setNextSeasonFocus: (CarDevelopmentFocus) -> Unit
) {
    var selectedComponent by remember { mutableStateOf<CarComponent?>(null) }
    var selectedDesign by remember { mutableStateOf<com.f1teammanager.core.manager.ResearchDesign?>(null) }
    var selectedFocus by remember { mutableStateOf(ResearchFocus.BALANCED) }
    var selectedComplexity by remember { mutableStateOf(ResearchComplexity.MEDIUM) }
    val researchEngine = remember { ResearchEngine() }
    val factoryEngine = remember { FactoryEngine() }
    val factorySpec = factoryEngine.specification(state.facilities)
    val garage = state.garage
    val pdLevel = state.facilities.level(FacilityType.RESEARCH)
    val simultaneousLimit = when {
        pdLevel >= 8 -> 3
        pdLevel >= 4 -> 2
        else -> 1
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(7.dp)
    ) {
        garage?.let { g ->
            item { PhysicalCarCard("CARRO 1", g.car1) }
            item { PhysicalCarCard("CARRO 2", g.car2) }
        }

        item {
            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(Panel)) {
                Column(Modifier.padding(11.dp)) {
                    Text("CENTRO DE P&D", color = Red, fontWeight = FontWeight.Black, fontSize = 12.sp)
                    Text("Nível $pdLevel • Pesquisas ${state.research.activeProjects.size}/$simultaneousLimit", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 10.sp)
                    Text("A pesquisa gera tecnologia. O carro só muda depois de Design → Fábrica → peça física → instalação.", color = Muted, fontSize = 9.sp, modifier = Modifier.padding(top = 3.dp))
                }
            }
        }

        if (state.research.activeProjects.isNotEmpty()) {
            item { Text("PESQUISAS EM ANDAMENTO", color = Color.White, fontWeight = FontWeight.Black, fontSize = 11.sp) }
            items(state.research.activeProjects) { project ->
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(Panel2)) {
                    Column(Modifier.padding(9.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("${componentLabel(project.component)} V${project.version}", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                            Text(researchEngine.complexityLabel(project.complexity).uppercase(), color = Red, fontWeight = FontWeight.Black, fontSize = 8.sp)
                        }
                        Text("${researchEngine.focusLabel(project.focus)} • ${project.remainingWeeks}/${project.totalWeeks} semana(s) • ${formatMoney(project.cost)}", color = Muted, fontSize = 9.sp)
                        Text("P ${project.basePerformance} → ${project.targetPerformance} • C ${project.baseReliability} → ${project.targetReliability}", color = Muted, fontSize = 9.sp, modifier = Modifier.padding(top = 2.dp))
                    }
                }
            }
        }

        item { Text("NOVA PESQUISA", color = Color.White, fontWeight = FontWeight.Black, fontSize = 11.sp) }

        CarComponent.values().forEach { component ->
            item {
                val latest = state.research.completedDesigns.filter { it.component == component }.maxByOrNull { it.version }
                val cooldown = state.research.cooldownUntil[component] ?: 0
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(Panel)) {
                    Row(Modifier.fillMaxWidth().padding(9.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(componentLabel(component), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                            Text(
                                if (latest == null) "Tecnologia inicial V1"
                                else "Último design V${latest.version} • P${latest.performance} • C${latest.reliability}",
                                color = Muted, fontSize = 9.sp
                            )
                            if (currentWeek < cooldown) {
                                Text("Disponível novamente na semana $cooldown", color = Red, fontSize = 8.sp)
                            }
                        }
                        Button(
                            onClick = { selectedComponent = component },
                            enabled = state.research.activeProjects.size < simultaneousLimit && currentWeek >= cooldown && state.research.activeProjects.none { it.component == component },
                            colors = ButtonDefaults.buttonColors(containerColor = Red, contentColor = Color.White, disabledContainerColor = Panel2),
                            contentPadding = PaddingValues(horizontal = 9.dp, vertical = 4.dp)
                        ) { Text("PESQUISAR", fontSize = 8.sp, fontWeight = FontWeight.Black) }
                    }
                }
            }
        }

        if (state.research.completedDesigns.isNotEmpty()) {
            item { Text("DESIGNS CONCLUÍDOS / AGUARDANDO FÁBRICA", color = Color.White, fontWeight = FontWeight.Black, fontSize = 11.sp) }
            items(state.research.completedDesigns.asReversed().take(12)) { design ->
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(Panel2)) {
                    Row(Modifier.fillMaxWidth().padding(9.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column(Modifier.weight(1f)) {
                            Text("${componentLabel(design.component)} V${design.version}", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 10.sp)
                            Text("Performance ${design.performance} • Confiabilidade ${design.reliability}", color = Muted, fontSize = 9.sp)
                        }
                        Text("FÁBRICA", color = Red, fontWeight = FontWeight.Black, fontSize = 8.sp)
                    }
                }
            }
        }

        item {
            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(Panel)) {
                Column(Modifier.padding(11.dp)) {
                    Text("FÁBRICA", color = Red, fontWeight = FontWeight.Black, fontSize = 12.sp)
                    Text(
                        if (state.factory.activeOrders.isEmpty()) "Nenhuma produção em andamento"
                        else state.factory.activeOrders.joinToString(" • ") { "${componentLabel(it.component)} V${it.version} x${it.remainingUnits} • ${it.remainingWeeks}/${it.totalWeeks} semana(s)" },
                        color = Color.White, fontSize = 10.sp
                    )
                    Text("As peças fabricadas entram no estoque. A instalação em Carro 1 ou Carro 2 acontece separadamente.", color = Muted, fontSize = 9.sp, modifier = Modifier.padding(top = 3.dp))
                }
            }
        }

        if (garage != null && garage.inventory.isNotEmpty()) {
            item { Text("ESTOQUE DE PEÇAS", color = Color.White, fontWeight = FontWeight.Black, fontSize = 11.sp) }
            items(garage.inventory.takeLast(30)) { piece ->
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(Panel2)) {
                    Column(Modifier.padding(9.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column(Modifier.weight(1f)) {
                                Text("${componentLabel(piece.component)} V${piece.version}", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 10.sp)
                                Text("Performance ${piece.performance} • Confiabilidade ${piece.reliability}", color = Muted, fontSize = 8.sp)
                            }
                            Text("FÍSICA", color = Red, fontWeight = FontWeight.Black, fontSize = 8.sp)
                        }
                        Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Button(onClick = { installPiece(piece, GarageCarId.CAR_1) }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Red, contentColor = Color.White), contentPadding = PaddingValues(vertical = 4.dp)) { Text("CARRO 1", fontSize = 8.sp, fontWeight = FontWeight.Black) }
                            Button(onClick = { installPiece(piece, GarageCarId.CAR_2) }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Panel, contentColor = Color.White), contentPadding = PaddingValues(vertical = 4.dp)) { Text("CARRO 2", fontSize = 8.sp, fontWeight = FontWeight.Black) }
                        }
                    }
                }
            }
        }

        state.research.completedDesigns.asReversed().take(8).forEach { design ->
            item {
                val options = factoryEngine.options(design, state.facilities)
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(Panel2)) {
                    Row(Modifier.fillMaxWidth().padding(9.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("${componentLabel(design.component)} V${design.version}", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 10.sp)
                            Text("Peça ${design.performance} • confiabilidade ${design.reliability}", color = Muted, fontSize = 9.sp)
                            Text("Até ${factorySpec.maxUnitsPerOrder} unidade(s) por ordem • ${factorySpec.parallelOrders} ordem(ns) simultânea(s)", color = Muted, fontSize = 8.sp)
                        }
                        Button(onClick = { selectedDesign = design }, enabled = state.factory.activeOrders.size < factorySpec.parallelOrders, colors = ButtonDefaults.buttonColors(containerColor = Red, contentColor = Color.White), contentPadding = PaddingValues(horizontal = 8.dp, vertical = 3.dp)) { Text("FABRICAR", fontSize = 8.sp, fontWeight = FontWeight.Black) }
                    }
                }
            }
        }

        if (message.isNotBlank()) item { Text(message, color = Color.White, fontSize = 10.sp) }
    }

    selectedDesign?.let { design ->
        val options = factoryEngine.options(design, state.facilities)
        AlertDialog(
            onDismissRequest = { selectedDesign = null },
            title = { Text("FÁBRICA • ${componentLabel(design.component).uppercase()}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    options.forEach { option ->
                        Button(
                            onClick = { manufactureDesign(design, option.quantity, option.weeks, option.costPerUnit); selectedDesign = null },
                            enabled = state.finance.budget >= option.costPerUnit * option.quantity && state.factory.activeOrders.size < factorySpec.parallelOrders,
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = if (option.quantity == 1) Red else Panel2, contentColor = Color.White)
                        ) {
                            Column(Modifier.fillMaxWidth()) {
                                Text("${option.quantity} peça(s) • ${option.weeks} semana(s)", fontWeight = FontWeight.Black, fontSize = 10.sp)
                                Text("${formatMoney(option.costPerUnit)} por peça • total ${formatMoney(option.costPerUnit * option.quantity)}", fontSize = 9.sp)
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { selectedDesign = null }) { Text("CANCELAR") } }
        )
    }

    selectedComponent?.let { component ->
        val options = researchEngine.options(pdLevel)
        AlertDialog(
            onDismissRequest = { selectedComponent = null },
            title = { Text("P&D • ${componentLabel(component).uppercase()}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Text("Escolha foco e complexidade. O nível $pdLevel define a capacidade tecnológica.", color = Muted, fontSize = 10.sp)
                    Text("FOCO", color = Color.White, fontWeight = FontWeight.Black, fontSize = 9.sp)
                    ResearchFocus.values().forEach { focus ->
                        Button(onClick = { selectedFocus = focus }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = if (selectedFocus == focus) Red else Panel2, contentColor = Color.White)) { Text(researchEngine.focusLabel(focus), fontSize = 9.sp) }
                    }
                    Text("COMPLEXIDADE", color = Color.White, fontWeight = FontWeight.Black, fontSize = 9.sp)
                    ResearchComplexity.values().forEach { complexity ->
                        val option = options.first { it.complexity == complexity }
                        Button(onClick = { selectedComplexity = complexity }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = if (selectedComplexity == complexity) Red else Panel2, contentColor = Color.White)) {
                            Column(Modifier.fillMaxWidth()) {
                                Text(researchEngine.complexityLabel(complexity), fontWeight = FontWeight.Black, fontSize = 9.sp)
                                Text("${option.weeks} semana(s) • ${formatMoney(option.cost)} • risco ${option.riskLabel}", fontSize = 8.sp)
                            }
                        }
                    }
                    Button(onClick = { develop(component, selectedFocus, selectedComplexity); selectedComponent = null }, enabled = state.finance.budget >= researchEngine.baseCost(selectedComplexity), modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Red, contentColor = Color.White)) { Text("INICIAR PESQUISA", fontWeight = FontWeight.Black, fontSize = 9.sp) }
                }
            },
            confirmButton = { TextButton(onClick = { selectedComponent = null }) { Text("CANCELAR") } }
        )
    }
}

@Composable
private fun PhysicalCarCard(title:String,car:com.f1teammanager.core.manager.PhysicalCar){
    val rows=listOf("Motor" to car.engine,"Chassi" to car.chassis,"Asa dianteira" to car.frontWing,"Asa traseira" to car.rearWing,"Freios" to car.brakes,"Unidade elétrica" to car.electricPowerUnit)
    Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(Panel)){
        Column(Modifier.padding(11.dp)){
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){
                Text(title,color=Red,fontWeight=FontWeight.Black,fontSize=12.sp)
                Text("Overall ${"%.1f".format(java.util.Locale.US,car.overall)}",color=Color.White,fontWeight=FontWeight.Black,fontSize=12.sp)
            }
            rows.forEach { (label,value) ->
                Row(Modifier.fillMaxWidth().padding(top=5.dp),horizontalArrangement=Arrangement.SpaceBetween){
                    Text(label,color=Muted,fontSize=9.sp)
                    Text(value.toString(),color=Color.White,fontWeight=FontWeight.Bold,fontSize=10.sp)
                }
            }
            Row(Modifier.fillMaxWidth().padding(top=5.dp),horizontalArrangement=Arrangement.SpaceBetween){
                Text("Confiabilidade média",color=Muted,fontSize=9.sp)
                Text(car.reliability.toString(),color=Color.White,fontWeight=FontWeight.Bold,fontSize=10.sp)
            }
        }
    }
}

@Composable private fun CarComponentRow(title:String,level:Int,component:CarComponent,project:com.f1teammanager.core.manager.DevelopmentProject?,options:List<CarDevelopmentEngine.DevelopmentOption>,open:()->Unit){
    val default=options.firstOrNull { it.intensity==DevelopmentIntensity.STANDARD }
    Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(Panel)){
        Row(Modifier.fillMaxWidth().padding(9.dp),verticalAlignment=Alignment.CenterVertically){
            Column(Modifier.weight(1f)){
                Text(title,color=Color.White,fontWeight=FontWeight.Bold,fontSize=11.sp)
                Text("NÍVEL $level • ${default?.weeks ?: 2} semanas padrão • ${default?.cost?.let(::formatMoney) ?: formatMoney(0)} • +${default?.minGain ?: 0} a +${default?.maxGain ?: 0}",color=Muted,fontSize=9.sp)
            }
            Button(onClick=open,enabled=project==null,colors=ButtonDefaults.buttonColors(containerColor=Red,contentColor=Color.White,disabledContainerColor=Panel2),contentPadding=PaddingValues(horizontal=9.dp,vertical=3.dp)){
                Text(if(project==null)"DESENVOLVER" else "P&D OCUPADO",fontSize=8.sp)
            }
        }
    }
}

private fun optionLabel(i:DevelopmentIntensity)=when(i){DevelopmentIntensity.QUICK->"RÁPIDO";DevelopmentIntensity.STANDARD->"PADRÃO";DevelopmentIntensity.ADVANCED->"AVANÇADO";DevelopmentIntensity.AGGRESSIVE->"AGRESSIVO"}
private fun seasonDateLabel(round: RoundDefinition, season: Int): String =
    round.dateLabel.replace(Regex("/\\d{4}$"), "/$season")

@Composable
private fun Calendar(
    idx:Int,
    current:Int,
    currentWeek:Int,
    season:Int,
    message:String,
    openHistory:(Int)->Unit,
    hasHistory:(Int)->Boolean,
    skipOneWeek:()->Unit,
    jumpToNextRace:()->Unit
){
    val seasonRounds = SeasonCalendar.forSeason(season)
    val raceByWeek=seasonRounds.associateBy { it.weekOfSeason }
    val next=seasonRounds.getOrNull(idx) ?: seasonRounds.lastOrNull()
    LazyColumn(
        contentPadding=PaddingValues(start=16.dp,end=16.dp,top=8.dp,bottom=12.dp),
        verticalArrangement=Arrangement.spacedBy(7.dp)
    ){
        item{
            Column(Modifier.fillMaxWidth().padding(bottom=1.dp)){
                Text("CALENDÁRIO $season",color=Color.White,fontSize=24.sp,fontWeight=FontWeight.Black)
                Row(Modifier.fillMaxWidth().padding(top=5.dp),verticalAlignment=Alignment.CenterVertically){
                    CalendarMeta("▣","30 GRAND PRIX")
                    MetaDivider()
                    CalendarMeta("▤","56 SEMANAS")
                    MetaDivider()
                    CalendarMeta("⚒","26 SEMANAS LIVRES")
                }
                Spacer(Modifier.height(8.dp))
                Box(Modifier.fillMaxWidth().height(2.dp).background(Red))
            }
        }
        item{
            Card(
                Modifier.fillMaxWidth(),
                shape=RoundedCornerShape(16.dp),
                colors=CardDefaults.cardColors(containerColor=Panel),
                border=BorderStroke(1.dp,Red)
            ){
                Box(Modifier.fillMaxWidth().background(
                    Brush.horizontalGradient(listOf(Color(0xFF151820),Color(0xFF190B0C),Color(0xFF241013))),
                    RoundedCornerShape(16.dp)
                )){
                    Column(Modifier.padding(horizontal=16.dp,vertical=14.dp)){
                        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){
                            Text("SEMANA ATUAL: $currentWeek/56",color=Red,fontWeight=FontWeight.Black,fontSize=17.sp)
                            Text("TEMPORADA $season",color=Muted,fontSize=9.sp,fontWeight=FontWeight.Bold)
                        }
                        Text(
                            if(next!=null) "Próximo GP: Round ${next.round}  •  Semana ${next.weekOfSeason}  •  ${next.grandPrix}"
                            else "Temporada encerrada",
                            color=Color.White,fontWeight=FontWeight.Bold,fontSize=10.sp,
                            modifier=Modifier.padding(top=7.dp)
                        )
                        Text(
                            "As semanas sem GP são semanas livres de desenvolvimento do carro, contratações e gerenciamento da equipe.",
                            color=Muted,fontSize=9.sp,lineHeight=13.sp,
                            modifier=Modifier.padding(top=5.dp)
                        )
                        Row(Modifier.fillMaxWidth().padding(top=11.dp),horizontalArrangement=Arrangement.spacedBy(8.dp)){
                            Button(
                                onClick=skipOneWeek,
                                modifier=Modifier.weight(0.92f).height(42.dp),
                                enabled=currentWeek<56,
                                shape=RoundedCornerShape(22.dp),
                                contentPadding=PaddingValues(horizontal=8.dp),
                                colors=ButtonDefaults.buttonColors(containerColor=Panel2,contentColor=Color.White,disabledContainerColor=Panel2,disabledContentColor=Muted)
                            ){Text("PULAR 1 SEMANA",fontSize=8.sp,fontWeight=FontWeight.Black,maxLines=1)}
                            Button(
                                onClick=jumpToNextRace,
                                modifier=Modifier.weight(1.18f).height(42.dp),
                                shape=RoundedCornerShape(22.dp),
                                contentPadding=PaddingValues(horizontal=8.dp),
                                colors=ButtonDefaults.buttonColors(containerColor=Red,contentColor=Color.White)
                            ){Text("PULAR ATÉ PRÓXIMO GP",fontSize=8.sp,fontWeight=FontWeight.Black,maxLines=1)}
                        }
                        if(message.isNotBlank()) Text(message,color=Color.White,fontSize=8.sp,lineHeight=12.sp,modifier=Modifier.padding(top=7.dp))
                    }
                }
            }
        }
        items((1..56).toList()){week->
            val r=raceByWeek[week]
            val isCurrent=week==currentWeek
            if(r==null){
                Card(
                    Modifier.fillMaxWidth(),
                    shape=RoundedCornerShape(12.dp),
                    colors=CardDefaults.cardColors(containerColor=Panel)
                ){
                    Row(Modifier.fillMaxWidth().padding(horizontal=12.dp,vertical=10.dp),verticalAlignment=Alignment.CenterVertically){
                        CalendarOutlineIcon(Modifier.size(36.dp))
                        Spacer(Modifier.width(11.dp))
                        Column(Modifier.weight(1f)){
                            Text("SEMANA $week/56${if(isCurrent) " • AGORA" else ""}",color=if(isCurrent) Red else Muted,fontSize=9.sp,fontWeight=FontWeight.Black)
                            Text("SEMANA LIVRE",color=Color.White,fontWeight=FontWeight.Black,fontSize=11.sp,modifier=Modifier.padding(top=4.dp))
                            Text("P&D / DESENVOLVIMENTO",color=Color.White,fontSize=9.sp,fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=2.dp))
                            Text("Use esta semana para avançar projetos do carro.",color=Muted,fontSize=8.sp,modifier=Modifier.padding(top=2.dp))
                        }
                        Text("›",color=Color.White,fontSize=28.sp)
                    }
                }
            } else {
                Card(
                    Modifier.fillMaxWidth(),
                    shape=RoundedCornerShape(12.dp),
                    colors=CardDefaults.cardColors(containerColor=Panel)
                ){
                    Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){
                        Box(Modifier.width(5.dp).height(164.dp).background(Red, RoundedCornerShape(topStart=12.dp,bottomStart=12.dp)))
                        Column(Modifier.fillMaxWidth().padding(start=12.dp,end=12.dp,top=10.dp,bottom=10.dp)){
                            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){
                                Text("SEMANA ${r.weekOfSeason}/56${if(isCurrent) " • AGORA" else ""}",color=if(isCurrent) Color.White else Color.White,fontSize=10.sp,fontWeight=FontWeight.Black)
                                Text("ROUND ${r.round}  •  ${seasonDateLabel(r, season)}",color=Muted,fontSize=8.sp,fontWeight=FontWeight.Bold)
                            }
                            Row(Modifier.fillMaxWidth().padding(top=7.dp),verticalAlignment=Alignment.CenterVertically){
                                RaceImage(r,Modifier.size(width=130.dp,height=90.dp))
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(3.dp)){
                                    Text(r.grandPrix,color=Color.White,fontWeight=FontWeight.Black,fontSize=13.sp,maxLines=1,overflow=TextOverflow.Ellipsis)
                                    Text(r.circuit,color=Muted,fontSize=10.sp,maxLines=1,overflow=TextOverflow.Ellipsis)
                                    Text("◌  ${r.laps} VOLTAS",color=Color.White,fontSize=8.sp,fontWeight=FontWeight.Bold)
                                    Text("⌖  ${r.circuit}",color=Muted,fontSize=8.sp,maxLines=1,overflow=TextOverflow.Ellipsis)
                                    if(hasHistory(r.round)){
                                        Text("VER RESULTADOS  ›",color=Red,fontSize=8.sp,fontWeight=FontWeight.Black,modifier=Modifier.clickable{openHistory(r.round)})
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun RowScope.CalendarMeta(icon:String,label:String){
    Row(verticalAlignment=Alignment.CenterVertically,modifier=Modifier.weight(1f)){
        Text(icon,color=Color.White,fontSize=12.sp,fontWeight=FontWeight.Bold)
        Spacer(Modifier.width(4.dp))
        Text(label,color=Color.White,fontSize=8.sp,fontWeight=FontWeight.Bold,maxLines=1)
    }
}

@Composable
private fun MetaDivider(){
    Box(Modifier.width(1.dp).height(15.dp).background(Line))
}

@Composable
private fun CalendarOutlineIcon(modifier:Modifier=Modifier){
    Canvas(modifier){
        val stroke=androidx.compose.ui.graphics.drawscope.Stroke(width=2.2f)
        val w=size.width
        val h=size.height
        drawRoundRect(Color.White,topLeft=androidx.compose.ui.geometry.Offset(w*0.15f,h*0.22f),size=androidx.compose.ui.geometry.Size(w*0.70f,h*0.62f),cornerRadius=androidx.compose.ui.geometry.CornerRadius(5f,5f),style=stroke)
        drawLine(Color.White,androidx.compose.ui.geometry.Offset(w*0.15f,h*0.40f),androidx.compose.ui.geometry.Offset(w*0.85f,h*0.40f),strokeWidth=2.2f)
        drawLine(Color.White,androidx.compose.ui.geometry.Offset(w*0.30f,h*0.10f),androidx.compose.ui.geometry.Offset(w*0.30f,h*0.30f),strokeWidth=2.2f)
        drawLine(Color.White,androidx.compose.ui.geometry.Offset(w*0.70f,h*0.10f),androidx.compose.ui.geometry.Offset(w*0.70f,h*0.30f),strokeWidth=2.2f)
        drawCircle(Color.White,radius=1.5f,center=androidx.compose.ui.geometry.Offset(w*0.36f,h*0.58f))
        drawCircle(Color.White,radius=1.5f,center=androidx.compose.ui.geometry.Offset(w*0.50f,h*0.58f))
        drawCircle(Color.White,radius=1.5f,center=androidx.compose.ui.geometry.Offset(w*0.64f,h*0.58f))
    }
}

@Composable private fun RaceHero(r:RoundDefinition,start:()->Unit,currentWeek:Int){
    Card(Modifier.fillMaxWidth(), colors=CardDefaults.cardColors(Panel)){
        Column(Modifier.padding(14.dp)){
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){
                Text("ROUND ${r.round}",color=Red,fontWeight=FontWeight.Black,fontSize=11.sp)
                Text("SEMANA ${r.weekOfSeason}",color=Muted,fontWeight=FontWeight.Bold,fontSize=10.sp)
            }
            Text(r.grandPrix,color=Color.White,fontSize=21.sp,fontWeight=FontWeight.Black,modifier=Modifier.padding(top=4.dp))
            Text(r.circuit,color=Muted,fontSize=11.sp)
            Text(if(currentWeek==r.weekOfSeason) "FIM DE SEMANA DISPONÍVEL" else "CORRIDA AGUARDANDO A SEMANA CORRETA",color=if(currentWeek==r.weekOfSeason) Green else Muted,fontSize=9.sp,fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=8.dp))
            Button(onClick=start,enabled=currentWeek==r.weekOfSeason,modifier=Modifier.fillMaxWidth().padding(top=8.dp),colors=ButtonDefaults.buttonColors(containerColor=Red,contentColor=Color.White,disabledContainerColor=Panel2,disabledContentColor=Muted)){Text("ABRIR FIM DE SEMANA",fontWeight=FontWeight.Black)}
        }
    }
}

@Composable private fun Weekend(r:RoundDefinition,currentWeek:Int,start:()->Unit){LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){item{HeaderBlock(r.grandPrix,"ROUND ${r.round} • ${r.circuit}")};item{RaceHero(r,start,currentWeek)};item{InfoPanel("QUALIFICAÇÃO","Define o grid de largada");InfoPanel("ESTRATÉGIA","Postura + pneu inicial");InfoPanel("CORRIDA","Decisões VSC, SC e bandeira vermelha")};item{Button(onClick=start,modifier=Modifier.fillMaxWidth()){Text("COMEÇAR QUALIFICAÇÃO")}}}}
@Composable private fun InfoPanel(a:String,b:String){Row(Modifier.fillMaxWidth().background(Panel,RoundedCornerShape(8.dp)).padding(14.dp),horizontalArrangement=Arrangement.SpaceBetween){Column{Text(a,color=Color.White,fontWeight=FontWeight.Bold);Text(b,color=Muted,fontSize=11.sp)};Text("›",color=Red,fontSize=24.sp)}}
@Composable
private fun Qualifying(
    s: CareerWeekendEngine.SessionSnapshot,
    simulate: () -> Unit,
    start: () -> Unit
){
    var phase by remember { mutableIntStateOf(s.qualifyingPhaseIndex) }
    var running by remember { mutableStateOf(false) }
    var speedMs by remember { mutableIntStateOf(900) }
    val phases=s.grid?.phases.orEmpty()
    val q3Complete=s.grid?.phases?.getOrNull(2)?.entries?.size==20
    val currentPhase=s.qualifyingPhaseIndex.coerceIn(0,2)
    val currentName=listOf("Q1","Q2","Q3")[currentPhase]
    val durationMin=listOf(30,20,10)[currentPhase]
    val elapsedSeconds=(s.qualifyingElapsedMs/1000L).coerceAtMost(durationMin*60L)
    val progress=if(s.qualifyingDurationMs>0) (s.qualifyingElapsedMs.toFloat()/s.qualifyingDurationMs.toFloat()).coerceIn(0f,1f) else 0f
    val selected=phases.getOrNull(phase)

    LaunchedEffect(running, s.qualifyingPhaseIndex, s.qualifyingElapsedMs, speedMs) {
        if(running && !q3Complete){
            phase=currentPhase
            kotlinx.coroutines.delay(speedMs.toLong())
            simulate()
        }
    }

    LaunchedEffect(s.qualifyingPhaseIndex, s.grid?.phases?.getOrNull(2)?.entries?.size) {
        phase=currentPhase
        running=false
    }

    Column(Modifier.fillMaxSize().padding(12.dp)){
        Text("CLASSIFICAÇÃO",color=Color.White,fontSize=23.sp,fontWeight=FontWeight.Black)
        Text("Q1 80 → Q2 50 → Q3 20",color=Red,fontSize=10.sp,fontWeight=FontWeight.Bold)
        Spacer(Modifier.height(5.dp))

        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(5.dp)){
            listOf("Q1","Q2","Q3").forEachIndexed{i,label->
                val available=phases.getOrNull(i)?.entries?.isNotEmpty()==true || i==currentPhase
                Button(onClick={if(available){phase=i}},enabled=available,modifier=Modifier.weight(1f),colors=ButtonDefaults.buttonColors(containerColor=if(phase==i)Red else Panel2,contentColor=Color.White,disabledContainerColor=Panel2,disabledContentColor=Muted),contentPadding=PaddingValues(vertical=4.dp)){
                    Text(label,fontWeight=FontWeight.Black)
                }
            }
        }

        Card(Modifier.fillMaxWidth().padding(top=5.dp,bottom=5.dp),colors=CardDefaults.cardColors(Panel)){
            Column(Modifier.padding(8.dp)){
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){
                    Text("${currentName} • ${durationMin}:00",color=Color.White,fontWeight=FontWeight.Black,fontSize=11.sp)
                    Text(if(running) "SIMULANDO" else if(q3Complete) "CONCLUÍDA" else "PRONTA",color=if(running) Green else Muted,fontWeight=FontWeight.Black,fontSize=9.sp)
                }
                Spacer(Modifier.height(5.dp))
                LinearProgressIndicator(progress={progress},modifier=Modifier.fillMaxWidth().height(5.dp),color=Red,trackColor=Panel2)
                Row(Modifier.fillMaxWidth().padding(top=4.dp),horizontalArrangement=Arrangement.SpaceBetween){
                    Text("TEMPO ${elapsedSeconds/60}:${(elapsedSeconds%60).toString().padStart(2,'0')}",color=Muted,fontSize=8.sp)
                    Text("MELHOR VOLTA DE CADA PILOTO",color=Muted,fontSize=8.sp)
                }
            }
        }

        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(4.dp)){
            listOf(1500 to "0,5x",900 to "1x",450 to "2x",220 to "4x").forEach { (ms,label) ->
                Button(onClick={speedMs=ms},modifier=Modifier.weight(1f),colors=ButtonDefaults.buttonColors(containerColor=if(speedMs==ms)Red else Panel2,contentColor=Color.White),contentPadding=PaddingValues(vertical=3.dp)){
                    Text(label,fontSize=8.sp,fontWeight=FontWeight.Black)
                }
            }
        }

        selected?.let{
            Text("${it.name}: ${it.entries.size} pilotos • eliminados nesta fase: ${it.eliminatedDriverIds.size}",color=Muted,fontSize=9.sp,modifier=Modifier.padding(vertical=5.dp))
        }

        LazyColumn(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(2.dp)){
            items(selected?.entries.orEmpty()){e->
                val mine = e.driverId in s.plans.keys
                Row(Modifier.fillMaxWidth().background(if(mine) Color(0xFF2A1010) else Panel,RoundedCornerShape(4.dp)).padding(horizontal=8.dp,vertical=5.dp),horizontalArrangement=Arrangement.SpaceBetween){
                    Text("P${e.position}",color=if(mine) Red else Muted,fontWeight=FontWeight.Black,fontSize=10.sp)
                    Text(if(mine) "★ ${WorldDatabase.drivers.firstOrNull{it.id==e.driverId}?.name?:"Piloto ${e.driverId}"}" else (WorldDatabase.drivers.firstOrNull{it.id==e.driverId}?.name?:"Piloto ${e.driverId}"),color=if(mine) Red else Color.White,fontWeight=if(mine) FontWeight.Black else FontWeight.Normal,fontSize=10.sp,modifier=Modifier.weight(1f).padding(horizontal=8.dp))
                    Text(if(e.lapTimeMs==Long.MAX_VALUE) "—" else formatMs(e.lapTimeMs),color=if(mine) Color.White else Muted,fontSize=9.sp)
                }
            }
        }

        Button(onClick={
            if(q3Complete){ start() }
            else if(running){ running=false }
            else { phase=currentPhase; running=true; simulate() }
        },modifier=Modifier.fillMaxWidth().height(48.dp),colors=ButtonDefaults.buttonColors(containerColor=Red,contentColor=Color.White)){
            Text(when{
                q3Complete -> "INICIAR CORRIDA"
                running -> "PAUSAR SIMULAÇÃO"
                else -> "SIMULAR $currentName"
            },fontWeight=FontWeight.Black)
        }
    }
}
@Composable private fun <T> ChoiceRow(title:String,current:String,values:List<T>,select:(T)->Unit){Column{Text(title,color=Muted,fontSize=10.sp,fontWeight=FontWeight.Bold);Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(6.dp)){values.forEach{v->FilterChip(selected=v.toString()==current,onClick={select(v)},label={Text(v.toString())})}}}}
@Composable
private fun Race(
    s: CareerWeekendEngine.SessionSnapshot,
    drivers: List<com.f1teammanager.core.season.DriverDefinition>,
    advance: () -> Unit,
    setStrategy: (Int, DriverStrategyMode) -> Unit,
    pitNow: (Int, Tyre) -> Unit,
    pitPlan: (Int, String) -> Unit,
    setRacePlan: (Int, String) -> Unit,
    decision: (ManagerDecisionAction) -> Unit,
) {
    var raceStarted by remember { mutableStateOf(false) }
    var running by remember { mutableStateOf(false) }
    var speedMs by remember { mutableIntStateOf(1100) }
    var pitDriver by remember { mutableIntStateOf(-1) }
    val playerIds = drivers.map { it.id }.toSet()
    val playerStatus = s.carStatus.filter { it.driverId in playerIds }
    val statusById = s.carStatus.associateBy { it.driverId }
    val leaderTime = s.classification.minOfOrNull { it.totalTimeMs } ?: 0L

    LaunchedEffect(s.lap, s.decision, s.completed, running, speedMs, raceStarted) {
        if (raceStarted && running && s.decision == null && !s.completed) {
            kotlinx.coroutines.delay(speedMs.toLong())
            advance()
        }
    }

    Column(Modifier.fillMaxSize().padding(horizontal = 10.dp)) {
        Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column { Text("PIT WALL", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Black); Text("VOLTA ${s.lap}/${s.totalLaps}", color = Red, fontWeight = FontWeight.Bold) }
            Column(horizontalAlignment = Alignment.End) { Text(statusLabel(s.neutral), color = if (s.neutral == Neutralisation.GREEN) Green else Red, fontWeight = FontWeight.Black); Text(if (!raceStarted) "AGUARDANDO INÍCIO" else if (running) "AUTOMÁTICA" else "PAUSADA", color = Muted, fontSize = 9.sp)
            Text(weatherLabel(s.weather), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp) }
        }
        if (!raceStarted) {
            Card(Modifier.fillMaxWidth().padding(vertical=5.dp), colors=CardDefaults.cardColors(Panel)) {
                Column(Modifier.padding(9.dp)) {
                    Text("PREPARAÇÃO PARA A CORRIDA", color=Red, fontWeight=FontWeight.Black, fontSize=12.sp)
                    Text("Defina o plano de pneus e a postura dos 2 pilotos antes de iniciar.", color=Muted, fontSize=9.sp, modifier=Modifier.padding(top=2.dp,bottom=6.dp))
                    playerStatus.forEach { st ->
                        val plan=s.plans[st.driverId]
                        Text(st.driverName, color=Color.White, fontWeight=FontWeight.Black, fontSize=12.sp, modifier=Modifier.padding(top=4.dp))
                        Row(Modifier.fillMaxWidth().padding(vertical=3.dp),horizontalArrangement=Arrangement.spacedBy(4.dp)){
                            listOf("A","B","C","D").forEach { id ->
                                Button(onClick={setRacePlan(st.driverId,id)},modifier=Modifier.weight(1f),colors=ButtonDefaults.buttonColors(containerColor=if(plan?.activePlan==id) Red else Panel2,contentColor=Color.White),contentPadding=PaddingValues(vertical=4.dp)){Text("PLANO $id",fontSize=8.sp,fontWeight=FontWeight.Black)}
                            }
                        }
                        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(4.dp)){
                            DriverStrategyMode.entries.forEach { m ->
                                Button(onClick={setStrategy(st.driverId,m)},modifier=Modifier.weight(1f),colors=ButtonDefaults.buttonColors(containerColor=if(plan?.mode==m) Red else Panel2,contentColor=Color.White),contentPadding=PaddingValues(vertical=4.dp)){Text(strategyLabel(m),fontSize=8.sp,maxLines=1)}
                            }
                        }
                        Text(plan?.tyrePlans?.get(plan.activePlan)?.let(::planDescription) ?: "", color=Muted, fontSize=8.sp, modifier=Modifier.padding(top=3.dp,bottom=3.dp))
                    }
                    Button(onClick={raceStarted=true;running=true},modifier=Modifier.fillMaxWidth().height(44.dp).padding(top=5.dp),colors=ButtonDefaults.buttonColors(containerColor=Red,contentColor=Color.White)){Text("INICIAR CORRIDA",fontWeight=FontWeight.Black)}
                }
            }
        } else {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                listOf(1600 to "0,7x", 1100 to "1x", 650 to "1,7x", 300 to "3x").forEach { (ms, label) ->
                    Button(onClick={speedMs=ms}, modifier=Modifier.weight(1f), colors=ButtonDefaults.buttonColors(containerColor=if(speedMs==ms) Red else Panel2, contentColor=Color.White), contentPadding=PaddingValues(vertical=2.dp)){Text(label,fontSize=9.sp)}
                }
            }
        }

        val critical=s.alerts.firstOrNull { it.severity>=3 }
        critical?.let { Card(Modifier.fillMaxWidth().padding(vertical=3.dp), colors=CardDefaults.cardColors(containerColor=Color(0xFF3A0D0D))){Text(it.message,color=Color.White,fontWeight=FontWeight.Bold,fontSize=10.sp,modifier=Modifier.padding(7.dp))} }

        // Decision area deliberately compact: only the two team cars remain above the live classification.
        playerStatus.forEach { st ->
            val plan=s.plans[st.driverId]
            val aheadTime = if (st.position > 1) s.classification.firstOrNull { it.position == st.position - 1 }?.totalTimeMs else null
            val ownTime = s.classification.firstOrNull { it.driverId == st.driverId }?.totalTimeMs ?: st.lastLapMs
            val gap=if(st.position<=1) "LÍDER" else gapText(ownTime, aheadTime ?: ownTime, ahead=false)
            Card(Modifier.fillMaxWidth().padding(vertical=2.dp), colors=CardDefaults.cardColors(Panel)) {
                Row(Modifier.fillMaxWidth().padding(horizontal=8.dp,vertical=6.dp),verticalAlignment=Alignment.CenterVertically){
                    Column(Modifier.weight(1f)){
                        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text(st.driverName,color=Color.White,fontWeight=FontWeight.Black,fontSize=14.sp);Text("P${st.position} $gap",color=Red,fontWeight=FontWeight.Black,fontSize=12.sp)}
                        Text("${tyreLabel(st.tyre)} ${st.tyreWear}%/${st.stintLaps}v • COMB ${st.fuelPercent}% • ERS ${st.ersPercent}% ${if(st.ersActive) "(-${st.ersGainMs}ms)" else ""} • ${if(st.drsActive) "DRS ATIVO (-${st.drsGainMs}ms)" else "DRS —"} • BOX ${st.pitStops}x",color=if(st.fuelPercent<=20||st.tyreWear>=75) Red else Muted,fontSize=9.sp)
                        Text("ÚLTIMA ${formatMs(st.lastLapMs)} • PNEU ~${st.tyre.targetLaps}v",color=Muted,fontSize=8.sp)
                    }
                    Spacer(Modifier.width(5.dp))
                    Button(onClick={pitDriver=st.driverId},colors=ButtonDefaults.buttonColors(containerColor=Red,contentColor=Color.White),contentPadding=PaddingValues(horizontal=11.dp,vertical=3.dp)){Text("BOX",fontSize=9.sp,fontWeight=FontWeight.Black)}
                }
                Row(Modifier.fillMaxWidth().padding(start=8.dp,end=8.dp,bottom=5.dp),horizontalArrangement=Arrangement.spacedBy(4.dp)){
                    DriverStrategyMode.entries.forEach { m -> Button(onClick={setStrategy(st.driverId,m)},modifier=Modifier.weight(1f),colors=ButtonDefaults.buttonColors(containerColor=if(plan?.mode==m) Red else Panel2,contentColor=Color.White),contentPadding=PaddingValues(vertical=2.dp)){Text(strategyLabel(m),fontSize=8.sp,maxLines=1)} }
                }
            }
        }

        Card(Modifier.fillMaxWidth().weight(1f), colors=CardDefaults.cardColors(Panel)) {
            Column {
                Row(Modifier.fillMaxWidth().padding(horizontal=8.dp,vertical=6.dp),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){Text("CLASSIFICAÇÃO AO VIVO",color=Color.White,fontWeight=FontWeight.Black,fontSize=15.sp);Text("${s.classification.size} PILOTOS",color=Red,fontWeight=FontWeight.Black,fontSize=10.sp)}
                Row(Modifier.fillMaxWidth().padding(horizontal=8.dp),horizontalArrangement=Arrangement.SpaceBetween){Text("POS",color=Muted,fontSize=8.sp,modifier=Modifier.width(24.dp));Text("PILOTO",color=Muted,fontSize=8.sp,modifier=Modifier.weight(1f));Text("PNEU",color=Muted,fontSize=8.sp,modifier=Modifier.width(42.dp));Text("GAP",color=Muted,fontSize=8.sp,modifier=Modifier.width(54.dp))}
                LazyColumn(Modifier.weight(1f)) {
                    items(s.classification) { f ->
                        val mine=f.driverId in playerIds; val st=statusById[f.driverId]
                        val aheadTime = if (f.position > 1) s.classification.firstOrNull { it.position == f.position - 1 }?.totalTimeMs else null
                        val gap=if(f.position==1)"LÍDER" else gapText(f.totalTimeMs, aheadTime ?: f.totalTimeMs, ahead=false)
                        Row(Modifier.fillMaxWidth().background(if(mine) Color(0xFF2A1010) else Color.Transparent).padding(horizontal=8.dp,vertical=3.dp),verticalAlignment=Alignment.CenterVertically){
                            Text("${f.position}",color=if(mine)Red else Muted,fontWeight=FontWeight.Bold,modifier=Modifier.width(24.dp),fontSize=10.sp)
                            val raceTeam = WorldDatabase.teams.firstOrNull { it.name.equals(f.teamName, ignoreCase = true) }
                            TeamLogo(f.teamName, raceTeam?.id ?: 0, Modifier.size(22.dp))
                            Spacer(Modifier.width(4.dp))
                            Text(f.driverName,color=if(mine) Red else Color.White,fontWeight=if(mine) FontWeight.Black else FontWeight.Normal,modifier=Modifier.weight(1f),maxLines=1,overflow=TextOverflow.Ellipsis,fontSize=10.sp)
                            Text(tyreLabel(f.tyre),color=if((st?.tyreWear?:0)>=80)Red else Muted,fontSize=8.sp,modifier=Modifier.width(42.dp))
                            Text(if(f.status.startsWith("DNF"))"DNF" else gap,color=if(f.status.startsWith("DNF"))Red else Muted,fontSize=8.sp,modifier=Modifier.width(54.dp))
                        }
                    }
                }
            }
        }

        if(s.events.isNotEmpty()) Text(s.events.takeLast(1).joinToString(" • "){it.detail},color=Muted,fontSize=8.sp,maxLines=1,overflow=TextOverflow.Ellipsis,modifier=Modifier.padding(vertical=2.dp))
        Button(onClick={running=!running},modifier=Modifier.fillMaxWidth().height(42.dp),colors=ButtonDefaults.buttonColors(containerColor=Red,contentColor=Color.White)){Text(if(running)"PAUSAR CORRIDA" else "RETOMAR CORRIDA",fontWeight=FontWeight.Black,fontSize=12.sp)}

        s.decision?.let { d ->
            val isRedFlag = d.request.type == ManagerDecisionType.RED_FLAG
            val restartPlan = s.plans[d.request.driverId]
            AlertDialog(
                onDismissRequest={},
                title={Text(if(isRedFlag) "BANDEIRA VERMELHA • RELARGADA" else "DECISÃO DO MANAGER",fontWeight=FontWeight.Black)},
                text={
                    Column(Modifier.verticalScroll(rememberScrollState())) {
                        Text("${d.driverName}: ${d.request.message}",color=Color.White)
                        if(isRedFlag && restartPlan != null){
                            Spacer(Modifier.height(6.dp))
                            Text("NOVOS PLANOS PARA AS ${((s.totalLaps-s.lap).coerceAtLeast(0))} VOLTAS RESTANTES",color=Red,fontWeight=FontWeight.Black,fontSize=10.sp)
                            Text("Os planos A/B/C/D foram recalculados para a distância restante. O combustível permanece intacto.",color=Muted,fontSize=8.sp,modifier=Modifier.padding(top=3.dp,bottom=5.dp))
                            listOf("A","B","C","D").forEach { id ->
                                val plan = restartPlan.tyrePlans[id]
                                Button(onClick={decision(when(id){"A"->ManagerDecisionAction.RESTART_PLAN_A;"B"->ManagerDecisionAction.RESTART_PLAN_B;"C"->ManagerDecisionAction.RESTART_PLAN_C;else->ManagerDecisionAction.RESTART_PLAN_D});running=true},modifier=Modifier.fillMaxWidth().padding(vertical=2.dp),colors=ButtonDefaults.buttonColors(containerColor=if(restartPlan.activePlan==id) Red else Panel2,contentColor=Color.White),contentPadding=PaddingValues(vertical=5.dp)){
                                    Column(Modifier.fillMaxWidth()){
                                        Text("PLANO $id",fontSize=10.sp,fontWeight=FontWeight.Black)
                                        Text(planDescription(plan),fontSize=8.sp,color=Muted,maxLines=2,overflow=TextOverflow.Ellipsis)
                                    }
                                }
                            }
                        }
                        if(!isRedFlag){
                            d.request.options.forEach{action->Button(onClick={ if(action==ManagerDecisionAction.BOX) { pitDriver=d.request.driverId; running=true } else { decision(action); running=true } },modifier=Modifier.fillMaxWidth().padding(vertical=1.dp),colors=ButtonDefaults.buttonColors(containerColor=Red,contentColor=Color.White),contentPadding=PaddingValues(vertical=4.dp)){Text(actionLabel(action),fontSize=10.sp)}}
                        }
                    }
                },
                confirmButton={}
            )
        }
        if(pitDriver>0){
            val recommended = when(s.weather){
                Weather.HEAVY_RAIN -> Tyre.WET
                Weather.LIGHT_RAIN, Weather.MEDIUM_RAIN -> Tyre.INTERMEDIATE
                else -> Tyre.MEDIUM
            }
            AlertDialog(
                onDismissRequest={pitDriver=-1;running=true},
                title={Text("ESCOLHER PNEU PARA O BOX",fontWeight=FontWeight.Black)},
                text={Column{
                    val remainingLaps=(s.totalLaps-s.lap).coerceAtLeast(0)
                    Text("FALTAM $remainingLaps VOLTAS PARA O FIM DA CORRIDA",color=Red,fontWeight=FontWeight.Black,fontSize=11.sp)
                    Text("A vida mostrada é a referência do composto nas condições atuais. O desgaste real também considera clima e postura.",color=Muted,fontSize=9.sp,modifier=Modifier.padding(top=4.dp))
                    Text("RECOMENDADO AGORA: ${tyreLabel(recommended)}",color=Green,fontWeight=FontWeight.Black,fontSize=10.sp,modifier=Modifier.padding(top=6.dp,bottom=4.dp))
                    listOf(Tyre.SOFT,Tyre.MEDIUM,Tyre.HARD,Tyre.INTERMEDIATE,Tyre.WET).forEach{t->
                        val driverTyreWear = drivers.firstOrNull { it.id == pitDriver }?.tyre ?: 50
                        val life=tyreLifeEstimate(t,s.weather,s.plans[pitDriver]?.mode ?: DriverStrategyMode.BALANCED,driverTyreWear)
                        Button(onClick={pitNow(pitDriver,t);pitDriver=-1;running=true},modifier=Modifier.fillMaxWidth().padding(vertical=2.dp),colors=ButtonDefaults.buttonColors(containerColor=if(t==recommended) Red else Panel2,contentColor=Color.White)){Text("${tyreLabel(t)} • ${life} VOLTAS${if(t==recommended) " • RECOMENDADO" else ""}")}
                    }
                    val activePlan = s.plans[pitDriver]
                    if (activePlan != null) {
                        if (activePlan.weatherManualMode) {
                            Text("PLANO ABANDONADO PELA CHUVA",color=Red,fontWeight=FontWeight.Black,fontSize=10.sp,modifier=Modifier.padding(top=6.dp))
                            Text("A partir da entrada de chuva, as trocas são 100% manuais. O plano não volta automaticamente quando a pista seca.",color=Muted,fontSize=9.sp,modifier=Modifier.padding(top=2.dp,bottom=4.dp))
                        } else {
                            val activeTyrePlan = activePlan.tyrePlans[activePlan.activePlan]
                            Text("PLANO ATUAL: ${activePlan.activePlan}",color=Color.White,fontWeight=FontWeight.Black,fontSize=10.sp,modifier=Modifier.padding(top=6.dp))
                            Text(planDescription(activeTyrePlan),color=Muted,fontSize=9.sp,modifier=Modifier.padding(top=2.dp,bottom=4.dp))
                            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(4.dp)){
                                listOf("A","B","C","D").forEach { id ->
                                    val p = activePlan.tyrePlans[id]
                                    Button(onClick={pitPlan(pitDriver,id);pitDriver=-1;running=true},modifier=Modifier.weight(1f),colors=ButtonDefaults.buttonColors(containerColor=if(activePlan.activePlan==id) Red else Panel2,contentColor=Color.White),contentPadding=PaddingValues(vertical=3.dp)){Text("PLANO $id",fontSize=8.sp,fontWeight=FontWeight.Black)}
                                }
                            }
                            Button(onClick={pitPlan(pitDriver,activePlan.activePlan);pitDriver=-1;running=true},modifier=Modifier.fillMaxWidth().padding(top=4.dp),colors=ButtonDefaults.buttonColors(containerColor=Red,contentColor=Color.White)){Text("MANTER PLANO ${activePlan.activePlan}",fontWeight=FontWeight.Black,fontSize=9.sp)}
                        }
                    }
                    Spacer(Modifier.height(4.dp))
                    Text("OU ESCOLHER MANUALMENTE",color=Muted,fontWeight=FontWeight.Bold,fontSize=8.sp,modifier=Modifier.padding(top=2.dp,bottom=2.dp))
                    Button(
                        onClick={pitDriver=-1;running=true},
                        modifier=Modifier.fillMaxWidth().padding(top=2.dp),
                        colors=ButtonDefaults.buttonColors(containerColor=Panel2,contentColor=Color.White)
                    ){Text("SAIR • NÃO IR AO BOX",fontWeight=FontWeight.Black)}
                }},
                confirmButton={}
            )
        }
    }
}

private fun gapText(time: Long, reference: Long, ahead: Boolean = false): String {
    val gap = (time - reference).coerceAtLeast(0L)
    return "+${gap / 1000}.${(gap % 1000) / 100}s"
}

private fun formatRaceTime(ms: Long): String {
    val totalSeconds = ms / 1000
    val hours = totalSeconds / 3600
    val minutes = (totalSeconds % 3600) / 60
    val seconds = totalSeconds % 60
    val millis = ms % 1000
    return if (hours > 0) String.format(java.util.Locale.US, "%d:%02d:%02d.%03d", hours, minutes, seconds, millis)
    else String.format(java.util.Locale.US, "%d:%02d.%03d", minutes, seconds, millis)
}

private fun formatGap(ms: Long): String {
    val seconds = ms / 1000
    val millis = ms % 1000
    return String.format(java.util.Locale.US, "+%d.%03ds", seconds, millis)
}

@Composable private fun Result(r:RaceResult,teamId:Int,store:CareerPreferences,onCalendar:()->Unit){
    val teamName=WorldDatabase.teams.first{it.id==teamId}.name
    val mine=r.classification.filter{it.teamName==teamName}
    val earned=mine.sumOf{r.points[it.driverId]?:0}
    val leader=r.classification.firstOrNull { !it.status.startsWith("DNF") }
    val leaderTime=leader?.totalTimeMs ?: 0L
    val dnfs=r.classification.filter { it.status.startsWith("DNF") }
    Column(Modifier.fillMaxSize().padding(16.dp)){
        HeaderBlock("RESULTADO","CORRIDA FINALIZADA")
        Card(Modifier.fillMaxWidth().padding(top=10.dp),colors=CardDefaults.cardColors(Panel)){
            Column(Modifier.padding(13.dp)){
                Text("SUA EQUIPE",color=Red,fontWeight=FontWeight.Black)
                mine.forEach{f->
                    Row(Modifier.fillMaxWidth().padding(top=6.dp),verticalAlignment=Alignment.CenterVertically){
                        Text("P${f.position}",color=if(f.position<=3)Red else Muted,fontWeight=FontWeight.Black,modifier=Modifier.width(34.dp))
                        Text(f.driverName,color=Color.White,fontWeight=FontWeight.Bold,modifier=Modifier.weight(1f),maxLines=1,overflow=TextOverflow.Ellipsis)
                        Text("${r.points[f.driverId]?:0} PTS",color=Color.White,fontWeight=FontWeight.Bold,fontSize=10.sp)
                    }
                }
                Text("PONTOS CONQUISTADOS: $earned",color=Color.White,fontWeight=FontWeight.Black,modifier=Modifier.padding(top=8.dp))
            }
        }
        if(leader!=null){
            Card(Modifier.fillMaxWidth().padding(top=8.dp),colors=CardDefaults.cardColors(Panel2)){
                Column(Modifier.padding(11.dp)){
                    Text("TEMPO DO LÍDER",color=Red,fontWeight=FontWeight.Black,fontSize=10.sp)
                    Text(formatRaceTime(leaderTime),color=Color.White,fontWeight=FontWeight.Black,fontSize=19.sp)
                    Text("${leader.driverName} • P1",color=Muted,fontSize=10.sp)
                }
            }
        }
        LazyColumn(Modifier.weight(1f),contentPadding=PaddingValues(vertical=10.dp),verticalArrangement=Arrangement.spacedBy(3.dp)){
            items(r.classification){f->
                val resultTeam=WorldDatabase.teams.firstOrNull { it.name.equals(f.teamName, ignoreCase = true) }
                val finished=!f.status.startsWith("DNF")
                val gap=if(finished && leader!=null) (f.totalTimeMs-leaderTime).coerceAtLeast(0L) else 0L
                Row(Modifier.fillMaxWidth().background(if(f.position<=3)Color(0xFF251414) else if(!finished) Color(0xFF2A1113) else Panel,RoundedCornerShape(5.dp)).padding(9.dp),verticalAlignment=Alignment.CenterVertically){
                    Text("P${f.position}",color=if(f.position<=3)Red else if(!finished)Red else Muted,fontWeight=FontWeight.Black,modifier=Modifier.width(38.dp))
                    TeamLogo(f.teamName,resultTeam?.id ?: 0,Modifier.size(24.dp))
                    Spacer(Modifier.width(5.dp))
                    Column(Modifier.weight(1f)){
                        Text(f.driverName,color=Color.White,fontWeight=if(!finished) FontWeight.Black else FontWeight.Normal,maxLines=1,overflow=TextOverflow.Ellipsis)
                        Text(if(!finished) "ABANDONOU • ${f.laps} voltas" else if(f.position==leader?.position) "LÍDER" else "GAP ${formatGap(gap)}",color=if(!finished) Red else Muted,fontSize=8.sp)
                    }
                    Column(horizontalAlignment=Alignment.End){
                        Text("${r.points[f.driverId]?:0} PTS",color=if((r.points[f.driverId]?:0)>0) Color.White else Muted,fontSize=9.sp,fontWeight=FontWeight.Bold)
                        if(!finished) Text("DNF",color=Red,fontSize=8.sp,fontWeight=FontWeight.Black)
                    }
                }
            }
        }
        Text("ABANDONOS: ${dnfs.size} • Safety Car ${r.safetyCarLaps} • VSC ${r.vscLaps} • Campeonato: ${store.constructorPoints()[teamId]?:0} PTS",color=Muted,fontSize=9.sp)
        Button(onClick=onCalendar,modifier=Modifier.fillMaxWidth().height(48.dp),colors=ButtonDefaults.buttonColors(containerColor=Red,contentColor=Color.White)){Text("IR PARA CALENDÁRIO",fontWeight=FontWeight.Black)}
    }
}

@Composable
private fun RaceImage(round:RoundDefinition, modifier:Modifier = Modifier) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var bitmap by remember(round.round) { mutableStateOf<android.graphics.Bitmap?>(null) }
    LaunchedEffect(round.round) {
        bitmap = withContext(Dispatchers.IO) { ExternalAssets.loadGrandPrixImage(context, round.grandPrix) }
    }
    if (bitmap != null) {
        Image(bitmap = bitmap!!.asImageBitmap(), contentDescription = round.grandPrix, modifier = modifier.clip(RoundedCornerShape(8.dp)), contentScale = androidx.compose.ui.layout.ContentScale.Fit)
    } else {
        Box(modifier.clip(RoundedCornerShape(8.dp)).background(Panel2).border(1.dp, Line, RoundedCornerShape(8.dp)), contentAlignment = Alignment.Center) {
            Text("IMAGEM DO GP", color = Muted, fontWeight = FontWeight.Black, fontSize = 9.sp)
        }
    }
}

@Composable
private fun DriverPhoto(driverId:Int, driverName:String, modifier:Modifier = Modifier) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var bitmap by remember(driverId, driverName) { mutableStateOf<android.graphics.Bitmap?>(null) }
    LaunchedEffect(driverId, driverName) {
        bitmap = withContext(Dispatchers.IO) { ExternalAssets.loadDriverPhoto(context, driverId, driverName) }
    }
    if (bitmap != null) {
        Image(bitmap = bitmap!!.asImageBitmap(), contentDescription = "Foto $driverName", modifier = modifier, contentScale = androidx.compose.ui.layout.ContentScale.Crop)
    } else {
        Box(modifier.background(Panel2, RoundedCornerShape(6.dp)).border(1.dp, Line, RoundedCornerShape(6.dp)), contentAlignment = Alignment.Center) {
            Text(driverName.split(" ").mapNotNull { it.firstOrNull() }.take(2).joinToString(""), color = Muted, fontWeight = FontWeight.Black, fontSize = 9.sp)
        }
    }
}

@Composable
private fun MovementBadge(movement:Int, hasPrevious:Boolean, modifier:Modifier = Modifier) {
    val label = when {
        !hasPrevious -> "•"
        movement > 0 -> "▲$movement"
        movement < 0 -> "▼${-movement}"
        else -> "—"
    }
    val color = when {
        !hasPrevious || movement == 0 -> Muted
        movement > 0 -> Green
        else -> Red
    }
    Text(label, color=color, fontWeight=FontWeight.Black, fontSize=9.sp, modifier=modifier)
}

@Composable
private fun TeamLogo(teamName:String, teamId:Int, modifier:Modifier = Modifier) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var bitmap by remember(teamId, teamName) { mutableStateOf<android.graphics.Bitmap?>(null) }
    LaunchedEffect(teamId, teamName) {
        bitmap = withContext(Dispatchers.IO) { ExternalAssets.loadTeamLogo(context, teamId, teamName) }
    }
    if (bitmap != null) {
        Image(bitmap = bitmap!!.asImageBitmap(), contentDescription = "Escudo $teamName", modifier = modifier, contentScale = androidx.compose.ui.layout.ContentScale.Fit)
    } else {
        Box(modifier.background(Panel2, RoundedCornerShape(6.dp)).border(1.dp, Line, RoundedCornerShape(6.dp)), contentAlignment = Alignment.Center) {
            Text("${teamName.take(2).uppercase()}", color = Muted, fontWeight = FontWeight.Black, fontSize = 8.sp)
        }
    }
}

private fun initialManagerState(teamId:Int,store:CareerPreferences):TeamManagerState {
    val t=WorldDatabase.teams.first{it.id==teamId}
    val base=TeamManagerState(season=store.season,round=store.roundIndex+1,playerTeamId=teamId,car=InitialTeamProfile.carState(t),garage=TeamGarageFactory.fromInitial(t),facilities=InitialTeamProfile.teamFacilities(t.initialLevel),finance=TeamFinanceState(75_000_000L))
    val sponsors=store.loadSponsors(teamId)
    val market=store.loadDriverMarket() ?: DriverMarketEngine(20261003).initialState(store.season)
    store.saveDriverMarket(market)
    var finance=store.loadFinance(teamId,base.finance)
    finance = store.applyAnnualDriverSalariesOnce(teamId, store.season, finance, market)
    store.saveFacilities(teamId,base.facilities)
    return base.copy(finance=finance,sponsor=sponsors.firstOrNull { it.slot==1 } ?: store.loadSponsor(teamId,base.sponsor),sponsors=sponsors,driverMarket=market)
}
private fun componentLabel(c:CarComponent)=when(c){CarComponent.ENGINE->"Unidade de potência";CarComponent.CHASSIS->"Chassi";CarComponent.FRONT_WING->"Asa dianteira";CarComponent.REAR_WING->"Asa traseira";CarComponent.BRAKES->"Freios";CarComponent.ELECTRIC_POWER_UNIT->"Unidade de potência elétrica"}
private fun componentDuration(c:CarComponent)=when(c){CarComponent.ENGINE->4;CarComponent.CHASSIS->3;CarComponent.FRONT_WING->2;CarComponent.REAR_WING->2;CarComponent.BRAKES->2;CarComponent.ELECTRIC_POWER_UNIT->4}
@Composable private fun HistoryResult(round:Int,result:RaceResult?){
    if(result==null){Text("Nenhuma classificação salva para o Round $round",color=Muted,modifier=Modifier.padding(16.dp));return}
    val leader=result.classification.firstOrNull { !it.status.startsWith("DNF") }
    val leaderTime=leader?.totalTimeMs ?: 0L
    Column(Modifier.fillMaxSize().padding(12.dp)){
        HeaderBlock("ROUND $round","CLASSIFICAÇÃO SALVA")
        if(leader!=null){
            Card(Modifier.fillMaxWidth().padding(top=8.dp),colors=CardDefaults.cardColors(Panel2)){
                Column(Modifier.padding(10.dp)){
                    Text("TEMPO DO LÍDER",color=Red,fontWeight=FontWeight.Black,fontSize=10.sp)
                    Text(formatRaceTime(leaderTime),color=Color.White,fontWeight=FontWeight.Black,fontSize=18.sp)
                    Text("${leader.driverName} • P1",color=Muted,fontSize=9.sp)
                }
            }
        }
        LazyColumn(Modifier.weight(1f),contentPadding=PaddingValues(vertical=8.dp),verticalArrangement=Arrangement.spacedBy(3.dp)){
            items(result.classification){f->
                val historyTeam=WorldDatabase.teams.firstOrNull { it.name.equals(f.teamName, ignoreCase = true) }
                val finished=!f.status.startsWith("DNF")
                val gap=if(finished && leader!=null) (f.totalTimeMs-leaderTime).coerceAtLeast(0L) else 0L
                Row(Modifier.fillMaxWidth().background(if(f.position<=3)Color(0xFF251414) else if(!finished) Color(0xFF2A1113) else Panel,RoundedCornerShape(5.dp)).padding(8.dp),verticalAlignment=Alignment.CenterVertically){
                    Text("P${f.position}",color=if(f.position<=3)Red else if(!finished)Red else Muted,fontWeight=FontWeight.Black,modifier=Modifier.width(38.dp))
                    TeamLogo(f.teamName,historyTeam?.id ?: 0,Modifier.size(22.dp))
                    Spacer(Modifier.width(5.dp))
                    Column(Modifier.weight(1f)){
                        Text(f.driverName,color=Color.White,maxLines=1,overflow=TextOverflow.Ellipsis)
                        Text(if(!finished) "ABANDONOU • ${f.laps} voltas" else if(f.position==leader?.position) "LÍDER" else "GAP ${formatGap(gap)}",color=if(!finished) Red else Muted,fontSize=8.sp)
                    }
                    Text("${result.points[f.driverId]?:0} PTS",color=Muted,fontSize=9.sp)
                }
            }
        }
        Text("ABANDONOS: ${result.classification.count { it.status.startsWith("DNF") }}",color=Muted,fontSize=9.sp)
    }
}

@Composable
private fun SeasonArchive(store: CareerPreferences) {
    val db = store.history
    val seasons = db.seasons()
    var scope by remember { mutableIntStateOf(0) }
    var selectedSeason by remember(seasons) { mutableIntStateOf(seasons.firstOrNull() ?: store.season) }
    LazyColumn(
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        item { HistorySection("📅 TEMPORADA", "Registro final somente após as 30 corridas") }
        item { HistoryScopeSelector(scope) { scope = it } }
        if (seasons.isEmpty()) {
            item { EmptyHistory("A temporada atual ainda está em andamento. O registro só será criado depois do GP 30.") }
        } else {
            item {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    seasons.forEach { season ->
                        Button(
                            onClick = { selectedSeason = season },
                            colors = ButtonDefaults.buttonColors(containerColor = if (selectedSeason == season) Red else Panel2, contentColor = Color.White),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 5.dp)
                        ) { Text(season.toString(), fontSize = 8.sp, fontWeight = FontWeight.Black) }
                    }
                }
            }
            if (scope == 0) {
                val rows = db.driverSeasonRecords(selectedSeason)
                item { HistorySection("PILOTOS • $selectedSeason", "80 pilotos • Ano / Posição / Piloto / Equipe / Pontos / Vitórias / Poles / Voltas + rápidas / DNF / GPs") }
                items(rows) { SeasonDriverRow(it) }
            } else {
                val rows = db.constructorSeasonRecords(selectedSeason)
                item { HistorySection("CONSTRUTORES • $selectedSeason", "40 equipes • Ano / Posição / Equipe / Pontos / Vitórias / Poles / Voltas + rápidas / DNF / GPs") }
                items(rows) { SeasonConstructorRow(it) }
            }
        }
    }
}

@Composable
private fun HistoryScreen(store: CareerPreferences) {
    val db = store.history
    var historyScope by remember { mutableIntStateOf(0) }
    var historyCategory by remember { mutableIntStateOf(0) }

    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        item { HistorySection("📖 HISTÓRIA", "Registro atualizado imediatamente após cada GP") }
        item { HistoryScopeSelector(historyScope) { historyScope = it } }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("🏆 VITÓRIAS", "🥇 POLES", "⚡ VOLTAS + RÁPIDAS", "👑 CAMPEÕES").chunked(2).forEach { row ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        row.forEach { label ->
                            val index = listOf("🏆 VITÓRIAS", "🥇 POLES", "⚡ VOLTAS + RÁPIDAS", "👑 CAMPEÕES").indexOf(label)
                            Button(onClick = { historyCategory = index }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = if (historyCategory == index) Red else Panel2, contentColor = Color.White), contentPadding = PaddingValues(vertical = 6.dp)) {
                                Text(label, fontSize = 8.sp, fontWeight = FontWeight.Black)
                            }
                        }
                    }
                }
            }
        }
        when (historyCategory) {
            0 -> {
                val rows = db.victories()
                item { HistorySection("🏆 VITÓRIAS • ${if (historyScope == 0) "PILOTOS" else "CONSTRUTORES"}", "1 vencedor por GP") }
                items(rows) { r -> HistoryHistoryRow(r, "VENCEDOR", formatRaceTime(r.totalTimeMs), showDriver = historyScope == 0) }
            }
            1 -> {
                val rows = db.poles()
                item { HistorySection("🥇 POLES • ${if (historyScope == 0) "PILOTOS" else "CONSTRUTORES"}", "1 pole por GP") }
                items(rows) { r ->
                    HistoryPanel {
                        HistoryEventHeader(r.season, r.round, r.grandPrix, r.teamId, r.teamName, r.driverName, showDriver = historyScope == 0, driverId = r.driverId)
                        Text("TEMPO • ${formatMs(r.timeMs)}", color = Color.White, fontWeight = FontWeight.Black, fontSize = 9.sp)
                    }
                }
            }
            2 -> {
                val rows = db.fastestLaps()
                item { HistorySection("⚡ VOLTAS + RÁPIDAS • ${if (historyScope == 0) "PILOTOS" else "CONSTRUTORES"}", "1 volta mais rápida por GP") }
                items(rows) { r -> HistoryHistoryRow(r, "VOLTA MAIS RÁPIDA", formatMs(r.fastestLapTimeMs), showDriver = historyScope == 0) }
            }
            3 -> {
                if (historyScope == 0) {
                    val rows = db.driverChampions()
                    item { HistorySection("👑 CAMPEÕES • PILOTOS", "1 campeão por temporada • disponível somente após o GP 30") }
                    items(rows) { c ->
                        HistoryPanel {
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Text("${c.season}", color = Red, fontWeight = FontWeight.Black, modifier = Modifier.width(46.dp))
                                TeamLogo(c.teamName, c.teamId, Modifier.size(30.dp))
                                Column(Modifier.weight(1f).padding(start = 7.dp, end = 6.dp)) {
                                    Text(c.driverName, color = Color.White, fontWeight = FontWeight.Black, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text(c.teamName, color = Muted, fontSize = 8.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                                DriverPhoto(c.driverId, c.driverName, Modifier.size(38.dp).clip(RoundedCornerShape(6.dp)))
                                Spacer(Modifier.width(7.dp))
                                Text("${c.points} PTS", color = Color.White, fontWeight = FontWeight.Black, fontSize = 9.sp)
                            }
                        }
                    }
                } else {
                    val rows = db.constructorChampions()
                    item { HistorySection("👑 CAMPEÕES • CONSTRUTORES", "1 campeão por temporada • disponível somente após o GP 30") }
                    items(rows) { c ->
                        HistoryPanel {
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Text("${c.season}", color = Red, fontWeight = FontWeight.Black, modifier = Modifier.width(46.dp))
                                TeamLogo(c.teamName, c.teamId, Modifier.size(34.dp))
                                Column(Modifier.weight(1f).padding(start = 7.dp)) { Text(c.teamName, color = Color.White, fontWeight = FontWeight.Black) }
                                Text("${c.points} PTS", color = Color.White, fontWeight = FontWeight.Black, fontSize = 9.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun HallOfFameScreen(store: CareerPreferences) {
    val db = store.history
    var hallScope by remember { mutableIntStateOf(0) }
    var hallMetric by remember { mutableIntStateOf(0) }
    val metricLabels = if (hallScope == 0) listOf("👑 CAMPEÕES", "🏆 VITÓRIAS", "🥇 POLES", "⚡ VOLTAS + RÁPIDAS", "📊 PONTOS", "🏁 GPs")
    else listOf("👑 CAMPEÕES", "🏆 VITÓRIAS", "🥇 POLES", "⚡ VOLTAS + RÁPIDAS", "📊 PONTOS")
    val metric = when (hallMetric) { 0 -> HistoricalDatabase.HallMetric.CHAMPIONS; 1 -> HistoricalDatabase.HallMetric.WINS; 2 -> HistoricalDatabase.HallMetric.POLES; 3 -> HistoricalDatabase.HallMetric.FASTEST_LAPS; 4 -> HistoricalDatabase.HallMetric.POINTS; else -> HistoricalDatabase.HallMetric.GPS }
    val scope = if (hallScope == 0) HistoricalDatabase.HallScope.DRIVERS else HistoricalDatabase.HallScope.CONSTRUCTORS
    val rows = db.hallRanking(scope, metric).filter { it.value > 0 }
    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        item { HistorySection("🏛️ HALL DA FAMA", "Ranking histórico • atualizado sempre que uma nova informação entra no histórico") }
        item { HistoryScopeSelector(hallScope) { hallScope = it; hallMetric = 0 } }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                metricLabels.chunked(2).forEach { row ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        row.forEach { label ->
                            val index = metricLabels.indexOf(label)
                            Button(onClick = { hallMetric = index }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = if (hallMetric == index) Red else Panel2, contentColor = Color.White), contentPadding = PaddingValues(vertical = 6.dp)) { Text(label, fontSize = 8.sp, fontWeight = FontWeight.Black) }
                        }
                        if (row.size == 1) Spacer(Modifier.weight(1f))
                    }
                }
            }
        }
        item { HistorySection("RANKING", "Maior para menor • ↑ subiu • ↓ desceu • → manteve • NOVO") }
        if (rows.isEmpty()) item { EmptyHistory("Ainda não há registros suficientes para este ranking.") }
        else items(rows) { h -> HallRow(h, hallScope == 0) }
    }
}

@Composable
private fun RecordsScreen(store: CareerPreferences) {
    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        item { HistorySection("🏅 RECORDES", "Área exclusiva para os recordes históricos do jogo") }
        item { EmptyHistory("Os recordes serão definidos em uma próxima etapa. Nenhum recorde foi criado automaticamente.") }
    }
}

@Composable
private fun HistoryScopeSelector(selected: Int, onSelect: (Int) -> Unit) {
    Row(
        Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(9.dp)).padding(3.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        listOf("PILOTOS", "CONSTRUTORES").forEachIndexed { index, label ->
            Button(
                onClick = { onSelect(index) },
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = if (selected == index) Red else Panel2, contentColor = Color.White),
                contentPadding = PaddingValues(vertical = 6.dp)
            ) { Text(label, fontSize = 9.sp, fontWeight = FontWeight.Black) }
        }
    }
}

@Composable
private fun SeasonDriverRow(r: HistoricalDatabase.DriverSeasonRecord) {
    HistoryPanel {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("P${r.position}", color = if (r.position <= 3) Red else Muted, fontWeight = FontWeight.Black, modifier = Modifier.width(34.dp))
            TeamLogo(r.teamName, r.teamId, Modifier.size(30.dp))
            Column(Modifier.weight(1f).padding(start = 7.dp, end = 6.dp)) {
                Text(r.driverName, color = Color.White, fontWeight = FontWeight.Black, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(r.teamName, color = Muted, fontSize = 8.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("V ${r.wins} • P ${r.poles} • ⚡ ${r.fastestLaps} • DNF ${r.dnf} • GPs ${r.gps}", color = Muted, fontSize = 7.sp)
            }
            DriverPhoto(r.driverId, r.driverName, Modifier.size(38.dp).clip(RoundedCornerShape(6.dp)))
            Spacer(Modifier.width(7.dp))
            Text("${r.points} PTS", color = Color.White, fontWeight = FontWeight.Black, fontSize = 9.sp)
        }
    }
}

@Composable
private fun SeasonConstructorRow(r: HistoricalDatabase.ConstructorSeasonRecord) {
    HistoryPanel {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("P${r.position}", color = if (r.position <= 3) Red else Muted, fontWeight = FontWeight.Black, modifier = Modifier.width(34.dp))
            TeamLogo(r.teamName, r.teamId, Modifier.size(30.dp))
            Column(Modifier.weight(1f).padding(start = 7.dp)) {
                Text(r.teamName, color = Color.White, fontWeight = FontWeight.Black, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("V ${r.wins} • P ${r.poles} • ⚡ ${r.fastestLaps} • DNF ${r.dnf} • GPs ${r.gps}", color = Muted, fontSize = 7.sp)
            }
            Text("${r.points} PTS", color = Color.White, fontWeight = FontWeight.Black, fontSize = 9.sp)
        }
    }
}

@Composable
private fun HistoryEventHeader(season: Int, round: Int, grandPrix: String, teamId: Int, teamName: String, driverName: String, showDriver: Boolean = true, driverId: Int = 0) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text("$season • R$round", color = Red, fontWeight = FontWeight.Black, fontSize = 9.sp, modifier = Modifier.width(72.dp))
        TeamLogo(teamName, teamId, Modifier.size(30.dp))
        Column(Modifier.weight(1f).padding(start = 7.dp, end = 6.dp)) {
            Text(if (showDriver) driverName else teamName, color = Color.White, fontWeight = FontWeight.Black, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(if (showDriver) "$grandPrix • $teamName" else "$grandPrix • $driverName", color = Muted, fontSize = 8.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        if (showDriver) DriverPhoto(driverId, driverName, Modifier.size(38.dp).clip(RoundedCornerShape(6.dp)))
    }
}

@Composable
private fun HistoryHistoryRow(r: HistoricalDatabase.RaceRecord, label: String, time: String, showDriver: Boolean = true) {
    HistoryPanel {
        HistoryEventHeader(r.season, r.round, r.grandPrix, r.teamId, r.teamName, r.driverName, showDriver, r.driverId)
        Row(Modifier.fillMaxWidth().padding(top = 7.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, color = Muted, fontSize = 8.sp, fontWeight = FontWeight.Black)
            Text("TEMPO • $time", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Black)
        }
    }
}

@Composable
private fun HallRow(h: HistoricalDatabase.HallEntry, showDriverPhoto: Boolean) {
    HistoryPanel {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("#${h.position}", color = if (h.position <= 3) Red else Muted, fontWeight = FontWeight.Black, modifier = Modifier.width(36.dp))
            if (h.teamId > 0) TeamLogo(h.teamName, h.teamId, Modifier.size(30.dp))
            Column(Modifier.weight(1f).padding(start = 7.dp, end = 6.dp)) {
                Text(h.name, color = Color.White, fontWeight = FontWeight.Black, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (h.teamName.isNotBlank()) Text(h.teamName, color = Muted, fontSize = 7.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            if (showDriverPhoto) {
                DriverPhoto(h.id, h.name, Modifier.size(38.dp).clip(RoundedCornerShape(6.dp)))
                Spacer(Modifier.width(7.dp))
            }
            Column(horizontalAlignment = Alignment.End) {
                Text("${h.value}", color = Color.White, fontWeight = FontWeight.Black, fontSize = 12.sp)
                Text(
                    when {
                        h.movement == Int.MIN_VALUE -> "NOVO"
                        h.movement > 0 -> "↑${h.movement}"
                        h.movement < 0 -> "↓${-h.movement}"
                        else -> "→"
                    },
                    color = when {
                        h.movement > 0 -> Green
                        h.movement < 0 -> Red
                        else -> Muted
                    },
                    fontSize = 8.sp,
                    fontWeight = FontWeight.Black
                )
            }
        }
    }
}

@Composable
private fun HistorySection(title: String, subtitle: String) {
    Column(Modifier.padding(top = 2.dp, bottom = 2.dp)) {
        Text(title, color = Color.White, fontWeight = FontWeight.Black, fontSize = 14.sp)
        Text(subtitle, color = Muted, fontSize = 9.sp, modifier = Modifier.padding(top = 2.dp))
    }
}

@Composable
private fun HistoryPanel(content: @Composable ColumnScope.() -> Unit) {
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(Panel)) { Column(Modifier.padding(7.dp), content = content) }
}

@Composable
private fun HistoryRaceRow(r: HistoricalDatabase.RaceRecord, showPosition: Boolean, emphasizeTime: Boolean = false) {
    val finished = !r.status.startsWith("DNF")
    HistoryPanel {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            if (showPosition) Text("P${r.position}", color = if (r.position <= 3) Red else Muted, fontWeight = FontWeight.Black, modifier = Modifier.width(34.dp))
            else Text("R${r.round}", color = Red, fontWeight = FontWeight.Black, modifier = Modifier.width(34.dp))
            TeamLogo(r.teamName, r.teamId, Modifier.size(26.dp))
            Column(Modifier.weight(1f).padding(start = 7.dp)) {
                Text(r.driverName, color = Color.White, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("${r.grandPrix} • ${r.teamName} • ${r.season}", color = Muted, fontSize = 8.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(if (!finished) "ABANDONOU • ${r.laps} voltas" else if (r.position == 1) "VENCEDOR" else "GAP ${formatGap(r.gapToLeaderMs)}", color = if (!finished) Red else Muted, fontSize = 8.sp)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text("${r.points} PTS", color = Color.White, fontWeight = FontWeight.Black, fontSize = 9.sp)
                Text(formatRaceTime(r.totalTimeMs), color = if (emphasizeTime) Red else Muted, fontWeight = FontWeight.Bold, fontSize = 8.sp)
            }
        }
    }
}

@Composable
private fun EmptyHistory(message: String) {
    HistoryPanel { Text(message, color = Muted, fontSize = 10.sp) }
}

@Composable
private fun TeamSelect(onSelect: (Int) -> Unit) {
    Column(Modifier.fillMaxSize().statusBarsPadding().padding(16.dp)) {
        HeaderBlock("F1 MANAGER", "ESCOLHA SUA EQUIPE")
        Text("40 equipes • 80 pilotos", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(vertical = 8.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp), contentPadding = PaddingValues(bottom = 16.dp)) {
            items(WorldDatabase.teams.sortedWith(compareByDescending<com.f1teammanager.core.season.TeamDefinition> { it.baseCar }.thenByDescending { it.engine }.thenByDescending { it.reliability }.thenBy { it.id })) { t ->
                Card(Modifier.fillMaxWidth().clickable { onSelect(t.id) }, colors = CardDefaults.cardColors(Panel)) {
                    Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        TeamLogo(t.name,t.id,Modifier.size(48.dp)); Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(t.name, color = Color.White, fontWeight = FontWeight.Black)
                            Text("Força ${t.baseCar} • Motor ${t.engine} • Confiabilidade ${t.reliability}", color = Muted, fontSize = 10.sp)
                        }
                        Text("ESCOLHER", color = Red, fontWeight = FontWeight.Black, fontSize = 10.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun Standings(teamId: Int, store: CareerPreferences) {
    var tab by remember { mutableIntStateOf(0) }
    val driverPoints=store.driverPoints()
    val constructorPoints=store.constructorPoints()
    val market = store.loadDriverMarket()
    val drivers = (market?.contracts?.filter { it.activeIn(store.season) }?.mapNotNull { deal ->
        val d=WorldDatabase.allDrivers.firstOrNull { it.id==deal.driverId } ?: return@mapNotNull null
        val t=WorldDatabase.teams.firstOrNull { it.id==deal.teamId } ?: return@mapNotNull null
        Triple(d,t,driverPoints[d.id]?:0)
    } ?: WorldDatabase.drivers.map { d -> val t=WorldDatabase.teams.first{it.id==d.teamId}; Triple(d,t,driverPoints[d.id]?:0) }).sortedByDescending{it.third}
    val constructors=WorldDatabase.teams.map{t->t to (constructorPoints[t.id]?:0)}.sortedWith(compareByDescending<Pair<com.f1teammanager.core.season.TeamDefinition,Int>>{it.second}.thenBy{it.first.id})
    val previousDrivers = store.previousDriverPositions()
    val previousConstructors = store.previousConstructorPositions()
    val hasPrevious = previousDrivers.isNotEmpty() || previousConstructors.isNotEmpty()
    Column(Modifier.fillMaxSize().padding(12.dp)){
        HeaderBlock("CAMPEONATO","PILOTOS E CONSTRUTORES")
        Row(Modifier.fillMaxWidth().background(Panel,RoundedCornerShape(8.dp)).padding(4.dp),horizontalArrangement=Arrangement.spacedBy(4.dp)){
            listOf("PILOTOS","CONSTRUTORES").forEachIndexed{index,label->Button(onClick={tab=index},modifier=Modifier.weight(1f),colors=ButtonDefaults.buttonColors(containerColor=if(tab==index)Red else Panel2,contentColor=Color.White),contentPadding=PaddingValues(vertical=8.dp)){Text(label,fontWeight=FontWeight.Black,fontSize=10.sp)}}
        }
        if(tab==0){
            LazyColumn(Modifier.weight(1f),contentPadding=PaddingValues(vertical=8.dp),verticalArrangement=Arrangement.spacedBy(3.dp)){
                items(drivers){(d,t,pts)->
                    val position = drivers.indexOfFirst{it.first.id==d.id}+1
                    val previous = previousDrivers[d.id]
                    val movement = if(hasPrevious && previous != null) previous-position else 0
                    val abovePoints = if(position > 1) drivers[position-2].third else null
                    val gap = abovePoints?.let { it - pts }
                    Row(Modifier.fillMaxWidth().background(if(t.id==teamId)Color(0xFF251414)else Panel,RoundedCornerShape(5.dp)).padding(horizontal=8.dp,vertical=7.dp),verticalAlignment=Alignment.CenterVertically){
                        Text("P$position",color=if(t.id==teamId)Red else Muted,fontWeight=FontWeight.Black,modifier=Modifier.width(36.dp))
                        MovementBadge(movement,hasPrevious,Modifier.width(30.dp))
                        DriverPhoto(d.id,d.name,Modifier.size(36.dp).clip(RoundedCornerShape(6.dp)))
                        Spacer(Modifier.width(8.dp))
                        Text(d.name,color=Color.White,modifier=Modifier.weight(1f),maxLines=1,overflow=TextOverflow.Ellipsis)
                        TeamLogo(t.name,t.id,Modifier.size(24.dp))
                        Spacer(Modifier.width(7.dp))
                        Column(horizontalAlignment=Alignment.End){
                            Text("$pts PTS",color=Color.White,fontWeight=FontWeight.Black,fontSize=10.sp)
                            if(gap != null) Text("~ $gap",color=Muted,fontSize=8.sp)
                        }
                    }
                }
            }
        }else{
            LazyColumn(Modifier.weight(1f),contentPadding=PaddingValues(vertical=8.dp),verticalArrangement=Arrangement.spacedBy(3.dp)){
                items(constructors){(t,pts)->
                    val position = constructors.indexOfFirst{it.first.id==t.id}+1
                    val previous = previousConstructors[t.id]
                    val movement = if(hasPrevious && previous != null) previous-position else 0
                    val abovePoints = if(position > 1) constructors[position-2].second else null
                    val gap = abovePoints?.let { it - pts }
                    Row(Modifier.fillMaxWidth().background(if(t.id==teamId)Color(0xFF251414)else Panel,RoundedCornerShape(5.dp)).padding(horizontal=8.dp,vertical=8.dp),verticalAlignment=Alignment.CenterVertically){
                        Text("P$position",color=if(t.id==teamId)Red else Muted,fontWeight=FontWeight.Black,modifier=Modifier.width(36.dp))
                        MovementBadge(movement,hasPrevious,Modifier.width(30.dp))
                        TeamLogo(t.name,t.id,Modifier.size(28.dp))
                        Spacer(Modifier.width(7.dp))
                        Text(t.name,color=Color.White,modifier=Modifier.weight(1f),fontWeight=if(t.id==teamId)FontWeight.Black else FontWeight.Normal,maxLines=1,overflow=TextOverflow.Ellipsis)
                        Column(horizontalAlignment=Alignment.End){
                            Text("$pts PTS",color=Color.White,fontWeight=FontWeight.Black,fontSize=11.sp)
                            if(gap != null) Text("~ $gap",color=Muted,fontSize=8.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun Finance(store: CareerPreferences, teamId: Int, state:TeamManagerState, message:String, signSponsor:(SponsorContract)->Unit) {
    val sponsorshipEngine = remember { com.f1teammanager.core.manager.TeamSponsorshipEngine(20261006) }
    val offers = remember(teamId, store.season, state.round, state.facilities.level(FacilityType.MARKETING), state.sponsors.size) {
        (1..5).map { slot -> sponsorshipEngine.offersForSlot(teamId, store.season, slot, state.facilities.level(FacilityType.MARKETING), state.round) }
    }
    LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
        item{
            HeaderBlock("FINANÇAS","ORÇAMENTO, RECEITAS E PATROCÍNIOS")
            Spacer(Modifier.height(4.dp))
            Text("Centro Comercial nível ${state.facilities.level(FacilityType.MARKETING)} • categorias definidas pela instalação",color=Muted,fontSize=9.sp)
        }
        item{Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(Panel)){Column(Modifier.padding(14.dp)){
            Text("SALDO",color=Red,fontWeight=FontWeight.Black)
            Text(formatMoney(state.finance.budget),color=Color.White,fontSize=28.sp,fontWeight=FontWeight.Black)
            Text("Receitas da temporada: ${formatMoney(state.finance.seasonIncome)}",color=Green,fontSize=10.sp)
            Text("Despesas da temporada: ${formatMoney(state.finance.seasonExpenses)}",color=Muted,fontSize=10.sp)
            Text("Patrocínios ativos: ${state.sponsors.count { it.active }}/5",color=Color.White,fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=6.dp))
        }}}
        if(message.isNotBlank()) item{Text(message,color=Green,fontWeight=FontWeight.Bold,fontSize=10.sp)}
        item{SectionTitle("5 ESPAÇOS DE PATROCÍNIO")}
        items(offers.indices.toList()){slotIndex->
            val slot=slotIndex+1
            val signed=state.sponsors.firstOrNull { it.slot==slot && it.active }
            Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(Panel)){Column(Modifier.padding(12.dp)){
                Text(if(slot==1) "SLOT 1 • MASTER / PRINCIPAL" else "SLOT $slot • PATROCINADOR SECUNDÁRIO",color=if(slot==1) Red else Color.White,fontWeight=FontWeight.Black)
                if(signed!=null) {
                    Text("ATIVO: ${signed.name}",color=Green,fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=5.dp))
                    Text("${signed.category} • Entrada ${formatMoney(signed.upfront)} • ${formatMoney(signed.racePayment)}/GP • ${signed.racesRemaining}/${signed.races} corridas",color=Muted,fontSize=9.sp)
                    Text("Meta quali P${signed.qualifyingTarget}: +${formatMoney(signed.qualifyingBonus)} • Meta corrida P${signed.raceTarget}: +${formatMoney(signed.raceTargetBonus)}",color=Muted,fontSize=8.sp,modifier=Modifier.padding(top=3.dp))
                } else {
                    offers[slotIndex].forEach { o ->
                        Column(Modifier.padding(top=9.dp)){
                            Text("${o.sponsor.name} • ${o.category.name}",color=Color.White,fontWeight=FontWeight.Bold,fontSize=15.sp)
                            Text("Entrada ${formatMoney(o.sponsor.upfront)} • ${formatMoney(o.sponsor.racePayment)}/GP • ${formatMoney(o.sponsor.pointsBonus)}/ponto",color=Muted,fontSize=9.sp)
                            Text("${o.sponsor.races} corridas • Meta quali P${o.sponsor.qualifyingTarget}: +${formatMoney(o.sponsor.qualifyingBonus)} • Meta corrida P${o.sponsor.raceTarget}: +${formatMoney(o.sponsor.raceTargetBonus)}",color=Muted,fontSize=8.sp)
                            Button(onClick={signSponsor(o.sponsor)},modifier=Modifier.fillMaxWidth().padding(top=5.dp),colors=ButtonDefaults.buttonColors(containerColor=Red,contentColor=Color.White)){Text("ACEITAR ${o.sponsor.name}",fontWeight=FontWeight.Black,fontSize=10.sp)}
                        }
                    }
                }
            }}
        }
        item{SectionTitle("REGRAS DO CENTRO COMERCIAL")}
        item{Text("Nível 0–1: Básico • 2–3: Básico/Regional • 4–5: Regional/Nacional • 6–7: Nacional/Internacional • 8: Internacional/Premium • 9: Internacional/Premium/Global • 10: Premium/Global. Níveis altos aumentam a chance das categorias superiores, sem tornar o nível 10 exclusivamente Global.",color=Muted,fontSize=10.sp)}
        item{Text("Recomendação aplicada: o Slot 1 usa exclusivamente o pool Master; Slots 2–5 usam o pool secundário. O mesmo patrocinador não pode ocupar dois slots ativos ao mesmo tempo. Ao fim do contrato, o espaço volta ao mercado e recebe 3 novas propostas.",color=Muted,fontSize=10.sp)}
    }
}

@Composable
private fun DriverMarket(
    store: CareerPreferences,
    teamId: Int,
    currentWeek: Int,
    selectedDriverId: Int,
    state: DriverMarketState,
    message: String,
    onSelect: (Int) -> Unit,
    onInterest: (Int, Int?) -> Unit,
    onProposal: (Int, Int?, Int, Long, DriverTeamRole) -> Unit,
    onCounter: (com.f1teammanager.core.manager.DriverOffer, Int?, Int, Long, DriverTeamRole) -> Unit,
    onAcceptCounter: (com.f1teammanager.core.manager.DriverOffer) -> Unit,
    onRejectCounter: (com.f1teammanager.core.manager.DriverOffer) -> Unit,
    onRenew: (Int, Int, Long, DriverTeamRole) -> Unit,
    onAcceptIncoming: (com.f1teammanager.core.manager.DriverOffer) -> Unit,
    onRejectIncoming: (com.f1teammanager.core.manager.DriverOffer) -> Unit,
    onScout: (Int) -> Unit
) {
    var replacementId by remember(teamId) { mutableIntStateOf(-1) }
    var filter by remember { mutableStateOf("TODOS") }
    var search by remember { mutableStateOf("") }
    var sort by remember { mutableStateOf("Overall") }
    var showProposal by remember { mutableIntStateOf(-1) }
    var years by remember { mutableIntStateOf(1) }
    var role by remember { mutableStateOf(DriverTeamRole.EQUAL) }
    var salaryText by remember { mutableStateOf("") }
    var counterOffer by remember { mutableStateOf<com.f1teammanager.core.manager.DriverOffer?>(null) }
    var renewDriver by remember { mutableIntStateOf(-1) }
    var scoutDriver by remember { mutableIntStateOf(-1) }

    val currentDeals = state.contracts.filter { it.teamId == teamId && it.activeIn(store.season) }
    val currentIds = currentDeals.map { it.driverId }.toSet()
    val scheduledIds = state.scheduled.map { it.driverId }.toSet()
    val allDrivers = WorldDatabase.allDrivers
    val marketEngine = remember { DriverMarketEngine(20261003) }
    val visibleIds = when (filter) {
        "LIVRES" -> state.freeAgents
        "CONTRATADOS" -> state.contracts.map { it.driverId }
        "MINHA EQUIPE" -> currentIds.toList()
        "NEGOCIÁVEIS" -> allDrivers.map { it.id }.filter { marketEngine.canReceiveProposals(state, it, store.season) }
        "FECHADOS" -> state.scheduled.filter { it.signedSeason == store.season }.map { it.driverId }
        "FUTUROS" -> scheduledIds.toList()
        else -> allDrivers.map { it.id }
    }.distinct()

    val rows = visibleIds.mapNotNull { id ->
        val d = runCatching { store.driverDefinition(id) }.getOrNull() ?: return@mapNotNull null
        if (search.isNotBlank() && !d.name.contains(search, ignoreCase = true) &&
            !WorldDatabase.teams.firstOrNull { it.id == d.teamId }?.name.orEmpty().contains(search, ignoreCase = true)) return@mapNotNull null
        val deal = state.contracts.firstOrNull { it.driverId == id && it.activeIn(store.season) }
        val future = state.scheduled.firstOrNull { it.driverId == id }
        Triple(d, deal, future)
    }.sortedWith(
        when (sort) {
            "Nome" -> compareBy { it.first.name }
            else -> compareByDescending<Triple<com.f1teammanager.core.season.DriverDefinition, com.f1teammanager.core.manager.DriverDeal?, com.f1teammanager.core.manager.FutureDriverDeal?>> {
                (it.first.speed + it.first.qualifying + it.first.overtaking + it.first.defense + it.first.consistency + it.first.wet + it.first.tyre) / 7
            }.thenBy { it.first.name }
        }
    )

    Column(Modifier.fillMaxSize().background(Bg)) {
        // Cabeçalho e controles ficam fixos. Somente a lista de pilotos rola.
        Column(
            Modifier
                .fillMaxWidth()
                .background(Bg)
                .padding(start = 14.dp, end = 14.dp, top = 0.dp, bottom = 6.dp)
        ) {
            Text(
                "100 PILOTOS • 40 EQUIPES • TRANSFERÊNCIAS SOMENTE NA PRÓXIMA TEMPORADA",
                color = Red,
                fontSize = 7.sp,
                fontWeight = FontWeight.Black,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(top = 0.dp, bottom = 5.dp)
            )

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                MarketStat("100", "PILOTOS", "total", Modifier.weight(1f))
                MarketStat("80", "NO GRID", "40 equipes", Modifier.weight(1f))
                MarketStat("${state.freeAgents.size}", "LIVRES", "sem contrato", Modifier.weight(1f))
                MarketStat("${state.scheduled.count { it.startSeason == store.season + 1 }}", "TRANSFERÊNCIAS", "${store.season + 1}", Modifier.weight(1f))
            }

            if (message.isNotBlank()) {
                Card(Modifier.fillMaxWidth().padding(top = 5.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF052418)), shape = RoundedCornerShape(8.dp)) {
                    Row(Modifier.padding(horizontal = 9.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("◎", color = Green, fontSize = 17.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(end = 6.dp))
                        Text(message, color = Green, fontSize = 9.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    }
                }
            }

            Text(
                "Escolha o piloto que será substituído na próxima contratação. A seleção permanece ativa até você escolher outro.",
                color = Muted,
                fontSize = 9.sp,
                lineHeight = 13.sp,
                modifier = Modifier.padding(top = 6.dp, bottom = 5.dp)
            )

            if (currentDeals.size >= 2) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("PILOTO(S) SELECIONADO(S) PARA SUBSTITUIR", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Black, modifier = Modifier.weight(1f))
                    Text("${currentDeals.count { replacementId == it.driverId || state.scheduled.any { s -> s.toTeamId == teamId && s.replaceDriverId == it.driverId } }}/2", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Black)
                }
                Spacer(Modifier.height(4.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    currentDeals.forEach { deal ->
                        val name = allDrivers.firstOrNull { it.id == deal.driverId }?.name ?: "Piloto ${deal.driverId}"
                        val reserved = state.scheduled.any { it.toTeamId == teamId && it.replaceDriverId == deal.driverId }
                        Card(
                            Modifier.weight(1f).clickable(enabled = !reserved) { replacementId = if (replacementId == deal.driverId) -1 else deal.driverId },
                            colors = CardDefaults.cardColors(containerColor = if (replacementId == deal.driverId || reserved) Color(0xFF191D24) else Panel),
                            border = BorderStroke(1.dp, if (replacementId == deal.driverId || reserved) Red else Line),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Row(Modifier.padding(5.dp), verticalAlignment = Alignment.CenterVertically) {
                                DriverPhoto(deal.driverId, name, Modifier.size(28.dp).clip(RoundedCornerShape(50)))
                                Text(name, color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f).padding(horizontal = 4.dp))
                                Text("×", color = if (reserved) Muted else Red, fontSize = 17.sp, fontWeight = FontWeight.Black)
                            }
                        }
                    }
                }
            }

            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(top = 5.dp), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                listOf("TODOS", "LIVRES", "CONTRATADOS", "MINHA EQUIPE", "ABERTO", "FECHADO").forEach { f ->
                    val key = when (f) {
                        "ABERTO" -> "NEGOCIÁVEIS"
                        "FECHADO" -> "FECHADOS"
                        else -> f
                    }
                    Button(onClick = { filter = key }, colors = ButtonDefaults.buttonColors(containerColor = if (filter == key) Red else Bg, contentColor = Color.White), border = BorderStroke(1.dp, if (filter == key) Red else Line), shape = RoundedCornerShape(8.dp), contentPadding = PaddingValues(horizontal = 13.dp, vertical = 7.dp)) {
                        Text(f, fontSize = 8.sp, fontWeight = FontWeight.Black)
                    }
                }
            }

            Row(Modifier.fillMaxWidth().padding(top = 5.dp), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = search,
                    onValueChange = { search = it },
                    modifier = Modifier.weight(1f).height(52.dp),
                    singleLine = true,
                    placeholder = { Text("Buscar piloto, equipe ou país...", color = Muted, fontSize = 10.sp) },
                    leadingIcon = { Text("⌕", color = Muted, fontSize = 19.sp) },
                    colors = OutlinedTextFieldDefaults.colors(unfocusedBorderColor = Line, focusedBorderColor = Red, unfocusedContainerColor = Panel, focusedContainerColor = Panel, unfocusedTextColor = Color.White, focusedTextColor = Color.White),
                    shape = RoundedCornerShape(9.dp)
                )
                Box(
                    Modifier.weight(1f).height(52.dp).background(Panel, RoundedCornerShape(9.dp)).border(1.dp, Line, RoundedCornerShape(9.dp)).clickable { sort = if (sort == "Overall") "Nome" else "Overall" },
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(sort, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        Text(if (sort == "Overall") "↕" else "A–Z", color = Muted, fontSize = 9.sp)
                    }
                }
            }
        }

        LazyColumn(
            modifier = Modifier.fillMaxWidth().weight(1f),
            contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 2.dp, bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
if (rows.isEmpty()) item { Text("Nenhum piloto encontrado.", color = Muted, modifier = Modifier.padding(10.dp)) }

items(rows, key = { it.first.id }) { (d, deal, future) ->
    val selected = selectedDriverId == d.id
    val overall = (d.speed + d.qualifying + d.overtaking + d.defense + d.consistency + d.wet + d.tyre) / 7
    val canTalk = marketEngine.canReceiveProposals(state, d.id, store.season)
    val currentTeamName = deal?.let { WorldDatabase.teams.firstOrNull { t -> t.id == it.teamId }?.name } ?: "Sem equipe"
    val status = when {
        future != null -> "FUTURO"
        deal == null -> "LIVRE"
        deal.teamId == teamId -> "SUA EQUIPE"
        else -> "CONTRATO"
    }
    Card(Modifier.fillMaxWidth().clickable { onSelect(d.id) }, colors = CardDefaults.cardColors(containerColor = if (selected) Color(0xFF191317) else Panel), shape = RoundedCornerShape(14.dp), border = BorderStroke(1.dp, if (selected) Red else Color(0xFF1D222A))) {
        Column(Modifier.padding(10.dp)) {
            Row(verticalAlignment = Alignment.Top) {
                DriverPhoto(d.id, d.name, Modifier.size(72.dp).clip(RoundedCornerShape(10.dp)))
                Column(Modifier.weight(1f).padding(start = 9.dp, end = 6.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(d.name, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Black, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                        Text(status, color = if (future != null) Green else Color.White, fontSize = 8.sp, fontWeight = FontWeight.Black, modifier = Modifier.background(Panel2, RoundedCornerShape(12.dp)).padding(horizontal = 8.dp, vertical = 5.dp))
                    }
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 2.dp)) {
                        Text("Overall $overall", color = Muted, fontSize = 10.sp)
                        Text(" • ", color = Muted, fontSize = 10.sp)
                        Text(d.driverClass, color = when(d.driverClass){"Lenda"->Color(0xFFFFD32A);"Pro"->Color(0xFF36B7FF);"Forte"->Green;else->Muted}, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        Text(" • ", color = Muted, fontSize = 10.sp)
                        Text(d.evolution, color = Color(0xFFB86CFF), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                    Row(Modifier.padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("Equipe atual:", color = Muted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.width(4.dp))
                        TeamLogo(currentTeamName, WorldDatabase.teams.firstOrNull { it.name.equals(currentTeamName, ignoreCase = true) }?.id ?: 0, Modifier.size(18.dp))
                        Spacer(Modifier.width(4.dp))
                        Text(currentTeamName, color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    if (deal != null) {
                        val year = deal.contractYear(store.season)
                        Text("Contrato ${deal.years} ano(s) • ano $year/${deal.years} • salário ${formatMoney(deal.salary)}", color = Muted, fontSize = 9.sp, modifier = Modifier.padding(top = 2.dp))
                        Text(if (deal.canReceiveProposals(store.season)) "Último ano: pode receber propostas e renovar" else "Contrato protegido até o último ano.", color = if (deal.canReceiveProposals(store.season)) Green else Muted, fontSize = 9.sp, fontWeight = if (deal.canReceiveProposals(store.season)) FontWeight.Bold else FontWeight.Normal)
                    }
                    if (future != null) {
                        val nextTeamName = WorldDatabase.teams.firstOrNull { it.id == future.toTeamId }?.name ?: "Equipe ${future.toTeamId}"
                        Row(Modifier.padding(top = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("Próxima:", color = Green, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.width(4.dp))
                            TeamLogo(nextTeamName, future.toTeamId, Modifier.size(18.dp))
                            Spacer(Modifier.width(4.dp))
                            Text(nextTeamName, color = Green, fontSize = 9.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(" • ${future.startSeason}", color = Muted, fontSize = 8.sp)
                        }
                    }
                }
            }

            val report = state.scouting.lastOrNull { it.driverId == d.id && it.teamId == teamId && it.season == store.season }
            Row(Modifier.fillMaxWidth().padding(top = 5.dp), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                val labels = listOf("VEL","CLA","ULT","DEF","CON","CHU","PNE")
                val ranges = report?.attributeRanges?.split("|").orEmpty()
                labels.forEachIndexed { index, label ->
                    Column(Modifier.weight(1f).height(52.dp).background(Panel2, RoundedCornerShape(5.dp)).border(1.dp, if (report != null) Red.copy(alpha = 0.45f) else Line, RoundedCornerShape(5.dp)).padding(vertical = 3.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                        Text(label, color = Muted, fontSize = 6.sp, fontWeight = FontWeight.Black)
                        Text(if (report == null || index >= ranges.size || ranges[index].isBlank()) "🔒" else ranges[index], color = if (report == null) Muted else Color.White, fontSize = 8.sp, fontWeight = FontWeight.Black, maxLines = 1)
                    }
                }
            }
            if (report == null) Text("Atributos ocultos • realize o Scout para obter uma estimativa.", color = Muted, fontSize = 8.sp, modifier = Modifier.padding(top = 4.dp))
            else Text("Scout ${report.season} • relatório disponível até o fim da temporada", color = Green, fontSize = 8.sp, modifier = Modifier.padding(top = 4.dp))

            Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedButton(onClick = { onScout(d.id); scoutDriver = -1 }, modifier = Modifier.weight(1f), border = BorderStroke(1.dp, Line), shape = RoundedCornerShape(10.dp), contentPadding = PaddingValues(vertical = 7.dp)) { Text("SCOUT", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Black) }
                if (d.id in currentIds && deal != null && deal.contractYear(store.season) == deal.years && future == null) {
                    Button(enabled = currentWeek > 1 && DriverMarketEngine(20261003).marketOpen(currentWeek, store.season), onClick = { salaryText = deal.salary.toString(); years = deal.years; role = deal.role; renewDriver = d.id }, modifier = Modifier.weight(1.35f), colors = ButtonDefaults.buttonColors(containerColor = Red, contentColor = Color.White), shape = RoundedCornerShape(10.dp), contentPadding = PaddingValues(vertical = 7.dp)) { Text("RENOVAR", fontSize = 9.sp, fontWeight = FontWeight.Black) }
                } else if (d.id !in currentIds && canTalk) {
                    Button(enabled = DriverMarketEngine(20261003).marketOpen(currentWeek, store.season), onClick = { salaryText = marketEngine.salaryFor(d.id).toString(); years = 1; role = DriverTeamRole.EQUAL; showProposal = d.id }, modifier = Modifier.weight(1.35f), colors = ButtonDefaults.buttonColors(containerColor = Red, contentColor = Color.White), shape = RoundedCornerShape(10.dp), contentPadding = PaddingValues(vertical = 7.dp)) { Text("NEGOCIAR", fontSize = 9.sp, fontWeight = FontWeight.Black) }
                } else {
                    Spacer(Modifier.weight(1.35f))
                }
            }
        }
    }
}

val waiting = state.pending.filter { it.status == NegotiationStatus.PENDING && it.seasonTarget == store.season + 1 }
val waitingForDriver = waiting.filter { it.proposerTeamId == teamId }
val waitingFromAi = waiting.filter { it.proposerTeamId != 0 && it.proposerTeamId != teamId }
if (waitingForDriver.isNotEmpty()) item {
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFF171B22))) {
        Column(Modifier.padding(10.dp)) {
            Text("NEGOCIAÇÕES AGUARDANDO RESPOSTA", color = Color.White, fontWeight = FontWeight.Black, fontSize = 10.sp)
            waitingForDriver.takeLast(5).forEach { offer ->
                val name = allDrivers.firstOrNull { it.id == offer.driverId }?.name ?: "Piloto ${offer.driverId}"
                Text("${name} • resposta prevista em ${offer.expiresAfterWeek - store.currentWeek.coerceAtLeast(0)} semana(s)", color = Muted, fontSize = 8.sp, modifier = Modifier.padding(top = 4.dp))
            }
        }
    }
}
if (waitingFromAi.isNotEmpty()) item {
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFF171B22))) {
        Column(Modifier.padding(10.dp)) {
            Text("PROPOSTAS EM ANÁLISE PELO PILOTO", color = Color.White, fontWeight = FontWeight.Black, fontSize = 10.sp)
            waitingFromAi.takeLast(5).forEach { offer ->
                val name = allDrivers.firstOrNull { it.id == offer.driverId }?.name ?: "Piloto ${offer.driverId}"
                val proposer = WorldDatabase.teams.firstOrNull { it.id == offer.proposerTeamId }?.name ?: "Equipe ${offer.proposerTeamId}"
                Text("${proposer} • ${name} • resposta prevista na semana ${offer.expiresAfterWeek}", color = Muted, fontSize = 8.sp, modifier = Modifier.padding(top = 4.dp))
            }
        }
    }
}
val responseCards = state.notifications.filter { it.season == store.season && (it.title == "RESPOSTA DO PILOTO" || it.title == "DECISÃO DA EQUIPE" || it.title == "CONTRAPROPOSTA DA EQUIPE") }.takeLast(5).asReversed()
if (responseCards.isNotEmpty()) item {
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFF211817))) {
        Column(Modifier.padding(10.dp)) {
            Text("RESPOSTAS DAS NEGOCIAÇÕES", color = Color.White, fontWeight = FontWeight.Black, fontSize = 10.sp)
            responseCards.forEach { n ->
                NewsNotificationCard(n)
            }
        }
    }
}

val counters = state.pending.filter { it.proposerTeamId == teamId && it.status == NegotiationStatus.COUNTER && it.seasonTarget == store.season + 1 }
if (counters.isNotEmpty()) item {
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFF211817))) { Column(Modifier.padding(10.dp)) { Text("CONTRAPROPOSTAS PENDENTES", color = Color.White, fontWeight = FontWeight.Black, fontSize = 10.sp); counters.takeLast(3).forEach { offer -> val name=allDrivers.firstOrNull { it.id==offer.driverId }?.name ?: "Piloto ${offer.driverId}"; Row(Modifier.fillMaxWidth().padding(top=5.dp), verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(name,color=Color.White,fontWeight=FontWeight.Bold,fontSize=9.sp);Text("Rodada ${offer.round}/3 • ${formatMoney(offer.salary)}/ano • ${offer.years} ano(s)",color=Muted,fontSize=8.sp)};Button(onClick={counterOffer=offer;salaryText=offer.salary.toString();years=offer.years;role=offer.role},colors=ButtonDefaults.buttonColors(containerColor=Red),contentPadding=PaddingValues(horizontal=8.dp,vertical=2.dp)){Text("VER CONTRAPROPOSTA",fontSize=8.sp)}} } } }
}
val incoming = emptyList<com.f1teammanager.core.manager.DriverOffer>()
if (incoming.isNotEmpty()) item {
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFF211817))) { Column(Modifier.padding(10.dp)) { Text("OFERTAS RECEBIDAS", color = Color.White, fontWeight = FontWeight.Black, fontSize = 10.sp); incoming.takeLast(5).forEach { offer -> val name=allDrivers.firstOrNull { it.id==offer.driverId }?.name ?: "Piloto ${offer.driverId}"; val teamName=WorldDatabase.teams.firstOrNull { it.id==offer.toTeamId }?.name ?: "Equipe ${offer.toTeamId}"; Row(Modifier.fillMaxWidth().padding(top=5.dp),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text("$name → $teamName",color=Color.White,fontWeight=FontWeight.Bold,fontSize=9.sp);Text("${offer.years} ano(s) • ${formatMoney(offer.salary)}/ano • válida até semana ${offer.expiresAfterWeek}",color=Muted,fontSize=8.sp)};TextButton(onClick={onRejectIncoming(offer)}){Text("RECUSAR",color=Muted,fontSize=8.sp)};Button(onClick={onAcceptIncoming(offer)},colors=ButtonDefaults.buttonColors(containerColor=Red),contentPadding=PaddingValues(horizontal=7.dp,vertical=2.dp)){Text("ACEITAR",fontSize=8.sp)}} } } }
        }
    }

    if (showProposal > 0) {
        val d=allDrivers.firstOrNull { it.id==showProposal }
        if (d != null) AlertDialog(onDismissRequest={showProposal=-1},title={Text("PROPOSTA • ${d.name}",fontWeight=FontWeight.Black)},text={Column(verticalArrangement=Arrangement.spacedBy(7.dp)){Text("A proposta vale para ${store.season+1}. O piloto permanece na equipe atual até o fim da temporada.",color=Muted,fontSize=10.sp);Text("Duração",color=Color.White,fontWeight=FontWeight.Bold,fontSize=10.sp);Row(horizontalArrangement=Arrangement.spacedBy(5.dp)){listOf(1,2,3,4,5).forEach{y->FilterChip(selected=years==y,onClick={years=y},label={Text("$y ano",fontSize=9.sp)})}};Text("Papel",color=Color.White,fontWeight=FontWeight.Bold,fontSize=10.sp);Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(5.dp)){listOf(DriverTeamRole.PILOT_1,DriverTeamRole.PILOT_2,DriverTeamRole.EQUAL).forEach{r->FilterChip(selected=role==r,onClick={role=r},label={Text(when(r){DriverTeamRole.PILOT_1->"Piloto 1";DriverTeamRole.PILOT_2->"Piloto 2";DriverTeamRole.EQUAL->"Iguais"},fontSize=9.sp)})}};Text("Salário anual",color=Color.White,fontWeight=FontWeight.Bold,fontSize=10.sp);OutlinedTextField(value=salaryText,onValueChange={salaryText=it.filter(Char::isDigit)},singleLine=true,label={Text("Valor")});Text("Valor de mercado e salário são referências separadas. Não existe multa contratual.",color=Muted,fontSize=8.sp)}},confirmButton={Button(onClick={val salary=salaryText.toLongOrNull()?:0L;if(salary>0){onProposal(d.id,if(currentDeals.size>=2)replacementId.takeIf{it>0} else null,years,salary,role);showProposal=-1}},colors=ButtonDefaults.buttonColors(containerColor=Red)){Text("ENVIAR PROPOSTA")}},dismissButton={TextButton(onClick={showProposal=-1}){Text("CANCELAR")}})
    }
    if (renewDriver > 0) {
        val d=allDrivers.firstOrNull { it.id==renewDriver }
        if(d!=null) AlertDialog(onDismissRequest={renewDriver=-1},title={Text("RENOVAR • ${d.name}",fontWeight=FontWeight.Black)},text={Column(verticalArrangement=Arrangement.spacedBy(7.dp)){Text("A renovação começa em ${store.season+1}. O contrato atual continua válido até o fim desta temporada.",color=Muted,fontSize=9.sp);Text("Duração",fontWeight=FontWeight.Bold,fontSize=10.sp);Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(4.dp)){listOf(1,2,3,4,5).forEach{y->FilterChip(selected=years==y,onClick={years=y},label={Text("$y ano",fontSize=8.sp)})}};Text("Papel",fontWeight=FontWeight.Bold,fontSize=10.sp);Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(4.dp)){listOf(DriverTeamRole.PILOT_1,DriverTeamRole.PILOT_2,DriverTeamRole.EQUAL).forEach{r->FilterChip(selected=role==r,onClick={role=r},label={Text(when(r){DriverTeamRole.PILOT_1->"Piloto 1";DriverTeamRole.PILOT_2->"Piloto 2";DriverTeamRole.EQUAL->"Iguais"},fontSize=8.sp)})}};Text("Salário anual",fontWeight=FontWeight.Bold,fontSize=10.sp);OutlinedTextField(value=salaryText,onValueChange={salaryText=it.filter(Char::isDigit)},singleLine=true)}},confirmButton={Button(onClick={val salary=salaryText.toLongOrNull()?:0L;if(salary>0){onRenew(d.id,years,salary,role);renewDriver=-1}},colors=ButtonDefaults.buttonColors(containerColor=Red)){Text("CONFIRMAR RENOVAÇÃO")}},dismissButton={TextButton(onClick={renewDriver=-1}){Text("CANCELAR")}})
    }
    if (counterOffer != null) {
        val offer=counterOffer!!; val d=allDrivers.firstOrNull { it.id==offer.driverId }
        if(d!=null) AlertDialog(onDismissRequest={counterOffer=null},title={Text("CONTRAPROPOSTA • ${d.name}",fontWeight=FontWeight.Black)},text={Column(verticalArrangement=Arrangement.spacedBy(7.dp)){Text("RODADA ${offer.round}/3 • início em ${offer.seasonTarget}",color=Muted,fontSize=9.sp);Text("O piloto exige:",color=Color.White,fontWeight=FontWeight.Black,fontSize=10.sp);Text("Salário exigido: ${formatMoney(offer.salary)}/ano",color=Color.White,fontSize=10.sp);Text("Duração exigida: ${offer.years} ano(s)",color=Color.White,fontSize=10.sp);Text("Papel exigido: ${when(offer.role){DriverTeamRole.PILOT_1->"Piloto 1";DriverTeamRole.PILOT_2->"Piloto 2";DriverTeamRole.EQUAL->"Pilotos iguais"}}",color=Color.White,fontSize=10.sp);Text("Você pode aceitar, fazer outra contraproposta ou recusar.",color=Muted,fontSize=9.sp);Text("Sua nova proposta",fontWeight=FontWeight.Bold,fontSize=10.sp);OutlinedTextField(value=salaryText,onValueChange={salaryText=it.filter(Char::isDigit)},singleLine=true);Text("Duração",fontWeight=FontWeight.Bold,fontSize=10.sp);Row(horizontalArrangement=Arrangement.spacedBy(4.dp)){listOf(1,2,3,4,5).forEach{y->FilterChip(selected=years==y,onClick={years=y},label={Text("$y ano",fontSize=8.sp)})}};Text("Papel",fontWeight=FontWeight.Bold,fontSize=10.sp);Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(4.dp)){listOf(DriverTeamRole.PILOT_1,DriverTeamRole.PILOT_2,DriverTeamRole.EQUAL).forEach{r->FilterChip(selected=role==r,onClick={role=r},label={Text(when(r){DriverTeamRole.PILOT_1->"Piloto 1";DriverTeamRole.PILOT_2->"Piloto 2";DriverTeamRole.EQUAL->"Iguais"},fontSize=8.sp)})}}}},confirmButton={if(offer.round<3) Button(onClick={val salary=salaryText.toLongOrNull()?:0L;if(salary>0){onCounter(offer,if(currentDeals.size>=2)replacementId.takeIf{it>0} else null,years,salary,role);counterOffer=null}},colors=ButtonDefaults.buttonColors(containerColor=Red)){Text("FAZER CONTRAPROPOSTA")}},dismissButton={Row(horizontalArrangement=Arrangement.spacedBy(4.dp)){Button(onClick={onAcceptCounter(offer);counterOffer=null},colors=ButtonDefaults.buttonColors(containerColor=Red)){Text("ACEITAR")};TextButton(onClick={onRejectCounter(offer);counterOffer=null}){Text("RECUSAR")}}})
    }
    if (scoutDriver > 0) {
        val d=allDrivers.firstOrNull { it.id==scoutDriver }
        if(d!=null) AlertDialog(onDismissRequest={scoutDriver=-1},title={Text("SCOUT • ${d.name}",fontWeight=FontWeight.Black)},text={Column(verticalArrangement=Arrangement.spacedBy(6.dp)){Text("Relatório de scouting",color=Color.White,fontSize=10.sp,fontWeight=FontWeight.Bold);Text("Custo: US$ 0,5M",color=Muted,fontSize=9.sp);Text("A precisão dos atributos será definida pelo sistema de instalações em uma atualização futura. O relatório fica disponível durante toda a temporada e não garante contratação.",color=Muted,fontSize=9.sp)}},confirmButton={Button(onClick={onScout(d.id);scoutDriver=-1},colors=ButtonDefaults.buttonColors(containerColor=Red)){Text("REALIZAR SCOUT")}},dismissButton={TextButton(onClick={scoutDriver=-1}){Text("CANCELAR")}})
    }
}
}

@Composable
private fun MarketStat(value: String, title: String, subtitle: String, modifier: Modifier = Modifier) {
    Card(modifier.height(52.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF101319)), shape = RoundedCornerShape(7.dp)) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 2.dp, vertical = 3.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Text(value, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Black, maxLines = 1)
            Text(title, color = Color.White, fontSize = 6.sp, fontWeight = FontWeight.Black, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(subtitle, color = Muted, fontSize = 4.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun MarketNews(state: DriverMarketState, season: Int, onViewed: () -> Unit) {
    LaunchedEffect(state.notifications, season) { onViewed() }
    var category by remember { mutableStateOf(MarketNewsCategory.MARKET) }
    val items = state.notifications
        .filter { it.season <= season && it.category == category }
        .sortedWith(compareByDescending<MarketNotification> { it.week }.thenByDescending { it.season })

    val labels = listOf(
        MarketNewsCategory.MARKET to "MERCADO",
        MarketNewsCategory.DRIVER_EVOLUTION to "EVOLUÇÃO DE PILOTOS",
        MarketNewsCategory.TEAM_EVOLUTION to "EVOLUÇÃO DE EQUIPES",
        MarketNewsCategory.ANNUAL_EVENTS to "EVENTOS ANUAIS"
    )

    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 12.dp),
        contentPadding = PaddingValues(top = 8.dp, bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            Text("CENTRAL DE NOTÍCIAS", color = Color.White, fontWeight = FontWeight.Black, fontSize = 24.sp)
            Text(
                "TUDO O QUE ACONTECE NA TEMPORADA",
                color = Red,
                fontWeight = FontWeight.Bold,
                fontSize = 10.sp,
                modifier = Modifier.padding(top = 3.dp, bottom = 10.dp)
            )
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(7.dp)
            ) {
                labels.forEach { (key, label) ->
                    NewsCategoryChip(label, category == key) { category = key }
                }
            }
        }

        if (items.isEmpty()) {
            item {
                Card(
                    Modifier.fillMaxWidth().padding(top = 5.dp),
                    colors = CardDefaults.cardColors(containerColor = Panel),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Column(
                        Modifier.fillMaxWidth().padding(22.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        NewsCategoryGlyph(category, Modifier.size(42.dp))
                        Text("Nenhuma notícia nesta categoria ainda.", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 10.dp))
                    }
                }
            }
        } else {
            val weeks = items.groupBy { it.week }
            weeks.toSortedMap(compareByDescending { it }).forEach { (week, weekItems) ->
                item {
                    Text(
                        "SEMANA $week",
                        color = Red,
                        fontWeight = FontWeight.Black,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(top = 6.dp, bottom = 2.dp)
                    )
                }
                items(weekItems.sortedWith(compareByDescending<MarketNotification> { it.season }.thenByDescending { it.title })) { n ->
                    NewsNotificationCard(n)
                }
            }
        }
    }
}

@Composable
private fun NewsCategoryChip(label: String, selected: Boolean, onClick: () -> Unit) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(12.dp),
        color = if (selected) Color(0xFF514B61) else Color.Transparent,
        border = BorderStroke(1.2.dp, if (selected) Color(0xFF514B61) else Color(0xFF8A8790))
    ) {
        Box(Modifier.padding(horizontal = 18.dp, vertical = 10.dp)) {
            Text(label, color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Medium, maxLines = 1)
        }
    }
}

private data class NewsParsed(
    val entityName: String?,
    val entityId: Int?,
    val component: CarComponent?,
    val before: Int?,
    val after: Int?,
    val delta: Int?,
    val detail: String
)

private fun parseNews(n: MarketNotification): NewsParsed {
    val component = when {
        n.message.contains("Unidade de potência elétrica", true) || n.message.contains("Unidade elétrica", true) -> CarComponent.ELECTRIC_POWER_UNIT
        n.message.contains("Unidade de potência", true) -> CarComponent.ENGINE
        n.message.contains("Asa dianteira", true) -> CarComponent.FRONT_WING
        n.message.contains("Asa traseira", true) -> CarComponent.REAR_WING
        n.message.contains("Chassi", true) -> CarComponent.CHASSIS
        n.message.contains("Freios", true) -> CarComponent.BRAKES
        n.message.contains("Suspensão", true) -> null
        else -> null
    }
    val range = Regex("(\\d+)\\s*(?:→|->)\\s*(\\d+)").find(n.message)
    val before = range?.groupValues?.getOrNull(1)?.toIntOrNull()
    val after = range?.groupValues?.getOrNull(2)?.toIntOrNull()
    val delta = if (before != null && after != null) after - before else null

    val allTeams = WorldDatabase.teams
    val allDrivers = WorldDatabase.allDrivers
    val team = allTeams.firstOrNull { n.message.contains(it.name, true) }
    val driver = allDrivers.firstOrNull { n.message.contains(it.name, true) }
    val entityName = team?.name ?: driver?.name
    val entityId = team?.id ?: driver?.id
    return NewsParsed(entityName, entityId, component, before, after, delta, n.message)
}

@Composable
private fun NewsNotificationCard(n: MarketNotification) {
    val parsed = remember(n.season, n.week, n.title, n.message) { parseNews(n) }
    val isTeam = n.category == MarketNewsCategory.TEAM_EVOLUTION
    val isDriver = n.category == MarketNewsCategory.DRIVER_EVOLUTION
    val entityTeamId = if (isTeam) parsed.entityId else if (isDriver && parsed.entityId != null) {
        WorldDatabase.allDrivers.firstOrNull { it.id == parsed.entityId }?.teamId
    } else null
    val teamName = entityTeamId?.let { id -> WorldDatabase.teams.firstOrNull { it.id == id }?.name }

    Card(
        Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1B1416)),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(Modifier.fillMaxWidth().padding(12.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
                Box(Modifier.size(58.dp), contentAlignment = Alignment.Center) {
                    when {
                        isTeam && parsed.entityId != null -> TeamLogo(parsed.entityName ?: "", parsed.entityId, Modifier.size(48.dp))
                        isDriver && parsed.entityId != null -> DriverPhoto(parsed.entityId, parsed.entityName ?: "", Modifier.size(48.dp).clip(RoundedCornerShape(10.dp)))
                        else -> NewsCategoryGlyph(n.category, Modifier.size(42.dp))
                    }
                }
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        parsed.entityName ?: newsEntityFallback(n.category),
                        color = Color.White,
                        fontWeight = FontWeight.Black,
                        fontSize = 15.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        n.title,
                        color = Red,
                        fontWeight = FontWeight.Black,
                        fontSize = 9.sp,
                        modifier = Modifier.padding(top = 2.dp),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                if (parsed.delta != null) {
                    val positive = parsed.delta >= 0
                    Column(horizontalAlignment = Alignment.End) {
                        Text(if (positive) "▲ +${parsed.delta}" else "▼ ${parsed.delta}", color = if (positive) Green else Red, fontWeight = FontWeight.Black, fontSize = 12.sp)
                        if (parsed.before != null && parsed.after != null) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(parsed.before.toString(), color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Black)
                                Text("  ${if (positive) "→" else "→"}  ", color = if (positive) Green else Red, fontSize = 17.sp, fontWeight = FontWeight.Black)
                                Text(parsed.after.toString(), color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Black)
                            }
                        }
                    }
                }
            }

            if (isTeam && parsed.component != null) {
                Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    ComponentIcon(parsed.component, Modifier.size(26.dp))
                    Spacer(Modifier.width(7.dp))
                    Text(componentLabel(parsed.component).uppercase(), color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Medium)
                    Spacer(Modifier.weight(1f))
                    Text("P&D", color = Muted, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                }
            } else if (isDriver && teamName != null) {
                Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    TeamLogo(teamName, entityTeamId ?: 0, Modifier.size(24.dp))
                    Spacer(Modifier.width(7.dp))
                    Text(teamName.uppercase(), color = Muted, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.weight(1f))
                    Text("EVOLUÇÃO", color = Muted, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                }
            }

            Text(
                n.message,
                color = Color.White,
                fontSize = 10.sp,
                lineHeight = 16.sp,
                modifier = Modifier.padding(top = 8.dp)
            )
        }
    }
}

private fun newsEntityFallback(category: MarketNewsCategory) = when (category) {
    MarketNewsCategory.MARKET -> "Mercado de pilotos"
    MarketNewsCategory.DRIVER_EVOLUTION -> "Evolução dos pilotos"
    MarketNewsCategory.TEAM_EVOLUTION -> "Evolução das equipes"
    MarketNewsCategory.ANNUAL_EVENTS -> "Temporada"
}

@Composable
private fun NewsCategoryGlyph(category: MarketNewsCategory, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val c = Red
        when (category) {
            MarketNewsCategory.MARKET -> {
                drawRoundRect(c, topLeft = androidx.compose.ui.geometry.Offset(size.width*.18f,size.height*.28f), size = androidx.compose.ui.geometry.Size(size.width*.64f,size.height*.54f), cornerRadius = androidx.compose.ui.geometry.CornerRadius(6f,6f), style = androidx.compose.ui.graphics.drawscope.Stroke(width=3f))
                drawLine(c, androidx.compose.ui.geometry.Offset(size.width*.28f,size.height*.18f), androidx.compose.ui.geometry.Offset(size.width*.72f,size.height*.18f), strokeWidth=3f)
                drawLine(c, androidx.compose.ui.geometry.Offset(size.width*.32f,size.height*.45f), androidx.compose.ui.geometry.Offset(size.width*.68f,size.height*.45f), strokeWidth=3f)
            }
            MarketNewsCategory.DRIVER_EVOLUTION -> {
                drawCircle(c, size.minDimension*.24f, androidx.compose.ui.geometry.Offset(size.width*.5f,size.height*.34f), style=androidx.compose.ui.graphics.drawscope.Stroke(width=3f))
                drawArc(color=c, startAngle=200f, sweepAngle=140f, useCenter=false, topLeft=androidx.compose.ui.geometry.Offset(size.width*.18f,size.height*.30f), size=androidx.compose.ui.geometry.Size(size.width*.64f,size.height*.58f), style=androidx.compose.ui.graphics.drawscope.Stroke(width=3f))
                drawLine(Green, androidx.compose.ui.geometry.Offset(size.width*.28f,size.height*.78f), androidx.compose.ui.geometry.Offset(size.width*.48f,size.height*.58f), strokeWidth=4f)
                drawLine(Green, androidx.compose.ui.geometry.Offset(size.width*.48f,size.height*.58f), androidx.compose.ui.geometry.Offset(size.width*.72f,size.height*.42f), strokeWidth=4f)
            }
            MarketNewsCategory.TEAM_EVOLUTION -> {
                drawRoundRect(c, topLeft=androidx.compose.ui.geometry.Offset(size.width*.18f,size.height*.30f), size=androidx.compose.ui.geometry.Size(size.width*.64f,size.height*.42f), cornerRadius=androidx.compose.ui.geometry.CornerRadius(6f,6f), style=androidx.compose.ui.graphics.drawscope.Stroke(width=3f))
                drawLine(c, androidx.compose.ui.geometry.Offset(size.width*.30f,size.height*.30f), androidx.compose.ui.geometry.Offset(size.width*.36f,size.height*.18f), strokeWidth=3f)
                drawLine(c, androidx.compose.ui.geometry.Offset(size.width*.70f,size.height*.30f), androidx.compose.ui.geometry.Offset(size.width*.64f,size.height*.18f), strokeWidth=3f)
                drawLine(Green, androidx.compose.ui.geometry.Offset(size.width*.36f,size.height*.58f), androidx.compose.ui.geometry.Offset(size.width*.50f,size.height*.44f), strokeWidth=4f)
                drawLine(Green, androidx.compose.ui.geometry.Offset(size.width*.50f,size.height*.44f), androidx.compose.ui.geometry.Offset(size.width*.68f,size.height*.58f), strokeWidth=4f)
            }
            MarketNewsCategory.ANNUAL_EVENTS -> {
                drawRoundRect(c, topLeft=androidx.compose.ui.geometry.Offset(size.width*.18f,size.height*.24f), size=androidx.compose.ui.geometry.Size(size.width*.64f,size.height*.58f), cornerRadius=androidx.compose.ui.geometry.CornerRadius(5f,5f), style=androidx.compose.ui.graphics.drawscope.Stroke(width=3f))
                drawLine(c, androidx.compose.ui.geometry.Offset(size.width*.30f,size.height*.12f), androidx.compose.ui.geometry.Offset(size.width*.30f,size.height*.34f), strokeWidth=4f)
                drawLine(c, androidx.compose.ui.geometry.Offset(size.width*.70f,size.height*.12f), androidx.compose.ui.geometry.Offset(size.width*.70f,size.height*.34f), strokeWidth=4f)
                drawLine(c, androidx.compose.ui.geometry.Offset(size.width*.22f,size.height*.40f), androidx.compose.ui.geometry.Offset(size.width*.78f,size.height*.40f), strokeWidth=3f)
            }
        }
    }
}

@Composable
private fun ComponentIcon(component: CarComponent, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val c = Color.White
        val r = Red
        when (component) {
            CarComponent.ENGINE -> {
                drawRoundRect(r, topLeft=androidx.compose.ui.geometry.Offset(size.width*.18f,size.height*.28f), size=androidx.compose.ui.geometry.Size(size.width*.64f,size.height*.44f), cornerRadius=androidx.compose.ui.geometry.CornerRadius(6f,6f), style=androidx.compose.ui.graphics.drawscope.Stroke(width=3f))
                drawLine(r, androidx.compose.ui.geometry.Offset(size.width*.08f,size.height*.50f), androidx.compose.ui.geometry.Offset(size.width*.20f,size.height*.50f), strokeWidth=4f)
                drawLine(r, androidx.compose.ui.geometry.Offset(size.width*.80f,size.height*.50f), androidx.compose.ui.geometry.Offset(size.width*.94f,size.height*.50f), strokeWidth=4f)
                drawCircle(c,size.minDimension*.10f,androidx.compose.ui.geometry.Offset(size.width*.50f,size.height*.50f))
            }
            CarComponent.CHASSIS -> {
                val p=androidx.compose.ui.graphics.Path().apply { moveTo(size.width*.12f,size.height*.70f); lineTo(size.width*.28f,size.height*.30f); lineTo(size.width*.72f,size.height*.30f); lineTo(size.width*.88f,size.height*.70f); close() }
                drawPath(p,r,style=androidx.compose.ui.graphics.drawscope.Stroke(width=3f))
                drawLine(c,androidx.compose.ui.geometry.Offset(size.width*.32f,size.height*.50f),androidx.compose.ui.geometry.Offset(size.width*.68f,size.height*.50f),strokeWidth=3f)
            }
            CarComponent.FRONT_WING -> {
                drawLine(c,androidx.compose.ui.geometry.Offset(size.width*.10f,size.height*.38f),androidx.compose.ui.geometry.Offset(size.width*.90f,size.height*.38f),strokeWidth=4f)
                drawLine(c,androidx.compose.ui.geometry.Offset(size.width*.20f,size.height*.58f),androidx.compose.ui.geometry.Offset(size.width*.80f,size.height*.58f),strokeWidth=3f)
                drawLine(r,androidx.compose.ui.geometry.Offset(size.width*.18f,size.height*.38f),androidx.compose.ui.geometry.Offset(size.width*.28f,size.height*.70f),strokeWidth=3f)
                drawLine(r,androidx.compose.ui.geometry.Offset(size.width*.82f,size.height*.38f),androidx.compose.ui.geometry.Offset(size.width*.72f,size.height*.70f),strokeWidth=3f)
            }
            CarComponent.REAR_WING -> {
                drawLine(c,androidx.compose.ui.geometry.Offset(size.width*.16f,size.height*.30f),androidx.compose.ui.geometry.Offset(size.width*.84f,size.height*.30f),strokeWidth=4f)
                drawLine(c,androidx.compose.ui.geometry.Offset(size.width*.24f,size.height*.52f),androidx.compose.ui.geometry.Offset(size.width*.76f,size.height*.52f),strokeWidth=3f)
                drawLine(r,androidx.compose.ui.geometry.Offset(size.width*.28f,size.height*.30f),androidx.compose.ui.geometry.Offset(size.width*.34f,size.height*.76f),strokeWidth=3f)
                drawLine(r,androidx.compose.ui.geometry.Offset(size.width*.72f,size.height*.30f),androidx.compose.ui.geometry.Offset(size.width*.66f,size.height*.76f),strokeWidth=3f)
            }
            CarComponent.BRAKES -> {
                drawCircle(r,size.minDimension*.32f,androidx.compose.ui.geometry.Offset(size.width*.50f,size.height*.50f),style=androidx.compose.ui.graphics.drawscope.Stroke(width=3f))
                drawCircle(c,size.minDimension*.12f,androidx.compose.ui.geometry.Offset(size.width*.50f,size.height*.50f))
                for (i in 0 until 6) {
                    val a=Math.toRadians((i*60).toDouble())
                    val x1=size.width*.50f + kotlin.math.cos(a).toFloat()*size.width*.18f
                    val y1=size.height*.50f + kotlin.math.sin(a).toFloat()*size.height*.18f
                    val x2=size.width*.50f + kotlin.math.cos(a).toFloat()*size.width*.28f
                    val y2=size.height*.50f + kotlin.math.sin(a).toFloat()*size.height*.28f
                    drawLine(c,androidx.compose.ui.geometry.Offset(x1,y1),androidx.compose.ui.geometry.Offset(x2,y2),strokeWidth=2f)
                }
            }
            CarComponent.ELECTRIC_POWER_UNIT -> {
                val p=androidx.compose.ui.graphics.Path().apply { moveTo(size.width*.56f,size.height*.10f); lineTo(size.width*.24f,size.height*.54f); lineTo(size.width*.48f,size.height*.54f); lineTo(size.width*.40f,size.height*.90f); lineTo(size.width*.78f,size.height*.42f); lineTo(size.width*.54f,size.height*.42f); close() }
                drawPath(p,Green)
                drawPath(p,r,style=androidx.compose.ui.graphics.drawscope.Stroke(width=2f))
            }
        }
    }
}

@Composable
private fun ManagementHub(
    raceActive: Boolean,
    onDrivers: () -> Unit,
    onMarket: () -> Unit,
    onFinance: () -> Unit,
    onSeason: () -> Unit,
    onCar: () -> Unit,
    onStandings: () -> Unit,
    onCalendar: () -> Unit,
    onWeekend: () -> Unit,
    onRace: () -> Unit,
    onHistory: () -> Unit,
    onNews: () -> Unit,
    onHallOfFame: () -> Unit,
    onRecords: () -> Unit
) {
    val actions = listOf(
        "FIM DE SEMANA" to onWeekend,
        "PILOTOS" to onDrivers,
        "MERCADO" to onMarket,
        "CENTRAL DE NOTÍCIAS" to onNews,
        "CARRO / P&D" to onCar,
        "CAMPEONATO" to onStandings,
        "CALENDÁRIO" to onCalendar,
        "FINANÇAS" to onFinance,
        "TEMPORADA" to onSeason,
        "HISTÓRIA" to onHistory,
        "HALL DA FAMA" to onHallOfFame,
        "RECORDES" to onRecords
    )
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        HeaderBlock("CENTRAL DE GESTÃO", if (raceActive) "CORRIDA ATIVA" else "TEMPORADA")
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(vertical = 10.dp)) {
            items(actions) { (label, action) ->
                Button(onClick = action, modifier = Modifier.fillMaxWidth().height(46.dp), colors = ButtonDefaults.buttonColors(containerColor = if (label == "PIT WALL" && raceActive) Red else Panel2, contentColor = Color.White)) {
                    Text(label, fontWeight = FontWeight.Black, fontSize = 11.sp)
                }
            }
        }
    }
}

private fun strategyLabel(m:DriverStrategyMode)=when(m){DriverStrategyMode.ATTACK->"ATAQUE";DriverStrategyMode.BALANCED->"EQUILIBRADO";DriverStrategyMode.DEFENSE->"DEFESA / ECONOMIA"}
private fun tyreLabel(t:Tyre)=when(t){Tyre.SOFT->"SOFT";Tyre.MEDIUM->"MEDIUM";Tyre.HARD->"HARD";Tyre.INTERMEDIATE->"INTER";Tyre.WET->"WET"}
private fun weatherLabel(w:Weather)=when(w){Weather.DRY->"☀️ SOL";Weather.CLOUDY->"☁️ NUBLADO";Weather.LIGHT_RAIN->"🌦️ CHUVA FRACA • INTERMEDIÁRIO";Weather.MEDIUM_RAIN->"🌧️ CHUVA MÉDIA • INTERMEDIÁRIO";Weather.HEAVY_RAIN->"🌧️ CHUVA FORTE • WET"}
private fun statusLabel(n:Neutralisation)=when(n){Neutralisation.GREEN->"GREEN FLAG";Neutralisation.VSC->"VSC";Neutralisation.SAFETY_CAR->"SAFETY CAR"}
private fun tyreLifeEstimate(tyre:Tyre, weather:Weather, mode:DriverStrategyMode, driverTyreWear:Int = 50):Int = tyre.targetLaps

private fun actionLabel(a:ManagerDecisionAction)=when(a){ManagerDecisionAction.BOX->"BOX";ManagerDecisionAction.STAY_OUT->"MANTER";ManagerDecisionAction.EXTEND_STINT->"ESTENDER STINT";ManagerDecisionAction.SAVE_FUEL->"POUPAR COMBUSTÍVEL";ManagerDecisionAction.CHANGE_STRATEGY->"MUDAR ESTRATÉGIA";ManagerDecisionAction.RESTART_ATTACK->"RELARGADA • ATAQUE";ManagerDecisionAction.RESTART_BALANCED->"RELARGADA • EQUILIBRADO";ManagerDecisionAction.RESTART_DEFENSE->"RELARGADA • DEFESA";ManagerDecisionAction.RESTART_PLAN_A->"PLANO A • RELARGADA";ManagerDecisionAction.RESTART_PLAN_B->"PLANO B • RELARGADA";ManagerDecisionAction.RESTART_PLAN_C->"PLANO C • RELARGADA";ManagerDecisionAction.RESTART_PLAN_D->"PLANO D • RELARGADA";ManagerDecisionAction.CHANGE_TYRE_SOFT->"SOFT";ManagerDecisionAction.CHANGE_TYRE_MEDIUM->"MEDIUM";ManagerDecisionAction.CHANGE_TYRE_HARD->"HARD";ManagerDecisionAction.CHANGE_TYRE_INTERMEDIATE->"INTERMEDIÁRIO";ManagerDecisionAction.CHANGE_TYRE_WET->"WET"}
private fun constructorPosition(teamId:Int, store:CareerPreferences): Int {
    val points = store.constructorPoints()
    val rows = WorldDatabase.teams.map { it.id to (points[it.id] ?: 0) }
        .sortedWith(compareByDescending<Pair<Int,Int>> { it.second }.thenBy { it.first })
    return rows.indexOfFirst { it.first == teamId }.let { if (it >= 0) it + 1 else WorldDatabase.teams.indexOfFirst { it.id == teamId } + 1 }
}
private fun driverChampionshipPosition(driverId:Int, store:CareerPreferences): Int {
    val points = store.driverPoints()
    val rows = WorldDatabase.drivers.map { it.id to (points[it.id] ?: 0) }
        .sortedWith(compareByDescending<Pair<Int,Int>> { it.second }.thenBy { it.first })
    return rows.indexOfFirst { it.first == driverId }.let { if (it >= 0) it + 1 else WorldDatabase.drivers.indexOfFirst { it.id == driverId } + 1 }
}

private fun planDescription(plan:TyrePlan?): String = plan?.let {
    it.sequence.indices.joinToString(" → ") { i -> "${tyreLabel(it.sequence[i])} ${it.stintLaps.getOrElse(i) { 0 }}v" }
} ?: "Plano indisponível"

@Composable
private fun SectionTitle(title:String) {
    Text(
        title,
        color = Red,
        fontSize = 11.sp,
        fontWeight = FontWeight.Black,
        modifier = Modifier.padding(top = 2.dp, bottom = 1.dp)
    )
}

@Composable
private fun StatCard(title:String, value:String, subtitle:String, modifier:Modifier = Modifier) {
    Column(
        modifier = modifier
            .background(Panel2, RoundedCornerShape(8.dp))
            .padding(9.dp)
    ) {
        Text(title, color = Muted, fontSize = 8.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(value, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Black, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 3.dp))
        Text(subtitle, color = Muted, fontSize = 8.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 2.dp))
    }
}

@Composable
private fun HeaderBlock(title:String, subtitle:String) {
    Column(Modifier.fillMaxWidth().padding(bottom = 6.dp)) {
        Text(title, color=Color.White, fontSize=22.sp, fontWeight=FontWeight.Black, maxLines=1, overflow=TextOverflow.Ellipsis)
        Text(subtitle, color=Red, fontSize=10.sp, fontWeight=FontWeight.Bold)
    }
}

private fun formatMoney(value:Long):String {
    val sign = if (value < 0) "-" else ""
    val abs = kotlin.math.abs(value)
    return when {
        abs >= 1_000_000L -> {
            val millions = abs / 1_000_000L
            val thousands = (abs % 1_000_000L) / 1_000L
            if (thousands == 0L) "€ ${sign}${millions} M"
            else "€ ${sign}${millions},${(thousands / 100).coerceAtLeast(1)} M"
        }
        abs >= 1_000L -> "€ ${sign}${abs / 1_000L} mil"
        else -> "€ ${sign}${abs}"
    }
}

private fun formatMs(ms:Long)=if(ms==Long.MAX_VALUE) "—" else "%d:%02d.%03d".format(ms/60000,(ms/1000)%60,ms%1000)
