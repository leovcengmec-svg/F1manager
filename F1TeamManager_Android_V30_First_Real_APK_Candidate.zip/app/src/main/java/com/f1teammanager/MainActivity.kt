package com.f1teammanager

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.f1teammanager.core.race.*
import com.f1teammanager.core.manager.CarComponent
import com.f1teammanager.core.manager.CarDevelopmentEngine
import com.f1teammanager.core.manager.TeamCarState
import com.f1teammanager.core.manager.TeamManagerState
import com.f1teammanager.core.manager.TeamFinanceState
import com.f1teammanager.core.manager.DriverMarketEngine
import com.f1teammanager.core.manager.DriverMarketState
import com.f1teammanager.core.season.CarCatalog
import com.f1teammanager.core.season.RoundDefinition
import com.f1teammanager.core.season.WorldDatabase
import com.f1teammanager.core.season.toParticipant

private val Bg = Color(0xFF08090C)
private val Panel = Color(0xFF14161B)
private val Panel2 = Color(0xFF1B1E24)
private val Red = Color(0xFFE10600)
private val Muted = Color(0xFF8D929C)
private val Line = Color(0xFF2B2F36)
private val Green = Color(0xFF38C878)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { F1ManagerApp(CareerPreferences(this)) }
    }
}

private enum class Screen { HOME, TEAM, DRIVERS, CAR, CALENDAR, STANDINGS, FINANCE, MARKET, WEEKEND, QUALIFYING, RACE, RESULT, HISTORY, MANAGEMENT, SELECT_TEAM }
private enum class Nav { HOME, TEAM, CAR, CALENDAR, STANDINGS }

@Composable
private fun F1ManagerApp(store: CareerPreferences) {
    var hasCareer by remember { mutableStateOf(store.hasCareer) }
    var teamId by remember { mutableIntStateOf(store.teamId) }
    var roundIndex by remember { mutableIntStateOf(store.roundIndex) }
    var screen by remember { mutableStateOf(if (hasCareer) Screen.HOME else Screen.SELECT_TEAM) }
    var nav by remember { mutableStateOf(Nav.HOME) }
    var selectedMode by remember { mutableStateOf(DriverStrategyMode.BALANCED) }
    var selectedTyre by remember { mutableStateOf(Tyre.MEDIUM) }
    var snapshot by remember { mutableStateOf<CareerWeekendEngine.SessionSnapshot?>(null) }
    var result by remember { mutableStateOf<RaceResult?>(null) }
    var marketDriverId by remember { mutableIntStateOf(-1) }
    var marketState by remember { mutableStateOf(DriverMarketEngine(20261003).initialState(store.season)) }
    var marketMessage by remember { mutableStateOf("") }
    var managerState by remember(teamId) { mutableStateOf(store.loadCar(teamId)?.let { TeamManagerState(car=it, finance=TeamFinanceState(75_000_000L), playerTeamId=teamId) } ?: initialManagerState(teamId)) }
    var historyRound by remember { mutableIntStateOf(-1) }
    var historyResult by remember { mutableStateOf<RaceResult?>(null) }
    var carMessage by remember { mutableStateOf("") }
    val marketEngine = remember { DriverMarketEngine(20261003) }
    val engine = remember { CareerWeekendEngine(20261003) }
    val team = WorldDatabase.teams.firstOrNull { it.id == teamId } ?: WorldDatabase.teams.first()
    val drivers = WorldDatabase.drivers.filter { it.teamId == team.id }
    val round = WorldDatabase.rounds.getOrElse(roundIndex) { WorldDatabase.rounds.first() }
    val development = remember { CarDevelopmentEngine() }

    fun participants() = WorldDatabase.drivers.map { d ->
        val t = WorldDatabase.teams.first { it.id == d.teamId }
        d.toParticipant(t)
    }
    fun circuit() = RaceCircuit(round.round, round.circuit, round.laps, round.baseLapTimeMs, round.powerFactor, round.overtakingFactor, round.crashRisk, round.reliabilityRisk, round.safetyCarRisk)
    fun startWeekend() {
        if (snapshot != null && snapshot?.completed == false && snapshot?.phase == "RACE") { screen = Screen.RACE; return }
        snapshot = engine.start(participants(), circuit(), team.id); result = null; screen = Screen.QUALIFYING
    }
    fun startRace() { drivers.forEach { engine.setPlan(it.id, selectedMode, selectedTyre) }; snapshot = engine.snapshotForUi(); screen = Screen.RACE }
    fun advanceRace() {
        snapshot = engine.advance()
        if (snapshot?.completed == true) {
            result = engine.result()
            store.recordRace(round.round, result!!)
            screen = Screen.RESULT
        }
    }
    fun nextRound() {
        val currentWeek = round.weekOfSeason
        val nextIndex = if (roundIndex < WorldDatabase.rounds.lastIndex) roundIndex + 1 else 0
        val nextWeek = if (roundIndex < WorldDatabase.rounds.lastIndex) WorldDatabase.rounds[nextIndex].weekOfSeason else 56
        managerState = development.advanceWeeks(managerState, (nextWeek - currentWeek).coerceAtLeast(1))
        store.saveCar(teamId, managerState.car)
        snapshot = null; result = null; store.advanceRound(); roundIndex = store.roundIndex; screen = Screen.HOME; nav = Nav.HOME
    }
    fun startDevelopment(component: CarComponent) {
        runCatching { managerState = development.start(managerState, component); store.saveCar(teamId, managerState.car); carMessage = "${componentLabel(component)} iniciado: ${managerState.car.activeProject?.totalWeeks} semanas." }
            .onFailure { carMessage = it.message ?: "Não foi possível iniciar o projeto." }
    }
    fun openHistory(r:Int) { historyRound=r; historyResult=store.raceHistory(r); screen=Screen.HISTORY }
    fun makeMarketInterest(driverId: Int) {
        val driver = WorldDatabase.allDrivers.first { it.id == driverId }
        val from = driver.teamId
        val years = if (from == 0) 2 else 1
        val salary = marketEngine.salaryFor(driverId)
        runCatching {
            val (next, offer) = marketEngine.offer(marketState, driverId, from, team.id, years, salary, season = store.season)
            marketState = next
            marketMessage = if (offer.accepted) "Negociação aceita: ${driver.name}. Pré-contrato registrado." else "Interesse registrado por ${driver.name}; negociação ainda não aceita."
        }.onFailure { marketMessage = it.message ?: "Não foi possível negociar agora." }
    }
    fun selectTeam(id: Int) { store.startNewCareer(id); marketState = marketEngine.initialState(2026); marketMessage = ""; managerState=initialManagerState(id); teamId = id; roundIndex = 0; hasCareer = true; screen = Screen.HOME; nav = Nav.HOME }

    MaterialTheme(colorScheme = darkColorScheme(background = Bg, surface = Panel, primary = Red, onPrimary = Color.White, onSurface = Color.White)) {
        Surface(Modifier.fillMaxSize(), color = Bg) {
            when (screen) {
                Screen.SELECT_TEAM -> TeamSelect(::selectTeam)
                Screen.HOME -> AppScaffold("${team.name.uppercase()} • 2026", nav, { nav = it; screen = when(it){Nav.HOME->Screen.HOME;Nav.TEAM->Screen.TEAM;Nav.CAR->Screen.CAR;Nav.CALENDAR->Screen.CALENDAR;Nav.STANDINGS->Screen.STANDINGS} }, onMore={ screen=Screen.MANAGEMENT }) { Home(team.name, CarCatalog.forTeam(team.id), drivers, round, store, snapshot?.phase == "RACE" && snapshot?.completed == false, onStart=::startWeekend, onDrivers={screen=Screen.DRIVERS}, onWeekend={screen=Screen.WEEKEND}, onMarket={screen=Screen.MARKET}, onFinance={screen=Screen.FINANCE}, onStandings={screen=Screen.STANDINGS}, onCar={nav=Nav.CAR;screen=Screen.CAR}) }
                Screen.TEAM -> AppScaffold("EQUIPE", nav, { nav=it; screen=when(it){Nav.HOME->Screen.HOME;Nav.TEAM->Screen.TEAM;Nav.CAR->Screen.CAR;Nav.CALENDAR->Screen.CALENDAR;Nav.STANDINGS->Screen.STANDINGS} }, onMore={screen=Screen.MANAGEMENT}) { Team(team.name, team.engine, team.reliability, drivers, onDrivers={screen=Screen.DRIVERS}, onMarket={screen=Screen.MARKET}) }
                Screen.DRIVERS -> DetailScaffold("PILOTOS", {screen=Screen.TEAM}) { Drivers(drivers) }
                Screen.CAR -> AppScaffold("CARRO / P&D", nav, { nav=it; screen=when(it){Nav.HOME->Screen.HOME;Nav.TEAM->Screen.TEAM;Nav.CAR->Screen.CAR;Nav.CALENDAR->Screen.CALENDAR;Nav.STANDINGS->Screen.STANDINGS} }, onMore={screen=Screen.MANAGEMENT}) { Car(CarCatalog.forTeam(team.id), managerState, carMessage, ::startDevelopment) }
                Screen.CALENDAR -> AppScaffold("CALENDÁRIO", nav, { nav=it; screen=when(it){Nav.HOME->Screen.HOME;Nav.TEAM->Screen.TEAM;Nav.CAR->Screen.CAR;Nav.CALENDAR->Screen.CALENDAR;Nav.STANDINGS->Screen.STANDINGS} }, onMore={screen=Screen.MANAGEMENT}) { Calendar(roundIndex, store.roundIndex, ::openHistory) }
                Screen.STANDINGS -> AppScaffold("CAMPEONATO", nav, { nav=it; screen=when(it){Nav.HOME->Screen.HOME;Nav.TEAM->Screen.TEAM;Nav.CAR->Screen.CAR;Nav.CALENDAR->Screen.CALENDAR;Nav.STANDINGS->Screen.STANDINGS} }, onMore={screen=Screen.MANAGEMENT}) { Standings(team.id, store) }
                Screen.FINANCE -> DetailScaffold("FINANÇAS", {screen=Screen.HOME}) { Finance(store) }
                Screen.MARKET -> DetailScaffold("MERCADO DE PILOTOS", {screen=Screen.TEAM}) { DriverMarket(store, team.id, marketDriverId, marketState, marketMessage, { marketDriverId = it }, ::makeMarketInterest) }
                Screen.WEEKEND -> DetailScaffold("FIM DE SEMANA", {screen=Screen.HOME}) { Weekend(round, ::startWeekend) }
                Screen.QUALIFYING -> DetailScaffold("QUALIFICAÇÃO", { screen = Screen.HOME }) { Qualifying(snapshot!!, selectedMode, selectedTyre, {selectedMode=it}, {selectedTyre=it}, ::startRace) }
                Screen.RACE -> DetailScaffold("PIT WALL", { screen = Screen.HOME }) { Race(snapshot!!, drivers, ::advanceRace, { id, mode -> snapshot = engine.setStrategy(id, mode) }, { id, tyre -> snapshot = engine.pitNow(id, tyre) }, { action -> snapshot = engine.choose(action) }) }
                Screen.RESULT -> DetailScaffold("RESULTADO", { screen = Screen.HOME }) { Result(result!!, team.id, store, ::nextRound) }
                Screen.HISTORY -> DetailScaffold("CLASSIFICAÇÃO ARQUIVADA", { screen = Screen.CALENDAR }) { HistoryResult(historyRound, historyResult) }
                Screen.MANAGEMENT -> DetailScaffold("GESTÃO", { screen = Screen.HOME }) { ManagementHub(snapshot?.phase == "RACE" && snapshot?.completed == false, onDrivers={screen=Screen.DRIVERS}, onMarket={screen=Screen.MARKET}, onFinance={screen=Screen.FINANCE}, onCar={screen=Screen.CAR}, onStandings={screen=Screen.STANDINGS}, onCalendar={screen=Screen.CALENDAR}, onWeekend={screen=Screen.WEEKEND}, onRace={screen=Screen.RACE}) }
            }
        }
    }
}

@Composable private fun AppScaffold(title:String, nav:Nav, select:(Nav)->Unit, onMore:()->Unit, content:@Composable ColumnScope.()->Unit) {
    Column(Modifier.fillMaxSize()) { TopBar(title, onMore); Column(Modifier.weight(1f)) { content() }; BottomNav(nav, select) }
}
@Composable private fun DetailScaffold(title:String, back:()->Unit, content:@Composable ColumnScope.()->Unit) { Column(Modifier.fillMaxSize()) { BackTopBar(title, back); Column(Modifier.weight(1f)) { content() } } }
@Composable private fun BackTopBar(title:String, back:()->Unit) { Row(Modifier.fillMaxWidth().padding(horizontal=14.dp,vertical=10.dp),verticalAlignment=Alignment.CenterVertically){Text("‹",color=Color.White,fontSize=34.sp,modifier=Modifier.clickable{back()}.padding(horizontal=6.dp));Text(title,color=Color.White,fontWeight=FontWeight.Bold,maxLines=1,overflow=TextOverflow.Ellipsis,modifier=Modifier.weight(1f));Text("F1 MANAGER",color=Red,fontWeight=FontWeight.Black,fontSize=12.sp)}}
@Composable private fun TopBar(title:String, action:()->Unit) { Row(Modifier.fillMaxWidth().padding(horizontal=16.dp,vertical=12.dp), verticalAlignment=Alignment.CenterVertically, horizontalArrangement=Arrangement.SpaceBetween) { Text("F1 MANAGER",color=Red,fontWeight=FontWeight.Black,letterSpacing=1.sp); Text(title,color=Color.White,fontWeight=FontWeight.Bold,maxLines=1,overflow=TextOverflow.Ellipsis); Text("⋮",color=Color.White,fontSize=25.sp,modifier=Modifier.clickable{action()}) } }
@Composable private fun BottomNav(selected:Nav, select:(Nav)->Unit) { Row(Modifier.fillMaxWidth().background(Color(0xFF101216)).padding(6.dp), horizontalArrangement=Arrangement.SpaceEvenly) { listOf(Nav.HOME to "⌂",Nav.TEAM to "♟",Nav.CAR to "▰",Nav.CALENDAR to "▦",Nav.STANDINGS to "≡").forEach{(n,l)-> Column(horizontalAlignment=Alignment.CenterHorizontally,modifier=Modifier.weight(1f).clickable{select(n)}.padding(5.dp)){Text(l,color=if(selected==n)Red else Muted,fontSize=20.sp);Text(n.name,color=if(selected==n)Color.White else Muted,fontSize=9.sp,fontWeight=FontWeight.Bold)}} } }

@Composable
private fun Home(
    team: String,
    car: com.f1teammanager.core.season.CarSpec,
    drivers: List<com.f1teammanager.core.season.DriverDefinition>,
    round: RoundDefinition,
    store: CareerPreferences,
    raceInProgress: Boolean,
    onStart: () -> Unit,
    onDrivers: () -> Unit,
    onWeekend: () -> Unit,
    onMarket: () -> Unit,
    onFinance: () -> Unit,
    onStandings: () -> Unit,
    onCar: () -> Unit,
) {
    val teamPoints = store.constructorPoints()[WorldDatabase.teams.first { it.name == team }.id] ?: 0
    val teamId = WorldDatabase.teams.first { it.name == team }.id
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("DASHBOARD", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Black); Text("Temporada ${store.season} • Round ${round.round}/24", color = Muted) }
        item { HeroCard(team, car.model) }
        item { SectionTitle("SITUAÇÃO DO CAMPEONATO") }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                StatCard("CONSTRUTORES", "${constructorPosition(teamId, store)}º", "$teamPoints PTS", Modifier.weight(1f))
                StatCard("PILOTO 1", "${drivers.firstOrNull()?.name ?: "—"}", "titular", Modifier.weight(1f))
                StatCard("SALDO", "€ 41,5M", "orçamento", Modifier.weight(1f))
            }
        }
        item { SectionTitle("PRÓXIMA CORRIDA") }
        item { RaceHero(round, onStart) }
        item { SectionTitle("ACESSO RÁPIDO") }
        item {
            val shortcuts = listOf(
                "FIM DE SEMANA" to onWeekend,
                "PILOTOS" to onDrivers,
                "MERCADO" to onMarket,
                "FINANÇAS" to onFinance,
                "CAMPEONATO" to onStandings,
                "CARRO / P&D" to onCar,
            )
            Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                shortcuts.chunked(2).forEach { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(7.dp), modifier = Modifier.fillMaxWidth()) {
                        row.forEach { (label, action) ->
                            Button(onClick = action, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Panel, contentColor = Color.White), shape = RoundedCornerShape(8.dp)) { Text(label, fontSize = 10.sp, fontWeight = FontWeight.Bold) }
                        }
                        if (row.size == 1) Spacer(Modifier.weight(1f))
                    }
                }
            }
        }
        item { SectionTitle("EQUIPE") }
        item { Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(Panel)) { Column(Modifier.padding(14.dp)) { Text("PILOTOS TITULARES", color = Red, fontWeight = FontWeight.Bold); drivers.forEach { Text(it.name, color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 7.dp)) }; Text("Ver perfil completo →", color = Muted, modifier = Modifier.clickable { onDrivers() }.padding(top = 8.dp)) } } }
        item { Button(onClick = onStart, modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(8.dp), colors = ButtonDefaults.buttonColors(containerColor = Red, contentColor = Color.White)) { Text(if (raceInProgress) "RETOMAR PIT WALL" else "INICIAR FIM DE SEMANA", fontWeight = FontWeight.Black) } }
    }
}
@Composable private fun HeroCard(team:String, model:String){ Box(Modifier.fillMaxWidth().height(180.dp).clip(RoundedCornerShape(12.dp)).background(Panel)){Column(Modifier.fillMaxSize().padding(18.dp),verticalArrangement=Arrangement.Bottom){Text(team.uppercase(),color=Color.White,fontSize=25.sp,fontWeight=FontWeight.Black);Text(model,color=Red,fontWeight=FontWeight.Bold);Text("MODELO ESPECÍFICO DA EQUIPE",color=Muted,fontSize=11.sp)}} }
@Composable private fun RaceHero(r:RoundDefinition,onStart:()->Unit){Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(Panel)){Column(Modifier.padding(16.dp)){Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Column{Text("ROUND ${r.round}",color=Red,fontWeight=FontWeight.Bold);Text(r.grandPrix,color=Color.White,fontSize=21.sp,fontWeight=FontWeight.Black);Text(r.circuit,color=Muted)};Text("${r.laps} LAPS",color=Color.White,fontWeight=FontWeight.Bold)};Spacer(Modifier.height(12.dp));Button(onClick=onStart,modifier=Modifier.fillMaxWidth()){Text("ABRIR FIM DE SEMANA")}}}}
@Composable private fun SectionTitle(t:String){Text(t,color=Color.White,fontWeight=FontWeight.Black,fontSize=13.sp,letterSpacing=1.sp)}
@Composable private fun StatCard(a:String,b:String,c:String,m:Modifier){Card(m,colors=CardDefaults.cardColors(Panel)){Column(Modifier.padding(11.dp)){Text(a,color=Muted,fontSize=10.sp,fontWeight=FontWeight.Bold);Text(b,color=Color.White,fontSize=19.sp,fontWeight=FontWeight.Black);Text(c,color=Muted,fontSize=10.sp)}}}

@Composable private fun Team(name:String,engine:Int,reliability:Int,drivers:List<com.f1teammanager.core.season.DriverDefinition>,onDrivers:()->Unit,onMarket:()->Unit){LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){item{HeaderBlock(name,"GESTÃO DA EQUIPE")};item{MetricPanel("FORNECEDOR / MOTOR","Engine",engine,"Confiabilidade",reliability)};item{SectionTitle("PILOTOS TITULARES")};items(drivers){DriverMini(it)};item{Button(onClick=onDrivers,modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=Red,contentColor=Color.White)){Text("ABRIR PERFIS")}};item{SectionTitle("GESTÃO")};item{Row(Modifier.fillMaxWidth().background(Panel,RoundedCornerShape(8.dp)).clickable{onMarket()}.padding(14.dp),horizontalArrangement=Arrangement.SpaceBetween){Column{Text("MERCADO DE PILOTOS",color=Color.White,fontWeight=FontWeight.Bold);Text("Contratos, salários e disponibilidade",color=Muted,fontSize=11.sp)};Text("›",color=Red,fontSize=24.sp)}};item{SectionTitle("INSTALAÇÕES")};item{Facility("FÁBRICA",72)};item{Facility("CENTRO DE P&D",68)};item{Facility("TÚNEL DE VENTO",61)};item{Facility("SIMULADOR",75)}}}
@Composable private fun Drivers(ds:List<com.f1teammanager.core.season.DriverDefinition>){LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){item{HeaderBlock("PILOTOS","PERFIS E ATRIBUTOS")};items(ds){d->Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(Panel)){Column(Modifier.padding(14.dp)){Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text(d.name,color=Color.White,fontWeight=FontWeight.Black,fontSize=18.sp);Text("${d.speed}",color=Red,fontSize=20.sp,fontWeight=FontWeight.Black)};Text("Velocidade  ${d.speed} • Classificação  ${d.qualifying}",color=Muted);Text("Ultrapassagem ${d.overtaking} • Defesa ${d.defense} • Consistência ${d.consistency}",color=Muted);Text("Chuva ${d.wet} • Pneus ${d.tyre}",color=Muted)}}}}}
@Composable private fun DriverMini(d:com.f1teammanager.core.season.DriverDefinition){Row(Modifier.fillMaxWidth().background(Panel,RoundedCornerShape(8.dp)).padding(13.dp),horizontalArrangement=Arrangement.SpaceBetween){Text(d.name,color=Color.White,fontWeight=FontWeight.Bold);Text("OVR ${((d.speed+d.qualifying+d.overtaking+d.defense+d.consistency+d.wet+d.tyre)/7)}",color=Red,fontWeight=FontWeight.Black)}}
@Composable private fun Facility(name:String,v:Int){Column(Modifier.fillMaxWidth().background(Panel,RoundedCornerShape(8.dp)).padding(12.dp)){Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text(name,color=Color.White,fontWeight=FontWeight.Bold);Text("Nível ${v/10}",color=Muted)};LinearProgressIndicator(progress={v/100f},modifier=Modifier.fillMaxWidth().padding(top=8.dp),color=Red,trackColor=Line)}}
@Composable private fun MetricPanel(title:String,a:String,av:Int,b:String,bv:Int){Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(Panel)){Column(Modifier.padding(14.dp)){Text(title,color=Red,fontWeight=FontWeight.Bold);MetricLine(a,av);MetricLine(b,bv)}}}
@Composable private fun MetricLine(l:String,v:Int){Column(Modifier.padding(top=9.dp)){Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text(l,color=Muted);Text(v.toString(),color=Color.White,fontWeight=FontWeight.Bold)};LinearProgressIndicator(progress={v/100f},modifier=Modifier.fillMaxWidth().padding(top=4.dp),color=Red,trackColor=Line)}}
@Composable private fun Car(c:com.f1teammanager.core.season.CarSpec, state:TeamManagerState, message:String, develop:(CarComponent)->Unit){
    val car=state.car; val p=car.activeProject
    LazyColumn(contentPadding=PaddingValues(12.dp),verticalArrangement=Arrangement.spacedBy(7.dp)){
        item{HeaderBlock(c.model,"CARRO • 6 COMPONENTES")}
        item{Text("FORÇA DO CARRO ${((car.engine+car.chassis+car.frontWing+car.rearWing+car.brakes+car.electricPowerUnit)/6)}",color=Red,fontWeight=FontWeight.Black)}
        item{CarComponentRow("UNIDADE DE POTÊNCIA",car.engine,CarComponent.ENGINE,p,develop)}
        item{CarComponentRow("CHASSI",car.chassis,CarComponent.CHASSIS,p,develop)}
        item{CarComponentRow("ASA DIANTEIRA",car.frontWing,CarComponent.FRONT_WING,p,develop)}
        item{CarComponentRow("ASA TRASEIRA",car.rearWing,CarComponent.REAR_WING,p,develop)}
        item{CarComponentRow("FREIOS",car.brakes,CarComponent.BRAKES,p,develop)}
        item{CarComponentRow("UNIDADE DE POTÊNCIA ELÉTRICA",car.electricPowerUnit,CarComponent.ELECTRIC_POWER_UNIT,p,develop)}
        p?.let{item{Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(Panel)){Column(Modifier.padding(10.dp)){Text("P&D EM ANDAMENTO",color=Red,fontWeight=FontWeight.Black,fontSize=10.sp);Text(componentLabel(it.component),color=Color.White,fontWeight=FontWeight.Bold);Text("${it.remainingWeeks}/${it.totalWeeks} semanas restantes",color=Muted,fontSize=10.sp)}}}}
        if(message.isNotBlank()) item{Text(message,color=Color.White,fontSize=10.sp)}
        item{Text("As melhorias entram no motor da corrida e usam semanas do calendário, não quantidade de GPs.",color=Muted,fontSize=9.sp)}
    }
}
@Composable private fun CarComponentRow(title:String,level:Int,component:CarComponent,project:com.f1teammanager.core.manager.DevelopmentProject?,develop:(CarComponent)->Unit){
    Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(Panel)){Row(Modifier.fillMaxWidth().padding(9.dp),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(title,color=Color.White,fontWeight=FontWeight.Bold,fontSize=11.sp);Text("NÍVEL $level • ${componentDuration(component)} semanas",color=Muted,fontSize=9.sp)};Button(onClick={develop(component)},enabled=project==null,colors=ButtonDefaults.buttonColors(containerColor=Red,contentColor=Color.White,disabledContainerColor=Panel2),contentPadding=PaddingValues(horizontal=9.dp,vertical=3.dp)){Text(if(project==null)"DESENVOLVER" else "P&D OCUPADO",fontSize=8.sp)}}}
}
@Composable private fun Calendar(idx:Int,current:Int,openHistory:(Int)->Unit){LazyColumn(contentPadding=PaddingValues(12.dp),verticalArrangement=Arrangement.spacedBy(5.dp)){item{HeaderBlock("CALENDÁRIO 2026","30 GRAND PRIX • 56 SEMANAS")};items(WorldDatabase.rounds){r->Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(if(r.round-1==idx) Color(0xFF2A1010) else Panel)){Row(Modifier.fillMaxWidth().padding(9.dp),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text("ROUND ${r.round} • SEMANA ${r.weekOfSeason} • ${r.month.uppercase()}",color=if(r.round-1==idx)Red else Muted,fontSize=9.sp,fontWeight=FontWeight.Bold);Text(r.grandPrix,color=Color.White,fontWeight=FontWeight.Bold,fontSize=12.sp);Text(r.circuit,color=Muted,fontSize=10.sp)};Column(horizontalAlignment=Alignment.End){Text("${r.laps}v",color=Color.White,fontWeight=FontWeight.Bold,fontSize=10.sp);if(r.round<=current+1){Text("VER RESULTADO",color=Red,fontSize=8.sp,modifier=Modifier.clickable{openHistory(r.round)})}}}}}}
}
@Composable private fun Weekend(r:RoundDefinition,start:()->Unit){LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){item{HeaderBlock(r.grandPrix,"ROUND ${r.round} • ${r.circuit}")};item{RaceHero(r,start)};item{InfoPanel("QUALIFICAÇÃO","Define o grid de largada");InfoPanel("ESTRATÉGIA","Postura + pneu inicial");InfoPanel("CORRIDA","Decisões VSC, SC e bandeira vermelha")};item{Button(onClick=start,modifier=Modifier.fillMaxWidth()){Text("COMEÇAR QUALIFICAÇÃO")}}}}
@Composable private fun InfoPanel(a:String,b:String){Row(Modifier.fillMaxWidth().background(Panel,RoundedCornerShape(8.dp)).padding(14.dp),horizontalArrangement=Arrangement.SpaceBetween){Column{Text(a,color=Color.White,fontWeight=FontWeight.Bold);Text(b,color=Muted,fontSize=11.sp)};Text("›",color=Red,fontSize=24.sp)}}
@Composable private fun Qualifying(s:CareerWeekendEngine.SessionSnapshot,mode:DriverStrategyMode,tyre:Tyre,onMode:(DriverStrategyMode)->Unit,onTyre:(Tyre)->Unit,start:()->Unit){
    var phase by remember { mutableIntStateOf(2) }
    val phases=s.grid?.phases.orEmpty()
    val selected=phases.getOrNull(phase)
    Column(Modifier.fillMaxSize().padding(12.dp)){
        Text("CLASSIFICAÇÃO",color=Color.White,fontSize=23.sp,fontWeight=FontWeight.Black)
        Text("Q1 • Q2 • Q3 — 80 pilotos",color=Red,fontSize=10.sp,fontWeight=FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(5.dp)){listOf("Q1","Q2","Q3").forEachIndexed{i,label->Button(onClick={phase=i},modifier=Modifier.weight(1f),colors=ButtonDefaults.buttonColors(containerColor=if(phase==i)Red else Panel2,contentColor=Color.White),contentPadding=PaddingValues(vertical=4.dp)){Text(label,fontWeight=FontWeight.Black)}}}
        selected?.let{Text("${it.name}: ${it.entries.size} pilotos • eliminados nesta fase: ${it.eliminatedDriverIds.size}",color=Muted,fontSize=9.sp,modifier=Modifier.padding(vertical=5.dp))}
        ChoiceRow("POSTURA",mode.name,DriverStrategyMode.entries.toList(),onMode)
        ChoiceRow("PNEU INICIAL",tyre.name,listOf(Tyre.SOFT,Tyre.MEDIUM,Tyre.HARD),onTyre)
        LazyColumn(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(2.dp)){
            items(selected?.entries.orEmpty()){e->Row(Modifier.fillMaxWidth().background(Panel,RoundedCornerShape(4.dp)).padding(horizontal=8.dp,vertical=5.dp),horizontalArrangement=Arrangement.SpaceBetween){Text("P${e.position}",color=Red,fontWeight=FontWeight.Black,fontSize=10.sp);Text(WorldDatabase.drivers.firstOrNull{it.id==e.driverId}?.name?:"Piloto ${e.driverId}",color=Color.White,fontSize=10.sp,modifier=Modifier.weight(1f).padding(horizontal=8.dp));Text(formatMs(e.lapTimeMs),color=Muted,fontSize=9.sp)}}
        }
        Button(onClick=start,modifier=Modifier.fillMaxWidth().height(48.dp),colors=ButtonDefaults.buttonColors(containerColor=Red,contentColor=Color.White)){Text("INICIAR CORRIDA",fontWeight=FontWeight.Black)}
    }
}
@Composable private fun <T> ChoiceRow(title:String,current:String,values:List<T>,select:(T)->Unit){Column{Text(title,color=Muted,fontSize=10.sp,fontWeight=FontWeight.Bold);Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(6.dp)){values.forEach{v->FilterChip(selected=v.toString()==current,onClick={select(v)},label={Text(v.toString())})}}}}
@Composable
private fun Race(
    s: CareerWeekendEngine.SessionSnapshot,
    drivers: List<com.f1teammanager.core.season.DriverDefinition>,
    advance: () -> Unit,
    setStrategy: (Int, DriverStrategyMode) -> Unit,
    pitNow: (Int, Tyre) -> Unit,
    decision: (ManagerDecisionAction) -> Unit,
) {
    var running by remember { mutableStateOf(true) }
    var speedMs by remember { mutableIntStateOf(1100) }
    var pitDriver by remember { mutableIntStateOf(-1) }
    val playerIds = drivers.map { it.id }.toSet()
    val playerStatus = s.carStatus.filter { it.driverId in playerIds }
    val statusById = s.carStatus.associateBy { it.driverId }
    val leaderTime = s.classification.minOfOrNull { it.totalTimeMs } ?: 0L

    LaunchedEffect(s.lap, s.decision, s.completed, running, speedMs) {
        if (running && s.decision == null && !s.completed) {
            kotlinx.coroutines.delay(speedMs.toLong())
            advance()
        }
    }

    Column(Modifier.fillMaxSize().padding(horizontal = 10.dp)) {
        Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column { Text("PIT WALL", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Black); Text("VOLTA ${s.lap}/${s.totalLaps}", color = Red, fontWeight = FontWeight.Bold) }
            Column(horizontalAlignment = Alignment.End) { Text(statusLabel(s.neutral), color = if (s.neutral == Neutralisation.GREEN) Green else Red, fontWeight = FontWeight.Black); Text(if (running) "AUTOMÁTICA" else "PAUSADA", color = Muted, fontSize = 9.sp) }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            listOf(1600 to "0,7x", 1100 to "1x", 650 to "1,7x", 300 to "3x").forEach { (ms, label) ->
                Button(onClick={speedMs=ms}, modifier=Modifier.weight(1f), colors=ButtonDefaults.buttonColors(containerColor=if(speedMs==ms) Red else Panel2, contentColor=Color.White), contentPadding=PaddingValues(vertical=2.dp)){Text(label,fontSize=9.sp)}
            }
        }

        val critical=s.alerts.firstOrNull { it.severity>=3 }
        critical?.let { Card(Modifier.fillMaxWidth().padding(vertical=3.dp), colors=CardDefaults.cardColors(containerColor=Color(0xFF3A0D0D))){Text(it.message,color=Color.White,fontWeight=FontWeight.Bold,fontSize=10.sp,modifier=Modifier.padding(7.dp))} }

        // Decision area deliberately compact: only the two team cars remain above the live classification.
        playerStatus.forEach { st ->
            val plan=s.plans[st.driverId]
            val gap=if(st.position<=1) "LÍDER" else gapText(s.classification.getOrNull(st.position-1)?.totalTimeMs ?: st.lastLapMs,leaderTime)
            Card(Modifier.fillMaxWidth().padding(vertical=2.dp), colors=CardDefaults.cardColors(Panel)) {
                Row(Modifier.fillMaxWidth().padding(horizontal=8.dp,vertical=6.dp),verticalAlignment=Alignment.CenterVertically){
                    Column(Modifier.weight(1f)){
                        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text(st.driverName,color=Color.White,fontWeight=FontWeight.Black,fontSize=14.sp);Text("P${st.position} $gap",color=Red,fontWeight=FontWeight.Black,fontSize=12.sp)}
                        Text("${tyreLabel(st.tyre)} ${st.tyreWear}%  •  COMB ${st.fuelPercent}%  •  ERS ${st.ersPercent}%  •  ${if(st.drsActive) "DRS ATIVO" else "DRS —"}",color=if(st.fuelPercent<=20||st.tyreWear>=75) Red else Muted,fontSize=9.sp)
                    }
                    Spacer(Modifier.width(5.dp))
                    Button(onClick={pitDriver=st.driverId},colors=ButtonDefaults.buttonColors(containerColor=Red,contentColor=Color.White),contentPadding=PaddingValues(horizontal=11.dp,vertical=3.dp)){Text("BOX",fontSize=9.sp,fontWeight=FontWeight.Black)}
                }
                Row(Modifier.fillMaxWidth().padding(start=8.dp,end=8.dp,bottom=5.dp),horizontalArrangement=Arrangement.spacedBy(4.dp)){
                    DriverStrategyMode.entries.forEach { m -> Button(onClick={setStrategy(st.driverId,m)},modifier=Modifier.weight(1f),colors=ButtonDefaults.buttonColors(containerColor=if(plan?.mode==m) Red else Panel2,contentColor=Color.White),contentPadding=PaddingValues(vertical=2.dp)){Text(strategyLabel(m),fontSize=8.sp,maxLines=1)} }
                }
            }
        }

        Card(Modifier.fillMaxWidth().weight(1f), colors=CardDefaults.cardColors(Panel)) {
            Column {
                Row(Modifier.fillMaxWidth().padding(horizontal=8.dp,vertical=6.dp),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){Text("CLASSIFICAÇÃO AO VIVO",color=Color.White,fontWeight=FontWeight.Black,fontSize=15.sp);Text("${s.classification.size} PILOTOS",color=Red,fontWeight=FontWeight.Black,fontSize=10.sp)}
                Row(Modifier.fillMaxWidth().padding(horizontal=8.dp),horizontalArrangement=Arrangement.SpaceBetween){Text("POS",color=Muted,fontSize=8.sp,modifier=Modifier.width(24.dp));Text("PILOTO",color=Muted,fontSize=8.sp,modifier=Modifier.weight(1f));Text("PNEU",color=Muted,fontSize=8.sp,modifier=Modifier.width(42.dp));Text("GAP",color=Muted,fontSize=8.sp,modifier=Modifier.width(54.dp))}
                LazyColumn(Modifier.weight(1f)) {
                    items(s.classification) { f ->
                        val mine=f.driverId in playerIds; val st=statusById[f.driverId]; val gap=if(f.position==1)"LÍDER" else gapText(f.totalTimeMs,leaderTime)
                        Row(Modifier.fillMaxWidth().background(if(mine) Color(0xFF2A1010) else Color.Transparent).padding(horizontal=8.dp,vertical=3.dp),verticalAlignment=Alignment.CenterVertically){
                            Text("${f.position}",color=if(mine)Red else Muted,fontWeight=FontWeight.Bold,modifier=Modifier.width(24.dp),fontSize=10.sp)
                            Text(f.driverName,color=Color.White,modifier=Modifier.weight(1f),maxLines=1,overflow=TextOverflow.Ellipsis,fontSize=10.sp)
                            Text(tyreLabel(f.tyre),color=if((st?.tyreWear?:0)>=80)Red else Muted,fontSize=8.sp,modifier=Modifier.width(42.dp))
                            Text(if(f.status.startsWith("DNF"))"DNF" else gap,color=if(f.status.startsWith("DNF"))Red else Muted,fontSize=8.sp,modifier=Modifier.width(54.dp))
                        }
                    }
                }
            }
        }

        if(s.events.isNotEmpty()) Text(s.events.takeLast(1).joinToString(" • "){it.detail},color=Muted,fontSize=8.sp,maxLines=1,overflow=TextOverflow.Ellipsis,modifier=Modifier.padding(vertical=2.dp))
        Button(onClick={running=!running},modifier=Modifier.fillMaxWidth().height(42.dp),colors=ButtonDefaults.buttonColors(containerColor=Red,contentColor=Color.White)){Text(if(running)"PAUSAR CORRIDA" else "RETOMAR CORRIDA",fontWeight=FontWeight.Black,fontSize=12.sp)}

        s.decision?.let { d ->
            AlertDialog(onDismissRequest={},title={Text("DECISÃO DO MANAGER",fontWeight=FontWeight.Black)},text={Column{Text("${d.driverName}: ${d.request.message}",color=Color.White);Spacer(Modifier.height(6.dp));d.request.options.forEach{action->Button(onClick={decision(action)},modifier=Modifier.fillMaxWidth().padding(vertical=1.dp),colors=ButtonDefaults.buttonColors(containerColor=Red,contentColor=Color.White),contentPadding=PaddingValues(vertical=4.dp)){Text(actionLabel(action),fontSize=10.sp)}}}},confirmButton={})
        }
        if(pitDriver>0){
            AlertDialog(onDismissRequest={pitDriver=-1},title={Text("ESCOLHER PNEU PARA O BOX",fontWeight=FontWeight.Black)},text={Column{Text("A troca acontece agora. Escolha o composto:",color=Muted);listOf(Tyre.SOFT,Tyre.MEDIUM,Tyre.HARD).forEach{t->Button(onClick={pitNow(pitDriver,t);pitDriver=-1},modifier=Modifier.fillMaxWidth().padding(vertical=2.dp),colors=ButtonDefaults.buttonColors(containerColor=Panel2,contentColor=Color.White)){Text(tyreLabel(t))}}}},confirmButton={})
        }
    }
}

private fun gapText(time: Long, leader: Long): String {
    val gap = (time - leader).coerceAtLeast(0L)
    return "+${gap / 1000}.${(gap % 1000) / 100}s"
}

@Composable private fun Result(r:RaceResult,teamId:Int,store:CareerPreferences,next:()->Unit){
    val teamName=WorldDatabase.teams.first{it.id==teamId}.name
    val mine=r.classification.filter{it.teamName==teamName}
    val earned=mine.sumOf{r.points[it.driverId]?:0}
    Column(Modifier.fillMaxSize().padding(16.dp)){
        HeaderBlock("RESULTADO","CORRIDA FINALIZADA")
        Card(Modifier.fillMaxWidth().padding(top=10.dp),colors=CardDefaults.cardColors(Panel)){Column(Modifier.padding(13.dp)){Text("SUA EQUIPE",color=Red,fontWeight=FontWeight.Black);mine.forEach{f->Text("P${f.position} • ${f.driverName} • ${r.points[f.driverId]?:0} PTS",color=Color.White,fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=5.dp))};Text("PONTOS CONQUISTADOS: $earned",color=Color.White,fontWeight=FontWeight.Black,modifier=Modifier.padding(top=8.dp))}}
        LazyColumn(Modifier.weight(1f),contentPadding=PaddingValues(vertical=10.dp),verticalArrangement=Arrangement.spacedBy(3.dp)){items(r.classification){f->Row(Modifier.fillMaxWidth().background(if(f.position<=3)Color(0xFF251414) else Panel,RoundedCornerShape(5.dp)).padding(9.dp),horizontalArrangement=Arrangement.SpaceBetween){Text("P${f.position}",color=if(f.position<=3)Red else Muted,fontWeight=FontWeight.Black);Text(f.driverName,color=Color.White,modifier=Modifier.weight(1f).padding(horizontal=8.dp),maxLines=1,overflow=TextOverflow.Ellipsis);Text("${r.points[f.driverId]?:0} PTS",color=if((r.points[f.driverId]?:0)>0) Color.White else Muted,fontSize=10.sp)}}}
        Text("Safety Car ${r.safetyCarLaps} • VSC ${r.vscLaps} • Campeonato: ${store.constructorPoints()[teamId]?:0} PTS",color=Muted,fontSize=10.sp)
        Button(onClick=next,modifier=Modifier.fillMaxWidth().height(48.dp),colors=ButtonDefaults.buttonColors(containerColor=Red,contentColor=Color.White)){Text("PRÓXIMO GP",fontWeight=FontWeight.Black)}
    }
}
private fun initialManagerState(teamId:Int):TeamManagerState { val t=WorldDatabase.teams.first{it.id==teamId}; return TeamManagerState(playerTeamId=teamId,car=TeamCarState(t.baseCar,t.chassis,t.engine,t.reliability,frontWing=t.frontWing,rearWing=t.rearWing,brakes=t.brakes,electricPowerUnit=t.electricPowerUnit),finance=TeamFinanceState(75_000_000L)) }
private fun componentLabel(c:CarComponent)=when(c){CarComponent.ENGINE->"Unidade de potência";CarComponent.CHASSIS->"Chassi";CarComponent.FRONT_WING->"Asa dianteira";CarComponent.REAR_WING->"Asa traseira";CarComponent.BRAKES->"Freios";CarComponent.ELECTRIC_POWER_UNIT->"Unidade de potência elétrica"}
private fun componentDuration(c:CarComponent)=when(c){CarComponent.ENGINE->4;CarComponent.CHASSIS->3;CarComponent.FRONT_WING->2;CarComponent.REAR_WING->2;CarComponent.BRAKES->2;CarComponent.ELECTRIC_POWER_UNIT->4}
@Composable private fun HistoryResult(round:Int,result:RaceResult?){ if(result==null){Text("Nenhuma classificação salva para o Round $round",color=Muted,modifier=Modifier.padding(16.dp));return}; Column(Modifier.fillMaxSize().padding(12.dp)){HeaderBlock("ROUND $round","CLASSIFICAÇÃO SALVA");LazyColumn(Modifier.weight(1f),contentPadding=PaddingValues(vertical=8.dp)){items(result.classification){f->Row(Modifier.fillMaxWidth().background(if(f.position<=3)Color(0xFF251414) else Panel,RoundedCornerShape(5.dp)).padding(8.dp),verticalAlignment=Alignment.CenterVertically){Text("P${f.position}",color=if(f.position<=3)Red else Muted,fontWeight=FontWeight.Black,modifier=Modifier.width(38.dp));Text(f.driverName,color=Color.White,modifier=Modifier.weight(1f),maxLines=1,overflow=TextOverflow.Ellipsis);Text("${result.points[f.driverId]?:0} PTS",color=Muted,fontSize=9.sp)}}}} }



@Composable
private fun TeamSelect(onSelect: (Int) -> Unit) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        HeaderBlock("F1 MANAGER", "ESCOLHA SUA EQUIPE")
        Text("40 equipes • 80 pilotos", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(vertical = 8.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp), contentPadding = PaddingValues(bottom = 16.dp)) {
            items(WorldDatabase.teams) { t ->
                Card(Modifier.fillMaxWidth().clickable { onSelect(t.id) }, colors = CardDefaults.cardColors(Panel)) {
                    Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(t.name, color = Color.White, fontWeight = FontWeight.Black)
                            Text("Força ${t.baseCar} • Motor ${t.engine} • Confiabilidade ${t.reliability}", color = Muted, fontSize = 10.sp)
                        }
                        Text("ESCOLHER", color = Red, fontWeight = FontWeight.Black, fontSize = 10.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun Standings(teamId: Int, store: CareerPreferences) {
    val points = store.driverPoints()
    val rows = WorldDatabase.drivers.map { d ->
        val t = WorldDatabase.teams.first { it.id == d.teamId }
        Triple(d, t, points[d.id] ?: 0)
    }.sortedByDescending { it.third }
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        HeaderBlock("CAMPEONATO", "PILOTOS")
        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            items(rows) { (d, t, pts) ->
                Row(Modifier.fillMaxWidth().background(if (t.id == teamId) Color(0xFF251414) else Panel, RoundedCornerShape(5.dp)).padding(9.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("${rows.indexOfFirst { it.first.id == d.id } + 1}", color = if (t.id == teamId) Red else Muted, fontWeight = FontWeight.Black, modifier = Modifier.width(28.dp))
                    Text(d.name, color = Color.White, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(t.name, color = Muted, fontSize = 9.sp, modifier = Modifier.width(105.dp), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("$pts PTS", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 10.sp)
                }
            }
        }
    }
}

@Composable
private fun Finance(store: CareerPreferences) {
    val teamId = store.teamId
    val points = store.constructorPoints()[teamId] ?: 0
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        HeaderBlock("FINANÇAS", "CARREIRA")
        Card(Modifier.fillMaxWidth().padding(top = 10.dp), colors = CardDefaults.cardColors(Panel)) {
            Column(Modifier.padding(14.dp)) {
                Text("ORÇAMENTO", color = Red, fontWeight = FontWeight.Black, fontSize = 11.sp)
                Text("€75.000.000", color = Color.White, fontWeight = FontWeight.Black, fontSize = 24.sp, modifier = Modifier.padding(vertical = 5.dp))
                Text("Patrocínio: disponível na gestão financeira da carreira", color = Muted, fontSize = 10.sp)
                Text("Pontos de construtores: $points", color = Muted, fontSize = 10.sp, modifier = Modifier.padding(top = 4.dp))
            }
        }
        Text("Receitas e despesas detalhadas ficam vinculadas ao estado financeiro da carreira.", color = Muted, fontSize = 10.sp, modifier = Modifier.padding(top = 10.dp))
    }
}

@Composable
private fun DriverMarket(
    store: CareerPreferences,
    teamId: Int,
    selectedDriverId: Int,
    state: DriverMarketState,
    message: String,
    onSelect: (Int) -> Unit,
    onInterest: (Int) -> Unit
) {
    val free = state.released.mapNotNull { id -> WorldDatabase.allDrivers.firstOrNull { it.id == id } }
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        HeaderBlock("MERCADO", "PILOTOS LIVRES")
        if (message.isNotBlank()) Text(message, color = Green, fontSize = 10.sp, modifier = Modifier.padding(vertical = 6.dp))
        if (free.isEmpty()) Text("Nenhum piloto livre no momento.", color = Muted, modifier = Modifier.padding(16.dp))
        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            items(free) { d ->
                val selected = selectedDriverId == d.id
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(if (selected) Color(0xFF251414) else Panel)) {
                    Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(d.name, color = Color.White, fontWeight = FontWeight.Bold)
                            Text("Velocidade ${d.speed} • Quali ${d.qualifying} • Chuva ${d.wet}", color = Muted, fontSize = 9.sp)
                        }
                        Button(onClick = { onSelect(d.id); onInterest(d.id) }, colors = ButtonDefaults.buttonColors(containerColor = Red, contentColor = Color.White), contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)) {
                            Text("INTERESSE", fontSize = 9.sp, fontWeight = FontWeight.Black)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ManagementHub(
    raceActive: Boolean,
    onDrivers: () -> Unit,
    onMarket: () -> Unit,
    onFinance: () -> Unit,
    onCar: () -> Unit,
    onStandings: () -> Unit,
    onCalendar: () -> Unit,
    onWeekend: () -> Unit,
    onRace: () -> Unit
) {
    val actions = listOf(
        "PIT WALL" to onRace,
        "FIM DE SEMANA" to onWeekend,
        "PILOTOS" to onDrivers,
        "MERCADO" to onMarket,
        "CARRO / P&D" to onCar,
        "CAMPEONATO" to onStandings,
        "CALENDÁRIO" to onCalendar,
        "FINANÇAS" to onFinance
    )
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        HeaderBlock("CENTRAL DE GESTÃO", if (raceActive) "CORRIDA ATIVA" else "TEMPORADA")
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(vertical = 10.dp)) {
            items(actions) { (label, action) ->
                Button(onClick = action, modifier = Modifier.fillMaxWidth().height(46.dp), colors = ButtonDefaults.buttonColors(containerColor = if (label == "PIT WALL" && raceActive) Red else Panel2, contentColor = Color.White)) {
                    Text(label, fontWeight = FontWeight.Black, fontSize = 11.sp)
                }
            }
        }
    }
}

private fun strategyLabel(m:DriverStrategyMode)=when(m){DriverStrategyMode.ATTACK->"ATAQUE";DriverStrategyMode.BALANCED->"EQUILIBRADO";DriverStrategyMode.DEFENSE->"DEFESA / ECONOMIA"}
private fun tyreLabel(t:Tyre)=when(t){Tyre.SOFT->"SOFT";Tyre.MEDIUM->"MEDIUM";Tyre.HARD->"HARD";Tyre.INTERMEDIATE->"INTER";Tyre.WET->"WET"}
private fun statusLabel(n:Neutralisation)=when(n){Neutralisation.GREEN->"GREEN FLAG";Neutralisation.VSC->"VSC";Neutralisation.SAFETY_CAR->"SAFETY CAR"}
private fun actionLabel(a:ManagerDecisionAction)=when(a){ManagerDecisionAction.BOX->"BOX";ManagerDecisionAction.STAY_OUT->"MANTER";ManagerDecisionAction.EXTEND_STINT->"ESTENDER STINT";ManagerDecisionAction.SAVE_FUEL->"POUPAR COMBUSTÍVEL";ManagerDecisionAction.CHANGE_STRATEGY->"MUDAR ESTRATÉGIA";ManagerDecisionAction.RESTART_ATTACK->"RELARGADA • ATAQUE";ManagerDecisionAction.RESTART_BALANCED->"RELARGADA • EQUILIBRADO";ManagerDecisionAction.RESTART_DEFENSE->"RELARGADA • DEFESA";ManagerDecisionAction.CHANGE_TYRE_SOFT->"RELARGADA • SOFT / ATAQUE";ManagerDecisionAction.CHANGE_TYRE_MEDIUM->"RELARGADA • MEDIUM / EQUILIBRADO";ManagerDecisionAction.CHANGE_TYRE_HARD->"RELARGADA • HARD / DEFESA";ManagerDecisionAction.CHANGE_TYRE_INTERMEDIATE->"INTERMEDIÁRIO";ManagerDecisionAction.CHANGE_TYRE_WET->"WET"}
private fun formatMs(ms:Long)="%d:%02d.%03d".format(ms/60000,(ms/1000)%60,ms%1000)
