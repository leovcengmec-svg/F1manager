package com.f1teammanager

import android.os.Bundle
import android.os.Build
import android.Manifest
import androidx.activity.ComponentActivity
import androidx.core.view.WindowCompat
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import com.f1teammanager.core.race.*
import com.f1teammanager.core.manager.CarComponent
import com.f1teammanager.core.manager.CarDevelopmentEngine
import com.f1teammanager.core.manager.DevelopmentIntensity
import com.f1teammanager.core.manager.CarDevelopmentFocus
import com.f1teammanager.core.manager.TeamCarState
import com.f1teammanager.core.manager.TeamManagerState
import com.f1teammanager.core.manager.TeamFinanceState
import com.f1teammanager.core.manager.FinanceEngine
import com.f1teammanager.core.manager.ManagerMarketEngine
import com.f1teammanager.core.manager.SponsorContract
import com.f1teammanager.core.manager.DynamicGridEngine
import com.f1teammanager.core.manager.DriverMarketEngine
import com.f1teammanager.core.manager.DriverMarketState
import com.f1teammanager.core.manager.DriverTeamRole
import com.f1teammanager.core.manager.NegotiationStatus
import com.f1teammanager.core.season.CarCatalog
import com.f1teammanager.core.season.RoundDefinition
import com.f1teammanager.core.season.WorldDatabase
import com.f1teammanager.core.season.toParticipant

private val Bg = Color(0xFF08090C)
private val Panel = Color(0xFF14161B)
private val Panel2 = Color(0xFF1B1E24)
private val Red = Color(0xFFE10600)
private val Muted = Color(0xFF8D929C)
private val Line = Color(0xFF2B2F36)
private val Green = Color(0xFF38C878)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, true)
        setContent { F1ManagerApp(CareerPreferences(this)) }
        window.decorView.post { requestExternalAssetPermissionIfNeeded() }
    }

    private fun requestExternalAssetPermissionIfNeeded() {
        runCatching {
            val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_IMAGES else Manifest.permission.READ_EXTERNAL_STORAGE
            if (androidx.core.content.ContextCompat.checkSelfPermission(this, permission) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(permission), 4101)
            }
        }
    }
}

private enum class Screen { HOME, TEAM, DRIVERS, CAR, CALENDAR, STANDINGS, FINANCE, MARKET, WEEKEND, QUALIFYING, RACE, RESULT, HISTORY, HISTORY_CENTER, NEWS, HALL_OF_FAME, RECORDS, SEASON, MANAGEMENT, SELECT_TEAM }
private enum class Nav { HOME, TEAM, CAR, CALENDAR, STANDINGS }

@Composable
private fun F1ManagerApp(store: CareerPreferences) {
    var hasCareer by remember { mutableStateOf(store.hasCareer) }
    var teamId by remember { mutableIntStateOf(store.teamId) }
    var roundIndex by remember { mutableIntStateOf(store.roundIndex) }
    var currentWeek by remember { mutableIntStateOf(store.currentWeek) }
    var screen by remember { mutableStateOf(if (hasCareer) Screen.HOME else Screen.SELECT_TEAM) }
    var nav by remember { mutableStateOf(Nav.HOME) }
    var selectedMode by remember { mutableStateOf(DriverStrategyMode.BALANCED) }
    var selectedTyre by remember { mutableStateOf(Tyre.MEDIUM) }
    var snapshot by remember { mutableStateOf<CareerWeekendEngine.SessionSnapshot?>(null) }
    var result by remember { mutableStateOf<RaceResult?>(null) }
    var marketDriverId by remember { mutableIntStateOf(-1) }
    var marketMessage by remember { mutableStateOf("") }
        var managerState by remember(teamId) { mutableStateOf(store.loadCar(teamId)?.let { val base=TeamManagerState(season=store.season, round=store.roundIndex+1, car=it, finance=TeamFinanceState(75_000_000L), playerTeamId=teamId); run { val sponsors=store.loadSponsors(teamId); base.copy(finance=store.loadFinance(teamId,base.finance), sponsor=sponsors.firstOrNull { it.slot==1 } ?: store.loadSponsor(teamId,base.sponsor), sponsors=sponsors, driverMarket=store.loadDriverMarket() ?: DriverMarketEngine(20261003).initialState(store.season)) } } ?: initialManagerState(teamId,store)) }
    var historyRound by remember { mutableIntStateOf(-1) }
    var historyResult by remember { mutableStateOf<RaceResult?>(null) }
    var carMessage by remember { mutableStateOf("") }
    var calendarMessage by remember { mutableStateOf("") }
    var sponsorMessage by remember { mutableStateOf("") }
    val marketEngine = remember { DriverMarketEngine(20261003) }
    val engine = remember { CareerWeekendEngine(20261003) }
    val team = WorldDatabase.teams.firstOrNull { it.id == teamId } ?: WorldDatabase.teams.first()
    val drivers = store.currentDrivers().filter { it.teamId == team.id }
    val round = WorldDatabase.rounds.getOrElse(roundIndex) { WorldDatabase.rounds.first() }
    val development = remember { CarDevelopmentEngine() }

    fun participants() = DynamicGridEngine().participants(
        managerState.driverMarket, managerState.car, managerState.playerTeamId, 0, roundIndex + 1, store.season, (currentWeek - 1).coerceAtLeast(0),
        store.currentDrivers().associateBy { it.id }
    )
    fun circuit() = RaceCircuit(round.round, round.circuit, round.laps, round.baseLapTimeMs, round.powerFactor, round.overtakingFactor, round.crashRisk, round.reliabilityRisk, round.safetyCarRisk)
    fun startWeekend() {
        if (snapshot != null && snapshot?.completed == false && snapshot?.phase == "RACE") { screen = Screen.RACE; return }
        if (currentWeek != round.weekOfSeason) {
            calendarMessage = "A próxima corrida é na semana ${round.weekOfSeason}. Use PULAR 1 SEMANA ou PULAR ATÉ A PRÓXIMA CORRIDA."
            screen = Screen.CALENDAR
            return
        }
        snapshot = engine.start(participants(), circuit(), team.id); result = null; screen = Screen.QUALIFYING
    }
    fun advanceFreeWeeks(weeks: Int, targetWeek: Int) {
        val delta = (targetWeek - currentWeek).coerceAtLeast(0)
        if (delta == 0) return
        // P&D trabalha em semanas reais do calendário, não apenas em semanas livres.
        // Assim, semanas de GP também consomem uma etapa do projeto.
        managerState = development.advanceWeeks(managerState, delta)
        // O mercado da IA funciona durante toda a temporada: cada semana realmente
        // transcorrida precisa ter seu próprio tick para expirar propostas, scouting
        // e permitir novas negociações. Não podemos processar apenas a semana-alvo.
        for (week in (currentWeek + 1)..targetWeek) {
            managerState = managerState.copy(
                driverMarket = marketEngine.processAiMarketWeek(managerState.driverMarket, store.season, week, team.id)
            )
        }
        store.saveCar(teamId, managerState.car)
        store.saveDriverMarket(managerState.driverMarket)
        currentWeek = targetWeek
        store.jumpToWeek(targetWeek)
        calendarMessage = "${delta} semana(s) de calendário processada(s). P&D avançou junto com o calendário, incluindo semanas de GP."
    }
    fun skipOneWeek() {
        if (currentWeek >= 56) return
        if (currentWeek == round.weekOfSeason) {
            calendarMessage = "Esta é a semana do GP. Não é possível pular a corrida."
            return
        }
        advanceFreeWeeks(1, currentWeek + 1)
    }
    fun jumpToNextRace() {
        if (currentWeek == round.weekOfSeason) {
            calendarMessage = "Você está na semana do GP. Primeiro simule e conclua esta corrida; só depois poderá avançar para o próximo GP."
            screen = Screen.CALENDAR
            return
        }
        val target = if (currentWeek < round.weekOfSeason) {
            round.weekOfSeason
        } else {
            WorldDatabase.rounds.getOrNull(roundIndex + 1)?.weekOfSeason
        }
        if (target == null) { calendarMessage = "Você já está na última corrida da temporada."; return }
        advanceFreeWeeks((target-currentWeek).coerceAtLeast(0), target)
    }
    fun simulateQualifying() { snapshot = engine.simulateQualifyingPhase() }
    fun startRace() {
        if (!engine.qualifyingComplete()) { snapshot = engine.simulateQualifyingPhase(); return }
        snapshot = engine.snapshotForUi()
        screen = Screen.RACE
    }
    fun advanceRace() {
        snapshot = engine.advance()
        if (snapshot?.completed == true) {
            result = engine.result()
            val teamName = team.name
            val mine = result!!.classification.filter { it.teamName == teamName }
            val teamPoints = mine.sumOf { result!!.points[it.driverId] ?: 0 }
            val best = mine.minOfOrNull { if (it.status.startsWith("DNF")) 999 else it.position } ?: 999
            managerState = FinanceEngine().applyRace(managerState,best,teamPoints,mine.all { it.status.startsWith("DNF") })
            store.recordRace(round.round, result!!, round, snapshot?.grid)
            store.applyDriverRaceEvolution(round.round)
            store.saveCar(teamId, managerState.car); store.saveFinance(teamId, managerState.finance); store.saveSponsors(teamId, managerState.sponsors)
            screen = Screen.RESULT
        }
    }
    fun returnToCalendarAfterRace() {
        // O avanço do calendário já consumiu todas as semanas que realmente
        // transcorreram. A semana do GP só entra no P&D depois que a corrida
        // é concluída e o jogador avança para a semana seguinte.
        store.completeCurrentRace()
        roundIndex = store.roundIndex
        currentWeek = store.currentWeek

        snapshot = null
        result = null
        if (store.isSeasonEnded()) {
            screen = Screen.HOME
            nav = Nav.HOME
            calendarMessage = "TEMPORADA ${store.season} ENCERRADA. As 30 corridas foram concluídas e o histórico foi arquivado."
        } else {
            screen = Screen.CALENDAR
            nav = Nav.CALENDAR
            calendarMessage = "Corrida concluída. A semana ${currentWeek} continua sendo a semana atual; avance o calendário manualmente até o próximo GP."
        }
    }

    fun startNextSeason() {
        runCatching {
            store.startNextSeason()
            managerState = development.startNextSeason(managerState, store.season)
            store.initializeDriverSeasonTargets(managerState.car)
            store.saveCar(teamId, managerState.car)
            store.saveFinance(teamId, managerState.finance)
            store.saveSponsors(teamId, managerState.sponsors)
            managerState = managerState.copy(driverMarket=store.loadDriverMarket() ?: marketEngine.initialState(store.season))
            store.saveDriverMarket(managerState.driverMarket)
            roundIndex = store.roundIndex
            currentWeek = store.currentWeek
            calendarMessage = "Nova temporada ${store.season} iniciada. O novo carro foi aplicado e o campeonato foi zerado."
            screen = Screen.HOME
            nav = Nav.HOME
        }.onFailure {
            calendarMessage = it.message ?: "Não foi possível iniciar a nova temporada."
        }
    }
    fun startDevelopment(component: CarComponent, intensity: DevelopmentIntensity) {
        runCatching {
            managerState = development.start(managerState, component, intensity)
            val projectTotal = managerState.car.activeProject?.totalWeeks ?: 0
            val gain = managerState.car.activeProject?.expectedGain ?: 0
            // Iniciar um projeto não consome uma semana imediatamente.
            // O trabalho só avança quando o calendário avança de fato.
            store.saveCar(teamId, managerState.car); store.saveFinance(teamId, managerState.finance)
            carMessage = "${componentLabel(component)} iniciado: ${projectTotal} semana(s) • +${gain}."
        }
            .onFailure { carMessage = it.message ?: "Não foi possível iniciar o projeto." }
    }
    fun investNextSeason(amount: Long) {
        runCatching { managerState = development.investNextSeason(managerState, amount); store.saveCar(teamId, managerState.car); store.saveFinance(teamId, managerState.finance); carMessage = "€ ${amount/1_000_000}M investidos no carro ${store.season + 1}." }
            .onFailure { carMessage = it.message ?: "Não foi possível investir no próximo carro." }
    }
    fun setNextSeasonFocus(focus: CarDevelopmentFocus) {
        managerState = development.setNextSeasonFocus(managerState, focus)
        store.saveCar(teamId, managerState.car)
    }
    fun openHistory(r:Int) { historyRound=r; historyResult=store.raceHistory(r); screen=Screen.HISTORY }
    fun makeMarketProposal(driverId: Int, replacementDriverId: Int?, years: Int, salary: Long, role: DriverTeamRole) {
        val driver = WorldDatabase.allDrivers.first { it.id == driverId }
        runCatching {
            val (next, offer) = marketEngine.makeOffer(managerState.driverMarket, driverId, team.id, years, salary, role, store.season, currentWeek = currentWeek, replaceDriverId = replacementDriverId)
            managerState = managerState.copy(driverMarket=next)
            store.saveDriverMarket(managerState.driverMarket)
            store.saveFinance(teamId, managerState.finance)
            marketMessage = when (offer.status) {
                NegotiationStatus.ACCEPTED -> "Pré-contrato com ${driver.name} assinado para ${store.season + 1}. O piloto continua na equipe atual até o fim da temporada."
                NegotiationStatus.COUNTER -> "${driver.name} fez uma contraproposta. Você pode tentar novamente dentro das 3 rodadas."
                NegotiationStatus.REJECTED -> "${driver.name} recusou a proposta neste momento."
                else -> "Proposta registrada para ${driver.name}."
            }
        }.onFailure { marketMessage = it.message ?: "Não foi possível negociar agora." }
    }

    fun makeMarketInterest(driverId: Int, replacementDriverId: Int?) {
        makeMarketProposal(driverId, replacementDriverId, 1, marketEngine.salaryFor(driverId), DriverTeamRole.EQUAL)
    }

    fun renewMarketDriver(driverId: Int, years: Int, salary: Long, role: DriverTeamRole) {
        val driver = WorldDatabase.allDrivers.first { it.id == driverId }
        runCatching {
            managerState = managerState.copy(driverMarket = marketEngine.renew(managerState.driverMarket, driverId, team.id, years, salary, role, store.season, currentWeek))
            store.saveDriverMarket(managerState.driverMarket)
            marketMessage = "Renovação de ${driver.name} preparada para ${store.season + 1}. O contrato atual permanece válido até o fim desta temporada."
        }.onFailure { marketMessage = it.message ?: "Não foi possível renovar o piloto." }
    }

    fun acceptIncomingMarketOffer(offer: com.f1teammanager.core.manager.DriverOffer) {
        runCatching {
            managerState = managerState.copy(driverMarket = marketEngine.acceptIncomingOffer(managerState.driverMarket, offer, store.season, currentWeek))
            store.saveDriverMarket(managerState.driverMarket)
            marketMessage = "Oferta aceita. ${WorldDatabase.allDrivers.firstOrNull { it.id == offer.driverId }?.name ?: "Piloto"} irá para ${WorldDatabase.teams.firstOrNull { it.id == offer.toTeamId }?.name ?: "a nova equipe"} em ${offer.seasonTarget}."
        }.onFailure { marketMessage = it.message ?: "Não foi possível aceitar a proposta." }
    }

    fun rejectIncomingMarketOffer(offer: com.f1teammanager.core.manager.DriverOffer) {
        runCatching {
            managerState = managerState.copy(driverMarket = marketEngine.rejectIncomingOffer(managerState.driverMarket, offer, store.season, currentWeek))
            store.saveDriverMarket(managerState.driverMarket)
            marketMessage = "Proposta recusada."
        }.onFailure { marketMessage = it.message ?: "Não foi possível recusar a proposta." }
    }

    fun makeMarketCounter(previous: com.f1teammanager.core.manager.DriverOffer, replacementDriverId: Int?, years: Int, salary: Long, role: DriverTeamRole) {
        val driver = WorldDatabase.allDrivers.first { it.id == previous.driverId }
        runCatching {
            val (next, offer) = marketEngine.counterOffer(managerState.driverMarket, previous, store.season, currentWeek, salary, years, role, replacementDriverId)
            managerState = managerState.copy(driverMarket=next)
            store.saveDriverMarket(managerState.driverMarket); store.saveFinance(teamId, managerState.finance)
            marketMessage = when(offer.status) {
                NegotiationStatus.ACCEPTED -> "${driver.name} aceitou a contraproposta. Pré-contrato para ${store.season+1} assinado."
                NegotiationStatus.COUNTER -> "${driver.name} apresentou uma nova contraproposta. Rodada ${offer.round}/3."
                NegotiationStatus.REJECTED -> "${driver.name} recusou a proposta após a rodada ${offer.round}/3."
                else -> "Negociação atualizada."
            }
        }.onFailure { marketMessage = it.message ?: "Não foi possível continuar a negociação." }
    }

    fun runScouting(driverId:Int) {
        runCatching {
            val (next, report)=marketEngine.scout(managerState.driverMarket,driverId,team.id,currentWeek,store.season)
            managerState=managerState.copy(driverMarket=next,finance=managerState.finance.transact(-report.cost,"Scouting de piloto ${driverId}"))
            store.saveDriverMarket(managerState.driverMarket); store.saveFinance(teamId,managerState.finance)
            marketMessage="Scouting concluído: salário ${formatMoney(report.expectedSalary)} • valor ${formatMoney(report.marketValue)} • interesse ${report.interest}/100."
        }.onFailure { marketMessage=it.message ?: "Não foi possível realizar o scouting." }
    }

    fun signSponsor(sponsor:SponsorContract) {
        runCatching { managerState=ManagerMarketEngine().signSponsor(managerState,sponsor,sponsor.slot); store.saveFinance(teamId,managerState.finance); store.saveSponsors(teamId,managerState.sponsors); sponsorMessage="Contrato ${sponsor.name} aceito por ${sponsor.races} ${if(sponsor.races==1) "corrida" else "corridas"}." }
            .onFailure { sponsorMessage=it.message ?: "Não foi possível aceitar o contrato." }
    }

    fun selectTeam(id: Int) { store.startNewCareer(id); marketMessage = ""; calendarMessage = ""; managerState=initialManagerState(id,store); teamId = id; roundIndex = 0; currentWeek = store.currentWeek; hasCareer = true; screen = Screen.HOME; nav = Nav.HOME }

    MaterialTheme(colorScheme = darkColorScheme(background = Bg, surface = Panel, primary = Red, onPrimary = Color.White, onSurface = Color.White)) {
        Surface(Modifier.fillMaxSize(), color = Bg) {
            when (screen) {
                Screen.SELECT_TEAM -> TeamSelect(::selectTeam)
                Screen.HOME -> AppScaffold("${team.name.uppercase()} • ${store.season}", nav, { nav = it; screen = when(it){Nav.HOME->Screen.HOME;Nav.TEAM->Screen.TEAM;Nav.CAR->Screen.CAR;Nav.CALENDAR->Screen.CALENDAR;Nav.STANDINGS->Screen.STANDINGS} }, onMore={ screen=Screen.MANAGEMENT }) { Home(team.name, CarCatalog.forTeam(team.id), drivers, round, currentWeek, store, managerState, snapshot?.phase == "RACE" && snapshot?.completed == false, onStart=::startWeekend, onDrivers={screen=Screen.DRIVERS}, onWeekend={screen=Screen.WEEKEND}, onMarket={screen=Screen.MARKET}, onFinance={screen=Screen.FINANCE}, onStandings={screen=Screen.STANDINGS}, onNews={screen=Screen.NEWS}, onCar={nav=Nav.CAR;screen=Screen.CAR}, onSkipWeek=::skipOneWeek, onStartNextSeason=::startNextSeason, onJumpNextRace=::jumpToNextRace) }
                Screen.TEAM -> AppScaffold("EQUIPE", nav, { nav=it; screen=when(it){Nav.HOME->Screen.HOME;Nav.TEAM->Screen.TEAM;Nav.CAR->Screen.CAR;Nav.CALENDAR->Screen.CALENDAR;Nav.STANDINGS->Screen.STANDINGS} }, onMore={screen=Screen.MANAGEMENT}) { Team(team.name, team.engine, team.reliability, drivers, onDrivers={screen=Screen.DRIVERS}, onMarket={screen=Screen.MARKET}) }
                Screen.DRIVERS -> DetailScaffold("PILOTOS", {screen=Screen.TEAM}) { Drivers(drivers) }
                Screen.CAR -> AppScaffold("CARRO / P&D", nav, { nav=it; screen=when(it){Nav.HOME->Screen.HOME;Nav.TEAM->Screen.TEAM;Nav.CAR->Screen.CAR;Nav.CALENDAR->Screen.CALENDAR;Nav.STANDINGS->Screen.STANDINGS} }, onMore={screen=Screen.MANAGEMENT}) { Car(CarCatalog.forTeam(team.id), managerState, currentWeek, carMessage, ::startDevelopment, ::investNextSeason, ::setNextSeasonFocus) }
                Screen.CALENDAR -> AppScaffold("CALENDÁRIO", nav, { nav=it; screen=when(it){Nav.HOME->Screen.HOME;Nav.TEAM->Screen.TEAM;Nav.CAR->Screen.CAR;Nav.CALENDAR->Screen.CALENDAR;Nav.STANDINGS->Screen.STANDINGS} }, onMore={screen=Screen.MANAGEMENT}) { Calendar(roundIndex, store.roundIndex, currentWeek, store.season, calendarMessage, ::openHistory, { store.raceHistory(it) != null }, ::skipOneWeek, ::jumpToNextRace) }
                Screen.STANDINGS -> AppScaffold("CAMPEONATO", nav, { nav=it; screen=when(it){Nav.HOME->Screen.HOME;Nav.TEAM->Screen.TEAM;Nav.CAR->Screen.CAR;Nav.CALENDAR->Screen.CALENDAR;Nav.STANDINGS->Screen.STANDINGS} }, onMore={screen=Screen.MANAGEMENT}) { Standings(team.id, store) }
                Screen.FINANCE -> DetailScaffold("FINANÇAS", {screen=Screen.HOME}) { Finance(store, team.id, managerState, sponsorMessage, ::signSponsor) }
                Screen.MARKET -> DetailScaffold("MERCADO DE PILOTOS", {screen=Screen.TEAM}) { DriverMarket(store, team.id, marketDriverId, managerState.driverMarket, marketMessage, { marketDriverId = it }, ::makeMarketInterest, ::makeMarketProposal, ::makeMarketCounter, ::renewMarketDriver, ::acceptIncomingMarketOffer, ::rejectIncomingMarketOffer, ::runScouting) }
                Screen.WEEKEND -> DetailScaffold("FIM DE SEMANA", {screen=Screen.HOME}) { Weekend(round, currentWeek, ::startWeekend) }
                Screen.QUALIFYING -> DetailScaffold("QUALIFICAÇÃO", { screen = Screen.HOME }) {
                    Qualifying(
                        snapshot!!,
                        onMode = { id, mode -> snapshot = engine.setStrategy(id, mode) },
                        onPlan = { id, plan -> snapshot = engine.setTyrePlan(id, plan) },
                        simulate = ::simulateQualifying,
                        start = ::startRace
                    )
                }
                Screen.RACE -> DetailScaffold("PIT WALL", { screen = Screen.CALENDAR; nav = Nav.CALENDAR }) { Race(snapshot!!, drivers, ::advanceRace, { id, mode -> snapshot = engine.setStrategy(id, mode) }, { id, tyre -> snapshot = engine.pitNow(id, tyre) }, { id, plan -> snapshot = engine.pitWithPlan(id, plan) }, { action -> snapshot = engine.choose(action) }) }
                Screen.RESULT -> DetailScaffold("RESULTADO", { returnToCalendarAfterRace() }) { Result(result!!, team.id, store, ::returnToCalendarAfterRace) }
                Screen.HISTORY -> DetailScaffold("CLASSIFICAÇÃO ARQUIVADA", { screen = Screen.CALENDAR }) { HistoryResult(historyRound, historyResult) }
                Screen.HISTORY_CENTER -> DetailScaffold("HISTÓRIA", { screen = Screen.HOME }) { HistoryScreen(store) }
                Screen.NEWS -> DetailScaffold("CENTRAL DE NOTÍCIAS", { screen = Screen.HOME }) { MarketNews(managerState.driverMarket, store.season) }
                Screen.HALL_OF_FAME -> DetailScaffold("HALL DA FAMA", { screen = Screen.HOME }) { HallOfFameScreen(store) }
                Screen.RECORDS -> DetailScaffold("RECORDES", { screen = Screen.HOME }) { RecordsScreen(store) }
                Screen.SEASON -> DetailScaffold("TEMPORADA", { screen = Screen.HOME }) { SeasonArchive(store) }
                Screen.MANAGEMENT -> DetailScaffold("GESTÃO", { screen = Screen.HOME }) { ManagementHub(snapshot?.phase == "RACE" && snapshot?.completed == false, onDrivers={screen=Screen.DRIVERS}, onMarket={screen=Screen.MARKET}, onFinance={screen=Screen.FINANCE}, onSeason={screen=Screen.SEASON}, onCar={screen=Screen.CAR}, onStandings={screen=Screen.STANDINGS}, onCalendar={screen=Screen.CALENDAR}, onWeekend={screen=Screen.WEEKEND}, onRace={screen=Screen.RACE}, onHistory={screen=Screen.HISTORY_CENTER}, onNews={screen=Screen.NEWS}, onHallOfFame={screen=Screen.HALL_OF_FAME}, onRecords={screen=Screen.RECORDS}) }
            }
        }
    }
}

@Composable private fun AppScaffold(title:String, nav:Nav, select:(Nav)->Unit, onMore:()->Unit, content:@Composable ColumnScope.()->Unit) {
    Column(Modifier.fillMaxSize().statusBarsPadding()) { TopBar(title, onMore); Column(Modifier.weight(1f)) { content() }; BottomNav(nav, select) }
}
@Composable private fun DetailScaffold(title:String, back:()->Unit, content:@Composable ColumnScope.()->Unit) { Column(Modifier.fillMaxSize().statusBarsPadding()) { BackTopBar(title, back); Column(Modifier.weight(1f)) { content() } } }
@Composable private fun BackTopBar(title:String, back:()->Unit) { Row(Modifier.fillMaxWidth().padding(horizontal=14.dp,vertical=10.dp),verticalAlignment=Alignment.CenterVertically){Text("‹",color=Color.White,fontSize=34.sp,modifier=Modifier.clickable{back()}.padding(horizontal=6.dp));Text(title,color=Color.White,fontWeight=FontWeight.Bold,maxLines=1,overflow=TextOverflow.Ellipsis,modifier=Modifier.weight(1f));Text("F1 MANAGER",color=Red,fontWeight=FontWeight.Black,fontSize=12.sp)}}
@Composable private fun TopBar(title:String, action:()->Unit) { Row(Modifier.fillMaxWidth().padding(horizontal=16.dp,vertical=12.dp), verticalAlignment=Alignment.CenterVertically, horizontalArrangement=Arrangement.SpaceBetween) { Text("F1 MANAGER",color=Red,fontWeight=FontWeight.Black,letterSpacing=1.sp); Text(title,color=Color.White,fontWeight=FontWeight.Bold,maxLines=1,overflow=TextOverflow.Ellipsis); Text("⋮",color=Color.White,fontSize=25.sp,modifier=Modifier.clickable{action()}) } }
@Composable private fun BottomNav(selected:Nav, select:(Nav)->Unit) { Row(Modifier.fillMaxWidth().navigationBarsPadding().background(Color(0xFF101216)).padding(6.dp), horizontalArrangement=Arrangement.SpaceEvenly) { listOf(Nav.HOME to "⌂",Nav.TEAM to "♟",Nav.CAR to "▰",Nav.CALENDAR to "▦",Nav.STANDINGS to "≡").forEach{(n,l)-> Column(horizontalAlignment=Alignment.CenterHorizontally,modifier=Modifier.weight(1f).clickable{select(n)}.padding(5.dp)){Text(l,color=if(selected==n)Red else Muted,fontSize=20.sp);Text(n.name,color=if(selected==n)Color.White else Muted,fontSize=9.sp,fontWeight=FontWeight.Bold)}} } }

@Composable
private fun Home(
    team: String,
    car: com.f1teammanager.core.season.CarSpec,
    drivers: List<com.f1teammanager.core.season.DriverDefinition>,
    round: RoundDefinition,
    currentWeek: Int,
    store: CareerPreferences,
    managerState: TeamManagerState,
    raceInProgress: Boolean,
    onStart: () -> Unit,
    onDrivers: () -> Unit,
    onWeekend: () -> Unit,
    onMarket: () -> Unit,
    onFinance: () -> Unit,
    onStandings: () -> Unit,
    onNews: () -> Unit,
    onCar: () -> Unit,
    onSkipWeek: () -> Unit,
    onJumpNextRace: () -> Unit,
    onStartNextSeason: () -> Unit
) {
    val teamId = WorldDatabase.teams.first { it.name == team }.id
    val teamPoints = store.constructorPoints()[teamId] ?: 0
    val atRaceWeek = currentWeek == round.weekOfSeason

    LazyColumn(
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        if (store.isSeasonEnded()) {
            item {
                Card(
                    Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(Panel),
                    border = BorderStroke(1.dp, Red)
                ) {
                    Column(
                        Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(7.dp)
                    ) {
                        Text(
                            "TEMPORADA ${store.season} ENCERRADA",
                            color = Red,
                            fontWeight = FontWeight.Black,
                            fontSize = 15.sp
                        )
                        Text(
                            "As 30 corridas foram concluídas e o histórico foi arquivado.",
                            color = Color.White,
                            fontSize = 10.sp
                        )
                        Button(
                            onClick = onStartNextSeason,
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Red,
                                contentColor = Color.White
                            )
                        ) {
                            Text("IR PARA NOVA TEMPORADA", fontWeight = FontWeight.Black)
                        }
                    }
                }
            }
        }

        item { TeamHeroCard(team, car.model) }

        item {
            SectionTitle("SITUAÇÃO DO CAMPEONATO")
            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(Panel)) {
                Row(
                    Modifier.fillMaxWidth().padding(8.dp),
                    horizontalArrangement = Arrangement.spacedBy(7.dp)
                ) {
                    StatCard("CONSTRUTORES", "P${constructorPosition(teamId, store)}", "$teamPoints PTS", Modifier.weight(1f))
                    StatCard("PILOTO 1", drivers.firstOrNull()?.name ?: "—", "titular", Modifier.weight(1f))
                    StatCard("ORÇAMENTO", formatMoney(managerState.finance.budget), "disponível", Modifier.weight(1f))
                }
            }
        }

        item {
            SectionTitle(if (store.isSeasonEnded()) "TEMPORADA ENCERRADA" else "PRÓXIMA CORRIDA")
            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(Panel)) {
                Column(Modifier.padding(13.dp)) {
                    if (store.isSeasonEnded()) {
                        Text("${store.season} concluída", color = Red, fontSize = 21.sp, fontWeight = FontWeight.Black)
                        Text(
                            "O calendário de ${store.season} foi encerrado e o histórico está arquivado.",
                            color = Muted,
                            fontSize = 10.sp,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    } else {
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("ROUND ${round.round}", color = Red, fontWeight = FontWeight.Black)
                            Text("SEMANA ${round.weekOfSeason}", color = Color.White, fontWeight = FontWeight.Black, fontSize = 11.sp)
                        }
                        RaceImage(round, Modifier.fillMaxWidth().aspectRatio(1f).padding(top = 8.dp))
                        Text(round.grandPrix, color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(top = 7.dp))
                        Text(round.circuit, color = Muted, fontSize = 12.sp)
                        Row(
                            Modifier.fillMaxWidth().padding(top = 9.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("${round.laps} VOLTAS", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Text(seasonDateLabel(round, store.season), color = Muted, fontSize = 10.sp)
                        }
                        Button(
                            onClick = onStart,
                            enabled = raceInProgress || atRaceWeek,
                            modifier = Modifier.fillMaxWidth().padding(top = 9.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Red,
                                contentColor = Color.White,
                                disabledContainerColor = Panel2,
                                disabledContentColor = Muted
                            )
                        ) {
                            Text(
                                if (raceInProgress) "RETOMAR PIT WALL"
                                else if (atRaceWeek) "ABRIR FIM DE SEMANA"
                                else "IR PARA CALENDÁRIO",
                                fontWeight = FontWeight.Black
                            )
                        }
                    }
                }
            }
        }

        item {
            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(Panel)) {
                Column(Modifier.padding(12.dp)) {
                    Text("CALENDÁRIO", color = Red, fontWeight = FontWeight.Black, fontSize = 11.sp)
                    Text(
                        "O P&D avança com as semanas do calendário, inclusive semanas de GP. Nunca é possível ultrapassar um GP sem simular a corrida.",
                        color = Muted,
                        fontSize = 9.sp,
                        modifier = Modifier.padding(top = 3.dp)
                    )
                    Row(
                        Modifier.fillMaxWidth().padding(top = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(7.dp)
                    ) {
                        Button(
                            onClick = onSkipWeek,
                            enabled = currentWeek < 56 && !atRaceWeek,
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Panel2,
                                contentColor = Color.White,
                                disabledContainerColor = Color(0xFF101116),
                                disabledContentColor = Muted
                            ),
                            contentPadding = PaddingValues(vertical = 8.dp)
                        ) { Text("PULAR 1 SEMANA", fontSize = 8.sp, fontWeight = FontWeight.Black) }

                        Button(
                            onClick = onJumpNextRace,
                            enabled = currentWeek < round.weekOfSeason,
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Red,
                                contentColor = Color.White,
                                disabledContainerColor = Color(0xFF3A0D0D),
                                disabledContentColor = Muted
                            ),
                            contentPadding = PaddingValues(vertical = 8.dp)
                        ) { Text("PULAR ATÉ PRÓXIMO GP", fontSize = 8.sp, fontWeight = FontWeight.Black) }
                    }
                }
            }
        }

        item {
            SectionTitle("ACESSO RÁPIDO")
            val shortcuts = listOf(
                "FIM DE SEMANA" to onWeekend,
                "PILOTOS" to onDrivers,
                "MERCADO" to onMarket,
        "CENTRAL DE NOTÍCIAS" to onNews,
                "FINANÇAS" to onFinance,
                "CAMPEONATO" to onStandings,
                "CARRO / P&D" to onCar
            )
            Column(
                verticalArrangement = Arrangement.spacedBy(7.dp),
                modifier = Modifier.padding(top = 3.dp)
            ) {
                shortcuts.chunked(3).forEach { row ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        row.forEach { (label, action) ->
                            Button(
                                onClick = action,
                                modifier = Modifier.weight(1f).height(48.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Panel2, contentColor = Color.White),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 4.dp)
                            ) {
                                Text(label, fontSize = 8.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                            }
                        }
                    }
                }
            }
        }

        item {
            SectionTitle("EQUIPE")
            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(Panel)) {
                Column(Modifier.padding(12.dp)) {
                    Text("PILOTOS TITULARES", color = Red, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    Row(
                        Modifier.fillMaxWidth().padding(top = 7.dp),
                        horizontalArrangement = Arrangement.spacedBy(7.dp)
                    ) {
                        drivers.take(2).forEachIndexed { index, d ->
                            Column(
                                Modifier.weight(1f).background(Panel2, RoundedCornerShape(8.dp)).padding(10.dp)
                            ) {
                                Text(d.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text("#${index + 1} • Titular", color = Muted, fontSize = 9.sp)
                                Text("P${driverChampionshipPosition(d.id, store)}", color = Color.White, fontWeight = FontWeight.Black, fontSize = 15.sp, modifier = Modifier.padding(top = 4.dp))
                            }
                        }
                    }
                    Button(
                        onClick = onDrivers,
                        modifier = Modifier.fillMaxWidth().padding(top = 7.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Panel2, contentColor = Color.White)
                    ) { Text("VER PERFIL COMPLETO →", fontWeight = FontWeight.Black, fontSize = 9.sp) }
                }
            }
        }
    }
}

@Composable private fun TeamHeroCard(team:String,model:String){Box(Modifier.fillMaxWidth().height(138.dp).clip(RoundedCornerShape(12.dp)).background(Panel).border(1.dp,Red,RoundedCornerShape(12.dp))){Row(Modifier.fillMaxSize().padding(16.dp),verticalAlignment=Alignment.CenterVertically){TeamLogo(team,WorldDatabase.teams.firstOrNull{it.name.equals(team,ignoreCase=true)}?.id ?: 0,Modifier.size(86.dp));Spacer(Modifier.width(14.dp));Column(Modifier.weight(1f)){Text(team.uppercase(),color=Color.White,fontSize=23.sp,fontWeight=FontWeight.Black);Text(model,color=Red,fontSize=17.sp,fontWeight=FontWeight.Black);Text("MODELO ESPECÍFICO DA EQUIPE",color=Muted,fontSize=10.sp,modifier=Modifier.padding(top=4.dp))}}}}

@Composable private fun Team(name:String,engine:Int,reliability:Int,drivers:List<com.f1teammanager.core.season.DriverDefinition>,onDrivers:()->Unit,onMarket:()->Unit){LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){item{HeaderBlock(name,"GESTÃO DA EQUIPE");Row(Modifier.fillMaxWidth().background(Panel,RoundedCornerShape(10.dp)).padding(12.dp),verticalAlignment=Alignment.CenterVertically){TeamLogo(name,WorldDatabase.teams.firstOrNull{it.name.equals(name,ignoreCase=true)}?.id ?: 0,Modifier.size(120.dp));Spacer(Modifier.width(14.dp));Column{Text(name.uppercase(),color=Color.White,fontWeight=FontWeight.Black,fontSize=20.sp);Text("ESCUDO DA EQUIPE",color=Muted,fontSize=9.sp)}}};item{MetricPanel("FORNECEDOR / MOTOR","Engine",engine,"Confiabilidade",reliability)};item{SectionTitle("PILOTOS TITULARES")};items(drivers){DriverMini(it)};item{Button(onClick=onDrivers,modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=Red,contentColor=Color.White)){Text("ABRIR PERFIS")}};item{SectionTitle("GESTÃO")};item{Row(Modifier.fillMaxWidth().background(Panel,RoundedCornerShape(8.dp)).clickable{onMarket()}.padding(14.dp),horizontalArrangement=Arrangement.SpaceBetween){Column{Text("MERCADO DE PILOTOS",color=Color.White,fontWeight=FontWeight.Bold);Text("Contratos, salários e disponibilidade",color=Muted,fontSize=11.sp)};Text("›",color=Red,fontSize=24.sp)}};item{SectionTitle("INSTALAÇÕES")};item{Facility("FÁBRICA",72)};item{Facility("CENTRO DE P&D",68)};item{Facility("TÚNEL DE VENTO",61)};item{Facility("SIMULADOR",75)}}}
@Composable private fun Drivers(ds:List<com.f1teammanager.core.season.DriverDefinition>){LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){item{HeaderBlock("PILOTOS","PERFIS • CLASSE • EVOLUÇÃO DURANTE A TEMPORADA")};items(ds){d->val overall=(d.speed+d.qualifying+d.overtaking+d.defense+d.consistency+d.wet+d.tyre)/7;Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(Panel)){Column(Modifier.padding(14.dp)){Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Column{Text(d.name,color=Color.White,fontWeight=FontWeight.Black,fontSize=18.sp);Text("${d.driverClass} • ${d.evolution}",color=Red,fontWeight=FontWeight.Bold,fontSize=10.sp)};Text("$overall",color=Red,fontSize=20.sp,fontWeight=FontWeight.Black)};Text("Velocidade ${d.speed} • Classificação ${d.qualifying}",color=Muted);Text("Ultrapassagem ${d.overtaking} • Defesa ${d.defense} • Consistência ${d.consistency}",color=Muted);Text("Chuva ${d.wet} • Pneus ${d.tyre}",color=Muted)}}}}}
@Composable private fun DriverMini(d:com.f1teammanager.core.season.DriverDefinition){Row(Modifier.fillMaxWidth().background(Panel,RoundedCornerShape(8.dp)).padding(13.dp),horizontalArrangement=Arrangement.SpaceBetween){Text(d.name,color=Color.White,fontWeight=FontWeight.Bold);Text("CHUVA ${d.wet}",color=Red,fontWeight=FontWeight.Black,fontSize=10.sp)}}
@Composable private fun Facility(name:String,v:Int){Column(Modifier.fillMaxWidth().background(Panel,RoundedCornerShape(8.dp)).padding(12.dp)){Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text(name,color=Color.White,fontWeight=FontWeight.Bold);Text("Nível ${v/10}",color=Muted)};LinearProgressIndicator(progress={v/100f},modifier=Modifier.fillMaxWidth().padding(top=8.dp),color=Red,trackColor=Line)}}
@Composable private fun MetricPanel(title:String,a:String,av:Int,b:String,bv:Int){Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(Panel)){Column(Modifier.padding(14.dp)){Text(title,color=Red,fontWeight=FontWeight.Bold);MetricLine(a,av);MetricLine(b,bv)}}}
@Composable private fun MetricLine(l:String,v:Int){Column(Modifier.padding(top=9.dp)){Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text(l,color=Muted);Text(v.toString(),color=Color.White,fontWeight=FontWeight.Bold)};LinearProgressIndicator(progress={v/100f},modifier=Modifier.fillMaxWidth().padding(top=4.dp),color=Red,trackColor=Line)}}
@Composable private fun Car(
    c:com.f1teammanager.core.season.CarSpec,
    state:TeamManagerState,
    currentWeek:Int,
    message:String,
    develop:(CarComponent,DevelopmentIntensity)->Unit,
    investNextSeason:(Long)->Unit,
    setNextSeasonFocus:(CarDevelopmentFocus)->Unit
){
    val car=state.car; val p=car.activeProject
    var selectedComponent by remember { mutableStateOf<CarComponent?>(null) }
    val development=remember { CarDevelopmentEngine() }
    val cap=development.nextSeasonInvestmentCap(car)
    val remaining=cap-car.nextSeasonInvestment
    LazyColumn(contentPadding=PaddingValues(12.dp),verticalArrangement=Arrangement.spacedBy(7.dp)){
        item{HeaderBlock(c.model,"CARRO ${state.season} • 6 COMPONENTES")}
        item{Text("ORÇAMENTO ${formatMoney(state.finance.budget)}",color=Green,fontWeight=FontWeight.Black);Text("FORÇA DO CARRO ${((car.engine+car.chassis+car.frontWing+car.rearWing+car.brakes+car.electricPowerUnit)/6)}",color=Red,fontWeight=FontWeight.Black);Text("EVOLUÇÃO ${car.seasonDevelopmentGain}/140 PONTOS NESTA TEMPORADA",color=Muted,fontSize=9.sp,fontWeight=FontWeight.Bold);Text("SEMANAS TRANSCORRIDAS: ${(currentWeek-1).coerceAtLeast(0)} • SEMANA ATUAL: $currentWeek/56",color=Muted,fontSize=9.sp,fontWeight=FontWeight.Bold)}
        item{Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(Panel)){Column(Modifier.padding(12.dp)){Text("CARRO ${state.season}",color=Red,fontWeight=FontWeight.Black,fontSize=12.sp);Text("Desenvolva o carro atual sem perder o foco no próximo.",color=Muted,fontSize=9.sp,modifier=Modifier.padding(top=2.dp))}}}
        item{CarComponentRow("UNIDADE DE POTÊNCIA",car.engine,CarComponent.ENGINE,p,development.options(state,CarComponent.ENGINE),{selectedComponent=CarComponent.ENGINE})}
        item{CarComponentRow("CHASSI",car.chassis,CarComponent.CHASSIS,p,development.options(state,CarComponent.CHASSIS),{selectedComponent=CarComponent.CHASSIS})}
        item{CarComponentRow("ASA DIANTEIRA",car.frontWing,CarComponent.FRONT_WING,p,development.options(state,CarComponent.FRONT_WING),{selectedComponent=CarComponent.FRONT_WING})}
        item{CarComponentRow("ASA TRASEIRA",car.rearWing,CarComponent.REAR_WING,p,development.options(state,CarComponent.REAR_WING),{selectedComponent=CarComponent.REAR_WING})}
        item{CarComponentRow("FREIOS",car.brakes,CarComponent.BRAKES,p,development.options(state,CarComponent.BRAKES),{selectedComponent=CarComponent.BRAKES})}
        item{CarComponentRow("UNIDADE DE POTÊNCIA ELÉTRICA",car.electricPowerUnit,CarComponent.ELECTRIC_POWER_UNIT,p,development.options(state,CarComponent.ELECTRIC_POWER_UNIT),{selectedComponent=CarComponent.ELECTRIC_POWER_UNIT})}
        item{Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(Panel)){Column(Modifier.padding(12.dp)){Text("CARRO ${state.season+1} • INVESTIMENTO ANTECIPADO",color=Red,fontWeight=FontWeight.Black,fontSize=12.sp);Text("Investido: ${formatMoney(car.nextSeasonInvestment)} / ${formatMoney(cap)}",color=Color.White,fontWeight=FontWeight.Bold);Text("O valor investido agora vira vantagem de partida no próximo carro. O limite impede que uma equipe compre uma vantagem infinita.",color=Muted,fontSize=9.sp,modifier=Modifier.padding(top=3.dp));Row(Modifier.fillMaxWidth().padding(top=8.dp),horizontalArrangement=Arrangement.spacedBy(5.dp)){listOf(5L,10L,20L).forEach{m->val amount=m*1_000_000L;Button(onClick={investNextSeason(amount)},enabled=remaining>=amount&&state.finance.budget>=amount,modifier=Modifier.weight(1f),colors=ButtonDefaults.buttonColors(containerColor=Panel2,contentColor=Color.White)){Text("+€${m}M",fontSize=8.sp,fontWeight=FontWeight.Black)}}};Text("FOCO DO CARRO ${state.season+1}",color=Muted,fontSize=8.sp,fontWeight=FontWeight.Black,modifier=Modifier.padding(top=8.dp));Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(4.dp)){listOf(CarDevelopmentFocus.BALANCED to "EQUILÍBRIO",CarDevelopmentFocus.POWER to "POTÊNCIA",CarDevelopmentFocus.AERODYNAMICS to "AERO",CarDevelopmentFocus.CORNERING to "CURVAS").forEach{(focus,label)->Button(onClick={setNextSeasonFocus(focus)},modifier=Modifier.weight(1f),colors=ButtonDefaults.buttonColors(containerColor=if(car.nextSeasonFocus==focus) Red else Panel2,contentColor=Color.White),contentPadding=PaddingValues(horizontal=3.dp,vertical=5.dp)){Text(label,fontSize=7.sp,fontWeight=FontWeight.Black)}}}}}}
        p?.let{item{Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(Panel)){Column(Modifier.padding(10.dp)){Text("P&D EM ANDAMENTO",color=Red,fontWeight=FontWeight.Black,fontSize=10.sp);Text(componentLabel(it.component),color=Color.White,fontWeight=FontWeight.Bold);Text("${it.remainingWeeks}/${it.totalWeeks} semana(s) restantes • ganho +${it.expectedGain}",color=Muted,fontSize=10.sp)}}}}
        if(message.isNotBlank()) item{Text(message,color=Color.White,fontSize=10.sp)}
        item{Text("As melhorias entram no motor da corrida e usam semanas do calendário. O investimento do próximo carro é reservado agora e aplicado na virada da temporada.",color=Muted,fontSize=9.sp)}
    }
    selectedComponent?.let { component ->
        val options=development.options(state,component)
        AlertDialog(onDismissRequest={selectedComponent=null},title={Text("DESENVOLVER ${componentLabel(component).uppercase()}")},text={Column(verticalArrangement=Arrangement.spacedBy(6.dp)){Text("Escolha quanto acelerar o projeto. Quanto maior o investimento, maior o ganho e o tempo.",color=Muted,fontSize=11.sp);options.forEach{option->Button(onClick={develop(component,option.intensity);selectedComponent=null},enabled=state.finance.budget>=option.cost&&state.car.activeProject==null,modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=if(option.intensity==DevelopmentIntensity.STANDARD) Red else Panel2,contentColor=Color.White)){Column(Modifier.fillMaxWidth()){Text("${optionLabel(option.intensity)} • ${option.weeks} semana(s)",fontWeight=FontWeight.Black,fontSize=11.sp);Text("${formatMoney(option.cost)} • ganho aleatório +${option.minGain} a +${option.maxGain} (maior chance no máximo)",fontSize=9.sp)}}}}},confirmButton={TextButton(onClick={selectedComponent=null}){Text("CANCELAR")}})
    }
}

@Composable private fun CarComponentRow(title:String,level:Int,component:CarComponent,project:com.f1teammanager.core.manager.DevelopmentProject?,options:List<CarDevelopmentEngine.DevelopmentOption>,open:()->Unit){
    val default=options.firstOrNull { it.intensity==DevelopmentIntensity.STANDARD }
    Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(Panel)){Row(Modifier.fillMaxWidth().padding(9.dp),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(title,color=Color.White,fontWeight=FontWeight.Bold,fontSize=11.sp);Text("NÍVEL $level • ${default?.weeks ?: 2} semanas padrão • ${default?.cost?.let(::formatMoney) ?: formatMoney(0)} • +${default?.minGain ?: 0} a +${default?.maxGain ?: 0}",color=Muted,fontSize=9.sp)};Button(onClick=open,enabled=project==null,colors=ButtonDefaults.buttonColors(containerColor=Red,contentColor=Color.White,disabledContainerColor=Panel2),contentPadding=PaddingValues(horizontal=9.dp,vertical=3.dp)){Text(if(project==null)"DESENVOLVER" else "P&D OCUPADO",fontSize=8.sp)}}}
}

private fun optionLabel(i:DevelopmentIntensity)=when(i){DevelopmentIntensity.QUICK->"RÁPIDO";DevelopmentIntensity.STANDARD->"PADRÃO";DevelopmentIntensity.ADVANCED->"AVANÇADO";DevelopmentIntensity.AGGRESSIVE->"AGRESSIVO"}
private fun seasonDateLabel(round: RoundDefinition, season: Int): String =
    round.dateLabel.replace(Regex("/\\d{4}$"), "/$season")

@Composable
private fun Calendar(
    idx:Int,
    current:Int,
    currentWeek:Int,
    season:Int,
    message:String,
    openHistory:(Int)->Unit,
    hasHistory:(Int)->Boolean,
    skipOneWeek:()->Unit,
    jumpToNextRace:()->Unit
){
    val raceByWeek=WorldDatabase.rounds.associateBy { it.weekOfSeason }
    LazyColumn(contentPadding=PaddingValues(12.dp),verticalArrangement=Arrangement.spacedBy(5.dp)){
        item{
            HeaderBlock("CALENDÁRIO $season","30 GRAND PRIX • 56 SEMANAS • 26 SEMANAS LIVRES")
            Spacer(Modifier.height(6.dp))
            Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(Panel)){
                Column(Modifier.padding(12.dp)){
                    Text("SEMANA ATUAL: $currentWeek/56",color=Red,fontWeight=FontWeight.Black,fontSize=16.sp)
                    val next=WorldDatabase.rounds.getOrNull(idx) ?: WorldDatabase.rounds.lastOrNull()
                    Text(if(next!=null) "Próximo GP: Round ${next.round} • Semana ${next.weekOfSeason} • ${next.grandPrix}" else "Temporada encerrada",color=Color.White,fontWeight=FontWeight.Bold,fontSize=10.sp)
                    Text("As semanas sem GP são semanas livres de desenvolvimento do carro.",color=Muted,fontSize=9.sp,modifier=Modifier.padding(top=3.dp))
                    Row(Modifier.fillMaxWidth().padding(top=8.dp),horizontalArrangement=Arrangement.spacedBy(6.dp)){
                        Button(onClick=skipOneWeek,modifier=Modifier.weight(1f),enabled=currentWeek<56,colors=ButtonDefaults.buttonColors(containerColor=Panel2,contentColor=Color.White)){Text("PULAR 1 SEMANA",fontSize=9.sp,fontWeight=FontWeight.Black)}
                        Button(onClick=jumpToNextRace,modifier=Modifier.weight(1f),colors=ButtonDefaults.buttonColors(containerColor=Red,contentColor=Color.White)){Text("PULAR ATÉ PRÓXIMO GP",fontSize=9.sp,fontWeight=FontWeight.Black)}
                    }
                    if(message.isNotBlank()) Text(message,color=Color.White,fontSize=9.sp,modifier=Modifier.padding(top=7.dp))
                }
            }
        }
        items((1..56).toList()){week->
            val r=raceByWeek[week]
            val isCurrent=week==currentWeek
            Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(if(isCurrent) Color(0xFF2A1010) else Panel)){
                Row(Modifier.fillMaxWidth().padding(9.dp),verticalAlignment=Alignment.CenterVertically){
                    Column(Modifier.weight(1f)){
                        Text("SEMANA $week/56${if(isCurrent) " • AGORA" else ""}",color=if(isCurrent) Red else Muted,fontSize=9.sp,fontWeight=FontWeight.Black)
                        if(r!=null){
                            Row(Modifier.fillMaxWidth().padding(top=5.dp),verticalAlignment=Alignment.CenterVertically){
                                RaceImage(r,Modifier.size(92.dp))
                                Spacer(Modifier.width(9.dp))
                                Column(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(3.dp)){
                                    Text("ROUND ${r.round} • ${seasonDateLabel(r, season)}",color=if(isCurrent) Color.White else Muted,fontSize=8.sp,fontWeight=FontWeight.Bold)
                                    Text(r.grandPrix,color=Color.White,fontWeight=FontWeight.Black,fontSize=12.sp,maxLines=2,overflow=TextOverflow.Ellipsis)
                                    Text(r.circuit,color=Muted,fontSize=10.sp,maxLines=1,overflow=TextOverflow.Ellipsis)
                                    Text("${r.laps} VOLTAS",color=Color.White,fontSize=8.sp,fontWeight=FontWeight.Bold)
                                    if(hasHistory(r.round)){Text("VER RESULTADO",color=Red,fontSize=8.sp,modifier=Modifier.clickable{openHistory(r.round)})}
                                }
                            }
                        } else {
                            Text("SEMANA LIVRE • P&D / DESENVOLVIMENTO",color=Color.White,fontWeight=FontWeight.Bold,fontSize=10.sp)
                            Text("Use esta semana para avançar projetos do carro.",color=Muted,fontSize=9.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable private fun RaceHero(r:RoundDefinition,start:()->Unit,currentWeek:Int){
    Card(Modifier.fillMaxWidth(), colors=CardDefaults.cardColors(Panel)){
        Column(Modifier.padding(14.dp)){
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){
                Text("ROUND ${r.round}",color=Red,fontWeight=FontWeight.Black,fontSize=11.sp)
                Text("SEMANA ${r.weekOfSeason}",color=Muted,fontWeight=FontWeight.Bold,fontSize=10.sp)
            }
            Text(r.grandPrix,color=Color.White,fontSize=21.sp,fontWeight=FontWeight.Black,modifier=Modifier.padding(top=4.dp))
            Text(r.circuit,color=Muted,fontSize=11.sp)
            Text(if(currentWeek==r.weekOfSeason) "FIM DE SEMANA DISPONÍVEL" else "CORRIDA AGUARDANDO A SEMANA CORRETA",color=if(currentWeek==r.weekOfSeason) Green else Muted,fontSize=9.sp,fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=8.dp))
            Button(onClick=start,enabled=currentWeek==r.weekOfSeason,modifier=Modifier.fillMaxWidth().padding(top=8.dp),colors=ButtonDefaults.buttonColors(containerColor=Red,contentColor=Color.White,disabledContainerColor=Panel2,disabledContentColor=Muted)){Text("ABRIR FIM DE SEMANA",fontWeight=FontWeight.Black)}
        }
    }
}

@Composable private fun Weekend(r:RoundDefinition,currentWeek:Int,start:()->Unit){LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){item{HeaderBlock(r.grandPrix,"ROUND ${r.round} • ${r.circuit}")};item{RaceHero(r,start,currentWeek)};item{InfoPanel("QUALIFICAÇÃO","Define o grid de largada");InfoPanel("ESTRATÉGIA","Postura + pneu inicial");InfoPanel("CORRIDA","Decisões VSC, SC e bandeira vermelha")};item{Button(onClick=start,modifier=Modifier.fillMaxWidth()){Text("COMEÇAR QUALIFICAÇÃO")}}}}
@Composable private fun InfoPanel(a:String,b:String){Row(Modifier.fillMaxWidth().background(Panel,RoundedCornerShape(8.dp)).padding(14.dp),horizontalArrangement=Arrangement.SpaceBetween){Column{Text(a,color=Color.White,fontWeight=FontWeight.Bold);Text(b,color=Muted,fontSize=11.sp)};Text("›",color=Red,fontSize=24.sp)}}
@Composable
private fun Qualifying(
    s: CareerWeekendEngine.SessionSnapshot,
    onMode: (Int, DriverStrategyMode) -> Unit,
    onPlan: (Int, String) -> Unit,
    simulate: () -> Unit,
    start: () -> Unit
){
    var phase by remember { mutableIntStateOf(0) }
    val phases=s.grid?.phases.orEmpty()
    val selected=phases.getOrNull(phase)
    val q3Complete=s.grid?.phases?.getOrNull(2)?.entries?.size==20

    Column(Modifier.fillMaxSize().padding(12.dp)){
        Text("CLASSIFICAÇÃO",color=Color.White,fontSize=23.sp,fontWeight=FontWeight.Black)
        Text("Q1 80 → Q2 50 → Q3 20",color=Red,fontSize=10.sp,fontWeight=FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(5.dp)){
            listOf("Q1","Q2","Q3").forEachIndexed{i,label->
                Button(onClick={phase=i},modifier=Modifier.weight(1f),colors=ButtonDefaults.buttonColors(containerColor=if(phase==i)Red else Panel2,contentColor=Color.White),contentPadding=PaddingValues(vertical=4.dp)){
                    Text(label,fontWeight=FontWeight.Black)
                }
            }
        }
        selected?.let{Text("${it.name}: ${it.entries.size} pilotos • eliminados nesta fase: ${it.eliminatedDriverIds.size}",color=Muted,fontSize=9.sp,modifier=Modifier.padding(vertical=5.dp))}

        LazyColumn(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(2.dp)){
            items(selected?.entries.orEmpty()){e->
                val mine = e.driverId in s.plans.keys
                Row(Modifier.fillMaxWidth().background(if(mine) Color(0xFF2A1010) else Panel,RoundedCornerShape(4.dp)).padding(horizontal=8.dp,vertical=5.dp),horizontalArrangement=Arrangement.SpaceBetween){
                    Text("P${e.position}",color=if(mine) Red else Muted,fontWeight=FontWeight.Black,fontSize=10.sp)
                    Text(if(mine) "★ ${WorldDatabase.drivers.firstOrNull{it.id==e.driverId}?.name?:"Piloto ${e.driverId}"}" else (WorldDatabase.drivers.firstOrNull{it.id==e.driverId}?.name?:"Piloto ${e.driverId}"),color=if(mine) Red else Color.White,fontWeight=if(mine) FontWeight.Black else FontWeight.Normal,fontSize=10.sp,modifier=Modifier.weight(1f).padding(horizontal=8.dp))
                    Text(formatMs(e.lapTimeMs),color=if(mine) Color.White else Muted,fontSize=9.sp)
                }
            }

            if(q3Complete){
                item {
                    Text("PLANO DE CORRIDA",color=Red,fontWeight=FontWeight.Black,fontSize=11.sp,modifier=Modifier.padding(top=10.dp,bottom=4.dp))
                    Text("Defina a postura de cada piloto e o plano de pneus A, B ou C para a corrida.",color=Muted,fontSize=9.sp,modifier=Modifier.padding(bottom=5.dp))
                }

                items(s.plans.entries.toList()){ entry ->
                    val driverId=entry.key
                    val driverPlan=entry.value
                    val driverName=WorldDatabase.drivers.firstOrNull{it.id==driverId}?.name ?: "Piloto $driverId"
                    Card(Modifier.fillMaxWidth().padding(bottom=5.dp),colors=CardDefaults.cardColors(Panel)){
                        Column(Modifier.padding(8.dp)){
                            Text(driverName,color=Color.White,fontWeight=FontWeight.Black,fontSize=12.sp)
                            Text("POSTURA",color=Muted,fontSize=9.sp,fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=6.dp,bottom=3.dp))
                            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(4.dp)){
                                DriverStrategyMode.entries.forEach { m ->
                                    Button(onClick={onMode(driverId,m)},modifier=Modifier.weight(1f),colors=ButtonDefaults.buttonColors(containerColor=if(driverPlan.mode==m) Red else Panel2,contentColor=Color.White),contentPadding=PaddingValues(vertical=4.dp)){
                                        Text(strategyLabel(m),fontSize=8.sp,fontWeight=FontWeight.Black,maxLines=1)
                                    }
                                }
                            }
                            Text("PLANO DE PNEUS",color=Muted,fontSize=9.sp,fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=6.dp,bottom=3.dp))
                            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(4.dp)){
                                listOf("A","B","C").forEach { id ->
                                    Button(onClick={onPlan(driverId,id)},modifier=Modifier.weight(1f),colors=ButtonDefaults.buttonColors(containerColor=if(driverPlan.activePlan==id) Red else Panel2,contentColor=Color.White),contentPadding=PaddingValues(vertical=4.dp)){
                                        Text("PLANO $id",fontSize=8.sp,fontWeight=FontWeight.Black)
                                    }
                                }
                            }
                            val active=driverPlan.tyrePlans[driverPlan.activePlan]
                            Text(planDescription(active),color=Muted,fontSize=9.sp,modifier=Modifier.padding(top=4.dp))
                        }
                    }
                }
            }
        }

        Button(onClick=if(q3Complete) start else simulate,modifier=Modifier.fillMaxWidth().height(48.dp),colors=ButtonDefaults.buttonColors(containerColor=Red,contentColor=Color.White)){
            Text(if(q3Complete) "INICIAR CORRIDA" else "SIMULAR ${listOf("Q1","Q2","Q3")[phases.indexOfFirst { it.entries.isEmpty() }.coerceAtLeast(0).coerceAtMost(2)]}",fontWeight=FontWeight.Black)
        }
    }
}
@Composable private fun <T> ChoiceRow(title:String,current:String,values:List<T>,select:(T)->Unit){Column{Text(title,color=Muted,fontSize=10.sp,fontWeight=FontWeight.Bold);Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(6.dp)){values.forEach{v->FilterChip(selected=v.toString()==current,onClick={select(v)},label={Text(v.toString())})}}}}
@Composable
private fun Race(
    s: CareerWeekendEngine.SessionSnapshot,
    drivers: List<com.f1teammanager.core.season.DriverDefinition>,
    advance: () -> Unit,
    setStrategy: (Int, DriverStrategyMode) -> Unit,
    pitNow: (Int, Tyre) -> Unit,
    pitPlan: (Int, String) -> Unit,
    decision: (ManagerDecisionAction) -> Unit,
) {
    var running by remember { mutableStateOf(true) }
    var speedMs by remember { mutableIntStateOf(1100) }
    var pitDriver by remember { mutableIntStateOf(-1) }
    val playerIds = drivers.map { it.id }.toSet()
    val playerStatus = s.carStatus.filter { it.driverId in playerIds }
    val statusById = s.carStatus.associateBy { it.driverId }
    val leaderTime = s.classification.minOfOrNull { it.totalTimeMs } ?: 0L

    LaunchedEffect(s.lap, s.decision, s.completed, running, speedMs) {
        if (running && s.decision == null && !s.completed) {
            kotlinx.coroutines.delay(speedMs.toLong())
            advance()
        }
    }

    Column(Modifier.fillMaxSize().padding(horizontal = 10.dp)) {
        Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column { Text("PIT WALL", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Black); Text("VOLTA ${s.lap}/${s.totalLaps}", color = Red, fontWeight = FontWeight.Bold) }
            Column(horizontalAlignment = Alignment.End) { Text(statusLabel(s.neutral), color = if (s.neutral == Neutralisation.GREEN) Green else Red, fontWeight = FontWeight.Black); Text(if (running) "AUTOMÁTICA" else "PAUSADA", color = Muted, fontSize = 9.sp)
            Text(weatherLabel(s.weather), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp) }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            listOf(1600 to "0,7x", 1100 to "1x", 650 to "1,7x", 300 to "3x").forEach { (ms, label) ->
                Button(onClick={speedMs=ms}, modifier=Modifier.weight(1f), colors=ButtonDefaults.buttonColors(containerColor=if(speedMs==ms) Red else Panel2, contentColor=Color.White), contentPadding=PaddingValues(vertical=2.dp)){Text(label,fontSize=9.sp)}
            }
        }

        val critical=s.alerts.firstOrNull { it.severity>=3 }
        critical?.let { Card(Modifier.fillMaxWidth().padding(vertical=3.dp), colors=CardDefaults.cardColors(containerColor=Color(0xFF3A0D0D))){Text(it.message,color=Color.White,fontWeight=FontWeight.Bold,fontSize=10.sp,modifier=Modifier.padding(7.dp))} }

        // Decision area deliberately compact: only the two team cars remain above the live classification.
        playerStatus.forEach { st ->
            val plan=s.plans[st.driverId]
            val aheadTime = if (st.position > 1) s.classification.firstOrNull { it.position == st.position - 1 }?.totalTimeMs else null
            val ownTime = s.classification.firstOrNull { it.driverId == st.driverId }?.totalTimeMs ?: st.lastLapMs
            val gap=if(st.position<=1) "LÍDER" else gapText(ownTime, aheadTime ?: ownTime, ahead=false)
            Card(Modifier.fillMaxWidth().padding(vertical=2.dp), colors=CardDefaults.cardColors(Panel)) {
                Row(Modifier.fillMaxWidth().padding(horizontal=8.dp,vertical=6.dp),verticalAlignment=Alignment.CenterVertically){
                    Column(Modifier.weight(1f)){
                        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text(st.driverName,color=Color.White,fontWeight=FontWeight.Black,fontSize=14.sp);Text("P${st.position} $gap",color=Red,fontWeight=FontWeight.Black,fontSize=12.sp)}
                        Text("${tyreLabel(st.tyre)} ${st.tyreWear}%/${st.stintLaps}v • COMB ${st.fuelPercent}% • ERS ${st.ersPercent}% ${if(st.ersActive) "(-${st.ersGainMs}ms)" else ""} • ${if(st.drsActive) "DRS ATIVO (-${st.drsGainMs}ms)" else "DRS —"} • BOX ${st.pitStops}x",color=if(st.fuelPercent<=20||st.tyreWear>=75) Red else Muted,fontSize=9.sp)
                        Text("ÚLTIMA ${formatMs(st.lastLapMs)} • PNEU ~${st.tyre.targetLaps}v",color=Muted,fontSize=8.sp)
                    }
                    Spacer(Modifier.width(5.dp))
                    Button(onClick={pitDriver=st.driverId},colors=ButtonDefaults.buttonColors(containerColor=Red,contentColor=Color.White),contentPadding=PaddingValues(horizontal=11.dp,vertical=3.dp)){Text("BOX",fontSize=9.sp,fontWeight=FontWeight.Black)}
                }
                Row(Modifier.fillMaxWidth().padding(start=8.dp,end=8.dp,bottom=5.dp),horizontalArrangement=Arrangement.spacedBy(4.dp)){
                    DriverStrategyMode.entries.forEach { m -> Button(onClick={setStrategy(st.driverId,m)},modifier=Modifier.weight(1f),colors=ButtonDefaults.buttonColors(containerColor=if(plan?.mode==m) Red else Panel2,contentColor=Color.White),contentPadding=PaddingValues(vertical=2.dp)){Text(strategyLabel(m),fontSize=8.sp,maxLines=1)} }
                }
            }
        }

        Card(Modifier.fillMaxWidth().weight(1f), colors=CardDefaults.cardColors(Panel)) {
            Column {
                Row(Modifier.fillMaxWidth().padding(horizontal=8.dp,vertical=6.dp),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){Text("CLASSIFICAÇÃO AO VIVO",color=Color.White,fontWeight=FontWeight.Black,fontSize=15.sp);Text("${s.classification.size} PILOTOS",color=Red,fontWeight=FontWeight.Black,fontSize=10.sp)}
                Row(Modifier.fillMaxWidth().padding(horizontal=8.dp),horizontalArrangement=Arrangement.SpaceBetween){Text("POS",color=Muted,fontSize=8.sp,modifier=Modifier.width(24.dp));Text("PILOTO",color=Muted,fontSize=8.sp,modifier=Modifier.weight(1f));Text("PNEU",color=Muted,fontSize=8.sp,modifier=Modifier.width(42.dp));Text("GAP",color=Muted,fontSize=8.sp,modifier=Modifier.width(54.dp))}
                LazyColumn(Modifier.weight(1f)) {
                    items(s.classification) { f ->
                        val mine=f.driverId in playerIds; val st=statusById[f.driverId]
                        val aheadTime = if (f.position > 1) s.classification.firstOrNull { it.position == f.position - 1 }?.totalTimeMs else null
                        val gap=if(f.position==1)"LÍDER" else gapText(f.totalTimeMs, aheadTime ?: f.totalTimeMs, ahead=false)
                        Row(Modifier.fillMaxWidth().background(if(mine) Color(0xFF2A1010) else Color.Transparent).padding(horizontal=8.dp,vertical=3.dp),verticalAlignment=Alignment.CenterVertically){
                            Text("${f.position}",color=if(mine)Red else Muted,fontWeight=FontWeight.Bold,modifier=Modifier.width(24.dp),fontSize=10.sp)
                            val raceTeam = WorldDatabase.teams.firstOrNull { it.name.equals(f.teamName, ignoreCase = true) }
                            TeamLogo(f.teamName, raceTeam?.id ?: 0, Modifier.size(22.dp))
                            Spacer(Modifier.width(4.dp))
                            Text(f.driverName,color=if(mine) Red else Color.White,fontWeight=if(mine) FontWeight.Black else FontWeight.Normal,modifier=Modifier.weight(1f),maxLines=1,overflow=TextOverflow.Ellipsis,fontSize=10.sp)
                            Text(tyreLabel(f.tyre),color=if((st?.tyreWear?:0)>=80)Red else Muted,fontSize=8.sp,modifier=Modifier.width(42.dp))
                            Text(if(f.status.startsWith("DNF"))"DNF" else gap,color=if(f.status.startsWith("DNF"))Red else Muted,fontSize=8.sp,modifier=Modifier.width(54.dp))
                        }
                    }
                }
            }
        }

        if(s.events.isNotEmpty()) Text(s.events.takeLast(1).joinToString(" • "){it.detail},color=Muted,fontSize=8.sp,maxLines=1,overflow=TextOverflow.Ellipsis,modifier=Modifier.padding(vertical=2.dp))
        Button(onClick={running=!running},modifier=Modifier.fillMaxWidth().height(42.dp),colors=ButtonDefaults.buttonColors(containerColor=Red,contentColor=Color.White)){Text(if(running)"PAUSAR CORRIDA" else "RETOMAR CORRIDA",fontWeight=FontWeight.Black,fontSize=12.sp)}

        s.decision?.let { d ->
            AlertDialog(onDismissRequest={},title={Text("DECISÃO DO MANAGER",fontWeight=FontWeight.Black)},text={Column{Text("${d.driverName}: ${d.request.message}",color=Color.White);Spacer(Modifier.height(6.dp));d.request.options.forEach{action->Button(onClick={ if(action==ManagerDecisionAction.BOX) { pitDriver=d.request.driverId; running=true } else { decision(action); running=true } },modifier=Modifier.fillMaxWidth().padding(vertical=1.dp),colors=ButtonDefaults.buttonColors(containerColor=Red,contentColor=Color.White),contentPadding=PaddingValues(vertical=4.dp)){Text(actionLabel(action),fontSize=10.sp)}}}},confirmButton={})
        }
        if(pitDriver>0){
            val recommended = when(s.weather){
                Weather.HEAVY_RAIN -> Tyre.WET
                Weather.LIGHT_RAIN, Weather.MEDIUM_RAIN -> Tyre.INTERMEDIATE
                else -> Tyre.MEDIUM
            }
            AlertDialog(
                onDismissRequest={pitDriver=-1;running=true},
                title={Text("ESCOLHER PNEU PARA O BOX",fontWeight=FontWeight.Black)},
                text={Column{
                    val remainingLaps=(s.totalLaps-s.lap).coerceAtLeast(0)
                    Text("FALTAM $remainingLaps VOLTAS PARA O FIM DA CORRIDA",color=Red,fontWeight=FontWeight.Black,fontSize=11.sp)
                    Text("A vida mostrada é a referência do composto nas condições atuais. O desgaste real também considera clima e postura.",color=Muted,fontSize=9.sp,modifier=Modifier.padding(top=4.dp))
                    Text("RECOMENDADO AGORA: ${tyreLabel(recommended)}",color=Green,fontWeight=FontWeight.Black,fontSize=10.sp,modifier=Modifier.padding(top=6.dp,bottom=4.dp))
                    listOf(Tyre.SOFT,Tyre.MEDIUM,Tyre.HARD,Tyre.INTERMEDIATE,Tyre.WET).forEach{t->
                        val driverTyreWear = drivers.firstOrNull { it.id == pitDriver }?.tyre ?: 50
                        val life=tyreLifeEstimate(t,s.weather,s.plans[pitDriver]?.mode ?: DriverStrategyMode.BALANCED,driverTyreWear)
                        Button(onClick={pitNow(pitDriver,t);pitDriver=-1;running=true},modifier=Modifier.fillMaxWidth().padding(vertical=2.dp),colors=ButtonDefaults.buttonColors(containerColor=if(t==recommended) Red else Panel2,contentColor=Color.White)){Text("${tyreLabel(t)} • ${life} VOLTAS${if(t==recommended) " • RECOMENDADO" else ""}")}
                    }
                    val activePlan = s.plans[pitDriver]
                    if (activePlan != null) {
                        if (activePlan.weatherManualMode) {
                            Text("PLANO ABANDONADO PELA CHUVA",color=Red,fontWeight=FontWeight.Black,fontSize=10.sp,modifier=Modifier.padding(top=6.dp))
                            Text("A partir da entrada de chuva, as trocas são 100% manuais. O plano não volta automaticamente quando a pista seca.",color=Muted,fontSize=9.sp,modifier=Modifier.padding(top=2.dp,bottom=4.dp))
                        } else {
                            val activeTyrePlan = activePlan.tyrePlans[activePlan.activePlan]
                            Text("PLANO ATUAL: ${activePlan.activePlan}",color=Color.White,fontWeight=FontWeight.Black,fontSize=10.sp,modifier=Modifier.padding(top=6.dp))
                            Text(planDescription(activeTyrePlan),color=Muted,fontSize=9.sp,modifier=Modifier.padding(top=2.dp,bottom=4.dp))
                            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(4.dp)){
                                listOf("A","B","C").forEach { id ->
                                    val p = activePlan.tyrePlans[id]
                                    Button(onClick={pitPlan(pitDriver,id);pitDriver=-1;running=true},modifier=Modifier.weight(1f),colors=ButtonDefaults.buttonColors(containerColor=if(activePlan.activePlan==id) Red else Panel2,contentColor=Color.White),contentPadding=PaddingValues(vertical=3.dp)){Text("PLANO $id",fontSize=8.sp,fontWeight=FontWeight.Black)}
                                }
                            }
                            Button(onClick={pitPlan(pitDriver,activePlan.activePlan);pitDriver=-1;running=true},modifier=Modifier.fillMaxWidth().padding(top=4.dp),colors=ButtonDefaults.buttonColors(containerColor=Red,contentColor=Color.White)){Text("MANTER PLANO ${activePlan.activePlan}",fontWeight=FontWeight.Black,fontSize=9.sp)}
                        }
                    }
                    Spacer(Modifier.height(4.dp))
                    Text("OU ESCOLHER MANUALMENTE",color=Muted,fontWeight=FontWeight.Bold,fontSize=8.sp,modifier=Modifier.padding(top=2.dp,bottom=2.dp))
                    Button(
                        onClick={pitDriver=-1;running=true},
                        modifier=Modifier.fillMaxWidth().padding(top=2.dp),
                        colors=ButtonDefaults.buttonColors(containerColor=Panel2,contentColor=Color.White)
                    ){Text("SAIR • NÃO IR AO BOX",fontWeight=FontWeight.Black)}
                }},
                confirmButton={}
            )
        }
    }
}

private fun gapText(time: Long, reference: Long, ahead: Boolean = false): String {
    val gap = (time - reference).coerceAtLeast(0L)
    return "+${gap / 1000}.${(gap % 1000) / 100}s"
}

private fun formatRaceTime(ms: Long): String {
    val totalSeconds = ms / 1000
    val hours = totalSeconds / 3600
    val minutes = (totalSeconds % 3600) / 60
    val seconds = totalSeconds % 60
    val millis = ms % 1000
    return if (hours > 0) String.format(java.util.Locale.US, "%d:%02d:%02d.%03d", hours, minutes, seconds, millis)
    else String.format(java.util.Locale.US, "%d:%02d.%03d", minutes, seconds, millis)
}

private fun formatGap(ms: Long): String {
    val seconds = ms / 1000
    val millis = ms % 1000
    return String.format(java.util.Locale.US, "+%d.%03ds", seconds, millis)
}

@Composable private fun Result(r:RaceResult,teamId:Int,store:CareerPreferences,onCalendar:()->Unit){
    val teamName=WorldDatabase.teams.first{it.id==teamId}.name
    val mine=r.classification.filter{it.teamName==teamName}
    val earned=mine.sumOf{r.points[it.driverId]?:0}
    val leader=r.classification.firstOrNull { !it.status.startsWith("DNF") }
    val leaderTime=leader?.totalTimeMs ?: 0L
    val dnfs=r.classification.filter { it.status.startsWith("DNF") }
    Column(Modifier.fillMaxSize().padding(16.dp)){
        HeaderBlock("RESULTADO","CORRIDA FINALIZADA")
        Card(Modifier.fillMaxWidth().padding(top=10.dp),colors=CardDefaults.cardColors(Panel)){
            Column(Modifier.padding(13.dp)){
                Text("SUA EQUIPE",color=Red,fontWeight=FontWeight.Black)
                mine.forEach{f->
                    Row(Modifier.fillMaxWidth().padding(top=6.dp),verticalAlignment=Alignment.CenterVertically){
                        Text("P${f.position}",color=if(f.position<=3)Red else Muted,fontWeight=FontWeight.Black,modifier=Modifier.width(34.dp))
                        Text(f.driverName,color=Color.White,fontWeight=FontWeight.Bold,modifier=Modifier.weight(1f),maxLines=1,overflow=TextOverflow.Ellipsis)
                        Text("${r.points[f.driverId]?:0} PTS",color=Color.White,fontWeight=FontWeight.Bold,fontSize=10.sp)
                    }
                }
                Text("PONTOS CONQUISTADOS: $earned",color=Color.White,fontWeight=FontWeight.Black,modifier=Modifier.padding(top=8.dp))
            }
        }
        if(leader!=null){
            Card(Modifier.fillMaxWidth().padding(top=8.dp),colors=CardDefaults.cardColors(Panel2)){
                Column(Modifier.padding(11.dp)){
                    Text("TEMPO DO LÍDER",color=Red,fontWeight=FontWeight.Black,fontSize=10.sp)
                    Text(formatRaceTime(leaderTime),color=Color.White,fontWeight=FontWeight.Black,fontSize=19.sp)
                    Text("${leader.driverName} • P1",color=Muted,fontSize=10.sp)
                }
            }
        }
        LazyColumn(Modifier.weight(1f),contentPadding=PaddingValues(vertical=10.dp),verticalArrangement=Arrangement.spacedBy(3.dp)){
            items(r.classification){f->
                val resultTeam=WorldDatabase.teams.firstOrNull { it.name.equals(f.teamName, ignoreCase = true) }
                val finished=!f.status.startsWith("DNF")
                val gap=if(finished && leader!=null) (f.totalTimeMs-leaderTime).coerceAtLeast(0L) else 0L
                Row(Modifier.fillMaxWidth().background(if(f.position<=3)Color(0xFF251414) else if(!finished) Color(0xFF2A1113) else Panel,RoundedCornerShape(5.dp)).padding(9.dp),verticalAlignment=Alignment.CenterVertically){
                    Text("P${f.position}",color=if(f.position<=3)Red else if(!finished)Red else Muted,fontWeight=FontWeight.Black,modifier=Modifier.width(38.dp))
                    TeamLogo(f.teamName,resultTeam?.id ?: 0,Modifier.size(24.dp))
                    Spacer(Modifier.width(5.dp))
                    Column(Modifier.weight(1f)){
                        Text(f.driverName,color=Color.White,fontWeight=if(!finished) FontWeight.Black else FontWeight.Normal,maxLines=1,overflow=TextOverflow.Ellipsis)
                        Text(if(!finished) "ABANDONOU • ${f.laps} voltas" else if(f.position==leader?.position) "LÍDER" else "GAP ${formatGap(gap)}",color=if(!finished) Red else Muted,fontSize=8.sp)
                    }
                    Column(horizontalAlignment=Alignment.End){
                        Text("${r.points[f.driverId]?:0} PTS",color=if((r.points[f.driverId]?:0)>0) Color.White else Muted,fontSize=9.sp,fontWeight=FontWeight.Bold)
                        if(!finished) Text("DNF",color=Red,fontSize=8.sp,fontWeight=FontWeight.Black)
                    }
                }
            }
        }
        Text("ABANDONOS: ${dnfs.size} • Safety Car ${r.safetyCarLaps} • VSC ${r.vscLaps} • Campeonato: ${store.constructorPoints()[teamId]?:0} PTS",color=Muted,fontSize=9.sp)
        Button(onClick=onCalendar,modifier=Modifier.fillMaxWidth().height(48.dp),colors=ButtonDefaults.buttonColors(containerColor=Red,contentColor=Color.White)){Text("IR PARA CALENDÁRIO",fontWeight=FontWeight.Black)}
    }
}

@Composable
private fun RaceImage(round:RoundDefinition, modifier:Modifier = Modifier) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var bitmap by remember(round.round) { mutableStateOf<android.graphics.Bitmap?>(null) }
    LaunchedEffect(round.round) {
        bitmap = withContext(Dispatchers.IO) { ExternalAssets.loadGrandPrixImage(context, round.grandPrix) }
    }
    if (bitmap != null) {
        Image(bitmap = bitmap!!.asImageBitmap(), contentDescription = round.grandPrix, modifier = modifier.clip(RoundedCornerShape(8.dp)), contentScale = androidx.compose.ui.layout.ContentScale.Fit)
    } else {
        Box(modifier.clip(RoundedCornerShape(8.dp)).background(Panel2).border(1.dp, Line, RoundedCornerShape(8.dp)), contentAlignment = Alignment.Center) {
            Text("IMAGEM DO GP", color = Muted, fontWeight = FontWeight.Black, fontSize = 9.sp)
        }
    }
}

@Composable
private fun DriverPhoto(driverId:Int, driverName:String, modifier:Modifier = Modifier) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var bitmap by remember(driverId, driverName) { mutableStateOf<android.graphics.Bitmap?>(null) }
    LaunchedEffect(driverId, driverName) {
        bitmap = withContext(Dispatchers.IO) { ExternalAssets.loadDriverPhoto(context, driverId, driverName) }
    }
    if (bitmap != null) {
        Image(bitmap = bitmap!!.asImageBitmap(), contentDescription = "Foto $driverName", modifier = modifier, contentScale = androidx.compose.ui.layout.ContentScale.Crop)
    } else {
        Box(modifier.background(Panel2, RoundedCornerShape(6.dp)).border(1.dp, Line, RoundedCornerShape(6.dp)), contentAlignment = Alignment.Center) {
            Text(driverName.split(" ").mapNotNull { it.firstOrNull() }.take(2).joinToString(""), color = Muted, fontWeight = FontWeight.Black, fontSize = 9.sp)
        }
    }
}

@Composable
private fun MovementBadge(movement:Int, hasPrevious:Boolean, modifier:Modifier = Modifier) {
    val label = when {
        !hasPrevious -> "•"
        movement > 0 -> "▲$movement"
        movement < 0 -> "▼${-movement}"
        else -> "—"
    }
    val color = when {
        !hasPrevious || movement == 0 -> Muted
        movement > 0 -> Green
        else -> Red
    }
    Text(label, color=color, fontWeight=FontWeight.Black, fontSize=9.sp, modifier=modifier)
}

@Composable
private fun TeamLogo(teamName:String, teamId:Int, modifier:Modifier = Modifier) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var bitmap by remember(teamId, teamName) { mutableStateOf<android.graphics.Bitmap?>(null) }
    LaunchedEffect(teamId, teamName) {
        bitmap = withContext(Dispatchers.IO) { ExternalAssets.loadTeamLogo(context, teamId, teamName) }
    }
    if (bitmap != null) {
        Image(bitmap = bitmap!!.asImageBitmap(), contentDescription = "Escudo $teamName", modifier = modifier, contentScale = androidx.compose.ui.layout.ContentScale.Fit)
    } else {
        Box(modifier.background(Panel2, RoundedCornerShape(6.dp)).border(1.dp, Line, RoundedCornerShape(6.dp)), contentAlignment = Alignment.Center) {
            Text("${teamName.take(2).uppercase()}", color = Muted, fontWeight = FontWeight.Black, fontSize = 8.sp)
        }
    }
}

private fun initialManagerState(teamId:Int,store:CareerPreferences):TeamManagerState { val t=WorldDatabase.teams.first{it.id==teamId}; val base=TeamManagerState(season=store.season,round=store.roundIndex+1,playerTeamId=teamId,car=TeamCarState(t.baseCar,t.chassis,t.engine,t.reliability,frontWing=t.frontWing,rearWing=t.rearWing,brakes=t.brakes,electricPowerUnit=t.electricPowerUnit),finance=TeamFinanceState(75_000_000L)); val sponsors=store.loadSponsors(teamId); val market=store.loadDriverMarket() ?: DriverMarketEngine(20261003).initialState(store.season); store.saveDriverMarket(market); return base.copy(finance=store.loadFinance(teamId,base.finance),sponsor=sponsors.firstOrNull { it.slot==1 } ?: store.loadSponsor(teamId,base.sponsor),sponsors=sponsors,driverMarket=market) }
private fun componentLabel(c:CarComponent)=when(c){CarComponent.ENGINE->"Unidade de potência";CarComponent.CHASSIS->"Chassi";CarComponent.FRONT_WING->"Asa dianteira";CarComponent.REAR_WING->"Asa traseira";CarComponent.BRAKES->"Freios";CarComponent.ELECTRIC_POWER_UNIT->"Unidade de potência elétrica"}
private fun componentDuration(c:CarComponent)=when(c){CarComponent.ENGINE->4;CarComponent.CHASSIS->3;CarComponent.FRONT_WING->2;CarComponent.REAR_WING->2;CarComponent.BRAKES->2;CarComponent.ELECTRIC_POWER_UNIT->4}
@Composable private fun HistoryResult(round:Int,result:RaceResult?){
    if(result==null){Text("Nenhuma classificação salva para o Round $round",color=Muted,modifier=Modifier.padding(16.dp));return}
    val leader=result.classification.firstOrNull { !it.status.startsWith("DNF") }
    val leaderTime=leader?.totalTimeMs ?: 0L
    Column(Modifier.fillMaxSize().padding(12.dp)){
        HeaderBlock("ROUND $round","CLASSIFICAÇÃO SALVA")
        if(leader!=null){
            Card(Modifier.fillMaxWidth().padding(top=8.dp),colors=CardDefaults.cardColors(Panel2)){
                Column(Modifier.padding(10.dp)){
                    Text("TEMPO DO LÍDER",color=Red,fontWeight=FontWeight.Black,fontSize=10.sp)
                    Text(formatRaceTime(leaderTime),color=Color.White,fontWeight=FontWeight.Black,fontSize=18.sp)
                    Text("${leader.driverName} • P1",color=Muted,fontSize=9.sp)
                }
            }
        }
        LazyColumn(Modifier.weight(1f),contentPadding=PaddingValues(vertical=8.dp),verticalArrangement=Arrangement.spacedBy(3.dp)){
            items(result.classification){f->
                val historyTeam=WorldDatabase.teams.firstOrNull { it.name.equals(f.teamName, ignoreCase = true) }
                val finished=!f.status.startsWith("DNF")
                val gap=if(finished && leader!=null) (f.totalTimeMs-leaderTime).coerceAtLeast(0L) else 0L
                Row(Modifier.fillMaxWidth().background(if(f.position<=3)Color(0xFF251414) else if(!finished) Color(0xFF2A1113) else Panel,RoundedCornerShape(5.dp)).padding(8.dp),verticalAlignment=Alignment.CenterVertically){
                    Text("P${f.position}",color=if(f.position<=3)Red else if(!finished)Red else Muted,fontWeight=FontWeight.Black,modifier=Modifier.width(38.dp))
                    TeamLogo(f.teamName,historyTeam?.id ?: 0,Modifier.size(22.dp))
                    Spacer(Modifier.width(5.dp))
                    Column(Modifier.weight(1f)){
                        Text(f.driverName,color=Color.White,maxLines=1,overflow=TextOverflow.Ellipsis)
                        Text(if(!finished) "ABANDONOU • ${f.laps} voltas" else if(f.position==leader?.position) "LÍDER" else "GAP ${formatGap(gap)}",color=if(!finished) Red else Muted,fontSize=8.sp)
                    }
                    Text("${result.points[f.driverId]?:0} PTS",color=Muted,fontSize=9.sp)
                }
            }
        }
        Text("ABANDONOS: ${result.classification.count { it.status.startsWith("DNF") }}",color=Muted,fontSize=9.sp)
    }
}

@Composable
private fun SeasonArchive(store: CareerPreferences) {
    val db = store.history
    val seasons = db.seasons()
    var scope by remember { mutableIntStateOf(0) }
    var selectedSeason by remember(seasons) { mutableIntStateOf(seasons.firstOrNull() ?: store.season) }
    LazyColumn(
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        item { HistorySection("📅 TEMPORADA", "Registro final somente após as 30 corridas") }
        item { HistoryScopeSelector(scope) { scope = it } }
        if (seasons.isEmpty()) {
            item { EmptyHistory("A temporada atual ainda está em andamento. O registro só será criado depois do GP 30.") }
        } else {
            item {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    seasons.forEach { season ->
                        Button(
                            onClick = { selectedSeason = season },
                            colors = ButtonDefaults.buttonColors(containerColor = if (selectedSeason == season) Red else Panel2, contentColor = Color.White),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 5.dp)
                        ) { Text(season.toString(), fontSize = 8.sp, fontWeight = FontWeight.Black) }
                    }
                }
            }
            if (scope == 0) {
                val rows = db.driverSeasonRecords(selectedSeason)
                item { HistorySection("PILOTOS • $selectedSeason", "80 pilotos • Ano / Posição / Piloto / Equipe / Pontos / Vitórias / Poles / Voltas + rápidas / DNF / GPs") }
                items(rows) { SeasonDriverRow(it) }
            } else {
                val rows = db.constructorSeasonRecords(selectedSeason)
                item { HistorySection("CONSTRUTORES • $selectedSeason", "40 equipes • Ano / Posição / Equipe / Pontos / Vitórias / Poles / Voltas + rápidas / DNF / GPs") }
                items(rows) { SeasonConstructorRow(it) }
            }
        }
    }
}

@Composable
private fun HistoryScreen(store: CareerPreferences) {
    val db = store.history
    var historyScope by remember { mutableIntStateOf(0) }
    var historyCategory by remember { mutableIntStateOf(0) }

    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        item { HistorySection("📖 HISTÓRIA", "Registro atualizado imediatamente após cada GP") }
        item { HistoryScopeSelector(historyScope) { historyScope = it } }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("🏆 VITÓRIAS", "🥇 POLES", "⚡ VOLTAS + RÁPIDAS", "👑 CAMPEÕES").chunked(2).forEach { row ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        row.forEach { label ->
                            val index = listOf("🏆 VITÓRIAS", "🥇 POLES", "⚡ VOLTAS + RÁPIDAS", "👑 CAMPEÕES").indexOf(label)
                            Button(onClick = { historyCategory = index }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = if (historyCategory == index) Red else Panel2, contentColor = Color.White), contentPadding = PaddingValues(vertical = 6.dp)) {
                                Text(label, fontSize = 8.sp, fontWeight = FontWeight.Black)
                            }
                        }
                    }
                }
            }
        }
        when (historyCategory) {
            0 -> {
                val rows = db.victories()
                item { HistorySection("🏆 VITÓRIAS • ${if (historyScope == 0) "PILOTOS" else "CONSTRUTORES"}", "1 vencedor por GP") }
                items(rows) { r -> HistoryHistoryRow(r, "VENCEDOR", formatRaceTime(r.totalTimeMs), showDriver = historyScope == 0) }
            }
            1 -> {
                val rows = db.poles()
                item { HistorySection("🥇 POLES • ${if (historyScope == 0) "PILOTOS" else "CONSTRUTORES"}", "1 pole por GP") }
                items(rows) { r ->
                    HistoryPanel {
                        HistoryEventHeader(r.season, r.round, r.grandPrix, r.teamId, r.teamName, r.driverName, showDriver = historyScope == 0, driverId = r.driverId)
                        Text("TEMPO • ${formatMs(r.timeMs)}", color = Color.White, fontWeight = FontWeight.Black, fontSize = 9.sp)
                    }
                }
            }
            2 -> {
                val rows = db.fastestLaps()
                item { HistorySection("⚡ VOLTAS + RÁPIDAS • ${if (historyScope == 0) "PILOTOS" else "CONSTRUTORES"}", "1 volta mais rápida por GP") }
                items(rows) { r -> HistoryHistoryRow(r, "VOLTA MAIS RÁPIDA", formatMs(r.fastestLapTimeMs), showDriver = historyScope == 0) }
            }
            3 -> {
                if (historyScope == 0) {
                    val rows = db.driverChampions()
                    item { HistorySection("👑 CAMPEÕES • PILOTOS", "1 campeão por temporada • disponível somente após o GP 30") }
                    items(rows) { c ->
                        HistoryPanel {
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Text("${c.season}", color = Red, fontWeight = FontWeight.Black, modifier = Modifier.width(46.dp))
                                TeamLogo(c.teamName, c.teamId, Modifier.size(30.dp))
                                Column(Modifier.weight(1f).padding(start = 7.dp, end = 6.dp)) {
                                    Text(c.driverName, color = Color.White, fontWeight = FontWeight.Black, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text(c.teamName, color = Muted, fontSize = 8.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                                DriverPhoto(c.driverId, c.driverName, Modifier.size(38.dp).clip(RoundedCornerShape(6.dp)))
                                Spacer(Modifier.width(7.dp))
                                Text("${c.points} PTS", color = Color.White, fontWeight = FontWeight.Black, fontSize = 9.sp)
                            }
                        }
                    }
                } else {
                    val rows = db.constructorChampions()
                    item { HistorySection("👑 CAMPEÕES • CONSTRUTORES", "1 campeão por temporada • disponível somente após o GP 30") }
                    items(rows) { c ->
                        HistoryPanel {
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Text("${c.season}", color = Red, fontWeight = FontWeight.Black, modifier = Modifier.width(46.dp))
                                TeamLogo(c.teamName, c.teamId, Modifier.size(34.dp))
                                Column(Modifier.weight(1f).padding(start = 7.dp)) { Text(c.teamName, color = Color.White, fontWeight = FontWeight.Black) }
                                Text("${c.points} PTS", color = Color.White, fontWeight = FontWeight.Black, fontSize = 9.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun HallOfFameScreen(store: CareerPreferences) {
    val db = store.history
    var hallScope by remember { mutableIntStateOf(0) }
    var hallMetric by remember { mutableIntStateOf(0) }
    val metricLabels = if (hallScope == 0) listOf("👑 CAMPEÕES", "🏆 VITÓRIAS", "🥇 POLES", "⚡ VOLTAS + RÁPIDAS", "📊 PONTOS", "🏁 GPs")
    else listOf("👑 CAMPEÕES", "🏆 VITÓRIAS", "🥇 POLES", "⚡ VOLTAS + RÁPIDAS", "📊 PONTOS")
    val metric = when (hallMetric) { 0 -> HistoricalDatabase.HallMetric.CHAMPIONS; 1 -> HistoricalDatabase.HallMetric.WINS; 2 -> HistoricalDatabase.HallMetric.POLES; 3 -> HistoricalDatabase.HallMetric.FASTEST_LAPS; 4 -> HistoricalDatabase.HallMetric.POINTS; else -> HistoricalDatabase.HallMetric.GPS }
    val scope = if (hallScope == 0) HistoricalDatabase.HallScope.DRIVERS else HistoricalDatabase.HallScope.CONSTRUCTORS
    val rows = db.hallRanking(scope, metric).filter { it.value > 0 }
    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        item { HistorySection("🏛️ HALL DA FAMA", "Ranking histórico • atualizado sempre que uma nova informação entra no histórico") }
        item { HistoryScopeSelector(hallScope) { hallScope = it; hallMetric = 0 } }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                metricLabels.chunked(2).forEach { row ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        row.forEach { label ->
                            val index = metricLabels.indexOf(label)
                            Button(onClick = { hallMetric = index }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = if (hallMetric == index) Red else Panel2, contentColor = Color.White), contentPadding = PaddingValues(vertical = 6.dp)) { Text(label, fontSize = 8.sp, fontWeight = FontWeight.Black) }
                        }
                        if (row.size == 1) Spacer(Modifier.weight(1f))
                    }
                }
            }
        }
        item { HistorySection("RANKING", "Maior para menor • ↑ subiu • ↓ desceu • → manteve • NOVO") }
        if (rows.isEmpty()) item { EmptyHistory("Ainda não há registros suficientes para este ranking.") }
        else items(rows) { h -> HallRow(h, hallScope == 0) }
    }
}

@Composable
private fun RecordsScreen(store: CareerPreferences) {
    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        item { HistorySection("🏅 RECORDES", "Área exclusiva para os recordes históricos do jogo") }
        item { EmptyHistory("Os recordes serão definidos em uma próxima etapa. Nenhum recorde foi criado automaticamente.") }
    }
}

@Composable
private fun HistoryScopeSelector(selected: Int, onSelect: (Int) -> Unit) {
    Row(
        Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(9.dp)).padding(3.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        listOf("PILOTOS", "CONSTRUTORES").forEachIndexed { index, label ->
            Button(
                onClick = { onSelect(index) },
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = if (selected == index) Red else Panel2, contentColor = Color.White),
                contentPadding = PaddingValues(vertical = 6.dp)
            ) { Text(label, fontSize = 9.sp, fontWeight = FontWeight.Black) }
        }
    }
}

@Composable
private fun SeasonDriverRow(r: HistoricalDatabase.DriverSeasonRecord) {
    HistoryPanel {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("P${r.position}", color = if (r.position <= 3) Red else Muted, fontWeight = FontWeight.Black, modifier = Modifier.width(34.dp))
            TeamLogo(r.teamName, r.teamId, Modifier.size(30.dp))
            Column(Modifier.weight(1f).padding(start = 7.dp, end = 6.dp)) {
                Text(r.driverName, color = Color.White, fontWeight = FontWeight.Black, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(r.teamName, color = Muted, fontSize = 8.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("V ${r.wins} • P ${r.poles} • ⚡ ${r.fastestLaps} • DNF ${r.dnf} • GPs ${r.gps}", color = Muted, fontSize = 7.sp)
            }
            DriverPhoto(r.driverId, r.driverName, Modifier.size(38.dp).clip(RoundedCornerShape(6.dp)))
            Spacer(Modifier.width(7.dp))
            Text("${r.points} PTS", color = Color.White, fontWeight = FontWeight.Black, fontSize = 9.sp)
        }
    }
}

@Composable
private fun SeasonConstructorRow(r: HistoricalDatabase.ConstructorSeasonRecord) {
    HistoryPanel {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("P${r.position}", color = if (r.position <= 3) Red else Muted, fontWeight = FontWeight.Black, modifier = Modifier.width(34.dp))
            TeamLogo(r.teamName, r.teamId, Modifier.size(30.dp))
            Column(Modifier.weight(1f).padding(start = 7.dp)) {
                Text(r.teamName, color = Color.White, fontWeight = FontWeight.Black, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("V ${r.wins} • P ${r.poles} • ⚡ ${r.fastestLaps} • DNF ${r.dnf} • GPs ${r.gps}", color = Muted, fontSize = 7.sp)
            }
            Text("${r.points} PTS", color = Color.White, fontWeight = FontWeight.Black, fontSize = 9.sp)
        }
    }
}

@Composable
private fun HistoryEventHeader(season: Int, round: Int, grandPrix: String, teamId: Int, teamName: String, driverName: String, showDriver: Boolean = true, driverId: Int = 0) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text("$season • R$round", color = Red, fontWeight = FontWeight.Black, fontSize = 9.sp, modifier = Modifier.width(72.dp))
        TeamLogo(teamName, teamId, Modifier.size(30.dp))
        Column(Modifier.weight(1f).padding(start = 7.dp, end = 6.dp)) {
            Text(if (showDriver) driverName else teamName, color = Color.White, fontWeight = FontWeight.Black, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(if (showDriver) "$grandPrix • $teamName" else "$grandPrix • $driverName", color = Muted, fontSize = 8.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        if (showDriver) DriverPhoto(driverId, driverName, Modifier.size(38.dp).clip(RoundedCornerShape(6.dp)))
    }
}

@Composable
private fun HistoryHistoryRow(r: HistoricalDatabase.RaceRecord, label: String, time: String, showDriver: Boolean = true) {
    HistoryPanel {
        HistoryEventHeader(r.season, r.round, r.grandPrix, r.teamId, r.teamName, r.driverName, showDriver, r.driverId)
        Row(Modifier.fillMaxWidth().padding(top = 7.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, color = Muted, fontSize = 8.sp, fontWeight = FontWeight.Black)
            Text("TEMPO • $time", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Black)
        }
    }
}

@Composable
private fun HallRow(h: HistoricalDatabase.HallEntry, showDriverPhoto: Boolean) {
    HistoryPanel {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("#${h.position}", color = if (h.position <= 3) Red else Muted, fontWeight = FontWeight.Black, modifier = Modifier.width(36.dp))
            if (h.teamId > 0) TeamLogo(h.teamName, h.teamId, Modifier.size(30.dp))
            Column(Modifier.weight(1f).padding(start = 7.dp, end = 6.dp)) {
                Text(h.name, color = Color.White, fontWeight = FontWeight.Black, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (h.teamName.isNotBlank()) Text(h.teamName, color = Muted, fontSize = 7.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            if (showDriverPhoto) {
                DriverPhoto(h.id, h.name, Modifier.size(38.dp).clip(RoundedCornerShape(6.dp)))
                Spacer(Modifier.width(7.dp))
            }
            Column(horizontalAlignment = Alignment.End) {
                Text("${h.value}", color = Color.White, fontWeight = FontWeight.Black, fontSize = 12.sp)
                Text(
                    when {
                        h.movement == Int.MIN_VALUE -> "NOVO"
                        h.movement > 0 -> "↑${h.movement}"
                        h.movement < 0 -> "↓${-h.movement}"
                        else -> "→"
                    },
                    color = when {
                        h.movement > 0 -> Green
                        h.movement < 0 -> Red
                        else -> Muted
                    },
                    fontSize = 8.sp,
                    fontWeight = FontWeight.Black
                )
            }
        }
    }
}

@Composable
private fun HistorySection(title: String, subtitle: String) {
    Column(Modifier.padding(top = 2.dp, bottom = 2.dp)) {
        Text(title, color = Color.White, fontWeight = FontWeight.Black, fontSize = 14.sp)
        Text(subtitle, color = Muted, fontSize = 9.sp, modifier = Modifier.padding(top = 2.dp))
    }
}

@Composable
private fun HistoryPanel(content: @Composable ColumnScope.() -> Unit) {
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(Panel)) { Column(Modifier.padding(7.dp), content = content) }
}

@Composable
private fun HistoryRaceRow(r: HistoricalDatabase.RaceRecord, showPosition: Boolean, emphasizeTime: Boolean = false) {
    val finished = !r.status.startsWith("DNF")
    HistoryPanel {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            if (showPosition) Text("P${r.position}", color = if (r.position <= 3) Red else Muted, fontWeight = FontWeight.Black, modifier = Modifier.width(34.dp))
            else Text("R${r.round}", color = Red, fontWeight = FontWeight.Black, modifier = Modifier.width(34.dp))
            TeamLogo(r.teamName, r.teamId, Modifier.size(26.dp))
            Column(Modifier.weight(1f).padding(start = 7.dp)) {
                Text(r.driverName, color = Color.White, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("${r.grandPrix} • ${r.teamName} • ${r.season}", color = Muted, fontSize = 8.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(if (!finished) "ABANDONOU • ${r.laps} voltas" else if (r.position == 1) "VENCEDOR" else "GAP ${formatGap(r.gapToLeaderMs)}", color = if (!finished) Red else Muted, fontSize = 8.sp)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text("${r.points} PTS", color = Color.White, fontWeight = FontWeight.Black, fontSize = 9.sp)
                Text(formatRaceTime(r.totalTimeMs), color = if (emphasizeTime) Red else Muted, fontWeight = FontWeight.Bold, fontSize = 8.sp)
            }
        }
    }
}

@Composable
private fun EmptyHistory(message: String) {
    HistoryPanel { Text(message, color = Muted, fontSize = 10.sp) }
}

@Composable
private fun TeamSelect(onSelect: (Int) -> Unit) {
    Column(Modifier.fillMaxSize().statusBarsPadding().padding(16.dp)) {
        HeaderBlock("F1 MANAGER", "ESCOLHA SUA EQUIPE")
        Text("40 equipes • 80 pilotos", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(vertical = 8.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp), contentPadding = PaddingValues(bottom = 16.dp)) {
            items(WorldDatabase.teams.sortedWith(compareByDescending<com.f1teammanager.core.season.TeamDefinition> { it.baseCar }.thenByDescending { it.engine }.thenByDescending { it.reliability }.thenBy { it.id })) { t ->
                Card(Modifier.fillMaxWidth().clickable { onSelect(t.id) }, colors = CardDefaults.cardColors(Panel)) {
                    Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        TeamLogo(t.name,t.id,Modifier.size(48.dp)); Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(t.name, color = Color.White, fontWeight = FontWeight.Black)
                            Text("Força ${t.baseCar} • Motor ${t.engine} • Confiabilidade ${t.reliability}", color = Muted, fontSize = 10.sp)
                        }
                        Text("ESCOLHER", color = Red, fontWeight = FontWeight.Black, fontSize = 10.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun Standings(teamId: Int, store: CareerPreferences) {
    var tab by remember { mutableIntStateOf(0) }
    val driverPoints=store.driverPoints()
    val constructorPoints=store.constructorPoints()
    val market = store.loadDriverMarket()
    val drivers = (market?.contracts?.filter { it.activeIn(store.season) }?.mapNotNull { deal ->
        val d=WorldDatabase.allDrivers.firstOrNull { it.id==deal.driverId } ?: return@mapNotNull null
        val t=WorldDatabase.teams.firstOrNull { it.id==deal.teamId } ?: return@mapNotNull null
        Triple(d,t,driverPoints[d.id]?:0)
    } ?: WorldDatabase.drivers.map { d -> val t=WorldDatabase.teams.first{it.id==d.teamId}; Triple(d,t,driverPoints[d.id]?:0) }).sortedByDescending{it.third}
    val constructors=WorldDatabase.teams.map{t->t to (constructorPoints[t.id]?:0)}.sortedWith(compareByDescending<Pair<com.f1teammanager.core.season.TeamDefinition,Int>>{it.second}.thenBy{it.first.id})
    val previousDrivers = store.previousDriverPositions()
    val previousConstructors = store.previousConstructorPositions()
    val hasPrevious = previousDrivers.isNotEmpty() || previousConstructors.isNotEmpty()
    Column(Modifier.fillMaxSize().padding(12.dp)){
        HeaderBlock("CAMPEONATO","PILOTOS E CONSTRUTORES")
        Row(Modifier.fillMaxWidth().background(Panel,RoundedCornerShape(8.dp)).padding(4.dp),horizontalArrangement=Arrangement.spacedBy(4.dp)){
            listOf("PILOTOS","CONSTRUTORES").forEachIndexed{index,label->Button(onClick={tab=index},modifier=Modifier.weight(1f),colors=ButtonDefaults.buttonColors(containerColor=if(tab==index)Red else Panel2,contentColor=Color.White),contentPadding=PaddingValues(vertical=8.dp)){Text(label,fontWeight=FontWeight.Black,fontSize=10.sp)}}
        }
        if(tab==0){
            LazyColumn(Modifier.weight(1f),contentPadding=PaddingValues(vertical=8.dp),verticalArrangement=Arrangement.spacedBy(3.dp)){
                items(drivers){(d,t,pts)->
                    val position = drivers.indexOfFirst{it.first.id==d.id}+1
                    val previous = previousDrivers[d.id]
                    val movement = if(hasPrevious && previous != null) previous-position else 0
                    val abovePoints = if(position > 1) drivers[position-2].third else null
                    val gap = abovePoints?.let { it - pts }
                    Row(Modifier.fillMaxWidth().background(if(t.id==teamId)Color(0xFF251414)else Panel,RoundedCornerShape(5.dp)).padding(horizontal=8.dp,vertical=7.dp),verticalAlignment=Alignment.CenterVertically){
                        Text("P$position",color=if(t.id==teamId)Red else Muted,fontWeight=FontWeight.Black,modifier=Modifier.width(36.dp))
                        MovementBadge(movement,hasPrevious,Modifier.width(30.dp))
                        DriverPhoto(d.id,d.name,Modifier.size(36.dp).clip(RoundedCornerShape(6.dp)))
                        Spacer(Modifier.width(8.dp))
                        Text(d.name,color=Color.White,modifier=Modifier.weight(1f),maxLines=1,overflow=TextOverflow.Ellipsis)
                        TeamLogo(t.name,t.id,Modifier.size(24.dp))
                        Spacer(Modifier.width(7.dp))
                        Column(horizontalAlignment=Alignment.End){
                            Text("$pts PTS",color=Color.White,fontWeight=FontWeight.Black,fontSize=10.sp)
                            if(gap != null) Text("~ $gap",color=Muted,fontSize=8.sp)
                        }
                    }
                }
            }
        }else{
            LazyColumn(Modifier.weight(1f),contentPadding=PaddingValues(vertical=8.dp),verticalArrangement=Arrangement.spacedBy(3.dp)){
                items(constructors){(t,pts)->
                    val position = constructors.indexOfFirst{it.first.id==t.id}+1
                    val previous = previousConstructors[t.id]
                    val movement = if(hasPrevious && previous != null) previous-position else 0
                    val abovePoints = if(position > 1) constructors[position-2].second else null
                    val gap = abovePoints?.let { it - pts }
                    Row(Modifier.fillMaxWidth().background(if(t.id==teamId)Color(0xFF251414)else Panel,RoundedCornerShape(5.dp)).padding(horizontal=8.dp,vertical=8.dp),verticalAlignment=Alignment.CenterVertically){
                        Text("P$position",color=if(t.id==teamId)Red else Muted,fontWeight=FontWeight.Black,modifier=Modifier.width(36.dp))
                        MovementBadge(movement,hasPrevious,Modifier.width(30.dp))
                        TeamLogo(t.name,t.id,Modifier.size(28.dp))
                        Spacer(Modifier.width(7.dp))
                        Text(t.name,color=Color.White,modifier=Modifier.weight(1f),fontWeight=if(t.id==teamId)FontWeight.Black else FontWeight.Normal,maxLines=1,overflow=TextOverflow.Ellipsis)
                        Column(horizontalAlignment=Alignment.End){
                            Text("$pts PTS",color=Color.White,fontWeight=FontWeight.Black,fontSize=11.sp)
                            if(gap != null) Text("~ $gap",color=Muted,fontSize=8.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun Finance(store: CareerPreferences, teamId: Int, state:TeamManagerState, message:String, signSponsor:(SponsorContract)->Unit) {
    val baseOffers=listOf(
        listOf(SponsorContract("Apex Mobility",6_000_000,3_200_000,50_000,1,0,1,5,1_500_000,3,4_000_000), SponsorContract("Velocity Energy",4_500_000,2_400_000,40_000,1,0,1,7,1_000_000,5,2_500_000), SponsorContract("Atlas Global",3_000_000,1_900_000,30_000,1,0,1,10,750_000,8,1_500_000)),
        listOf(SponsorContract("Titan Motors",3_500_000,1_700_000,28_000,1,0,2,8,700_000,6,1_800_000), SponsorContract("Nova Bank",2_800_000,1_450_000,24_000,1,0,2,10,550_000,8,1_300_000), SponsorContract("Orion Tech",2_200_000,1_250_000,20_000,1,0,2,12,400_000,10,1_000_000)),
        listOf(SponsorContract("Vertex Systems",2_600_000,1_250_000,22_000,1,0,3,10,500_000,8,1_200_000), SponsorContract("Apex Fuel",2_000_000,1_050_000,18_000,1,0,3,12,350_000,10,900_000), SponsorContract("Pulse Mobile",1_600_000,900_000,15_000,1,0,3,15,250_000,12,700_000)),
        listOf(SponsorContract("Helix Finance",1_800_000,850_000,16_000,1,0,4,12,300_000,10,800_000), SponsorContract("Vector Energy",1_450_000,750_000,13_000,1,0,4,15,220_000,12,600_000), SponsorContract("Northstar",1_100_000,650_000,10_000,1,0,4,18,150_000,15,450_000)),
        listOf(SponsorContract("Falcon Media",1_250_000,550_000,9_000,1,0,5,15,180_000,12,500_000), SponsorContract("Quantum",950_000,480_000,8_000,1,0,5,18,130_000,15,350_000), SponsorContract("Velocity Labs",700_000,400_000,6_000,1,0,5,20,100_000,18,250_000))
    )
    // A duração de cada oferta é sorteada entre 1 e 10 GPs, mas permanece estável
    // enquanto a tela estiver aberta e durante a carreira atual.
    val offers = remember(teamId, store.season) {
        val rng = kotlin.random.Random(20261004 + teamId * 97 + store.season)
        baseOffers.map { slotOffers ->
            slotOffers.map { offer ->
                val duration = rng.nextInt(1, 11)
                offer.copy(races = duration, racesRemaining = duration)
            }
        }
    }
    LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
        item{
            HeaderBlock("FINANÇAS","ORÇAMENTO, RECEITAS E PATROCÍNIOS")
            Spacer(Modifier.height(4.dp))
            Text("Todos os valores usam € milhões ou € mil para facilitar a leitura.",color=Muted,fontSize=9.sp)
        }
        item{Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(Panel)){Column(Modifier.padding(14.dp)){
            Text("SALDO",color=Red,fontWeight=FontWeight.Black)
            Text(formatMoney(state.finance.budget),color=Color.White,fontSize=28.sp,fontWeight=FontWeight.Black)
            Text("Receitas da temporada: ${formatMoney(state.finance.seasonIncome)}",color=Green,fontSize=10.sp)
            Text("Despesas da temporada: ${formatMoney(state.finance.seasonExpenses)}",color=Muted,fontSize=10.sp)
            val activeCount=state.sponsors.count { it.active }
            Text("Patrocínios ativos: $activeCount/5",color=Color.White,fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=6.dp))
        }}}
        if(message.isNotBlank()) item{Text(message,color=Green,fontWeight=FontWeight.Bold,fontSize=10.sp)}
        item{SectionTitle("5 ESPAÇOS DE PATROCÍNIO")}
        items(offers.indices.toList()){slotIndex->
            val slot=slotIndex+1
            val signed=state.sponsors.firstOrNull { it.slot==slot && it.active }
            Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(Panel)){Column(Modifier.padding(12.dp)){
                Text(if(slot==1) "SLOT 1 • PRINCIPAL / MAIOR VALOR" else "SLOT $slot • PATROCINADOR SECUNDÁRIO",color=if(slot==1) Red else Color.White,fontWeight=FontWeight.Black)
                if(signed!=null) {
                    Text("ATIVO: ${signed.name}",color=Green,fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=5.dp))
                    Text("Entrada ${formatMoney(signed.upfront)} • ${formatMoney(signed.racePayment)}/GP • ${signed.racesRemaining}/${signed.races} corridas • ${formatMoney(signed.pointsBonus)}/ponto",color=Muted,fontSize=9.sp)
                    Text("Meta quali P${signed.qualifyingTarget}: +${formatMoney(signed.qualifyingBonus)} • Meta corrida P${signed.raceTarget}: +${formatMoney(signed.raceTargetBonus)}",color=Muted,fontSize=8.sp,modifier=Modifier.padding(top=3.dp))
                } else {
                    offers[slotIndex].forEach { o ->
                        Column(Modifier.padding(top=9.dp)){
                            Text(o.name,color=Color.White,fontWeight=FontWeight.Bold,fontSize=16.sp)
                            Text("Entrada ${formatMoney(o.upfront)} • ${formatMoney(o.racePayment)}/GP • ${formatMoney(o.pointsBonus)}/ponto",color=Muted,fontSize=9.sp)
                            Text("${o.races} ${if(o.races==1) "corrida" else "corridas"} • Meta quali P${o.qualifyingTarget}: +${formatMoney(o.qualifyingBonus)} • Meta corrida P${o.raceTarget}: +${formatMoney(o.raceTargetBonus)}",color=Muted,fontSize=8.sp)
                            Button(onClick={signSponsor(o)},modifier=Modifier.fillMaxWidth().padding(top=5.dp),colors=ButtonDefaults.buttonColors(containerColor=Red,contentColor=Color.White)){Text("ACEITAR ${o.name}",fontWeight=FontWeight.Black,fontSize=10.sp)}
                        }
                    }
                }
            }}
        }
        item{SectionTitle("COMO A EQUIPE GANHA DINHEIRO")}
        item{Text("Cada contrato paga a entrada no momento da assinatura, o valor por GP e os bônus de pontos/metas. Ao terminar a última corrida contratada, o espaço é liberado para um novo patrocínio.",color=Muted,fontSize=10.sp)}
    }
}

@Composable
private fun DriverMarket(
    store: CareerPreferences,
    teamId: Int,
    selectedDriverId: Int,
    state: DriverMarketState,
    message: String,
    onSelect: (Int) -> Unit,
    onInterest: (Int, Int?) -> Unit,
    onProposal: (Int, Int?, Int, Long, DriverTeamRole) -> Unit,
    onCounter: (com.f1teammanager.core.manager.DriverOffer, Int?, Int, Long, DriverTeamRole) -> Unit,
    onRenew: (Int, Int, Long, DriverTeamRole) -> Unit,
    onAcceptIncoming: (com.f1teammanager.core.manager.DriverOffer) -> Unit,
    onRejectIncoming: (com.f1teammanager.core.manager.DriverOffer) -> Unit,
    onScout: (Int) -> Unit
) {
    var replacementId by remember(teamId) { mutableIntStateOf(-1) }
    var filter by remember { mutableStateOf("TODOS") }
    var showProposal by remember { mutableIntStateOf(-1) }
    var years by remember { mutableIntStateOf(1) }
    var role by remember { mutableStateOf(DriverTeamRole.EQUAL) }
    var salaryText by remember { mutableStateOf("") }
    var counterOffer by remember { mutableStateOf<com.f1teammanager.core.manager.DriverOffer?>(null) }
    var renewDriver by remember { mutableIntStateOf(-1) }
    var scoutDriver by remember { mutableIntStateOf(-1) }

    val currentDeals = state.contracts.filter { it.teamId == teamId && it.activeIn(store.season) }
    val currentIds = currentDeals.map { it.driverId }.toSet()
    val scheduledIds = state.scheduled.map { it.driverId }.toSet()
    val visibleIds = when (filter) {
        "LIVRES" -> state.freeAgents
        "CONTRATADOS" -> state.contracts.map { it.driverId }
        "MINHA EQUIPE" -> currentIds.toList()
        "NEGOCIÁVEIS" -> WorldDatabase.allDrivers.map { it.id }.filter { DriverMarketEngine().canReceiveProposals(state, it, store.season) }
        "FUTUROS" -> scheduledIds.toList()
        else -> WorldDatabase.allDrivers.map { it.id }
    }.distinct()

    val rows = visibleIds.mapNotNull { id ->
        val d = runCatching { store.driverDefinition(id) }.getOrNull() ?: return@mapNotNull null
        val deal = state.contracts.firstOrNull { it.driverId == id && it.activeIn(store.season) }
        val future = state.scheduled.firstOrNull { it.driverId == id }
        Triple(d, deal, future)
    }.sortedWith(compareByDescending<Triple<com.f1teammanager.core.season.DriverDefinition, com.f1teammanager.core.manager.DriverDeal?, com.f1teammanager.core.manager.FutureDriverDeal?>> { (it.first.speed+it.first.qualifying+it.first.overtaking+it.first.defense+it.first.consistency+it.first.wet+it.first.tyre)/7 }.thenBy { it.first.name })

    Column(Modifier.fillMaxSize().padding(12.dp)) {
        HeaderBlock("MERCADO DE PILOTOS", "100 PILOTOS • 40 EQUIPES • TRANSFERÊNCIAS SOMENTE NA PRÓXIMA TEMPORADA")
        Text("${currentDeals.size}/2 pilotos na equipe  •  ${state.freeAgents.size} fora do grid  •  ${state.scheduled.count { it.startSeason == store.season + 1 }} transferências para ${store.season + 1}", color=Muted, fontSize=9.sp)
        if (message.isNotBlank()) Text(message, color=Green, fontSize=10.sp, modifier=Modifier.padding(vertical=6.dp))

        if (currentDeals.size >= 2) {
            Text("Escolha o piloto que será substituído na próxima contratação. A seleção permanece ativa até você escolher outro.", color=Muted, fontSize=9.sp, modifier=Modifier.padding(vertical=4.dp))
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement=Arrangement.spacedBy(5.dp)) {
                currentDeals.forEach { deal ->
                    val name = WorldDatabase.allDrivers.firstOrNull { it.id == deal.driverId }?.name ?: "Piloto ${deal.driverId}"
                    val reserved = state.scheduled.any { it.toTeamId == teamId && it.replaceDriverId == deal.driverId }
                    OutlinedButton(onClick={if(!reserved) replacementId=deal.driverId}, enabled=!reserved, border=BorderStroke(1.dp, if(replacementId==deal.driverId) Red else Line), contentPadding=PaddingValues(horizontal=8.dp,vertical=3.dp)) { Text(if(reserved) "✓ $name • RESERVADO" else if(replacementId==deal.driverId) "✓ $name" else name, fontSize=8.sp, color=Color.White) }
                }
            }
        }

        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(vertical=6.dp), horizontalArrangement=Arrangement.spacedBy(5.dp)) {
            listOf("TODOS","LIVRES","CONTRATADOS","MINHA EQUIPE","NEGOCIÁVEIS","FUTUROS").forEach { f ->
                FilterChip(selected=filter==f,onClick={filter=f},label={Text(f,fontSize=8.sp)},colors=FilterChipDefaults.filterChipColors(selectedContainerColor=Red,selectedLabelColor=Color.White))
            }
        }

        val counters = state.pending.filter { it.toTeamId == teamId && it.status == NegotiationStatus.COUNTER && it.seasonTarget == store.season + 1 }
        if (counters.isNotEmpty()) {
            Card(Modifier.fillMaxWidth().padding(vertical=4.dp), colors=CardDefaults.cardColors(containerColor=Color(0xFF211817))) {
                Column(Modifier.padding(9.dp), verticalArrangement=Arrangement.spacedBy(5.dp)) {
                    Text("CONTRAPROPOSTAS PENDENTES", color=Color.White, fontWeight=FontWeight.Black, fontSize=10.sp)
                    counters.takeLast(3).forEach { offer ->
                        val name=WorldDatabase.allDrivers.firstOrNull { it.id==offer.driverId }?.name ?: "Piloto ${offer.driverId}"
                        Row(Modifier.fillMaxWidth(), verticalAlignment=Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) { Text(name,color=Color.White,fontWeight=FontWeight.Bold,fontSize=9.sp); Text("Rodada ${offer.round}/3 • ${formatMoney(offer.salary)}/ano • ${offer.years} ano(s)",color=Muted,fontSize=8.sp) }
                            Button(onClick={ counterOffer=offer; salaryText=offer.salary.toString(); years=offer.years; role=offer.role },colors=ButtonDefaults.buttonColors(containerColor=Red),contentPadding=PaddingValues(horizontal=8.dp,vertical=2.dp)) { Text("RESPONDER",fontSize=8.sp) }
                        }
                    }
                }
            }
        }

        val incoming = state.pending.filter { it.fromTeamId == teamId && it.status == NegotiationStatus.PENDING && it.seasonTarget == store.season + 1 }
        if (incoming.isNotEmpty()) {
            Card(Modifier.fillMaxWidth().padding(vertical=4.dp), colors=CardDefaults.cardColors(containerColor=Color(0xFF211817))) {
                Column(Modifier.padding(9.dp), verticalArrangement=Arrangement.spacedBy(5.dp)) {
                    Text("OFERTAS RECEBIDAS", color=Color.White, fontWeight=FontWeight.Black, fontSize=10.sp)
                    incoming.takeLast(5).forEach { offer ->
                        val name=WorldDatabase.allDrivers.firstOrNull { it.id==offer.driverId }?.name ?: "Piloto ${offer.driverId}"
                        val teamName=WorldDatabase.teams.firstOrNull { it.id==offer.toTeamId }?.name ?: "Equipe ${offer.toTeamId}"
                        Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){
                            Column(Modifier.weight(1f)){ Text("$name → $teamName",color=Color.White,fontWeight=FontWeight.Bold,fontSize=9.sp); Text("${offer.years} ano(s) • ${formatMoney(offer.salary)}/ano • válida até semana ${offer.expiresAfterWeek}",color=Muted,fontSize=8.sp) }
                            TextButton(onClick={onRejectIncoming(offer)}){Text("RECUSAR",color=Muted,fontSize=8.sp)}
                            Button(onClick={onAcceptIncoming(offer)},colors=ButtonDefaults.buttonColors(containerColor=Red),contentPadding=PaddingValues(horizontal=7.dp,vertical=2.dp)){Text("ACEITAR",fontSize=8.sp)}
                        }
                    }
                }
            }
        }

        LazyColumn(Modifier.weight(1f), contentPadding=PaddingValues(vertical=4.dp), verticalArrangement=Arrangement.spacedBy(5.dp)) {
            items(rows) { (d, deal, future) ->
                val selected = selectedDriverId == d.id
                val overall=(d.speed+d.qualifying+d.overtaking+d.defense+d.consistency+d.wet+d.tyre)/7
                val canTalk=DriverMarketEngine().canReceiveProposals(state,d.id,store.season)
                Card(Modifier.fillMaxWidth().clickable { onSelect(d.id) }, colors=CardDefaults.cardColors(if(selected) Color(0xFF251414) else Panel)) {
                    Column(Modifier.fillMaxWidth().padding(9.dp)) {
                        Row(verticalAlignment=Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(d.name,color=Color.White,fontWeight=FontWeight.Bold,maxLines=1,overflow=TextOverflow.Ellipsis)
                                Text("Overall $overall • ${d.driverClass} • ${d.evolution}",color=Muted,fontSize=8.sp)
                            }
                            val status=when {
                                future!=null -> "→ ${future.startSeason}"
                                deal==null -> "LIVRE"
                                deal.teamId==teamId -> "SUA EQUIPE"
                                else -> "CONTRATO"
                            }
                            Text(status,color=if(future!=null) Green else Color.White,fontSize=8.sp,fontWeight=FontWeight.Bold)
                        }
                        if (deal != null) {
                            val year=deal.contractYear(store.season)
                            val currentTeamName=WorldDatabase.teams.firstOrNull { it.id==deal.teamId }?.name ?: "Equipe ${deal.teamId}"
                            Text("Equipe atual: $currentTeamName",color=Color.White,fontSize=8.sp,fontWeight=FontWeight.Bold)
                            Text("Contrato ${deal.years} ano(s) • ano $year/${deal.years} • salário ${formatMoney(deal.salary)} • ${when(deal.role){DriverTeamRole.PILOT_1->"PILOTO 1";DriverTeamRole.PILOT_2->"PILOTO 2";DriverTeamRole.EQUAL->"IGUAIS"}}",color=Muted,fontSize=8.sp)
                            Text(if(deal.canReceiveProposals(store.season)) "Último ano: pode receber propostas e renovar" else "Contrato protegido até o último ano",color=if(deal.canReceiveProposals(store.season)) Green else Muted,fontSize=8.sp)
                        }
                        if (future!=null) {
                            val nextTeamName=WorldDatabase.teams.firstOrNull { it.id==future.toTeamId }?.name ?: "Equipe ${future.toTeamId}"
                            Text("Próxima equipe: $nextTeamName • ${future.startSeason} • ${future.years} ano(s)",color=Green,fontSize=8.sp,fontWeight=FontWeight.Bold)
                            future.replaceDriverId?.let { rid ->
                                val rn=WorldDatabase.allDrivers.firstOrNull { it.id==rid }?.name ?: "Piloto $rid"
                                Text("Substitui: $rn",color=Muted,fontSize=8.sp)
                            }
                        }
                        if (d.id in currentIds && deal != null && deal.contractYear(store.season) == deal.years && future == null) {
                            Row(horizontalArrangement=Arrangement.spacedBy(5.dp)) {
                                Button(onClick={salaryText=deal.salary.toString();years=deal.years;role=deal.role;renewDriver=d.id},colors=ButtonDefaults.buttonColors(containerColor=Red),contentPadding=PaddingValues(horizontal=10.dp,vertical=3.dp)){Text("RENOVAR",fontSize=8.sp,fontWeight=FontWeight.Black)}
                            }
                        }
                        if (d.id !in currentIds) {
                            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(5.dp),verticalAlignment=Alignment.CenterVertically) {
                                OutlinedButton(onClick={onScout(d.id);scoutDriver=-1},border=BorderStroke(1.dp,Line),contentPadding=PaddingValues(horizontal=8.dp,vertical=2.dp)) { Text("SCOUT",fontSize=8.sp) }
                                if (canTalk) Button(onClick={salaryText=DriverMarketEngine().salaryFor(d.id).toString();years=1;role=DriverTeamRole.EQUAL;showProposal=d.id},colors=ButtonDefaults.buttonColors(containerColor=Red,contentColor=Color.White),contentPadding=PaddingValues(horizontal=10.dp,vertical=3.dp)) { Text("NEGOCIAR",fontSize=8.sp,fontWeight=FontWeight.Black) }
                            }
                        }
                    }
                }
            }
        }

        if (showProposal > 0) {
            val d=WorldDatabase.allDrivers.firstOrNull { it.id==showProposal }
            if (d != null) {
                AlertDialog(onDismissRequest={showProposal=-1},title={Text("PROPOSTA • ${d.name}",fontWeight=FontWeight.Black)},text={
                    Column(verticalArrangement=Arrangement.spacedBy(7.dp)) {
                        Text("A proposta vale para ${store.season+1}. O piloto permanece na equipe atual até o fim da temporada.",color=Muted,fontSize=10.sp)
                        Text("Duração",color=Color.White,fontWeight=FontWeight.Bold,fontSize=10.sp)
                        Row(horizontalArrangement=Arrangement.spacedBy(5.dp)) { listOf(1,2,3,4,5).forEach { y -> FilterChip(selected=years==y,onClick={years=y},label={Text("$y ano",fontSize=9.sp)}) } }
                        Text("Papel",color=Color.White,fontWeight=FontWeight.Bold,fontSize=10.sp)
                        Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(5.dp)) { listOf(DriverTeamRole.PILOT_1,DriverTeamRole.PILOT_2,DriverTeamRole.EQUAL).forEach { r -> FilterChip(selected=role==r,onClick={role=r},label={Text(when(r){DriverTeamRole.PILOT_1->"Piloto 1";DriverTeamRole.PILOT_2->"Piloto 2";DriverTeamRole.EQUAL->"Iguais"},fontSize=9.sp)}) } }
                        Text("Salário anual",color=Color.White,fontWeight=FontWeight.Bold,fontSize=10.sp)
                        OutlinedTextField(value=salaryText,onValueChange={salaryText=it.filter(Char::isDigit)},singleLine=true,label={Text("Valor")})
                        Text("Valor de mercado e salário são referências separadas. Não existe multa contratual; a decisão financeira é do gestor.",color=Muted,fontSize=8.sp)
                    }
                },confirmButton={Button(onClick={val salary=salaryText.toLongOrNull() ?: 0L; if(salary>0){onProposal(d.id,if(currentDeals.size>=2) replacementId.takeIf{it>0} else null,years,salary,role);showProposal=-1}},colors=ButtonDefaults.buttonColors(containerColor=Red)){Text("ENVIAR PROPOSTA")}},dismissButton={TextButton(onClick={showProposal=-1}){Text("CANCELAR")}})
            }
        }

        if (renewDriver > 0) {
            val d=WorldDatabase.allDrivers.firstOrNull { it.id==renewDriver }
            if(d!=null) AlertDialog(onDismissRequest={renewDriver=-1},title={Text("RENOVAR • ${d.name}",fontWeight=FontWeight.Black)},text={
                Column(verticalArrangement=Arrangement.spacedBy(7.dp)){
                    Text("A renovação começa em ${store.season+1}. O contrato atual continua válido até o fim desta temporada.",color=Muted,fontSize=9.sp)
                    Text("Duração",fontWeight=FontWeight.Bold,fontSize=10.sp)
                    Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(4.dp)){listOf(1,2,3,4,5).forEach{y->FilterChip(selected=years==y,onClick={years=y},label={Text("$y ano",fontSize=8.sp)})}}
                    Text("Papel",fontWeight=FontWeight.Bold,fontSize=10.sp)
                    Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(4.dp)){listOf(DriverTeamRole.PILOT_1,DriverTeamRole.PILOT_2,DriverTeamRole.EQUAL).forEach{r->FilterChip(selected=role==r,onClick={role=r},label={Text(when(r){DriverTeamRole.PILOT_1->"Piloto 1";DriverTeamRole.PILOT_2->"Piloto 2";DriverTeamRole.EQUAL->"Iguais"},fontSize=8.sp)})}}
                    Text("Salário anual",fontWeight=FontWeight.Bold,fontSize=10.sp)
                    OutlinedTextField(value=salaryText,onValueChange={salaryText=it.filter(Char::isDigit)},singleLine=true)
                }
            },confirmButton={Button(onClick={val salary=salaryText.toLongOrNull()?:0L;if(salary>0){onRenew(d.id,years,salary,role);renewDriver=-1}},colors=ButtonDefaults.buttonColors(containerColor=Red)){Text("CONFIRMAR RENOVAÇÃO")}},dismissButton={TextButton(onClick={renewDriver=-1}){Text("CANCELAR")}})
        }

        if (counterOffer != null) {
            val offer=counterOffer!!
            val d=WorldDatabase.allDrivers.firstOrNull { it.id==offer.driverId }
            if (d!=null) AlertDialog(onDismissRequest={counterOffer=null},title={Text("CONTRAPROPOSTA • ${d.name}",fontWeight=FontWeight.Black)},text={
                Column(verticalArrangement=Arrangement.spacedBy(7.dp)) {
                    Text("Rodada ${offer.round}/3 • válida até a semana ${offer.expiresAfterWeek} • início em ${offer.seasonTarget}",color=Muted,fontSize=9.sp)
                    Text("O piloto continua na equipe atual até o fim da temporada.",color=Muted,fontSize=9.sp)
                    Text("Novo salário anual",fontWeight=FontWeight.Bold,fontSize=10.sp)
                    OutlinedTextField(value=salaryText,onValueChange={salaryText=it.filter(Char::isDigit)},singleLine=true)
                    Text("Duração",fontWeight=FontWeight.Bold,fontSize=10.sp)
                    Row(horizontalArrangement=Arrangement.spacedBy(4.dp)){listOf(1,2,3,4,5).forEach{y->FilterChip(selected=years==y,onClick={years=y},label={Text("$y ano",fontSize=8.sp)})}}
                    Text("Papel",fontWeight=FontWeight.Bold,fontSize=10.sp)
                    Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(4.dp)){listOf(DriverTeamRole.PILOT_1,DriverTeamRole.PILOT_2,DriverTeamRole.EQUAL).forEach{r->FilterChip(selected=role==r,onClick={role=r},label={Text(when(r){DriverTeamRole.PILOT_1->"Piloto 1";DriverTeamRole.PILOT_2->"Piloto 2";DriverTeamRole.EQUAL->"Iguais"},fontSize=8.sp)})}}
                }
            },confirmButton={Button(onClick={val salary=salaryText.toLongOrNull()?:0L;if(salary>0){onCounter(offer,if(currentDeals.size>=2)replacementId.takeIf{it>0} else null,years,salary,role);counterOffer=null}},colors=ButtonDefaults.buttonColors(containerColor=Red)){Text("ENVIAR")}},dismissButton={TextButton(onClick={counterOffer=null}){Text("CANCELAR")}})
        }

        if (scoutDriver > 0) {
            val d=WorldDatabase.allDrivers.firstOrNull { it.id==scoutDriver }
            if(d!=null) AlertDialog(onDismissRequest={scoutDriver=-1},title={Text("SCOUT • ${d.name}",fontWeight=FontWeight.Black)},text={
                Column(verticalArrangement=Arrangement.spacedBy(6.dp)){
                    Text("Relatório de scouting completo.",color=Color.White,fontSize=10.sp,fontWeight=FontWeight.Bold)
                    Text("Custo: US$ 0,5M • validade: 4 semanas",color=Muted,fontSize=9.sp)
                    Text("Revela salário esperado, valor de mercado, preferência de papel, interesse e tendência. Não existe multa contratual. Não garante contratação.",color=Muted,fontSize=9.sp)
                }
            },confirmButton={Button(onClick={onScout(d.id);scoutDriver=-1},colors=ButtonDefaults.buttonColors(containerColor=Red)){Text("REALIZAR SCOUT")}},dismissButton={TextButton(onClick={scoutDriver=-1}){Text("CANCELAR")}})
        }
    }
}

@Composable
private fun MarketNews(state: DriverMarketState, season: Int) {
    val items = state.notifications.filter { it.season <= season }.reversed()
    LazyColumn(Modifier.fillMaxSize().padding(12.dp), contentPadding=PaddingValues(bottom=20.dp), verticalArrangement=Arrangement.spacedBy(7.dp)) {
        item {
            HeaderBlock("CENTRAL DE NOTÍCIAS", "MERCADO • TRANSFERÊNCIAS • RENOVAÇÕES")
            Text("Aqui aparecem as movimentações importantes do mercado da sua carreira.", color=Muted, fontSize=9.sp)
        }
        if (items.isEmpty()) item { Text("Nenhuma notícia do mercado ainda.", color=Muted, modifier=Modifier.padding(top=12.dp)) }
        items(items.take(100)) { n ->
            Card(Modifier.fillMaxWidth(), colors=CardDefaults.cardColors(if(n.important) Color(0xFF211817) else Panel)) {
                Column(Modifier.padding(10.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween) {
                        Text(n.title, color=if(n.important) Red else Color.White, fontWeight=FontWeight.Black, fontSize=9.sp)
                        Text("${n.season} • SEM ${n.week}", color=Muted, fontSize=8.sp)
                    }
                    Text(n.message, color=Color.White, fontSize=10.sp, modifier=Modifier.padding(top=4.dp))
                }
            }
        }
    }
}

@Composable
private fun ManagementHub(
    raceActive: Boolean,
    onDrivers: () -> Unit,
    onMarket: () -> Unit,
    onFinance: () -> Unit,
    onSeason: () -> Unit,
    onCar: () -> Unit,
    onStandings: () -> Unit,
    onCalendar: () -> Unit,
    onWeekend: () -> Unit,
    onRace: () -> Unit,
    onHistory: () -> Unit,
    onNews: () -> Unit,
    onHallOfFame: () -> Unit,
    onRecords: () -> Unit
) {
    val actions = listOf(
        "FIM DE SEMANA" to onWeekend,
        "PILOTOS" to onDrivers,
        "MERCADO" to onMarket,
        "CENTRAL DE NOTÍCIAS" to onNews,
        "CARRO / P&D" to onCar,
        "CAMPEONATO" to onStandings,
        "CALENDÁRIO" to onCalendar,
        "FINANÇAS" to onFinance,
        "TEMPORADA" to onSeason,
        "HISTÓRIA" to onHistory,
        "HALL DA FAMA" to onHallOfFame,
        "RECORDES" to onRecords
    )
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        HeaderBlock("CENTRAL DE GESTÃO", if (raceActive) "CORRIDA ATIVA" else "TEMPORADA")
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(vertical = 10.dp)) {
            items(actions) { (label, action) ->
                Button(onClick = action, modifier = Modifier.fillMaxWidth().height(46.dp), colors = ButtonDefaults.buttonColors(containerColor = if (label == "PIT WALL" && raceActive) Red else Panel2, contentColor = Color.White)) {
                    Text(label, fontWeight = FontWeight.Black, fontSize = 11.sp)
                }
            }
        }
    }
}

private fun strategyLabel(m:DriverStrategyMode)=when(m){DriverStrategyMode.ATTACK->"ATAQUE";DriverStrategyMode.BALANCED->"EQUILIBRADO";DriverStrategyMode.DEFENSE->"DEFESA / ECONOMIA"}
private fun tyreLabel(t:Tyre)=when(t){Tyre.SOFT->"SOFT";Tyre.MEDIUM->"MEDIUM";Tyre.HARD->"HARD";Tyre.INTERMEDIATE->"INTER";Tyre.WET->"WET"}
private fun weatherLabel(w:Weather)=when(w){Weather.DRY->"☀️ SOL";Weather.CLOUDY->"☁️ NUBLADO";Weather.LIGHT_RAIN->"🌦️ CHUVA FRACA • INTERMEDIÁRIO";Weather.MEDIUM_RAIN->"🌧️ CHUVA MÉDIA • INTERMEDIÁRIO";Weather.HEAVY_RAIN->"🌧️ CHUVA FORTE • WET"}
private fun statusLabel(n:Neutralisation)=when(n){Neutralisation.GREEN->"GREEN FLAG";Neutralisation.VSC->"VSC";Neutralisation.SAFETY_CAR->"SAFETY CAR"}
private fun tyreLifeEstimate(tyre:Tyre, weather:Weather, mode:DriverStrategyMode, driverTyreWear:Int = 50):Int {
    val weatherFactor=when(weather){
        Weather.DRY -> 1.00
        Weather.CLOUDY -> when(tyre){Tyre.SOFT,Tyre.MEDIUM,Tyre.HARD->0.95;Tyre.INTERMEDIATE,Tyre.WET->1.20}
        Weather.LIGHT_RAIN,Weather.MEDIUM_RAIN -> when(tyre){Tyre.SOFT,Tyre.MEDIUM,Tyre.HARD->0.72;Tyre.INTERMEDIATE,Tyre.WET->0.90}
        Weather.HEAVY_RAIN -> when(tyre){Tyre.SOFT,Tyre.MEDIUM,Tyre.HARD->0.55;Tyre.INTERMEDIATE->0.88;Tyre.WET->0.35}
    }
    val strategyFactor=when(mode){DriverStrategyMode.ATTACK->1.10;DriverStrategyMode.BALANCED->1.00;DriverStrategyMode.DEFENSE->0.90}
    val driverFactor=(1.10-((driverTyreWear.coerceIn(1,100)-50)*0.002)).coerceIn(0.90,1.10)
    return kotlin.math.floor((tyre.targetLaps/(weatherFactor*strategyFactor*driverFactor)).toDouble() + 0.000001).toInt().coerceAtLeast(1).coerceAtMost(tyre.targetLaps)
}

private fun actionLabel(a:ManagerDecisionAction)=when(a){ManagerDecisionAction.BOX->"BOX";ManagerDecisionAction.STAY_OUT->"MANTER";ManagerDecisionAction.EXTEND_STINT->"ESTENDER STINT";ManagerDecisionAction.SAVE_FUEL->"POUPAR COMBUSTÍVEL";ManagerDecisionAction.CHANGE_STRATEGY->"MUDAR ESTRATÉGIA";ManagerDecisionAction.RESTART_ATTACK->"RELARGADA • ATAQUE";ManagerDecisionAction.RESTART_BALANCED->"RELARGADA • EQUILIBRADO";ManagerDecisionAction.RESTART_DEFENSE->"RELARGADA • DEFESA";ManagerDecisionAction.CHANGE_TYRE_SOFT->"SOFT";ManagerDecisionAction.CHANGE_TYRE_MEDIUM->"MEDIUM";ManagerDecisionAction.CHANGE_TYRE_HARD->"HARD";ManagerDecisionAction.CHANGE_TYRE_INTERMEDIATE->"INTERMEDIÁRIO";ManagerDecisionAction.CHANGE_TYRE_WET->"WET"}
private fun constructorPosition(teamId:Int, store:CareerPreferences): Int {
    val points = store.constructorPoints()
    val rows = WorldDatabase.teams.map { it.id to (points[it.id] ?: 0) }
        .sortedWith(compareByDescending<Pair<Int,Int>> { it.second }.thenBy { it.first })
    return rows.indexOfFirst { it.first == teamId }.let { if (it >= 0) it + 1 else WorldDatabase.teams.indexOfFirst { it.id == teamId } + 1 }
}
private fun driverChampionshipPosition(driverId:Int, store:CareerPreferences): Int {
    val points = store.driverPoints()
    val rows = WorldDatabase.drivers.map { it.id to (points[it.id] ?: 0) }
        .sortedWith(compareByDescending<Pair<Int,Int>> { it.second }.thenBy { it.first })
    return rows.indexOfFirst { it.first == driverId }.let { if (it >= 0) it + 1 else WorldDatabase.drivers.indexOfFirst { it.id == driverId } + 1 }
}

private fun planDescription(plan:TyrePlan?): String = plan?.let {
    it.sequence.indices.joinToString(" → ") { i -> "${tyreLabel(it.sequence[i])} ${it.stintLaps.getOrElse(i) { 0 }}v" }
} ?: "Plano indisponível"

@Composable
private fun SectionTitle(title:String) {
    Text(
        title,
        color = Red,
        fontSize = 11.sp,
        fontWeight = FontWeight.Black,
        modifier = Modifier.padding(top = 2.dp, bottom = 1.dp)
    )
}

@Composable
private fun StatCard(title:String, value:String, subtitle:String, modifier:Modifier = Modifier) {
    Column(
        modifier = modifier
            .background(Panel2, RoundedCornerShape(8.dp))
            .padding(9.dp)
    ) {
        Text(title, color = Muted, fontSize = 8.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(value, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Black, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 3.dp))
        Text(subtitle, color = Muted, fontSize = 8.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 2.dp))
    }
}

@Composable
private fun HeaderBlock(title:String, subtitle:String) {
    Column(Modifier.fillMaxWidth().padding(bottom = 6.dp)) {
        Text(title, color=Color.White, fontSize=22.sp, fontWeight=FontWeight.Black, maxLines=1, overflow=TextOverflow.Ellipsis)
        Text(subtitle, color=Red, fontSize=10.sp, fontWeight=FontWeight.Bold)
    }
}

private fun formatMoney(value:Long):String {
    val sign = if (value < 0) "-" else ""
    val abs = kotlin.math.abs(value)
    return when {
        abs >= 1_000_000L -> {
            val millions = abs / 1_000_000L
            val thousands = (abs % 1_000_000L) / 1_000L
            if (thousands == 0L) "€ ${sign}${millions} M"
            else "€ ${sign}${millions},${(thousands / 100).coerceAtLeast(1)} M"
        }
        abs >= 1_000L -> "€ ${sign}${abs / 1_000L} mil"
        else -> "€ ${sign}${abs}"
    }
}

private fun formatMs(ms:Long)="%d:%02d.%03d".format(ms/60000,(ms/1000)%60,ms%1000)
