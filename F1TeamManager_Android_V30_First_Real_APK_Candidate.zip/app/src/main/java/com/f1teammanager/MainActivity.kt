package com.f1teammanager

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.f1teammanager.core.race.*
import com.f1teammanager.core.manager.DriverMarketEngine
import com.f1teammanager.core.manager.DriverMarketState
import com.f1teammanager.core.season.CarCatalog
import com.f1teammanager.core.season.RoundDefinition
import com.f1teammanager.core.season.WorldDatabase
import com.f1teammanager.core.season.toParticipant

private val Bg = Color(0xFF08090C)
private val Panel = Color(0xFF14161B)
private val Panel2 = Color(0xFF1B1E24)
private val Red = Color(0xFFE10600)
private val Muted = Color(0xFF8D929C)
private val Line = Color(0xFF2B2F36)
private val Green = Color(0xFF38C878)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { F1ManagerApp(CareerPreferences(this)) }
    }
}

private enum class Screen { HOME, TEAM, DRIVERS, CAR, CALENDAR, STANDINGS, FINANCE, MARKET, WEEKEND, QUALIFYING, RACE, RESULT, MANAGEMENT, SELECT_TEAM }
private enum class Nav { HOME, TEAM, CAR, CALENDAR, STANDINGS }

@Composable
private fun F1ManagerApp(store: CareerPreferences) {
    var hasCareer by remember { mutableStateOf(store.hasCareer) }
    var teamId by remember { mutableIntStateOf(store.teamId) }
    var roundIndex by remember { mutableIntStateOf(store.roundIndex) }
    var screen by remember { mutableStateOf(if (hasCareer) Screen.HOME else Screen.SELECT_TEAM) }
    var nav by remember { mutableStateOf(Nav.HOME) }
    var selectedMode by remember { mutableStateOf(DriverStrategyMode.BALANCED) }
    var selectedTyre by remember { mutableStateOf(Tyre.MEDIUM) }
    var snapshot by remember { mutableStateOf<CareerWeekendEngine.SessionSnapshot?>(null) }
    var result by remember { mutableStateOf<RaceResult?>(null) }
    var marketDriverId by remember { mutableIntStateOf(-1) }
    var marketState by remember { mutableStateOf(DriverMarketEngine(20261003).initialState(store.season)) }
    var marketMessage by remember { mutableStateOf("") }
    val marketEngine = remember { DriverMarketEngine(20261003) }
    val engine = remember { CareerWeekendEngine(20261003) }
    val team = WorldDatabase.teams.firstOrNull { it.id == teamId } ?: WorldDatabase.teams.first()
    val drivers = WorldDatabase.drivers.filter { it.teamId == team.id }
    val round = WorldDatabase.rounds.getOrElse(roundIndex) { WorldDatabase.rounds.first() }

    fun participants() = WorldDatabase.drivers.map { d ->
        val t = WorldDatabase.teams.first { it.id == d.teamId }
        d.toParticipant(t)
    }
    fun circuit() = RaceCircuit(round.round, round.circuit, round.laps, round.baseLapTimeMs, round.powerFactor, round.overtakingFactor, round.crashRisk, round.reliabilityRisk, round.safetyCarRisk)
    fun startWeekend() {
        if (snapshot != null && snapshot?.completed == false && snapshot?.phase == "RACE") { screen = Screen.RACE; return }
        snapshot = engine.start(participants(), circuit(), team.id); result = null; screen = Screen.QUALIFYING
    }
    fun startRace() { drivers.forEach { engine.setPlan(it.id, selectedMode, selectedTyre) }; snapshot = engine.snapshotForUi(); screen = Screen.RACE }
    fun advanceRace() {
        snapshot = engine.advance()
        if (snapshot?.completed == true) {
            result = engine.result()
            store.recordRace(result!!)
            screen = Screen.RESULT
        }
    }
    fun nextRound() { snapshot = null; result = null; store.advanceRound(); roundIndex = store.roundIndex; screen = Screen.HOME; nav = Nav.HOME }
    fun makeMarketInterest(driverId: Int) {
        val driver = WorldDatabase.allDrivers.first { it.id == driverId }
        val from = driver.teamId
        val years = if (from == 0) 2 else 1
        val salary = marketEngine.salaryFor(driverId)
        runCatching {
            val (next, offer) = marketEngine.offer(marketState, driverId, from, team.id, years, salary, season = store.season)
            marketState = next
            marketMessage = if (offer.accepted) "Negociação aceita: ${driver.name}. Pré-contrato registrado." else "Interesse registrado por ${driver.name}; negociação ainda não aceita."
        }.onFailure { marketMessage = it.message ?: "Não foi possível negociar agora." }
    }
    fun selectTeam(id: Int) { store.startNewCareer(id); marketState = marketEngine.initialState(2026); marketMessage = ""; teamId = id; roundIndex = 0; hasCareer = true; screen = Screen.HOME; nav = Nav.HOME }

    MaterialTheme(colorScheme = darkColorScheme(background = Bg, surface = Panel, primary = Red, onPrimary = Color.White, onSurface = Color.White)) {
        Surface(Modifier.fillMaxSize(), color = Bg) {
            when (screen) {
                Screen.SELECT_TEAM -> TeamSelect(::selectTeam)
                Screen.HOME -> AppScaffold("${team.name.uppercase()} • 2026", nav, { nav = it; screen = when(it){Nav.HOME->Screen.HOME;Nav.TEAM->Screen.TEAM;Nav.CAR->Screen.CAR;Nav.CALENDAR->Screen.CALENDAR;Nav.STANDINGS->Screen.STANDINGS} }, onMore={ screen=Screen.MANAGEMENT }) { Home(team.name, CarCatalog.forTeam(team.id), drivers, round, store, snapshot?.phase == "RACE" && snapshot?.completed == false, onStart=::startWeekend, onDrivers={screen=Screen.DRIVERS}, onWeekend={screen=Screen.WEEKEND}, onMarket={screen=Screen.MARKET}, onFinance={screen=Screen.FINANCE}, onStandings={screen=Screen.STANDINGS}, onCar={nav=Nav.CAR;screen=Screen.CAR}) }
                Screen.TEAM -> AppScaffold("EQUIPE", nav, { nav=it; screen=when(it){Nav.HOME->Screen.HOME;Nav.TEAM->Screen.TEAM;Nav.CAR->Screen.CAR;Nav.CALENDAR->Screen.CALENDAR;Nav.STANDINGS->Screen.STANDINGS} }, onMore={screen=Screen.MANAGEMENT}) { Team(team.name, team.engine, team.reliability, drivers, onDrivers={screen=Screen.DRIVERS}, onMarket={screen=Screen.MARKET}) }
                Screen.DRIVERS -> DetailScaffold("PILOTOS", {screen=Screen.TEAM}) { Drivers(drivers) }
                Screen.CAR -> AppScaffold("CARRO", nav, { nav=it; screen=when(it){Nav.HOME->Screen.HOME;Nav.TEAM->Screen.TEAM;Nav.CAR->Screen.CAR;Nav.CALENDAR->Screen.CALENDAR;Nav.STANDINGS->Screen.STANDINGS} }, onMore={screen=Screen.MANAGEMENT}) { Car(CarCatalog.forTeam(team.id), team.engine, team.reliability) }
                Screen.CALENDAR -> AppScaffold("CALENDÁRIO", nav, { nav=it; screen=when(it){Nav.HOME->Screen.HOME;Nav.TEAM->Screen.TEAM;Nav.CAR->Screen.CAR;Nav.CALENDAR->Screen.CALENDAR;Nav.STANDINGS->Screen.STANDINGS} }, onMore={screen=Screen.MANAGEMENT}) { Calendar(roundIndex) }
                Screen.STANDINGS -> AppScaffold("CAMPEONATO", nav, { nav=it; screen=when(it){Nav.HOME->Screen.HOME;Nav.TEAM->Screen.TEAM;Nav.CAR->Screen.CAR;Nav.CALENDAR->Screen.CALENDAR;Nav.STANDINGS->Screen.STANDINGS} }, onMore={screen=Screen.MANAGEMENT}) { Standings(team.id, store) }
                Screen.FINANCE -> DetailScaffold("FINANÇAS", {screen=Screen.HOME}) { Finance(store) }
                Screen.MARKET -> DetailScaffold("MERCADO DE PILOTOS", {screen=Screen.TEAM}) { DriverMarket(store, team.id, marketDriverId, marketState, marketMessage, { marketDriverId = it }, ::makeMarketInterest) }
                Screen.WEEKEND -> DetailScaffold("FIM DE SEMANA", {screen=Screen.HOME}) { Weekend(round, ::startWeekend) }
                Screen.QUALIFYING -> DetailScaffold("QUALIFICAÇÃO", { screen = Screen.HOME }) { Qualifying(snapshot!!, selectedMode, selectedTyre, {selectedMode=it}, {selectedTyre=it}, ::startRace) }
                Screen.RACE -> DetailScaffold("PIT WALL", { screen = Screen.HOME }) { Race(snapshot!!, drivers, ::advanceRace, { id, mode -> snapshot = engine.setStrategy(id, mode) }, { id, tyre -> snapshot = engine.pitNow(id, tyre) }, { action -> snapshot = engine.choose(action) }) }
                Screen.RESULT -> DetailScaffold("RESULTADO", { screen = Screen.HOME }) { Result(result!!, team.id, store, ::nextRound) }
                Screen.MANAGEMENT -> DetailScaffold("GESTÃO", { screen = Screen.HOME }) { ManagementHub(snapshot?.phase == "RACE" && snapshot?.completed == false, onDrivers={screen=Screen.DRIVERS}, onMarket={screen=Screen.MARKET}, onFinance={screen=Screen.FINANCE}, onCar={screen=Screen.CAR}, onStandings={screen=Screen.STANDINGS}, onCalendar={screen=Screen.CALENDAR}, onWeekend={screen=Screen.WEEKEND}, onRace={screen=Screen.RACE}) }
            }
        }
    }
}

@Composable private fun AppScaffold(title:String, nav:Nav, select:(Nav)->Unit, onMore:()->Unit, content:@Composable ColumnScope.()->Unit) {
    Column(Modifier.fillMaxSize()) { TopBar(title, onMore); Column(Modifier.weight(1f)) { content() }; BottomNav(nav, select) }
}
@Composable private fun DetailScaffold(title:String, back:()->Unit, content:@Composable ColumnScope.()->Unit) { Column(Modifier.fillMaxSize()) { BackTopBar(title, back); Column(Modifier.weight(1f)) { content() } } }
@Composable private fun BackTopBar(title:String, back:()->Unit) { Row(Modifier.fillMaxWidth().padding(horizontal=14.dp,vertical=10.dp),verticalAlignment=Alignment.CenterVertically){Text("‹",color=Color.White,fontSize=34.sp,modifier=Modifier.clickable{back()}.padding(horizontal=6.dp));Text(title,color=Color.White,fontWeight=FontWeight.Bold,maxLines=1,overflow=TextOverflow.Ellipsis,modifier=Modifier.weight(1f));Text("F1 MANAGER",color=Red,fontWeight=FontWeight.Black,fontSize=12.sp)}}
@Composable private fun TopBar(title:String, action:()->Unit) { Row(Modifier.fillMaxWidth().padding(horizontal=16.dp,vertical=12.dp), verticalAlignment=Alignment.CenterVertically, horizontalArrangement=Arrangement.SpaceBetween) { Text("F1 MANAGER",color=Red,fontWeight=FontWeight.Black,letterSpacing=1.sp); Text(title,color=Color.White,fontWeight=FontWeight.Bold,maxLines=1,overflow=TextOverflow.Ellipsis); Text("⋮",color=Color.White,fontSize=25.sp,modifier=Modifier.clickable{action()}) } }
@Composable private fun BottomNav(selected:Nav, select:(Nav)->Unit) { Row(Modifier.fillMaxWidth().background(Color(0xFF101216)).padding(6.dp), horizontalArrangement=Arrangement.SpaceEvenly) { listOf(Nav.HOME to "⌂",Nav.TEAM to "♟",Nav.CAR to "▰",Nav.CALENDAR to "▦",Nav.STANDINGS to "≡").forEach{(n,l)-> Column(horizontalAlignment=Alignment.CenterHorizontally,modifier=Modifier.weight(1f).clickable{select(n)}.padding(5.dp)){Text(l,color=if(selected==n)Red else Muted,fontSize=20.sp);Text(n.name,color=if(selected==n)Color.White else Muted,fontSize=9.sp,fontWeight=FontWeight.Bold)}} } }

@Composable
private fun Home(
    team: String,
    car: com.f1teammanager.core.season.CarSpec,
    drivers: List<com.f1teammanager.core.season.DriverDefinition>,
    round: RoundDefinition,
    store: CareerPreferences,
    raceInProgress: Boolean,
    onStart: () -> Unit,
    onDrivers: () -> Unit,
    onWeekend: () -> Unit,
    onMarket: () -> Unit,
    onFinance: () -> Unit,
    onStandings: () -> Unit,
    onCar: () -> Unit,
) {
    val teamPoints = store.constructorPoints()[WorldDatabase.teams.first { it.name == team }.id] ?: 0
    val teamId = WorldDatabase.teams.first { it.name == team }.id
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("DASHBOARD", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Black); Text("Temporada ${store.season} • Round ${round.round}/24", color = Muted) }
        item { HeroCard(team, car.model) }
        item { SectionTitle("SITUAÇÃO DO CAMPEONATO") }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                StatCard("CONSTRUTORES", "${constructorPosition(teamId, store)}º", "$teamPoints PTS", Modifier.weight(1f))
                StatCard("PILOTO 1", "${drivers.firstOrNull()?.name ?: "—"}", "titular", Modifier.weight(1f))
                StatCard("SALDO", "€ 41,5M", "orçamento", Modifier.weight(1f))
            }
        }
        item { SectionTitle("PRÓXIMA CORRIDA") }
        item { RaceHero(round, onStart) }
        item { SectionTitle("ACESSO RÁPIDO") }
        item {
            val shortcuts = listOf(
                "FIM DE SEMANA" to onWeekend,
                "PILOTOS" to onDrivers,
                "MERCADO" to onMarket,
                "FINANÇAS" to onFinance,
                "CAMPEONATO" to onStandings,
                "CARRO / P&D" to onCar,
            )
            Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                shortcuts.chunked(2).forEach { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(7.dp), modifier = Modifier.fillMaxWidth()) {
                        row.forEach { (label, action) ->
                            Button(onClick = action, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Panel, contentColor = Color.White), shape = RoundedCornerShape(8.dp)) { Text(label, fontSize = 10.sp, fontWeight = FontWeight.Bold) }
                        }
                        if (row.size == 1) Spacer(Modifier.weight(1f))
                    }
                }
            }
        }
        item { SectionTitle("EQUIPE") }
        item { Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(Panel)) { Column(Modifier.padding(14.dp)) { Text("PILOTOS TITULARES", color = Red, fontWeight = FontWeight.Bold); drivers.forEach { Text(it.name, color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 7.dp)) }; Text("Ver perfil completo →", color = Muted, modifier = Modifier.clickable { onDrivers() }.padding(top = 8.dp)) } } }
        item { Button(onClick = onStart, modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(8.dp), colors = ButtonDefaults.buttonColors(containerColor = Red, contentColor = Color.White)) { Text(if (raceInProgress) "RETOMAR PIT WALL" else "INICIAR FIM DE SEMANA", fontWeight = FontWeight.Black) } }
    }
}
@Composable private fun HeroCard(team:String, model:String){ Box(Modifier.fillMaxWidth().height(180.dp).clip(RoundedCornerShape(12.dp)).background(Panel)){Column(Modifier.fillMaxSize().padding(18.dp),verticalArrangement=Arrangement.Bottom){Text(team.uppercase(),color=Color.White,fontSize=25.sp,fontWeight=FontWeight.Black);Text(model,color=Red,fontWeight=FontWeight.Bold);Text("MODELO ESPECÍFICO DA EQUIPE",color=Muted,fontSize=11.sp)}} }
@Composable private fun RaceHero(r:RoundDefinition,onStart:()->Unit){Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(Panel)){Column(Modifier.padding(16.dp)){Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Column{Text("ROUND ${r.round}",color=Red,fontWeight=FontWeight.Bold);Text(r.grandPrix,color=Color.White,fontSize=21.sp,fontWeight=FontWeight.Black);Text(r.circuit,color=Muted)};Text("${r.laps} LAPS",color=Color.White,fontWeight=FontWeight.Bold)};Spacer(Modifier.height(12.dp));Button(onClick=onStart,modifier=Modifier.fillMaxWidth()){Text("ABRIR FIM DE SEMANA")}}}}
@Composable private fun SectionTitle(t:String){Text(t,color=Color.White,fontWeight=FontWeight.Black,fontSize=13.sp,letterSpacing=1.sp)}
@Composable private fun StatCard(a:String,b:String,c:String,m:Modifier){Card(m,colors=CardDefaults.cardColors(Panel)){Column(Modifier.padding(11.dp)){Text(a,color=Muted,fontSize=10.sp,fontWeight=FontWeight.Bold);Text(b,color=Color.White,fontSize=19.sp,fontWeight=FontWeight.Black);Text(c,color=Muted,fontSize=10.sp)}}}

@Composable private fun Team(name:String,engine:Int,reliability:Int,drivers:List<com.f1teammanager.core.season.DriverDefinition>,onDrivers:()->Unit,onMarket:()->Unit){LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){item{HeaderBlock(name,"GESTÃO DA EQUIPE")};item{MetricPanel("FORNECEDOR / MOTOR","Engine",engine,"Confiabilidade",reliability)};item{SectionTitle("PILOTOS TITULARES")};items(drivers){DriverMini(it)};item{Button(onClick=onDrivers,modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=Red,contentColor=Color.White)){Text("ABRIR PERFIS")}};item{SectionTitle("GESTÃO")};item{Row(Modifier.fillMaxWidth().background(Panel,RoundedCornerShape(8.dp)).clickable{onMarket()}.padding(14.dp),horizontalArrangement=Arrangement.SpaceBetween){Column{Text("MERCADO DE PILOTOS",color=Color.White,fontWeight=FontWeight.Bold);Text("Contratos, salários e disponibilidade",color=Muted,fontSize=11.sp)};Text("›",color=Red,fontSize=24.sp)}};item{SectionTitle("INSTALAÇÕES")};item{Facility("FÁBRICA",72)};item{Facility("CENTRO DE P&D",68)};item{Facility("TÚNEL DE VENTO",61)};item{Facility("SIMULADOR",75)}}}
@Composable private fun Drivers(ds:List<com.f1teammanager.core.season.DriverDefinition>){LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){item{HeaderBlock("PILOTOS","PERFIS E ATRIBUTOS")};items(ds){d->Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(Panel)){Column(Modifier.padding(14.dp)){Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text(d.name,color=Color.White,fontWeight=FontWeight.Black,fontSize=18.sp);Text("${d.speed}",color=Red,fontSize=20.sp,fontWeight=FontWeight.Black)};Text("Velocidade  ${d.speed} • Classificação  ${d.qualifying}",color=Muted);Text("Ultrapassagem ${d.overtaking} • Defesa ${d.defense} • Consistência ${d.consistency}",color=Muted);Text("Chuva ${d.wet} • Pneus ${d.tyre}",color=Muted)}}}}}
@Composable private fun DriverMini(d:com.f1teammanager.core.season.DriverDefinition){Row(Modifier.fillMaxWidth().background(Panel,RoundedCornerShape(8.dp)).padding(13.dp),horizontalArrangement=Arrangement.SpaceBetween){Text(d.name,color=Color.White,fontWeight=FontWeight.Bold);Text("OVR ${((d.speed+d.qualifying+d.overtaking+d.defense+d.consistency+d.wet+d.tyre)/7)}",color=Red,fontWeight=FontWeight.Black)}}
@Composable private fun Facility(name:String,v:Int){Column(Modifier.fillMaxWidth().background(Panel,RoundedCornerShape(8.dp)).padding(12.dp)){Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text(name,color=Color.White,fontWeight=FontWeight.Bold);Text("Nível ${v/10}",color=Muted)};LinearProgressIndicator(progress={v/100f},modifier=Modifier.fillMaxWidth().padding(top=8.dp),color=Red,trackColor=Line)}}
@Composable private fun MetricPanel(title:String,a:String,av:Int,b:String,bv:Int){Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(Panel)){Column(Modifier.padding(14.dp)){Text(title,color=Red,fontWeight=FontWeight.Bold);MetricLine(a,av);MetricLine(b,bv)}}}
@Composable private fun MetricLine(l:String,v:Int){Column(Modifier.padding(top=9.dp)){Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text(l,color=Muted);Text(v.toString(),color=Color.White,fontWeight=FontWeight.Bold)};LinearProgressIndicator(progress={v/100f},modifier=Modifier.fillMaxWidth().padding(top=4.dp),color=Red,trackColor=Line)}}
@Composable private fun Car(c:com.f1teammanager.core.season.CarSpec,engine:Int,reliability:Int){LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){item{HeaderBlock(c.model,"CARRO DA EQUIPE")};item{Text("DESEMPENHO",color=Color.White,fontWeight=FontWeight.Black)};item{MetricPanel("PACOTE", "Velocidade máxima",c.topSpeed,"Aceleração",c.acceleration)};item{MetricPanel("CURVAS", "Baixa velocidade",c.lowSpeed,"Alta velocidade",c.highSpeed)};item{MetricPanel("CONTROLE", "Frenagem",c.braking,"Consistência",c.consistency)};item{MetricPanel("OPERAÇÃO","Motor",engine,"Confiabilidade",reliability)};item{SectionTitle("DESENVOLVIMENTO ATIVO")};item{Project("AERODINÂMICA",74,"12 dias")};item{Project("CHASSI",58,"21 dias")};item{Project("UNIDADE DE POTÊNCIA",41,"34 dias")}}}
@Composable private fun Project(n:String,v:Int,time:String){Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(Panel)){Column(Modifier.padding(13.dp)){Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text(n,color=Color.White,fontWeight=FontWeight.Bold);Text("$v%",color=Red,fontWeight=FontWeight.Black)};LinearProgressIndicator(progress={v/100f},modifier=Modifier.fillMaxWidth().padding(vertical=7.dp),color=Red,trackColor=Line);Text("Conclusão estimada: $time",color=Muted,fontSize=11.sp)}}}
@Composable private fun Calendar(idx:Int){LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(5.dp)){item{HeaderBlock("CALENDÁRIO 2026","24 GRAND PRIX")};items(WorldDatabase.rounds){r->Row(Modifier.fillMaxWidth().background(if(r.round-1==idx) Color(0xFF2A1010) else Panel,RoundedCornerShape(7.dp)).padding(12.dp),horizontalArrangement=Arrangement.SpaceBetween){Column{Text("ROUND ${r.round}",color=if(r.round-1==idx)Red else Muted,fontSize=10.sp,fontWeight=FontWeight.Bold);Text(r.grandPrix,color=Color.White,fontWeight=FontWeight.Bold);Text(r.circuit,color=Muted)};Text("${r.laps}v",color=Color.White,fontWeight=FontWeight.Bold)}}}}
@Composable private fun Standings(teamId:Int,store:CareerPreferences){
    var tab by remember { mutableStateOf(0) }
    val driverPoints=store.driverPoints()
    val constructorPoints=store.constructorPoints()
    Column(Modifier.fillMaxSize().padding(horizontal=16.dp)) {
        HeaderBlock("CAMPEONATO","PILOTOS • CONSTRUTORES")
        Row(Modifier.fillMaxWidth().padding(vertical=10.dp),horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            Button(onClick={tab=0},colors=ButtonDefaults.buttonColors(containerColor=if(tab==0) Red else Panel,contentColor=Color.White),modifier=Modifier.weight(1f)){Text("PILOTOS")}
            Button(onClick={tab=1},colors=ButtonDefaults.buttonColors(containerColor=if(tab==1) Red else Panel,contentColor=Color.White),modifier=Modifier.weight(1f)){Text("CONSTRUTORES")}
        }
        if(tab==0) {
            val rows=WorldDatabase.drivers.sortedWith(compareByDescending<com.f1teammanager.core.season.DriverDefinition>{driverPoints[it.id]?:0}.thenBy{it.name})
            LazyColumn(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(4.dp),contentPadding=PaddingValues(bottom=12.dp)) {
                items(rows) { d ->
                    val pts=driverPoints[d.id]?:0
                    val pos=rows.indexOf(d)+1
                    val selected=d.teamId==teamId
                    Row(Modifier.fillMaxWidth().background(if(selected) Color(0xFF251414) else Panel,RoundedCornerShape(5.dp)).padding(10.dp),horizontalArrangement=Arrangement.SpaceBetween) {
                        Text("$pos. ${d.name}",color=Color.White,fontWeight=if(selected) FontWeight.Bold else FontWeight.Normal)
                        Text("$pts PTS",color=if(selected) Red else Muted,fontWeight=FontWeight.Bold)
                    }
                }
            }
        } else {
            val rows=WorldDatabase.teams.sortedWith(compareByDescending<com.f1teammanager.core.season.TeamDefinition>{constructorPoints[it.id]?:0}.thenBy{it.name})
            LazyColumn(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(4.dp),contentPadding=PaddingValues(bottom=12.dp)) {
                items(rows) { t ->
                    val pts=constructorPoints[t.id]?:0
                    val pos=rows.indexOf(t)+1
                    val selected=t.id==teamId
                    Row(Modifier.fillMaxWidth().background(if(selected) Color(0xFF251414) else Panel,RoundedCornerShape(5.dp)).padding(10.dp),horizontalArrangement=Arrangement.SpaceBetween) {
                        Text("$pos. ${t.name}",color=Color.White,fontWeight=if(selected) FontWeight.Bold else FontWeight.Normal)
                        Text("$pts PTS",color=if(selected) Red else Muted,fontWeight=FontWeight.Bold)
                    }
                }
            }
        }
    }
}

private fun constructorPosition(teamId:Int,store:CareerPreferences):Int{val points=store.constructorPoints();return WorldDatabase.teams.sortedWith(compareByDescending<com.f1teammanager.core.season.TeamDefinition>{points[it.id]?:0}.thenBy{it.name}).indexOfFirst{it.id==teamId}+1}

@Composable private fun Finance(store:CareerPreferences){val points=store.constructorPoints().values.sum();LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){item{HeaderBlock("FINANÇAS","TEMPORADA ${store.season}")};item{StatCard("ORÇAMENTO","€ 41,5M","Disponível",Modifier.fillMaxWidth())};item{MetricPanel("CAMPEONATO","Pontos da equipe",store.constructorPoints()[store.teamId]?:0,"Posição",constructorPosition(store.teamId,store))};item{SectionTitle("RESUMO")};item{Text("Pontos registrados após cada corrida: $points",color=Color.White,modifier=Modifier.fillMaxWidth().background(Panel,RoundedCornerShape(7.dp)).padding(13.dp))}}}

@Composable private fun DriverMarket(store:CareerPreferences,teamId:Int,selectedId:Int,state:DriverMarketState,message:String,onSelect:(Int)->Unit,onInterest:(Int)->Unit){
    val drivers=WorldDatabase.allDrivers
    val contracts=state.contracts.associateBy{it.driverId}
    val free=state.released.toSet()
    LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(7.dp)){
        item{HeaderBlock("MERCADO DE PILOTOS","100 PILOTOS • CONTRATOS")};
        item{Text("80 titulares no campeonato + 20 pilotos disponíveis no mercado/reserva.",color=Muted,fontSize=12.sp)}
        if(message.isNotBlank()) item{Text(message,color=Color.White,modifier=Modifier.fillMaxWidth().background(Color(0xFF251414),RoundedCornerShape(7.dp)).padding(10.dp))}
        items(drivers){d->
            val selected=d.teamId==teamId
            val isFree=d.id in free
            val teamName=if(d.teamId==0) "MERCADO / RESERVA" else WorldDatabase.teams[d.teamId-1].name
            val salary=marketSalary(d)
            Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(if(selected) Color(0xFF251414) else Panel)){
                Column(Modifier.padding(11.dp)){
                    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){
                        Column(Modifier.weight(1f)){Text(d.name,color=Color.White,fontWeight=FontWeight.Bold);Text("$teamName • OVR ${driverOverall(d)}",color=Muted,fontSize=11.sp)}
                        Text(if(selected) "SEU PILOTO" else if(isFree) "LIVRE" else "CONTRATO",color=if(isFree) Red else Color.White,fontSize=9.sp,fontWeight=FontWeight.Black)
                    }
                    Text("€ ${salary/1_000_000}M/ano • ${d.experience} exp. • Vel ${d.speed} • Class ${d.qualifying}",color=Muted,fontSize=10.sp,modifier=Modifier.padding(top=4.dp))
                    if(!selected){
                        Button(onClick={onSelect(d.id);onInterest(d.id)},modifier=Modifier.fillMaxWidth().padding(top=6.dp),colors=ButtonDefaults.buttonColors(containerColor=Red,contentColor=Color.White)){Text(if(isFree) "REGISTRAR INTERESSE" else "ABRIR NEGOCIAÇÃO",fontSize=10.sp,fontWeight=FontWeight.Black)}
                    }
                }
            }
        }
    }
}
private fun driverOverall(d:com.f1teammanager.core.season.DriverDefinition)=((d.speed+d.qualifying+d.overtaking+d.defense+d.consistency+d.wet+d.tyre)/7)
private fun marketSalary(d:com.f1teammanager.core.season.DriverDefinition):Long=(500_000L+driverOverall(d)*90_000L+d.experience*20_000L).coerceAtMost(25_000_000L)

@Composable private fun ManagementHub(hasActiveRace:Boolean,onDrivers:()->Unit,onMarket:()->Unit,onFinance:()->Unit,onCar:()->Unit,onStandings:()->Unit,onCalendar:()->Unit,onWeekend:()->Unit,onRace:()->Unit){
    LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
        item{HeaderBlock("CENTRAL DE GESTÃO","TODAS AS FUNÇÕES")};
        item{SectionTitle("CORRIDA")};
        item{HubAction("FIM DE SEMANA","Qualificação, estratégia e corrida",onWeekend)}
        item{HubAction(if(hasActiveRace) "RETOMAR PIT WALL" else "PIT WALL","${if(hasActiveRace) "Corrida em andamento" else "Nenhuma corrida em andamento — abrir fim de semana"}",if(hasActiveRace) onRace else onWeekend)}
        item{SectionTitle("EQUIPE")};
        item{HubAction("PILOTOS","Perfis e atributos",onDrivers)}
        item{HubAction("MERCADO DE PILOTOS","100 pilotos • contratos e disponibilidade",onMarket)}
        item{HubAction("CARRO / P&D","Desempenho e desenvolvimento",onCar)}
        item{SectionTitle("CAMPEONATO")};
        item{HubAction("CLASSIFICAÇÃO","80 pilotos e 40 construtores",onStandings)}
        item{HubAction("CALENDÁRIO","24 Grandes Prêmios",onCalendar)}
        item{SectionTitle("FINANÇAS")};
        item{HubAction("FINANÇAS","Orçamento e resultados",onFinance)}
    }
}
@Composable private fun HubAction(title:String,subtitle:String,onClick:()->Unit){Row(Modifier.fillMaxWidth().background(Panel,RoundedCornerShape(8.dp)).clickable{onClick()}.padding(14.dp),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(title,color=Color.White,fontWeight=FontWeight.Black);Text(subtitle,color=Muted,fontSize=11.sp)};Text("›",color=Red,fontSize=25.sp,fontWeight=FontWeight.Black)}}

@Composable private fun HeaderBlock(a:String,b:String){Column{Text(a,color=Color.White,fontSize=25.sp,fontWeight=FontWeight.Black);Text(b,color=Red,fontSize=11.sp,fontWeight=FontWeight.Bold,letterSpacing=1.sp)}}
@Composable private fun TeamSelect(onSelect:(Int)->Unit){Column(Modifier.fillMaxSize().padding(16.dp)){HeaderBlock("NOVA CARREIRA","ESCOLHA SUA EQUIPE");Spacer(Modifier.height(12.dp));LazyColumn(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(6.dp)){items(WorldDatabase.teams){t->val car=CarCatalog.forTeam(t.id);Row(Modifier.fillMaxWidth().background(Panel,RoundedCornerShape(8.dp)).clickable{onSelect(t.id)}.padding(13.dp),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(t.name,color=Color.White,fontWeight=FontWeight.Black);Text(car.model,color=Red,fontSize=12.sp);Text("Motor ${t.engine} • Confiabilidade ${t.reliability}",color=Muted,fontSize=11.sp)};Text("›",color=Red,fontSize=30.sp)}}}}}

@Composable private fun Weekend(r:RoundDefinition,start:()->Unit){LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){item{HeaderBlock(r.grandPrix,"ROUND ${r.round} • ${r.circuit}")};item{RaceHero(r,start)};item{InfoPanel("QUALIFICAÇÃO","Define o grid de largada");InfoPanel("ESTRATÉGIA","Postura + pneu inicial");InfoPanel("CORRIDA","Decisões VSC, SC e bandeira vermelha")};item{Button(onClick=start,modifier=Modifier.fillMaxWidth()){Text("COMEÇAR QUALIFICAÇÃO")}}}}
@Composable private fun InfoPanel(a:String,b:String){Row(Modifier.fillMaxWidth().background(Panel,RoundedCornerShape(8.dp)).padding(14.dp),horizontalArrangement=Arrangement.SpaceBetween){Column{Text(a,color=Color.White,fontWeight=FontWeight.Bold);Text(b,color=Muted,fontSize=11.sp)};Text("›",color=Red,fontSize=24.sp)}}
@Composable private fun Qualifying(s:CareerWeekendEngine.SessionSnapshot,mode:DriverStrategyMode,tyre:Tyre,onMode:(DriverStrategyMode)->Unit,onTyre:(Tyre)->Unit,start:()->Unit){
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("GRID",color=Color.White,fontSize=24.sp,fontWeight=FontWeight.Black)
        Text("Escolha a postura e o pneu antes da corrida",color=Muted)
        Spacer(Modifier.height(10.dp))
        ChoiceRow("POSTURA",mode.name,DriverStrategyMode.entries.toList(),onMode)
        ChoiceRow("PNEU",tyre.name,listOf(Tyre.SOFT,Tyre.MEDIUM,Tyre.HARD),onTyre)
        Text("SOFT: mais rápido / mais desgaste • MEDIUM: equilíbrio • HARD: mais lento / mais durável",color=Muted,fontSize=9.sp,modifier=Modifier.padding(top=4.dp))
        LazyColumn(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(3.dp)) {
            items(s.grid?.grid.orEmpty()) { e ->
                Row(Modifier.fillMaxWidth().background(Panel,RoundedCornerShape(5.dp)).padding(9.dp),horizontalArrangement=Arrangement.SpaceBetween) {
                    Text("P${e.position}",color=Red,fontWeight=FontWeight.Black)
                    Text(WorldDatabase.drivers.firstOrNull { it.id == e.driverId }?.name ?: "Piloto ${e.driverId}",color=Color.White)
                    Text(formatMs(e.lapTimeMs),color=Muted)
                }
            }
        }
        Button(onClick=start,modifier=Modifier.fillMaxWidth().height(52.dp),colors=ButtonDefaults.buttonColors(containerColor=Red,contentColor=Color.White)) { Text("INICIAR CORRIDA") }
    }
}
@Composable private fun <T> ChoiceRow(title:String,current:String,values:List<T>,select:(T)->Unit){Column{Text(title,color=Muted,fontSize=10.sp,fontWeight=FontWeight.Bold);Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(6.dp)){values.forEach{v->FilterChip(selected=v.toString()==current,onClick={select(v)},label={Text(v.toString())})}}}}
@Composable
private fun Race(
    s: CareerWeekendEngine.SessionSnapshot,
    drivers: List<com.f1teammanager.core.season.DriverDefinition>,
    advance: () -> Unit,
    setStrategy: (Int, DriverStrategyMode) -> Unit,
    pitNow: (Int, Tyre) -> Unit,
    decision: (ManagerDecisionAction) -> Unit,
) {
    var running by remember { mutableStateOf(true) }
    var speedMs by remember { mutableIntStateOf(1100) }
    val playerIds = drivers.map { it.id }.toSet()
    val playerStatus = s.carStatus.filter { it.driverId in playerIds }
    val statusById = s.carStatus.associateBy { it.driverId }
    val leaderTime = s.classification.minOfOrNull { it.totalTimeMs } ?: 0L

    LaunchedEffect(s.lap, s.decision, s.completed, running, speedMs) {
        if (running && s.decision == null && !s.completed) {
            kotlinx.coroutines.delay(speedMs.toLong())
            advance()
        }
    }

    Column(Modifier.fillMaxSize().padding(horizontal = 12.dp)) {
        Row(Modifier.fillMaxWidth().padding(vertical = 7.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column {
                Text("PIT WALL", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Black)
                Text("VOLTA ${s.lap}/${s.totalLaps}", color = Red, fontWeight = FontWeight.Bold)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(statusLabel(s.neutral), color = if (s.neutral == Neutralisation.GREEN) Green else Red, fontWeight = FontWeight.Black)
                Text(if (running) "AUTOMÁTICA" else "PAUSADA", color = Muted, fontSize = 10.sp)
            }
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            listOf(1600 to "0,7x", 1100 to "1x", 650 to "1,7x", 300 to "3x").forEach { (ms, label) ->
                Button(onClick = { speedMs = ms }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = if (speedMs == ms) Red else Panel2, contentColor = Color.White), contentPadding = PaddingValues(horizontal = 3.dp, vertical = 3.dp)) { Text(label, fontSize = 9.sp) }
            }
        }

        val critical = s.alerts.firstOrNull { it.severity >= 3 }
        critical?.let { alert ->
            Card(Modifier.fillMaxWidth().padding(vertical = 3.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF3A0D0D))) {
                Column(Modifier.padding(10.dp)) {
                    Text("ATENÇÃO DO PILOTO", color = Red, fontWeight = FontWeight.Black, fontSize = 10.sp)
                    Text(alert.message, color = Color.White, fontWeight = FontWeight.Bold)
                    Text("A decisão será solicitada se a condição continuar crítica.", color = Color.White, fontSize = 9.sp)
                }
            }
        }

        playerStatus.forEach { st ->
            val plan = s.plans[st.driverId]
            val gap = st.position.let { pos -> if (pos <= 1) "LÍDER" else gapText(s.classification.getOrNull(pos - 1)?.totalTimeMs ?: st.lastLapMs, leaderTime) }
            Card(Modifier.fillMaxWidth().padding(vertical = 3.dp), colors = CardDefaults.cardColors(Panel)) {
                Column(Modifier.padding(9.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(st.driverName, color = Color.White, fontWeight = FontWeight.Black); Text("P${st.position}  $gap", color = Red, fontWeight = FontWeight.Black) }
                    Row(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("${tyreLabel(st.tyre)}  ${st.tyreWear}%", color = if (st.tyreWear >= 75) Red else Color.White, fontSize = 10.sp)
                        Text("COMB. ${st.fuelPercent}%", color = if (st.fuelPercent <= 20) Red else Color.White, fontSize = 10.sp)
                        Text("STINT ${st.stintLaps}v", color = Muted, fontSize = 10.sp)
                        Text("ERS ${st.ersPercent}%", color = if(st.ersPercent<20) Red else Color.White, fontSize = 10.sp)
                        Text(if(st.drsActive) "DRS ATIVO" else "DRS AUTO", color = if(st.drsActive) Green else Muted, fontSize = 10.sp)
                        Text("BOX ${st.pitStops}", color = Muted, fontSize = 10.sp)
                    }
                    Row(Modifier.fillMaxWidth().padding(top = 3.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("ÚLTIMA ${formatMs(st.lastLapMs)}", color = Muted, fontSize = 9.sp)
                        Text("POSTURA ${strategyLabel(plan?.mode ?: DriverStrategyMode.BALANCED)}", color = Color.White, fontSize = 9.sp)
                    }
                    Row(modifier = Modifier.horizontalScroll(rememberScrollState()).padding(top = 5.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        listOf(DriverStrategyMode.ATTACK, DriverStrategyMode.BALANCED, DriverStrategyMode.DEFENSE).forEach { m ->
                            Button(onClick = { setStrategy(st.driverId, m) }, colors = ButtonDefaults.buttonColors(containerColor = if (plan?.mode == m) Red else Panel2, contentColor = Color.White), contentPadding = PaddingValues(horizontal = 7.dp, vertical = 1.dp)) { Text(strategyLabel(m), fontSize = 9.sp) }
                        }
                        Button(onClick = { pitNow(st.driverId, plan?.tyre ?: st.tyre) }, colors = ButtonDefaults.buttonColors(containerColor = Red, contentColor = Color.White), contentPadding = PaddingValues(horizontal = 9.dp, vertical = 1.dp)) { Text("BOX", fontSize = 9.sp) }
                    }
                    Row(modifier = Modifier.horizontalScroll(rememberScrollState()).padding(top = 3.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        listOf(Tyre.SOFT, Tyre.MEDIUM, Tyre.HARD).forEach { t ->
                            Button(onClick = { pitNow(st.driverId, t) }, colors = ButtonDefaults.buttonColors(containerColor = Panel2, contentColor = Color.White), contentPadding = PaddingValues(horizontal = 7.dp, vertical = 1.dp)) { Text("BOX ${tyreLabel(t)}", fontSize = 8.sp) }
                        }
                    }
                }
            }
        }

        if (s.alerts.isNotEmpty()) {
            Card(Modifier.fillMaxWidth().padding(vertical = 3.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF261313))) {
                Column(Modifier.padding(8.dp)) {
                    Text("RÁDIO / ALERTAS", color = Red, fontWeight = FontWeight.Black, fontSize = 10.sp)
                    s.alerts.takeLast(3).forEach { Text("• ${it.message}", color = Color.White, fontSize = 10.sp, maxLines = 2, overflow = TextOverflow.Ellipsis) }
                }
            }
        }

        Card(Modifier.fillMaxWidth().weight(1f), colors = CardDefaults.cardColors(Panel)) {
            Column {
                Text("CLASSIFICAÇÃO AO VIVO • ${s.classification.size} PILOTOS", color = Color.White, fontWeight = FontWeight.Black, modifier = Modifier.padding(8.dp))
                Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), horizontalArrangement = Arrangement.SpaceBetween) { Text("POS", color = Muted, fontSize = 8.sp); Text("PILOTO", color = Muted, fontSize = 8.sp); Text("PNEU", color = Muted, fontSize = 8.sp); Text("GAP", color = Muted, fontSize = 8.sp) }
                LazyColumn(Modifier.weight(1f)) {
                    items(s.classification) { f ->
                        val mine = f.driverId in playerIds
                        val st = statusById[f.driverId]
                        val gap = if (f.position == 1) "LÍDER" else gapText(f.totalTimeMs, leaderTime)
                        Row(Modifier.fillMaxWidth().background(if (mine) Color(0xFF2A1010) else Color.Transparent).padding(horizontal = 8.dp, vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text("${f.position}", color = if (mine) Red else Muted, fontWeight = FontWeight.Bold, modifier = Modifier.width(24.dp))
                            Text(f.driverName, color = Color.White, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 11.sp)
                            Text(tyreLabel(f.tyre), color = if (st?.tyreWear ?: 0 >= 80) Red else Muted, fontSize = 8.sp, modifier = Modifier.width(48.dp))
                            Text(if (f.status.startsWith("DNF")) "DNF" else gap, color = if (f.status.startsWith("DNF")) Red else Muted, fontSize = 8.sp, modifier = Modifier.width(58.dp))
                        }
                    }
                }
            }
        }

        if (s.events.isNotEmpty()) Text(s.events.takeLast(2).joinToString("  • ") { it.detail }, color = Color.White, fontSize = 10.sp, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(vertical = 4.dp))
        Button(onClick = { running = !running }, modifier = Modifier.fillMaxWidth().height(46.dp), colors = ButtonDefaults.buttonColors(containerColor = Red, contentColor = Color.White)) { Text(if (running) "PAUSAR CORRIDA" else "RETOMAR CORRIDA", fontWeight = FontWeight.Black) }

        s.decision?.let { d ->
            AlertDialog(onDismissRequest = {}, title = { Text("DECISÃO DO MANAGER", fontWeight = FontWeight.Black) }, text = { Column { Text("${d.driverName}: ${d.request.message}", color = Color.White); Spacer(Modifier.height(8.dp)); d.request.options.forEach { action -> Button(onClick = { decision(action) }, modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp), colors = ButtonDefaults.buttonColors(containerColor = Red, contentColor = Color.White)) { Text(actionLabel(action)) } } } }, confirmButton = {})
        }
    }
}

private fun gapText(time: Long, leader: Long): String {
    val gap = (time - leader).coerceAtLeast(0L)
    return "+${gap / 1000}.${(gap % 1000) / 100}s"
}

@Composable private fun Result(r:RaceResult,teamId:Int,store:CareerPreferences,next:()->Unit){
    val teamName=WorldDatabase.teams.first{it.id==teamId}.name
    val mine=r.classification.filter{it.teamName==teamName}
    val earned=mine.sumOf{r.points[it.driverId]?:0}
    Column(Modifier.fillMaxSize().padding(16.dp)){
        HeaderBlock("RESULTADO","CORRIDA FINALIZADA")
        Card(Modifier.fillMaxWidth().padding(top=10.dp),colors=CardDefaults.cardColors(Panel)){Column(Modifier.padding(13.dp)){Text("SUA EQUIPE",color=Red,fontWeight=FontWeight.Black);mine.forEach{f->Text("P${f.position} • ${f.driverName} • ${r.points[f.driverId]?:0} PTS",color=Color.White,fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=5.dp))};Text("PONTOS CONQUISTADOS: $earned",color=Color.White,fontWeight=FontWeight.Black,modifier=Modifier.padding(top=8.dp))}}
        LazyColumn(Modifier.weight(1f),contentPadding=PaddingValues(vertical=10.dp),verticalArrangement=Arrangement.spacedBy(3.dp)){items(r.classification){f->Row(Modifier.fillMaxWidth().background(if(f.position<=3)Color(0xFF251414) else Panel,RoundedCornerShape(5.dp)).padding(9.dp),horizontalArrangement=Arrangement.SpaceBetween){Text("P${f.position}",color=if(f.position<=3)Red else Muted,fontWeight=FontWeight.Black);Text(f.driverName,color=Color.White,modifier=Modifier.weight(1f).padding(horizontal=8.dp),maxLines=1,overflow=TextOverflow.Ellipsis);Text("${r.points[f.driverId]?:0} PTS",color=if((r.points[f.driverId]?:0)>0) Color.White else Muted,fontSize=10.sp)}}}
        Text("Safety Car ${r.safetyCarLaps} • VSC ${r.vscLaps} • Campeonato: ${store.constructorPoints()[teamId]?:0} PTS",color=Muted,fontSize=10.sp)
        Button(onClick=next,modifier=Modifier.fillMaxWidth().height(48.dp),colors=ButtonDefaults.buttonColors(containerColor=Red,contentColor=Color.White)){Text("PRÓXIMO GP",fontWeight=FontWeight.Black)}
    }
}
private fun strategyLabel(m:DriverStrategyMode)=when(m){DriverStrategyMode.ATTACK->"ATAQUE";DriverStrategyMode.BALANCED->"EQUILIBRADO";DriverStrategyMode.DEFENSE->"DEFESA / ECONOMIA"}
private fun tyreLabel(t:Tyre)=when(t){Tyre.SOFT->"SOFT";Tyre.MEDIUM->"MEDIUM";Tyre.HARD->"HARD";Tyre.INTERMEDIATE->"INTER";Tyre.WET->"WET"}
private fun statusLabel(n:Neutralisation)=when(n){Neutralisation.GREEN->"GREEN FLAG";Neutralisation.VSC->"VSC";Neutralisation.SAFETY_CAR->"SAFETY CAR"}
private fun actionLabel(a:ManagerDecisionAction)=when(a){ManagerDecisionAction.BOX->"BOX";ManagerDecisionAction.STAY_OUT->"MANTER";ManagerDecisionAction.EXTEND_STINT->"ESTENDER STINT";ManagerDecisionAction.SAVE_FUEL->"POUPAR COMBUSTÍVEL";ManagerDecisionAction.CHANGE_STRATEGY->"MUDAR ESTRATÉGIA";ManagerDecisionAction.RESTART_ATTACK->"RELARGADA • ATAQUE";ManagerDecisionAction.RESTART_BALANCED->"RELARGADA • EQUILIBRADO";ManagerDecisionAction.RESTART_DEFENSE->"RELARGADA • DEFESA";ManagerDecisionAction.CHANGE_TYRE_SOFT->"RELARGADA • SOFT / ATAQUE";ManagerDecisionAction.CHANGE_TYRE_MEDIUM->"RELARGADA • MEDIUM / EQUILIBRADO";ManagerDecisionAction.CHANGE_TYRE_HARD->"RELARGADA • HARD / DEFESA";ManagerDecisionAction.CHANGE_TYRE_INTERMEDIATE->"INTERMEDIÁRIO";ManagerDecisionAction.CHANGE_TYRE_WET->"WET"}
private fun formatMs(ms:Long)="%d:%02d.%03d".format(ms/60000,(ms/1000)%60,ms%1000)
