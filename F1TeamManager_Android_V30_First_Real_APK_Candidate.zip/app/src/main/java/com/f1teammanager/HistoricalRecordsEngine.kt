package com.f1teammanager

import kotlin.math.roundToInt

/**
 * Reconstructs the Record Book directly from the official career archive.
 * No separate mutable counter is stored: rebuilding the board is deterministic
 * and cannot duplicate a GP when the screen is reopened or a backup is restored.
 */
object HistoricalRecordsEngine {
    data class Holder(
        val id: Int,
        val name: String,
        val teamId: Int = 0,
        val teamName: String = "",
        val season: Int? = null,
        val round: Int? = null,
        val grandPrix: String = "",
        val circuit: String = "",
        val driver: Boolean = true
    )

    data class Card(
        val title: String,
        val value: String,
        val unit: String = "",
        val holders: List<Holder>,
        val context: String = "",
        val note: String = ""
    )

    data class Milestone(
        val title: String,
        val value: Int,
        val holder: Holder,
        val season: Int,
        val round: Int,
        val circuit: String
    )

    private data class Aggregate(
        val id: Int,
        val name: String,
        val teamId: Int,
        val teamName: String,
        val value: Int,
        val season: Int? = null
    )

    fun driverCareer(
        races: List<HistoricalDatabase.RaceRecord>,
        poles: List<HistoricalDatabase.PoleRecord>,
        champions: List<HistoricalDatabase.DriverChampion>
    ): List<Card> {
        if (races.isEmpty() && poles.isEmpty() && champions.isEmpty()) return emptyList()
        val cards = mutableListOf<Card>()
        fun add(title: String, unit: String, values: List<Aggregate>) {
            topCard(title, unit, values)?.let(cards::add)
        }
        val wins = races.filter { it.position == 1 && !it.status.startsWith("DNF", true) }
        val podiums = races.filter { it.position in 1..3 && !it.status.startsWith("DNF", true) }
        add("Títulos mundiais", "títulos", champions.groupBy { it.driverId }.map { (id, rows) ->
            val row = rows.maxBy { it.season }
            val teams = rows.map { it.teamId to it.teamName }.distinctBy { it.first }
            Aggregate(id, row.driverName, if (teams.size == 1) teams.single().first else 0,
                if (teams.size == 1) teams.single().second else "Múltiplas equipes", rows.map { it.season }.distinct().size)
        })
        add("Vitórias na carreira", "vitórias", wins.groupBy { it.driverId }.map { (id, rows) -> aggregateFromRows(id, rows, rows.size) })
        add("Pódios na carreira", "pódios", podiums.groupBy { it.driverId }.map { (id, rows) -> aggregateFromRows(id, rows, rows.size) })
        add("Poles na carreira", "poles", poles.groupBy { it.driverId }.map { (id, rows) ->
            val row = rows.maxWithOrNull(compareBy<HistoricalDatabase.PoleRecord> { it.season }.thenBy { it.round })!!
            val teams = rows.map { it.teamId to it.teamName }.distinctBy { it.first }
            Aggregate(id, row.driverName, if (teams.size == 1) teams.single().first else 0,
                if (teams.size == 1) teams.single().second else "Múltiplas equipes", rows.size)
        })
        add("Voltas mais rápidas", "voltas", races.filter { it.isFastestLap && it.fastestLapTimeMs > 0L }.groupBy { it.driverId }.map { (id, rows) -> aggregateFromRows(id, rows, rows.size) })
        add("Pontos acumulados", "pontos", races.groupBy { it.driverId }.map { (id, rows) -> aggregateFromRows(id, rows, rows.sumOf { it.points }) })
        add("Maior sequência de vitórias", "GPs consecutivos", longestStreak(races, driver = true, predicate = { it.position == 1 && !it.status.startsWith("DNF", true) }))
        add("Maior sequência de pódios", "GPs consecutivos", longestStreak(races, driver = true, predicate = { it.position in 1..3 && !it.status.startsWith("DNF", true) }))
        return cards
    }

    fun constructorCareer(
        races: List<HistoricalDatabase.RaceRecord>,
        poles: List<HistoricalDatabase.PoleRecord>,
        champions: List<HistoricalDatabase.ConstructorChampion>
    ): List<Card> {
        if (races.isEmpty() && poles.isEmpty() && champions.isEmpty()) return emptyList()
        val cards = mutableListOf<Card>()
        fun add(title: String, unit: String, values: List<Aggregate>) { topCard(title, unit, values, driver = false)?.let(cards::add) }
        val wins = races.filter { it.position == 1 && !it.status.startsWith("DNF", true) }
        val podiums = races.filter { it.position in 1..3 && !it.status.startsWith("DNF", true) }
        add("Títulos de construtores", "títulos", champions.groupBy { it.teamId }.map { (id, rows) ->
            val row = rows.maxBy { it.season }
            Aggregate(id, row.teamName, id, row.teamName, rows.map { it.season }.distinct().size)
        })
        add("Vitórias de equipes", "vitórias", wins.groupBy { it.teamId }.map { (id, rows) -> aggregateTeamFromRows(id, rows, rows.size) })
        add("Pódios de equipes", "pódios", podiums.groupBy { it.teamId }.map { (id, rows) -> aggregateTeamFromRows(id, rows, rows.size) })
        add("Poles de equipes", "poles", poles.groupBy { it.teamId }.map { (id, rows) ->
            val row = rows.maxWithOrNull(compareBy<HistoricalDatabase.PoleRecord> { it.season }.thenBy { it.round })!!
            Aggregate(id, row.teamName, id, row.teamName, rows.size)
        })
        add("Voltas mais rápidas", "voltas", races.filter { it.isFastestLap && it.fastestLapTimeMs > 0L }.groupBy { it.teamId }.map { (id, rows) -> aggregateTeamFromRows(id, rows, rows.size) })
        add("Pontos acumulados", "pontos", races.groupBy { it.teamId }.map { (id, rows) -> aggregateTeamFromRows(id, rows, rows.sumOf { it.points }) })
        add("Maior sequência de vitórias", "GPs consecutivos", longestStreak(races, driver = false, predicate = { it.position == 1 && !it.status.startsWith("DNF", true) }))
        add("Maior sequência de pódios", "GPs consecutivos", longestStreak(races, driver = false, predicate = { it.position in 1..3 && !it.status.startsWith("DNF", true) }))
        return cards
    }

    fun driverSeason(
        seasonRows: List<HistoricalDatabase.DriverSeasonRecord>,
        races: List<HistoricalDatabase.RaceRecord>
    ): List<Card> {
        val cards = mutableListOf<Card>()
        fun add(title: String, unit: String, values: List<Aggregate>) { topCard(title, unit, values)?.let(cards::add) }
        add("Mais pontos em uma temporada", "pontos", seasonRows.map { Aggregate(it.driverId, it.driverName, it.teamId, it.teamName, it.points, it.season) })
        add("Mais vitórias em uma temporada", "vitórias", seasonRows.map { Aggregate(it.driverId, it.driverName, it.teamId, it.teamName, it.wins, it.season) })
        add("Mais poles em uma temporada", "poles", seasonRows.map { Aggregate(it.driverId, it.driverName, it.teamId, it.teamName, it.poles, it.season) })
        val podiums = races.filter { it.position in 1..3 && !it.status.startsWith("DNF", true) }
            .groupBy { it.season to it.driverId }.map { (key, rows) ->
                val row = rows.last()
                Aggregate(key.second, row.driverName, row.teamId, row.teamName, rows.size, key.first)
            }
        add("Mais pódios em uma temporada", "pódios", podiums)
        add("Mais voltas rápidas em uma temporada", "voltas", seasonRows.map { Aggregate(it.driverId, it.driverName, it.teamId, it.teamName, it.fastestLaps, it.season) })
        val starts = races.groupBy { it.season to it.driverId }
        val winRates = seasonRows.mapNotNull { row ->
            val total = starts[row.season to row.driverId]?.map { it.round }?.distinct()?.size ?: 0
            if (total == 0) null else Aggregate(row.driverId, row.driverName, row.teamId, row.teamName, (row.wins * 1_000_000.0 / total).roundToInt(), row.season)
        }
        add("Maior aproveitamento de vitórias", "%", winRates)
        val poleRates = seasonRows.mapNotNull { row ->
            val total = starts[row.season to row.driverId]?.map { it.round }?.distinct()?.size ?: 0
            if (total == 0) null else Aggregate(row.driverId, row.driverName, row.teamId, row.teamName, (row.poles * 1_000_000.0 / total).roundToInt(), row.season)
        }
        add("Maior aproveitamento de poles", "%", poleRates)
        val averagePoints = seasonRows.mapNotNull { row ->
            val total = starts[row.season to row.driverId]?.map { it.round }?.distinct()?.size ?: 0
            if (total == 0) null else Aggregate(row.driverId, row.driverName, row.teamId, row.teamName, (row.points * 100.0 / total).roundToInt(), row.season)
        }
        add("Maior média de pontos por GP", "média", averagePoints)
        return cards
    }

    fun constructorSeason(
        seasonRows: List<HistoricalDatabase.ConstructorSeasonRecord>,
        races: List<HistoricalDatabase.RaceRecord>
    ): List<Card> {
        val cards = mutableListOf<Card>()
        fun add(title: String, unit: String, values: List<Aggregate>) { topCard(title, unit, values, driver = false)?.let(cards::add) }
        add("Mais pontos em uma temporada", "pontos", seasonRows.map { Aggregate(it.teamId, it.teamName, it.teamId, it.teamName, it.points, it.season) })
        add("Mais vitórias em uma temporada", "vitórias", seasonRows.map { Aggregate(it.teamId, it.teamName, it.teamId, it.teamName, it.wins, it.season) })
        add("Mais poles em uma temporada", "poles", seasonRows.map { Aggregate(it.teamId, it.teamName, it.teamId, it.teamName, it.poles, it.season) })
        val podiums = races.filter { it.position in 1..3 && !it.status.startsWith("DNF", true) }
            .groupBy { it.season to it.teamId }.map { (key, rows) ->
                val row = rows.last()
                Aggregate(key.second, row.teamName, key.second, row.teamName, rows.size, key.first)
            }
        add("Mais pódios em uma temporada", "pódios", podiums)
        add("Mais voltas rápidas em uma temporada", "voltas", seasonRows.map { Aggregate(it.teamId, it.teamName, it.teamId, it.teamName, it.fastestLaps, it.season) })
        val starts = races.groupBy { it.season to it.teamId }
        val winRates = seasonRows.mapNotNull { row ->
            val total = starts[row.season to row.teamId]?.map { it.round }?.distinct()?.size ?: 0
            if (total == 0) null else Aggregate(row.teamId, row.teamName, row.teamId, row.teamName, (row.wins * 1_000_000.0 / total).roundToInt(), row.season)
        }
        add("Maior aproveitamento de vitórias", "%", winRates)
        val poleRates = seasonRows.mapNotNull { row ->
            val total = starts[row.season to row.teamId]?.map { it.round }?.distinct()?.size ?: 0
            if (total == 0) null else Aggregate(row.teamId, row.teamName, row.teamId, row.teamName, (row.poles * 1_000_000.0 / total).roundToInt(), row.season)
        }
        add("Maior aproveitamento de poles", "%", poleRates)
        val margins = seasonRows.groupBy { it.season }.values.mapNotNull { rows ->
            val sorted = rows.sortedByDescending { it.points }
            val first = sorted.getOrNull(0) ?: return@mapNotNull null
            val second = sorted.getOrNull(1) ?: return@mapNotNull null
            Aggregate(first.teamId, first.teamName, first.teamId, first.teamName, first.points - second.points, first.season)
        }
        add("Maior vantagem sobre a vice-líder", "pontos", margins)
        return cards
    }

    fun circuitCards(circuit: String, races: List<HistoricalDatabase.RaceRecord>, poles: List<HistoricalDatabase.PoleRecord>): List<Card> {
        if (circuit.isBlank()) return emptyList()
        val circuitRaces = races.filter { it.circuit.equals(circuit, true) }
        val circuitPoles = poles.filter { it.circuit.equals(circuit, true) }
        if (circuitRaces.isEmpty() && circuitPoles.isEmpty()) return emptyList()
        val cards = mutableListOf<Card>()
        fun add(title: String, unit: String, values: List<Aggregate>) { topCard(title, unit, values)?.let(cards::add) }
        add("Mais vitórias nesta pista", "vitórias", circuitRaces.filter { it.position == 1 && !it.status.startsWith("DNF", true) }.groupBy { it.driverId }.map { (id, rows) -> aggregateFromRows(id, rows, rows.size) })
        add("Mais pódios nesta pista", "pódios", circuitRaces.filter { it.position in 1..3 && !it.status.startsWith("DNF", true) }.groupBy { it.driverId }.map { (id, rows) -> aggregateFromRows(id, rows, rows.size) })
        add("Mais poles nesta pista", "poles", circuitPoles.groupBy { it.driverId }.map { (id, rows) ->
            val row = rows.maxWithOrNull(compareBy<HistoricalDatabase.PoleRecord> { it.season }.thenBy { it.round })!!
            val teams = rows.map { it.teamId to it.teamName }.distinctBy { it.first }
            Aggregate(id, row.driverName, if (teams.size == 1) teams.single().first else 0,
                if (teams.size == 1) teams.single().second else "Múltiplas equipes", rows.size)
        })
        add("Mais voltas rápidas nesta pista", "voltas", circuitRaces.filter { it.isFastestLap && it.fastestLapTimeMs > 0L }.groupBy { it.driverId }.map { (id, rows) -> aggregateFromRows(id, rows, rows.size) })
        val fastestLap = circuitRaces.filter { it.isFastestLap && it.fastestLapTimeMs > 0L }.minOfOrNull { it.fastestLapTimeMs }
        if (fastestLap != null) {
            val holders = circuitRaces.filter { it.isFastestLap && it.fastestLapTimeMs == fastestLap }.map {
                Holder(it.driverId, it.driverName, it.teamId, it.teamName, it.season, it.round, it.grandPrix, it.circuit)
            }.distinctBy { it.id to it.season }
            cards += Card("Melhor volta de corrida", formatTime(fastestLap), "", holders, circuit, "Menor tempo registrado nesta pista")
        }
        val fastestPole = circuitPoles.filter { it.timeMs > 0L }.minOfOrNull { it.timeMs }
        if (fastestPole != null) {
            val holders = circuitPoles.filter { it.timeMs == fastestPole }.map {
                Holder(it.driverId, it.driverName, it.teamId, it.teamName, it.season, it.round, it.grandPrix, it.circuit)
            }.distinctBy { it.id to it.season }
            cards += Card("Melhor classificação", formatTime(fastestPole), "", holders, circuit, "Menor tempo de pole registrado nesta pista")
        }
        return cards
    }

    fun recentMilestones(
        races: List<HistoricalDatabase.RaceRecord>,
        poles: List<HistoricalDatabase.PoleRecord>,
        driverChampions: List<HistoricalDatabase.DriverChampion>,
        constructorChampions: List<HistoricalDatabase.ConstructorChampion>
    ): List<Milestone> {
        val found = mutableListOf<Milestone>()
        val driverCounts = mutableMapOf<Pair<Int, String>, Int>()
        val teamCounts = mutableMapOf<Pair<Int, String>, Int>()
        val best = mutableMapOf<String, Int>()
        fun check(key: String, title: String, count: Int, holder: Holder, season: Int, round: Int, circuit: String) {
            val old = best[key] ?: 0
            if (count > old) {
                best[key] = count
                found += Milestone(title, count, holder, season, round, circuit)
            }
        }
        races.groupBy { it.season to it.round }.toSortedMap(compareBy<Pair<Int, Int>> { it.first }.thenBy { it.second }).forEach { (gp, rows) ->
            rows.forEach { row ->
                val dh = Holder(row.driverId, row.driverName, row.teamId, row.teamName, row.season, row.round, row.grandPrix, row.circuit, true)
                val th = Holder(row.teamId, row.teamName, row.teamId, row.teamName, row.season, row.round, row.grandPrix, row.circuit, false)
                fun driver(metric: String, label: String, inc: Int) {
                    if (inc <= 0) return
                    val key = row.driverId to metric
                    val count = (driverCounts[key] ?: 0) + inc
                    driverCounts[key] = count
                    check("D:$metric", label, count, dh, gp.first, gp.second, row.circuit)
                }
                fun team(metric: String, label: String, inc: Int) {
                    if (inc <= 0) return
                    val key = row.teamId to metric
                    val count = (teamCounts[key] ?: 0) + inc
                    teamCounts[key] = count
                    check("T:$metric", label, count, th, gp.first, gp.second, row.circuit)
                }
                driver("POINTS", "Recorde de pontos acumulados", row.points)
                team("POINTS", "Recorde de pontos acumulados da equipe", row.points)
                if (row.position == 1 && !row.status.startsWith("DNF", true)) { driver("WINS", "Recorde de vitórias", 1); team("WINS", "Recorde de vitórias da equipe", 1) }
                if (row.position in 1..3 && !row.status.startsWith("DNF", true)) { driver("PODIUMS", "Recorde de pódios", 1); team("PODIUMS", "Recorde de pódios da equipe", 1) }
                if (row.isFastestLap && row.fastestLapTimeMs > 0L) { driver("FASTEST", "Recorde de voltas rápidas", 1); team("FASTEST", "Recorde de voltas rápidas da equipe", 1) }
            }
        }
        poles.sortedWith(compareBy<HistoricalDatabase.PoleRecord> { it.season }.thenBy { it.round }).forEach { row ->
            val dk = row.driverId to "POLES"
            val dc = (driverCounts[dk] ?: 0) + 1
            driverCounts[dk] = dc
            check("D:POLES", "Recorde de poles", dc, Holder(row.driverId, row.driverName, row.teamId, row.teamName, row.season, row.round, row.grandPrix, row.circuit), row.season, row.round, row.circuit)
            val tk = row.teamId to "POLES"
            val tc = (teamCounts[tk] ?: 0) + 1
            teamCounts[tk] = tc
            check("T:POLES", "Recorde de poles da equipe", tc, Holder(row.teamId, row.teamName, row.teamId, row.teamName, row.season, row.round, row.grandPrix, row.circuit, false), row.season, row.round, row.circuit)
        }
        driverChampions.sortedBy { it.season }.forEach { row ->
            val key = row.driverId to "TITLES"
            val count = (driverCounts[key] ?: 0) + 1
            driverCounts[key] = count
            check("D:TITLES", "Recorde de títulos mundiais", count, Holder(row.driverId, row.driverName, row.teamId, row.teamName, row.season, driver = true), row.season, 30, "")
        }
        constructorChampions.sortedBy { it.season }.forEach { row ->
            val key = row.teamId to "TITLES"
            val count = (teamCounts[key] ?: 0) + 1
            teamCounts[key] = count
            check("T:TITLES", "Recorde de títulos de construtores", count, Holder(row.teamId, row.teamName, row.teamId, row.teamName, row.season, driver = false), row.season, 30, "")
        }
        return found.sortedWith(compareByDescending<Milestone> { it.season }.thenByDescending { it.round }).take(8)
    }

    private fun aggregateFromRows(id: Int, rows: List<HistoricalDatabase.RaceRecord>, value: Int): Aggregate {
        val row = rows.maxWithOrNull(compareBy<HistoricalDatabase.RaceRecord> { it.season }.thenBy { it.round })!!
        val teams = rows.map { it.teamId to it.teamName }.distinctBy { it.first }
        return Aggregate(id, row.driverName, if (teams.size == 1) teams.single().first else 0,
            if (teams.size == 1) teams.single().second else "Múltiplas equipes", value)
    }

    private fun aggregateTeamFromRows(id: Int, rows: List<HistoricalDatabase.RaceRecord>, value: Int): Aggregate {
        val row = rows.maxWithOrNull(compareBy<HistoricalDatabase.RaceRecord> { it.season }.thenBy { it.round })!!
        return Aggregate(id, row.teamName, id, row.teamName, value)
    }

    private fun longestStreak(
        races: List<HistoricalDatabase.RaceRecord>,
        driver: Boolean,
        predicate: (HistoricalDatabase.RaceRecord) -> Boolean
    ): List<Aggregate> {
        val grouped = if (driver) races.groupBy { it.driverId } else races.groupBy { it.teamId }
        return grouped.mapNotNull { (id, rows) ->
            val eventRows = if (driver) {
                rows.distinctBy { it.season to it.round }
            } else {
                // A constructor has two driver rows per GP. Treat the GP as one event
                // and mark it successful when at least one car satisfies the metric.
                rows.groupBy { it.season to it.round }.values.map { gpRows ->
                    gpRows.firstOrNull(predicate) ?: gpRows.first()
                }
            }.sortedWith(compareBy<HistoricalDatabase.RaceRecord> { it.season }.thenBy { it.round })
            var streak = 0
            var maximum = 0
            var bestRow = eventRows.lastOrNull() ?: return@mapNotNull null
            var previous: HistoricalDatabase.RaceRecord? = null
            eventRows.forEach { row ->
                val prior = previous
                val contiguous = prior == null ||
                    (row.season == prior.season && row.round == prior.round + 1) ||
                    (row.season == prior.season + 1 && prior.round == 30 && row.round == 1)
                if (!contiguous) streak = 0
                if (predicate(row)) {
                    streak++
                    if (streak > maximum) { maximum = streak; bestRow = row }
                } else streak = 0
                previous = row
            }
            if (maximum <= 0) null else if (driver) Aggregate(id, bestRow.driverName, bestRow.teamId, bestRow.teamName, maximum)
            else Aggregate(id, bestRow.teamName, id, bestRow.teamName, maximum)
        }
    }

    private fun topCard(title: String, unit: String, values: List<Aggregate>, driver: Boolean = true): Card? {
        val maximum = values.maxOfOrNull { it.value } ?: return null
        if (maximum <= 0) return null
        val winners = values.filter { it.value == maximum }.distinctBy { Triple(it.id, it.season, it.name) }
        val holders = winners.map { Holder(it.id, it.name, it.teamId, it.teamName, it.season, driver = driver) }
        val seasons = winners.mapNotNull { it.season }.distinct().sorted()
        val context = when {
            seasons.size == 1 -> "Temporada ${seasons.single()}"
            seasons.size > 1 -> "Temporadas ${seasons.joinToString(", ")}"
            else -> "Recorde de carreira"
        }
        val displayValue = when (unit) {
            "%" -> String.format(java.util.Locale.US, "%.2f", maximum / 10_000.0)
            "média" -> String.format(java.util.Locale.US, "%.2f", maximum / 100.0)
            else -> maximum.toString()
        }
        return Card(title, displayValue, unit, holders, context, if (winners.size > 1) "Empate: todos os recordistas estão preservados" else "")
    }

    private fun formatTime(ms: Long): String {
        val totalSeconds = ms / 1000
        val minutes = totalSeconds / 60
        val seconds = totalSeconds % 60
        return "%d:%02d.%03d".format(minutes, seconds, ms % 1000)
    }
}
