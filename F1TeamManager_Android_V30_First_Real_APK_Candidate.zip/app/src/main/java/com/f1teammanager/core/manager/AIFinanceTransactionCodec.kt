package com.f1teammanager.core.manager

import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.util.Base64
import java.util.zip.GZIPInputStream
import java.util.zip.GZIPOutputStream

/**
 * Compact, backwards-compatible encoding for the bounded AI finance display ledger.
 * Old snapshots contain Base64(UTF-8 lines); new large ledgers contain
 * Base64("GZ1:" + Base64(GZIP(UTF-8 lines))). The outer snapshot field layout is unchanged.
 */
internal object AIFinanceTransactionCodec {
    private const val COMPRESSED_PREFIX = "GZ1:"
    private const val COMPRESS_THRESHOLD_BYTES = 4 * 1024

    fun encode(transactions: List<String>): String {
        val raw = transactions.joinToString("\n").toByteArray(Charsets.UTF_8)
        val payload = if (raw.size >= COMPRESS_THRESHOLD_BYTES) {
            val compressed = ByteArrayOutputStream().also { buffer ->
                GZIPOutputStream(buffer).use { gzip -> gzip.write(raw) }
            }.toByteArray()
            COMPRESSED_PREFIX + Base64.getEncoder().encodeToString(compressed)
        } else {
            String(raw, Charsets.UTF_8)
        }
        return Base64.getEncoder().encodeToString(payload.toByteArray(Charsets.UTF_8))
    }

    fun decode(encoded: String): List<String> {
        val outer = runCatching { String(Base64.getDecoder().decode(encoded), Charsets.UTF_8) }
            .getOrElse { return emptyList() }
        val raw = if (outer.startsWith(COMPRESSED_PREFIX)) {
            runCatching {
                val compressed = Base64.getDecoder().decode(outer.removePrefix(COMPRESSED_PREFIX))
                GZIPInputStream(ByteArrayInputStream(compressed)).bufferedReader(Charsets.UTF_8).use { it.readText() }
            }.getOrElse { return emptyList() }
        } else outer // V1/V2 snapshots remain readable without migration.
        return raw.lineSequence().filter { it.isNotBlank() }.toList().takeLast(20_000)
    }
}
