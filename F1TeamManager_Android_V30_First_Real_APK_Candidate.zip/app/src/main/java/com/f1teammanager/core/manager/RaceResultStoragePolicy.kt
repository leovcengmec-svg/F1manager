package com.f1teammanager.core.manager

/**
 * Canonical storage-key policy for race results.
 * Legacy `race_<round>` records contain no season identity and therefore may only
 * be used to migrate season 1. Reading them in later seasons can silently display
 * an old result when the season-scoped record is missing.
 */
object RaceResultStoragePolicy {
    fun canonicalKey(season: Int, round: Int): String {
        require(season > 0) { "Season must be positive" }
        require(round in 1..30) { "Round must be in 1..30" }
        return "race_${season}_$round"
    }

    fun legacyReadKey(season: Int, round: Int): String? {
        require(season > 0) { "Season must be positive" }
        require(round in 1..30) { "Round must be in 1..30" }
        return if (season == 1) "race_$round" else null
    }
}
