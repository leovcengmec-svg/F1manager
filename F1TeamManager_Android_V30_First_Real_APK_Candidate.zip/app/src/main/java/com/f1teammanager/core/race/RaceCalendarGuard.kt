package com.f1teammanager.core.race

import com.f1teammanager.core.season.RoundDefinition

/** Lightweight guard shared by the instant and interactive race entry points. */
object RaceCalendarGuard {
    /** Returns a user-facing reason when the current UI/persisted calendar cannot start this GP. */
    fun validationError(
        currentWeek: Int,
        persistedRoundIndex: Int,
        scheduledRound: RoundDefinition?,
        displayedRound: RoundDefinition?,
        weekendInProgress: Boolean
    ): String? {
        if (persistedRoundIndex < 0) return "O índice do calendário é inválido. Nenhuma corrida foi simulada."
        val scheduled = scheduledRound
            ?: return "Não existe GP pendente neste índice do calendário. Nenhuma corrida foi simulada."
        val displayed = displayedRound
            ?: return "O GP exibido não corresponde ao calendário. Nenhuma corrida foi simulada."
        if (scheduled.round != persistedRoundIndex + 1 || displayed.round != scheduled.round ||
            displayed.weekOfSeason != scheduled.weekOfSeason || displayed.circuit != scheduled.circuit ||
            displayed.laps != scheduled.laps) {
            return "O GP exibido não corresponde ao próximo GP salvo no calendário. Nenhuma corrida foi simulada."
        }
        if (weekendInProgress) {
            return "Já existe um fim de semana de corrida em andamento. Retome essa sessão; nenhuma nova corrida foi iniciada."
        }
        if (currentWeek != scheduled.weekOfSeason) {
            return if (currentWeek < scheduled.weekOfSeason) {
                "O GP ${scheduled.round} acontece na semana ${scheduled.weekOfSeason}. Avance até essa semana antes de simular."
            } else {
                "A semana ${scheduled.weekOfSeason} do GP ${scheduled.round} já passou. O calendário precisa ser conferido; nenhuma corrida foi simulada."
            }
        }
        return null
    }
}
