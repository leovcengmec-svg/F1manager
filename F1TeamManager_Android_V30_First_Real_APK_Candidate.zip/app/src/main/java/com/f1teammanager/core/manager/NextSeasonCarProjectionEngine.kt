package com.f1teammanager.core.manager

/**
 * Canonical next-season car builder shared by rankings, team overview, market forecasts
 * and the AI rollover checkpoint. It deliberately accepts only committed investment
 * for the official Overall. A separate runway estimate may be shown by the UI, but it
 * must never change this official result.
 */
object NextSeasonCarProjectionEngine {
    /** Shared physical construction before the annual regulation and closure penalty. */
    fun buildUnregulatedGarage(
        previousGarage: TeamGarage,
        committedInvestment: Long,
        isPlayerTeam: Boolean,
        focus: CarDevelopmentFocus = CarDevelopmentFocus.BALANCED,
        technicalKnowledge: Map<CarComponent, Int> = emptyMap(),
        development: CarDevelopmentEngine = CarDevelopmentEngine()
    ): TeamGarage {
        val bounds = development.nextSeasonOverallBounds(previousGarage.teamAverageOverall)
        return if (isPlayerTeam) {
            development.buildNextSeasonGarage(
                previousGarage = previousGarage,
                invested = committedInvestment.coerceAtLeast(0L),
                focus = focus,
                technicalKnowledge = technicalKnowledge,
                minimumOverall = bounds.minimumOverall,
                maximumOverall = bounds.maximumOverall
            )
        } else {
            development.buildAiNextSeasonGarage(
                previousGarage = previousGarage,
                invested = committedInvestment.coerceAtLeast(0L),
                technicalKnowledge = technicalKnowledge
            )
        }
    }

    fun buildOfficialGarage(
        teamId: Int,
        previousGarage: TeamGarage,
        committedInvestment: Long,
        nextSeason: Int,
        regulationSeed: Int,
        isPlayerTeam: Boolean,
        focus: CarDevelopmentFocus = CarDevelopmentFocus.BALANCED,
        technicalKnowledge: Map<CarComponent, Int> = emptyMap(),
        applyFinancialPenalty: Boolean = false,
        development: CarDevelopmentEngine = CarDevelopmentEngine()
    ): TeamGarage {
        val built = buildUnregulatedGarage(
            previousGarage = previousGarage,
            committedInvestment = committedInvestment,
            isPlayerTeam = isPlayerTeam,
            focus = focus,
            technicalKnowledge = technicalKnowledge,
            development = development
        )
        val regulation = AnnualCarRegulationEngine.generateForCalendarYear(nextSeason, regulationSeed)
        val regulated = AnnualCarRegulationEngine.applyToGarage(built, regulation, teamId.hashCode())
        return if (applyFinancialPenalty) FinancialSeasonClosureEngine.applyGaragePenalty(regulated) else regulated
    }
}
