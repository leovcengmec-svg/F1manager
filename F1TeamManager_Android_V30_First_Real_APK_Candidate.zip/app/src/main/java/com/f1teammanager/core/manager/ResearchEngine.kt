package com.f1teammanager.core.manager

import com.f1teammanager.core.season.WorldDatabase
import kotlin.math.ceil
import kotlin.math.roundToInt

/**
 * Centro de P&D: desenvolve tecnologia, nunca altera um carro físico.
 * O fluxo é P&D -> Design -> Fábrica -> Peça -> Carro.
 */
class ResearchEngine {
    data class ResearchOption(
        val complexity: ResearchComplexity,
        val weeks: Int,
        val cost: Long,
        val riskLabel: String
    )

    fun timeMultiplier(level: Int): Double = when (level.coerceIn(0, 10)) {
        0 -> 1.00; 1 -> .97; 2 -> .94; 3 -> .91; 4 -> .88; 5 -> .85
        6 -> .82; 7 -> .79; 8 -> .76; 9 -> .72; else -> .68
    }

    fun baseWeeks(complexity: ResearchComplexity): Int = when (complexity) {
        ResearchComplexity.SIMPLE -> 2
        ResearchComplexity.MEDIUM -> 4
        ResearchComplexity.ADVANCED -> 6
        ResearchComplexity.EXPERIMENTAL -> 8
    }

    fun baseCost(complexity: ResearchComplexity): Long = when (complexity) {
        ResearchComplexity.SIMPLE -> 5_000_000L
        ResearchComplexity.MEDIUM -> 10_000_000L
        ResearchComplexity.ADVANCED -> 18_000_000L
        ResearchComplexity.EXPERIMENTAL -> 28_000_000L
    }

    fun calculatedWeeks(level: Int, complexity: ResearchComplexity): Int =
        (baseWeeks(complexity) * timeMultiplier(level)).roundToInt().coerceAtLeast(1)

    fun options(level: Int): List<ResearchOption> = ResearchComplexity.values().map { c ->
        ResearchOption(c, calculatedWeeks(level, c), baseCost(c), riskLabel(level, c))
    }

    fun maxImprovement(level: Int): IntRange = when (level.coerceIn(0, 10)) {
        0 -> 0..0
        1 -> 1..2
        2 -> 1..3
        3 -> 2..4
        4 -> 2..5
        5 -> 3..6
        6 -> 4..7
        7 -> 5..8
        8 -> 6..9
        9 -> 7..10
        else -> 8..12
    }

    fun failureChance(level: Int, complexity: ResearchComplexity): Int {
        val base = intArrayOf(20,18,16,14,12,10,8,6,4,2,1)[level.coerceIn(0,10)]
        val extra = when (complexity) {
            ResearchComplexity.SIMPLE -> 0
            ResearchComplexity.MEDIUM -> 2
            ResearchComplexity.ADVANCED -> 4
            ResearchComplexity.EXPERIMENTAL -> 7
        }
        return (base + extra).coerceAtMost(35)
    }

    private fun partialChance(level: Int, complexity: ResearchComplexity): Int {
        val base = when (complexity) {
            ResearchComplexity.SIMPLE -> 10
            ResearchComplexity.MEDIUM -> 15
            ResearchComplexity.ADVANCED -> 20
            ResearchComplexity.EXPERIMENTAL -> 25
        }
        return (base - level).coerceAtLeast(5)
    }

    fun riskLabel(level: Int, complexity: ResearchComplexity): String = when {
        failureChance(level, complexity) <= 5 -> "BAIXO"
        failureChance(level, complexity) <= 10 -> "MODERADO"
        failureChance(level, complexity) <= 20 -> "ALTO"
        else -> "MÁXIMO"
    }

    fun start(
        state: TeamManagerState,
        component: CarComponent,
        focus: ResearchFocus,
        complexity: ResearchComplexity,
        currentWeek: Int
    ): TeamManagerState {
        val level = state.facilities.level(FacilityType.RESEARCH)
        val activeLimit = when { level >= 8 -> 3; level >= 4 -> 2; else -> 1 }
        require(state.research.activeProjects.size < activeLimit) { "Capacidade atual do P&D: $activeLimit pesquisa(s) simultânea(s)." }
        require(currentWeek >= (state.research.cooldownUntil[component] ?: 0)) {
            "${componentLabel(component)} estará disponível novamente na semana ${state.research.cooldownUntil[component]}."
        }
        require(state.research.activeProjects.none { it.component == component }) { "Este componente já possui uma pesquisa em andamento." }

        val cost = baseCost(complexity)
        require(state.finance.budget >= cost) { "Orçamento insuficiente." }
        val garage = state.garage ?: TeamGarageFactory.fromCarState(state.car, state.playerTeamId, state.season)
        val latest = state.research.completedDesigns.filter { it.component == component }.maxByOrNull { it.version }
        val basePerformance = latest?.performance ?: maxOf(garage.car1.componentValue(component), garage.car2.componentValue(component))
        val baseReliability = latest?.reliability ?: maxOf(garage.car1.componentReliability(component), garage.car2.componentReliability(component))
        val previousVersion = latest?.version ?: 1
        val version = previousVersion + 1
        val range = maxImprovement(level)
        val total = if (range.first == range.last) range.first else kotlin.random.Random.nextInt(range.first, range.last + 1)
        val outcomeSeed = kotlin.random.Random.nextInt(0, 100)
        val failure = failureChance(level, complexity)
        val partial = partialChance(level, complexity)
        val outcome = when { outcomeSeed < failure -> ResearchOutcome.FAILURE; outcomeSeed < failure + partial -> ResearchOutcome.PARTIAL; else -> ResearchOutcome.SUCCESS }
        val effective = when (outcome) { ResearchOutcome.SUCCESS -> total; ResearchOutcome.PARTIAL -> (total * 0.5).roundToInt(); ResearchOutcome.FAILURE -> 0 }
        val performanceGain = when (focus) { ResearchFocus.PERFORMANCE -> (effective * .70).roundToInt(); ResearchFocus.RELIABILITY -> (effective * .30).roundToInt(); ResearchFocus.BALANCED -> (effective * .50).roundToInt() }
        val reliabilityGain = effective - performanceGain
        val project = ResearchProject(
            projectId = "R-${state.season}-${currentWeek}-${component.name}-V$version",
            component = component, version = version,
            basePerformance = basePerformance, baseReliability = baseReliability,
            targetPerformance = (basePerformance + performanceGain).coerceAtMost(100),
            targetReliability = (baseReliability + reliabilityGain).coerceAtMost(100),
            totalWeeks = calculatedWeeks(level, complexity),
            remainingWeeks = calculatedWeeks(level, complexity),
            cost = cost, startedWeek = currentWeek, focus = focus, complexity = complexity, outcome = outcome
        )
        return state.copy(
            research = state.research.copy(activeProjects = state.research.activeProjects + project),
            finance = state.finance.transact(-cost, "P&D ${componentLabel(component)} V$version • ${complexityLabel(complexity)}")
        )
    }

    fun advanceWeeks(state: TeamManagerState, weeks: Int, season: Int, currentWeek: Int): TeamManagerState {
        if (weeks <= 0 || state.research.activeProjects.isEmpty()) return state
        var projects = state.research.activeProjects
        var designs = state.research.completedDesigns
        var cooldowns = state.research.cooldownUntil
        val history = state.history.toMutableList()
        var weekCursor = currentWeek
        repeat(weeks) {
            weekCursor = (weekCursor + 1).coerceAtMost(56)
            val completionWeek = weekCursor
            val completed = projects.filter { it.remainingWeeks <= 1 }
            projects = projects.mapNotNull { p -> if (p.remainingWeeks > 1) p.copy(remainingWeeks = p.remainingWeeks - 1) else null }
            completed.forEach { p ->
                if (p.outcome == ResearchOutcome.FAILURE) {
                    history += "P&D falhou: ${componentLabel(p.component)} V${p.version}. Tecnologia anterior preservada."
                } else {
                    val d = ResearchDesign(p.projectId,p.component,p.version,p.targetPerformance,p.targetReliability,season,completionWeek)
                    designs = (designs + d).takeLast(60)
                    cooldowns = cooldowns + (p.component to (completionWeek + 4))
                    history += "P&D concluído: ${componentLabel(p.component)} V${p.version} (${p.basePerformance}→${p.targetPerformance} / ${p.baseReliability}→${p.targetReliability})."
                }
            }
        }
        return state.copy(research = TeamResearchState(projects, designs, cooldowns), history = history.takeLast(100))
    }

    fun complexityLabel(c: ResearchComplexity): String = when(c) {
        ResearchComplexity.SIMPLE -> "Simples"; ResearchComplexity.MEDIUM -> "Média"; ResearchComplexity.ADVANCED -> "Avançada"; ResearchComplexity.EXPERIMENTAL -> "Experimental"
    }
    fun focusLabel(f: ResearchFocus): String = when(f) {
        ResearchFocus.PERFORMANCE -> "Performance"; ResearchFocus.RELIABILITY -> "Confiabilidade"; ResearchFocus.BALANCED -> "Balanceada"
    }
    private fun componentLabel(c: CarComponent): String = when(c) {
        CarComponent.ENGINE -> "Motor"; CarComponent.CHASSIS -> "Chassi"; CarComponent.FRONT_WING -> "Asa dianteira"; CarComponent.REAR_WING -> "Asa traseira"; CarComponent.BRAKES -> "Freios"; CarComponent.ELECTRIC_POWER_UNIT -> "Unidade de potência elétrica"
    }
}
