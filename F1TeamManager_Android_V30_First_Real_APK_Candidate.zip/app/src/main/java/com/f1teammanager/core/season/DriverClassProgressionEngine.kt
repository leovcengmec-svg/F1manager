package com.f1teammanager.core.season

/**
 * Deterministic class ladder. Sporting promotions/demotions are reviewed biennially;
 * uncontracted-season demotions use their own consecutive full-season thresholds.
 */
object DriverClassProgressionEngine {
    /** Official ladder: Médio (Normal) is the lowest class. Fraco is legacy-only. */
    val ladder: List<String> = listOf("Médio", "Forte", "Pro", "Lenda")

    /** Converts legacy labels to the current official class ladder. */
    fun canonicalClass(driverClass: String): String? = when (driverClass) {
        "Fraco", "Normal", "Médio" -> "Médio"
        "Forte", "Pro", "Lenda" -> driverClass
        else -> null
    }

    data class SeasonPerformance(
        val season: Int,
        val averageIndex: Double,
        val raceCount: Int
    )

    data class Decision(
        val previousClass: String,
        val resultingClass: String,
        val direction: Direction,
        val twoSeasonAverage: Double,
        val reason: String = ""
    ) {
        val changed: Boolean get() = direction != Direction.KEEP
    }

    enum class Direction { PROMOTION, DEMOTION, KEEP }

    /** Shared guard for one-step class transitions, including legacy event adapters. */
    fun adjacentClass(driverClass: String, promote: Boolean, isChampion: Boolean = false): String? {
        val officialClass = canonicalClass(driverClass) ?: return null
        val index = ladder.indexOf(officialClass)
        val nextIndex = index + if (promote) 1 else -1
        if (nextIndex !in ladder.indices) return null
        val nextClass = ladder[nextIndex]
        if (promote && officialClass == "Pro" && nextClass == "Lenda" && !isChampion) return null
        return nextClass
    }

    fun minimumOverall(driverClass: String): Int = DriverProfileCatalog.minimumOverall(driverClass)
    fun maximumOverall(driverClass: String): Int = DriverProfileCatalog.ceiling(driverClass)

    /** Consecutive full-season absence clock: any active contract resets the sequence. */
    fun nextUncontractedSeasonCount(previousCount: Int, hasActiveContract: Boolean): Int =
        if (hasActiveContract) 0 else previousCount.coerceAtLeast(0) + 1

    /** Complete consecutive seasons without an active team contract required for demotion. */
    fun uncontractedSeasonsToDemote(driverClass: String): Int? = when (canonicalClass(driverClass)) {
        "Forte" -> 2
        "Pro" -> 3
        "Lenda" -> 5
        else -> null
    }

    /** One class step only; after demotion the caller resets the class-specific counter. */
    fun evaluateUncontractedAbsence(driverClass: String, consecutiveSeasons: Int): Decision? {
        val current = canonicalClass(driverClass) ?: return null
        val required = uncontractedSeasonsToDemote(current) ?: return null
        if (consecutiveSeasons < required) return null
        val next = adjacentClass(current, promote = false) ?: return null
        return Decision(
            previousClass = current,
            resultingClass = next,
            direction = Direction.DEMOTION,
            twoSeasonAverage = 0.0,
            reason = "ausência de equipe por $required temporadas consecutivas"
        )
    }

    /** A pilot needs at least 80% of the season's race weekends in both years. */
    fun minimumEvidenceRaces(expectedSeasonRounds: Int): Int =
        (expectedSeasonRounds * 0.80).toInt().let { if (it < expectedSeasonRounds * 0.80) it + 1 else it }.coerceAtLeast(1)

    fun evaluate(
        driverClass: String,
        overall: Int,
        previous: SeasonPerformance?,
        latest: SeasonPerformance?,
        expectedSeasonRounds: Int,
        /** The driver must have at least one career championship title to move Pro -> Lenda. */
        isChampion: Boolean = false
    ): Decision {
        val officialClass = canonicalClass(driverClass)
            ?: error("Classe de piloto inválida: $driverClass")
        val index = ladder.indexOf(officialClass)
        val average = if (previous != null && latest != null)
            (previous.averageIndex + latest.averageIndex) / 2.0 else 0.0
        val keep = Decision(officialClass, officialClass, Direction.KEEP, average, "sem evidência suficiente")
        if (previous == null || latest == null) return keep
        if (latest.season != previous.season + 1) return keep
        val minimumRaces = minimumEvidenceRaces(expectedSeasonRounds)
        if (previous.raceCount < minimumRaces || latest.raceCount < minimumRaces) return keep
        if (!previous.averageIndex.isFinite() || !latest.averageIndex.isFinite()) return keep

        // Promotion requires outperformance in BOTH complete seasons, a two-year
        // average of 105+, and an Overall already inside the next class band.
        if (index < ladder.lastIndex) {
            val nextClass = ladder[index + 1]
            val nextBandEntry = minimumOverall(nextClass)
            val titleRequired = officialClass != "Pro" || nextClass != "Lenda" || isChampion
            if (titleRequired && previous.averageIndex >= 100.0 && latest.averageIndex >= 100.0 &&
                average >= 105.0 && overall >= nextBandEntry + 1) {
                return Decision(officialClass, nextClass, Direction.PROMOTION, average, "desempenho excelente em duas temporadas consecutivas")
            }
        }

        // Demotion is deliberately conservative: two poor seasons and an Overall
        // already below the current class band, with a two-point safety margin.
        if (index > 0) {
            val currentBandEntry = minimumOverall(officialClass)
            if (previous.averageIndex <= 80.0 && latest.averageIndex <= 80.0 &&
                average <= 80.0 && overall <= currentBandEntry - 2) {
                return Decision(officialClass, ladder[index - 1], Direction.DEMOTION, average, "desempenho insuficiente em duas temporadas consecutivas")
            }
        }
        return keep
    }
}
