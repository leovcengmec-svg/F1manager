package com.f1teammanager.core.season

/**
 * Deterministic class ladder. Class is reviewed only at a season boundary and only
 * after two consecutive, sufficiently complete seasons of sporting evidence.
 */
object DriverClassProgressionEngine {
    val ladder: List<String> = listOf("Fraco", "Médio", "Forte", "Pro", "Lenda")

    data class SeasonPerformance(
        val season: Int,
        val averageIndex: Double,
        val raceCount: Int
    )

    data class Decision(
        val previousClass: String,
        val resultingClass: String,
        val direction: Direction,
        val twoSeasonAverage: Double
    ) {
        val changed: Boolean get() = previousClass != resultingClass
    }

    enum class Direction { PROMOTION, DEMOTION, KEEP }

    fun minimumOverall(driverClass: String): Int = DriverProfileCatalog.minimumOverall(driverClass)
    fun maximumOverall(driverClass: String): Int = DriverProfileCatalog.ceiling(driverClass)

    /** A pilot needs at least 80% of the season's race weekends in both years. */
    fun minimumEvidenceRaces(expectedSeasonRounds: Int): Int =
        (expectedSeasonRounds * 0.80).toInt().let { if (it < expectedSeasonRounds * 0.80) it + 1 else it }.coerceAtLeast(1)

    fun evaluate(
        driverClass: String,
        overall: Int,
        previous: SeasonPerformance?,
        latest: SeasonPerformance?,
        expectedSeasonRounds: Int
    ): Decision {
        require(driverClass in ladder) { "Classe de piloto inválida: $driverClass" }
        val index = ladder.indexOf(driverClass)
        val average = if (previous != null && latest != null)
            (previous.averageIndex + latest.averageIndex) / 2.0 else 0.0
        val keep = Decision(driverClass, driverClass, Direction.KEEP, average)
        if (previous == null || latest == null) return keep
        if (latest.season != previous.season + 1) return keep
        val minimumRaces = minimumEvidenceRaces(expectedSeasonRounds)
        if (previous.raceCount < minimumRaces || latest.raceCount < minimumRaces) return keep
        if (!previous.averageIndex.isFinite() || !latest.averageIndex.isFinite()) return keep

        // Promotion requires outperformance in BOTH complete seasons, a two-year
        // average of 105+, and an Overall already inside the next class band.
        if (index < ladder.lastIndex) {
            val nextClass = ladder[index + 1]
            val nextBandEntry = minimumOverall(nextClass)
            if (previous.averageIndex >= 100.0 && latest.averageIndex >= 100.0 &&
                average >= 105.0 && overall >= nextBandEntry + 1) {
                return Decision(driverClass, nextClass, Direction.PROMOTION, average)
            }
        }

        // Demotion is deliberately conservative: two poor seasons and an Overall
        // already below the current class band, with a two-point safety margin.
        if (index > 0) {
            val currentBandEntry = minimumOverall(driverClass)
            if (previous.averageIndex <= 80.0 && latest.averageIndex <= 80.0 &&
                average <= 80.0 && overall <= currentBandEntry - 2) {
                return Decision(driverClass, ladder[index - 1], Direction.DEMOTION, average)
            }
        }
        return keep
    }
}
