package com.f1teammanager.core.race

import kotlin.math.roundToInt

/** Regime de pista usado para decidir quando a IA precisa recalcular sua estratégia. */
enum class AiTyreWeatherRegime { DRY, INTERMEDIATE, WET }

/** Plano privado de cada carro da IA; não é exposto como controle do jogador na interface. */
data class AiTyreStrategyState(
    val teamPlanId: String,
    var activePlanId: String,
    var planStintIndex: Int,
    val plans: Map<String, TyrePlan>,
    val stintLaps: List<Int>,
    var weatherRegime: AiTyreWeatherRegime
)

/**
 * Planejamento estratégico dos pneus dos adversários.
 *
 * A equipe define uma preferência-base para o GP. Cada piloto recebe uma avaliação
 * individual, considerando conservação, velocidade, aderência, consistência e posição
 * de largada. Os dois carros de uma equipe evitam copiar o mesmo plano quando existem
 * alternativas válidas, como acontece com estratégias divididas entre companheiros.
 */
object AiTyreStrategyPlanner {
    fun weatherRegime(weather: Weather): AiTyreWeatherRegime = when (weather) {
        Weather.DRY, Weather.CLOUDY -> AiTyreWeatherRegime.DRY
        Weather.LIGHT_RAIN, Weather.MEDIUM_RAIN -> AiTyreWeatherRegime.INTERMEDIATE
        Weather.HEAVY_RAIN -> AiTyreWeatherRegime.WET
    }

    /**
     * Distribui exatamente as voltas da prova entre os stints sem exceder a vida-base
     * de nenhum composto. Os planos secos guardam capacidade por composto; aqui essa
     * capacidade é convertida em janelas reais para a distância desta corrida.
     */
    fun allocateStintLaps(totalLaps: Int, plan: TyrePlan): List<Int> {
        require(totalLaps > 0) { "A estratégia precisa cobrir pelo menos uma volta" }
        require(plan.sequence.isNotEmpty()) { "A estratégia não possui compostos" }
        require(plan.sequence.size <= totalLaps) { "A estratégia possui mais stints que voltas restantes" }

        if (plan.stintLaps.size == plan.sequence.size &&
            plan.stintLaps.sum() == totalLaps &&
            plan.stintLaps.indices.all { plan.stintLaps[it] in 1..plan.sequence[it].targetLaps }
        ) return plan.stintLaps

        val capacities = plan.sequence.map { it.targetLaps.coerceAtLeast(1) }
        require(capacities.sum() >= totalLaps) {
            "O plano ${plan.id} não cobre $totalLaps voltas: capacidade ${capacities.sum()}"
        }

        var remainingLaps = totalLaps
        var remainingCapacity = capacities.sum()
        val allocation = mutableListOf<Int>()
        capacities.forEachIndexed { index, capacity ->
            val futureCapacity = capacities.drop(index + 1).sum()
            val remainingStints = capacities.size - index - 1
            val minimumHere = (remainingLaps - futureCapacity).coerceAtLeast(1)
            val maximumHere = minOf(capacity, remainingLaps - remainingStints)
            val proportional = (remainingLaps * capacity.toDouble() / remainingCapacity).roundToInt()
            val stintLaps = proportional.coerceIn(minimumHere, maximumHere)
            allocation += stintLaps
            remainingLaps -= stintLaps
            remainingCapacity -= capacity
        }
        check(remainingLaps == 0 && allocation.sum() == totalLaps)
        check(allocation.indices.all { allocation[it] in 1..plan.sequence[it].targetLaps })
        return allocation
    }

    /** Preferência-base de estratégia definida pela equipe para o circuito e clima. */
    fun chooseTeamPlanId(
        plans: Map<String, TyrePlan>,
        teamDrivers: List<RaceParticipant>,
        circuitId: Int,
        totalLaps: Int,
        weather: Weather
    ): String {
        require(plans.isNotEmpty()) { "Nenhum plano de pneus disponível para a equipe" }
        require(teamDrivers.isNotEmpty()) { "A equipe não possui pilotos para planejar os pneus" }
        val ids = plans.keys.sorted()
        val averageCarPerformance = teamDrivers.map { driver ->
            (driver.enginePerformance + driver.chassisPerformance +
                driver.frontWingPerformance + driver.rearWingPerformance +
                driver.brakesPerformance + driver.electricPowerUnitPerformance) / 6
        }.average().roundToInt()
        val teamId = teamDrivers.first().teamId
        val preferenceSeed = teamId * 31 + circuitId * 17 + totalLaps * 7 +
            averageCarPerformance / 5 + weather.ordinal * 13
        return ids[Math.floorMod(preferenceSeed, ids.size)]
    }

    /**
     * Escolhe o plano individual mais adequado. Quando há plano do companheiro
     * disponível, ele é excluído da lista para criar uma divisão estratégica real.
     */
    fun chooseDriverPlanId(
        plans: Map<String, TyrePlan>,
        participant: RaceParticipant,
        totalLaps: Int,
        weather: Weather,
        teamPreferredPlanId: String,
        gridPosition: Int,
        teammatePlanId: String? = null,
        circuitId: Int = 0
    ): String {
        require(plans.isNotEmpty()) { "Nenhum plano de pneus disponível para o piloto" }
        val allCandidates = plans.values.sortedBy { it.id }
        val teammatePlan = teammatePlanId?.let(plans::get)
        val distinctCandidates = if (teammatePlan != null && allCandidates.size > 1) {
            allCandidates.filterNot { candidate ->
                candidate.sequence == teammatePlan.sequence &&
                    allocateStintLaps(totalLaps, candidate) == allocateStintLaps(totalLaps, teammatePlan)
            }.ifEmpty { allCandidates }
        } else allCandidates

        fun score(plan: TyrePlan): Double {
            val stints = allocateStintLaps(totalLaps, plan)
            val total = totalLaps.toDouble()
            val averagePace = plan.sequence.indices.sumOf { index ->
                TyreModel.performanceMultiplier(plan.sequence[index], weather) * stints[index]
            } / total
            val stops = (plan.sequence.size - 1).coerceAtLeast(0)
            // 21 s por parada, convertido em fração do tempo estimado da prova.
            val pitPenalty = stops * 21_000.0 / (90_000.0 * total)
            val wearLoad = plan.sequence.indices.sumOf { index ->
                val ratio = stints[index].toDouble() / plan.sequence[index].targetLaps.coerceAtLeast(1)
                ratio * ratio * stints[index]
            } / total
            val tyreManagement = ((50 - participant.tyreWear).coerceIn(-50, 50)) / 50.0
            val wearPenalty = wearLoad * tyreManagement * 0.0022
            val softShare = plan.sequence.indices.sumOf { index ->
                if (plan.sequence[index] == Tyre.SOFT) stints[index] else 0
            } / total
            val paceSkill = (participant.driverSpeed - 50) * 0.000035 +
                (participant.tyreGrip - 50) * 0.000025
            val softPaceBonus = softShare * paceSkill
            val consistencyPenalty = stops * (100 - participant.consistency).coerceIn(0, 100) * 0.000012
            val gridTactic = when {
                gridPosition >= 30 -> -softShare * 0.0012
                gridPosition <= 8 -> stops * 0.00018
                else -> 0.0
            }
            val teamPreference = if (plan.id == teamPreferredPlanId) -0.0032 else 0.0
            // Pequena variação estável por piloto/circuito evita decisões idênticas
            // mesmo entre pilotos com atributos muito próximos.
            val planIndex = allCandidates.indexOfFirst { it.id == plan.id }
            val tieBreak = (Math.floorMod(
                participant.driverId * 37 + participant.teamId * 19 + circuitId * 11 + planIndex * 7,
                17
            ) - 8) * 0.00010
            return averagePace + pitPenalty + wearPenalty + consistencyPenalty +
                gridTactic + teamPreference - softPaceBonus + tieBreak
        }

        return distinctCandidates.minWithOrNull(compareBy<TyrePlan> { score(it) }.thenBy { it.id })?.id
            ?: allCandidates.first().id
    }
}
