package com.f1teammanager.core.manager

/**
 * Canonical ordered commit plan for one completed GP. The keys intentionally match
 * the persisted V345+ SharedPreferences keys; changing them would orphan old markers.
 */
object RaceFinalizationPlan {
    const val PLAYER_FINANCE = "player_finance"
    const val PLAYER_SALARY = "player_salary"
    const val AI_FINANCE = "ai_finance"
    const val AI_SPONSORSHIP = "ai_sponsorship"
    const val RACE_RECORD = "race_record"
    const val DRIVER_EVOLUTION = "driver_evolution"
    const val RACE_NEWS = "race_news"
    const val SEASON_PRIZES = "season_prizes"
    const val PERSIST_FINAL_STATE = "persist_final_state"
    const val COMPLETE = "complete"

    fun steps(round: Int, totalRounds: Int): List<String> {
        require(totalRounds > 0) { "Total rounds must be positive" }
        require(round in 1..totalRounds) { "Round must be within the season" }
        val base = listOf(
            PLAYER_FINANCE, PLAYER_SALARY, AI_FINANCE, AI_SPONSORSHIP,
            RACE_RECORD, DRIVER_EVOLUTION, RACE_NEWS
        )
        return if (round == totalRounds) base + SEASON_PRIZES + PERSIST_FINAL_STATE
        else base + PERSIST_FINAL_STATE
    }
}
