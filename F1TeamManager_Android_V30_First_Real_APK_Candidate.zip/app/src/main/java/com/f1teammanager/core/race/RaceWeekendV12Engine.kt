package com.f1teammanager.core.race

import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

/**
 * V12 race-weekend control layer. The manager handles strategy decisions;
 * the driver autonomously manages DRS/ERS execution every lap.
 */
class RaceWeekendV12Engine(private val random: Random = Random(20261003)) {
    private var circuit: RaceCircuit? = null
    private var pilot: RaceParticipant? = null
    private var control: DriverRaceControl? = null
    private var lap: Int = 0
    private var neutral: Neutralisation = Neutralisation.GREEN
    private var neutralEnd: Int = 0
    private var pending: ManagerDecisionRequest? = null
    private var redFlagUsed = false
    private var completed = false

    fun start(participant: RaceParticipant, circuit: RaceCircuit, startingTyre: Tyre = Tyre.MEDIUM): RaceStep {
        this.pilot = participant
        this.circuit = circuit
        this.control = DriverRaceControl(participant.driverId, tyre = startingTyre)
        this.lap = 0
        this.neutral = Neutralisation.GREEN
        this.neutralEnd = 0
        this.pending = null
        this.redFlagUsed = false
        this.completed = false
        return nextStep()
    }

    fun setDriverStrategy(mode: DriverStrategyMode): RaceStep {
        val c = control ?: error("Corrida não iniciada")
        check(pending == null) { "Resolva a decisão pendente antes de mudar a estratégia" }
        c.mode = mode
        return snapshot(listOf(RaceControlEvent(lap, c.driverId, "Estratégia alterada para $mode", false)), null, false)
    }

    fun advance(): RaceStep {
        check(pending == null) { "Resolva a decisão estratégica pendente antes de avançar" }
        return nextStep()
    }

    fun choose(action: ManagerDecisionAction): RaceStep {
        val req = pending ?: error("Não há decisão estratégica pendente")
        val c = control ?: error("Corrida não iniciada")
        when (action) {
            ManagerDecisionAction.BOX,
            ManagerDecisionAction.CHANGE_STRATEGY -> {
                c.pitStops++
                c.tyreAge = 0
                c.tyre = when (c.tyre) {
                    Tyre.SOFT -> Tyre.MEDIUM
                    Tyre.MEDIUM -> Tyre.HARD
                    Tyre.HARD -> Tyre.MEDIUM
                    Tyre.INTERMEDIATE -> Tyre.WET
                    Tyre.WET -> Tyre.INTERMEDIATE
                }
            }
            ManagerDecisionAction.EXTEND_STINT,
            ManagerDecisionAction.STAY_OUT -> Unit
            ManagerDecisionAction.SAVE_FUEL -> c.mode = DriverStrategyMode.DEFENSE
            ManagerDecisionAction.RESTART_ATTACK -> c.mode = DriverStrategyMode.ATTACK
            ManagerDecisionAction.RESTART_BALANCED -> c.mode = DriverStrategyMode.BALANCED
            ManagerDecisionAction.RESTART_DEFENSE -> c.mode = DriverStrategyMode.DEFENSE
            ManagerDecisionAction.CHANGE_TYRE_SOFT -> { c.tyre = Tyre.SOFT; c.tyreAge = 0 }
            ManagerDecisionAction.CHANGE_TYRE_MEDIUM -> { c.tyre = Tyre.MEDIUM; c.tyreAge = 0 }
            ManagerDecisionAction.CHANGE_TYRE_HARD -> { c.tyre = Tyre.HARD; c.tyreAge = 0 }
            ManagerDecisionAction.CHANGE_TYRE_INTERMEDIATE -> { c.tyre = Tyre.INTERMEDIATE; c.tyreAge = 0 }
            ManagerDecisionAction.CHANGE_TYRE_WET -> { c.tyre = Tyre.WET; c.tyreAge = 0 }
        }
        if (req.type == ManagerDecisionType.RED_FLAG) {
            neutral = Neutralisation.GREEN
            neutralEnd = lap
            c.fuelKg = 110.0
        }
        pending = null
        return nextStep()
    }

    private fun nextStep(): RaceStep {
        val p = pilot ?: error("Corrida não iniciada")
        val ckt = circuit ?: error("Circuito não definido")
        val s = control ?: error("Estado não definido")
        if (completed) return snapshot(emptyList(), null, true)
        if (pending != null) return snapshot(emptyList(), pending, false)

        lap++
        if (lap > ckt.laps) {
            completed = true
            s.finished = true
            return snapshot(listOf(RaceControlEvent(lap - 1, p.driverId, "Bandeirada — corrida finalizada", true)), null, true)
        }

        val events = mutableListOf<RaceControlEvent>()
        if (neutral != Neutralisation.GREEN && lap > neutralEnd) {
            events += RaceControlEvent(lap, null, if (neutral == Neutralisation.SAFETY_CAR) "Safety Car recolhido" else "VSC encerrado", true)
            neutral = Neutralisation.GREEN
        }

        // Large events are intentionally rare and only one red flag can happen in a race.
        if (neutral == Neutralisation.GREEN) {
            val roll = random.nextDouble()
            when {
                !redFlagUsed && roll < 0.0025 * ckt.safetyCarRisk -> {
                    redFlagUsed = true
                    neutral = Neutralisation.SAFETY_CAR
                    neutralEnd = min(ckt.laps, lap + random.nextInt(1, 3))
                    events += RaceControlEvent(lap, null, "BANDEIRA VERMELHA — corrida interrompida", true)
                    pending = ManagerDecisionRequest(lap, ManagerDecisionType.RED_FLAG, p.driverId,
                        "Corrida interrompida. Escolha pneus e postura para a relargada.",
                        listOf(ManagerDecisionAction.CHANGE_TYRE_SOFT, ManagerDecisionAction.CHANGE_TYRE_MEDIUM,
                            ManagerDecisionAction.CHANGE_TYRE_HARD, ManagerDecisionAction.RESTART_ATTACK,
                            ManagerDecisionAction.RESTART_BALANCED, ManagerDecisionAction.RESTART_DEFENSE))
                    return snapshot(events, pending, false)
                }
                roll < 0.010 * ckt.safetyCarRisk -> {
                    neutral = Neutralisation.SAFETY_CAR
                    neutralEnd = min(ckt.laps, lap + random.nextInt(2, 5))
                    events += RaceControlEvent(lap, null, "SAFETY CAR DEPLOYED", true)
                    pending = ManagerDecisionRequest(lap, ManagerDecisionType.SAFETY_CAR, p.driverId,
                        "Safety Car na pista. Alterar a estratégia?", listOf(ManagerDecisionAction.BOX, ManagerDecisionAction.STAY_OUT, ManagerDecisionAction.EXTEND_STINT))
                    return snapshot(events, pending, false)
                }
                roll < 0.028 * ckt.safetyCarRisk -> {
                    neutral = Neutralisation.VSC
                    neutralEnd = min(ckt.laps, lap + random.nextInt(1, 3))
                    events += RaceControlEvent(lap, null, "VIRTUAL SAFETY CAR DEPLOYED", true)
                    pending = ManagerDecisionRequest(lap, ManagerDecisionType.VSC, p.driverId,
                        "VSC ativo. Aproveitar a janela estratégica?", listOf(ManagerDecisionAction.BOX, ManagerDecisionAction.STAY_OUT, ManagerDecisionAction.EXTEND_STINT))
                    return snapshot(events, pending, false)
                }
            }
        }

        // Driver autonomously manages DRS and ERS.
        val drsOpportunity = random.nextDouble() < (if (s.mode == DriverStrategyMode.ATTACK) .72 else if (s.mode == DriverStrategyMode.DEFENSE) .28 else .50)
        if (drsOpportunity && neutral == Neutralisation.GREEN) {
            s.drsUses++
            events += RaceControlEvent(lap, p.driverId, "DRS utilizado automaticamente pelo piloto", true)
        }
        val ersSpend = when (s.mode) {
            DriverStrategyMode.ATTACK -> 18.0
            DriverStrategyMode.BALANCED -> 10.0
            DriverStrategyMode.DEFENSE -> 4.0
        }
        if (neutral == Neutralisation.GREEN && s.ersPercent >= ersSpend) {
            s.ersPercent -= ersSpend
            s.ersDeployments++
            events += RaceControlEvent(lap, p.driverId, "Bateria/ERS usado automaticamente pelo piloto", true)
        } else {
            s.ersPercent = min(100.0, s.ersPercent + 8.0)
            events += RaceControlEvent(lap, p.driverId, "Piloto recuperando energia da bateria", true)
        }

        s.fuelKg = max(0.0, s.fuelKg - 110.0 / ckt.laps)
        s.tyreAge++
        if (s.fuelKg <= 12.0 && !s.alertFuelSent) {
            s.alertFuelSent = true
            pending = ManagerDecisionRequest(lap, ManagerDecisionType.FUEL_CRITICAL, p.driverId,
                "Piloto: combustível baixo. Precisamos administrar ou ir para o box.",
                listOf(ManagerDecisionAction.BOX, ManagerDecisionAction.EXTEND_STINT, ManagerDecisionAction.STAY_OUT))
            events += RaceControlEvent(lap, p.driverId, "ALERTA DO PILOTO: combustível baixo")
            return snapshot(events, pending, false)
        }
        if (s.tyreAge >= 18 && !s.alertTyreSent) {
            s.alertTyreSent = true
            pending = ManagerDecisionRequest(lap, ManagerDecisionType.TYRE_CRITICAL, p.driverId,
                "Piloto: pneu perdendo desempenho. Recomendo avaliar o box.",
                listOf(ManagerDecisionAction.BOX, ManagerDecisionAction.EXTEND_STINT, ManagerDecisionAction.STAY_OUT))
            events += RaceControlEvent(lap, p.driverId, "ALERTA DO PILOTO: pneu desgastado")
            return snapshot(events, pending, false)
        }
        return snapshot(events, null, lap >= ckt.laps)
    }

    private fun snapshot(events: List<RaceControlEvent>, decision: ManagerDecisionRequest?, done: Boolean): RaceStep =
        RaceStep(lap, circuit?.laps ?: 0, neutral, events, decision, control ?: error("Estado não definido"), done)
}
