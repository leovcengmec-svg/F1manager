package com.f1teammanager.core.race

import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

/**
 * Complete deterministic race-weekend core. No UI/network dependency.
 * Pipeline: qualifying -> grid -> strategy -> lap simulation -> incidents/wear ->
 * VSC/SC -> pit stops -> overtakes -> fastest lap -> classification -> points.
 */
class RaceWeekendEngine(seed: Int = 20261003) {
    private val random = Random(seed)
    private val pace = PitwallPaceModel(random)
    private val incidents = IncidentEngine(random)

    fun qualify(participants: List<RaceParticipant>, circuit: RaceCircuit): QualifyingResult {
        require(participants.size == 80) { "Qualificação oficial exige 80 pilotos" }
        fun runPhase(name: String, pool: List<RaceParticipant>): Pair<List<QualifyingEntry>, List<RaceParticipant>> {
            val ranked = pool.map { p -> QualifyingEntry(p.driverId, 0, qualifyingTime(p, circuit)) }
                .sortedWith(compareBy<QualifyingEntry> { it.lapTimeMs }.thenBy { it.driverId })
                .mapIndexed { i,e -> e.copy(position=i+1) }
            return ranked to pool
        }
        val q1Rank = participants.map { p -> QualifyingEntry(p.driverId,0,qualifyingTime(p,circuit)) }
            .sortedWith(compareBy<QualifyingEntry>{it.lapTimeMs}.thenBy{it.driverId})
        val q1 = q1Rank.mapIndexed { i,e -> e.copy(position=i+1) }
        val q2Drivers = q1.take(50).map { e -> participants.first { it.driverId == e.driverId } }
        val q2Rank = q2Drivers.map { p -> QualifyingEntry(p.driverId,0,qualifyingTime(p,circuit)-80L) }
            .sortedWith(compareBy<QualifyingEntry>{it.lapTimeMs}.thenBy{it.driverId})
        val q2 = q2Rank.mapIndexed { i,e -> e.copy(position=i+1) }
        val q3Drivers = q2.take(20).map { e -> participants.first { it.driverId == e.driverId } }
        val q3Rank = q3Drivers.map { p -> QualifyingEntry(p.driverId,0,qualifyingTime(p,circuit)-160L) }
            .sortedWith(compareBy<QualifyingEntry>{it.lapTimeMs}.thenBy{it.driverId})
        val q3 = q3Rank.mapIndexed { i,e -> e.copy(position=i+1) }

        val q2OrderedIds = q2.map { it.driverId }.toSet()
        val q3OrderedIds = q3.map { it.driverId }.toSet()
        val finalGrid = (q3.map { it.copy(position = it.position) } +
            q2.filter { it.driverId !in q3OrderedIds }.mapIndexed { i,e -> e.copy(position=21+i) } +
            q1.filter { it.driverId !in q2OrderedIds }.mapIndexed { i,e -> e.copy(position=51+i) })
            .sortedBy { it.position }
        return QualifyingResult(
            grid=finalGrid,
            phases=listOf(
                QualifyingPhase("Q1", q1, q1.drop(50).map { it.driverId }),
                QualifyingPhase("Q2", q2, q2.drop(20).map { it.driverId }),
                QualifyingPhase("Q3", q3, emptyList())
            )
        )
    }

    fun defaultStrategy(p: RaceParticipant, c: RaceCircuit): RaceStrategy {
        val stops = when (random.nextInt(100)) { in 0..54 -> 1; in 55..92 -> 2; else -> 3 }
        val windows = when (stops) {
            1 -> listOf(c.laps * .40 to c.laps * .60)
            2 -> listOf(c.laps * .23 to c.laps * .34, c.laps * .58 to c.laps * .74)
            else -> listOf(c.laps * .18 to c.laps * .27, c.laps * .43 to c.laps * .57, c.laps * .70 to c.laps * .84)
        }
        val pits = windows.map { w ->
            val lo = max(2, w.first.toInt())
            val hi = max(lo, w.second.toInt())
            random.nextInt(lo, hi + 1)
        }
        val start = if (random.nextDouble() < .22) Tyre.SOFT else Tyre.MEDIUM
        return RaceStrategy(p.driverId, stops, pits, start, listOf(start), true, true)
    }

    fun race(participants: List<RaceParticipant>, circuit: RaceCircuit, strategies: Map<Int, RaceStrategy> = emptyMap()): RaceResult {
        require(participants.isNotEmpty()) { "A corrida precisa de participantes" }
        val grid = qualify(participants, circuit)
        val state = participants.associate { p ->
            p.driverId to DriverState(p, grid.grid.first { it.driverId == p.driverId }.position, strategies[p.driverId] ?: defaultStrategy(p, circuit))
        }.toMutableMap()
        val events = mutableListOf<LapEvent>()
        var neutral = Neutralisation.GREEN
        var neutralEndLap = 0
        var weather = Weather.DRY
        var fastestId: Int? = null
        var fastest = Long.MAX_VALUE
        var safetyLaps = 0
        var vscLaps = 0
        val totalFuel = 110.0

        for (lap in 1..circuit.laps) {
            if (neutral != Neutralisation.GREEN && lap > neutralEndLap) {
                events += LapEvent(lap, null, if (neutral == Neutralisation.SAFETY_CAR) EventType.SAFETY_CAR_ENDED else EventType.VSC_ENDED, "Neutralização encerrada")
                neutral = Neutralisation.GREEN
            }

            if (weather == Weather.DRY && random.nextDouble() < 0.002) {
                weather = Weather.CLOUDY
                events += LapEvent(lap, null, EventType.WEATHER_CHANGE, "Nublado")
            } else if (weather == Weather.CLOUDY && random.nextDouble() < 0.04) {
                weather = Weather.LIGHT_RAIN
                events += LapEvent(lap, null, EventType.WEATHER_CHANGE, "Chuva fraca")
            } else if (weather == Weather.LIGHT_RAIN && random.nextDouble() < 0.08) {
                weather = Weather.MEDIUM_RAIN
                events += LapEvent(lap, null, EventType.WEATHER_CHANGE, "Chuva média")
            } else if (weather == Weather.MEDIUM_RAIN && random.nextDouble() < 0.06) {
                weather = Weather.HEAVY_RAIN
                events += LapEvent(lap, null, EventType.WEATHER_CHANGE, "Chuva forte")
            }

            if (neutral == Neutralisation.GREEN) {
                when (val n = incidents.neutralisation(circuit)) {
                    Neutralisation.SAFETY_CAR -> {
                        neutral = n; neutralEndLap = min(circuit.laps, lap + random.nextInt(2, 5))
                        events += LapEvent(lap, null, EventType.SAFETY_CAR_DEPLOYED, "Safety Car")
                    }
                    Neutralisation.VSC -> {
                        neutral = n; neutralEndLap = min(circuit.laps, lap + random.nextInt(1, 3))
                        events += LapEvent(lap, null, EventType.VSC_DEPLOYED, "VSC")
                    }
                    Neutralisation.GREEN -> Unit
                }
            }
            if (neutral == Neutralisation.SAFETY_CAR) safetyLaps++ else if (neutral == Neutralisation.VSC) vscLaps++

            val active = state.values.filter { !it.dnf }.sortedWith(compareBy<DriverState> { it.totalTimeMs }.thenBy { it.grid })
            for (s in active) {
                val plannedPit = s.strategy.pitLaps.contains(lap)
                val shouldReact = s.strategy.reactToSafetyCar && neutral != Neutralisation.GREEN
                val weatherPit = s.strategy.reactToWeather && ((weather == Weather.HEAVY_RAIN && s.tyre.wetSuitability < 90) || ((weather == Weather.LIGHT_RAIN || weather == Weather.MEDIUM_RAIN) && s.tyre.wetSuitability < 65))
                if (plannedPit || shouldReact && lap > 1 && random.nextDouble() < .30 || weatherPit && random.nextDouble() < .65) {
                    if (lap < circuit.laps) {
                        s.totalTimeMs += if (neutral == Neutralisation.SAFETY_CAR) 12000 else if (neutral == Neutralisation.VSC) 17000 else 25000
                        s.stopCount++
                        s.stintLaps = 0
                        s.tyre = chooseNextTyre(s, weather)
                        events += LapEvent(lap, s.p.driverId, EventType.PIT_STOP, "Pit stop ${s.stopCount}: ${s.tyre}")
                    }
                }

                val incident = incidents.driverIncident(s.p, circuit, lap, circuit.laps, s.wear)
                if (incident.type != null) {
                    s.dnf = true
                    s.laps = lap - 1
                    events += LapEvent(lap, s.p.driverId, incident.type, incident.detail)
                    events += LapEvent(lap, s.p.driverId, EventType.DNF, "DNF")
                    continue
                }

                val remaining = max(1, circuit.laps - lap + 1)
                val fuelKg = totalFuel / circuit.laps * remaining
                val ahead = active.firstOrNull { it != s && it.totalTimeMs < s.totalTimeMs && s.totalTimeMs - it.totalTimeMs <= 1500 }
                val dirty = ahead != null
                var lapMs = pace.lapTime(s.p, circuit, fuelKg, s.stintLaps, s.tyre, dirty)
                lapMs += when (neutral) { Neutralisation.SAFETY_CAR -> 9000; Neutralisation.VSC -> 4500; Neutralisation.GREEN -> 0 }
                if (weather != Weather.DRY) lapMs += rainPenalty(s.p, s.tyre, weather)
                s.totalTimeMs += lapMs
                s.lastLapMs = lapMs
                s.laps = lap
                s.stintLaps++
                s.wear = min(100, s.wear + max(1, (100 - s.p.tyreWear) / 20 + 1))
                if (s.wear >= 75 && !s.wearWarningSent) {
                    s.wearWarningSent = true
                    events += LapEvent(lap, s.p.driverId, EventType.WEAR_WARNING, "Desgaste elevado")
                }
                if (lapMs < s.bestLapMs) {
                    s.bestLapMs = lapMs
                    if (lapMs < fastest) { fastest = lapMs; fastestId = s.p.driverId; events += LapEvent(lap, s.p.driverId, EventType.FASTEST_LAP, "Melhor volta") }
                }
            }

            // Passagem de posição: a ordem é determinada pelo tempo acumulado; o evento
            // só é criado quando um carro que estava atrás termina a volta à frente.
            val after = state.values.filter { !it.dnf }.sortedWith(compareBy<DriverState> { it.totalTimeMs }.thenBy { it.grid })
            after.forEachIndexed { idx, attacker ->
                val previous = attacker.lastPosition
                val current = idx + 1
                if (previous > current && previous != Int.MAX_VALUE) {
                    events += LapEvent(lap, attacker.p.driverId, EventType.OVERTAKE, "Ganhou ${previous - current} posição(ões)")
                }
                attacker.lastPosition = current
            }
        }

        val classification = state.values.sortedWith(compareByDescending<DriverState> { it.laps }.thenBy { it.totalTimeMs })
            .mapIndexed { idx, s -> FinishEntry(idx + 1, s.p.driverId, s.p.driverName, s.p.teamName, s.laps, s.totalTimeMs, if (s.dnf) "DNF" else "FINISHED", s.tyre, s.stopCount) }
        val base = RaceResult(classification, events, fastestId, weather, emptyMap(), safetyLaps, vscLaps)
        return base.copy(points = ChampionshipEngine.award(base))
    }

    private fun qualifyingTime(p: RaceParticipant, c: RaceCircuit): Long {
        val driver = p.qualifying * .38 + p.driverSpeed * .24 + p.consistency * .16 + p.racecraft * .22
        // Potencial do carro é modulado pela capacidade do piloto de extrair o carro.
        val extraction = ((p.driverSpeed - 70) * .22 + (p.consistency - 70) * .10)
        val effectiveCar = (p.carSpeed + extraction).coerceIn(1.0,100.0)
        val car = effectiveCar * .62 + p.enginePower * c.powerFactor * .23 + p.tyreGrip * .15
        val jitter = random.nextLong(-180, 181)
        return (c.baseLapTimeMs.toDouble() - driver * 19.0 - car * 8.8 + jitter).toLong().coerceAtLeast(45_000L)
    }

    private fun chooseNextTyre(s: DriverState, weather: Weather): Tyre = when (weather) {
        Weather.HEAVY_RAIN -> Tyre.WET
        Weather.LIGHT_RAIN, Weather.MEDIUM_RAIN -> Tyre.INTERMEDIATE
        Weather.CLOUDY, Weather.DRY -> when (s.stopCount % 3) { 1 -> Tyre.HARD; 2 -> Tyre.SOFT; else -> Tyre.MEDIUM }
    }

    private fun rainPenalty(p: RaceParticipant, tyre: Tyre, weather: Weather): Long {
        val mismatch = when (weather) {
            Weather.LIGHT_RAIN -> max(0, 82 - tyre.wetSuitability)
            Weather.MEDIUM_RAIN -> max(0, 90 - tyre.wetSuitability)
            Weather.HEAVY_RAIN -> max(0, 100 - tyre.wetSuitability)
            Weather.CLOUDY, Weather.DRY -> 0
        }
        return (mismatch * 35L - p.consistency * 2L).coerceAtLeast(0)
    }

    private data class DriverState(
        val p: RaceParticipant,
        val grid: Int,
        val strategy: RaceStrategy,
        var totalTimeMs: Long = 0,
        var lastLapMs: Long = 0,
        var bestLapMs: Long = Long.MAX_VALUE,
        var laps: Int = 0,
        var stintLaps: Int = 0,
        var stopCount: Int = 0,
        var dnf: Boolean = false,
        var wear: Int = p.chassisWear,
        var wearWarningSent: Boolean = false,
        var tyre: Tyre = strategy.startingTyre,
        var lastPosition: Int = grid
    )
}
