package com.f1teammanager.core.season

object WorldDatabase {
    private val roster = listOf(
        "Ferrari|Charles Leclerc|Lewis Hamilton","McLaren|Lando Norris|Oscar Piastri","Williams|Carlos Sainz|Alexander Albon","Mercedes|George Russell|Kimi Antonelli","Red Bull Racing|Max Verstappen|Isack Hadjar",
        "Benetton|Michael Schumacher|Rafael Câmara","Renault|Pierre Gasly|Franco Colapinto","Team Lotus|Ayrton Senna|Nikola Tsolov","Lotus F1 Team|Alain Prost|Gabriele Minì","Brabham|Sebastian Vettel|Martinius Stenshorne",
        "Tyrrell|Jenson Button|Alexander Dunne","Jordan Grand Prix|Nico Rosberg|Dino Beganovic","Minardi|Mika Häkkinen|Oliver Goethe","Toro Rosso|Liam Lawson|Arvid Lindblad","Sauber|Nico Hülkenberg|Gabriel Bortoleto",
        "BMW Sauber|Nigel Mansell|Sebastian Montoya","Alfa Romeo|Nelson Piquet|Mari Boya","Aston Martin|Fernando Alonso|Lance Stroll","Force India|Niki Lauda|Joshua Dürksen","Racing Point|James Hunt|Ritomo Miyata",
        "Brawn GP|Emerson Fittipaldi|Noel León","Toyota Racing|Jackie Stewart|Roman Bilinski","Honda Racing|Jim Clark|Tuukka Taponen","Jaguar Racing|Juan Manuel Fangio|Ugo Ugochukwu","Stewart Grand Prix|Jack Brabham|Freddie Slater",
        "Arrows|Mario Andretti|Théophile Naël","Prost Grand Prix|Damon Hill|Noah Strømsted","BAR|Kimi Räikkönen|Matteo De Palo","Cooper|Felipe Massa|Mattia Colnaghi","Maserati|Rubens Barrichello|Enzo Deligny",
        "BMW|Mark Webber|Brando Badoer","Ford|Juan Pablo Montoya|James Wharton","Bugatti|Jacques Villeneuve|Alex Powell","Caterham|Esteban Ocon|Oliver Bearman","Audi F1 Team|Carlos Reutemann|Pedro Clerot",
        "Super Aguri|Gilles Villeneuve|Laurens van Hoepen","Andretti|Sergio Pérez|Valtteri Bottas","Campos Racing|Gerhard Berger|Taito Kato","Invicta Racing|David Coulthard|Maciej Gładysz","Rodin Motorsport|Eddie Irvine|Jean Alesi"
    )
    /**
     * Força do carro é explícita e estável. Não usa mais uma fórmula baseada no ID
     * da equipe. Os seis componentes recebem pequenas diferenças próprias, mas o
     * nível global da equipe é controlado por esta tabela.
     */
    // V37: 21 equipes da era atual ocupam a faixa superior. As outras 19
    // são distribuídas abaixo delas conforme peso histórico, sem usar o ID como
    // fórmula de desempenho. Audi F1 Team (ID 35) pertence ao grupo atual.
    private val currentEraTeamIds = setOf(1,2,3,4,5,7,13,14,15,17,18,19,20,21,22,23,24,28,31,32,35)
    private val currentEraStrength = mapOf(
        1 to 97, 2 to 96, 3 to 90, 4 to 94, 5 to 98, 7 to 88, 13 to 80,
        14 to 82, 15 to 79, 17 to 81, 18 to 86, 19 to 76, 20 to 74, 21 to 83,
        22 to 78, 23 to 85, 24 to 77, 28 to 75, 31 to 84, 32 to 73, 35 to 87
    )
    // As 21 equipes da era atual são a faixa superior, nenhuma das 19
    // históricas ultrapassa a menor equipe da faixa atual. Dentro da faixa
    // histórica, a ordem segue peso/desempenho histórico.
    private val historicalStrength = mapOf(
        6 to 72, 8 to 71, 9 to 70, 10 to 69, 11 to 68, 12 to 67, 16 to 66,
        25 to 65, 26 to 64, 27 to 63, 29 to 62, 30 to 61, 33 to 60, 34 to 59,
        36 to 58, 37 to 57, 38 to 56, 39 to 55, 40 to 54
    )
    private val teamStrength = (1..40).map { id ->
        if (id in currentEraTeamIds) currentEraStrength[id] ?: 70 else historicalStrength[id] ?: 65
    }
    val teams: List<TeamDefinition> by lazy {
        roster.mapIndexed { i,row ->
            val p=row.split('|'); val s=teamStrength[i]
            TeamDefinition(
                id=i+1,name=p[0],driverIds=listOf(i*2+1,i*2+2),baseCar=s,
                chassis=(s + 1 - (i%3)).coerceIn(1,100),
                engine=(s + if (i%5==0) 2 else if(i%5==1) 1 else 0).coerceIn(1,100),
                reliability=(s + 5 - (i%4)).coerceIn(1,100),
                frontWing=(s + 2 - (i%5)).coerceIn(1,100),
                rearWing=(s + 1 - (i%4)).coerceIn(1,100),
                brakes=(s - 1 + (i%4)).coerceIn(1,100),
                electricPowerUnit=(s + 3 - (i%6)).coerceIn(1,100)
            )
        }
    }
    private val current = mapOf(
        "Lando Norris" to intArrayOf(92,93,88,82,84,82,86),"Oscar Piastri" to intArrayOf(92,91,87,84,87,80,87),"George Russell" to intArrayOf(91,92,83,86,88,83,87),"Kimi Antonelli" to intArrayOf(91,92,81,79,78,78,82),"Charles Leclerc" to intArrayOf(94,96,86,82,83,86,83),"Lewis Hamilton" to intArrayOf(94,96,91,92,92,96,94),"Max Verstappen" to intArrayOf(99,98,97,96,94,91,91),"Isack Hadjar" to intArrayOf(87,85,81,78,76,78,79),"Liam Lawson" to intArrayOf(85,82,82,82,77,78,80),"Arvid Lindblad" to intArrayOf(83,82,78,76,72,74,75),"Pierre Gasly" to intArrayOf(88,87,84,85,86,83,85),"Franco Colapinto" to intArrayOf(83,82,80,77,73,76,77),"Esteban Ocon" to intArrayOf(86,85,83,87,82,82,83),"Oliver Bearman" to intArrayOf(86,85,82,79,76,77,79),"Nico Hülkenberg" to intArrayOf(87,86,80,86,90,82,88),"Gabriel Bortoleto" to intArrayOf(85,84,81,78,76,77,79),"Carlos Sainz" to intArrayOf(89,88,84,88,89,83,87),"Alexander Albon" to intArrayOf(88,86,84,85,86,85,84),"Fernando Alonso" to intArrayOf(94,93,92,96,95,97,92),"Lance Stroll" to intArrayOf(84,83,79,81,75,80,78),"Sergio Pérez" to intArrayOf(89,87,90,92,86,88,89),"Valtteri Bottas" to intArrayOf(91,93,84,85,89,87,90)
    )
    /** 80 pilotos titulares: exatamente 2 por equipe e, portanto, exatamente 80 no grid. */
    val drivers: List<DriverDefinition> by lazy { teams.flatMap { t -> t.driverIds.mapIndexed { slot,id -> val name=roster[t.id-1].split('|')[slot+1]; val a=current[name] ?: intArrayOf(78-((id*3)%12),76-((id*5)%13),74-((id*7)%14),73-((id*2)%12),75-((id*4)%15),72-((id*6)%13),74-((id*5)%12)); DriverDefinition(id,name,t.id,a[0],a[1],a[2],a[3],a[4],a[5],a[6], if(id<=44) 70 else 35) } } }

    /**
     * 20 pilotos de mercado/reserva. Eles não entram no grid de 80 enquanto não
     * houver uma contratação que altere o elenco. Isso mantém a separação entre
     * campeonato (80) e mercado (100 nomes disponíveis).
     */
    private val reserveMarket = listOf(
        "Heinz-Harald Frentzen","Jarno Trulli","Nick Heidfeld","Robert Kubica","Heikki Kovalainen",
        "Romain Grosjean","Timo Glock","Giancarlo Fisichella","Takuma Sato","Johnny Herbert",
        "Riccardo Patrese","Michele Alboreto","Carlos Pace","Bruce McLaren","Olivier Panis",
        "Pedro de la Rosa","Adrian Sutil","Paul di Resta","Pastor Maldonado","Alexander Rossi"
    )
    private val reserveRatings = listOf(
        intArrayOf(88,87,84,86,89,84,87), intArrayOf(86,85,82,84,86,82,85),
        intArrayOf(87,86,82,87,88,83,87), intArrayOf(89,88,86,89,90,85,88),
        intArrayOf(85,84,82,82,84,82,83), intArrayOf(86,85,84,80,78,80,81),
        intArrayOf(84,83,80,83,84,81,83), intArrayOf(88,89,86,86,88,87,87),
        intArrayOf(85,82,88,78,76,80,82), intArrayOf(83,84,80,82,85,81,83),
        intArrayOf(87,88,84,86,89,85,87), intArrayOf(85,84,83,84,86,84,85),
        intArrayOf(88,86,84,83,85,84,85), intArrayOf(87,85,84,85,88,84,86),
        intArrayOf(84,84,81,83,86,82,84), intArrayOf(85,84,82,83,87,83,85),
        intArrayOf(82,81,80,82,79,82,81), intArrayOf(84,83,82,84,86,82,84),
        intArrayOf(86,84,86,79,73,80,80), intArrayOf(82,81,79,78,77,79,80)
    )
    val allDrivers: List<DriverDefinition> by lazy {
        drivers + reserveMarket.mapIndexed { index, name ->
            val a = reserveRatings[index]
            DriverDefinition(81 + index, name, 0, a[0], a[1], a[2], a[3], a[4], a[5], a[6], 72 - (index % 9))
        }
    }
    /** 30 GPs, distributed across a 56-week season. All circuits are real venues. */
    val rounds = listOf(
        Triple("GP da Austrália","Albert Park",58), Triple("GP da China","Shanghai",56), Triple("GP do Japão","Suzuka",53),
        Triple("GP do Bahrein","Sakhir",57), Triple("GP da Arábia Saudita","Jeddah",50), Triple("GP de Miami","Miami",57),
        Triple("GP da Emília-Romanha","Imola",63), Triple("GP do Canadá","Montreal",70), Triple("GP de Mônaco","Monte Carlo",78),
        Triple("GP da Espanha","Barcelona",66), Triple("GP da Áustria","Red Bull Ring",71), Triple("GP da Grã-Bretanha","Silverstone",52),
        Triple("GP da Bélgica","Spa-Francorchamps",44), Triple("GP da Hungria","Hungaroring",70), Triple("GP da Holanda","Zandvoort",72),
        Triple("GP da Itália","Monza",53), Triple("GP de Madri","Madrid",57), Triple("GP do Azerbaijão","Baku",51),
        Triple("GP de Singapura","Marina Bay",61), Triple("GP dos EUA","Austin",56), Triple("GP do México","Hermanos Rodríguez",71),
        Triple("GP de São Paulo","Interlagos",71), Triple("GP de Las Vegas","Las Vegas",50), Triple("GP do Catar","Lusail",57),
        Triple("GP de Abu Dhabi","Yas Marina",58), Triple("GP de Portugal","Algarve / Portimão",66), Triple("GP da França","Paul Ricard",53),
        Triple("GP da Alemanha","Nürburgring",60), Triple("GP da Malásia","Sepang",56), Triple("GP da África do Sul","Kyalami",55)
    ).mapIndexed { i,x ->
        // A temporada 2026 usa 56 semanas de calendário interno. As datas são
        // distribuídas de forma uniforme dentro de 2026 para que nenhuma semana
        // apareça com data de 2027 por engano. A semana é a unidade do jogo; os
        // GPs ocupam 30 dessas 56 semanas e as demais são semanas livres de P&D.
        val weeks = listOf(3,5,7,9,11,13,15,17,19,21,23,25,27,29,31,33,35,37,39,41,43,45,47,49,51,52,53,54,55,56)
        val dates = listOf("14/01/2026","27/01/2026","10/02/2026","23/02/2026","08/03/2026","21/03/2026","04/04/2026","17/04/2026","30/04/2026","13/05/2026","27/05/2026","09/06/2026","22/06/2026","05/07/2026","19/07/2026","01/08/2026","14/08/2026","27/08/2026","09/09/2026","23/09/2026","06/10/2026","19/10/2026","01/11/2026","15/11/2026","28/11/2026","05/12/2026","11/12/2026","18/12/2026","24/12/2026","31/12/2026")
        val monthNames = listOf("Janeiro","Fevereiro","Março","Abril","Maio","Junho","Julho","Agosto","Setembro","Outubro","Novembro","Dezembro")
        val month = monthNames[dates[i].substring(3,5).toInt()-1]
        RoundDefinition(i+1,x.first,x.second,x.third, baseLapTimeMs=78000L+(i%6)*1800L, powerFactor=0.75+(i%5)*0.06, overtakingFactor=0.75+(i%4)*0.07, crashRisk=0.85+(i%5)*0.08, reliabilityRisk=0.90+(i%4)*0.06, safetyCarRisk=0.75+(i%6)*0.10, month=month, weekOfSeason=weeks[i], dateLabel=dates[i])
    }
}
