package com.f1teammanager.core.season

object WorldDatabase {
    private val roster = listOf(
        "Ferrari|Charles Leclerc|Lewis Hamilton","McLaren|Lando Norris|Oscar Piastri","Williams|Carlos Sainz|Alexander Albon","Mercedes|George Russell|Kimi Antonelli","Red Bull Racing|Max Verstappen|Isack Hadjar",
        "Benetton|Michael Schumacher|Rafael Câmara","Renault|Pierre Gasly|Franco Colapinto","Team Lotus|Ayrton Senna|Nikola Tsolov","Lotus F1 Team|Alain Prost|Gabriele Minì","Brabham|Sebastian Vettel|Martinius Stenshorne",
        "Tyrrell|Jenson Button|Alexander Dunne","Jordan Grand Prix|Nico Rosberg|Dino Beganovic","Minardi|Mika Häkkinen|Oliver Goethe","Toro Rosso|Liam Lawson|Arvid Lindblad","Sauber|Nico Hülkenberg|Gabriel Bortoleto",
        "BMW Sauber|Nigel Mansell|Sebastian Montoya","Alfa Romeo|Nelson Piquet|Mari Boya","Aston Martin|Fernando Alonso|Lance Stroll","Force India|Niki Lauda|Joshua Dürksen","Racing Point|James Hunt|Ritomo Miyata",
        "Brawn GP|Emerson Fittipaldi|Noel León","Toyota Racing|Jackie Stewart|Roman Bilinski","Honda Racing|Jim Clark|Tuukka Taponen","Jaguar Racing|Juan Manuel Fangio|Ugo Ugochukwu","Stewart Grand Prix|Jack Brabham|Freddie Slater",
        "Arrows|Mario Andretti|Théophile Naël","Prost Grand Prix|Damon Hill|Noah Strømsted","BAR|Kimi Räikkönen|Matteo De Palo","Cooper|Felipe Massa|Mattia Colnaghi","Maserati|Rubens Barrichello|Enzo Deligny",
        "BMW|Mark Webber|Brando Badoer","Ford|Juan Pablo Montoya|James Wharton","Bugatti|Jacques Villeneuve|Alex Powell","Caterham|Esteban Ocon|Oliver Bearman","Audi F1 Team|Carlos Reutemann|Pedro Clerot",
        "Super Aguri|Gilles Villeneuve|Laurens van Hoepen","Andretti|Sergio Pérez|Valtteri Bottas","Campos Racing|Gerhard Berger|Taito Kato","Invicta Racing|David Coulthard|Maciej Gładysz","Rodin Motorsport|Eddie Irvine|Jean Alesi"
    )
    /**
     * Força do carro é explícita e estável. Não usa mais uma fórmula baseada no ID
     * da equipe. Os seis componentes recebem pequenas diferenças próprias, mas o
     * nível global da equipe é controlado por esta tabela.
     */
    // V37: 21 equipes da era atual ocupam a faixa superior. As outras 19
    // são distribuídas abaixo delas conforme peso histórico, sem usar o ID como
    // fórmula de desempenho. Audi F1 Team (ID 35) pertence ao grupo atual.
    private val currentEraTeamIds = setOf(1,2,3,4,5,7,13,14,15,17,18,19,20,21,22,23,24,28,31,32,35)
    private val currentEraStrength = mapOf(
        1 to 97, 2 to 96, 3 to 90, 4 to 94, 5 to 98, 7 to 88, 13 to 80,
        14 to 82, 15 to 79, 17 to 81, 18 to 86, 19 to 76, 20 to 74, 21 to 83,
        22 to 78, 23 to 85, 24 to 77, 28 to 75, 31 to 84, 32 to 73, 35 to 87
    )
    // As 21 equipes da era atual são a faixa superior, nenhuma das 19
    // históricas ultrapassa a menor equipe da faixa atual. Dentro da faixa
    // histórica, a ordem segue peso/desempenho histórico.
    private val historicalStrength = mapOf(
        6 to 72, 8 to 71, 9 to 70, 10 to 69, 11 to 68, 12 to 67, 16 to 66,
        25 to 65, 26 to 64, 27 to 63, 29 to 62, 30 to 61, 33 to 60, 34 to 59,
        36 to 58, 37 to 57, 38 to 56, 39 to 55, 40 to 54
    )
    private val teamStrength = (1..40).map { id ->
        if (id in currentEraTeamIds) currentEraStrength[id] ?: 70 else historicalStrength[id] ?: 65
    }
    // Nível inicial oficial para uma nova carreira.
    // 2 = Forte, 1 = Médio, 0 = Fraco.
    private val initialTeamLevel = mapOf(
        1 to 2, 2 to 2, 3 to 2, 4 to 2, 5 to 2, 6 to 2, 7 to 2, 8 to 2,
        9 to 0, 10 to 1, 11 to 0, 12 to 1, 13 to 0, 14 to 1, 15 to 1, 16 to 1,
        17 to 1, 18 to 2, 19 to 1, 20 to 1, 21 to 2, 22 to 1, 23 to 1, 24 to 1,
        25 to 1, 26 to 0, 27 to 1, 28 to 1, 29 to 0, 30 to 0, 31 to 0, 32 to 0,
        33 to 0, 34 to 0, 35 to 2, 36 to 0, 37 to 0, 38 to 0, 39 to 0, 40 to 0
    )
    private val teamCountry = mapOf(
        1 to "Itália",
        2 to "Reino Unido",
        3 to "Reino Unido",
        4 to "Alemanha",
        5 to "Áustria",
        6 to "Reino Unido",
        7 to "França",
        8 to "Reino Unido",
        9 to "Reino Unido",
        10 to "Reino Unido",
        11 to "Reino Unido",
        12 to "Irlanda",
        13 to "Itália",
        14 to "Itália",
        15 to "Suíça",
        16 to "Alemanha",
        17 to "Itália",
        18 to "Reino Unido",
        19 to "Índia",
        20 to "Reino Unido",
        21 to "Reino Unido",
        22 to "Japão",
        23 to "Japão",
        24 to "Reino Unido",
        25 to "Reino Unido",
        26 to "Reino Unido",
        27 to "França",
        28 to "Reino Unido",
        29 to "Reino Unido",
        30 to "Itália",
        31 to "Alemanha",
        32 to "Estados Unidos",
        33 to "França",
        34 to "Malásia",
        35 to "Alemanha",
        36 to "Japão",
        37 to "Estados Unidos",
        38 to "Espanha",
        39 to "Reino Unido",
        40 to "Nova Zelândia",
    )

    val teams: List<TeamDefinition> by lazy {
        roster.mapIndexed { i,row ->
            val p=row.split('|'); val s=teamStrength[i]
            TeamDefinition(
                id=i+1,name=p[0],driverIds=listOf(i*2+1,i*2+2),baseCar=s,
                chassis=(s + 1 - (i%3)).coerceIn(1,100),
                engine=(s + if (i%5==0) 2 else if(i%5==1) 1 else 0).coerceIn(1,100),
                reliability=(s + 5 - (i%4)).coerceIn(1,100),
                frontWing=(s + 2 - (i%5)).coerceIn(1,100),
                rearWing=(s + 1 - (i%4)).coerceIn(1,100),
                brakes=(s - 1 + (i%4)).coerceIn(1,100),
                electricPowerUnit=(s + 3 - (i%6)).coerceIn(1,100),
                country=teamCountry[i+1] ?: "",
                initialLevel=initialTeamLevel[i+1] ?: 1
            )
        }
    }
    private val current = mapOf(
        "Lando Norris" to intArrayOf(92,93,88,82,84,82,86),"Oscar Piastri" to intArrayOf(92,91,87,84,87,80,87),"George Russell" to intArrayOf(91,92,83,86,88,83,87),"Kimi Antonelli" to intArrayOf(91,92,81,79,78,78,82),"Charles Leclerc" to intArrayOf(94,96,86,82,83,86,83),"Lewis Hamilton" to intArrayOf(94,96,91,92,92,96,94),"Max Verstappen" to intArrayOf(99,98,97,96,94,91,91),"Isack Hadjar" to intArrayOf(87,85,81,78,76,78,79),"Liam Lawson" to intArrayOf(85,82,82,82,77,78,80),"Arvid Lindblad" to intArrayOf(83,82,78,76,72,74,75),"Pierre Gasly" to intArrayOf(88,87,84,85,86,83,85),"Franco Colapinto" to intArrayOf(83,82,80,77,73,76,77),"Esteban Ocon" to intArrayOf(86,85,83,87,82,82,83),"Oliver Bearman" to intArrayOf(86,85,82,79,76,77,79),"Nico Hülkenberg" to intArrayOf(87,86,80,86,90,82,88),"Gabriel Bortoleto" to intArrayOf(85,84,81,78,76,77,79),"Carlos Sainz" to intArrayOf(89,88,84,88,89,83,87),"Alexander Albon" to intArrayOf(88,86,84,85,86,85,84),"Fernando Alonso" to intArrayOf(94,93,92,96,95,97,92),"Lance Stroll" to intArrayOf(84,83,79,81,75,80,78),"Sergio Pérez" to intArrayOf(89,87,90,92,86,88,89),"Valtteri Bottas" to intArrayOf(91,93,84,85,89,87,90)
    )
    private val driverCountry = mapOf(
        "Charles Leclerc" to "Mônaco",
        "Lewis Hamilton" to "Reino Unido",
        "Lando Norris" to "Reino Unido",
        "Oscar Piastri" to "Austrália",
        "Carlos Sainz" to "Espanha",
        "Alexander Albon" to "Tailândia",
        "George Russell" to "Reino Unido",
        "Kimi Antonelli" to "Itália",
        "Max Verstappen" to "Países Baixos",
        "Isack Hadjar" to "França",
        "Michael Schumacher" to "Alemanha",
        "Rafael Câmara" to "Brasil",
        "Pierre Gasly" to "França",
        "Franco Colapinto" to "Argentina",
        "Ayrton Senna" to "Brasil",
        "Nikola Tsolov" to "Bulgária",
        "Alain Prost" to "França",
        "Gabriele Minì" to "Itália",
        "Sebastian Vettel" to "Alemanha",
        "Martinius Stenshorne" to "Noruega",
        "Jenson Button" to "Reino Unido",
        "Alexander Dunne" to "Irlanda",
        "Nico Rosberg" to "Alemanha",
        "Dino Beganovic" to "Suécia",
        "Mika Häkkinen" to "Finlândia",
        "Oliver Goethe" to "Alemanha",
        "Liam Lawson" to "Nova Zelândia",
        "Arvid Lindblad" to "Reino Unido",
        "Nico Hülkenberg" to "Alemanha",
        "Gabriel Bortoleto" to "Brasil",
        "Nigel Mansell" to "Reino Unido",
        "Sebastian Montoya" to "Colômbia",
        "Nelson Piquet" to "Brasil",
        "Mari Boya" to "Espanha",
        "Fernando Alonso" to "Espanha",
        "Lance Stroll" to "Canadá",
        "Niki Lauda" to "Áustria",
        "Joshua Dürksen" to "Paraguai",
        "James Hunt" to "Reino Unido",
        "Ritomo Miyata" to "Japão",
        "Emerson Fittipaldi" to "Brasil",
        "Noel León" to "México",
        "Jackie Stewart" to "Reino Unido",
        "Roman Bilinski" to "Polônia",
        "Jim Clark" to "Reino Unido",
        "Tuukka Taponen" to "Finlândia",
        "Juan Manuel Fangio" to "Argentina",
        "Ugo Ugochukwu" to "Estados Unidos",
        "Jack Brabham" to "Austrália",
        "Freddie Slater" to "Reino Unido",
        "Mario Andretti" to "Estados Unidos",
        "Théophile Naël" to "França",
        "Damon Hill" to "Reino Unido",
        "Noah Strømsted" to "Dinamarca",
        "Kimi Räikkönen" to "Finlândia",
        "Matteo De Palo" to "Itália",
        "Felipe Massa" to "Brasil",
        "Mattia Colnaghi" to "Itália",
        "Rubens Barrichello" to "Brasil",
        "Enzo Deligny" to "França",
        "Mark Webber" to "Austrália",
        "Brando Badoer" to "Itália",
        "Juan Pablo Montoya" to "Colômbia",
        "James Wharton" to "Austrália",
        "Jacques Villeneuve" to "Canadá",
        "Alex Powell" to "Estados Unidos",
        "Esteban Ocon" to "França",
        "Oliver Bearman" to "Reino Unido",
        "Carlos Reutemann" to "Argentina",
        "Pedro Clerot" to "Brasil",
        "Gilles Villeneuve" to "Canadá",
        "Laurens van Hoepen" to "Países Baixos",
        "Sergio Pérez" to "México",
        "Valtteri Bottas" to "Finlândia",
        "Gerhard Berger" to "Áustria",
        "Taito Kato" to "Japão",
        "David Coulthard" to "Reino Unido",
        "Maciej Gładysz" to "Polônia",
        "Eddie Irvine" to "Reino Unido",
        "Jean Alesi" to "França",
        "Heinz-Harald Frentzen" to "Alemanha",
        "Jarno Trulli" to "Itália",
        "Nick Heidfeld" to "Alemanha",
        "Robert Kubica" to "Polônia",
        "Heikki Kovalainen" to "Finlândia",
        "Romain Grosjean" to "França",
        "Timo Glock" to "Alemanha",
        "Giancarlo Fisichella" to "Itália",
        "Takuma Sato" to "Japão",
        "Johnny Herbert" to "Reino Unido",
        "Riccardo Patrese" to "Itália",
        "Michele Alboreto" to "Itália",
        "Carlos Pace" to "Brasil",
        "Bruce McLaren" to "Nova Zelândia",
        "Olivier Panis" to "França",
        "Pedro de la Rosa" to "Espanha",
        "Adrian Sutil" to "Alemanha",
        "Paul di Resta" to "Reino Unido",
        "Pastor Maldonado" to "Venezuela",
        "Alexander Rossi" to "Estados Unidos",
    )

    /** 80 pilotos titulares: exatamente 2 por equipe e, portanto, exatamente 80 no grid. */
    val drivers: List<DriverDefinition> by lazy { teams.flatMap { t -> t.driverIds.mapIndexed { slot,id -> val name=roster[t.id-1].split('|')[slot+1]; val p=DriverProfileCatalog.profile(name); val a=p.ratings; DriverDefinition(id,name,t.id,a[0],a[1],a[2],a[3],a[4],a[5],a[6], p.driverClass, p.evolution, driverCountry[name] ?: "") } } }

    /**
     * 20 pilotos de mercado/reserva. Eles não entram no grid de 80 enquanto não
     * houver uma contratação que altere o elenco. Isso mantém a separação entre
     * campeonato (80) e mercado (100 nomes disponíveis).
     */
    private val reserveMarket = listOf(
        "Heinz-Harald Frentzen","Jarno Trulli","Nick Heidfeld","Robert Kubica","Heikki Kovalainen",
        "Romain Grosjean","Timo Glock","Giancarlo Fisichella","Takuma Sato","Johnny Herbert",
        "Riccardo Patrese","Michele Alboreto","Carlos Pace","Bruce McLaren","Olivier Panis",
        "Pedro de la Rosa","Adrian Sutil","Paul di Resta","Pastor Maldonado","Alexander Rossi"
    )
    private val reserveRatings = listOf(
        intArrayOf(88,87,84,86,89,84,87), intArrayOf(86,85,82,84,86,82,85),
        intArrayOf(87,86,82,87,88,83,87), intArrayOf(89,88,86,89,90,85,88),
        intArrayOf(85,84,82,82,84,82,83), intArrayOf(86,85,84,80,78,80,81),
        intArrayOf(84,83,80,83,84,81,83), intArrayOf(88,89,86,86,88,87,87),
        intArrayOf(85,82,88,78,76,80,82), intArrayOf(83,84,80,82,85,81,83),
        intArrayOf(87,88,84,86,89,85,87), intArrayOf(85,84,83,84,86,84,85),
        intArrayOf(88,86,84,83,85,84,85), intArrayOf(87,85,84,85,88,84,86),
        intArrayOf(84,84,81,83,86,82,84), intArrayOf(85,84,82,83,87,83,85),
        intArrayOf(82,81,80,82,79,82,81), intArrayOf(84,83,82,84,86,82,84),
        intArrayOf(86,84,86,79,73,80,80), intArrayOf(82,81,79,78,77,79,80)
    )
    val allDrivers: List<DriverDefinition> by lazy {
        drivers + reserveMarket.mapIndexed { index, name ->
            val p=DriverProfileCatalog.profile(name); val r=p.ratings; DriverDefinition(81 + index, name, 0, r[0], r[1], r[2], r[3], r[4], r[5], r[6], p.driverClass, p.evolution, driverCountry[name] ?: "")
        }
    }
    /** Compatibility view for the default 2026 calendar. Career code uses SeasonCalendar.forSeason(season). */
    val rounds: List<RoundDefinition> get() = SeasonCalendar.forSeason(2026)

}
