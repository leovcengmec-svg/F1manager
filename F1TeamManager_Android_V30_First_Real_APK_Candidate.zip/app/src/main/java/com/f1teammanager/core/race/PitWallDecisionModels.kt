package com.f1teammanager.core.race

enum class DriverPosture { ATTACK, BALANCED, DEFENSE }

enum class NeutralisationAction { BOX, MAINTAIN, EXTEND }

enum class RedFlagTyre { SOFT, MEDIUM, HARD }

enum class DecisionStatus { NOT_REQUIRED, PENDING, RESOLVED }

data class ManagerStrategy(
    val driverId: Int,
    val posture: DriverPosture = DriverPosture.BALANCED,
    val startingTyre: Tyre = Tyre.MEDIUM,
    val plannedTyreSequence: List<Tyre> = listOf(startingTyre)
)

enum class DriverAlertType { FUEL_LOW, TYRE_DEGRADING, TYRE_CRITICAL, MECHANICAL_WARNING }

data class DriverAlert(
    val lap: Int,
    val driverId: Int,
    val type: DriverAlertType,
    val message: String,
    val severity: Int
)

data class PendingManagerDecision(
    val type: ManagerDecisionType,
    val lap: Int,
    val driverId: Int?,
    val message: String,
    val status: DecisionStatus = DecisionStatus.PENDING
)

data class ManagerDecision(
    val type: ManagerDecisionType,
    val neutralisationAction: NeutralisationAction? = null,
    val restartTyre: RedFlagTyre? = null,
    val restartPosture: DriverPosture? = null,
    val keepRunning: Boolean = false
)

data class PitWallSnapshot(
    val lap: Int,
    val totalLaps: Int,
    val position: Int,
    val tyre: Tyre,
    val tyreWear: Int,
    val fuelPercent: Int,
    val posture: DriverPosture,
    val neutralisation: Neutralisation,
    val alerts: List<DriverAlert>,
    val pendingDecision: PendingManagerDecision?
)
