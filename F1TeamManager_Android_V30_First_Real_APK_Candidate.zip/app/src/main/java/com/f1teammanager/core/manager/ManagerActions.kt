package com.f1teammanager.core.manager

class ManagerActions(private val dev:CarDevelopmentEngine=CarDevelopmentEngine(), private val market:ManagerMarketEngine=ManagerMarketEngine()) {
    fun apply(state:TeamManagerState, action:ManagementAction):TeamManagerState = when(action) {
        ManagementAction.DEVELOP_AERO -> dev.start(state,CarComponent.FRONT_WING)
        ManagementAction.DEVELOP_CHASSIS -> dev.start(state,CarComponent.CHASSIS)
        ManagementAction.DEVELOP_ENGINE -> dev.start(state,CarComponent.ENGINE)
        ManagementAction.DEVELOP_RELIABILITY -> dev.start(state,CarComponent.BRAKES)
        ManagementAction.UPGRADE_FACTORY -> dev.upgradeFacility(state,Facility.FACTORY)
        ManagementAction.UPGRADE_WIND_TUNNEL -> dev.upgradeFacility(state,Facility.WIND_TUNNEL)
        ManagementAction.UPGRADE_SIMULATOR -> dev.upgradeFacility(state,Facility.SIMULATOR)
        ManagementAction.UPGRADE_TESTING -> dev.upgradeFacility(state,Facility.TESTING)
        ManagementAction.HIRE_BEST_TECHNICAL -> market.hireStaff(state, StaffMarketEngine().staffPool().filter { it.role==StaffRole.TECHNICAL_DIRECTOR }.maxBy { it.skill })
        ManagementAction.HIRE_BEST_COMMERCIAL -> market.hireStaff(state, StaffMarketEngine().staffPool().filter { it.role==StaffRole.COMMERCIAL_MANAGER }.maxBy { it.skill })
        ManagementAction.HIRE_BEST_PRINCIPAL -> market.hireStaff(state, StaffMarketEngine().staffPool().filter { it.role==StaffRole.TEAM_PRINCIPAL }.maxBy { it.skill })
    }
}
