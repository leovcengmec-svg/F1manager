package com.f1teammanager.core.manager

/** Bridges annual-event car deltas into the physical two-car race model. */
object AnnualEventGarageAdapter {
    fun applyDelta(garage: TeamGarage, before: TeamCarState, after: TeamCarState): TeamGarage {
        fun apply(car: PhysicalCar): PhysicalCar {
            val reliabilityDelta = after.reliability - before.reliability
            val reliabilities = car.componentReliabilities.mapValues { (_, value) ->
                (value + reliabilityDelta).coerceIn(1, 100)
            }
            fun performance(component: CarComponent, current: Int, beforeValue: Int, afterValue: Int): Int {
                // Events may tune an existing piece but must not manufacture performance.
                if (component !in car.installedPieces) return 0
                return (current + afterValue - beforeValue).coerceIn(1, 100)
            }
            return car.copy(
                engine = performance(CarComponent.ENGINE, car.engine, before.engine, after.engine),
                chassis = performance(CarComponent.CHASSIS, car.chassis, before.chassis, after.chassis),
                frontWing = performance(CarComponent.FRONT_WING, car.frontWing, before.frontWing, after.frontWing),
                rearWing = performance(CarComponent.REAR_WING, car.rearWing, before.rearWing, after.rearWing),
                brakes = performance(CarComponent.BRAKES, car.brakes, before.brakes, after.brakes),
                electricPowerUnit = performance(CarComponent.ELECTRIC_POWER_UNIT, car.electricPowerUnit, before.electricPowerUnit, after.electricPowerUnit),
                reliability = (car.reliability + reliabilityDelta).coerceIn(1, 100),
                componentReliabilities = reliabilities
            )
        }
        return garage.copy(car1 = apply(garage.car1), car2 = apply(garage.car2))
    }
}
