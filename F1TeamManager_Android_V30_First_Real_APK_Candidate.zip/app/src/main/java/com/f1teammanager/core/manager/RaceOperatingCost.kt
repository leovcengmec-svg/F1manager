package com.f1teammanager.core.manager

import com.f1teammanager.core.season.WorldDatabase

/** Per-GP operating costs scale with team size and competitive resources. */
object RaceOperatingCost {
    fun forTeam(teamId: Int): Long {
        val level = WorldDatabase.teams.firstOrNull { it.id == teamId }?.initialLevel
            ?: InitialTeamProfile.FRACO
        return when (level) {
            InitialTeamProfile.FORTE -> 2_500_000L
            InitialTeamProfile.MEDIO -> 1_500_000L
            else -> 800_000L
        }
    }
}
