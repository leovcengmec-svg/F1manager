package com.f1teammanager.core.manager

/**
 * Persists a single, player-career announcement when the driver transfer window
 * opens. The UI must render the stored event instead of inferring a temporary
 * card directly from the current week, so saves/reloads cannot silently miss it.
 */
object DriverMarketWindowNotificationPolicy {
    const val OPEN_TITLE = "JANELA DE TRANSFERÊNCIA ABERTA"
    fun ensureOpeningNotice(
        state: DriverMarketState,
        season: Int,
        currentWeek: Int,
        isMarketOpen: Boolean,
        playerTeamName: String
    ): DriverMarketState {
        if (!isMarketOpen || season < 1 || playerTeamName.isBlank()) return state
        val alreadyRecorded = state.notifications.any { notice ->
            notice.season == season && notice.title.trim().equals(OPEN_TITLE, ignoreCase = true)
        }
        if (alreadyRecorded) return state

        val notice = MarketNotification(
            season = season,
            week = currentWeek.coerceIn(1, 56),
            title = OPEN_TITLE,
            message = "A janela de transferência da equipe $playerTeamName está aberta. Avalie oportunidades, negocie contratos e prepare a equipe para a próxima temporada.",
            important = true,
            category = MarketNewsCategory.MARKET
        )
        return state.copy(notifications = (state.notifications + notice).takeLast(1000)).normalized()
    }
}
