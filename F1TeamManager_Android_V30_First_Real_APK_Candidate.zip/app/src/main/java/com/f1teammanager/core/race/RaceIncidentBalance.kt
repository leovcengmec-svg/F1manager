package com.f1teammanager.core.race

import kotlin.random.Random

/**
 * Calibrated race-incident model. Accidents are rare field-wide events, and a
 * loss of control is not automatically a retirement. Driver consistency and
 * wet-weather skill influence who is most exposed when an incident is rolled.
 */
object RaceIncidentBalance {
    const val BASE_CRASH_CHANCE_PER_LAP = 0.006
    const val BASE_SEVERE_CRASH_CHANCE = 0.25
    const val BASE_COLLISION_DNF_CHANCE = 0.20

    fun crashChancePerLap(circuitRisk: Double): Double =
        (BASE_CRASH_CHANCE_PER_LAP * circuitRisk.coerceIn(0.50, 1.50)).coerceIn(0.002, 0.009)

    fun driverRiskWeight(consistency: Int, wetSkill: Int, weather: Weather): Double {
        val consistencyRisk = (1.0 + (80 - consistency.coerceIn(40, 100)) * 0.012).coerceIn(0.76, 1.48)
        val weatherRisk = when (weather) {
            Weather.HEAVY_RAIN -> (1.0 + (82 - wetSkill.coerceIn(40, 100)) * 0.009).coerceIn(0.78, 1.38)
            Weather.MEDIUM_RAIN, Weather.LIGHT_RAIN -> (1.0 + (82 - wetSkill.coerceIn(40, 100)) * 0.004).coerceIn(0.88, 1.18)
            Weather.DRY, Weather.CLOUDY -> 1.0
        }
        return consistencyRisk * weatherRisk
    }

    fun selectDriverId(
        participants: List<RaceParticipant>,
        weather: Weather,
        random: Random
    ): Int? {
        if (participants.isEmpty()) return null
        val weighted = participants.map { participant ->
            participant.driverId to driverRiskWeight(participant.consistency, participant.wetSkill, weather)
        }
        val total = weighted.sumOf { it.second }
        var roll = random.nextDouble() * total
        for ((driverId, weight) in weighted) {
            roll -= weight
            if (roll <= 0.0) return driverId
        }
        return weighted.last().first
    }

    fun severeCrashChance(consistency: Int, wetSkill: Int, weather: Weather): Double {
        val lowConsistency = (80 - consistency.coerceIn(40, 100)).coerceAtLeast(0) * 0.002
        val wetPenalty = when (weather) {
            Weather.HEAVY_RAIN -> (82 - wetSkill.coerceIn(40, 100)).coerceAtLeast(0) * 0.0015
            Weather.MEDIUM_RAIN, Weather.LIGHT_RAIN -> (82 - wetSkill.coerceIn(40, 100)).coerceAtLeast(0) * 0.0006
            Weather.DRY, Weather.CLOUDY -> 0.0
        }
        return (BASE_SEVERE_CRASH_CHANCE + lowConsistency + wetPenalty).coerceIn(0.15, 0.42)
    }
}
