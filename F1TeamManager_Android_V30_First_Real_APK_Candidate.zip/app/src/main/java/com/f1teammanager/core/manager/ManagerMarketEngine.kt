package com.f1teammanager.core.manager

class ManagerMarketEngine(private val market: StaffMarketEngine = StaffMarketEngine()) {
    fun hireStaff(state: TeamManagerState, member: StaffMember): TeamManagerState {
        val normalized=member.normalized()
        val existing=state.staff.filterNot { it.role==normalized.role }
        val cost=normalized.salary/2
        require(state.finance.budget >= cost) { "Orçamento insuficiente" }
        val finance=state.finance.transact(-cost,"Bônus de contratação: ${normalized.name}")
        return state.copy(staff=existing+(normalized.copy(teamId=state.playerTeamId)),finance=finance,
            history=(state.history+"Contratado ${normalized.name}").takeLast(100))
    }

    fun replaceSponsor(state: TeamManagerState, sponsor: SponsorContract): TeamManagerState = signSponsor(state, sponsor, sponsor.slot)

    fun signSponsor(state: TeamManagerState, sponsor: SponsorContract, slot: Int): TeamManagerState {
        require(slot in 1..5) { "Slot de patrocinador inválido" }
        val current = state.sponsors.associateBy { it.slot }.toMutableMap()
        require(current[slot] == null || current[slot]?.active != true) { "Este espaço de patrocínio já está ocupado" }
        val signed = sponsor.copy(
            slot=slot,
            active=true,
            races=sponsor.races.coerceIn(1,10),
            racesRemaining=sponsor.races.coerceIn(1,10),
            upfront=if (sponsor.paymentType == SponsorPaymentType.UPFRONT) sponsor.upfront else 0L,
            racePayment=if (sponsor.paymentType == SponsorPaymentType.PER_RACE) sponsor.racePayment else 0L
        )
        current[slot] = signed
        val list = current.values.sortedBy { it.slot }
        val primary = list.firstOrNull { it.slot == 1 } ?: SponsorContract("Patrocinador Base",0,0,0,1,0,1,0,0,0,0,false)
        return state.copy(sponsors=list, sponsor=primary, finance=state.finance.transact(signed.upfront,"Entrada patrocínio: ${signed.name} (slot $slot)"),
            history=(state.history+"Patrocinador ${signed.name} contratado no slot $slot").takeLast(100))
    }

    fun replaceSupplier(state: TeamManagerState, supplier: SupplierContract): TeamManagerState {
        val normalized=supplier.normalized()
        val finance=state.finance.transact(-normalized.annualCost,"Contrato fornecedor: ${normalized.name}")
        return when(normalized.type) {
            SupplierType.ENGINE -> state.copy(engineSupplier=normalized,finance=finance)
            SupplierType.TYRE -> state.copy(tyreSupplier=normalized,finance=finance)
        }
    }

    fun availableStaff(state: TeamManagerState): List<ContractOffer> = market.staffPool().map { market.generateOffer(it,state) }
}
