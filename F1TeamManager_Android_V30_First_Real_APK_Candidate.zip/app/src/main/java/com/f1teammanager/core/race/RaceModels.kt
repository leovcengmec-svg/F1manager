package com.f1teammanager.core.race

data class RaceCircuit(
    val id: Int,
    val name: String,
    val laps: Int,
    val baseLapTimeMs: Long,
    val crashRisk: Double = 1.0,
    val reliabilityRisk: Double = 1.0,
    val safetyCarRisk: Double = 1.0
)

data class RaceParticipant(
    val driverId: Int,
    val driverName: String,
    val teamId: Int,
    val teamName: String,
    val driverSpeed: Int,
    val qualifying: Int,
    val overtaking: Int,
    val defense: Int,
    val consistency: Int,
    val enginePerformance: Int,
    val tyreGrip: Int = 50,
    val tyreWear: Int = 50,
    val reliability: Int = 95,
    val chassisWear: Int = 0,
    val wetSkill: Int = 50,
    val chassisPerformance: Int = 50,
    val frontWingPerformance: Int = 50,
    val rearWingPerformance: Int = 50,
    val brakesPerformance: Int = 50,
    val electricPowerUnitPerformance: Int = 50,
    // Factory reliability carried independently for each physical component.
    val engineReliability: Int = 95,
    val chassisReliability: Int = 95,
    val frontWingReliability: Int = 95,
    val rearWingReliability: Int = 95,
    val brakesReliability: Int = 95,
    val electricPowerUnitReliability: Int = 95
)


/** Etapa 2: converte cada atributo 40..100 em um dos 10 níveis de influência.
 *  Os modificadores são deliberadamente limitados: atributos orientam probabilidades
 *  e degradação, mas não determinam sozinhos o resultado da corrida.
 */
object DriverAttributeInfluence {
    fun level(value: Int): Int = when (value.coerceIn(40, 100)) {
        in 40..45 -> 1
        in 46..51 -> 2
        in 52..57 -> 3
        in 58..63 -> 4
        in 64..69 -> 5
        in 70..75 -> 6
        in 76..81 -> 7
        in 82..87 -> 8
        in 88..93 -> 9
        else -> 10
    }

    private fun table(value: Int, values: DoubleArray): Double = values[level(value) - 1]

    fun velocity(value: Int): Double = table(value, doubleArrayOf(-0.030, -0.023, -0.017, -0.011, -0.005, 0.0, 0.005, 0.011, 0.017, 0.023))
    fun qualifying(value: Int): Double = velocity(value)
    fun overtaking(value: Int): Double = table(value, doubleArrayOf(-0.25, -0.19, -0.14, -0.09, -0.04, 0.0, 0.05, 0.11, 0.17, 0.23))
    fun defense(value: Int): Double = table(value, doubleArrayOf(-0.23, -0.17, -0.11, -0.06, -0.03, 0.0, 0.05, 0.10, 0.16, 0.22))
    fun consistency(value: Int): Double = velocity(value)
    fun wet(value: Int): Double = table(value, doubleArrayOf(-0.08, -0.065, -0.05, -0.035, -0.02, 0.0, 0.02, 0.04, 0.06, 0.08))
    fun tyre(value: Int): Double = wet(value)
}

data class QualifyingEntry(val driverId: Int, val position: Int, val lapTimeMs: Long)
data class QualifyingPhase(
    val name: String,
    val entries: List<QualifyingEntry>,
    val eliminatedDriverIds: List<Int>
)

data class QualifyingResult(
    val grid: List<QualifyingEntry>,
    val phases: List<QualifyingPhase> = emptyList()
)

enum class Tyre(val gripClassMs: Int, val wearMultiplier: Double, val wetSuitability: Int, val targetLaps: Int) {
    SOFT(-650, 1.35, 10, 15),
    MEDIUM(-250, 1.00, 20, 25),
    HARD(0, 0.72, 30, 36),
    INTERMEDIATE(500, 1.25, 82, 36),
    WET(850, 1.25, 100, 50)
}

enum class Weather { DRY, CLOUDY, LIGHT_RAIN, MEDIUM_RAIN, HEAVY_RAIN }
enum class Neutralisation { GREEN, VSC, SAFETY_CAR }

data class RaceStrategy(
    val driverId: Int,
    val plannedStops: Int,
    val pitLaps: List<Int>,
    val startingTyre: Tyre = Tyre.MEDIUM,
    val tyreSequence: List<Tyre> = listOf(startingTyre),
    val reactToSafetyCar: Boolean = true,
    val reactToWeather: Boolean = true
)

data class LapEvent(
    val lap: Int,
    val driverId: Int?,
    val type: EventType,
    val detail: String
)

enum class EventType {
    FASTEST_LAP, QUALIFYING_LAP_DISCARDED, OVERTAKE, PIT_STOP, CRASH, MECHANICAL_FAILURE, WEAR_WARNING,
    VSC_DEPLOYED, VSC_ENDED, SAFETY_CAR_DEPLOYED, SAFETY_CAR_ENDED, RED_FLAG_DEPLOYED, WEATHER_CHANGE, DNF
}

data class FinishEntry(
    val position: Int,
    val driverId: Int,
    val driverName: String,
    val teamName: String,
    val laps: Int,
    val totalTimeMs: Long,
    val status: String,
    val tyre: Tyre,
    val pitStops: Int
)

data class RaceResult(
    val classification: List<FinishEntry>,
    val events: List<LapEvent>,
    val fastestLapDriverId: Int?,
    val weather: Weather,
    val points: Map<Int, Int>,
    val safetyCarLaps: Int,
    val vscLaps: Int,
    /** Exact lap time of the single fastest lap of the race. */
    val fastestLapTimeMs: Long = 0L,
    /** Final qualifying grid used by the driver-evolution GP performance model. */
    val qualifying: QualifyingResult? = null
)
