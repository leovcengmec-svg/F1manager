package com.f1teammanager.core.race

data class RaceCircuit(
    val id: Int,
    val name: String,
    val laps: Int,
    val baseLapTimeMs: Long,
    val powerFactor: Double,
    val overtakingFactor: Double,
    val distanceToT1M: Double = 615.0,
    val crashRisk: Double = 1.0,
    val reliabilityRisk: Double = 1.0,
    val safetyCarRisk: Double = 1.0
)

data class RaceParticipant(
    val driverId: Int,
    val driverName: String,
    val teamId: Int,
    val teamName: String,
    val driverSpeed: Int,
    val qualifying: Int,
    val overtaking: Int,
    val defense: Int,
    val consistency: Int,
    val carSpeed: Int,
    val enginePower: Int,
    val tyreGrip: Int = 50,
    val tyreWear: Int = 50,
    val racecraft: Int = 50,
    val reliability: Int = 95,
    val chassisWear: Int = 0,
    val wetSkill: Int = 50
)

data class QualifyingEntry(val driverId: Int, val position: Int, val lapTimeMs: Long)
data class QualifyingPhase(
    val name: String,
    val entries: List<QualifyingEntry>,
    val eliminatedDriverIds: List<Int>
)

data class QualifyingResult(
    val grid: List<QualifyingEntry>,
    val phases: List<QualifyingPhase> = emptyList()
)

enum class Tyre(val gripClassMs: Int, val wearMultiplier: Double, val wetSuitability: Int, val targetLaps: Int) {
    SOFT(-650, 1.35, 10, 15),
    MEDIUM(-250, 1.00, 20, 22),
    HARD(0, 0.72, 30, 30),
    INTERMEDIATE(500, 1.25, 82, 25),
    WET(850, 1.25, 100, 28)
}

enum class Weather { DRY, CLOUDY, LIGHT_RAIN, MEDIUM_RAIN, HEAVY_RAIN }
enum class Neutralisation { GREEN, VSC, SAFETY_CAR }

data class RaceStrategy(
    val driverId: Int,
    val plannedStops: Int,
    val pitLaps: List<Int>,
    val startingTyre: Tyre = Tyre.MEDIUM,
    val tyreSequence: List<Tyre> = listOf(startingTyre),
    val reactToSafetyCar: Boolean = true,
    val reactToWeather: Boolean = true
)

data class LapEvent(
    val lap: Int,
    val driverId: Int?,
    val type: EventType,
    val detail: String
)

enum class EventType {
    FASTEST_LAP, OVERTAKE, PIT_STOP, CRASH, MECHANICAL_FAILURE, WEAR_WARNING,
    VSC_DEPLOYED, VSC_ENDED, SAFETY_CAR_DEPLOYED, SAFETY_CAR_ENDED, RED_FLAG_DEPLOYED, WEATHER_CHANGE, DNF
}

data class FinishEntry(
    val position: Int,
    val driverId: Int,
    val driverName: String,
    val teamName: String,
    val laps: Int,
    val totalTimeMs: Long,
    val status: String,
    val tyre: Tyre,
    val pitStops: Int
)

data class RaceResult(
    val classification: List<FinishEntry>,
    val events: List<LapEvent>,
    val fastestLapDriverId: Int?,
    val weather: Weather,
    val points: Map<Int, Int>,
    val safetyCarLaps: Int,
    val vscLaps: Int
)
