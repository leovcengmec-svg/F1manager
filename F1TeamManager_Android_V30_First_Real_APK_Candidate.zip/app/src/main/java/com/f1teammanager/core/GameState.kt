package com.f1teammanager.core

import com.f1teammanager.core.race.RaceResult

/** Minimal domain state used by the race core; persistence/UI may wrap this later. */
data class GameState(
    val season: Int = 2026,
    val currentRound: Int = 1,
    val championship: Map<Int, Int> = emptyMap(),
    val lastRace: RaceResult? = null
) {
    fun applyRace(result: RaceResult): GameState {
        val merged = championship.toMutableMap()
        result.points.forEach { (driver, points) -> merged[driver] = (merged[driver] ?: 0) + points }
        return copy(currentRound = currentRound + 1, championship = merged, lastRace = result)
    }
}
