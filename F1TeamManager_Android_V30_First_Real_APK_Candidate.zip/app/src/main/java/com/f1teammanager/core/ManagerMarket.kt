package com.f1teammanager.core

class ManagerMarket {

    fun shouldTriggerDismissal(manager: ManagerState): Boolean =
        manager.performance < 60

    fun shouldGenerateInterest(manager: ManagerState): Boolean =
        manager.performance >= 80 && manager.reputation >= 75

    fun dismiss(manager: ManagerState): ManagerState =
        manager.copy(teamId = null, available = true, contractYears = 0)

    fun receiveOffer(manager: ManagerState, newTeamId: Int, years: Int): ManagerState =
        manager.copy(teamId = newTeamId, available = false, contractYears = years)
}
