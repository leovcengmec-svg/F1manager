package com.f1teammanager.core.career

/**
 * V16: career orchestration layer. It owns the high-level flow while race/manager engines
 * remain responsible for their own domains. This prevents the UI from becoming a second game state.
 */
class CareerFlowEngine(initial: CareerFlowState = CareerFlowState()) {
    var state: CareerFlowState = initial
        private set

    fun startCareer(teamId: Int): CareerFlowState {
        require(teamId > 0) { "Equipe inválida" }
        state = CareerFlowState(playerTeamId = teamId)
        return state
    }

    fun openWeekend(): CareerFlowState {
        require(state.phase == CareerPhase.HOME || state.phase == CareerPhase.RESULT) { "Não é possível abrir o fim de semana nesta fase" }
        require(state.completedRounds < 30) { "Temporada concluída" }
        state = state.copy(phase = CareerPhase.QUALIFYING, events = state.events + CareerEvent(state.round, "WEEKEND", "Fim de semana aberto"))
        return state
    }

    fun qualifyingComplete(): CareerFlowState {
        require(state.phase == CareerPhase.QUALIFYING) { "Classificação não está ativa" }
        state = state.copy(phase = CareerPhase.PRE_RACE, events = state.events + CareerEvent(state.round, "QUALIFYING", "Grid definido"))
        return state
    }

    fun startRace(): CareerFlowState {
        require(state.phase == CareerPhase.PRE_RACE) { "Corrida não pode iniciar agora" }
        state = state.copy(phase = CareerPhase.RACE, events = state.events + CareerEvent(state.round, "RACE", "Corrida iniciada"))
        return state
    }

    fun requestDecision(reason: String): CareerFlowState {
        require(state.phase == CareerPhase.RACE) { "Decisão só pode ser criada durante a corrida" }
        state = state.copy(phase = CareerPhase.DECISION, events = state.events + CareerEvent(state.round, "DECISION", reason))
        return state
    }

    fun resolveDecision(): CareerFlowState {
        require(state.phase == CareerPhase.DECISION) { "Não há decisão pendente" }
        state = state.copy(phase = CareerPhase.RACE, events = state.events + CareerEvent(state.round, "DECISION_RESOLVED", "Decisão do gestor confirmada"))
        return state
    }

    fun finishRace(driverPoints: Int, constructorPoints: Int, raceIncome: Long = 0, raceCost: Long = 0): CareerFlowState {
        require(state.phase == CareerPhase.RACE) { "Corrida não está em andamento" }
        val newBudget = state.budget + raceIncome - raceCost
        state = state.copy(
            phase = CareerPhase.RESULT,
            championshipPoints = state.championshipPoints + driverPoints,
            constructorPoints = state.constructorPoints + constructorPoints,
            budget = newBudget,
            events = state.events + CareerEvent(state.round, "RESULT", "Resultado confirmado")
        )
        return state
    }

    fun advanceRound(): CareerFlowState {
        require(state.phase == CareerPhase.RESULT) { "Só é possível avançar após o resultado" }
        if (state.completedRounds + 1 >= 30) {
            state = state.copy(completedRounds = 30, phase = CareerPhase.OFFSEASON, events = state.events + CareerEvent(state.round, "SEASON", "Temporada encerrada"))
        } else {
            state = state.copy(round = state.round + 1, completedRounds = state.completedRounds + 1, phase = CareerPhase.HOME,
                events = state.events + CareerEvent(state.round, "ROUND", "Avanço para o próximo GP"))
        }
        return state
    }

    fun startNextSeason(): CareerFlowState {
        require(state.phase == CareerPhase.OFFSEASON) { "Offseason não está disponível" }
        state = state.copy(season = state.season + 1, round = 1, completedRounds = 0, phase = CareerPhase.HOME,
            events = state.events + CareerEvent(1, "NEW_SEASON", "Nova temporada iniciada"))
        return state
    }

    fun save(): String = buildString {
        appendLine("F1TM_V16")
        appendLine("season=${state.season}")
        appendLine("round=${state.round}")
        appendLine("team=${state.playerTeamId}")
        appendLine("phase=${state.phase.name}")
        appendLine("completed=${state.completedRounds}")
        appendLine("driverPoints=${state.championshipPoints}")
        appendLine("constructorPoints=${state.constructorPoints}")
        appendLine("budget=${state.budget}")
    }

    companion object {
        fun load(serialized: String): CareerFlowEngine {
            val lines = serialized.lines().filter { it.contains('=') }
            val map = lines.associate { it.substringBefore('=') to it.substringAfter('=') }
            require(serialized.lineSequence().firstOrNull() == "F1TM_V16") { "Save V16 inválido" }
            val s = CareerFlowState(
                season = map["season"]!!.toInt(), round = map["round"]!!.toInt(), playerTeamId = map["team"]!!.toInt(),
                phase = CareerPhase.valueOf(map["phase"]!!), completedRounds = map["completed"]!!.toInt(),
                championshipPoints = map["driverPoints"]!!.toInt(), constructorPoints = map["constructorPoints"]!!.toInt(),
                budget = map["budget"]!!.toLong()
            )
            return CareerFlowEngine(s)
        }
    }
}
