package com.f1teammanager.core.race

/**
 * V351: validates a completed GP before the career layer applies any persistent side effects.
 * This is deliberately pure so the same invariants can be tested without Android/Compose.
 */
object RaceResultValidator {
    fun validate(result: RaceResult, programmedLaps: Int): List<String> {
        val errors = mutableListOf<String>()
        if (programmedLaps <= 0) errors += "A distância programada deve ser positiva."
        if (result.classification.isEmpty()) errors += "A classificação está vazia."

        val ids = result.classification.map { it.driverId }
        if (ids.size != ids.distinct().size) errors += "Há pilotos duplicados na classificação."
        if (result.classification.any { it.driverId <= 0 }) errors += "A classificação contém ID de piloto inválido."
        if (result.classification.any { it.driverName.isBlank() || it.teamName.isBlank() }) {
            errors += "A classificação contém piloto ou equipe sem identificação."
        }
        if (result.classification.any { it.position <= 0 }) errors += "A classificação contém posição inválida."
        if (result.classification.map { it.position }.distinct().size != result.classification.size) {
            errors += "A classificação contém posições duplicadas."
        }
        if (result.classification.any { it.totalTimeMs < 0L }) errors += "A classificação contém tempo total negativo."
        if (result.classification.any { it.pitStops < 0 }) errors += "A classificação contém número negativo de paradas."
        if (result.classification.any { it.laps < 0 || it.laps > programmedLaps }) {
            errors += "Há piloto com número de voltas fora da distância programada."
        }
        if (result.classification.isNotEmpty() && result.classification.none { it.laps == programmedLaps }) {
            errors += "Nenhum piloto concluiu a distância programada."
        }
        if (result.points.keys.any { it !in ids }) errors += "A pontuação contém piloto ausente da classificação."
        if (result.fastestLapDriverId != null && result.fastestLapDriverId !in ids) {
            errors += "O piloto da volta mais rápida não consta na classificação."
        }
        if (result.points.values.any { it < 0 }) errors += "A pontuação contém valor negativo."
        if (result.safetyCarLaps < 0 || result.vscLaps < 0) errors += "A neutralização contém número negativo de voltas."
        if (result.fastestLapTimeMs < 0L) errors += "O tempo da volta mais rápida é negativo."
        return errors
    }

    fun requireValid(result: RaceResult, programmedLaps: Int) {
        val errors = validate(result, programmedLaps)
        require(errors.isEmpty()) { "Resultado do GP inválido: ${errors.joinToString(" ")}" }
    }
}
