package com.f1teammanager.core.manager

import com.f1teammanager.core.season.WorldDatabase
import com.f1teammanager.core.season.DriverProfileCatalog
import com.f1teammanager.core.season.SeasonCalendar
import kotlin.math.roundToLong
import kotlin.random.Random

/** Stage 3: driver market. Transfers are future-season commitments; the current grid never changes mid-season. */
class DriverMarketEngine(private val seed: Int = 20261003) {
    private val allIds = WorldDatabase.allDrivers.map { it.id }.toSet()

    fun initialState(season: Int = 2026): DriverMarketState {
        val contracts = WorldDatabase.drivers.map { d ->
            val value = marketValueFor(d.id)
            val years = chooseAiYears(d.id, season, 1)
            DriverDeal(d.id, d.teamId, years, salaryFor(d.id), value, season, role = DriverTeamRole.EQUAL)
        }
        val prefs = WorldDatabase.allDrivers.associate { it.id to DriverRolePreference.INDIFFERENT }
        val free = WorldDatabase.allDrivers.map { it.id }.filter { id -> contracts.none { it.driverId == id } }
        return DriverMarketState(contracts=contracts, freeAgents=free, rolePreferences=prefs).normalized()
    }

    fun salaryFor(driverId: Int): Long {
        val d = WorldDatabase.allDrivers.firstOrNull { it.id == driverId } ?: return 500_000L
        val overall = overall(d)
        val classBonus = when (d.driverClass.lowercase()) {
            "lenda" -> 18_000_000L
            "pro" -> 9_000_000L
            "forte" -> 4_000_000L
            "médio", "medio" -> 1_500_000L
            else -> 0L
        }
        val evolutionBonus = when (d.evolution.lowercase()) {
            "prodígio", "prodigio" -> 2_500_000L
            "auge rápido", "auge rapido" -> 1_800_000L
            "auge moderado", "auge tardio" -> 1_200_000L
            else -> 0L
        }
        // V503: reduce the generated base salary for every driver by 40%.
        // Keep the same rating/class/evolution balance; only the salary scale changes.
        val originalSalary = (500_000L + overall * 380_000L + classBonus + evolutionBonus)
            .coerceIn(500_000L, 70_000_000L)
        return (originalSalary * 0.60).roundToLong().coerceIn(300_000L, 42_000_000L)
    }

    fun marketValueFor(driverId: Int): Long {
        val d = WorldDatabase.allDrivers.firstOrNull { it.id == driverId } ?: return 500_000L
        val base = overall(d) * 500_000L
        val classMultiplier = when (d.driverClass.lowercase()) {
            "lenda" -> 1.65; "pro" -> 1.35; "forte" -> 1.15; "médio", "medio" -> 0.90; else -> 0.70
        }
        val evolutionMultiplier = when (d.evolution.lowercase()) {
            "prodígio", "prodigio" -> 1.25; "auge rápido", "auge rapido" -> 1.15; "auge moderado", "auge tardio" -> 1.10; "demorado" -> 0.90; else -> 1.0
        }
        return (base * classMultiplier * evolutionMultiplier).roundToLong().coerceIn(500_000L, 80_000_000L)
    }

    fun roster(state: DriverMarketState, teamId: Int, includeScheduled: Boolean = false, season: Int = 2026): List<Int> {
        if (includeScheduled) return projectedRosterForSeason(state, teamId, season)
        return state.contracts.filter { it.teamId == teamId && it.activeIn(season) }.map { it.driverId }
    }

    /** Roster projection applies both incoming deals and the seats they explicitly replace. */
    fun projectedRosterForSeason(state: DriverMarketState, teamId: Int, season: Int): List<Int> {
        val incoming = state.scheduled.filter { it.toTeamId == teamId && it.startSeason == season }
        val leavingIds = state.scheduled.filter {
            it.fromTeamId == teamId && it.toTeamId != teamId && it.startSeason == season
        }.map { it.driverId }.toSet()
        val replacedIds = incoming.mapNotNull { it.replaceDriverId }.toSet()
        val retained = state.contracts.filter {
            it.teamId == teamId && it.activeIn(season) && it.driverId !in leavingIds && it.driverId !in replacedIds
        }.map { it.driverId }
        return (retained + incoming.map { it.driverId }).distinct()
    }

    fun freeAgents(state: DriverMarketState): List<Int> = state.freeAgents.filter { id -> state.contracts.none { it.driverId == id } && state.scheduled.none { it.driverId == id } }

    fun expiring(state: DriverMarketState, season: Int): List<DriverDeal> = state.contracts.filter { it.seasonSigned + it.years <= season }

    fun canReceiveProposals(state: DriverMarketState, driverId: Int, season: Int): Boolean {
        if (state.scheduled.any { it.driverId == driverId }) return false
        val deal = state.contracts.firstOrNull { it.driverId == driverId } ?: return driverId in state.freeAgents
        return deal.canReceiveProposals(season)
    }

    /**
     * Candidate pool for an AI team. Player-owned drivers are deliberately included
     * only when their contract is in its final year; multi-year player contracts are
     * not eligible for mid-contract poaching. This keeps incoming proposals manual.
     */
    internal fun aiApproachCandidates(
        state: DriverMarketState, teamId: Int, season: Int, playerTeamId: Int,
        teamChampionshipPoints: Map<Int, Int> = emptyMap(),
        driverAttributes: Map<Int, List<Int>> = emptyMap(),
        nextSeasonCarStrength: Map<Int, Int> = emptyMap()
    ): List<Int> {
        val free = freeAgents(state).filter { canReceiveProposals(state, it, season) }
        val contracted = state.contracts.filter { deal ->
            deal.teamId != teamId && when {
                deal.teamId == playerTeamId -> canReceiveProposals(state, deal.driverId, season)
                else -> canReceiveProposals(state, deal.driverId, season) || canAiApproachMidContract(
                    state, deal.driverId, teamId, season, playerTeamId, teamChampionshipPoints,
                    driverAttributes, nextSeasonCarStrength
                )
            }
        }.map { it.driverId }
        return (free + contracted).distinct()
    }

    fun interestScore(
        state: DriverMarketState, driverId: Int, toTeamId: Int, salary: Long,
        role: DriverTeamRole, season: Int,
        teamChampionshipPoints: Map<Int, Int> = emptyMap(),
        driverAttributes: Map<Int, List<Int>> = emptyMap(),
        driverChampionshipPoints: Map<Int, Int> = emptyMap(),
        nextSeasonCarStrength: Map<Int, Int> = emptyMap()
    ): Int {
        val destinationStrength = nextSeasonCarStrength[toTeamId]?.coerceIn(0, 100)
            ?: teamSportingStrength(toTeamId, teamChampionshipPoints)
        val currentForSalary = state.contracts.firstOrNull { it.driverId == driverId && it.activeIn(season) }
        val salaryReferenceForScore = maxOf(currentSalaryValue(driverId, driverAttributes), currentForSalary?.salary ?: 0L).coerceAtLeast(1L)
        val salaryScore = (salary.toDouble() / salaryReferenceForScore * 20.0).roundToLong().toInt().coerceIn(0,20)
        val rolePref = state.rolePreferences[driverId] ?: DriverRolePreference.INDIFFERENT
        val roleScore = when (rolePref) {
            DriverRolePreference.DEMANDS_PILOT_1 -> if (role == DriverTeamRole.PILOT_1) 10 else -18
            DriverRolePreference.PREFERS_PILOT_1 -> if (role == DriverTeamRole.PILOT_1) 7 else 0
            DriverRolePreference.PREFERS_EQUALITY -> if (role == DriverTeamRole.EQUAL) 7 else 0
            DriverRolePreference.INDIFFERENT -> 5
        }
        val prestige = teamPrestige(toTeamId, teamChampionshipPoints)
        val project = (destinationStrength + prestige) / 2
        val recent = teamRecentPerformance(toTeamId, teamChampionshipPoints)
        val current = state.contracts.firstOrNull { it.driverId == driverId && it.activeIn(season) }
        val retention = if (current?.teamId == toTeamId) 10 else 0
        val currentStrength = current?.let {
            nextSeasonCarStrength[it.teamId]?.coerceIn(0, 100)
                ?: teamSportingStrength(it.teamId, teamChampionshipPoints)
        }
        val strengthDrop = if (currentStrength == null || toTeamId == current?.teamId) 0
            else (currentStrength - destinationStrength).coerceAtLeast(0)
        val currentOverall = currentDriverOverall(driverId, driverAttributes)
        // V660: for future-season decisions, the physical next-car projection dominates
        // current championship reputation. A 20+ point downgrade is a major career risk.
        val sportingPenalty = if (nextSeasonCarStrength.isEmpty()) {
            (strengthDrop * 0.82).roundToLong().toInt().coerceIn(0, 38)
        } else when {
            strengthDrop >= 30 -> 64
            strengthDrop >= 25 -> 56
            strengthDrop >= 20 -> 47
            strengthDrop >= 15 -> 35
            strengthDrop >= 10 -> 23
            strengthDrop >= 5 -> 12
            strengthDrop > 0 -> 5
            else -> 0
        } + if (nextSeasonCarStrength.isNotEmpty() && currentStrength != null && currentStrength >= 70 &&
            destinationStrength <= (currentStrength * 0.40).toInt()) 12 else 0
        val eliteDowngradePenalty = if (nextSeasonCarStrength.isNotEmpty() && currentOverall >= 82 && strengthDrop >= 12) 10 else 0
        val driverPoints = driverChampionshipPoints[driverId] ?: 0
        val driverRank = if (driverChampionshipPoints.values.any { it > 0 }) driverChampionshipPoints.count { it.value > driverPoints } + 1 else Int.MAX_VALUE
        val driverIsTitleContender = driverRank <= 5 && driverPoints > 0
        val titleContenderLeavingCurrent = current != null && toTeamId != current.teamId && currentOverall >= 84 && currentStrength != null && currentStrength >= 72
        val titleContenderDropPenalty = if (destinationStrength <= 50 && (titleContenderLeavingCurrent || driverIsTitleContender)) 12 else 0
        // Compare against both fair market pay and existing pay. A stale low salary can
        // no longer make an ordinary raise look like a super-offer.
        val salaryReference = maxOf(currentSalaryValue(driverId, driverAttributes), current?.salary ?: 0L).coerceAtLeast(1L)
        val salaryRatio = salary.toDouble() / salaryReference.toDouble()
        val exceptionalMoneyBonus = if (nextSeasonCarStrength.isEmpty()) when {
            salaryRatio >= 10.0 -> 88
            salaryRatio >= 8.0 -> 76
            salaryRatio >= 6.0 -> 65
            salaryRatio >= 4.5 -> 54
            salaryRatio >= 3.5 -> 42
            salaryRatio >= 2.75 -> 30
            salaryRatio >= 2.0 -> 18
            salaryRatio >= 1.5 -> 8
            else -> 0
        } else when {
            salaryRatio >= 10.0 -> 50
            salaryRatio >= 8.0 -> 44
            salaryRatio >= 6.0 -> 36
            salaryRatio >= 4.5 -> 28
            salaryRatio >= 3.5 -> 22
            salaryRatio >= 2.75 -> 17
            salaryRatio >= 2.0 -> 12
            salaryRatio >= 1.5 -> 6
            else -> 0
        }
        val score = if (nextSeasonCarStrength.isEmpty()) {
            // Preserve legacy scoring for standalone callers that do not have a career projection.
            (destinationStrength * .25 + salaryScore + prestige * .15 + project * .15 + roleScore +
                recent * .10 + teamHistory(toTeamId, teamChampionshipPoints) * .05 + retention +
                exceptionalMoneyBonus - sportingPenalty - titleContenderDropPenalty).roundToLong().toInt()
        } else {
            (destinationStrength * .40 + prestige * .08 + project * .08 + salaryScore + roleScore +
                recent * .06 + teamHistory(toTeamId, teamChampionshipPoints) * .03 + retention +
                exceptionalMoneyBonus - sportingPenalty - eliteDowngradePenalty - titleContenderDropPenalty).roundToLong().toInt()
        }
        val bounded = score.coerceIn(0,100)
        // An elite driver does not abandon a leading future project for an ordinary raise.
        // Truly exceptional compensation can reopen the decision, but never by default.
        val protectedScore = if (nextSeasonCarStrength.isNotEmpty() && currentOverall >= 82 && strengthDrop >= 20) {
            when { salaryRatio >= 9.0 -> bounded
                salaryRatio >= 6.0 -> minOf(bounded, 72)
                salaryRatio >= 3.5 -> minOf(bounded, 58)
                else -> minOf(bounded, 42)
            }
        } else bounded
        return protectedScore
    }

    /** Compatibility entry point for the previous V9 engine. It now creates a future-season offer instead of moving the driver immediately. */
    fun offer(state: DriverMarketState, driverId: Int, fromTeamId: Int, toTeamId: Int, years: Int, salary: Long,
              teamStrength: Int = 70, reputation: Int = 50, season: Int = 2026, rngSeed: Int = seed): Pair<DriverMarketState, DriverOffer> =
        makeOffer(state, driverId, toTeamId, years.coerceIn(1,5), salary, DriverTeamRole.EQUAL, season)

    fun makeOffer(
        state: DriverMarketState, driverId: Int, toTeamId: Int, years: Int, salary: Long,
        role: DriverTeamRole, season: Int, currentWeek: Int = 1, round: Int = 1, replaceDriverId: Int? = null, proposerTeamId: Int? = null,
        teamChampionshipPoints: Map<Int, Int> = emptyMap(), driverAttributes: Map<Int, List<Int>> = emptyMap(),
        driverChampionshipPoints: Map<Int, Int> = emptyMap(),
        nextSeasonCarStrength: Map<Int, Int> = emptyMap(),
        allowMidContractTransfer: Boolean = false,
        playerTeamId: Int? = null,
        notificationTitle: String = "PROPOSTA ENVIADA"
    ): Pair<DriverMarketState, DriverOffer> {
        require(driverId in allIds) { "Piloto inexistente" }
        require(toTeamId in WorldDatabase.teams.map { it.id }) { "Equipe inexistente" }
        require(marketOpen(currentWeek, season)) { "O mercado de pilotos abre somente após 8 corridas realizadas" }
        require(years in 1..5) { "O contrato deve ter entre 1 e 5 anos" }
        val standardAvailability = canReceiveProposals(state, driverId, season)
        val currentContract = state.contracts.firstOrNull { it.driverId == driverId && it.activeIn(season) }
        val permittedMidContractApproach = allowMidContractTransfer && currentContract != null &&
            currentContract.teamId != toTeamId && currentContract.contractYear(season) < currentContract.years &&
            state.scheduled.none { it.driverId == driverId && it.startSeason == season + 1 }
        require(standardAvailability || permittedMidContractApproach) {
            "Este piloto não está disponível para propostas nesta temporada"
        }
        val destinationRoster = roster(state, toTeamId, season = season)
        val reservedOpenSeats = state.scheduled.count { it.toTeamId == toTeamId && it.startSeason == season + 1 && it.replaceDriverId == null && it.driverId != driverId }
        val projectedRosterSize = destinationRoster.size + reservedOpenSeats
        if (projectedRosterSize >= 2 && state.contracts.none { it.driverId == driverId && it.teamId == toTeamId }) {
            require(replaceDriverId != null && replaceDriverId in destinationRoster) { "As duas vagas futuras já estão ocupadas; selecione um titular atual para substituir" }
            require(state.scheduled.none { it.toTeamId == toTeamId && it.replaceDriverId == replaceDriverId }) { "Esse piloto já está reservado para outra contratação futura; selecione o outro piloto" }
        }
        require(state.scheduled.none { it.driverId == driverId }) { "Piloto já possui transferência futura" }
        if (replaceDriverId != null) {
            require(state.scheduled.none {
                it.toTeamId == toTeamId && it.startSeason == season + 1 && it.replaceDriverId == replaceDriverId
            }) { "A vaga selecionada já foi reservada por um contrato futuro" }
            require(state.pending.none {
                it.toTeamId == toTeamId && it.seasonTarget == season + 1 && it.replaceDriverId == replaceDriverId &&
                    it.status in setOf(NegotiationStatus.PENDING, NegotiationStatus.COUNTER)
            }) { "A vaga selecionada já está em negociação" }
        }
        // Um piloto pode negociar simultaneamente com várias equipes.
        // A negociação é individual por equipe; somente uma transferência futura
        // efetivamente assinada encerra as demais negociações do piloto.
        val current = state.contracts.firstOrNull { it.driverId == driverId }
        val from = current?.teamId ?: 0
        val proposer = proposerTeamId ?: toTeamId
        require(state.pending.none {
            it.driverId == driverId && it.toTeamId == toTeamId && it.proposerTeamId == proposer &&
                it.seasonTarget == season + 1 && it.status in setOf(NegotiationStatus.PENDING, NegotiationStatus.COUNTER)
        }) { "Esta equipe já possui uma proposta ativa para este piloto" }
        val value = currentMarketValue(driverId, driverAttributes)
        val score = interestScore(state, driverId, toTeamId, salary, role, season, teamChampionshipPoints, driverAttributes, driverChampionshipPoints, nextSeasonCarStrength)
        val rng = Random(seed + driverId * 31 + toTeamId * 17 + round * 13 + currentWeek * 7)
        // The ordinary market keeps a 2–3 week response window. In the final
        // negotiation weeks, deadlines contract so accepted deals can be recorded
        // before the season boundary instead of being discarded during rollover.
        val responseDelay = when {
            currentWeek >= 56 -> 0
            currentWeek >= 52 -> 1
            else -> if (rng.nextBoolean()) 2 else 3
        }
        val normalizedRound = round.coerceIn(1, 3)
        val offer = DriverOffer(
            driverId, from, toTeamId, years.coerceIn(1, 5), salary.coerceAtLeast(100_000L), role,
            value, (score + rng.nextInt(-4, 5)).coerceIn(0, 100), normalizedRound,
            currentWeek + responseDelay, NegotiationStatus.PENDING, season + 1, replaceDriverId, proposer
        )
        val next = state.copy(
            pending = (state.pending.filterNot {
                it.driverId == driverId && it.toTeamId == toTeamId && it.seasonTarget == season + 1 && it.round == normalizedRound
            } + offer).takeLast(100),
            notifications = state.notifications + MarketNotification(
                season, currentWeek, notificationTitle,
                "A ${teamName(proposer)} fez uma proposta para ${teamName(toTeamId)} por ${driverName(driverId)} (equipe atual: ${if (from > 0) teamName(from) else "sem equipe"}). O piloto responderá em ${responseDelay} semanas.",
                true,
                relatedTeamId = playerTeamId?.takeIf { it == from || it == toTeamId || it == proposer }
            )
        )
        return next.normalized() to offer
    }

    /** Processes proposals whose driver-response deadline has arrived. Responses take 2 or 3 calendar weeks. */
    fun expireOffers(
        state: DriverMarketState,
        currentWeek: Int,
        season: Int = 0,
        playerTeamId: Int? = null,
        onlyDriverId: Int? = null,
        onlyTeamId: Int? = null,
        teamChampionshipPoints: Map<Int, Int> = emptyMap(),
        driverAttributes: Map<Int, List<Int>> = emptyMap(),
        driverChampionshipPoints: Map<Int, Int> = emptyMap(),
        nextSeasonCarStrength: Map<Int, Int> = emptyMap()
    ): DriverMarketState {
        // Offers from AI teams for player-owned drivers have a real deadline, but
        // expiration is a manager decision timeout, never an automatic driver reply.
        val due = state.pending.filter {
            it.status == NegotiationStatus.PENDING && it.expiresAfterWeek <= currentWeek &&
                (onlyDriverId == null || it.driverId == onlyDriverId) &&
                (onlyTeamId == null || it.toTeamId == onlyTeamId)
        }
        if (due.isEmpty()) return state
        var s = state
        fun playerTeamFor(offer: DriverOffer): Int? = playerTeamId?.takeIf {
            it == offer.fromTeamId || it == offer.toTeamId || it == offer.proposerTeamId
        }
        due.forEach { offer ->
            // The due list is a snapshot. A previous accepted offer may already have
            // signed this driver and removed rival offers; never process a stale entry
            // from that snapshot or emit a false "transfer could not be recorded" notice.
            if (s.pending.none { sameNegotiation(it, offer) && it.status == NegotiationStatus.PENDING }) return@forEach
            val isPlayerIncoming = playerTeamId != null && offer.fromTeamId == playerTeamId &&
                offer.toTeamId != playerTeamId && offer.proposerTeamId == offer.toTeamId
            if (isPlayerIncoming) {
                s = s.copy(
                    pending = s.pending.filterNot { sameNegotiation(it, offer) },
                    notifications = s.notifications + MarketNotification(
                        season, currentWeek, "OFERTA EXPIRADA",
                        "A proposta da ${teamName(offer.toTeamId)} por ${driverName(offer.driverId)}, piloto da ${teamName(offer.fromTeamId)}, expirou sem decisão do Team Principal.", true,
                        relatedTeamId = playerTeamFor(offer)
                    )
                )
                return@forEach
            }
            val rng = Random(seed + season * 997 + currentWeek * 31 + offer.driverId * 41 + offer.toTeamId * 17 + offer.round * 13)
            val refreshedScore = interestScore(
                s, offer.driverId, offer.toTeamId, offer.salary, offer.role, season,
                teamChampionshipPoints, driverAttributes, driverChampionshipPoints, nextSeasonCarStrength
            )
            val evaluatedOffer = offer.copy(interestScore = refreshedScore)
            val base = refreshedScore
            val incumbent = s.contracts.firstOrNull { it.driverId == offer.driverId }
            val needsSeat = offer.driverId in s.freeAgents || (incumbent != null && !incumbent.activeIn(offer.seasonTarget))
            val endWindowUrgency = if (needsSeat) ((currentWeek - 32) / 3).coerceIn(0, 10) else 0
            val bestAlternative = s.pending.asSequence().filter {
                it.driverId == offer.driverId && it.seasonTarget == offer.seasonTarget && !sameNegotiation(it, offer) &&
                    it.status in setOf(NegotiationStatus.PENDING, NegotiationStatus.COUNTER)
            }.map { alternative ->
                alternative.copy(interestScore = interestScore(
                    s, alternative.driverId, alternative.toTeamId, alternative.salary, alternative.role, season,
                    teamChampionshipPoints, driverAttributes, driverChampionshipPoints, nextSeasonCarStrength
                ))
            }.maxByOrNull(::offerAttractiveness)
            val choosesAnotherOffer = bestAlternative != null && offerAttractiveness(bestAlternative) >= offerAttractiveness(evaluatedOffer) + 6
            val adjusted = (base + endWindowUrgency + rng.nextInt(-6, 7)).coerceIn(0, 100)
            val decision = when {
                choosesAnotherOffer -> NegotiationStatus.REJECTED
                adjusted >= 78 -> NegotiationStatus.ACCEPTED
                adjusted >= 52 -> NegotiationStatus.COUNTER
                else -> NegotiationStatus.REJECTED
            }
            val demandedSalary = if (decision == NegotiationStatus.COUNTER)
                (offer.salary * (1.06 + rng.nextDouble() * 0.10)).roundToLong() else offer.salary
            val demandedYears = if (decision == NegotiationStatus.COUNTER && rng.nextInt(100) >= 65) (1..5).random(rng) else offer.years
            val demandedRole = if (decision == NegotiationStatus.COUNTER) {
                when (s.rolePreferences[offer.driverId]) {
                    DriverRolePreference.DEMANDS_PILOT_1 -> DriverTeamRole.PILOT_1
                    DriverRolePreference.PREFERS_EQUALITY -> DriverTeamRole.EQUAL
                    else -> offer.role
                }
            } else offer.role
            val response = offer.copy(
                years = demandedYears, salary = demandedSalary.coerceAtLeast(100_000L), role = demandedRole,
                interestScore = adjusted, status = decision, expiresAfterWeek = currentWeek
            )
            s = s.copy(pending = s.pending.filterNot { sameNegotiation(it, offer) })
            when (decision) {
                NegotiationStatus.ACCEPTED -> {
                    // Nunca descarte silenciosamente a resposta: se a assinatura futura
                    // falhar por conflito de elenco/transferência, a carreira precisa
                    // registrar um evento visível em vez de remover a proposta sem retorno.
                    val signed = runCatching { signFuture(s, response, season) }
                    if (signed.isSuccess) {
                        val next = signed.getOrThrow()
                        val deal = next.scheduled.first { it.driverId == offer.driverId && it.startSeason == offer.seasonTarget }
                        s = recordCompletedSignature(next, deal, season, currentWeek, playerTeamFor(offer))
                    } else {
                        s = s.copy(notifications = s.notifications + MarketNotification(
                            season, currentWeek, "PROPOSTA NÃO CONCLUÍDA",
                            "${driverName(offer.driverId)} aceitou a proposta da equipe ${teamName(offer.toTeamId)}, mas a transferência não pôde ser registrada: ${signed.exceptionOrNull()?.message ?: "conflito de contrato"}. Revise a negociação no mercado de pilotos.", true,
                            relatedTeamId = playerTeamFor(offer)
                        ))
                    }
                }
                NegotiationStatus.REJECTED -> {
                    s = s.copy(notifications = s.notifications + MarketNotification(
                        season, currentWeek, "PROPOSTA RECUSADA",
                        if (choosesAnotherOffer && bestAlternative != null)
                            "${driverName(offer.driverId)} recusou ${teamName(offer.toTeamId)} e priorizou a proposta da ${teamName(bestAlternative.toTeamId)}."
                        else "${driverName(offer.driverId)} recusou a proposta da ${teamName(offer.toTeamId)}.", true,
                        relatedTeamId = playerTeamFor(offer)
                    ))
                }
                NegotiationStatus.COUNTER -> {
                    val counter = response.copy(expiresAfterWeek = currentWeek, status = NegotiationStatus.COUNTER)
                    s = s.copy(
                        pending = (s.pending + counter).takeLast(100),
                        notifications = s.notifications + MarketNotification(
                            season, currentWeek, "CONTRAPROPOSTA RECEBIDA",
                            "${driverName(offer.driverId)} enviou uma contraproposta para ${teamName(offer.toTeamId)} (proposta iniciada por ${teamName(offer.proposerTeamId)}; equipe atual: ${if (offer.fromTeamId > 0) teamName(offer.fromTeamId) else "sem equipe"}): salário exigido ${compactMoney(counter.salary)}/ano; duração ${counter.years} ano(s); papel ${roleLabel(counter.role)}; início na temporada ${counter.seasonTarget}. Abra Mercado de Pilotos para aceitar, recusar ou fazer outra contraproposta.", true,
                            relatedTeamId = playerTeamFor(offer)
                        )
                    )
                    // If the proposing team is AI, it decides automatically. If it is the player,
                    // the counter remains visible as an action card in the market screen.
                }
                else -> Unit
            }
        }
        return s.normalized()
    }

    private fun compactMoney(value: Long): String = when {
        value >= 1_000_000L -> "€ ${"%.1f".format(java.util.Locale("pt", "BR"), value / 1_000_000.0)} milhões"
        value >= 1_000L -> "€ ${"%.0f".format(java.util.Locale("pt", "BR"), value / 1_000.0)} mil"
        else -> "€ $value"
    }

    private fun roleLabel(role: DriverTeamRole): String = when (role) {
        DriverTeamRole.PILOT_1 -> "Piloto 1"
        DriverTeamRole.PILOT_2 -> "Piloto 2"
        DriverTeamRole.EQUAL -> "Pilotos em igualdade"
    }

    private fun sameNegotiation(a: DriverOffer, b: DriverOffer): Boolean =
        a.driverId == b.driverId && a.toTeamId == b.toTeamId && a.seasonTarget == b.seasonTarget && a.round == b.round

    private fun resolveAiCounters(
        state: DriverMarketState, season: Int, currentWeek: Int, playerTeamId: Int,
        teamChampionshipPoints: Map<Int, Int>, driverAttributes: Map<Int, List<Int>>,
        driverChampionshipPoints: Map<Int, Int>,
        nextSeasonCarStrength: Map<Int, Int> = emptyMap()
    ): DriverMarketState {
        var s = state
        val counters = s.pending.filter { it.status == NegotiationStatus.COUNTER && it.proposerTeamId != 0 && it.proposerTeamId != playerTeamId }
        counters.forEach { offer ->
            val playerRelatedTeamId = playerTeamId.takeIf { it == offer.fromTeamId || it == offer.toTeamId }
            if (s.pending.none { sameNegotiation(it, offer) && it.status == NegotiationStatus.COUNTER }) return@forEach
            val rng = Random(seed + season * 701 + currentWeek * 19 + offer.driverId * 29 + offer.toTeamId * 11 + offer.round * 43)
            val original = maxOf(currentSalaryValue(offer.driverId, driverAttributes), s.contracts.firstOrNull { it.driverId == offer.driverId && it.activeIn(season) }?.salary ?: 0L)
            val salaryRatio = offer.salary.toDouble() / original.coerceAtLeast(1L)
            val fit = interestScore(s, offer.driverId, offer.toTeamId, offer.salary, offer.role, season, teamChampionshipPoints, driverAttributes, driverChampionshipPoints, nextSeasonCarStrength)
            val acceptScore = fit + if (salaryRatio <= 1.18) 8 else if (salaryRatio <= 1.28) 2 else -8
            val accept = acceptScore + rng.nextInt(-6, 7) >= if (offer.round >= 3) 56 else 64
            if (accept) {
                val accepted = offer.copy(status = NegotiationStatus.ACCEPTED)
                val signed = runCatching { signFuture(s, accepted, season) }
                if (signed.isSuccess) {
                    val next = signed.getOrThrow()
                    val deal = next.scheduled.first { it.driverId == offer.driverId && it.startSeason == offer.seasonTarget }
                    s = recordCompletedSignature(next, deal, season, currentWeek, playerRelatedTeamId)
                } else {
                    s = s.copy(notifications = s.notifications + MarketNotification(
                        season, currentWeek, "PROPOSTA NÃO CONCLUÍDA",
                        "A contraproposta de ${driverName(offer.driverId)} foi aceita, mas o contrato não pôde ser registrado: ${signed.exceptionOrNull()?.message ?: "conflito de contrato"}.", true,
                        relatedTeamId = playerRelatedTeamId
                    ))
                }
            } else if (offer.round < 3) {
                val nextSalary = (offer.salary * (0.97 + rng.nextDouble() * 0.04)).roundToLong().coerceAtLeast(500_000L)
                val nextRole = if (rng.nextInt(100) < 70) offer.role else preferredRoleFor(s, offer.driverId, offer.toTeamId, season)
                val cleaned = s.copy(pending = s.pending.filterNot { sameNegotiation(it, offer) })
                runCatching {
                    val (next, _) = counterOffer(cleaned, offer, season, currentWeek, nextSalary, offer.years, nextRole, offer.replaceDriverId, playerRelatedTeamId)
                    s = next.copy(notifications = next.notifications + MarketNotification(
                        season, currentWeek, "CONTRAPROPOSTA DA EQUIPE",
                        "A ${teamName(offer.toTeamId)} fez uma nova contraproposta a ${driverName(offer.driverId)}. O piloto responderá em 2 ou 3 semanas.", true,
                        relatedTeamId = playerRelatedTeamId
                    ))
                }
            } else {
                s = s.copy(
                    pending = s.pending.filterNot { sameNegotiation(it, offer) },
                    notifications = s.notifications + MarketNotification(
                        season, currentWeek, "CONTRAPROPOSTA RECUSADA",
                        "A ${teamName(offer.toTeamId)} recusou a contraproposta final de ${driverName(offer.driverId)}.", true,
                        relatedTeamId = playerRelatedTeamId
                    )
                )
            }
        }
        return s.normalized()
    }

    /** Opens the next negotiation round using the player's new terms. Maximum 3 rounds. */
    fun counterOffer(
        state: DriverMarketState,
        previous: DriverOffer,
        season: Int,
        currentWeek: Int,
        salary: Long,
        years: Int,
        role: DriverTeamRole,
        replaceDriverId: Int? = null,
        playerTeamId: Int? = null
    ): Pair<DriverMarketState, DriverOffer> {
        require(previous.status == NegotiationStatus.COUNTER) { "Esta negociação não está aguardando contraproposta" }
        require(previous.round < 3) { "A negociação já atingiu 3 rodadas" }
        require(previous.seasonTarget == season + 1) { "A proposta pertence a outra temporada" }
        require(state.pending.any { it.driverId == previous.driverId && it.toTeamId == previous.toTeamId && it.seasonTarget == previous.seasonTarget && it.round == previous.round && it.status == NegotiationStatus.COUNTER }) {
            "Esta contraproposta já não está ativa"
        }
        val cleaned = state.copy(pending = state.pending.filterNot {
            it.driverId == previous.driverId && it.toTeamId == previous.toTeamId &&
                it.seasonTarget == previous.seasonTarget && it.round == previous.round
        })
        // Keep the replacement selected in the original negotiation when the UI does not
        // explicitly choose another driver. A nullable UI selection must not erase it.
        val effectiveReplacementDriverId = replaceDriverId ?: previous.replaceDriverId
        return makeOffer(
            cleaned, previous.driverId, previous.toTeamId, years, salary, role, season, currentWeek,
            previous.round + 1, effectiveReplacementDriverId, previous.proposerTeamId,
            playerTeamId = playerTeamId,
            notificationTitle = "CONTRAPROPOSTA ENVIADA"
        )
    }

    fun signFuture(state: DriverMarketState, offer: DriverOffer, season: Int, replaceDriverId: Int? = null): DriverMarketState {
        require(offer.status == NegotiationStatus.ACCEPTED) { "Somente uma proposta aceita pode gerar contrato futuro" }
        require(offer.seasonTarget == season + 1) { "A transferência deve começar na próxima temporada" }
        require(state.scheduled.none { it.driverId == offer.driverId }) { "Piloto já possui transferência futura" }
        val current = state.contracts.firstOrNull { it.driverId == offer.driverId }
        val future = FutureDriverDeal(offer.driverId, current?.teamId ?: 0, offer.toTeamId, offer.seasonTarget, offer.years, offer.salary, offer.role, season, offer.replaceDriverId ?: replaceDriverId)
        // A future signature settles the driver's choice for that target season.
        // Other offers for the same driver/season must not survive and race this deal.
        val cleanPending = state.pending.filterNot { it.driverId == offer.driverId && it.seasonTarget == offer.seasonTarget }
        return state.copy(pending=cleanPending, scheduled=state.scheduled + future,
            history=state.history + "${driverName(offer.driverId)} assinou com equipe ${offer.toTeamId} para ${offer.seasonTarget}")
    }

    /** Emits exactly one Home-compatible event for every successfully scheduled signature. */
    private fun recordCompletedSignature(
        state: DriverMarketState,
        deal: FutureDriverDeal,
        season: Int,
        currentWeek: Int,
        playerTeamId: Int? = null
    ): DriverMarketState {
        val driver = driverName(deal.driverId)
        val destination = teamName(deal.toTeamId)
        val sourceTeamId = deal.fromTeamId
        val title = when {
            sourceTeamId == deal.toTeamId -> "RENOVAÇÃO DE CONTRATO"
            sourceTeamId > 0 -> "TRANSFERÊNCIA CONFIRMADA"
            else -> "CONTRATO ASSINADO"
        }
        val alreadyRecorded = state.notifications.any { notice ->
            notice.title.trim().equals(title, ignoreCase = true) &&
                notice.message.contains(driver, ignoreCase = true) &&
                notice.message.contains(destination, ignoreCase = true) &&
                notice.message.contains(deal.startSeason.toString())
        }
        if (alreadyRecorded) return state
        val message = when (title) {
            "RENOVAÇÃO DE CONTRATO" -> "$driver renovou contrato com $destination para a temporada ${deal.startSeason}."
            "TRANSFERÊNCIA CONFIRMADA" -> "$driver mudou de ${teamName(sourceTeamId)} para $destination. Contrato assinado para a temporada ${deal.startSeason}."
            else -> "$driver assinou contrato com $destination para a temporada ${deal.startSeason}."
        }
        return state.copy(notifications = state.notifications + MarketNotification(
            season, currentWeek, title, message, true,
            relatedTeamId = playerTeamId?.takeIf { it == deal.fromTeamId || it == deal.toTeamId }
        ))
    }

    fun acceptCounterOffer(state: DriverMarketState, offer: DriverOffer, season: Int, currentWeek: Int, playerTeamId: Int? = null): DriverMarketState {
        require(offer.status == NegotiationStatus.COUNTER) { "A contraproposta não está ativa" }
        require(offer.seasonTarget == season + 1) { "A proposta pertence a outra temporada" }
        require(offer.round in 1..3) { "Rodada inválida" }
        require(state.pending.any { it.driverId == offer.driverId && it.toTeamId == offer.toTeamId && it.seasonTarget == offer.seasonTarget && it.round == offer.round && it.status == NegotiationStatus.COUNTER }) { "Contraproposta não encontrada" }
        val accepted = offer.copy(status = NegotiationStatus.ACCEPTED)
        val next = signFuture(state, accepted, season)
        val deal = next.scheduled.first { it.driverId == offer.driverId && it.startSeason == offer.seasonTarget }
        return recordCompletedSignature(next, deal, season, currentWeek, playerTeamId).normalized()
    }

    fun rejectCounterOffer(state: DriverMarketState, offer: DriverOffer, season: Int, currentWeek: Int, playerTeamId: Int? = null): DriverMarketState {
        require(offer.status == NegotiationStatus.COUNTER) { "A contraproposta não está ativa" }
        val next = state.copy(pending = state.pending.filterNot {
            it.driverId == offer.driverId && it.toTeamId == offer.toTeamId && it.seasonTarget == offer.seasonTarget && it.round == offer.round
        })
        return next.copy(
            notifications = next.notifications + MarketNotification(
                season, currentWeek, "NEGOCIAÇÃO ENCERRADA",
                "Você recusou a contraproposta de ${driverName(offer.driverId)} da equipe ${teamName(offer.toTeamId)}.", true,
                relatedTeamId = playerTeamId?.takeIf { it == offer.fromTeamId || it == offer.toTeamId || it == offer.proposerTeamId }
            )
        ).normalized()
    }

    fun acceptIncomingOffer(state: DriverMarketState, offer: DriverOffer, season: Int, currentWeek: Int, playerTeamId: Int? = null): DriverMarketState {
        require(offer.status == NegotiationStatus.PENDING) { "A proposta não está pendente" }
        require(offer.fromTeamId != offer.toTeamId) { "Proposta inválida" }
        require(offer.seasonTarget == season + 1) { "A proposta pertence a outra temporada" }
        require(currentWeek <= offer.expiresAfterWeek) { "O prazo desta proposta expirou" }
        require(state.pending.any { it.driverId == offer.driverId && it.toTeamId == offer.toTeamId && it.seasonTarget == offer.seasonTarget && it.status == NegotiationStatus.PENDING }) { "Proposta não encontrada" }
        val accepted = offer.copy(status = NegotiationStatus.ACCEPTED)
        val next = signFuture(state, accepted, season)
        val deal = next.scheduled.first { it.driverId == offer.driverId && it.startSeason == offer.seasonTarget }
        return recordCompletedSignature(next, deal, season, currentWeek, playerTeamId).normalized()
    }

    fun rejectIncomingOffer(state: DriverMarketState, offer: DriverOffer, season: Int, currentWeek: Int, playerTeamId: Int? = null): DriverMarketState {
        val clean = state.copy(pending = state.pending.filterNot { it.driverId == offer.driverId && it.toTeamId == offer.toTeamId && it.seasonTarget == offer.seasonTarget })
        return clean.copy(
            notifications = clean.notifications + MarketNotification(
                season, currentWeek, "PROPOSTA RECUSADA",
                "Você recusou a proposta da ${teamName(offer.toTeamId)} por ${driverName(offer.driverId)}, piloto da ${teamName(offer.fromTeamId)}.", true,
                relatedTeamId = playerTeamId?.takeIf { it == offer.fromTeamId || it == offer.toTeamId || it == offer.proposerTeamId })
        ).normalized()
    }

    fun renew(state: DriverMarketState, driverId: Int, teamId: Int, years: Int, salary: Long, season: Int, currentWeek: Int = 1): DriverMarketState =
        renew(state, driverId, teamId, years, salary, DriverTeamRole.EQUAL, season, currentWeek)

    fun renew(state: DriverMarketState, driverId: Int, teamId: Int, years: Int, salary: Long, role: DriverTeamRole, season: Int, currentWeek: Int = 1): DriverMarketState {
        require(marketOpen(currentWeek, season)) { "O mercado de pilotos abre somente após 8 corridas realizadas" }
        require(years in 1..5) { "O contrato deve ter entre 1 e 5 anos" }
        val current = state.contracts.firstOrNull { it.driverId == driverId && it.teamId == teamId && it.activeIn(season) }
            ?: error("Piloto não pertence à equipe nesta temporada")
        require(current.contractYear(season) == current.years) { "Renovação disponível apenas no último ano do contrato" }
        require(state.scheduled.none { it.driverId == driverId && it.startSeason == season + 1 }) { "Piloto já possui decisão para a próxima temporada" }
        require(roleCompatible(state, teamId, driverId, role, season, replacingDriverId = driverId)) { "Conflito de Piloto 1" }
        val future = FutureDriverDeal(
            driverId = driverId, fromTeamId = teamId, toTeamId = teamId, startSeason = season + 1,
            years = years, salary = salary.coerceAtLeast(100_000L), role = role, signedSeason = season,
            replaceDriverId = driverId
        )
        return state.copy(
            scheduled = state.scheduled.filterNot { it.driverId == driverId } + future,
            notifications = state.notifications + MarketNotification(
                season, currentWeek, "RENOVAÇÃO DE CONTRATO",
                "${driverName(driverId)} renovou com a ${teamName(teamId)} para ${season + 1} por $years ano(s).", true),
            history = state.history + "Renovação de ${driverName(driverId)} preparada para ${season + 1} por $years ano(s)"
        ).normalized()
    }

    /**
     * Rolls back future deals rejected by the caller's financial validation.
     * A success notice must never survive after its scheduled deal is removed:
     * otherwise the news feed says a driver renewed while the market still lists them as open.
     */
    fun cancelUnaffordableScheduledDeals(
        state: DriverMarketState,
        rejectedDeals: Collection<FutureDriverDeal>,
        season: Int,
        currentWeek: Int
    ): DriverMarketState {
        if (rejectedDeals.isEmpty()) return state
        val keys = rejectedDeals.map { "${it.driverId}:${it.toTeamId}:${it.startSeason}" }.toSet()
        val rejectedIds = rejectedDeals.map { it.driverId }.toSet()
        val rejectedNames = rejectedDeals.associate { deal ->
            deal.driverId to (driverName(deal.driverId) to teamName(deal.toTeamId))
        }
        val remainingScheduled = state.scheduled.filterNot { "${it.driverId}:${it.toTeamId}:${it.startSeason}" in keys }
        val remainingPending = state.pending.filterNot { offer ->
            rejectedDeals.any { deal -> offer.driverId == deal.driverId && offer.toTeamId == deal.toTeamId && offer.seasonTarget == deal.startSeason }
        }
        val notices = state.notifications.filterNot { notice ->
            if (notice.season != season) return@filterNot false
            rejectedNames.any { (id, names) ->
                val (driver, team) = names
                id in rejectedIds && notice.title in setOf("RENOVAÇÃO DE CONTRATO", "CONTRATO ASSINADO", "CONTRAPROPOSTA ACEITA", "TRANSFERÊNCIA CONFIRMADA") &&
                    notice.message.contains(driver, ignoreCase = true) && notice.message.contains(team, ignoreCase = true)
            }
        }
        val cancellations = rejectedDeals.map { deal ->
            val name = driverName(deal.driverId)
            val team = teamName(deal.toTeamId)
            val movement = if (deal.fromTeamId == deal.toTeamId) "renovação de $name com $team" else "contratação de $name pela equipe $team"
            MarketNotification(
                season, currentWeek, "NEGOCIAÇÃO ENCERRADA",
                "A $movement para ${deal.startSeason} não foi concluída por saldo insuficiente para a taxa de assinatura.",
                true
            )
        }
        return state.copy(
            scheduled = remainingScheduled,
            pending = remainingPending,
            notifications = (notices + cancellations).takeLast(1000),
            history = (state.history + rejectedDeals.map { deal ->
                "Renovação/contratação não concluída por saldo insuficiente: ${driverName(deal.driverId)}, ${teamName(deal.toTeamId)}, temporada ${deal.startSeason}"
            }).takeLast(300)
        ).normalized()
    }

    /**
     * Processes the AI driver market during the season. AI follows the same eligibility,
     * contract and role rules as the player, but may make imperfect decisions. No current
     * roster changes occur here: every accepted move is scheduled for the next season.
     */
    fun marketOpen(currentWeek: Int, season: Int = 2026): Boolean = SeasonCalendar.forSeason(season).count { it.weekOfSeason < currentWeek } >= 8

    /**
     * Signing fee is a percentage of the driver's market value (not salary).
     * Free agent: 20%; own renewal: 20%; signing from another team: 40%.
     */
    fun signatureFeeFor(state: DriverMarketState, driverId: Int, toTeamId: Int, season: Int): Long {
        val current = state.contracts.firstOrNull { it.driverId == driverId && it.activeIn(season) }
        val marketValue = current?.marketValue ?: state.contracts.firstOrNull { it.driverId == driverId }?.marketValue ?: marketValueFor(driverId)
        val rate = when {
            current == null -> 0.20 // free driver
            current.teamId == toTeamId -> 0.20 // own renewal
            else -> 0.40 // sign from another team
        }
        return (marketValue * rate).roundToLong()
    }

    fun signatureFeeForRenewal(state: DriverMarketState, driverId: Int, teamId: Int, season: Int): Long {
        val current = state.contracts.firstOrNull { it.driverId == driverId && it.teamId == teamId && it.activeIn(season) }
            ?: error("Piloto não pertence à equipe nesta temporada")
        return (current.marketValue * 0.20).roundToLong()
    }

    fun processAiMarketWeek(
        state: DriverMarketState, season: Int, currentWeek: Int, playerTeamId: Int,
        teamChampionshipPoints: Map<Int, Int> = emptyMap(),
        driverAttributes: Map<Int, List<Int>> = emptyMap(),
        driverChampionshipPoints: Map<Int, Int> = emptyMap(),
        nextSeasonCarStrength: Map<Int, Int> = emptyMap(),
        teamFacilitiesById: Map<Int, TeamFacilitiesState> = emptyMap()
    ): DriverMarketState {
        // Respostas de propostas pendentes são eventos de calendário independentes da
        // janela de abertura do mercado. Processá-las primeiro evita que uma proposta
        // fique sem resposta se a semana avançar para fora da janela de negociações.
        var s = expireOffers(state, currentWeek, season, playerTeamId,
            teamChampionshipPoints = teamChampionshipPoints, driverAttributes = driverAttributes,
            driverChampionshipPoints = driverChampionshipPoints, nextSeasonCarStrength = nextSeasonCarStrength)
        if (!marketOpen(currentWeek, season)) return s
        s = resolveAiCounters(s, season, currentWeek, playerTeamId, teamChampionshipPoints, driverAttributes, driverChampionshipPoints, nextSeasonCarStrength)
        val teams = WorldDatabase.teams.filter { it.id != playerTeamId }
        val rng = Random(seed + season * 997 + currentWeek * 31)
        // Resolve offers and counters every week above, but new AI approaches are
        // opened in periodic market windows. This avoids 40 teams shopping every
        // calendar tick while preserving a continuous negotiation response cycle.
        if (currentWeek % 6 == 0 || currentWeek >= 52) {
            teams.shuffled(Random(seed + season * 37 + currentWeek)).forEach { team ->
            val scoutingFacilities = teamFacilitiesById[team.id] ?: FacilityEngine.initial(team.initialLevel)
            val rosterNow = roster(s, team.id, season = season)
            val expiringCount = rosterNow.count { id ->
                s.contracts.firstOrNull { it.driverId == id }?.let { it.seasonSigned + it.years - 1 == season } == true
            }
            val weakestOverall = rosterNow.minOfOrNull { currentDriverOverall(it, driverAttributes) } ?: 0
            val currentTeamStrength = teamSportingStrength(team.id, teamChampionshipPoints)
            val activityChance = when {
                rosterNow.size < 2 -> 100
                expiringCount > 0 -> 62
                weakestOverall <= 62 -> 28
                weakestOverall <= 68 -> 19
                weakestOverall <= 74 -> 13
                currentTeamStrength >= 80 && weakestOverall < 84 -> 11
                currentTeamStrength <= 55 -> 9
                else -> 5
            }
            if (rng.nextInt(100) >= activityChance) return@forEach

            val candidates = aiApproachCandidates(
                s, team.id, season, playerTeamId, teamChampionshipPoints, driverAttributes, nextSeasonCarStrength
            )

            val reservedReplacementIds = (
                s.scheduled.filter { it.toTeamId == team.id && it.startSeason == season + 1 }.mapNotNull { it.replaceDriverId } +
                    s.pending.filter { it.toTeamId == team.id && it.seasonTarget == season + 1 && it.status in setOf(NegotiationStatus.PENDING, NegotiationStatus.COUNTER) }.mapNotNull { it.replaceDriverId }
                ).toSet()
            val expiringIds = rosterNow.filter { id ->
                id !in reservedReplacementIds &&
                    s.scheduled.none { it.driverId == id && it.startSeason == season + 1 } &&
                    s.contracts.firstOrNull { it.driverId == id && it.teamId == team.id }?.let { it.seasonSigned + it.years - 1 == season } == true
            }
            // Prefer an unreserved expiring seat. Only target a multi-year incumbent
            // when the prospect is a major upgrade and no renewal/transfer already
            // owns that seat in the future-contract ledger.
            val replacementCandidates = if (expiringIds.isNotEmpty()) expiringIds else rosterNow.filter { it !in reservedReplacementIds }
            val replacement = if (rosterNow.size >= 2) {
                replacementCandidates.minWithOrNull(compareBy<Int> { currentDriverOverall(it, driverAttributes) }
                    .thenBy { currentMarketValue(it, driverAttributes) })
            } else null
            val replacementIsExpiring = replacement != null && expiringIds.contains(replacement)
            // A full two-driver roster must identify a concrete seat to replace.
            // Do not create extra signings when both seats are already reserved.
            if (rosterNow.size >= 2 && replacement == null) return@forEach

            val candidate = candidates.shuffled(Random(seed + team.id * 71 + currentWeek)).maxByOrNull { id ->
                val preferredRole = preferredRoleFor(s, id, team.id, season)
                val salaryBenchmark = maxOf(currentSalaryValue(id, driverAttributes), s.contracts.firstOrNull { it.driverId == id && it.activeIn(season) }?.salary ?: 0L)
                val offeredSalary = (salaryBenchmark * (1.02 + rng.nextDouble() * 0.16)).roundToLong()
                val replacementOverall = replacement?.let { currentDriverOverall(it, driverAttributes) } ?: 0
                val observedCandidateOverall = aiScoutingEstimateForMarket(id, scoutingFacilities, driverAttributes)
                val improvement = observedCandidateOverall - replacementOverall
                val upgradeWeight = if (replacement == null) 0 else improvement * if (teamSportingStrength(team.id, teamChampionshipPoints) >= 78) 3 else 2
                val observedValueWeight = observedCandidateOverall * 35_000L
                interestScore(s, id, team.id, offeredSalary, preferredRole, season, teamChampionshipPoints, driverAttributes, driverChampionshipPoints, nextSeasonCarStrength) +
                    observedValueWeight + upgradeWeight
            } ?: return@forEach

            // Avoid meaningless churn: a complete team should normally move only
            // when the target is a clear sporting/economic upgrade. This is not a
            // transfer cap: an exceptional opportunity can still trigger a move.
            if (replacement != null) {
                val replacementDeal = s.contracts.firstOrNull { it.driverId == replacement }
                val candidateOverall = aiScoutingEstimateForMarket(candidate, scoutingFacilities, driverAttributes)
                val replacementOverall = currentDriverOverall(replacement, driverAttributes)
                val candidateValue = currentMarketValue(candidate, driverAttributes)
                val replacementValue = currentMarketValue(replacement, driverAttributes)
                val candidateBenchmark = maxOf(currentSalaryValue(candidate, driverAttributes), s.contracts.firstOrNull { it.driverId == candidate && it.activeIn(season) }?.salary ?: 0L)
                val candidateInterest = interestScore(s, candidate, team.id, (candidateBenchmark * 1.15).roundToLong(),
                    preferredRoleFor(s, candidate, team.id, season), season, teamChampionshipPoints, driverAttributes, driverChampionshipPoints, nextSeasonCarStrength)
                val replacementInterest = replacementDeal?.let {
                    interestScore(s, replacement, team.id, it.salary, it.role, season, teamChampionshipPoints, driverAttributes, driverChampionshipPoints, nextSeasonCarStrength)
                } ?: 50
                val sportingGain = candidateOverall - replacementOverall
                val economicPremium = candidateValue - replacementValue
                val strength = teamSportingStrength(team.id, teamChampionshipPoints)
                val requiredGain = when { strength >= 80 -> 4; strength >= 65 -> 2; else -> 0 }
                val clearUpgrade = sportingGain >= requiredGain && (sportingGain >= 3 || candidateInterest >= replacementInterest + 8)
                val evolution = WorldDatabase.allDrivers.firstOrNull { it.id == candidate }?.evolution?.lowercase().orEmpty()
                val highPotentialBet = sportingGain >= -2 && candidateInterest >= 76 && evolution in setOf("prodígio", "prodigio", "auge rápido", "auge rapido")
                val eliteUpgrade = candidateOverall >= replacementOverall + 8 && candidateInterest >= 70
                val multiYearBreakout = !replacementIsExpiring && (
                    candidateOverall >= replacementOverall + 12 ||
                    (candidateOverall >= replacementOverall + 9 && candidateInterest >= 84 && replacementOverall <= 68)
                )
                val fallbackNearWindowEnd = replacementIsExpiring && currentWeek >= 48 &&
                    candidateOverall >= replacementOverall - 2 && candidateInterest >= 52
                val eligibleMove = if (replacementIsExpiring) {
                    clearUpgrade || highPotentialBet || eliteUpgrade || fallbackNearWindowEnd
                } else {
                    multiYearBreakout && (clearUpgrade || eliteUpgrade) && (candidateInterest >= 70 || candidateOverall >= replacementOverall + 12)
                }
                if (!eligibleMove) return@forEach
                if (economicPremium < 0 && sportingGain < requiredGain + 2 && candidateInterest < 75) return@forEach
            }

            val role = preferredRoleFor(s, candidate, team.id, season)
            val salaryBenchmark = maxOf(currentSalaryValue(candidate, driverAttributes), s.contracts.firstOrNull { it.driverId == candidate && it.activeIn(season) }?.salary ?: 0L)
            val salary = (salaryBenchmark * (0.98 + rng.nextDouble() * 0.20)).roundToLong().coerceAtLeast(500_000L)
            val candidateDeal = s.contracts.firstOrNull { it.driverId == candidate && it.activeIn(season) }
            // When an AI team approaches a driver belonging to the player's team,
            // this is an incoming proposal. It must wait for the manager's decision.
            if (candidateDeal?.teamId == playerTeamId) {
                // Different teams may compete for the same driver, but one team cannot
                // stack duplicate live offers for that driver and target season.
                val alreadyOfferedByThisTeam = s.pending.any {
                    it.driverId == candidate && it.fromTeamId == playerTeamId &&
                        it.toTeamId == team.id && it.proposerTeamId == team.id &&
                        it.seasonTarget == season + 1 &&
                        it.status in setOf(NegotiationStatus.PENDING, NegotiationStatus.COUNTER)
                }
                if (alreadyOfferedByThisTeam || s.scheduled.any { it.driverId == candidate && it.startSeason == season + 1 }) return@forEach
                val responseDelay = if (rng.nextBoolean()) 2 else 3
                val incoming = DriverOffer(
                    candidate, playerTeamId, team.id, chooseAiYears(candidate, season, currentWeek, driverAttributes), salary, role,
                    currentMarketValue(candidate, driverAttributes), interestScore(s, candidate, team.id, salary, role, season, teamChampionshipPoints, driverAttributes, driverChampionshipPoints, nextSeasonCarStrength),
                    1, currentWeek + responseDelay, NegotiationStatus.PENDING, season + 1, replacement, team.id
                )
                s = s.copy(
                    pending = (s.pending + incoming).takeLast(100),
                    notifications = s.notifications + MarketNotification(
                        season, currentWeek, "PROPOSTA RECEBIDA",
                        "A ${teamName(team.id)} fez uma proposta por ${driverName(candidate)} para ${season + 1}.", true,
                        relatedTeamId = playerTeamId)
                )
                return@forEach
            }
            runCatching {
                val (next, _) = makeOffer(
                    s, candidate, team.id, chooseAiYears(candidate, season, currentWeek, driverAttributes),
                    salary, role, season, currentWeek, 1, replacement, team.id,
                    teamChampionshipPoints, driverAttributes, driverChampionshipPoints, nextSeasonCarStrength,
                    allowMidContractTransfer = true
                )
                s = next
            }.onFailure { /* one failed AI negotiation never breaks the market tick */ }
            }
        }
        // Renewal/transfer mix is deliberately not used as a quota. Decisions are local
        // to each team: renewal fit, roster weakness, market availability and sporting gain.
        // First, allow teams to renew drivers they already trust. Renewal is not a
        // transfer and therefore can happen during the current season.
        teams.shuffled(Random(seed + season * 43 + currentWeek)).forEach { team ->
            val scoutingFacilities = teamFacilitiesById[team.id] ?: FacilityEngine.initial(team.initialLevel)
            val expiring = roster(s, team.id, season = season)
                .mapNotNull { id -> s.contracts.firstOrNull { it.driverId == id && it.teamId == team.id } }
                .filter { it.seasonSigned + it.years - 1 == season }
            expiring.forEach dealLoop@ { deal ->
                if (s.scheduled.any { it.driverId == deal.driverId && it.startSeason == season + 1 }) return@dealLoop
                // First let rival teams make approaches. A renewal is evaluated once,
                // late enough for the market to develop but early enough to close a deal.
                if (currentWeek < 40) return@dealLoop
                val competingOfferPending = s.pending.any {
                    it.driverId == deal.driverId && it.toTeamId != team.id &&
                        it.seasonTarget == season + 1 &&
                        it.status in setOf(NegotiationStatus.PENDING, NegotiationStatus.COUNTER)
                }
                if (competingOfferPending) return@dealLoop
                if (renewalWasEvaluatedThisSeason(s, season, team.id, deal.driverId)) return@dealLoop
                val evaluationKey = renewalEvaluationKey(season, team.id, deal.driverId)
                s = s.copy(renewalEvaluations = (s.renewalEvaluations + evaluationKey).toList().takeLast(600).toSet())

                val role = deal.role
                val fit = interestScore(s, deal.driverId, team.id, deal.salary, role, season, teamChampionshipPoints, driverAttributes, driverChampionshipPoints, nextSeasonCarStrength)
                val possibleUpgrades = aiApproachCandidates(
                    s, team.id, season, playerTeamId, teamChampionshipPoints, driverAttributes, nextSeasonCarStrength
                )
                val incumbentOverall = currentDriverOverall(deal.driverId, driverAttributes)
                var credibleUpgrade = false
                for (candidateId in possibleUpgrades) {
                    val candidateCanBeApproached = canReceiveProposals(s, candidateId, season) ||
                        canAiApproachMidContract(
                            s, candidateId, team.id, season, playerTeamId, teamChampionshipPoints,
                            driverAttributes, nextSeasonCarStrength
                        )
                    if (candidateId == deal.driverId || !candidateCanBeApproached) continue
                    val candidateOverall = aiScoutingEstimateForMarket(candidateId, scoutingFacilities, driverAttributes)
                    if (candidateOverall < incumbentOverall + 8) continue
                    val candidateSalary = (maxOf(currentSalaryValue(candidateId, driverAttributes), s.contracts.firstOrNull { it.driverId == candidateId && it.activeIn(season) }?.salary ?: 0L) * 1.15).roundToLong()
                    val candidateInterest = interestScore(s, candidateId, team.id, candidateSalary, preferredRoleFor(s, candidateId, team.id, season), season, teamChampionshipPoints, driverAttributes, driverChampionshipPoints, nextSeasonCarStrength)
                    if (candidateInterest >= 70 && candidateInterest >= fit - 4) {
                        credibleUpgrade = true
                        break
                    }
                }
                val baseChance = when {
                    fit >= 82 -> 46
                    fit >= 72 -> 34
                    fit >= 60 -> 19
                    else -> 7
                }
                // The late negotiation window modestly favours continuity, but this
                // is a single seasonal decision rather than repeated cumulative rolls.
                val deadlineBonus = when {
                    currentWeek >= 52 -> 20
                    currentWeek >= 48 -> 12
                    else -> 0
                }
                val chance = (baseChance + deadlineBonus).coerceAtMost(88)
                // If a clearly better, interested driver is available, do not renew the
                // incumbent. The team must pursue the upgrade instead of locking in a weak
                // driver and leaving the stronger candidate on the open market.
                val effectiveChance = if (credibleUpgrade) 0 else chance
                val renewalAlreadyPending = s.pending.any {
                    it.driverId == deal.driverId && it.toTeamId == team.id &&
                        it.seasonTarget == season + 1 && it.status in setOf(NegotiationStatus.PENDING, NegotiationStatus.COUNTER)
                }
                if (!renewalAlreadyPending && rng.nextInt(100) < effectiveChance) {
                    val years = chooseAiYears(deal.driverId, season, currentWeek, driverAttributes)
                    val salary = (deal.salary * (1.03 + rng.nextDouble() * 0.12)).roundToLong()
                    // Renewals use the same 2–3 week negotiation window as transfers.
                    // Keep the driver's incumbent-team offer pending so other teams can compete.
                    runCatching {
                        val (next, _) = makeOffer(
                            s, deal.driverId, team.id, years, salary, role, season,
                            currentWeek, 1, deal.driverId, team.id,
                            teamChampionshipPoints, driverAttributes, driverChampionshipPoints, nextSeasonCarStrength
                        )
                        s = next
                    }
                }
            }
        }

        if (currentWeek >= 52) {
            // Resolve offers created in this very tick when the response deadline is
            // immediate (week 56), then close AI seats through the same offer/signature
            // ledger used by ordinary negotiations. The player roster is never touched.
            s = expireOffers(s, currentWeek, season, playerTeamId,
                    teamChampionshipPoints = teamChampionshipPoints, driverAttributes = driverAttributes,
                    driverChampionshipPoints = driverChampionshipPoints, nextSeasonCarStrength = nextSeasonCarStrength)
            s = closeAiRosterGaps(
                s, season, currentWeek, playerTeamId,
                teamChampionshipPoints, driverAttributes, driverChampionshipPoints, nextSeasonCarStrength
            )
        }
        return s.normalized()
    }

    // There is intentionally no global renewal/transfer quota. Each AI team compares
    // the sporting and financial value of its own roster moves independently.

    private fun preferredRoleFor(state: DriverMarketState, driverId: Int, teamId: Int, season: Int): DriverTeamRole {
        return when (state.rolePreferences[driverId]) {
            DriverRolePreference.DEMANDS_PILOT_1, DriverRolePreference.PREFERS_PILOT_1 -> DriverTeamRole.PILOT_1
            DriverRolePreference.PREFERS_EQUALITY -> DriverTeamRole.EQUAL
            DriverRolePreference.INDIFFERENT, null -> {
                if (roster(state, teamId, season = season).isEmpty()) DriverTeamRole.PILOT_1 else DriverTeamRole.PILOT_2
            }
        }
    }

    private fun renewalEvaluationKey(season: Int, teamId: Int, driverId: Int): String =
        "$season:$teamId:$driverId:FINAL"

    /**
     * A small, selective part of the AI market may approach a driver before the
     * current contract expires. This models negotiated releases/buy-outs without
     * making every multi-year contract permanently open to rival teams.
     *
     * The opportunity must be sporting: the destination's projected next car must
     * be materially stronger, and only a deterministic minority of drivers is
     * considered mobile in a given season. The driver's own interest score still
     * decides whether the approach can become a signature.
     */
    private fun canAiApproachMidContract(
        state: DriverMarketState,
        driverId: Int,
        destinationTeamId: Int,
        season: Int,
        playerTeamId: Int,
        teamChampionshipPoints: Map<Int, Int>,
        driverAttributes: Map<Int, List<Int>>,
        nextSeasonCarStrength: Map<Int, Int>
    ): Boolean {
        if (state.scheduled.any { it.driverId == driverId && it.startSeason == season + 1 }) return false
        val current = state.contracts.firstOrNull { it.driverId == driverId } ?: return false
        if (current.teamId == destinationTeamId || current.teamId == playerTeamId || !current.activeIn(season)) return false
        if (current.contractYear(season) >= current.years) return false
        val currentStrength = nextSeasonCarStrength[current.teamId]?.coerceIn(0, 100)
            ?: teamSportingStrength(current.teamId, teamChampionshipPoints)
        val destinationStrength = nextSeasonCarStrength[destinationTeamId]?.coerceIn(0, 100)
            ?: teamSportingStrength(destinationTeamId, teamChampionshipPoints)
        val strengthGain = destinationStrength - currentStrength
        val overall = currentDriverOverall(driverId, driverAttributes)
        val mobilityRoll = Math.floorMod(seed + season * 31 + driverId * 17 + destinationTeamId * 13, 100)
        return when {
            strengthGain >= 16 && overall >= 76 -> mobilityRoll < 24
            strengthGain >= 11 && overall >= 84 -> mobilityRoll < 15
            currentStrength <= 50 && destinationStrength >= 72 && overall >= 78 -> mobilityRoll < 12
            else -> false
        }
    }

    private fun renewalWasEvaluatedThisSeason(state: DriverMarketState, season: Int, teamId: Int, driverId: Int): Boolean {
        val prefix = "$season:$teamId:$driverId:"
        return state.renewalEvaluations.any { it == "$season:$teamId:$driverId" || it.startsWith(prefix) }
    }

    /**
     * Final AI contract window. It prepares missing seats for the coming season
     * using ordinary proposals, driver acceptance/counteroffers and scheduled deals.
     * It never directly assigns a driver and never processes the player's team.
     */
    private fun closeAiRosterGaps(
        input: DriverMarketState,
        season: Int,
        currentWeek: Int,
        playerTeamId: Int,
        teamChampionshipPoints: Map<Int, Int>,
        driverAttributes: Map<Int, List<Int>>,
        driverChampionshipPoints: Map<Int, Int>,
        nextSeasonCarStrength: Map<Int, Int> = emptyMap()
    ): DriverMarketState {
        val targetSeason = season + 1
        var s = input

        // Resolve legacy late-season pending AI offers as a final calendar action.
        // Offers involving the player's contracted drivers remain manual decisions.
        if (currentWeek >= 56) {
            val legacyLateOffers = s.pending.filter {
                it.seasonTarget == targetSeason && it.status == NegotiationStatus.PENDING &&
                    it.toTeamId != playerTeamId && it.proposerTeamId == it.toTeamId &&
                    it.fromTeamId != playerTeamId
            }
            if (legacyLateOffers.isNotEmpty()) {
                val keys = legacyLateOffers.map { Triple(it.driverId, it.toTeamId, it.seasonTarget) }.toSet()
                s = s.copy(pending = s.pending.map { offer ->
                    if (Triple(offer.driverId, offer.toTeamId, offer.seasonTarget) in keys) offer.copy(expiresAfterWeek = currentWeek) else offer
                }).normalized()
                s = expireOffers(s, currentWeek, season, playerTeamId,
                    teamChampionshipPoints = teamChampionshipPoints, driverAttributes = driverAttributes,
                    driverChampionshipPoints = driverChampionshipPoints, nextSeasonCarStrength = nextSeasonCarStrength)
            }
            // AI teams may accept a financially reasonable counter in the closing
            // window; an excessive demand is explicitly declined instead of lingering.
            val finalCounters = s.pending.filter {
                it.seasonTarget == targetSeason && it.status == NegotiationStatus.COUNTER &&
                    it.toTeamId != playerTeamId && it.proposerTeamId == it.toTeamId && it.fromTeamId != playerTeamId
            }
            finalCounters.forEach { counter ->
                if (s.scheduled.any { it.driverId == counter.driverId && it.startSeason == targetSeason }) return@forEach
                val reference = maxOf(
                    currentSalaryValue(counter.driverId, driverAttributes),
                    s.contracts.firstOrNull { it.driverId == counter.driverId && it.activeIn(season) }?.salary ?: 0L
                ).coerceAtLeast(1L)
                if (counter.salary <= (reference * 4.75).roundToLong()) {
                    val accepted = runCatching { signFuture(s.copy(pending = s.pending.filterNot { sameNegotiation(it, counter) }), counter.copy(status = NegotiationStatus.ACCEPTED), season) }
                    if (accepted.isSuccess) {
                        val next = accepted.getOrThrow()
                        val deal = next.scheduled.first { it.driverId == counter.driverId && it.startSeason == targetSeason }
                        s = recordCompletedSignature(next, deal, season, currentWeek).normalized()
                    } else {
                        s = s.copy(pending = s.pending.filterNot { sameNegotiation(it, counter) }).normalized()
                    }
                } else {
                    s = s.copy(
                        pending = s.pending.filterNot { sameNegotiation(it, counter) },
                        notifications = s.notifications + MarketNotification(
                            season, currentWeek, "CONTRAPROPOSTA RECUSADA NO FECHAMENTO",
                            "A ${teamName(counter.toTeamId)} não conseguiu atender às condições finais de ${driverName(counter.driverId)} antes da virada.", true
                        )
                    ).normalized()
                }
            }
        }

        for (team in WorldDatabase.teams.filter { it.id != playerTeamId }) {
            var attempts = 0
            while (projectedRosterForSeason(s, team.id, targetSeason).size < 2 && attempts < 2) {
                // One live negotiation per destination/target seat avoids duplicate
                // offers while a driver is still considering the current proposal.
                val unresolved = s.pending.any {
                    it.toTeamId == team.id && it.seasonTarget == targetSeason &&
                        it.status in setOf(NegotiationStatus.PENDING, NegotiationStatus.COUNTER)
                }
                if (unresolved) break

                val currentRoster = roster(s, team.id, season = season)
                val alreadyReplacing = (
                    s.scheduled.filter { it.toTeamId == team.id && it.startSeason == targetSeason }.mapNotNull { it.replaceDriverId } +
                        s.pending.filter { it.toTeamId == team.id && it.seasonTarget == targetSeason && it.status in setOf(NegotiationStatus.PENDING, NegotiationStatus.COUNTER) }.mapNotNull { it.replaceDriverId }
                    ).toSet()
                val scheduledLeaving = s.scheduled.filter {
                    it.fromTeamId == team.id && it.toTeamId != team.id && it.startSeason == targetSeason
                }.map { it.driverId }.toSet()
                val replaceable = s.contracts.filter { deal ->
                    deal.teamId == team.id && deal.activeIn(season) && deal.driverId !in alreadyReplacing &&
                        ( !deal.activeIn(targetSeason) || deal.driverId in scheduledLeaving )
                }.map { it.driverId }
                val replacementSeat = if (currentRoster.size >= 2) replaceable.firstOrNull() else null
                if (currentRoster.size >= 2 && replacementSeat == null) break

                val candidates = (
                    freeAgents(s) + s.contracts.filter { deal ->
                        deal.teamId != playerTeamId && deal.driverId != playerTeamId &&
                            canReceiveProposals(s, deal.driverId, season)
                    }.map { it.driverId }
                ).distinct().filter { candidate ->
                    candidate !in s.scheduled.map { it.driverId } &&
                        s.contracts.firstOrNull { it.driverId == candidate }?.teamId != playerTeamId
                }.sortedWith(compareByDescending<Int> { candidate ->
                    val reference = maxOf(
                        currentSalaryValue(candidate, driverAttributes),
                        s.contracts.firstOrNull { it.driverId == candidate && it.activeIn(season) }?.salary ?: 0L
                    )
                    val role = preferredRoleFor(s, candidate, team.id, season)
                    interestScore(s, candidate, team.id, (reference * 2.0).roundToLong(), role, season,
                        teamChampionshipPoints, driverAttributes, driverChampionshipPoints, nextSeasonCarStrength) * 100 +
                        currentDriverOverall(candidate, driverAttributes)
                })

                var completed = false
                candidateLoop@ for (candidate in candidates) {
                    val candidateDeal = s.contracts.firstOrNull { it.driverId == candidate }
                    val replacementId = if (candidateDeal?.teamId == team.id) candidate else replacementSeat
                    val role = preferredRoleFor(s, candidate, team.id, season)
                    val salaryReference = maxOf(
                        currentSalaryValue(candidate, driverAttributes), candidateDeal?.salary ?: 0L
                    ).coerceAtLeast(500_000L)
                    val multipliers = listOf(1.15, 1.50, 2.00, 2.75, 3.50, 4.25)
                    for (multiplier in multipliers) {
                        val proposed = runCatching {
                            makeOffer(
                                s, candidate, team.id, chooseAiYears(candidate, season, currentWeek, driverAttributes),
                                (salaryReference * multiplier).roundToLong(), role, season,
                                currentWeek = currentWeek, round = 1, replaceDriverId = replacementId,
                                proposerTeamId = team.id, teamChampionshipPoints = teamChampionshipPoints,
                                driverAttributes = driverAttributes, driverChampionshipPoints = driverChampionshipPoints,
                                nextSeasonCarStrength = nextSeasonCarStrength
                            )
                        }.getOrNull() ?: continue
                        s = proposed.first
                        if (currentWeek >= 56) {
                            // Week 56 is the last pre-season decision point. Resolve a
                            // same-week offer immediately so it cannot be discarded as stale.
                            s = expireOffers(s, currentWeek, season, playerTeamId,
                                onlyDriverId = candidate, onlyTeamId = team.id,
                                teamChampionshipPoints = teamChampionshipPoints, driverAttributes = driverAttributes,
                                driverChampionshipPoints = driverChampionshipPoints, nextSeasonCarStrength = nextSeasonCarStrength)
                        }
                        val signed = s.scheduled.any {
                            it.driverId == candidate && it.toTeamId == team.id && it.startSeason == targetSeason
                        }
                        if (signed) {
                            val deal = s.scheduled.first { it.driverId == candidate && it.toTeamId == team.id && it.startSeason == targetSeason }
                            s = recordCompletedSignature(s, deal, season, currentWeek).normalized()
                            completed = true
                            break@candidateLoop
                        }
                        // A counteroffer may be resolved by the final closeout, but a
                        // rejected or unaffordable response must not block the next candidate.
                        val counter = s.pending.firstOrNull {
                            it.driverId == candidate && it.toTeamId == team.id && it.seasonTarget == targetSeason &&
                                it.status == NegotiationStatus.COUNTER
                        }
                        if (counter != null && currentWeek >= 56) {
                            val ceiling = (salaryReference * 4.75).roundToLong()
                            if (counter.salary <= ceiling) {
                                val accepted = runCatching {
                                    signFuture(s.copy(pending = s.pending.filterNot { sameNegotiation(it, counter) }),
                                        counter.copy(status = NegotiationStatus.ACCEPTED), season)
                                }
                                if (accepted.isSuccess) {
                                    s = accepted.getOrThrow().normalized()
                                    completed = true
                                    break@candidateLoop
                                }
                            }
                            s = s.copy(pending = s.pending.filterNot { sameNegotiation(it, counter) }).normalized()
                        }
                        if (currentWeek < 56) break@candidateLoop
                        s = s.copy(pending = s.pending.filterNot {
                            it.driverId == candidate && it.toTeamId == team.id && it.seasonTarget == targetSeason
                        }).normalized()
                    }
                    if (completed) break
                    attempts++
                }
                if (!completed) break
            }
            if (currentWeek >= 56 && projectedRosterForSeason(s, team.id, targetSeason).size < 2) {
                val missing = 2 - projectedRosterForSeason(s, team.id, targetSeason).size
                val reason = "${team.name} ainda tem $missing vaga(s) sem contrato confirmado para ${targetSeason}; nenhuma contratação foi atribuída sem aceitação do piloto."
                if (s.notifications.none { it.season == season && it.week == currentWeek && it.title == "VAGA DE PILOTO EM ABERTO" && it.message == reason }) {
                    s = s.copy(
                        notifications = s.notifications + MarketNotification(season, currentWeek, "VAGA DE PILOTO EM ABERTO", reason, true),
                        history = s.history + reason
                    ).normalized()
                }
            }
        }
        return s.normalized()
    }

    /** AI contract planning values sustainable potential before current rating, then age. */
    internal fun chooseAiYears(driverId: Int, season: Int, week: Int, attributes: Map<Int, List<Int>> = emptyMap()): Int {
        val driver = WorldDatabase.allDrivers.firstOrNull { it.id == driverId }
        val age = driver?.let { com.f1teammanager.core.season.DriverEvolutionEngine.careerAge(it, season) } ?: 27
        val ratings = attributes[driverId]?.takeIf { it.size == 7 }?.toIntArray() ?: driver?.let {
            intArrayOf(it.speed,it.qualifying,it.overtaking,it.defense,it.consistency,it.wet,it.tyre)
        }
        val overall = ratings?.let { DriverProfileCatalog.overall(it) } ?: 60
        val potential = driver?.potentialOverall ?: overall
        val roll = Math.floorMod(seed + driverId * 17 + season * 13 + week * 7, 100)
        return when {
            // Elite prospects retain long-term investment value even before their
            // current Overall catches up with their potential.
            age <= 22 && potential >= 88 -> if (roll < 55) 5 else if (roll < 88) 4 else 3
            age <= 25 && potential >= 90 -> if (roll < 42) 5 else if (roll < 88) 4 else 3
            age <= 25 && potential >= 82 -> if (roll < 35) 5 else if (roll < 78) 4 else 3
            age <= 29 && potential >= 90 -> if (roll < 28) 5 else if (roll < 78) 4 else 3
            age <= 29 && potential >= 85 -> if (roll < 18) 4 else if (roll < 72) 3 else 2
            age <= 29 && overall >= 82 -> if (roll < 18) 5 else if (roll < 58) 4 else if (roll < 88) 3 else 2
            age <= 32 && potential >= 88 -> if (roll < 16) 4 else if (roll < 72) 3 else 2
            age <= 32 && overall >= 78 -> if (roll < 12) 4 else if (roll < 55) 3 else if (roll < 88) 2 else 1
            age <= 35 && potential >= 82 && overall >= 70 -> if (roll < 22) 3 else if (roll < 82) 2 else 1
            age <= 35 -> if (roll < 12) 3 else if (roll < 55) 2 else 1
            else -> if (roll < 20) 2 else 1
        }.coerceIn(1, 5)
    }

    fun runAiOffseason(
        state: DriverMarketState, season: Int, teamBudget: Map<Int, Long>, playerTeamId: Int? = null,
        teamChampionshipPoints: Map<Int, Int> = emptyMap(), driverAttributes: Map<Int, List<Int>> = emptyMap(),
        driverChampionshipPoints: Map<Int, Int> = emptyMap()
    ): DriverMarketState = applySeasonTransition(state, season, teamBudget, playerTeamId, teamChampionshipPoints, driverAttributes, driverChampionshipPoints)

    fun applySeasonTransition(
        state: DriverMarketState, newSeason: Int, teamBudgets: Map<Int,Long> = emptyMap(), playerTeamId: Int? = null,
        teamChampionshipPoints: Map<Int, Int> = emptyMap(), driverAttributes: Map<Int, List<Int>> = emptyMap(),
        driverChampionshipPoints: Map<Int, Int> = emptyMap(),
        automaticVacancyFillTeamIds: Set<Int> = emptySet()
    ): DriverMarketState {
        var s = state
        // Only a contract signed by the driver can move a pilot at the season boundary.
        // An unrelated incumbent is never removed merely to make an incoming deal fit.
        val due = s.scheduled.filter { it.startSeason <= newSeason }
        due.forEach { move ->
            if (s.scheduled.none { it.driverId == move.driverId && it.startSeason == move.startSeason && it.toTeamId == move.toTeamId }) return@forEach
            val currentContract = s.contracts.firstOrNull { it.driverId == move.driverId }
            val destinationRoster = s.contracts.filter { it.teamId == move.toTeamId && it.activeIn(newSeason) }
            val replacement = move.replaceDriverId?.let { id ->
                s.contracts.firstOrNull { it.driverId == id && it.teamId == move.toTeamId && it.activeIn(newSeason) }
            }
            val destinationHasRoom = destinationRoster.size < 2 || replacement != null
            if (!destinationHasRoom) {
                val reason = "Transferência de ${driverName(move.driverId)} para ${teamName(move.toTeamId)} cancelada: as duas vagas futuras estão ocupadas e não existe substituição válida."
                s = s.copy(
                    scheduled = s.scheduled.filterNot { it.driverId == move.driverId },
                    pending = s.pending.filterNot { it.driverId == move.driverId && it.seasonTarget == newSeason },
                    freeAgents = if (currentContract == null || !currentContract.activeIn(newSeason)) (s.freeAgents + move.driverId).distinct() else s.freeAgents,
                    notifications = s.notifications + MarketNotification(newSeason, 1, "TRANSFERÊNCIA CANCELADA", reason, true, relatedTeamId = playerTeamId?.takeIf { it == move.fromTeamId || it == move.toTeamId }),
                    history = s.history + reason
                )
                return@forEach
            }
            val releasedIds = buildSet {
                add(move.driverId)
                replacement?.let { add(it.driverId) }
            }
            val oldTeam = currentContract?.teamId
            val deal = DriverDeal(move.driverId, move.toTeamId, move.years, move.salary, currentMarketValue(move.driverId, driverAttributes), newSeason, move.role)
            val withSignatureEvent = recordCompletedSignature(s, move, newSeason, 1, playerTeamId)
            s = withSignatureEvent.copy(
                contracts = withSignatureEvent.contracts.filterNot { it.driverId in releasedIds } + deal,
                scheduled = withSignatureEvent.scheduled.filterNot { it.driverId == move.driverId },
                freeAgents = (withSignatureEvent.freeAgents - move.driverId + listOfNotNull(replacement?.driverId).filter { it != move.driverId }).distinct(),
                pending = withSignatureEvent.pending.filterNot { it.driverId == move.driverId && it.seasonTarget == newSeason },
                history = withSignatureEvent.history + "Contrato de ${driverName(move.driverId)} aplicado para ${teamName(move.toTeamId)}${oldTeam?.let { " (origem ${teamName(it)})" } ?: ""}"
            ).normalized()
        }
        s = cancelOrphanedAiDevelopmentPrograms(s, newSeason, playerTeamId)
        s = resolveExpiredAndVacancies(
            s, newSeason, teamBudgets, playerTeamId, teamChampionshipPoints, driverAttributes, driverChampionshipPoints,
            automaticVacancyFillTeamIds
        )
        s = s.copy(pending = s.pending.filter { it.seasonTarget > newSeason }).normalized()
        return s.normalized()
    }

    fun scout(
        state: DriverMarketState,
        driverId: Int,
        teamId: Int,
        currentWeek: Int,
        season: Int = 2026,
        scoutingFacilityLevel: Int = 0
    ): Pair<DriverMarketState, ScoutingReport> {
        require(driverId in allIds) { "Piloto inexistente" }
        val value=marketValueFor(driverId)
        val d = WorldDatabase.allDrivers.first { it.id == driverId }
        val attrs = listOf(d.speed,d.qualifying,d.overtaking,d.defense,d.consistency,d.wet,d.tyre)
        // Scouting facility now affects the precision of the persisted report.
        val precision = FacilityEngine.scoutingPrecision(
            TeamFacilitiesState().withLevel(FacilityType.SCOUTING, scoutingFacilityLevel)
        )
        val margin = ((100 - precision) / 8).coerceIn(0,10)
        val ranges = attrs.joinToString("|") { v -> if (margin == 0) "$v-$v" else "${(v-margin).coerceAtLeast(40)}-${(v+margin).coerceAtMost(100)}" }
        val report=ScoutingReport(driverId,teamId,500_000L,currentWeek,56,salaryFor(driverId),value,state.rolePreferences[driverId] ?: DriverRolePreference.INDIFFERENT,interestScore(state,driverId,teamId,salaryFor(driverId),DriverTeamRole.EQUAL,season),season,ranges)
        return state.copy(scouting=(state.scouting.filterNot { it.driverId==driverId && it.teamId==teamId && it.season==season }+report).takeLast(200),history=state.history+"Scouting concluído: ${driverName(driverId)}") to report
    }


    /** Cancels only programmes whose driver no longer belongs to that AI team. */
    private fun cancelOrphanedAiDevelopmentPrograms(
        state: DriverMarketState, season: Int, playerTeamId: Int?
    ): DriverMarketState {
        if (state.aiDriverDevelopment.isEmpty()) return state
        val activeOwners = state.contracts.filter { it.activeIn(season) }.associate { it.driverId to it.teamId }
        val queues = state.aiDriverDevelopment.toMutableMap()
        val notices = mutableListOf<MarketNotification>()
        queues.toMap().forEach { (teamId, queue) ->
            val orphaned = queue.programs.filter { activeOwners[it.driverId] != teamId }
            if (orphaned.isEmpty()) return@forEach
            queues[teamId] = queue.copy(programs = queue.programs.filter { activeOwners[it.driverId] == teamId }).normalized()
            orphaned.forEach { program ->
                val driverName = WorldDatabase.allDrivers.firstOrNull { it.id == program.driverId }?.name ?: "Piloto ${program.driverId}"
                val newOwner = activeOwners[program.driverId]
                val destination = newOwner?.let(::teamName) ?: "mercado de pilotos"
                val message = "O programa de desenvolvimento de $driverName na ${teamName(teamId)} foi cancelado na virada da temporada $season porque o piloto passou para $destination. A vaga foi liberada imediatamente."
                notices += MarketNotification(
                    season, 1, "PROGRAMA DE DESENVOLVIMENTO CANCELADO", message, true,
                    MarketNewsCategory.DRIVER_EVOLUTION,
                    relatedTeamId = playerTeamId?.takeIf { it == teamId || it == newOwner }
                )
            }
        }
        return state.copy(
            aiDriverDevelopment = queues,
            notifications = (state.notifications + notices).takeLast(1000),
            history = (state.history + notices.map { it.message }).takeLast(300)
        ).normalized()
    }

    fun marketSummary(state: DriverMarketState, season: Int): String = "Mercado ${if (marketOpen(SeasonCalendar.forSeason(season).maxOfOrNull { it.weekOfSeason } ?: 56, season)) "aberto" else "fechado"} | Contratados: ${state.contracts.count { it.activeIn(season) }} | Livres: ${freeAgents(state).size} | Propostas: ${state.pending.count { it.seasonTarget == season + 1 }} | Transferências: ${state.scheduled.count { it.startSeason == season + 1 }}"

    private fun resolveExpiredAndVacancies(
        input: DriverMarketState,
        season: Int,
        budgets: Map<Int, Long>,
        playerTeamId: Int? = null,
        teamChampionshipPoints: Map<Int, Int> = emptyMap(),
        driverAttributes: Map<Int, List<Int>> = emptyMap(),
        driverChampionshipPoints: Map<Int, Int> = emptyMap(),
        automaticVacancyFillTeamIds: Set<Int> = emptySet()
    ): DriverMarketState {
        var s = input
        val remainingBudgets = WorldDatabase.teams.associate { team ->
            team.id to (budgets[team.id] ?: InitialTeamProfile.initialBudget(team).coerceAtLeast(0L))
        }.toMutableMap()

        // Let expired contracts become free agents first; never keep a stale roster seat.
        s.contracts.filter { !it.activeIn(season) }.forEach { deal ->
            s = s.copy(
                contracts = s.contracts.filterNot { it.driverId == deal.driverId },
                freeAgents = (s.freeAgents + deal.driverId).distinct(),
                history = s.history + "Contrato de ${driverName(deal.driverId)} encerrado ao fim da temporada ${season - 1}"
            ).normalized()
        }

        // The player controls their own roster. The game must not secretly assign a driver
        // to the player's team; the season-change UI blocks the boundary until vacancies
        // are resolved by a contract the player actually accepted.
        for (team in WorldDatabase.teams.filter { it.id != playerTeamId || it.id in automaticVacancyFillTeamIds }) {
            val attempted = mutableSetOf<Int>()
            var attempts = 0
            while (s.rosterCount(team.id, season) < 2 && attempts < WorldDatabase.allDrivers.size) {
                attempts++
                val budget = remainingBudgets[team.id] ?: 0L
                val candidates = freeAgents(s).filter { it !in attempted && s.scheduled.none { scheduled -> scheduled.driverId == it } }
                    .sortedWith(compareByDescending<Int> { id ->
                        interestScore(s, id, team.id, currentSalaryValue(id, driverAttributes), preferredRoleFor(s, id, team.id, season), season, teamChampionshipPoints, driverAttributes, driverChampionshipPoints)
                    }.thenByDescending { id -> currentDriverOverall(id, driverAttributes) })
                if (candidates.isEmpty()) break

                var signedDeal: FutureDriverDeal? = null
                var selectedDriver: Int? = null
                var consumedFee = 0L
                candidateLoop@ for (candidate in candidates) {
                    attempted += candidate
                    val fee = (currentMarketValue(candidate, driverAttributes) * 0.20).roundToLong()
                    if (fee > budget) continue
                    val responseSeason = season - 1
                    val role = if (s.rosterCount(team.id, season) == 0) DriverTeamRole.PILOT_1 else DriverTeamRole.PILOT_2
                    val salaryReference = maxOf(currentSalaryValue(candidate, driverAttributes), s.contracts.firstOrNull { it.driverId == candidate }?.salary ?: 0L)
                    // Escalate through explicit offers: a difficult market can cost dearly,
                    // but only a driver acceptance (or a counter accepted by the team) signs.
                    val salaryMultipliers = listOf(1.05, 1.25, 1.55, 1.90, 2.35, 2.90, 3.55, 4.25)
                    for ((tier, multiplier) in salaryMultipliers.withIndex()) {
                        val salary = (salaryReference * multiplier).roundToLong().coerceAtLeast(500_000L)
                        val proposed = runCatching {
                            makeOffer(
                                s, candidate, team.id, chooseAiYears(candidate, responseSeason, 53, driverAttributes), salary, role, responseSeason,
                                currentWeek = 53, round = (tier + 1).coerceIn(1, 3), replaceDriverId = null,
                                proposerTeamId = team.id, teamChampionshipPoints = teamChampionshipPoints,
                                driverAttributes = driverAttributes, driverChampionshipPoints = driverChampionshipPoints
                            )
                        }.getOrNull() ?: continue
                        s = proposed.first
                        val offer = proposed.second
                        s = expireOffers(s, offer.expiresAfterWeek, responseSeason, playerTeamId = playerTeamId,
                            onlyDriverId = candidate, onlyTeamId = team.id)
                        var signed = s.scheduled.firstOrNull { it.driverId == candidate && it.toTeamId == team.id && it.startSeason == season }
                        if (signed == null) {
                            // If the driver counters, the AI must explicitly decide whether
                            // the demanded terms are financially reasonable before signing.
                            val counter = s.pending.firstOrNull {
                                it.driverId == candidate && it.toTeamId == team.id && it.seasonTarget == season && it.status == NegotiationStatus.COUNTER
                            }
                            val salaryCeiling = (salaryReference * 4.75).roundToLong()
                            if (counter != null && counter.salary <= salaryCeiling) {
                                val acceptedCounter = counter.copy(status = NegotiationStatus.ACCEPTED)
                                s = runCatching { signFuture(s, acceptedCounter, responseSeason) }.getOrElse { s }
                                signed = s.scheduled.firstOrNull { it.driverId == candidate && it.toTeamId == team.id && it.startSeason == season }
                                if (signed != null) {
                                    val deal = s.scheduled.first { it.driverId == candidate && it.toTeamId == team.id && it.startSeason == season }
                                    s = recordCompletedSignature(s, deal, responseSeason, 56).copy(
                                        pending = s.pending.filterNot { it.driverId == candidate && it.seasonTarget == season }
                                    )
                                }
                            }
                        }
                        if (signed != null) {
                            signedDeal = signed
                            selectedDriver = candidate
                            consumedFee = fee
                            break@candidateLoop
                        }
                        s = s.copy(pending = s.pending.filterNot {
                            it.driverId == candidate && it.toTeamId == team.id && it.seasonTarget == season
                        }).normalized()
                    }
                    if (signedDeal != null) break
                }

                val signed = signedDeal
                val driverId = selectedDriver
                if (signed == null || driverId == null) {
                    val reason = "${team.name} terminou a janela sem acordo para a vaga restante; nenhum piloto foi atribuído sem aceitar um contrato."
                    s = s.copy(
                        notifications = s.notifications + MarketNotification(season, 1, "VAGA DE PILOTO EM ABERTO", reason, true),
                        history = s.history + reason
                    ).normalized()
                    break
                }
                // The accepted offer was already recorded in the future-contract ledger.
                // Apply it to the new season without fabricating a direct assignment.
                val destinationCount = s.rosterCount(team.id, season)
                if (destinationCount >= 2) {
                    val reason = "Contrato aceito de ${driverName(driverId)} não aplicado: ${team.name} já possui duas vagas válidas."
                    s = s.copy(scheduled = s.scheduled.filterNot { it.driverId == driverId }, notifications = s.notifications + MarketNotification(season, 1, "CONTRATO NÃO APLICADO", reason, true, relatedTeamId = playerTeamId?.takeIf { it == team.id }), history = s.history + reason)
                    break
                }
                val withSignatureEvent = recordCompletedSignature(s, signed, season, 1, playerTeamId)
                s = withSignatureEvent.copy(
                    contracts = s.contracts.filterNot { it.driverId == driverId } + DriverDeal(
                        driverId, team.id, signed.years, signed.salary, currentMarketValue(driverId, driverAttributes), season, signed.role
                    ),
                    scheduled = s.scheduled.filterNot { it.driverId == driverId },
                    pending = s.pending.filterNot { it.driverId == driverId && it.seasonTarget <= season },
                    freeAgents = s.freeAgents - driverId,
                    notifications = withSignatureEvent.notifications,
                    history = s.history + "Contrato aceito de ${driverName(driverId)} para ${team.name} na virada da temporada (taxa de assinatura $consumedFee)"
                ).normalized()
                remainingBudgets[team.id] = (remainingBudgets[team.id] ?: 0L) - consumedFee
            }
        }
        return s.normalized()
    }

    private fun DriverMarketState.rosterCount(teamId:Int,season:Int)=contracts.count { it.teamId==teamId && it.activeIn(season) }
    private fun roleCompatible(state: DriverMarketState, teamId:Int, driverId:Int, role:DriverTeamRole, season:Int, replacingDriverId:Int?=null):Boolean {
        if (role != DriverTeamRole.PILOT_1) return true
        return state.contracts.none { it.teamId==teamId && it.activeIn(season) && it.driverId != (replacingDriverId ?: driverId) && it.role==DriverTeamRole.PILOT_1 }
    }
    private fun overall(d: com.f1teammanager.core.season.DriverDefinition):Int = com.f1teammanager.core.season.DriverProfileCatalog.overall(d.normalized().let { intArrayOf(it.speed,it.qualifying,it.overtaking,it.defense,it.consistency,it.wet,it.tyre) })
    private fun currentDriverOverall(driverId: Int, attributes: Map<Int,List<Int>>): Int {
        val live = attributes[driverId]?.takeIf { it.size == 7 }
        if (live != null) return live.sumOf { it.coerceIn(40, 100) } / live.size
        return WorldDatabase.allDrivers.firstOrNull { it.id == driverId }?.let(::overall) ?: 50
    }
    private fun currentSalaryValue(driverId: Int, attributes: Map<Int, List<Int>>): Long {
        val definition = WorldDatabase.allDrivers.firstOrNull { it.id == driverId } ?: return 500_000L
        val baseOverall = overall(definition).coerceAtLeast(1)
        return (salaryFor(driverId).toDouble() * currentDriverOverall(driverId, attributes) / baseOverall)
            .roundToLong().coerceIn(300_000L, 60_000_000L)
    }
    private fun currentMarketValue(driverId: Int, attributes: Map<Int,List<Int>>): Long {
        val definition = WorldDatabase.allDrivers.firstOrNull { it.id == driverId } ?: return 500_000L
        val baseOverall = overall(definition).coerceAtLeast(1)
        return (marketValueFor(driverId).toDouble() * currentDriverOverall(driverId, attributes) / baseOverall)
            .roundToLong().coerceIn(500_000L, 100_000_000L)
    }
    private fun currentChampionshipRating(teamId: Int, points: Map<Int, Int>): Int? {
        if (points.values.none { it > 0 }) return null
        val teams = WorldDatabase.teams.sortedWith(
            compareByDescending<com.f1teammanager.core.season.TeamDefinition> { points[it.id] ?: 0 }
                .thenByDescending { InitialTeamProfile.strength(it) }
        )
        val rank = (teams.indexOfFirst { it.id == teamId } + 1).coerceAtLeast(1)
        return (100 - ((rank - 1) * 65.0 / (teams.size - 1).coerceAtLeast(1)))
            .roundToLong().toInt().coerceIn(35, 100)
    }

    /** Championship position gains authority gradually as more season results accumulate. */
    private fun seasonPerformanceWeight(points: Map<Int, Int>): Double {
        val totalPoints = points.values.sumOf { it.coerceAtLeast(0) }.toDouble()
        if (totalPoints <= 0.0) return 0.0
        return (totalPoints / 2_500.0).coerceIn(0.20, 0.80)
    }

    private fun blendedTeamRating(base: Int, current: Int, weight: Double): Int =
        (base * (1.0 - weight) + current * weight).roundToLong().toInt().coerceIn(25, 100)

    private fun teamSportingStrength(teamId: Int, points: Map<Int,Int>): Int {
        val base = InitialTeamProfile.strength(WorldDatabase.teams.first { it.id == teamId })
        val current = currentChampionshipRating(teamId, points) ?: return base
        val weight = seasonPerformanceWeight(points)
        // Sporting merit dominates by the end of a full season, but one early result
        // cannot instantly rewrite the reputation of a 40-team championship.
        return blendedTeamRating(base, current, weight)
    }
    /** Effective current-season sporting pull, combining reputation and championship position. */
    fun sportingStrengthForMarket(teamId: Int, teamChampionshipPoints: Map<Int, Int> = emptyMap()): Int =
        teamSportingStrength(teamId, teamChampionshipPoints)

    /** Live overall is exposed for deterministic regression tests and market diagnostics. */
    fun driverOverallForMarket(driverId: Int, driverAttributes: Map<Int, List<Int>> = emptyMap()): Int =
        currentDriverOverall(driverId, driverAttributes)

    /**
     * AI candidate estimate: Scouting precision controls how much of the driver's
     * true rating is exposed to its decision model. Low-level scouting keeps the
     * estimate closer to the neutral market baseline; level 10 is fully precise.
     */
    fun aiScoutingEstimateForMarket(
        driverId: Int,
        facilities: TeamFacilitiesState,
        driverAttributes: Map<Int, List<Int>> = emptyMap()
    ): Int {
        val precision = FacilityEngine.scoutingPrecision(facilities) / 100.0
        val actual = currentDriverOverall(driverId, driverAttributes)
        val neutralMarketEstimate = 65.0
        return (neutralMarketEstimate * (1.0 - precision) + actual * precision)
            .roundToLong().toInt().coerceIn(40, 100)
    }

    private fun offerAttractiveness(offer: DriverOffer): Int = (offer.interestScore * 0.78 + offer.years.coerceIn(1,5) * 1.2 + when (offer.role) {
        DriverTeamRole.PILOT_1 -> 4
        DriverTeamRole.EQUAL -> 3
        DriverTeamRole.PILOT_2 -> 0
    }).roundToLong().toInt()
    private fun teamPrestige(teamId: Int, points: Map<Int, Int>): Int {
        val base = InitialTeamProfile.strength(WorldDatabase.teams.first { it.id == teamId })
        val current = currentChampionshipRating(teamId, points) ?: return base
        return blendedTeamRating(base, current, seasonPerformanceWeight(points) * 0.65)
    }
    private fun teamRecentPerformance(teamId:Int, points: Map<Int,Int>): Int {
        val base = InitialTeamProfile.strength(WorldDatabase.teams.first { it.id == teamId })
        val current = currentChampionshipRating(teamId, points) ?: return base
        return blendedTeamRating(base, current, seasonPerformanceWeight(points))
    }
    private fun teamHistory(teamId:Int, points: Map<Int,Int>): Int {
        val base = InitialTeamProfile.strength(WorldDatabase.teams.first { it.id == teamId })
        val current = currentChampionshipRating(teamId, points) ?: return base
        return blendedTeamRating(base, current, seasonPerformanceWeight(points) * 0.55)
    }
    private fun driverName(id:Int)=WorldDatabase.allDrivers.firstOrNull { it.id==id }?.name ?: "Piloto $id"
    private fun teamName(id:Int)=WorldDatabase.teams.firstOrNull { it.id==id }?.name ?: "Equipe $id"
}
