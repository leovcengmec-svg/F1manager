package com.f1teammanager.core.manager

import com.f1teammanager.core.season.WorldDatabase
import kotlin.math.roundToLong
import kotlin.random.Random

class DriverMarketEngine(private val seed: Int = 20261003) {
    fun initialState(season: Int = 2026): DriverMarketState {
        val contracts = WorldDatabase.drivers.map { d ->
            DriverDeal(d.id, d.teamId, years = if (d.id <= 44) 2 else 1, salary = salaryFor(d.id), buyout = salaryFor(d.id) / 2, seasonSigned = season)
        }
        val reserveIds = WorldDatabase.allDrivers.filter { it.teamId == 0 }.map { it.id }
        return DriverMarketState(contracts = contracts, released = reserveIds).normalized()
    }

    fun salaryFor(driverId: Int): Long {
        val d = WorldDatabase.allDrivers.firstOrNull { it.id == driverId }
        val rating = d?.let { (it.speed + it.qualifying + it.overtaking + it.consistency + it.tyre) / 5 } ?: 70
        return (500_000L + rating * 90_000L + (d?.experience ?: 20) * 20_000L).coerceAtMost(25_000_000L)
    }

    fun roster(state: DriverMarketState, teamId: Int): List<Int> = state.contracts.filter { it.teamId == teamId }.map { it.driverId }
    fun freeAgents(state: DriverMarketState): List<Int> = state.released.filter { id -> state.contracts.none { it.driverId == id } }
    fun expiring(state: DriverMarketState, season: Int): List<DriverDeal> = state.contracts.filter { it.seasonSigned + it.years <= season }

    fun offer(
        state: DriverMarketState,
        driverId: Int,
        fromTeamId: Int,
        toTeamId: Int,
        years: Int,
        salary: Long,
        buyout: Long = 0L,
        teamStrength: Int = 70,
        reputation: Int = 50,
        season: Int = 2026,
        rngSeed: Int = seed + driverId * 31 + toTeamId * 17
    ): Pair<DriverMarketState, DriverOffer> {
        require(driverId in WorldDatabase.allDrivers.map { it.id }) { "Piloto inexistente" }
        require(fromTeamId != toTeamId) { "A equipe de origem e destino são iguais" }
        val destinationFull = roster(state, toTeamId).size >= 2
        val current = state.contracts.firstOrNull { it.driverId == driverId }
        require(current == null || current.teamId == fromTeamId) { "Piloto não pertence à equipe de origem" }
        val driver = WorldDatabase.allDrivers.first { it.id == driverId }
        val salaryScore = ((salary.toDouble() / salaryFor(driverId)) * 35).roundToLong().toInt().coerceIn(0,35)
        val performanceScore = (((teamStrength + reputation) / 2.0) - 50).roundToLong().toInt().coerceIn(-20,20)
        val loyaltyPenalty = if (current != null && current.years > 1) 12 else 0
        val random = Random(rngSeed).nextInt(-5,6)
        val score = (45 + salaryScore + performanceScore - loyaltyPenalty + random).coerceIn(0,100)
        val accepted = score >= 60 && !destinationFull
        val offer = DriverOffer(driverId, fromTeamId, toTeamId, years.coerceIn(1,4), salary.coerceAtLeast(100_000L), buyout.coerceAtLeast(0L), score, accepted)
        if (!accepted) return state.copy(pending = (state.pending + offer).takeLast(50)) to offer

        val replacement = current?.let { state.contracts.filterNot { c -> c.driverId == driverId } } ?: state.contracts
        val next = replacement + DriverDeal(driverId, toTeamId, offer.years, offer.salary, offer.buyout, season, isPreContract = season > (current?.seasonSigned ?: season))
        val history = state.history + "${driver.name}: ${fromTeamId}->${toTeamId} por ${offer.years} ano(s)"
        return state.copy(contracts = next, pending = (state.pending + offer).takeLast(50), released = state.released - driverId, history = history).normalized() to offer
    }

    fun release(state: DriverMarketState, driverId: Int, teamId: Int, season: Int): DriverMarketState {
        val current = state.contracts.firstOrNull { it.driverId == driverId }
        require(current != null && current.teamId == teamId) { "Piloto não pertence à equipe" }
        require(current.seasonSigned + current.years <= season || current.years <= 1) { "Contrato ainda protegido" }
        val next = state.contracts.filterNot { it.driverId == driverId }
        return state.copy(contracts = next, released = (state.released + driverId).distinct(), history = state.history + "Piloto ${driverId} liberado").normalized()
    }

    fun renew(state: DriverMarketState, driverId: Int, teamId: Int, years: Int, salary: Long, season: Int): DriverMarketState {
        val current = state.contracts.firstOrNull { it.driverId == driverId }
        require(current != null && current.teamId == teamId) { "Piloto não pertence à equipe" }
        val deal = current.copy(years = years.coerceIn(1,5), salary = salary.coerceAtLeast(100_000L), seasonSigned = season)
        return state.copy(contracts = state.contracts.filterNot { it.driverId == driverId } + deal,
            history = state.history + "Renovação ${driverId}: ${deal.years} ano(s)").normalized()
    }

    fun runAiOffseason(state: DriverMarketState, season: Int, teamBudget: Map<Int, Long>): DriverMarketState {
        var s = state
        val expiring = expiring(s, season).toMutableList()
        val rng = Random(seed + season)
        expiring.forEach { deal ->
            if (s.contracts.none { it.driverId == deal.driverId }) return@forEach
            val team = deal.teamId
            val budget = teamBudget[team] ?: 20_000_000L
            val keep = rng.nextInt(0,100) < (55 + (WorldDatabase.teams.first { it.id == team }.baseCar - 70).coerceIn(-10,15))
            if (keep && roster(s, team).size <= 2 && budget >= deal.salary) {
                s = renew(s, deal.driverId, team, 1 + rng.nextInt(0,3), (deal.salary * (1.05 + rng.nextDouble()*0.20)).roundToLong(), season)
            } else {
                s = s.copy(contracts = s.contracts.filterNot { it.driverId == deal.driverId }, released = (s.released + deal.driverId).distinct(), history = s.history + "IA liberou piloto ${deal.driverId}")
            }
        }
        // Fill empty AI seats with released drivers, preferring higher rated drivers.
        val pool = freeAgents(s).sortedByDescending { id -> WorldDatabase.allDrivers.firstOrNull { it.id == id }?.speed ?: 0 }.toMutableList()
        for (team in WorldDatabase.teams) {
            if (team.id == 1) continue
            while (roster(s, team.id).size < 2 && pool.isNotEmpty()) {
                val driverId = pool.removeAt(0)
                val driver = WorldDatabase.allDrivers.first { it.id == driverId }
                val deal = DriverDeal(driverId, team.id, 1 + rng.nextInt(0,2), salaryFor(driverId), salaryFor(driverId)/2, season)
                s = s.copy(contracts = s.contracts + deal, released = s.released - driverId, history = s.history + "IA contratou ${driver.name} para equipe ${team.id}").normalized()
            }
        }
        return s
    }

    fun marketSummary(state: DriverMarketState, season: Int): String {
        val exp = expiring(state, season).size
        return "Contratados: ${state.contracts.size} | Livres: ${freeAgents(state).size} | Expirando: $exp"
    }
}
