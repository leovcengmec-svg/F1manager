package com.f1teammanager.core.manager

import com.f1teammanager.core.season.WorldDatabase
import com.f1teammanager.core.season.SeasonCalendar
import kotlin.math.roundToLong
import kotlin.random.Random

/** Stage 3: driver market. Transfers are future-season commitments; the current grid never changes mid-season. */
class DriverMarketEngine(private val seed: Int = 20261003) {
    private val allIds = WorldDatabase.allDrivers.map { it.id }.toSet()

    fun initialState(season: Int = 2026): DriverMarketState {
        val contracts = WorldDatabase.drivers.map { d ->
            val value = marketValueFor(d.id)
            val years = if (d.id <= 44) 2 else 1
            DriverDeal(d.id, d.teamId, years, salaryFor(d.id), value, season, role = DriverTeamRole.EQUAL)
        }
        val prefs = WorldDatabase.allDrivers.associate { it.id to DriverRolePreference.INDIFFERENT }
        val free = WorldDatabase.allDrivers.map { it.id }.filter { id -> contracts.none { it.driverId == id } }
        return DriverMarketState(contracts=contracts, freeAgents=free, rolePreferences=prefs).normalized()
    }

    fun salaryFor(driverId: Int): Long {
        val d = WorldDatabase.allDrivers.firstOrNull { it.id == driverId } ?: return 500_000L
        val overall = overall(d)
        val classBonus = when (d.driverClass.lowercase()) {
            "lenda" -> 18_000_000L
            "pro" -> 9_000_000L
            "forte" -> 4_000_000L
            "médio", "medio" -> 1_500_000L
            else -> 0L
        }
        val evolutionBonus = when (d.evolution.lowercase()) {
            "prodígio", "prodigio" -> 2_500_000L
            "auge rápido", "auge rapido" -> 1_800_000L
            "auge moderado", "auge tardio" -> 1_200_000L
            else -> 0L
        }
        // V503: reduce the generated base salary for every driver by 40%.
        // Keep the same rating/class/evolution balance; only the salary scale changes.
        val originalSalary = (500_000L + overall * 380_000L + classBonus + evolutionBonus)
            .coerceIn(500_000L, 70_000_000L)
        return (originalSalary * 0.60).roundToLong().coerceIn(300_000L, 42_000_000L)
    }

    fun marketValueFor(driverId: Int): Long {
        val d = WorldDatabase.allDrivers.firstOrNull { it.id == driverId } ?: return 500_000L
        val base = overall(d) * 500_000L
        val classMultiplier = when (d.driverClass.lowercase()) {
            "lenda" -> 1.65; "pro" -> 1.35; "forte" -> 1.15; "médio", "medio" -> 0.90; else -> 0.70
        }
        val evolutionMultiplier = when (d.evolution.lowercase()) {
            "prodígio", "prodigio" -> 1.25; "auge rápido", "auge rapido" -> 1.15; "auge moderado", "auge tardio" -> 1.10; "demorado" -> 0.90; else -> 1.0
        }
        return (base * classMultiplier * evolutionMultiplier).roundToLong().coerceIn(500_000L, 80_000_000L)
    }

    fun roster(state: DriverMarketState, teamId: Int, includeScheduled: Boolean = false, season: Int = 2026): List<Int> {
        val current = state.contracts.filter { it.teamId == teamId && it.activeIn(season) }.map { it.driverId }
        if (!includeScheduled) return current
        return (current + state.scheduled.filter { it.toTeamId == teamId && it.startSeason == season }.map { it.driverId }).distinct()
    }

    fun freeAgents(state: DriverMarketState): List<Int> = state.freeAgents.filter { id -> state.contracts.none { it.driverId == id } && state.scheduled.none { it.driverId == id } }

    fun expiring(state: DriverMarketState, season: Int): List<DriverDeal> = state.contracts.filter { it.seasonSigned + it.years <= season }

    fun canReceiveProposals(state: DriverMarketState, driverId: Int, season: Int): Boolean {
        if (state.scheduled.any { it.driverId == driverId }) return false
        val deal = state.contracts.firstOrNull { it.driverId == driverId } ?: return driverId in state.freeAgents
        return deal.canReceiveProposals(season)
    }

    fun interestScore(
        state: DriverMarketState, driverId: Int, toTeamId: Int, salary: Long,
        role: DriverTeamRole, season: Int,
        teamChampionshipPoints: Map<Int, Int> = emptyMap(),
        driverAttributes: Map<Int, List<Int>> = emptyMap(),
        driverChampionshipPoints: Map<Int, Int> = emptyMap()
    ): Int {
        val destinationStrength = teamSportingStrength(toTeamId, teamChampionshipPoints)
        val currentForSalary = state.contracts.firstOrNull { it.driverId == driverId && it.activeIn(season) }
        val salaryReferenceForScore = maxOf(currentSalaryValue(driverId, driverAttributes), currentForSalary?.salary ?: 0L).coerceAtLeast(1L)
        val salaryScore = (salary.toDouble() / salaryReferenceForScore * 20.0).roundToLong().toInt().coerceIn(0,20)
        val rolePref = state.rolePreferences[driverId] ?: DriverRolePreference.INDIFFERENT
        val roleScore = when (rolePref) {
            DriverRolePreference.DEMANDS_PILOT_1 -> if (role == DriverTeamRole.PILOT_1) 10 else -18
            DriverRolePreference.PREFERS_PILOT_1 -> if (role == DriverTeamRole.PILOT_1) 7 else 0
            DriverRolePreference.PREFERS_EQUALITY -> if (role == DriverTeamRole.EQUAL) 7 else 0
            DriverRolePreference.INDIFFERENT -> 5
        }
        val prestige = teamPrestige(toTeamId)
        val project = (destinationStrength + prestige) / 2
        val recent = teamRecentPerformance(toTeamId, teamChampionshipPoints)
        val current = state.contracts.firstOrNull { it.driverId == driverId && it.activeIn(season) }
        val retention = if (current?.teamId == toTeamId) 10 else 0
        val currentStrength = current?.let { teamSportingStrength(it.teamId, teamChampionshipPoints) }
        val strengthDrop = if (currentStrength == null || toTeamId == current.teamId) 0
            else (currentStrength - destinationStrength).coerceAtLeast(0)
        val currentOverall = currentDriverOverall(driverId, driverAttributes)
        val sportingPenalty = (strengthDrop * 0.82).roundToLong().toInt().coerceIn(0,38)
        val driverPoints = driverChampionshipPoints[driverId] ?: 0
        val driverRank = if (driverChampionshipPoints.values.any { it > 0 }) driverChampionshipPoints.count { it.value > driverPoints } + 1 else Int.MAX_VALUE
        val driverIsTitleContender = driverRank <= 5 && driverPoints > 0
        val titleContenderLeavingCurrent = current != null && toTeamId != current.teamId && currentOverall >= 84 && currentStrength != null && currentStrength >= 72
        val titleContenderDropPenalty = if (destinationStrength <= 50 && (titleContenderLeavingCurrent || driverIsTitleContender)) 12 else 0
        // Compare against both fair market pay and existing pay. A stale low salary can
        // no longer make an ordinary raise look like a super-offer.
        val salaryReference = maxOf(currentSalaryValue(driverId, driverAttributes), current?.salary ?: 0L).coerceAtLeast(1L)
        val salaryRatio = salary.toDouble() / salaryReference.toDouble()
        val exceptionalMoneyBonus = when {
            salaryRatio >= 10.0 -> 88
            salaryRatio >= 8.0 -> 76
            salaryRatio >= 6.0 -> 65
            salaryRatio >= 4.5 -> 54
            salaryRatio >= 3.5 -> 42
            salaryRatio >= 2.75 -> 30
            salaryRatio >= 2.0 -> 18
            salaryRatio >= 1.5 -> 8
            else -> 0
        }
        val score = (destinationStrength * .25 + salaryScore + prestige * .15 + project * .15 + roleScore +
            recent * .10 + teamHistory(toTeamId) * .05 + retention + exceptionalMoneyBonus - sportingPenalty - titleContenderDropPenalty)
            .roundToLong().toInt()
        return score.coerceIn(0,100)
    }

    /** Compatibility entry point for the previous V9 engine. It now creates a future-season offer instead of moving the driver immediately. */
    fun offer(state: DriverMarketState, driverId: Int, fromTeamId: Int, toTeamId: Int, years: Int, salary: Long,
              teamStrength: Int = 70, reputation: Int = 50, season: Int = 2026, rngSeed: Int = seed): Pair<DriverMarketState, DriverOffer> =
        makeOffer(state, driverId, toTeamId, years.coerceIn(1,5), salary, DriverTeamRole.EQUAL, season)

    fun makeOffer(
        state: DriverMarketState, driverId: Int, toTeamId: Int, years: Int, salary: Long,
        role: DriverTeamRole, season: Int, currentWeek: Int = 1, round: Int = 1, replaceDriverId: Int? = null, proposerTeamId: Int? = null,
        teamChampionshipPoints: Map<Int, Int> = emptyMap(), driverAttributes: Map<Int, List<Int>> = emptyMap(),
        driverChampionshipPoints: Map<Int, Int> = emptyMap()
    ): Pair<DriverMarketState, DriverOffer> {
        require(driverId in allIds) { "Piloto inexistente" }
        require(toTeamId in WorldDatabase.teams.map { it.id }) { "Equipe inexistente" }
        require(marketOpen(currentWeek, season)) { "O mercado de pilotos abre somente após 8 corridas realizadas" }
        require(years in 1..5) { "O contrato deve ter entre 1 e 5 anos" }
        require(canReceiveProposals(state, driverId, season)) { "Este piloto não está disponível para propostas nesta temporada" }
        val destinationRoster = roster(state, toTeamId, season = season)
        val reservedOpenSeats = state.scheduled.count { it.toTeamId == toTeamId && it.startSeason == season + 1 && it.replaceDriverId == null && it.driverId != driverId }
        val projectedRosterSize = destinationRoster.size + reservedOpenSeats
        if (projectedRosterSize >= 2 && state.contracts.none { it.driverId == driverId && it.teamId == toTeamId }) {
            require(replaceDriverId != null && replaceDriverId in destinationRoster) { "As duas vagas futuras já estão ocupadas; selecione um titular atual para substituir" }
            require(state.scheduled.none { it.toTeamId == toTeamId && it.replaceDriverId == replaceDriverId }) { "Esse piloto já está reservado para outra contratação futura; selecione o outro piloto" }
        }
        require(state.scheduled.none { it.driverId == driverId }) { "Piloto já possui transferência futura" }
        // Um piloto pode negociar simultaneamente com várias equipes.
        // A negociação é individual por equipe; somente uma transferência futura
        // efetivamente assinada encerra as demais negociações do piloto.
        val current = state.contracts.firstOrNull { it.driverId == driverId }
        val from = current?.teamId ?: 0
        val proposer = proposerTeamId ?: toTeamId
        val value = currentMarketValue(driverId, driverAttributes)
        val score = interestScore(state, driverId, toTeamId, salary, role, season, teamChampionshipPoints, driverAttributes, driverChampionshipPoints)
        val rng = Random(seed + driverId * 31 + toTeamId * 17 + round * 13 + currentWeek * 7)
        val responseDelay = if (rng.nextBoolean()) 2 else 3
        val normalizedRound = round.coerceIn(1, 3)
        val offer = DriverOffer(
            driverId, from, toTeamId, years.coerceIn(1, 5), salary.coerceAtLeast(100_000L), role,
            value, (score + rng.nextInt(-4, 5)).coerceIn(0, 100), normalizedRound,
            currentWeek + responseDelay, NegotiationStatus.PENDING, season + 1, replaceDriverId, proposer
        )
        val next = state.copy(
            pending = (state.pending.filterNot {
                it.driverId == driverId && it.toTeamId == toTeamId && it.seasonTarget == season + 1 && it.round == normalizedRound
            } + offer).takeLast(100),
            notifications = state.notifications + MarketNotification(
                season, currentWeek, "PROPOSTA ENVIADA",
                "A ${teamName(toTeamId)} fez uma proposta por ${driverName(driverId)}. O piloto responderá em ${responseDelay} semanas.",
                true
            )
        )
        return next.normalized() to offer
    }

    /** Processes proposals whose driver-response deadline has arrived. Responses take 2 or 3 calendar weeks. */
    fun expireOffers(
        state: DriverMarketState,
        currentWeek: Int,
        season: Int = 0,
        playerTeamId: Int? = null,
        onlyDriverId: Int? = null,
        onlyTeamId: Int? = null
    ): DriverMarketState {
        // Offers made by AI teams to the player's contracted drivers are not automatic driver replies.
        // They must remain pending until the player explicitly accepts or rejects them in the market UI.
        val due = state.pending.filter {
            it.status == NegotiationStatus.PENDING && it.expiresAfterWeek <= currentWeek &&
                (onlyDriverId == null || it.driverId == onlyDriverId) &&
                (onlyTeamId == null || it.toTeamId == onlyTeamId) &&
                !(playerTeamId != null && it.fromTeamId == playerTeamId && it.toTeamId != playerTeamId && it.proposerTeamId == it.toTeamId)
        }
        if (due.isEmpty()) return state
        var s = state
        due.forEach { offer ->
            // The due list is a snapshot. A previous accepted offer may already have
            // signed this driver and removed rival offers; never process a stale entry
            // from that snapshot or emit a false "transfer could not be recorded" notice.
            if (s.pending.none { sameNegotiation(it, offer) && it.status == NegotiationStatus.PENDING }) return@forEach
            val rng = Random(seed + season * 997 + currentWeek * 31 + offer.driverId * 41 + offer.toTeamId * 17 + offer.round * 13)
            val base = offer.interestScore
            val incumbent = s.contracts.firstOrNull { it.driverId == offer.driverId }
            val needsSeat = offer.driverId in s.freeAgents || (incumbent != null && !incumbent.activeIn(offer.seasonTarget))
            val endWindowUrgency = if (needsSeat) ((currentWeek - 32) / 3).coerceIn(0, 10) else 0
            val bestAlternative = s.pending.asSequence().filter {
                it.driverId == offer.driverId && it.seasonTarget == offer.seasonTarget && !sameNegotiation(it, offer) &&
                    it.status in setOf(NegotiationStatus.PENDING, NegotiationStatus.COUNTER)
            }.maxByOrNull(::offerAttractiveness)
            val choosesAnotherOffer = bestAlternative != null && offerAttractiveness(bestAlternative) >= offerAttractiveness(offer) + 6
            val adjusted = (base + endWindowUrgency + rng.nextInt(-6, 7)).coerceIn(0, 100)
            val decision = when {
                choosesAnotherOffer -> NegotiationStatus.REJECTED
                adjusted >= 78 -> NegotiationStatus.ACCEPTED
                adjusted >= 52 -> NegotiationStatus.COUNTER
                else -> NegotiationStatus.REJECTED
            }
            val demandedSalary = if (decision == NegotiationStatus.COUNTER)
                (offer.salary * (1.06 + rng.nextDouble() * 0.10)).roundToLong() else offer.salary
            val demandedYears = if (decision == NegotiationStatus.COUNTER && rng.nextInt(100) >= 65) (1..5).random(rng) else offer.years
            val demandedRole = if (decision == NegotiationStatus.COUNTER) {
                when (s.rolePreferences[offer.driverId]) {
                    DriverRolePreference.DEMANDS_PILOT_1 -> DriverTeamRole.PILOT_1
                    DriverRolePreference.PREFERS_EQUALITY -> DriverTeamRole.EQUAL
                    else -> offer.role
                }
            } else offer.role
            val response = offer.copy(
                years = demandedYears, salary = demandedSalary.coerceAtLeast(100_000L), role = demandedRole,
                interestScore = adjusted, status = decision, expiresAfterWeek = currentWeek
            )
            s = s.copy(pending = s.pending.filterNot { sameNegotiation(it, offer) })
            when (decision) {
                NegotiationStatus.ACCEPTED -> {
                    // Nunca descarte silenciosamente a resposta: se a assinatura futura
                    // falhar por conflito de elenco/transferência, a carreira precisa
                    // registrar um evento visível em vez de remover a proposta sem retorno.
                    val signed = runCatching { signFuture(s, response, season) }
                    if (signed.isSuccess) {
                        val currentTeamId = s.contracts.firstOrNull { it.driverId == offer.driverId }?.teamId
                        val currentTeamLabel = currentTeamId?.let(::teamName) ?: "sem equipe atual"
                        val isRenewal = offer.fromTeamId == offer.toTeamId
                        s = signed.getOrThrow().copy(notifications = signed.getOrThrow().notifications + MarketNotification(
                            season, currentWeek, if (isRenewal) "RENOVAÇÃO DE CONTRATO" else "CONTRATO ASSINADO",
                            if (isRenewal) "${driverName(offer.driverId)} aceitou a renovação com ${teamName(offer.toTeamId)} para ${offer.seasonTarget}."
                            else "${driverName(offer.driverId)}: ${currentTeamLabel} → ${teamName(offer.toTeamId)}. Contrato para ${offer.seasonTarget}.", true
                        ))
                    } else {
                        s = s.copy(notifications = s.notifications + MarketNotification(
                            season, currentWeek, "PROPOSTA NÃO CONCLUÍDA",
                            "${driverName(offer.driverId)} aceitou a proposta, mas a transferência não pôde ser registrada: ${signed.exceptionOrNull()?.message ?: "conflito de contrato"}. Revise a negociação no mercado de pilotos.", true
                        ))
                    }
                }
                NegotiationStatus.REJECTED -> {
                    s = s.copy(notifications = s.notifications + MarketNotification(
                        season, currentWeek, "PROPOSTA RECUSADA",
                        if (choosesAnotherOffer && bestAlternative != null)
                            "${driverName(offer.driverId)} recusou ${teamName(offer.toTeamId)} e priorizou a proposta da ${teamName(bestAlternative.toTeamId)}."
                        else "${driverName(offer.driverId)} recusou a proposta da ${teamName(offer.toTeamId)}.", true
                    ))
                }
                NegotiationStatus.COUNTER -> {
                    val counter = response.copy(expiresAfterWeek = currentWeek, status = NegotiationStatus.COUNTER)
                    s = s.copy(
                        pending = (s.pending + counter).takeLast(100),
                        notifications = s.notifications + MarketNotification(
                            season, currentWeek, "CONTRAPROPOSTA RECEBIDA",
                            "${driverName(offer.driverId)} enviou uma contraproposta para ${teamName(offer.toTeamId)}: salário exigido ${compactMoney(counter.salary)}/ano; duração ${counter.years} ano(s); papel ${roleLabel(counter.role)}; início na temporada ${counter.seasonTarget}. Abra Mercado de Pilotos para aceitar, recusar ou fazer outra contraproposta.", true
                        )
                    )
                    // If the proposing team is AI, it decides automatically. If it is the player,
                    // the counter remains visible as an action card in the market screen.
                }
                else -> Unit
            }
        }
        return s.normalized()
    }

    private fun compactMoney(value: Long): String = when {
        value >= 1_000_000L -> "€ ${"%.1f".format(java.util.Locale("pt", "BR"), value / 1_000_000.0)} milhões"
        value >= 1_000L -> "€ ${"%.0f".format(java.util.Locale("pt", "BR"), value / 1_000.0)} mil"
        else -> "€ $value"
    }

    private fun roleLabel(role: DriverTeamRole): String = when (role) {
        DriverTeamRole.PILOT_1 -> "Piloto 1"
        DriverTeamRole.PILOT_2 -> "Piloto 2"
        DriverTeamRole.EQUAL -> "Pilotos em igualdade"
    }

    private fun sameNegotiation(a: DriverOffer, b: DriverOffer): Boolean =
        a.driverId == b.driverId && a.toTeamId == b.toTeamId && a.seasonTarget == b.seasonTarget && a.round == b.round

    private fun resolveAiCounters(
        state: DriverMarketState, season: Int, currentWeek: Int, playerTeamId: Int,
        teamChampionshipPoints: Map<Int, Int>, driverAttributes: Map<Int, List<Int>>,
        driverChampionshipPoints: Map<Int, Int>
    ): DriverMarketState {
        var s = state
        val counters = s.pending.filter { it.status == NegotiationStatus.COUNTER && it.proposerTeamId != 0 && it.proposerTeamId != playerTeamId }
        counters.forEach { offer ->
            if (s.pending.none { sameNegotiation(it, offer) && it.status == NegotiationStatus.COUNTER }) return@forEach
            val rng = Random(seed + season * 701 + currentWeek * 19 + offer.driverId * 29 + offer.toTeamId * 11 + offer.round * 43)
            val original = maxOf(currentSalaryValue(offer.driverId, driverAttributes), s.contracts.firstOrNull { it.driverId == offer.driverId && it.activeIn(season) }?.salary ?: 0L)
            val salaryRatio = offer.salary.toDouble() / original.coerceAtLeast(1L)
            val fit = interestScore(s, offer.driverId, offer.toTeamId, offer.salary, offer.role, season, teamChampionshipPoints, driverAttributes, driverChampionshipPoints)
            val acceptScore = fit + if (salaryRatio <= 1.18) 8 else if (salaryRatio <= 1.28) 2 else -8
            val accept = acceptScore + rng.nextInt(-6, 7) >= if (offer.round >= 3) 56 else 64
            if (accept) {
                val accepted = offer.copy(status = NegotiationStatus.ACCEPTED)
                runCatching { s = signFuture(s, accepted, season) }
                s = s.copy(notifications = s.notifications + MarketNotification(
                    season, currentWeek, "CONTRAPROPOSTA ACEITA",
                    "A ${teamName(offer.toTeamId)} aceitou a contraproposta de ${driverName(offer.driverId)}.", true
                ))
            } else if (offer.round < 3) {
                val nextSalary = (offer.salary * (0.97 + rng.nextDouble() * 0.04)).roundToLong().coerceAtLeast(500_000L)
                val nextRole = if (rng.nextInt(100) < 70) offer.role else preferredRoleFor(s, offer.driverId, offer.toTeamId, season)
                val cleaned = s.copy(pending = s.pending.filterNot { sameNegotiation(it, offer) })
                runCatching {
                    val (next, _) = counterOffer(cleaned, offer, season, currentWeek, nextSalary, offer.years, nextRole, offer.replaceDriverId)
                    s = next.copy(notifications = next.notifications + MarketNotification(
                        season, currentWeek, "CONTRAPROPOSTA DA EQUIPE",
                        "A ${teamName(offer.toTeamId)} fez uma nova contraproposta a ${driverName(offer.driverId)}. O piloto responderá em 2 ou 3 semanas.", true
                    ))
                }
            } else {
                s = s.copy(
                    pending = s.pending.filterNot { sameNegotiation(it, offer) },
                    notifications = s.notifications + MarketNotification(
                        season, currentWeek, "CONTRAPROPOSTA RECUSADA",
                        "A ${teamName(offer.toTeamId)} recusou a contraproposta final de ${driverName(offer.driverId)}.", true
                    )
                )
            }
        }
        return s.normalized()
    }

    /** Opens the next negotiation round using the player's new terms. Maximum 3 rounds. */
    fun counterOffer(
        state: DriverMarketState,
        previous: DriverOffer,
        season: Int,
        currentWeek: Int,
        salary: Long,
        years: Int,
        role: DriverTeamRole,
        replaceDriverId: Int? = null
    ): Pair<DriverMarketState, DriverOffer> {
        require(previous.status == NegotiationStatus.COUNTER) { "Esta negociação não está aguardando contraproposta" }
        require(previous.round < 3) { "A negociação já atingiu 3 rodadas" }
        require(previous.seasonTarget == season + 1) { "A proposta pertence a outra temporada" }
        require(state.pending.any { it.driverId == previous.driverId && it.toTeamId == previous.toTeamId && it.seasonTarget == previous.seasonTarget && it.round == previous.round && it.status == NegotiationStatus.COUNTER }) {
            "Esta contraproposta já não está ativa"
        }
        val cleaned = state.copy(pending = state.pending.filterNot {
            it.driverId == previous.driverId && it.toTeamId == previous.toTeamId &&
                it.seasonTarget == previous.seasonTarget && it.round == previous.round
        })
        // Keep the replacement selected in the original negotiation when the UI does not
        // explicitly choose another driver. A nullable UI selection must not erase it.
        val effectiveReplacementDriverId = replaceDriverId ?: previous.replaceDriverId
        return makeOffer(cleaned, previous.driverId, previous.toTeamId, years, salary, role, season, currentWeek, previous.round + 1, effectiveReplacementDriverId, previous.proposerTeamId)
    }

    fun signFuture(state: DriverMarketState, offer: DriverOffer, season: Int, replaceDriverId: Int? = null): DriverMarketState {
        require(offer.status == NegotiationStatus.ACCEPTED) { "Somente uma proposta aceita pode gerar contrato futuro" }
        require(offer.seasonTarget == season + 1) { "A transferência deve começar na próxima temporada" }
        require(state.scheduled.none { it.driverId == offer.driverId }) { "Piloto já possui transferência futura" }
        val current = state.contracts.firstOrNull { it.driverId == offer.driverId }
        val future = FutureDriverDeal(offer.driverId, current?.teamId ?: 0, offer.toTeamId, offer.seasonTarget, offer.years, offer.salary, offer.role, season, offer.replaceDriverId ?: replaceDriverId)
        // A future signature settles the driver's choice for that target season.
        // Other offers for the same driver/season must not survive and race this deal.
        val cleanPending = state.pending.filterNot { it.driverId == offer.driverId && it.seasonTarget == offer.seasonTarget }
        return state.copy(pending=cleanPending, scheduled=state.scheduled + future,
            history=state.history + "${driverName(offer.driverId)} assinou com equipe ${offer.toTeamId} para ${offer.seasonTarget}")
    }

    fun acceptCounterOffer(state: DriverMarketState, offer: DriverOffer, season: Int, currentWeek: Int): DriverMarketState {
        require(offer.status == NegotiationStatus.COUNTER) { "A contraproposta não está ativa" }
        require(offer.seasonTarget == season + 1) { "A proposta pertence a outra temporada" }
        require(offer.round in 1..3) { "Rodada inválida" }
        require(state.pending.any { it.driverId == offer.driverId && it.toTeamId == offer.toTeamId && it.seasonTarget == offer.seasonTarget && it.round == offer.round && it.status == NegotiationStatus.COUNTER }) { "Contraproposta não encontrada" }
        val accepted = offer.copy(status = NegotiationStatus.ACCEPTED)
        val next = signFuture(state, accepted, season)
        val currentTeamId = state.contracts.firstOrNull { it.driverId == offer.driverId }?.teamId
        val currentTeamLabel = currentTeamId?.let(::teamName) ?: "sem equipe atual"
        return next.copy(
            notifications = next.notifications + MarketNotification(
                season, currentWeek, "CONTRATO FECHADO",
                "${driverName(offer.driverId)}: ${currentTeamLabel} → ${teamName(offer.toTeamId)}. Contrato para ${offer.seasonTarget}.", true
            )
        ).normalized()
    }

    fun rejectCounterOffer(state: DriverMarketState, offer: DriverOffer, season: Int, currentWeek: Int): DriverMarketState {
        require(offer.status == NegotiationStatus.COUNTER) { "A contraproposta não está ativa" }
        val next = state.copy(pending = state.pending.filterNot {
            it.driverId == offer.driverId && it.toTeamId == offer.toTeamId && it.seasonTarget == offer.seasonTarget && it.round == offer.round
        })
        return next.copy(
            notifications = next.notifications + MarketNotification(
                season, currentWeek, "NEGOCIAÇÃO ENCERRADA",
                "Você recusou a contraproposta de ${driverName(offer.driverId)}.", true
            )
        ).normalized()
    }

    fun acceptIncomingOffer(state: DriverMarketState, offer: DriverOffer, season: Int, currentWeek: Int): DriverMarketState {
        require(offer.status == NegotiationStatus.PENDING) { "A proposta não está pendente" }
        require(offer.fromTeamId != offer.toTeamId) { "Proposta inválida" }
        require(offer.seasonTarget == season + 1) { "A proposta pertence a outra temporada" }
        require(state.pending.any { it.driverId == offer.driverId && it.toTeamId == offer.toTeamId && it.seasonTarget == offer.seasonTarget && it.status == NegotiationStatus.PENDING }) { "Proposta não encontrada" }
        val accepted = offer.copy(status = NegotiationStatus.ACCEPTED)
        return signFuture(state, accepted, season).copy(
            notifications = state.notifications + MarketNotification(
                season, currentWeek, "TRANSFERÊNCIA CONFIRMADA",
                "Você aceitou a proposta da ${teamName(offer.toTeamId)} por ${driverName(offer.driverId)}. Transferência em ${offer.seasonTarget}.", true)
        ).normalized()
    }

    fun rejectIncomingOffer(state: DriverMarketState, offer: DriverOffer, season: Int, currentWeek: Int): DriverMarketState {
        val clean = state.copy(pending = state.pending.filterNot { it.driverId == offer.driverId && it.toTeamId == offer.toTeamId && it.seasonTarget == offer.seasonTarget })
        return clean.copy(
            notifications = clean.notifications + MarketNotification(
                season, currentWeek, "PROPOSTA RECUSADA",
                "Você recusou a proposta da ${teamName(offer.toTeamId)} por ${driverName(offer.driverId)}.", true)
        ).normalized()
    }

    fun renew(state: DriverMarketState, driverId: Int, teamId: Int, years: Int, salary: Long, season: Int, currentWeek: Int = 1): DriverMarketState =
        renew(state, driverId, teamId, years, salary, DriverTeamRole.EQUAL, season, currentWeek)

    fun renew(state: DriverMarketState, driverId: Int, teamId: Int, years: Int, salary: Long, role: DriverTeamRole, season: Int, currentWeek: Int = 1): DriverMarketState {
        require(marketOpen(currentWeek, season)) { "O mercado de pilotos abre somente após 8 corridas realizadas" }
        require(years in 1..5) { "O contrato deve ter entre 1 e 5 anos" }
        val current = state.contracts.firstOrNull { it.driverId == driverId && it.teamId == teamId && it.activeIn(season) }
            ?: error("Piloto não pertence à equipe nesta temporada")
        require(current.contractYear(season) == current.years) { "Renovação disponível apenas no último ano do contrato" }
        require(state.scheduled.none { it.driverId == driverId && it.startSeason == season + 1 }) { "Piloto já possui decisão para a próxima temporada" }
        require(roleCompatible(state, teamId, driverId, role, season, replacingDriverId = driverId)) { "Conflito de Piloto 1" }
        val future = FutureDriverDeal(
            driverId = driverId, fromTeamId = teamId, toTeamId = teamId, startSeason = season + 1,
            years = years, salary = salary.coerceAtLeast(100_000L), role = role, signedSeason = season,
            replaceDriverId = driverId
        )
        return state.copy(
            scheduled = state.scheduled.filterNot { it.driverId == driverId } + future,
            notifications = state.notifications + MarketNotification(
                season, currentWeek, "RENOVAÇÃO DE CONTRATO",
                "${driverName(driverId)} renovou com a ${teamName(teamId)} para ${season + 1} por $years ano(s).", true),
            history = state.history + "Renovação de ${driverName(driverId)} preparada para ${season + 1} por $years ano(s)"
        ).normalized()
    }

    /**
     * Rolls back future deals rejected by the caller's financial validation.
     * A success notice must never survive after its scheduled deal is removed:
     * otherwise the news feed says a driver renewed while the market still lists them as open.
     */
    fun cancelUnaffordableScheduledDeals(
        state: DriverMarketState,
        rejectedDeals: Collection<FutureDriverDeal>,
        season: Int,
        currentWeek: Int
    ): DriverMarketState {
        if (rejectedDeals.isEmpty()) return state
        val keys = rejectedDeals.map { "${it.driverId}:${it.toTeamId}:${it.startSeason}" }.toSet()
        val rejectedIds = rejectedDeals.map { it.driverId }.toSet()
        val rejectedNames = rejectedDeals.associate { deal ->
            deal.driverId to (driverName(deal.driverId) to teamName(deal.toTeamId))
        }
        val remainingScheduled = state.scheduled.filterNot { "${it.driverId}:${it.toTeamId}:${it.startSeason}" in keys }
        val remainingPending = state.pending.filterNot { offer ->
            rejectedDeals.any { deal -> offer.driverId == deal.driverId && offer.toTeamId == deal.toTeamId && offer.seasonTarget == deal.startSeason }
        }
        val notices = state.notifications.filterNot { notice ->
            if (notice.season != season) return@filterNot false
            rejectedNames.any { (id, names) ->
                val (driver, team) = names
                id in rejectedIds && notice.title in setOf("RENOVAÇÃO DE CONTRATO", "CONTRATO ASSINADO", "CONTRAPROPOSTA ACEITA", "TRANSFERÊNCIA CONFIRMADA") &&
                    notice.message.contains(driver, ignoreCase = true) && notice.message.contains(team, ignoreCase = true)
            }
        }
        val cancellations = rejectedDeals.map { deal ->
            val name = driverName(deal.driverId)
            val team = teamName(deal.toTeamId)
            val movement = if (deal.fromTeamId == deal.toTeamId) "renovação de $name com $team" else "contratação de $name pela equipe $team"
            MarketNotification(
                season, currentWeek, "NEGOCIAÇÃO ENCERRADA",
                "A $movement para ${deal.startSeason} não foi concluída por saldo insuficiente para a taxa de assinatura.",
                true
            )
        }
        return state.copy(
            scheduled = remainingScheduled,
            pending = remainingPending,
            notifications = (notices + cancellations).takeLast(1000),
            history = (state.history + rejectedDeals.map { deal ->
                "Renovação/contratação não concluída por saldo insuficiente: ${driverName(deal.driverId)}, ${teamName(deal.toTeamId)}, temporada ${deal.startSeason}"
            }).takeLast(300)
        ).normalized()
    }

    /**
     * Processes the AI driver market during the season. AI follows the same eligibility,
     * contract and role rules as the player, but may make imperfect decisions. No current
     * roster changes occur here: every accepted move is scheduled for the next season.
     */
    fun marketOpen(currentWeek: Int, season: Int = 2026): Boolean = SeasonCalendar.forSeason(season).count { it.weekOfSeason < currentWeek } >= 8

    /**
     * Signing fee is a percentage of the driver's market value (not salary).
     * Free agent: 20%; own renewal: 20%; signing from another team: 40%.
     */
    fun signatureFeeFor(state: DriverMarketState, driverId: Int, toTeamId: Int, season: Int): Long {
        val current = state.contracts.firstOrNull { it.driverId == driverId && it.activeIn(season) }
        val marketValue = current?.marketValue ?: state.contracts.firstOrNull { it.driverId == driverId }?.marketValue ?: marketValueFor(driverId)
        val rate = when {
            current == null -> 0.20 // free driver
            current.teamId == toTeamId -> 0.20 // own renewal
            else -> 0.40 // sign from another team
        }
        return (marketValue * rate).roundToLong()
    }

    fun signatureFeeForRenewal(state: DriverMarketState, driverId: Int, teamId: Int, season: Int): Long {
        val current = state.contracts.firstOrNull { it.driverId == driverId && it.teamId == teamId && it.activeIn(season) }
            ?: error("Piloto não pertence à equipe nesta temporada")
        return (current.marketValue * 0.20).roundToLong()
    }

    fun processAiMarketWeek(
        state: DriverMarketState, season: Int, currentWeek: Int, playerTeamId: Int,
        teamChampionshipPoints: Map<Int, Int> = emptyMap(),
        driverAttributes: Map<Int, List<Int>> = emptyMap(),
        driverChampionshipPoints: Map<Int, Int> = emptyMap()
    ): DriverMarketState {
        // Respostas de propostas pendentes são eventos de calendário independentes da
        // janela de abertura do mercado. Processá-las primeiro evita que uma proposta
        // fique sem resposta se a semana avançar para fora da janela de negociações.
        var s = expireOffers(state, currentWeek, season, playerTeamId)
        if (!marketOpen(currentWeek, season)) return s
        s = resolveAiCounters(s, season, currentWeek, playerTeamId, teamChampionshipPoints, driverAttributes, driverChampionshipPoints)
        val teams = WorldDatabase.teams.filter { it.id != playerTeamId }
        val rng = Random(seed + season * 997 + currentWeek * 31)
        // Renewal/transfer mix is deliberately not used as a quota. Decisions are local
        // to each team: renewal fit, roster weakness, market availability and sporting gain.
        // First, allow teams to renew drivers they already trust. Renewal is not a
        // transfer and therefore can happen during the current season.
        teams.shuffled(Random(seed + season * 43 + currentWeek)).forEach { team ->
            val expiring = roster(s, team.id, season = season)
                .mapNotNull { id -> s.contracts.firstOrNull { it.driverId == id && it.teamId == team.id } }
                .filter { it.seasonSigned + it.years - 1 == season }
            expiring.forEach dealLoop@ { deal ->
                val evaluationKey = renewalEvaluationKey(season, team.id, deal.driverId)
                // A no-offer or a rejected offer is still a decision. Without this
                // persistent ledger the same driver was reconsidered every week, making
                // a 30-76% probability approach certainty over a long season.
                if (evaluationKey in s.renewalEvaluations) return@dealLoop
                s = s.copy(renewalEvaluations = (s.renewalEvaluations + evaluationKey).toList().takeLast(240).toSet())

                val role = deal.role
                val fit = interestScore(s, deal.driverId, team.id, deal.salary, role, season, teamChampionshipPoints, driverAttributes, driverChampionshipPoints)
                val possibleUpgrades = (freeAgents(s) + s.contracts.filter { it.teamId != team.id && canReceiveProposals(s, it.driverId, season) }.map { it.driverId }).distinct()
                val incumbentOverall = currentDriverOverall(deal.driverId, driverAttributes)
                var credibleUpgrade = false
                for (candidateId in possibleUpgrades) {
                    if (candidateId == deal.driverId || !canReceiveProposals(s, candidateId, season)) continue
                    val candidateOverall = currentDriverOverall(candidateId, driverAttributes)
                    if (candidateOverall < incumbentOverall + 8) continue
                    val candidateSalary = (maxOf(currentSalaryValue(candidateId, driverAttributes), s.contracts.firstOrNull { it.driverId == candidateId && it.activeIn(season) }?.salary ?: 0L) * 1.15).roundToLong()
                    val candidateInterest = interestScore(s, candidateId, team.id, candidateSalary, preferredRoleFor(s, candidateId, team.id, season), season, teamChampionshipPoints, driverAttributes, driverChampionshipPoints)
                    if (candidateInterest >= 70 && candidateInterest >= fit - 4) {
                        credibleUpgrade = true
                        break
                    }
                }
                val chance = when {
                    fit >= 82 -> 40
                    fit >= 72 -> 28
                    fit >= 60 -> 16
                    else -> 6
                }
                // If a clearly better, interested driver is available, do not renew the
                // incumbent. The team must pursue the upgrade instead of locking in a weak
                // driver and leaving the stronger candidate on the open market.
                val effectiveChance = if (credibleUpgrade) 0 else chance
                val renewalAlreadyPending = s.pending.any {
                    it.driverId == deal.driverId && it.toTeamId == team.id &&
                        it.seasonTarget == season + 1 && it.status in setOf(NegotiationStatus.PENDING, NegotiationStatus.COUNTER)
                }
                if (!renewalAlreadyPending && rng.nextInt(100) < effectiveChance) {
                    val years = chooseAiYears(deal.driverId, season, currentWeek)
                    val salary = (deal.salary * (1.03 + rng.nextDouble() * 0.12)).roundToLong()
                    // Renewals use the same 2–3 week negotiation window as transfers.
                    // Keep the driver's incumbent-team offer pending so other teams can compete.
                    runCatching {
                        val (next, _) = makeOffer(
                            s, deal.driverId, team.id, years, salary, role, season,
                            currentWeek, 1, deal.driverId, team.id,
                            teamChampionshipPoints, driverAttributes, driverChampionshipPoints
                        )
                        s = next
                    }
                }
            }
        }

        // AI may negotiate at any point of the season, but most teams do not shop
        // aggressively every week. This is an activity probability, not a transfer cap.
        teams.shuffled(Random(seed + season * 37 + currentWeek)).forEach { team ->
            val rosterNow = roster(s, team.id, season = season)
            val expiringCount = rosterNow.count { id ->
                s.contracts.firstOrNull { it.driverId == id }?.let { it.seasonSigned + it.years - 1 == season } == true
            }
            val weakestOverall = rosterNow.minOfOrNull { currentDriverOverall(it, driverAttributes) } ?: 0
            val currentTeamStrength = teamSportingStrength(team.id, teamChampionshipPoints)
            val activityChance = when {
                rosterNow.size < 2 -> 100
                expiringCount > 0 -> 82
                weakestOverall <= 63 -> 35
                weakestOverall <= 70 -> 22
                currentTeamStrength >= 80 && weakestOverall < 82 -> 25
                else -> 3
            }
            if (rng.nextInt(100) >= activityChance) return@forEach

            val candidates = (freeAgents(s).filter { canReceiveProposals(s, it, season) } +
                s.contracts.filter { it.teamId != team.id && canReceiveProposals(s, it.driverId, season) }.map { it.driverId })
                .distinct()

            val expiringIds = rosterNow.filter { id ->
                s.contracts.firstOrNull { it.driverId == id && it.teamId == team.id }?.let { it.seasonSigned + it.years - 1 == season } == true
            }
            // Prefer the actual expiring seat. Only target a multi-year incumbent when
            // the prospect is a major upgrade; a routine market tick must not void deals.
            val replacementCandidates = if (expiringIds.isNotEmpty()) expiringIds else rosterNow
            val replacement = if (rosterNow.size >= 2) {
                replacementCandidates.minWithOrNull(compareBy<Int> { currentDriverOverall(it, driverAttributes) }
                    .thenBy { currentMarketValue(it, driverAttributes) })
            } else null
            val replacementIsExpiring = replacement != null && expiringIds.contains(replacement)

            val candidate = candidates.shuffled(Random(seed + team.id * 71 + currentWeek)).maxByOrNull { id ->
                val preferredRole = preferredRoleFor(s, id, team.id, season)
                val salaryBenchmark = maxOf(currentSalaryValue(id, driverAttributes), s.contracts.firstOrNull { it.driverId == id && it.activeIn(season) }?.salary ?: 0L)
                val offeredSalary = (salaryBenchmark * (1.02 + rng.nextDouble() * 0.16)).roundToLong()
                val replacementOverall = replacement?.let { currentDriverOverall(it, driverAttributes) } ?: 0
                val improvement = currentDriverOverall(id, driverAttributes) - replacementOverall
                val upgradeWeight = if (replacement == null) 0 else improvement * if (teamSportingStrength(team.id, teamChampionshipPoints) >= 78) 3 else 2
                interestScore(s, id, team.id, offeredSalary, preferredRole, season, teamChampionshipPoints, driverAttributes, driverChampionshipPoints) +
                    currentMarketValue(id, driverAttributes) / 5_000_000 + upgradeWeight
            } ?: return@forEach

            // Avoid meaningless churn: a complete team should normally move only
            // when the target is a clear sporting/economic upgrade. This is not a
            // transfer cap: an exceptional opportunity can still trigger a move.
            if (replacement != null) {
                val replacementDeal = s.contracts.firstOrNull { it.driverId == replacement }
                val candidateOverall = currentDriverOverall(candidate, driverAttributes)
                val replacementOverall = currentDriverOverall(replacement, driverAttributes)
                val candidateValue = currentMarketValue(candidate, driverAttributes)
                val replacementValue = currentMarketValue(replacement, driverAttributes)
                val candidateBenchmark = maxOf(currentSalaryValue(candidate, driverAttributes), s.contracts.firstOrNull { it.driverId == candidate && it.activeIn(season) }?.salary ?: 0L)
                val candidateInterest = interestScore(s, candidate, team.id, (candidateBenchmark * 1.15).roundToLong(),
                    preferredRoleFor(s, candidate, team.id, season), season, teamChampionshipPoints, driverAttributes, driverChampionshipPoints)
                val replacementInterest = replacementDeal?.let {
                    interestScore(s, replacement, team.id, it.salary, it.role, season, teamChampionshipPoints, driverAttributes, driverChampionshipPoints)
                } ?: 50
                val sportingGain = candidateOverall - replacementOverall
                val economicPremium = candidateValue - replacementValue
                val strength = teamSportingStrength(team.id, teamChampionshipPoints)
                val requiredGain = when { strength >= 80 -> 4; strength >= 65 -> 2; else -> 0 }
                val clearUpgrade = sportingGain >= requiredGain && (sportingGain >= 3 || candidateInterest >= replacementInterest + 8)
                val evolution = WorldDatabase.allDrivers.firstOrNull { it.id == candidate }?.evolution?.lowercase().orEmpty()
                val highPotentialBet = sportingGain >= -2 && candidateInterest >= 76 && evolution in setOf("prodígio", "prodigio", "auge rápido", "auge rapido")
                val eliteUpgrade = candidateOverall >= replacementOverall + 8 && candidateInterest >= 70
                val multiYearBreakout = !replacementIsExpiring && (
                    candidateOverall >= replacementOverall + 12 ||
                    (candidateOverall >= replacementOverall + 9 && candidateInterest >= 84 && replacementOverall <= 68)
                )
                val fallbackNearWindowEnd = replacementIsExpiring && currentWeek >= 48 &&
                    candidateOverall >= replacementOverall - 2 && candidateInterest >= 52
                val eligibleMove = if (replacementIsExpiring) {
                    clearUpgrade || highPotentialBet || eliteUpgrade || fallbackNearWindowEnd
                } else {
                    multiYearBreakout && (clearUpgrade || eliteUpgrade) && (candidateInterest >= 70 || candidateOverall >= replacementOverall + 12)
                }
                if (!eligibleMove) return@forEach
                if (economicPremium < 0 && sportingGain < requiredGain + 2 && candidateInterest < 75) return@forEach
            }

            val role = preferredRoleFor(s, candidate, team.id, season)
            val salaryBenchmark = maxOf(currentSalaryValue(candidate, driverAttributes), s.contracts.firstOrNull { it.driverId == candidate && it.activeIn(season) }?.salary ?: 0L)
            val salary = (salaryBenchmark * (0.98 + rng.nextDouble() * 0.20)).roundToLong().coerceAtLeast(500_000L)
            val candidateDeal = s.contracts.firstOrNull { it.driverId == candidate && it.activeIn(season) }
            // When an AI team approaches a driver belonging to the player's team,
            // this is an incoming proposal. It must wait for the manager's decision.
            if (candidateDeal?.teamId == playerTeamId) {
                // Várias equipes podem disputar o mesmo piloto simultaneamente.
                // Não bloquear uma nova proposta apenas porque já existe outra negociação.
                val responseDelay = if (rng.nextBoolean()) 2 else 3
                val incoming = DriverOffer(
                    candidate, playerTeamId, team.id, chooseAiYears(candidate, season, currentWeek), salary, role,
                    currentMarketValue(candidate, driverAttributes), interestScore(s, candidate, team.id, salary, role, season, teamChampionshipPoints, driverAttributes, driverChampionshipPoints),
                    1, currentWeek + responseDelay, NegotiationStatus.PENDING, season + 1, replacement, team.id
                )
                s = s.copy(
                    pending = (s.pending + incoming).takeLast(100),
                    notifications = s.notifications + MarketNotification(
                        season, currentWeek, "PROPOSTA RECEBIDA",
                        "A ${teamName(team.id)} fez uma proposta por ${driverName(candidate)} para ${season + 1}.", true)
                )
                return@forEach
            }
            runCatching {
                val (next, _) = makeOffer(
                    s, candidate, team.id, chooseAiYears(candidate, season, currentWeek),
                    salary, role, season, currentWeek, 1, replacement, team.id,
                    teamChampionshipPoints, driverAttributes, driverChampionshipPoints
                )
                s = next
            }.onFailure { /* one failed AI negotiation never breaks the market tick */ }
        }
        return s.normalized()
    }

    // There is intentionally no global renewal/transfer quota. Each AI team compares
    // the sporting and financial value of its own roster moves independently.

    private fun preferredRoleFor(state: DriverMarketState, driverId: Int, teamId: Int, season: Int): DriverTeamRole {
        return when (state.rolePreferences[driverId]) {
            DriverRolePreference.DEMANDS_PILOT_1, DriverRolePreference.PREFERS_PILOT_1 -> DriverTeamRole.PILOT_1
            DriverRolePreference.PREFERS_EQUALITY -> DriverTeamRole.EQUAL
            DriverRolePreference.INDIFFERENT, null -> {
                if (roster(state, teamId, season = season).isEmpty()) DriverTeamRole.PILOT_1 else DriverTeamRole.PILOT_2
            }
        }
    }

    private fun renewalEvaluationKey(season: Int, teamId: Int, driverId: Int): String = "$season:$teamId:$driverId"

    private fun chooseAiYears(driverId: Int, season: Int, week: Int): Int {
        val roll = (seed + driverId * 17 + season * 13 + week) % 100
        return when {
            roll < 50 -> 1
            roll < 88 -> 2
            else -> 3
        }
    }

    fun runAiOffseason(
        state: DriverMarketState, season: Int, teamBudget: Map<Int, Long>, playerTeamId: Int? = null,
        teamChampionshipPoints: Map<Int, Int> = emptyMap(), driverAttributes: Map<Int, List<Int>> = emptyMap(),
        driverChampionshipPoints: Map<Int, Int> = emptyMap()
    ): DriverMarketState = applySeasonTransition(state, season, teamBudget, playerTeamId, teamChampionshipPoints, driverAttributes, driverChampionshipPoints)

    fun applySeasonTransition(
        state: DriverMarketState, newSeason: Int, teamBudgets: Map<Int,Long> = emptyMap(), playerTeamId: Int? = null,
        teamChampionshipPoints: Map<Int, Int> = emptyMap(), driverAttributes: Map<Int, List<Int>> = emptyMap(),
        driverChampionshipPoints: Map<Int, Int> = emptyMap()
    ): DriverMarketState {
        var s = state
        // Only a contract signed by the driver can move a pilot at the season boundary.
        // An unrelated incumbent is never removed merely to make an incoming deal fit.
        val due = s.scheduled.filter { it.startSeason <= newSeason }
        due.forEach { move ->
            if (s.scheduled.none { it.driverId == move.driverId && it.startSeason == move.startSeason && it.toTeamId == move.toTeamId }) return@forEach
            val currentContract = s.contracts.firstOrNull { it.driverId == move.driverId }
            val destinationRoster = s.contracts.filter { it.teamId == move.toTeamId && it.activeIn(newSeason) }
            val replacement = move.replaceDriverId?.let { id ->
                s.contracts.firstOrNull { it.driverId == id && it.teamId == move.toTeamId && it.activeIn(newSeason) }
            }
            val destinationHasRoom = destinationRoster.size < 2 || replacement != null
            if (!destinationHasRoom) {
                val reason = "Transferência de ${driverName(move.driverId)} para ${teamName(move.toTeamId)} cancelada: as duas vagas futuras estão ocupadas e não existe substituição válida."
                s = s.copy(
                    scheduled = s.scheduled.filterNot { it.driverId == move.driverId },
                    pending = s.pending.filterNot { it.driverId == move.driverId && it.seasonTarget == newSeason },
                    freeAgents = if (currentContract == null || !currentContract.activeIn(newSeason)) (s.freeAgents + move.driverId).distinct() else s.freeAgents,
                    notifications = s.notifications + MarketNotification(newSeason, 1, "TRANSFERÊNCIA CANCELADA", reason, true),
                    history = s.history + reason
                )
                return@forEach
            }
            val releasedIds = buildSet {
                add(move.driverId)
                replacement?.let { add(it.driverId) }
            }
            val oldTeam = currentContract?.teamId
            val deal = DriverDeal(move.driverId, move.toTeamId, move.years, move.salary, currentMarketValue(move.driverId, driverAttributes), newSeason, move.role)
            s = s.copy(
                contracts = s.contracts.filterNot { it.driverId in releasedIds } + deal,
                scheduled = s.scheduled.filterNot { it.driverId == move.driverId },
                freeAgents = (s.freeAgents - move.driverId + listOfNotNull(replacement?.driverId).filter { it != move.driverId }).distinct(),
                pending = s.pending.filterNot { it.driverId == move.driverId && it.seasonTarget == newSeason },
                notifications = s.notifications + MarketNotification(newSeason, 1, "TRANSFERÊNCIA CONFIRMADA", "${driverName(move.driverId)} agora é piloto da ${teamName(move.toTeamId)} após contrato aceito.", true),
                history = s.history + "Transferência assinada de ${driverName(move.driverId)} executada para ${teamName(move.toTeamId)}${oldTeam?.let { " (origem ${teamName(it)})" } ?: ""}"
            ).normalized()
        }
        s = resolveExpiredAndVacancies(s, newSeason, teamBudgets, playerTeamId, teamChampionshipPoints, driverAttributes, driverChampionshipPoints)
        s = s.copy(pending = s.pending.filter { it.seasonTarget > newSeason }).normalized()
        return s.normalized()
    }

    fun scout(
        state: DriverMarketState,
        driverId: Int,
        teamId: Int,
        currentWeek: Int,
        season: Int = 2026,
        scoutingFacilityLevel: Int = 0
    ): Pair<DriverMarketState, ScoutingReport> {
        require(driverId in allIds) { "Piloto inexistente" }
        val value=marketValueFor(driverId)
        val d = WorldDatabase.allDrivers.first { it.id == driverId }
        val attrs = listOf(d.speed,d.qualifying,d.overtaking,d.defense,d.consistency,d.wet,d.tyre)
        // Scouting facility now affects the precision of the persisted report.
        val precision = FacilityEngine.scoutingPrecision(
            TeamFacilitiesState().withLevel(FacilityType.SCOUTING, scoutingFacilityLevel)
        )
        val margin = ((100 - precision) / 8).coerceIn(0,10)
        val ranges = attrs.joinToString("|") { v -> if (margin == 0) "$v-$v" else "${(v-margin).coerceAtLeast(40)}-${(v+margin).coerceAtMost(100)}" }
        val report=ScoutingReport(driverId,teamId,500_000L,currentWeek,56,salaryFor(driverId),value,state.rolePreferences[driverId] ?: DriverRolePreference.INDIFFERENT,interestScore(state,driverId,teamId,salaryFor(driverId),DriverTeamRole.EQUAL,season),season,ranges)
        return state.copy(scouting=(state.scouting.filterNot { it.driverId==driverId && it.teamId==teamId && it.season==season }+report).takeLast(200),history=state.history+"Scouting concluído: ${driverName(driverId)}") to report
    }

    fun marketSummary(state: DriverMarketState, season: Int): String = "Mercado ${if (marketOpen(SeasonCalendar.forSeason(season).maxOfOrNull { it.weekOfSeason } ?: 56, season)) "aberto" else "fechado"} | Contratados: ${state.contracts.count { it.activeIn(season) }} | Livres: ${freeAgents(state).size} | Propostas: ${state.pending.count { it.seasonTarget == season + 1 }} | Transferências: ${state.scheduled.count { it.startSeason == season + 1 }}"

    private fun resolveExpiredAndVacancies(
        input: DriverMarketState,
        season: Int,
        budgets: Map<Int, Long>,
        playerTeamId: Int? = null,
        teamChampionshipPoints: Map<Int, Int> = emptyMap(),
        driverAttributes: Map<Int, List<Int>> = emptyMap(),
        driverChampionshipPoints: Map<Int, Int> = emptyMap()
    ): DriverMarketState {
        var s = input
        val remainingBudgets = WorldDatabase.teams.associate { team ->
            team.id to (budgets[team.id] ?: InitialTeamProfile.initialBudget(team).coerceAtLeast(0L))
        }.toMutableMap()

        // Let expired contracts become free agents first; never keep a stale roster seat.
        s.contracts.filter { !it.activeIn(season) }.forEach { deal ->
            s = s.copy(
                contracts = s.contracts.filterNot { it.driverId == deal.driverId },
                freeAgents = (s.freeAgents + deal.driverId).distinct(),
                history = s.history + "Contrato de ${driverName(deal.driverId)} encerrado ao fim da temporada ${season - 1}"
            ).normalized()
        }

        // The player controls their own roster. The game must not secretly assign a driver
        // to the player's team; the season-change UI blocks the boundary until vacancies
        // are resolved by a contract the player actually accepted.
        for (team in WorldDatabase.teams.filter { it.id != playerTeamId }) {
            val attempted = mutableSetOf<Int>()
            var attempts = 0
            while (s.rosterCount(team.id, season) < 2 && attempts < WorldDatabase.allDrivers.size) {
                attempts++
                val budget = remainingBudgets[team.id] ?: 0L
                val candidates = freeAgents(s).filter { it !in attempted && s.scheduled.none { scheduled -> scheduled.driverId == it } }
                    .sortedWith(compareByDescending<Int> { id ->
                        interestScore(s, id, team.id, currentSalaryValue(id, driverAttributes), preferredRoleFor(s, id, team.id, season), season, teamChampionshipPoints, driverAttributes, driverChampionshipPoints)
                    }.thenByDescending { id -> currentDriverOverall(id, driverAttributes) })
                if (candidates.isEmpty()) break

                var signedDeal: FutureDriverDeal? = null
                var selectedDriver: Int? = null
                var consumedFee = 0L
                candidateLoop@ for (candidate in candidates) {
                    attempted += candidate
                    val fee = (currentMarketValue(candidate, driverAttributes) * 0.20).roundToLong()
                    if (fee > budget) continue
                    val responseSeason = season - 1
                    val role = if (s.rosterCount(team.id, season) == 0) DriverTeamRole.PILOT_1 else DriverTeamRole.PILOT_2
                    val salaryReference = maxOf(currentSalaryValue(candidate, driverAttributes), s.contracts.firstOrNull { it.driverId == candidate }?.salary ?: 0L)
                    // Escalate through explicit offers: a difficult market can cost dearly,
                    // but only a driver acceptance (or a counter accepted by the team) signs.
                    val salaryMultipliers = listOf(1.05, 1.25, 1.55, 1.90, 2.35, 2.90, 3.55, 4.25)
                    for ((tier, multiplier) in salaryMultipliers.withIndex()) {
                        val salary = (salaryReference * multiplier).roundToLong().coerceAtLeast(500_000L)
                        val proposed = runCatching {
                            makeOffer(
                                s, candidate, team.id, 1, salary, role, responseSeason,
                                currentWeek = 53, round = (tier + 1).coerceIn(1, 3), replaceDriverId = null,
                                proposerTeamId = team.id, teamChampionshipPoints = teamChampionshipPoints,
                                driverAttributes = driverAttributes, driverChampionshipPoints = driverChampionshipPoints
                            )
                        }.getOrNull() ?: continue
                        s = proposed.first
                        val offer = proposed.second
                        s = expireOffers(s, offer.expiresAfterWeek, responseSeason, playerTeamId = playerTeamId,
                            onlyDriverId = candidate, onlyTeamId = team.id)
                        var signed = s.scheduled.firstOrNull { it.driverId == candidate && it.toTeamId == team.id && it.startSeason == season }
                        if (signed == null) {
                            // If the driver counters, the AI must explicitly decide whether
                            // the demanded terms are financially reasonable before signing.
                            val counter = s.pending.firstOrNull {
                                it.driverId == candidate && it.toTeamId == team.id && it.seasonTarget == season && it.status == NegotiationStatus.COUNTER
                            }
                            val salaryCeiling = (salaryReference * 4.75).roundToLong()
                            if (counter != null && counter.salary <= salaryCeiling) {
                                val acceptedCounter = counter.copy(status = NegotiationStatus.ACCEPTED)
                                s = runCatching { signFuture(s, acceptedCounter, responseSeason) }.getOrElse { s }
                                signed = s.scheduled.firstOrNull { it.driverId == candidate && it.toTeamId == team.id && it.startSeason == season }
                                if (signed != null) {
                                    s = s.copy(notifications = s.notifications + MarketNotification(
                                        responseSeason, 56, "CONTRAPROPOSTA ACEITA PELA IA",
                                        "A ${team.name} aceitou as condições de ${driverName(candidate)} para preencher a vaga da próxima temporada.", true
                                    ), pending = s.pending.filterNot { it.driverId == candidate && it.seasonTarget == season })
                                }
                            }
                        }
                        if (signed != null) {
                            signedDeal = signed
                            selectedDriver = candidate
                            consumedFee = fee
                            break@candidateLoop
                        }
                        s = s.copy(pending = s.pending.filterNot {
                            it.driverId == candidate && it.toTeamId == team.id && it.seasonTarget == season
                        }).normalized()
                    }
                    if (signedDeal != null) break
                }

                val signed = signedDeal
                val driverId = selectedDriver
                if (signed == null || driverId == null) {
                    val reason = "${team.name} terminou a janela sem acordo para a vaga restante; nenhum piloto foi atribuído sem aceitar um contrato."
                    s = s.copy(
                        notifications = s.notifications + MarketNotification(season, 1, "VAGA DE PILOTO EM ABERTO", reason, true),
                        history = s.history + reason
                    ).normalized()
                    break
                }
                // The accepted offer was already recorded in the future-contract ledger.
                // Apply it to the new season without fabricating a direct assignment.
                val destinationCount = s.rosterCount(team.id, season)
                if (destinationCount >= 2) {
                    val reason = "Contrato aceito de ${driverName(driverId)} não aplicado: ${team.name} já possui duas vagas válidas."
                    s = s.copy(scheduled = s.scheduled.filterNot { it.driverId == driverId }, notifications = s.notifications + MarketNotification(season, 1, "CONTRATO NÃO APLICADO", reason, true), history = s.history + reason)
                    break
                }
                s = s.copy(
                    contracts = s.contracts.filterNot { it.driverId == driverId } + DriverDeal(
                        driverId, team.id, signed.years, signed.salary, currentMarketValue(driverId, driverAttributes), season, signed.role
                    ),
                    scheduled = s.scheduled.filterNot { it.driverId == driverId },
                    pending = s.pending.filterNot { it.driverId == driverId && it.seasonTarget <= season },
                    freeAgents = s.freeAgents - driverId,
                    notifications = s.notifications + MarketNotification(
                        season, 1, "CONTRATO ACEITO NA PRÉ-TEMPORADA",
                        "${driverName(driverId)} aceitou uma proposta da ${team.name} para a temporada $season.", true
                    ),
                    history = s.history + "Contrato aceito de ${driverName(driverId)} para ${team.name} na virada da temporada (taxa de assinatura $consumedFee)"
                ).normalized()
                remainingBudgets[team.id] = (remainingBudgets[team.id] ?: 0L) - consumedFee
            }
        }
        return s.normalized()
    }

    private fun DriverMarketState.rosterCount(teamId:Int,season:Int)=contracts.count { it.teamId==teamId && it.activeIn(season) }
    private fun roleCompatible(state: DriverMarketState, teamId:Int, driverId:Int, role:DriverTeamRole, season:Int, replacingDriverId:Int?=null):Boolean {
        if (role != DriverTeamRole.PILOT_1) return true
        return state.contracts.none { it.teamId==teamId && it.activeIn(season) && it.driverId != (replacingDriverId ?: driverId) && it.role==DriverTeamRole.PILOT_1 }
    }
    private fun overall(d: com.f1teammanager.core.season.DriverDefinition):Int = (d.speed+d.qualifying+d.overtaking+d.defense+d.consistency+d.wet+d.tyre)/7
    private fun currentDriverOverall(driverId: Int, attributes: Map<Int,List<Int>>): Int {
        val live = attributes[driverId]?.takeIf { it.size == 7 }
        if (live != null) return live.sum() / live.size
        return WorldDatabase.allDrivers.firstOrNull { it.id == driverId }?.let(::overall) ?: 50
    }
    private fun currentSalaryValue(driverId: Int, attributes: Map<Int, List<Int>>): Long {
        val definition = WorldDatabase.allDrivers.firstOrNull { it.id == driverId } ?: return 500_000L
        val baseOverall = overall(definition).coerceAtLeast(1)
        return (salaryFor(driverId).toDouble() * currentDriverOverall(driverId, attributes) / baseOverall)
            .roundToLong().coerceIn(300_000L, 60_000_000L)
    }
    private fun currentMarketValue(driverId: Int, attributes: Map<Int,List<Int>>): Long {
        val definition = WorldDatabase.allDrivers.firstOrNull { it.id == driverId } ?: return 500_000L
        val baseOverall = overall(definition).coerceAtLeast(1)
        return (marketValueFor(driverId).toDouble() * currentDriverOverall(driverId, attributes) / baseOverall)
            .roundToLong().coerceIn(500_000L, 100_000_000L)
    }
    private fun teamSportingStrength(teamId: Int, points: Map<Int,Int>): Int {
        val team = WorldDatabase.teams.first { it.id == teamId }
        val base = InitialTeamProfile.strength(team)
        if (points.values.none { it > 0 }) return base
        val currentPoints = points[teamId] ?: 0
        val rank = WorldDatabase.teams.count { (points[it.id] ?: 0) > currentPoints } + 1
        val rankRating = (100 - ((rank - 1) * 65.0 / (WorldDatabase.teams.size - 1).coerceAtLeast(1))).roundToLong().toInt()
        // Start with team reputation, but let results in this career materially reshape its pull.
        return (base * 0.55 + rankRating * 0.45).roundToLong().toInt().coerceIn(25,100)
    }
    /** Effective current-season sporting pull, combining reputation and championship position. */
    fun sportingStrengthForMarket(teamId: Int, teamChampionshipPoints: Map<Int, Int> = emptyMap()): Int =
        teamSportingStrength(teamId, teamChampionshipPoints)

    /** Live overall is exposed for deterministic regression tests and market diagnostics. */
    fun driverOverallForMarket(driverId: Int, driverAttributes: Map<Int, List<Int>> = emptyMap()): Int =
        currentDriverOverall(driverId, driverAttributes)

    private fun offerAttractiveness(offer: DriverOffer): Int = (offer.interestScore * 0.78 + offer.years.coerceIn(1,5) * 1.2 + when (offer.role) {
        DriverTeamRole.PILOT_1 -> 4
        DriverTeamRole.EQUAL -> 3
        DriverTeamRole.PILOT_2 -> 0
    }).roundToLong().toInt()
    private fun teamPrestige(teamId:Int)=InitialTeamProfile.strength(WorldDatabase.teams.first { it.id==teamId })
    private fun teamRecentPerformance(teamId:Int, points: Map<Int,Int>)=teamSportingStrength(teamId, points)
    private fun teamHistory(teamId:Int)=InitialTeamProfile.strength(WorldDatabase.teams.first { it.id==teamId })
    private fun driverName(id:Int)=WorldDatabase.allDrivers.firstOrNull { it.id==id }?.name ?: "Piloto $id"
    private fun teamName(id:Int)=WorldDatabase.teams.firstOrNull { it.id==id }?.name ?: "Equipe $id"
}
