package com.f1teammanager.core.manager

import com.f1teammanager.core.season.WorldDatabase
import com.f1teammanager.core.season.SeasonCalendar
import kotlin.math.roundToLong
import kotlin.random.Random

/** Stage 3: driver market. Transfers are future-season commitments; the current grid never changes mid-season. */
class DriverMarketEngine(private val seed: Int = 20261003) {
    private val allIds = WorldDatabase.allDrivers.map { it.id }.toSet()

    fun initialState(season: Int = 2026): DriverMarketState {
        val contracts = WorldDatabase.drivers.map { d ->
            val value = marketValueFor(d.id)
            val years = if (d.id <= 44) 2 else 1
            DriverDeal(d.id, d.teamId, years, salaryFor(d.id), value, season, role = DriverTeamRole.EQUAL)
        }
        val prefs = WorldDatabase.allDrivers.associate { it.id to DriverRolePreference.INDIFFERENT }
        val free = WorldDatabase.allDrivers.map { it.id }.filter { id -> contracts.none { it.driverId == id } }
        return DriverMarketState(contracts=contracts, freeAgents=free, rolePreferences=prefs).normalized()
    }

    fun salaryFor(driverId: Int): Long {
        val d = WorldDatabase.allDrivers.firstOrNull { it.id == driverId } ?: return 500_000L
        val overall = overall(d)
        val classBonus = when (d.driverClass.lowercase()) {
            "lenda" -> 18_000_000L
            "pro" -> 9_000_000L
            "forte" -> 4_000_000L
            "médio", "medio" -> 1_500_000L
            else -> 0L
        }
        val evolutionBonus = when (d.evolution.lowercase()) {
            "prodígio", "prodigio" -> 2_500_000L
            "auge rápido", "auge rapido" -> 1_800_000L
            "auge moderado", "auge tardio" -> 1_200_000L
            else -> 0L
        }
        return (500_000L + overall * 380_000L + classBonus + evolutionBonus).coerceIn(500_000L, 70_000_000L)
    }

    fun marketValueFor(driverId: Int): Long {
        val d = WorldDatabase.allDrivers.firstOrNull { it.id == driverId } ?: return 500_000L
        val base = overall(d) * 500_000L
        val classMultiplier = when (d.driverClass.lowercase()) {
            "lenda" -> 1.65; "pro" -> 1.35; "forte" -> 1.15; "médio", "medio" -> 0.90; else -> 0.70
        }
        val evolutionMultiplier = when (d.evolution.lowercase()) {
            "prodígio", "prodigio" -> 1.25; "auge rápido", "auge rapido" -> 1.15; "auge moderado", "auge tardio" -> 1.10; "demorado" -> 0.90; else -> 1.0
        }
        return (base * classMultiplier * evolutionMultiplier).roundToLong().coerceIn(500_000L, 80_000_000L)
    }

    fun roster(state: DriverMarketState, teamId: Int, includeScheduled: Boolean = false, season: Int = 2026): List<Int> {
        val current = state.contracts.filter { it.teamId == teamId && it.activeIn(season) }.map { it.driverId }
        if (!includeScheduled) return current
        return (current + state.scheduled.filter { it.toTeamId == teamId && it.startSeason == season }.map { it.driverId }).distinct()
    }

    fun freeAgents(state: DriverMarketState): List<Int> = state.freeAgents.filter { id -> state.contracts.none { it.driverId == id } && state.scheduled.none { it.driverId == id } }

    fun expiring(state: DriverMarketState, season: Int): List<DriverDeal> = state.contracts.filter { it.seasonSigned + it.years <= season }

    fun canReceiveProposals(state: DriverMarketState, driverId: Int, season: Int): Boolean {
        if (state.scheduled.any { it.driverId == driverId }) return false
        val deal = state.contracts.firstOrNull { it.driverId == driverId } ?: return driverId in state.freeAgents
        return deal.canReceiveProposals(season)
    }

    fun interestScore(state: DriverMarketState, driverId: Int, toTeamId: Int, salary: Long, role: DriverTeamRole, season: Int): Int {
        val d = WorldDatabase.allDrivers.first { it.id == driverId }
        val team = WorldDatabase.teams.first { it.id == toTeamId }
        val car = team.baseCar.coerceIn(1,100)
        val salaryScore = (salary.toDouble() / salaryFor(driverId) * 20.0).roundToLong().toInt().coerceIn(0,20)
        val rolePref = state.rolePreferences[driverId] ?: DriverRolePreference.INDIFFERENT
        val roleScore = when (rolePref) {
            DriverRolePreference.DEMANDS_PILOT_1 -> if (role == DriverTeamRole.PILOT_1) 10 else -18
            DriverRolePreference.PREFERS_PILOT_1 -> if (role == DriverTeamRole.PILOT_1) 7 else 0
            DriverRolePreference.PREFERS_EQUALITY -> if (role == DriverTeamRole.EQUAL) 7 else 0
            DriverRolePreference.INDIFFERENT -> 5
        }
        val prestige = teamPrestige(toTeamId)
        val project = ((team.baseCar + prestige) / 2)
        val recent = teamRecentPerformance(toTeamId)
        val current = state.contracts.firstOrNull { it.driverId == driverId }
        val retention = if (current?.teamId == toTeamId) 10 else 0
        val score = (car * .25 + salaryScore + prestige * .15 + project * .15 + roleScore + recent * .10 + teamHistory(toTeamId) * .05 + retention).roundToLong().toInt()
        return score.coerceIn(0,100)
    }

    /** Compatibility entry point for the previous V9 engine. It now creates a future-season offer instead of moving the driver immediately. */
    fun offer(state: DriverMarketState, driverId: Int, fromTeamId: Int, toTeamId: Int, years: Int, salary: Long,
              teamStrength: Int = 70, reputation: Int = 50, season: Int = 2026, rngSeed: Int = seed): Pair<DriverMarketState, DriverOffer> =
        makeOffer(state, driverId, toTeamId, years.coerceIn(1,5), salary, DriverTeamRole.EQUAL, season)

    fun makeOffer(
        state: DriverMarketState, driverId: Int, toTeamId: Int, years: Int, salary: Long,
        role: DriverTeamRole, season: Int, currentWeek: Int = 1, round: Int = 1, replaceDriverId: Int? = null, proposerTeamId: Int? = null
    ): Pair<DriverMarketState, DriverOffer> {
        require(driverId in allIds) { "Piloto inexistente" }
        require(toTeamId in WorldDatabase.teams.map { it.id }) { "Equipe inexistente" }
        require(marketOpen(currentWeek, season)) { "O mercado de pilotos abre somente após 8 corridas realizadas" }
        require(years in 1..5) { "O contrato deve ter entre 1 e 5 anos" }
        require(canReceiveProposals(state, driverId, season)) { "Este piloto não está disponível para propostas nesta temporada" }
        val destinationRoster = roster(state, toTeamId, season = season)
        if (destinationRoster.size >= 2 && state.contracts.none { it.driverId == driverId && it.teamId == toTeamId }) {
            require(replaceDriverId != null && replaceDriverId in destinationRoster) { "A equipe já possui 2 pilotos; escolha qual piloto será substituído" }
            require(state.scheduled.none { it.toTeamId == toTeamId && it.replaceDriverId == replaceDriverId }) { "Esse piloto já está reservado para outra contratação futura; selecione o outro piloto" }
        }
        require(state.scheduled.none { it.driverId == driverId }) { "Piloto já possui transferência futura" }
        // Um piloto pode negociar simultaneamente com várias equipes.
        // A negociação é individual por equipe; somente uma transferência futura
        // efetivamente assinada encerra as demais negociações do piloto.
        val current = state.contracts.firstOrNull { it.driverId == driverId }
        val from = current?.teamId ?: 0
        val proposer = proposerTeamId ?: toTeamId
        val value = marketValueFor(driverId)
        val score = interestScore(state, driverId, toTeamId, salary, role, season)
        val rng = Random(seed + driverId * 31 + toTeamId * 17 + round * 13 + currentWeek * 7)
        val responseDelay = if (rng.nextBoolean()) 2 else 3
        val normalizedRound = round.coerceIn(1, 3)
        val offer = DriverOffer(
            driverId, from, toTeamId, years.coerceIn(1, 5), salary.coerceAtLeast(100_000L), role,
            value, (score + rng.nextInt(-4, 5)).coerceIn(0, 100), normalizedRound,
            currentWeek + responseDelay, NegotiationStatus.PENDING, season + 1, replaceDriverId, proposer
        )
        val next = state.copy(
            pending = (state.pending.filterNot {
                it.driverId == driverId && it.toTeamId == toTeamId && it.seasonTarget == season + 1 && it.round == normalizedRound
            } + offer).takeLast(100),
            notifications = state.notifications + MarketNotification(
                season, currentWeek, "PROPOSTA ENVIADA",
                "A ${teamName(toTeamId)} fez uma proposta por ${driverName(driverId)}. O piloto responderá em ${responseDelay} semanas.",
                true
            )
        )
        return next.normalized() to offer
    }

    /** Processes proposals whose driver-response deadline has arrived. Responses take 2 or 3 calendar weeks. */
    fun expireOffers(state: DriverMarketState, currentWeek: Int, season: Int = 0): DriverMarketState {
        val due = state.pending.filter { it.status == NegotiationStatus.PENDING && it.expiresAfterWeek <= currentWeek }
        if (due.isEmpty()) return state
        var s = state
        due.forEach { offer ->
            val rng = Random(seed + season * 997 + currentWeek * 31 + offer.driverId * 41 + offer.toTeamId * 17 + offer.round * 13)
            val base = offer.interestScore
            val adjusted = (base + rng.nextInt(-6, 7)).coerceIn(0, 100)
            val decision = when {
                adjusted >= 78 -> NegotiationStatus.ACCEPTED
                adjusted >= 52 -> NegotiationStatus.COUNTER
                else -> NegotiationStatus.REJECTED
            }
            val demandedSalary = if (decision == NegotiationStatus.COUNTER)
                (offer.salary * (1.06 + rng.nextDouble() * 0.10)).roundToLong() else offer.salary
            val demandedYears = if (decision == NegotiationStatus.COUNTER && rng.nextInt(100) >= 65) (1..5).random(rng) else offer.years
            val demandedRole = if (decision == NegotiationStatus.COUNTER) {
                when (s.rolePreferences[offer.driverId]) {
                    DriverRolePreference.DEMANDS_PILOT_1 -> DriverTeamRole.PILOT_1
                    DriverRolePreference.PREFERS_EQUALITY -> DriverTeamRole.EQUAL
                    else -> offer.role
                }
            } else offer.role
            val response = offer.copy(
                years = demandedYears, salary = demandedSalary.coerceAtLeast(100_000L), role = demandedRole,
                interestScore = adjusted, status = decision, expiresAfterWeek = currentWeek
            )
            s = s.copy(pending = s.pending.filterNot { sameNegotiation(it, offer) })
            when (decision) {
                NegotiationStatus.ACCEPTED -> {
                    runCatching {
                        s = signFuture(s, response, season)
                        s = s.copy(notifications = s.notifications + MarketNotification(
                            season, currentWeek, "RESPOSTA DO PILOTO",
                            "${driverName(offer.driverId)} aceitou a proposta da ${teamName(offer.toTeamId)} para ${offer.seasonTarget}.", true
                        ))
                    }
                }
                NegotiationStatus.REJECTED -> {
                    s = s.copy(notifications = s.notifications + MarketNotification(
                        season, currentWeek, "RESPOSTA DO PILOTO",
                        "${driverName(offer.driverId)} recusou a proposta da ${teamName(offer.toTeamId)}.", true
                    ))
                }
                NegotiationStatus.COUNTER -> {
                    val counter = response.copy(expiresAfterWeek = currentWeek, status = NegotiationStatus.COUNTER)
                    s = s.copy(
                        pending = (s.pending + counter).takeLast(100),
                        notifications = s.notifications + MarketNotification(
                            season, currentWeek, "RESPOSTA DO PILOTO",
                            "${driverName(offer.driverId)} respondeu à proposta da ${teamName(offer.toTeamId)} com uma contraproposta.", true
                        )
                    )
                    // If the proposing team is AI, it decides automatically. If it is the player,
                    // the counter remains visible as an action card in the market screen.
                }
                else -> Unit
            }
        }
        return s.normalized()
    }

    private fun sameNegotiation(a: DriverOffer, b: DriverOffer): Boolean =
        a.driverId == b.driverId && a.toTeamId == b.toTeamId && a.seasonTarget == b.seasonTarget && a.round == b.round

    private fun resolveAiCounters(state: DriverMarketState, season: Int, currentWeek: Int, playerTeamId: Int): DriverMarketState {
        var s = state
        val counters = s.pending.filter { it.status == NegotiationStatus.COUNTER && it.proposerTeamId != 0 && it.proposerTeamId != playerTeamId }
        counters.forEach { offer ->
            if (s.pending.none { sameNegotiation(it, offer) && it.status == NegotiationStatus.COUNTER }) return@forEach
            val rng = Random(seed + season * 701 + currentWeek * 19 + offer.driverId * 29 + offer.toTeamId * 11 + offer.round * 43)
            val original = salaryFor(offer.driverId)
            val salaryRatio = offer.salary.toDouble() / original.coerceAtLeast(1L)
            val fit = interestScore(s, offer.driverId, offer.toTeamId, offer.salary, offer.role, season)
            val acceptScore = fit + if (salaryRatio <= 1.18) 8 else if (salaryRatio <= 1.28) 2 else -8
            val accept = acceptScore + rng.nextInt(-6, 7) >= if (offer.round >= 3) 56 else 64
            if (accept) {
                val accepted = offer.copy(status = NegotiationStatus.ACCEPTED)
                runCatching { s = signFuture(s, accepted, season) }
                s = s.copy(notifications = s.notifications + MarketNotification(
                    season, currentWeek, "DECISÃO DA EQUIPE",
                    "A ${teamName(offer.toTeamId)} aceitou a contraproposta de ${driverName(offer.driverId)}.", true
                ))
            } else if (offer.round < 3) {
                val nextSalary = (offer.salary * (0.97 + rng.nextDouble() * 0.04)).roundToLong().coerceAtLeast(500_000L)
                val nextRole = if (rng.nextInt(100) < 70) offer.role else preferredRoleFor(s, offer.driverId, offer.toTeamId, season)
                val cleaned = s.copy(pending = s.pending.filterNot { sameNegotiation(it, offer) })
                runCatching {
                    val (next, _) = counterOffer(cleaned, offer, season, currentWeek, nextSalary, offer.years, nextRole, offer.replaceDriverId)
                    s = next.copy(notifications = next.notifications + MarketNotification(
                        season, currentWeek, "CONTRAPROPOSTA DA EQUIPE",
                        "A ${teamName(offer.toTeamId)} fez uma nova contraproposta a ${driverName(offer.driverId)}. O piloto responderá em 2 ou 3 semanas.", true
                    ))
                }
            } else {
                s = s.copy(
                    pending = s.pending.filterNot { sameNegotiation(it, offer) },
                    notifications = s.notifications + MarketNotification(
                        season, currentWeek, "DECISÃO DA EQUIPE",
                        "A ${teamName(offer.toTeamId)} recusou a contraproposta final de ${driverName(offer.driverId)}.", true
                    )
                )
            }
        }
        return s.normalized()
    }

    /** Opens the next negotiation round using the player's new terms. Maximum 3 rounds. */
    fun counterOffer(
        state: DriverMarketState,
        previous: DriverOffer,
        season: Int,
        currentWeek: Int,
        salary: Long,
        years: Int,
        role: DriverTeamRole,
        replaceDriverId: Int? = null
    ): Pair<DriverMarketState, DriverOffer> {
        require(previous.status == NegotiationStatus.COUNTER) { "Esta negociação não está aguardando contraproposta" }
        require(previous.round < 3) { "A negociação já atingiu 3 rodadas" }
        require(previous.seasonTarget == season + 1) { "A proposta pertence a outra temporada" }
        require(state.pending.any { it.driverId == previous.driverId && it.toTeamId == previous.toTeamId && it.seasonTarget == previous.seasonTarget && it.round == previous.round && it.status == NegotiationStatus.COUNTER }) {
            "Esta contraproposta já não está ativa"
        }
        val cleaned = state.copy(pending = state.pending.filterNot {
            it.driverId == previous.driverId && it.toTeamId == previous.toTeamId &&
                it.seasonTarget == previous.seasonTarget && it.round == previous.round
        })
        return makeOffer(cleaned, previous.driverId, previous.toTeamId, years, salary, role, season, currentWeek, previous.round + 1, replaceDriverId, previous.proposerTeamId)
    }

    fun signFuture(state: DriverMarketState, offer: DriverOffer, season: Int, replaceDriverId: Int? = null): DriverMarketState {
        require(offer.status == NegotiationStatus.ACCEPTED) { "Somente uma proposta aceita pode gerar contrato futuro" }
        require(offer.seasonTarget == season + 1) { "A transferência deve começar na próxima temporada" }
        require(state.scheduled.none { it.driverId == offer.driverId }) { "Piloto já possui transferência futura" }
        val current = state.contracts.firstOrNull { it.driverId == offer.driverId }
        val future = FutureDriverDeal(offer.driverId, current?.teamId ?: 0, offer.toTeamId, offer.seasonTarget, offer.years, offer.salary, offer.role, season, offer.replaceDriverId ?: replaceDriverId)
        val cleanPending = state.pending.filterNot { it.driverId == offer.driverId && it.seasonTarget == offer.seasonTarget }
        return state.copy(pending=cleanPending, scheduled=state.scheduled + future,
            history=state.history + "${driverName(offer.driverId)} assinou com equipe ${offer.toTeamId} para ${offer.seasonTarget}")
    }

    fun acceptCounterOffer(state: DriverMarketState, offer: DriverOffer, season: Int, currentWeek: Int): DriverMarketState {
        require(offer.status == NegotiationStatus.COUNTER) { "A contraproposta não está ativa" }
        require(offer.seasonTarget == season + 1) { "A proposta pertence a outra temporada" }
        require(offer.round in 1..3) { "Rodada inválida" }
        require(state.pending.any { it.driverId == offer.driverId && it.toTeamId == offer.toTeamId && it.seasonTarget == offer.seasonTarget && it.round == offer.round && it.status == NegotiationStatus.COUNTER }) { "Contraproposta não encontrada" }
        val accepted = offer.copy(status = NegotiationStatus.ACCEPTED)
        val next = signFuture(state, accepted, season)
        return next.copy(
            notifications = next.notifications + MarketNotification(
                season, currentWeek, "CONTRATO FECHADO",
                "${driverName(offer.driverId)} aceitou os termos da contraproposta para ${offer.seasonTarget}.", true
            )
        ).normalized()
    }

    fun rejectCounterOffer(state: DriverMarketState, offer: DriverOffer, season: Int, currentWeek: Int): DriverMarketState {
        require(offer.status == NegotiationStatus.COUNTER) { "A contraproposta não está ativa" }
        val next = state.copy(pending = state.pending.filterNot {
            it.driverId == offer.driverId && it.toTeamId == offer.toTeamId && it.seasonTarget == offer.seasonTarget && it.round == offer.round
        })
        return next.copy(
            notifications = next.notifications + MarketNotification(
                season, currentWeek, "NEGOCIAÇÃO ENCERRADA",
                "Você recusou a contraproposta de ${driverName(offer.driverId)}.", true
            )
        ).normalized()
    }

    fun acceptIncomingOffer(state: DriverMarketState, offer: DriverOffer, season: Int, currentWeek: Int): DriverMarketState {
        require(offer.status == NegotiationStatus.PENDING) { "A proposta não está pendente" }
        require(offer.fromTeamId != offer.toTeamId) { "Proposta inválida" }
        require(offer.seasonTarget == season + 1) { "A proposta pertence a outra temporada" }
        require(state.pending.any { it.driverId == offer.driverId && it.toTeamId == offer.toTeamId && it.seasonTarget == offer.seasonTarget && it.status == NegotiationStatus.PENDING }) { "Proposta não encontrada" }
        val accepted = offer.copy(status = NegotiationStatus.ACCEPTED)
        return signFuture(state, accepted, season).copy(
            notifications = state.notifications + MarketNotification(
                season, currentWeek, "TRANSFERÊNCIA CONFIRMADA",
                "Você aceitou a proposta da ${teamName(offer.toTeamId)} por ${driverName(offer.driverId)}. Transferência em ${offer.seasonTarget}.", true)
        ).normalized()
    }

    fun rejectIncomingOffer(state: DriverMarketState, offer: DriverOffer, season: Int, currentWeek: Int): DriverMarketState {
        val clean = state.copy(pending = state.pending.filterNot { it.driverId == offer.driverId && it.toTeamId == offer.toTeamId && it.seasonTarget == offer.seasonTarget })
        return clean.copy(
            notifications = clean.notifications + MarketNotification(
                season, currentWeek, "PROPOSTA RECUSADA",
                "Você recusou a proposta da ${teamName(offer.toTeamId)} por ${driverName(offer.driverId)}.", true)
        ).normalized()
    }

    fun renew(state: DriverMarketState, driverId: Int, teamId: Int, years: Int, salary: Long, season: Int, currentWeek: Int = 1): DriverMarketState =
        renew(state, driverId, teamId, years, salary, DriverTeamRole.EQUAL, season, currentWeek)

    fun renew(state: DriverMarketState, driverId: Int, teamId: Int, years: Int, salary: Long, role: DriverTeamRole, season: Int, currentWeek: Int = 1): DriverMarketState {
        require(marketOpen(currentWeek, season)) { "O mercado de pilotos abre somente após 8 corridas realizadas" }
        require(years in 1..5) { "O contrato deve ter entre 1 e 5 anos" }
        val current = state.contracts.firstOrNull { it.driverId == driverId && it.teamId == teamId && it.activeIn(season) }
            ?: error("Piloto não pertence à equipe nesta temporada")
        require(current.contractYear(season) == current.years) { "Renovação disponível apenas no último ano do contrato" }
        require(state.scheduled.none { it.driverId == driverId && it.startSeason == season + 1 }) { "Piloto já possui decisão para a próxima temporada" }
        require(roleCompatible(state, teamId, driverId, role, season, replacingDriverId = driverId)) { "Conflito de Piloto 1" }
        val future = FutureDriverDeal(
            driverId = driverId, fromTeamId = teamId, toTeamId = teamId, startSeason = season + 1,
            years = years, salary = salary.coerceAtLeast(100_000L), role = role, signedSeason = season,
            replaceDriverId = driverId
        )
        return state.copy(
            scheduled = state.scheduled.filterNot { it.driverId == driverId } + future,
            notifications = state.notifications + MarketNotification(
                season, currentWeek, "RENOVAÇÃO",
                "${driverName(driverId)} renovou com a ${teamName(teamId)} para ${season + 1} por $years ano(s).", true),
            history = state.history + "Renovação de ${driverName(driverId)} preparada para ${season + 1} por $years ano(s)"
        ).normalized()
    }

    /**
     * Processes the AI driver market during the season. AI follows the same eligibility,
     * contract and role rules as the player, but may make imperfect decisions. No current
     * roster changes occur here: every accepted move is scheduled for the next season.
     */
    fun marketOpen(currentWeek: Int, season: Int = 2026): Boolean = SeasonCalendar.forSeason(season).count { it.weekOfSeason < currentWeek } >= 8

    /** Immediate signature fee. Salary is never included here; salary is charged annually at season start. */
    fun signatureFeeFor(state: DriverMarketState, driverId: Int, toTeamId: Int, season: Int): Long {
        val marketValue = state.contracts.firstOrNull { it.driverId == driverId }?.marketValue ?: marketValueFor(driverId)
        val current = state.contracts.firstOrNull { it.driverId == driverId && it.activeIn(season) }
        val rate = when {
            current == null -> 0.30 // free driver
            current.teamId == toTeamId -> 0.50 // own renewal
            else -> 0.70 // take driver from another team
        }
        return (marketValue * rate).roundToLong()
    }

    fun signatureFeeForRenewal(state: DriverMarketState, driverId: Int, teamId: Int, season: Int): Long {
        val current = state.contracts.firstOrNull { it.driverId == driverId && it.teamId == teamId && it.activeIn(season) }
            ?: error("Piloto não pertence à equipe nesta temporada")
        return (current.marketValue * 0.50).roundToLong()
    }

    fun processAiMarketWeek(state: DriverMarketState, season: Int, currentWeek: Int, playerTeamId: Int): DriverMarketState {
        if (!marketOpen(currentWeek, season)) return state
        var s = expireOffers(state, currentWeek, season)
        s = resolveAiCounters(s, season, currentWeek, playerTeamId)
        val teams = WorldDatabase.teams.filter { it.id != playerTeamId }
        val rng = Random(seed + season * 997 + currentWeek * 31)
        // The market is deliberately not a fixed 50/50 split. Each weekly market
        // cycle receives a deterministic-but-variable target between 40% and 60%
        // renewals; transfers occupy the remaining share. The target is a guide for
        // accepted movements, while driver/team eligibility still decides whether a
        // movement can actually happen.
        val targetRenewalPct = marketMovementTargetRenewalPct(season, currentWeek)

        // First, allow teams to renew drivers they already trust. Renewal is not a
        // transfer and therefore can happen during the current season.
        teams.shuffled(Random(seed + season * 43 + currentWeek)).forEach { team ->
            val expiring = roster(s, team.id, season = season)
                .mapNotNull { id -> s.contracts.firstOrNull { it.driverId == id && it.teamId == team.id } }
                .filter { it.seasonSigned + it.years - 1 == season }
            expiring.forEach { deal ->
                val role = deal.role
                val fit = interestScore(s, deal.driverId, team.id, deal.salary, role, season)
                val chance = when {
                    fit >= 82 -> 12
                    fit >= 72 -> 9
                    fit >= 60 -> 6
                    else -> 2
                }
                val (renewalsNow, transfersNow) = movementCounts(s, season)
                val totalNow = renewalsNow + transfersNow
                val currentRenewalPct = if (totalNow == 0) 50.0 else renewalsNow * 100.0 / totalNow
                val targetBias = when {
                    currentRenewalPct < targetRenewalPct - 5 -> 1.25
                    currentRenewalPct > targetRenewalPct + 5 -> 0.75
                    else -> 1.0
                }
                val effectiveChance = (chance * targetBias).roundToLong().toInt().coerceIn(1, 20)
                if (rng.nextInt(100) < effectiveChance && allowsRenewalMovement(s, season, targetRenewalPct)) {
                    val years = chooseAiYears(deal.driverId, season, currentWeek)
                    val salary = (deal.salary * (1.03 + rng.nextDouble() * 0.12)).roundToLong()
                    runCatching { s = renew(s, deal.driverId, team.id, years, salary, role, season, currentWeek) }
                }
            }
        }

        // AI may negotiate at any point of the season, but most teams do not shop
        // aggressively every week. This is an activity probability, not a transfer cap.
        teams.shuffled(Random(seed + season * 37 + currentWeek)).take(8).forEach { team ->
            val rosterNow = roster(s, team.id, season = season)
            val expiringCount = rosterNow.count { id ->
                s.contracts.firstOrNull { it.driverId == id }?.let { it.seasonSigned + it.years - 1 == season } == true
            }
            val activityChance = when {
                rosterNow.size < 2 -> 100
                expiringCount > 0 -> 78
                else -> 7
            }
            if (rng.nextInt(100) >= activityChance) return@forEach

            val candidates = (freeAgents(s).filter { canReceiveProposals(s, it, season) } +
                s.contracts.filter { it.teamId != team.id && canReceiveProposals(s, it.driverId, season) }.map { it.driverId })
                .distinct()

            val replacement = if (rosterNow.size >= 2) {
                rosterNow.minByOrNull { id ->
                    val deal = s.contracts.first { it.driverId == id }
                    marketValueFor(id) + interestScore(s, id, team.id, deal.salary, deal.role, season) * 100_000L
                }
            } else null

            val candidate = candidates.shuffled(Random(seed + team.id * 71 + currentWeek)).maxByOrNull { id ->
                val preferredRole = preferredRoleFor(s, id, team.id, season)
                val offeredSalary = (salaryFor(id) * (1.02 + rng.nextDouble() * 0.16)).roundToLong()
                interestScore(s, id, team.id, offeredSalary, preferredRole, season) + marketValueFor(id) / 5_000_000
            } ?: return@forEach

            // Avoid meaningless churn: a complete team should normally move only
            // when the target is a clear sporting/economic upgrade. This is not a
            // transfer cap: an exceptional opportunity can still trigger a move.
            if (replacement != null && expiringCount == 0) {
                val replacementDeal = s.contracts.firstOrNull { it.driverId == replacement }
                val candidateValue = marketValueFor(candidate)
                val replacementValue = marketValueFor(replacement)
                val candidateInterest = interestScore(
                    s, candidate, team.id,
                    (salaryFor(candidate) * 1.08).roundToLong(),
                    preferredRoleFor(s, candidate, team.id, season), season
                )
                val replacementInterest = replacementDeal?.let {
                    interestScore(s, replacement, team.id, it.salary, it.role, season)
                } ?: 50
                val sportingGain = candidateValue - replacementValue
                val interestGain = candidateInterest - replacementInterest

                // Normal churn needs a meaningful gain. Small random exceptions keep
                // the market imperfect and preserve the possibility of surprising moves.
                val meaningfulUpgrade = sportingGain >= 4_000_000L || interestGain >= 12
                val exceptionalMove = sportingGain >= 12_000_000L && candidateInterest >= 70
                if (!meaningfulUpgrade && !exceptionalMove && rng.nextInt(100) >= 12) return@forEach
                if (meaningfulUpgrade && !exceptionalMove && rng.nextInt(100) >= 58) return@forEach
            }

            // Keep the accepted movement mix inside the hard 40%-60% band. The
            // dynamic target influences preference, but never overrides these bounds.
            if (!allowsTransferMovement(s, season, targetRenewalPct)) return@forEach

            val role = preferredRoleFor(s, candidate, team.id, season)
            val salary = (salaryFor(candidate) * (0.98 + rng.nextDouble() * 0.20)).roundToLong().coerceAtLeast(500_000L)
            val candidateDeal = s.contracts.firstOrNull { it.driverId == candidate && it.activeIn(season) }
            // When an AI team approaches a driver belonging to the player's team,
            // this is an incoming proposal. It must wait for the manager's decision.
            if (candidateDeal?.teamId == playerTeamId) {
                // Várias equipes podem disputar o mesmo piloto simultaneamente.
                // Não bloquear uma nova proposta apenas porque já existe outra negociação.
                val responseDelay = if (rng.nextBoolean()) 2 else 3
                val incoming = DriverOffer(
                    candidate, playerTeamId, team.id, chooseAiYears(candidate, season, currentWeek), salary, role,
                    marketValueFor(candidate), interestScore(s, candidate, team.id, salary, role, season),
                    1, currentWeek + responseDelay, NegotiationStatus.PENDING, season + 1, replacement, team.id
                )
                s = s.copy(
                    pending = (s.pending + incoming).takeLast(100),
                    notifications = s.notifications + MarketNotification(
                        season, currentWeek, "PROPOSTA RECEBIDA",
                        "A ${teamName(team.id)} fez uma proposta por ${driverName(candidate)} para ${season + 1}.", true)
                )
                return@forEach
            }
            runCatching {
                val (next, _) = makeOffer(
                    s, candidate, team.id, chooseAiYears(candidate, season, currentWeek),
                    salary, role, season, currentWeek, 1, replacement, team.id
                )
                s = next
            }.onFailure { /* one failed AI negotiation never breaks the market tick */ }
        }
        return s.normalized()
    }

    /** Dynamic market target: renewals vary between 40% and 60%; transfers fill the remainder. */
    private fun marketMovementTargetRenewalPct(season: Int, week: Int): Int =
        (40 + Math.floorMod(seed * 31 + season * 17 + week * 13, 21)).coerceIn(40, 60)

    private fun movementCounts(state: DriverMarketState, season: Int): Pair<Int, Int> {
        var renewals = 0
        var transfers = 0
        state.notifications.filter { it.season == season }.forEach { notice ->
            when (notice.title) {
                "RENOVAÇÃO" -> renewals++
                "TRANSFERÊNCIA NEGOCIADA" -> transfers++
            }
        }
        return renewals to transfers
    }

    private fun allowsRenewalMovement(state: DriverMarketState, season: Int, targetRenewalPct: Int): Boolean {
        val (renewals, transfers) = movementCounts(state, season)
        val total = renewals + transfers
        if (total == 0) return true
        // The target varies by market week, while 40/60 remain absolute bounds.
        // Use the target as the preferred side of the mix instead of merely calculating it.
        val target = targetRenewalPct.coerceIn(40, 60)
        val projected = (renewals + 1).toDouble() * 100.0 / (total + 1)
        return projected <= target || renewals * 100 < total * 40
    }

    private fun allowsTransferMovement(state: DriverMarketState, season: Int, targetRenewalPct: Int): Boolean {
        val (renewals, transfers) = movementCounts(state, season)
        val total = renewals + transfers
        if (total == 0) return true
        // Transfers are the complement of the dynamic renewal target.
        val targetTransfer = (100 - targetRenewalPct).coerceIn(40, 60)
        val projected = (transfers + 1).toDouble() * 100.0 / (total + 1)
        return projected <= targetTransfer || transfers * 100 < total * 40
    }

    private fun preferredRoleFor(state: DriverMarketState, driverId: Int, teamId: Int, season: Int): DriverTeamRole {
        return when (state.rolePreferences[driverId]) {
            DriverRolePreference.DEMANDS_PILOT_1, DriverRolePreference.PREFERS_PILOT_1 -> DriverTeamRole.PILOT_1
            DriverRolePreference.PREFERS_EQUALITY -> DriverTeamRole.EQUAL
            DriverRolePreference.INDIFFERENT, null -> {
                if (roster(state, teamId, season = season).isEmpty()) DriverTeamRole.PILOT_1 else DriverTeamRole.PILOT_2
            }
        }
    }

    private fun chooseAiYears(driverId: Int, season: Int, week: Int): Int {
        val roll = (seed + driverId * 17 + season * 13 + week) % 100
        return when {
            roll < 50 -> 1
            roll < 88 -> 2
            else -> 3
        }
    }

    fun runAiOffseason(state: DriverMarketState, season: Int, teamBudget: Map<Int, Long>): DriverMarketState =
        applySeasonTransition(state, season, teamBudget)

    fun applySeasonTransition(state: DriverMarketState, newSeason: Int, teamBudgets: Map<Int,Long> = emptyMap()): DriverMarketState {
        var s = state
        // Execute only contracts whose start season has arrived.
        val due = s.scheduled.filter { it.startSeason <= newSeason }
        due.forEach { move ->
            s = s.copy(contracts=s.contracts.filterNot { it.driverId == move.driverId || it.driverId == move.replaceDriverId }, freeAgents=((s.freeAgents - move.driverId) + listOfNotNull(move.replaceDriverId)).distinct())
            // If destination is full, remove the weakest contract only as a final AI fallback; player must choose replacement in UI.
            val dest = s.contracts.filter { it.teamId == move.toTeamId && it.activeIn(newSeason) }
            if (dest.size >= 2) {
                val weakest = dest.minByOrNull { marketValueFor(it.driverId) }
                if (weakest != null) s = s.copy(contracts=s.contracts.filterNot { it.driverId == weakest.driverId }, freeAgents=(s.freeAgents + weakest.driverId).distinct())
            }
            val deal = DriverDeal(move.driverId, move.toTeamId, move.years, move.salary, marketValueFor(move.driverId), newSeason, move.role)
            s = s.copy(contracts=s.contracts + deal, scheduled=s.scheduled.filterNot { it.driverId == move.driverId }, notifications=s.notifications + MarketNotification(newSeason, 1, "TRANSFERÊNCIA CONFIRMADA", "${driverName(move.driverId)} agora é piloto da ${teamName(move.toTeamId)}.", true), history=s.history + "Transferência ${driverName(move.driverId)} executada para ${teamName(move.toTeamId)}")
        }
        s = resolveExpiredAndVacancies(s, newSeason, teamBudgets)
        return s.normalized()
    }

    fun scout(
        state: DriverMarketState,
        driverId: Int,
        teamId: Int,
        currentWeek: Int,
        season: Int = 2026,
        scoutingFacilityLevel: Int = 0
    ): Pair<DriverMarketState, ScoutingReport> {
        require(driverId in allIds) { "Piloto inexistente" }
        val value=marketValueFor(driverId)
        val d = WorldDatabase.allDrivers.first { it.id == driverId }
        val attrs = listOf(d.speed,d.qualifying,d.overtaking,d.defense,d.consistency,d.wet,d.tyre)
        // Scouting facility now affects the precision of the persisted report.
        val precision = FacilityEngine.scoutingPrecision(
            TeamFacilitiesState().withLevel(FacilityType.SCOUTING, scoutingFacilityLevel)
        )
        val margin = ((100 - precision) / 8).coerceIn(0,10)
        val ranges = attrs.joinToString("|") { v -> if (margin == 0) "$v-$v" else "${(v-margin).coerceAtLeast(40)}-${(v+margin).coerceAtMost(100)}" }
        val report=ScoutingReport(driverId,teamId,500_000L,currentWeek,56,salaryFor(driverId),value,state.rolePreferences[driverId] ?: DriverRolePreference.INDIFFERENT,interestScore(state,driverId,teamId,salaryFor(driverId),DriverTeamRole.EQUAL,season),season,ranges)
        return state.copy(scouting=(state.scouting.filterNot { it.driverId==driverId && it.teamId==teamId && it.season==season }+report).takeLast(200),history=state.history+"Scouting concluído: ${driverName(driverId)}") to report
    }

    fun marketSummary(state: DriverMarketState, season: Int): String = "Mercado ${if (marketOpen(SeasonCalendar.forSeason(season).maxOfOrNull { it.weekOfSeason } ?: 56, season)) "aberto" else "fechado"} | Contratados: ${state.contracts.count { it.activeIn(season) }} | Livres: ${freeAgents(state).size} | Propostas: ${state.pending.count { it.seasonTarget == season + 1 }} | Transferências: ${state.scheduled.count { it.startSeason == season + 1 }}"

    private fun resolveExpiredAndVacancies(input: DriverMarketState, season: Int, budgets: Map<Int,Long>): DriverMarketState {
        var s=input
        s.contracts.filter { !it.activeIn(season) }.forEach { d ->
            s=s.copy(contracts=s.contracts.filterNot { it.driverId==d.driverId }, freeAgents=(s.freeAgents+d.driverId).distinct(), history=s.history+"Contrato de ${driverName(d.driverId)} encerrado")
        }
        // AI fallback: fill vacancies using interest, not simply speed.
        for (team in WorldDatabase.teams) {
            while (s.rosterCount(team.id, season) < 2) {
                val candidate=freeAgents(s).maxByOrNull { id -> interestScore(s,id,team.id,salaryFor(id),DriverTeamRole.EQUAL,season) } ?: break
                val salary=(salaryFor(candidate)*1.05).roundToLong()
                val role=if (s.rosterCount(team.id,season)==0) DriverTeamRole.PILOT_1 else DriverTeamRole.PILOT_2
                val deal=DriverDeal(candidate,team.id,1,salary,marketValueFor(candidate),season,role)
                s=s.copy(contracts=s.contracts+deal,freeAgents=s.freeAgents-candidate,history=s.history+"IA contratou ${driverName(candidate)} para ${team.name}")
            }
        }
        return s
    }

    private fun DriverMarketState.rosterCount(teamId:Int,season:Int)=contracts.count { it.teamId==teamId && it.activeIn(season) }
    private fun roleCompatible(state: DriverMarketState, teamId:Int, driverId:Int, role:DriverTeamRole, season:Int, replacingDriverId:Int?=null):Boolean {
        if (role != DriverTeamRole.PILOT_1) return true
        return state.contracts.none { it.teamId==teamId && it.activeIn(season) && it.driverId != (replacingDriverId ?: driverId) && it.role==DriverTeamRole.PILOT_1 }
    }
    private fun overall(d: com.f1teammanager.core.season.DriverDefinition):Int = (d.speed+d.qualifying+d.overtaking+d.defense+d.consistency+d.wet+d.tyre)/7
    private fun teamPrestige(teamId:Int)=WorldDatabase.teams.first { it.id==teamId }.baseCar.coerceIn(40,100)
    private fun teamRecentPerformance(teamId:Int)=WorldDatabase.teams.first { it.id==teamId }.baseCar.coerceIn(40,100)
    private fun teamHistory(teamId:Int)=WorldDatabase.teams.first { it.id==teamId }.baseCar.coerceIn(40,100)
    private fun driverName(id:Int)=WorldDatabase.allDrivers.firstOrNull { it.id==id }?.name ?: "Piloto $id"
    private fun teamName(id:Int)=WorldDatabase.teams.firstOrNull { it.id==id }?.name ?: "Equipe $id"
}
