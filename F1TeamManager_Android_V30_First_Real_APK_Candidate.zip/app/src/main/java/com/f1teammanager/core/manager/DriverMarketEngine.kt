package com.f1teammanager.core.manager

import com.f1teammanager.core.season.WorldDatabase
import kotlin.math.roundToLong
import kotlin.random.Random

/** Stage 3: driver market. Transfers are future-season commitments; the current grid never changes mid-season. */
class DriverMarketEngine(private val seed: Int = 20261003) {
    private val allIds = WorldDatabase.allDrivers.map { it.id }.toSet()

    fun initialState(season: Int = 2026): DriverMarketState {
        val contracts = WorldDatabase.drivers.map { d ->
            val value = marketValueFor(d.id)
            val years = if (d.id <= 44) 2 else 1
            DriverDeal(d.id, d.teamId, years, salaryFor(d.id), value, buyoutFor(value, years, d.id), season,
                role = DriverTeamRole.EQUAL)
        }
        val prefs = WorldDatabase.allDrivers.associate { it.id to DriverRolePreference.INDIFFERENT }
        val free = WorldDatabase.allDrivers.map { it.id }.filter { id -> contracts.none { it.driverId == id } }
        return DriverMarketState(contracts=contracts, freeAgents=free, rolePreferences=prefs).normalized()
    }

    fun salaryFor(driverId: Int): Long {
        val d = WorldDatabase.allDrivers.firstOrNull { it.id == driverId } ?: return 500_000L
        val overall = overall(d)
        val classBonus = when (d.driverClass.lowercase()) {
            "lenda" -> 18_000_000L
            "pro" -> 9_000_000L
            "forte" -> 4_000_000L
            "médio", "medio" -> 1_500_000L
            else -> 0L
        }
        val evolutionBonus = when (d.evolution.lowercase()) {
            "prodígio", "prodigio" -> 2_500_000L
            "auge rápido", "auge rapido" -> 1_800_000L
            "auge moderado", "auge tardio" -> 1_200_000L
            else -> 0L
        }
        return (500_000L + overall * 380_000L + classBonus + evolutionBonus).coerceIn(500_000L, 70_000_000L)
    }

    fun marketValueFor(driverId: Int): Long {
        val d = WorldDatabase.allDrivers.firstOrNull { it.id == driverId } ?: return 500_000L
        val base = overall(d) * 500_000L
        val classMultiplier = when (d.driverClass.lowercase()) {
            "lenda" -> 1.65; "pro" -> 1.35; "forte" -> 1.15; "médio", "medio" -> 0.90; else -> 0.70
        }
        val evolutionMultiplier = when (d.evolution.lowercase()) {
            "prodígio", "prodigio" -> 1.25; "auge rápido", "auge rapido" -> 1.15; "auge moderado", "auge tardio" -> 1.10; "demorado" -> 0.90; else -> 1.0
        }
        return (base * classMultiplier * evolutionMultiplier).roundToLong().coerceIn(500_000L, 80_000_000L)
    }

    /** Centralized high-penalty rule. Remaining years make a release materially more expensive. */
    fun buyoutFor(marketValue: Long, remainingYears: Int, driverId: Int = 0): Long {
        val phase = when (remainingYears.coerceIn(0,3)) { 3 -> 2.80; 2 -> 2.25; 1 -> 1.70; else -> 1.0 }
        val anchor = if (driverId % 2 == 0) 1.0 else 1.05
        return (marketValue * phase * anchor).roundToLong().coerceAtLeast(500_000L)
    }

    fun roster(state: DriverMarketState, teamId: Int, includeScheduled: Boolean = false, season: Int = 2026): List<Int> {
        val current = state.contracts.filter { it.teamId == teamId && it.activeIn(season) }.map { it.driverId }
        if (!includeScheduled) return current
        return (current + state.scheduled.filter { it.toTeamId == teamId && it.startSeason == season }.map { it.driverId }).distinct()
    }

    fun freeAgents(state: DriverMarketState): List<Int> = state.freeAgents.filter { id -> state.contracts.none { it.driverId == id } && state.scheduled.none { it.driverId == id } }

    fun expiring(state: DriverMarketState, season: Int): List<DriverDeal> = state.contracts.filter { it.seasonSigned + it.years <= season }

    fun canReceiveProposals(state: DriverMarketState, driverId: Int, season: Int): Boolean {
        if (state.scheduled.any { it.driverId == driverId }) return false
        val deal = state.contracts.firstOrNull { it.driverId == driverId } ?: return driverId in state.freeAgents
        return deal.canReceiveProposals(season)
    }

    fun interestScore(state: DriverMarketState, driverId: Int, toTeamId: Int, salary: Long, role: DriverTeamRole, season: Int): Int {
        val d = WorldDatabase.allDrivers.first { it.id == driverId }
        val team = WorldDatabase.teams.first { it.id == toTeamId }
        val car = team.baseCar.coerceIn(1,100)
        val salaryScore = (salary.toDouble() / salaryFor(driverId) * 20.0).roundToLong().toInt().coerceIn(0,20)
        val rolePref = state.rolePreferences[driverId] ?: DriverRolePreference.INDIFFERENT
        val roleScore = when (rolePref) {
            DriverRolePreference.DEMANDS_PILOT_1 -> if (role == DriverTeamRole.PILOT_1) 10 else -18
            DriverRolePreference.PREFERS_PILOT_1 -> if (role == DriverTeamRole.PILOT_1) 7 else 0
            DriverRolePreference.PREFERS_EQUALITY -> if (role == DriverTeamRole.EQUAL) 7 else 0
            DriverRolePreference.INDIFFERENT -> 5
        }
        val prestige = teamPrestige(toTeamId)
        val project = ((team.baseCar + prestige) / 2)
        val recent = teamRecentPerformance(toTeamId)
        val current = state.contracts.firstOrNull { it.driverId == driverId }
        val retention = if (current?.teamId == toTeamId) 10 else 0
        val score = (car * .25 + salaryScore + prestige * .15 + project * .15 + roleScore + recent * .10 + teamHistory(toTeamId) * .05 + retention).roundToLong().toInt()
        return score.coerceIn(0,100)
    }

    /** Compatibility entry point for the previous V9 engine. It now creates a future-season offer instead of moving the driver immediately. */
    fun offer(state: DriverMarketState, driverId: Int, fromTeamId: Int, toTeamId: Int, years: Int, salary: Long, buyout: Long = 0L,
              teamStrength: Int = 70, reputation: Int = 50, season: Int = 2026, rngSeed: Int = seed): Pair<DriverMarketState, DriverOffer> =
        makeOffer(state, driverId, toTeamId, years.coerceIn(1,3), salary, DriverTeamRole.EQUAL, season)

    fun makeOffer(
        state: DriverMarketState, driverId: Int, toTeamId: Int, years: Int, salary: Long,
        role: DriverTeamRole, season: Int, currentWeek: Int = 1, round: Int = 1, replaceDriverId: Int? = null
    ): Pair<DriverMarketState, DriverOffer> {
        require(driverId in allIds) { "Piloto inexistente" }
        require(toTeamId in WorldDatabase.teams.map { it.id }) { "Equipe inexistente" }
        require(years in 1..3) { "O contrato deve ter 1, 2 ou 3 anos" }
        require(canReceiveProposals(state, driverId, season)) { "Este piloto não está disponível para propostas nesta temporada" }
        val destinationRoster = roster(state, toTeamId, season = season)
        if (destinationRoster.size >= 2 && state.contracts.none { it.driverId == driverId && it.teamId == toTeamId }) {
            require(replaceDriverId != null && replaceDriverId in destinationRoster) { "A equipe já possui 2 pilotos; escolha qual piloto será substituído" }
        }
        require(state.scheduled.none { it.driverId == driverId }) { "Piloto já possui transferência futura" }
        val current = state.contracts.firstOrNull { it.driverId == driverId }
        val from = current?.teamId ?: 0
        val value = marketValueFor(driverId)
        val remaining = current?.let { (it.seasonSigned + it.years - season).coerceAtLeast(0) } ?: 0
        val buyout = if (from == 0) 0L else buyoutFor(value, remaining, driverId)
        val score = interestScore(state, driverId, toTeamId, salary, role, season)
        val rng = Random(seed + driverId * 31 + toTeamId * 17 + round * 13)
        val adjusted = (score + rng.nextInt(-4,5)).coerceIn(0,100)
        val status = when {
            adjusted >= 78 -> NegotiationStatus.ACCEPTED
            adjusted >= 55 -> NegotiationStatus.COUNTER
            else -> NegotiationStatus.REJECTED
        }
        val target = season + 1
        val offer = DriverOffer(driverId, from, toTeamId, years, salary.coerceAtLeast(100_000L), role, value, buyout, adjusted, round.coerceIn(1,3), currentWeek + 1, status, target)
        var next = if (status == NegotiationStatus.COUNTER) {
            state.copy(pending = (state.pending + offer).takeLast(100))
        } else {
            state
        }
        if (status == NegotiationStatus.ACCEPTED) {
            require(roleCompatible(next, toTeamId, driverId, role, season)) { "Os dois pilotos não podem exigir o papel de Piloto 1" }
            next = signFuture(next, offer, season, replaceDriverId)
        }
        return next.normalized() to offer
    }

    /** Advances market time and expires proposals whose 1-week window ended. */
    fun expireOffers(state: DriverMarketState, currentWeek: Int): DriverMarketState {
        val (expired, active) = state.pending.partition {
            (it.status == NegotiationStatus.PENDING || it.status == NegotiationStatus.COUNTER) && it.expiresAfterWeek <= currentWeek
        }
        if (expired.isEmpty()) return state
        val marked = expired.map { it.copy(status = NegotiationStatus.EXPIRED) }
        return state.copy(pending = active.takeLast(100), history = state.history + marked.map { "Proposta para ${driverName(it.driverId)} expirou" }).normalized()
    }

    /** Opens the next negotiation round using the player's new terms. Maximum 3 rounds. */
    fun counterOffer(
        state: DriverMarketState,
        previous: DriverOffer,
        season: Int,
        currentWeek: Int,
        salary: Long,
        years: Int,
        role: DriverTeamRole,
        replaceDriverId: Int? = null
    ): Pair<DriverMarketState, DriverOffer> {
        require(previous.status == NegotiationStatus.COUNTER) { "Esta negociação não está aguardando contraproposta" }
        require(previous.round < 3) { "A negociação já atingiu 3 rodadas" }
        require(previous.seasonTarget == season + 1) { "A proposta pertence a outra temporada" }
        require(state.pending.any { it.driverId == previous.driverId && it.toTeamId == previous.toTeamId && it.seasonTarget == previous.seasonTarget && it.round == previous.round && it.status == NegotiationStatus.COUNTER }) {
            "Esta contraproposta já não está ativa"
        }
        val cleaned = state.copy(pending = state.pending.filterNot {
            it.driverId == previous.driverId && it.toTeamId == previous.toTeamId &&
                it.seasonTarget == previous.seasonTarget && it.round == previous.round
        })
        return makeOffer(cleaned, previous.driverId, previous.toTeamId, years, salary, role, season, currentWeek, previous.round + 1, replaceDriverId)
    }

    fun signFuture(state: DriverMarketState, offer: DriverOffer, season: Int, replaceDriverId: Int? = null): DriverMarketState {
        require(offer.status == NegotiationStatus.ACCEPTED) { "Somente uma proposta aceita pode gerar contrato futuro" }
        require(offer.seasonTarget == season + 1) { "A transferência deve começar na próxima temporada" }
        require(state.scheduled.none { it.driverId == offer.driverId }) { "Piloto já possui transferência futura" }
        val current = state.contracts.firstOrNull { it.driverId == offer.driverId }
        val future = FutureDriverDeal(offer.driverId, current?.teamId ?: 0, offer.toTeamId, offer.seasonTarget, offer.years, offer.salary, offer.role, season, if (current == null) 0 else offer.buyout, replaceDriverId)
        val cleanPending = state.pending.filterNot { it.driverId == offer.driverId && it.toTeamId == offer.toTeamId && it.seasonTarget == offer.seasonTarget }
        return state.copy(pending=cleanPending, scheduled=state.scheduled + future,
            history=state.history + "${driverName(offer.driverId)} assinou com equipe ${offer.toTeamId} para ${offer.seasonTarget}")
    }

    fun renew(state: DriverMarketState, driverId: Int, teamId: Int, years: Int, salary: Long, season: Int): DriverMarketState =
        renew(state, driverId, teamId, years, salary, DriverTeamRole.EQUAL, season)

    fun renew(state: DriverMarketState, driverId: Int, teamId: Int, years: Int, salary: Long, role: DriverTeamRole, season: Int): DriverMarketState {
        require(years in 1..3) { "O contrato deve ter 1, 2 ou 3 anos" }
        val current = state.contracts.firstOrNull { it.driverId == driverId && it.teamId == teamId && it.activeIn(season) }
            ?: error("Piloto não pertence à equipe nesta temporada")
        require(state.scheduled.none { it.driverId == driverId && it.startSeason == season + 1 }) { "Piloto já possui decisão para a próxima temporada" }
        require(roleCompatible(state, teamId, driverId, role, season, replacingDriverId = driverId)) { "Conflito de Piloto 1" }
        val future = FutureDriverDeal(
            driverId = driverId, fromTeamId = teamId, toTeamId = teamId, startSeason = season + 1,
            years = years, salary = salary.coerceAtLeast(100_000L), role = role, signedSeason = season,
            buyoutPaid = 0L, replaceDriverId = driverId
        )
        return state.copy(
            scheduled = state.scheduled.filterNot { it.driverId == driverId } + future,
            history = state.history + "Renovação de ${driverName(driverId)} preparada para ${season + 1} por $years ano(s)"
        ).normalized()
    }

    /**
     * Processes the AI driver market during the season. AI follows the same eligibility,
     * contract and role rules as the player, but may make imperfect decisions. No current
     * roster changes occur here: every accepted move is scheduled for the next season.
     */
    fun processAiMarketWeek(state: DriverMarketState, season: Int, currentWeek: Int, playerTeamId: Int): DriverMarketState {
        var s = expireOffers(state, currentWeek)
        val teams = WorldDatabase.teams.filter { it.id != playerTeamId }
        val rng = Random(seed + season * 997 + currentWeek * 31)

        // First, allow teams to renew drivers they already trust. Renewal is not a
        // transfer and therefore can happen during the current season.
        teams.shuffled(Random(seed + season * 43 + currentWeek)).forEach { team ->
            val expiring = roster(s, team.id, season = season)
                .mapNotNull { id -> s.contracts.firstOrNull { it.driverId == id && it.teamId == team.id } }
                .filter { it.seasonSigned + it.years - 1 == season }
            expiring.forEach { deal ->
                val role = deal.role
                val fit = interestScore(s, deal.driverId, team.id, deal.salary, role, season)
                val chance = when {
                    fit >= 82 -> 82
                    fit >= 72 -> 64
                    fit >= 60 -> 42
                    else -> 18
                }
                if (rng.nextInt(100) < chance) {
                    val years = chooseAiYears(deal.driverId, season, currentWeek)
                    val salary = (deal.salary * (1.03 + rng.nextDouble() * 0.12)).roundToLong()
                    runCatching { s = renew(s, deal.driverId, team.id, years, salary, role, season) }
                }
            }
        }

        // AI may negotiate at any point of the season, but most teams do not shop
        // aggressively every week. This is an activity probability, not a transfer cap.
        teams.shuffled(Random(seed + season * 37 + currentWeek)).take(8).forEach { team ->
            val rosterNow = roster(s, team.id, season = season)
            val expiringCount = rosterNow.count { id ->
                s.contracts.firstOrNull { it.driverId == id }?.let { it.seasonSigned + it.years - 1 == season } == true
            }
            val activityChance = when {
                rosterNow.size < 2 -> 100
                expiringCount > 0 -> 22
                else -> 7
            }
            if (rng.nextInt(100) >= activityChance) return@forEach

            val candidates = (freeAgents(s).filter { canReceiveProposals(s, it, season) } +
                s.contracts.filter { it.teamId != team.id && canReceiveProposals(s, it.driverId, season) }.map { it.driverId })
                .distinct()

            val replacement = if (rosterNow.size >= 2) {
                rosterNow.minByOrNull { id ->
                    val deal = s.contracts.first { it.driverId == id }
                    marketValueFor(id) + interestScore(s, id, team.id, deal.salary, deal.role, season) * 100_000L
                }
            } else null

            val candidate = candidates.shuffled(Random(seed + team.id * 71 + currentWeek)).maxByOrNull { id ->
                val preferredRole = preferredRoleFor(s, id, team.id, season)
                val offeredSalary = (salaryFor(id) * (1.02 + rng.nextDouble() * 0.16)).roundToLong()
                interestScore(s, id, team.id, offeredSalary, preferredRole, season) + marketValueFor(id) / 5_000_000
            } ?: return@forEach

            // Avoid meaningless churn: a complete team should normally move only
            // when the target is a clear sporting/economic upgrade. This is not a
            // transfer cap: an exceptional opportunity can still trigger a move.
            if (replacement != null && expiringCount == 0) {
                val replacementDeal = s.contracts.firstOrNull { it.driverId == replacement }
                val candidateValue = marketValueFor(candidate)
                val replacementValue = marketValueFor(replacement)
                val candidateInterest = interestScore(
                    s, candidate, team.id,
                    (salaryFor(candidate) * 1.08).roundToLong(),
                    preferredRoleFor(s, candidate, team.id, season), season
                )
                val replacementInterest = replacementDeal?.let {
                    interestScore(s, replacement, team.id, it.salary, it.role, season)
                } ?: 50
                val sportingGain = candidateValue - replacementValue
                val interestGain = candidateInterest - replacementInterest

                // Normal churn needs a meaningful gain. Small random exceptions keep
                // the market imperfect and preserve the possibility of surprising moves.
                val meaningfulUpgrade = sportingGain >= 4_000_000L || interestGain >= 12
                val exceptionalMove = sportingGain >= 12_000_000L && candidateInterest >= 70
                if (!meaningfulUpgrade && !exceptionalMove && rng.nextInt(100) >= 4) return@forEach
                if (meaningfulUpgrade && !exceptionalMove && rng.nextInt(100) >= 38) return@forEach
            }

            val role = preferredRoleFor(s, candidate, team.id, season)
            val salary = (salaryFor(candidate) * (0.98 + rng.nextDouble() * 0.20)).roundToLong().coerceAtLeast(500_000L)
            runCatching {
                val (next, offer) = makeOffer(
                    s, candidate, team.id, chooseAiYears(candidate, season, currentWeek),
                    salary, role, season, currentWeek, 1, replacement
                )
                s = next
                if (offer.status == NegotiationStatus.COUNTER && offer.round < 3) {
                    val counterSalary = (offer.salary * (1.04 + rng.nextDouble() * 0.10)).roundToLong()
                    val counterYears = if (rng.nextInt(100) < 65) offer.years else (1..3).random(rng)
                    val counterRole = when (s.rolePreferences[candidate]) {
                        DriverRolePreference.DEMANDS_PILOT_1 -> DriverTeamRole.PILOT_1
                        DriverRolePreference.PREFERS_EQUALITY -> DriverTeamRole.EQUAL
                        else -> offer.role
                    }
                    val (next2, offer2) = counterOffer(s, offer, season, currentWeek, counterSalary, counterYears, counterRole, replacement)
                    s = next2
                    if (offer2.status == NegotiationStatus.COUNTER && offer2.round < 3) {
                        val finalSalary = (offer2.salary * (1.02 + rng.nextDouble() * 0.06)).roundToLong()
                        val (next3, _) = counterOffer(s, offer2, season, currentWeek, finalSalary, offer2.years, offer2.role, replacement)
                        s = next3
                    }
                }
            }.onFailure { /* one failed AI negotiation never breaks the market tick */ }
        }
        return s.normalized()
    }

    private fun preferredRoleFor(state: DriverMarketState, driverId: Int, teamId: Int, season: Int): DriverTeamRole {
        return when (state.rolePreferences[driverId]) {
            DriverRolePreference.DEMANDS_PILOT_1, DriverRolePreference.PREFERS_PILOT_1 -> DriverTeamRole.PILOT_1
            DriverRolePreference.PREFERS_EQUALITY -> DriverTeamRole.EQUAL
            DriverRolePreference.INDIFFERENT, null -> {
                if (roster(state, teamId, season = season).isEmpty()) DriverTeamRole.PILOT_1 else DriverTeamRole.PILOT_2
            }
        }
    }

    private fun chooseAiYears(driverId: Int, season: Int, week: Int): Int {
        val roll = (seed + driverId * 17 + season * 13 + week) % 100
        return when {
            roll < 50 -> 1
            roll < 88 -> 2
            else -> 3
        }
    }

    fun runAiOffseason(state: DriverMarketState, season: Int, teamBudget: Map<Int, Long>): DriverMarketState =
        applySeasonTransition(state, season, teamBudget)

    fun applySeasonTransition(state: DriverMarketState, newSeason: Int, teamBudgets: Map<Int,Long> = emptyMap()): DriverMarketState {
        var s = state
        // Execute only contracts whose start season has arrived.
        val due = s.scheduled.filter { it.startSeason <= newSeason }
        due.forEach { move ->
            s = s.copy(contracts=s.contracts.filterNot { it.driverId == move.driverId || it.driverId == move.replaceDriverId }, freeAgents=((s.freeAgents - move.driverId) + listOfNotNull(move.replaceDriverId)).distinct())
            // If destination is full, remove the weakest contract only as a final AI fallback; player must choose replacement in UI.
            val dest = s.contracts.filter { it.teamId == move.toTeamId && it.activeIn(newSeason) }
            if (dest.size >= 2) {
                val weakest = dest.minByOrNull { marketValueFor(it.driverId) }
                if (weakest != null) s = s.copy(contracts=s.contracts.filterNot { it.driverId == weakest.driverId }, freeAgents=(s.freeAgents + weakest.driverId).distinct())
            }
            val deal = DriverDeal(move.driverId, move.toTeamId, move.years, move.salary, marketValueFor(move.driverId), buyoutFor(marketValueFor(move.driverId), move.years, move.driverId), newSeason, move.role)
            s = s.copy(contracts=s.contracts + deal, scheduled=s.scheduled.filterNot { it.driverId == move.driverId }, history=s.history + "Transferência ${driverName(move.driverId)} executada para ${move.toTeamId}")
        }
        s = resolveExpiredAndVacancies(s, newSeason, teamBudgets)
        return s.normalized()
    }

    fun scout(state: DriverMarketState, driverId: Int, teamId: Int, currentWeek: Int, season: Int = 2026): Pair<DriverMarketState, ScoutingReport> {
        require(driverId in allIds) { "Piloto inexistente" }
        val value=marketValueFor(driverId)
        val deal=state.contracts.firstOrNull { it.driverId==driverId }
        val remaining = deal?.let { (it.seasonSigned + it.years - season).coerceAtLeast(0) } ?: 0
        val report=ScoutingReport(driverId,teamId,500_000L,currentWeek,currentWeek+3,salaryFor(driverId),value,if(deal==null) 0 else buyoutFor(value, remaining, driverId),state.rolePreferences[driverId] ?: DriverRolePreference.INDIFFERENT,interestScore(state,driverId,teamId,salaryFor(driverId),DriverTeamRole.EQUAL,season))
        return state.copy(scouting=(state.scouting.filterNot { it.driverId==driverId && it.teamId==teamId }+report).takeLast(200),history=state.history+"Scouting concluído: ${driverName(driverId)}") to report
    }

    fun marketSummary(state: DriverMarketState, season: Int): String = "Contratados: ${state.contracts.count { it.activeIn(season) }} | Livres: ${freeAgents(state).size} | Propostas: ${state.pending.count { it.seasonTarget == season + 1 }} | Transferências: ${state.scheduled.count { it.startSeason == season + 1 }}"

    private fun resolveExpiredAndVacancies(input: DriverMarketState, season: Int, budgets: Map<Int,Long>): DriverMarketState {
        var s=input
        s.contracts.filter { !it.activeIn(season) }.forEach { d ->
            s=s.copy(contracts=s.contracts.filterNot { it.driverId==d.driverId }, freeAgents=(s.freeAgents+d.driverId).distinct(), history=s.history+"Contrato de ${driverName(d.driverId)} encerrado")
        }
        // AI fallback: fill vacancies using interest, not simply speed.
        for (team in WorldDatabase.teams) {
            while (s.rosterCount(team.id, season) < 2) {
                val candidate=freeAgents(s).maxByOrNull { id -> interestScore(s,id,team.id,salaryFor(id),DriverTeamRole.EQUAL,season) } ?: break
                val salary=(salaryFor(candidate)*1.05).roundToLong()
                val role=if (s.rosterCount(team.id,season)==0) DriverTeamRole.PILOT_1 else DriverTeamRole.PILOT_2
                val deal=DriverDeal(candidate,team.id,1,salary,marketValueFor(candidate),buyoutFor(marketValueFor(candidate),1,candidate),season,role)
                s=s.copy(contracts=s.contracts+deal,freeAgents=s.freeAgents-candidate,history=s.history+"IA contratou ${driverName(candidate)} para ${team.name}")
            }
        }
        return s
    }

    private fun DriverMarketState.rosterCount(teamId:Int,season:Int)=contracts.count { it.teamId==teamId && it.activeIn(season) }
    private fun roleCompatible(state: DriverMarketState, teamId:Int, driverId:Int, role:DriverTeamRole, season:Int, replacingDriverId:Int?=null):Boolean {
        if (role != DriverTeamRole.PILOT_1) return true
        return state.contracts.none { it.teamId==teamId && it.activeIn(season) && it.driverId != (replacingDriverId ?: driverId) && it.role==DriverTeamRole.PILOT_1 }
    }
    private fun overall(d: com.f1teammanager.core.season.DriverDefinition):Int = (d.speed+d.qualifying+d.overtaking+d.defense+d.consistency+d.wet+d.tyre)/7
    private fun teamPrestige(teamId:Int)=WorldDatabase.teams.first { it.id==teamId }.baseCar.coerceIn(40,100)
    private fun teamRecentPerformance(teamId:Int)=WorldDatabase.teams.first { it.id==teamId }.baseCar.coerceIn(40,100)
    private fun teamHistory(teamId:Int)=WorldDatabase.teams.first { it.id==teamId }.baseCar.coerceIn(40,100)
    private fun driverName(id:Int)=WorldDatabase.allDrivers.firstOrNull { it.id==id }?.name ?: "Piloto $id"
}
