package com.f1teammanager.core.manager

import java.util.Locale

/**
 * Home notification scope for the driver market. Completed contracts are global
 * sporting news; detailed proposal/counteroffer cards belong only to the player team.
 */
object DriverMarketHomeNotificationPolicy {
    val completedSignatureTitles = setOf(
        "RENOVAÇÃO DE CONTRATO", "CONTRATO ASSINADO", "CONTRATO FECHADO", "TRANSFERÊNCIA CONFIRMADA"
    )

    val playerNegotiationTitles = setOf(
        "PROPOSTA ENVIADA", "PROPOSTA RECUSADA", "PROPOSTA NÃO CONCLUÍDA",
        "CONTRAPROPOSTA RECEBIDA", "CONTRAPROPOSTA ENVIADA",
        "CONTRAPROPOSTA DA EQUIPE", "CONTRAPROPOSTA RECUSADA",
        "NEGOCIAÇÃO ENCERRADA", "OFERTA EXPIRADA",
        "CONTRAPROPOSTA RECUSADA NO FECHAMENTO"
    )

    fun isCompletedSignature(notice: MarketNotification): Boolean =
        notice.title.trim().uppercase(Locale.ROOT) in completedSignatureTitles

    fun isPlayerNegotiationStage(notice: MarketNotification, playerTeamName: String): Boolean {
        val title = notice.title.trim().uppercase(Locale.ROOT)
        if (title !in playerNegotiationTitles || playerTeamName.isBlank()) return false
        return notice.message.contains(playerTeamName.trim(), ignoreCase = true)
    }

    fun shouldShowOnHome(notice: MarketNotification, playerTeamName: String): Boolean =
        isCompletedSignature(notice) || isPlayerNegotiationStage(notice, playerTeamName)
}
