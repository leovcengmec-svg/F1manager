package com.f1teammanager.core

/** Shared bounds for persistent sporting ratings (driver attributes and car hardware).
 * Transient in-race wear/failure states are deliberately modeled separately.
 */
object AttributeBounds {
    const val MIN = 40
    const val MAX = 100

    fun rating(value: Int): Int = value.coerceIn(MIN, MAX)
    fun ratings(values: IntArray): IntArray = values.copyOf().also { array ->
        array.indices.forEach { array[it] = rating(array[it]) }
    }
}
