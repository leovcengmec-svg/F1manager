package com.f1teammanager.core.race

/**
 * Influência contínua dos componentes físicos do carro.
 *
 * Os valores oficiais dos componentes ocupam a faixa 40..100. A função level()
 * permanece apenas para compatibilidade de telas/auditorias; o motor de corrida
 * utiliza interpolação contínua, evitando que 90 e 99 tenham a mesma influência.
 */
object CarComponentInfluence {
    private val ratingAnchors = intArrayOf(40, 46, 52, 58, 64, 70, 76, 82, 88, 94, 100)

    fun level(value: Int): Int = (((value.coerceIn(40, 100) - 40) / 6) + 1).coerceIn(1, 10)

    private fun interpolate(value: Int, anchors: DoubleArray): Double {
        require(anchors.size == ratingAnchors.size)
        val rating = value.coerceIn(40, 100)
        if (rating <= ratingAnchors.first()) return anchors.first()
        if (rating >= ratingAnchors.last()) return anchors.last()
        val upperIndex = ratingAnchors.indexOfFirst { it >= rating }
        val lowerIndex = upperIndex - 1
        val lowerX = ratingAnchors[lowerIndex].toDouble()
        val upperX = ratingAnchors[upperIndex].toDouble()
        val fraction = (rating - lowerX) / (upperX - lowerX)
        return anchors[lowerIndex] + (anchors[upperIndex] - anchors[lowerIndex]) * fraction
    }

    /** Percentual aplicado ao tempo médio do GP: positivo = mais lento. */
    fun engineLapModifier(value: Int): Double = interpolate(value, doubleArrayOf(
        0.0300, 0.0235, 0.0175, 0.0115, 0.0055, 0.0000,
        -0.0055, -0.0115, -0.0175, -0.0235, -0.0280
    ))

    /** Chassi: tempo puro e estabilidade da volta. */
    fun chassisLapModifier(value: Int): Double = interpolate(value, doubleArrayOf(
        0.0240, 0.0190, 0.0140, 0.0090, 0.0045, 0.0000,
        -0.0045, -0.0090, -0.0140, -0.0190, -0.0230
    ))

    /** Asa dianteira: carga aerodinâmica e equilíbrio dianteiro. */
    fun frontWingLapModifier(value: Int): Double = interpolate(value, doubleArrayOf(
        0.0180, 0.0140, 0.0105, 0.0070, 0.0035, 0.0000,
        -0.0035, -0.0070, -0.0105, -0.0140, -0.0170
    ))

    /** Asa traseira: pequeno efeito de equilíbrio/eficiência além do DRS. */
    fun rearWingLapModifier(value: Int): Double = interpolate(value, doubleArrayOf(
        0.0060, 0.0048, 0.0036, 0.0024, 0.0012, 0.0000,
        -0.0012, -0.0024, -0.0036, -0.0048, -0.0060
    ))

    /** Freios: estabilidade em frenagens e repetibilidade nas zonas de desaceleração. */
    fun brakeLapModifier(value: Int): Double = interpolate(value, doubleArrayOf(
        0.0030, 0.0024, 0.0018, 0.0012, 0.0006, 0.0000,
        -0.0006, -0.0012, -0.0018, -0.0024, -0.0030
    ))

    /** MGU-K/ERS: pequena contribuição para aceleração e eficiência energética. */
    fun electricPowerUnitLapModifier(value: Int): Double = interpolate(value, doubleArrayOf(
        0.0040, 0.0032, 0.0024, 0.0016, 0.0008, 0.0000,
        -0.0008, -0.0016, -0.0024, -0.0032, -0.0040
    ))

    /** Eficiência da Asa dianteira no DRS. 1.00 = referência. */
    fun frontWingDrsEfficiency(value: Int): Double = interpolate(value, doubleArrayOf(
        0.70, 0.73, 0.76, 0.80, 0.85, 0.90, 0.94, 0.98, 1.02, 1.06, 1.10
    ))

    /** Eficiência da Asa traseira no DRS; a traseira é o componente principal. */
    fun rearWingDrsEfficiency(value: Int): Double = interpolate(value, doubleArrayOf(
        0.65, 0.69, 0.73, 0.78, 0.83, 0.88, 0.93, 0.98, 1.04, 1.10, 1.16
    ))

    /** Freios: eficiência de recuperação de ERS por frenagem. */
    fun brakeErsRecovery(value: Int): Double = interpolate(value, doubleArrayOf(
        0.70, 0.74, 0.78, 0.82, 0.86, 0.90, 0.94, 0.98, 1.04, 1.10, 1.15
    ))

    fun brakeDefenseEfficiency(value: Int): Double = interpolate(value, doubleArrayOf(
        0.80, 0.83, 0.86, 0.89, 0.92, 0.95, 0.98, 1.02, 1.06, 1.10, 1.14
    ))

    fun brakeOvertakingEfficiency(value: Int): Double = brakeDefenseEfficiency(value)

    /** MGU-K - ERS: eficiência de aproveitamento da energia. */
    fun electricPowerUnitErsEfficiency(value: Int): Double = interpolate(value, doubleArrayOf(
        0.70, 0.74, 0.78, 0.82, 0.86, 0.90, 0.94, 0.98, 1.04, 1.10, 1.15
    ))

    /** Redução da amplitude da variação natural da volta causada pelo carro. */
    fun chassisStabilityReduction(value: Int): Double = interpolate(value, doubleArrayOf(
        0.00, 0.04, 0.08, 0.12, 0.16, 0.20, 0.25, 0.30, 0.36, 0.42, 0.47
    ))
}
