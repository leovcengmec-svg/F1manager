package com.f1teammanager.core.race

/**
 * Escala oficial dos componentes do carro.
 * Valores físicos 40..100 são convertidos em 10 níveis de influência.
 * A base de tempo é sempre o tempo médio de referência da volta do GP.
 */
object CarComponentInfluence {
    fun level(value: Int): Int = when (value.coerceIn(40, 100)) {
        in 40..45 -> 1
        in 46..51 -> 2
        in 52..57 -> 3
        in 58..63 -> 4
        in 64..69 -> 5
        in 70..75 -> 6
        in 76..81 -> 7
        in 82..87 -> 8
        in 88..93 -> 9
        else -> 10
    }

    /** Percentual aplicado ao tempo médio do GP: positivo = mais lento. */
    fun engineLapModifier(value: Int): Double = when (level(value)) {
        1 -> 0.0300
        2 -> 0.0235
        3 -> 0.0175
        4 -> 0.0115
        5 -> 0.0055
        6 -> 0.0000
        7 -> -0.0055
        8 -> -0.0115
        9 -> -0.0175
        else -> -0.0235
    }

    /** Chassi tem efeito menor no tempo puro e maior na estabilidade da volta. */
    fun chassisLapModifier(value: Int): Double = when (level(value)) {
        1 -> 0.0240
        2 -> 0.0190
        3 -> 0.0140
        4 -> 0.0090
        5 -> 0.0045
        6 -> 0.0000
        7 -> -0.0045
        8 -> -0.0090
        9 -> -0.0140
        else -> -0.0190
    }

    /** Asa dianteira: efeito direto no tempo médio de referência do GP. */
    fun frontWingLapModifier(value: Int): Double = when (level(value)) {
        1 -> 0.0180
        2 -> 0.0140
        3 -> 0.0105
        4 -> 0.0070
        5 -> 0.0035
        6 -> 0.0000
        7 -> -0.0035
        8 -> -0.0070
        9 -> -0.0105
        else -> -0.0140
    }

    /** Eficiência da Asa dianteira no DRS. 1.00 = 100% da referência. */
    fun frontWingDrsEfficiency(value: Int): Double = when (level(value)) {
        1 -> 0.70
        2 -> 0.73
        3 -> 0.76
        4 -> 0.80
        5 -> 0.85
        6 -> 0.90
        7 -> 0.94
        8 -> 0.98
        9 -> 1.02
        else -> 1.06
    }

    /** Eficiência da Asa traseira no DRS. A traseira é o componente principal do DRS. */
    fun rearWingDrsEfficiency(value: Int): Double = when (level(value)) {
        1 -> 0.65
        2 -> 0.69
        3 -> 0.73
        4 -> 0.78
        5 -> 0.83
        6 -> 0.88
        7 -> 0.93
        8 -> 0.98
        9 -> 1.04
        else -> 1.10
    }


    /** Freios: eficiência de recuperação de ERS por frenagem. 1.00 = referência. */
    fun brakeErsRecovery(value: Int): Double = when (level(value)) {
        1 -> 0.70
        2 -> 0.74
        3 -> 0.78
        4 -> 0.82
        5 -> 0.86
        6 -> 0.90
        7 -> 0.94
        8 -> 0.98
        9 -> 1.04
        else -> 1.10
    }

    /** Freios: multiplicador da capacidade defensiva do piloto durante um duelo. */
    fun brakeDefenseEfficiency(value: Int): Double = when (level(value)) {
        1 -> 0.80
        2 -> 0.83
        3 -> 0.86
        4 -> 0.89
        5 -> 0.92
        6 -> 0.95
        7 -> 0.98
        8 -> 1.02
        9 -> 1.06
        else -> 1.10
    }

    /** Freios: multiplicador da capacidade de ataque/ultrapassagem do piloto durante um duelo. */
    fun brakeOvertakingEfficiency(value: Int): Double = when (level(value)) {
        1 -> 0.80
        2 -> 0.83
        3 -> 0.86
        4 -> 0.89
        5 -> 0.92
        6 -> 0.95
        7 -> 0.98
        8 -> 1.02
        9 -> 1.06
        else -> 1.10
    }

    /** Unidade elétrica: eficiência de aproveitamento da energia do ERS. 1.00 = referência. */
    fun electricPowerUnitErsEfficiency(value: Int): Double = when (level(value)) {
        1 -> 0.70
        2 -> 0.74
        3 -> 0.78
        4 -> 0.82
        5 -> 0.86
        6 -> 0.90
        7 -> 0.94
        8 -> 0.98
        9 -> 1.04
        else -> 1.10
    }

    /** Redução da amplitude da variação natural da volta causada pelo carro. */
    fun chassisStabilityReduction(value: Int): Double = when (level(value)) {
        1 -> 0.00
        2 -> 0.04
        3 -> 0.08
        4 -> 0.12
        5 -> 0.16
        6 -> 0.20
        7 -> 0.25
        8 -> 0.30
        9 -> 0.36
        else -> 0.42
    }
}
