package com.f1teammanager.core.career

/** Single source of truth for the career shell. No UI state belongs here. */
enum class CareerPhase { HOME, QUALIFYING, PRE_RACE, RACE, DECISION, RESULT, OFFSEASON, FINISHED }

data class CareerCheckpoint(
    val season: Int,
    val round: Int,
    val playerTeamId: Int,
    val phase: CareerPhase,
    val completedRounds: Int,
    val championshipPoints: Int,
    val constructorPoints: Int,
    val budget: Long
)

data class CareerEvent(val round: Int, val type: String, val message: String)

data class CareerFlowState(
    val season: Int = 2026,
    val round: Int = 1,
    val playerTeamId: Int = 1,
    val phase: CareerPhase = CareerPhase.HOME,
    val completedRounds: Int = 0,
    val championshipPoints: Int = 0,
    val constructorPoints: Int = 0,
    val budget: Long = 50_000_000,
    val events: List<CareerEvent> = emptyList()
) {
    fun checkpoint() = CareerCheckpoint(season, round, playerTeamId, phase, completedRounds, championshipPoints, constructorPoints, budget)
}
