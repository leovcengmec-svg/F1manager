package com.f1teammanager.core.manager

import com.f1teammanager.core.season.DriverProfileCatalog
import com.f1teammanager.core.season.DriverDefinition
import kotlin.random.Random

/**
 * Official driver-development facility: fixed programs, fixed duration and fixed
 * attribute points. It does not change class, evolution type or potential.
 */
data class DriverDevelopmentProgram(
    val driverId: Int,
    val startedWeek: Int,
    val totalWeeks: Int,
    val remainingWeeks: Int,
    val points: Int
) {
    fun normalized() = copy(
        startedWeek = startedWeek.coerceIn(1, 56),
        totalWeeks = totalWeeks.coerceIn(1, 56),
        remainingWeeks = remainingWeeks.coerceIn(0, totalWeeks),
        points = points.coerceAtLeast(0)
    )
}

data class DriverDevelopmentState(
    val programs: List<DriverDevelopmentProgram> = emptyList(),
    /** Points that could not be placed because every eligible attribute was at its ceiling. */
    val reservePoints: Map<Int, Int> = emptyMap()
) {
    fun normalized() = copy(
        programs = programs.map { it.normalized() }.distinctBy { it.driverId },
        reservePoints = reservePoints.mapValues { it.value.coerceAtLeast(0) }.filterValues { it > 0 }
    )
}

object DriverDevelopmentEngine {
    private data class Spec(val weeks: Int, val points: Int, val capacity: Int)

    private val specs = arrayOf(
        Spec(0, 0, 0),
        Spec(12, 2, 1),
        Spec(11, 3, 1),
        Spec(10, 4, 1),
        Spec(9, 5, 1),
        Spec(8, 6, 2),
        Spec(7, 7, 2),
        Spec(6, 8, 2),
        Spec(5, 9, 2),
        Spec(4, 10, 2),
        Spec(3, 12, 2)
    )

    fun capacity(level: Int): Int = spec(level).capacity
    fun weeks(level: Int): Int = spec(level).weeks
    fun points(level: Int): Int = spec(level).points

    private fun spec(level: Int): Spec = specs[level.coerceIn(0, 10)]

    fun start(
        state: DriverDevelopmentState,
        level: Int,
        driverId: Int,
        currentWeek: Int,
        teamDrivers: Set<Int>
    ): DriverDevelopmentState {
        val s = spec(level)
        require(level > 0) { "A instalação precisa estar acima do nível 0." }
        require(driverId in teamDrivers) { "O piloto não pertence à equipe." }
        val current = state.normalized()
        require(current.programs.none { it.driverId == driverId }) { "Este piloto já está em desenvolvimento." }
        require(current.programs.size < s.capacity) { "Não há vaga disponível no programa de desenvolvimento." }
        val program = DriverDevelopmentProgram(driverId, currentWeek, s.weeks, s.weeks, s.points)
        return current.copy(programs = current.programs + program).normalized()
    }

    fun advanceWeeks(
        state: DriverDevelopmentState,
        weeks: Int,
        currentWeek: Int,
        drivers: Map<Int, DriverDefinition>,
        attributes: Map<Int, IntArray>,
        seed: Int
    ): Result {
        if (weeks <= 0) return Result(state.normalized(), attributes, emptyList())
        val nextPrograms = mutableListOf<DriverDevelopmentProgram>()
        val nextReserve = state.reservePoints.toMutableMap()
        val nextAttributes = attributes.mapValues { it.value.copyOf() }.toMutableMap()
        val completed = mutableListOf<Completion>()

        state.normalized().programs.forEach { original ->
            val remaining = (original.remainingWeeks - weeks).coerceAtLeast(0)
            if (remaining > 0) {
                nextPrograms += original.copy(remainingWeeks = remaining)
            } else {
                val driver = drivers[original.driverId]
                val current = nextAttributes[original.driverId]
                if (driver != null && current != null) {
                    val total = original.points + (nextReserve[original.driverId] ?: 0)
                    val random = Random(seed + driver.id * 997 + currentWeek * 31 + original.startedWeek * 17)
                    val applied = distribute(driver, current, total, random)
                    nextAttributes[driver.id] = applied.values
                    if (applied.remaining > 0) nextReserve[driver.id] = applied.remaining else nextReserve.remove(driver.id)
                    completed += Completion(driver.id, original.points, applied.applied, applied.remaining, applied.values)
                }
            }
        }
        return Result(DriverDevelopmentState(nextPrograms, nextReserve).normalized(), nextAttributes, completed)
    }

    private data class Distribution(val values: IntArray, val applied: Int, val remaining: Int)

    private fun distribute(driver: DriverDefinition, source: IntArray, points: Int, random: Random): Distribution {
        val values = source.copyOf()
        val ceiling = DriverProfileCatalog.ceiling(driver.driverClass)
        var remaining = points.coerceAtLeast(0)
        var applied = 0
        while (remaining > 0) {
            val eligible = values.indices.filter { values[it] < ceiling }
            if (eligible.isEmpty()) break
            val index = eligible[random.nextInt(eligible.size)]
            values[index]++
            remaining--
            applied++
        }
        return Distribution(values, applied, remaining)
    }

    data class Completion(
        val driverId: Int,
        val programPoints: Int,
        val appliedPoints: Int,
        val reservedPoints: Int,
        val attributes: IntArray
    )

    data class Result(
        val state: DriverDevelopmentState,
        val attributes: Map<Int, IntArray>,
        val completed: List<Completion>
    )
}
