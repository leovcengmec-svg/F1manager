package com.f1teammanager.core.game

import com.f1teammanager.core.manager.*
import com.f1teammanager.core.season.*
import java.io.File

/** V23 career save. Race sessions are intentionally not serialized; saves are taken between races. */
object GameSave {
    fun save(file:File, engine:UnifiedGameEngine) {
        val m=engine.managerState(); val s=engine.seasonState()
        file.parentFile?.mkdirs()
        file.writeText(buildString {
            appendLine("F1TM_SAVE_V23")
            appendLine("season=${s.season}"); appendLine("round=${s.currentRound}")
            appendLine("standings=${map(s.standings)}"); appendLine("wins=${map(s.wins)}"); appendLine("podiums=${map(s.podiums)}"); appendLine("starts=${map(s.starts)}")
            appendLine("team=${m.playerTeamId}"); appendLine("budget=${m.finance.budget}")
            appendLine("aero=${m.car.aerodynamics}"); appendLine("chassis=${m.car.chassis}"); appendLine("engine=${m.car.engine}"); appendLine("reliability=${m.car.reliability}")
            appendLine("rep=${m.manager.reputation}"); appendLine("experience=${m.manager.experience}")
        })
    }
    fun load(file:File):Pair<SeasonState,Map<String,String>>?=runCatching {
        val lines=file.readLines(); require(lines.firstOrNull()=="F1TM_SAVE_V23")
        val p=lines.drop(1).mapNotNull { line -> line.split("=",limit=2).takeIf{it.size==2}?.let{it[0] to it[1]} }.toMap()
        SeasonState(p["season"]!!.toInt(),p["round"]!!.toInt(),parse(p["standings"]),parse(p["wins"]),parse(p["podiums"]),parse(p["starts"])) to p
    }.getOrNull()
    private fun map(m:Map<Int,Int>)=m.entries.joinToString(","){"${it.key}:${it.value}"}
    private fun parse(v:String?):Map<Int,Int> = if(v.isNullOrBlank()) emptyMap() else v.split(',').associate { val x=it.split(':'); x[0].toInt() to x[1].toInt() }
}
