package com.f1teammanager.core.manager

/**
 * Durable at-least-once GP finalization journal. Steps must execute in the canonical
 * order; each action must still provide its own idempotency key because a process may
 * die after an action commits but before its marker is persisted.
 */
class RaceFinalizationJournal(
    private val season: Int,
    private val round: Int,
    private val isDone: (season: Int, round: Int, step: String) -> Boolean,
    private val markDone: (season: Int, round: Int, step: String) -> Boolean,
    private val totalRounds: Int = 30
) {
    private val plannedSteps: List<String>
        get() = RaceFinalizationPlan.steps(round, totalRounds)

    init {
        require(season > 0) { "Season must be positive" }
        require(round in 1..totalRounds) { "Round must be within the season" }
        require(totalRounds > 0) { "Total rounds must be positive" }
    }

    @Synchronized
    fun runStep(step: String, action: () -> Unit) {
        require(step in plannedSteps) { "Etapa '$step' não faz parte do plano do GP $round/$season" }
        val index = plannedSteps.indexOf(step)
        val incompletePredecessor = plannedSteps.take(index).firstOrNull { !isDone(season, round, it) }
        check(incompletePredecessor == null) {
            "Não é possível executar '$step': a etapa anterior '$incompletePredecessor' ainda não foi confirmada"
        }
        if (isDone(season, round, step)) return
        action()
        check(markDone(season, round, step)) {
            "Não foi possível persistir a etapa '$step' do GP $round/temporada $season"
        }
    }

    /** Commit the terminal marker only after every planned side-effect step is durable. */
    @Synchronized
    fun complete() {
        val missing = plannedSteps.firstOrNull { !isDone(season, round, it) }
        check(missing == null) {
            "Não é possível concluir o GP $round/temporada $season: etapa '$missing' pendente"
        }
        if (isDone(season, round, RaceFinalizationPlan.COMPLETE)) return
        check(markDone(season, round, RaceFinalizationPlan.COMPLETE)) {
            "Não foi possível persistir a conclusão do GP $round/temporada $season"
        }
    }
}
