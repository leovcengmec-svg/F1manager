package com.f1teammanager.core.season

import java.io.File

/** Dependency-free save format for Android filesDir. One line per map entry. */
object SaveGame {
    fun save(file:File,state:SeasonState){ file.parentFile?.mkdirs(); file.writeText(buildString { appendLine("F1TM_SAVE_V6"); appendLine("season=${state.season}"); appendLine("round=${state.currentRound}"); appendLine("points=${state.standings.entries.joinToString(","){"${it.key}:${it.value}"}}"); appendLine("wins=${state.wins.entries.joinToString(","){"${it.key}:${it.value}"}}"); appendLine("podiums=${state.podiums.entries.joinToString(","){"${it.key}:${it.value}"}}"); appendLine("starts=${state.starts.entries.joinToString(","){"${it.key}:${it.value}"}}") }) }
    fun load(file:File):SeasonState?=runCatching { val m=file.readLines().associate { val p=it.split("=",limit=2); p[0] to p.getOrElse(1){""} }; require(m["F1TM_SAVE_V6"]==""); SeasonState((m["season"]?:"2026").toInt(),(m["round"]?:"1").toInt(),parse(m["points"]),parse(m["wins"]),parse(m["podiums"]),parse(m["starts"])) }.getOrNull()
    private fun parse(s:String?):Map<Int,Int> = if(s.isNullOrBlank()) emptyMap() else s.split(',').associate { val p=it.split(':'); p[0].toInt() to p[1].toInt() }
}
