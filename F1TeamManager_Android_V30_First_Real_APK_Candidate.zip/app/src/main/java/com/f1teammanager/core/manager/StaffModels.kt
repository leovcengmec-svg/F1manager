package com.f1teammanager.core.manager

enum class StaffRole { TEAM_PRINCIPAL, TECHNICAL_DIRECTOR, COMMERCIAL_MANAGER }
enum class SupplierType { ENGINE, TYRE }

data class StaffMember(
    val id: Int,
    val name: String,
    val role: StaffRole,
    val skill: Int,
    val salary: Long,
    val contractYears: Int,
    val reputation: Int = 50,
    val teamId: Int? = null
) { fun normalized() = copy(skill=skill.coerceIn(1,100), reputation=reputation.coerceIn(1,100)) }

data class SupplierContract(
    val type: SupplierType,
    val name: String,
    val performance: Int,
    val reliability: Int,
    val annualCost: Long,
    val years: Int
) { fun normalized() = copy(performance=performance.coerceIn(1,100), reliability=reliability.coerceIn(1,100)) }

data class SponsorContract(
    val name: String,
    val upfront: Long,
    val racePayment: Long,
    val pointsBonus: Long,
    val years: Int,
    val minimumReputation: Int,
    val slot: Int = 1,
    val qualifyingTarget: Int = 0,
    val qualifyingBonus: Long = 0L,
    val raceTarget: Int = 0,
    val raceTargetBonus: Long = 0L,
    val active: Boolean = false,
    val races: Int = 5,
    val racesRemaining: Int = races
)

data class ContractOffer(
    val targetId: Int,
    val role: String,
    val salary: Long,
    val years: Int,
    val signingBonus: Long,
    val desirability: Int
)
