package com.f1teammanager.core.season

/** Real persisted career point. Future projections are deliberately stored separately by the UI. */
data class DriverEvolutionSnapshot(
    val driverId: Int,
    val season: Int,
    val age: Int,
    val cycleIndex: Int,
    val overall: Int,
    val attributes: List<Int>,
    val eventType: String
) {
    init {
        require(driverId > 0)
        require(season >= 2026)
        require(age in 18..45)
        require(cycleIndex >= 0)
        require(overall in 40..100)
        require(attributes.size == 7 && attributes.all { it in 40..100 })
        require(eventType in setOf("BASELINE", "SEASON_END", "CYCLE_RESET"))
    }
}
