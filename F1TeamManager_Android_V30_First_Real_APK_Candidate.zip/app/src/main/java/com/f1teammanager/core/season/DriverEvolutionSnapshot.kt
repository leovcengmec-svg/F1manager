package com.f1teammanager.core.season

/** Real persisted career point. Future projections are deliberately stored separately by the UI. */
data class DriverEvolutionSnapshot(
    val driverId: Int,
    val season: Int,
    val age: Int,
    val cycleIndex: Int,
    val overall: Int,
    val attributes: List<Int>,
    val eventType: String
) {
    init {
        require(driverId > 0)
        require(season >= 2026)
        require(age in 16..45)
        require(cycleIndex >= 0)
        require(overall in 40..100)
        require(attributes.size == 7 && attributes.all { it in 40..100 })
        require(eventType in setOf("BASELINE", "SEASON_END", "CYCLE_RESET"))
    }
}


/** Presentation-only selector: history stays archived, while the chart shows the newest age cycle. */
object DriverEvolutionChartModel {
    fun currentCycle(snapshots: List<DriverEvolutionSnapshot>): List<DriverEvolutionSnapshot> {
        val cycle = snapshots.maxOfOrNull { it.cycleIndex } ?: return emptyList()
        return snapshots.asSequence()
            .filter { it.cycleIndex == cycle }
            .sortedWith(compareBy<DriverEvolutionSnapshot> { it.season }.thenBy { it.eventType })
            .toList()
    }

    /** The chart exposes only the first and latest real snapshot as visible markers. */
    fun endpoints(snapshots: List<DriverEvolutionSnapshot>): Pair<DriverEvolutionSnapshot, DriverEvolutionSnapshot>? {
        val active = currentCycle(snapshots)
        if (active.isEmpty()) return null
        return active.first() to active.last()
    }
}
