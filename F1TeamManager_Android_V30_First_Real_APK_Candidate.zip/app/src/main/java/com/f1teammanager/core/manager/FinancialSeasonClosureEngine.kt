package com.f1teammanager.core.manager

/**
 * Single authority for financial season closure.
 * A team may operate below zero during the season, but it cannot carry a negative
 * balance through the season boundary without a technical penalty.
 */
object FinancialSeasonClosureEngine {
    const val NEGATIVE_BALANCE_COMPONENT_PENALTY_PERCENT = 20

    data class CarPenaltyResult(
        val car: TeamCarState,
        val penalized: Boolean,
        val balanceAtClosure: Long
    )

    fun applyPlayerPenalty(state: TeamManagerState): TeamManagerState {
        val result = applyCarPenalty(state.car, state.finance.budget)
        return if (!result.penalized) state else state.copy(
            car = result.car,
            history = state.history + "Penalidade financeira: saldo €${result.balanceAtClosure}; -20% nos 6 componentes do carro"
        )
    }

    private val aiPenalties = mutableSetOf<Pair<Int,Int>>()

    fun recordAiPenalty(teamId: Int, season: Int) { aiPenalties.add(teamId to season) }
    fun aiPenaltyActive(teamId: Int, season: Int): Boolean = (teamId to (season - 1)) in aiPenalties

    fun applyCarPenalty(car: TeamCarState, balanceAtClosure: Long): CarPenaltyResult {
        if (balanceAtClosure >= 0L) return CarPenaltyResult(car, false, balanceAtClosure)
        fun reduce(v: Int): Int = (v * (100 - NEGATIVE_BALANCE_COMPONENT_PENALTY_PERCENT) / 100).coerceAtLeast(1)
        val penalized = car.copy(
            engine = reduce(car.engine),
            chassis = reduce(car.chassis),
            frontWing = reduce(car.frontWing),
            rearWing = reduce(car.rearWing),
            brakes = reduce(car.brakes),
            electricPowerUnit = reduce(car.electricPowerUnit)
        ).copy(aerodynamics = maxOf(reduce(car.frontWing), reduce(car.rearWing))).normalized()
        return CarPenaltyResult(penalized, true, balanceAtClosure)
    }
}
