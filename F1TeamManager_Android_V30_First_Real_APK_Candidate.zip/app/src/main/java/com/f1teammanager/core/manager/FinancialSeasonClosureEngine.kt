package com.f1teammanager.core.manager

/**
 * Single authority for financial season closure.
 * A team may operate below zero during the season, but it cannot carry a negative
 * balance through the season boundary without a technical penalty.
 */
object FinancialSeasonClosureEngine {
    const val NEGATIVE_BALANCE_COMPONENT_PENALTY_PERCENT = 20

    data class CarPenaltyResult(
        val car: TeamCarState,
        val penalized: Boolean,
        val balanceAtClosure: Long
    )

    fun applyPlayerPenalty(state: TeamManagerState): TeamManagerState {
        val effectiveClosingBalance = FinanceEngine().effectiveClosingBalance(state.finance)
        val result = applyCarPenalty(state.car, effectiveClosingBalance)
        return if (!result.penalized) state else state.copy(
            car = result.car,
            garage = state.garage?.let { applyGaragePenalty(it) },
            history = state.history + "Penalidade financeira: saldo €${result.balanceAtClosure}; -20% nos 6 componentes do carro físico"
        )
    }

    fun applyGaragePenalty(garage: TeamGarage): TeamGarage {
        fun reduce(v: Int): Int = if (v <= 0) 0 else (v * (100 - NEGATIVE_BALANCE_COMPONENT_PENALTY_PERCENT) / 100).coerceIn(40, 100)
        fun physical(c: PhysicalCar, component: CarComponent, value: Int): Int =
            if (component !in c.installedPieces) 0 else reduce(value)
        fun car(c: PhysicalCar): PhysicalCar {
            val reliabilities = c.componentReliabilities.mapValues { (_, value) -> (value * (100 - NEGATIVE_BALANCE_COMPONENT_PENALTY_PERCENT) / 100).coerceIn(40, 100) }
            return c.copy(
                engine = physical(c, CarComponent.ENGINE, c.engine),
                chassis = physical(c, CarComponent.CHASSIS, c.chassis),
                frontWing = physical(c, CarComponent.FRONT_WING, c.frontWing),
                rearWing = physical(c, CarComponent.REAR_WING, c.rearWing),
                brakes = physical(c, CarComponent.BRAKES, c.brakes),
                electricPowerUnit = physical(c, CarComponent.ELECTRIC_POWER_UNIT, c.electricPowerUnit),
                reliability = reduce(c.reliability),
                componentReliabilities = reliabilities
            ).normalized()
        }
        return garage.copy(car1 = car(garage.car1), car2 = car(garage.car2)).normalized()
    }

    private val aiPenalties = mutableSetOf<Pair<Int,Int>>()

    fun recordAiPenalty(teamId: Int, season: Int) { aiPenalties.add(teamId to season) }
    fun aiPenaltyActive(teamId: Int, season: Int): Boolean = (teamId to (season - 1)) in aiPenalties

    fun applyCarPenalty(car: TeamCarState, balanceAtClosure: Long): CarPenaltyResult {
        if (balanceAtClosure >= 0L) return CarPenaltyResult(car, false, balanceAtClosure)
        fun reduce(v: Int): Int = if (v <= 0) 0 else (v * (100 - NEGATIVE_BALANCE_COMPONENT_PENALTY_PERCENT) / 100).coerceIn(40, 100)
        val penalized = car.copy(
            engine = reduce(car.engine),
            chassis = reduce(car.chassis),
            frontWing = reduce(car.frontWing),
            rearWing = reduce(car.rearWing),
            brakes = reduce(car.brakes),
            electricPowerUnit = reduce(car.electricPowerUnit)
        ).copy(aerodynamics = maxOf(reduce(car.frontWing), reduce(car.rearWing))).normalized()
        return CarPenaltyResult(penalized, true, balanceAtClosure)
    }
}
