package com.f1teammanager.core.manager

class StaffMarketEngine {
    fun staffPool(): List<StaffMember> = listOf(
        StaffMember(1,"Adrian Keller",StaffRole.TECHNICAL_DIRECTOR,88,3_200_000,2,86),
        StaffMember(2,"Marina Costa",StaffRole.COMMERCIAL_MANAGER,82,2_100_000,2,80),
        StaffMember(3,"Henrik Bauer",StaffRole.TEAM_PRINCIPAL,91,4_000_000,2,92),
        StaffMember(4,"Sofia Martins",StaffRole.TECHNICAL_DIRECTOR,76,1_900_000,2,74),
        StaffMember(5,"Victor Moreau",StaffRole.COMMERCIAL_MANAGER,89,2_700_000,3,87),
        StaffMember(6,"Daniel Rossi",StaffRole.TEAM_PRINCIPAL,79,2_400_000,2,77)
    )

    fun supplierPool(): List<SupplierContract> = listOf(
        SupplierContract(SupplierType.ENGINE,"Apex Power",94,91,18_000_000,2),
        SupplierContract(SupplierType.ENGINE,"Velocity Works",88,86,13_000_000,2),
        SupplierContract(SupplierType.ENGINE,"Nova Motorsport",82,94,10_000_000,3),
        SupplierContract(SupplierType.TYRE,"Pirelli",92,93,12_000_000,2),
        SupplierContract(SupplierType.TYRE,"Bridgestone",87,90,9_000_000,2),
        SupplierContract(SupplierType.TYRE,"Continental Racing",81,88,7_000_000,3)
    )

    fun generateOffer(member: StaffMember, manager: TeamManagerState): ContractOffer {
        val desirability=(manager.manager.reputation + member.reputation + manager.manager.experience/2)/2
        return ContractOffer(member.id,member.role.name,member.salary,member.contractYears,member.salary/10,desirability.coerceIn(1,100))
    }
}
