package com.f1teammanager.core.manager

enum class SponsorCategory { BASICO, REGIONAL, NACIONAL, INTERNACIONAL, PREMIUM, GLOBAL }

data class SponsorProfile(val name:String, val category:SponsorCategory, val master:Boolean)

/** Real commercial brands used as the sponsorship pool. A sponsor exists only once in this catalog. */
object SponsorCatalog {
    private val names = mapOf(
        SponsorCategory.BASICO to listOf("Castrol","Shell","Mobil 1","DHL","Pirelli","Michelin","Bosch","SKF","Brembo","NGK","Valeo","ZF","Mahle","Bilstein","Schaeffler","Webasto","Hella","Akrapovic","OMP","Sparco","Motul","Liqui Moly","Elf","TotalEnergies","Europcar","Avis","Sixt","UPS","FedEx","Garmin"),
        SponsorCategory.REGIONAL to listOf("Emirates","Qatar Airways","Etihad Airways","Gulf Air","Petronas","Aramco","DP World","Maersk","Kuehne+Nagel","Adecco","Randstad","Manpower","Continental","Goodyear","Hankook","Bridgestone","Osram","Philips","Panasonic","Hitachi","Yokohama","Rexona","Nivea","Red Bull","Monster Energy","Coca-Cola","Pepsi","Heineken","Carlsberg","Marriott"),
        SponsorCategory.NACIONAL to listOf("Santander","HSBC","Barclays","Lloyds Bank","NatWest","Standard Chartered","Banco do Brasil","Bradesco","Itaú","Nubank","Caixa","Mercado Livre","Magazine Luiza","Americanas","Natura","Ambev","Vale","Embraer","Gerdau","Vivo","Claro","TIM","Telefónica","Orange","Vodafone","Rakuten","Lenovo","Acer","Dell Technologies","HP"),
        SponsorCategory.INTERNACIONAL to listOf("Oracle","SAP","Salesforce","Accenture","IBM","Cisco","Qualcomm","Intel","AMD","Microsoft","Google","Amazon Web Services","AWS","Adobe","Atlassian","Dell","Siemens","Schneider Electric","Honeywell","ABB","3M","FedEx Express","UPS Airlines","Visa","Mastercard","American Express","Booking.com","Expedia","Hilton","Marriott International"),
        SponsorCategory.PREMIUM to listOf("Puma","Adidas","Nike","Under Armour","New Balance","TAG Heuer","Rolex","Richard Mille","IWC Schaffhausen","Hublot","Brembo Racing","Alpinestars","Bell Racing","Oakley","Ray-Ban","Tommy Hilfiger","Hugo Boss","Giorgio Armani","Louis Vuitton","Moët & Chandon","Monster Energy Ultra","Red Bull Racing","Heineken 0.0","Lenovo Legion","AWS Motorsport","Cognizant","MoneyGram","Workday","Splunk","Deloitte"),
        SponsorCategory.GLOBAL to listOf("Aston Martin","McLaren Automotive","Mercedes-Benz","Ferrari","Audi","BMW","Ford","Honda","Toyota","Hyundai","Kia","Porsche","Lamborghini","Bentley","Genesis","Cadillac","Chevrolet","Shell V-Power","Petronas Syntium","Aramco Global","Oracle Red Bull Racing","Visa Cash App","Pirelli P Zero","DHL Express","Bain & Company","EY","PwC","NVIDIA","KPMG","Google Cloud")
    )

    // The first 10 in each category are eligible for Slot 1 (Master); all 30 are eligible for secondary slots.
    val all:List<SponsorProfile> = SponsorCategory.values().flatMap { category ->
        names.getValue(category).distinct().mapIndexed { index, name -> SponsorProfile(name, category, index < 10) }
    }.distinctBy { it.name }

    fun pool(category:SponsorCategory, master:Boolean):List<SponsorProfile> =
        all.filter { it.category == category && (!master || it.master) }
}
