package com.f1teammanager.core.manager

import kotlin.math.roundToLong

/**
 * Compatibility and migration pricing for sponsor contracts created before every
 * sponsorship paid both an entry fee and a per-GP amount.
 * Existing non-zero negotiated terms are preserved; only the missing payment
 * component is restored so old careers continue under the V619 commercial rule.
 */
object SponsorContractPricing {
    /**
     * Diminishing-return commercial curve for new contracts.
     * Levels 0-3 preserve the previous balance; from level 4 onward each level
     * adds only 0.75 percentage point instead of 2.5. Existing signed contracts
     * are never repriced, so the adjustment affects only future signatures.
     */
    fun commercialMultiplier(marketingLevel: Int): Double {
        val level = marketingLevel.coerceIn(0, 10)
        return if (level <= 3) 1.60 + level * 0.025
        else 1.675 + (level - 3) * 0.0075
    }

    private data class Band(
        val entryMin: Double, val entryMax: Double,
        val gpMin: Double, val gpMax: Double
    )

    private fun band(category: SponsorCategory): Band = when (category) {
        SponsorCategory.BASICO -> Band(1.0, 2.0, 0.15, 0.30)
        SponsorCategory.REGIONAL -> Band(2.0, 3.5, 0.25, 0.45)
        SponsorCategory.NACIONAL -> Band(3.0, 5.0, 0.35, 0.60)
        SponsorCategory.INTERNACIONAL -> Band(4.5, 7.0, 0.50, 0.80)
        SponsorCategory.PREMIUM -> Band(6.0, 9.0, 0.65, 1.00)
        SponsorCategory.GLOBAL -> Band(8.0, 12.0, 0.85, 1.30)
    }

    /** Returns a migrated copy and never changes a payment component already agreed. */
    @Suppress("UNUSED_PARAMETER")
    fun ensureEntryAndGp(
        contract: SponsorContract,
        teamId: Int,
        season: Int,
        marketingLevel: Int
    ): SponsorContract {
        if (contract.upfront > 0L && contract.racePayment > 0L) return contract
        if (!contract.active && contract.upfront <= 0L && contract.racePayment <= 0L) return contract

        val category = runCatching { SponsorCategory.valueOf(contract.category.uppercase()) }
            .getOrDefault(SponsorCategory.BASICO)
        val band = band(category)
        val master = contract.slot == 1
        // This is a compatibility migration of an already signed contract, not a
        // new offer or renewal. Add only the missing legacy component at base value.
        val rawSeed = contract.name.hashCode().toLong() xor (teamId.toLong() * 97L) xor
            (season.toLong() * 31L) xor (contract.slot.toLong() * 13L)
        val ratio = Math.floorMod(rawSeed, 100L) / 99.0
        fun value(min: Double, max: Double) = (min + (max - min) * ratio) * 1_000_000.0

        val entry = if (contract.upfront > 0L) contract.upfront else {
            val min = if (master) band.entryMin * 1.7 else band.entryMin
            val max = if (master) band.entryMax * 2.2 else band.entryMax
            value(min, max).roundToLong().coerceAtLeast(1L)
        }
        val gp = if (contract.racePayment > 0L) contract.racePayment else {
            val min = if (master) band.gpMin * 1.8 else band.gpMin
            val max = if (master) band.gpMax * 2.0 else band.gpMax
            value(min, max).roundToLong().coerceAtLeast(1L)
        }
        return contract.copy(upfront = entry, racePayment = gp)
    }
}
