package com.f1teammanager.core.manager

/**
 * V36: single source of truth for end-of-season constructors settlement.
 * Every execution path (Android UI and headless season simulation) must use this
 * object. It only calculates immutable settlement data; persistence is owned by
 * the active career store.
 */
object SeasonSettlementEngine {
    data class Settlement(val teamId: Int, val position: Int, val prize: Long)

    fun rank(constructorPoints: Map<Int, Int>): List<Pair<Int, Long>> =
        SeasonPrizeEngine.rankTeams(constructorPoints)

    fun settleAll(constructorPoints: Map<Int, Int>): List<Settlement> =
        rank(constructorPoints).mapIndexed { index, row ->
            Settlement(row.first, index + 1, row.second)
        }.sortedBy { it.position }

    fun forTeam(teamId: Int, constructorPoints: Map<Int, Int>): Settlement? =
        settleAll(constructorPoints).firstOrNull { it.teamId == teamId }

    fun prizeFor(teamId: Int, constructorPoints: Map<Int, Int>): Long =
        forTeam(teamId, constructorPoints)?.prize ?: 0L
}
