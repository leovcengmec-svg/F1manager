package com.f1teammanager.core.manager

import java.util.Locale

/**
 * Scope Home popups to the career team. The central news archive remains global,
 * but negotiations belonging only to AI-vs-AI teams must not interrupt the player.
 */
object PlayerHomeNotificationPolicy {
    private val playerMarketTitles = setOf(
        "PROPOSTA ENVIADA",
        "PROPOSTA RECEBIDA",
        "PROPOSTA RECUSADA",
        "PROPOSTA NÃO CONCLUÍDA",
        "OFERTA EXPIRADA",
        "CONTRAPROPOSTA ENVIADA",
        "CONTRAPROPOSTA RECEBIDA",
        "CONTRAPROPOSTA DA EQUIPE",
        "CONTRAPROPOSTA RECUSADA",
        "CONTRAPROPOSTA RECUSADA NO FECHAMENTO",
        "NEGOCIAÇÃO ENCERRADA",
        "RENOVAÇÃO DE CONTRATO",
        "CONTRATO ASSINADO",
        "CONTRATO FECHADO",
        "TRANSFERÊNCIA CONFIRMADA",
        "TRANSFERÊNCIA CANCELADA",
        "CONTRATO NÃO APLICADO"
    )

    private val completedSignatureTitles = setOf(
        "RENOVAÇÃO DE CONTRATO", "CONTRATO ASSINADO", "CONTRATO FECHADO", "TRANSFERÊNCIA CONFIRMADA"
    )

    fun isCompletedSignature(notice: MarketNotification): Boolean =
        notice.title.trim().uppercase(Locale.ROOT) in completedSignatureTitles

    fun isPlayerMarketEvent(
        notice: MarketNotification,
        playerTeamId: Int,
        playerTeamName: String
    ): Boolean {
        val title = notice.title.trim().uppercase(Locale.ROOT)
        if (title in completedSignatureTitles) return true // Global sporting news for every team.
        if (title !in playerMarketTitles || playerTeamId <= 0) return false
        return when (notice.relatedTeamId) {
            playerTeamId -> true
            null -> playerTeamName.isNotBlank() && notice.message.contains(playerTeamName.trim(), ignoreCase = true)
            else -> false
        }
    }

    fun isPlayerResearchEvent(
        notice: MarketNotification,
        playerTeamId: Int,
        playerTeamName: String
    ): Boolean {
        val title = notice.title.trim()
        if (!title.equals("P&D CONCLUÍDO", ignoreCase = true) &&
            !title.equals("FALHA NO P&D — DESIGN NÃO CONCLUÍDO", ignoreCase = true)) return false
        return when (notice.relatedTeamId) {
            playerTeamId -> playerTeamId > 0
            null -> isPlayerResearchMessage(notice.message, playerTeamName)
            else -> false
        }
    }

    /** Legacy message matching retained for saves created before V686. */
    fun isPlayerResearchMessage(message: String, playerTeamName: String): Boolean {
        val team = playerTeamName.trim()
        if (team.isEmpty()) return false
        return message.startsWith("$team ", ignoreCase = true) ||
            message.startsWith("$team:", ignoreCase = true)
    }

    /**
     * Build failure cards from the actual project outcome and remaining duration.
     * This is more reliable than inferring a failure from a project disappearing
     * from the active list after a multi-week calendar jump.
     */
    fun failedResearchNotices(
        projectsBeforeAdvance: List<ResearchProject>,
        season: Int,
        currentWeek: Int,
        targetWeek: Int,
        playerTeamId: Int,
        playerTeamName: String
    ): List<MarketNotification> {
        val elapsedWeeks = (targetWeek - currentWeek).coerceAtLeast(0)
        if (elapsedWeeks == 0 || playerTeamId <= 0 || playerTeamName.isBlank()) return emptyList()
        return projectsBeforeAdvance
            .filter { it.outcome == ResearchOutcome.FAILURE && it.remainingWeeks.coerceAtLeast(1) <= elapsedWeeks }
            .distinctBy { it.projectId }
            .map { project ->
                val completedWeek = (currentWeek + project.remainingWeeks.coerceAtLeast(1)).coerceAtMost(targetWeek)
                MarketNotification(
                    season = season,
                    week = completedWeek,
                    title = "FALHA NO P&D — DESIGN NÃO CONCLUÍDO",
                    message = "$playerTeamName: a tentativa de ${componentLabel(project.component)} V${project.version} falhou. Nenhum novo design foi criado; a tecnologia anterior foi preservada. O custo e o tempo desta tentativa foram consumidos. É possível iniciar uma nova tentativa.",
                    important = true,
                    category = MarketNewsCategory.TEAM_EVOLUTION,
                    relatedTeamId = playerTeamId
                )
            }
    }

    private fun componentLabel(component: CarComponent): String = when (component) {
        CarComponent.ENGINE -> "Motor - ICE"
        CarComponent.CHASSIS -> "Chassi"
        CarComponent.FRONT_WING -> "Asa dianteira"
        CarComponent.REAR_WING -> "Asa traseira"
        CarComponent.BRAKES -> "Freios"
        CarComponent.ELECTRIC_POWER_UNIT -> "MGU-K - ERS"
    }
}
