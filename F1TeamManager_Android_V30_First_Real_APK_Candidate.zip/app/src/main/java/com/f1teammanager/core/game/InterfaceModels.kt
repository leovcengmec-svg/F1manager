package com.f1teammanager.core.game

import com.f1teammanager.core.manager.*
import com.f1teammanager.core.race.*
import com.f1teammanager.core.season.*

data class CalendarCard(val round:Int,val grandPrix:String,val circuit:String,val laps:Int,val isCurrent:Boolean,val completed:Boolean)
data class StandingCard(val position:Int,val driverId:Int,val driverName:String,val teamName:String,val points:Int,val wins:Int,val podiums:Int)
data class FinanceCard(val budget:Long,val income:Long,val expenses:Long,val net:Long)
data class CarCard(val aero:Int,val chassis:Int,val engine:Int,val reliability:Int,val overall:Int,val activeProject:String?)
data class DriverCard(val id:Int,val name:String,val team:String,val overall:Int,val role:String)
data class RaceCard(
    val phase:String,val lap:Int,val totalLaps:Int,val currentPosition:Int?,val tyre:Tyre?,val tyreWear:Int?,val fuelPercent:Int?,
    val posture:DriverPosture?,val neutralisation:Neutralisation,val pendingDecision:PendingManagerDecision?,val alerts:List<DriverAlert>,val completed:Boolean
)
data class InterfaceSnapshot(
    val season:Int,val round:Int,val teamId:Int,val teamName:String,val managerName:String,val reputation:Int,
    val nextRace:CalendarCard,val calendar:List<CalendarCard>,val standings:List<StandingCard>,val finance:FinanceCard,
    val car:CarCard,val drivers:List<DriverCard>,val race:RaceCard?,val messages:List<String>
)
