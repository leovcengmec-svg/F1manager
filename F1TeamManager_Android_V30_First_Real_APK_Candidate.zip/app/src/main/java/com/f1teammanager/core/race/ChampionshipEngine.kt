package com.f1teammanager.core.race

object ChampionshipEngine {
    val pointsTable = listOf(100,98,95,93,90,88,86,83,81,79,76,74,72,70,67,65,63,61,59,57,55,53,51,49,47,45,43,41,40,38,36,34,33,31,29,28,26,24,23,21,20,19,17,16,15,13,12,11,10,9,8,7,6,5,4,3,3,2,2,1)

    fun pointsForPosition(position: Int): Int = if (position in 1..pointsTable.size) pointsTable[position - 1] else 0

    fun award(result: RaceResult): Map<Int, Int> = result.classification
        .filter { it.status == "FINISHED" }
        .associate { it.driverId to pointsForPosition(it.position) }
}
