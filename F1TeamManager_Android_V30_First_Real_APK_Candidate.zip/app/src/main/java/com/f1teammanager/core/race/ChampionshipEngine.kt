package com.f1teammanager.core.race

object ChampionshipEngine {
    val pointsTable = listOf(100, 85, 75, 68, 62, 57, 53, 49, 45, 42, 39, 36, 33, 30, 28, 26, 24, 22, 20, 18, 16, 15, 14, 13, 12, 12, 11, 10, 9, 8, 7, 6, 5, 4, 4, 3, 3, 3, 3, 3, 2, 2, 2, 2, 2, 1, 1, 1, 1, 1)

    fun pointsForPosition(position: Int): Int = if (position in 1..pointsTable.size) pointsTable[position - 1] else 0

    /**
     * Championship points: 50 classified finishers positions score according to
     * the approved table. The fastest-lap bonus is +1 and applies to the recorded
     * fastest-lap driver even if they finish outside the top 50, as approved.
     */
    fun award(result: RaceResult): Map<Int, Int> {
        val points = result.classification
            .filter { it.status == "FINISHED" }
            .associate { it.driverId to pointsForPosition(it.position) }
            .toMutableMap()
        result.fastestLapDriverId?.let { driverId ->
            points[driverId] = (points[driverId] ?: 0) + 1
        }
        return points
    }
}
