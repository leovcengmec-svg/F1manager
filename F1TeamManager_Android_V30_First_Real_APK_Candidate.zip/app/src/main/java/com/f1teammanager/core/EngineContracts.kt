package com.f1teammanager.core

/**
 * Contratos do núcleo. A UI não calcula corrida.
 */
interface SaveRepository {
    fun save(state: GameState)
    fun load(): GameState?
}

interface RaceEngine {
    fun qualify(state: GameState, circuit: CircuitState): QualifyingResult
    fun race(state: GameState, circuit: CircuitState, strategy: RaceStrategy): RaceResult
}

data class CircuitState(
    val id: Int,
    val name: String,
    val laps: Int,
    val baseLapTimeMs: Long,
    val powerFactor: Double,
    val overtakingFactor: Double
)

data class RaceStrategy(
    val driverId: Int,
    val startingTyre: String,
    val pitLaps: List<Int>
)

data class QualifyingResult(
    val grid: List<GridEntry>
)

data class GridEntry(
    val driverId: Int,
    val position: Int,
    val lapTimeMs: Long
)

data class RaceResult(
    val classification: List<FinishEntry>,
    val incidents: List<RaceIncident>
)

data class FinishEntry(
    val driverId: Int,
    val position: Int,
    val lapsCompleted: Int,
    val totalTimeMs: Long
)

data class RaceIncident(
    val driverId: Int,
    val lap: Int,
    val type: IncidentType
)

enum class IncidentType {
    CRASH,
    MECHANICAL_FAILURE,
    PENALTY
}
