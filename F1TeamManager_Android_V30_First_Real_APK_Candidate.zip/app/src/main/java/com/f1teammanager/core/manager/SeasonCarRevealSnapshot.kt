package com.f1teammanager.core.manager

/** Persisted, presentation-only snapshot for the first reveal of a newly built season car. */
data class SeasonCarRevealSnapshot(
    val season: Int,
    val teamId: Int,
    val startingOverall: Int,
    val investmentOverall: Int,
    val inheritedOverall: Int,
    val finalOverall: Int,
    val startingReliability: Int,
    val finalReliability: Int,
    val investmentAmount: Long,
    /** Legacy display/save field retained for backward compatibility; no longer drives construction. */
    val investmentSteps: Int
) {
    init {
        require(season >= 1 && teamId >= 0)
        require(listOf(startingOverall, investmentOverall, inheritedOverall, finalOverall).all { it in 0..100 })
        require(startingReliability in 0..100 && finalReliability in 0..100)
        require(investmentAmount >= 0 && investmentSteps in 0..7)
    }
}

/**
 * Builds reveal stages from the same table-driven construction as the actual season
 * transition. The investment stage shows the table target; the technical stage shows
 * focus/knowledge specialization with no second increase to the team-average Overall.
 * This never mutates or persists the game state.
 */
object SeasonCarRevealSnapshotBuilder {
    fun build(
        season: Int,
        teamId: Int,
        previousCar: TeamCarState,
        previousGarage: TeamGarage,
        finalRegulatedGarage: TeamGarage,
        development: CarDevelopmentEngine
    ): SeasonCarRevealSnapshot {
        val steps = development.nextSeasonInvestmentSteps(
            previousGarage.teamAverageOverall,
            previousCar.nextSeasonInvestment
        ) // retained only for old save/reveal compatibility
        val investmentGarage = development.buildNextSeasonGarage(
            previousGarage = previousGarage,
            invested = previousCar.nextSeasonInvestment,
            focus = previousCar.nextSeasonFocus,
            technicalKnowledge = emptyMap(),
            applyTechnicalSpecialization = false
        )
        val technicalGarage = development.buildNextSeasonGarage(
            previousGarage = previousGarage,
            invested = previousCar.nextSeasonInvestment,
            focus = previousCar.nextSeasonFocus,
            technicalKnowledge = previousCar.developmentKnowledge,
            applyTechnicalSpecialization = true
        )
        return SeasonCarRevealSnapshot(
            season = season,
            teamId = teamId,
            startingOverall = previousGarage.teamAverageOverall,
            investmentOverall = investmentGarage.teamAverageOverall,
            inheritedOverall = technicalGarage.teamAverageOverall,
            finalOverall = finalRegulatedGarage.teamAverageOverall,
            startingReliability = ((previousGarage.car1.reliability + previousGarage.car2.reliability + 1) / 2).coerceIn(0, 100),
            finalReliability = ((finalRegulatedGarage.car1.reliability + finalRegulatedGarage.car2.reliability + 1) / 2).coerceIn(0, 100),
            investmentAmount = previousCar.nextSeasonInvestment,
            investmentSteps = steps
        )
    }
}
