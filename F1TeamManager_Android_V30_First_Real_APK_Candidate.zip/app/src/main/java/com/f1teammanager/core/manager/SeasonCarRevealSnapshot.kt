package com.f1teammanager.core.manager

import kotlin.math.roundToInt

/** Persisted, presentation-only snapshot for the first reveal of a newly built season car. */
data class SeasonCarRevealSnapshot(
    val season: Int,
    val teamId: Int,
    val startingOverall: Int,
    val investmentOverall: Int,
    val inheritedOverall: Int,
    val finalOverall: Int,
    val startingReliability: Int,
    val finalReliability: Int,
    val investmentAmount: Long,
    val investmentSteps: Int
) {
    init {
        require(season >= 1 && teamId >= 0)
        require(listOf(startingOverall, investmentOverall, inheritedOverall, finalOverall).all { it in 0..100 })
        require(startingReliability in 0..100 && finalReliability in 0..100)
        require(investmentAmount >= 0 && investmentSteps in 0..7)
    }
}

/**
 * Builds visual stage values using the same component-level helper methods as the real rollover.
 * This never mutates or persists the game state; the final stage receives the actual regulated garage.
 */
object SeasonCarRevealSnapshotBuilder {
    fun build(
        season: Int,
        teamId: Int,
        previousCar: TeamCarState,
        previousGarage: TeamGarage,
        finalRegulatedGarage: TeamGarage,
        development: CarDevelopmentEngine
    ): SeasonCarRevealSnapshot {
        val steps = development.nextSeasonInvestmentSteps(previousGarage.teamAverageOverall, previousCar.nextSeasonInvestment)
        fun PhysicalCar.withValues(values: Map<CarComponent, Int>, stepsForReliability: Int): PhysicalCar {
            val reliabilities = CarComponent.values().associateWith { component ->
                (componentReliability(component) + stepsForReliability / 2).coerceIn(1, 100)
            }
            fun v(component: CarComponent) = values[component] ?: 0
            return copy(
                engine = v(CarComponent.ENGINE),
                chassis = v(CarComponent.CHASSIS),
                frontWing = v(CarComponent.FRONT_WING),
                rearWing = v(CarComponent.REAR_WING),
                brakes = v(CarComponent.BRAKES),
                electricPowerUnit = v(CarComponent.ELECTRIC_POWER_UNIT),
                reliability = reliabilities.values.average().roundToInt().coerceIn(1, 100),
                componentReliabilities = reliabilities
            )
        }
        fun stageInvestment(car: PhysicalCar): PhysicalCar {
            val values = CarComponent.values().associateWith { component ->
                development.nextSeasonPhysicalInvestmentOnlyComponentValue(
                    previousValue = car.componentValue(component),
                    installed = component in car.installedPieces,
                    investmentSteps = steps,
                    focus = previousCar.nextSeasonFocus,
                    component = component
                )
            }
            return car.withValues(values, steps)
        }
        fun stageInheritance(source: PhysicalCar, invested: PhysicalCar): PhysicalCar {
            val values = CarComponent.values().associateWith { component ->
                development.nextSeasonPhysicalTechnicalCarryoverComponentValue(
                    investmentOnlyValue = invested.componentValue(component),
                    previousValue = source.componentValue(component),
                    installed = component in source.installedPieces,
                    component = component,
                    technicalKnowledge = previousCar.developmentKnowledge[component] ?: 0
                )
            }
            return source.copy(
                engine = values[CarComponent.ENGINE] ?: 0,
                chassis = values[CarComponent.CHASSIS] ?: 0,
                frontWing = values[CarComponent.FRONT_WING] ?: 0,
                rearWing = values[CarComponent.REAR_WING] ?: 0,
                brakes = values[CarComponent.BRAKES] ?: 0,
                electricPowerUnit = values[CarComponent.ELECTRIC_POWER_UNIT] ?: 0,
                reliability = invested.reliability,
                componentReliabilities = invested.componentReliabilities
            )
        }
        val investmentGarage = TeamGarage(
            stageInvestment(previousGarage.car1),
            stageInvestment(previousGarage.car2)
        )
        val inheritanceGarage = TeamGarage(
            stageInheritance(previousGarage.car1, investmentGarage.car1),
            stageInheritance(previousGarage.car2, investmentGarage.car2)
        )
        return SeasonCarRevealSnapshot(
            season = season,
            teamId = teamId,
            startingOverall = previousGarage.teamAverageOverall,
            investmentOverall = investmentGarage.teamAverageOverall,
            inheritedOverall = inheritanceGarage.teamAverageOverall,
            finalOverall = finalRegulatedGarage.teamAverageOverall,
            startingReliability = ((previousGarage.car1.reliability + previousGarage.car2.reliability + 1) / 2).coerceIn(0, 100),
            finalReliability = ((finalRegulatedGarage.car1.reliability + finalRegulatedGarage.car2.reliability + 1) / 2).coerceIn(0, 100),
            investmentAmount = previousCar.nextSeasonInvestment,
            investmentSteps = steps
        )
    }
}
