package com.f1teammanager.core.manager

/**
 * Weekly orchestration primitives for annual team events.
 * The caller must persist processedWeekKeys and event IDs in the career save transaction.
 * This scheduler deliberately returns a plan instead of mutating global career state.
 */
object AnnualTeamEventScheduler {
    data class WeekContext(
        val season: Int,
        val week: Int,
        val isQualifyingOrRaceScreen: Boolean,
        val seed: Int,
        val teams: List<AnnualTeamEventEngine.TeamSnapshot>,
        val processedWeekKeys: Set<String>,
        val processedEventIds: Set<String>,
        val acquisitionUsedThisSeason: Boolean,
        val classChangeUsedThisSeason: Boolean
    )

    data class PlannedEvent(
        val event: AnnualTeamEventEngine.Event,
        val teamResult: AnnualTeamEventEngine.TeamResult
    )

    data class WeekPlan(
        val weekKey: String,
        val shouldPersistWeekKey: Boolean,
        val events: List<PlannedEvent>,
        val acquisitionUsedThisSeason: Boolean,
        val classChangeUsedThisSeason: Boolean
    )

    /**
     * Breaks a multi-week calendar jump at every unprocessed annual-event week.
     * The caller commits each boundary before advancing beyond it, so later
     * development uses the post-event facilities, cash and car state.
     */
    fun advancementBoundaries(currentWeek: Int, targetWeek: Int, pendingEventWeeks: List<Int>): List<Int> {
        if (currentWeek !in 0..56 || targetWeek !in currentWeek..56 || targetWeek == currentWeek) return emptyList()
        return (pendingEventWeeks.filter { it > currentWeek && it <= targetWeek } + targetWeek)
            .distinct().sorted()
    }

    /** Returns no plan for invalid weeks, sports screens, or an already-processed week. */
    fun plan(context: WeekContext): WeekPlan? {
        if (!AnnualTeamEventEngine.canApplyWeeklyEvent(
                context.season, context.week, context.isQualifyingOrRaceScreen
            )) return null
        val weekKey = AnnualTeamEventEngine.weekLedgerKey(context.season, context.week)
        if (weekKey in context.processedWeekKeys) return null
        val events = mutableListOf<PlannedEvent>()
        var acquisitionUsed = context.acquisitionUsedThisSeason
        val classChangeUsed = context.classChangeUsedThisSeason

        val seasonCalendar = AnnualTeamEventSeasonCalendar.generate(context.season, context.seed)
        val scheduled = seasonCalendar.filter { slot ->
            slot.week == context.week &&
                !(context.acquisitionUsedThisSeason && slot.kind == AnnualTeamEventEngine.Kind.INVESTOR_ACQUISITION)
        }
        val batch = AnnualTeamEventEngine.resolveSeasonBatch(
            context.season, scheduled, context.teams, context.seed
        )
        batch.teamResults.forEach { (_, result) ->
            addIfNew(events, result, context.processedEventIds)
        }
        if (events.any { it.event.kind == AnnualTeamEventEngine.Kind.INVESTOR_ACQUISITION }) {
            acquisitionUsed = true
        }

        // V649 removed random class-change opportunities. The two-season sporting
        // review is performed by the career repository at the season boundary.

        return WeekPlan(weekKey, true, events, acquisitionUsed, classChangeUsed)
    }

    private fun addIfNew(
        target: MutableList<PlannedEvent>,
        result: AnnualTeamEventEngine.TeamResult,
        alreadyProcessed: Set<String>
    ): Boolean {
        val event = result.event ?: return false
        if (AnnualTeamEventEngine.eventLedgerKey(event) in alreadyProcessed || target.any { it.event.id == event.id }) return false
        target.add(PlannedEvent(event, result))
        return true
    }

    // The plan for a class-change opportunity has no team mutation. The repository should ignore
    // this placeholder state and apply only the event after committing the pilot class change.
    private fun emptyCarPlaceholder(): TeamCarState = TeamCarState(
        aerodynamics = 40, chassis = 40, engine = 40, reliability = 40,
        frontWing = 40, rearWing = 40, brakes = 40, electricPowerUnit = 40
    )
}
