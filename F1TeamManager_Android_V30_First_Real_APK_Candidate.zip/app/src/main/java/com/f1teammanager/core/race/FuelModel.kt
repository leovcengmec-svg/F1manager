package com.f1teammanager.core.race

/**
 * Canonical no-refuelling fuel model.
 * The car starts the race with the full tank. The load is sized so that even
 * sustained ATTACK pace completes the scheduled distance with a safety reserve.
 */
object FuelModel {
    const val TANK_CAPACITY_KG = 110.0
    const val SAFETY_LAPS = 2.0
    const val ATTACK_FACTOR = 1.10
    const val BALANCED_FACTOR = 1.00
    const val DEFENSE_FACTOR = 0.90
    private const val DRY_REFERENCE_FACTOR = 1.12

    fun strategyFactor(mode: DriverStrategyMode): Double = when (mode) {
        DriverStrategyMode.ATTACK -> ATTACK_FACTOR
        DriverStrategyMode.BALANCED -> BALANCED_FACTOR
        DriverStrategyMode.DEFENSE -> DEFENSE_FACTOR
    }

    fun weatherFactor(weather: Weather, tyre: Tyre): Double = when (weather) {
        Weather.DRY -> DRY_REFERENCE_FACTOR
        Weather.CLOUDY -> 1.04
        Weather.LIGHT_RAIN -> 0.90
        Weather.MEDIUM_RAIN -> 0.78
        Weather.HEAVY_RAIN -> if (tyre == Tyre.WET) 0.45 else 0.65
    }

    /** Fuel used on one lap. Attack is the sizing reference for the safety reserve. */
    fun consumptionPerLap(totalLaps: Int, mode: DriverStrategyMode, weather: Weather, tyre: Tyre): Double {
        require(totalLaps > 0) { "A corrida precisa ter pelo menos 1 volta" }
        val referencePerLap = TANK_CAPACITY_KG / (totalLaps + SAFETY_LAPS)
        val strategyRatio = strategyFactor(mode) / ATTACK_FACTOR
        val weatherRatio = weatherFactor(weather, tyre) / DRY_REFERENCE_FACTOR
        return referencePerLap * strategyRatio * weatherRatio
    }

    fun fuelPercent(fuelKg: Double): Int =
        ((fuelKg / TANK_CAPACITY_KG) * 100.0).toInt().coerceIn(0, 100)
}
