package com.f1teammanager.core.manager

import kotlin.math.roundToInt
import kotlin.random.Random

data class AITeamDecision(val teamId:Int,val development:CarComponent?,val facility:Facility?,val signedStaff:Boolean)

class AIManagerEngine(private val seed:Int=20261003) {
    fun decide(teamId:Int, round:Int, car:TeamCarState, budget:Long): AITeamDecision {
        val r=Random(seed + teamId*997 + round*31)
        val weak=listOf(
            CarComponent.ENGINE to car.engine,
            CarComponent.CHASSIS to car.chassis,
            CarComponent.FRONT_WING to car.frontWing,
            CarComponent.REAR_WING to car.rearWing,
            CarComponent.BRAKES to car.brakes,
            CarComponent.ELECTRIC_POWER_UNIT to car.electricPowerUnit
        ).minBy { it.second }
        val develop=if(budget>2_000_000 && r.nextInt(100)<78) weak.first else null
        val facility=if(r.nextInt(100)<22) Facility.values().minBy { car.facilities[it] ?: 1 } else null
        val staff=r.nextInt(100)<12
        return AITeamDecision(teamId,develop,facility,staff)
    }

    fun performanceModifier(staff:List<StaffMember>, sponsor:SponsorContract, engine:SupplierContract, tyre:SupplierContract):Int {
        val technical=staff.filter { it.role==StaffRole.TECHNICAL_DIRECTOR }.maxOfOrNull { it.skill } ?: 50
        val commercial=staff.filter { it.role==StaffRole.COMMERCIAL_MANAGER }.maxOfOrNull { it.skill } ?: 50
        return ((technical-50)*0.12 + (commercial-50)*0.04 + (engine.performance-50)*0.10 + (tyre.performance-50)*0.06).roundToInt()
    }
}
