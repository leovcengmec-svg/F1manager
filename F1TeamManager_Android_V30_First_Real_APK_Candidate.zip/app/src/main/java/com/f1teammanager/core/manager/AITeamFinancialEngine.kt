package com.f1teammanager.core.manager

import com.f1teammanager.core.season.WorldDatabase

/** Persistent cash-flow ledger for AI teams. All 39 AI teams keep their own balance. */
class AITeamFinancialEngine(seed:Int = 20261006) {
    data class State(val teamId:Int, val season:Int, val finance:TeamFinanceState)
    private val states = mutableMapOf<Int, State>()
    private val seenDeals = mutableMapOf<Int, MutableSet<String>>()
    private val seenSponsorContracts = mutableMapOf<Int, MutableSet<String>>()
    private val developmentBudgets = mutableMapOf<Pair<Int,Int>, Long>()
    private val negativeBalancePenalties = mutableMapOf<Pair<Int,Int>, Boolean>()
    /** Salary payment idempotency ledger: one charge per team, season and completed GP. */
    private val salaryPaidGps = mutableSetOf<Triple<Int,Int,Int>>()
    private val facilities = mutableMapOf<Int, TeamFacilitiesState>()
    private val facilityUpgrades = mutableMapOf<Int, FacilityUpgradeState>()
    /** Shared annual cap for AI research/design, fabrication and facility upgrades. */
    private val technicalInvestments = mutableMapOf<Pair<Int,Int>, TechnicalInvestmentState>()

    fun state(teamId:Int, season:Int): State {
        val existing = states[teamId]
        if (existing != null) return existing
        val team = WorldDatabase.teams.first { it.id == teamId }
        val initial = InitialTeamProfile.initialBudget(team)
        return State(teamId, season, TeamFinanceState(initial)).also {
            states[teamId] = it
            facilities.putIfAbsent(teamId, FacilityEngine.initial(team.initialLevel))
        }
    }

    fun allStates(): List<State> = states.values.sortedBy { it.teamId }

    /** Annual event adjustments are applied directly and remain in the exported finance snapshot. */
    fun setBudgetForAnnualEvent(teamId: Int, season: Int, budget: Long, description: String): State {
        val current = state(teamId, season)
        val safeBudget = budget.coerceAtLeast(0L)
        val delta = safeBudget - current.finance.budget
        val updatedFinance = if (delta == 0L) current.finance.copy(budget = safeBudget) else current.finance.transact(delta, description).copy(budget = safeBudget)
        return current.copy(finance = updatedFinance).also { states[teamId] = it }
    }

    /**
     * AI uses the same 12-week, one-at-a-time facility construction rule as the player.
     * Facility upgrades are capped at 20% of the annual technical cap; 80% remains
     * available for R&D/design and physical fabrication.
     */
    fun advanceFacilityDevelopment(teamId:Int, season:Int, week:Int): State {
        var s = state(teamId, season)
        val active = facilityUpgrades[teamId]
        if (active != null) {
            val remaining = active.remainingWeeks - 1
            if (remaining <= 0) {
                facilities[teamId] = facilities(teamId).withLevel(active.facility, active.targetLevel)
                facilityUpgrades.remove(teamId)
            } else facilityUpgrades[teamId] = active.copy(remainingWeeks = remaining)
            states[teamId] = s
            return s
        }
        if (week <= 0 || week % 8 != 0) return s
        val current = facilities(teamId)
        val priority = listOf(FacilityType.RESEARCH, FacilityType.FACTORY, FacilityType.MARKETING, FacilityType.WIND_TUNNEL, FacilityType.SIMULATOR, FacilityType.SCOUTING, FacilityType.DRIVER_DEVELOPMENT)
        val type = priority.filter { current.level(it) < 10 }.minWithOrNull(compareBy<FacilityType> { current.level(it) }.thenBy { priority.indexOf(it) }) ?: return s
        val cost = FacilityEngine.upgradeCost(current.level(type)) ?: return s
        val investment = technicalInvestment(teamId, s.season)
        val facilityBudgetLimit = investment.annualCap * 20L / 100L
        val facilityBudgetRemaining = (facilityBudgetLimit - investment.facilityUpgradeSpent).coerceAtLeast(0L)
        // AI must retain an operating buffer; a large technical cap is not permission
        // to spend cash needed for salaries and race operations.
        val protectedCash = SeasonInvestmentPolicy.protectedCash(s.finance.budget)
        if (s.finance.budget - cost < protectedCash || investment.available < cost || facilityBudgetRemaining < cost) return s
        technicalInvestments[teamId to s.season] = investment.withSpend(TechnicalInvestmentCategory.FACILITY_UPGRADE, cost)
        s = s.copy(finance = debit(s.finance, cost, "Início de melhoria instalação IA: ${FacilityEngine.label(type)} ${current.level(type)}→${current.level(type)+1} (12 semanas)"))
        facilityUpgrades[teamId] = FacilityUpgradeState(type, current.level(type), current.level(type)+1, 12, 12, cost, season, week)
        states[teamId] = s
        return s
    }

    fun facilityUpgrade(teamId: Int): FacilityUpgradeState? = facilityUpgrades[teamId]

    fun beginSeason(teamId:Int, season:Int, market:DriverMarketState): State {
        var s = state(teamId, season)
        if (s.season != season) s = State(teamId, season, s.finance.copy(seasonIncome=0, seasonExpenses=0, raceIncome=0, raceExpenses=0)).also { states[teamId]=it }
        // Salaries are no longer charged here. They are settled once after each completed GP.
        technicalInvestment(teamId, season)
        states[teamId]=s
        return s
    }

    /** Charges annual driver salaries in 30 installments, once after each completed GP. */
    fun applyDriverSalariesForRace(teamId:Int, season:Int, round:Int, market:DriverMarketState): State {
        var s = state(teamId, season)
        if (round !in 1..30) return s
        val key = Triple(teamId, season, round)
        if (key in salaryPaidGps) return s
        val annual = market.contracts.filter { it.teamId == teamId && it.activeIn(season) }.sumOf { it.salary.coerceAtLeast(0L) }
        val requested = annual / 30L + if (round == 30) annual % 30L else 0L
        val finance = SalaryLedger.apply(s.finance, season, round, requested)
        s = s.copy(finance=SignatureFeeAccounting.recognizeForRace(finance, season, round))
        if ("$season:$round" in s.finance.salaryPaidRounds) salaryPaidGps += key
        states[teamId] = s
        return s
    }

    /** Returns the season-frozen investment state; ranking determines the annual €200–400M ceiling. */
    fun technicalInvestment(teamId:Int, season:Int): TechnicalInvestmentState = technicalInvestments.getOrPut(teamId to season) {
        val ranking = TechnicalInvestmentEngine.seasonRanking()[teamId] ?: 40
        TechnicalInvestmentEngine.create(season, ranking)
    }

    /** Debit only available cash. Unpaid mandatory costs are recorded, never converted into debt. */
    private fun debit(finance:TeamFinanceState, requested:Long, description:String):TeamFinanceState {
        if (requested <= 0L) return finance
        val paid = requested.coerceAtMost(finance.budget.coerceAtLeast(0L))
        var next = if (paid > 0L) finance.transact(-paid, description) else finance
        if (paid < requested) {
            next = next.copy(transactions=(next.transactions + "BLOQUEADO/INSUFICIENTE: €${requested-paid} não pagos — $description").takeLast(100))
        }
        return next.copy(budget=next.budget.coerceAtLeast(0L))
    }

    fun facilities(teamId:Int): TeamFacilitiesState =
        facilities.getOrPut(teamId) {
            val team = WorldDatabase.teams.first { it.id == teamId }
            FacilityEngine.initial(team.initialLevel)
        }

    fun setFacilities(teamId:Int, value:TeamFacilitiesState) {
        facilities[teamId] = value
    }

    fun applySeasonConstructorsPrize(teamId:Int, season:Int, position:Int): State {
        var s = state(teamId, season)
        if (season in s.finance.seasonPrizesPaid) return s
        val prize = SeasonPrizeEngine.prizeForPosition(position)
        s = s.copy(finance = s.finance.transact(prize, "Premiação de construtores — $season — ${position}º lugar")
            .copy(seasonPrizesPaid = s.finance.seasonPrizesPaid + season))
        states[teamId] = s
        return s
    }

    fun applyEndOfSeasonFinancialPenalty(teamId:Int, season:Int): State {
        var s = state(teamId, season)
        val key = teamId to season
        if (negativeBalancePenalties[key] == true) return s
        if (s.finance.budget < 0L) {
            negativeBalancePenalties[key] = true
            FinancialSeasonClosureEngine.recordAiPenalty(teamId, season)
            s = s.copy(finance = s.finance.copy(
                transactions = (s.finance.transactions + "PENALIDADE_FINANCEIRA:-20% nos 6 componentes do carro — saldo €${s.finance.budget}").takeLast(100)
            ))
            states[teamId] = s
        }
        return s
    }

    private fun initialDevelopmentBudget(teamId:Int): Long {
        val team = WorldDatabase.teams.first { it.id == teamId }
        return InitialTeamProfile.initialBudget(team)
    }

    fun hadNegativeBalancePenalty(teamId:Int, season:Int): Boolean = negativeBalancePenalties[teamId to season] == true

    /**
     * Returns the AI technical capacity available now: real cash plus the amount
     * already spent on development this season. Sunk development cost is added
     * back only to let the deterministic pipeline reconstruct its cumulative
     * history; it is never spendable cash.
     */
    fun developmentCapacity(teamId:Int, season:Int): Long {
        val s = state(teamId, season)
        val investment = technicalInvestment(teamId, season)
        val researchSpent = investment.researchDesignSpent
        // Reconstruct only the R&D spend already simulated. Facility spend consumes the
        // same cap but must not be counted twice by the cumulative R&D simulator.
        val spendableCash = minOf(
            (s.finance.budget.coerceAtLeast(0L) - SeasonInvestmentPolicy.protectedCash(s.finance.budget)).coerceAtLeast(0L),
            investment.available
        )
        return researchSpent + spendableCash
    }

    fun developmentSpent(teamId:Int, season:Int): Long =
        technicalInvestment(teamId, season).researchDesignSpent

    fun applyDevelopmentCost(teamId:Int, season:Int, developmentBudgetAfter:Long, startingCapacity:Long): State {
        val key = teamId to season
        val initial = initialDevelopmentBudget(teamId)
        val investment = technicalInvestment(teamId, season)
        val previousSpent = investment.researchDesignSpent
        val cumulativeSpentAfter = (startingCapacity.coerceAtLeast(0L) - developmentBudgetAfter.coerceAtLeast(0L)).coerceAtLeast(0L)
        val requestedIncrement = (cumulativeSpentAfter - previousSpent).coerceAtLeast(0L)
        val s0 = state(teamId, season)
        // Hard guards: no negative cash and no annual-cap overrun, even if the
        // technical simulator proposes a larger cumulative spend than allowed.
        val actualIncrement = minOf(
            requestedIncrement,
            (s0.finance.budget.coerceAtLeast(0L) - SeasonInvestmentPolicy.protectedCash(s0.finance.budget)).coerceAtLeast(0L),
            investment.available
        ).coerceAtLeast(0L)
        developmentBudgets[key] = (initial - previousSpent - actualIncrement).coerceAtLeast(0L) // legacy snapshot compatibility
        if (actualIncrement > 0L) {
            technicalInvestments[key] = investment.withSpend(TechnicalInvestmentCategory.RESEARCH_DESIGN, actualIncrement)
        }
        val s = if (actualIncrement > 0) {
            s0.copy(finance=debit(s0.finance, actualIncrement, "P&D IA"))
        } else s0
        states[teamId]=s
        return s
    }

    fun applyRace(teamId:Int, season:Int, round:Int, sponsorship:TeamSponsorshipEngine.TeamSponsorshipState, market:DriverMarketState, bestFinish:Int=20, points:Int=0): State {
        var s = state(teamId, season)
        val settlementKey = "AI_GP_SETTLEMENT:$season:$round"
        // The transaction marker is included in the exported finance snapshot. This
        // prevents duplicate income/prize/costs when a completed GP callback is replayed.
        if (settlementKey in s.finance.raceSettlementKeys) return s
        if (s.season != season) s = beginSeason(teamId, season, market)
        val active = sponsorship.sponsors.filter { it.active && it.racesRemaining > 0 }
        val income = active.sumOf { it.racePayment } + active.sumOf { it.pointsBonus } * points.toLong() +
            active.sumOf { if (it.raceTarget > 0 && bestFinish >= (if(it.raceTargetMin>0) it.raceTargetMin else 1) && bestFinish <= (if(it.raceTargetMax>0) it.raceTargetMax else it.raceTarget)) it.raceTargetBonus else 0L }
        val prize = when {
            bestFinish <= 3 -> 2_500_000L
            bestFinish <= 10 -> 1_500_000L
            bestFinish <= 20 -> 900_000L
            else -> 500_000L
        }
        val raceOperatingCost = RaceOperatingCost.forTeam(teamId)
        val settledFinance = debit(s.finance.transact(income, "Patrocínios e bônus GP $round").transact(prize, "Premiação GP $round"), raceOperatingCost, "Custos operacionais GP $round")
            .copy(transactions = (s.finance.transactions + "+0:$settlementKey").takeLast(100), raceSettlementKeys = s.finance.raceSettlementKeys + settlementKey)
        s = s.copy(finance=settledFinance)
        states[teamId]=s
        s = applyDriverSalariesForRace(teamId, season, round, market)
        return s
    }

    /** Credits sponsorship upfront exactly once when an AI contract is first observed as active. */
    fun applySponsorshipSignings(teamId:Int, season:Int, sponsorship:TeamSponsorshipEngine.TeamSponsorshipState): State {
        var s = state(teamId, season)
        val seen = seenSponsorContracts.getOrPut(teamId) { mutableSetOf() }
        sponsorship.sponsors.filter { it.active }.forEach { sponsor ->
            val key = "${season}:${sponsor.slot}:${sponsor.name}:${sponsor.races}"
            if (seen.add(key)) {
                s = s.copy(finance = s.finance.transact(sponsor.upfront, "Entrada patrocínio: ${sponsor.name} (slot ${sponsor.slot})"))
            }
        }
        states[teamId] = s
        return s
    }

    /** Charges a signature fee exactly once for each newly scheduled AI deal. */
    fun applyNewDeals(teamId:Int, season:Int, before:DriverMarketState, after:DriverMarketState, marketEngine:DriverMarketEngine, nextRound:Int = 1): State {
        var s = state(teamId, season)
        val beforeKeys = before.scheduled.filter { it.toTeamId == teamId && it.startSeason == season + 1 }.map { key(it) }.toSet()
        val deals = after.scheduled.filter { it.toTeamId == teamId && it.startSeason == season + 1 && key(it) !in beforeKeys && key(it) !in (seenDeals[teamId] ?: mutableSetOf()) }
        deals.forEach { deal ->
            val fee = marketEngine.signatureFeeFor(after, deal.driverId, teamId, season)
            if (fee > 0) {
                val description = "Taxa de contratação ${deal.driverId} — temporada $season"
                val remaining = (31 - nextRound).coerceIn(1, 30)
                s = s.copy(finance=SignatureFeeAccounting.register(s.finance, fee, description, season, nextRound, remaining))
                seenDeals.getOrPut(teamId) { mutableSetOf() }.add(key(deal))
            } else {
                seenDeals.getOrPut(teamId) { mutableSetOf() }.add(key(deal))
            }
        }
        states[teamId]=s
        return s
    }

    fun ensureAllTeams(season:Int, playerTeamId:Int, market:DriverMarketState) {
        WorldDatabase.teams.filter { it.id != playerTeamId }.forEach { beginSeason(it.id, season, market) }
    }

    /** Stable persistence snapshot for Android process restarts. */
    fun exportSnapshot(): String {
        fun b64(v:String)=java.util.Base64.getEncoder().encodeToString(v.toByteArray(Charsets.UTF_8))
        val lines=mutableListOf<String>()
        states.values.sortedBy { it.teamId }.forEach { s ->
            val f=s.finance
            val seenD=seenDeals[s.teamId].orEmpty().joinToString(",") { b64(it) }
            val seenS=seenSponsorContracts[s.teamId].orEmpty().joinToString(",") { b64(it) }
            val dev=developmentBudgets[s.teamId to s.season] ?: 0L
            val pen=negativeBalancePenalties[s.teamId to s.season] == true
            val facilityData = FacilityType.values().joinToString(",") { "${it.name}:${facilities(s.teamId).level(it)}" }
            val activeUpgrade = facilityUpgrades[s.teamId]?.let { u -> listOf(u.facility.name,u.previousLevel,u.targetLevel,u.remainingWeeks,u.totalWeeks,u.cost,u.startedSeason,u.startedWeek).joinToString(":") }.orEmpty()
            // Field 14 is retained as an empty compatibility slot for older snapshot readers.
            val paidSeasons = ""
            val ti = technicalInvestment(s.teamId, s.season)
            val paidGps = salaryPaidGps.filter { it.first == s.teamId }.map { "${it.second}:${it.third}" }.sorted().joinToString(",")
            val feeSchedules = f.signatureFeeSchedules.joinToString(";") { sch -> listOf(b64(sch.id), sch.amount, sch.season, sch.recognizedRounds.sorted().joinToString(","), sch.startRound, sch.installmentCount, sch.paidRounds.sorted().joinToString(",")).joinToString(":") }
            lines += listOf("S",s.teamId,s.season,f.budget,f.seasonIncome,f.seasonExpenses,f.raceIncome,f.raceExpenses,f.seasonPrizesPaid.sorted().joinToString(","),b64(seenD),b64(seenS),dev,pen,b64(facilityData),paidSeasons,ti.ranking,ti.annualCap,ti.researchDesignSpent,ti.fabricationSpent,ti.facilityUpgradeSpent,paidGps,"",b64(f.transactions.joinToString("\n")),b64(feeSchedules),b64(f.salaryOutstanding.entries.sortedBy { it.key }.joinToString(",") { "${it.key}:${it.value}" }),b64(activeUpgrade),b64(f.raceSettlementKeys.sorted().joinToString(","))).joinToString("|")
        }
        return lines.joinToString("\n")
    }

    fun restoreSnapshot(raw:String) {
        states.clear(); seenDeals.clear(); seenSponsorContracts.clear(); developmentBudgets.clear(); negativeBalancePenalties.clear(); salaryPaidGps.clear(); facilities.clear(); facilityUpgrades.clear(); technicalInvestments.clear()
        fun dec(v:String)=runCatching { String(java.util.Base64.getDecoder().decode(v),Charsets.UTF_8) }.getOrDefault("")
        raw.lineSequence().filter { it.isNotBlank() }.forEach { line ->
            val p=line.split("|", limit=27)
            if (p.size<13 || p[0]!="S") return@forEach
            val team=p[1].toIntOrNull() ?: return@forEach; val season=p[2].toIntOrNull() ?: return@forEach
            val f=TeamFinanceState(
                budget=p[3].toLongOrNull()?:0L,
                seasonIncome=p[4].toLongOrNull()?:0L,
                seasonExpenses=p[5].toLongOrNull()?:0L,
                raceIncome=p[6].toLongOrNull()?:0L,
                raceExpenses=p[7].toLongOrNull()?:0L,
                transactions=if (p.size >= 23) dec(p[22]).split("\n").filter { it.isNotBlank() }.takeLast(500) else emptyList(),
                seasonPrizesPaid=p[8].split(",").mapNotNull { it.toIntOrNull() }.toSet(),
                signatureFeeSchedules=if (p.size >= 24) dec(p[23]).split(";").filter { it.isNotBlank() }.mapNotNull { row ->
                    val q=row.split(":", limit=7)
                    if (q.size < 4) null else runCatching { SignatureFeeSchedule(dec(q[0]), q[1].toLong(), q[2].toInt(), q[3].split(",").mapNotNull { it.toIntOrNull() }.toSet(), q.getOrNull(4)?.toIntOrNull() ?: 1, q.getOrNull(5)?.toIntOrNull() ?: 30, if (q.size >= 7) q[6].split(",").mapNotNull { it.toIntOrNull() }.toSet() else (1..30).toSet()) }.getOrNull()
                } else emptyList(),
                salaryOutstanding=if (p.size >= 25) dec(p[24]).split(",").filter { it.isNotBlank() }.mapNotNull { token -> val q=token.split(":"); if(q.size==3) runCatching { (q[0]+":"+q[1]) to q[2].toLong() }.getOrNull() else null }.toMap() else emptyMap(),
                raceSettlementKeys=if (p.size >= 27) dec(p[26]).split(",").filter { it.isNotBlank() }.toSet() else emptySet()
            )
            states[team]=State(team,season,f)
            if (p.size >= 14) {
                val restored = dec(p[13]).split(",").mapNotNull { token ->
                    val q = token.split(":", limit=2)
                    if (q.size == 2) runCatching { FacilityType.valueOf(q[0]) to q[1].toInt() }.getOrNull() else null
                }.toMap()
                if (restored.isNotEmpty()) facilities[team] = TeamFacilitiesState(restored)
            } else {
                val teamDef = WorldDatabase.teams.firstOrNull { it.id == team }
                if (teamDef != null) facilities[team] = FacilityEngine.initial(teamDef.initialLevel)
            }
            if (p.size >= 26) {
                val u = dec(p[25])
                val q = u.split(":")
                if (q.size == 8) runCatching { FacilityUpgradeState(FacilityType.valueOf(q[0]),q[1].toInt(),q[2].toInt(),q[3].toInt(),q[4].toInt(),q[5].toLong(),q[6].toInt(),q[7].toInt()) }.getOrNull()?.let { facilityUpgrades[team] = it }
            }
            seenDeals[team]=dec(p[9]).split(",").filter { it.isNotBlank() }.mapTo(mutableSetOf()) { dec(it) }
            seenSponsorContracts[team]=dec(p[10]).split(",").filter { it.isNotBlank() }.mapTo(mutableSetOf()) { dec(it) }
            developmentBudgets[team to season]=p[11].toLongOrNull()?:0L
            if (p[12].toBoolean()) negativeBalancePenalties[team to season]=true
            // Backward compatibility: older snapshots used field 14 for an annual salary ledger.
            // Do not re-charge a season's annual salary on restore; only V155+ snapshots contain per-GP keys.
            if (p.size >= 21) {
                p[20].split(",").filter { it.isNotBlank() }.forEach { token ->
                    val parts = token.split(":")
                    if (parts.size == 2) {
                        val paidSeason = parts[0].toIntOrNull()
                        val paidRound = parts[1].toIntOrNull()
                        if (paidSeason != null && paidRound != null && paidRound in 1..30) salaryPaidGps += Triple(team, paidSeason, paidRound)
                    }
                }
            } else if (p.size >= 15) {
                // Legacy snapshots may have charged salaries at season start; mark all rounds paid
                // for that season to prevent a duplicate transition charge after upgrading.
                p[14].split(",").mapNotNull { it.toIntOrNull() }.forEach { oldSeason ->
                    (1..30).forEach { oldRound -> salaryPaidGps += Triple(team, oldSeason, oldRound) }
                }
            } else {
                (1..30).forEach { oldRound -> salaryPaidGps += Triple(team, season, oldRound) }
            }
            if (p.size >= 20) {
                val rank = p[15].toIntOrNull() ?: (TechnicalInvestmentEngine.seasonRanking()[team] ?: 40)
                val cap = p[16].toLongOrNull() ?: TechnicalInvestmentEngine.capForRank(rank)
                technicalInvestments[team to season] = TechnicalInvestmentState(
                    season, rank, TechnicalInvestmentEngine.levelForRank(rank), cap,
                    p[17].toLongOrNull() ?: 0L, p[18].toLongOrNull() ?: 0L, p[19].toLongOrNull() ?: 0L
                )
            } else {
                technicalInvestment(team, season)
            }
        }
    }

    private fun key(d:FutureDriverDeal):String = "${d.driverId}:${d.toTeamId}:${d.startSeason}:${d.years}:${d.salary}:${d.role}"
}
