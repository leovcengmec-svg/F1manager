package com.f1teammanager.core.manager

import com.f1teammanager.core.season.WorldDatabase

/** Persistent cash-flow ledger for AI teams. All 39 AI teams keep their own balance. */
class AITeamFinancialEngine(seed:Int = 20261006) {
    data class State(val teamId:Int, val season:Int, val finance:TeamFinanceState)
    private val states = mutableMapOf<Int, State>()
    private val seenDeals = mutableMapOf<Int, MutableSet<String>>()
    private val seenSponsorContracts = mutableMapOf<Int, MutableSet<String>>()
    private val developmentBudgets = mutableMapOf<Pair<Int,Int>, Long>()
    private val negativeBalancePenalties = mutableMapOf<Pair<Int,Int>, Boolean>()

    fun state(teamId:Int, season:Int): State {
        val existing = states[teamId]
        if (existing != null) return existing
        val team = WorldDatabase.teams.first { it.id == teamId }
        val initial = (35_000_000L + team.baseCar.coerceIn(50,100) * 650_000L)
        return State(teamId, season, TeamFinanceState(initial)) .also { states[teamId] = it }
    }

    fun allStates(): List<State> = states.values.sortedBy { it.teamId }

    fun beginSeason(teamId:Int, season:Int, market:DriverMarketState): State {
        var s = state(teamId, season)
        if (s.season != season) s = State(teamId, season, s.finance.copy(seasonIncome=0, seasonExpenses=0, raceIncome=0, raceExpenses=0)).also { states[teamId]=it }
        val active = market.contracts.filter { it.teamId == teamId && it.activeIn(season) }
        val salary = active.sumOf { it.salary.toLong() }
        if (salary > 0) s = s.copy(finance=s.finance.transact(-salary, "Salários anuais — temporada $season"))
        states[teamId]=s
        return s
    }

    fun applySeasonConstructorsPrize(teamId:Int, season:Int, position:Int): State {
        var s = state(teamId, season)
        if (season in s.finance.seasonPrizesPaid) return s
        val prize = SeasonPrizeEngine.prizeForPosition(position)
        s = s.copy(finance = s.finance.transact(prize, "Premiação de construtores — $season — ${position}º lugar")
            .copy(seasonPrizesPaid = s.finance.seasonPrizesPaid + season))
        states[teamId] = s
        return s
    }

    fun applyEndOfSeasonFinancialPenalty(teamId:Int, season:Int): State {
        var s = state(teamId, season)
        val key = teamId to season
        if (negativeBalancePenalties[key] == true) return s
        if (s.finance.budget < 0L) {
            negativeBalancePenalties[key] = true
            FinancialSeasonClosureEngine.recordAiPenalty(teamId, season)
            s = s.copy(finance = s.finance.copy(
                transactions = (s.finance.transactions + "PENALIDADE_FINANCEIRA:-20% nos 6 componentes do carro — saldo €${s.finance.budget}").takeLast(100)
            ))
            states[teamId] = s
        }
        return s
    }

    fun hadNegativeBalancePenalty(teamId:Int, season:Int): Boolean = negativeBalancePenalties[teamId to season] == true

    fun applyDevelopmentCost(teamId:Int, season:Int, developmentBudgetAfter:Long): State {
        val key = teamId to season
        val previous = developmentBudgets[key] ?: (35_000_000L + WorldDatabase.teams.first { it.id == teamId }.baseCar.coerceIn(50,100) * 650_000L)
        val cost = (previous - developmentBudgetAfter).coerceAtLeast(0L)
        developmentBudgets[key] = developmentBudgetAfter
        var s = state(teamId, season)
        if (cost > 0) s = s.copy(finance=s.finance.transact(-cost, "P&D IA"))
        states[teamId]=s
        return s
    }

    fun applyRace(teamId:Int, season:Int, round:Int, sponsorship:TeamSponsorshipEngine.TeamSponsorshipState, market:DriverMarketState, bestFinish:Int=20, points:Int=0): State {
        var s = state(teamId, season)
        if (s.season != season) s = beginSeason(teamId, season, market)
        val active = sponsorship.sponsors.filter { it.active && it.racesRemaining > 0 }
        val income = active.sumOf { it.racePayment } + active.sumOf { it.pointsBonus } * points.toLong() +
            active.sumOf { if (it.raceTarget > 0 && bestFinish <= it.raceTarget) it.raceTargetBonus else 0L }
        val prize = when {
            bestFinish <= 3 -> 2_500_000L
            bestFinish <= 10 -> 1_500_000L
            bestFinish <= 20 -> 900_000L
            else -> 500_000L
        }
        s = s.copy(finance=s.finance.transact(income, "Patrocínios e bônus GP $round").transact(prize, "Premiação GP $round").transact(-850_000L, "Custos GP $round"))
        states[teamId]=s
        return s
    }

    /** Credits sponsorship upfront exactly once when an AI contract is first observed as active. */
    fun applySponsorshipSignings(teamId:Int, season:Int, sponsorship:TeamSponsorshipEngine.TeamSponsorshipState): State {
        var s = state(teamId, season)
        val seen = seenSponsorContracts.getOrPut(teamId) { mutableSetOf() }
        sponsorship.sponsors.filter { it.active }.forEach { sponsor ->
            val key = "${season}:${sponsor.slot}:${sponsor.name}:${sponsor.races}"
            if (seen.add(key)) {
                s = s.copy(finance = s.finance.transact(sponsor.upfront, "Entrada patrocínio: ${sponsor.name} (slot ${sponsor.slot})"))
            }
        }
        states[teamId] = s
        return s
    }

    /** Charges a signature fee exactly once for each newly scheduled AI deal. */
    fun applyNewDeals(teamId:Int, season:Int, before:DriverMarketState, after:DriverMarketState, marketEngine:DriverMarketEngine): State {
        var s = state(teamId, season)
        val beforeKeys = before.scheduled.filter { it.toTeamId == teamId && it.startSeason == season + 1 }.map { key(it) }.toSet()
        val deals = after.scheduled.filter { it.toTeamId == teamId && it.startSeason == season + 1 && key(it) !in beforeKeys && key(it) !in (seenDeals[teamId] ?: mutableSetOf()) }
        deals.forEach { deal ->
            val fee = marketEngine.signatureFeeFor(after, deal.driverId, teamId, season)
            if (fee > 0) s = s.copy(finance=s.finance.transact(-fee, "Taxa de assinatura ${deal.driverId} — temporada ${season+1}"))
            seenDeals.getOrPut(teamId) { mutableSetOf() }.add(key(deal))
        }
        states[teamId]=s
        return s
    }

    fun ensureAllTeams(season:Int, playerTeamId:Int, market:DriverMarketState) {
        WorldDatabase.teams.filter { it.id != playerTeamId }.forEach { beginSeason(it.id, season, market) }
    }

    /** Stable persistence snapshot for Android process restarts. */
    fun exportSnapshot(): String {
        fun b64(v:String)=java.util.Base64.getEncoder().encodeToString(v.toByteArray(Charsets.UTF_8))
        val lines=mutableListOf<String>()
        states.values.sortedBy { it.teamId }.forEach { s ->
            val f=s.finance
            val seenD=seenDeals[s.teamId].orEmpty().joinToString(",") { b64(it) }
            val seenS=seenSponsorContracts[s.teamId].orEmpty().joinToString(",") { b64(it) }
            val dev=developmentBudgets[s.teamId to s.season] ?: 0L
            val pen=negativeBalancePenalties[s.teamId to s.season] == true
            lines += listOf("S",s.teamId,s.season,f.budget,f.seasonIncome,f.seasonExpenses,f.raceIncome,f.raceExpenses,f.seasonPrizesPaid.sorted().joinToString(","),b64(seenD),b64(seenS),dev,pen).joinToString("|")
        }
        return lines.joinToString("\n")
    }

    fun restoreSnapshot(raw:String) {
        states.clear(); seenDeals.clear(); seenSponsorContracts.clear(); developmentBudgets.clear(); negativeBalancePenalties.clear()
        fun dec(v:String)=runCatching { String(java.util.Base64.getDecoder().decode(v),Charsets.UTF_8) }.getOrDefault("")
        raw.lineSequence().filter { it.isNotBlank() }.forEach { line ->
            val p=line.split("|", limit=13)
            if (p.size<13 || p[0]!="S") return@forEach
            val team=p[1].toIntOrNull() ?: return@forEach; val season=p[2].toIntOrNull() ?: return@forEach
            val f=TeamFinanceState(p[3].toLongOrNull()?:0L,p[4].toLongOrNull()?:0L,p[5].toLongOrNull()?:0L,p[6].toLongOrNull()?:0L,p[7].toLongOrNull()?:0L,seasonPrizesPaid=p[8].split(",").mapNotNull { it.toIntOrNull() }.toSet())
            states[team]=State(team,season,f)
            seenDeals[team]=dec(p[9]).split(",").filter { it.isNotBlank() }.mapTo(mutableSetOf()) { dec(it) }
            seenSponsorContracts[team]=dec(p[10]).split(",").filter { it.isNotBlank() }.mapTo(mutableSetOf()) { dec(it) }
            developmentBudgets[team to season]=p[11].toLongOrNull()?:0L
            if (p[12].toBoolean()) negativeBalancePenalties[team to season]=true
        }
    }

    private fun key(d:FutureDriverDeal):String = "${d.driverId}:${d.toTeamId}:${d.startSeason}:${d.years}:${d.salary}:${d.role}"
}
