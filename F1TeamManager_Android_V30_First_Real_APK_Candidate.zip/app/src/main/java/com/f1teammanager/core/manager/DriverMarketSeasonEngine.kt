package com.f1teammanager.core.manager

class DriverMarketSeasonEngine(private val market: DriverMarketEngine = DriverMarketEngine()) {
    fun start(state: TeamManagerState): TeamManagerState {
        if (state.driverMarket.contracts.isNotEmpty()) return state
        return state.copy(driverMarket = market.initialState(state.season))
    }

    fun offer(state: TeamManagerState, driverId: Int, toTeamId: Int, years: Int, salary: Long, buyout: Long = 0L): TeamManagerState {
        val s = start(state)
        val current = s.driverMarket.contracts.first { it.driverId == driverId }
        require(current.teamId != toTeamId) { "Piloto já está na equipe" }
        require(toTeamId == s.playerTeamId) { "Esta ação é para contratar para a equipe do jogador" }
        val (marketState, offer) = market.offer(s.driverMarket, driverId, current.teamId, toTeamId, years, salary, buyout,
            teamStrength = s.car.aerodynamics.coerceIn(1,100), reputation = s.manager.reputation, season = s.season)
        if (!offer.accepted) return s.copy(driverMarket = marketState, history = (s.history + "Oferta recusada para piloto ${driverId}").takeLast(100))
        require(s.finance.budget >= salary / 4) { "Orçamento insuficiente para bônus de assinatura" }
        val finance = s.finance.transact(-(salary/4), "Bônus de assinatura do piloto ${driverId}")
        return s.copy(driverMarket = marketState, finance = finance, history = (s.history + "Piloto ${driverId} contratado").takeLast(100))
    }

    fun renew(state: TeamManagerState, driverId: Int, years: Int, salary: Long): TeamManagerState {
        val s = start(state)
        val ms = market.renew(s.driverMarket, driverId, s.playerTeamId, years, salary, s.season)
        return s.copy(driverMarket = ms, history = (s.history + "Piloto ${driverId} renovado").takeLast(100))
    }

    fun offseason(state: TeamManagerState): TeamManagerState {
        val s = start(state)
        val budgets = (1..40).associateWith { if (it == s.playerTeamId) s.finance.budget else 15_000_000L + it * 250_000L }
        val nextMarket = market.runAiOffseason(s.driverMarket, s.season + 1, budgets)
        return s.copy(season = s.season + 1, round = 1, driverMarket = nextMarket,
            history = (s.history + "Mercado de pilotos resolvido para ${s.season + 1}").takeLast(100))
    }
}
