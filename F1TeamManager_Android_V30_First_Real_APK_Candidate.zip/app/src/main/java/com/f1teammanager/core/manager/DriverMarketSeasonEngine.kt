package com.f1teammanager.core.manager

/** Coordinates the Stage 3 market with the manager career. */
class DriverMarketSeasonEngine(private val market: DriverMarketEngine = DriverMarketEngine()) {
    fun start(state: TeamManagerState): TeamManagerState {
        if (state.driverMarket.contracts.isNotEmpty() || state.driverMarket.freeAgents.isNotEmpty()) return state
        return state.copy(driverMarket = market.initialState(state.season))
    }

    fun offer(state: TeamManagerState, driverId: Int, toTeamId: Int, years: Int, salary: Long, role: DriverTeamRole = DriverTeamRole.EQUAL, currentWeek: Int = 1): TeamManagerState {
        val s = start(state)
        val (nextMarket, offer) = market.makeOffer(s.driverMarket, driverId, toTeamId, years, salary, role, s.season, currentWeek = currentWeek)
        var next = s.copy(driverMarket = nextMarket)
        if (offer.accepted && offer.buyout > 0) {
            next = next.copy(finance = next.finance.transact(-offer.buyout, "Multa de transferência do piloto ${driverId}"))
        }
        return next.copy(history=(next.history+"Proposta para piloto $driverId: ${offer.status}").takeLast(100))
    }

    fun renew(state: TeamManagerState, driverId: Int, years: Int, salary: Long, role: DriverTeamRole = DriverTeamRole.EQUAL): TeamManagerState {
        val s = start(state)
        val ms = market.renew(s.driverMarket, driverId, s.playerTeamId, years, salary, role, s.season)
        return s.copy(driverMarket = ms, history = (s.history + "Piloto ${driverId} renovado").takeLast(100))
    }

    fun offseason(state: TeamManagerState): TeamManagerState {
        val s = start(state)
        val budgets = (1..40).associateWith { if (it == s.playerTeamId) s.finance.budget else 15_000_000L + it * 250_000L }
        val nextSeason = s.season + 1
        val nextMarket = market.applySeasonTransition(s.driverMarket, nextSeason, budgets)
        return s.copy(season = nextSeason, round = 1, driverMarket = nextMarket,
            history = (s.history + "Mercado de pilotos resolvido para $nextSeason").takeLast(100))
    }
}
