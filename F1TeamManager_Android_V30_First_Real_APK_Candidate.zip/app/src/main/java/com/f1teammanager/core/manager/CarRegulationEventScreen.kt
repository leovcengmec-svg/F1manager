package com.f1teammanager.core.manager

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

/** First-week regulation briefing; deliberately reuses the existing event-card artwork and layout. */
@Composable
fun CarRegulationEventScreen(
    season: Int,
    rule: AnnualCarRegulationEngine.SeasonRule,
    onContinue: () -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF070B10))
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text(
            if (rule.decennialRevolution) "REVOLUÇÃO DE REGULAMENTO"
            else if (rule.season == 1) "CICLO TÉCNICO SORTEADO"
            else if (rule.annualEvents.isEmpty()) "REGULAMENTO MANTIDO"
            else "MUDANÇA DE REGULAMENTO",
            style = MaterialTheme.typography.titleLarge,
            color = Color.White,
            fontWeight = FontWeight.Black,
            maxLines = 2,
            lineHeight = MaterialTheme.typography.titleLarge.lineHeight
        )
        Text("TEMPORADA $season • REGRA TÉCNICA DO CAMPEONATO",
            style = MaterialTheme.typography.labelMedium, color = Color(0xFFB0BDCC))
        Text(
            "CICLO TÉCNICO: ${rule.cycleLength} temporadas • início ${rule.cycleStartSeason} • próxima revolução na temporada ${rule.cycleStartSeason + rule.cycleLength}",
            style = MaterialTheme.typography.bodySmall, color = Color(0xFF8EC5FF)
        )
        if (rule.decennialRevolution) {
            Text("REVOLUÇÃO DO CICLO TÉCNICO", style = MaterialTheme.typography.titleMedium,
                color = Color(0xFFFF8617), fontWeight = FontWeight.Bold)
            Text("Revolução técnica: neste ano, a regra decenal substitui a regra anual. Um novo ciclo de ${rule.cycleLength} temporadas foi sorteado para esta carreira. Cada equipe também recebe uma redução aleatória própria de 0% a 8%, representando a dificuldade de acertar o carro no primeiro ano do regulamento.",
                style = MaterialTheme.typography.bodyMedium, color = Color.White)
        } else if (rule.season == 1) {
            Text("Temporada inaugural: não há alteração anual de desempenho. A duração do primeiro ciclo técnico já foi sorteada e ficará válida até a revolução indicada acima.",
                style = MaterialTheme.typography.bodyMedium, color = Color.White)
        } else if (rule.annualEvents.isEmpty()) {
            Text("Nenhuma mudança anual foi sorteada. O regulamento permanece igual nesta temporada; a próxima revolução técnica continua programada pelo ciclo indicado acima.",
                style = MaterialTheme.typography.bodyMedium, color = Color.White)
        }
        LazyColumn(
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(bottom = 8.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(rule.annualEvents, key = { it.id }) { event ->
                AnnualCarRegulationEventCard(event = event, season = season)
            }
            if (rule.decennialRevolution) {
                item(key = "decennial-summary") {
                    Column(modifier = Modifier.fillMaxWidth().background(Color(0xFF121C27)).padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Text("REDUÇÕES DA REVOLUÇÃO TÉCNICA", color = Color.White, fontWeight = FontWeight.Bold)
                        rule.decennialReductions.entries.sortedBy { it.key.name }.forEach { (component, percent) ->
                            Text("${component.regulationLabel()}: −$percent% de desempenho",
                                color = Color(0xFFB0BDCC), style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            }
        }
        Button(onClick = onContinue, modifier = Modifier.fillMaxWidth()) {
            Text("CONTINUAR PARA O INÍCIO DA TEMPORADA")
        }
    }
}

private fun CarComponent.regulationLabel(): String = when (this) {
    CarComponent.ENGINE -> "Motor"
    CarComponent.CHASSIS -> "Chassi"
    CarComponent.FRONT_WING -> "Asa dianteira"
    CarComponent.REAR_WING -> "Asa traseira"
    CarComponent.BRAKES -> "Freios"
    CarComponent.ELECTRIC_POWER_UNIT -> "MGU-K / unidade elétrica"
}
