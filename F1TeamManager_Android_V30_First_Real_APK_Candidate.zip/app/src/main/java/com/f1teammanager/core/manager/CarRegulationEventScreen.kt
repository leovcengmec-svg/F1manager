package com.f1teammanager.core.manager

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

/** First-week regulation briefing; deliberately reuses the existing event-card artwork and layout. */
@Composable
fun CarRegulationEventScreen(
    season: Int,
    rule: AnnualCarRegulationEngine.SeasonRule,
    onContinue: () -> Unit,
) {
    Column(
        modifier = Modifier.fillMaxSize().background(Color(0xFF070B10)).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("MUDANÇA DE REGULAMENTO", style = MaterialTheme.typography.titleLarge,
            color = Color.White, fontWeight = FontWeight.Black)
        Text("TEMPORADA $season • REGRA TÉCNICA DO CAMPEONATO",
            style = MaterialTheme.typography.labelMedium, color = Color(0xFFB0BDCC))
        if (rule.decennialRevolution) {
            Text("REVOLUÇÃO DECENAL", style = MaterialTheme.typography.titleMedium,
                color = Color(0xFFFF8617), fontWeight = FontWeight.Bold)
            Text("Revisão técnica ampla: os seis componentes recebem as reduções decenais previstas, além de eventual regra anual.",
                style = MaterialTheme.typography.bodyMedium, color = Color.White)
        }
        LazyColumn(
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(bottom = 8.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(rule.annualEvents, key = { it.id }) { event ->
                AnnualCarRegulationEventCard(event = event, season = season)
            }
            if (rule.decennialRevolution) {
                item(key = "decennial-summary") {
                    Column(modifier = Modifier.fillMaxWidth().background(Color(0xFF121C27)).padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Text("REDUÇÕES DA REVOLUÇÃO DECENAL", color = Color.White, fontWeight = FontWeight.Bold)
                        rule.decennialReductions.entries.sortedBy { it.key.name }.forEach { (component, percent) ->
                            Text("${component.regulationLabel()}: −$percent% de desempenho",
                                color = Color(0xFFB0BDCC), style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            }
        }
        Button(onClick = onContinue, modifier = Modifier.fillMaxWidth()) {
            Text("CONTINUAR PARA O INÍCIO DA TEMPORADA")
        }
    }
}

private fun CarComponent.regulationLabel(): String = when (this) {
    CarComponent.ENGINE -> "Motor"
    CarComponent.CHASSIS -> "Chassi"
    CarComponent.FRONT_WING -> "Asa dianteira"
    CarComponent.REAR_WING -> "Asa traseira"
    CarComponent.BRAKES -> "Freios"
    CarComponent.ELECTRIC_POWER_UNIT -> "MGU-K / unidade elétrica"
}
