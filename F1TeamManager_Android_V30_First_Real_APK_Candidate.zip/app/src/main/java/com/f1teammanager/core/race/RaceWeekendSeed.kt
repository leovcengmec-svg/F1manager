package com.f1teammanager.core.race

/**
 * Stable, independent random seed for each Grand Prix weekend.
 * The same career/season/round/circuit always reproduces the same weather and
 * qualifying draws (including after reload), while different rounds do not reuse
 * the same opening random sequence.
 */
object RaceWeekendSeed {
    fun forWeekend(careerSeed: Int, season: Int, round: Int, circuitName: String): Int {
        require(season > 0) { "Temporada inválida para a semente do GP" }
        require(round in 1..50) { "Etapa inválida para a semente do GP" }
        require(circuitName.isNotBlank()) { "Circuito obrigatório para a semente do GP" }

        // FNV-1a over explicit fields, followed by a 64-bit avalanche. This avoids
        // Kotlin/JVM process-randomized hashes and keeps replays deterministic.
        var hash = 0xcbf29ce484222325UL.toLong()
        val key = "$careerSeed|$season|$round|${circuitName.trim().lowercase()}"
        key.toByteArray(Charsets.UTF_8).forEach { byte ->
            hash = (hash xor (byte.toLong() and 0xffL)) * 0x100000001b3L
        }
        hash = hash xor (hash ushr 33)
        hash *= 0xff51afd7ed558ccdUL.toLong()
        hash = hash xor (hash ushr 33)
        hash *= 0xc4ceb9fe1a85ec53UL.toLong()
        hash = hash xor (hash ushr 33)
        return (hash xor (hash ushr 32)).toInt().let { if (it == 0) 1 else it }
    }
}
