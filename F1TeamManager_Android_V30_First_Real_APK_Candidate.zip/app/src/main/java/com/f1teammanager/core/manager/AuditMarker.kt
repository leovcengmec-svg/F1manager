package com.f1teammanager.core.manager

/**
 * Build-time marker for the cleaned architecture. The playable race engine is
 * CareerWeekendEngine; ManagerSeasonEngine is the season/audit orchestrator.
 */
object AuditMarker {
    const val ARCHITECTURE_VERSION = "V48"
    const val NEXT_CAR_CONSTRUCTION_POLICY = "PRESERVE_BASE_PLUS_INVESTMENT_AND_REGULATION_V548"
}
