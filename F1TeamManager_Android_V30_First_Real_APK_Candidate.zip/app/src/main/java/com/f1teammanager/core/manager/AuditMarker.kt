package com.f1teammanager.core.manager

/**
 * Build-time marker for the cleaned architecture. The playable race engine is
 * CareerWeekendEngine; ManagerSeasonEngine is the season/audit orchestrator.
 */
object AuditMarker {
    const val ARCHITECTURE_VERSION = "V48"
    const val ANNUAL_CAR_CONTINUITY = 0.70
}
