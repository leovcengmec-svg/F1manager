package com.f1teammanager.core.manager

/** Persistent, simulation-independent career state for the Team Principal mode. */
data class TeamPrincipalObjective(val id: String, val title: String, val detail: String, val kind: String, val target: Int, val prestige: Int)

data class TeamPrincipalContractOffer(
    val teamId: Int,
    val years: Int,
    val isCurrentTeam: Boolean = false
) {
    fun normalized() = copy(years = years.coerceIn(1, 2))
}

data class TeamPrincipalSeasonRecord(
    val season: Int,
    val teamId: Int,
    val teamRank: Int,
    val objectiveRank: Int,
    val prestigeDelta: Int,
    val objectiveResults: String = ""
)

data class TeamPrincipalCareerState(
    val teamId: Int,
    val prestige: Int = 1,
    val contractStartSeason: Int = 2026,
    val objectiveRank: Int = 37,
    val lastProcessedSeason: Int = 2025,
    val lastRank: Int = 40,
    val bestRank: Int = 40,
    val reviewPending: Boolean = false,
    val dismissed: Boolean = false,
    /** Kept for backwards-compatible callers and old saves; mirrors contractOffers team IDs. */
    val offerTeamIds: List<Int> = emptyList(),
    val records: List<TeamPrincipalSeasonRecord> = emptyList(),
    val objectives: List<TeamPrincipalObjective> = emptyList(),
    /** Season whose board objectives were calibrated after the new car and regulation were finalized. */
    val objectivesPreparedForSeason: Int = 0,
    /** The signed term length. New careers start with a one-season contract. */
    val contractYears: Int = 1,
    /** Board confidence is persistent and influences end-of-season dismissal risk. */
    val boardSupport: Int = 75,
    /** Offers include the current team's renewal when it has not dismissed the principal. */
    val contractOffers: List<TeamPrincipalContractOffer> = emptyList(),
    /** Prevents creating duplicate contract windows/events on repeated season settlement. */
    val offersSeason: Int = 0
) {
    val contractEndSeason: Int get() = contractStartSeason + contractYears.coerceIn(1, 2) - 1

    fun encode(): String {
        val recordsText = records.joinToString(";") { "${it.season},${it.teamId},${it.teamRank},${it.objectiveRank},${it.prestigeDelta},${it.objectiveResults.ifBlank { "-" }}" }
        val objectivesText = objectives.joinToString(";") { listOf(it.id,it.title,it.detail,it.kind,it.target,it.prestige).joinToString("~") }
        val offers = if (contractOffers.isNotEmpty()) contractOffers else offerTeamIds.map { TeamPrincipalContractOffer(it, 1, it == teamId) }
        val offersText = offers.joinToString(";") { "${it.teamId},${it.years.coerceIn(1, 2)},${if (it.isCurrentTeam) 1 else 0}" }
        return listOf(
            5, teamId, prestige, contractStartSeason, objectiveRank, lastProcessedSeason,
            lastRank, bestRank, if (reviewPending) 1 else 0, if (dismissed) 1 else 0,
            offers.joinToString(",") { it.teamId.toString() }, recordsText, objectivesText,
            objectivesPreparedForSeason, contractYears.coerceIn(1, 2), boardSupport.coerceIn(0, 100),
            offersText, offersSeason
        ).joinToString("#")
    }

    companion object {
        fun decode(raw: String?): TeamPrincipalCareerState? = runCatching {
            val p = raw?.split('#') ?: return null
            val schema = p.firstOrNull()?.toIntOrNull() ?: return null
            if (p.size !in 12..18 || schema !in 1..5) return null
            val records = p[11].split(';').filter { it.isNotBlank() }.mapNotNull { row ->
                val r = row.split(',')
                when (r.size) {
                    6 -> TeamPrincipalSeasonRecord(r[0].toInt(), r[1].toInt(), r[2].toInt(), r[3].toInt(), r[4].toInt(), r[5].takeIf { it != "-" }.orEmpty())
                    5 -> TeamPrincipalSeasonRecord(r[0].toInt(), r[1].toInt(), r[2].toInt(), r[3].toInt(), r[4].toInt())
                    // Backward compatibility for early Team Principal V586 development saves.
                    4 -> TeamPrincipalSeasonRecord(r[0].toInt(), p[1].toInt(), r[1].toInt(), r[2].toInt(), r[3].toInt())
                    else -> null
                }
            }
            val objectives = if (schema >= 3 && p.size >= 13) p[12].split(';').filter { it.isNotBlank() }.mapNotNull { row ->
                val r = row.split('~'); if (r.size != 6) null else TeamPrincipalObjective(r[0],r[1],r[2],r[3],r[4].toIntOrNull() ?: return@mapNotNull null,r[5].toIntOrNull() ?: return@mapNotNull null)
            } else emptyList()
            val oldTeamIds = p[10].split(',').mapNotNull { it.toIntOrNull() }.distinct()
            val currentTeamId = p[1].toInt()
            val decodedOffers = if (schema >= 5 && p.size >= 18) {
                p[16].split(';').filter { it.isNotBlank() }.mapNotNull { row ->
                    val r = row.split(',')
                    if (r.size < 3) null else runCatching { TeamPrincipalContractOffer(r[0].toInt(), r[1].toInt().coerceIn(1, 2), r[2] == "1") }.getOrNull()
                }.distinctBy { it.teamId }
            } else oldTeamIds.map { TeamPrincipalContractOffer(it, 1, it == currentTeamId) }
            val migratedOffers = if (schema < 5 && p[8] == "1" && p[9] != "1" && decodedOffers.none { it.teamId == currentTeamId }) {
                (listOf(TeamPrincipalContractOffer(currentTeamId, 1, true)) + decodedOffers.filterNot { it.teamId == currentTeamId }.take(3)).take(4)
            } else decodedOffers.take(4)
            val decodedStartSeason = p[3].toInt()
            val decodedLastProcessedSeason = p[5].toInt()
            // Older versions used a biennial review marker without a durable term length. For
            // an active legacy save, start the migrated one-year term at the next unprocessed
            // season so the new strict expiry check cannot silently skip the next contract window.
            val migratedStartSeason = if (schema < 5 && p[8] != "1" && p[9] != "1") {
                maxOf(decodedStartSeason, decodedLastProcessedSeason + 1)
            } else decodedStartSeason
            TeamPrincipalCareerState(
                teamId = p[1].toInt(), prestige = p[2].toInt().coerceIn(0, 100),
                contractStartSeason = migratedStartSeason, objectiveRank = p[4].toInt().coerceIn(1, 40),
                lastProcessedSeason = p[5].toInt(), lastRank = p[6].toInt().coerceIn(1, 40),
                bestRank = when {
                    records.isEmpty() -> 40
                    schema == 1 -> records.minOfOrNull { it.teamRank.coerceIn(1, 40) } ?: 40
                    else -> p[7].toInt().coerceIn(1, 40)
                }, reviewPending = p[8] == "1",
                dismissed = p[9] == "1",
                offerTeamIds = if (migratedOffers.isNotEmpty()) migratedOffers.map { it.teamId } else oldTeamIds,
                records = records,
                objectives = objectives,
                objectivesPreparedForSeason = if (schema >= 4 && p.size >= 14) p[13].toIntOrNull()?.coerceAtLeast(0) ?: 0 else 0,
                contractYears = if (schema >= 5 && p.size >= 18) p[14].toIntOrNull()?.coerceIn(1, 2) ?: 1 else 1,
                boardSupport = if (schema >= 5 && p.size >= 18) p[15].toIntOrNull()?.coerceIn(0, 100) ?: 75 else 75,
                contractOffers = migratedOffers,
                offersSeason = if (schema >= 5 && p.size >= 18) p[17].toIntOrNull()?.coerceAtLeast(0) ?: 0 else 0
            )
        }.getOrNull()
    }
}

/**
 * Official Team Principal rules. Rank 1 is best. The opening rank is based on the
 * canonical starting-car ranking; seasonal performance uses the championship table.
 */
object TeamPrincipalCareerEngine {
    /** Confidence granted when a principal signs a fresh contract with a board. */
    const val INITIAL_BOARD_SUPPORT = 75
    /**
     * Ordinary careers may cross the season boundary only with exactly two confirmed drivers.
     * After a signed Team Principal handoff, however, the destination roster is still managed
     * by the AI until rollover; its vacancies are resolved by the offseason market within the
     * same durable transition, so checking the pre-rollover roster would deadlock the career.
     */
    fun mayAdvanceWithProjectedRoster(projectedRosterSize: Int, acceptedHandoffForTargetSeason: Boolean): Boolean =
        acceptedHandoffForTargetSeason || projectedRosterSize == 2

    /** A stale or unrelated saved manager state must never expose Team Principal UI in Free/Hard mode.
     * A missing mode is accepted only for backward compatibility with pre-mode-key Team Principal saves. */
    fun isActiveMode(activeGameMode: String?, hasCareerState: Boolean): Boolean =
        hasCareerState && (activeGameMode == "TEAM_PRINCIPAL" || activeGameMode == null)

    fun initial(teamId: Int, season: Int, openingRankByTeam: Map<Int, Int>, facilityLevels: Map<FacilityType, Int> = emptyMap()): TeamPrincipalCareerState {
        val rank = openingRankByTeam[teamId] ?: 40
        val objectiveRank = targetRank(rank)
        return TeamPrincipalCareerState(
            teamId = teamId, prestige = 1, contractStartSeason = season,
            objectiveRank = objectiveRank, lastProcessedSeason = season - 1,
            lastRank = rank, bestRank = 40,
            boardSupport = INITIAL_BOARD_SUPPORT,
            objectives = generateObjectives(teamId, season, rank, objectiveRank, 0, facilityLevels)
        )
    }

    /** The contractual market window opens only in the exact season the signed term expires. */
    fun isEvaluationSeason(state: TeamPrincipalCareerState, season: Int): Boolean =
        season == state.contractEndSeason

    /** A completed season cannot roll over until the player resolves the TP contract decision. */
    fun mayAdvanceWithContractDecision(state: TeamPrincipalCareerState?): Boolean =
        state == null || !state.reviewPending

    fun outsideOfferQuota(prestige: Int): Int = when (prestige.coerceIn(0, 100)) {
        in 0..39 -> 1
        in 40..59 -> 2
        else -> 3
    }

    /** Transparent end-of-season firing odds derived from board confidence and sporting delivery. */
    /**
     * Board dismissal risk. Support is only the starting pressure: race pace, qualifying,
     * finances, technical progress and facility investment all add independent consequences.
     * Performance scores use 0..100, where 50 is broadly on the board's expected level.
     */
    /** Shared scoring used by both the live career forecast and the season settlement. */
    fun performanceScore(positions: List<Int>, objectiveRank: Int): Int {
        if (positions.isEmpty()) return 50
        val expectedDriverPosition = (objectiveRank.coerceIn(1, 40) * 2.0) - 0.5
        val average = positions.map { it.coerceIn(1, 80) }.average()
        return (50.0 + (expectedDriverPosition - average) * 2.0).toInt().coerceIn(0, 100)
    }

    fun financialStressPercent(effectiveBalance: Long, cashTarget: Long): Int = when {
        effectiveBalance < 0L -> 100
        cashTarget > 0L && effectiveBalance < cashTarget / 4L -> 80
        cashTarget > 0L && effectiveBalance < cashTarget / 2L -> 60
        cashTarget > 0L && effectiveBalance < cashTarget -> 35
        else -> 0
    }

    fun facilityInvestmentScore(
        objectives: List<TeamPrincipalObjective>,
        results: List<String>,
        upgradeProgressPercent: Int = 0
    ): Int {
        val facilityObjectives = objectives.filter { it.kind.startsWith("facility_") }
        if (facilityObjectives.isEmpty()) return 2
        val completed = facilityObjectives.count { goal -> results.any { it == goal.id + ":1" } }
        val completedScore = ((completed * 2) / facilityObjectives.size).coerceIn(0, 2)
        // A paid upgrade still under construction is meaningful board investment, even
        // though it cannot satisfy the level objective until the work is complete.
        return if (upgradeProgressPercent.coerceIn(0, 100) > 0) maxOf(completedScore, 1) else completedScore
    }

    fun developmentProgressScore(
        completedResearchCount: Int,
        researchProgressPercent: Int,
        manufacturedPiecesReady: Int,
        manufacturingProgressPercent: Int = 0
    ): Int {
        val researchDelivered = completedResearchCount > 0 || researchProgressPercent.coerceIn(0, 100) > 0
        val physicalUpgradeInPipeline = manufacturedPiecesReady > 0 || manufacturingProgressPercent.coerceIn(0, 100) > 0
        return when {
            researchDelivered && physicalUpgradeInPipeline -> 2
            researchDelivered || physicalUpgradeInPipeline -> 1
            else -> 0
        }
    }

    fun objectiveCompletionPercent(results: List<String>): Int =
        if (results.isEmpty()) 50 else results.count { it.endsWith(":1") } * 100 / results.size

    fun dismissalProbabilityPercent(
        boardSupport: Int,
        rank: Int,
        objectiveRank: Int,
        repeatedObjectiveFailure: Boolean = false,
        racePerformance: Int = 50,
        qualifyingPerformance: Int = 50,
        financialStress: Int = 0,
        developmentProgress: Int = 1,
        facilityInvestment: Int = 1,
        objectiveCompletionPercent: Int = 50
    ): Int {
        val base = when (boardSupport.coerceIn(0, 100)) {
            in 80..100 -> 4
            in 70..79 -> 12
            in 60..69 -> 22
            in 50..59 -> 35
            in 40..49 -> 50
            in 30..39 -> 65
            in 20..29 -> 80
            else -> 90
        }
        val sportingPenalty = when {
            rank >= objectiveRank + 8 -> 15
            rank >= objectiveRank + 5 -> 11
            rank >= objectiveRank + 3 -> 7
            rank > objectiveRank -> 3
            else -> 0
        }
        val racePenalty = when (racePerformance.coerceIn(0, 100)) {
            in 0..19 -> 16
            in 20..34 -> 12
            in 35..44 -> 7
            in 45..54 -> 2
            else -> 0
        }
        val qualifyingPenalty = when (qualifyingPerformance.coerceIn(0, 100)) {
            in 0..19 -> 12
            in 20..34 -> 9
            in 35..44 -> 5
            in 45..54 -> 2
            else -> 0
        }
        val financePenalty = when (financialStress.coerceIn(0, 100)) {
            in 80..100 -> 15
            in 60..79 -> 11
            in 40..59 -> 7
            in 20..39 -> 3
            else -> 0
        }
        val developmentPenalty = when (developmentProgress.coerceIn(0, 2)) {
            0 -> 8 // no research completion and no manufactured upgrade ready
            1 -> 3
            else -> 0
        }
        val facilityPenalty = when (facilityInvestment.coerceIn(0, 2)) {
            0 -> 8 // no facility upgrade despite the board's investment expectation
            1 -> 3
            else -> 0
        }
        val objectivePenalty = when (objectiveCompletionPercent.coerceIn(0, 100)) {
            in 0..19 -> 12
            in 20..39 -> 8
            in 40..59 -> 4
            else -> 0
        }
        return (base + sportingPenalty + racePenalty + qualifyingPenalty + financePenalty +
            developmentPenalty + facilityPenalty + objectivePenalty + if (repeatedObjectiveFailure) 10 else 0)
            .coerceIn(0, 98)
    }

    fun targetRank(teamRank: Int): Int = when (teamRank.coerceIn(1, 40)) {
        in 1..3 -> (teamRank + 1).coerceAtMost(4)
        in 4..10 -> (teamRank + 2).coerceAtMost(12)
        in 11..20 -> (teamRank + 3).coerceAtMost(24)
        in 21..30 -> (teamRank + 4).coerceAtMost(34)
        else -> (teamRank + 5).coerceAtMost(40)
    }

    /**
     * Rebuilds objectives exactly once per season, only after the next-season physical car
     * and the season's regulation have been applied. The opening car rank is the primary
     * signal; last season's sporting rank, points, real cash and facility levels adjust the
     * challenge so a strong new car/high-investment organization does not receive trivial goals.
     */
    fun prepareObjectivesForOpeningSeason(
        state: TeamPrincipalCareerState,
        season: Int,
        openingRankByTeam: Map<Int, Int>,
        facilityLevels: Map<FacilityType, Int>,
        previousSeasonPoints: Int,
        cashBalance: Long
    ): TeamPrincipalCareerState {
        val normalizedState = normalizeImpossibleObjectives(state)
        if (normalizedState.dismissed || season <= 0 || normalizedState.objectivesPreparedForSeason >= season) return normalizedState
        val openingRank = (openingRankByTeam[normalizedState.teamId] ?: normalizedState.lastRank).coerceIn(1, 40)
        // lastRank is the last actual sporting position for this contract/team; it is refreshed
        // during season settlement and explicitly set to the destination's latest rank on hiring.
        val previousRank = normalizedState.lastRank.coerceIn(1, 40)
        val priorPoints = previousSeasonPoints.coerceAtLeast(0)
        val facilityAverage = averageFacilityLevel(facilityLevels)
        val mainTarget = openingObjectiveTarget(openingRank, previousRank, facilityAverage)
        val objectives = generateObjectives(
            teamId = normalizedState.teamId,
            season = season,
            rank = openingRank,
            mainTarget = mainTarget,
            points = priorPoints,
            facilityLevels = facilityLevels,
            cashBalance = cashBalance,
            previousRank = previousRank
        )
        // If the save came from a legacy schema with stale/missing objective IDs, this also
        // creates a complete set for the current opening. It is still a single persisted decision.
        return normalizedState.copy(
            objectiveRank = mainTarget,
            objectives = objectives,
            objectivesPreparedForSeason = season
        )
    }

    private fun normalizeImpossibleObjectives(state: TeamPrincipalCareerState): TeamPrincipalCareerState {
        if (state.objectives.isEmpty()) return state
        val maximumGain = (state.lastRank.coerceIn(1, 40) - 1).coerceAtLeast(0)
        var changed = false
        val normalized = state.objectives.map { goal ->
            if (goal.kind != "improve" || goal.target <= maximumGain) goal
            else {
                changed = true
                if (maximumGain == 0) goal.copy(
                    title = "Defender a liderança",
                    detail = "Manter a equipe na liderança do Mundial de Construtores",
                    kind = "maintain_rank",
                    target = 1
                ) else goal.copy(
                    target = maximumGain,
                    detail = "Melhorar pelo menos $maximumGain posição(ões) em relação à temporada anterior"
                )
            }
        }
        return if (changed) state.copy(objectives = normalized) else state
    }

    private fun openingObjectiveTarget(openingRank: Int, previousRank: Int, facilityAverage: Int): Int {
        // Give new-car strength 80% of the forecast and retain 20% of last season's result.
        // Then demand a genuine step forward. Higher facilities raise the expectation instead
        // of allowing an advanced organization to keep last year's easy target.
        val projectedRank = (openingRank * 0.80 + previousRank * 0.20).toInt().let { floor ->
            val exact = openingRank * 0.80 + previousRank * 0.20
            if (exact - floor >= 0.5) floor + 1 else floor
        }.coerceIn(1, 40)
        val challengePush = 3 + (facilityAverage / 4)
        return (projectedRank - challengePush).coerceAtLeast(1)
    }

    private fun averageFacilityLevel(facilityLevels: Map<FacilityType, Int>): Int =
        FacilityType.values().map { (facilityLevels[it] ?: 0).coerceIn(0, 10) }.average().toInt().coerceIn(0, 10)

    private fun generateObjectives(
        teamId: Int,
        season: Int,
        rank: Int,
        mainTarget: Int,
        points: Int,
        facilityLevels: Map<FacilityType, Int> = emptyMap(),
        cashBalance: Long = 0L,
        previousRank: Int = rank
    ): List<TeamPrincipalObjective> {
        val averageFacility = averageFacilityLevel(facilityLevels)
        val primary = TeamPrincipalObjective(
            "main_$season", "Objetivo principal",
            "Terminar em ${mainTarget}º ou melhor no Mundial de Equipes", "rank", mainTarget, 4
        )
        val basePointsTarget = when (rank) { in 1..3 -> 260; in 4..5 -> 220; in 6..10 -> 160; in 11..20 -> 85; in 21..30 -> 40; else -> 15 }
        val rankChange = previousRank - rank // positive when the new car is projected to improve the team's position
        val priorPointsFactor = when {
            rankChange >= 8 -> 1.10
            rankChange >= 3 -> 1.00
            rankChange >= -3 -> 0.85
            rankChange >= -8 -> 0.70
            else -> 0.55
        }
        val previousPointsFloor = kotlin.math.ceil(points.coerceAtLeast(0) * priorPointsFactor).toInt()
        val facilityPointMultiplier = 1.0 + (averageFacility * 0.015)
        val pointsTarget = kotlin.math.ceil(maxOf(basePointsTarget, previousPointsFloor) * facilityPointMultiplier).toInt().coerceAtLeast(basePointsTarget)
        val cashGoal = cashTarget(rank, averageFacility, cashBalance)
        val requestedImprovement = maxOf(if (rank >= 30) 2 else 1, 1 + (averageFacility / 5)).coerceAtMost(3)
        // A team already in P1 cannot improve its rank. Turn that impossible target into
        // a title-defence objective; otherwise cap the requested gain to available places.
        val improvementTarget = requestedImprovement.coerceAtMost((previousRank - 1).coerceIn(0, 39))
        val improvementObjective = if (improvementTarget == 0) {
            TeamPrincipalObjective("improve_$season", "Defender a liderança", "Manter a equipe na liderança do Mundial de Construtores", "maintain_rank", rank, 1)
        } else {
            TeamPrincipalObjective("improve_$season", "Evolução no grid", "Melhorar pelo menos $improvementTarget posição(ões) em relação à temporada anterior", "improve", improvementTarget, 1)
        }
        val pool = mutableListOf(
            TeamPrincipalObjective("cash_$season", "Reserva financeira", "Manter pelo menos €${cashGoal / 1_000_000} M no caixa ao fim da temporada", "cash", cashGoal.coerceAtMost(Int.MAX_VALUE.toLong()).toInt(), 1),
            TeamPrincipalObjective("points_$season", "Pontuação de construtores", "Conquistar pelo menos $pointsTarget pontos", "points", pointsTarget, 1),
            improvementObjective,
            TeamPrincipalObjective("rank10_$season", "Presença no top 10", "Terminar entre as 10 melhores equipes", "rank10", 10, 1),
            TeamPrincipalObjective("rank20_$season", "Competitividade", "Terminar entre as 20 melhores equipes", "rank20", 20, 1),
            TeamPrincipalObjective("avoid_bottom_$season", "Sair do fundo do grid", "Evitar terminar entre as últimas 5 equipes", "rank35", 35, 1),
            TeamPrincipalObjective("points_gain_$season", "Progresso esportivo", "Superar os $points pontos conquistados na temporada anterior", "points_gain", points, 1),
            TeamPrincipalObjective("research_$season", "Pesquisa concluída", "Concluir pelo menos um projeto de pesquisa nesta temporada", "research", 1, 1),
            TeamPrincipalObjective("manufacture_$season", "Peça fabricada na temporada", "Fabricar nesta temporada pelo menos uma peça aguardando instalação", "manufacture", 1, 1)
        )
        val facilityGoals = listOf(
            FacilityType.FACTORY to "Melhorar a Fábrica",
            FacilityType.RESEARCH to "Melhorar o Centro de P&D",
            FacilityType.WIND_TUNNEL to "Melhorar o Túnel de Vento",
            FacilityType.SIMULATOR to "Melhorar o Simulador",
            FacilityType.SCOUTING to "Melhorar o Scouting",
            FacilityType.DRIVER_DEVELOPMENT to "Melhorar o Desenvolvimento de Pilotos",
            FacilityType.MARKETING to "Melhorar o Centro Comercial"
        )
        facilityGoals.forEach { (facility, title) ->
            val current = facilityLevels[facility] ?: 0
            if (current < 10) pool += TeamPrincipalObjective(
                "facility_${facility.name.lowercase()}_$season", title,
                "Elevar ${FacilityEngine.label(facility)} do nível $current para ${current + 1}",
                "facility_${facility.name}", current + 1, 1
            )
        }
        val eligible = pool.filter { goal -> when (goal.kind) {
            // Avoid spending an objective slot on a target already guaranteed by the primary goal.
            "rank10" -> rank <= 15 && mainTarget > 10
            "rank20" -> rank <= 30 && mainTarget > 20
            "rank35" -> mainTarget > 35
            else -> true
        } }
        val facilities = eligible.filter { it.kind.startsWith("facility_") }
            .sortedWith(compareByDescending<TeamPrincipalObjective> { it.target }.thenBy { (it.id + teamId + season).hashCode() })
        val facilityGoalCount = when {
            facilities.isEmpty() -> 0
            averageFacility >= 7 -> 2
            else -> 1
        }
        // Never omit the three core management dimensions: financial reserve, constructor
        // points and improvement versus the previous sporting result. Facilities and rotating
        // development/ranking objectives fill the remaining slots.
        val selectedCore = listOf("cash", "points", "improve").mapNotNull { kind ->
            eligible.firstOrNull { it.kind == kind }
        }
        val selectedFacilities = facilities.take(facilityGoalCount)
        val selectedBase = (selectedCore + selectedFacilities).distinctBy { it.id }
        val selectedOther = eligible.filterNot { candidate -> selectedBase.any { it.id == candidate.id } }
            .sortedBy { (it.id + teamId + season).hashCode() }
            .take((5 - selectedBase.size).coerceAtLeast(0))
        val selected = (selectedBase + selectedOther).take(5)
        return listOf(primary) + selected
    }

    private fun cashTarget(rank: Int, averageFacility: Int = 0, cashBalance: Long = 0L): Long {
        val baseline = when (rank) {
            in 1..10 -> 50_000_000L
            in 11..20 -> 25_000_000L
            in 21..30 -> 12_000_000L
            else -> 5_000_000L
        }
        // Strong cash reserves set a higher retention target, while weak teams still get a
        // meaningful but achievable floor. Better-equipped organizations carry higher standards.
        val reserveBasedTarget = if (cashBalance > 0L) minOf((cashBalance * 75L) / 100L, baseline + 50_000_000L) else baseline
        return maxOf(baseline, reserveBasedTarget) + averageFacility.coerceIn(0, 10) * 1_000_000L
    }

    fun evaluateObjectives(
        state: TeamPrincipalCareerState,
        actualRank: Int,
        constructorPoints: Int,
        cashBalance: Long,
        facilityLevels: Map<FacilityType, Int>,
        completedResearchCount: Int,
        manufacturedPiecesReady: Int
    ): List<String> {
        val rank = actualRank.coerceIn(1, 40)
        return state.objectives.map { goal ->
            val achieved = when (goal.kind) {
                "rank", "rank10", "rank20", "rank35" -> rank <= goal.target
                "cash" -> cashBalance >= goal.target.toLong()
                "points" -> constructorPoints >= goal.target
                "improve" -> state.lastRank - rank >= goal.target
                "maintain_rank" -> rank <= goal.target
                "points_gain" -> constructorPoints > goal.target
                "research" -> completedResearchCount >= goal.target
                "manufacture" -> manufacturedPiecesReady >= goal.target
                else -> goal.kind.startsWith("facility_") && runCatching {
                    val facility = FacilityType.valueOf(goal.kind.removePrefix("facility_"))
                    (facilityLevels[facility] ?: 0) >= goal.target
                }.getOrDefault(false)
            }
            goal.id + ":" + if (achieved) "1" else "0"
        }
    }

    fun recordSeason(
        state: TeamPrincipalCareerState,
        season: Int,
        actualRank: Int,
        currentRankByTeam: Map<Int, Int>,
        constructorPoints: Int = 0,
        cashBalance: Long = 0L,
        facilityLevels: Map<FacilityType, Int> = emptyMap(),
        completedResearchCount: Int = 0,
        manufacturedPiecesReady: Int = 0,
        researchProgressPercent: Int = 0,
        manufacturingProgressPercent: Int = 0,
        facilityUpgradeProgressPercent: Int = 0,
        racePerformance: Int = 50,
        qualifyingPerformance: Int = 50,
        dismissalRoll: Int = kotlin.random.Random.nextInt(100)
    ): TeamPrincipalCareerState {
        if (season <= state.lastProcessedSeason || state.dismissed) return state
        val rank = actualRank.coerceIn(1, 40)
        val objective = state.objectiveRank.coerceIn(1, 40)
        val results = evaluateObjectives(
            state, rank, constructorPoints, cashBalance, facilityLevels,
            completedResearchCount, manufacturedPiecesReady
        )
        val rawDelta = state.objectives.sumOf { goal ->
            val result = results.firstOrNull { it.startsWith(goal.id + ":") }?.endsWith(":1") == true
            if (result) goal.prestige else -goal.prestige
        }
        // Maximum +8 earned prestige per season; missed objectives still carry their penalties.
        val delta = if (rawDelta > 8) 8 else rawDelta.coerceAtLeast(-8)
        val nextPrestige = (state.prestige + delta).coerceIn(0, 100)
        val record = TeamPrincipalSeasonRecord(season, state.teamId, rank, objective, delta, results.joinToString("|"))
        val records = (state.records + record).takeLast(30)
        val repeatedFailure = records.takeLast(2).let { lastTwo ->
            lastTwo.size == 2 && lastTwo.all { it.teamId == state.teamId && it.teamRank >= it.objectiveRank + 2 }
        }
        val nextBoardSupport = calculateBoardSupport(state.boardSupport, rank, objective, results, delta)
        val objectiveCompletion = objectiveCompletionPercent(results)
        val cashTarget = state.objectives.firstOrNull { it.kind == "cash" }?.target?.toLong() ?: 0L
        val financialStress = financialStressPercent(cashBalance, cashTarget)
        val facilityInvestment = facilityInvestmentScore(state.objectives, results, facilityUpgradeProgressPercent)
        val developmentProgress = developmentProgressScore(
            completedResearchCount, researchProgressPercent, manufacturedPiecesReady, manufacturingProgressPercent
        )
        val dismissalOdds = dismissalProbabilityPercent(
            nextBoardSupport, rank, objective, repeatedFailure,
            racePerformance, qualifyingPerformance, financialStress,
            developmentProgress, facilityInvestment, objectiveCompletion
        )
        val fired = dismissalRoll.coerceIn(0, 99) < dismissalOdds
        val contractEnding = isEvaluationSeason(state, season)
        val openContractWindow = contractEnding || fired
        val offers = if (openContractWindow) {
            buildContractOffers(state.teamId, nextPrestige, currentRankByTeam, season, includeCurrentTeam = !fired, dismissed = fired)
        } else emptyList()
        val nextObjectiveRank = targetRank(rank)
        return state.copy(
            prestige = nextPrestige, lastProcessedSeason = season, lastRank = rank,
            objectiveRank = nextObjectiveRank, bestRank = minOf(state.bestRank, rank),
            reviewPending = openContractWindow, dismissed = fired,
            offerTeamIds = offers.map { it.teamId }, records = records,
            objectives = generateObjectives(state.teamId, season + 1, rank, nextObjectiveRank, constructorPoints, facilityLevels),
            boardSupport = nextBoardSupport, contractOffers = offers, offersSeason = if (openContractWindow) season else 0
        )
    }

    /** Forecasts the support that the same season settlement will calculate from current evidence. */
    fun projectedBoardSupport(
        state: TeamPrincipalCareerState,
        rank: Int,
        objectiveResults: List<String>
    ): Int {
        val rawDelta = state.objectives.sumOf { goal ->
            if (objectiveResults.any { it == goal.id + ":1" }) goal.prestige else -goal.prestige
        }
        val prestigeDelta = if (rawDelta > 8) 8 else rawDelta.coerceAtLeast(-8)
        return calculateBoardSupport(state.boardSupport, rank, state.objectiveRank, objectiveResults, prestigeDelta)
    }

    private fun calculateBoardSupport(
        current: Int,
        rank: Int,
        objectiveRank: Int,
        objectiveResults: List<String>,
        prestigeDelta: Int
    ): Int {
        val completed = objectiveResults.count { it.endsWith(":1") }
        val ratio = if (objectiveResults.isEmpty()) 0.0 else completed.toDouble() / objectiveResults.size
        var delta = when {
            ratio >= 0.80 -> 8
            ratio >= 0.60 -> 4
            ratio >= 0.40 -> 0
            ratio >= 0.20 -> -5
            else -> -10
        }
        delta += when {
            rank <= objectiveRank -> 3
            rank >= objectiveRank + 8 -> -8
            rank >= objectiveRank + 4 -> -4
            else -> 0
        }
        if (prestigeDelta >= 4) delta += 2 else if (prestigeDelta <= -4) delta -= 3
        return (current.coerceIn(0, 100) + delta).coerceIn(0, 100)
    }

    private fun buildContractOffers(
        currentTeamId: Int,
        prestige: Int,
        currentRankByTeam: Map<Int, Int>,
        season: Int,
        includeCurrentTeam: Boolean,
        dismissed: Boolean
    ): List<TeamPrincipalContractOffer> {
        val result = mutableListOf<TeamPrincipalContractOffer>()
        if (includeCurrentTeam) {
            result += TeamPrincipalContractOffer(currentTeamId, offerDuration(currentTeamId, prestige, season, 0), true)
        }
        var outsiders = availableOffers(currentTeamId, prestige, currentRankByTeam)
        // Defensive fallback for incomplete ranking maps: a dismissed principal must still
        // receive one recovery destination if any other team is represented in the table.
        if (dismissed && outsiders.isEmpty()) {
            outsiders = currentRankByTeam.entries.filter { it.key != currentTeamId }
                .sortedByDescending { it.value }.take(1).map { it.key }
        }
        outsiders.take(if (includeCurrentTeam) 3 else 4).forEachIndexed { index, teamId ->
            result += TeamPrincipalContractOffer(teamId, offerDuration(teamId, prestige, season, index + 1), false)
        }
        return result.distinctBy { it.teamId }.take(4)
    }

    private fun offerDuration(teamId: Int, prestige: Int, season: Int, index: Int): Int =
        ((teamId * 7 + prestige * 3 + season + index * 11).mod(2) + 1).coerceIn(1, 2)

    /** Every completed contract window offers at least one external destination, even at zero prestige. */
    fun availableOffers(currentTeamId: Int, prestige: Int, currentRankByTeam: Map<Int, Int>): List<Int> {
        val quota = outsideOfferQuota(prestige)
        if (quota <= 0) return emptyList()
        val minimumEligibleRank = when (prestige.coerceIn(0, 100)) {
            in 0..19 -> 1
            in 20..39 -> 31
            in 40..59 -> 21
            in 60..79 -> 5
            else -> 1
        }
        return currentRankByTeam.entries
            .filter { it.key != currentTeamId && it.value >= minimumEligibleRank && it.value in 1..40 }
            .sortedWith(
                if (prestige >= 60) compareBy<Map.Entry<Int, Int>> { it.value }.thenBy { it.key }
                else compareByDescending<Map.Entry<Int, Int>> { it.value }.thenBy { it.key }
            )
            .take(quota).map { it.key }
    }

    fun renew(
        state: TeamPrincipalCareerState,
        nextSeason: Int,
        currentChampionshipRank: Int,
        facilityLevels: Map<FacilityType, Int> = emptyMap(),
        previousSeasonPoints: Int = 0,
        cashBalance: Long = 0L,
        contractYears: Int = state.contractOffers.firstOrNull { it.isCurrentTeam }?.years ?: 1
    ): TeamPrincipalCareerState = state.copy(
        contractStartSeason = nextSeason,
        contractYears = contractYears.coerceIn(1, 2),
        objectiveRank = targetRank(currentChampionshipRank),
        lastRank = currentChampionshipRank.coerceIn(1, 40),
        reviewPending = false, dismissed = false, offerTeamIds = emptyList(), contractOffers = emptyList(), offersSeason = 0,
        boardSupport = state.boardSupport.coerceIn(0, 100),
        objectives = generateObjectives(state.teamId, nextSeason, currentChampionshipRank, targetRank(currentChampionshipRank), previousSeasonPoints, facilityLevels, cashBalance, currentChampionshipRank)
    )

    fun acceptOffer(
        state: TeamPrincipalCareerState,
        newTeamId: Int,
        nextSeason: Int,
        newTeamChampionshipRank: Int,
        facilityLevels: Map<FacilityType, Int> = emptyMap(),
        previousSeasonPoints: Int = 0,
        cashBalance: Long = 0L,
        contractYears: Int = state.contractOffers.firstOrNull { it.teamId == newTeamId }?.years ?: 1
    ): TeamPrincipalCareerState = state.copy(
        teamId = newTeamId,
        contractStartSeason = nextSeason,
        contractYears = contractYears.coerceIn(1, 2),
        objectiveRank = targetRank(newTeamChampionshipRank),
        lastRank = newTeamChampionshipRank.coerceIn(1, 40),
        reviewPending = false, dismissed = false, offerTeamIds = emptyList(), contractOffers = emptyList(), offersSeason = 0,
        boardSupport = maxOf(state.boardSupport.coerceIn(0, 100), INITIAL_BOARD_SUPPORT),
        objectives = generateObjectives(newTeamId, nextSeason, newTeamChampionshipRank, targetRank(newTeamChampionshipRank), previousSeasonPoints, facilityLevels, cashBalance, newTeamChampionshipRank)
    )

}

/** End-of-season physical package left behind when a principal moves to another team. */
data class TeamPrincipalTeamHandoff(
    val teamId: Int,
    val closingSeason: Int,
    val garage: TeamGarage,
    val facilities: TeamFacilitiesState,
    val nextSeasonInvestment: Long,
    val technicalKnowledge: Map<CarComponent, Int>
) {
    fun encode(): String = listOf(
        teamId, closingSeason, nextSeasonInvestment,
        encodeIntMap(technicalKnowledge.mapKeys { it.key.name }),
        encodeIntMap(facilities.levels.mapKeys { it.key.name }),
        encodePhysical(garage.car1), encodePhysical(garage.car2)
    ).joinToString("#")

    companion object {
        fun decode(raw: String?): TeamPrincipalTeamHandoff? = runCatching {
            val p = raw?.split('#') ?: return null
            if (p.size != 7) return null
            val knowledgeRaw = decodeIntMap(p[3])
            val facilitiesRaw = decodeIntMap(p[4])
            TeamPrincipalTeamHandoff(
                teamId = p[0].toInt(), closingSeason = p[1].toInt(),
                nextSeasonInvestment = p[2].toLong().coerceAtLeast(0L),
                garage = TeamGarage(decodePhysical(p[5]), decodePhysical(p[6])),
                facilities = TeamFacilitiesState(FacilityType.values().associateWith { facilitiesRaw[it.name] ?: 0 }),
                technicalKnowledge = knowledgeRaw.mapNotNull { (key, value) ->
                    runCatching { CarComponent.valueOf(key) to value }.getOrNull()
                }.toMap()
            )
        }.getOrNull()

        private fun encodeIntMap(map: Map<String, Int>): String = map.entries.sortedBy { it.key }
            .joinToString(";") { "${it.key}:${it.value}" }

        private fun decodeIntMap(raw: String): Map<String, Int> = raw.split(';').filter { it.isNotBlank() }.mapNotNull {
            val p = it.split(':'); if (p.size != 2) null else p[0] to (p[1].toIntOrNull() ?: return@mapNotNull null)
        }.toMap()

        private fun encodePhysical(car: PhysicalCar): String {
            val reliabilities = car.componentReliabilities.entries.sortedBy { it.key.name }.joinToString(";") { "${it.key.name}:${it.value}" }
            val installed = car.installedPieces.entries.sortedBy { it.key.name }.joinToString(";") {
                "${it.key.name}:${java.util.Base64.getUrlEncoder().withoutPadding().encodeToString(it.value.toByteArray(Charsets.UTF_8))}"
            }
            val versions = car.installedPieceVersions.entries.sortedBy { it.key.name }.joinToString(";") { "${it.key.name}:${it.value}" }
            return listOf(car.id.name, car.engine, car.chassis, car.frontWing, car.rearWing, car.brakes,
                car.electricPowerUnit, car.reliability, reliabilities, installed, versions).joinToString(",")
        }

        private fun decodePhysical(raw: String): PhysicalCar {
            val p = raw.split(',', limit = 11)
            require(p.size == 11)
            fun componentIntMap(text: String): Map<CarComponent, Int> = text.split(';').filter { it.isNotBlank() }.mapNotNull {
                val q = it.split(':'); if (q.size != 2) null else runCatching { CarComponent.valueOf(q[0]) to q[1].toInt() }.getOrNull()
            }.toMap()
            val installed = p[9].split(';').filter { it.isNotBlank() }.mapNotNull {
                val q = it.split(':', limit = 2); if (q.size != 2) null else runCatching {
                    CarComponent.valueOf(q[0]) to String(java.util.Base64.getUrlDecoder().decode(q[1]), Charsets.UTF_8)
                }.getOrNull()
            }.toMap()
            return PhysicalCar(
                id = GarageCarId.valueOf(p[0]), engine = p[1].toInt(), chassis = p[2].toInt(),
                frontWing = p[3].toInt(), rearWing = p[4].toInt(), brakes = p[5].toInt(),
                electricPowerUnit = p[6].toInt(), reliability = p[7].toInt(),
                componentReliabilities = componentIntMap(p[8]), installedPieces = installed,
                installedPieceVersions = componentIntMap(p[10])
            )
        }
    }
}
