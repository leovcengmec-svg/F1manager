package com.f1teammanager.core.manager

/** Persistent, simulation-independent career state for the Team Principal mode. */
data class TeamPrincipalObjective(val id: String, val title: String, val detail: String, val kind: String, val target: Int, val prestige: Int)

data class TeamPrincipalSeasonRecord(
    val season: Int,
    val teamId: Int,
    val teamRank: Int,
    val objectiveRank: Int,
    val prestigeDelta: Int,
    val objectiveResults: String = ""
)

data class TeamPrincipalCareerState(
    val teamId: Int,
    val prestige: Int = 1,
    val contractStartSeason: Int = 2026,
    val objectiveRank: Int = 37,
    val lastProcessedSeason: Int = 2025,
    val lastRank: Int = 40,
    val bestRank: Int = 40,
    val reviewPending: Boolean = false,
    val dismissed: Boolean = false,
    val offerTeamIds: List<Int> = emptyList(),
    val records: List<TeamPrincipalSeasonRecord> = emptyList(),
    val objectives: List<TeamPrincipalObjective> = emptyList()
) {
    fun encode(): String {
        val recordsText = records.joinToString(";") { "${it.season},${it.teamId},${it.teamRank},${it.objectiveRank},${it.prestigeDelta},${it.objectiveResults.ifBlank { "-" }}" }
        val objectivesText = objectives.joinToString(";") { listOf(it.id,it.title,it.detail,it.kind,it.target,it.prestige).joinToString("~") }
        val offersText = offerTeamIds.joinToString(",")
        return listOf(
            3, teamId, prestige, contractStartSeason, objectiveRank, lastProcessedSeason,
            lastRank, bestRank, if (reviewPending) 1 else 0, if (dismissed) 1 else 0,
            offersText, recordsText, objectivesText
        ).joinToString("#")
    }

    companion object {
        fun decode(raw: String?): TeamPrincipalCareerState? = runCatching {
            val p = raw?.split('#') ?: return null
            val schema = p.firstOrNull()?.toIntOrNull() ?: return null
            if (p.size !in 12..13 || schema !in 1..3) return null
            val records = p[11].split(';').filter { it.isNotBlank() }.mapNotNull { row ->
                val r = row.split(',')
                when (r.size) {
                    6 -> TeamPrincipalSeasonRecord(r[0].toInt(), r[1].toInt(), r[2].toInt(), r[3].toInt(), r[4].toInt(), r[5].takeIf { it != "-" }.orEmpty())
                    5 -> TeamPrincipalSeasonRecord(r[0].toInt(), r[1].toInt(), r[2].toInt(), r[3].toInt(), r[4].toInt())
                    // Backward compatibility for early Team Principal V586 development saves.
                    4 -> TeamPrincipalSeasonRecord(r[0].toInt(), p[1].toInt(), r[1].toInt(), r[2].toInt(), r[3].toInt())
                    else -> null
                }
            }
            val objectives = if (schema >= 3 && p.size == 13) p[12].split(';').filter { it.isNotBlank() }.mapNotNull { row ->
                val r = row.split('~'); if (r.size != 6) null else TeamPrincipalObjective(r[0],r[1],r[2],r[3],r[4].toIntOrNull() ?: return@mapNotNull null,r[5].toIntOrNull() ?: return@mapNotNull null)
            } else emptyList()
            TeamPrincipalCareerState(
                teamId = p[1].toInt(), prestige = p[2].toInt().coerceIn(0, 100),
                contractStartSeason = p[3].toInt(), objectiveRank = p[4].toInt().coerceIn(1, 40),
                lastProcessedSeason = p[5].toInt(), lastRank = p[6].toInt().coerceIn(1, 40),
                bestRank = when {
                    records.isEmpty() -> 40
                    schema == 1 -> records.minOfOrNull { it.teamRank.coerceIn(1, 40) } ?: 40
                    else -> p[7].toInt().coerceIn(1, 40)
                }, reviewPending = p[8] == "1",
                dismissed = p[9] == "1",
                offerTeamIds = p[10].split(',').mapNotNull { it.toIntOrNull() }.distinct(), records = records,
                objectives = objectives
            )
        }.getOrNull()
    }
}

/**
 * Official Team Principal rules. Rank 1 is best. The opening rank is based on the
 * canonical starting-car ranking; seasonal performance uses the championship table.
 */
object TeamPrincipalCareerEngine {
    /** A stale or unrelated saved manager state must never expose Team Principal UI in Free/Hard mode.
     * A missing mode is accepted only for backward compatibility with pre-mode-key Team Principal saves. */
    fun isActiveMode(activeGameMode: String?, hasCareerState: Boolean): Boolean =
        hasCareerState && (activeGameMode == "TEAM_PRINCIPAL" || activeGameMode == null)

    fun initial(teamId: Int, season: Int, openingRankByTeam: Map<Int, Int>, facilityLevels: Map<FacilityType, Int> = emptyMap()): TeamPrincipalCareerState {
        val rank = openingRankByTeam[teamId] ?: 40
        val objectiveRank = targetRank(rank)
        return TeamPrincipalCareerState(
            teamId = teamId, prestige = 1, contractStartSeason = season,
            objectiveRank = objectiveRank, lastProcessedSeason = season - 1,
            lastRank = rank, bestRank = 40,
            objectives = generateObjectives(teamId, season, rank, objectiveRank, 0, facilityLevels)
        )
    }

    fun isEvaluationSeason(state: TeamPrincipalCareerState, season: Int): Boolean =
        season >= state.contractStartSeason + 1 && ((season - state.contractStartSeason + 1) % 2 == 0)

    fun targetRank(teamRank: Int): Int = when (teamRank.coerceIn(1, 40)) {
        in 1..3 -> (teamRank + 1).coerceAtMost(4)
        in 4..10 -> (teamRank + 2).coerceAtMost(12)
        in 11..20 -> (teamRank + 3).coerceAtMost(24)
        in 21..30 -> (teamRank + 4).coerceAtMost(34)
        else -> (teamRank + 5).coerceAtMost(40)
    }

    private fun generateObjectives(
        teamId: Int,
        season: Int,
        rank: Int,
        mainTarget: Int,
        points: Int,
        facilityLevels: Map<FacilityType, Int> = emptyMap()
    ): List<TeamPrincipalObjective> {
        val primary = TeamPrincipalObjective(
            "main_$season", "Objetivo principal",
            "Terminar em ${mainTarget}º ou melhor no Mundial de Equipes", "rank", mainTarget, 4
        )
        val pointsTarget = when (rank) { in 1..5 -> 180; in 6..10 -> 100; in 11..20 -> 50; in 21..30 -> 20; else -> 5 }
        val pool = mutableListOf(
            TeamPrincipalObjective("cash_$season", "Reserva financeira", "Manter pelo menos ${cashTarget(rank)} no caixa ao fim da temporada", "cash", cashTarget(rank).toInt(), 1),
            TeamPrincipalObjective("points_$season", "Pontuação de construtores", "Conquistar pelo menos $pointsTarget pontos", "points", pointsTarget, 1),
            TeamPrincipalObjective("improve_$season", "Evolução no grid", "Melhorar pelo menos ${if (rank >= 30) 2 else 1} posição(ões) em relação à temporada anterior", "improve", if (rank >= 30) 2 else 1, 1),
            TeamPrincipalObjective("rank10_$season", "Presença no top 10", "Terminar entre as 10 melhores equipes", "rank10", 10, 1),
            TeamPrincipalObjective("rank20_$season", "Competitividade", "Terminar entre as 20 melhores equipes", "rank20", 20, 1),
            TeamPrincipalObjective("avoid_bottom_$season", "Sair do fundo do grid", "Evitar terminar entre as últimas 5 equipes", "rank35", 35, 1),
            TeamPrincipalObjective("points_gain_$season", "Progresso esportivo", "Superar os $points pontos conquistados na temporada anterior", "points_gain", points, 1),
            TeamPrincipalObjective("research_$season", "Pesquisa concluída", "Concluir pelo menos um projeto de pesquisa nesta temporada", "research", 1, 1),
            TeamPrincipalObjective("manufacture_$season", "Peça fabricada disponível", "Ter pelo menos uma peça fabricada aguardando instalação", "manufacture", 1, 1)
        )
        val facilityGoals = listOf(
            FacilityType.FACTORY to "Melhorar a Fábrica",
            FacilityType.RESEARCH to "Melhorar o Centro de P&D",
            FacilityType.WIND_TUNNEL to "Melhorar o Túnel de Vento",
            FacilityType.SIMULATOR to "Melhorar o Simulador",
            FacilityType.SCOUTING to "Melhorar o Scouting",
            FacilityType.DRIVER_DEVELOPMENT to "Melhorar o Desenvolvimento de Pilotos",
            FacilityType.MARKETING to "Melhorar o Centro Comercial"
        )
        facilityGoals.forEach { (facility, title) ->
            val current = facilityLevels[facility] ?: 0
            if (current < 10) pool += TeamPrincipalObjective(
                "facility_${facility.name.lowercase()}_$season", title,
                "Elevar ${FacilityEngine.label(facility)} do nível $current para ${current + 1}",
                "facility_${facility.name}", current + 1, 1
            )
        }
        val eligible = pool.filter { goal -> when (goal.kind) {
            "rank10" -> rank <= 15
            "rank20" -> rank <= 30
            else -> true
        } }
        val selected = eligible.sortedBy { (it.id + teamId + season).hashCode() }.take(5)
        return listOf(primary) + selected
    }

    private fun cashTarget(rank: Int): Long = when (rank) {
        in 1..10 -> 50_000_000L
        in 11..20 -> 25_000_000L
        in 21..30 -> 12_000_000L
        else -> 5_000_000L
    }

    fun recordSeason(
        state: TeamPrincipalCareerState,
        season: Int,
        actualRank: Int,
        currentRankByTeam: Map<Int, Int>,
        constructorPoints: Int = 0,
        cashBalance: Long = 0L,
        facilityLevels: Map<FacilityType, Int> = emptyMap(),
        completedResearchCount: Int = 0,
        manufacturedPiecesReady: Int = 0
    ): TeamPrincipalCareerState {
        if (season <= state.lastProcessedSeason || state.dismissed) return state
        val rank = actualRank.coerceIn(1, 40)
        val objective = state.objectiveRank.coerceIn(1, 40)
        val results = state.objectives.map { goal ->
            val achieved = when (goal.kind) {
                "rank", "rank10", "rank20", "rank35" -> rank <= goal.target
                "cash" -> cashBalance >= goal.target.toLong()
                "points" -> constructorPoints >= goal.target
                "improve" -> state.lastRank - rank >= goal.target
                "points_gain" -> constructorPoints > goal.target
                "research" -> completedResearchCount >= goal.target
                "manufacture" -> manufacturedPiecesReady >= goal.target
                else -> goal.kind.startsWith("facility_") && runCatching {
                    val facility = FacilityType.valueOf(goal.kind.removePrefix("facility_"))
                    (facilityLevels[facility] ?: 0) >= goal.target
                }.getOrDefault(false)
            }
            goal.id + ":" + if (achieved) "1" else "0"
        }
        val rawDelta = state.objectives.sumOf { goal ->
            val result = results.firstOrNull { it.startsWith(goal.id + ":") }?.endsWith(":1") == true
            if (result) goal.prestige else -goal.prestige
        }
        // Maximum +8 earned prestige per season; missed objectives still carry their penalties.
        val delta = if (rawDelta > 8) 8 else rawDelta.coerceAtLeast(-8)
        val nextPrestige = (state.prestige + delta).coerceIn(0, 100)
        val record = TeamPrincipalSeasonRecord(season, state.teamId, rank, objective, delta, results.joinToString("|"))
        val records = (state.records + record).takeLast(30)
        val reviewDue = isEvaluationSeason(state, season)
        val lastTwo = records.takeLast(2)
        val repeatedlyFailed = lastTwo.size == 2 && lastTwo.all { it.teamRank >= it.objectiveRank + 2 }
        val fired = reviewDue && repeatedlyFailed && nextPrestige < 25
        val offers = if (reviewDue) availableOffers(state.teamId, nextPrestige, currentRankByTeam) else emptyList()
        val nextObjectiveRank = targetRank(rank)
        return state.copy(
            prestige = nextPrestige, lastProcessedSeason = season, lastRank = rank,
            objectiveRank = nextObjectiveRank, bestRank = minOf(state.bestRank, rank), reviewPending = reviewDue,
            dismissed = fired, offerTeamIds = offers, records = records,
            objectives = generateObjectives(state.teamId, season + 1, rank, nextObjectiveRank, constructorPoints, facilityLevels)
        )
    }
    /** Higher prestige opens progressively stronger employers, up to the top three. */
    fun availableOffers(currentTeamId: Int, prestige: Int, currentRankByTeam: Map<Int, Int>): List<Int> {
        val minimumEligibleRank = when (prestige.coerceIn(0, 100)) {
            in 0..19 -> 31
            in 20..39 -> 21
            in 40..59 -> 11
            in 60..79 -> 5
            else -> 1
        }
        val eligible = currentRankByTeam.entries
            .filter { it.key != currentTeamId && it.value >= minimumEligibleRank }
            .sortedWith(compareBy<Map.Entry<Int, Int>> { it.value }.thenBy { it.key })
            .take(3).map { it.key }
        if (eligible.isNotEmpty()) return eligible
        return currentRankByTeam.entries.filter { it.key != currentTeamId }
            .sortedByDescending { it.value }.take(3).map { it.key }
    }

    fun renew(state: TeamPrincipalCareerState, nextSeason: Int, currentChampionshipRank: Int): TeamPrincipalCareerState =
        state.copy(
            contractStartSeason = nextSeason,
            objectiveRank = targetRank(currentChampionshipRank),
            lastRank = currentChampionshipRank.coerceIn(1, 40),
            reviewPending = false, dismissed = false, offerTeamIds = emptyList(),
            objectives = generateObjectives(state.teamId, nextSeason, currentChampionshipRank, targetRank(currentChampionshipRank), 0)
        )

    fun acceptOffer(
        state: TeamPrincipalCareerState,
        newTeamId: Int,
        nextSeason: Int,
        newTeamChampionshipRank: Int
    ): TeamPrincipalCareerState = state.copy(
        teamId = newTeamId,
        contractStartSeason = nextSeason,
        objectiveRank = targetRank(newTeamChampionshipRank),
        lastRank = newTeamChampionshipRank.coerceIn(1, 40),
        reviewPending = false, dismissed = false, offerTeamIds = emptyList(),
        objectives = generateObjectives(newTeamId, nextSeason, newTeamChampionshipRank, targetRank(newTeamChampionshipRank), 0)
    )
}

/** End-of-season physical package left behind when a principal moves to another team. */
data class TeamPrincipalTeamHandoff(
    val teamId: Int,
    val closingSeason: Int,
    val garage: TeamGarage,
    val facilities: TeamFacilitiesState,
    val nextSeasonInvestment: Long,
    val technicalKnowledge: Map<CarComponent, Int>
) {
    fun encode(): String = listOf(
        teamId, closingSeason, nextSeasonInvestment,
        encodeIntMap(technicalKnowledge.mapKeys { it.key.name }),
        encodeIntMap(facilities.levels.mapKeys { it.key.name }),
        encodePhysical(garage.car1), encodePhysical(garage.car2)
    ).joinToString("#")

    companion object {
        fun decode(raw: String?): TeamPrincipalTeamHandoff? = runCatching {
            val p = raw?.split('#') ?: return null
            if (p.size != 7) return null
            val knowledgeRaw = decodeIntMap(p[3])
            val facilitiesRaw = decodeIntMap(p[4])
            TeamPrincipalTeamHandoff(
                teamId = p[0].toInt(), closingSeason = p[1].toInt(),
                nextSeasonInvestment = p[2].toLong().coerceAtLeast(0L),
                garage = TeamGarage(decodePhysical(p[5]), decodePhysical(p[6])),
                facilities = TeamFacilitiesState(FacilityType.values().associateWith { facilitiesRaw[it.name] ?: 0 }),
                technicalKnowledge = knowledgeRaw.mapNotNull { (key, value) ->
                    runCatching { CarComponent.valueOf(key) to value }.getOrNull()
                }.toMap()
            )
        }.getOrNull()

        private fun encodeIntMap(map: Map<String, Int>): String = map.entries.sortedBy { it.key }
            .joinToString(";") { "${it.key}:${it.value}" }

        private fun decodeIntMap(raw: String): Map<String, Int> = raw.split(';').filter { it.isNotBlank() }.mapNotNull {
            val p = it.split(':'); if (p.size != 2) null else p[0] to (p[1].toIntOrNull() ?: return@mapNotNull null)
        }.toMap()

        private fun encodePhysical(car: PhysicalCar): String {
            val reliabilities = car.componentReliabilities.entries.sortedBy { it.key.name }.joinToString(";") { "${it.key.name}:${it.value}" }
            val installed = car.installedPieces.entries.sortedBy { it.key.name }.joinToString(";") {
                "${it.key.name}:${java.util.Base64.getUrlEncoder().withoutPadding().encodeToString(it.value.toByteArray(Charsets.UTF_8))}"
            }
            val versions = car.installedPieceVersions.entries.sortedBy { it.key.name }.joinToString(";") { "${it.key.name}:${it.value}" }
            return listOf(car.id.name, car.engine, car.chassis, car.frontWing, car.rearWing, car.brakes,
                car.electricPowerUnit, car.reliability, reliabilities, installed, versions).joinToString(",")
        }

        private fun decodePhysical(raw: String): PhysicalCar {
            val p = raw.split(',', limit = 11)
            require(p.size == 11)
            fun componentIntMap(text: String): Map<CarComponent, Int> = text.split(';').filter { it.isNotBlank() }.mapNotNull {
                val q = it.split(':'); if (q.size != 2) null else runCatching { CarComponent.valueOf(q[0]) to q[1].toInt() }.getOrNull()
            }.toMap()
            val installed = p[9].split(';').filter { it.isNotBlank() }.mapNotNull {
                val q = it.split(':', limit = 2); if (q.size != 2) null else runCatching {
                    CarComponent.valueOf(q[0]) to String(java.util.Base64.getUrlDecoder().decode(q[1]), Charsets.UTF_8)
                }.getOrNull()
            }.toMap()
            return PhysicalCar(
                id = GarageCarId.valueOf(p[0]), engine = p[1].toInt(), chassis = p[2].toInt(),
                frontWing = p[3].toInt(), rearWing = p[4].toInt(), brakes = p[5].toInt(),
                electricPowerUnit = p[6].toInt(), reliability = p[7].toInt(),
                componentReliabilities = componentIntMap(p[8]), installedPieces = installed,
                installedPieceVersions = componentIntMap(p[10])
            )
        }
    }
}
