package com.f1teammanager.core.career

import com.f1teammanager.core.race.*

/**
 * V22: the career facade now delegates the playable weekend to the single
 * full-field interactive CareerWeekendEngine. The older V21 RaceDecisionEngine
 * remains in the source tree for regression/reference, but career gameplay no
 * longer runs a second race state in parallel.
 */
class CareerRaceIntegration(
    private val season: Int,
    private val circuit: RaceCircuit,
    private val participants: List<RaceParticipant>,
    private val playerTeamId: Int,
    seed: Int = season
) {
    private val weekend = CareerWeekendEngine(seed)
    private var started = false
    private var qualifying: QualifyingResult? = null

    fun begin(): CareerWeekendEngine.SessionSnapshot {
        check(!started) { "Fim de semana já iniciado" }
        val first = weekend.start(participants, circuit, playerTeamId)
        qualifying = first.grid
        started = true
        return first
    }

    fun setStrategy(driverId: Int, posture: DriverPosture? = null, tyre: Tyre? = null): CareerWeekendEngine.SessionSnapshot {
        check(started) { "Inicie o fim de semana antes de configurar a estratégia" }
        return weekend.setPlan(driverId, posture?.toMode(), tyre)
    }

    fun advance(): CareerWeekendEngine.SessionSnapshot = weekend.advance()

    fun choose(action: ManagerDecisionAction): CareerWeekendEngine.SessionSnapshot = weekend.choose(action)

    /** Red flag is a single manager decision containing BOTH restart tyre and posture. */
    fun chooseRedFlag(tyre: Tyre, posture: DriverPosture): CareerWeekendEngine.SessionSnapshot =
        weekend.chooseRedFlag(tyre, posture)

    fun snapshot(): CareerWeekendEngine.SessionSnapshot =
        weekend.snapshotForUi()

    fun result(): RaceResult = weekend.result()

    fun summary(): CareerRaceSummary {
        val s = weekend.snapshotForUi()
        return CareerRaceSummary(
            season = season,
            circuit = circuit.name,
            qualifyingPosition = qualifying?.grid?.firstOrNull { it.driverId == playerFirstDriverId() }?.position ?: 0,
            currentLap = s.lap,
            totalLaps = circuit.laps,
            status = if (s.completed) SessionStatus.FINISHED else if (s.decision != null) SessionStatus.PAUSED_FOR_MANAGER_DECISION else SessionStatus.RUNNING,
            eventCount = s.events.size
        )
    }

    private fun playerFirstDriverId(): Int =
        participants.firstOrNull { it.teamId == playerTeamId }?.driverId ?: -1

    private fun DriverPosture.toMode(): DriverStrategyMode = when (this) {
        DriverPosture.ATTACK -> DriverStrategyMode.ATTACK
        DriverPosture.BALANCED -> DriverStrategyMode.BALANCED
        DriverPosture.DEFENSE -> DriverStrategyMode.DEFENSE
    }
}

data class CareerRaceSummary(
    val season: Int,
    val circuit: String,
    val qualifyingPosition: Int,
    val currentLap: Int,
    val totalLaps: Int,
    val status: SessionStatus,
    val eventCount: Int
)
