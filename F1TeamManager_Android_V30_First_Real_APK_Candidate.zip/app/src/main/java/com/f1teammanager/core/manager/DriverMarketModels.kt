package com.f1teammanager.core.manager

enum class DriverTeamRole { PILOT_1, PILOT_2, EQUAL }
enum class DriverRolePreference { DEMANDS_PILOT_1, PREFERS_PILOT_1, INDIFFERENT, PREFERS_EQUALITY }

enum class NegotiationStatus { PENDING, COUNTER, ACCEPTED, REJECTED, EXPIRED }

data class DriverDeal(
    val driverId: Int,
    val teamId: Int,
    val years: Int,
    val salary: Long,
    val marketValue: Long,
    val buyout: Long,
    val seasonSigned: Int,
    val role: DriverTeamRole = DriverTeamRole.EQUAL
) {
    fun normalized() = copy(
        years = years.coerceIn(1, 3), salary = salary.coerceAtLeast(100_000L),
        marketValue = marketValue.coerceAtLeast(0L), buyout = buyout.coerceAtLeast(0L)
    )
    fun contractYear(season: Int): Int = (season - seasonSigned + 1).coerceAtLeast(1)
    fun activeIn(season: Int): Boolean = season in seasonSigned..(seasonSigned + years - 1)
    fun canReceiveProposals(season: Int): Boolean {
        if (!activeIn(season)) return false
        return !(years == 3 && contractYear(season) == 1)
    }
}

data class FutureDriverDeal(
    val driverId: Int,
    val fromTeamId: Int,
    val toTeamId: Int,
    val startSeason: Int,
    val years: Int,
    val salary: Long,
    val role: DriverTeamRole,
    val signedSeason: Int,
    val buyoutPaid: Long = 0L,
    val replaceDriverId: Int? = null
) {
    fun normalized() = copy(years = years.coerceIn(1, 3), salary = salary.coerceAtLeast(100_000L), buyoutPaid = buyoutPaid.coerceAtLeast(0L))
}

data class DriverOffer(
    val driverId: Int,
    val fromTeamId: Int,
    val toTeamId: Int,
    val years: Int,
    val salary: Long,
    val role: DriverTeamRole,
    val marketValue: Long,
    val buyout: Long,
    val interestScore: Int,
    val round: Int = 1,
    val expiresAfterWeek: Int = 1,
    val status: NegotiationStatus = NegotiationStatus.PENDING,
    val seasonTarget: Int = 2027
) {
    val accepted: Boolean get() = status == NegotiationStatus.ACCEPTED
}

data class ScoutingReport(
    val driverId: Int,
    val teamId: Int,
    val cost: Long,
    val createdWeek: Int,
    val expiresWeek: Int,
    val expectedSalary: Long,
    val marketValue: Long,
    val buyout: Long,
    val rolePreference: DriverRolePreference,
    val interest: Int
)

data class DriverMarketState(
    val contracts: List<DriverDeal> = emptyList(),
    val pending: List<DriverOffer> = emptyList(),
    val scheduled: List<FutureDriverDeal> = emptyList(),
    val freeAgents: List<Int> = emptyList(),
    val rolePreferences: Map<Int, DriverRolePreference> = emptyMap(),
    val scouting: List<ScoutingReport> = emptyList(),
    val history: List<String> = emptyList()
) {
    // Compatibility accessor for the old UI/tests.
    val released: List<Int> get() = freeAgents

    fun normalized(): DriverMarketState {
        val known = contracts.map { it.normalized() }.distinctBy { it.driverId }
        val occupied = known.map { it.driverId }.toSet()
        val free = freeAgents.distinct().filter { it !in occupied }
        return copy(
            contracts = known,
            pending = pending.takeLast(100),
            scheduled = scheduled.map { it.normalized() }.distinctBy { it.driverId },
            freeAgents = free,
            rolePreferences = rolePreferences.filterKeys { it in 1..100 },
            scouting = scouting.takeLast(200),
            history = history.takeLast(300)
        )
    }
}
