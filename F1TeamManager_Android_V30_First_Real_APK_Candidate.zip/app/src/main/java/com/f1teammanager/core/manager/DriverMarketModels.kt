package com.f1teammanager.core.manager

enum class DriverTeamRole { PILOT_1, PILOT_2, EQUAL }
enum class DriverRolePreference { DEMANDS_PILOT_1, PREFERS_PILOT_1, INDIFFERENT, PREFERS_EQUALITY }

enum class NegotiationStatus { PENDING, COUNTER, ACCEPTED, REJECTED, EXPIRED }

enum class MarketNewsCategory {
    MARKET, DRIVER_EVOLUTION, TEAM_EVOLUTION, ANNUAL_EVENTS, DRIVER_EVENTS;

    companion object {
        /** Presentation order only; enum names/ordinals stay untouched for save compatibility. */
        val CENTRAL_DISPLAY_ORDER: List<MarketNewsCategory> = listOf(
            MARKET,
            DRIVER_EVOLUTION,
            TEAM_EVOLUTION,
            DRIVER_EVENTS,
            ANNUAL_EVENTS
        )
    }
}

data class DriverDeal(
    val driverId: Int,
    val teamId: Int,
    val years: Int,
    val salary: Long,
    val marketValue: Long,
    val seasonSigned: Int,
    val role: DriverTeamRole = DriverTeamRole.EQUAL
) {
    fun normalized() = copy(
        years = years.coerceIn(1, 5), salary = salary.coerceAtLeast(100_000L),
        marketValue = marketValue.coerceAtLeast(0L)
    )
    fun contractYear(season: Int): Int = (season - seasonSigned + 1).coerceAtLeast(1)
    fun activeIn(season: Int): Boolean = season in seasonSigned..(seasonSigned + years - 1)
    fun canReceiveProposals(season: Int): Boolean {
        if (!activeIn(season)) return false
        return contractYear(season) == years
    }
}

data class FutureDriverDeal(
    val driverId: Int,
    val fromTeamId: Int,
    val toTeamId: Int,
    val startSeason: Int,
    val years: Int,
    val salary: Long,
    val role: DriverTeamRole,
    val signedSeason: Int,
    val replaceDriverId: Int? = null
) {
    fun normalized() = copy(years = years.coerceIn(1, 5), salary = salary.coerceAtLeast(100_000L))
}

data class DriverOffer(
    val driverId: Int,
    val fromTeamId: Int,
    val toTeamId: Int,
    val years: Int,
    val salary: Long,
    val role: DriverTeamRole,
    val marketValue: Long,
    val interestScore: Int,
    val round: Int = 1,
    val expiresAfterWeek: Int = 1,
    val status: NegotiationStatus = NegotiationStatus.PENDING,
    val seasonTarget: Int = 2027,
    val replaceDriverId: Int? = null,
    val proposerTeamId: Int = 0
) {
    val accepted: Boolean get() = status == NegotiationStatus.ACCEPTED
}

data class MarketNotification(
    val season: Int,
    val week: Int,
    val title: String,
    val message: String,
    val important: Boolean = true,
    val category: MarketNewsCategory = MarketNewsCategory.MARKET,
    /** Optional team ownership for Home-scoped notices; null keeps legacy/global semantics. */
    val relatedTeamId: Int? = null,
    /** Structured transfer identity; optional so V735 and earlier saves remain readable. */
    val driverId: Int? = null,
    /** Zero means the driver was a free agent before signing. */
    val fromTeamId: Int? = null,
    val toTeamId: Int? = null,
    /** Contract duration signed for the destination/renewal. */
    val contractYears: Int? = null
)

data class DriverMarketState(
    val contracts: List<DriverDeal> = emptyList(),
    val pending: List<DriverOffer> = emptyList(),
    val scheduled: List<FutureDriverDeal> = emptyList(),
    val freeAgents: List<Int> = emptyList(),
    val rolePreferences: Map<Int, DriverRolePreference> = emptyMap(),
    val notifications: List<MarketNotification> = emptyList(),
    val history: List<String> = emptyList(),
    /** AI renewal checkpoints already evaluated, keyed by season:teamId:driverId:8-week-window. */
    val renewalEvaluations: Set<String> = emptySet(),
    /** Per-team persistent AI facility queues; serialized with the canonical market save. */
    val aiDriverDevelopment: Map<Int, DriverDevelopmentState> = emptyMap(),
    /** Absolute season-week serial used to advance AI queues by the same elapsed calendar weeks as the player. */
    val aiDriverDevelopmentLastTick: Map<Int, Int> = emptyMap()
) {
    // Compatibility accessor for the old UI/tests.
    val released: List<Int> get() = freeAgents

    fun normalized(): DriverMarketState {
        val known = contracts.map { it.normalized() }.distinctBy { it.driverId }
        val occupied = known.map { it.driverId }.toSet()
        val free = freeAgents.distinct().filter { it !in occupied }
        return copy(
            contracts = known,
            pending = pending.takeLast(100),
            scheduled = scheduled.map { it.normalized() }.distinctBy { it.driverId },
            freeAgents = free,
            rolePreferences = rolePreferences.filterKeys { it in 1..100 },
            notifications = notifications.takeLast(1000),
            history = history.takeLast(300),
            renewalEvaluations = renewalEvaluations.toList().takeLast(600).toSet(),
            aiDriverDevelopment = aiDriverDevelopment.filterKeys { it in 1..40 }.mapValues { it.value.normalized() },
            aiDriverDevelopmentLastTick = aiDriverDevelopmentLastTick.filterKeys { it in 1..40 }.mapValues { it.value.coerceAtLeast(0) }
        )
    }
}

/**
 * Backward-compatible codec for per-team AI facility queues. V702 stored only
 * active programmes; V703 also stores unspent/reserved points so save/load does
 * not silently discard points blocked by annual or potential ceilings.
 */
object AiDriverDevelopmentCodec {
    fun encode(states: Map<Int, DriverDevelopmentState>): String =
        states.toSortedMap().entries.joinToString(";") { (teamId, raw) ->
            val state = raw.normalized()
            val programmes = state.programs.joinToString("~") {
                listOf(it.driverId, it.startedWeek, it.totalWeeks, it.remainingWeeks, it.points).joinToString(",")
            }
            val reserves = state.reservePoints.toSortedMap().entries.joinToString(",") { "${it.key}:${it.value}" }
            "$teamId#$programmes#$reserves"
        }

    fun decode(raw: String): Map<Int, DriverDevelopmentState> = raw
        .split(';').filter { it.isNotBlank() }.mapNotNull { row ->
            val teamParts = row.split('#', limit = 3)
            val teamId = teamParts.firstOrNull()?.toIntOrNull() ?: return@mapNotNull null
            val programmes = teamParts.getOrNull(1).orEmpty()
                .split('~').filter { it.isNotBlank() }.mapNotNull { item ->
                    val values = item.split(',')
                    runCatching {
                        require(values.size >= 5)
                        DriverDevelopmentProgram(values[0].toInt(), values[1].toInt(), values[2].toInt(), values[3].toInt(), values[4].toInt())
                    }.getOrNull()
                }
            val reserves = teamParts.getOrNull(2).orEmpty()
                .split(',').filter { it.isNotBlank() }.mapNotNull { item ->
                    val pair = item.split(':', limit = 2)
                    if (pair.size != 2) null else runCatching { pair[0].toInt() to pair[1].toInt().coerceAtLeast(0) }.getOrNull()
                }.toMap()
            teamId to DriverDevelopmentState(programmes, reserves).normalized()
        }.toMap()
}
