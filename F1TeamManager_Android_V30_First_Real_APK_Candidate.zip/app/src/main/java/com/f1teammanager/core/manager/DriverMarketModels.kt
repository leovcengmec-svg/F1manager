package com.f1teammanager.core.manager

data class DriverDeal(
    val driverId: Int,
    val teamId: Int,
    val years: Int,
    val salary: Long,
    val buyout: Long = 0L,
    val seasonSigned: Int = 2026,
    val isPreContract: Boolean = false
) {
    fun normalized() = copy(years = years.coerceIn(1, 5), salary = salary.coerceAtLeast(100_000L), buyout = buyout.coerceAtLeast(0L))
}

data class DriverOffer(
    val driverId: Int,
    val fromTeamId: Int,
    val toTeamId: Int,
    val years: Int,
    val salary: Long,
    val buyout: Long,
    val acceptanceScore: Int,
    val accepted: Boolean
)

data class DriverMarketState(
    val contracts: List<DriverDeal> = emptyList(),
    val pending: List<DriverOffer> = emptyList(),
    val released: List<Int> = emptyList(),
    val history: List<String> = emptyList()
) {
    fun normalized(): DriverMarketState {
        val unique = contracts.map { it.normalized() }.distinctBy { it.driverId }
        return copy(contracts = unique, released = released.distinct(), history = history.takeLast(200))
    }
}
