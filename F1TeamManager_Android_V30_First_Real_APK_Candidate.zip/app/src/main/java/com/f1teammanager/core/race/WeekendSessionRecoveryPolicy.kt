package com.f1teammanager.core.race

/**
 * Recovery policy for an in-progress weekend after Android process death.
 *
 * A UI SessionSnapshot is not a complete engine checkpoint (PRNG state, queued lap
 * work, incident schedule and exact tyre/fuel precision are not serialized). Therefore
 * an unfinished session is discarded, while a durable completed-result outbox is
 * finalized exactly as saved and an already-finalized result is only restored for display.
 */
object WeekendSessionRecoveryPolicy {
    enum class Action {
        DISCARD_INCOMPLETE_SESSION,
        FINALIZE_DURABLE_RESULT,
        RESTORE_ALREADY_FINALIZED_RESULT
    }

    fun decide(hasMatchingPendingResult: Boolean, isAlreadyFinalized: Boolean): Action = when {
        hasMatchingPendingResult -> Action.FINALIZE_DURABLE_RESULT
        isAlreadyFinalized -> Action.RESTORE_ALREADY_FINALIZED_RESULT
        else -> Action.DISCARD_INCOMPLETE_SESSION
    }
}
