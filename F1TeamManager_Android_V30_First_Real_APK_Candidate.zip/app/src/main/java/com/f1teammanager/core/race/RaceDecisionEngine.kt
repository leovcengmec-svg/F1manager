package com.f1teammanager.core.race

enum class RacePosture { ATTACK, BALANCED, DEFENSE }
enum class LegacyDecisionTyre { SOFT, MEDIUM, HARD }
enum class RaceEvent { NONE, FUEL_LOW, TYRE_DEGRADATION, VSC, SAFETY_CAR, RED_FLAG, MECHANICAL }
enum class ManagerAction { BOX, MAINTAIN, EXTEND }

data class RaceState(
    val lap: Int,
    val totalLaps: Int,
    val fuelPct: Int,
    val tyreAge: Int,
    val tyreWearPct: Int,
    val tyre: LegacyDecisionTyre,
    val posture: RacePosture,
    val event: RaceEvent = RaceEvent.NONE,
    val paused: Boolean = false,
    val finished: Boolean = false,
    val pitStops: Int = 0
)

data class RedFlagRestart(val tyre: LegacyDecisionTyre, val posture: RacePosture)

/**
 * Pure deterministic decision layer. The driver owns DRS/ERS execution;
 * the manager only changes strategy when the race engine requests a decision.
 */
class RaceDecisionEngine {
    fun advance(state: RaceState): RaceState {
        require(!state.finished) { "Race already finished" }
        require(!state.paused) { "Manager decision pending" }
        val nextLap = (state.lap + 1).coerceAtMost(state.totalLaps)
        val fuel = (state.fuelPct - 3).coerceAtLeast(0)
        val age = state.tyreAge + 1
        val wear = (state.tyreWearPct + wearPerLap(state.tyre)).coerceAtMost(100)
        val event = detectEvent(nextLap, fuel, wear)
        val paused = event != RaceEvent.NONE
        return state.copy(
            lap = nextLap,
            fuelPct = fuel,
            tyreAge = age,
            tyreWearPct = wear,
            event = event,
            paused = paused,
            finished = nextLap >= state.totalLaps && !paused
        )
    }

    fun resolve(state: RaceState, action: ManagerAction): RaceState {
        require(state.paused) { "No pending manager decision" }
        require(state.event != RaceEvent.RED_FLAG) { "Red flag requires restart configuration" }
        return when (action) {
            ManagerAction.BOX -> state.copy(
                tyreAge = 0,
                tyreWearPct = 0,
                fuelPct = (state.fuelPct + 70).coerceAtMost(100),
                pitStops = state.pitStops + 1,
                event = RaceEvent.NONE,
                paused = false
            )
            ManagerAction.MAINTAIN -> state.copy(event = RaceEvent.NONE, paused = false)
            ManagerAction.EXTEND -> state.copy(event = RaceEvent.NONE, paused = false)
        }
    }

    fun restartAfterRedFlag(state: RaceState, restart: RedFlagRestart): RaceState {
        require(state.event == RaceEvent.RED_FLAG && state.paused) { "Red flag restart is not pending" }
        return state.copy(
            tyre = restart.tyre,
            posture = restart.posture,
            tyreAge = 0,
            tyreWearPct = 0,
            fuelPct = 100,
            event = RaceEvent.NONE,
            paused = false,
            pitStops = state.pitStops
        )
    }

    private fun detectEvent(lap: Int, fuel: Int, wear: Int): RaceEvent = when {
        lap % 19 == 0 -> RaceEvent.RED_FLAG
        lap % 13 == 0 -> RaceEvent.SAFETY_CAR
        lap % 9 == 0 -> RaceEvent.VSC
        wear >= 65 -> RaceEvent.TYRE_DEGRADATION
        fuel <= 18 -> RaceEvent.FUEL_LOW
        else -> RaceEvent.NONE
    }

    private fun wearPerLap(tyre: LegacyDecisionTyre): Int = when (tyre) {
        LegacyDecisionTyre.SOFT -> 7
        LegacyDecisionTyre.MEDIUM -> 5
        LegacyDecisionTyre.HARD -> 3
    }
}
