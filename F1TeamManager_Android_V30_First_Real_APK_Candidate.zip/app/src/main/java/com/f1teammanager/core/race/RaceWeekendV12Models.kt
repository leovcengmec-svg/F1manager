package com.f1teammanager.core.race

enum class DriverStrategyMode { ATTACK, BALANCED, DEFENSE }
enum class ManagerDecisionType { SAFETY_CAR, VSC, RED_FLAG, FUEL_CRITICAL, TYRE_CRITICAL, MECHANICAL_ALERT }
enum class ManagerDecisionAction { BOX, STAY_OUT, EXTEND_STINT, SAVE_FUEL, CHANGE_STRATEGY, RESTART_ATTACK, RESTART_BALANCED, RESTART_DEFENSE, CHANGE_TYRE_SOFT, CHANGE_TYRE_MEDIUM, CHANGE_TYRE_HARD, CHANGE_TYRE_INTERMEDIATE, CHANGE_TYRE_WET }
enum class DriverAutoEvent { DRS_USED, ERS_DEPLOYED, ERS_RECOVERED }

data class DriverRaceControl(
    val driverId: Int,
    var mode: DriverStrategyMode = DriverStrategyMode.BALANCED,
    var fuelKg: Double = 110.0,
    var tyreAge: Int = 0,
    var tyre: Tyre = Tyre.MEDIUM,
    var ersPercent: Double = 100.0,
    var drsUses: Int = 0,
    var ersDeployments: Int = 0,
    var pitStops: Int = 0,
    var alertFuelSent: Boolean = false,
    var alertTyreSent: Boolean = false,
    var finished: Boolean = false
)

data class ManagerDecisionRequest(
    val lap: Int,
    val type: ManagerDecisionType,
    val driverId: Int,
    val message: String,
    val options: List<ManagerDecisionAction>
)

data class RaceControlEvent(
    val lap: Int,
    val driverId: Int?,
    val text: String,
    val auto: Boolean = false
)

data class RaceStep(
    val lap: Int,
    val totalLaps: Int,
    val status: Neutralisation,
    val events: List<RaceControlEvent>,
    val decision: ManagerDecisionRequest?,
    val driverState: DriverRaceControl,
    val completed: Boolean
)
