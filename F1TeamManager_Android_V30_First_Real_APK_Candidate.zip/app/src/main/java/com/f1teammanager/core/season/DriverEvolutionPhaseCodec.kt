package com.f1teammanager.core.season

/**
 * Backward-compatible codec for the compact SharedPreferences representation
 * used by the driver evolution phase ledger: `driverId:phase;driverId:phase`.
 */
object DriverEvolutionPhaseCodec {
    fun decode(serialized: String): MutableMap<Int, String> = serialized
        .split(';')
        .mapNotNull { token ->
            val parts = token.split(':', limit = 2)
            if (parts.size != 2) null
            else parts[0].toIntOrNull()?.let { driverId -> driverId to parts[1] }
        }
        .toMap()
        .toMutableMap()

    fun encode(phases: Map<Int, String>): String = phases
        .toSortedMap()
        .entries
        .joinToString(";") { "${it.key}:${it.value}" }
}
