package com.f1teammanager.core.manager

import com.f1teammanager.core.season.WorldDatabase

/**
 * Persistent commercial layer for AI teams.
 * Sponsorship contracts have a finite number of races. When a contract reaches
 * zero at the end of a GP, that slot is immediately replaced by a new contract
 * so AI teams continuously participate in the sponsorship market.
 */
class TeamSponsorshipEngine(private val seed: Int = 20261006) {
    data class TeamSponsorshipState(
        val teamId: Int,
        val season: Int,
        val sponsors: List<SponsorContract>,
        val annualGuaranteedIncome: Long
    )

    data class SponsorshipEvent(
        val season: Int,
        val round: Int,
        val teamId: Int,
        val slot: Int,
        val type: String,
        val sponsorName: String
    )

    private val states = mutableMapOf<Pair<Int, Int>, TeamSponsorshipState>()
    private val eventLog = mutableListOf<SponsorshipEvent>()

    fun forTeam(teamId: Int, season: Int): TeamSponsorshipState {
        require(WorldDatabase.teams.any { it.id == teamId }) { "Equipe inexistente: $teamId" }
        return states.getOrPut(teamId to season) { createInitial(teamId, season) }
    }

    fun allTeams(season: Int): Map<Int, TeamSponsorshipState> =
        WorldDatabase.teams.associate { it.id to forTeam(it.id, season) }

    /** Advances all five AI sponsorship slots by one completed GP. */
    fun advanceRace(teamId: Int, season: Int, round: Int): TeamSponsorshipState {
        var state = forTeam(teamId, season)
        val updated = mutableListOf<SponsorContract>()
        state.sponsors.forEach { sponsor ->
            val remaining = (sponsor.racesRemaining - 1).coerceAtLeast(0)
            if (remaining > 0) {
                updated += sponsor.copy(racesRemaining = remaining)
            } else {
                eventLog += SponsorshipEvent(season, round, teamId, sponsor.slot, "ENCERRADO", sponsor.name)
                val replacement = createReplacement(teamId, season, round, sponsor.slot)
                updated += replacement
                eventLog += SponsorshipEvent(season, round, teamId, sponsor.slot, "NOVO_CONTRATO", replacement.name)
            }
        }
        state = buildState(teamId, season, updated)
        states[teamId to season] = state
        return state
    }

    fun advanceAllTeams(season: Int, round: Int, playerTeamId: Int? = null) {
        WorldDatabase.teams.filter { it.id != playerTeamId }.forEach { advanceRace(it.id, season, round) }
    }

    fun events(): List<SponsorshipEvent> = eventLog.toList()

    fun activeContractCount(season: Int): Int = allTeams(season).values.sumOf { it.sponsors.count { s -> s.active && s.racesRemaining > 0 } }

    fun replacementCount(season: Int): Int = eventLog.count { it.season == season && it.type == "NOVO_CONTRATO" }

    private fun createInitial(teamId: Int, season: Int): TeamSponsorshipState {
        val sponsors = (1..5).map { slot -> createSponsor(teamId, season, round = 0, slot = slot, initial = true) }
        return buildState(teamId, season, sponsors)
    }

    private fun createReplacement(teamId: Int, season: Int, round: Int, slot: Int): SponsorContract =
        createSponsor(teamId, season, round, slot, initial = false)

    private fun createSponsor(teamId: Int, season: Int, round: Int, slot: Int, initial: Boolean): SponsorContract {
        val team = WorldDatabase.teams.first { it.id == teamId }
        val strength = team.baseCar.coerceIn(40, 100)
        val cycle = kotlin.math.abs(seed + teamId * 97 + season * 31 + round * 17 + slot * 13)
        val tier = (cycle % 5).coerceIn(0, 4)
        val duration = if (initial) 5 + (cycle % 26) else 5 + (cycle % 21)
        val serial = if (initial) 1 else (cycle % 10_000)
        val name = if (initial) "Patrocinador ${team.name} $slot" else "Novo Parceiro ${team.name} $slot-$serial"
        val upfront = 1_000_000L + strength * 20_000L + slot * 150_000L + tier * 100_000L
        val racePayment = 150_000L + strength * 2_500L + slot * 15_000L + tier * 10_000L
        return SponsorContract(
            name = name, upfront = upfront, racePayment = racePayment,
            pointsBonus = 30_000L + strength * 500L, years = 1,
            minimumReputation = strength / 2, slot = slot,
            qualifyingTarget = (12 - slot).coerceAtLeast(3),
            qualifyingBonus = 75_000L + strength * 1_000L,
            raceTarget = (15 - slot).coerceAtLeast(5),
            raceTargetBonus = 100_000L + strength * 1_500L,
            active = true, races = duration, racesRemaining = duration
        )
    }

    private fun buildState(teamId: Int, season: Int, sponsors: List<SponsorContract>): TeamSponsorshipState =
        TeamSponsorshipState(
            teamId, season, sponsors,
            sponsors.sumOf { it.upfront } + sponsors.sumOf { it.racePayment } * 30L
        )
}
