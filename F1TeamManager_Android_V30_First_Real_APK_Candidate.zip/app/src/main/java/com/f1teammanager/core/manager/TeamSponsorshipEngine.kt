package com.f1teammanager.core.manager

import com.f1teammanager.core.season.WorldDatabase
import kotlin.math.abs
import kotlin.math.roundToLong

/** Commercial system: five permanent slots, category access controlled by Marketing level. */
class TeamSponsorshipEngine(private val seed:Int = 20261006) {
    data class TeamSponsorshipState(val teamId:Int,val season:Int,val sponsors:List<SponsorContract>,val annualGuaranteedIncome:Long)
    data class SponsorshipEvent(val season:Int,val round:Int,val teamId:Int,val slot:Int,val type:String,val sponsorName:String)
    data class SponsorOffer(val sponsor:SponsorContract,val category:SponsorCategory)

    private val states=mutableMapOf<Pair<Int,Int>,TeamSponsorshipState>()
    private val eventLog=mutableListOf<SponsorshipEvent>()

    fun forTeam(teamId:Int,season:Int):TeamSponsorshipState {
        require(WorldDatabase.teams.any { it.id==teamId }) { "Equipe inexistente: $teamId" }
        return states.getOrPut(teamId to season) { createInitial(teamId,season) }
    }
    fun allTeams(season:Int)=WorldDatabase.teams.associate { it.id to forTeam(it.id,season) }

    fun advanceRace(teamId:Int,season:Int,round:Int):TeamSponsorshipState {
        val state=forTeam(teamId,season)
        val updated=state.sponsors.map { sponsor ->
            val remaining=(sponsor.racesRemaining-1).coerceAtLeast(0)
            if(remaining>0) sponsor.copy(racesRemaining=remaining)
            else {
                eventLog += SponsorshipEvent(season,round,teamId,sponsor.slot,"ENCERRADO",sponsor.name)
                val replacement=createReplacement(teamId,season,round,sponsor.slot)
                eventLog += SponsorshipEvent(season,round,teamId,sponsor.slot,"NOVO_CONTRATO",replacement.name)
                replacement
            }
        }
        return buildState(teamId,season,updated).also { states[teamId to season]=it }
    }
    fun advanceAllTeams(season:Int,round:Int,playerTeamId:Int?=null)=WorldDatabase.teams.filter { it.id!=playerTeamId }.forEach { advanceRace(it.id,season,round) }
    fun events()=eventLog.toList()
    fun activeContractCount(season:Int)=allTeams(season).values.sumOf { it.sponsors.count { s->s.active && s.racesRemaining>0 } }
    fun replacementCount(season:Int)=eventLog.count { it.season==season && it.type=="NOVO_CONTRATO" }

    /** Three offers for a slot. Category is selected from the team's Marketing level. */
    fun offersForSlot(teamId:Int,season:Int,slot:Int,marketingLevel:Int,round:Int=0):List<SponsorOffer> {
        require(slot in 1..5)
        val active=forTeam(teamId,season).sponsors.filter { it.active && it.slot!=slot }.map { it.name }.toSet()
        val master=slot==1
        val categories=availableCategories(marketingLevel)
        return (0 until 3).map { index ->
            val category=drawCategory(marketingLevel,teamId,season,slot,round,index)
            val pool=SponsorCatalog.pool(category,master).filterNot { it.name in active }
            val profile=pool[abs(seed+teamId*97+season*31+round*17+slot*13+index*53)%pool.size]
            SponsorOffer(buildContract(profile,teamId,season,round,slot,index),category)
        }
    }

    fun availableCategories(level:Int):List<SponsorCategory> = when(level.coerceIn(0,10)) {
        0,1 -> listOf(SponsorCategory.BASICO)
        2,3 -> listOf(SponsorCategory.BASICO,SponsorCategory.REGIONAL)
        4,5 -> listOf(SponsorCategory.REGIONAL,SponsorCategory.NACIONAL)
        6,7 -> listOf(SponsorCategory.NACIONAL,SponsorCategory.INTERNACIONAL)
        8 -> listOf(SponsorCategory.INTERNACIONAL,SponsorCategory.PREMIUM)
        9 -> listOf(SponsorCategory.INTERNACIONAL,SponsorCategory.PREMIUM,SponsorCategory.GLOBAL)
        else -> listOf(SponsorCategory.PREMIUM,SponsorCategory.GLOBAL)
    }

    private fun drawCategory(level:Int,teamId:Int,season:Int,slot:Int,round:Int,index:Int):SponsorCategory {
        val n=abs(seed+teamId*97+season*31+round*17+slot*13+index*53)%100
        return when(level.coerceIn(0,10)) {
            0,1 -> SponsorCategory.BASICO
            2 -> if(n<70) SponsorCategory.BASICO else SponsorCategory.REGIONAL
            3 -> if(n<50) SponsorCategory.BASICO else SponsorCategory.REGIONAL
            4 -> if(n<65) SponsorCategory.REGIONAL else SponsorCategory.NACIONAL
            5 -> if(n<40) SponsorCategory.REGIONAL else SponsorCategory.NACIONAL
            6 -> if(n<60) SponsorCategory.NACIONAL else SponsorCategory.INTERNACIONAL
            7 -> if(n<35) SponsorCategory.NACIONAL else SponsorCategory.INTERNACIONAL
            8 -> if(n<55) SponsorCategory.INTERNACIONAL else SponsorCategory.PREMIUM
            9 -> when { n<25 -> SponsorCategory.INTERNACIONAL; n<85 -> SponsorCategory.PREMIUM; else -> SponsorCategory.GLOBAL }
            else -> if(n<40) SponsorCategory.PREMIUM else SponsorCategory.GLOBAL
        }
    }

    private fun createInitial(teamId:Int,season:Int):TeamSponsorshipState = buildState(teamId,season,(1..5).map { createSponsor(teamId,season,0,it,true) })
    private fun createReplacement(teamId:Int,season:Int,round:Int,slot:Int)=createSponsor(teamId,season,round,slot,false)

    private fun createSponsor(teamId:Int,season:Int,round:Int,slot:Int,initial:Boolean):SponsorContract {
        val level=WorldDatabase.teams.first { it.id==teamId }.initialLevel // AI starts with its official facility level.
        val category=drawCategory(level,teamId,season,slot,round,if(initial) 0 else 1)
        val master=slot==1
        val pool=SponsorCatalog.pool(category,master)
        val profile=pool[abs(seed+teamId*97+season*31+round*17+slot*13+if(initial) 0 else 71)%pool.size]
        return buildContract(profile,teamId,season,round,slot,if(initial) 0 else 1)
    }

    private fun buildContract(profile:SponsorProfile,teamId:Int,season:Int,round:Int,slot:Int,index:Int):SponsorContract {
        val team=WorldDatabase.teams.first { it.id==teamId }
        val strength=team.baseCar.coerceIn(40,100)
        val rank=WorldDatabase.teams.sortedByDescending { it.baseCar }.indexOfFirst { it.id==teamId }+1
        val cycle=abs(seed+teamId*97+season*31+round*17+slot*13+index*53)
        fun range(min:Double,max:Double)= (min+(max-min)*(cycle%100)/99.0)
        val master=slot==1
        val e=if(master) range(6.0,12.0) else range(2.0,5.0)
        val gp=if(master) range(0.8,1.4) else range(0.3,0.7)
        val qb=if(master) range(0.8,1.4) else range(0.3,0.7)
        val rb=if(master) range(1.2,2.0) else range(0.5,1.0)
        val pp=if(master) range(0.040,0.070) else range(0.020,0.040)
        val duration=3+(cycle%8)
        return SponsorContract(profile.name,(e*1_000_000.0).roundToLong(),(gp*1_000_000.0).roundToLong(),(pp*1_000_000.0).roundToLong(),1,strength/2,slot,rank,(qb*1_000_000.0).roundToLong(),rank,(rb*1_000_000.0).roundToLong(),true,duration,duration,profile.category.name)
    }

    /** Stable persistence snapshot for sponsor contracts across Android process restarts. */
    fun exportSnapshot(): String {
        fun b64(v:String)=java.util.Base64.getEncoder().encodeToString(v.toByteArray(Charsets.UTF_8))
        return states.values.sortedWith(compareBy<TeamSponsorshipState> { it.teamId }.thenBy { it.season }).joinToString("\n") { st ->
            val sponsors=st.sponsors.joinToString("~") { s -> listOf(s.name,s.upfront,s.racePayment,s.pointsBonus,s.years,s.minimumReputation,s.slot,s.qualifyingTarget,s.qualifyingBonus,s.raceTarget,s.raceTargetBonus,s.active,s.races,s.racesRemaining,s.category).joinToString("^") { b64(it.toString()) } }
            listOf(st.teamId,st.season,st.annualGuaranteedIncome,b64(sponsors)).joinToString("|")
        }
    }

    fun restoreSnapshot(raw:String) {
        states.clear(); eventLog.clear()
        fun dec(v:String)=runCatching { String(java.util.Base64.getDecoder().decode(v),Charsets.UTF_8) }.getOrDefault("")
        raw.lineSequence().filter { it.isNotBlank() }.forEach { line ->
            val p=line.split("|", limit=4); if(p.size!=4) return@forEach
            val team=p[0].toIntOrNull()?:return@forEach; val season=p[1].toIntOrNull()?:return@forEach; val income=p[2].toLongOrNull()?:0L
            val sponsors=dec(p[3]).split("~").filter { it.isNotBlank() }.mapNotNull { row ->
                val v=row.split("^").map(::dec); if(v.size!=15) return@mapNotNull null
                runCatching { SponsorContract(v[0],v[1].toLong(),v[2].toLong(),v[3].toLong(),v[4].toInt(),v[5].toInt(),v[6].toInt(),v[7].toInt(),v[8].toLong(),v[9].toInt(),v[10].toLong(),v[11].toBoolean(),v[12].toInt(),v[13].toInt(),v[14]) }.getOrNull()
            }
            states[team to season]=TeamSponsorshipState(team,season,sponsors,income)
        }
    }

    private fun buildState(teamId:Int,season:Int,sponsors:List<SponsorContract>)=TeamSponsorshipState(teamId,season,sponsors,sponsors.sumOf { it.upfront }+sponsors.sumOf { it.racePayment }*30L)
}
