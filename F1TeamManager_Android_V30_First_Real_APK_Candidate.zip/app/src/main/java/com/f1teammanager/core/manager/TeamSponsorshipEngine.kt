package com.f1teammanager.core.manager

import com.f1teammanager.core.season.WorldDatabase
import kotlin.math.abs
import kotlin.math.roundToLong

/** Commercial system: five permanent slots, category access controlled by Marketing level. */
class TeamSponsorshipEngine(private val seed:Int = 20261006) {
    data class TeamSponsorshipState(val teamId:Int,val season:Int,val sponsors:List<SponsorContract>,val annualGuaranteedIncome:Long)
    data class SponsorshipEvent(val season:Int,val round:Int,val teamId:Int,val slot:Int,val type:String,val sponsorName:String)
    data class SponsorOffer(val sponsor:SponsorContract,val category:SponsorCategory)

    private val states=mutableMapOf<Pair<Int,Int>,TeamSponsorshipState>()
    private val eventLog=mutableListOf<SponsorshipEvent>()
    private val marketingLevels=mutableMapOf<Int,Int>()

    fun forTeam(teamId:Int,season:Int):TeamSponsorshipState {
        require(WorldDatabase.teams.any { it.id==teamId }) { "Equipe inexistente: $teamId" }
        return states.getOrPut(teamId to season) { createInitial(teamId,season) }
    }
    fun setMarketingLevel(teamId:Int, level:Int) { marketingLevels[teamId] = level.coerceIn(0,10) }

    fun allTeams(season:Int)=WorldDatabase.teams.associate { it.id to forTeam(it.id,season) }

    fun advanceRace(teamId:Int,season:Int,round:Int):TeamSponsorshipState {
        val state=forTeam(teamId,season)
        val updated=state.sponsors.map { sponsor ->
            val remaining=(sponsor.racesRemaining-1).coerceAtLeast(0)
            if(remaining>0) sponsor.copy(racesRemaining=remaining)
            else {
                eventLog += SponsorshipEvent(season,round,teamId,sponsor.slot,"ENCERRADO",sponsor.name)
                val replacement=createReplacement(teamId,season,round,sponsor.slot)
                eventLog += SponsorshipEvent(season,round,teamId,sponsor.slot,"NOVO_CONTRATO",replacement.name)
                replacement
            }
        }
        return buildState(teamId,season,updated).also { states[teamId to season]=it }
    }
    fun advanceAllTeams(season:Int,round:Int,playerTeamId:Int?=null)=WorldDatabase.teams.filter { it.id!=playerTeamId }.forEach { advanceRace(it.id,season,round) }
    fun events()=eventLog.toList()
    fun activeContractCount(season:Int)=allTeams(season).values.sumOf { it.sponsors.count { s->s.active && s.racesRemaining>0 } }
    fun replacementCount(season:Int)=eventLog.count { it.season==season && it.type=="NOVO_CONTRATO" }

    /** Three offers for a slot. Category is selected from the team's Marketing level. */
    fun offersForSlot(teamId:Int,season:Int,slot:Int,marketingLevel:Int,round:Int=0):List<SponsorOffer> {
        require(slot in 1..5)
        val active=forTeam(teamId,season).sponsors.filter { it.active && it.slot!=slot }.map { it.name }.toSet()
        val master=slot==1
        // A sponsorship opportunity is one live draw: first draw ONE category,
        // then draw 3 different sponsors from that same category.
        // The draw changes with the opportunity key (round/slot/seed), so it is
        // never a permanently fixed list for the same slot.
        val category=drawCategory(marketingLevel,teamId,season,slot,round,0)
        val pool=SponsorCatalog.pool(category,master).filterNot { it.name in active }
        require(pool.size >= 3) { "Pool de patrocinadores insuficiente para ${category.name}" }
        val drawSeed=abs(seed.toLong()+teamId*97L+season*31L+round*17L+slot*13L)
        val offers=pool.shuffled(kotlin.random.Random(drawSeed)).take(3)
        return offers.mapIndexed { index, profile ->
            SponsorOffer(buildContract(profile,teamId,season,round,slot,index),category)
        }
    }

    fun availableCategories(level:Int):List<SponsorCategory> = when(level.coerceIn(0,10)) {
        0,1 -> listOf(SponsorCategory.BASICO)
        2,3 -> listOf(SponsorCategory.BASICO,SponsorCategory.REGIONAL)
        4,5 -> listOf(SponsorCategory.REGIONAL,SponsorCategory.NACIONAL)
        6,7 -> listOf(SponsorCategory.NACIONAL,SponsorCategory.INTERNACIONAL)
        8 -> listOf(SponsorCategory.INTERNACIONAL,SponsorCategory.PREMIUM)
        9 -> listOf(SponsorCategory.INTERNACIONAL,SponsorCategory.PREMIUM,SponsorCategory.GLOBAL)
        else -> listOf(SponsorCategory.PREMIUM,SponsorCategory.GLOBAL)
    }

    private fun drawCategory(level:Int,teamId:Int,season:Int,slot:Int,round:Int,index:Int):SponsorCategory {
        val n=abs(seed+teamId*97+season*31+round*17+slot*13+index*53)%100
        return when(level.coerceIn(0,10)) {
            0,1 -> SponsorCategory.BASICO
            2 -> if(n<70) SponsorCategory.BASICO else SponsorCategory.REGIONAL
            3 -> if(n<50) SponsorCategory.BASICO else SponsorCategory.REGIONAL
            4 -> if(n<65) SponsorCategory.REGIONAL else SponsorCategory.NACIONAL
            5 -> if(n<40) SponsorCategory.REGIONAL else SponsorCategory.NACIONAL
            6 -> if(n<60) SponsorCategory.NACIONAL else SponsorCategory.INTERNACIONAL
            7 -> if(n<35) SponsorCategory.NACIONAL else SponsorCategory.INTERNACIONAL
            8 -> if(n<55) SponsorCategory.INTERNACIONAL else SponsorCategory.PREMIUM
            9 -> when { n<25 -> SponsorCategory.INTERNACIONAL; n<85 -> SponsorCategory.PREMIUM; else -> SponsorCategory.GLOBAL }
            else -> if(n<40) SponsorCategory.PREMIUM else SponsorCategory.GLOBAL
        }
    }

    private fun createInitial(teamId:Int,season:Int):TeamSponsorshipState = buildState(teamId,season,(1..5).map { createSponsor(teamId,season,0,it,true) })
    private fun createReplacement(teamId:Int,season:Int,round:Int,slot:Int)=createSponsor(teamId,season,round,slot,false)

    private fun createSponsor(teamId:Int,season:Int,round:Int,slot:Int,initial:Boolean):SponsorContract {
        val level=marketingLevels[teamId] ?: WorldDatabase.teams.first { it.id==teamId }.initialLevel
        val category=drawCategory(level,teamId,season,slot,round,if(initial) 0 else 1)
        val master=slot==1
        val pool=SponsorCatalog.pool(category,master)
        val profile=pool[abs(seed+teamId*97+season*31+round*17+slot*13+if(initial) 0 else 71)%pool.size]
        return buildContract(profile,teamId,season,round,slot,if(initial) 0 else 1)
    }

    /**
     * Converts the opening-season strength rank into a realistic performance window.
     * The same opening car ranking is the single sporting source of truth.
     */
    private fun targetRange(teamRank:Int): Pair<Int,Int> {
        // There are 40 teams but 80 active race seats. The sporting target
        // therefore follows the team's best expected driver slot (1,3,5...79),
        // not the team rank itself. A two-position margin is applied on both
        // sides and clipped to the real P1..P80 grid.
        val r = teamRank.coerceIn(1,40)
        val expectedBestDriverPosition = (r * 2 - 1).coerceIn(1,80)
        val min = (expectedBestDriverPosition - 2).coerceAtLeast(1)
        val max = (expectedBestDriverPosition + 2).coerceAtMost(80)
        return min to max
    }

    private fun buildContract(profile:SponsorProfile,teamId:Int,season:Int,round:Int,slot:Int,index:Int):SponsorContract {
        val team=WorldDatabase.teams.first { it.id==teamId }
        val strength=InitialTeamProfile.strength(team)
        // Rank from the actual randomized opening car, not only Forte/Médio/Fraco.
        val rank=WorldDatabase.teams.sortedByDescending {
            val c=InitialTeamProfile.values(it)
            (c.chassis+c.engine+c.frontWing+c.rearWing+c.brakes+c.electricPowerUnit)/6.0
        }.indexOfFirst { it.id==teamId }+1
        val (targetMin,targetMax)=targetRange(rank)
        val cycle=abs(seed+teamId*97+season*31+round*17+slot*13+index*53)
        fun range(min:Double,max:Double)= (min+(max-min)*(cycle%100)/99.0)
        val master=slot==1
        val payment=profile.paymentModel

        // Commercial value is driven by the sponsor category. The category is
        // not cosmetic: higher categories must produce materially stronger
        // contracts while retaining variation between sponsors.
        data class CategoryBand(val entryMin:Double,val entryMax:Double,val gpMin:Double,val gpMax:Double,val qualMin:Double,val qualMax:Double,val raceMin:Double,val raceMax:Double,val pointMin:Double,val pointMax:Double)
        val band=when(profile.category) {
            SponsorCategory.BASICO -> CategoryBand(1.0,2.0,0.15,0.30,0.10,0.20,0.15,0.30,0.010,0.020)
            SponsorCategory.REGIONAL -> CategoryBand(2.0,3.5,0.25,0.45,0.15,0.30,0.25,0.45,0.015,0.025)
            SponsorCategory.NACIONAL -> CategoryBand(3.0,5.0,0.35,0.60,0.20,0.40,0.35,0.60,0.020,0.035)
            SponsorCategory.INTERNACIONAL -> CategoryBand(4.5,7.0,0.50,0.80,0.30,0.55,0.50,0.85,0.025,0.045)
            SponsorCategory.PREMIUM -> CategoryBand(6.0,9.0,0.65,1.00,0.40,0.70,0.70,1.10,0.035,0.055)
            SponsorCategory.GLOBAL -> CategoryBand(8.0,12.0,0.85,1.30,0.50,0.90,0.90,1.40,0.045,0.070)
        }
        // Master sponsors sit above secondary sponsors within the same
        // category, preserving a clear hierarchy without changing the
        // category progression itself.
        val e=if(master || payment==SponsorPaymentModel.ENTRY_AND_GP || payment==SponsorPaymentModel.ENTRY_ONLY) {
            if(master) range(band.entryMin*1.7,band.entryMax*2.2) else range(band.entryMin,band.entryMax)
        } else 0.0
        val gp=if(master || payment==SponsorPaymentModel.ENTRY_AND_GP || payment==SponsorPaymentModel.GP_ONLY) {
            if(master) range(band.gpMin*1.8,band.gpMax*2.0) else range(band.gpMin,band.gpMax)
        } else 0.0
        val qb=if(master) range(band.qualMin*1.8,band.qualMax*2.0) else range(band.qualMin,band.qualMax)
        val rb=if(master) range(band.raceMin*1.8,band.raceMax*2.0) else range(band.raceMin,band.raceMax)
        val pp=if(master) range(band.pointMin*1.8,band.pointMax*2.0) else range(band.pointMin,band.pointMax)
        val duration=3+(cycle%8)
        return SponsorContract(profile.name,(e*1_000_000.0).roundToLong(),(gp*1_000_000.0).roundToLong(),(pp*1_000_000.0).roundToLong(),1,strength/2,slot,targetMax,(qb*1_000_000.0).roundToLong(),targetMax,(rb*1_000_000.0).roundToLong(),true,duration,duration,profile.category.name,targetMin,targetMax,targetMin,targetMax)
    }

    /** Stable persistence snapshot for sponsor contracts across Android process restarts. */
    fun exportSnapshot(): String {
        fun b64(v:String)=java.util.Base64.getEncoder().encodeToString(v.toByteArray(Charsets.UTF_8))
        return states.values.sortedWith(compareBy<TeamSponsorshipState> { it.teamId }.thenBy { it.season }).joinToString("\n") { st ->
            val sponsors=st.sponsors.joinToString("~") { s -> listOf(s.name,s.upfront,s.racePayment,s.pointsBonus,s.years,s.minimumReputation,s.slot,s.qualifyingTarget,s.qualifyingBonus,s.raceTarget,s.raceTargetBonus,s.active,s.races,s.racesRemaining,s.category,s.qualifyingTargetMin,s.qualifyingTargetMax,s.raceTargetMin,s.raceTargetMax).joinToString("^") { b64(it.toString()) } }
            listOf(st.teamId,st.season,st.annualGuaranteedIncome,b64(sponsors)).joinToString("|")
        }
    }

    fun restoreSnapshot(raw:String) {
        states.clear(); eventLog.clear()
        fun dec(v:String)=runCatching { String(java.util.Base64.getDecoder().decode(v),Charsets.UTF_8) }.getOrDefault("")
        raw.lineSequence().filter { it.isNotBlank() }.forEach { line ->
            val p=line.split("|", limit=4); if(p.size!=4) return@forEach
            val team=p[0].toIntOrNull()?:return@forEach; val season=p[1].toIntOrNull()?:return@forEach; val income=p[2].toLongOrNull()?:0L
            val sponsors=dec(p[3]).split("~").filter { it.isNotBlank() }.mapNotNull { row ->
                val v=row.split("^").map(::dec); if(v.size!=19 && v.size!=15) return@mapNotNull null
                runCatching {
                    if(v.size==19) SponsorContract(v[0],v[1].toLong(),v[2].toLong(),v[3].toLong(),v[4].toInt(),v[5].toInt(),v[6].toInt(),v[7].toInt(),v[8].toLong(),v[9].toInt(),v[10].toLong(),v[11].toBoolean(),v[12].toInt(),v[13].toInt(),v[14],v[15].toInt(),v[16].toInt(),v[17].toInt(),v[18].toInt())
                    else { val q=v[7].toInt(); val r=v[9].toInt(); SponsorContract(v[0],v[1].toLong(),v[2].toLong(),v[3].toLong(),v[4].toInt(),v[5].toInt(),v[6].toInt(),q,v[8].toLong(),r,v[10].toLong(),v[11].toBoolean(),v[12].toInt(),v[13].toInt(),v[14],q,q,r,r) }
                }.getOrNull()
            }
            states[team to season]=TeamSponsorshipState(team,season,sponsors,income)
        }
    }

    private fun buildState(teamId:Int,season:Int,sponsors:List<SponsorContract>)=TeamSponsorshipState(teamId,season,sponsors,sponsors.sumOf { it.upfront }+sponsors.sumOf { it.racePayment }*30L)
}
