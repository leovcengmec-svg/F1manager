package com.f1teammanager.core.manager

import com.f1teammanager.core.season.WorldDatabase
import kotlin.math.abs
import kotlin.math.roundToLong

/** Commercial system: five permanent slots, category access controlled by Marketing level. */
class TeamSponsorshipEngine(private val seed:Int = 20261006) {
    data class TeamSponsorshipState(val teamId:Int,val season:Int,val sponsors:List<SponsorContract>,val annualGuaranteedIncome:Long)
    data class SponsorshipEvent(val season:Int,val round:Int,val teamId:Int,val slot:Int,val type:String,val sponsorName:String)
    data class SponsorOffer(val sponsor:SponsorContract,val category:SponsorCategory)

    private val states=mutableMapOf<Pair<Int,Int>,TeamSponsorshipState>()
    private val eventLog=mutableListOf<SponsorshipEvent>()
    private val marketingLevels=mutableMapOf<Int,Int>()
    /** Durable idempotency keys: one sponsorship contract advancement per team/season/GP. */
    private val processedRaceKeys=mutableSetOf<String>()

    /**
     * Pure two-season projections are requested repeatedly by the weekly AI finance
     * pipeline. Cache them against the exact live portfolio/ledger fingerprint so a
     * week advance can reuse the same forecast, while a contract, marketing-level or
     * race-ledger change automatically produces a fresh entry.
     */
    private data class ProjectionCacheKey(
        val teamId: Int,
        val season: Int,
        val completedGps: Int,
        val currentMarketingLevel: Int,
        val upgradedMarketingLevel: Int,
        val activationRound: Int,
        val currentPortfolioHash: Int,
        val nextPortfolioHash: Int,
        val processedRaceLedgerHash: Int,
        val liveMarketingLevel: Int,
        val strengthRank: Int
    )
    private val projectionCache = LinkedHashMap<ProjectionCacheKey, SponsorshipCashflowProjection>()
    private val projectionCacheLimit = 256
    private val strengthRanks by lazy(LazyThreadSafetyMode.NONE) {
        WorldDatabase.teams.sortedByDescending {
            val c = InitialTeamProfile.values(it)
            (c.chassis + c.engine + c.frontWing + c.rearWing + c.brakes + c.electricPowerUnit) / 6.0
        }.mapIndexed { index, team -> team.id to (index + 1) }.toMap()
    }

    fun forTeam(teamId:Int,season:Int):TeamSponsorshipState {
        require(WorldDatabase.teams.any { it.id==teamId }) { "Equipe inexistente: $teamId" }
        val key = teamId to season
        val existing = states[key]
        if (existing == null) return createInitial(teamId,season).also { states[key] = it }
        val level = marketingLevels[teamId] ?: WorldDatabase.teams.first { it.id == teamId }.initialLevel
        val normalized = normalizePayments(existing, level)
        if (normalized !== existing) states[key] = normalized
        return normalized
    }

    /** Keeps restored offers and active AI contracts aligned with the real facility level. */
    fun setMarketingLevel(teamId:Int, level:Int) {
        val normalizedLevel = level.coerceIn(0,10)
        marketingLevels[teamId] = normalizedLevel
        states.filterKeys { it.first == teamId }.toList().forEach { (key, state) ->
            val normalized = normalizePayments(state, normalizedLevel)
            if (normalized !== state) states[key] = normalized
        }
    }

    private fun normalizePayments(state: TeamSponsorshipState, level: Int): TeamSponsorshipState {
        val fixed = state.sponsors.map { SponsorContractPricing.ensureEntryAndGp(it, state.teamId, state.season, level) }
        return if (fixed == state.sponsors) state else buildState(state.teamId, state.season, fixed)
    }

    fun allTeams(season:Int)=WorldDatabase.teams.associate { it.id to forTeam(it.id,season) }

    @Synchronized
    fun advanceRace(teamId:Int,season:Int,round:Int):TeamSponsorshipState {
        require(round >= 0) { "Rodada inválida: $round" }
        val state=forTeam(teamId,season)
        val key="$teamId:$season:$round"
        // A repeated callback or a restored snapshot must not consume contract duration twice.
        if (key in processedRaceKeys) return state
        val decremented = state.sponsors.map { sponsor ->
            if (!sponsor.active || sponsor.racesRemaining <= 0) sponsor
            else sponsor.copy(racesRemaining = (sponsor.racesRemaining - 1).coerceAtLeast(0))
        }
        val expiring = state.sponsors.filter { it.active && it.racesRemaining == 1 }.sortedBy { it.slot }
        val working = decremented.toMutableList()
        // Build the exclusion set from remaining active contracts. If several slots expire
        // on the same GP, each signed replacement is added before choosing the next one,
        // so the AI cannot accidentally sign the same brand twice in a single transaction.
        val reservedNames = working.filter { it.active && it.racesRemaining > 0 }
            .mapTo(mutableSetOf()) { it.name }
        expiring.forEach { old ->
            eventLog += SponsorshipEvent(season,round,teamId,old.slot,"ENCERRADO",old.name)
            val replacement = createReplacement(teamId,season,round,old.slot,reservedNames)
            val index = working.indexOfFirst { it.slot == old.slot }
            if (index >= 0) working[index] = replacement
            reservedNames += replacement.name
            eventLog += SponsorshipEvent(season,round,teamId,old.slot,"NOVO_CONTRATO",replacement.name)
        }
        return buildState(teamId,season,working).also { states[teamId to season]=it; processedRaceKeys += key }
    }
    @Synchronized fun advanceAllTeams(season:Int,round:Int,playerTeamId:Int?=null)=WorldDatabase.teams.filter { it.id!=playerTeamId }.forEach { advanceRace(it.id,season,round) }
    fun events()=eventLog.toList()
    fun activeContractCount(season:Int)=allTeams(season).values.sumOf { it.sponsors.count { s->s.active && s.racesRemaining>0 } }
    fun replacementCount(season:Int)=eventLog.count { it.season==season && it.type=="NOVO_CONTRATO" }

    data class SponsorshipCashflowProjection(
        val currentSeasonIncome: Long,
        val nextSeasonIncome: Long
    ) {
        val twoSeasonIncome: Long get() = currentSeasonIncome + nextSeasonIncome
    }

    /**
     * Replays the team's own contract-renewal rules in an isolated engine to estimate
     * cash receipts through the rest of this season and all of the next one. Existing
     * contracts remain unchanged; new offers use the supplied marketing-level plan.
     * The live engine, event log and save snapshot are never mutated.
     */
    @Synchronized
    fun projectCashflowForMarketingPlan(
        teamId: Int,
        season: Int,
        completedGps: Int,
        currentMarketingLevel: Int,
        upgradedMarketingLevel: Int = currentMarketingLevel,
        activationRound: Int = 31
    ): SponsorshipCashflowProjection {
        val currentKey = teamId to season
        val nextKey = teamId to (season + 1)
        val relevantRaceLedger = processedRaceKeys.filter {
            it.startsWith("$teamId:$season:") || it.startsWith("$teamId:${season + 1}:")
        }
        val cacheKey = ProjectionCacheKey(
            teamId = teamId,
            season = season,
            completedGps = completedGps.coerceIn(0, 30),
            currentMarketingLevel = currentMarketingLevel.coerceIn(0, 10),
            upgradedMarketingLevel = upgradedMarketingLevel.coerceIn(0, 10),
            activationRound = activationRound,
            currentPortfolioHash = states[currentKey]?.hashCode() ?: 0,
            nextPortfolioHash = states[nextKey]?.hashCode() ?: 0,
            processedRaceLedgerHash = relevantRaceLedger.sorted().hashCode(),
            liveMarketingLevel = marketingLevels[teamId] ?: -1,
            strengthRank = teamStrengthRank(teamId)
        )
        projectionCache[cacheKey]?.let { return it }
        val hadCurrentState = states.containsKey(currentKey)
        val hadNextState = states.containsKey(nextKey)
        val projection = TeamSponsorshipEngine(seed)
        states[currentKey]?.let { projection.states[currentKey] = it }
        states[nextKey]?.let { projection.states[nextKey] = it }
        processedRaceKeys.filterTo(projection.processedRaceKeys) {
            it.startsWith("$teamId:$season:") || it.startsWith("$teamId:${season + 1}:")
        }
        projection.marketingLevels[teamId] = currentMarketingLevel.coerceIn(0, 10)

        val rank = teamStrengthRank(teamId)
        fun expectedRaceReceipts(state: TeamSponsorshipState): Long = state.sponsors
            .filter { it.active && it.racesRemaining > 0 }
            .sumOf { sponsor ->
                sponsor.racePayment.coerceAtLeast(0L) +
                    (expectedSponsorBonusPerGp(sponsor, rank) * SPONSOR_BONUS_RISK_DISCOUNT).roundToLong().coerceAtLeast(0L)
            }

        fun runSeason(targetSeason: Int, firstRound: Int, lastRound: Int, levelForRound: (Int) -> Int): Long {
            var receipts = 0L
            for (round in firstRound..lastRound) {
                val desiredLevel = levelForRound(round).coerceIn(0, 10)
                if (projection.marketingLevels[teamId] != desiredLevel) {
                    projection.setMarketingLevel(teamId, desiredLevel)
                }
                val before = projection.forTeam(teamId, targetSeason)
                receipts += expectedRaceReceipts(before)
                val eventStart = projection.eventLog.size
                projection.advanceRace(teamId, targetSeason, round)
                val replacements = projection.eventLog.drop(eventStart)
                    .filter { it.teamId == teamId && it.season == targetSeason && it.round == round && it.type == "NOVO_CONTRATO" }
                if (replacements.isNotEmpty()) {
                    val afterBySlot = projection.forTeam(teamId, targetSeason).sponsors.associateBy { it.slot }
                    receipts += replacements.sumOf { event -> afterBySlot[event.slot]?.upfront?.coerceAtLeast(0L) ?: 0L }
                }
            }
            return receipts
        }

        var currentIncome = 0L
        if (!hadCurrentState) {
            val initial = projection.forTeam(teamId, season)
            currentIncome += initial.sponsors.filter { it.active }.sumOf { it.upfront.coerceAtLeast(0L) }
        }
        val firstCurrentRound = (completedGps + 1).coerceIn(1, 31)
        if (firstCurrentRound <= 30) {
            currentIncome += runSeason(season, firstCurrentRound, 30) { round ->
                if (round >= activationRound) upgradedMarketingLevel else currentMarketingLevel
            }
        }

        if (projection.marketingLevels[teamId] != upgradedMarketingLevel.coerceIn(0, 10)) {
            projection.setMarketingLevel(teamId, upgradedMarketingLevel)
        }
        var nextIncome = 0L
        val nextOpening = projection.forTeam(teamId, season + 1)
        if (!hadNextState) {
            nextIncome += nextOpening.sponsors.filter { it.active }.sumOf { it.upfront.coerceAtLeast(0L) }
        }
        nextIncome += runSeason(season + 1, 1, 30) { upgradedMarketingLevel }
        return SponsorshipCashflowProjection(currentIncome, nextIncome).also { result ->
            projectionCache[cacheKey] = result
            while (projectionCache.size > projectionCacheLimit) {
                val oldest = projectionCache.entries.iterator()
                if (oldest.hasNext()) {
                    oldest.next()
                    oldest.remove()
                } else break
            }
        }
    }

    /** Three offers for a slot. Category is selected from the team's Marketing level.
     * The player UI may pass the real active portfolio so duplicate brands are excluded
     * against the player's contracts, rather than against synthetic market state.
     */
    fun offersForSlot(
        teamId:Int, season:Int, slot:Int, marketingLevel:Int, round:Int=0,
        activeSponsorNames:Set<String>?=null
    ):List<SponsorOffer> = generateOffersForSlot(
        teamId, season, slot, marketingLevel, round, excludedNamesOverride=activeSponsorNames
    )

    private fun generateOffersForSlot(
        teamId:Int, season:Int, slot:Int, marketingLevel:Int, round:Int,
        excludedNamesOverride:Set<String>?
    ):List<SponsorOffer> {
        // Keep the live commercial-center level synchronized before a real offer is
        // created. Financial projections use generateOffersAtLevel directly and do
        // not mutate the running career while comparing alternative investments.
        setMarketingLevel(teamId, marketingLevel)
        val active = excludedNamesOverride ?: forTeam(teamId,season).sponsors
            .filter { it.active && it.racesRemaining > 0 && it.slot != slot }
            .map { it.name }.toSet()
        return generateOffersAtLevel(teamId, season, slot, marketingLevel, round, active)
    }

    private fun generateOffersAtLevel(
        teamId:Int, season:Int, slot:Int, marketingLevel:Int, round:Int,
        excludedNames:Set<String>
    ):List<SponsorOffer> {
        require(slot in 1..5)
        val master=slot==1
        // A sponsorship opportunity is one live draw: first draw ONE category,
        // then draw 3 different sponsors from that same category. The player sees
        // these same three generated offers; the AI evaluates and signs one of them.
        val category=drawCategory(marketingLevel,teamId,season,slot,round,0)
        val pool=SponsorCatalog.pool(category,master).filterNot { it.name in excludedNames }
        require(pool.size >= 3) { "Pool de patrocinadores insuficiente para ${category.name}" }
        val drawSeed=abs(seed.toLong()+teamId*97L+season*31L+round*17L+slot*13L)
        val offers=pool.shuffled(kotlin.random.Random(drawSeed)).take(3)
        return offers.mapIndexed { index, profile ->
            SponsorOffer(buildContract(profile,teamId,season,round,slot,index,marketingLevel),category)
        }
    }

    fun availableCategories(level:Int):List<SponsorCategory> = when(level.coerceIn(0,10)) {
        0,1 -> listOf(SponsorCategory.BASICO)
        2,3 -> listOf(SponsorCategory.BASICO,SponsorCategory.REGIONAL)
        4,5 -> listOf(SponsorCategory.REGIONAL,SponsorCategory.NACIONAL)
        6,7 -> listOf(SponsorCategory.NACIONAL,SponsorCategory.INTERNACIONAL)
        8 -> listOf(SponsorCategory.INTERNACIONAL,SponsorCategory.PREMIUM)
        9 -> listOf(SponsorCategory.INTERNACIONAL,SponsorCategory.PREMIUM,SponsorCategory.GLOBAL)
        else -> listOf(SponsorCategory.PREMIUM,SponsorCategory.GLOBAL)
    }

    private fun drawCategory(level:Int,teamId:Int,season:Int,slot:Int,round:Int,index:Int):SponsorCategory {
        val n=abs(seed+teamId*97+season*31+round*17+slot*13+index*53)%100
        return when(level.coerceIn(0,10)) {
            0,1 -> SponsorCategory.BASICO
            2 -> if(n<70) SponsorCategory.BASICO else SponsorCategory.REGIONAL
            3 -> if(n<50) SponsorCategory.BASICO else SponsorCategory.REGIONAL
            4 -> if(n<65) SponsorCategory.REGIONAL else SponsorCategory.NACIONAL
            5 -> if(n<40) SponsorCategory.REGIONAL else SponsorCategory.NACIONAL
            6 -> if(n<60) SponsorCategory.NACIONAL else SponsorCategory.INTERNACIONAL
            7 -> if(n<35) SponsorCategory.NACIONAL else SponsorCategory.INTERNACIONAL
            8 -> if(n<55) SponsorCategory.INTERNACIONAL else SponsorCategory.PREMIUM
            9 -> when { n<25 -> SponsorCategory.INTERNACIONAL; n<85 -> SponsorCategory.PREMIUM; else -> SponsorCategory.GLOBAL }
            else -> if(n<40) SponsorCategory.PREMIUM else SponsorCategory.GLOBAL
        }
    }

    private fun createInitial(teamId:Int,season:Int):TeamSponsorshipState {
        // Like the player, each AI team evaluates the same three offers for every empty
        // slot. The only difference is that the AI accepts its highest-value offer
        // automatically and reserves that brand before opening the next slot.
        val signed = mutableListOf<SponsorContract>()
        val reservedNames = mutableSetOf<String>()
        for (slot in 1..5) {
            val chosen = chooseAiReplacement(teamId, season, 0, slot, reservedNames)
            signed += chosen
            reservedNames += chosen.name
        }
        return buildState(teamId, season, signed)
    }

    private fun createReplacement(teamId:Int,season:Int,round:Int,slot:Int,reservedNames:Set<String>):SponsorContract =
        chooseAiReplacement(teamId,season,round,slot,reservedNames)

    /** AI evaluates exactly the same three generated sponsorship offers shown to the player. */
    private fun chooseAiReplacement(
        teamId:Int, season:Int, round:Int, slot:Int, reservedNames:Set<String>
    ):SponsorContract {
        val marketingLevel = marketingLevels[teamId] ?: WorldDatabase.teams.first { it.id == teamId }.initialLevel
        val offers = generateOffersForSlot(
            teamId, season, slot, marketingLevel, round, excludedNamesOverride=reservedNames
        )
        return selectBestAiSponsorOffer(offers, teamStrengthRank(teamId)).sponsor
    }

    private data class AiSponsorMetrics(
        val guaranteedTotal: Double,
        val guaranteedPerGp: Double,
        val expectedBonusTotal: Double,
        val riskAdjustedBonusPerGp: Double,
        val flexibility: Double
    )

    /**
     * Selects the best economic offer, not the largest headline contract. Guaranteed
     * cash per GP leads the decision; uncertain performance bonuses are probability-
     * adjusted and then discounted, while shorter terms retain renegotiation value.
     */
    internal fun selectBestAiSponsorOffer(offers: List<SponsorOffer>, teamRank: Int): SponsorOffer {
        require(offers.isNotEmpty()) { "A IA precisa de ao menos uma proposta de patrocínio" }
        if (offers.size == 1) return offers.single()

        val metrics = offers.associateWith { aiSponsorMetrics(it.sponsor, teamRank) }
        fun normalized(value: Double, selector: (AiSponsorMetrics) -> Double): Double {
            val values = metrics.values.map(selector)
            val min = values.minOrNull() ?: return 0.5
            val max = values.maxOrNull() ?: return 0.5
            return if (max - min <= 1e-9) 0.5 else ((value - min) / (max - min)).coerceIn(0.0, 1.0)
        }
        fun score(offer: SponsorOffer): Double {
            val m = metrics.getValue(offer)
            return normalized(m.guaranteedPerGp) { it.guaranteedPerGp } * 0.55 +
                normalized(m.guaranteedTotal) { it.guaranteedTotal } * 0.20 +
                normalized(m.riskAdjustedBonusPerGp) { it.riskAdjustedBonusPerGp } * 0.10 +
                normalized(m.flexibility) { it.flexibility } * 0.15
        }
        return offers.maxWithOrNull(
            compareBy<SponsorOffer> { score(it) }
                .thenBy { metrics.getValue(it).guaranteedPerGp }
                .thenBy { metrics.getValue(it).riskAdjustedBonusPerGp }
                .thenBy { metrics.getValue(it).guaranteedTotal }
                // A shorter contract wins an otherwise exact tie, preserving a
                // renegotiation window without sacrificing meaningful guaranteed value.
                .thenByDescending { metrics.getValue(it).flexibility }
                .thenBy { it.sponsor.name }
        ) ?: offers.first()
    }

    private fun aiSponsorMetrics(sponsor: SponsorContract, teamRank: Int): AiSponsorMetrics {
        val duration = sponsor.races.coerceIn(MIN_CONTRACT_RACES, MAX_CONTRACT_RACES).toDouble()
        val guaranteedTotal = sponsor.upfront.coerceAtLeast(0L).toDouble() +
            sponsor.racePayment.coerceAtLeast(0L).toDouble() * duration
        val expectedBonusPerGp = expectedSponsorBonusPerGp(sponsor, teamRank)
        val riskAdjustedBonusPerGp = expectedBonusPerGp * SPONSOR_BONUS_RISK_DISCOUNT
        return AiSponsorMetrics(
            guaranteedTotal = guaranteedTotal,
            guaranteedPerGp = guaranteedTotal / duration,
            expectedBonusTotal = expectedBonusPerGp * duration,
            riskAdjustedBonusPerGp = riskAdjustedBonusPerGp,
            flexibility = (MAX_CONTRACT_RACES - duration) /
                (MAX_CONTRACT_RACES - MIN_CONTRACT_RACES).toDouble()
        )
    }

    /**
     * Estimates on-track bonuses instead of treating every target as a 20% chance.
     * The generated objectives are centered on the team's expected best-driver grid
     * position. A normal density estimates the qualifying window; a logistic CDF
     * approximates the chance of finishing at or ahead of the race target.
     */
    internal fun expectedSponsorBonusPerGp(sponsor: SponsorContract, teamRank: Int): Double {
        val expectedPosition = (teamRank.coerceIn(1, 40) * 2 - 1).toDouble()
        val sigma = 7.0
        val low = (if (sponsor.qualifyingTargetMin > 0) sponsor.qualifyingTargetMin else 1).coerceIn(1, 80)
        val high = (if (sponsor.qualifyingTargetMax > 0) sponsor.qualifyingTargetMax else sponsor.qualifyingTarget)
            .coerceIn(low, 80)
        val qualifyingProbability = if (sponsor.qualifyingTarget <= 0 || sponsor.qualifyingBonus <= 0L) 0.0 else {
            val center = (low + high) / 2.0
            val width = high - low + 1.0
            val z = (center - expectedPosition) / sigma
            (width / (sigma * kotlin.math.sqrt(2.0 * Math.PI)) * kotlin.math.exp(-0.5 * z * z))
                .coerceIn(0.0, 0.95)
        }
        val raceProbability = if (sponsor.raceTarget <= 0 || sponsor.raceTargetBonus <= 0L) 0.0 else {
            val z = (sponsor.raceTarget - expectedPosition) / sigma
            (1.0 / (1.0 + kotlin.math.exp(-1.702 * z))).coerceIn(0.01, 0.99)
        }
        return sponsor.qualifyingBonus.coerceAtLeast(0L) * qualifyingProbability +
            sponsor.raceTargetBonus.coerceAtLeast(0L) * raceProbability
    }

    private fun teamStrengthRank(teamId: Int): Int = strengthRanks[teamId] ?: 40

    private companion object {
        const val MIN_CONTRACT_RACES = 3
        const val MAX_CONTRACT_RACES = 10
        const val SPONSOR_BONUS_RISK_DISCOUNT = 0.55
    }

    /**
     * Converts the opening-season strength rank into a realistic performance window.
     * The same opening car ranking is the single sporting source of truth.
     */
    private fun targetRange(teamRank:Int): Pair<Int,Int> {
        // There are 40 teams but 80 active race seats. The sporting target
        // therefore follows the team's best expected driver slot (1,3,5...79),
        // not the team rank itself. A two-position margin is applied on both
        // sides and clipped to the real P1..P80 grid.
        val r = teamRank.coerceIn(1,40)
        val expectedBestDriverPosition = (r * 2 - 1).coerceIn(1,80)
        val min = (expectedBestDriverPosition - 2).coerceAtLeast(1)
        val max = (expectedBestDriverPosition + 2).coerceAtMost(80)
        return min to max
    }

    private fun buildContract(
        profile:SponsorProfile, teamId:Int, season:Int, round:Int, slot:Int, index:Int,
        marketingLevelOverride: Int? = null
    ):SponsorContract {
        val team=WorldDatabase.teams.first { it.id==teamId }
        val strength=InitialTeamProfile.strength(team)
        // Rank from the actual randomized opening car, not only Forte/Médio/Fraco.
        val rank=teamStrengthRank(teamId)
        val (targetMin,targetMax)=targetRange(rank)
        val cycle=abs(seed+teamId*97+season*31+round*17+slot*13+index*53)
        fun range(min:Double,max:Double)= (min+(max-min)*(cycle%100)/99.0)
        val master=slot==1

        // Commercial value is driven by the sponsor category. The category is
        // not cosmetic: higher categories must produce materially stronger
        // contracts while retaining variation between sponsors.
        data class CategoryBand(val entryMin:Double,val entryMax:Double,val gpMin:Double,val gpMax:Double,val qualMin:Double,val qualMax:Double,val raceMin:Double,val raceMax:Double,val pointMin:Double,val pointMax:Double)
        val band=when(profile.category) {
            SponsorCategory.BASICO -> CategoryBand(1.0,2.0,0.15,0.30,0.10,0.20,0.15,0.30,0.010,0.020)
            SponsorCategory.REGIONAL -> CategoryBand(2.0,3.5,0.25,0.45,0.15,0.30,0.25,0.45,0.015,0.025)
            SponsorCategory.NACIONAL -> CategoryBand(3.0,5.0,0.35,0.60,0.20,0.40,0.35,0.60,0.020,0.035)
            SponsorCategory.INTERNACIONAL -> CategoryBand(4.5,7.0,0.50,0.80,0.30,0.55,0.50,0.85,0.025,0.045)
            SponsorCategory.PREMIUM -> CategoryBand(6.0,9.0,0.65,1.00,0.40,0.70,0.70,1.10,0.035,0.055)
            SponsorCategory.GLOBAL -> CategoryBand(8.0,12.0,0.85,1.30,0.50,0.90,0.90,1.40,0.045,0.070)
        }
        // Master sponsors sit above secondary sponsors within the same
        // category, preserving a clear hierarchy without changing the
        // category progression itself.
        // V619: every signed offer has both an entry payment and a guaranteed GP payment.
        // The catalog's legacy payment-model field remains only for source/save compatibility.
        val e = if(master) range(band.entryMin*1.7,band.entryMax*2.2) else range(band.entryMin,band.entryMax)
        val gp = if(master) range(band.gpMin*1.8,band.gpMax*2.0) else range(band.gpMin,band.gpMax)
        val qb=if(master) range(band.qualMin*1.8,band.qualMax*2.0) else range(band.qualMin,band.qualMax)
        val rb=if(master) range(band.raceMin*1.8,band.raceMax*2.0) else range(band.raceMin,band.raceMax)
        val pp=if(master) range(band.pointMin*1.8,band.pointMax*2.0) else range(band.pointMin,band.pointMax)
        val duration=3+(cycle%8)
        // Each Commercial Center level raises the value of newly negotiated
        // sponsorship terms; upgrading can never reduce the team's offer value.
        val commercialMultiplier = SponsorContractPricing.commercialMultiplier(
            marketingLevelOverride ?: marketingLevels[teamId] ?: team.initialLevel
        )
        fun valued(amount: Double) = (amount * 1_000_000.0 * commercialMultiplier).roundToLong()
        return SponsorContract(profile.name,valued(e),valued(gp),valued(pp),1,strength/2,slot,targetMax,valued(qb),targetMax,valued(rb),true,duration,duration,profile.category.name,targetMin,targetMax,targetMin,targetMax)
    }

    /** Stable persistence snapshot for sponsor contracts across Android process restarts. */
    fun exportSnapshot(): String {
        fun b64(v:String)=java.util.Base64.getEncoder().encodeToString(v.toByteArray(Charsets.UTF_8))
        val stateLines = states.values.sortedWith(compareBy<TeamSponsorshipState> { it.teamId }.thenBy { it.season }).map { st ->
            val sponsors=st.sponsors.joinToString("~") { s -> listOf(s.name,s.upfront,s.racePayment,s.pointsBonus,s.years,s.minimumReputation,s.slot,s.qualifyingTarget,s.qualifyingBonus,s.raceTarget,s.raceTargetBonus,s.active,s.races,s.racesRemaining,s.category,s.qualifyingTargetMin,s.qualifyingTargetMax,s.raceTargetMin,s.raceTargetMax).joinToString("^") { b64(it.toString()) } }
            listOf(st.teamId,st.season,st.annualGuaranteedIncome,b64(sponsors)).joinToString("|")
        }
        val meta = "@V356|" + b64(processedRaceKeys.sorted().joinToString("\n"))
        return (listOf(meta) + stateLines).joinToString("\n")
    }

    @Synchronized fun restoreSnapshot(raw:String) {
        states.clear(); eventLog.clear(); processedRaceKeys.clear(); projectionCache.clear()
        fun dec(v:String)=runCatching { String(java.util.Base64.getDecoder().decode(v),Charsets.UTF_8) }.getOrDefault("")
        raw.lineSequence().filter { it.isNotBlank() }.forEach { line ->
            if (line.startsWith("@V356|")) {
                dec(line.substringAfter("@V356|")).lineSequence().filter { it.isNotBlank() }.forEach { processedRaceKeys += it }
                return@forEach
            }
            val p=line.split("|", limit=4); if(p.size!=4) return@forEach
            val team=p[0].toIntOrNull()?:return@forEach; val season=p[1].toIntOrNull()?:return@forEach; val income=p[2].toLongOrNull()?:0L
            val sponsors=dec(p[3]).split("~").filter { it.isNotBlank() }.mapNotNull { row ->
                val v=row.split("^").map(::dec); if(v.size!=19 && v.size!=15) return@mapNotNull null
                runCatching {
                    if(v.size==19) SponsorContract(v[0],v[1].toLong(),v[2].toLong(),v[3].toLong(),v[4].toInt(),v[5].toInt(),v[6].toInt(),v[7].toInt(),v[8].toLong(),v[9].toInt(),v[10].toLong(),v[11].toBoolean(),v[12].toInt(),v[13].toInt(),v[14],v[15].toInt(),v[16].toInt(),v[17].toInt(),v[18].toInt())
                    else { val q=v[7].toInt(); val r=v[9].toInt(); SponsorContract(v[0],v[1].toLong(),v[2].toLong(),v[3].toLong(),v[4].toInt(),v[5].toInt(),v[6].toInt(),q,v[8].toLong(),r,v[10].toLong(),v[11].toBoolean(),v[12].toInt(),v[13].toInt(),v[14],q,q,r,r) }
                }.getOrNull()
            }
            states[team to season]=TeamSponsorshipState(team,season,sponsors,income)
        }
    }

    private fun buildState(teamId:Int,season:Int,sponsors:List<SponsorContract>)=TeamSponsorshipState(teamId,season,sponsors,sponsors.sumOf { it.upfront }+sponsors.sumOf { it.racePayment }*30L)
}
