package com.f1teammanager.core.season

import java.util.Calendar
import kotlin.random.Random

/** Permanent 50-GP database. Each season selects 30 unique venues from this pool. */
object SeasonCalendar {
    data class GpTemplate(
        val grandPrix: String,
        val circuit: String,
        val country: String,
        val distanceKm: Double,
        val laps: Int,
        /** Competitive reference lap, never the official fastest-lap record. */
        val averageLapTimeMs: Long,
        val assetSearchName: String
    )

    private val raceWeeks = listOf(8,10,11,13,15,16,18,20,21,23,25,26,28,30,31,33,34,36,38,39,41,43,44,46,48,49,51,53,54,56)

    val allGps: List<GpTemplate> = listOf(
        GpTemplate("GP da Austrália", "Albert Park", "Austrália", 5.278, 58, 87_500, "Albert Park Circuit F1"),
        GpTemplate("GP da China", "Shanghai", "China", 5.451, 56, 99_000, "Shanghai International Circuit F1"),
        GpTemplate("GP do Japão", "Suzuka", "Japão", 5.807, 53, 95_500, "Suzuka Circuit F1"),
        GpTemplate("GP do Bahrein", "Sakhir", "Bahrein", 5.412, 57, 100_500, "Bahrain International Circuit F1"),
        GpTemplate("GP da Arábia Saudita", "Jeddah", "Arábia Saudita", 6.174, 50, 95_500, "Jeddah Corniche Circuit F1"),
        GpTemplate("GP de Miami", "Miami International", "EUA", 5.412, 57, 95_000, "Miami International Autodrome F1"),
        GpTemplate("GP do Canadá", "Gilles-Villeneuve", "Canadá", 4.361, 70, 78_000, "Circuit Gilles Villeneuve F1"),
        GpTemplate("GP de Mônaco", "Monte Carlo", "Mônaco", 3.337, 78, 77_500, "Circuit de Monaco F1"),
        GpTemplate("GP da Espanha", "Barcelona-Catalunya", "Espanha", 4.657, 66, 84_000, "Barcelona Catalunya F1"),
        GpTemplate("GP da Áustria", "Red Bull Ring", "Áustria", 4.326, 71, 71_500, "Red Bull Ring F1"),
        GpTemplate("GP da Grã-Bretanha", "Silverstone", "Grã-Bretanha", 5.891, 52, 94_500, "Silverstone Circuit F1"),
        GpTemplate("GP da Bélgica", "Spa-Francorchamps", "Bélgica", 7.004, 44, 111_500, "Spa Francorchamps F1"),
        GpTemplate("GP da Hungria", "Hungaroring", "Hungria", 4.381, 70, 84_000, "Hungaroring F1"),
        GpTemplate("GP dos Países Baixos", "Zandvoort", "Países Baixos", 4.259, 72, 76_000, "Zandvoort Circuit F1"),
        GpTemplate("GP da Itália", "Monza", "Itália", 5.793, 53, 85_500, "Monza Circuit F1"),
        GpTemplate("GP de Madri", "Madring", "Espanha", 5.416, 57, 95_500, "Madrid Madring F1 Circuit"),
        GpTemplate("GP do Azerbaijão", "Baku", "Azerbaijão", 6.003, 51, 107_500, "Baku City Circuit F1"),
        GpTemplate("GP de Singapura", "Marina Bay", "Singapura", 4.940, 62, 99_500, "Marina Bay Street Circuit F1"),
        GpTemplate("GP dos EUA", "COTA", "EUA", 5.513, 56, 99_500, "Circuit of the Americas F1"),
        GpTemplate("GP do México", "Hermanos Rodríguez", "México", 4.304, 71, 82_500, "Autodromo Hermanos Rodriguez F1"),
        GpTemplate("GP de São Paulo", "Interlagos", "Brasil", 4.309, 71, 75_500, "Interlagos Circuit F1"),
        GpTemplate("GP de Las Vegas", "Las Vegas Strip", "EUA", 6.201, 50, 99_000, "Las Vegas Strip Circuit F1"),
        GpTemplate("GP do Catar", "Lusail", "Catar", 5.419, 57, 87_500, "Lusail International Circuit F1"),
        GpTemplate("GP de Abu Dhabi", "Yas Marina", "Emirados Árabes", 5.281, 58, 89_500, "Yas Marina Circuit F1"),
        GpTemplate("GP da Emília-Romanha", "Imola", "Itália", 4.909, 63, 81_500, "Imola Circuit F1"),
        GpTemplate("GP de Portugal", "Portimão", "Portugal", 4.653, 66, 105_500, "Portimao Algarve Circuit F1"),
        GpTemplate("GP da Turquia", "Istanbul Park", "Turquia", 5.338, 58, 90_000, "Istanbul Park F1 Circuit"),
        GpTemplate("GP da Malásia", "Sepang", "Malásia", 5.543, 56, 100_500, "Sepang International Circuit F1"),
        GpTemplate("GP da Alemanha", "Hockenheimring", "Alemanha", 4.574, 67, 79_500, "Hockenheimring F1 Circuit"),
        GpTemplate("GP da Alemanha", "Nürburgring GP", "Alemanha", 5.148, 60, 95_000, "Nurburgring GP Circuit F1"),
        GpTemplate("GP da França", "Paul Ricard", "França", 5.842, 53, 96_500, "Paul Ricard Circuit F1"),
        GpTemplate("GP da França", "Magny-Cours", "França", 4.411, 70, 78_500, "Magny Cours Circuit F1"),
        GpTemplate("GP da Itália", "Mugello", "Itália", 5.245, 59, 83_500, "Mugello Circuit F1"),
        GpTemplate("GP dos EUA", "Indianapolis GP", "EUA", 4.192, 73, 73_500, "Indianapolis Motor Speedway Road Course"),
        GpTemplate("GP de Portugal", "Estoril", "Portugal", 4.360, 70, 80_500, "Estoril Circuit F1"),
        GpTemplate("GP da Coreia do Sul", "Korea International", "Coreia do Sul", 5.615, 55, 104_000, "Korea International Circuit F1"),
        GpTemplate("GP da Índia", "Buddh", "Índia", 5.125, 60, 95_500, "Buddh International Circuit F1"),
        GpTemplate("GP da Rússia", "Sochi", "Rússia", 5.848, 53, 100_500, "Sochi Autodrom F1"),
        GpTemplate("GP da Espanha", "MotorLand Aragón", "Espanha", 5.344, 56, 112_000, "MotorLand Aragon Circuit"),
        GpTemplate("GP do Japão", "Fuji Speedway", "Japão", 4.563, 66, 92_500, "Fuji Speedway F1"),
        GpTemplate("GP dos Países Baixos", "Assen", "Países Baixos", 4.555, 66, 95_000, "TT Circuit Assen"),
        GpTemplate("GP da África do Sul", "Kyalami", "África do Sul", 4.522, 67, 104_000, "Kyalami Grand Prix Circuit"),
        GpTemplate("GP da Argentina", "Buenos Aires", "Argentina", 4.259, 72, 95_500, "Buenos Aires Autodromo F1"),
        GpTemplate("GP do Brasil", "Jacarepaguá", "Brasil", 5.031, 61, 104_000, "Jacarepagua Circuit Rio"),
        GpTemplate("GP da Espanha", "Jerez", "Espanha", 4.428, 69, 91_000, "Jerez Circuit F1"),
        GpTemplate("GP dos Emirados Árabes", "Dubai Autodrome", "Emirados Árabes", 5.390, 56, 108_000, "Dubai Autodrome Circuit"),
        GpTemplate("GP dos EUA", "Long Beach", "EUA", 3.167, 95, 81_000, "Long Beach Grand Prix Circuit"),
        GpTemplate("GP dos EUA", "Watkins Glen", "EUA", 5.472, 55, 73_500, "Watkins Glen International"),
        GpTemplate("GP da Suécia", "Anderstorp", "Suécia", 4.018, 70, 87_500, "Anderstorp Raceway"),
        GpTemplate("GP da Itália", "Vallelunga", "Itália", 4.085, 74, 88_500, "Vallelunga Circuit")
    )

    init { require(allGps.size == 50) { "Banco permanente de GPs deve conter exatamente 50 circuitos" } }

    fun forSeason(season: Int): List<RoundDefinition> {
        val selected = allGps.shuffled(Random(0xF1_5000 + season)).take(30)
        return selected.mapIndexed { index, gp ->
            val week = raceWeeks[index]
            val date = raceDateLabel(season, week)
            val crash = (0.82 + ((gp.distanceKm * 10).toInt() % 6) * 0.07).coerceIn(0.82, 1.17)
            val reliability = (0.88 + (gp.laps % 5) * 0.06).coerceIn(0.88, 1.12)
            val safety = (0.72 + ((gp.circuit.length + gp.grandPrix.length) % 7) * 0.08).coerceIn(0.72, 1.20)
            RoundDefinition(
                round=index + 1,
                grandPrix=gp.grandPrix,
                circuit=gp.circuit,
                laps=gp.laps,
                baseLapTimeMs=gp.averageLapTimeMs,
                crashRisk=crash,
                reliabilityRisk=reliability,
                safetyCarRisk=safety,
                month=monthFor(date),
                weekOfSeason=week,
                dateLabel=date,
                distanceKm=gp.distanceKm,
                assetSearchName=gp.assetSearchName
            )
        }
    }

    private fun raceDateLabel(season: Int, week: Int): String {
        val c = Calendar.getInstance().apply { set(season, Calendar.JANUARY, 1, 12, 0, 0); add(Calendar.WEEK_OF_YEAR, week - 1); add(Calendar.DAY_OF_YEAR, 4) }
        return "%02d/%02d/%04d".format(c.get(Calendar.DAY_OF_MONTH), c.get(Calendar.MONTH) + 1, season)
    }
    private fun monthFor(date: String): String = listOf("Janeiro","Fevereiro","Março","Abril","Maio","Junho","Julho","Agosto","Setembro","Outubro","Novembro","Dezembro")[date.substring(3,5).toInt() - 1]
}
