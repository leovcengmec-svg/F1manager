package com.f1teammanager.core.race

import kotlin.random.Random

class IncidentEngine(private val random: Random) {
    data class Decision(val type: EventType?, val detail: String = "")

    fun driverIncident(p: RaceParticipant, circuit: RaceCircuit, lap: Int, totalLaps: Int, wear: Int): Decision {
        val consistencyRisk = ((100 - p.consistency).coerceAtLeast(0) / 100.0)
        val racecraftRisk = ((100 - p.racecraft).coerceAtLeast(0) / 100.0)
        val wearRisk = (wear.coerceIn(0, 100) / 100.0)
        val phase = if (lap <= 2 || lap >= totalLaps - 2) 1.18 else 1.0
        val crash = 0.00030 * circuit.crashRisk * (0.65 + consistencyRisk * 1.35 + racecraftRisk * 0.65) * phase * (1.0 + wearRisk * 0.65)
        val mechanical = 0.00045 * circuit.reliabilityRisk * (1.0 + (100 - p.reliability).coerceAtLeast(0) / 80.0) * (1.0 + wearRisk * 1.8)
        val roll = random.nextDouble()
        return when {
            roll < crash -> Decision(EventType.CRASH, "Acidente na volta $lap")
            roll < crash + mechanical -> Decision(EventType.MECHANICAL_FAILURE, "Falha mecânica na volta $lap")
            else -> Decision(null)
        }
    }

    fun neutralisation(circuit: RaceCircuit): Neutralisation {
        val roll = random.nextDouble()
        return when {
            roll < 0.0009 * circuit.safetyCarRisk -> Neutralisation.SAFETY_CAR
            roll < 0.0022 * circuit.safetyCarRisk -> Neutralisation.VSC
            else -> Neutralisation.GREEN
        }
    }
}
