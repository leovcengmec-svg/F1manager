package com.f1teammanager.core.manager

enum class FacilityType {
    FACTORY, RESEARCH, WIND_TUNNEL, SIMULATOR, SCOUTING, DRIVER_DEVELOPMENT, MARKETING
}

data class TeamFacilitiesState(
    val levels: Map<FacilityType, Int> = FacilityType.values().associateWith { 0 }
) {
    fun level(type: FacilityType): Int = (levels[type] ?: 0).coerceIn(0, 10)
    fun withLevel(type: FacilityType, value: Int): TeamFacilitiesState = copy(levels = levels + (type to value.coerceIn(0, 10)))
}

object FacilityEngine {
    private val upgradeCosts = longArrayOf(10_000_000L, 15_000_000L, 22_000_000L, 30_000_000L, 40_000_000L, 52_000_000L, 66_000_000L, 82_000_000L, 100_000_000L, 120_000_000L)

    fun initial(level: Int): TeamFacilitiesState =
        TeamFacilitiesState(FacilityType.values().associateWith { level.coerceIn(0, 2) })

    fun upgradeCost(currentLevel: Int): Long? = upgradeCosts.getOrNull(currentLevel.coerceIn(0, 10))

    fun upgrade(state: TeamManagerState, type: FacilityType): TeamManagerState {
        val current = state.facilities.level(type)
        require(current < 10) { "Instalação já está no nível máximo." }
        val cost = upgradeCost(current) ?: error("Custo inválido")
        require(state.finance.budget >= cost) { "Orçamento insuficiente." }
        val technical = TechnicalInvestmentEngine.ensureSeason(state.technicalInvestment, state.season, TechnicalInvestmentEngine.seasonRanking(state.playerTeamId, state.car)[state.playerTeamId] ?: 40)
        val technicalAfter = technical.withSpend(TechnicalInvestmentCategory.FACILITY_UPGRADE, cost)
        val next = state.facilities.withLevel(type, current + 1)
        return state.copy(
            facilities = next,
            technicalInvestment = technicalAfter,
            finance = state.finance.transact(-cost, "Upgrade ${label(type)} ${current}→${current + 1}")
        )
    }

    fun label(type: FacilityType): String = when (type) {
        FacilityType.FACTORY -> "Fábrica"
        FacilityType.RESEARCH -> "Centro de P&D"
        FacilityType.WIND_TUNNEL -> "Túnel de Vento"
        FacilityType.SIMULATOR -> "Simulador"
        FacilityType.SCOUTING -> "Scouting"
        FacilityType.DRIVER_DEVELOPMENT -> "Desenvolvimento de Pilotos"
        FacilityType.MARKETING -> "Centro Comercial / Marketing"
    }

    fun description(type: FacilityType): String = when (type) {
        FacilityType.FACTORY -> "Capacidade, tempo, custo e produção de peças físicas."
        FacilityType.RESEARCH -> "Pesquisa tecnológica: reduz custo e tempo dos projetos e aumenta a qualidade do desenho. Não altera carros diretamente."
        FacilityType.WIND_TUNNEL -> "Especialização aerodinâmica para chassi e asas."
        FacilityType.SIMULATOR -> "Simulação do carro: reduz tempo de P&D geral e melhora diretamente a performance global na pista, sem bônus específico para asas."
        FacilityType.SCOUTING -> "Precisão das informações obtidas no mercado de pilotos."
        FacilityType.DRIVER_DEVELOPMENT -> "Aumenta a eficiência para o piloto atingir o potencial que já possui."
        FacilityType.MARKETING -> "Quantidade, qualidade e valor das oportunidades de patrocínio."
    }

    // Effects are intentionally small and stack with the level, avoiding direct Overall inflation.
    fun isAerodynamic(component: CarComponent): Boolean =
        component == CarComponent.FRONT_WING || component == CarComponent.REAR_WING || component == CarComponent.CHASSIS

    /** Wind tunnel accelerates only aerodynamic research, up to 50% at level 10. */
    fun researchWeeks(base: Int, state: TeamFacilitiesState, component: CarComponent): Int {
        var multiplier = 1.0 - state.level(FacilityType.RESEARCH) * 0.032
        if (isAerodynamic(component)) multiplier *= 1.0 - state.level(FacilityType.WIND_TUNNEL) * 0.05
        // Simulator reduces research time for every component, up to 30% at level 10.
        multiplier *= 1.0 - state.level(FacilityType.SIMULATOR) * 0.03
        return kotlin.math.ceil(base * multiplier).toInt().coerceAtLeast(1)
    }

    fun researchGain(base: Int, state: TeamFacilitiesState, component: CarComponent): Int {
        var bonus = state.level(FacilityType.RESEARCH) / 3
        if (isAerodynamic(component)) bonus += state.level(FacilityType.WIND_TUNNEL) / 2
        return base + bonus
    }

    /** Direct on-track aerodynamic efficiency bonus. Does not change Overall or piece values. */
    fun windTunnelPerformanceMultiplier(state: TeamFacilitiesState): Double =
        1.0 + state.level(FacilityType.WIND_TUNNEL) * 0.002

    /** Applies the tunnel bonus only to the aerodynamic contribution of a car. */
    fun aerodynamicPerformanceBonus(
        state: TeamFacilitiesState,
        chassis: Int,
        frontWing: Int,
        rearWing: Int,
        chassisWeight: Double,
        frontWingWeight: Double,
        rearWingWeight: Double
    ): Double {
        val aero = chassis * chassisWeight + frontWing * frontWingWeight + rearWing * rearWingWeight
        return aero * (windTunnelPerformanceMultiplier(state) - 1.0)
    }

    fun factoryWeeks(base: Int, state: TeamFacilitiesState): Int = (base - state.level(FacilityType.FACTORY) / 4).coerceAtLeast(1)
    fun factoryCost(base: Long, state: TeamFacilitiesState): Long = (base * (1.0 - state.level(FacilityType.FACTORY) * 0.025)).toLong().coerceAtLeast(1_000_000L)
    fun factoryCapacity(state: TeamFacilitiesState): Int = 1 + state.level(FacilityType.FACTORY) / 3

    fun scoutingPrecision(state: TeamFacilitiesState): Int = (20 + state.level(FacilityType.SCOUTING) * 8).coerceAtMost(100)
    fun driverDevelopmentEfficiency(state: TeamFacilitiesState): Double = 0.80 + state.level(FacilityType.DRIVER_DEVELOPMENT) * 0.03
    /** Direct global on-track simulator bonus: +0.1% per level, max +1.0%. */
    fun simulatorPerformanceMultiplier(state: TeamFacilitiesState): Double =
        1.0 + state.level(FacilityType.SIMULATOR) * 0.001

    /** Legacy efficiency helper retained for compatibility with older callers. */
    fun simulatorEfficiency(state: TeamFacilitiesState): Double = 0.85 + state.level(FacilityType.SIMULATOR) * 0.025
    fun marketingQuality(state: TeamFacilitiesState): Int = (state.level(FacilityType.MARKETING) * 8).coerceAtMost(80)
}
