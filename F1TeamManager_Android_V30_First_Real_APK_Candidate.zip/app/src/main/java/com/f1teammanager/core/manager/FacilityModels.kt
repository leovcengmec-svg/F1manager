package com.f1teammanager.core.manager

enum class FacilityType {
    FACTORY, RESEARCH, WIND_TUNNEL, SIMULATOR, SCOUTING, DRIVER_DEVELOPMENT, MARKETING
}

data class FacilityUpgradeState(
    val facility: FacilityType,
    val previousLevel: Int,
    val targetLevel: Int,
    val remainingWeeks: Int = 12,
    val totalWeeks: Int = 12,
    val cost: Long,
    val startedSeason: Int,
    val startedWeek: Int
) {
    fun advance(weeks: Int): FacilityUpgradeState? {
        val remaining = remainingWeeks - weeks.coerceAtLeast(0)
        return if (remaining <= 0) null else copy(remainingWeeks = remaining)
    }
}

data class TeamFacilitiesState(
    val levels: Map<FacilityType, Int> = FacilityType.values().associateWith { 0 }
) {
    fun level(type: FacilityType): Int = (levels[type] ?: 0).coerceIn(0, 10)
    fun withLevel(type: FacilityType, value: Int): TeamFacilitiesState = copy(levels = levels + (type to value.coerceIn(0, 10)))
}

object FacilityEngine {
    private val upgradeCosts = longArrayOf(10_000_000L, 15_000_000L, 22_000_000L, 30_000_000L, 40_000_000L, 52_000_000L, 66_000_000L, 82_000_000L, 100_000_000L, 120_000_000L)

    fun initial(level: Int): TeamFacilitiesState =
        TeamFacilitiesState(FacilityType.values().associateWith { level.coerceIn(0, 2) })

    fun upgradeCost(currentLevel: Int): Long? = upgradeCosts.getOrNull(currentLevel.coerceIn(0, 10))

    fun upgrade(state: TeamManagerState, type: FacilityType, currentWeek: Int = 1): TeamManagerState {
        require(state.facilityUpgrade == null) { "Já existe uma melhoria de instalação em andamento." }
        val current = state.facilities.level(type)
        require(current < 10) { "Instalação já está no nível máximo." }
        val cost = upgradeCost(current) ?: error("Custo inválido")
        require(state.finance.budget >= cost) { "Orçamento insuficiente." }
        val technical = TechnicalInvestmentEngine.ensureSeason(state.technicalInvestment, state.season, TechnicalInvestmentEngine.seasonRanking(state.playerTeamId, state.car)[state.playerTeamId] ?: 40)
        require(technical.available >= cost) { "Limite de investimento técnico insuficiente." }
        val technicalAfter = technical.withSpend(TechnicalInvestmentCategory.FACILITY_UPGRADE, cost)
        return state.copy(
            technicalInvestment = technicalAfter,
            finance = FinanceEngine().applyCashDebitFinance(state.finance, cost, "Início de melhoria ${label(type)} ${current}→${current + 1} (12 semanas)"),
            facilityUpgrade = FacilityUpgradeState(type, current, current + 1, 12, 12, cost, state.season, currentWeek)
        )
    }

    /** Advances a single active build. Level is applied only once when the 12-week timer expires. */
    fun advanceUpgrade(state: TeamManagerState, weeks: Int): Pair<TeamManagerState, Boolean> {
        val active = state.facilityUpgrade ?: return state to false
        if (weeks <= 0) return state to false
        val remaining = active.remainingWeeks - weeks
        if (remaining > 0) return state.copy(facilityUpgrade = active.copy(remainingWeeks = remaining)) to false
        val completed = state.facilities.withLevel(active.facility, active.targetLevel)
        return state.copy(facilities = completed, facilityUpgrade = null) to true
    }


    /** Weekly team-store sales range by Commercial Center level, including revenue at level 0. */
    fun weeklyMerchandiseRevenueRange(level: Int): LongRange = when (level.coerceIn(0, 10)) {
        0 -> 200_000L..400_000L
        1 -> 350_000L..600_000L
        2 -> 500_000L..800_000L
        3 -> 650_000L..1_000_000L
        4 -> 800_000L..1_200_000L
        5 -> 950_000L..1_500_000L
        6 -> 1_100_000L..1_800_000L
        7 -> 1_300_000L..2_100_000L
        8 -> 1_500_000L..2_400_000L
        9 -> 1_750_000L..2_700_000L
        else -> 2_000_000L..3_000_000L
    }

    /** Deterministic weekly sales value, stable across save/reload and duplicate callbacks. */
    fun weeklyMerchandiseRevenue(teamId: Int, season: Int, week: Int, level: Int): Long {
        val range = weeklyMerchandiseRevenueRange(level)
        val width = (range.last - range.first + 1L).coerceAtLeast(1L)
        val seed = (teamId.toLong() * 73856093L) xor (season.toLong() * 19349663L) xor (week.toLong() * 83492791L)
        val offset = Math.floorMod(seed, width)
        return range.first + offset
    }

    /** Weekly maintenance per facility level, in euros. Level 0 has no cost. */
    fun weeklyMaintenanceCost(level: Int): Long = when (level.coerceIn(0, 10)) {
        0 -> 0L
        1 -> 25_000L
        2 -> 50_000L
        3 -> 80_000L
        4 -> 120_000L
        5 -> 170_000L
        6 -> 230_000L
        7 -> 300_000L
        8 -> 380_000L
        9 -> 470_000L
        else -> 575_000L
    }

    fun weeklyMaintenanceTotal(state: TeamFacilitiesState): Long =
        FacilityType.values().sumOf { weeklyMaintenanceCost(state.level(it)) }

    fun label(type: FacilityType): String = when (type) {
        FacilityType.FACTORY -> "Fábrica"
        FacilityType.RESEARCH -> "Centro de P&D"
        FacilityType.WIND_TUNNEL -> "Túnel de Vento"
        FacilityType.SIMULATOR -> "Simulador"
        FacilityType.SCOUTING -> "Scouting"
        FacilityType.DRIVER_DEVELOPMENT -> "Desenvolvimento de Pilotos"
        FacilityType.MARKETING -> "Centro Comercial / Marketing"
    }

    fun description(type: FacilityType): String = when (type) {
        FacilityType.FACTORY -> "Capacidade, tempo, custo e produção de peças físicas."
        FacilityType.RESEARCH -> "Pesquisa tecnológica: reduz custo e tempo dos projetos e aumenta a qualidade do desenho. Não altera carros diretamente."
        FacilityType.WIND_TUNNEL -> "Especialização aerodinâmica para chassi e asas."
        FacilityType.SIMULATOR -> "Simulação do carro: reduz tempo de P&D geral e melhora diretamente a performance global na pista, sem bônus específico para asas."
        FacilityType.SCOUTING -> "Precisão das informações obtidas no mercado de pilotos."
        FacilityType.DRIVER_DEVELOPMENT -> "Aumenta a eficiência para o piloto atingir o potencial que já possui."
        FacilityType.MARKETING -> "Quantidade, qualidade e valor das oportunidades de patrocínio."
    }

    // Effects are intentionally small and stack with the level, avoiding direct Overall inflation.
    fun isAerodynamic(component: CarComponent): Boolean =
        component == CarComponent.FRONT_WING || component == CarComponent.REAR_WING || component == CarComponent.CHASSIS

    /** Wind tunnel accelerates only aerodynamic research, up to 50% at level 10. */
    fun researchWeeks(base: Int, state: TeamFacilitiesState, component: CarComponent): Int {
        var multiplier = 1.0 - state.level(FacilityType.RESEARCH) * 0.032
        if (isAerodynamic(component)) multiplier *= 1.0 - state.level(FacilityType.WIND_TUNNEL) * 0.05
        // Simulator reduces research time for every component, up to 30% at level 10.
        multiplier *= 1.0 - state.level(FacilityType.SIMULATOR) * 0.03
        return kotlin.math.ceil(base * multiplier).toInt().coerceAtLeast(1)
    }

    fun researchGain(base: Int, state: TeamFacilitiesState, component: CarComponent): Int {
        var bonus = state.level(FacilityType.RESEARCH) / 3
        if (isAerodynamic(component)) bonus += state.level(FacilityType.WIND_TUNNEL) / 2
        return base + bonus
    }

    /** Direct on-track aerodynamic efficiency bonus. Does not change Overall or piece values. */
    fun windTunnelPerformanceMultiplier(state: TeamFacilitiesState): Double =
        1.0 + state.level(FacilityType.WIND_TUNNEL) * 0.002

    /** Applies the tunnel bonus only to the aerodynamic contribution of a car. */
    fun aerodynamicPerformanceBonus(
        state: TeamFacilitiesState,
        chassis: Int,
        frontWing: Int,
        rearWing: Int,
        chassisWeight: Double,
        frontWingWeight: Double,
        rearWingWeight: Double
    ): Double {
        val aero = chassis * chassisWeight + frontWing * frontWingWeight + rearWing * rearWingWeight
        return aero * (windTunnelPerformanceMultiplier(state) - 1.0)
    }

    fun factoryWeeks(base: Int, state: TeamFacilitiesState): Int = (base - state.level(FacilityType.FACTORY) / 4).coerceAtLeast(1)
    fun factoryCost(base: Long, state: TeamFacilitiesState): Long = (base * (1.0 - state.level(FacilityType.FACTORY) * 0.025)).toLong().coerceAtLeast(1_000_000L)
    fun factoryCapacity(state: TeamFacilitiesState): Int = 1 + state.level(FacilityType.FACTORY) / 3

    fun scoutingPrecision(state: TeamFacilitiesState): Int = (20 + state.level(FacilityType.SCOUTING) * 8).coerceAtMost(100)
    fun driverDevelopmentEfficiency(state: TeamFacilitiesState): Double = 0.80 + state.level(FacilityType.DRIVER_DEVELOPMENT) * 0.03
    /** Direct global on-track simulator bonus: +0.1% per level, max +1.0%. */
    fun simulatorPerformanceMultiplier(state: TeamFacilitiesState): Double =
        1.0 + state.level(FacilityType.SIMULATOR) * 0.001

    fun marketingQuality(state: TeamFacilitiesState): Int = (state.level(FacilityType.MARKETING) * 8).coerceAtMost(80)
}
