package com.f1teammanager.core.manager

enum class FacilityType {
    FACTORY, RESEARCH, WIND_TUNNEL, SIMULATOR, SCOUTING, DRIVER_DEVELOPMENT, MARKETING
}

data class FacilityUpgradeState(
    val facility: FacilityType,
    val previousLevel: Int,
    val targetLevel: Int,
    val remainingWeeks: Int = 12,
    val totalWeeks: Int = 12,
    val cost: Long,
    val startedSeason: Int,
    val startedWeek: Int
) {
    fun advance(weeks: Int): FacilityUpgradeState? {
        val remaining = remainingWeeks - weeks.coerceAtLeast(0)
        return if (remaining <= 0) null else copy(remainingWeeks = remaining)
    }
}

data class TeamFacilitiesState(
    val levels: Map<FacilityType, Int> = FacilityType.values().associateWith { 0 }
) {
    fun level(type: FacilityType): Int = (levels[type] ?: 0).coerceIn(0, 10)
    fun withLevel(type: FacilityType, value: Int): TeamFacilitiesState = copy(levels = levels + (type to value.coerceIn(0, 10)))
}

object FacilityEngine {
    private val upgradeCosts = longArrayOf(10_000_000L, 15_000_000L, 22_000_000L, 30_000_000L, 40_000_000L, 52_000_000L, 66_000_000L, 82_000_000L, 100_000_000L, 120_000_000L)

    fun initial(level: Int): TeamFacilitiesState =
        TeamFacilitiesState(FacilityType.values().associateWith { level.coerceIn(0, 2) })

    fun upgradeCost(currentLevel: Int): Long? = upgradeCosts.getOrNull(currentLevel.coerceIn(0, 10))

    fun upgrade(state: TeamManagerState, type: FacilityType, currentWeek: Int = 1): TeamManagerState {
        require(state.facilityUpgrade == null) { "Já existe uma melhoria de instalação em andamento." }
        val current = state.facilities.level(type)
        require(current < 10) { "Instalação já está no nível máximo." }
        val cost = upgradeCost(current) ?: error("Custo inválido")
        require(state.finance.budget >= cost) { "Orçamento insuficiente." }
        val technical = TechnicalInvestmentEngine.ensureSeason(state.technicalInvestment, state.season, TechnicalInvestmentEngine.seasonRanking(state.playerTeamId, state.car)[state.playerTeamId] ?: 40)
        val annualRemaining = SeasonInvestmentPolicy.remainingAnnualTechnicalEnvelope(
            technical.annualCap, technical.totalSpent, state.car.nextSeasonInvestment
        )
        require(annualRemaining >= cost) { "Limite anual compartilhado de investimento técnico insuficiente." }
        val technicalAfter = technical.withSpend(TechnicalInvestmentCategory.FACILITY_UPGRADE, cost)
        return state.copy(
            technicalInvestment = technicalAfter,
            finance = FinanceEngine().applyCashDebitFinance(state.finance, cost, "Início de melhoria ${label(type)} ${current}→${current + 1} (12 semanas)"),
            facilityUpgrade = FacilityUpgradeState(type, current, current + 1, 12, 12, cost, state.season, currentWeek)
        )
    }

    /** Advances a single active build. Level is applied only once when the 12-week timer expires. */
    fun advanceUpgrade(state: TeamManagerState, weeks: Int): Pair<TeamManagerState, Boolean> {
        val active = state.facilityUpgrade ?: return state to false
        if (weeks <= 0) return state to false
        val remaining = active.remainingWeeks - weeks
        if (remaining > 0) return state.copy(facilityUpgrade = active.copy(remainingWeeks = remaining)) to false
        val completed = state.facilities.withLevel(active.facility, active.targetLevel)
        return state.copy(facilities = completed, facilityUpgrade = null) to true
    }


    /** Weekly team-store sales range by Commercial Center level, including revenue at level 0. */
    fun weeklyMerchandiseRevenueRange(level: Int): LongRange = when (level.coerceIn(0, 10)) {
        0 -> 200_000L..400_000L
        1 -> 350_000L..600_000L
        2 -> 500_000L..800_000L
        3 -> 650_000L..1_000_000L
        // From level 4 onward, merchandise growth is deliberately incremental.
        // The previous curve multiplied sales too quickly and made advanced
        // Commercial Centers an almost automatic source of excess cash.
        4 -> 700_000L..1_050_000L
        5 -> 750_000L..1_100_000L
        6 -> 800_000L..1_150_000L
        7 -> 850_000L..1_200_000L
        8 -> 900_000L..1_250_000L
        9 -> 950_000L..1_300_000L
        else -> 1_000_000L..1_350_000L
    }

    /** Deterministic weekly sales value, stable across save/reload and duplicate callbacks. */
    fun weeklyMerchandiseRevenue(teamId: Int, season: Int, week: Int, level: Int): Long {
        val range = weeklyMerchandiseRevenueRange(level)
        val width = (range.last - range.first + 1L).coerceAtLeast(1L)
        val seed = (teamId.toLong() * 73856093L) xor (season.toLong() * 19349663L) xor (week.toLong() * 83492791L)
        val offset = Math.floorMod(seed, width)
        return range.first + offset
    }

    /** Weekly maintenance for ordinary facilities, in euros. Level 0 has no cost. */
    fun weeklyMaintenanceCost(level: Int): Long = when (level.coerceIn(0, 10)) {
        0 -> 0L
        1 -> 25_000L
        2 -> 50_000L
        3 -> 80_000L
        4 -> 120_000L
        5 -> 170_000L
        6 -> 230_000L
        7 -> 300_000L
        8 -> 380_000L
        9 -> 470_000L
        else -> 575_000L
    }

    /**
     * Marketing facilities carry additional retail, licensing, activation and
     * staffing costs. The higher-level curve grows faster than store revenue so
     * a level 4-10 center is a strategic choice, not a guaranteed cash printer.
     */
    fun weeklyMarketingMaintenanceCost(level: Int): Long = when (level.coerceIn(0, 10)) {
        0 -> 0L
        1 -> 25_000L
        2 -> 50_000L
        3 -> 80_000L
        4 -> 130_000L
        5 -> 220_000L
        6 -> 330_000L
        7 -> 460_000L
        8 -> 610_000L
        9 -> 780_000L
        else -> 980_000L
    }

    fun weeklyMaintenanceTotal(state: TeamFacilitiesState): Long =
        FacilityType.values().sumOf { type ->
            if (type == FacilityType.MARKETING) weeklyMarketingMaintenanceCost(state.level(type))
            else weeklyMaintenanceCost(state.level(type))
        }

    fun label(type: FacilityType): String = when (type) {
        FacilityType.FACTORY -> "Fábrica"
        FacilityType.RESEARCH -> "Centro de P&D"
        FacilityType.WIND_TUNNEL -> "Túnel de Vento"
        FacilityType.SIMULATOR -> "Simulador"
        FacilityType.SCOUTING -> "Scouting"
        FacilityType.DRIVER_DEVELOPMENT -> "Desenvolvimento de Pilotos"
        FacilityType.MARKETING -> "Centro Comercial / Marketing"
    }

    fun description(type: FacilityType): String = when (type) {
        FacilityType.FACTORY -> "Capacidade, tempo, custo e produção de peças físicas."
        FacilityType.RESEARCH -> "Pesquisa tecnológica: reduz custo e tempo dos projetos e aumenta a qualidade do desenho. Não altera carros diretamente."
        FacilityType.WIND_TUNNEL -> "Aprimora a aerodinâmica, acelera pesquisas de chassi e asas e melhora o ritmo de pista."
        FacilityType.SIMULATOR -> "Simulação do carro: reduz tempo de P&D geral e melhora diretamente a performance global na pista, sem bônus específico para asas."
        FacilityType.SCOUTING -> "Precisão das informações obtidas no mercado de pilotos."
        FacilityType.DRIVER_DEVELOPMENT -> "Aumenta a eficiência para o piloto atingir o potencial que já possui."
        FacilityType.MARKETING -> "Quantidade, qualidade e valor das oportunidades de patrocínio."
    }

    // Effects are intentionally small and stack with the level, avoiding direct Overall inflation.
    fun isAerodynamic(component: CarComponent): Boolean =
        component == CarComponent.FRONT_WING || component == CarComponent.REAR_WING || component == CarComponent.CHASSIS

    /** Wind tunnel accelerates only aerodynamic research, up to 50% at level 10. */
    fun researchWeeks(base: Int, state: TeamFacilitiesState, component: CarComponent): Int {
        var multiplier = 1.0 - state.level(FacilityType.RESEARCH) * 0.032
        if (isAerodynamic(component)) multiplier *= 1.0 - state.level(FacilityType.WIND_TUNNEL) * 0.05
        // Simulator reduces research time for every component, up to 30% at level 10.
        multiplier *= 1.0 - state.level(FacilityType.SIMULATOR) * 0.03
        return kotlin.math.ceil(base * multiplier).toInt().coerceAtLeast(1)
    }

    fun researchGain(base: Int, state: TeamFacilitiesState, component: CarComponent): Int {
        var bonus = state.level(FacilityType.RESEARCH) / 3
        if (isAerodynamic(component)) bonus += state.level(FacilityType.WIND_TUNNEL) / 2
        return base + bonus
    }

    /** Legacy aerodynamic-component preview multiplier; race timing uses racePaceBonus below. */
    fun windTunnelPerformanceMultiplier(state: TeamFacilitiesState): Double =
        1.0 + state.level(FacilityType.WIND_TUNNEL) * 0.001

    /** Applies the tunnel bonus only to the aerodynamic contribution of a car. */
    fun aerodynamicPerformanceBonus(
        state: TeamFacilitiesState,
        chassis: Int,
        frontWing: Int,
        rearWing: Int,
        chassisWeight: Double,
        frontWingWeight: Double,
        rearWingWeight: Double
    ): Double {
        val aero = chassis * chassisWeight + frontWing * frontWingWeight + rearWing * rearWingWeight
        return aero * (windTunnelPerformanceMultiplier(state) - 1.0)
    }

    /** Compatibility helpers delegate to the same official progression as FactoryEngine. */
    fun factoryWeeks(base: Int, state: TeamFacilitiesState): Int = kotlin.math.ceil(
        base.coerceAtLeast(1) * FactorySpecification.level(state.level(FacilityType.FACTORY)).timeMultiplier
    ).toInt().coerceAtLeast(1)

    fun factoryCost(base: Long, state: TeamFacilitiesState): Long = (
        base.coerceAtLeast(1L) * FactorySpecification.level(state.level(FacilityType.FACTORY)).costMultiplier
    ).toLong().coerceAtLeast(1L)
    /** Uses the same authoritative order capacity as the player's physical factory. */
    fun factoryCapacity(state: TeamFacilitiesState): Int =
        FactorySpecification.level(state.level(FacilityType.FACTORY)).parallelOrders

    /**
     * Continuous lap-time benefit from the Wind Tunnel and Simulator.
     * It is passed as a fractional car-time modifier instead of rounding facility
     * gains into integer component ratings. At level 10 the combined benefit is
     * +1.0% from Wind Tunnel and +0.5% from Simulator (1.5% total).
     */
    fun racePaceBonus(state: TeamFacilitiesState): Double =
        state.level(FacilityType.WIND_TUNNEL) * 0.0010 +
            state.level(FacilityType.SIMULATOR) * 0.0005

    fun scoutingPrecision(state: TeamFacilitiesState): Int = (20 + state.level(FacilityType.SCOUTING) * 8).coerceAtMost(100)
    /** Driver development has no passive attribute multiplier; benefits exist only through explicit programmes. */
    @Suppress("UNUSED_PARAMETER")
    fun driverDevelopmentEfficiency(state: TeamFacilitiesState): Double = 1.0
    /** Legacy simulator preview multiplier aligned with the race-time bonus: +0.05% per level. */
    fun simulatorPerformanceMultiplier(state: TeamFacilitiesState): Double =
        1.0 + state.level(FacilityType.SIMULATOR) * 0.0005

    fun marketingQuality(state: TeamFacilitiesState): Int = (state.level(FacilityType.MARKETING) * 8).coerceAtMost(80)

    /** Concrete benefit snapshot rendered in the facilities screen. */
    fun levelEffect(
        type: FacilityType,
        level: Int,
        allFacilities: TeamFacilitiesState = TeamFacilitiesState()
    ): String {
        val normalized = level.coerceIn(0, 10)
        val state = allFacilities.withLevel(type, normalized)
        return when (type) {
            FacilityType.FACTORY -> {
                val spec = FactorySpecification.level(normalized)
                val timeSaving = ((1.0 - spec.timeMultiplier) * 100).toInt()
                val costSaving = ((1.0 - spec.costMultiplier) * 100).toInt()
                "${spec.parallelOrders} ordem(ns) paralela(s) · até ${spec.maxUnitsPerOrder} peça(s)/ordem · tempo -$timeSaving% · custo -$costSaving%"
            }
            FacilityType.RESEARCH -> {
                val engineRange = ResearchEngine().maxImprovement(state, CarComponent.ENGINE)
                val aeroRange = ResearchEngine().maxImprovement(state, CarComponent.FRONT_WING)
                val timeSaving = (normalized * 3.2).toInt()
                "${ResearchEngine().activeProjectCapacity(normalized)} projeto(s) simultâneo(s) · P&D +${engineRange.first}–${engineRange.last} pts · aero +${aeroRange.first}–${aeroRange.last} pts · tempo -$timeSaving% · custo -${normalized * 2}%"
            }
            FacilityType.WIND_TUNNEL -> {
                val aeroGain = normalized / 2
                "Ritmo de pista +${normalized * 0.10}% · pesquisa aerodinâmica -${normalized * 5}% · ganho extra de P&D aero +$aeroGain"
            }
            FacilityType.SIMULATOR ->
                "Ritmo de pista +${normalized * 0.05}% · pesquisa geral -${normalized * 3}%"
            FacilityType.SCOUTING -> {
                val precision = scoutingPrecision(state)
                val margin = ((100 - precision) / 8).coerceIn(0, 10)
                "Precisão ${precision}% · margem dos atributos ±$margin"
            }
            FacilityType.DRIVER_DEVELOPMENT -> {
                val points = DriverDevelopmentEngine.points(normalized)
                val weeks = DriverDevelopmentEngine.weeks(normalized)
                val capacity = DriverDevelopmentEngine.capacity(normalized)
                "Sem bônus passivo · programa ${if (normalized == 0) "bloqueado" else "+$points pts / $weeks sem. / $capacity vaga(s)"}"
            }
            FacilityType.MARKETING -> {
                val revenue = weeklyMerchandiseRevenueRange(normalized)
                val multiplier = SponsorContractPricing.commercialMultiplier(normalized)
                val maintenance = weeklyMarketingMaintenanceCost(normalized)
                "Contratos x${"%.3f".format(java.util.Locale.US, multiplier)} · lojas €${revenue.first / 1_000}–${revenue.last / 1_000} mil/sem. · manutenção €${maintenance / 1_000} mil/sem."
            }
        }
    }

    fun nextLevelEffect(
        type: FacilityType,
        currentLevel: Int,
        allFacilities: TeamFacilitiesState = TeamFacilitiesState()
    ): String = if (currentLevel >= 10) "Benefício máximo atingido"
        else levelEffect(type, currentLevel + 1, allFacilities)
}
