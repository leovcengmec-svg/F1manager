package com.f1teammanager.core.manager

import kotlin.random.Random

/**
 * Immutable, deterministic season event calendar. Counts are drawn once from the season seed,
 * then each event is assigned a week. Persist the generated entries with the career save;
 * regenerating with the same season and seed yields the same calendar.
 */
object AnnualTeamEventSeasonCalendar {
    data class Slot(val week: Int, val kind: AnnualTeamEventEngine.Kind, val ordinal: Int)

    fun generate(season: Int, seed: Int): List<Slot> {
        if (season < 1) return emptyList()
        val rng = Random(seed.toLong() + season * 7919L + 0x5EA50L)
        val planned = mutableListOf<AnnualTeamEventEngine.Kind>()

        // Rare special events: at most one of each per season, and neither is tied to week 1.
        if (AnnualTeamEventEngine.shouldRollAcquisition(season, seed)) planned += AnnualTeamEventEngine.Kind.INVESTOR_ACQUISITION
        // Pilot classes are reviewed by DriverClassProgressionEngine after two
        // completed seasons; they are intentionally absent from random event calendars.

        // Modest season-wide volume, not a weekly chance. A count of zero is a valid outcome.
        repeat(rng.nextInt(0, 3)) { planned += AnnualTeamEventEngine.Kind.FINANCIAL_CRISIS } // 0–2
        repeat(rng.nextInt(0, 2)) { planned += if (rng.nextBoolean()) AnnualTeamEventEngine.Kind.FIRE else AnnualTeamEventEngine.Kind.EARTHQUAKE } // 0–1
        repeat(rng.nextInt(1, 4)) { // 1–3 car/reliability events combined
            planned += when (rng.nextInt(4)) {
                0 -> AnnualTeamEventEngine.Kind.CAR_GAIN
                1 -> AnnualTeamEventEngine.Kind.CAR_LOSS
                2 -> AnnualTeamEventEngine.Kind.RELIABILITY_GAIN
                else -> AnnualTeamEventEngine.Kind.RELIABILITY_LOSS
            }
        }
        repeat(rng.nextInt(0, 3)) { // 0–2 facility upgrades per season
            planned += AnnualTeamEventEngine.Kind.FACILITY_UPGRADE
        }
        // Driver ratings now change only through the performance engine and the
        // explicitly managed development programme, never through random annual events.
        planned.shuffle(rng)

        // Spread events across the full 56-week season; prefer unique weeks, allow a collision only
        // if the planned event count ever exceeds available weeks (not possible with these limits).
        val weeks = (1..56).shuffled(rng).take(planned.size)
        return planned.mapIndexed { index, kind -> Slot(weeks[index], kind, index + 1) }
            .sortedWith(compareBy<Slot> { it.week }.thenBy { it.ordinal })
    }
}
