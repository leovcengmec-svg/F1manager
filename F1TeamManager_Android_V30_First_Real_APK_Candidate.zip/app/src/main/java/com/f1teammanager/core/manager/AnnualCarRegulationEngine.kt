package com.f1teammanager.core.manager

import kotlin.random.Random

/**
 * Annual and decennial car-regulation calendar. This module only decides and records
 * the rule; applying its impact to a newly constructed car is a separate transition stage.
 * The same immutable rule is intended for every team in a given career/season.
 */
object AnnualCarRegulationEngine {
    data class Event(
        val id: String,
        val name: String,
        val component: CarComponent,
        /** Performance reduction as a percentage (not reliability). */
        val reductionPercent: Int
    )

    data class SeasonRule(
        val season: Int,
        val annualEvents: List<Event>,
        val decennialRevolution: Boolean,
        val decennialReductions: Map<CarComponent, Int>,
        /** Start and length of the active macro-cycle; persisted with the season rule. */
        val cycleStartSeason: Int = 1,
        val cycleLength: Int = 10
    ) {
        val affectedComponents: Set<CarComponent>
            get() = annualEvents.map { it.component }.toSet() +
                if (decennialRevolution) decennialReductions.keys else emptySet()
    }

    private val catalog = listOf(
        Event("MOT-01", "Restrição de potência", CarComponent.ENGINE, 8),
        Event("MOT-02", "Limite de eficiência energética", CarComponent.ENGINE, 5),
        Event("MOT-03", "Nova homologação do motor", CarComponent.ENGINE, 10),
        Event("CHA-01", "Requisitos estruturais mais rígidos", CarComponent.CHASSIS, 5),
        Event("CHA-02", "Restrição de redução de peso", CarComponent.CHASSIS, 8),
        Event("CHA-03", "Nova homologação estrutural", CarComponent.CHASSIS, 10),
        Event("AD-01", "Limite de eficiência aerodinâmica", CarComponent.FRONT_WING, 8),
        Event("AD-02", "Restrição de geração de carga aerodinâmica", CarComponent.FRONT_WING, 10),
        Event("AD-03", "Nova geometria regulamentar", CarComponent.FRONT_WING, 5),
        Event("AT-01", "Restrição de eficiência aerodinâmica", CarComponent.REAR_WING, 8),
        Event("AT-02", "Restrição do sistema de redução de arrasto", CarComponent.REAR_WING, 5),
        Event("AT-03", "Nova geometria regulamentar", CarComponent.REAR_WING, 10),
        Event("FRE-01", "Limite de eficiência de frenagem", CarComponent.BRAKES, 5),
        Event("FRE-02", "Restrição de refrigeração", CarComponent.BRAKES, 8),
        Event("FRE-03", "Nova homologação dos freios", CarComponent.BRAKES, 10),
        Event("MGU-01", "Limite de entrega de energia", CarComponent.ELECTRIC_POWER_UNIT, 8),
        Event("MGU-02", "Restrição de recuperação energética", CarComponent.ELECTRIC_POWER_UNIT, 5),
        Event("MGU-03", "Nova homologação elétrica", CarComponent.ELECTRIC_POWER_UNIT, 10)
    )

    /** A more disruptive reset after a career-specific cycle of 6–10 completed seasons. */
    private val decennial = mapOf(
        // Reset total calibrated so a developed 80–100 car returns to roughly 40–60.
        CarComponent.ENGINE to 40,
        CarComponent.CHASSIS to 35,
        CarComponent.FRONT_WING to 45,
        CarComponent.REAR_WING to 45,
        CarComponent.BRAKES to 35,
        CarComponent.ELECTRIC_POWER_UNIT to 40
    )

    fun catalog(): List<Event> = catalog.toList()

    /** Maps calendar years to career-season ordinals (the default career begins in 2026). */
    fun seasonIndexForCalendarYear(calendarYear: Int, firstCalendarYear: Int = 2026): Int =
        (calendarYear - firstCalendarYear + 1).coerceAtLeast(1)

    fun generateForCalendarYear(calendarYear: Int, careerSeed: Int, firstCalendarYear: Int = 2026): SeasonRule =
        generate(seasonIndexForCalendarYear(calendarYear, firstCalendarYear), careerSeed)

    private data class CycleInfo(
        val startSeason: Int,
        val length: Int,
        val isBoundary: Boolean
    )

    /**
     * A new cycle length is drawn at the beginning of each cycle. Deriving each draw
     * from the career seed and cycle start makes the draw stable across reloads and
     * identical in player, AI, market forecasts and headless season simulation.
     */
    fun cycleLengthForStart(cycleStartSeason: Int, careerSeed: Int): Int {
        val mixedSeed = careerSeed.toLong() xor
            (cycleStartSeason.toLong() * 0x6A09E667F3BCC909L)
        return Random(mixedSeed).nextInt(6, 11)
    }

    private fun cycleInfo(season: Int, careerSeed: Int): CycleInfo {
        require(season >= 1) { "Temporada inválida" }
        var start = 1
        while (true) {
            val length = cycleLengthForStart(start, careerSeed)
            val boundary = start + length
            when {
                season < boundary -> return CycleInfo(start, length, false)
                season == boundary -> {
                    // The revolution opens the next cycle. Draw its duration now,
                    // so the new term is already established at the cycle boundary.
                    val nextLength = cycleLengthForStart(boundary, careerSeed)
                    return CycleInfo(boundary, nextLength, true)
                }
                else -> start = boundary
            }
        }
    }

    fun nextDecennialSeasonAfter(season: Int, careerSeed: Int): Int {
        val cycle = cycleInfo(season.coerceAtLeast(1), careerSeed)
        return cycle.startSeason + cycle.length
    }

    fun isDecennialSeason(season: Int, careerSeed: Int): Boolean =
        season > 1 && cycleInfo(season, careerSeed).isBoundary

    /** Compatibility overload for old tools that did not pass the career seed. */
    fun isDecennialSeason(season: Int): Boolean = isDecennialSeason(season, 0)

    /**
     * Season 1 is exempt. Every later annual regulation draws 0, 1 or 2 distinct
     * component changes. Zero and two changes are less likely than one change.
     */
    fun generate(season: Int, careerSeed: Int): SeasonRule {
        require(season >= 1) { "Temporada inválida" }
        val cycle = cycleInfo(season, careerSeed)
        if (season == 1) return SeasonRule(1, emptyList(), false, emptyMap(), cycle.startSeason, cycle.length)
        val rng = Random(careerSeed.toLong() xor (season.toLong() * 0x9E3779B97F4A7C15UL.toLong()))
        val groups = catalog.groupBy { it.component }.keys.toList().shuffled(rng)
        val countRoll = rng.nextInt(100)
        val componentCount = when {
            countRoll < 15 -> 0
            countRoll < 85 -> 1
            else -> 2
        }
        val chosen = groups.take(componentCount).map { component ->
            catalog.filter { it.component == component }.let { choices -> choices[rng.nextInt(choices.size)] }
        }.sortedBy { it.id }
        val decennialSeason = cycle.isBoundary
        // A decennial revolution replaces, rather than stacks with, the ordinary annual event.
        val seasonEvents = if (decennialSeason) emptyList() else chosen
        return SeasonRule(
            season, seasonEvents, decennialSeason,
            if (decennialSeason) decennial.toMap() else emptyMap(),
            cycle.startSeason, cycle.length
        )
    }

    /** One stable 0–8% team-specific adaptation penalty for the first season of a new regulation. */
    fun teamAdaptationReductionPercent(rule: SeasonRule, teamSeed: Int): Int {
        if (!rule.decennialRevolution) return 0
        val mixedSeed = teamSeed.toLong() xor (rule.season.toLong() * 0x517CC1B727220A95L)
        return Random(mixedSeed).nextInt(0, 9)
    }

    /** Apply a season rule to a freshly constructed car. Never changes reliability. */
    fun applyToCar(car: TeamCarState, rule: SeasonRule, teamSeed: Int = 0): TeamCarState {
        val teamPenalty = teamAdaptationReductionPercent(rule, teamSeed)
        fun reduce(value: Int, component: CarComponent): Int {
            val annual = if (rule.decennialRevolution) 0 else rule.annualEvents.firstOrNull { it.component == component }?.reductionPercent ?: 0
            val decennial = if (rule.decennialRevolution) rule.decennialReductions[component] ?: 0 else 0
            val afterAnnual = (value * (100 - annual) / 100.0).toInt()
            val afterDecennial = (afterAnnual * (100 - decennial) / 100.0).toInt()
            if (value <= 0) return 0
            return (afterDecennial * (100 - teamPenalty) / 100.0).toInt().coerceIn(40, 100)
        }
        val front = reduce(car.frontWing, CarComponent.FRONT_WING)
        val rear = reduce(car.rearWing, CarComponent.REAR_WING)
        return car.copy(
            engine = reduce(car.engine, CarComponent.ENGINE),
            chassis = reduce(car.chassis, CarComponent.CHASSIS),
            aerodynamics = ((front + rear) / 2).coerceIn(40, 100),
            frontWing = front,
            rearWing = rear,
            brakes = reduce(car.brakes, CarComponent.BRAKES),
            electricPowerUnit = reduce(car.electricPowerUnit, CarComponent.ELECTRIC_POWER_UNIT)
        ).normalized()
    }

    /** Applies the identical rule to both physical cars, preserving their reliability and identities. */
    fun applyToGarage(garage: TeamGarage, rule: SeasonRule, teamSeed: Int = 0): TeamGarage {
        val teamPenalty = teamAdaptationReductionPercent(rule, teamSeed)
        fun apply(car: PhysicalCar): PhysicalCar {
            fun reduce(value: Int, component: CarComponent): Int {
                val annual = if (rule.decennialRevolution) 0 else rule.annualEvents.firstOrNull { it.component == component }?.reductionPercent ?: 0
                val decennial = if (rule.decennialRevolution) rule.decennialReductions[component] ?: 0 else 0
                val afterAnnual = (value * (100 - annual) / 100.0).toInt()
                val afterDecennial = (afterAnnual * (100 - decennial) / 100.0).toInt()
                if (value <= 0) return 0
            return (afterDecennial * (100 - teamPenalty) / 100.0).toInt().coerceIn(40, 100)
            }
            fun physical(component: CarComponent, value: Int): Int =
                if (component !in car.installedPieces || value <= 0) 0 else reduce(value, component)
            return car.copy(
                engine = physical(CarComponent.ENGINE, car.engine),
                chassis = physical(CarComponent.CHASSIS, car.chassis),
                frontWing = physical(CarComponent.FRONT_WING, car.frontWing),
                rearWing = physical(CarComponent.REAR_WING, car.rearWing),
                brakes = physical(CarComponent.BRAKES, car.brakes),
                electricPowerUnit = physical(CarComponent.ELECTRIC_POWER_UNIT, car.electricPowerUnit)
            )
        }
        return TeamGarage(apply(garage.car1), apply(garage.car2)).normalized()
    }

    /** Stable, compact representation suitable for a career save. */
    fun encode(rule: SeasonRule): String = buildString {
        append(rule.season).append('|')
        append(if (rule.decennialRevolution) '1' else '0').append('|')
        append(rule.annualEvents.joinToString(",") { it.id }).append('|')
        append(rule.cycleStartSeason).append('|')
        append(rule.cycleLength)
    }

    /** Decodes only IDs from the built-in catalog; unknown IDs fail closed. */
    fun decode(encoded: String): SeasonRule? = runCatching {
        val parts = encoded.split('|')
        require(parts.size == 3 || parts.size == 5)
        val season = parts[0].toInt().also { require(it >= 1) }
        val revolution = parts[1] == "1"
        require(parts[1] == "0" || revolution)
        val decodedEvents = if (parts[2].isBlank()) emptyList() else parts[2].split(',').map { id ->
            catalog.first { it.id == id }
        }
        require(decodedEvents.map { it.component }.distinct().size == decodedEvents.size)
        // Older saves may contain annual IDs for a decennial year; discard them so
        // neither the UI nor any downstream consumer can treat them as active.
        val events = if (revolution) emptyList() else decodedEvents
        val cycleStart = parts.getOrNull(3)?.toIntOrNull()?.coerceAtLeast(1) ?: 1
        val cycleLength = parts.getOrNull(4)?.toIntOrNull()?.takeIf { it in 6..10 } ?: 10
        SeasonRule(season, events, revolution, if (revolution) decennial.toMap() else emptyMap(), cycleStart, cycleLength)
    }.getOrNull()
}
