package com.f1teammanager.core.manager

import kotlin.random.Random

/**
 * Annual and decennial car-regulation calendar. This module only decides and records
 * the rule; applying its impact to a newly constructed car is a separate transition stage.
 * The same immutable rule is intended for every team in a given career/season.
 */
object AnnualCarRegulationEngine {
    data class Event(
        val id: String,
        val name: String,
        val component: CarComponent,
        /** Performance reduction as a percentage (not reliability). */
        val reductionPercent: Int
    )

    data class SeasonRule(
        val season: Int,
        val annualEvents: List<Event>,
        val decennialRevolution: Boolean,
        val decennialReductions: Map<CarComponent, Int>
    ) {
        val affectedComponents: Set<CarComponent>
            get() = annualEvents.map { it.component }.toSet() +
                if (decennialRevolution) decennialReductions.keys else emptySet()
    }

    private val catalog = listOf(
        Event("MOT-01", "Restrição de potência", CarComponent.ENGINE, 8),
        Event("MOT-02", "Limite de eficiência energética", CarComponent.ENGINE, 5),
        Event("MOT-03", "Nova homologação do motor", CarComponent.ENGINE, 10),
        Event("CHA-01", "Requisitos estruturais mais rígidos", CarComponent.CHASSIS, 5),
        Event("CHA-02", "Restrição de redução de peso", CarComponent.CHASSIS, 8),
        Event("CHA-03", "Nova homologação estrutural", CarComponent.CHASSIS, 10),
        Event("AD-01", "Limite de eficiência aerodinâmica", CarComponent.FRONT_WING, 8),
        Event("AD-02", "Restrição de geração de carga aerodinâmica", CarComponent.FRONT_WING, 10),
        Event("AD-03", "Nova geometria regulamentar", CarComponent.FRONT_WING, 5),
        Event("AT-01", "Restrição de eficiência aerodinâmica", CarComponent.REAR_WING, 8),
        Event("AT-02", "Restrição do sistema de redução de arrasto", CarComponent.REAR_WING, 5),
        Event("AT-03", "Nova geometria regulamentar", CarComponent.REAR_WING, 10),
        Event("FRE-01", "Limite de eficiência de frenagem", CarComponent.BRAKES, 5),
        Event("FRE-02", "Restrição de refrigeração", CarComponent.BRAKES, 8),
        Event("FRE-03", "Nova homologação dos freios", CarComponent.BRAKES, 10),
        Event("MGU-01", "Limite de entrega de energia", CarComponent.ELECTRIC_POWER_UNIT, 8),
        Event("MGU-02", "Restrição de recuperação energética", CarComponent.ELECTRIC_POWER_UNIT, 5),
        Event("MGU-03", "Nova homologação elétrica", CarComponent.ELECTRIC_POWER_UNIT, 10)
    )

    /** A more disruptive reset after each ten completed seasons: 11, 21, 31... */
    private val decennial = mapOf(
        // Reset total calibrated so a developed 80–100 car returns to roughly 40–60.
        CarComponent.ENGINE to 40,
        CarComponent.CHASSIS to 35,
        CarComponent.FRONT_WING to 45,
        CarComponent.REAR_WING to 45,
        CarComponent.BRAKES to 35,
        CarComponent.ELECTRIC_POWER_UNIT to 40
    )

    fun catalog(): List<Event> = catalog.toList()

    fun isDecennialSeason(season: Int): Boolean = season > 1 && (season - 1) % 10 == 0

    /** Maps calendar years to career-season ordinals (the default career begins in 2026). */
    fun seasonIndexForCalendarYear(calendarYear: Int, firstCalendarYear: Int = 2026): Int =
        (calendarYear - firstCalendarYear + 1).coerceAtLeast(1)

    fun generateForCalendarYear(calendarYear: Int, careerSeed: Int, firstCalendarYear: Int = 2026): SeasonRule =
        generate(seasonIndexForCalendarYear(calendarYear, firstCalendarYear), careerSeed)

    /** Season 1 is exempt. For later seasons choose one or two distinct component groups. */
    fun generate(season: Int, careerSeed: Int): SeasonRule {
        require(season >= 1) { "Temporada inválida" }
        if (season == 1) return SeasonRule(1, emptyList(), false, emptyMap())
        val rng = Random(careerSeed.toLong() xor (season.toLong() * 0x9E3779B97F4A7C15UL.toLong()))
        val groups = catalog.groupBy { it.component }.keys.toList().shuffled(rng)
        val componentCount = rng.nextInt(1, 3)
        val chosen = groups.take(componentCount).map { component ->
            catalog.filter { it.component == component }.let { choices -> choices[rng.nextInt(choices.size)] }
        }.sortedBy { it.id }
        val decennialSeason = isDecennialSeason(season)
        // A decennial revolution replaces, rather than stacks with, the ordinary annual event.
        val seasonEvents = if (decennialSeason) emptyList() else chosen
        return SeasonRule(season, seasonEvents, decennialSeason, if (decennialSeason) decennial.toMap() else emptyMap())
    }

    /** One stable 0–8% team-specific adaptation penalty for the first season of a new regulation. */
    fun teamAdaptationReductionPercent(rule: SeasonRule, teamSeed: Int): Int {
        if (!rule.decennialRevolution) return 0
        val mixedSeed = teamSeed.toLong() xor (rule.season.toLong() * 0x517CC1B727220A95L)
        return Random(mixedSeed).nextInt(0, 9)
    }

    /** Apply a season rule to a freshly constructed car. Never changes reliability. */
    fun applyToCar(car: TeamCarState, rule: SeasonRule, teamSeed: Int = 0): TeamCarState {
        val teamPenalty = teamAdaptationReductionPercent(rule, teamSeed)
        fun reduce(value: Int, component: CarComponent): Int {
            val annual = if (rule.decennialRevolution) 0 else rule.annualEvents.firstOrNull { it.component == component }?.reductionPercent ?: 0
            val decennial = if (rule.decennialRevolution) rule.decennialReductions[component] ?: 0 else 0
            val afterAnnual = (value * (100 - annual) / 100.0).toInt()
            val afterDecennial = (afterAnnual * (100 - decennial) / 100.0).toInt()
            if (value <= 0) return 0
            return (afterDecennial * (100 - teamPenalty) / 100.0).toInt().coerceIn(40, 100)
        }
        val front = reduce(car.frontWing, CarComponent.FRONT_WING)
        val rear = reduce(car.rearWing, CarComponent.REAR_WING)
        return car.copy(
            engine = reduce(car.engine, CarComponent.ENGINE),
            chassis = reduce(car.chassis, CarComponent.CHASSIS),
            aerodynamics = ((front + rear) / 2).coerceIn(40, 100),
            frontWing = front,
            rearWing = rear,
            brakes = reduce(car.brakes, CarComponent.BRAKES),
            electricPowerUnit = reduce(car.electricPowerUnit, CarComponent.ELECTRIC_POWER_UNIT)
        ).normalized()
    }

    /** Applies the identical rule to both physical cars, preserving their reliability and identities. */
    fun applyToGarage(garage: TeamGarage, rule: SeasonRule, teamSeed: Int = 0): TeamGarage {
        val teamPenalty = teamAdaptationReductionPercent(rule, teamSeed)
        fun apply(car: PhysicalCar): PhysicalCar {
            fun reduce(value: Int, component: CarComponent): Int {
                val annual = if (rule.decennialRevolution) 0 else rule.annualEvents.firstOrNull { it.component == component }?.reductionPercent ?: 0
                val decennial = if (rule.decennialRevolution) rule.decennialReductions[component] ?: 0 else 0
                val afterAnnual = (value * (100 - annual) / 100.0).toInt()
                val afterDecennial = (afterAnnual * (100 - decennial) / 100.0).toInt()
                if (value <= 0) return 0
            return (afterDecennial * (100 - teamPenalty) / 100.0).toInt().coerceIn(40, 100)
            }
            fun physical(component: CarComponent, value: Int): Int =
                if (component !in car.installedPieces || value <= 0) 0 else reduce(value, component)
            return car.copy(
                engine = physical(CarComponent.ENGINE, car.engine),
                chassis = physical(CarComponent.CHASSIS, car.chassis),
                frontWing = physical(CarComponent.FRONT_WING, car.frontWing),
                rearWing = physical(CarComponent.REAR_WING, car.rearWing),
                brakes = physical(CarComponent.BRAKES, car.brakes),
                electricPowerUnit = physical(CarComponent.ELECTRIC_POWER_UNIT, car.electricPowerUnit)
            )
        }
        return TeamGarage(apply(garage.car1), apply(garage.car2)).normalized()
    }

    /** Stable, compact representation suitable for a career save. */
    fun encode(rule: SeasonRule): String = buildString {
        append(rule.season).append('|')
        append(if (rule.decennialRevolution) '1' else '0').append('|')
        append(rule.annualEvents.joinToString(",") { it.id })
    }

    /** Decodes only IDs from the built-in catalog; unknown IDs fail closed. */
    fun decode(encoded: String): SeasonRule? = runCatching {
        val parts = encoded.split('|')
        require(parts.size == 3)
        val season = parts[0].toInt().also { require(it >= 1) }
        val revolution = parts[1] == "1"
        require(parts[1] == "0" || revolution)
        val decodedEvents = if (parts[2].isBlank()) emptyList() else parts[2].split(',').map { id ->
            catalog.first { it.id == id }
        }
        require(decodedEvents.map { it.component }.distinct().size == decodedEvents.size)
        require(revolution == isDecennialSeason(season))
        // Older saves may contain annual IDs for a decennial year; discard them so
        // neither the UI nor any downstream consumer can treat them as active.
        val events = if (revolution) emptyList() else decodedEvents
        SeasonRule(season, events, revolution, if (revolution) decennial.toMap() else emptyMap())
    }.getOrNull()
}
