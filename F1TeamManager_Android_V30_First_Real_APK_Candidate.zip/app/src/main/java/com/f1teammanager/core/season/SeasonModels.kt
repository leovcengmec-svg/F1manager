package com.f1teammanager.core.season

import com.f1teammanager.core.race.RaceParticipant

data class TeamDefinition(
    val id:Int,
    val name:String,
    val driverIds:List<Int>,
    val baseCar:Int,
    val engine:Int,
    val chassis:Int=baseCar,
    val reliability:Int,
    val frontWing:Int=baseCar,
    val rearWing:Int=baseCar,
    val brakes:Int=baseCar,
    val electricPowerUnit:Int=engine
)
data class DriverDefinition(
    val id:Int,val name:String,val teamId:Int,
    val speed:Int,val qualifying:Int,val overtaking:Int,val defense:Int,val consistency:Int,val wet:Int,val tyre:Int,val experience:Int,
    val driverClass:String="Médio", val evolution:String="Normal"
)
data class RoundDefinition(
    val round:Int,val grandPrix:String,val circuit:String,val laps:Int,
    val baseLapTimeMs:Long,val powerFactor:Double,val overtakingFactor:Double,
    val crashRisk:Double=1.0,val reliabilityRisk:Double=1.0,val safetyCarRisk:Double=1.0,
    val month:String="Março", val weekOfSeason:Int=1, val dateLabel:String="01/03/2026"
)
data class ChampionshipRow(val driverId:Int,val driverName:String,val teamId:Int,val teamName:String,val points:Int,val wins:Int,val podiums:Int,val starts:Int)
data class SeasonState(val season:Int=2026,val currentRound:Int=1,val standings:Map<Int,Int> = emptyMap(),val wins:Map<Int,Int> = emptyMap(),val podiums:Map<Int,Int> = emptyMap(),val starts:Map<Int,Int> = emptyMap())

fun DriverDefinition.toParticipant(team: TeamDefinition)=RaceParticipant(
    id,name,team.id,team.name,speed,qualifying,overtaking,defense,consistency,
    carSpeed=((team.baseCar*.30)+(team.frontWing*.16)+(team.rearWing*.16)+(team.chassis*.14)+(team.brakes*.08)+(team.electricPowerUnit*.08)+(team.engine*.08)).toInt().coerceIn(1,100),
    enginePower=team.engine, tyreGrip=tyre, tyreWear=tyre, racecraft=experience.coerceIn(1,100), reliability=team.reliability, chassisWear=0, wetSkill=wet
)

