package com.f1teammanager.core.season

import com.f1teammanager.core.race.RaceParticipant

data class TeamDefinition(
    val id:Int,
    val name:String,
    val driverIds:List<Int>,
    val engine:Int,
    val chassis:Int,
    val reliability:Int,
    val frontWing:Int,
    val rearWing:Int,
    val brakes:Int,
    val electricPowerUnit:Int=engine,
    val country:String="",
    /** Official starting career level: 2 Forte, 1 Médio, 0 Fraco. */
    val initialLevel:Int=1
) {
    fun normalized() = copy(
        engine=com.f1teammanager.core.AttributeBounds.rating(engine),
        chassis=com.f1teammanager.core.AttributeBounds.rating(chassis),
        reliability=com.f1teammanager.core.AttributeBounds.rating(reliability),
        frontWing=com.f1teammanager.core.AttributeBounds.rating(frontWing),
        rearWing=com.f1teammanager.core.AttributeBounds.rating(rearWing),
        brakes=com.f1teammanager.core.AttributeBounds.rating(brakes),
        electricPowerUnit=com.f1teammanager.core.AttributeBounds.rating(electricPowerUnit)
    )
}
data class DriverDefinition(
    val id:Int,val name:String,val teamId:Int,
    val speed:Int,val qualifying:Int,val overtaking:Int,val defense:Int,val consistency:Int,val wet:Int,val tyre:Int,
    val driverClass:String="Médio", val evolution:String="Normal", val country:String="",
    /** Individual Overall potential; not derived from reputation/class. */
    val potentialOverall:Int=100
) {
    fun normalized() = copy(
        speed=com.f1teammanager.core.AttributeBounds.rating(speed),
        qualifying=com.f1teammanager.core.AttributeBounds.rating(qualifying),
        overtaking=com.f1teammanager.core.AttributeBounds.rating(overtaking),
        defense=com.f1teammanager.core.AttributeBounds.rating(defense),
        consistency=com.f1teammanager.core.AttributeBounds.rating(consistency),
        wet=com.f1teammanager.core.AttributeBounds.rating(wet),
        tyre=com.f1teammanager.core.AttributeBounds.rating(tyre),
        potentialOverall=com.f1teammanager.core.AttributeBounds.rating(potentialOverall)
    )
}
data class RoundDefinition(
    val round:Int,val grandPrix:String,val circuit:String,val laps:Int,
    val baseLapTimeMs:Long,
    val crashRisk:Double=1.0,val reliabilityRisk:Double=1.0,val safetyCarRisk:Double=1.0,
    val month:String="Março", val weekOfSeason:Int=1, val dateLabel:String="01/03/2026", val distanceKm:Double=0.0, val assetSearchName:String=""
)
data class ChampionshipRow(val driverId:Int,val driverName:String,val teamId:Int,val teamName:String,val points:Int,val wins:Int,val podiums:Int,val starts:Int)
data class SeasonState(val season:Int=2026,val currentRound:Int=1,val standings:Map<Int,Int> = emptyMap(),val wins:Map<Int,Int> = emptyMap(),val podiums:Map<Int,Int> = emptyMap(),val starts:Map<Int,Int> = emptyMap())

