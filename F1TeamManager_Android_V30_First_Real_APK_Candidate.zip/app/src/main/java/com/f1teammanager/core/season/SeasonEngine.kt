package com.f1teammanager.core.season

import com.f1teammanager.core.race.*

class SeasonEngine(private val seed:Int=20261003) {
    private val race = RaceWeekendEngine(seed)
    fun runRound(state:SeasonState, round:Int=state.currentRound): Pair<SeasonState,RaceResult> {
        require(round in 1..WorldDatabase.rounds.size)
        val rd=WorldDatabase.rounds[round-1]
        val participants=WorldDatabase.drivers.map { it.toParticipant(WorldDatabase.teams[it.teamId-1]) }
        val circuit=RaceCircuit(rd.round,rd.circuit,rd.laps,rd.baseLapTimeMs,rd.powerFactor,rd.overtakingFactor,crashRisk=rd.crashRisk,reliabilityRisk=rd.reliabilityRisk,safetyCarRisk=rd.safetyCarRisk)
        val result=race.race(participants,circuit)
        val pts=state.standings.toMutableMap(); val wins=state.wins.toMutableMap(); val pods=state.podiums.toMutableMap(); val starts=state.starts.toMutableMap()
        result.classification.forEach { f -> if(f.status!="DNF") starts[f.driverId]=(starts[f.driverId]?:0)+1; val p=result.points[f.driverId]?:0; pts[f.driverId]=(pts[f.driverId]?:0)+p; if(f.status!="DNF" && f.position==1) wins[f.driverId]=(wins[f.driverId]?:0)+1; if(f.status!="DNF" && f.position<=3) pods[f.driverId]=(pods[f.driverId]?:0)+1 }
        return state.copy(currentRound=if(round<WorldDatabase.rounds.size) round+1 else WorldDatabase.rounds.size+1,standings=pts,wins=wins,podiums=pods,starts=starts) to result
    }
    fun table(state:SeasonState):List<ChampionshipRow> = WorldDatabase.drivers.map { d -> val t=WorldDatabase.teams[d.teamId-1]; ChampionshipRow(d.id,d.name,t.id,t.name,state.standings[d.id]?:0,state.wins[d.id]?:0,state.podiums[d.id]?:0,state.starts[d.id]?:0) }.sortedWith(compareByDescending<ChampionshipRow>{it.points}.thenByDescending{it.wins}.thenByDescending{it.podiums}.thenBy{it.driverId})
}
