package com.f1teammanager.core

data class ManagerState(val id:Int,val name:String,val performance:Int,val reputation:Int,val teamId:Int?=null,val available:Boolean=false,val contractYears:Int=0)
