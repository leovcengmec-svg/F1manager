package com.f1teammanager.core.manager

/** P&D is measured in real season weeks, never in races. */
class CarDevelopmentEngine {
    fun durationWeeks(component: CarComponent): Int = when (component) {
        CarComponent.ENGINE -> 4
        CarComponent.CHASSIS -> 3
        CarComponent.FRONT_WING -> 2
        CarComponent.REAR_WING -> 2
        CarComponent.BRAKES -> 2
        CarComponent.ELECTRIC_POWER_UNIT -> 4
    }

    fun start(state: TeamManagerState, component: CarComponent): TeamManagerState {
        require(state.car.activeProject == null) { "Já existe um projeto em desenvolvimento" }
        val facility = when (component) {
            CarComponent.ENGINE, CarComponent.ELECTRIC_POWER_UNIT -> Facility.TESTING
            CarComponent.CHASSIS, CarComponent.BRAKES -> Facility.FACTORY
            CarComponent.FRONT_WING, CarComponent.REAR_WING -> Facility.WIND_TUNNEL
        }
        val level = state.car.facilities[facility] ?: 1
        val cost = 450_000L + level * 150_000L
        require(state.finance.budget >= cost) { "Orçamento insuficiente" }
        val weeks = durationWeeks(component)
        val project = DevelopmentProject(component, remainingWeeks = weeks, totalWeeks = weeks, level = level)
        return state.copy(
            car = state.car.copy(activeProject = project),
            finance = state.finance.transact(-cost, "P&D ${componentLabel(component)} • ${weeks} semanas")
        )
    }

    /** Advance exactly the number of elapsed calendar weeks. */
    fun advanceWeeks(state: TeamManagerState, weeks: Int): TeamManagerState {
        if (weeks <= 0) return state
        var current = state
        repeat(weeks) {
            val p = current.car.activeProject ?: return current
            current = if (p.remainingWeeks > 1) {
                current.copy(car = current.car.copy(activeProject = p.copy(remainingWeeks = p.remainingWeeks - 1)))
            } else {
                val bonus = 1 + p.level / 2
                val c = when (p.component) {
                    CarComponent.ENGINE -> current.car.copy(engine = current.car.engine + bonus, electricPowerUnit = current.car.electricPowerUnit, activeProject = null)
                    CarComponent.CHASSIS -> current.car.copy(chassis = current.car.chassis + bonus, activeProject = null)
                    CarComponent.FRONT_WING -> current.car.copy(frontWing = current.car.frontWing + bonus, aerodynamics = maxOf(current.car.aerodynamics, current.car.frontWing + bonus), activeProject = null)
                    CarComponent.REAR_WING -> current.car.copy(rearWing = current.car.rearWing + bonus, aerodynamics = maxOf(current.car.aerodynamics, current.car.rearWing + bonus), activeProject = null)
                    CarComponent.BRAKES -> current.car.copy(brakes = current.car.brakes + bonus, activeProject = null)
                    CarComponent.ELECTRIC_POWER_UNIT -> current.car.copy(electricPowerUnit = current.car.electricPowerUnit + bonus, activeProject = null)
                }.normalized()
                current.copy(car = c, history = current.history + "Projeto concluído: ${componentLabel(p.component)} (${p.totalWeeks} semanas)")
            }
        }
        return current
    }

    /** Kept for old career integrations: one round now means one elapsed week. */
    fun advanceRound(state: TeamManagerState): TeamManagerState = advanceWeeks(state, 1)

    fun upgradeFacility(state: TeamManagerState, facility: Facility): TeamManagerState {
        val current = state.car.facilities[facility] ?: 1
        require(current < 10) { "Instalação já está no nível máximo" }
        val cost = 1_000_000L * current
        require(state.finance.budget >= cost) { "Orçamento insuficiente" }
        val facilities = state.car.facilities.toMutableMap(); facilities[facility] = current + 1
        return state.copy(car = state.car.copy(facilities = facilities), finance = state.finance.transact(-cost, "Upgrade ${facility.name} para ${current + 1}"))
    }

    fun componentLevel(car: TeamCarState, component: CarComponent): Int = when (component) {
        CarComponent.ENGINE -> car.engine
        CarComponent.CHASSIS -> car.chassis
        CarComponent.FRONT_WING -> car.frontWing
        CarComponent.REAR_WING -> car.rearWing
        CarComponent.BRAKES -> car.brakes
        CarComponent.ELECTRIC_POWER_UNIT -> car.electricPowerUnit
    }

    private fun componentLabel(component: CarComponent) = when (component) {
        CarComponent.ENGINE -> "Unidade de potência"
        CarComponent.CHASSIS -> "Chassi"
        CarComponent.FRONT_WING -> "Asa dianteira"
        CarComponent.REAR_WING -> "Asa traseira"
        CarComponent.BRAKES -> "Freios"
        CarComponent.ELECTRIC_POWER_UNIT -> "Unidade de potência elétrica"
    }
}
