package com.f1teammanager.core.manager
import kotlin.math.roundToInt

/**
 * Car R&D is measured in real calendar weeks.  The model deliberately makes
 * current-car development meaningful while keeping the next-season program
 * capped so that money alone cannot break the championship.
 */
enum class CarPerformanceClass(val label: String, val referenceInvestment: Long) {
    BACK_OF_GRID("Fim de pelotão", 8_000_000L),
    POOR("Ruim", 25_000_000L),
    AVERAGE("Médio", 45_000_000L),
    GOOD("Bom", 70_000_000L),
    EXCELLENT("Excelente", 110_000_000L),
    TITLE_CONTENDER("Briga pelo título", 150_000_000L)
}

data class NextSeasonCarForecast(
    val currentClass: CarPerformanceClass,
    val referenceInvestment: Long,
    val invested: Long,
    val projectedClass: CarPerformanceClass,
    val status: String,
    val ratio: Double
)

class CarDevelopmentEngine {
    data class DevelopmentOption(
        val intensity: DevelopmentIntensity,
        val weeks: Int,
        val cost: Long,
        val minGain: Int,
        val maxGain: Int
    ) {
        val gain: Int get() = maxGain
    }

    fun durationWeeks(component: CarComponent): Int = 2

    fun options(state: TeamManagerState, component: CarComponent): List<DevelopmentOption> {
        val level = componentLevel(state.car, component)
        val facility = facilityFor(component)
        val facilityLevel = state.car.facilities[facility] ?: 1
        val levelFactor = level.coerceIn(1,100)
        fun cost(base: Long, perLevel: Long) = base + levelFactor * perLevel - (facilityLevel - 1) * 150_000L
        return listOf(
            DevelopmentOption(DevelopmentIntensity.QUICK, 1, 5_000_000L, 2, 5),
            DevelopmentOption(DevelopmentIntensity.STANDARD, 2, 12_000_000L, 4, 8),
            DevelopmentOption(DevelopmentIntensity.ADVANCED, 3, 18_000_000L, 6, 11),
            DevelopmentOption(DevelopmentIntensity.AGGRESSIVE, 4, 25_000_000L, 8, 15)
        )
    }

    /** Weighted random: higher gains are deliberately more likely, but the minimum remains possible. */
    private fun weightedGain(min: Int, max: Int): Int {
        val values = (min..max).toList()
        val weighted = values.flatMapIndexed { index, value -> List(index + 1) { value } }
        return weighted.random()
    }

    /** Compatibility path: the normal 2-week development. */
    fun start(state: TeamManagerState, component: CarComponent): TeamManagerState =
        start(state, component, DevelopmentIntensity.STANDARD)

    fun start(state: TeamManagerState, component: CarComponent, intensity: DevelopmentIntensity): TeamManagerState {
        require(state.car.activeProject == null) { "Já existe um projeto em desenvolvimento" }
        require(state.car.seasonDevelopmentGain < 140) { "Limite anual de desenvolvimento atingido" }
        val option = options(state, component).first { it.intensity == intensity }
        val remainingSeason = 140 - state.car.seasonDevelopmentGain
        val remainingComponent = 100 - componentLevel(state.car, component)
        val actualGain = weightedGain(option.minGain, option.maxGain)
            .coerceAtMost(remainingSeason)
            .coerceAtMost(remainingComponent)
        require(actualGain > 0) { "Limite anual ou do componente atingido" }
        require(state.finance.budget >= option.cost) { "Orçamento insuficiente" }
        val technical = TechnicalInvestmentEngine.ensureSeason(state.technicalInvestment, state.season, TechnicalInvestmentEngine.seasonRanking(state.playerTeamId, state.car)[state.playerTeamId] ?: 40)
        val technicalAfter = technical.withSpend(TechnicalInvestmentCategory.RESEARCH_DESIGN, option.cost)
        val level = state.car.facilities[facilityFor(component)] ?: 1
        val project = DevelopmentProject(
            component = component,
            remainingWeeks = option.weeks,
            totalWeeks = option.weeks,
            level = level,
            intensity = intensity,
            expectedGain = actualGain,
            cost = option.cost
        )
        return state.copy(
            car = state.car.copy(activeProject = project),
            technicalInvestment = technicalAfter,
            finance = FinanceEngine().applyCashDebitFinance(state.finance, option.cost, "P&D ${componentLabel(component)} • ${option.weeks} semana(s) • +$actualGain")
        )
    }

    /** Advance exactly the number of elapsed calendar weeks. */
    fun advanceWeeks(state: TeamManagerState, weeks: Int): TeamManagerState {
        if (weeks <= 0) return state
        var current = state
        repeat(weeks) {
            val p = current.car.activeProject ?: return current
            current = if (p.remainingWeeks > 1) {
                current.copy(car = current.car.copy(activeProject = p.copy(remainingWeeks = p.remainingWeeks - 1)))
            } else {
                val gain = p.expectedGain.coerceAtLeast(1)
                val c = when (p.component) {
                    CarComponent.ENGINE -> current.car.copy(engine = current.car.engine + gain, activeProject = null)
                    CarComponent.CHASSIS -> current.car.copy(chassis = current.car.chassis + gain, activeProject = null)
                    CarComponent.FRONT_WING -> current.car.copy(frontWing = current.car.frontWing + gain, aerodynamics = maxOf(current.car.aerodynamics, current.car.frontWing + gain), activeProject = null)
                    CarComponent.REAR_WING -> current.car.copy(rearWing = current.car.rearWing + gain, aerodynamics = maxOf(current.car.aerodynamics, current.car.rearWing + gain), activeProject = null)
                    CarComponent.BRAKES -> current.car.copy(brakes = current.car.brakes + gain, activeProject = null)
                    CarComponent.ELECTRIC_POWER_UNIT -> current.car.copy(electricPowerUnit = current.car.electricPowerUnit + gain, activeProject = null)
                }.copy(
                    developmentKnowledge = current.car.developmentKnowledge.toMutableMap().apply {
                        this[p.component] = ((this[p.component] ?: 0) + 1).coerceAtMost(8)
                    },
                    seasonDevelopmentGain = (current.car.seasonDevelopmentGain + gain).coerceAtMost(140)
                ).normalized()
                current.copy(car = c, history = current.history + "Projeto concluído: ${componentLabel(p.component)} (+$gain, ${p.totalWeeks} semana(s))")
            }
        }
        return current
    }

    /**
     * Returns true physical performance on the 0–100 scale. Zero means no developed
     * components yet. Legacy investment references still have a minimum cost tier.
     */
    fun carOverall(car: TeamCarState, garage: TeamGarage? = null): Int {
        val overall = garage?.teamAverageOverall ?: listOf(
            car.engine, car.chassis, car.frontWing, car.rearWing,
            car.brakes, car.electricPowerUnit
        ).average().roundToInt()
        return overall.coerceIn(0, 100)
    }

    fun performanceClass(car: TeamCarState, garage: TeamGarage? = null): CarPerformanceClass {
        return performanceClassForOverall(carOverall(car, garage))
    }

    /** Class labels are tiered, but the reference amount moves continuously with exact Overall. */
    fun performanceClassForOverall(overall: Int): CarPerformanceClass = when (overall.coerceIn(40, 100)) {
        in 40..49 -> CarPerformanceClass.BACK_OF_GRID
        in 50..59 -> CarPerformanceClass.POOR
        in 60..69 -> CarPerformanceClass.AVERAGE
        in 70..79 -> CarPerformanceClass.GOOD
        in 80..89 -> CarPerformanceClass.EXCELLENT
        else -> CarPerformanceClass.TITLE_CONTENDER
    }

    /**
     * Referência financeira individual para cada Overall inteiro entre 40 e 100.
     * A tabela é explícita: cada ponto tem seu próprio valor, sem compartilhar
     * uma referência fixa com outros Overall da mesma classe. Valores em passos
     * de €100 mil; os limites acordados são €8M (Overall 40) e €150M (Overall 100).
     */
    fun referenceInvestmentForOverall(overall: Int): Long {
        val referencesByOverall = longArrayOf(
            8_000_000L, 9_700_000L, 11_400_000L, 13_100_000L, 14_800_000L,
            16_500_000L, 18_200_000L, 19_900_000L, 21_600_000L, 23_300_000L,
            25_000_000L, 27_000_000L, 29_000_000L, 31_000_000L, 33_000_000L,
            35_000_000L, 37_000_000L, 39_000_000L, 41_000_000L, 43_000_000L,
            45_000_000L, 47_500_000L, 50_000_000L, 52_500_000L, 55_000_000L,
            57_500_000L, 60_000_000L, 62_500_000L, 65_000_000L, 67_500_000L,
            70_000_000L, 74_000_000L, 78_000_000L, 82_000_000L, 86_000_000L,
            90_000_000L, 94_000_000L, 98_000_000L, 102_000_000L, 106_000_000L,
            110_000_000L, 112_000_000L, 114_000_000L, 116_000_000L, 118_000_000L,
            120_000_000L, 122_000_000L, 124_000_000L, 126_000_000L, 128_000_000L,
            130_000_000L, 132_000_000L, 134_000_000L, 136_000_000L, 138_000_000L,
            140_000_000L, 142_000_000L, 144_000_000L, 146_000_000L, 148_000_000L,
            150_000_000L
        )
        return referencesByOverall[overall.coerceIn(40, 100) - 40]
    }

    fun nextSeasonForecast(state: TeamManagerState): NextSeasonCarForecast {
        val overall = carOverall(state.car, state.garage)
        val current = performanceClassForOverall(overall)
        val reference = referenceInvestmentForOverall(overall)
        val invested = state.car.nextSeasonInvestment
        val ratio = if (reference <= 0L) 0.0 else invested.toDouble() / reference.toDouble()
        val currentIndex = current.ordinal
        val projectedIndex = when {
            invested == 0L || ratio < 0.50 -> (currentIndex - 2).coerceAtLeast(0)
            ratio < 0.80 -> (currentIndex - 1).coerceAtLeast(0)
            ratio < 1.20 -> currentIndex
            ratio < 1.50 -> (currentIndex + 1).coerceAtMost(CarPerformanceClass.values().lastIndex)
            else -> (currentIndex + 2).coerceAtMost(CarPerformanceClass.values().lastIndex)
        }
        val status = when {
            invested == 0L -> "Sem investimento: alto risco de perder desempenho"
            ratio < 0.50 -> "Investimento muito abaixo da referência"
            ratio < 0.80 -> "Investimento abaixo do necessário para manter a força"
            ratio < 1.20 -> "Faixa de manutenção da classe atual"
            ratio < 1.50 -> "Potencial de subir uma classe"
            else -> "Potencial de subir até duas classes"
        }
        return NextSeasonCarForecast(current, reference, invested, CarPerformanceClass.values()[projectedIndex], status, ratio)
    }

    /**
     * Canonical investment-to-effect conversion shared by the forecast and the
     * actual season transition. This guarantees the exact Overall reference is
     * used when the next-season car is created, not only in the UI forecast.
     */
    fun nextSeasonInvestmentSteps(overall: Int, invested: Long): Int {
        if (invested <= 0L) return 0
        val reference = referenceInvestmentForOverall(overall)
        val ratio = invested.toDouble() / reference.toDouble()
        return when {
            ratio < 0.50 -> 2
            ratio < 0.80 -> 3
            ratio < 1.20 -> 5
            ratio < 1.50 -> 6
            else -> 7
        }
    }

    fun nextSeasonInvestmentCap(car: TeamCarState, garage: TeamGarage? = null): Long {
        // V420: all teams can invest up to the global €150M ceiling;
        // current class determines the reference investment, not the absolute cap.
        return 150_000_000L
    }

    fun investNextSeason(state: TeamManagerState, amount: Long): TeamManagerState {
        require(amount > 0) { "Investimento inválido" }
        val cap = nextSeasonInvestmentCap(state.car, state.garage)
        val room = cap - state.car.nextSeasonInvestment
        require(amount <= room) { "O limite absoluto de investimento no próximo carro é € ${cap}" }
        val budgetBase = state.car.nextSeasonInvestmentBudgetBase.takeIf { it > 0L }
            ?: (state.finance.budget + state.car.nextSeasonInvestment).coerceAtLeast(0L)
        // The former per-phase percentage cap was removed. Only the protected
        // operational reserve and the independent absolute ceiling remain.
        require(state.finance.budget - amount >= SeasonInvestmentPolicy.protectedCash(state.finance.budget)) {
            "Investimento bloqueado para preservar o caixa operacional da temporada atual."
        }
        return state.copy(
            car = state.car.copy(
                nextSeasonInvestment = state.car.nextSeasonInvestment + amount,
                nextSeasonInvestmentBudgetBase = budgetBase
            ),
            finance = FinanceEngine().applyCashDebitFinance(state.finance, amount, "Investimento carro ${state.season + 1}")
        )
    }

    fun setNextSeasonFocus(state: TeamManagerState, focus: CarDevelopmentFocus): TeamManagerState =
        state.copy(car = state.car.copy(nextSeasonFocus = focus))

    /**
     * Creates the next-generation car.  The old car is partially carried over,
     * technical knowledge is retained, and the reserved next-season investment
     * becomes a concrete starting advantage.
     */
    fun startNextSeason(state: TeamManagerState, nextSeason: Int): TeamManagerState {
        val old = state.car
        val physical = state.garage
        val overall = carOverall(old, physical)
        val currentClass = performanceClassForOverall(overall)
        // Use the exact same Overall-specific rule as the forecast, at the
        // moment the new season car is actually constructed.
        val investmentSteps = nextSeasonInvestmentSteps(overall, old.nextSeasonInvestment)
        fun physicalBase(component: CarComponent): Int = physical?.let {
            ((it.car1.componentValue(component) + it.car2.componentValue(component)) / 2.0).roundToInt()
        } ?: when (component) {
            CarComponent.ENGINE -> old.engine
            CarComponent.CHASSIS -> old.chassis
            CarComponent.FRONT_WING -> old.frontWing
            CarComponent.REAR_WING -> old.rearWing
            CarComponent.BRAKES -> old.brakes
            CarComponent.ELECTRIC_POWER_UNIT -> old.electricPowerUnit
        }
        fun base(component: CarComponent): Int {
            // A blank physical component cannot gain performance from bookkeeping
            // or annual rollover alone. Installed components may benefit from the
            // independent next-season investment/knowledge system.
            val previousValue = physicalBase(component)
            if (previousValue <= 0) return 0
            if (physical != null && physical.car1.componentValue(component) <= 0 && physical.car2.componentValue(component) <= 0) return 0
            // V575: cada atributo transfere individualmente 10% do carro anterior.
            // O arredondamento é feito por componente (ex.: 49 -> +5; 54 -> +5).
            val inherited = (previousValue * 0.10).roundToInt()
            val knowledge = old.developmentKnowledge[component] ?: 0
            val investment = investmentBonus(investmentSteps, old.nextSeasonFocus, component)
            // A regra anual é aplicada pelo orquestrador da virada após a construção.
            // Não aplicar aqui: isso duplicaria a regulamentação no fluxo de carreira.
            return (previousValue + inherited + knowledge + investment + focusBonus(old.nextSeasonFocus, component)).coerceIn(1,100)
        }
        val next = TeamCarState(
            aerodynamics = base(CarComponent.FRONT_WING),
            chassis = base(CarComponent.CHASSIS),
            engine = base(CarComponent.ENGINE),
            reliability = (((physical?.let { ((it.car1.reliability + it.car2.reliability) / 2.0).roundToInt() }) ?: old.reliability) + (investmentSteps / 2)).coerceIn(1,100),
            facilities = old.facilities,
            activeProject = null,
            frontWing = base(CarComponent.FRONT_WING),
            rearWing = base(CarComponent.REAR_WING),
            brakes = base(CarComponent.BRAKES),
            electricPowerUnit = base(CarComponent.ELECTRIC_POWER_UNIT),
            nextSeasonInvestment = 0L,
            nextSeasonInvestmentBudgetBase = 0L,
            nextSeasonFocus = CarDevelopmentFocus.BALANCED,
            developmentKnowledge = old.developmentKnowledge,
            seasonDevelopmentGain = 0
        ).normalized()

        // Preserve the two physical cars independently. Never collapse Car 1/Car 2
        // into an average and recreate two identical cars at the season boundary.
        val nextGarage = physical?.let { g ->
            fun carry(car: PhysicalCar, v:Int, component:CarComponent):Int {
                // New-season finance cannot create physical hardware: only a component
                // with an installed piece can carry/increase performance.
                // Player physical cars use the same canonical component rollover as AI.
                // The orchestrator applies regulation once after both cars are built.
                return nextSeasonPhysicalComponentValue(
                    previousValue = v,
                    installed = component in car.installedPieces,
                    investmentSteps = investmentSteps,
                    focus = old.nextSeasonFocus,
                    component = component,
                    technicalKnowledge = old.developmentKnowledge[component] ?: 0
                )
            }
            fun physicalCar(car:PhysicalCar):PhysicalCar {
                val rel = CarComponent.values().associateWith { component ->
                    (car.componentReliability(component) + investmentSteps / 2).coerceIn(1,100)
                }
                return PhysicalCar(
                    id = car.id,
                    engine = carry(car, car.engine, CarComponent.ENGINE),
                    chassis = carry(car, car.chassis, CarComponent.CHASSIS),
                    frontWing = carry(car, car.frontWing, CarComponent.FRONT_WING),
                    rearWing = carry(car, car.rearWing, CarComponent.REAR_WING),
                    brakes = carry(car, car.brakes, CarComponent.BRAKES),
                    electricPowerUnit = carry(car, car.electricPowerUnit, CarComponent.ELECTRIC_POWER_UNIT),
                    reliability = rel.values.average().roundToInt().coerceIn(1,100),
                    componentReliabilities = rel,
                    installedPieces = car.installedPieces,
                    installedPieceVersions = car.installedPieceVersions
                )
            }
            TeamGarage(physicalCar(g.car1), physicalCar(g.car2))
        }

        val alignedNext = nextGarage?.let { g ->
            val avg = { component: CarComponent -> (g.car1.componentValue(component) + g.car2.componentValue(component)) / 2 }
            next.copy(
                engine = avg(CarComponent.ENGINE),
                chassis = avg(CarComponent.CHASSIS),
                frontWing = avg(CarComponent.FRONT_WING),
                rearWing = avg(CarComponent.REAR_WING),
                aerodynamics = (avg(CarComponent.FRONT_WING) + avg(CarComponent.REAR_WING)) / 2,
                brakes = avg(CarComponent.BRAKES),
                electricPowerUnit = avg(CarComponent.ELECTRIC_POWER_UNIT),
                reliability = ((g.car1.reliability + g.car2.reliability) / 2).coerceIn(1,100)
            ).normalized()
        } ?: next
        return state.copy(
            season = nextSeason,
            round = 1,
            car = alignedNext,
            garage = nextGarage ?: TeamGarageFactory.fromCarState(alignedNext, state.playerTeamId, nextSeason),
            history = state.history + "Novo carro ${nextSeason} criado: investimento €${old.nextSeasonInvestment} aplicado"
        )
    }

    /**
     * Canonical next-season construction used by AI teams.
     * Preserves the previous car's base values and applies the same investment,
     * technical-knowledge and regulation rules without a separate annual regression.
     */
    fun carryAiCarToNextSeason(old: TeamCarState, nextSeason: Int, invested: Long = 0L): TeamCarState {
        val investmentSteps = nextSeasonInvestmentSteps(carOverall(old), invested)
        fun base(v: Int, component: CarComponent): Int {
            if (v <= 0) return 0
            // As equipes de IA seguem a mesma regra: transferência de 10% por atributo.
            val inherited = (v * 0.10).roundToInt()
            val knowledge = old.developmentKnowledge[component] ?: 0
            val investment = investmentBonus(investmentSteps, CarDevelopmentFocus.BALANCED, component)
            // Regulamento aplicado externamente, uma única vez após a construção.
            return (v + inherited + knowledge + investment).coerceIn(1, 100)
        }
        return TeamCarState(
            aerodynamics = base(old.aerodynamics, CarComponent.FRONT_WING),
            chassis = base(old.chassis, CarComponent.CHASSIS),
            engine = base(old.engine, CarComponent.ENGINE),
            reliability = (old.reliability + investmentSteps / 2).coerceIn(1, 100),
            facilities = old.facilities,
            activeProject = null,
            frontWing = base(old.frontWing, CarComponent.FRONT_WING),
            rearWing = base(old.rearWing, CarComponent.REAR_WING),
            brakes = base(old.brakes, CarComponent.BRAKES),
            electricPowerUnit = base(old.electricPowerUnit, CarComponent.ELECTRIC_POWER_UNIT),
            nextSeasonInvestment = 0L,
            nextSeasonInvestmentBudgetBase = 0L,
            nextSeasonFocus = CarDevelopmentFocus.BALANCED,
            developmentKnowledge = old.developmentKnowledge,
            seasonDevelopmentGain = 0
        ).normalized()
    }

    fun upgradeFacility(state: TeamManagerState, facility: Facility): TeamManagerState {
        val current = state.car.facilities[facility] ?: 1
        require(current < 10) { "Instalação já está no nível máximo" }
        val cost = 1_000_000L * current
        require(state.finance.budget >= cost) { "Orçamento insuficiente" }
        val technical = TechnicalInvestmentEngine.ensureSeason(state.technicalInvestment, state.season, TechnicalInvestmentEngine.seasonRanking(state.playerTeamId, state.car)[state.playerTeamId] ?: 40)
        val technicalAfter = technical.withSpend(TechnicalInvestmentCategory.FACILITY_UPGRADE, cost)
        val facilities = state.car.facilities.toMutableMap()
        facilities[facility] = current + 1
        return state.copy(car = state.car.copy(facilities = facilities), technicalInvestment = technicalAfter, finance = FinanceEngine().applyCashDebitFinance(state.finance, cost, "Upgrade ${facility.name} para ${current + 1}"))
    }

    fun regulationForSeason(season: Int): CarRegulationFocus = when (season % 5) {
        2 -> CarRegulationFocus.AERODYNAMICS
        3 -> CarRegulationFocus.POWER
        4 -> CarRegulationFocus.CORNERING
        0 -> CarRegulationFocus.EFFICIENCY
        else -> CarRegulationFocus.BALANCED
    }

    fun componentLevel(car: TeamCarState, component: CarComponent): Int = when (component) {
        CarComponent.ENGINE -> car.engine
        CarComponent.CHASSIS -> car.chassis
        CarComponent.FRONT_WING -> car.frontWing
        CarComponent.REAR_WING -> car.rearWing
        CarComponent.BRAKES -> car.brakes
        CarComponent.ELECTRIC_POWER_UNIT -> car.electricPowerUnit
    }

    fun componentLabel(component: CarComponent) = when (component) {
        CarComponent.ENGINE -> "Motor - ICE"
        CarComponent.CHASSIS -> "Chassi"
        CarComponent.FRONT_WING -> "Asa dianteira"
        CarComponent.REAR_WING -> "Asa traseira"
        CarComponent.BRAKES -> "Freios"
        CarComponent.ELECTRIC_POWER_UNIT -> "MGU-K - ERS"
    }

    private fun facilityFor(component: CarComponent): Facility = when (component) {
        CarComponent.ENGINE, CarComponent.ELECTRIC_POWER_UNIT -> Facility.TESTING
        CarComponent.CHASSIS, CarComponent.BRAKES -> Facility.FACTORY
        CarComponent.FRONT_WING, CarComponent.REAR_WING -> Facility.WIND_TUNNEL
    }

    private fun investmentBonus(steps:Int, focus:CarDevelopmentFocus, component:CarComponent): Int {
        if (steps <= 0) return 0
        val primary = when (focus) {
            CarDevelopmentFocus.BALANCED -> component in setOf(CarComponent.ENGINE, CarComponent.CHASSIS, CarComponent.FRONT_WING, CarComponent.REAR_WING, CarComponent.BRAKES, CarComponent.ELECTRIC_POWER_UNIT)
            CarDevelopmentFocus.POWER -> component == CarComponent.ENGINE || component == CarComponent.ELECTRIC_POWER_UNIT
            CarDevelopmentFocus.AERODYNAMICS -> component == CarComponent.FRONT_WING || component == CarComponent.REAR_WING
            CarDevelopmentFocus.CORNERING -> component == CarComponent.CHASSIS || component == CarComponent.BRAKES
        }
        return when {
            focus == CarDevelopmentFocus.BALANCED -> (steps / 2).coerceAtMost(3)
            primary -> ((steps + 1) / 2).coerceAtMost(4)
            else -> (steps / 3).coerceAtMost(2)
        }
    }

    fun aiBalancedInvestmentBonus(steps: Int, component: CarComponent): Int = investmentBonus(steps, CarDevelopmentFocus.BALANCED, component)

    /**
     * Single canonical component rollover rule shared by player and AI physical cars.
     * The old component's own value is used (never a team average); only installed
     * hardware carries over. Annual regulation is deliberately applied by the caller
     * after all components have been constructed.
     */
    fun nextSeasonPhysicalComponentValue(
        previousValue: Int,
        installed: Boolean,
        investmentSteps: Int,
        focus: CarDevelopmentFocus,
        component: CarComponent,
        technicalKnowledge: Int = 0
    ): Int {
        if (!installed || previousValue <= 0) return 0
        val inherited = (previousValue * 0.10).roundToInt()
        val investment = investmentBonus(investmentSteps, focus, component)
        return (previousValue + inherited + technicalKnowledge + investment + focusBonus(focus, component))
            .coerceIn(1, 100)
    }

    private fun focusBonus(focus: CarDevelopmentFocus, component: CarComponent): Int = when (focus) {
        CarDevelopmentFocus.BALANCED -> 0
        CarDevelopmentFocus.POWER -> if (component == CarComponent.ENGINE || component == CarComponent.ELECTRIC_POWER_UNIT) 1 else 0
        CarDevelopmentFocus.AERODYNAMICS -> if (component == CarComponent.FRONT_WING || component == CarComponent.REAR_WING) 1 else 0
        CarDevelopmentFocus.CORNERING -> if (component == CarComponent.CHASSIS || component == CarComponent.BRAKES) 1 else 0
    }

    private fun regulationBonus(regulation:CarRegulationFocus, component:CarComponent):Int = when (regulation) {
        CarRegulationFocus.AERODYNAMICS -> if (component == CarComponent.FRONT_WING || component == CarComponent.REAR_WING) 1 else 0
        CarRegulationFocus.POWER -> if (component == CarComponent.ENGINE || component == CarComponent.ELECTRIC_POWER_UNIT) 1 else 0
        CarRegulationFocus.CORNERING -> if (component == CarComponent.CHASSIS || component == CarComponent.BRAKES) 1 else 0
        CarRegulationFocus.EFFICIENCY -> if (component == CarComponent.ELECTRIC_POWER_UNIT || component == CarComponent.ENGINE) 1 else 0
        CarRegulationFocus.BALANCED -> 0
    }
}
