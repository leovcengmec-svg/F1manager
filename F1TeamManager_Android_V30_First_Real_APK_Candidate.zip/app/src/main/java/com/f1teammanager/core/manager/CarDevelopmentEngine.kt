package com.f1teammanager.core.manager
import kotlin.math.roundToInt

/**
 * Car R&D is measured in real calendar weeks.  The model deliberately makes
 * current-car development meaningful while keeping the next-season program
 * capped so that money alone cannot break the championship.
 */
enum class CarPerformanceClass(val label: String, val referenceInvestment: Long) {
    BACK_OF_GRID("Fim de pelotão", 8_000_000L),
    POOR("Ruim", 25_000_000L),
    AVERAGE("Médio", 45_000_000L),
    GOOD("Bom", 70_000_000L),
    EXCELLENT("Excelente", 110_000_000L),
    TITLE_CONTENDER("Briga pelo título", 150_000_000L)
}

data class NextSeasonCarForecast(
    val currentClass: CarPerformanceClass,
    val referenceInvestment: Long,
    val invested: Long,
    val projectedClass: CarPerformanceClass,
    val status: String,
    val ratio: Double,
    val projectedOverall: Int = 0
)

class CarDevelopmentEngine {
    companion object {
        /** Maximum attribute-point budget for the weakest cars; stronger cars receive less headroom. */
        const val MAX_SEASON_DEVELOPMENT_GAIN = 42

        /**
         * Diminishing annual development capacity. The value counts attribute points
         * across all six components, so 42 points represent at most about +7 car Overall.
         * High-performing teams cannot convert the same budget into the same leap as a
         * rebuilding team; research costs and per-component diminishing returns still apply.
         */
        fun seasonDevelopmentLimit(overall: Int): Int = when (overall.coerceIn(0, 100)) {
            in 0..59 -> 42
            in 60..74 -> 36
            in 75..84 -> 30
            in 85..92 -> 24
            else -> 18
        }
    }

    data class DevelopmentOption(
        val intensity: DevelopmentIntensity,
        val weeks: Int,
        val cost: Long,
        val minGain: Int,
        val maxGain: Int
    ) {
        val gain: Int get() = maxGain
    }

    fun durationWeeks(component: CarComponent): Int = 2

    fun options(state: TeamManagerState, component: CarComponent): List<DevelopmentOption> {
        val level = componentLevel(state.car, component)
        val facility = facilityFor(component)
        val facilityLevel = state.car.facilities[facility] ?: 1
        val levelFactor = level.coerceIn(40,100)
        val gainFactor = when (levelFactor) {
            in 0..59 -> 1.00
            in 60..69 -> 0.90
            in 70..79 -> 0.80
            in 80..89 -> 0.65
            in 90..94 -> 0.50
            in 95..99 -> 0.35
            else -> 0.25
        }
        val costFactor = 1.0 + ((levelFactor - 60).coerceAtLeast(0) * 0.01)
        fun scaledGain(value: Int) = (value * gainFactor).roundToInt().coerceAtLeast(1)
        fun scaledCost(base: Long) = (base * costFactor).toLong().coerceAtLeast(1L)
        return listOf(
            DevelopmentOption(DevelopmentIntensity.QUICK, 1, scaledCost(5_000_000L), scaledGain(2), scaledGain(5)),
            DevelopmentOption(DevelopmentIntensity.STANDARD, 2, scaledCost(12_000_000L), scaledGain(4), scaledGain(8)),
            DevelopmentOption(DevelopmentIntensity.ADVANCED, 3, scaledCost(18_000_000L), scaledGain(6), scaledGain(11)),
            DevelopmentOption(DevelopmentIntensity.AGGRESSIVE, 4, scaledCost(25_000_000L), scaledGain(8), scaledGain(15))
        )
    }

    /** Weighted random: higher gains are deliberately more likely, but the minimum remains possible. */
    private fun weightedGain(min: Int, max: Int): Int {
        val values = (min..max).toList()
        val weighted = values.flatMapIndexed { index, value -> List(index + 1) { value } }
        return weighted.random()
    }

    /** Compatibility path: the normal 2-week development. */
    fun start(state: TeamManagerState, component: CarComponent): TeamManagerState =
        start(state, component, DevelopmentIntensity.STANDARD)

    fun start(state: TeamManagerState, component: CarComponent, intensity: DevelopmentIntensity): TeamManagerState {
        require(state.car.activeProject == null) { "Já existe um projeto em desenvolvimento" }
        val currentOverall = carOverall(state.car, state.garage)
        val annualLimit = seasonDevelopmentLimit(currentOverall)
        require(state.car.seasonDevelopmentGain < annualLimit) {
            "Limite anual de desenvolvimento atingido para Overall $currentOverall ($annualLimit pontos de evolução)."
        }
        val option = options(state, component).first { it.intensity == intensity }
        val remainingSeason = annualLimit - state.car.seasonDevelopmentGain
        val remainingComponent = 100 - componentLevel(state.car, component)
        val actualGain = weightedGain(option.minGain, option.maxGain)
            .coerceAtMost(remainingSeason)
            .coerceAtMost(remainingComponent)
        require(actualGain > 0) { "Limite anual ou do componente atingido" }
        require(state.finance.budget >= option.cost) { "Orçamento insuficiente" }
        val technical = TechnicalInvestmentEngine.ensureSeason(state.technicalInvestment, state.season, TechnicalInvestmentEngine.seasonRanking(state.playerTeamId, state.car)[state.playerTeamId] ?: 40)
        val annualRemaining = SeasonInvestmentPolicy.remainingAnnualTechnicalEnvelope(
            technical.annualCap, technical.totalSpent, state.car.nextSeasonInvestment
        )
        require(option.cost <= annualRemaining) { "Limite anual de €${technical.annualCap / 1_000_000}M para P&D e desenvolvimento do carro atual atingido." }
        val technicalAfter = technical.withSpend(TechnicalInvestmentCategory.RESEARCH_DESIGN, option.cost)
        val level = state.car.facilities[facilityFor(component)] ?: 1
        val project = DevelopmentProject(
            component = component,
            remainingWeeks = option.weeks,
            totalWeeks = option.weeks,
            level = level,
            intensity = intensity,
            expectedGain = actualGain,
            cost = option.cost
        )
        return state.copy(
            car = state.car.copy(activeProject = project),
            technicalInvestment = technicalAfter,
            finance = FinanceEngine().applyCashDebitFinance(state.finance, option.cost, "P&D ${componentLabel(component)} • ${option.weeks} semana(s) • +$actualGain")
        )
    }

    /** Advance exactly the number of elapsed calendar weeks. */
    fun advanceWeeks(state: TeamManagerState, weeks: Int): TeamManagerState {
        if (weeks <= 0) return state
        var current = state
        repeat(weeks) {
            val p = current.car.activeProject ?: return current
            current = if (p.remainingWeeks > 1) {
                current.copy(car = current.car.copy(activeProject = p.copy(remainingWeeks = p.remainingWeeks - 1)))
            } else {
                val gain = p.expectedGain.coerceAtLeast(1)
                val c = when (p.component) {
                    CarComponent.ENGINE -> current.car.copy(engine = current.car.engine + gain, activeProject = null)
                    CarComponent.CHASSIS -> current.car.copy(chassis = current.car.chassis + gain, activeProject = null)
                    CarComponent.FRONT_WING -> current.car.copy(frontWing = current.car.frontWing + gain, aerodynamics = maxOf(current.car.aerodynamics, current.car.frontWing + gain), activeProject = null)
                    CarComponent.REAR_WING -> current.car.copy(rearWing = current.car.rearWing + gain, aerodynamics = maxOf(current.car.aerodynamics, current.car.rearWing + gain), activeProject = null)
                    CarComponent.BRAKES -> current.car.copy(brakes = current.car.brakes + gain, activeProject = null)
                    CarComponent.ELECTRIC_POWER_UNIT -> current.car.copy(electricPowerUnit = current.car.electricPowerUnit + gain, activeProject = null)
                }.copy(
                    developmentKnowledge = current.car.developmentKnowledge.toMutableMap().apply {
                        this[p.component] = ((this[p.component] ?: 0) + 1).coerceAtMost(8)
                    },
                    seasonDevelopmentGain = (current.car.seasonDevelopmentGain + gain).coerceAtMost(MAX_SEASON_DEVELOPMENT_GAIN)
                ).normalized()
                current.copy(car = c, history = current.history + "Projeto concluído: ${componentLabel(p.component)} (+$gain, ${p.totalWeeks} semana(s))")
            }
        }
        return current
    }

    /**
     * Returns permanent physical performance on the 40–100 scale. A blank/legacy
     * component is normalized to the universal baseline floor; missing hardware is
     * represented separately by installedPieces. Legacy investment references still
     * have a minimum cost tier.
     */
    fun carOverall(car: TeamCarState, garage: TeamGarage? = null): Int {
        val overall = garage?.teamAverageOverall ?: listOf(
            car.engine, car.chassis, car.frontWing, car.rearWing,
            car.brakes, car.electricPowerUnit
        ).average().roundToInt()
        return overall.coerceIn(40, 100)
    }

    fun performanceClass(car: TeamCarState, garage: TeamGarage? = null): CarPerformanceClass {
        return performanceClassForOverall(carOverall(car, garage))
    }

    /** Class labels are tiered, but the reference amount moves continuously with exact Overall. */
    fun performanceClassForOverall(overall: Int): CarPerformanceClass = when (overall.coerceIn(40, 100)) {
        in 40..49 -> CarPerformanceClass.BACK_OF_GRID
        in 50..59 -> CarPerformanceClass.POOR
        in 60..69 -> CarPerformanceClass.AVERAGE
        in 70..79 -> CarPerformanceClass.GOOD
        in 80..89 -> CarPerformanceClass.EXCELLENT
        else -> CarPerformanceClass.TITLE_CONTENDER
    }

    /**
     * Referência financeira para cada Overall de 0 a 100.
     * A tabela aprovada permanece exata entre Overall 40 e 100 (€8M–€150M).
     * A faixa abaixo do mínimo é uma extensão linear coerente: €0 corresponde
     * a Overall 0 e €8M a Overall 40, permitindo que investimento zero também
     * passe pela mesma regra de construção em vez de preservar a força antiga.
     */
    fun referenceInvestmentForOverall(overall: Int): Long {
        val boundedOverall = overall.coerceIn(0, 100)
        if (boundedOverall < 40) return (8_000_000L * boundedOverall) / 40L
        val referencesByOverall = longArrayOf(
            8_000_000L, 9_000_000L, 10_000_000L, 12_000_000L, 13_000_000L,
            14_000_000L, 16_000_000L, 18_000_000L, 20_000_000L, 22_000_000L,
            25_000_000L, 27_000_000L, 29_000_000L, 31_000_000L, 33_000_000L,
            35_000_000L, 37_000_000L, 39_000_000L, 41_000_000L, 43_000_000L,
            45_000_000L, 47_000_000L, 49_000_000L, 51_000_000L, 54_000_000L,
            56_000_000L, 59_000_000L, 62_000_000L, 65_000_000L, 67_000_000L,
            70_000_000L, 73_000_000L, 76_000_000L, 79_000_000L, 83_000_000L,
            86_000_000L, 90_000_000L, 95_000_000L, 100_000_000L, 105_000_000L,
            110_000_000L, 112_000_000L, 114_000_000L, 116_000_000L, 118_000_000L,
            120_000_000L, 122_000_000L, 124_000_000L, 126_000_000L, 128_000_000L,
            130_000_000L, 132_000_000L, 134_000_000L, 136_000_000L, 138_000_000L,
            140_000_000L, 142_000_000L, 144_000_000L, 146_000_000L, 148_000_000L,
            150_000_000L
        )
        return referencesByOverall[boundedOverall - 40]
    }

    /**
     * Converts every non-negative investment through one universal construction
     * ladder. From €0 to below €8M, the base scales linearly from Overall 0 to 39;
     * at €8M the approved Overall 40 row begins. Above that, use the exact approved
     * table and choose the greatest row fully funded. Negative values are invalid.
     */
    fun constructionBaseOverallForInvestment(invested: Long): Int? {
        if (invested < 0L) return null
        val amount = invested.coerceAtMost(150_000_000L)
        if (amount < 8_000_000L) {
            return ((amount * 40L) / 8_000_000L).toInt().coerceIn(0, 39)
        }
        return (100 downTo 40).firstOrNull { amount >= referenceInvestmentForOverall(it) } ?: 40
    }

    /**
     * Universal next-car target: the investment ladder is applied directly.
     * There is no free construction bonus at the season boundary. The physical
     * garage still enforces its 40-point installed-component floor.
     */
    fun constructionOverallForInvestment(invested: Long): Int? {
        val base = constructionBaseOverallForInvestment(invested) ?: return null
        return base.coerceIn(40, 100)
    }

    /**
     * Converts the AI's shortfall against its planned next-car investment into
     * component attribute loss. Every missing €1M costs one attribute point;
     * the loss is capped at 10 points per component for a single rollover.
     */
    fun aiUnderinvestmentPenaltyPoints(currentOverall: Int, invested: Long): Int {
        val targetInvestment = investmentReferenceForNextSeasonTarget(
            currentOverall,
            NextSeasonCarGrowthPolicy.maximumGain(currentOverall)
        )
        val shortfall = (targetInvestment - invested.coerceAtLeast(0L)).coerceAtLeast(0L)
        if (shortfall == 0L) return 0
        val missingMillions = ((shortfall + 999_999L) / 1_000_000L).coerceAtLeast(1L)
        return missingMillions.coerceAtMost(10L).toInt()
    }

    /** Compatibility result only; the physical AI rollover uses per-component loss. */
    fun aiContinuityFloorOverall(previousOverall: Int, invested: Long): Int {
        val previous = previousOverall.coerceIn(40, 100)
        return (previous - aiUnderinvestmentPenaltyPoints(previous, invested)).coerceAtLeast(40)
    }

    fun aiConstructionOverallForInvestment(invested: Long, previousOverall: Int): Int {
        val previous = previousOverall.coerceIn(40, 100)
        val targetInvestment = investmentReferenceForNextSeasonTarget(
            previous, NextSeasonCarGrowthPolicy.maximumGain(previous)
        )
        val target = constructionOverallForInvestment(targetInvestment) ?: previous
        return (target - aiUnderinvestmentPenaltyPoints(previous, invested)).coerceIn(40, 100)
    }

    /** Build the planned AI car first, then apply the shortfall to every installed component. */
    fun buildAiNextSeasonGarage(
        previousGarage: TeamGarage,
        invested: Long,
        technicalKnowledge: Map<CarComponent, Int> = emptyMap()
    ): TeamGarage {
        val previousOverall = previousGarage.teamAverageOverall.coerceIn(40, 100)
        val maximumOverall = (previousOverall + NextSeasonCarGrowthPolicy.maximumGain(previousOverall)).coerceAtMost(100)
        val targetInvestment = investmentReferenceForNextSeasonTarget(
            previousOverall, NextSeasonCarGrowthPolicy.maximumGain(previousOverall)
        )
        val builtToPlan = buildNextSeasonGarage(
            previousGarage = previousGarage,
            invested = targetInvestment,
            focus = CarDevelopmentFocus.BALANCED,
            technicalKnowledge = technicalKnowledge,
            maximumOverall = maximumOverall
        )
        return applyAiUnderinvestmentPenalty(
            builtToPlan,
            aiUnderinvestmentPenaltyPoints(previousOverall, invested)
        )
    }

    fun buildAiNextSeasonLegacyCar(
        previousCar: TeamCarState,
        invested: Long
    ): TeamCarState {
        val previousOverall = carOverall(previousCar)
        val maximumOverall = (previousOverall + NextSeasonCarGrowthPolicy.maximumGain(previousOverall)).coerceAtMost(100)
        val targetInvestment = investmentReferenceForNextSeasonTarget(
            previousOverall, NextSeasonCarGrowthPolicy.maximumGain(previousOverall)
        )
        val builtToPlan = buildNextSeasonLegacyCar(
            old = previousCar,
            invested = targetInvestment,
            focus = CarDevelopmentFocus.BALANCED,
            technicalKnowledge = previousCar.developmentKnowledge,
            maximumOverall = maximumOverall
        )
        val loss = aiUnderinvestmentPenaltyPoints(previousOverall, invested)
        return builtToPlan.copy(
            engine = penalizeComponent(builtToPlan.engine, loss),
            chassis = penalizeComponent(builtToPlan.chassis, loss),
            frontWing = penalizeComponent(builtToPlan.frontWing, loss),
            rearWing = penalizeComponent(builtToPlan.rearWing, loss),
            aerodynamics = ((penalizeComponent(builtToPlan.frontWing, loss) + penalizeComponent(builtToPlan.rearWing, loss)) / 2.0).roundToInt(),
            brakes = penalizeComponent(builtToPlan.brakes, loss),
            electricPowerUnit = penalizeComponent(builtToPlan.electricPowerUnit, loss)
        ).normalized()
    }

    private fun penalizeComponent(value: Int, points: Int): Int =
        if (value <= 0) 0 else (value - points.coerceIn(0, 10)).coerceIn(40, 100)

    private fun applyAiUnderinvestmentPenalty(garage: TeamGarage, points: Int): TeamGarage {
        if (points <= 0) return garage.normalized()
        fun penalize(car: PhysicalCar): PhysicalCar = car.copy(
            engine = if (CarComponent.ENGINE in car.installedPieces) penalizeComponent(car.engine, points) else 0,
            chassis = if (CarComponent.CHASSIS in car.installedPieces) penalizeComponent(car.chassis, points) else 0,
            frontWing = if (CarComponent.FRONT_WING in car.installedPieces) penalizeComponent(car.frontWing, points) else 0,
            rearWing = if (CarComponent.REAR_WING in car.installedPieces) penalizeComponent(car.rearWing, points) else 0,
            brakes = if (CarComponent.BRAKES in car.installedPieces) penalizeComponent(car.brakes, points) else 0,
            electricPowerUnit = if (CarComponent.ELECTRIC_POWER_UNIT in car.installedPieces) penalizeComponent(car.electricPowerUnit, points) else 0
        )
        return TeamGarage(penalize(garage.car1), penalize(garage.car2)).normalized()
    }

    /**
     * Chooses the least investment-table reference whose direct construction result
     * most closely matches a desired, bounded next-season gain. Ties prefer
     * not to exceed the target and then prefer the cheaper row. This is intended for
     * AI planning: no bonus is added after the table lookup.
     */
    fun investmentReferenceForNextSeasonTarget(currentOverall: Int, maximumGain: Int): Long {
        val current = currentOverall.coerceIn(40, 100)
        val target = (current + maximumGain.coerceAtLeast(0)).coerceIn(40, 100)
        val rows = (0..100).map { baseOverall ->
            val investment = referenceInvestmentForOverall(baseOverall)
            val builtOverall = constructionOverallForInvestment(investment) ?: 40
            Triple(investment, baseOverall, builtOverall)
        }
        if (maximumGain <= 0) {
            // Strong AI teams use investment to maintain the nearest achievable
            // strength through annual regulation, rather than receiving free growth.
            // If two output levels are equally close, prefer not to exceed the current car.
            return rows.minWithOrNull(
                compareBy<Triple<Long, Int, Int>> { kotlin.math.abs(it.third - current) }
                    .thenBy { if (it.third > current) 1 else 0 }
                    .thenBy { it.first }
            )!!.first
        }
        // Prefer the greatest achievable result that is above the current car but
        // does not exceed the requested endpoint. If table rounding skips every
        // value in that interval, select the smallest next attainable result so an
        // AI team never gets trapped forever on an unreachable Overall value.
        val inRange = rows.filter { it.third > current && it.third <= target }
        val selected = if (inRange.isNotEmpty()) {
            val bestOutput = inRange.maxOf { it.third }
            inRange.filter { it.third == bestOutput }.minBy { it.first }
        } else if (current < 100) {
            val nextOutput = rows.filter { it.third > current }.minOfOrNull { it.third }
            if (nextOutput != null) rows.filter { it.third == nextOutput }.minBy { it.first }
            else rows.filter { it.third >= target }.minBy { it.first }
        } else {
            // At 100, keep the car at the ceiling using the cheapest row that
            // reaches 100 directly; do not automatically spend the €150M row.
            rows.filter { it.third >= target }.minBy { it.first }
        }
        return selected.first
    }

    fun nextSeasonForecast(state: TeamManagerState): NextSeasonCarForecast {
        val overall = carOverall(state.car, state.garage)
        val current = performanceClassForOverall(overall)
        val reference = referenceInvestmentForOverall(overall)
        val invested = state.car.nextSeasonInvestment
        val ratio = if (reference <= 0L) 0.0 else invested.toDouble() / reference.toDouble()
        // Forecast the same physical/legacy path that the season transition will use.
        // This matters when components are absent or already at the 0/100 bounds: the
        // ideal table target may not be physically reachable, so the UI must not promise it.
        val projectedOverall = when {
            state.garage != null -> buildNextSeasonGarage(
                previousGarage = state.garage,
                invested = invested,
                focus = state.car.nextSeasonFocus,
                technicalKnowledge = state.car.developmentKnowledge,
                maximumOverall = (overall + NextSeasonCarGrowthPolicy.maximumGain(overall)).coerceAtMost(100)
            ).teamAverageOverall
            else -> carOverall(buildNextSeasonLegacyCar(
                old = state.car,
                invested = invested,
                focus = state.car.nextSeasonFocus,
                technicalKnowledge = state.car.developmentKnowledge,
                maximumOverall = (overall + NextSeasonCarGrowthPolicy.maximumGain(overall)).coerceAtMost(100)
            ))
        }
        val projectedClass = performanceClassForOverall(projectedOverall)
        val delta = projectedOverall - overall
        val status = when {
            invested <= 0L -> "Sem investimento: tabela leva o carro ao nível mínimo; Overall físico previsto $projectedOverall"
            delta > 0 -> "Tabela de investimento: +$delta Overall antes do regulamento"
            delta < 0 -> "Investimento abaixo do nível atual: previsão de $delta Overall na construção"
            else -> "Investimento converte diretamente para o Overall físico atual"
        }
        return NextSeasonCarForecast(current, reference, invested, projectedClass, status, ratio, projectedOverall)
    }

    /**
     * Legacy stepped-effect indicator retained for older saves/audit references.
     * It is NOT used by universal investment-table construction; the table now defines
     * the complete target Overall without a free construction bonus.
     */
    fun nextSeasonInvestmentSteps(overall: Int, invested: Long): Int {
        if (invested <= 0L) return 0
        val reference = referenceInvestmentForOverall(overall)
        val ratio = invested.toDouble() / reference.toDouble()
        return when {
            ratio < 0.50 -> 2
            ratio < 0.80 -> 3
            ratio < 1.20 -> 5
            ratio < 1.50 -> 6
            else -> 7
        }
    }

    fun nextSeasonInvestmentCap(car: TeamCarState, garage: TeamGarage? = null): Long {
        // V420: all teams can invest up to the global €150M ceiling;
        // current class determines the reference investment, not the absolute cap.
        return 150_000_000L
    }

    fun investNextSeason(state: TeamManagerState, amount: Long): TeamManagerState {
        require(amount > 0) { "Investimento inválido" }
        val cap = nextSeasonInvestmentCap(state.car, state.garage)
        val annualCap = SeasonInvestmentPolicy.nextCarAnnualCap()
        val alreadyInvested = state.car.nextSeasonInvestment.coerceAtLeast(0L)
        require(alreadyInvested < annualCap && alreadyInvested < cap) {
            "Trava ativada: o limite anual de investimento no próximo carro foi atingido."
        }
        val room = minOf(cap, annualCap) - alreadyInvested
        require(amount <= room) { "Investimento bloqueado: restam apenas €${room.coerceAtLeast(0L) / 1_000_000}M do limite anual." }
        // Next-season construction has its own annual €150M envelope, independent
        // from the €200M envelope used by current-car development and facilities.
        require(amount <= (annualCap - alreadyInvested).coerceAtLeast(0L)) {
            "Trava ativada: o limite anual de €${annualCap / 1_000_000}M para o próximo carro foi atingido."
        }
        val budgetBase = state.car.nextSeasonInvestmentBudgetBase.takeIf { it > 0L }
            ?: (state.finance.budget + state.car.nextSeasonInvestment).coerceAtLeast(0L)
        // The former per-phase percentage cap was removed. Only the protected
        // operational reserve and the independent absolute ceiling remain.
        require(state.finance.budget - amount >= SeasonInvestmentPolicy.protectedCash(state.finance.budget)) {
            "Investimento bloqueado para preservar o caixa operacional da temporada atual."
        }
        return state.copy(
            car = state.car.copy(
                nextSeasonInvestment = alreadyInvested + amount,
                nextSeasonInvestmentBudgetBase = budgetBase
            ),
            finance = FinanceEngine().applyCashDebitFinance(state.finance, amount, "Investimento carro ${state.season + 1}")
        )
    }

    fun setNextSeasonFocus(state: TeamManagerState, focus: CarDevelopmentFocus): TeamManagerState =
        state.copy(car = state.car.copy(nextSeasonFocus = focus))

    /**
     * Builds the new-season physical garage directly from the universal investment
     * ladder. Every investment amount, including zero, sets the target Overall;
     * knowledge and focus may redistribute component strength but a shared offset
     * keeps the team mean at that target when physically achievable. Uninstalled
     * hardware remains absent; existing part identity and reliability are preserved.
     */
    fun buildNextSeasonGarage(
        previousGarage: TeamGarage,
        invested: Long,
        focus: CarDevelopmentFocus = CarDevelopmentFocus.BALANCED,
        technicalKnowledge: Map<CarComponent, Int> = emptyMap(),
        applyTechnicalSpecialization: Boolean = true,
        minimumOverall: Int? = null,
        maximumOverall: Int? = null
    ): TeamGarage {
        val investmentTarget = constructionOverallForInvestment(invested) ?: return previousGarage.normalized()
        val permittedMaximum = maximumOverall?.coerceIn(40, 100) ?: 100
        val targetOverall = maxOf(investmentTarget.coerceAtMost(permittedMaximum), minimumOverall ?: investmentTarget)
            .coerceIn(40, permittedMaximum)

        fun rawComponentValue(car: PhysicalCar, component: CarComponent): Int {
            val previous = car.componentValue(component)
            if (component !in car.installedPieces || previous <= 0) return 0
            val specialization = if (applyTechnicalSpecialization && targetOverall > 0) {
                (technicalKnowledge[component] ?: 0).coerceIn(0, 8) + focusBonus(focus, component)
            } else 0
            return (previous + specialization).coerceIn(40, 100)
        }
        fun rawCar(car: PhysicalCar): PhysicalCar = car.copy(
            engine = rawComponentValue(car, CarComponent.ENGINE),
            chassis = rawComponentValue(car, CarComponent.CHASSIS),
            frontWing = rawComponentValue(car, CarComponent.FRONT_WING),
            rearWing = rawComponentValue(car, CarComponent.REAR_WING),
            brakes = rawComponentValue(car, CarComponent.BRAKES),
            electricPowerUnit = rawComponentValue(car, CarComponent.ELECTRIC_POWER_UNIT)
        )
        val rawGarage = TeamGarage(rawCar(previousGarage.car1), rawCar(previousGarage.car2))

        fun shiftedCar(car: PhysicalCar, offset: Int): PhysicalCar {
            fun shifted(component: CarComponent): Int {
                val value = car.componentValue(component)
                if (component !in car.installedPieces || value <= 0) return 0
                return (value + offset).coerceIn(40, 100)
            }
            return car.copy(
                engine = shifted(CarComponent.ENGINE),
                chassis = shifted(CarComponent.CHASSIS),
                frontWing = shifted(CarComponent.FRONT_WING),
                rearWing = shifted(CarComponent.REAR_WING),
                brakes = shifted(CarComponent.BRAKES),
                electricPowerUnit = shifted(CarComponent.ELECTRIC_POWER_UNIT)
            )
        }
        fun shiftedGarage(offset: Int) = TeamGarage(
            shiftedCar(rawGarage.car1, offset), shiftedCar(rawGarage.car2, offset)
        )

        // Search a single offset instead of adding another set of gains. Clamping
        // at 0/100 is respected, and the closest achievable Overall is selected
        // if missing pieces make the requested target physically unreachable.
        val candidates = (-100..100).map { offset -> offset to shiftedGarage(offset) }
        val best = candidates.minWithOrNull(
            compareBy<Pair<Int, TeamGarage>> { kotlin.math.abs(it.second.teamAverageOverall - targetOverall) }
                .thenBy { kotlin.math.abs(it.first) }
                .thenBy { it.first }
        )
        return (best?.second ?: rawGarage).normalized()
    }

    /**
     * Legacy summary-car equivalent of the canonical physical build. This path is
     * used for older saves and AI compatibility snapshots; it follows the same
     * universal investment target (including zero), preserves zero/absent components,
     * and normalizes technical specialization without adding it to the final average.
     */
    fun buildNextSeasonLegacyCar(
        old: TeamCarState,
        invested: Long = old.nextSeasonInvestment,
        focus: CarDevelopmentFocus = old.nextSeasonFocus,
        technicalKnowledge: Map<CarComponent, Int> = old.developmentKnowledge,
        applyTechnicalSpecialization: Boolean = true,
        minimumOverall: Int? = null,
        maximumOverall: Int? = null
    ): TeamCarState {
        val investmentTarget = constructionOverallForInvestment(invested)
        val permittedMaximum = maximumOverall?.coerceIn(40, 100) ?: 100
        val targetOverall = investmentTarget?.let {
            maxOf(it.coerceAtMost(permittedMaximum), minimumOverall ?: it).coerceIn(40, permittedMaximum)
        }
        val cleanTracking = old.copy(
            activeProject = null,
            nextSeasonInvestment = 0L,
            nextSeasonInvestmentBudgetBase = 0L,
            nextSeasonFocus = CarDevelopmentFocus.BALANCED,
            seasonDevelopmentGain = 0
        )
        if (targetOverall == null) return cleanTracking.normalized()

        val components = linkedMapOf(
            CarComponent.ENGINE to old.engine,
            CarComponent.CHASSIS to old.chassis,
            CarComponent.FRONT_WING to old.frontWing,
            CarComponent.REAR_WING to old.rearWing,
            CarComponent.BRAKES to old.brakes,
            CarComponent.ELECTRIC_POWER_UNIT to old.electricPowerUnit
        )
        val raw = components.mapValues { (component, previous) ->
            if (previous <= 0) 0 else {
                val specialization = if (applyTechnicalSpecialization && targetOverall > 0) {
                    (technicalKnowledge[component] ?: 0).coerceIn(0, 8) + focusBonus(focus, component)
                } else 0
                (previous + specialization).coerceIn(40, 100)
            }
        }
        fun withOffset(offset: Int): Map<CarComponent, Int> = raw.mapValues { (_, value) ->
            if (value <= 0) 0 else (value + offset).coerceIn(40, 100)
        }
        fun overall(values: Map<CarComponent, Int>) =
            values.values.average().roundToInt().coerceIn(40, 100)
        val candidates = (-100..100).map { offset -> offset to withOffset(offset) }
        val best = candidates.minWithOrNull(
            compareBy<Pair<Int, Map<CarComponent, Int>>> { kotlin.math.abs(overall(it.second) - targetOverall) }
                .thenBy { kotlin.math.abs(it.first) }
                .thenBy { it.first }
        )
        val built = best?.second ?: raw
        val front = built.getValue(CarComponent.FRONT_WING)
        val rear = built.getValue(CarComponent.REAR_WING)
        return cleanTracking.copy(
            aerodynamics = ((front + rear) / 2.0).roundToInt(),
            chassis = built.getValue(CarComponent.CHASSIS),
            engine = built.getValue(CarComponent.ENGINE),
            frontWing = front,
            rearWing = rear,
            brakes = built.getValue(CarComponent.BRAKES),
            electricPowerUnit = built.getValue(CarComponent.ELECTRIC_POWER_UNIT),
            reliability = old.reliability,
            developmentKnowledge = old.developmentKnowledge
        ).normalized()
    }

    /** Creates the player's next-season car using the same table-driven build as AI teams. */
    fun startNextSeason(state: TeamManagerState, nextSeason: Int): TeamManagerState {
        val old = state.car
        val invested = old.nextSeasonInvestment
        val previousGarage = state.garage
        val nextGarage: TeamGarage
        val nextCar: TeamCarState

        val previousOverall = carOverall(old, previousGarage)
        val maximumNextOverall = (previousOverall + NextSeasonCarGrowthPolicy.maximumGain(previousOverall)).coerceAtMost(100)
        if (previousGarage != null) {
            nextGarage = buildNextSeasonGarage(
                previousGarage, invested, old.nextSeasonFocus, old.developmentKnowledge,
                maximumOverall = maximumNextOverall
            )
            fun average(component: CarComponent): Int =
                (nextGarage.car1.componentValue(component) + nextGarage.car2.componentValue(component)) / 2
            val front = average(CarComponent.FRONT_WING)
            val rear = average(CarComponent.REAR_WING)
            nextCar = old.copy(
                aerodynamics = ((front + rear) / 2.0).roundToInt(),
                chassis = average(CarComponent.CHASSIS),
                engine = average(CarComponent.ENGINE),
                reliability = ((nextGarage.car1.reliability + nextGarage.car2.reliability) / 2).coerceIn(40, 100),
                frontWing = front,
                rearWing = rear,
                brakes = average(CarComponent.BRAKES),
                electricPowerUnit = average(CarComponent.ELECTRIC_POWER_UNIT),
                activeProject = null,
                nextSeasonInvestment = 0L,
                nextSeasonInvestmentBudgetBase = 0L,
                nextSeasonFocus = CarDevelopmentFocus.BALANCED,
                developmentKnowledge = old.developmentKnowledge,
                seasonDevelopmentGain = 0
            ).normalized()
        } else {
            nextCar = buildNextSeasonLegacyCar(
                old, invested, old.nextSeasonFocus, old.developmentKnowledge,
                maximumOverall = maximumNextOverall
            )
            nextGarage = TeamGarageFactory.fromCarState(nextCar, state.playerTeamId, nextSeason)
        }

        val target = constructionOverallForInvestment(invested)
        val constructionNote = target?.let { "meta Overall $it/100 (resultado físico ${nextGarage.teamAverageOverall}/100)" } ?: "investimento inválido; meta de construção indisponível"
        return state.copy(
            season = nextSeason,
            round = 1,
            car = nextCar,
            garage = nextGarage,
            history = state.history + "Novo carro $nextSeason criado: investimento €$invested aplicado; $constructionNote"
        )
    }

    /**
     * Compatibility path for AI legacy summaries. The canonical AI physical garage
     * is built by buildNextSeasonGarage; both routes use the same investment target.
     */
    fun carryAiCarToNextSeason(old: TeamCarState, nextSeason: Int, invested: Long = 0L): TeamCarState =
        buildAiNextSeasonLegacyCar(old, invested)

    fun upgradeFacility(state: TeamManagerState, facility: Facility): TeamManagerState {
        val current = state.car.facilities[facility] ?: 1
        require(current < 10) { "Instalação já está no nível máximo" }
        val cost = 1_000_000L * current
        require(state.finance.budget >= cost) { "Orçamento insuficiente" }
        val technical = TechnicalInvestmentEngine.ensureSeason(state.technicalInvestment, state.season, TechnicalInvestmentEngine.seasonRanking(state.playerTeamId, state.car)[state.playerTeamId] ?: 40)
        val annualRemaining = SeasonInvestmentPolicy.remainingAnnualTechnicalEnvelope(
            technical.annualCap, technical.totalSpent, state.car.nextSeasonInvestment
        )
        require(cost <= annualRemaining) { "Limite anual compartilhado de investimento técnico atingido." }
        val technicalAfter = technical.withSpend(TechnicalInvestmentCategory.FACILITY_UPGRADE, cost)
        val facilities = state.car.facilities.toMutableMap()
        facilities[facility] = current + 1
        return state.copy(car = state.car.copy(facilities = facilities), technicalInvestment = technicalAfter, finance = FinanceEngine().applyCashDebitFinance(state.finance, cost, "Upgrade ${facility.name} para ${current + 1}"))
    }

    fun regulationForSeason(season: Int): CarRegulationFocus = when (season % 5) {
        2 -> CarRegulationFocus.AERODYNAMICS
        3 -> CarRegulationFocus.POWER
        4 -> CarRegulationFocus.CORNERING
        0 -> CarRegulationFocus.EFFICIENCY
        else -> CarRegulationFocus.BALANCED
    }

    fun componentLevel(car: TeamCarState, component: CarComponent): Int = when (component) {
        CarComponent.ENGINE -> car.engine
        CarComponent.CHASSIS -> car.chassis
        CarComponent.FRONT_WING -> car.frontWing
        CarComponent.REAR_WING -> car.rearWing
        CarComponent.BRAKES -> car.brakes
        CarComponent.ELECTRIC_POWER_UNIT -> car.electricPowerUnit
    }

    fun componentLabel(component: CarComponent) = when (component) {
        CarComponent.ENGINE -> "Motor - ICE"
        CarComponent.CHASSIS -> "Chassi"
        CarComponent.FRONT_WING -> "Asa dianteira"
        CarComponent.REAR_WING -> "Asa traseira"
        CarComponent.BRAKES -> "Freios"
        CarComponent.ELECTRIC_POWER_UNIT -> "MGU-K - ERS"
    }

    private fun facilityFor(component: CarComponent): Facility = when (component) {
        CarComponent.ENGINE, CarComponent.ELECTRIC_POWER_UNIT -> Facility.TESTING
        CarComponent.CHASSIS, CarComponent.BRAKES -> Facility.FACTORY
        CarComponent.FRONT_WING, CarComponent.REAR_WING -> Facility.WIND_TUNNEL
    }

    private fun investmentBonus(steps:Int, focus:CarDevelopmentFocus, component:CarComponent): Int {
        if (steps <= 0) return 0
        val primary = when (focus) {
            CarDevelopmentFocus.BALANCED -> component in setOf(CarComponent.ENGINE, CarComponent.CHASSIS, CarComponent.FRONT_WING, CarComponent.REAR_WING, CarComponent.BRAKES, CarComponent.ELECTRIC_POWER_UNIT)
            CarDevelopmentFocus.POWER -> component == CarComponent.ENGINE || component == CarComponent.ELECTRIC_POWER_UNIT
            CarDevelopmentFocus.AERODYNAMICS -> component == CarComponent.FRONT_WING || component == CarComponent.REAR_WING
            CarDevelopmentFocus.CORNERING -> component == CarComponent.CHASSIS || component == CarComponent.BRAKES
        }
        return when {
            focus == CarDevelopmentFocus.BALANCED -> (steps / 2).coerceAtMost(3)
            primary -> ((steps + 1) / 2).coerceAtMost(4)
            else -> (steps / 3).coerceAtMost(2)
        }
    }

    fun aiBalancedInvestmentBonus(steps: Int, component: CarComponent): Int = investmentBonus(steps, CarDevelopmentFocus.BALANCED, component)

    /** Legacy step-based component helper retained for backward-compatible audits only. */
    /** First visible stage of the old step-based season reveal; not used by table-based construction. */
    fun nextSeasonPhysicalInvestmentOnlyComponentValue(
        previousValue: Int,
        installed: Boolean,
        investmentSteps: Int,
        focus: CarDevelopmentFocus,
        component: CarComponent
    ): Int {
        if (!installed || previousValue <= 0) return 0
        val investment = investmentBonus(investmentSteps, focus, component)
        return (previousValue + investment + focusBonus(focus, component)).coerceIn(40, 100)
    }

    /** Legacy compatibility stage: no automatic previous-car percentage is carried into the new season. */
    fun nextSeasonPhysicalTechnicalCarryoverComponentValue(
        investmentOnlyValue: Int,
        previousValue: Int,
        installed: Boolean,
        component: CarComponent,
        technicalKnowledge: Int = 0
    ): Int {
        if (!installed || previousValue <= 0 || investmentOnlyValue <= 0) return 0
        return (investmentOnlyValue + technicalKnowledge.coerceAtLeast(0)).coerceIn(40, 100)
    }

    fun nextSeasonPhysicalComponentValue(
        previousValue: Int,
        installed: Boolean,
        investmentSteps: Int,
        focus: CarDevelopmentFocus,
        component: CarComponent,
        technicalKnowledge: Int = 0
    ): Int {
        val afterInvestment = nextSeasonPhysicalInvestmentOnlyComponentValue(
            previousValue, installed, investmentSteps, focus, component
        )
        return nextSeasonPhysicalTechnicalCarryoverComponentValue(
            afterInvestment, previousValue, installed, component, technicalKnowledge
        )
    }

    private fun focusBonus(focus: CarDevelopmentFocus, component: CarComponent): Int = when (focus) {
        CarDevelopmentFocus.BALANCED -> 0
        CarDevelopmentFocus.POWER -> if (component == CarComponent.ENGINE || component == CarComponent.ELECTRIC_POWER_UNIT) 1 else 0
        CarDevelopmentFocus.AERODYNAMICS -> if (component == CarComponent.FRONT_WING || component == CarComponent.REAR_WING) 1 else 0
        CarDevelopmentFocus.CORNERING -> if (component == CarComponent.CHASSIS || component == CarComponent.BRAKES) 1 else 0
    }

    private fun regulationBonus(regulation:CarRegulationFocus, component:CarComponent):Int = when (regulation) {
        CarRegulationFocus.AERODYNAMICS -> if (component == CarComponent.FRONT_WING || component == CarComponent.REAR_WING) 1 else 0
        CarRegulationFocus.POWER -> if (component == CarComponent.ENGINE || component == CarComponent.ELECTRIC_POWER_UNIT) 1 else 0
        CarRegulationFocus.CORNERING -> if (component == CarComponent.CHASSIS || component == CarComponent.BRAKES) 1 else 0
        CarRegulationFocus.EFFICIENCY -> if (component == CarComponent.ELECTRIC_POWER_UNIT || component == CarComponent.ENGINE) 1 else 0
        CarRegulationFocus.BALANCED -> 0
    }
}
