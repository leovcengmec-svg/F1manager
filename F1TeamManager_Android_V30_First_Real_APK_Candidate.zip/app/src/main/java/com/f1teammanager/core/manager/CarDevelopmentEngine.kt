package com.f1teammanager.core.manager

/**
 * Car R&D is measured in real calendar weeks.  The model deliberately makes
 * current-car development meaningful while keeping the next-season program
 * capped so that money alone cannot break the championship.
 */
class CarDevelopmentEngine {
    companion object {
        /** Portion of the distance from 50 preserved when carrying a car into the next season. */
        const val ANNUAL_CONTINUITY_FACTOR = 0.70
    }
    data class DevelopmentOption(
        val intensity: DevelopmentIntensity,
        val weeks: Int,
        val cost: Long,
        val minGain: Int,
        val maxGain: Int
    ) {
        val gain: Int get() = maxGain
    }

    fun durationWeeks(component: CarComponent): Int = 2

    fun options(state: TeamManagerState, component: CarComponent): List<DevelopmentOption> {
        val level = componentLevel(state.car, component)
        val facility = facilityFor(component)
        val facilityLevel = state.car.facilities[facility] ?: 1
        val levelFactor = level.coerceIn(1,100)
        fun cost(base: Long, perLevel: Long) = base + levelFactor * perLevel - (facilityLevel - 1) * 150_000L
        return listOf(
            DevelopmentOption(DevelopmentIntensity.QUICK, 1, 5_000_000L, 2, 5),
            DevelopmentOption(DevelopmentIntensity.STANDARD, 2, 12_000_000L, 4, 8),
            DevelopmentOption(DevelopmentIntensity.ADVANCED, 3, 18_000_000L, 6, 11),
            DevelopmentOption(DevelopmentIntensity.AGGRESSIVE, 4, 25_000_000L, 8, 15)
        )
    }

    /** Weighted random: higher gains are deliberately more likely, but the minimum remains possible. */
    private fun weightedGain(min: Int, max: Int): Int {
        val values = (min..max).toList()
        val weighted = values.flatMapIndexed { index, value -> List(index + 1) { value } }
        return weighted.random()
    }

    /** Compatibility path: the normal 2-week development. */
    fun start(state: TeamManagerState, component: CarComponent): TeamManagerState =
        start(state, component, DevelopmentIntensity.STANDARD)

    fun start(state: TeamManagerState, component: CarComponent, intensity: DevelopmentIntensity): TeamManagerState {
        require(state.car.activeProject == null) { "Já existe um projeto em desenvolvimento" }
        require(state.car.seasonDevelopmentGain < 140) { "Limite anual de desenvolvimento atingido" }
        val option = options(state, component).first { it.intensity == intensity }
        val remainingSeason = 140 - state.car.seasonDevelopmentGain
        val remainingComponent = 100 - componentLevel(state.car, component)
        val actualGain = weightedGain(option.minGain, option.maxGain)
            .coerceAtMost(remainingSeason)
            .coerceAtMost(remainingComponent)
        require(actualGain > 0) { "Limite anual ou do componente atingido" }
        require(state.finance.budget >= option.cost) { "Orçamento insuficiente" }
        val level = state.car.facilities[facilityFor(component)] ?: 1
        val project = DevelopmentProject(
            component = component,
            remainingWeeks = option.weeks,
            totalWeeks = option.weeks,
            level = level,
            intensity = intensity,
            expectedGain = actualGain,
            cost = option.cost
        )
        return state.copy(
            car = state.car.copy(activeProject = project),
            finance = state.finance.transact(-option.cost, "P&D ${componentLabel(component)} • ${option.weeks} semana(s) • +$actualGain")
        )
    }

    /** Advance exactly the number of elapsed calendar weeks. */
    fun advanceWeeks(state: TeamManagerState, weeks: Int): TeamManagerState {
        if (weeks <= 0) return state
        var current = state
        repeat(weeks) {
            val p = current.car.activeProject ?: return current
            current = if (p.remainingWeeks > 1) {
                current.copy(car = current.car.copy(activeProject = p.copy(remainingWeeks = p.remainingWeeks - 1)))
            } else {
                val gain = p.expectedGain.coerceAtLeast(1)
                val c = when (p.component) {
                    CarComponent.ENGINE -> current.car.copy(engine = current.car.engine + gain, activeProject = null)
                    CarComponent.CHASSIS -> current.car.copy(chassis = current.car.chassis + gain, activeProject = null)
                    CarComponent.FRONT_WING -> current.car.copy(frontWing = current.car.frontWing + gain, aerodynamics = maxOf(current.car.aerodynamics, current.car.frontWing + gain), activeProject = null)
                    CarComponent.REAR_WING -> current.car.copy(rearWing = current.car.rearWing + gain, aerodynamics = maxOf(current.car.aerodynamics, current.car.rearWing + gain), activeProject = null)
                    CarComponent.BRAKES -> current.car.copy(brakes = current.car.brakes + gain, activeProject = null)
                    CarComponent.ELECTRIC_POWER_UNIT -> current.car.copy(electricPowerUnit = current.car.electricPowerUnit + gain, activeProject = null)
                }.copy(
                    developmentKnowledge = current.car.developmentKnowledge.toMutableMap().apply {
                        this[p.component] = ((this[p.component] ?: 0) + 1).coerceAtMost(8)
                    },
                    seasonDevelopmentGain = (current.car.seasonDevelopmentGain + gain).coerceAtMost(140)
                ).normalized()
                current.copy(car = c, history = current.history + "Projeto concluído: ${componentLabel(p.component)} (+$gain, ${p.totalWeeks} semana(s))")
            }
        }
        return current
    }

    fun nextSeasonInvestmentCap(car: TeamCarState): Long {
        val maxFacility = car.facilities.values.maxOrNull() ?: 1
        return (20_000_000L + (maxFacility - 1) * 5_000_000L).coerceAtMost(35_000_000L)
    }

    fun investNextSeason(state: TeamManagerState, amount: Long): TeamManagerState {
        require(amount > 0) { "Investimento inválido" }
        val cap = nextSeasonInvestmentCap(state.car)
        val room = cap - state.car.nextSeasonInvestment
        require(amount <= room) { "O limite de investimento no próximo carro é € ${cap}" }
        require(state.finance.budget >= amount) { "Orçamento insuficiente" }
        return state.copy(
            car = state.car.copy(nextSeasonInvestment = state.car.nextSeasonInvestment + amount),
            finance = state.finance.transact(-amount, "Investimento carro ${state.season + 1}")
        )
    }

    fun setNextSeasonFocus(state: TeamManagerState, focus: CarDevelopmentFocus): TeamManagerState =
        state.copy(car = state.car.copy(nextSeasonFocus = focus))

    /**
     * Creates the next-generation car.  The old car is partially carried over,
     * technical knowledge is retained, and the reserved next-season investment
     * becomes a concrete starting advantage.
     */
    fun startNextSeason(state: TeamManagerState, nextSeason: Int): TeamManagerState {
        val old = state.car
        val investmentSteps = (old.nextSeasonInvestment / 5_000_000L).toInt().coerceIn(0, 7)
        val regulation = regulationForSeason(nextSeason)
        fun base(v: Int, component: CarComponent): Int {
            val continuity = (50 + (v - 50) * ANNUAL_CONTINUITY_FACTOR).toInt()
            val knowledge = old.developmentKnowledge[component] ?: 0
            val investment = investmentBonus(investmentSteps, old.nextSeasonFocus, component)
            val regulationBonus = regulationBonus(regulation, component)
            return (continuity + knowledge + investment + focusBonus(old.nextSeasonFocus, component) + regulationBonus).coerceIn(1,100)
        }
        val next = TeamCarState(
            aerodynamics = base(old.aerodynamics, CarComponent.FRONT_WING),
            chassis = base(old.chassis, CarComponent.CHASSIS),
            engine = base(old.engine, CarComponent.ENGINE),
            reliability = (50 + (old.reliability - 50) * ANNUAL_CONTINUITY_FACTOR).toInt().coerceIn(1,100),
            facilities = old.facilities,
            activeProject = null,
            frontWing = base(old.frontWing, CarComponent.FRONT_WING),
            rearWing = base(old.rearWing, CarComponent.REAR_WING),
            brakes = base(old.brakes, CarComponent.BRAKES),
            electricPowerUnit = base(old.electricPowerUnit, CarComponent.ELECTRIC_POWER_UNIT),
            nextSeasonInvestment = 0L,
            nextSeasonFocus = CarDevelopmentFocus.BALANCED,
            developmentKnowledge = old.developmentKnowledge,
            seasonDevelopmentGain = 0
        ).normalized()
        return state.copy(
            season = nextSeason,
            round = 1,
            car = next,
            history = state.history + "Novo carro ${nextSeason} criado: investimento €${old.nextSeasonInvestment} aplicado"
        )
    }

    /**
     * Canonical carry-over used by AI teams when constructing a new season car.
     * It intentionally uses the same 70% annual continuity rule as the player,
     * without player-only investment/focus choices.
     */
    fun carryAiCarToNextSeason(old: TeamCarState, nextSeason: Int): TeamCarState {
        val regulation = regulationForSeason(nextSeason)
        fun base(v: Int, component: CarComponent): Int {
            val continuity = (50 + (v - 50) * ANNUAL_CONTINUITY_FACTOR).toInt()
            val knowledge = old.developmentKnowledge[component] ?: 0
            val regulationBonus = regulationBonus(regulation, component)
            return (continuity + knowledge + regulationBonus).coerceIn(1, 100)
        }
        return TeamCarState(
            aerodynamics = base(old.aerodynamics, CarComponent.FRONT_WING),
            chassis = base(old.chassis, CarComponent.CHASSIS),
            engine = base(old.engine, CarComponent.ENGINE),
            reliability = (50 + (old.reliability - 50) * ANNUAL_CONTINUITY_FACTOR).toInt().coerceIn(1, 100),
            facilities = old.facilities,
            activeProject = null,
            frontWing = base(old.frontWing, CarComponent.FRONT_WING),
            rearWing = base(old.rearWing, CarComponent.REAR_WING),
            brakes = base(old.brakes, CarComponent.BRAKES),
            electricPowerUnit = base(old.electricPowerUnit, CarComponent.ELECTRIC_POWER_UNIT),
            nextSeasonInvestment = 0L,
            nextSeasonFocus = CarDevelopmentFocus.BALANCED,
            developmentKnowledge = old.developmentKnowledge,
            seasonDevelopmentGain = 0
        ).normalized()
    }

    fun upgradeFacility(state: TeamManagerState, facility: Facility): TeamManagerState {
        val current = state.car.facilities[facility] ?: 1
        require(current < 10) { "Instalação já está no nível máximo" }
        val cost = 1_000_000L * current
        require(state.finance.budget >= cost) { "Orçamento insuficiente" }
        val facilities = state.car.facilities.toMutableMap()
        facilities[facility] = current + 1
        return state.copy(car = state.car.copy(facilities = facilities), finance = state.finance.transact(-cost, "Upgrade ${facility.name} para ${current + 1}"))
    }

    fun regulationForSeason(season: Int): CarRegulationFocus = when (season % 5) {
        2 -> CarRegulationFocus.AERODYNAMICS
        3 -> CarRegulationFocus.POWER
        4 -> CarRegulationFocus.CORNERING
        0 -> CarRegulationFocus.EFFICIENCY
        else -> CarRegulationFocus.BALANCED
    }

    fun componentLevel(car: TeamCarState, component: CarComponent): Int = when (component) {
        CarComponent.ENGINE -> car.engine
        CarComponent.CHASSIS -> car.chassis
        CarComponent.FRONT_WING -> car.frontWing
        CarComponent.REAR_WING -> car.rearWing
        CarComponent.BRAKES -> car.brakes
        CarComponent.ELECTRIC_POWER_UNIT -> car.electricPowerUnit
    }

    fun componentLabel(component: CarComponent) = when (component) {
        CarComponent.ENGINE -> "Unidade de potência"
        CarComponent.CHASSIS -> "Chassi"
        CarComponent.FRONT_WING -> "Asa dianteira"
        CarComponent.REAR_WING -> "Asa traseira"
        CarComponent.BRAKES -> "Freios"
        CarComponent.ELECTRIC_POWER_UNIT -> "Unidade de potência elétrica"
    }

    private fun facilityFor(component: CarComponent): Facility = when (component) {
        CarComponent.ENGINE, CarComponent.ELECTRIC_POWER_UNIT -> Facility.TESTING
        CarComponent.CHASSIS, CarComponent.BRAKES -> Facility.FACTORY
        CarComponent.FRONT_WING, CarComponent.REAR_WING -> Facility.WIND_TUNNEL
    }

    private fun investmentBonus(steps:Int, focus:CarDevelopmentFocus, component:CarComponent): Int {
        if (steps <= 0) return 0
        val primary = when (focus) {
            CarDevelopmentFocus.BALANCED -> component in setOf(CarComponent.ENGINE, CarComponent.CHASSIS, CarComponent.FRONT_WING, CarComponent.REAR_WING, CarComponent.BRAKES, CarComponent.ELECTRIC_POWER_UNIT)
            CarDevelopmentFocus.POWER -> component == CarComponent.ENGINE || component == CarComponent.ELECTRIC_POWER_UNIT
            CarDevelopmentFocus.AERODYNAMICS -> component == CarComponent.FRONT_WING || component == CarComponent.REAR_WING
            CarDevelopmentFocus.CORNERING -> component == CarComponent.CHASSIS || component == CarComponent.BRAKES
        }
        return when {
            focus == CarDevelopmentFocus.BALANCED -> (steps / 2).coerceAtMost(3)
            primary -> ((steps + 1) / 2).coerceAtMost(4)
            else -> (steps / 3).coerceAtMost(2)
        }
    }

    private fun focusBonus(focus: CarDevelopmentFocus, component: CarComponent): Int = when (focus) {
        CarDevelopmentFocus.BALANCED -> 0
        CarDevelopmentFocus.POWER -> if (component == CarComponent.ENGINE || component == CarComponent.ELECTRIC_POWER_UNIT) 1 else 0
        CarDevelopmentFocus.AERODYNAMICS -> if (component == CarComponent.FRONT_WING || component == CarComponent.REAR_WING) 1 else 0
        CarDevelopmentFocus.CORNERING -> if (component == CarComponent.CHASSIS || component == CarComponent.BRAKES) 1 else 0
    }

    private fun regulationBonus(regulation:CarRegulationFocus, component:CarComponent):Int = when (regulation) {
        CarRegulationFocus.AERODYNAMICS -> if (component == CarComponent.FRONT_WING || component == CarComponent.REAR_WING) 1 else 0
        CarRegulationFocus.POWER -> if (component == CarComponent.ENGINE || component == CarComponent.ELECTRIC_POWER_UNIT) 1 else 0
        CarRegulationFocus.CORNERING -> if (component == CarComponent.CHASSIS || component == CarComponent.BRAKES) 1 else 0
        CarRegulationFocus.EFFICIENCY -> if (component == CarComponent.ELECTRIC_POWER_UNIT || component == CarComponent.ENGINE) 1 else 0
        CarRegulationFocus.BALANCED -> 0
    }
}
