package com.f1teammanager.core.race

/**
 * Deterministic per-lap pace decision shared by player-team drivers and AI drivers.
 * DriverStrategyMode.DEFENSE is the persisted legacy identifier for the user-facing
 * POUPAR profile. No manager input can override this decision.
 */
internal object AutomaticDriverPacePolicy {
    fun choose(
        totalLaps: Int,
        currentLap: Int,
        fuelKg: Double,
        tyreWearPercent: Int,
        tyre: Tyre,
        weather: Weather,
        position: Int,
        driverSpeed: Int,
        wetSkill: Int,
        overtaking: Int,
        nearestRivalGapMs: Long?
    ): DriverStrategyMode {
        val raceLaps = totalLaps.coerceAtLeast(1)
        val remainingLaps = (raceLaps - currentLap + 1).coerceAtLeast(1)
        val wear = tyreWearPercent.coerceIn(0, 100)
        val speed = driverSpeed.coerceIn(40, 100)
        val wet = wetSkill.coerceIn(40, 100)
        val overtake = overtaking.coerceIn(40, 100)

        // Plan against dry-track consumption so a later weather improvement cannot
        // leave the car short of fuel. Keep a buffer in addition to the finish estimate.
        val attackPerLap = FuelModel.consumptionPerLap(raceLaps, DriverStrategyMode.ATTACK, Weather.DRY, tyre)
        val balancedPerLap = FuelModel.consumptionPerLap(raceLaps, DriverStrategyMode.BALANCED, Weather.DRY, tyre)
        val reserve = attackPerLap * 0.75
        val attackNeed = attackPerLap * remainingLaps
        val balancedNeed = balancedPerLap * remainingLaps

        // Finish safely takes priority over position or pace.
        if (fuelKg <= balancedNeed + reserve ||
            (FuelModel.fuelPercent(fuelKg) <= 12 && remainingLaps > 1)) {
            return DriverStrategyMode.DEFENSE
        }
        if (fuelKg <= attackNeed + reserve) return DriverStrategyMode.BALANCED

        // Tyre condition is the next priority. Save before the automatic pit threshold;
        // if degradation is moderate, settle into balanced pace instead of attacking.
        if (remainingLaps > 1 && wear >= 82) return DriverStrategyMode.DEFENSE
        if (remainingLaps > 1 && wear >= 65) return DriverStrategyMode.BALANCED

        if (weather == Weather.HEAVY_RAIN) {
            return when {
                wet >= 90 && position <= 10 && wear < 55 && fuelKg > attackNeed + reserve -> DriverStrategyMode.ATTACK
                wet >= 78 -> DriverStrategyMode.BALANCED
                else -> DriverStrategyMode.DEFENSE
            }
        }

        val nearRival = nearestRivalGapMs?.let { it <= 1_800L } ?: false
        val fuelSafeForAttack = fuelKg > attackNeed + reserve
        val tyreSafeForAttack = wear < 58
        val finalPhase = remainingLaps <= 3
        val earlyRace = currentLap.coerceAtLeast(1) <= (raceLaps * 0.25).toInt().coerceAtLeast(1)

        if (finalPhase && fuelSafeForAttack && tyreSafeForAttack && speed >= 65) {
            return DriverStrategyMode.ATTACK
        }
        if (nearRival && fuelSafeForAttack && tyreSafeForAttack && (overtake >= 68 || speed >= 82)) {
            return DriverStrategyMode.ATTACK
        }
        if (earlyRace && position <= 6 && speed >= 88 && fuelSafeForAttack && tyreSafeForAttack) {
            return DriverStrategyMode.ATTACK
        }
        if (position >= 45 && speed >= 82 && fuelSafeForAttack && tyreSafeForAttack) {
            return DriverStrategyMode.ATTACK
        }

        if (remainingLaps > 1 && wear >= 58) return DriverStrategyMode.BALANCED
        return DriverStrategyMode.BALANCED
    }
}
