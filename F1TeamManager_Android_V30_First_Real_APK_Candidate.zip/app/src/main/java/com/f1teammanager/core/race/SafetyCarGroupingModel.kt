package com.f1teammanager.core.race

import kotlin.math.min

/**
 * Shared, deterministic Safety Car bunching rule used by both playable race engines.
 * Cumulative race times are never rewritten: the closure is represented in upcoming
 * neutralised lap times, so already completed laps and their order remain intact.
 */
object SafetyCarGroupingModel {
    const val TARGET_GAP_MS: Long = 1_500L
    const val MAX_CATCH_UP_PER_LAP_MS: Long = 8_000L
    const val MIN_LAP_EXTRA_MS: Long = 2_000L
    const val SAFETY_CAR_PACE_PENALTY_MS: Long = 9_000L
    private const val CLOSURE_RATIO: Double = 0.60
    private const val RETAINED_PACE_VARIANCE_RATIO: Double = 0.10

    /** How much time a car may make up on the leader during one Safety-Car lap. */
    fun catchUpMilliseconds(gapBehindLeaderMs: Long): Long {
        val gapBeyondQueue = (gapBehindLeaderMs - TARGET_GAP_MS).coerceAtLeast(0L)
        return (gapBeyondQueue * CLOSURE_RATIO).toLong()
            .coerceAtMost(MAX_CATCH_UP_PER_LAP_MS)
    }

    /**
     * Apply that closure to the current lap only. The resulting lap never becomes faster
     * than the circuit reference plus a minimum neutralisation margin.
     */
    fun applyCatchUp(
        lapTimeWithSafetyCarPenaltyMs: Long,
        gapBehindLeaderMs: Long,
        circuitReferenceLapMs: Long
    ): Long {
        val minimumNeutralisedLap = circuitReferenceLapMs + MIN_LAP_EXTRA_MS
        // Under the Safety Car all cars follow a common pace, so retain only 10% of
        // their normal pace/weather variation before reducing the gap to the queue.
        val normalEquivalent = lapTimeWithSafetyCarPenaltyMs - SAFETY_CAR_PACE_PENALTY_MS
        val normalDelta = normalEquivalent - circuitReferenceLapMs
        val commonSafetyCarPace = circuitReferenceLapMs + SAFETY_CAR_PACE_PENALTY_MS +
            (normalDelta * RETAINED_PACE_VARIANCE_RATIO).toLong()
        val available = (commonSafetyCarPace - minimumNeutralisedLap).coerceAtLeast(0L)
        val closure = min(catchUpMilliseconds(gapBehindLeaderMs), available)
        return (commonSafetyCarPace - closure).coerceAtLeast(minimumNeutralisedLap)
    }
}
