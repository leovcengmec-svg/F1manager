package com.f1teammanager.core.season

/** Official Stage 1 driver profiles: fixed class + fixed evolution type. No age/retirement. */
object DriverProfileCatalog {
    data class Profile(val driverClass:String, val evolution:String, val ratings:IntArray)
    val profiles: Map<String, Profile> = mapOf(
        "Charles Leclerc" to Profile("Pro", "Auge rápido", intArrayOf(94, 96, 86, 82, 83, 86, 83)),
        "Lewis Hamilton" to Profile("Lenda", "Auge rápido", intArrayOf(94, 96, 91, 92, 92, 96, 94)),
        "Lando Norris" to Profile("Pro", "Auge moderado", intArrayOf(92, 93, 88, 82, 84, 82, 86)),
        "Oscar Piastri" to Profile("Pro", "Normal", intArrayOf(92, 91, 87, 84, 87, 80, 87)),
        "Carlos Sainz" to Profile("Forte", "Auge moderado", intArrayOf(80, 80, 77, 80, 81, 76, 79)),
        "Alexander Albon" to Profile("Forte", "Normal", intArrayOf(81, 79, 78, 79, 79, 79, 78)),
        "George Russell" to Profile("Pro", "Prodígio", intArrayOf(91, 92, 83, 86, 88, 83, 87)),
        "Kimi Antonelli" to Profile("Pro", "Prodígio", intArrayOf(91, 92, 81, 79, 78, 78, 82)),
        "Max Verstappen" to Profile("Lenda", "Prodígio", intArrayOf(99, 98, 97, 96, 94, 91, 91)),
        "Isack Hadjar" to Profile("Forte", "Auge moderado", intArrayOf(85, 83, 79, 77, 75, 77, 77)),
        "Michael Schumacher" to Profile("Lenda", "Auge rápido", intArrayOf(69, 73, 67, 63, 61, 71, 67)),
        "Rafael Câmara" to Profile("Pro", "Auge moderado", intArrayOf(78, 68, 74, 73, 72, 65, 74)),
        "Pierre Gasly" to Profile("Forte", "Auge moderado", intArrayOf(81, 80, 78, 79, 79, 77, 79)),
        "Franco Colapinto" to Profile("Médio", "Normal", intArrayOf(73, 72, 70, 68, 65, 67, 68)),
        "Ayrton Senna" to Profile("Lenda", "Auge moderado", intArrayOf(69, 66, 67, 67, 75, 60, 71)),
        "Nikola Tsolov" to Profile("Médio", "Normal", intArrayOf(76, 72, 72, 64, 69, 65, 65)),
        "Alain Prost" to Profile("Lenda", "Auge tardio", intArrayOf(75, 69, 67, 63, 67, 61, 73)),
        "Gabriele Minì" to Profile("Médio", "Normal", intArrayOf(72, 64, 74, 73, 63, 68, 68)),
        "Sebastian Vettel" to Profile("Lenda", "Prodígio", intArrayOf(69, 72, 67, 71, 74, 62, 63)),
        "Martinius Stenshorne" to Profile("Fraco", "Normal", intArrayOf(63, 57, 61, 58, 58, 58, 58)),
        "Jenson Button" to Profile("Pro", "Normal", intArrayOf(75, 75, 67, 67, 66, 63, 65)),
        "Alexander Dunne" to Profile("Fraco", "Normal", intArrayOf(61, 59, 62, 56, 54, 59, 61)),
        "Nico Rosberg" to Profile("Pro", "Normal", intArrayOf(69, 65, 67, 63, 73, 64, 67)),
        "Dino Beganovic" to Profile("Fraco", "Normal", intArrayOf(62, 59, 59, 59, 57, 58, 59)),
        "Mika Häkkinen" to Profile("Lenda", "Auge tardio", intArrayOf(75, 68, 67, 71, 65, 65, 69)),
        "Oliver Goethe" to Profile("Médio", "Normal", intArrayOf(71, 75, 73, 68, 60, 71, 63)),
        "Liam Lawson" to Profile("Forte", "Normal", intArrayOf(83, 80, 80, 80, 75, 76, 78)),
        "Arvid Lindblad" to Profile("Médio", "Normal", intArrayOf(73, 73, 70, 68, 65, 67, 67)),
        "Nico Hülkenberg" to Profile("Forte", "Auge tardio", intArrayOf(80, 79, 74, 79, 83, 76, 81)),
        "Gabriel Bortoleto" to Profile("Pro", "Prodígio", intArrayOf(85, 84, 81, 78, 76, 77, 79)),
        "Nigel Mansell" to Profile("Lenda", "Auge tardio", intArrayOf(69, 64, 67, 71, 71, 68, 63)),
        "Sebastian Montoya" to Profile("Médio", "Normal", intArrayOf(75, 71, 73, 68, 66, 61, 69)),
        "Nelson Piquet" to Profile("Pro", "Normal", intArrayOf(75, 67, 67, 67, 63, 69, 65)),
        "Mari Boya" to Profile("Fraco", "Normal", intArrayOf(60, 62, 61, 55, 61, 54, 60)),
        "Fernando Alonso" to Profile("Lenda", "Auge tardio", intArrayOf(94, 93, 92, 96, 95, 97, 92)),
        "Lance Stroll" to Profile("Fraco", "Demorado", intArrayOf(61, 60, 59, 59, 57, 59, 58)),
        "Niki Lauda" to Profile("Lenda", "Prodígio", intArrayOf(75, 73, 67, 71, 62, 71, 69)),
        "Joshua Dürksen" to Profile("Médio", "Normal", intArrayOf(72, 68, 72, 69, 73, 65, 64)),
        "James Hunt" to Profile("Pro", "Normal", intArrayOf(69, 76, 67, 67, 69, 72, 71)),
        "Ritomo Miyata" to Profile("Forte", "Normal", intArrayOf(78, 71, 74, 65, 65, 66, 66)),
        "Emerson Fittipaldi" to Profile("Pro", "Normal", intArrayOf(75, 66, 67, 63, 61, 60, 73)),
        "Noel León" to Profile("Médio", "Normal", intArrayOf(70, 71, 71, 70, 70, 65, 66)),
        "Jackie Stewart" to Profile("Pro", "Auge moderado", intArrayOf(69, 69, 67, 71, 68, 61, 63)),
        "Roman Bilinski" to Profile("Fraco", "Demorado", intArrayOf(64, 55, 62, 59, 55, 58, 59)),
        "Jim Clark" to Profile("Pro", "Normal", intArrayOf(75, 72, 67, 67, 75, 62, 65)),
        "Tuukka Taponen" to Profile("Fraco", "Demorado", intArrayOf(60, 57, 62, 56, 60, 58, 60)),
        "Juan Manuel Fangio" to Profile("Lenda", "Auge tardio", intArrayOf(69, 75, 67, 63, 67, 63, 67)),
        "Ugo Ugochukwu" to Profile("Fraco", "Normal", intArrayOf(63, 58, 60, 60, 54, 58, 60)),
        "Jack Brabham" to Profile("Forte", "Normal", intArrayOf(75, 65, 67, 71, 74, 64, 69)),
        "Freddie Slater" to Profile("Fraco", "Demorado", intArrayOf(60, 61, 61, 58, 59, 59, 55)),
        "Mario Andretti" to Profile("Forte", "Normal", intArrayOf(69, 68, 67, 67, 66, 65, 71)),
        "Théophile Naël" to Profile("Médio", "Normal", intArrayOf(76, 74, 72, 64, 61, 70, 65)),
        "Damon Hill" to Profile("Forte", "Normal", intArrayOf(75, 71, 67, 63, 73, 66, 73)),
        "Noah Strømsted" to Profile("Médio", "Normal", intArrayOf(72, 66, 74, 73, 69, 60, 68)),
        "Kimi Räikkönen" to Profile("Pro", "Auge tardio", intArrayOf(69, 74, 67, 71, 65, 67, 63)),
        "Matteo De Palo" to Profile("Médio", "Normal", intArrayOf(78, 69, 74, 69, 61, 61, 70)),
        "Felipe Massa" to Profile("Pro", "Auge moderado", intArrayOf(75, 64, 67, 67, 72, 68, 65)),
        "Mattia Colnaghi" to Profile("Médio", "Normal", intArrayOf(72, 72, 72, 65, 68, 62, 72)),
        "Rubens Barrichello" to Profile("Pro", "Auge moderado", intArrayOf(69, 67, 67, 63, 64, 69, 67)),
        "Enzo Deligny" to Profile("Fraco", "Normal", intArrayOf(62, 60, 59, 59, 60, 53, 59)),
        "Mark Webber" to Profile("Forte", "Normal", intArrayOf(75, 70, 67, 71, 71, 70, 69)),
        "Brando Badoer" to Profile("Médio", "Normal", intArrayOf(72, 65, 74, 69, 67, 64, 64)),
        "Juan Pablo Montoya" to Profile("Pro", "Auge tardio", intArrayOf(69, 73, 67, 67, 63, 71, 71)),
        "James Wharton" to Profile("Médio", "Normal", intArrayOf(77, 67, 73, 64, 73, 64, 65)),
        "Jacques Villeneuve" to Profile("Forte", "Auge moderado", intArrayOf(75, 76, 67, 63, 70, 72, 73)),
        "Alex Powell" to Profile("Médio", "Demorado", intArrayOf(71, 70, 73, 72, 65, 65, 67)),
        "Esteban Ocon" to Profile("Médio", "Auge moderado", intArrayOf(70, 70, 68, 71, 68, 68, 68)),
        "Oliver Bearman" to Profile("Forte", "Prodígio", intArrayOf(84, 83, 80, 77, 75, 76, 77)),
        "Carlos Reutemann" to Profile("Forte", "Auge moderado", intArrayOf(75, 69, 67, 67, 69, 61, 65)),
        "Pedro Clerot" to Profile("Médio", "Demorado", intArrayOf(72, 64, 74, 65, 65, 68, 72)),
        "Gilles Villeneuve" to Profile("Forte", "Normal", intArrayOf(69, 72, 67, 63, 61, 62, 67)),
        "Laurens van Hoepen" to Profile("Fraco", "Normal", intArrayOf(62, 56, 60, 59, 59, 57, 60)),
        "Sergio Pérez" to Profile("Pro", "Auge moderado", intArrayOf(89, 87, 90, 92, 86, 88, 89)),
        "Valtteri Bottas" to Profile("Pro", "Auge moderado", intArrayOf(91, 93, 84, 85, 89, 87, 90)),
        "Gerhard Berger" to Profile("Médio", "Normal", intArrayOf(69, 65, 67, 67, 75, 64, 71)),
        "Taito Kato" to Profile("Médio", "Normal", intArrayOf(75, 71, 72, 63, 69, 69, 64)),
        "David Coulthard" to Profile("Forte", "Auge moderado", intArrayOf(75, 68, 67, 63, 67, 65, 73)),
        "Maciej Gładysz" to Profile("Médio", "Normal", intArrayOf(70, 73, 72, 71, 61, 70, 66)),
        "Eddie Irvine" to Profile("Médio", "Normal", intArrayOf(69, 71, 67, 71, 74, 66, 63)),
        "Jean Alesi" to Profile("Médio", "Normal", intArrayOf(77, 65, 73, 68, 69, 60, 69)),
        "Heinz-Harald Frentzen" to Profile("Médio", "Auge moderado", intArrayOf(70, 69, 67, 69, 71, 67, 69)),
        "Jarno Trulli" to Profile("Médio", "Auge moderado", intArrayOf(70, 69, 68, 69, 70, 68, 69)),
        "Nick Heidfeld" to Profile("Médio", "Normal", intArrayOf(70, 69, 67, 70, 70, 67, 70)),
        "Robert Kubica" to Profile("Médio", "Normal", intArrayOf(70, 69, 68, 70, 70, 67, 69)),
        "Heikki Kovalainen" to Profile("Médio", "Normal", intArrayOf(70, 70, 68, 68, 70, 68, 69)),
        "Romain Grosjean" to Profile("Médio", "Normal", intArrayOf(72, 71, 70, 68, 66, 68, 68)),
        "Timo Glock" to Profile("Médio", "Normal", intArrayOf(70, 69, 67, 69, 70, 68, 69)),
        "Giancarlo Fisichella" to Profile("Forte", "Normal", intArrayOf(79, 80, 78, 78, 80, 79, 79)),
        "Takuma Sato" to Profile("Forte", "Normal", intArrayOf(82, 79, 85, 76, 74, 78, 79)),
        "Johnny Herbert" to Profile("Médio", "Normal", intArrayOf(69, 70, 67, 69, 71, 68, 69)),
        "Riccardo Patrese" to Profile("Médio", "Auge rápido", intArrayOf(69, 70, 67, 69, 71, 68, 69)),
        "Michele Alboreto" to Profile("Forte", "Auge tardio", intArrayOf(79, 79, 78, 79, 79, 79, 80)),
        "Carlos Pace" to Profile("Médio", "Normal", intArrayOf(71, 70, 68, 68, 69, 68, 69)),
        "Bruce McLaren" to Profile("Forte", "Normal", intArrayOf(80, 79, 78, 79, 80, 78, 79)),
        "Olivier Panis" to Profile("Médio", "Normal", intArrayOf(69, 69, 67, 69, 71, 68, 69)),
        "Pedro de la Rosa" to Profile("Médio", "Demorado", intArrayOf(70, 69, 68, 68, 70, 68, 70)),
        "Adrian Sutil" to Profile("Médio", "Normal", intArrayOf(69, 69, 68, 70, 68, 70, 69)),
        "Paul di Resta" to Profile("Médio", "Normal", intArrayOf(69, 69, 68, 69, 71, 68, 69)),
        "Pastor Maldonado" to Profile("Médio", "Normal", intArrayOf(72, 71, 72, 67, 63, 68, 68)),
        "Alexander Rossi" to Profile("Forte", "Normal", intArrayOf(80, 80, 79, 78, 77, 79, 80)),
    )

    fun profile(name:String): Profile = profiles[name] ?: error("Perfil de piloto não definido: $name")
    fun ceiling(driverClass:String): Int = when (driverClass) {
        "Fraco" -> 59
        "Médio" -> 69
        "Forte" -> 79
        "Pro" -> 89
        "Lenda" -> 100
        else -> error("Classe de piloto inválida: $driverClass")
    }
    fun maxAnnualGain(evolution:String): Int = when (evolution) {
        "Prodígio" -> 8
        "Auge rápido" -> 7
        "Auge moderado" -> 6
        "Auge tardio" -> 6
        "Normal" -> 5
        "Demorado" -> 4
        else -> error("Evolução inválida: $evolution")
    }
    fun overall(ratings:IntArray): Int = ratings.sum()/7
}
