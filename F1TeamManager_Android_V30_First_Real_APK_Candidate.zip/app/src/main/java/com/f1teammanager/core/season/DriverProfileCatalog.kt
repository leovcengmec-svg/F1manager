package com.f1teammanager.core.season

/** Individualized driver ratings, class/reputation, evolution style and personal potential. */
object DriverProfileCatalog {
    data class Profile(
        val driverClass:String,
        val evolution:String,
        val ratings:IntArray,
        /** Individual career potential (Overall), bounded at career start by the opening class. */
        val potentialOverall:Int = 0
    )
    val profiles: Map<String, Profile> = mapOf(
        "Charles Leclerc" to Profile("Pro", "Auge rápido", intArrayOf(94, 96, 86, 82, 83, 86, 83)),
        "Lewis Hamilton" to Profile("Lenda", "Auge rápido", intArrayOf(94, 96, 91, 92, 92, 96, 94)),
        "Lando Norris" to Profile("Pro", "Auge moderado", intArrayOf(92, 93, 88, 82, 84, 82, 86)),
        "Oscar Piastri" to Profile("Pro", "Auge moderado", intArrayOf(92, 91, 87, 84, 87, 80, 87)),
        "Carlos Sainz" to Profile("Forte", "Auge moderado", intArrayOf(80, 80, 77, 80, 81, 76, 79)),
        "Alexander Albon" to Profile("Forte", "Auge moderado", intArrayOf(81, 79, 78, 79, 79, 79, 78)),
        "George Russell" to Profile("Pro", "Prodígio", intArrayOf(91, 92, 83, 86, 88, 83, 87)),
        "Kimi Antonelli" to Profile("Pro", "Prodígio", intArrayOf(91, 92, 81, 79, 78, 78, 82)),
        "Max Verstappen" to Profile("Lenda", "Prodígio", intArrayOf(99, 98, 97, 96, 94, 91, 91)),
        "Isack Hadjar" to Profile("Forte", "Auge moderado", intArrayOf(85, 83, 79, 77, 75, 77, 77)),
        "Michael Schumacher" to Profile("Lenda", "Auge rápido", intArrayOf(69, 73, 67, 63, 61, 71, 67)),
        "Rafael Câmara" to Profile("Pro", "Auge moderado", intArrayOf(78, 68, 74, 73, 72, 65, 74)),
        "Pierre Gasly" to Profile("Forte", "Auge moderado", intArrayOf(81, 80, 78, 79, 79, 77, 79)),
        "Franco Colapinto" to Profile("Médio", "Auge moderado", intArrayOf(73, 72, 70, 68, 65, 67, 68)),
        "Ayrton Senna" to Profile("Lenda", "Auge moderado", intArrayOf(69, 66, 67, 67, 75, 60, 71)),
        "Nikola Tsolov" to Profile("Médio", "Auge moderado", intArrayOf(76, 72, 72, 64, 69, 65, 65)),
        "Alain Prost" to Profile("Lenda", "Auge tardio", intArrayOf(75, 69, 67, 63, 67, 61, 73)),
        "Gabriele Minì" to Profile("Médio", "Auge moderado", intArrayOf(72, 64, 74, 73, 63, 68, 68)),
        "Sebastian Vettel" to Profile("Lenda", "Prodígio", intArrayOf(69, 72, 67, 71, 74, 62, 63)),
        "Martinius Stenshorne" to Profile("Médio", "Auge moderado", intArrayOf(63, 57, 61, 58, 58, 58, 58)),
        "Jenson Button" to Profile("Pro", "Auge moderado", intArrayOf(75, 75, 67, 67, 66, 63, 65)),
        "Alexander Dunne" to Profile("Médio", "Auge moderado", intArrayOf(61, 59, 62, 56, 54, 59, 61)),
        "Nico Rosberg" to Profile("Pro", "Auge moderado", intArrayOf(69, 65, 67, 63, 73, 64, 67)),
        "Dino Beganovic" to Profile("Médio", "Auge moderado", intArrayOf(62, 59, 59, 59, 57, 58, 59)),
        "Mika Häkkinen" to Profile("Lenda", "Auge tardio", intArrayOf(75, 68, 67, 71, 65, 65, 69)),
        "Paul Aron" to Profile("Forte", "Auge moderado", intArrayOf(80, 79, 78, 77, 79, 78, 79)),
        "Liam Lawson" to Profile("Forte", "Auge moderado", intArrayOf(83, 80, 80, 80, 75, 76, 78)),
        "Arvid Lindblad" to Profile("Médio", "Auge moderado", intArrayOf(73, 73, 70, 68, 65, 67, 67)),
        "Nico Hülkenberg" to Profile("Forte", "Auge tardio", intArrayOf(80, 79, 74, 79, 83, 76, 81)),
        "Gabriel Bortoleto" to Profile("Pro", "Prodígio", intArrayOf(85, 84, 81, 78, 76, 77, 79)),
        "Nigel Mansell" to Profile("Lenda", "Auge tardio", intArrayOf(69, 64, 67, 71, 71, 68, 63)),
        "Sebastian Montoya" to Profile("Médio", "Auge moderado", intArrayOf(75, 71, 73, 68, 66, 61, 69)),
        "Nelson Piquet" to Profile("Pro", "Auge moderado", intArrayOf(75, 67, 67, 67, 63, 69, 65)),
        "Mari Boya" to Profile("Médio", "Auge moderado", intArrayOf(60, 62, 61, 55, 61, 54, 60)),
        "Fernando Alonso" to Profile("Lenda", "Auge tardio", intArrayOf(94, 93, 92, 96, 95, 97, 92)),
        "Lance Stroll" to Profile("Médio", "Auge moderado", intArrayOf(61, 60, 59, 59, 57, 59, 58)),
        "Niki Lauda" to Profile("Lenda", "Prodígio", intArrayOf(75, 73, 67, 71, 62, 71, 69)),
        "Joshua Dürksen" to Profile("Médio", "Auge moderado", intArrayOf(72, 68, 72, 69, 73, 65, 64)),
        "James Hunt" to Profile("Pro", "Auge moderado", intArrayOf(69, 76, 67, 67, 69, 72, 71)),
        "Ritomo Miyata" to Profile("Forte", "Auge moderado", intArrayOf(78, 71, 74, 65, 65, 66, 66)),
        "Emerson Fittipaldi" to Profile("Pro", "Auge moderado", intArrayOf(75, 66, 67, 63, 61, 60, 73)),
        "Noel León" to Profile("Médio", "Auge moderado", intArrayOf(70, 71, 71, 70, 70, 65, 66)),
        "Jackie Stewart" to Profile("Pro", "Auge moderado", intArrayOf(69, 69, 67, 71, 68, 61, 63)),
        "Daniel Ricciardo" to Profile("Pro", "Prodígio", intArrayOf(88, 87, 91, 84, 85, 86, 88)),
        "Jim Clark" to Profile("Pro", "Auge moderado", intArrayOf(75, 72, 67, 67, 75, 62, 65)),
        "Tuukka Taponen" to Profile("Médio", "Auge moderado", intArrayOf(60, 57, 62, 56, 60, 58, 60)),
        "Juan Manuel Fangio" to Profile("Lenda", "Auge tardio", intArrayOf(69, 75, 67, 63, 67, 63, 67)),
        "Ugo Ugochukwu" to Profile("Médio", "Auge moderado", intArrayOf(63, 58, 60, 60, 54, 58, 60)),
        "Jack Brabham" to Profile("Forte", "Auge moderado", intArrayOf(75, 65, 67, 71, 74, 64, 69)),
        "Freddie Slater" to Profile("Médio", "Auge moderado", intArrayOf(60, 61, 61, 58, 59, 59, 55)),
        "Mario Andretti" to Profile("Forte", "Auge moderado", intArrayOf(69, 68, 67, 67, 66, 65, 71)),
        "Théophile Naël" to Profile("Médio", "Auge moderado", intArrayOf(76, 74, 72, 64, 61, 70, 65)),
        "Damon Hill" to Profile("Forte", "Auge moderado", intArrayOf(75, 71, 67, 63, 73, 66, 73)),
        "Noah Strømsted" to Profile("Médio", "Auge moderado", intArrayOf(72, 66, 74, 73, 69, 60, 68)),
        "Kimi Räikkönen" to Profile("Pro", "Auge tardio", intArrayOf(69, 74, 67, 71, 65, 67, 63)),
        "Matteo De Palo" to Profile("Médio", "Auge moderado", intArrayOf(78, 69, 74, 69, 61, 61, 70)),
        "Felipe Massa" to Profile("Pro", "Auge moderado", intArrayOf(75, 64, 67, 67, 72, 68, 65)),
        "Mattia Colnaghi" to Profile("Médio", "Auge moderado", intArrayOf(72, 72, 72, 65, 68, 62, 72)),
        "Rubens Barrichello" to Profile("Pro", "Auge moderado", intArrayOf(69, 67, 67, 63, 64, 69, 67)),
        "Enzo Deligny" to Profile("Médio", "Auge moderado", intArrayOf(62, 60, 59, 59, 60, 53, 59)),
        "Mark Webber" to Profile("Forte", "Auge moderado", intArrayOf(75, 70, 67, 71, 71, 70, 69)),
        "Leonardo Vicente" to Profile("Pro", "Prodígio", intArrayOf(84, 83, 82, 81, 82, 80, 83)),
        "Juan Pablo Montoya" to Profile("Pro", "Auge tardio", intArrayOf(69, 73, 67, 67, 63, 71, 71)),
        "James Wharton" to Profile("Médio", "Auge moderado", intArrayOf(77, 67, 73, 64, 73, 64, 65)),
        "Jacques Villeneuve" to Profile("Forte", "Auge moderado", intArrayOf(75, 76, 67, 63, 70, 72, 73)),
        "Alex Powell" to Profile("Médio", "Demorado", intArrayOf(71, 70, 73, 72, 65, 65, 67)),
        "Esteban Ocon" to Profile("Médio", "Auge moderado", intArrayOf(70, 70, 68, 71, 68, 68, 68)),
        "Oliver Bearman" to Profile("Forte", "Prodígio", intArrayOf(84, 83, 80, 77, 75, 76, 77)),
        "Carlos Reutemann" to Profile("Forte", "Auge moderado", intArrayOf(75, 69, 67, 67, 69, 61, 65)),
        "Lyam Vicente" to Profile("Pro", "Prodígio", intArrayOf(82, 81, 83, 80, 81, 82, 80)),
        "Gilles Villeneuve" to Profile("Forte", "Auge moderado", intArrayOf(69, 72, 67, 63, 61, 62, 67)),
        "Laurens van Hoepen" to Profile("Médio", "Auge moderado", intArrayOf(62, 56, 60, 59, 59, 57, 60)),
        "Sergio Pérez" to Profile("Pro", "Auge moderado", intArrayOf(89, 87, 90, 92, 86, 88, 89)),
        "Valtteri Bottas" to Profile("Pro", "Auge moderado", intArrayOf(91, 93, 84, 85, 89, 87, 90)),
        "Gerhard Berger" to Profile("Médio", "Auge moderado", intArrayOf(69, 65, 67, 67, 75, 64, 71)),
        "Pyong Cris" to Profile("Pro", "Prodígio", intArrayOf(87, 86, 84, 82, 81, 83, 84)),
        "David Coulthard" to Profile("Forte", "Auge moderado", intArrayOf(75, 68, 67, 63, 67, 65, 73)),
        "Maciej Gładysz" to Profile("Médio", "Auge moderado", intArrayOf(70, 73, 72, 71, 61, 70, 66)),
        "Eddie Irvine" to Profile("Médio", "Auge moderado", intArrayOf(69, 71, 67, 71, 74, 66, 63)),
        "Jean Alesi" to Profile("Médio", "Auge moderado", intArrayOf(77, 65, 73, 68, 69, 60, 69)),
        "Heinz-Harald Frentzen" to Profile("Médio", "Auge moderado", intArrayOf(70, 69, 67, 69, 71, 67, 69)),
        "Jarno Trulli" to Profile("Médio", "Auge moderado", intArrayOf(70, 69, 68, 69, 70, 68, 69)),
        "Nick Heidfeld" to Profile("Médio", "Auge moderado", intArrayOf(70, 69, 67, 70, 70, 67, 70)),
        "Robert Kubica" to Profile("Médio", "Auge moderado", intArrayOf(70, 69, 68, 70, 70, 67, 69)),
        "Heikki Kovalainen" to Profile("Médio", "Auge moderado", intArrayOf(70, 70, 68, 68, 70, 68, 69)),
        "Romain Grosjean" to Profile("Médio", "Auge moderado", intArrayOf(72, 71, 70, 68, 66, 68, 68)),
        "Guanyu Zhou" to Profile("Forte", "Auge moderado", intArrayOf(80, 79, 78, 79, 81, 78, 79)),
        "Giancarlo Fisichella" to Profile("Forte", "Auge moderado", intArrayOf(79, 80, 78, 78, 80, 79, 79)),
        "Takuma Sato" to Profile("Forte", "Auge moderado", intArrayOf(82, 79, 85, 76, 74, 78, 79)),
        "Yuki Tsunoda" to Profile("Forte", "Auge moderado", intArrayOf(82, 81, 85, 79, 77, 80, 81)),
        "Riccardo Patrese" to Profile("Médio", "Auge rápido", intArrayOf(69, 70, 67, 69, 71, 68, 69)),
        "Michele Alboreto" to Profile("Forte", "Auge tardio", intArrayOf(79, 79, 78, 79, 79, 79, 80)),
        "Felipe Drugovich" to Profile("Forte", "Prodígio", intArrayOf(80, 79, 81, 78, 80, 82, 79)),
        "Bruce McLaren" to Profile("Forte", "Auge moderado", intArrayOf(80, 79, 78, 79, 80, 78, 79)),
        "Ralf Schumacher" to Profile("Forte", "Auge moderado", intArrayOf(82, 81, 78, 83, 82, 79, 81)),
        "Pedro de la Rosa" to Profile("Médio", "Demorado", intArrayOf(70, 69, 68, 68, 70, 68, 70)),
        "Adrian Sutil" to Profile("Médio", "Auge moderado", intArrayOf(69, 69, 68, 70, 68, 70, 69)),
        "Mick Schumacher" to Profile("Forte", "Auge moderado", intArrayOf(81, 80, 78, 82, 81, 79, 80)),
        "Pastor Maldonado" to Profile("Médio", "Auge moderado", intArrayOf(72, 71, 72, 67, 63, 68, 68)),
        "Alexander Rossi" to Profile("Forte", "Auge moderado", intArrayOf(80, 80, 79, 78, 77, 79, 80)),
    )

    /**
     * Prime-level ratings for historical drivers whose legacy source values were
     * authored on a different scale. These ratings are deliberately explicit and
     * independent of the driver's class label. Modern/current roster ratings are
     * injected by WorldDatabase and take precedence over this table.
     */
    private val historicalPrimeRatings: Map<String, IntArray> = mapOf(
        "Michael Schumacher" to intArrayOf(99, 98, 97, 95, 98, 96, 98),
        "Ayrton Senna" to intArrayOf(100, 99, 98, 96, 95, 98, 98),
        "Alain Prost" to intArrayOf(98, 97, 96, 98, 99, 92, 97),
        "Sebastian Vettel" to intArrayOf(97, 96, 94, 93, 96, 91, 96),
        "Nigel Mansell" to intArrayOf(96, 94, 94, 91, 92, 90, 93),
        "Mika Häkkinen" to intArrayOf(96, 97, 93, 92, 96, 90, 95),
        "Nico Rosberg" to intArrayOf(94, 95, 91, 94, 96, 89, 93),
        "Nelson Piquet" to intArrayOf(96, 94, 97, 94, 97, 91, 94),
        "Niki Lauda" to intArrayOf(97, 95, 94, 97, 98, 91, 96),
        "Juan Manuel Fangio" to intArrayOf(99, 97, 98, 95, 98, 91, 96),
        "Jenson Button" to intArrayOf(94, 93, 91, 93, 97, 94, 96),
        "James Hunt" to intArrayOf(94, 93, 95, 90, 90, 91, 92),
        "Jackie Stewart" to intArrayOf(97, 96, 96, 96, 97, 92, 96),
        "Jim Clark" to intArrayOf(99, 98, 97, 95, 97, 91, 96),
        "Emerson Fittipaldi" to intArrayOf(95, 94, 94, 93, 95, 91, 94),
        "Kimi Räikkönen" to intArrayOf(94, 94, 96, 91, 92, 95, 91),
        "Mark Webber" to intArrayOf(92, 91, 90, 91, 93, 90, 91),
        "Juan Pablo Montoya" to intArrayOf(94, 92, 96, 90, 91, 92, 90),
        "Mario Andretti" to intArrayOf(96, 94, 96, 94, 95, 91, 95),
        "Damon Hill" to intArrayOf(92, 91, 90, 93, 94, 90, 92),
        "Jack Brabham" to intArrayOf(94, 92, 94, 93, 96, 90, 93),
        "Bruce McLaren" to intArrayOf(94, 92, 94, 93, 94, 91, 94),
        "Gilles Villeneuve" to intArrayOf(96, 95, 98, 89, 90, 96, 91),
        "Carlos Reutemann" to intArrayOf(93, 92, 91, 91, 95, 90, 91),
        "Jacques Villeneuve" to intArrayOf(93, 92, 94, 90, 91, 92, 91),
        "Ralf Schumacher" to intArrayOf(91, 91, 90, 92, 93, 89, 91),
        "Felipe Massa" to intArrayOf(92, 91, 91, 90, 92, 90, 92),
        "Rubens Barrichello" to intArrayOf(92, 90, 91, 91, 93, 92, 92),
        "David Coulthard" to intArrayOf(91, 90, 90, 90, 92, 89, 91)
    )

    /**
     * Creates a career-ready profile. A class defines the driver's opening Overall
     * band and the maximum *starting potential* reachable in two class steps.
     * Individual attribute strengths are preserved as much as possible when the
     * seven ratings need to be brought into the opening band.
     */
    fun profile(name:String, ratingOverride:IntArray? = null): Profile {
        val base = profiles[name] ?: error("Perfil de piloto não definido: $name")
        // The legacy Fraco bucket has no official catalog entries; keep its existing
        // migration into Médio so older records remain readable.
        val normalizedClass = if (base.driverClass == "Fraco" || base.driverClass == "Normal") "Médio" else base.driverClass
        val rawRatings = (ratingOverride ?: historicalPrimeRatings[name] ?: base.ratings).copyOf()
        require(rawRatings.size == 7) { "$name deve ter exatamente 7 atributos" }
        require(rawRatings.all { it in 40..100 }) { "$name tem ratings fora da faixa 40..100" }
        val ratings = normalizeRatingsToClassBand(rawRatings, normalizedClass)
        val potential = if (base.potentialOverall >= overall(ratings))
            base.potentialOverall.coerceAtMost(maxPotentialOverall(normalizedClass))
        else estimatePotential(base.evolution, ratings, normalizedClass)
        return base.copy(
            driverClass = normalizedClass,
            ratings = ratings,
            potentialOverall = potential.coerceIn(overall(ratings), maxPotentialOverall(normalizedClass))
        )
    }

    /** The maximum personal potential available at career start: up to two classes above. */
    fun maxPotentialOverall(driverClass:String): Int {
        val officialClass = if (driverClass == "Fraco" || driverClass == "Normal") "Médio" else driverClass
        val ladder = listOf("Médio", "Forte", "Pro", "Lenda")
        val index = ladder.indexOf(officialClass).takeIf { it >= 0 }
            ?: error("Classe de piloto inválida: $driverClass")
        return ceiling(ladder[(index + 2).coerceAtMost(ladder.lastIndex)])
    }

    /**
     * Move a seven-attribute profile into the class's opening Overall band without
     * flattening the driver's strengths. The adjustment is distributed from the
     * strongest attributes downward (or weakest upward), retaining the seven-value
     * profile rather than assigning a synthetic equal rating.
     */
    fun normalizeRatingsToClassBand(source:IntArray, driverClass:String): IntArray {
        require(source.size == 7) { "Um piloto deve possuir exatamente sete atributos" }
        require(source.all { it in 40..100 }) { "Atributos fora da faixa 40..100" }
        val values = source.copyOf()
        val targetOverall = overall(values).coerceIn(minimumOverall(driverClass), ceiling(driverClass))
        val targetSum = targetOverall * values.size
        while (values.sum() < targetSum) {
            val index = values.indices.minByOrNull { values[it] } ?: break
            if (values[index] >= 100) break
            values[index]++
        }
        while (values.sum() > targetSum) {
            val index = values.indices.maxByOrNull { values[it] } ?: break
            if (values[index] <= 40) break
            values[index]--
        }
        return values
    }

    /** Evolution style supplies individual headroom; class limits the opening potential. */
    private fun estimatePotential(evolution:String, ratings:IntArray, driverClass:String):Int {
        val current = overall(ratings)
        val growth = when (evolution) {
            "Prodígio" -> 12
            "Auge rápido" -> 10
            "Auge moderado" -> 9
            "Auge tardio" -> 8
            "Normal" -> 7
            "Demorado" -> 11
            else -> 8
        }
        val styleFloor = when (evolution) {
            "Prodígio" -> 92
            "Auge rápido" -> 90
            "Auge moderado" -> 88
            "Auge tardio" -> 90
            "Normal" -> 84
            "Demorado" -> 86
            else -> 85
        }
        return maxOf(current, minOf(maxPotentialOverall(driverClass), maxOf(current + growth, styleFloor)))
    }

    fun ceiling(driverClass:String): Int = when (driverClass) {
        "Fraco", "Médio", "Normal" -> 69
        "Forte" -> 79
        "Pro" -> 89
        "Lenda" -> 100
        else -> error("Classe de piloto inválida: $driverClass")
    }

    /** Lower edge of each official opening Overall band. */
    fun minimumOverall(driverClass:String): Int = when (driverClass) {
        "Fraco", "Médio", "Normal" -> 60
        "Forte" -> 70
        "Pro" -> 80
        "Lenda" -> 90
        else -> error("Classe de piloto inválida: $driverClass")
    }

    /** Maximum positive evolution per individual attribute in one season. */
    fun maxAnnualGain(evolution:String): Int = when (evolution) {
        "Prodígio" -> 15
        "Auge rápido" -> 13
        "Auge moderado" -> 11
        "Auge tardio" -> 10
        "Normal" -> 8
        "Demorado" -> 6
        else -> error("Evolução inválida: $evolution")
    }
    fun overall(ratings:IntArray): Int = ratings.sum()/7
}
