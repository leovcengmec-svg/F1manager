package com.f1teammanager.core.race

import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

data class TyrePlan(
    val id: String,
    val sequence: List<Tyre>,
    val stintLaps: List<Int>
)

data class RaceCarStatus(
    val driverId: Int,
    val driverName: String,
    val position: Int,
    val tyre: Tyre,
    val tyreWear: Int,
    val fuelPercent: Int,
    val pitStops: Int,
    val stintLaps: Int,
    val lastLapMs: Long,
    val ersPercent: Int,
    val drsActive: Boolean,
    val status: String,
    val lastPitLossSec: Int = 0,
    val ersActive: Boolean = false,
    val ersGainMs: Int = 0,
    val drsGainMs: Int = 0,
    val engineReliability: Int = 95,
    val chassisReliability: Int = 95,
    val frontWingReliability: Int = 95,
    val rearWingReliability: Int = 95,
    val brakesReliability: Int = 95,
    val electricPowerUnitReliability: Int = 95,
    val averageReliability: Int = 95
)

/** V33: automatic lap simulation with live classification, tyre/fuel consequences and manager control. */
class CareerWeekendEngine(private val seed: Int = 20261003) {
    data class DriverPlan(
        var mode: DriverStrategyMode = DriverStrategyMode.BALANCED,
        var tyre: Tyre = Tyre.MEDIUM,
        var activePlan: String = "A",
        var planStintIndex: Int = 0,
        var tyrePlans: Map<String, TyrePlan> = emptyMap(),
        // Chuva encerra o plano A/B/C para este piloto. A partir daí,
        // todas as trocas de pneus precisam ser decididas manualmente.
        var weatherManualMode: Boolean = false
    )
    data class Decision(val request: ManagerDecisionRequest, val driverName: String)
    data class SessionSnapshot(
        val phase: String,
        val lap: Int,
        val totalLaps: Int,
        val grid: QualifyingResult?,
        val classification: List<FinishEntry>,
        val carStatus: List<RaceCarStatus>,
        val events: List<LapEvent>,
        val neutral: Neutralisation,
        val decision: Decision?,
        val plans: Map<Int, DriverPlan>,
        val alerts: List<DriverAlert>,
        val completed: Boolean,
        val weather: Weather,
        val qualifyingElapsedMs: Long = 0L,
        val qualifyingDurationMs: Long = 0L,
        val qualifyingPhaseIndex: Int = 0,
        val qualifyingRunning: Boolean = false,
    )

    private data class S(
        val p: RaceParticipant,
        val grid: Int,
        var total: Long = 0,
        var last: Long = 0,
        var best: Long = Long.MAX_VALUE,
        var laps: Int = 0,
        var stint: Int = 0,
        var stops: Int = 0,
        var dnf: Boolean = false,
        var wear: Int = 0,
        var wearExact: Double = 0.0,
        var tyre: Tyre = Tyre.MEDIUM,
        var fuel: Double = FuelModel.TANK_CAPACITY_KG,
        var lastPos: Int = Int.MAX_VALUE,
        var position: Int = grid,
        var ers: Double = 100.0,
        var drsActive: Boolean = false,
        var ersActive: Boolean = false,
        val componentReliability: MutableMap<com.f1teammanager.core.manager.CarComponent, Double> = mutableMapOf(),
        var dnfReason: String = "",
        var bypassCriticalOnce: Boolean = false,
        var lastFuelAlertLap: Int = -99,
        var lastTyreAlertLap: Int = -99,
        var lastPitLossSec: Int = 0,
        val aiPitBias: Int = 0,
    )

    private val random = Random(seed)
    // Qualifying randomness is isolated so the new session simulation cannot
    // shift the deterministic race-event sequence used after the grid is set.
    private val qualifyingRandom = Random(seed xor 0x5A17C0DE)
    private var circuit: RaceCircuit? = null
    private var states = mutableMapOf<Int, S>()
    private var grid: QualifyingResult? = null
    private var lap = 0
    private var neutral = Neutralisation.GREEN
    private var neutralEnd = 0
    private var weather = Weather.DRY
    private var lastWeatherChangeLap = 0
    private var pending: Decision? = null
    private val pendingDecisions = mutableListOf<Decision>()
    private var events = mutableListOf<LapEvent>()
    private var finished = false
    private var fastestId: Int? = null
    private var fastest = Long.MAX_VALUE
    private var qualifyingStage = 0 // número de sessões concluídas
    private var qualifyingElapsedMs = 0L
    private var qualifyingParticipants = emptyList<RaceParticipant>()
    private var qualifyingClockByDriver = mutableMapOf<Int, Long>()
    private var qualifyingNextLapByDriver = mutableMapOf<Int, Long>()
    private var qualifyingBestLapByDriver = mutableMapOf<Int, Long>()
    private var qualifyingLapCountByDriver = mutableMapOf<Int, Int>()
    private var qualifyingActive = false
    private var redFlagUsed = false
    private var dnfLimit = 0
    private var dnfCount = 0
    private val plans = mutableMapOf<Int, DriverPlan>()

    companion object {
        private const val STARTING_GRID_GAP_MS = 55L
        private const val Q1_DURATION_MS = 30L * 60L * 1000L
        private const val Q2_DURATION_MS = 20L * 60L * 1000L
        private const val Q3_DURATION_MS = 10L * 60L * 1000L
    }

    private fun qualifyingDuration(stage: Int): Long = when(stage) {
        0 -> Q1_DURATION_MS
        1 -> Q2_DURATION_MS
        else -> Q3_DURATION_MS
    }

    private fun qualifyingPhaseName(stage: Int): String = when(stage) {
        0 -> "Q1"
        1 -> "Q2"
        else -> "Q3"
    }

    private fun qualifyingLapTime(p: RaceParticipant, c: RaceCircuit, elapsedMs: Long): Long {
        val base = PitwallPaceModel(qualifyingRandom).qualifyingLapTime(p, c)
        // A qualifying session has good, normal and bad laps. Consistency narrows
        // the variance but never removes it, so positions can genuinely change.
        val consistency = p.consistency.coerceIn(40, 100)
        val roll = qualifyingRandom.nextDouble()
        val raw = when {
            roll < 0.06 -> -0.010 + qualifyingRandom.nextDouble(0.0, 0.004) // excelente
            roll < 0.22 -> -0.004 + qualifyingRandom.nextDouble(0.0, 0.003) // boa
            roll < 0.82 -> -0.001 + qualifyingRandom.nextDouble(0.0, 0.003) // normal
            roll < 0.96 -> 0.002 + qualifyingRandom.nextDouble(0.0, 0.006) // ruim
            else -> 0.008 + qualifyingRandom.nextDouble(0.0, 0.010) // muito ruim
        }
        val consistencyFactor = 1.18 - (consistency - 40) / 100.0 * 0.36
        val trackEvolution = -(elapsedMs.toDouble() / qualifyingDuration(qualifyingStage).coerceAtLeast(1L)) * 0.0025
        return max(45_000L, (base * (1.0 + raw * consistencyFactor + trackEvolution)).toLong())
    }

    private fun liveQualifyingEntries(): List<QualifyingEntry> {
        return qualifyingParticipants
            .map { p -> QualifyingEntry(p.driverId, 0, qualifyingBestLapByDriver[p.driverId] ?: Long.MAX_VALUE) }
            .sortedWith(compareBy<QualifyingEntry> { it.lapTimeMs }.thenBy { it.driverId })
            .mapIndexed { i, e -> e.copy(position = i + 1) }
    }

    private fun completedQualifyingPhase(stage: Int, entries: List<QualifyingEntry>): QualifyingPhase {
        val cutoff = if (stage == 0) 50 else if (stage == 1) 20 else entries.size
        return QualifyingPhase(
            qualifyingPhaseName(stage),
            entries,
            entries.drop(cutoff).map { it.driverId }
        )
    }

    private fun buildFinalGrid(phases: List<QualifyingPhase>): List<QualifyingEntry> {
        val q1 = phases[0].entries
        val q2 = phases[1].entries
        val q3 = phases[2].entries
        val q2Ids = q2.map { it.driverId }.toSet()
        val q3Ids = q3.map { it.driverId }.toSet()
        return (q3 +
            q2.filter { it.driverId !in q3Ids }.mapIndexed { i, e -> e.copy(position = 21 + i) } +
            q1.filter { it.driverId !in q2Ids }.mapIndexed { i, e -> e.copy(position = 51 + i) })
            .sortedBy { it.position }
    }

    fun start(participants: List<RaceParticipant>, c: RaceCircuit, playerTeamId: Int): SessionSnapshot {
        require(participants.size == 80) { "O campeonato deve iniciar com 80 pilotos; recebido ${participants.size}" }
        circuit = c
        lap = 0
        neutral = Neutralisation.GREEN
        neutralEnd = 0
        weather = Weather.DRY
        lastWeatherChangeLap = 0
        pending = null
        pendingDecisions.clear()
        events = mutableListOf()
        finished = false
        fastestId = null
        fastest = Long.MAX_VALUE
        qualifyingStage = 0
        qualifyingElapsedMs = 0L
        qualifyingParticipants = participants
        qualifyingClockByDriver = participants.associate { it.driverId to 0L }.toMutableMap()
        qualifyingNextLapByDriver = participants.associate { it.driverId to qualifyingLapTime(it, c, 0L) }.toMutableMap()
        qualifyingBestLapByDriver = participants.associate { it.driverId to Long.MAX_VALUE }.toMutableMap()
        qualifyingLapCountByDriver = participants.associate { it.driverId to 0 }.toMutableMap()
        qualifyingActive = false
        redFlagUsed = false
        dnfLimit = random.nextInt(0, 16)
        dnfCount = 0
        grid = QualifyingResult(
            emptyList(),
            listOf(
                QualifyingPhase("Q1", liveQualifyingEntries(), emptyList()),
                QualifyingPhase("Q2", emptyList(), emptyList()),
                QualifyingPhase("Q3", emptyList(), emptyList())
            )
        )
        states = participants.associate { p ->
            val g = p.driverId + 1
            p.driverId to S(
                p = p,
                grid = g,
                total = (g - 1L) * STARTING_GRID_GAP_MS,
                aiPitBias = ((p.driverId * 7) % 9) - 4,
                componentReliability = mutableMapOf(
                    com.f1teammanager.core.manager.CarComponent.ENGINE to p.engineReliability.toDouble(),
                    com.f1teammanager.core.manager.CarComponent.CHASSIS to p.chassisReliability.toDouble(),
                    com.f1teammanager.core.manager.CarComponent.FRONT_WING to p.frontWingReliability.toDouble(),
                    com.f1teammanager.core.manager.CarComponent.REAR_WING to p.rearWingReliability.toDouble(),
                    com.f1teammanager.core.manager.CarComponent.BRAKES to p.brakesReliability.toDouble(),
                    com.f1teammanager.core.manager.CarComponent.ELECTRIC_POWER_UNIT to p.electricPowerUnitReliability.toDouble()
                )
            )
        }.toMutableMap()
        plans.clear()
        participants.filter { it.teamId == playerTeamId }.forEach {
            val tyrePlans = TyreModel.buildDryPlans(c.laps)
            val firstTyre = tyrePlans["A"]?.sequence?.firstOrNull() ?: Tyre.MEDIUM
            plans[it.driverId] = DriverPlan(tyre = firstTyre, activePlan = "A", planStintIndex = 0, tyrePlans = tyrePlans)
            // O pneu definido pelo plano A/B/C precisa ser aplicado ao carro antes
            // da primeira volta. Antes disso o estado de corrida permanecia em MEDIUM
            // (valor padrão de S), mesmo quando o manager havia escolhido SOFT.
            states[it.driverId]?.let { state ->
                state.tyre = firstTyre
                state.stint = 0
                state.wear = 0
                state.wearExact = 0.0
            }
        }
        return snapshot("QUALIFYING", emptyList())
    }

    /** Advance the visible qualifying simulation by a bounded number of lap events. */
    fun advanceQualifyingSimulation(maxEvents: Int = 12): SessionSnapshot {
        require(!finished) { "Fim de semana concluído" }
        require(qualifyingStage < 3) { "Qualificação já concluída" }
        qualifyingActive = true
        val duration = qualifyingDuration(qualifyingStage)
        val newEvents = mutableListOf<LapEvent>()
        val currentStage = qualifyingStage
        for (eventIndex in 0 until maxEvents.coerceIn(1, 80)) {
            if (qualifyingStage != currentStage) break
            val next = qualifyingNextLapByDriver
                .filter { (id, time) -> qualifyingClockByDriver[id]!! + time <= duration }
                .minByOrNull { it.value }
            if (next == null) {
                finishQualifyingPhase()
                break
            }
            val id = next.key
            val current = qualifyingClockByDriver.getValue(id)
            val lapTime = next.value
            val finishAt = current + lapTime
            qualifyingClockByDriver[id] = finishAt
            qualifyingElapsedMs = max(qualifyingElapsedMs, finishAt).coerceAtMost(duration)
            val best = qualifyingBestLapByDriver.getValue(id)
            if (lapTime < best) {
                qualifyingBestLapByDriver[id] = lapTime
                newEvents += LapEvent(0, id, EventType.FASTEST_LAP, "${qualifyingPhaseName(qualifyingStage)} • ${qualifyingParticipants.first { it.driverId == id }.driverName} melhorou para ${lapTime / 60000}:${(lapTime / 1000) % 60}.${(lapTime % 1000).toString().padStart(3,'0')}")
            }
            qualifyingLapCountByDriver[id] = qualifyingLapCountByDriver.getValue(id) + 1
            qualifyingNextLapByDriver[id] = qualifyingLapTime(qualifyingParticipants.first { it.driverId == id }, circuit!!, finishAt)
        }
        if (qualifyingStage == currentStage && qualifyingClockByDriver.keys.all { id ->
                val elapsed = qualifyingClockByDriver[id] ?: 0L
                elapsed >= duration || elapsed + (qualifyingNextLapByDriver[id] ?: Long.MAX_VALUE) > duration
            }) {
            finishQualifyingPhase()
        }
        return snapshot("QUALIFYING", newEvents.takeLast(3))
    }

    /** Complete the current session immediately for headless season simulations/tests. */
    fun simulateQualifyingPhase(): SessionSnapshot {
        require(!finished) { "Fim de semana concluído" }
        require(qualifyingStage < 3) { "Qualificação já concluída" }
        val targetStage = qualifyingStage
        var guard = 0
        while (qualifyingStage == targetStage && ++guard < 10000) advanceQualifyingSimulation(80)
        require(qualifyingStage > targetStage) { "Não foi possível concluir a qualificação" }
        return snapshot("QUALIFYING", emptyList())
    }

    private fun finishQualifyingPhase() {
        if (!qualifyingActive || qualifyingStage >= 3) return
        val stage = qualifyingStage
        val entries = liveQualifyingEntries()
        val phase = completedQualifyingPhase(stage, entries)
        val previous = grid?.phases.orEmpty().toMutableList()
        while (previous.size < 3) previous += QualifyingPhase(qualifyingPhaseName(previous.size), emptyList(), emptyList())
        previous[stage] = phase
        qualifyingStage++
        qualifyingElapsedMs = if (stage == 2) qualifyingDuration(stage) else 0L
        qualifyingActive = false
        if (qualifyingStage < 3) {
            val survivors = entries.take(if (stage == 0) 50 else 20).mapNotNull { e -> qualifyingParticipants.firstOrNull { it.driverId == e.driverId } }
            qualifyingParticipants = survivors
            qualifyingClockByDriver = survivors.associate { it.driverId to 0L }.toMutableMap()
            qualifyingNextLapByDriver = survivors.associate { it.driverId to qualifyingLapTime(it, circuit!!, 0L) }.toMutableMap()
            qualifyingBestLapByDriver = survivors.associate { it.driverId to Long.MAX_VALUE }.toMutableMap()
            qualifyingLapCountByDriver = survivors.associate { it.driverId to 0 }.toMutableMap()
            previous[qualifyingStage] = QualifyingPhase(qualifyingPhaseName(qualifyingStage), liveQualifyingEntries(), emptyList())
            grid = QualifyingResult(emptyList(), previous)
        } else {
            // Preserve the deterministic race RNG sequence from V92: the former
            // static qualifying consumed exactly 150 qualifying jitter draws
            // (80 + 50 + 20). The new visual session uses its isolated RNG, so
            // consume the same count here without coupling quali outcomes to race events.
            repeat(150) { random.nextInt(-80, 81) }
            grid = QualifyingResult(buildFinalGrid(previous), previous)
        }
    }

    fun qualifyingComplete(): Boolean = qualifyingStage >= 3
    fun qualifyingRunning(): Boolean = qualifyingActive
    fun qualifyingPhaseIndex(): Int = qualifyingStage.coerceAtMost(2)
    fun qualifyingElapsedMs(): Long = qualifyingElapsedMs
    fun qualifyingDurationMs(): Long = if (qualifyingStage >= 3) Q3_DURATION_MS else qualifyingDuration(qualifyingStage)

    fun setPlan(driverId: Int, mode: DriverStrategyMode? = null, tyre: Tyre? = null): SessionSnapshot {
        val plan = plans[driverId] ?: error("Piloto não pertence à equipe do jogador")
        if (mode != null) plan.mode = mode
        if (tyre != null) plan.tyre = tyre
        states[driverId]?.tyre = plan.tyre
        return snapshot("RACE", emptyList())
    }

    fun snapshotForUi(): SessionSnapshot = snapshot(if (finished) "RESULT" else "RACE", emptyList())

    fun setTyrePlan(driverId: Int, planId: String): SessionSnapshot {
        val plan = plans[driverId] ?: error("Piloto não pertence à equipe do jogador")
        require(!plan.weatherManualMode) { "Plano A/B/C abandonado após entrada de chuva; troca manual obrigatória" }
        require(plan.tyrePlans.containsKey(planId)) { "Plano de pneus inexistente: $planId" }
        plan.activePlan = planId
        plan.planStintIndex = 0
        plan.tyre = plan.tyrePlans.getValue(planId).sequence.first()
        states[driverId]?.tyre = plan.tyre
        return snapshot("RACE", emptyList())
    }

    fun pitWithPlan(driverId: Int, planId: String): SessionSnapshot {
        val plan = plans[driverId] ?: error("Piloto não pertence à equipe do jogador")
        require(!plan.weatherManualMode) { "Plano A/B/C abandonado após entrada de chuva; troca manual obrigatória" }
        require(plan.tyrePlans.containsKey(planId)) { "Plano de pneus inexistente: $planId" }
        plan.activePlan = planId
        val s = states[driverId] ?: error("Piloto inexistente")
        val tyrePlan = plan.tyrePlans.getValue(planId)
        val nextIndex = (plan.planStintIndex + 1).coerceAtMost(tyrePlan.sequence.lastIndex)
        val nextTyre = tyrePlan.sequence[nextIndex]
        pit(s, nextTyre)
        plan.activePlan = planId
        plan.planStintIndex = nextIndex
        plan.tyre = nextTyre
        if (pending != null) completePendingDecision(false)
        return snapshot("RACE", emptyList())
    }

    fun setStrategy(driverId: Int, mode: DriverStrategyMode): SessionSnapshot {
        val plan = plans[driverId] ?: error("Piloto não pertence à equipe do jogador")
        plan.mode = mode
        return snapshot("RACE", emptyList())
    }

    fun pitNow(driverId: Int, tyre: Tyre = plans[driverId]?.tyre ?: Tyre.MEDIUM): SessionSnapshot {
        val s = states[driverId] ?: error("Piloto inexistente")
        require(!s.dnf && !finished) { "Piloto não está em corrida" }
        pit(s, tyre)
        // Qualquer troca manual abandona definitivamente o plano deste piloto.
        plans[driverId]?.let { plan ->
            plan.weatherManualMode = true
            plan.activePlan = "MANUAL"
            plan.tyre = tyre
        }
        if (pending?.request?.driverId == driverId) completePendingDecision(false)
        return snapshot("RACE", emptyList())
    }

    fun advance(): SessionSnapshot {
        check(!finished) { "Fim de semana concluído" }
        check(pending == null) { "Resolva a decisão pendente" }
        val c = circuit ?: error("Circuito não iniciado")
        if (lap == 0) lap = 1 else lap++
        if (lap > c.laps) return finish()
        val before = events.size

        if (neutral != Neutralisation.GREEN && lap > neutralEnd) {
            events += LapEvent(lap, null, if (neutral == Neutralisation.SAFETY_CAR) EventType.SAFETY_CAR_ENDED else EventType.VSC_ENDED, "Neutralização encerrada")
            neutral = Neutralisation.GREEN
        }

        val previousWeather = weather
        // O clima tem persistência: mudanças só podem acontecer após algumas voltas
        // e com probabilidades baixas. Assim a corrida pode ter chuva, mas não vira
        // uma troca constante de sol/nublado/chuva a cada poucas voltas.
        if (lap - lastWeatherChangeLap >= 6) {
            when (weather) {
                Weather.DRY -> if (lap >= 8 && random.nextDouble() < 0.018) weather = Weather.CLOUDY
                Weather.CLOUDY -> when {
                    random.nextDouble() < 0.025 -> weather = Weather.LIGHT_RAIN
                    random.nextDouble() < 0.018 -> weather = Weather.DRY
                }
                Weather.LIGHT_RAIN -> when {
                    random.nextDouble() < 0.025 -> weather = Weather.MEDIUM_RAIN
                    random.nextDouble() < 0.035 -> weather = Weather.CLOUDY
                }
                Weather.MEDIUM_RAIN -> when {
                    random.nextDouble() < 0.020 -> weather = Weather.HEAVY_RAIN
                    random.nextDouble() < 0.035 -> weather = Weather.LIGHT_RAIN
                }
                Weather.HEAVY_RAIN -> if (random.nextDouble() < 0.045) weather = Weather.MEDIUM_RAIN
            }
            if (weather != previousWeather) lastWeatherChangeLap = lap
        }

        // Quando a pista muda para chuva, os carros do jogador não podem ficar
        // silenciosamente em pneu de seco. O jogo pausa e entrega a decisão ao
        // manager; ao escolher BOX, a UI abre a seleção dos 5 compostos.
        if (weather != previousWeather && (weather == Weather.CLOUDY || weather == Weather.DRY) &&
            (previousWeather == Weather.LIGHT_RAIN || previousWeather == Weather.MEDIUM_RAIN || previousWeather == Weather.HEAVY_RAIN)) {
            val dryText = if (weather == Weather.DRY)
                "Pista seca. Pneus de chuva perdendo desempenho; troca para pneu de seco recomendada."
            else
                "Chuva diminuindo. Pista secando; considere trocar pneus de chuva."
            states.values.filter { plans.containsKey(it.p.driverId) && !it.dnf }.forEach { s ->
                events += LapEvent(lap, s.p.driverId, EventType.WEATHER_CHANGE, "Rádio: $dryText")
            }
        }

        if (weather != previousWeather && (weather == Weather.LIGHT_RAIN || weather == Weather.MEDIUM_RAIN || weather == Weather.HEAVY_RAIN)) {
            val rainText = if (weather == Weather.HEAVY_RAIN) {
                "Chuva forte detectada. WET recomendado."
            } else {
                "Chuva detectada. INTERMEDIÁRIO recomendado."
            }

            // A entrada de chuva abandona o plano A/B/C para os dois pilotos.
            // A partir deste momento nenhum stint do plano pode disparar um box
            // automático, nem quando a chuva terminar. Cada nova troca passa a
            // depender exclusivamente de uma decisão manual do manager.
            plans.values.forEach { it.weatherManualMode = true }

            val teamDrivers = states.values
                .filter { plans.containsKey(it.p.driverId) && !it.dnf }
                .sortedWith(compareBy<S> { it.position }.thenBy { it.grid })
            if (teamDrivers.isNotEmpty()) {
                if (pauseForPlayers(
                        "$rainText Escolha manualmente BOX ou permaneça na pista. O plano A/B/C foi abandonado para os dois pilotos.",
                        ManagerDecisionType.WEATHER_CHANGE
                    )) return snapshot("RACE", events.drop(before))
            }
        }

        if (neutral == Neutralisation.GREEN) {
            val r = random.nextDouble()
            // Neutralizações espontâneas são raras. A maior parte das neutralizações
            // deve nascer de um incidente relevante, e mesmo um acidente não implica
            // automaticamente VSC/SC.
            if (r < .0012 * c.safetyCarRisk) {
                neutral = Neutralisation.SAFETY_CAR
                neutralEnd = min(c.laps, lap + random.nextInt(2, 5))
                groupPeloton()
                events += LapEvent(lap, null, EventType.SAFETY_CAR_DEPLOYED, "Safety Car — pelotão agrupado")
                if (pauseForPlayers("Safety Car na pista. Box, manter ou estender?", ManagerDecisionType.SAFETY_CAR)) return snapshot("RACE", events.drop(before))
            } else if (r < .0040 * c.safetyCarRisk) {
                neutral = Neutralisation.VSC
                neutralEnd = min(c.laps, lap + random.nextInt(1, 3))
                events += LapEvent(lap, null, EventType.VSC_DEPLOYED, "VSC")
                if (pauseForPlayers("VSC ativo. Aproveitar a janela estratégica?", ManagerDecisionType.VSC)) return snapshot("RACE", events.drop(before))
            }
        }

        val active = states.values.filterNot { it.dnf }.sortedWith(compareBy<S> { it.total }.thenBy { it.grid })
        for (s in active) {
            val plan = plans[s.p.driverId]
            val aiWeatherTyre = when (weather) {
                Weather.HEAVY_RAIN -> Tyre.WET
                Weather.LIGHT_RAIN, Weather.MEDIUM_RAIN -> Tyre.INTERMEDIATE
                Weather.CLOUDY, Weather.DRY -> null
            }
            if (plan == null && !s.dnf && lap < c.laps) {
                if (aiWeatherTyre != null && s.tyre != aiWeatherTyre) pit(s, aiWeatherTyre)
                else if (s.wear >= (90 + s.aiPitBias).coerceIn(82, 96) || s.fuel <= FuelModel.TANK_CAPACITY_KG * 0.10) pit(s, nextTyre(s.tyre))
            }
            if (s.dnf) continue
            val mode = plan?.mode ?: aiMode(s, weather)

            // Incidentes reais: acidentes/falhas podem gerar VSC, Safety Car ou,
            // em um acidente grave, bandeira vermelha. Acidentes também podem
            // atingir um carro que esteja muito próximo.
            if (neutral == Neutralisation.GREEN && lap > 2 && !s.dnf) {
                val consistencyRisk = ((100 - s.p.consistency).coerceAtLeast(0) / 100.0)
                val racecraftRisk = ((100.0 - PitwallPaceModel(random).derivedRacecraft(s.p)).coerceAtLeast(0.0) / 100.0)
                val wearRisk = s.wear.coerceIn(0, 100) / 100.0
                val phase = if (lap <= 5 || lap >= c.laps - 3) 1.15 else 1.0
                val raceDnfFactor = if (dnfLimit == 0) 0.0 else 0.70 + (dnfLimit / 15.0) * 0.90
                val crashChance = 0.00055 * c.crashRisk * raceDnfFactor * (0.55 + consistencyRisk * 1.60 + racecraftRisk * 0.80) * phase * (1.0 + wearRisk * 0.90)
                val crashRoll = random.nextDouble()
                val crash = dnfCount < dnfLimit && crashRoll < crashChance
                if (crash) {
                    s.dnf = true
                    if (crash) dnfCount++
                    s.dnfReason = "ACIDENTE"
                    events += LapEvent(lap, s.p.driverId, EventType.CRASH, "${s.p.driverName} sofreu um acidente na volta $lap")

                    if (crash && random.nextDouble() < 0.32) {
                        val victim = states.values.filter { it.p.driverId != s.p.driverId && !it.dnf }
                            .minByOrNull { kotlin.math.abs(it.position - s.position) }
                        if (victim != null && kotlin.math.abs(victim.position - s.position) <= 3) {
                            if (dnfCount < dnfLimit) {
                                victim.dnf = true
                                dnfCount++
                                victim.dnfReason = "ACIDENTE • COLISÃO"
                                events += LapEvent(lap, victim.p.driverId, EventType.CRASH, "${victim.p.driverName} foi atingido no acidente de ${s.p.driverName}")
                            }
                        }
                    }

                    val severe = crash && !redFlagUsed && lap > 5 && random.nextDouble() < 0.04
                    if (severe) {
                        redFlagUsed = true
                        // Bandeira vermelha interrompe a corrida de verdade: não é Safety Car.
                        // O pelotão fica parado e será reorganizado para uma nova largada
                        // somente depois que os dois pilotos do manager tomarem suas decisões.
                        neutral = Neutralisation.GREEN
                        neutralEnd = lap
                        groupPeloton()
                        prepareRedFlagRestartPlans(c.laps - lap)
                        events += LapEvent(lap, null, EventType.RED_FLAG_DEPLOYED, "BANDEIRA VERMELHA — corrida interrompida; novos planos para ${c.laps - lap} voltas preparados")
                        if (pauseForPlayers("Bandeira vermelha após acidente. Escolha o plano de pneus para a relargada.", ManagerDecisionType.RED_FLAG)) return snapshot("RACE", events.drop(before))
                    } else {
                        // Um acidente não fecha automaticamente a pista. Só alguns
                        // incidentes têm gravidade suficiente para VSC/SC.
                        val neutralRoll = random.nextDouble()
                        val neutralAfterIncident = if (crash) {
                            when {
                                neutralRoll < 0.08 -> Neutralisation.SAFETY_CAR
                                neutralRoll < 0.23 -> Neutralisation.VSC
                                else -> Neutralisation.GREEN
                            }
                        } else {
                            if (neutralRoll < 0.04) Neutralisation.VSC else Neutralisation.GREEN
                        }
                        if (neutralAfterIncident != Neutralisation.GREEN) {
                            neutral = neutralAfterIncident
                            neutralEnd = min(c.laps, lap + if (neutral == Neutralisation.SAFETY_CAR) random.nextInt(2, 5) else random.nextInt(1, 3))
                            events += LapEvent(lap, null, if (neutral == Neutralisation.SAFETY_CAR) EventType.SAFETY_CAR_DEPLOYED else EventType.VSC_DEPLOYED, if (neutral == Neutralisation.SAFETY_CAR) "Safety Car após acidente" else "VSC após acidente")
                            if (pauseForPlayers(if (neutral == Neutralisation.SAFETY_CAR) "Acidente na pista. Safety Car. Box, manter ou estender?" else "Acidente na pista. VSC ativo. Aproveitar a janela?", if (neutral == Neutralisation.SAFETY_CAR) ManagerDecisionType.SAFETY_CAR else ManagerDecisionType.VSC)) return snapshot("RACE", events.drop(before))
                        }
                    }
                    continue
                }
            }

            if (plan != null && lap < c.laps && !s.bypassCriticalOnce) {
                val activeTyrePlan = if (plan.weatherManualMode) null else plan.tyrePlans[plan.activePlan]
                if (activeTyrePlan != null && plan.planStintIndex < activeTyrePlan.sequence.lastIndex) {
                    // O plano usa a vida real do composto. Não reduzimos a quantidade
                    // de voltas do pneu para fazer a estratégia caber matematicamente.
                    val targetStintLaps = activeTyrePlan.stintLaps.getOrElse(plan.planStintIndex) { s.tyre.targetLaps }
                    if (s.stint >= targetStintLaps) {
                        val nextIndex = (plan.planStintIndex + 1).coerceAtMost(activeTyrePlan.sequence.lastIndex)
                        val nextCompound = activeTyrePlan.sequence[nextIndex]
                        pit(s, nextCompound)
                        plan.planStintIndex = nextIndex
                        plan.tyre = nextCompound
                    }
                }

                if ((weather == Weather.LIGHT_RAIN || weather == Weather.MEDIUM_RAIN) && s.tyre != Tyre.INTERMEDIATE && lap != s.lastTyreAlertLap) {
                    s.lastTyreAlertLap = lap
                    events += LapEvent(lap, s.p.driverId, EventType.WEATHER_CHANGE, "Rádio: chuva fraca/média — intermediário recomendado")
                }
                if (weather == Weather.HEAVY_RAIN && s.tyre != Tyre.WET && lap != s.lastTyreAlertLap) {
                    s.lastTyreAlertLap = lap
                    events += LapEvent(lap, s.p.driverId, EventType.WEATHER_CHANGE, "Rádio: chuva forte — WET recomendado")
                }
                if (FuelModel.fuelPercent(s.fuel) <= 25 && lap != s.lastFuelAlertLap) {
                    s.lastFuelAlertLap = lap
                    events += LapEvent(lap, s.p.driverId, EventType.WEAR_WARNING, "Rádio: combustível baixo (${FuelModel.fuelPercent(s.fuel)}%)")
                }
                if (s.wear >= 65 && lap != s.lastTyreAlertLap) {
                    s.lastTyreAlertLap = lap
                    events += LapEvent(lap, s.p.driverId, EventType.WEAR_WARNING, "Rádio: ${s.tyre} perdendo desempenho (${s.wear}%)")
                }
                if (FuelModel.fuelPercent(s.fuel) <= 12) {
                    if (pauseForDriver(s, "Combustível crítico: ${FuelModel.fuelPercent(s.fuel)}%. Poupar combustível para concluir a prova.", ManagerDecisionType.FUEL_CRITICAL)) return snapshot("RACE", events.drop(before))
                }
                // A vida definida do composto é a referência de uso.
                // O alerta crítico só aparece no fim da janela útil, não 4–5 voltas antes.
                if (s.wear >= 95) {
                    if (pauseForDriver(s, "Pneu crítico: ${s.wear}%. A vida útil deste jogo de pneus está no fim.", ManagerDecisionType.TYRE_CRITICAL)) return snapshot("RACE", events.drop(before))
                }
            }

            s.bypassCriticalOnce = false
            // ERS é automático, mas precisa de um ciclo real: usar, esvaziar e recuperar.
            // Ataque usa ERS sempre que houver carga útil; equilibrado preserva uma reserva;
            // defesa conserva a bateria para recuperação.
            val ersThreshold = when (mode) {
                DriverStrategyMode.ATTACK -> 20.0
                DriverStrategyMode.BALANCED -> 35.0
                DriverStrategyMode.DEFENSE -> 101.0
            }
            val epuReliability = s.componentReliability[com.f1teammanager.core.manager.CarComponent.ELECTRIC_POWER_UNIT] ?: s.p.electricPowerUnitReliability.toDouble()
            val ersAvailable = epuReliability > 0.0 && s.ers >= ersThreshold
            s.ersActive = ersAvailable
            val ersBoost = if (ersAvailable) -PitwallPaceModel(random).ersGainMs(s.p, c, s.ers) else 0L

            // DRS é automático e independente da estratégia. A regra é <= 1,000 s do carro à frente.
            // O ganho é sempre negativo em ms: reduz o tempo da volta.
            val orderedBeforeLap = states.values.filterNot { it.dnf }
                .sortedWith(compareBy<S> { it.total }.thenBy { it.grid })
            val idxBeforeLap = orderedBeforeLap.indexOfFirst { it.p.driverId == s.p.driverId }
            val aheadBeforeLap = if (idxBeforeLap > 0) orderedBeforeLap[idxBeforeLap - 1] else null
            val gapBeforeLap = aheadBeforeLap?.let { (s.total - it.total).coerceAtLeast(0L) }
            val rearWingReliability = s.componentReliability[com.f1teammanager.core.manager.CarComponent.REAR_WING] ?: s.p.rearWingReliability.toDouble()
            s.drsActive = rearWingReliability > 0.0 && aheadBeforeLap != null && gapBeforeLap != null && gapBeforeLap <= 1000L && lap > 2
            val drsBoost = if (s.drsActive) -PitwallPaceModel(random).drsGainMs(s.p, c) else 0L
            val pace = PitwallPaceModel(random)
            val remainingFuel = max(0.0, s.fuel)
            var lapMs = pace.lapTime(s.p, c, remainingFuel, s.stint, s.tyre, false)
            lapMs = TyreModel.applyLapModifiers(
                carDriverLapMs = lapMs,
                gpAverageLapMs = c.baseLapTimeMs,
                tyre = s.tyre,
                weather = weather,
                wearPercent = s.wear,
                mode = mode
            )
            val reliabilityPenalty = s.componentReliability.entries.sumOf { (component, value) ->
                ReliabilityModel.performanceLossPercent(component, value)
            }
            lapMs = (lapMs + c.baseLapTimeMs * reliabilityPenalty).toLong()
            val fuelMultiplier = TyreModel.fuelPenaltyMultiplier(FuelModel.fuelPercent(s.fuel).toDouble())
            lapMs = (lapMs + c.baseLapTimeMs * (fuelMultiplier - 1.0)).toLong().coerceAtLeast(45_000L)
            lapMs += ersBoost + drsBoost
            lapMs += when (neutral) {
                Neutralisation.SAFETY_CAR -> 9000
                Neutralisation.VSC -> 4500
                Neutralisation.GREEN -> 0
            }
            lapMs += when (weather) {
                Weather.DRY -> 0
                Weather.CLOUDY -> 120
                Weather.LIGHT_RAIN -> rainPenalty(s.p, s.tyre, Weather.LIGHT_RAIN)
                Weather.MEDIUM_RAIN -> rainPenalty(s.p, s.tyre, Weather.MEDIUM_RAIN)
                Weather.HEAVY_RAIN -> rainPenalty(s.p, s.tyre, Weather.HEAVY_RAIN)
            }

            s.total += lapMs.coerceAtLeast(45000)
            s.last = lapMs
            s.laps = lap
            s.stint++
            // Combustível é finito e NÃO é reabastecido durante o pit stop.
            // O tanque inicial é dimensionado para completar a distância + 2 voltas
            // de segurança mesmo em ATTACK contínuo. Ataque consome 10% mais que
            // equilibrado; defesa economiza. Chuva reduz o consumo.
            s.fuel = max(0.0, s.fuel - FuelModel.consumptionPerLap(c.laps, mode, weather, s.tyre))
            // targetLaps é a vida-base real do composto em ritmo equilibrado.
            // Os fatores abaixo alteram essa vida sem destruir a referência de voltas.
            val wearFactor = TyreModel.tyreWeatherWearFactor(s.tyre, weather)
            val strategyWearFactor = TyreModel.strategyWearFactor(mode)
            // A vida-base do composto é fixa: Soft 15, Medium 22, Hard 30.
            // Em seco/equilibrado: 30 voltas de Hard = 100% (1% por volta).
            // Postura altera somente o desgaste: Ataque 1.10%/volta, Defesa 0.90%/volta.
            // O atributo de conservação de pneus do piloto também entra no desgaste real,
            // mas de forma limitada para não destruir a referência 15/25/36.
            val tyreInfluence = DriverAttributeInfluence.tyre(s.p.tyreWear)
            val driverWearFactor = (1.0 - tyreInfluence).coerceIn(0.90, 1.10)
            val wearIncrement = 100.0 / s.tyre.targetLaps * wearFactor * strategyWearFactor * driverWearFactor
            s.wearExact += wearIncrement
            s.wear = s.wearExact.coerceIn(0.0, 100.0).toInt()

            // Confiabilidade: degradação por volta, com margem dinâmica.
            // O valor de fábrica permanece intacto; apenas o estado desta corrida muda.
            val failedComponents = mutableListOf<com.f1teammanager.core.manager.CarComponent>()
            com.f1teammanager.core.manager.CarComponent.values().forEach { component ->
                val factoryReliability = when (component) {
                    com.f1teammanager.core.manager.CarComponent.ENGINE -> s.p.engineReliability
                    com.f1teammanager.core.manager.CarComponent.CHASSIS -> s.p.chassisReliability
                    com.f1teammanager.core.manager.CarComponent.FRONT_WING -> s.p.frontWingReliability
                    com.f1teammanager.core.manager.CarComponent.REAR_WING -> s.p.rearWingReliability
                    com.f1teammanager.core.manager.CarComponent.BRAKES -> s.p.brakesReliability
                    com.f1teammanager.core.manager.CarComponent.ELECTRIC_POWER_UNIT -> s.p.electricPowerUnitReliability
                }
                val current = s.componentReliability[component] ?: factoryReliability.toDouble()
                if (current > 0.0) {
                    val d = ReliabilityModel.degrade(factoryReliability, current, component, random, c.reliabilityRisk)
                    val next = (current - d.amount).coerceAtLeast(0.0)
                    s.componentReliability[component] = next
                    if (d.stressEvent && next > 0.0) {
                        events += LapEvent(lap, s.p.driverId, EventType.WEAR_WARNING, "${s.p.driverName}: esforço anormal em ${componentLabel(component)}; confiabilidade ${next.toInt()}%")
                    }
                    if (next <= 0.0) failedComponents += component
                }
            }

            // Falhas com consequência específica. Motor, freios e chassi podem gerar DNF;
            // asa dianteira é restaurada no pit, traseira perde DRS e EPU perde ERS.
            failedComponents.forEach { component ->
                when (component) {
                    com.f1teammanager.core.manager.CarComponent.ENGINE,
                    com.f1teammanager.core.manager.CarComponent.BRAKES -> {
                        if (!s.dnf) {
                            s.dnf = true
                            s.dnfReason = if (component == com.f1teammanager.core.manager.CarComponent.ENGINE) "FALHA • MOTOR" else "FALHA • FREIOS"
                            events += LapEvent(lap, s.p.driverId, EventType.MECHANICAL_FAILURE, "${s.p.driverName}: ${componentLabel(component)} chegou a 0% — ${s.dnfReason}")
                        }
                    }
                    com.f1teammanager.core.manager.CarComponent.CHASSIS -> {
                        val remaining = (c.laps - lap).coerceAtLeast(0)
                        val lastTwentyPercent = remaining <= kotlin.math.ceil(c.laps * 0.20).toInt()
                        if (lastTwentyPercent) {
                            s.dnf = true
                            s.dnfReason = "FALHA • CHASSI"
                            events += LapEvent(lap, s.p.driverId, EventType.MECHANICAL_FAILURE, "${s.p.driverName}: chassi chegou a 0% nos últimos 20% do GP — DFN")
                        } else {
                            events += LapEvent(lap, s.p.driverId, EventType.WEAR_WARNING, "${s.p.driverName}: chassi chegou a 0%; perda de desempenho máxima")
                        }
                    }
                    com.f1teammanager.core.manager.CarComponent.FRONT_WING -> {
                        val tyreBefore = s.tyre
                        pit(s, tyreBefore)
                        s.componentReliability[component] = s.p.frontWingReliability.coerceIn(40, 100).toDouble()
                        events += LapEvent(lap, s.p.driverId, EventType.MECHANICAL_FAILURE, "${s.p.driverName}: asa dianteira chegou a 0%; pit-stop restaurou para ${s.p.frontWingReliability}%")
                    }
                    com.f1teammanager.core.manager.CarComponent.REAR_WING -> {
                        s.drsActive = false
                        events += LapEvent(lap, s.p.driverId, EventType.MECHANICAL_FAILURE, "${s.p.driverName}: asa traseira chegou a 0%; DRS perdido")
                    }
                    com.f1teammanager.core.manager.CarComponent.ELECTRIC_POWER_UNIT -> {
                        s.ers = 0.0
                        s.ersActive = false
                        events += LapEvent(lap, s.p.driverId, EventType.MECHANICAL_FAILURE, "${s.p.driverName}: unidade de potência elétrica chegou a 0%; ERS perdido")
                    }
                }
            }

            // ERS recarrega automaticamente quando não está em uso e descarrega quando entrega potência.
            // Freios determinam a eficiência de recuperação; a Unidade elétrica
            // continua responsável pelo uso/entrega do ERS. N6 = referência (90%).
            val recoveryEfficiency = CarComponentInfluence.brakeErsRecovery(s.p.brakesPerformance)
            val electricEfficiency = CarComponentInfluence.electricPowerUnitErsEfficiency(s.p.electricPowerUnitPerformance)
            val ersDelta = if (s.ersActive) {
                // A better electrical unit extracts more useful energy from the same ERS reserve.
                -12.0 * (0.90 / electricEfficiency)
            } else {
                // Brakes recover the energy; the electrical unit determines how much of it becomes usable reserve.
                8.0 * (recoveryEfficiency / 0.90) * (electricEfficiency / 0.90)
            }
            s.ers = (s.ers + ersDelta).coerceIn(0.0, 100.0)

            if (lap < c.laps && s.fuel <= 0.0) {
                s.dnf = true
                s.dnfReason = "SEM COMBUSTÍVEL"
                events += LapEvent(lap, s.p.driverId, EventType.DNF, "${s.p.driverName} ficou sem combustível")
            } else if (s.wear >= 100 && s.stint > s.tyre.targetLaps + 5) {
                // DNF por pneu é independente da cota de acidentes.
                s.dnf = true
                s.dnfReason = "PNEU DEGRADADO"
                events += LapEvent(lap, s.p.driverId, EventType.DNF, "${s.p.driverName} perdeu o pneu por degradação")
            }

            if (lapMs < s.best) {
                s.best = lapMs
                if (lapMs < fastest) {
                    fastest = lapMs
                    fastestId = s.p.driverId
                }
            }
        }

        // Duelo real por posição: no máximo uma troca por carro por volta.
        // O DRS entra diretamente no ataque; Freios e atributos do piloto fecham o duelo.
        val duelOrder = states.values.filterNot { it.dnf }
            .sortedWith(compareBy<S> { it.position }.thenBy { it.grid })
            .toMutableList()
        for (i in 1 until duelOrder.size) {
            val attacker = duelOrder[i]
            val defender = duelOrder[i - 1]
            if (attacker.dnf || defender.dnf) continue
            val gap = (attacker.total - defender.total).coerceAtLeast(0L)
            val drsFactor = if (attacker.drsActive && gap <= 1000L)
                PitwallPaceModel(random).drsAttackEfficiency(attacker.p) else 1.0
            val attackSkill =
                DriverAttributeInfluence.overtaking(attacker.p.overtaking) *
                    CarComponentInfluence.brakeOvertakingEfficiency(attacker.p.brakesPerformance) *
                    drsFactor
            val defenseSkill =
                DriverAttributeInfluence.defense(defender.p.defense) *
                    CarComponentInfluence.brakeDefenseEfficiency(defender.p.brakesPerformance)
            val paceAdvantage = ((defender.total - attacker.total).toDouble() / 2000.0).coerceIn(-0.35, 0.35)
            val probability = (0.18 + (attackSkill - defenseSkill) * 0.42 + paceAdvantage).coerceIn(0.03, 0.82)
            if (gap <= 1200L && random.nextDouble() < probability) {
                val oldAttacker = attacker.position
                val oldDefender = defender.position
                attacker.position = oldDefender
                defender.position = oldAttacker
                duelOrder[i] = defender
                duelOrder[i - 1] = attacker
                events += LapEvent(lap, attacker.p.driverId, EventType.OVERTAKE,
                    "${attacker.p.driverName} ultrapassou ${defender.p.driverName}${if (attacker.drsActive) " com DRS" else ""}")
            }
        }
        duelOrder.forEachIndexed { index, car ->
            car.position = index + 1
            car.lastPos = car.position
        }

        val orderedNow = states.values.filterNot { it.dnf }
            .sortedWith(compareBy<S> { it.position }.thenBy { it.grid })
        orderedNow.forEachIndexed { index, car ->
            val ahead = orderedNow.getOrNull(index - 1)
            // DRS is automatic and uses the actual time gap to the car immediately ahead.
            car.drsActive = car.position > 1 && ahead != null && (car.total - ahead.total) in 0L..1000L && lap > 2
        }
        if (lap >= c.laps) return finish()
        return snapshot("RACE", events.drop(before))
    }

    /**
     * Exposes the final race result to the career layer. The previous update
     * changed the playable engine to CareerWeekendEngine but omitted this
     * adapter, leaving the main UI without a
     * compilable result() method.
     */
    fun result(): RaceResult {
        check(finished) { "A corrida ainda não terminou" }
        val classification = currentClassification()
        val base = RaceResult(
            classification = classification,
            events = events.toList(),
            fastestLapDriverId = fastestId,
            weather = weather,
            points = emptyMap(),
            safetyCarLaps = neutralisationLaps(EventType.SAFETY_CAR_DEPLOYED, EventType.SAFETY_CAR_ENDED),
            vscLaps = neutralisationLaps(EventType.VSC_DEPLOYED, EventType.VSC_ENDED),
            fastestLapTimeMs = fastest.takeIf { it != Long.MAX_VALUE } ?: 0L
        )
        return base.copy(points = ChampionshipEngine.award(base))
    }

    private fun neutralisationLaps(startType: EventType, endType: EventType): Int {
        var startLap: Int? = null
        var total = 0
        events.forEach { event ->
            when (event.type) {
                startType -> if (startLap == null) startLap = event.lap
                endType -> {
                    val start = startLap
                    if (start != null) total += (event.lap - start).coerceAtLeast(1)
                    startLap = null
                }
                else -> Unit
            }
        }
        startLap?.let { total += (lap - it + 1).coerceAtLeast(1) }
        return total
    }

    fun choose(action: ManagerDecisionAction): SessionSnapshot {
        val d = pending ?: error("Nenhuma decisão pendente")
        val s = states[d.request.driverId]
        if (d.request.type == ManagerDecisionType.RED_FLAG) {
            val planId = when (action) {
                ManagerDecisionAction.RESTART_PLAN_A -> "A"
                ManagerDecisionAction.RESTART_PLAN_B -> "B"
                ManagerDecisionAction.RESTART_PLAN_C -> "C"
                ManagerDecisionAction.RESTART_PLAN_D -> "D"
                else -> null
            }
            if (planId != null) {
                applyRedFlagPlanChoice(d, planId)
            } else {
                val tyre = when (action) {
                    ManagerDecisionAction.CHANGE_TYRE_SOFT, ManagerDecisionAction.RESTART_ATTACK -> Tyre.SOFT
                    ManagerDecisionAction.CHANGE_TYRE_MEDIUM, ManagerDecisionAction.RESTART_BALANCED -> Tyre.MEDIUM
                    ManagerDecisionAction.CHANGE_TYRE_HARD, ManagerDecisionAction.RESTART_DEFENSE -> Tyre.HARD
                    ManagerDecisionAction.CHANGE_TYRE_INTERMEDIATE -> Tyre.INTERMEDIATE
                    ManagerDecisionAction.CHANGE_TYRE_WET -> Tyre.WET
                    else -> s?.tyre ?: Tyre.MEDIUM
                }
                val posture = when (action) {
                    ManagerDecisionAction.RESTART_ATTACK -> DriverPosture.ATTACK
                    ManagerDecisionAction.RESTART_DEFENSE -> DriverPosture.DEFENSE
                    else -> DriverPosture.BALANCED
                }
                applyRedFlagChoice(d, tyre, posture)
            }
        } else if (s != null) {
            when (action) {
                ManagerDecisionAction.BOX -> {
                    val tyre = plans[s.p.driverId]?.tyre ?: nextTyre(s.tyre)
                    pit(s, tyre)
                    plans[s.p.driverId]?.let { it.tyre = tyre; it.activePlan = "MANUAL"; it.weatherManualMode = true }
                }
                ManagerDecisionAction.SAVE_FUEL -> { plans[s.p.driverId]?.mode = DriverStrategyMode.DEFENSE; s.bypassCriticalOnce = true }
                ManagerDecisionAction.CHANGE_STRATEGY -> { plans[s.p.driverId]?.mode = DriverStrategyMode.BALANCED; s.bypassCriticalOnce = true }
                ManagerDecisionAction.EXTEND_STINT, ManagerDecisionAction.STAY_OUT -> s.bypassCriticalOnce = true
                ManagerDecisionAction.RESTART_ATTACK -> plans[s.p.driverId]?.mode = DriverStrategyMode.ATTACK
                ManagerDecisionAction.RESTART_BALANCED -> plans[s.p.driverId]?.mode = DriverStrategyMode.BALANCED
                ManagerDecisionAction.RESTART_DEFENSE -> plans[s.p.driverId]?.mode = DriverStrategyMode.DEFENSE
                ManagerDecisionAction.RESTART_PLAN_A, ManagerDecisionAction.RESTART_PLAN_B, ManagerDecisionAction.RESTART_PLAN_C, ManagerDecisionAction.RESTART_PLAN_D -> Unit
                ManagerDecisionAction.CHANGE_TYRE_SOFT -> { pit(s, Tyre.SOFT); plans[s.p.driverId]?.let { it.tyre = Tyre.SOFT; it.activePlan = "MANUAL"; it.weatherManualMode = true } }
                ManagerDecisionAction.CHANGE_TYRE_MEDIUM -> { pit(s, Tyre.MEDIUM); plans[s.p.driverId]?.let { it.tyre = Tyre.MEDIUM; it.activePlan = "MANUAL"; it.weatherManualMode = true } }
                ManagerDecisionAction.CHANGE_TYRE_HARD -> { pit(s, Tyre.HARD); plans[s.p.driverId]?.let { it.tyre = Tyre.HARD; it.activePlan = "MANUAL"; it.weatherManualMode = true } }
                ManagerDecisionAction.CHANGE_TYRE_INTERMEDIATE -> { pit(s, Tyre.INTERMEDIATE); plans[s.p.driverId]?.let { it.tyre = Tyre.INTERMEDIATE; it.activePlan = "MANUAL"; it.weatherManualMode = true } }
                ManagerDecisionAction.CHANGE_TYRE_WET -> { pit(s, Tyre.WET); plans[s.p.driverId]?.let { it.tyre = Tyre.WET; it.activePlan = "MANUAL"; it.weatherManualMode = true } }
            }
        }
        completePendingDecision(d.request.type == ManagerDecisionType.RED_FLAG)
        return snapshot("RACE", emptyList())
    }

    fun chooseRedFlag(tyre: Tyre, posture: DriverPosture): SessionSnapshot {
        val d = pending ?: error("Nenhuma decisão pendente")
        require(d.request.type == ManagerDecisionType.RED_FLAG)
        applyRedFlagChoice(d, tyre, posture)
        completePendingDecision(true)
        return snapshot("RACE", emptyList())
    }

    private fun applyRedFlagChoice(d: Decision, tyre: Tyre, posture: DriverPosture) {
        val s = states[d.request.driverId] ?: return
        s.tyre = tyre
        s.wear = 0
        s.wearExact = 0.0
        s.stint = 0
        plans[s.p.driverId]?.let {
            it.mode = posture.toMode()
            it.tyre = tyre
            it.planStintIndex = 0
            it.activePlan = "MANUAL"
            it.weatherManualMode = true
        }
        events += LapEvent(lap, s.p.driverId, EventType.RED_FLAG_DEPLOYED, "Relargada: ${tyreLabel(tyre)} / $posture")
    }

    private fun applyRedFlagPlanChoice(d: Decision, planId: String) {
        val s = states[d.request.driverId] ?: return
        val plan = plans[s.p.driverId] ?: return
        val selected = plan.tyrePlans[planId] ?: return
        val firstTyre = selected.sequence.firstOrNull() ?: s.tyre
        s.tyre = firstTyre
        s.wear = 0
        s.wearExact = 0.0
        s.stint = 0
        plan.activePlan = planId
        plan.planStintIndex = 0
        plan.tyre = firstTyre
        plan.weatherManualMode = false
        events += LapEvent(lap, s.p.driverId, EventType.RED_FLAG_DEPLOYED, "Relargada: Plano $planId — ${tyreLabel(firstTyre)}")
    }

    private fun prepareRedFlagRestartPlans(remainingLaps: Int) {
        val remaining = remainingLaps.coerceAtLeast(1)
        // Recalcula os quatro planos do zero para a distância que realmente falta.
        // Assim uma estratégia de 2 ou 3 paradas da corrida original não é carregada
        // para uma relargada com poucas voltas restantes.
        plans.forEach { (driverId, plan) ->
            val fresh = TyreModel.buildDryPlans(remaining)
            val first = fresh["A"]?.sequence?.firstOrNull() ?: plan.tyre
            plan.tyrePlans = fresh
            plan.activePlan = "A"
            plan.planStintIndex = 0
            plan.tyre = first
            plan.weatherManualMode = false
        }

        // Os 78 carros da IA que continuam na prova também recebem uma nova escolha
        // coerente com o restante da corrida. Não há reabastecimento nem tempo de pit.
        states.values.filterNot { it.dnf }.filter { !plans.containsKey(it.p.driverId) }.forEach { s ->
            val restartTyre = when (weather) {
                Weather.HEAVY_RAIN -> Tyre.WET
                Weather.LIGHT_RAIN, Weather.MEDIUM_RAIN -> Tyre.INTERMEDIATE
                else -> when {
                    remaining <= 12 -> Tyre.SOFT
                    remaining <= 24 -> Tyre.MEDIUM
                    else -> if (s.tyre == Tyre.SOFT || s.tyre == Tyre.MEDIUM || s.tyre == Tyre.HARD) s.tyre else Tyre.MEDIUM
                }
            }
            s.tyre = restartTyre
            s.wear = 0
            s.wearExact = 0.0
            s.stint = 0
        }
    }

    private fun completePendingDecision(wasRedFlag: Boolean) {
        if (pendingDecisions.isNotEmpty()) {
            pending = pendingDecisions.removeAt(0)
            return
        }
        pending = null
        if (wasRedFlag) {
            // Nova largada: mantém a volta já percorrida, mas remove os gaps.
            // Combustível não é reabastecido pela bandeira vermelha.
            groupPeloton()
            events += LapEvent(lap, null, EventType.RED_FLAG_DEPLOYED, "RELARGADA — bandeira verde")
        }
    }

    private fun DriverPosture.toMode() = when (this) {
        DriverPosture.ATTACK -> DriverStrategyMode.ATTACK
        DriverPosture.BALANCED -> DriverStrategyMode.BALANCED
        DriverPosture.DEFENSE -> DriverStrategyMode.DEFENSE
    }

    private fun pauseForPlayers(message: String, type: ManagerDecisionType): Boolean {
        val teamDrivers = states.values
            .filter { plans.containsKey(it.p.driverId) && !it.dnf }
            .sortedWith(compareBy<S> { it.position }.thenBy { it.grid })
        if (teamDrivers.isEmpty()) return false
        pendingDecisions.clear()
        val decisions = teamDrivers.map { s ->
            Decision(
                ManagerDecisionRequest(lap, type, s.p.driverId, message, options(type)),
                s.p.driverName
            )
        }
        pending = decisions.first()
        pendingDecisions.addAll(decisions.drop(1))
        return true
    }

    private fun pauseForDriver(s: S, message: String, type: ManagerDecisionType): Boolean {
        pending = Decision(ManagerDecisionRequest(lap, type, s.p.driverId, message, options(type)), s.p.driverName)
        return true
    }

    private fun options(t: ManagerDecisionType) = when (t) {
        ManagerDecisionType.RED_FLAG -> listOf(ManagerDecisionAction.RESTART_PLAN_A, ManagerDecisionAction.RESTART_PLAN_B, ManagerDecisionAction.RESTART_PLAN_C, ManagerDecisionAction.RESTART_PLAN_D, ManagerDecisionAction.RESTART_ATTACK, ManagerDecisionAction.RESTART_BALANCED, ManagerDecisionAction.RESTART_DEFENSE)
        ManagerDecisionType.FUEL_CRITICAL -> listOf(ManagerDecisionAction.SAVE_FUEL, ManagerDecisionAction.BOX, ManagerDecisionAction.STAY_OUT)
        ManagerDecisionType.TYRE_CRITICAL -> listOf(ManagerDecisionAction.BOX, ManagerDecisionAction.CHANGE_TYRE_HARD, ManagerDecisionAction.STAY_OUT)
        ManagerDecisionType.WEATHER_CHANGE -> listOf(ManagerDecisionAction.BOX, ManagerDecisionAction.STAY_OUT, ManagerDecisionAction.EXTEND_STINT)
        else -> listOf(ManagerDecisionAction.BOX, ManagerDecisionAction.STAY_OUT, ManagerDecisionAction.EXTEND_STINT)
    }

    private fun groupPeloton() {
        val ordered = states.values.filterNot { it.dnf }
            .sortedWith(compareBy<S> { it.position }.thenBy { it.grid })
        ordered.forEachIndexed { index, car ->
            car.position = index + 1
            car.total = index.toLong() * STARTING_GRID_GAP_MS
            car.last = 0L
            car.drsActive = false
        }
    }

    private fun pit(s: S, tyre: Tyre) {
        s.stops++
        s.stint = 0
        s.tyre = tyre
        s.wear = 0
        s.wearExact = 0.0
        // F1 não permite reabastecimento: o pit stop troca pneus e adiciona apenas
        // a perda de tempo. O combustível restante segue intacto.
        s.lastPitLossSec = 21
        s.total += 21_000L
        events += LapEvent(lap, s.p.driverId, EventType.PIT_STOP, "Pit stop ${s.stops}: ${tyreLabel(tyre)} (+21s)")
    }


    private fun aiMode(s:S, weather:Weather): DriverStrategyMode {
        if (weather == Weather.HEAVY_RAIN) return when {
            s.p.wetSkill >= 90 -> DriverStrategyMode.ATTACK
            s.p.wetSkill >= 78 -> DriverStrategyMode.BALANCED
            else -> DriverStrategyMode.DEFENSE
        }
        if (FuelModel.fuelPercent(s.fuel) <= 22) return DriverStrategyMode.DEFENSE
        if (s.wear >= 78) return DriverStrategyMode.DEFENSE
        return when {
            s.position <= 6 && s.p.driverSpeed >= 88 -> DriverStrategyMode.ATTACK
            s.position in 7..20 && s.p.overtaking >= 88 -> DriverStrategyMode.ATTACK
            s.position >= 45 && s.p.driverSpeed >= 82 -> DriverStrategyMode.ATTACK
            else -> DriverStrategyMode.BALANCED
        }
    }

    private fun rainPenalty(p: RaceParticipant, tyre: Tyre, rain: Weather): Long {
        val required = when (rain) {
            Weather.LIGHT_RAIN -> 82
            Weather.MEDIUM_RAIN -> 90
            Weather.HEAVY_RAIN -> 100
            else -> 0
        }
        val tyreMismatch = max(0, required - tyre.wetSuitability)
        val wetInfluence = DriverAttributeInfluence.wet(p.wetSkill)
        val wetSkill = (p.wetSkill * 0.65 + p.consistency * 0.35)
        val driverPenalty = max(0.0, (required - wetSkill))
        val attributeAdjustment = -wetInfluence * 1800.0 * (required / 100.0)
        return (tyreMismatch * 32.0 + driverPenalty * 24.0 + attributeAdjustment).toLong().coerceAtLeast(-900L)
    }

    // Legacy fixed-ms weather tyre deltas are intentionally retired.
    // TyreModel.performanceMultiplier() is the single source of truth and scales
    // with the GP average lap time.

    private fun componentLabel(component: com.f1teammanager.core.manager.CarComponent): String = when (component) {
        com.f1teammanager.core.manager.CarComponent.ENGINE -> "motor"
        com.f1teammanager.core.manager.CarComponent.CHASSIS -> "chassi"
        com.f1teammanager.core.manager.CarComponent.FRONT_WING -> "asa dianteira"
        com.f1teammanager.core.manager.CarComponent.REAR_WING -> "asa traseira"
        com.f1teammanager.core.manager.CarComponent.BRAKES -> "freios"
        com.f1teammanager.core.manager.CarComponent.ELECTRIC_POWER_UNIT -> "unidade de potência elétrica"
    }

    private fun nextTyre(t: Tyre) = when (t) {
        Tyre.SOFT -> Tyre.MEDIUM
        Tyre.MEDIUM -> Tyre.HARD
        Tyre.HARD -> Tyre.MEDIUM
        Tyre.INTERMEDIATE -> Tyre.WET
        Tyre.WET -> Tyre.INTERMEDIATE
    }

    private fun finish(): SessionSnapshot {
        finished = true
        return snapshot("RESULT", emptyList())
    }

    private fun currentClassification(): List<FinishEntry> {
        val running = if (finished) {
            states.values.filterNot { it.dnf }.sortedWith(compareByDescending<S> { it.laps }.thenBy { it.total }.thenBy { it.grid })
        } else {
            states.values.filterNot { it.dnf }.sortedWith(compareBy<S> { it.position }.thenBy { it.grid })
        }
        val dnfs = states.values.filter { it.dnf }.sortedWith(compareByDescending<S> { it.laps }.thenBy { it.total }.thenBy { it.grid })
        return (running + dnfs).mapIndexed { i, s ->
            FinishEntry(i + 1, s.p.driverId, s.p.driverName, s.p.teamName, s.laps, s.total, if (s.dnf) "DNF • ${s.dnfReason}" else if (finished) "FINISHED" else "RUNNING", s.tyre, s.stops)
        }
    }

    private fun currentCarStatus(): List<RaceCarStatus> {
        val activeCircuit = circuit ?: return emptyList()
        return currentClassification().map { f ->
        val s = states.getValue(f.driverId)
        RaceCarStatus(
            f.driverId, f.driverName, f.position, s.tyre, s.wear, FuelModel.fuelPercent(s.fuel),
            s.stops, s.stint, s.last, s.ers.toInt().coerceIn(0, 100), s.drsActive,
            if (s.dnf) "DNF" else "OK", s.lastPitLossSec, s.ersActive,
            if (s.ersActive) PitwallPaceModel(random).ersGainMs(s.p, activeCircuit, s.ers).toInt() else 0, if (s.drsActive) PitwallPaceModel(random).drsGainMs(s.p, activeCircuit).toInt() else 0,
            s.componentReliability[com.f1teammanager.core.manager.CarComponent.ENGINE]?.toInt() ?: s.p.engineReliability,
            s.componentReliability[com.f1teammanager.core.manager.CarComponent.CHASSIS]?.toInt() ?: s.p.chassisReliability,
            s.componentReliability[com.f1teammanager.core.manager.CarComponent.FRONT_WING]?.toInt() ?: s.p.frontWingReliability,
            s.componentReliability[com.f1teammanager.core.manager.CarComponent.REAR_WING]?.toInt() ?: s.p.rearWingReliability,
            s.componentReliability[com.f1teammanager.core.manager.CarComponent.BRAKES]?.toInt() ?: s.p.brakesReliability,
            s.componentReliability[com.f1teammanager.core.manager.CarComponent.ELECTRIC_POWER_UNIT]?.toInt() ?: s.p.electricPowerUnitReliability,
            ReliabilityModel.average(s.componentReliability)
        )
        }
    }

    private fun currentAlerts(): List<DriverAlert> = states.values
        .filter { it.p.driverId in plans.keys && !it.dnf }
        .flatMap { s ->
            buildList {
                if (s.fuel <= 25.0) add(DriverAlert(lap, s.p.driverId, DriverAlertType.FUEL_LOW, "${s.p.driverName}: combustível em ${s.fuel.toInt()}%", if (FuelModel.fuelPercent(s.fuel) <= 12) 3 else 1))
                if (s.wear >= 65) add(DriverAlert(lap, s.p.driverId, if (s.wear >= 95) DriverAlertType.TYRE_CRITICAL else DriverAlertType.TYRE_DEGRADING, "${s.p.driverName}: ${tyreLabel(s.tyre)} em ${s.wear}%", if (s.wear >= 95) 3 else 2))
            }
        }
        .sortedByDescending { it.severity }

    private fun maskedQualifying(): QualifyingResult? {
        val g = grid ?: return null
        if (qualifyingStage >= 3) return g
        val phases = g.phases.mapIndexed { i, p ->
            when {
                i < qualifyingStage -> p
                i == qualifyingStage -> QualifyingPhase(p.name, liveQualifyingEntries(), emptyList())
                else -> QualifyingPhase(p.name, emptyList(), emptyList())
            }
        }
        return QualifyingResult(emptyList(), phases)
    }

    private fun snapshot(phase: String, newEvents: List<LapEvent>): SessionSnapshot = SessionSnapshot(
        phase = phase,
        lap = lap,
        totalLaps = circuit?.laps ?: 0,
        grid = maskedQualifying(),
        classification = currentClassification(),
        carStatus = currentCarStatus(),
        events = newEvents,
        neutral = neutral,
        decision = pending,
        plans = plans.mapValues { it.value.copy() },
        alerts = currentAlerts(),
        completed = finished,
        weather = weather,
        qualifyingElapsedMs = qualifyingElapsedMs,
        qualifyingDurationMs = if (qualifyingStage >= 3) Q3_DURATION_MS else qualifyingDuration(qualifyingStage),
        qualifyingPhaseIndex = qualifyingPhaseIndex(),
        qualifyingRunning = qualifyingActive,
    )

    private fun tyreLabel(t: Tyre) = when (t) {
        Tyre.SOFT -> "SOFT"
        Tyre.MEDIUM -> "MEDIUM"
        Tyre.HARD -> "HARD"
        Tyre.INTERMEDIATE -> "INTERMEDIÁRIO"
        Tyre.WET -> "WET"
    }
}
