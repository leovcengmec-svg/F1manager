package com.f1teammanager.core.race

import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

data class TyrePlan(
    val id: String,
    val sequence: List<Tyre>,
    val stintLaps: List<Int>
)

data class RaceCarStatus(
    val driverId: Int,
    val driverName: String,
    val position: Int,
    val tyre: Tyre,
    val tyreWear: Int,
    val fuelPercent: Int,
    val pitStops: Int,
    val stintLaps: Int,
    val lastLapMs: Long,
    val ersPercent: Int,
    val drsActive: Boolean,
    val status: String,
    val lastPitLossSec: Int = 0,
    val ersActive: Boolean = false,
    val ersGainMs: Int = 0,
    val drsGainMs: Int = 0,
    val engineReliability: Int = 95,
    val chassisReliability: Int = 95,
    val frontWingReliability: Int = 95,
    val rearWingReliability: Int = 95,
    val brakesReliability: Int = 95,
    val electricPowerUnitReliability: Int = 95,
    val averageReliability: Int = 95
)

/** V33: automatic lap simulation with live classification, tyre/fuel consequences and manager control. */
class CareerWeekendEngine(private val seed: Int = 20261003) {
    // Equipe do jogador mantida para reconstruir os planos após a qualificação.
    private var activePlayerTeamId: Int = -1
    data class DriverPlan(
        var mode: DriverStrategyMode = DriverStrategyMode.BALANCED,
        var tyre: Tyre = Tyre.MEDIUM,
        var activePlan: String = "A",
        var planStintIndex: Int = 0,
        var tyrePlans: Map<String, TyrePlan> = emptyMap(),
        // Plano livre em preparação no diálogo de box; só passa a valer após aplicar a parada.
        var pendingFreePlan: TyrePlan? = null,
        // Chuva encerra o plano A/B/C para este piloto. A partir daí,
        // todas as trocas de pneus precisam ser decididas manualmente.
        var weatherManualMode: Boolean = false
    )
    data class Decision(val request: ManagerDecisionRequest, val driverName: String)
    data class SessionSnapshot(
        val phase: String,
        val lap: Int,
        val totalLaps: Int,
        val grid: QualifyingResult?,
        val classification: List<FinishEntry>,
        val carStatus: List<RaceCarStatus>,
        val events: List<LapEvent>,
        val neutral: Neutralisation,
        val decision: Decision?,
        val plans: Map<Int, DriverPlan>,
        val alerts: List<DriverAlert>,
        val completed: Boolean,
        val weather: Weather,
        val qualifyingElapsedMs: Long = 0L,
        val qualifyingDurationMs: Long = 0L,
        val qualifyingPhaseIndex: Int = 0,
        val qualifyingRunning: Boolean = false,
        val qualifyingRemainingMs: Long = 0L,
        val qualifyingReferenceLapMs: Long = 0L,
        val qualifyingLapsByDriver: Map<Int, Int> = emptyMap(),
        val qualifyingDiscardedLapsByDriver: Map<Int, Int> = emptyMap(),
        val qualifyingLapsByDriverByPhase: List<Map<Int, Int>> = emptyList(),
        val qualifyingDiscardedLapsByDriverByPhase: List<Map<Int, Int>> = emptyList(),
        val qualifyingTyres: Map<Int, Tyre> = emptyMap(),
        // Estratégias internas da IA expostas apenas no snapshot para auditoria/testes;
        // os planos editáveis do manager continuam restritos à equipe do jogador.
        val aiTyreStrategies: Map<Int, TyrePlan> = emptyMap(),
    )

    private data class S(
        val p: RaceParticipant,
        var grid: Int,
        var total: Long = 0,
        var last: Long = 0,
        var best: Long = Long.MAX_VALUE,
        var laps: Int = 0,
        var stint: Int = 0,
        var stops: Int = 0,
        var dnf: Boolean = false,
        var wear: Int = 0,
        var wearExact: Double = 0.0,
        var tyre: Tyre = Tyre.MEDIUM,
        var fuel: Double = FuelModel.TANK_CAPACITY_KG,
        var lastPos: Int = Int.MAX_VALUE,
        var position: Int = grid,
        var ers: Double = 100.0,
        var drsActive: Boolean = false,
        var ersActive: Boolean = false,
        val componentReliability: MutableMap<com.f1teammanager.core.manager.CarComponent, Double> = mutableMapOf(),
        var dnfReason: String = "",
        var bypassCriticalOnce: Boolean = false,
        var lastFuelAlertLap: Int = -99,
        var fuelSavingAccepted: Boolean = false,
        var fuelCriticalAutoAlertSent: Boolean = false,
        var lastTyreAlertLap: Int = -99,
        var lastManualTyrePromptWear: Int = -1,
        var lastPitLossSec: Int = 0,
        val aiPitBias: Int = 0,
    )

    private val random = Random(seed)
    // Weather and qualifying use isolated streams: lowering rain frequency must not
    // shift race incidents, strategy outcomes or driver-evolution random sequences.
    private var qualifyingRandom = Random(seed xor 0x5A17C0DE)
    private var raceWeatherRandom = Random(seed xor 0x6327EA71)
    private var circuit: RaceCircuit? = null
    private var states = mutableMapOf<Int, S>()
    private var grid: QualifyingResult? = null
    private var lap = 0
    // Snapshot of cumulative timing at the beginning of the current lap. It is retained
    // across manager pauses so Safety Car catch-up never depends on cars already processed.
    private var lapStartTotalsByDriver: Map<Int, Long> = emptyMap()
    // A manager decision can pause simulation halfway through a lap. Resume that same
    // lap and skip cars already processed instead of incrementing the lap and simulating
    // them twice (or leaving the rest one lap behind).
    private var lapInProgress = false
    private var lapPreparationDone = false
    private val processedDriverIdsThisLap = mutableSetOf<Int>()
    private var neutral = Neutralisation.GREEN
    private var neutralEnd = 0
    private var weather = Weather.DRY
    // Weather is evaluated on fixed checkpoints even when no transition occurs.
    private var lastWeatherCheckLap = 0
    private var raceRainStartedLap = -1
    private var raceStartWeatherPrepared = false
    private var pending: Decision? = null
    private val pendingDecisions = mutableListOf<Decision>()
    private var events = mutableListOf<LapEvent>()
    private val badStartDriverIds = mutableSetOf<Int>()
    private var rainIncidentDriverId: Int? = null
    // Incidentos adicionais são sorteados uma vez por GP: no máximo um furo de pneu
    // e no máximo uma pane elétrica com abandono. A confiabilidade afeta a chance elétrica.
    private var raceIncidentsScheduled = false
    private var punctureScheduled = false
    private var punctureLap = -1
    private var punctureTriggered = false
    private var electricalFailureScheduled = false
    private var electricalFailureLap = -1
    private var electricalFailureTriggered = false
    private var finished = false
    private var fastestId: Int? = null
    private var fastest = Long.MAX_VALUE
    private var qualifyingStage = 0 // número de sessões concluídas
    private var qualifyingElapsedMs = 0L
    private var qualifyingParticipants = emptyList<RaceParticipant>()
    private var qualifyingClockByDriver = mutableMapOf<Int, Long>()
    private var qualifyingNextLapByDriver = mutableMapOf<Int, Long>()
    private var qualifyingBestLapByDriver = mutableMapOf<Int, Long>()
    private var qualifyingLapCountByDriver = mutableMapOf<Int, Int>()
    private var qualifyingDiscardedLapCountByDriver = mutableMapOf<Int, Int>()
    private var qualifyingLapCountByStage = MutableList(3) { mutableMapOf<Int, Int>() }
    private var qualifyingDiscardedLapCountByStage = MutableList(3) { mutableMapOf<Int, Int>() }
    private var qualifyingTyres: MutableMap<Int, Tyre> = mutableMapOf()
    private var lastQualifyingWeatherCheckMs: Long = 0L
    private var qualifyingActive = false
    private var redFlagUsed = false
    private val plans = mutableMapOf<Int, DriverPlan>()
    private data class AiStrategyState(var plan: TyrePlan, var stintIndex: Int = 0)
    private val aiStrategies = mutableMapOf<Int, AiStrategyState>()

    companion object {
        private const val STARTING_GRID_GAP_MS = 55L
        private const val SAFETY_CAR_PACE_PENALTY_MS = 9000L
        private const val VSC_PACE_PENALTY_MS = 4500L
        private const val Q1_DURATION_MS = 30L * 60L * 1000L
        private const val Q2_DURATION_MS = 20L * 60L * 1000L
        private const val Q3_DURATION_MS = 10L * 60L * 1000L
    }

    private fun qualifyingDuration(stage: Int): Long = when(stage) {
        0 -> Q1_DURATION_MS
        1 -> Q2_DURATION_MS
        else -> Q3_DURATION_MS
    }

    private fun qualifyingPhaseName(stage: Int): String = when(stage) {
        0 -> "Q1"
        1 -> "Q2"
        else -> "Q3"
    }

    private fun dryTyreForQualifyingStage(stage: Int): Tyre = when (stage.coerceIn(0, 2)) {
        0 -> Tyre.HARD
        1 -> Tyre.MEDIUM
        else -> Tyre.SOFT
    }

    private fun qualifyingTyreForWeather(stage: Int, conditions: Weather): Tyre = when (conditions) {
        Weather.LIGHT_RAIN, Weather.MEDIUM_RAIN -> Tyre.INTERMEDIATE
        Weather.HEAVY_RAIN -> Tyre.WET
        Weather.DRY, Weather.CLOUDY -> dryTyreForQualifyingStage(stage)
    }

    private fun qualifyingLapTime(p: RaceParticipant, c: RaceCircuit, elapsedMs: Long): Long {
        val tyre = qualifyingTyres[p.driverId] ?: qualifyingTyreForWeather(qualifyingStage, weather)
        val base = PitwallPaceModel(qualifyingRandom).qualifyingLapTime(p, c, weather)
        val reference = c.baseLapTimeMs.coerceAtLeast(45_000L).toDouble()
        val tyreWeatherDelta = reference * (TyreModel.performanceMultiplier(tyre, weather) - 1.0)
        val wetSkillDelta = if (weather in listOf(Weather.LIGHT_RAIN, Weather.MEDIUM_RAIN, Weather.HEAVY_RAIN)) {
            reference * ((50 - p.wetSkill.coerceIn(40, 100)) / 100.0) * 0.012
        } else 0.0
        val weatherAdjustedBase = (base + tyreWeatherDelta + wetSkillDelta).coerceAtLeast(45_000.0).toLong()
        // A qualifying session has good, normal and bad laps. Consistency narrows
        // the variance but never removes it, so positions can genuinely change.
        val consistency = p.consistency.coerceIn(40, 100)
        val roll = qualifyingRandom.nextDouble()
        val raw = when {
            roll < 0.06 -> -0.010 + qualifyingRandom.nextDouble(0.0, 0.004) // excelente
            roll < 0.22 -> -0.004 + qualifyingRandom.nextDouble(0.0, 0.003) // boa
            roll < 0.82 -> -0.001 + qualifyingRandom.nextDouble(0.0, 0.003) // normal
            roll < 0.96 -> 0.002 + qualifyingRandom.nextDouble(0.0, 0.006) // ruim
            else -> 0.008 + qualifyingRandom.nextDouble(0.0, 0.010) // muito ruim
        }
        val consistencyFactor = 1.18 - (consistency - 40) / 100.0 * 0.36
        val trackEvolution = -(elapsedMs.toDouble() / qualifyingDuration(qualifyingStage).coerceAtLeast(1L)) * 0.0025
        return max(45_000L, (weatherAdjustedBase * (1.0 + raw * consistencyFactor + trackEvolution)).toLong())
    }

    private fun liveQualifyingEntries(): List<QualifyingEntry> {
        return qualifyingParticipants
            .map { p -> QualifyingEntry(p.driverId, 0, qualifyingBestLapByDriver[p.driverId] ?: Long.MAX_VALUE) }
            .sortedWith(compareBy<QualifyingEntry> { it.lapTimeMs }.thenBy { it.driverId })
            .mapIndexed { i, e -> e.copy(position = i + 1) }
    }

    private fun completedQualifyingPhase(stage: Int, entries: List<QualifyingEntry>): QualifyingPhase {
        val cutoff = if (stage == 0) 50 else if (stage == 1) 20 else entries.size
        return QualifyingPhase(
            qualifyingPhaseName(stage),
            entries,
            entries.drop(cutoff).map { it.driverId }
        )
    }

    private fun buildFinalGrid(phases: List<QualifyingPhase>): List<QualifyingEntry> {
        val q1 = phases[0].entries
        val q2 = phases[1].entries
        val q3 = phases[2].entries
        val q2Ids = q2.map { it.driverId }.toSet()
        val q3Ids = q3.map { it.driverId }.toSet()
        return (q3 +
            q2.filter { it.driverId !in q3Ids }.mapIndexed { i, e -> e.copy(position = 21 + i) } +
            q1.filter { it.driverId !in q2Ids }.mapIndexed { i, e -> e.copy(position = 51 + i) })
            .sortedBy { it.position }
    }

    fun start(
        participants: List<RaceParticipant>,
        c: RaceCircuit,
        playerTeamId: Int,
        weekendSeed: Int = seed
    ): SessionSnapshot {
        // Validate the entire input before mutating engine state. A malformed roster must
        // never leave a half-started weekend or silently overwrite a driver in the ID map.
        require(participants.size == 80) { "O campeonato deve iniciar com 80 pilotos; recebido ${participants.size}" }
        require(participants.all { it.driverId > 0 }) { "Todos os pilotos precisam ter ID positivo" }
        require(participants.map { it.driverId }.distinct().size == participants.size) {
            "O grid contém IDs de piloto duplicados"
        }
        require(participants.all { it.driverName.isNotBlank() && it.teamName.isNotBlank() }) {
            "Todos os pilotos e equipes precisam ter identificação"
        }
        require(participants.all { it.teamId > 0 }) { "Todas as equipes precisam ter ID positivo" }
        require(participants.groupBy { it.teamId }.values.all { teamDrivers ->
            teamDrivers.map { it.teamName }.distinct().size == 1
        }) { "Uma equipe possui nomes inconsistentes no grid" }
        require(c.laps > 0 && c.baseLapTimeMs > 0L) { "Circuito inválido: distância e tempo-base precisam ser positivos" }
        require(playerTeamId > 0 && participants.any { it.teamId == playerTeamId }) {
            "A equipe do jogador precisa existir no grid"
        }
        // Enforce the permanent 40..100 sporting/factory floor at the race-engine
        // boundary too. UI/grid builders are not the only possible callers (instant,
        // headless and restored sessions can enter here directly).
        val normalizedParticipants = participants.map { it.normalized() }
        circuit = c
        activePlayerTeamId = playerTeamId
        lap = 0
        lapInProgress = false
        lapPreparationDone = false
        processedDriverIdsThisLap.clear()
        neutral = Neutralisation.GREEN
        neutralEnd = 0
        // Reinitialize the isolated weather/qualifying streams for this GP only.
        // MainActivity keeps one engine instance for the whole career, so using the
        // constructor seed here would repeat the same opening weather at every round.
        qualifyingRandom = Random(weekendSeed xor 0x5A17C0DE)
        raceWeatherRandom = Random(weekendSeed xor 0x6327EA71)
        weather = CircuitWeatherModel.qualifyingStartWeather(c, qualifyingRandom)
        lastWeatherCheckLap = 0
        raceRainStartedLap = -1
        raceStartWeatherPrepared = false
        qualifyingTyres = normalizedParticipants.associate { it.driverId to qualifyingTyreForWeather(0, weather) }.toMutableMap()
        lastQualifyingWeatherCheckMs = 0L
        pending = null
        pendingDecisions.clear()
        events = mutableListOf()
        badStartDriverIds.clear()
        rainIncidentDriverId = null
        raceIncidentsScheduled = false
        punctureScheduled = false
        punctureLap = -1
        punctureTriggered = false
        electricalFailureScheduled = false
        electricalFailureLap = -1
        electricalFailureTriggered = false
        finished = false
        fastestId = null
        fastest = Long.MAX_VALUE
        qualifyingStage = 0
        qualifyingElapsedMs = 0L
        qualifyingParticipants = normalizedParticipants
        qualifyingClockByDriver = normalizedParticipants.associate { it.driverId to 0L }.toMutableMap()
        qualifyingNextLapByDriver = normalizedParticipants.associate { it.driverId to qualifyingLapTime(it, c, 0L) }.toMutableMap()
        qualifyingBestLapByDriver = normalizedParticipants.associate { it.driverId to Long.MAX_VALUE }.toMutableMap()
        qualifyingLapCountByDriver = normalizedParticipants.associate { it.driverId to 0 }.toMutableMap()
        qualifyingDiscardedLapCountByDriver = normalizedParticipants.associate { it.driverId to 0 }.toMutableMap()
        qualifyingLapCountByStage = MutableList(3) { mutableMapOf() }
        qualifyingDiscardedLapCountByStage = MutableList(3) { mutableMapOf() }
        qualifyingActive = false
        redFlagUsed = false
        grid = QualifyingResult(
            emptyList(),
            listOf(
                QualifyingPhase("Q1", liveQualifyingEntries(), emptyList()),
                QualifyingPhase("Q2", emptyList(), emptyList()),
                QualifyingPhase("Q3", emptyList(), emptyList())
            )
        )
        states = normalizedParticipants.associate { p ->
            val g = p.driverId + 1
            p.driverId to S(
                p = p,
                grid = g,
                total = (g - 1L) * STARTING_GRID_GAP_MS,
                aiPitBias = ((p.driverId * 7) % 9) - 4,
                componentReliability = mutableMapOf(
                    com.f1teammanager.core.manager.CarComponent.ENGINE to p.engineReliability.toDouble(),
                    com.f1teammanager.core.manager.CarComponent.CHASSIS to p.chassisReliability.toDouble(),
                    com.f1teammanager.core.manager.CarComponent.FRONT_WING to p.frontWingReliability.toDouble(),
                    com.f1teammanager.core.manager.CarComponent.REAR_WING to p.rearWingReliability.toDouble(),
                    com.f1teammanager.core.manager.CarComponent.BRAKES to p.brakesReliability.toDouble(),
                    com.f1teammanager.core.manager.CarComponent.ELECTRIC_POWER_UNIT to p.electricPowerUnitReliability.toDouble()
                )
            )
        }.toMutableMap()
        plans.clear()
        aiStrategies.clear()
        normalizedParticipants.filter { it.teamId == playerTeamId }.forEach {
            val tyrePlans = TyreModel.buildPlansForWeather(c.laps, weather)
            val firstTyre = tyrePlans["A"]?.sequence?.firstOrNull() ?: Tyre.MEDIUM
            plans[it.driverId] = DriverPlan(tyre = firstTyre, activePlan = "A", planStintIndex = 0, tyrePlans = tyrePlans)
            // O pneu definido pelo plano A/B/C precisa ser aplicado ao carro antes
            // da primeira volta. Antes disso o estado de corrida permanecia em MEDIUM
            // (valor padrão de S), mesmo quando o manager havia escolhido SOFT.
            states[it.driverId]?.let { state ->
                state.tyre = firstTyre
                state.stint = 0
                state.wear = 0
                state.wearExact = 0.0
            }
        }
        return snapshot("QUALIFYING", emptyList())
    }

    /**
     * Advances the old event-based API by a bounded number of completed laps.
     * Kept for compatibility with tests/headless simulation. The visible Android
     * screen uses advanceQualifyingTimeSlice(), which moves a continuous clock.
     */
    fun advanceQualifyingSimulation(maxEvents: Int = 12): SessionSnapshot {
        require(!finished) { "Fim de semana concluído" }
        require(qualifyingStage < 3) { "Qualificação já concluída" }
        qualifyingActive = true
        val duration = qualifyingDuration(qualifyingStage)
        val newEvents = mutableListOf<LapEvent>()
        val currentStage = qualifyingStage
        repeat(maxEvents.coerceIn(1, 80)) {
            if (qualifyingStage != currentStage) return@repeat
            val next = qualifyingNextLapByDriver
                .filter { (id, time) -> qualifyingClockByDriver[id]!! + time <= duration }
                .minByOrNull { (id, time) -> qualifyingClockByDriver[id]!! + time }
            if (next == null) {
                qualifyingElapsedMs = duration
                finishQualifyingPhase()
                return@repeat
            }
            val id = next.key
            val current = qualifyingClockByDriver.getValue(id)
            val lapTime = next.value
            val finishAt = current + lapTime
            processQualifyingLap(id, lapTime, finishAt, newEvents)
            qualifyingElapsedMs = max(qualifyingElapsedMs, finishAt).coerceAtMost(duration)
            updateQualifyingWeatherAndTyres(newEvents)
        }
        if (qualifyingStage == currentStage && qualifyingElapsedMs >= duration) finishQualifyingPhase()
        return snapshot("QUALIFYING", newEvents.takeLast(3))
    }

    /**
     * Visible simulation clock. The GP's average lap time is the reference: a
     * 30-minute Q1 therefore represents approximately 30:00 / GP-average-lap
     * laps per driver, while each driver's actual qualifying lap time determines
     * whether he completes one before the clock reaches zero.
     */
    fun advanceQualifyingTimeSlice(sliceMs: Long = 5_000L): SessionSnapshot {
        require(!finished) { "Fim de semana concluído" }
        require(qualifyingStage < 3) { "Qualificação já concluída" }
        qualifyingActive = true
        val duration = qualifyingDuration(qualifyingStage)
        val target = (qualifyingElapsedMs + sliceMs.coerceIn(250L, 30_000L)).coerceAtMost(duration)
        val newEvents = mutableListOf<LapEvent>()
        val currentStage = qualifyingStage

        // Fixed 1-second simulation quanta make the underlying event order independent
        // of UI speed/slice size. Weather checkpoints are evaluated on the same virtual
        // timeline for manual and instant qualifying, never once per rendered frame.
        while (qualifyingStage == currentStage && qualifyingElapsedMs < target) {
            val quantumEnd = (qualifyingElapsedMs + 1_000L).coerceAtMost(target)
            while (qualifyingStage == currentStage) {
                val next = qualifyingNextLapByDriver
                    .mapNotNull { (id, lapTime) ->
                        val clock = qualifyingClockByDriver[id] ?: return@mapNotNull null
                        val finishAt = clock + lapTime
                        if (finishAt <= quantumEnd) Triple(id, lapTime, finishAt) else null
                    }
                    .minByOrNull { it.third } ?: break
                processQualifyingLap(next.first, next.second, next.third, newEvents)
            }
            qualifyingElapsedMs = quantumEnd
            updateQualifyingWeatherAndTyres(newEvents)
        }
        if (qualifyingElapsedMs >= duration) finishQualifyingPhase()
        return snapshot("QUALIFYING", newEvents.takeLast(4))
    }

    private fun updateQualifyingWeatherAndTyres(newEvents: MutableList<LapEvent>) {
        // Five-minute checkpoints are shared by all drivers and scoped to the active
        // Q session. Do not perform a last-second weather change at the chequered flag.
        val c = circuit ?: return
        val duration = qualifyingDuration(qualifyingStage.coerceIn(0, 2))
        if (qualifyingElapsedMs >= duration) return
        val checkpointMs = 300_000L
        if (qualifyingElapsedMs - lastQualifyingWeatherCheckMs < checkpointMs) return
        // Keep the marker on the virtual-clock grid, rather than drifting by slice size.
        lastQualifyingWeatherCheckMs = (qualifyingElapsedMs / checkpointMs) * checkpointMs
        val profile = CircuitWeatherModel.profileForCircuit(c)
        if (qualifyingRandom.nextDouble() >= profile.qualifyingTransitionChance) return
        val next = CircuitWeatherModel.nextQualifyingWeather(weather, qualifyingRandom)
        if (next == weather) return
        weather = next
        val changes = mutableListOf<String>()
        qualifyingParticipants.forEach { participant ->
            val recommended = qualifyingTyreForWeather(qualifyingStage, weather)
            val previous = qualifyingTyres[participant.driverId]
            if (previous != recommended) {
                qualifyingTyres[participant.driverId] = recommended
                changes += "${participant.driverName}: ${tyreLabel(recommended)}"
            }
        }
        // New lap attempts use the updated conditions and automatically selected compound.
        qualifyingParticipants.forEach { participant ->
            qualifyingNextLapByDriver[participant.driverId] = qualifyingLapTime(participant, circuit!!, qualifyingClockByDriver[participant.driverId] ?: qualifyingElapsedMs)
        }
        newEvents += LapEvent(0, qualifyingParticipants.firstOrNull()?.driverId ?: 0, EventType.WEATHER_CHANGE,
            "Clima da classificação: ${weatherLabel(weather)}. Pneus ajustados automaticamente.")
    }

    private fun weatherLabel(value: Weather): String = when (value) {
        Weather.DRY -> "seco"
        Weather.CLOUDY -> "nublado"
        Weather.LIGHT_RAIN -> "chuva fraca"
        Weather.MEDIUM_RAIN -> "chuva média"
        Weather.HEAVY_RAIN -> "chuva forte"
    }

    private fun processQualifyingLap(
        id: Int,
        lapTime: Long,
        finishAt: Long,
        newEvents: MutableList<LapEvent>
    ) {
        qualifyingClockByDriver[id] = finishAt
        qualifyingLapCountByDriver[id] = qualifyingLapCountByDriver.getValue(id) + 1
        qualifyingLapCountByStage[qualifyingStage][id] = (qualifyingLapCountByStage[qualifyingStage][id] ?: 0) + 1
        val participant = qualifyingParticipants.first { it.driverId == id }

        // A qualifying lap can be invalidated by an error/track-limit event.
        // The driver loses that lap's opportunity, but the session clock keeps
        // running and he immediately starts another attempt if time remains.
        val consistency = participant.consistency.coerceIn(40, 100)
        val errorChance = (0.050 - (consistency - 40) * 0.00055).coerceIn(0.010, 0.050)
        val discarded = qualifyingRandom.nextDouble() < errorChance
        if (discarded) {
            qualifyingDiscardedLapCountByDriver[id] = qualifyingDiscardedLapCountByDriver.getValue(id) + 1
            qualifyingDiscardedLapCountByStage[qualifyingStage][id] = (qualifyingDiscardedLapCountByStage[qualifyingStage][id] ?: 0) + 1
            newEvents += LapEvent(0, id, EventType.QUALIFYING_LAP_DISCARDED,
                "${qualifyingPhaseName(qualifyingStage)} • ${participant.driverName}: volta descartada")
        } else {
            val best = qualifyingBestLapByDriver.getValue(id)
            if (lapTime < best) {
                qualifyingBestLapByDriver[id] = lapTime
                newEvents += LapEvent(0, id, EventType.FASTEST_LAP,
                    "${qualifyingPhaseName(qualifyingStage)} • ${participant.driverName} melhorou para ${lapTime / 60000}:${(lapTime / 1000) % 60}.${(lapTime % 1000).toString().padStart(3,'0')}")
            }
        }
        qualifyingNextLapByDriver[id] = qualifyingLapTime(participant, circuit!!, finishAt)
    }

    /** Complete the current session immediately for headless season simulations/tests. */
    fun simulateQualifyingPhase(): SessionSnapshot {
        require(!finished) { "Fim de semana concluído" }
        require(qualifyingStage < 3) { "Qualificação já concluída" }
        val targetStage = qualifyingStage
        var guard = 0
        // Keep instant and interactive qualifying on the same continuous-clock path.
        // The UI may render fewer intermediate frames, but lap/weather processing is
        // owned by this exact implementation in both modes.
        while (qualifyingStage == targetStage && ++guard < 10000) {
            advanceQualifyingTimeSlice(30_000L)
        }
        require(qualifyingStage > targetStage) { "Não foi possível concluir a qualificação" }
        return snapshot("QUALIFYING", emptyList())
    }

    /**
     * V342: completes Q1, Q2 and Q3 synchronously, using the exact same qualifying
     * clock, lap generation, weather, discarded-lap rules and grid builder as the
     * interactive session. This is a domain API only; it deliberately adds no UI.
     */
    fun simulateQualifyingInstantly(): SessionSnapshot {
        require(!finished) { "Fim de semana concluído" }
        var guard = 0
        while (!qualifyingComplete() && ++guard <= 3) simulateQualifyingPhase()
        check(qualifyingComplete()) { "Não foi possível concluir todas as fases da qualificação" }
        val finalGrid = grid ?: error("A qualificação terminou sem gerar o grid")
        check(finalGrid.grid.isNotEmpty()) { "O grid final da qualificação está vazio" }
        return snapshot("QUALIFYING", emptyList())
    }

    /**
     * V343: one domain entry point for a complete instant weekend.
     * Runs all qualifying phases first, then the complete programmed race distance.
     * It returns both snapshots so a caller can persist/show the normal results without
     * introducing a second simulation model or changing any UI.
     */
    data class InstantWeekendResult(
        val qualifying: SessionSnapshot,
        val race: SessionSnapshot,
        val result: RaceResult
    )

    fun simulateWeekendInstantly(): InstantWeekendResult {
        val qualifyingSnapshot = simulateQualifyingInstantly()
        val raceSnapshot = simulateRaceInstantly()
        val raceResult = result()
        check(qualifyingSnapshot.grid?.grid?.isNotEmpty() == true) {
            "A simulação instantânea não gerou um grid de qualificação"
        }
        check(raceSnapshot.completed && raceResult.classification.isNotEmpty()) {
            "A simulação instantânea não gerou um resultado final"
        }
        val programmedLaps = circuit?.laps ?: error("Circuito não configurado")
        check(raceResult.classification.maxOfOrNull { it.laps } == programmedLaps) {
            "O vencedor não completou a distância programada"
        }
        return InstantWeekendResult(qualifyingSnapshot, raceSnapshot, raceResult)
    }

    private fun finishQualifyingPhase() {
        if (!qualifyingActive || qualifyingStage >= 3) return
        val stage = qualifyingStage
        val entries = liveQualifyingEntries()
        val phase = completedQualifyingPhase(stage, entries)
        val previous = grid?.phases.orEmpty().toMutableList()
        while (previous.size < 3) previous += QualifyingPhase(qualifyingPhaseName(previous.size), emptyList(), emptyList())
        previous[stage] = phase
        qualifyingStage++
        qualifyingElapsedMs = if (stage == 2) qualifyingDuration(stage) else 0L
        // Each session has its own clock. Reset the checkpoint marker when Q2/Q3 begins
        // so the fresh zero-based timer can advance weather normally.
        lastQualifyingWeatherCheckMs = 0L
        qualifyingActive = false
        if (qualifyingStage < 3) {
            val survivors = entries.take(if (stage == 0) 50 else 20).mapNotNull { e -> qualifyingParticipants.firstOrNull { it.driverId == e.driverId } }
            qualifyingParticipants = survivors
            qualifyingTyres = survivors.associate { it.driverId to qualifyingTyreForWeather(qualifyingStage, weather) }.toMutableMap()
            qualifyingClockByDriver = survivors.associate { it.driverId to 0L }.toMutableMap()
            qualifyingNextLapByDriver = survivors.associate { it.driverId to qualifyingLapTime(it, circuit!!, 0L) }.toMutableMap()
            qualifyingBestLapByDriver = survivors.associate { it.driverId to Long.MAX_VALUE }.toMutableMap()
            qualifyingLapCountByDriver = survivors.associate { it.driverId to 0 }.toMutableMap()
            qualifyingDiscardedLapCountByDriver = survivors.associate { it.driverId to 0 }.toMutableMap()
            previous[qualifyingStage] = QualifyingPhase(qualifyingPhaseName(qualifyingStage), liveQualifyingEntries(), emptyList())
            grid = QualifyingResult(emptyList(), previous)
        } else {
            // Preserve the deterministic race RNG sequence from V92: the former
            // static qualifying consumed exactly 150 qualifying jitter draws
            // (80 + 50 + 20). The new visual session uses its isolated RNG, so
            // consume the same count here without coupling quali outcomes to race events.
            repeat(150) { random.nextInt(-80, 81) }
            grid = QualifyingResult(buildFinalGrid(previous), previous)
            applyQualifyingGridToRaceStates(grid!!.grid)
            // Race conditions are deliberately drawn separately when the player starts
            // the race. Qualifying retains its own final weather for the Q3 results.
        }
    }

    private fun buildAiTyreStrategy(state: S, remainingLaps: Int, currentWeather: Weather): TyrePlan {
        val participant = state.p
        val teamMembers = states.values.filter { it.p.teamId == participant.teamId }
        val teamPace = teamMembers.map { member ->
            (member.p.enginePerformance * 0.24 +
                member.p.chassisPerformance * 0.18 +
                member.p.frontWingPerformance * 0.16 +
                member.p.rearWingPerformance * 0.16 +
                member.p.brakesPerformance * 0.10 +
                member.p.electricPowerUnitPerformance * 0.16)
        }.average().takeIf { it.isFinite() }?.toInt() ?: participant.enginePerformance
        val circuitId = circuit?.id ?: 0
        val seed = circuitId * 7919 + participant.teamId * 101 + participant.driverId * 37 + lap * 13
        return TyreModel.buildAiRaceStrategy(
            totalLaps = remainingLaps.coerceAtLeast(1),
            weather = currentWeather,
            driverTyreWear = participant.tyreWear,
            driverSpeed = participant.driverSpeed,
            consistency = participant.consistency,
            overtaking = participant.overtaking,
            defense = participant.defense,
            teamPace = teamPace,
            gridPosition = state.grid,
            fieldSize = states.size.coerceAtLeast(1),
            strategySeed = seed
        )
    }

    private fun rebuildAiStrategyAfterUnplannedStop(state: S, remainingLaps: Int) {
        if (remainingLaps <= 0) return
        val plan = buildAiTyreStrategy(state, remainingLaps, weather)
        val selectedTyre = plan.sequence.firstOrNull() ?: state.tyre
        aiStrategies[state.p.driverId] = AiStrategyState(plan)
        // The caller invokes this only for a stop opportunity (weather, critical
        // wear or Safety Car); even when the same compound is selected, replace it.
        pit(state, selectedTyre)
    }

    private fun rebuildRaceStartPlansForCurrentWeather() {
        val c = circuit ?: return
        plans.clear()
        aiStrategies.clear()

        // Cada piloto da IA recebe um plano independente antes da largada. A seleção
        // considera carro/equipe, atributos individuais, posição no grid e clima.
        states.values.filter { it.p.teamId != activePlayerTeamId }.forEach { state ->
            val aiPlan = buildAiTyreStrategy(state, c.laps, weather)
            aiStrategies[state.p.driverId] = AiStrategyState(aiPlan)
            state.tyre = aiPlan.sequence.firstOrNull() ?: when (weather) {
                Weather.HEAVY_RAIN -> Tyre.WET
                Weather.LIGHT_RAIN, Weather.MEDIUM_RAIN -> Tyre.INTERMEDIATE
                Weather.DRY, Weather.CLOUDY -> Tyre.MEDIUM
            }
            state.stint = 0
            state.wear = 0
            state.wearExact = 0.0
        }

        states.values.filter { it.p.teamId == activePlayerTeamId }.forEach { state ->
            val tyrePlans = TyreModel.buildPlansForWeather(c.laps, weather)
            val firstTyre = tyrePlans["A"]?.sequence?.firstOrNull() ?: when (weather) {
                Weather.HEAVY_RAIN -> Tyre.WET
                Weather.LIGHT_RAIN, Weather.MEDIUM_RAIN -> Tyre.INTERMEDIATE
                Weather.DRY, Weather.CLOUDY -> Tyre.MEDIUM
            }
            plans[state.p.driverId] = DriverPlan(
                tyre = firstTyre,
                activePlan = "A",
                planStintIndex = 0,
                tyrePlans = tyrePlans
            )
            state.tyre = firstTyre
            state.stint = 0
            state.wear = 0
            state.wearExact = 0.0
        }
    }

    /**
     * The qualifying result is authoritative for the actual race start.
     * Previously the UI showed the calculated grid, but S.position/S.grid and
     * cumulative start gaps remained tied to driverId+1, allowing database
     * ordering to influence the race independently of qualifying performance.
     */
    private fun applyQualifyingGridToRaceStates(finalGrid: List<QualifyingEntry>) {
        finalGrid.forEachIndexed { index, entry ->
            val state = states[entry.driverId] ?: return@forEachIndexed
            val position = index + 1
            state.grid = position
            state.position = position
            state.lastPos = position
            state.total = index.toLong() * STARTING_GRID_GAP_MS
        }
    }

    /** Legacy UI callback retained for binary/source compatibility; pace mode is automatic. */
    @Suppress("UNUSED_PARAMETER")
    @Deprecated("A postura é decidida automaticamente pelo piloto durante a corrida")
    fun setStrategy(driverId: Int, mode: DriverStrategyMode): SessionSnapshot {
        require(plans.containsKey(driverId)) { "Piloto não pertence à equipe do jogador" }
        return snapshot("RACE", emptyList())
    }

    fun qualifyingComplete(): Boolean = qualifyingStage >= 3
    fun qualifyingRunning(): Boolean = qualifyingActive

    /**
     * Prepare the race's own starting weather after qualifying is finished. Calling this
     * repeatedly is safe: a second UI recomposition cannot reroll the weather or rebuild
     * a different tyre plan. Headless/instant simulation is protected by advance() too.
     */
    fun prepareRaceStartWeather(): SessionSnapshot {
        require(qualifyingComplete()) { "Conclua a qualificação antes de definir o clima da corrida" }
        if (!raceStartWeatherPrepared) {
            val c = circuit ?: error("Circuito não iniciado")
            weather = CircuitWeatherModel.raceStartWeather(c, raceWeatherRandom)
            lastWeatherCheckLap = 0
            raceRainStartedLap = if (CircuitWeatherModel.isRain(weather)) 1 else -1
            rebuildRaceStartPlansForCurrentWeather()
            raceStartWeatherPrepared = true
        }
        return snapshotForUi()
    }
    fun qualifyingPhaseIndex(): Int = qualifyingStage.coerceAtMost(2)
    fun qualifyingElapsedMs(): Long = qualifyingElapsedMs
    fun qualifyingDurationMs(): Long = if (qualifyingStage >= 3) Q3_DURATION_MS else qualifyingDuration(qualifyingStage)

    @Suppress("UNUSED_PARAMETER")
    @Deprecated("O ritmo é sempre decidido automaticamente pelo piloto; apenas o composto pode ser ajustado")
    fun setPlan(driverId: Int, mode: DriverStrategyMode? = null, tyre: Tyre? = null): SessionSnapshot {
        val plan = plans[driverId] ?: error("Piloto não pertence à equipe do jogador")
        // `mode` remains in the signature for compatibility with older callers/save data,
        // but it can no longer override the automatic Attack/Balanced/Poupar policy.
        if (tyre != null) {
            plan.tyre = tyre
            states[driverId]?.tyre = tyre
        }
        return snapshot("RACE", emptyList())
    }

    /** Stable circuit identity used by orchestration boundaries before an instant run. */
    fun configuredCircuit(): RaceCircuit? = circuit

    fun snapshotForUi(): SessionSnapshot = snapshot(if (finished) "RESULT" else "RACE", emptyList())

    fun setTyrePlan(driverId: Int, planId: String): SessionSnapshot {
        val plan = plans[driverId] ?: error("Piloto não pertence à equipe do jogador")
        require(!plan.weatherManualMode || planId == "LIVRE") { "Plano A/B/C abandonado após entrada de chuva; crie um Plano Livre para as condições atuais" }
        require(plan.tyrePlans.containsKey(planId)) { "Plano de pneus inexistente: $planId" }
        val selected = plan.tyrePlans.getValue(planId)
        require(selected.sequence.isNotEmpty()) { "O plano precisa ter pelo menos um stint" }
        plan.activePlan = planId
        plan.planStintIndex = 0
        plan.tyre = selected.sequence.first()
        plan.pendingFreePlan = null
        plan.weatherManualMode = false
        states[driverId]?.tyre = plan.tyre
        return snapshot("RACE", emptyList())
    }

    /** Salva um plano livre de 1 a 6 stints; pode ativá-lo antes da largada ou apenas prepará-lo para o próximo box. */
    fun setFreeTyrePlan(
        driverId: Int,
        sequence: List<Tyre>,
        stintLaps: List<Int>,
        activate: Boolean = true
    ): SessionSnapshot {
        val plan = plans[driverId] ?: error("Piloto não pertence à equipe do jogador")
        val driverState = states[driverId] ?: error("Piloto inexistente")
        val requiredLaps = if (lap <= 0) {
            circuit?.laps ?: 0
        } else {
            ((circuit?.laps ?: lap) - lap).coerceAtLeast(0)
        }
        val validation = TyreModel.validateFreePlan(
            requiredLaps = requiredLaps,
            weather = weather,
            mode = plan.mode,
            driverTyreWear = driverState.p.tyreWear,
            sequence = sequence,
            stintLaps = stintLaps
        )
        require(validation.valid) { validation.issues.joinToString(" ") }

        val freePlan = TyrePlan("LIVRE", sequence.toList(), stintLaps.toList())
        if (activate) {
            plan.tyrePlans = plan.tyrePlans + ("LIVRE" to freePlan)
            plan.pendingFreePlan = null
            plan.activePlan = "LIVRE"
            plan.planStintIndex = 0
            plan.tyre = freePlan.sequence.first()
            plan.weatherManualMode = false
            driverState.tyre = plan.tyre
        } else {
            // A estratégia atual não muda até o jogador confirmar o próximo pit stop.
            plan.pendingFreePlan = freePlan
        }
        return snapshot("RACE", emptyList())
    }

    /** Aplica no box o plano livre preparado para as voltas que ainda faltam. */
    fun pitWithFreeTyrePlan(driverId: Int): SessionSnapshot {
        val plan = plans[driverId] ?: error("Piloto não pertence à equipe do jogador")
        val driverState = states[driverId] ?: error("Piloto inexistente")
        val remainingLaps = ((circuit?.laps ?: lap) - lap).coerceAtLeast(0)
        val freePlan = plan.pendingFreePlan?.takeIf { it.stintLaps.sum() == remainingLaps }
            ?: plan.tyrePlans["LIVRE"]?.takeIf { it.stintLaps.sum() == remainingLaps }
            ?: error("O Plano Livre não cobre exatamente as voltas restantes. Edite e valide novamente.")
        val validation = TyreModel.validateFreePlan(
            requiredLaps = remainingLaps,
            weather = weather,
            mode = plan.mode,
            driverTyreWear = driverState.p.tyreWear,
            sequence = freePlan.sequence,
            stintLaps = freePlan.stintLaps
        )
        require(validation.valid) { validation.issues.joinToString(" ") }
        val nextTyre = TyreModel.compoundForWeather(weather, freePlan.sequence.first(), remainingLaps.coerceAtLeast(1))
        pit(driverState, nextTyre)
        plan.tyrePlans = plan.tyrePlans + ("LIVRE" to freePlan)
        plan.pendingFreePlan = null
        plan.activePlan = "LIVRE"
        plan.planStintIndex = 0
        plan.tyre = nextTyre
        plan.weatherManualMode = false
        if (pending?.request?.driverId == driverId) completePendingDecision(false)
        return snapshot("RACE", emptyList())
    }

    fun pitWithPlan(driverId: Int, planId: String): SessionSnapshot {
        val plan = plans[driverId] ?: error("Piloto não pertence à equipe do jogador")
        require(!plan.weatherManualMode) { "Plano A/B/C abandonado após entrada de chuva; troca manual obrigatória" }
        require(plan.tyrePlans.containsKey(planId)) { "Plano de pneus inexistente: $planId" }
        plan.activePlan = planId
        val driverState = states[driverId] ?: error("Piloto inexistente")
        val tyrePlan = plan.tyrePlans.getValue(planId)
        val nextIndex = (plan.planStintIndex + 1).coerceAtMost(tyrePlan.sequence.lastIndex)
        val nextTyre = TyreModel.compoundForWeather(weather, tyrePlan.sequence[nextIndex], (circuit?.laps ?: lap) - lap)
        pit(driverState, nextTyre)
        plan.activePlan = planId
        plan.planStintIndex = nextIndex
        plan.tyre = nextTyre
        plan.pendingFreePlan = null
        if (pending != null) completePendingDecision(false)
        return snapshot("RACE", emptyList())
    }

    fun pitNow(driverId: Int, tyre: Tyre = plans[driverId]?.tyre ?: Tyre.MEDIUM): SessionSnapshot {
        val s = states[driverId] ?: error("Piloto inexistente")
        require(!s.dnf && !finished) { "Piloto não está em corrida" }
        pit(s, tyre)
        // Qualquer troca manual abandona definitivamente o plano deste piloto.
        plans[driverId]?.let { plan ->
            plan.weatherManualMode = true
            plan.activePlan = "MANUAL"
            plan.pendingFreePlan = null
            plan.tyre = tyre
        }
        if (pending?.request?.driverId == driverId) completePendingDecision(false)
        return snapshot("RACE", emptyList())
    }

    /**
     * Final da chuva: solicita uma decisão explícita para cada piloto do jogador
     * que ainda esteja com INTERMEDIATE/WET. Não executa pit stop nem escolhe slick.
     * Internal para permitir regressão determinística sem depender do sorteio climático.
     */
    internal fun requestPlayerTyreChoiceAfterRain(previousWeather: Weather, newWeather: Weather): Boolean {
        if (previousWeather !in listOf(Weather.LIGHT_RAIN, Weather.MEDIUM_RAIN, Weather.HEAVY_RAIN)) return false
        if (!TyreModel.isDryTrack(newWeather)) return false
        weather = newWeather

        val wetPlayerDrivers = states.values
            .filter { plans.containsKey(it.p.driverId) && !it.dnf && it.tyre in TyreModel.wetCompounds }
            .sortedWith(compareBy<S> { it.position }.thenBy { it.grid })
        if (wetPlayerDrivers.isEmpty()) return false

        val dryText = if (newWeather == Weather.DRY) {
            "A chuva terminou e a pista está seca."
        } else {
            "A chuva diminuiu e a pista está secando."
        }
        wetPlayerDrivers.forEach { state ->
            plans[state.p.driverId]?.let { plan ->
                // A entrada da chuva encerra o plano automático. Ao secar, não se
                // retoma o plano antigo nem se escolhe HARD/MEDIUM silenciosamente.
                plan.weatherManualMode = true
                plan.pendingFreePlan = null
            }
            events += LapEvent(
                lap,
                state.p.driverId,
                EventType.WEATHER_CHANGE,
                "Rádio: $dryText Escolha BOX para selecionar SOFT, MEDIUM ou HARD, ou permaneça na pista."
            )
        }

        return pauseForDrivers(
            wetPlayerDrivers,
            "$dryText Seus pilotos ainda usam pneus de chuva. Entre nos boxes para escolher SOFT, MEDIUM ou HARD; nenhuma troca será feita automaticamente.",
            ManagerDecisionType.WEATHER_CHANGE
        )
    }

    fun advance(): SessionSnapshot {
        check(!finished) { "Fim de semana concluído" }
        check(pending == null) { "Resolva a decisão pendente" }
        if (qualifyingComplete() && !raceStartWeatherPrepared) prepareRaceStartWeather()
        val c = circuit ?: error("Circuito não iniciado")
        if (!lapInProgress) {
            if (lap == 0) lap = 1 else lap++
            if (lap > c.laps) return finish()
            lapInProgress = true
            lapPreparationDone = false
            processedDriverIdsThisLap.clear()
            lapStartTotalsByDriver = states.values.filterNot { it.dnf }
                .associate { it.p.driverId to it.total }
        }
        val before = events.size
        // Guarda a classificação imediatamente anterior ao processamento desta volta.
        val positionsBeforeLap = states.values.associate { it.p.driverId to it.position }

        if (!lapPreparationDone) {
        if (neutral != Neutralisation.GREEN && lap > neutralEnd) {
            events += LapEvent(lap, null, if (neutral == Neutralisation.SAFETY_CAR) EventType.SAFETY_CAR_ENDED else EventType.VSC_ENDED, "Neutralização encerrada")
            neutral = Neutralisation.GREEN
        }

        val previousWeather = weather
        // Evaluate at most once every six laps. Rain fronts are allowed to clear
        // much more readily than they are allowed to begin, with a hard 18-lap cap
        // on one continuous wet spell. This prevents full-race rain caused by an
        // unlucky sequence of low-probability transition rolls.
        if (lap - lastWeatherCheckLap >= 6) {
            lastWeatherCheckLap = lap
            val profile = CircuitWeatherModel.profileForCircuit(c)
            val continuousRainLaps = if (CircuitWeatherModel.isRain(weather)) {
                if (raceRainStartedLap > 0) lap - raceRainStartedLap + 1 else 1
            } else 0
            if (CircuitWeatherModel.shouldTransitionDuringRace(
                    weather, profile, raceWeatherRandom, continuousRainLaps
                )) {
                weather = CircuitWeatherModel.nextRaceWeather(
                    weather, raceWeatherRandom, continuousRainLaps
                )
            }
            if (CircuitWeatherModel.isRain(weather)) {
                if (!CircuitWeatherModel.isRain(previousWeather)) raceRainStartedLap = lap
            } else {
                raceRainStartedLap = -1
            }
        }

        // Quando a chuva termina, os carros do jogador nunca podem escolher um
        // composto seco automaticamente. A decisão do composto pertence ao manager,
        // inclusive quando a corrida começou com chuva e o plano A/B/C ainda estava ativo.
        if (weather != previousWeather && TyreModel.isDryTrack(weather) &&
            previousWeather in listOf(Weather.LIGHT_RAIN, Weather.MEDIUM_RAIN, Weather.HEAVY_RAIN)) {
            if (requestPlayerTyreChoiceAfterRain(previousWeather, weather)) {
                return snapshot("RACE", events.drop(before))
            }
        }

        if (weather != previousWeather && (weather == Weather.LIGHT_RAIN || weather == Weather.MEDIUM_RAIN || weather == Weather.HEAVY_RAIN)) {
            val requiredRainTyre = if (weather == Weather.HEAVY_RAIN) Tyre.WET else Tyre.INTERMEDIATE
            val rainText = if (weather == Weather.HEAVY_RAIN) {
                "Chuva forte detectada. WET recomendado."
            } else {
                "Chuva detectada. INTERMEDIÁRIO recomendado."
            }

            // A entrada de chuva abandona o plano A/B/C para os dois pilotos.
            // A partir deste momento nenhum stint do plano pode disparar um box
            // automático, nem quando a chuva terminar. Cada nova troca passa a
            // depender exclusivamente de uma decisão manual do manager.
            plans.values.forEach {
                it.weatherManualMode = true
                it.pendingFreePlan = null
            }

            val teamDrivers = states.values
                .filter { plans.containsKey(it.p.driverId) && !it.dnf && it.tyre != requiredRainTyre }
                .sortedWith(compareBy<S> { it.position }.thenBy { it.grid })
            if (teamDrivers.isNotEmpty()) {
                if (pauseForPlayers(
                        "$rainText Há pilotos com composto inadequado. Escolha manualmente BOX ou permaneça na pista.",
                        ManagerDecisionType.WEATHER_CHANGE
                    )) return snapshot("RACE", events.drop(before))
            }
        }

        if (neutral == Neutralisation.GREEN) {
            val r = random.nextDouble()
            // Neutralizações espontâneas são raras. A maior parte das neutralizações
            // deve nascer de um incidente relevante, e mesmo um acidente não implica
            // automaticamente VSC/SC.
            if (r < .0012 * c.safetyCarRisk) {
                neutral = Neutralisation.SAFETY_CAR
                neutralEnd = min(c.laps, lap + random.nextInt(2, 5))
                groupPeloton(resetLastLap = false)
                events += LapEvent(lap, null, EventType.SAFETY_CAR_DEPLOYED, "Safety Car — pelotão agrupando")
                if (pauseForPlayers("Safety Car na pista. Box, manter ou estender?", ManagerDecisionType.SAFETY_CAR)) return snapshot("RACE", events.drop(before))
            } else if (r < .0040 * c.safetyCarRisk) {
                neutral = Neutralisation.VSC
                neutralEnd = min(c.laps, lap + random.nextInt(1, 3))
                events += LapEvent(lap, null, EventType.VSC_DEPLOYED, "VSC")
                if (pauseForPlayers("VSC ativo. Aproveitar a janela estratégica?", ManagerDecisionType.VSC)) return snapshot("RACE", events.drop(before))
            }
        }

        lapPreparationDone = true
        }

        val active = states.values.filterNot { it.dnf }
            .filter { it.p.driverId !in processedDriverIdsThisLap }
            .sortedWith(compareBy<S> { it.total }.thenBy { it.grid })
        // Largada ruim é um incidente coletivo: um único sorteio por corrida,
        // podendo atingir vários pilotos do pelotão na mesma largada.
        // O evento não é sorteado independentemente para cada piloto.
        if (lap == 1 && badStartDriverIds.isEmpty() && active.size >= 2 && random.nextDouble() < 0.18) {
            val shuffled = active.shuffled(random)
            val affectedCount = random.nextInt(2, min(6, active.size + 1))
            badStartDriverIds.addAll(shuffled.take(affectedCount).map { it.p.driverId })
        }
        rainIncidentDriverId = if (weather == Weather.HEAVY_RAIN && active.isNotEmpty() && random.nextDouble() < 0.15) {
            active[random.nextInt(active.size)].p.driverId
        } else null
        // Um único incidente coletivo pode ser sorteado por volta para todo o grid.
        // A taxa global foi reduzida: 2% por volta fazia uma corrida de 60 voltas ter
        // cerca de 70% de chance de acidente, e todo acidente provocava DNF automático.
        // Agora o circuito, a consistência e a habilidade na chuva influenciam o risco.
        val lapCrashDriverId = if (neutral == Neutralisation.GREEN && lap > 2 && active.isNotEmpty()
            && random.nextDouble() < RaceIncidentBalance.crashChancePerLap(c.crashRisk)) {
            RaceIncidentBalance.selectDriverId(active.map { it.p }, weather, random)
        } else null

        // Agenda os incidentes adicionais uma única vez por GP. O furo é no máximo
        // um por corrida; a pane elétrica é rara e sua probabilidade sobe quando a
        // confiabilidade média do MGU-K - ERS é menor.
        if (lap == 1 && !raceIncidentsScheduled && active.isNotEmpty()) {
            raceIncidentsScheduled = true
            if (c.laps >= 8 && random.nextDouble() < 0.30) {
                punctureScheduled = true
                val earliest = (c.laps * 0.20).toInt().coerceIn(2, c.laps - 2)
                val latest = (c.laps * 0.82).toInt().coerceIn(earliest, c.laps - 2)
                punctureLap = if (latest > earliest) random.nextInt(earliest, latest + 1) else earliest
            }
            val averageElectricReliability = active.map { it.p.electricPowerUnitReliability.coerceIn(40, 100) }.average()
            val electricFailureChance = (0.30 * (1.40 - averageElectricReliability / 100.0)).coerceIn(0.08, 0.40)
            if (c.laps >= 8 && random.nextDouble() < electricFailureChance) {
                electricalFailureScheduled = true
                val earliest = (c.laps * 0.18).toInt().coerceIn(2, c.laps - 2)
                val latest = (c.laps * 0.86).toInt().coerceIn(earliest, c.laps - 2)
                electricalFailureLap = if (latest > earliest) random.nextInt(earliest, latest + 1) else earliest
            }
        }
        val punctureDriverThisLap = if (punctureScheduled && !punctureTriggered && lap == punctureLap && active.isNotEmpty())
            active[random.nextInt(active.size)].p.driverId else null
        val electricalFailureDriverThisLap = if (electricalFailureScheduled && !electricalFailureTriggered && lap == electricalFailureLap && active.isNotEmpty())
            active[random.nextInt(active.size)].p.driverId else null
        for (s in active) {
            // V229: acumular penalidades nesta volta e aplicá-las ao tempo de volta
            // final, pois s.last é recalculado mais abaixo no processamento do piloto.
            var incidentLossMs = 0L
            // Largada ruim: os pilotos selecionados pelo sorteio coletivo sofrem
            // uma pequena perda de tempo individual, sem punição automática.
            if (lap == 1 && s.laps == 0 && s.p.driverId in badStartDriverIds) {
                val lossMs = random.nextLong(150L, 601L)
                incidentLossMs += lossMs
                events += LapEvent(lap, s.p.driverId, EventType.CRASH,
                    "LARGADA RUIM: ${s.p.driverName} teve uma saída lenta e perdeu ${"%.2f".format(java.util.Locale.US, lossMs / 1000.0)} s.")
            }
            // Chuva forte: chance global de 15% por volta de ocorrer uma única saída de pista.
            // O sorteio ocorre uma vez por volta e apenas um piloto pode receber o evento.
            if (weather == Weather.HEAVY_RAIN && !s.dnf && s.p.driverId == rainIncidentDriverId) {
                val lossMs = random.nextLong(1800L, 5001L)
                incidentLossMs += lossMs
                events += LapEvent(lap, s.p.driverId, EventType.CRASH,
                    "PERDA DE CONTROLE NA CHUVA FORTE: ${s.p.driverName} saiu da pista e perdeu ${"%.2f".format(java.util.Locale.US, lossMs / 1000.0)} s.")
            }
            val plan = plans[s.p.driverId]
            val aiStrategy = aiStrategies[s.p.driverId]
            val aiWeatherTyre = when (weather) {
                Weather.HEAVY_RAIN -> Tyre.WET
                Weather.LIGHT_RAIN, Weather.MEDIUM_RAIN -> Tyre.INTERMEDIATE
                Weather.CLOUDY, Weather.DRY -> null
            }
            if (plan == null && aiStrategy != null && !s.dnf && lap < c.laps) {
                val remainingBeforeLap = (c.laps - lap + 1).coerceAtLeast(1)
                val weatherMismatch = (aiWeatherTyre != null && s.tyre != aiWeatherTyre) ||
                    (TyreModel.isDryTrack(weather) && s.tyre in TyreModel.wetCompounds)

                if (weatherMismatch) {
                    // Mudança de clima invalida a estratégia anterior. A IA recalcula
                    // o plano completo para as voltas restantes, sem voltar a uma
                    // sequência universal de compostos.
                    rebuildAiStrategyAfterUnplannedStop(s, remainingBeforeLap)
                    events += LapEvent(lap, s.p.driverId, EventType.WEATHER_CHANGE,
                        "Estratégia da equipe atualizada: ${tyreLabel(s.tyre)} para as condições atuais.")
                } else {
                    val activeAiPlan = aiStrategy.plan
                    val lastStint = activeAiPlan.sequence.lastIndex
                    val targetStintLaps = activeAiPlan.stintLaps.getOrElse(aiStrategy.stintIndex) { s.tyre.targetLaps }
                    val plannedWindowReached = s.stint >= targetStintLaps
                    val criticalWearBeforeWindow = s.wear >= TyreModel.AUTOMATIC_TYRE_CHANGE_WEAR_PERCENT &&
                        s.stint < targetStintLaps
                    val safetyCarWindow = neutral != Neutralisation.GREEN && aiStrategy.stintIndex < lastStint &&
                        s.stint >= (targetStintLaps - 2).coerceAtLeast(1)

                    when {
                        criticalWearBeforeWindow || safetyCarWindow -> {
                            // Desgaste inesperado ou neutralização perto da janela:
                            // recalcula com o número real de voltas restantes.
                            rebuildAiStrategyAfterUnplannedStop(s, remainingBeforeLap)
                        }
                        plannedWindowReached && aiStrategy.stintIndex < lastStint -> {
                            val nextIndex = aiStrategy.stintIndex + 1
                            val plannedCompound = activeAiPlan.sequence[nextIndex]
                            val next = TyreModel.compoundForWeather(weather, plannedCompound, remainingBeforeLap)
                            pit(s, next)
                            aiStrategies[s.p.driverId]?.stintIndex = nextIndex
                        }
                        // Safety net: se a simulação dinâmica prolongar o stint final
                        // além da previsão, a IA escolhe um novo plano para o trecho.
                        aiStrategy.stintIndex == lastStint && s.wear >= (90 + s.aiPitBias).coerceIn(86, 96) -> {
                            rebuildAiStrategyAfterUnplannedStop(s, remainingBeforeLap)
                        }
                    }
                }
            }
            if (s.dnf) {
                processedDriverIdsThisLap += s.p.driverId
                continue
            }
            if (s.p.driverId == punctureDriverThisLap && !punctureTriggered) {
                punctureTriggered = true
                val remainingAfterPuncture = (c.laps - lap + 1).coerceAtLeast(1)
                val replacementTyre = if (plans[s.p.driverId] == null && aiStrategies.containsKey(s.p.driverId)) {
                    val emergencyPlan = buildAiTyreStrategy(s, remainingAfterPuncture, weather)
                    aiStrategies[s.p.driverId] = AiStrategyState(emergencyPlan)
                    emergencyPlan.sequence.firstOrNull() ?: TyreModel.compoundForWeather(weather, nextTyre(s.tyre), remainingAfterPuncture)
                } else {
                    TyreModel.compoundForWeather(weather, nextTyre(s.tyre), remainingAfterPuncture)
                }
                events += LapEvent(lap, s.p.driverId, EventType.MECHANICAL_FAILURE,
                    "FURO DE PNEU: ${s.p.driverName} sofreu um furo e precisou fazer uma parada emergencial; perda de 21 s.")
                pit(s, replacementTyre)
                // A parada emergencial reinicia também a estratégia individual da IA.
            }
            if (s.p.driverId == electricalFailureDriverThisLap && !electricalFailureTriggered) {
                electricalFailureTriggered = true
                s.dnf = true
                s.ers = 0.0
                s.ersActive = false
                s.dnfReason = "PANE ELÉTRICA • MGU-K - ERS"
                events += LapEvent(lap, s.p.driverId, EventType.MECHANICAL_FAILURE,
                    "PANE ELÉTRICA • MGU-K - ERS: ${s.p.driverName} sofreu uma falha elétrica e abandonou a corrida (DNF).")
                processedDriverIdsThisLap += s.p.driverId
                continue
            }
            // Mentalidade automática para todos os pilotos, inclusive os da equipe do jogador.
            // A mesma política estratégica da IA decide quando atacar, equilibrar ou poupar.
            val mode = aiMode(s, weather)
            if (plan != null) plan.mode = mode

            // Incidentes reais: acidentes/falhas podem gerar VSC, Safety Car ou,
            // em um acidente grave, bandeira vermelha. Acidentes também podem
            // atingir um carro que esteja muito próximo.
            if (neutral == Neutralisation.GREEN && lap > 2 && !s.dnf) {
                // V239: apenas o piloto escolhido no sorteio global pode iniciar o acidente
                // desta volta; isso impede cascatas de acidentes independentes no mesmo GP.
                val crash = s.p.driverId == lapCrashDriverId
                if (crash) {
                    val severeCrash = random.nextDouble() < RaceIncidentBalance.severeCrashChance(
                        s.p.consistency, s.p.wetSkill, weather
                    )
                    if (severeCrash) {
                        s.dnf = true
                        s.dnfReason = "ACIDENTE"
                        events += LapEvent(lap, s.p.driverId, EventType.CRASH, "${s.p.driverName} sofreu um acidente grave na volta $lap e abandonou")
                    } else {
                        val lossMs = random.nextLong(1800L, 7001L)
                        incidentLossMs += lossMs
                        s.wear = (s.wear + 5).coerceAtMost(100)
                        s.wearExact = (s.wearExact + 5.0).coerceAtMost(100.0)
                        events += LapEvent(lap, s.p.driverId, EventType.CRASH,
                            "${s.p.driverName} perdeu o controle, recuperou a pista e perdeu ${"%.2f".format(java.util.Locale.US, lossMs / 1000.0)} s")
                    }

                    // Só envolve carros próximos na ordem de corrida. O intervalo de posições
                    // é um filtro de plausibilidade; carros distantes não são vítimas aleatórias.
                    val nearby = states.values
                        .filter { it.p.driverId != s.p.driverId && !it.dnf && kotlin.math.abs(it.position - s.position) <= 4 }
                        .sortedBy { kotlin.math.abs(it.position - s.position) }
                    var collisionCount = 0
                    var eventDnfCount = if (s.dnf) 1 else 0
                    val maximumIncidentDnfs = if (s.dnf) 3 else 2
                    for (victim in nearby) {
                        if (collisionCount >= 4) break // máximo de 5 carros envolvidos, contando o causador
                        if (random.nextDouble() >= 0.32) continue
                        collisionCount++
                        if (eventDnfCount < maximumIncidentDnfs && random.nextDouble() < RaceIncidentBalance.BASE_COLLISION_DNF_CHANCE) {
                            victim.dnf = true
                            victim.dnfReason = "ACIDENTE • COLISÃO"
                                        eventDnfCount++
                            events += LapEvent(lap, victim.p.driverId, EventType.CRASH, "${victim.p.driverName} abandonou após colisão com ${s.p.driverName}")
                        } else {
                            // Sobrevive ao acidente, mas precisa de reparo nos boxes.
                            val damageLossMs = random.nextLong(12000L, 30001L)
                            victim.total += damageLossMs
                            victim.last += damageLossMs
                            victim.wear = (victim.wear + 18).coerceAtMost(100)
                            victim.wearExact = (victim.wearExact + 18.0).coerceAtMost(100.0)
                            events += LapEvent(lap, victim.p.driverId, EventType.CRASH, "${victim.p.driverName} danificou o carro na colisão e precisa ir aos boxes; perda estimada de ${"%.1f".format(java.util.Locale.US, damageLossMs / 1000.0)} s")
                        }
                    }

                    val severe = crash && s.dnf && !redFlagUsed && lap > 5 && random.nextDouble() < 0.04
                    if (severe) {
                        redFlagUsed = true
                        // Bandeira vermelha interrompe a corrida de verdade: não é Safety Car.
                        // O pelotão fica parado e será reorganizado para uma nova largada
                        // somente depois que os dois pilotos do manager tomarem suas decisões.
                        neutral = Neutralisation.GREEN
                        neutralEnd = lap
                        groupPeloton()
                        prepareRedFlagRestartPlans(c.laps - lap)
                        events += LapEvent(lap, null, EventType.RED_FLAG_DEPLOYED, "BANDEIRA VERMELHA — corrida interrompida; novos planos para ${c.laps - lap} voltas preparados")
                        processedDriverIdsThisLap += s.p.driverId
                        if (pauseForPlayers("Bandeira vermelha após acidente. Escolha o plano de pneus para a relargada.", ManagerDecisionType.RED_FLAG)) return snapshot("RACE", events.drop(before))
                    } else {
                        // Um acidente não fecha automaticamente a pista. Só alguns
                        // incidentes têm gravidade suficiente para VSC/SC.
                        val neutralRoll = random.nextDouble()
                        val neutralAfterIncident = if (crash) {
                            when {
                                neutralRoll < 0.08 -> Neutralisation.SAFETY_CAR
                                neutralRoll < 0.23 -> Neutralisation.VSC
                                else -> Neutralisation.GREEN
                            }
                        } else {
                            if (neutralRoll < 0.04) Neutralisation.VSC else Neutralisation.GREEN
                        }
                        if (neutralAfterIncident != Neutralisation.GREEN) {
                            neutral = neutralAfterIncident
                            if (neutral == Neutralisation.SAFETY_CAR) groupPeloton(resetLastLap = false)
                            neutralEnd = min(c.laps, lap + if (neutral == Neutralisation.SAFETY_CAR) random.nextInt(2, 5) else random.nextInt(1, 3))
                            events += LapEvent(lap, null, if (neutral == Neutralisation.SAFETY_CAR) EventType.SAFETY_CAR_DEPLOYED else EventType.VSC_DEPLOYED, if (neutral == Neutralisation.SAFETY_CAR) "Safety Car após acidente — pelotão agrupando" else "VSC após acidente")
                            if (pauseForPlayers(if (neutral == Neutralisation.SAFETY_CAR) "Acidente na pista. Safety Car. Box, manter ou estender?" else "Acidente na pista. VSC ativo. Aproveitar a janela?", if (neutral == Neutralisation.SAFETY_CAR) ManagerDecisionType.SAFETY_CAR else ManagerDecisionType.VSC)) return snapshot("RACE", events.drop(before))
                        }
                    }
                    processedDriverIdsThisLap += s.p.driverId
                    continue
                }
            }

            if (plan != null && lap < c.laps && !s.bypassCriticalOnce) {
                // V436: an automated plan must react to a weather transition even
                // between scheduled stints. Otherwise a player car can remain on
                // INTERMEDIATE/WET tyres after the track has dried until the next
                // planned pit window. Manual tyre choices remain under player control.
                if (!plan.weatherManualMode && plan.activePlan != "MANUAL") {
                    val weatherCorrectTyre = TyreModel.compoundForWeather(
                        weather, s.tyre, (c.laps - lap).coerceAtLeast(1)
                    )
                    if (weatherCorrectTyre != s.tyre) {
                        pit(s, weatherCorrectTyre)
                        plan.tyre = weatherCorrectTyre
                    }
                }
                val activeTyrePlan = if (plan.weatherManualMode || plan.activePlan == "MANUAL") null else plan.tyrePlans[plan.activePlan]
                if (activeTyrePlan != null && plan.planStintIndex < activeTyrePlan.sequence.lastIndex) {
                    // O plano escolhido pelo Manager é EXECUTADO automaticamente.
                    // A equipe não deve parar para pedir uma decisão manual só porque
                    // o pneu chegou ao limite: o plano manda no box enquanto estiver ativo.
                    // A troca acontece pela janela planejada OU por desgaste crítico,
                    // usando sempre o próximo composto do próprio plano.
                    val targetStintLaps = activeTyrePlan.stintLaps.getOrElse(plan.planStintIndex) { s.tyre.targetLaps }
                    val criticalWear = s.wear >= TyreModel.AUTOMATIC_TYRE_CHANGE_WEAR_PERCENT
                    if (s.stint >= targetStintLaps || criticalWear) {
                        val nextIndex = (plan.planStintIndex + 1).coerceAtMost(activeTyrePlan.sequence.lastIndex)
                        val proposedCompound = activeTyrePlan.sequence[nextIndex]
                        val nextCompound = TyreModel.compoundForWeather(weather, proposedCompound, c.laps - lap)
                        pit(s, nextCompound)
                        plan.planStintIndex = nextIndex
                        plan.tyre = nextCompound
                    }
                }

                if ((weather == Weather.LIGHT_RAIN || weather == Weather.MEDIUM_RAIN) && s.tyre != Tyre.INTERMEDIATE && lap != s.lastTyreAlertLap) {
                    s.lastTyreAlertLap = lap
                    events += LapEvent(lap, s.p.driverId, EventType.WEATHER_CHANGE, "Rádio: chuva fraca/média — intermediário recomendado")
                }
                if (weather == Weather.HEAVY_RAIN && s.tyre != Tyre.WET && lap != s.lastTyreAlertLap) {
                    s.lastTyreAlertLap = lap
                    events += LapEvent(lap, s.p.driverId, EventType.WEATHER_CHANGE, "Rádio: chuva forte — WET recomendado")
                }
                if (!s.fuelSavingAccepted && FuelModel.fuelPercent(s.fuel) <= 25 && lap != s.lastFuelAlertLap) {
                    s.lastFuelAlertLap = lap
                    events += LapEvent(lap, s.p.driverId, EventType.WEAR_WARNING, "Rádio: combustível baixo (${FuelModel.fuelPercent(s.fuel)}%)")
                }
                if (s.wear >= 65 && lap != s.lastTyreAlertLap) {
                    s.lastTyreAlertLap = lap
                    events += LapEvent(lap, s.p.driverId, EventType.WEAR_WARNING, "Rádio: ${s.tyre} perdendo desempenho (${s.wear}%)")
                }
                if (!s.fuelSavingAccepted && !s.fuelCriticalAutoAlertSent &&
                    FuelModel.fuelPercent(s.fuel) <= 12 && mode == DriverStrategyMode.DEFENSE &&
                    (c.laps - lap + 1) > 1) {
                    s.fuelCriticalAutoAlertSent = true
                    events += LapEvent(
                        lap, s.p.driverId, EventType.WEAR_WARNING,
                        "Rádio: combustível crítico (${FuelModel.fuelPercent(s.fuel)}%). ${s.p.driverName} ativa automaticamente o perfil POUPAR para garantir a chegada."
                    )
                }
                // Em plano automático, desgaste crítico já foi tratado acima pela própria estratégia.
                // No modo MANUAL, a recomendação é antecipada para 80% e respeita a escolha do jogador.
                if (s.wear >= TyreModel.MANUAL_TYRE_WARNING_WEAR_PERCENT && s.lastManualTyrePromptWear < TyreModel.MANUAL_TYRE_WARNING_WEAR_PERCENT && (plan.weatherManualMode || plan.activePlan == "MANUAL")) {
                    s.lastManualTyrePromptWear = s.wear
                    if (pauseForDriver(s, "Pneu com ${s.wear}% de desgaste. Troca recomendada a partir de 80%. Deseja ir aos boxes ou continuar?", ManagerDecisionType.TYRE_CRITICAL)) return snapshot("RACE", events.drop(before))
                }
            }

            s.bypassCriticalOnce = false
            // ERS é automático, mas precisa de um ciclo real: usar, esvaziar e recuperar.
            // Ataque usa ERS sempre que houver carga útil; equilibrado preserva uma reserva;
            // Poupar conserva a bateria para recuperação.
            val ersThreshold = when (mode) {
                DriverStrategyMode.ATTACK -> 20.0
                DriverStrategyMode.BALANCED -> 35.0
                DriverStrategyMode.DEFENSE -> 101.0
            }
            val epuReliability = s.componentReliability[com.f1teammanager.core.manager.CarComponent.ELECTRIC_POWER_UNIT] ?: s.p.electricPowerUnitReliability.toDouble()
            val ersAvailable = epuReliability > 0.0 && s.ers >= ersThreshold
            s.ersActive = ersAvailable
            val ersBoost = if (ersAvailable) -PitwallPaceModel(random).ersGainMs(s.p, c, s.ers) else 0L

            // DRS é automático e independente da estratégia. A regra é <= 1,000 s do carro à frente.
            // O ganho é sempre negativo em ms: reduz o tempo da volta.
            val orderedBeforeLap = states.values.filterNot { it.dnf }
                .sortedWith(compareBy<S> { it.total }.thenBy { it.grid })
            val idxBeforeLap = orderedBeforeLap.indexOfFirst { it.p.driverId == s.p.driverId }
            val aheadBeforeLap = if (idxBeforeLap > 0) orderedBeforeLap[idxBeforeLap - 1] else null
            val gapBeforeLap = aheadBeforeLap?.let { (s.total - it.total).coerceAtLeast(0L) }
            val rearWingReliability = s.componentReliability[com.f1teammanager.core.manager.CarComponent.REAR_WING] ?: s.p.rearWingReliability.toDouble()
            s.drsActive = neutral == Neutralisation.GREEN && rearWingReliability > 0.0 && aheadBeforeLap != null && gapBeforeLap != null && gapBeforeLap <= 1000L && lap > 2
            val drsBoost = if (s.drsActive) -PitwallPaceModel(random).drsGainMs(s.p, c) else 0L
            val pace = PitwallPaceModel(random)
            val remainingFuel = max(0.0, s.fuel)
            var lapMs = pace.lapTime(s.p, c, remainingFuel, s.stint, s.tyre, false, weather = weather)
            lapMs = TyreModel.applyLapModifiers(
                carDriverLapMs = lapMs,
                gpAverageLapMs = c.baseLapTimeMs,
                tyre = s.tyre,
                weather = weather,
                wearPercent = s.wear,
                mode = mode
            )
            val reliabilityPenalty = s.componentReliability.entries.sumOf { (component, value) ->
                ReliabilityModel.performanceLossPercent(component, value)
            }
            lapMs = (lapMs + c.baseLapTimeMs * reliabilityPenalty).toLong()
            val fuelMultiplier = TyreModel.fuelPenaltyMultiplier(FuelModel.fuelPercent(s.fuel).toDouble())
            lapMs = (lapMs + c.baseLapTimeMs * (fuelMultiplier - 1.0)).toLong().coerceAtLeast(45_000L)
            lapMs += ersBoost + drsBoost
            lapMs += when (weather) {
                Weather.DRY -> 0L
                Weather.CLOUDY -> 120L
                Weather.LIGHT_RAIN -> rainPenalty(s.p, s.tyre, Weather.LIGHT_RAIN)
                Weather.MEDIUM_RAIN -> rainPenalty(s.p, s.tyre, Weather.MEDIUM_RAIN)
                Weather.HEAVY_RAIN -> rainPenalty(s.p, s.tyre, Weather.HEAVY_RAIN)
            }
            lapMs += when (neutral) {
                Neutralisation.SAFETY_CAR -> SAFETY_CAR_PACE_PENALTY_MS
                Neutralisation.VSC -> VSC_PACE_PENALTY_MS
                Neutralisation.GREEN -> 0L
            }
            if (neutral == Neutralisation.SAFETY_CAR) {
                // A Safety Car closes the field progressively by modelling cars behind
                // the leader catching the queue during the slower neutralised lap.
                // Normal pace differences are mostly suppressed while cars follow the SC.
                lapMs = SafetyCarGroupingModel.applyCatchUp(
                    lapTimeWithSafetyCarPenaltyMs = lapMs,
                    gapBehindLeaderMs = gapBehindLeaderAtLapStart(s.p.driverId),
                    circuitReferenceLapMs = c.baseLapTimeMs
                )
            }

            // Aplicar perdas no tempo efetivo da volta, sem serem sobrescritas por s.last.
            lapMs = (lapMs + incidentLossMs).coerceAtLeast(45000L)
            s.total += lapMs
            s.last = lapMs
            s.laps = lap
            processedDriverIdsThisLap += s.p.driverId
            s.stint++
            // Combustível é finito e NÃO é reabastecido durante o pit stop.
            // O tanque inicial é dimensionado para completar a distância + 2 voltas
            // de segurança mesmo em ATTACK contínuo. Ataque consome 10% mais que
            // equilibrado; Poupar economiza. Chuva reduz o consumo.
            s.fuel = max(0.0, s.fuel - FuelModel.consumptionPerLap(c.laps, mode, weather, s.tyre))
            // targetLaps é a vida-base real do composto em ritmo equilibrado.
            // Os fatores abaixo alteram essa vida sem destruir a referência de voltas.
            val wearFactor = TyreModel.tyreWeatherWearFactor(s.tyre, weather)
            val strategyWearFactor = TyreModel.strategyWearFactor(mode)
            // A vida-base do composto é fixa: Soft 15, Medium 25, Hard 36.
            // Em seco/equilibrado: 36 voltas de Hard = 100% (1% por volta).
            // Postura altera somente o desgaste: Ataque 1.10%/volta, Poupar 0.90%/volta.
            // O atributo de conservação de pneus do piloto também entra no desgaste real,
            // mas de forma limitada para não destruir a referência 15/25/36.
            val tyreInfluence = DriverAttributeInfluence.tyre(s.p.tyreWear)
            val driverWearFactor = (1.0 - tyreInfluence).coerceIn(0.90, 1.10)
            val wearIncrement = 100.0 / s.tyre.targetLaps * wearFactor * strategyWearFactor * driverWearFactor
            s.wearExact += wearIncrement
            s.wear = s.wearExact.coerceIn(0.0, 100.0).toInt()

            // Confiabilidade: degradação por volta, com margem dinâmica.
            // O valor de fábrica permanece intacto; apenas o estado desta corrida muda.
            val failedComponents = mutableListOf<com.f1teammanager.core.manager.CarComponent>()
            com.f1teammanager.core.manager.CarComponent.values().forEach { component ->
                val factoryReliability = when (component) {
                    com.f1teammanager.core.manager.CarComponent.ENGINE -> s.p.engineReliability
                    com.f1teammanager.core.manager.CarComponent.CHASSIS -> s.p.chassisReliability
                    com.f1teammanager.core.manager.CarComponent.FRONT_WING -> s.p.frontWingReliability
                    com.f1teammanager.core.manager.CarComponent.REAR_WING -> s.p.rearWingReliability
                    com.f1teammanager.core.manager.CarComponent.BRAKES -> s.p.brakesReliability
                    com.f1teammanager.core.manager.CarComponent.ELECTRIC_POWER_UNIT -> s.p.electricPowerUnitReliability
                }
                val current = s.componentReliability[component] ?: factoryReliability.toDouble()
                if (current > 0.0) {
                    val d = ReliabilityModel.degrade(factoryReliability, current, component, random, c.reliabilityRisk)
                    val next = (current - d.amount).coerceAtLeast(0.0)
                    s.componentReliability[component] = next
                    if (d.stressEvent && next > 0.0) {
                        events += LapEvent(lap, s.p.driverId, EventType.WEAR_WARNING, "${s.p.driverName}: esforço anormal em ${componentLabel(component)}; confiabilidade ${next.toInt()}%")
                    }
                    if (next <= 0.0) failedComponents += component
                }
            }

            // Falhas com consequência específica. Motor, freios e chassi podem gerar DNF;
            // asa dianteira é restaurada no pit, traseira perde DRS e EPU perde ERS.
            failedComponents.forEach { component ->
                when (component) {
                    com.f1teammanager.core.manager.CarComponent.ENGINE,
                    com.f1teammanager.core.manager.CarComponent.BRAKES -> {
                        if (!s.dnf) {
                            s.dnf = true
                            s.dnfReason = if (component == com.f1teammanager.core.manager.CarComponent.ENGINE) "FALHA • MOTOR" else "FALHA • FREIOS"
                            events += LapEvent(lap, s.p.driverId, EventType.MECHANICAL_FAILURE, "${s.p.driverName}: ${componentLabel(component)} chegou a 0% — ${s.dnfReason}")
                        }
                    }
                    com.f1teammanager.core.manager.CarComponent.CHASSIS -> {
                        val remaining = (c.laps - lap).coerceAtLeast(0)
                        val lastTwentyPercent = remaining <= kotlin.math.ceil(c.laps * 0.20).toInt()
                        if (lastTwentyPercent) {
                            s.dnf = true
                            s.dnfReason = "FALHA • CHASSI"
                            events += LapEvent(lap, s.p.driverId, EventType.MECHANICAL_FAILURE, "${s.p.driverName}: chassi chegou a 0% nos últimos 20% do GP — DFN")
                        } else {
                            events += LapEvent(lap, s.p.driverId, EventType.WEAR_WARNING, "${s.p.driverName}: chassi chegou a 0%; perda de desempenho máxima")
                        }
                    }
                    com.f1teammanager.core.manager.CarComponent.FRONT_WING -> {
                        // A falha é detectada depois de o tempo da volta ter sido somado.
                        // Nunca simular um pit-stop retroativo após a bandeirada: isso
                        // acrescentava 21 s ao total sem uma volta posterior para cumprir
                        // a parada e podia inverter artificialmente o vencedor na última volta.
                        if (lap < c.laps) {
                            val tyreBefore = s.tyre
                            pit(s, tyreBefore)
                            s.componentReliability[component] = s.p.frontWingReliability.coerceIn(40, 100).toDouble()
                            events += LapEvent(lap, s.p.driverId, EventType.MECHANICAL_FAILURE, "${s.p.driverName}: asa dianteira chegou a 0%; pit-stop de reparo (+21s), restaurada para ${s.p.frontWingReliability}%")
                        } else {
                            // Já cruzou a linha de chegada nesta volta: registra a falha,
                            // mas não inventa uma parada pós-bandeirada nem altera o resultado.
                            s.componentReliability[component] = 0.0
                            events += LapEvent(lap, s.p.driverId, EventType.MECHANICAL_FAILURE, "${s.p.driverName}: asa dianteira chegou a 0% na última volta; falha registrada após a bandeirada, sem pit-stop retroativo")
                        }
                    }
                    com.f1teammanager.core.manager.CarComponent.REAR_WING -> {
                        s.drsActive = false
                        events += LapEvent(lap, s.p.driverId, EventType.MECHANICAL_FAILURE, "${s.p.driverName}: asa traseira chegou a 0%; DRS perdido")
                    }
                    com.f1teammanager.core.manager.CarComponent.ELECTRIC_POWER_UNIT -> {
                        s.ers = 0.0
                        s.ersActive = false
                        events += LapEvent(lap, s.p.driverId, EventType.MECHANICAL_FAILURE, "${s.p.driverName}: MGU-K - ERS chegou a 0%; ERS perdido")
                    }
                }
            }

            // ERS recarrega automaticamente quando não está em uso e descarrega quando entrega potência.
            // Freios determinam a eficiência de recuperação; o MGU-K - ERS
            // continua responsável pelo uso/entrega do ERS. N6 = referência (90%).
            val recoveryEfficiency = CarComponentInfluence.brakeErsRecovery(s.p.brakesPerformance)
            val electricEfficiency = CarComponentInfluence.electricPowerUnitErsEfficiency(s.p.electricPowerUnitPerformance)
            val ersDelta = if (s.ersActive) {
                // A better electrical unit extracts more useful energy from the same ERS reserve.
                -12.0 * (0.90 / electricEfficiency)
            } else {
                // Brakes recover the energy; the electrical unit determines how much of it becomes usable reserve.
                8.0 * (recoveryEfficiency / 0.90) * (electricEfficiency / 0.90)
            }
            s.ers = (s.ers + ersDelta).coerceIn(0.0, 100.0)

            if (lap < c.laps && s.fuel <= 0.0) {
                s.dnf = true
                s.dnfReason = "SEM COMBUSTÍVEL"
                events += LapEvent(lap, s.p.driverId, EventType.DNF, "${s.p.driverName} ficou sem combustível")
            } else if (s.wear >= 100 && s.stint > s.tyre.targetLaps + 5) {
                // DNF por pneu é independente da cota de acidentes.
                s.dnf = true
                s.dnfReason = "PNEU DEGRADADO"
                events += LapEvent(lap, s.p.driverId, EventType.DNF, "${s.p.driverName} perdeu o pneu por degradação")
            }

            if (lapMs < s.best) {
                s.best = lapMs
                if (lapMs < fastest) {
                    fastest = lapMs
                    fastestId = s.p.driverId
                }
            }
        }

        // A classificação de cada volta deve partir do tempo acumulado real.
        // Usar a posição anterior como ordem-base deixava posições desatualizadas
        // durante a prova e podia produzir saltos artificiais no resultado final.
        // O duelo é processado entre carros adjacentes no tempo acumulado.
        val duelOrder = states.values.filterNot { it.dnf }
            .sortedWith(compareBy<S> { it.total }.thenBy { it.grid })
            .toMutableList()
        if (neutral == Neutralisation.GREEN) for (i in 1 until duelOrder.size) {
            val attacker = duelOrder[i]
            val defender = duelOrder[i - 1]
            if (attacker.dnf || defender.dnf) continue
            val gap = (attacker.total - defender.total).coerceAtLeast(0L)
            val drsFactor = if (attacker.drsActive && gap <= 1000L)
                PitwallPaceModel(random).drsAttackEfficiency(attacker.p) else 1.0
            val attackSkill =
                DriverAttributeInfluence.overtaking(attacker.p.overtaking) *
                    CarComponentInfluence.brakeOvertakingEfficiency(attacker.p.brakesPerformance) *
                    drsFactor
            val defenseSkill =
                DriverAttributeInfluence.defense(defender.p.defense) *
                    CarComponentInfluence.brakeDefenseEfficiency(defender.p.brakesPerformance)
            val paceAdvantage = ((defender.total - attacker.total).toDouble() / 2000.0).coerceIn(-0.35, 0.35)
            val probability = (0.18 + (attackSkill - defenseSkill) * 0.42 + paceAdvantage).coerceIn(0.03, 0.82)
            if (gap <= 1200L && random.nextDouble() < probability) {
                val oldAttacker = attacker.position
                val oldDefender = defender.position
                attacker.position = oldDefender
                defender.position = oldAttacker
                duelOrder[i] = defender
                duelOrder[i - 1] = attacker
                events += LapEvent(lap, attacker.p.driverId, EventType.OVERTAKE,
                    "${attacker.p.driverName} ultrapassou ${defender.p.driverName}${if (attacker.drsActive) " com DRS" else ""}")
            }
        }
        // Recalcula posições após a volta usando o tempo total. Não ordenar pelo
        // índice do duelo: a ordem do duelo não pode substituir a classificação
        // cronométrica nem gerar saltos de várias posições na bandeirada.
        states.values.filterNot { it.dnf }
            .sortedWith(compareBy<S> { it.total }.thenBy { it.grid })
            .forEachIndexed { index, car ->
                car.position = index + 1
                car.lastPos = car.position
            }

        val orderedNow = states.values.filterNot { it.dnf }
            .sortedWith(compareBy<S> { it.total }.thenBy { it.grid })
        orderedNow.forEachIndexed { index, car ->
            val ahead = orderedNow.getOrNull(index - 1)
            // DRS is automatic and uses the actual time gap to the car immediately ahead.
            car.drsActive = neutral == Neutralisation.GREEN && car.position > 1 && ahead != null && (car.total - ahead.total) in 0L..1000L && lap > 2
        }
        // Registra as posições pré e pós-volta nos eventos gerados nesta volta.
        // O evento continua independente da classificação que a tela receber depois.
        val positionsAfterLap = states.values.associate { it.p.driverId to it.position }
        for (eventIndex in before until events.size) {
            val item = events[eventIndex]
            val id = item.driverId ?: continue
            val prior = positionsBeforeLap[id]
            val after = positionsAfterLap[id]
            if (prior != null || after != null) {
                events[eventIndex] = item.copy(positionBefore = prior, positionAfter = after)
            }
        }
        lapInProgress = false
        lapPreparationDone = false
        processedDriverIdsThisLap.clear()
        if (lap >= c.laps) return finish()
        return snapshot("RACE", events.drop(before))
    }

    /**
     * Exposes the final race result to the career layer. The previous update
     * changed the playable engine to CareerWeekendEngine but omitted this
     * adapter, leaving the main UI without a
     * compilable result() method.
     */
    fun result(): RaceResult {
        check(finished) { "A corrida ainda não terminou" }
        val classification = currentClassification()
        val base = RaceResult(
            classification = classification,
            events = events.toList(),
            fastestLapDriverId = fastestId,
            weather = weather,
            points = emptyMap(),
            safetyCarLaps = neutralisationLaps(EventType.SAFETY_CAR_DEPLOYED, EventType.SAFETY_CAR_ENDED),
            vscLaps = neutralisationLaps(EventType.VSC_DEPLOYED, EventType.VSC_ENDED),
            fastestLapTimeMs = fastest.takeIf { it != Long.MAX_VALUE } ?: 0L,
            qualifying = grid
        )
        return base.copy(points = ChampionshipEngine.award(base))
    }

    private fun neutralisationLaps(startType: EventType, endType: EventType): Int {
        var startLap: Int? = null
        var total = 0
        events.forEach { event ->
            when (event.type) {
                startType -> if (startLap == null) startLap = event.lap
                endType -> {
                    val start = startLap
                    if (start != null) total += (event.lap - start).coerceAtLeast(1)
                    startLap = null
                }
                else -> Unit
            }
        }
        startLap?.let { total += (lap - it + 1).coerceAtLeast(1) }
        return total
    }

    fun choose(action: ManagerDecisionAction): SessionSnapshot {
        val d = pending ?: error("Nenhuma decisão pendente")
        val s = states[d.request.driverId]
        if (d.request.type == ManagerDecisionType.RED_FLAG) {
            val planId = when (action) {
                ManagerDecisionAction.RESTART_PLAN_A -> "A"
                ManagerDecisionAction.RESTART_PLAN_B -> "B"
                ManagerDecisionAction.RESTART_PLAN_C -> "C"
                ManagerDecisionAction.RESTART_PLAN_D -> "D"
                else -> null
            }
            if (planId != null) {
                applyRedFlagPlanChoice(d, planId)
            } else {
                val tyre = when (action) {
                    ManagerDecisionAction.CHANGE_TYRE_SOFT -> Tyre.SOFT
                    ManagerDecisionAction.CHANGE_TYRE_MEDIUM -> Tyre.MEDIUM
                    ManagerDecisionAction.CHANGE_TYRE_HARD -> Tyre.HARD
                    ManagerDecisionAction.CHANGE_TYRE_INTERMEDIATE -> Tyre.INTERMEDIATE
                    ManagerDecisionAction.CHANGE_TYRE_WET -> Tyre.WET
                    else -> s?.tyre ?: Tyre.MEDIUM
                }
                // Pace is always automatic; legacy posture actions cannot override it.
                applyRedFlagChoice(d, tyre)
            }
        } else if (s != null) {
            when (action) {
                ManagerDecisionAction.BOX -> {
                    val selectedPlan = plans[s.p.driverId]
                    val plannedTyre = if (selectedPlan == null || selectedPlan.activePlan == "MANUAL" || selectedPlan.weatherManualMode) {
                        nextTyre(s.tyre)
                    } else {
                        selectedPlan.tyre
                    }
                    // Se a chuva terminou, BOX não pode concluir uma troca por conta
                    // própria: a interface deve abrir o seletor e confirmar o composto.
                    check(!(TyreModel.isDryTrack(weather) && s.tyre in TyreModel.wetCompounds)) {
                        "Escolha SOFT, MEDIUM ou HARD no seletor de pneus antes de confirmar o BOX."
                    }
                    val tyre = TyreModel.compoundForWeather(weather, plannedTyre, (circuit?.laps ?: lap) - lap)
                    pit(s, tyre)
                    plans[s.p.driverId]?.let { it.tyre = tyre; it.activePlan = "MANUAL"; it.pendingFreePlan = null; it.weatherManualMode = true }
                }
                ManagerDecisionAction.SAVE_FUEL -> { s.fuelSavingAccepted = true; s.bypassCriticalOnce = true }
                ManagerDecisionAction.CHANGE_STRATEGY -> s.bypassCriticalOnce = true
                ManagerDecisionAction.EXTEND_STINT, ManagerDecisionAction.STAY_OUT -> s.bypassCriticalOnce = true
                // Legacy pace actions cannot override the automatic driver policy.
                ManagerDecisionAction.RESTART_ATTACK, ManagerDecisionAction.RESTART_BALANCED,
                ManagerDecisionAction.RESTART_DEFENSE -> s.bypassCriticalOnce = true
                ManagerDecisionAction.RESTART_PLAN_A, ManagerDecisionAction.RESTART_PLAN_B, ManagerDecisionAction.RESTART_PLAN_C, ManagerDecisionAction.RESTART_PLAN_D -> Unit
                ManagerDecisionAction.CHANGE_TYRE_SOFT -> { pit(s, Tyre.SOFT); plans[s.p.driverId]?.let { it.tyre = Tyre.SOFT; it.activePlan = "MANUAL"; it.pendingFreePlan = null; it.weatherManualMode = true } }
                ManagerDecisionAction.CHANGE_TYRE_MEDIUM -> { pit(s, Tyre.MEDIUM); plans[s.p.driverId]?.let { it.tyre = Tyre.MEDIUM; it.activePlan = "MANUAL"; it.pendingFreePlan = null; it.weatherManualMode = true } }
                ManagerDecisionAction.CHANGE_TYRE_HARD -> { pit(s, Tyre.HARD); plans[s.p.driverId]?.let { it.tyre = Tyre.HARD; it.activePlan = "MANUAL"; it.pendingFreePlan = null; it.weatherManualMode = true } }
                ManagerDecisionAction.CHANGE_TYRE_INTERMEDIATE -> { pit(s, Tyre.INTERMEDIATE); plans[s.p.driverId]?.let { it.tyre = Tyre.INTERMEDIATE; it.activePlan = "MANUAL"; it.pendingFreePlan = null; it.weatherManualMode = true } }
                ManagerDecisionAction.CHANGE_TYRE_WET -> { pit(s, Tyre.WET); plans[s.p.driverId]?.let { it.tyre = Tyre.WET; it.activePlan = "MANUAL"; it.pendingFreePlan = null; it.weatherManualMode = true } }
            }
        }
        completePendingDecision(d.request.type == ManagerDecisionType.RED_FLAG)
        return snapshot("RACE", emptyList())
    }

    /**
     * V342: runs every programmed race lap immediately through advance(), including
     * pit strategy, weather, incidents, reliability, neutralisations and classification.
     * Manager prompts are auto-resolved only for this headless/instant path; the normal
     * interactive choose() flow remains unchanged. No lap is skipped or synthesized.
     */
    fun simulateRaceInstantly(): SessionSnapshot {
        require(qualifyingComplete()) { "Conclua a qualificação antes da corrida" }
        require(!finished) { "A corrida já foi concluída" }
        var current = snapshot("RACE", emptyList())
        var guard = 0
        while (!current.completed && ++guard <= 200_000) {
            val pendingDecision = current.decision
            if (pendingDecision != null) {
                current = choose(instantActionFor(pendingDecision.request.type))
            } else {
                current = advance()
            }
        }
        check(current.completed && finished) { "A simulação instantânea não concluiu a corrida dentro do limite de segurança" }
        val finalResult = result()
        check(finalResult.classification.isNotEmpty()) { "A corrida terminou sem classificação" }
        check(finalResult.classification.all { it.laps <= (circuit?.laps ?: 0) }) { "A classificação contém voltas acima da distância programada" }
        return current
    }

    private fun instantActionFor(type: ManagerDecisionType): ManagerDecisionAction = when (type) {
        ManagerDecisionType.SAFETY_CAR, ManagerDecisionType.VSC -> ManagerDecisionAction.STAY_OUT
        ManagerDecisionType.RED_FLAG -> ManagerDecisionAction.RESTART_PLAN_A
        ManagerDecisionType.FUEL_CRITICAL -> ManagerDecisionAction.STAY_OUT
        ManagerDecisionType.TYRE_CRITICAL -> ManagerDecisionAction.EXTEND_STINT
        ManagerDecisionType.WEATHER_CHANGE -> when (weather) {
            Weather.LIGHT_RAIN, Weather.MEDIUM_RAIN -> ManagerDecisionAction.CHANGE_TYRE_INTERMEDIATE
            Weather.HEAVY_RAIN -> ManagerDecisionAction.CHANGE_TYRE_WET
            // A simulação sem interface não pode abrir o seletor; MEDIUM é o fallback neutro.
            Weather.DRY, Weather.CLOUDY -> ManagerDecisionAction.CHANGE_TYRE_MEDIUM
        }
        ManagerDecisionType.MECHANICAL_ALERT -> ManagerDecisionAction.CHANGE_STRATEGY
    }

    fun chooseRedFlag(tyre: Tyre): SessionSnapshot {
        val d = pending ?: error("Nenhuma decisão pendente")
        require(d.request.type == ManagerDecisionType.RED_FLAG)
        applyRedFlagChoice(d, tyre)
        completePendingDecision(true)
        return snapshot("RACE", emptyList())
    }

    /** Legacy signature retained for compatibility; the supplied posture is ignored. */
    @Suppress("UNUSED_PARAMETER")
    @Deprecated("A postura é sempre decidida automaticamente pelo piloto")
    fun chooseRedFlag(tyre: Tyre, posture: DriverPosture): SessionSnapshot = chooseRedFlag(tyre)

    private fun applyRedFlagChoice(d: Decision, tyre: Tyre) {
        val s = states[d.request.driverId] ?: return
        s.tyre = tyre
        s.wear = 0
        s.wearExact = 0.0
        s.lastManualTyrePromptWear = -1
        s.stint = 0
        plans[s.p.driverId]?.let {
            // The tyre remains a manager choice; pace is recalculated automatically.
            it.tyre = tyre
            it.planStintIndex = 0
            it.activePlan = "MANUAL"
            it.pendingFreePlan = null
            it.weatherManualMode = true
        }
        events += LapEvent(lap, s.p.driverId, EventType.RED_FLAG_DEPLOYED, "Relargada: ${tyreLabel(tyre)} / postura automática")
    }

    private fun applyRedFlagPlanChoice(d: Decision, planId: String) {
        val s = states[d.request.driverId] ?: return
        val plan = plans[s.p.driverId] ?: return
        val selected = plan.tyrePlans[planId] ?: return
        val firstTyre = selected.sequence.firstOrNull() ?: s.tyre
        s.tyre = firstTyre
        s.wear = 0
        s.wearExact = 0.0
        s.lastManualTyrePromptWear = -1
        s.stint = 0
        plan.activePlan = planId
        plan.planStintIndex = 0
        plan.tyre = firstTyre
        plan.pendingFreePlan = null
        plan.weatherManualMode = false
        events += LapEvent(lap, s.p.driverId, EventType.RED_FLAG_DEPLOYED, "Relargada: Plano $planId — ${tyreLabel(firstTyre)}")
    }

    private fun prepareRedFlagRestartPlans(remainingLaps: Int) {
        val remaining = remainingLaps.coerceAtLeast(1)
        // Recalcula os quatro planos do zero para a distância que realmente falta.
        // Assim uma estratégia de 2 ou 3 paradas da corrida original não é carregada
        // para uma relargada com poucas voltas restantes.
        plans.forEach { (driverId, plan) ->
            val fresh = TyreModel.buildPlansForWeather(remaining, weather)
            val first = fresh["A"]?.sequence?.firstOrNull() ?: plan.tyre
            plan.tyrePlans = fresh
            plan.activePlan = "A"
            plan.planStintIndex = 0
            plan.pendingFreePlan = null
            plan.tyre = first
            plan.weatherManualMode = false
        }

        // Os carros da IA recalculam planos individuais para a distância restante.
        // A relargada não força o mesmo composto/roteiro para todo o grid.
        aiStrategies.clear()
        states.values.filterNot { it.dnf }.filter { !plans.containsKey(it.p.driverId) }.forEach { s ->
            val restartPlan = buildAiTyreStrategy(s, remaining, weather)
            aiStrategies[s.p.driverId] = AiStrategyState(restartPlan)
            s.tyre = restartPlan.sequence.firstOrNull() ?: s.tyre
            s.wear = 0
            s.wearExact = 0.0
            s.stint = 0
        }
    }

    private fun completePendingDecision(wasRedFlag: Boolean) {
        if (pendingDecisions.isNotEmpty()) {
            pending = pendingDecisions.removeAt(0)
            return
        }
        pending = null
        if (wasRedFlag) {
            // Nova largada: mantém a volta já percorrida, mas remove os gaps.
            // Combustível não é reabastecido pela bandeira vermelha.
            groupPeloton()
            events += LapEvent(lap, null, EventType.RED_FLAG_DEPLOYED, "RELARGADA — bandeira verde")
        }
    }

    private fun pauseForPlayers(message: String, type: ManagerDecisionType): Boolean {
        val teamDrivers = states.values
            .filter { plans.containsKey(it.p.driverId) && !it.dnf }
        return pauseForDrivers(teamDrivers, message, type)
    }

    /** Pause only the supplied player cars, preserving race order and avoiding prompts
     * for a teammate who has already moved to a dry compound. */
    private fun pauseForDrivers(drivers: List<S>, message: String, type: ManagerDecisionType): Boolean {
        val eligibleDrivers = drivers
            .filter { plans.containsKey(it.p.driverId) && !it.dnf }
            .distinctBy { it.p.driverId }
            .sortedWith(compareBy<S> { it.position }.thenBy { it.grid })
        if (eligibleDrivers.isEmpty()) return false
        pendingDecisions.clear()
        val decisions = eligibleDrivers.map { state ->
            Decision(
                ManagerDecisionRequest(lap, type, state.p.driverId, message, options(type)),
                state.p.driverName
            )
        }
        pending = decisions.first()
        pendingDecisions.addAll(decisions.drop(1))
        return true
    }

    private fun pauseForDriver(s: S, message: String, type: ManagerDecisionType): Boolean {
        pending = Decision(ManagerDecisionRequest(lap, type, s.p.driverId, message, options(type)), s.p.driverName)
        return true
    }

    private fun options(t: ManagerDecisionType) = when (t) {
        ManagerDecisionType.RED_FLAG -> listOf(ManagerDecisionAction.RESTART_PLAN_A, ManagerDecisionAction.RESTART_PLAN_B, ManagerDecisionAction.RESTART_PLAN_C, ManagerDecisionAction.RESTART_PLAN_D)
        ManagerDecisionType.FUEL_CRITICAL -> listOf(ManagerDecisionAction.STAY_OUT)
        ManagerDecisionType.TYRE_CRITICAL -> listOf(ManagerDecisionAction.BOX, ManagerDecisionAction.CHANGE_TYRE_HARD, ManagerDecisionAction.STAY_OUT)
        ManagerDecisionType.WEATHER_CHANGE -> listOf(ManagerDecisionAction.BOX, ManagerDecisionAction.STAY_OUT, ManagerDecisionAction.EXTEND_STINT)
        else -> listOf(ManagerDecisionAction.BOX, ManagerDecisionAction.STAY_OUT, ManagerDecisionAction.EXTEND_STINT)
    }

    private fun groupPeloton(resetLastLap: Boolean = true) {
        // Do not rewrite cumulative race times or place cars in artificial grid gaps.
        // Actual bunching is simulated on every Safety-Car lap by progressively reducing
        // the pace loss for drivers farther behind the leader. This only refreshes the
        // live order and disables DRS; a red-flag restart may also clear the last-lap display.
        val ordered = states.values.filterNot { it.dnf }
            .sortedWith(compareBy<S> { it.total }.thenBy { it.grid })
        ordered.forEachIndexed { index, car ->
            car.position = index + 1
            if (resetLastLap) car.last = 0L
            car.drsActive = false
        }
    }

    private fun gapBehindLeaderAtLapStart(driverId: Int): Long {
        val ownStartTotal = lapStartTotalsByDriver[driverId] ?: return 0L
        val leaderStartTotal = lapStartTotalsByDriver.entries
            .filter { (id, _) -> states[id]?.dnf == false }
            .minOfOrNull { it.value } ?: return 0L
        return (ownStartTotal - leaderStartTotal).coerceAtLeast(0L)
    }

    private fun pit(s: S, tyre: Tyre) {
        s.stops++
        s.stint = 0
        s.tyre = tyre
        s.wear = 0
        s.wearExact = 0.0
        s.lastManualTyrePromptWear = -1
        // F1 não permite reabastecimento: o pit stop troca pneus e adiciona apenas
        // a perda de tempo. O combustível restante segue intacto.
        s.lastPitLossSec = 21
        s.total += 21_000L
        // V241: paradas normais para troca de pneus não geram card/evento visual.
        // Erros de pit stop continuam sendo registrados pelos eventos de incidente próprios.
    }


    /**
     * Dynamic AI race engineer: chooses a posture every lap from fuel projection,
     * tyre condition, race phase, weather, driver skill and nearby rivals.
     * No refuelling exists: the model protects enough fuel to reach the flag and
     * never calls pit() because of fuel alone.
     */
    private fun aiMode(s: S, weather: Weather): DriverStrategyMode {
        val c = circuit ?: return DriverStrategyMode.BALANCED
        val nearestRivalGapMs = states.values.asSequence()
            .filter { it.p.driverId != s.p.driverId && !it.dnf }
            .map { kotlin.math.abs(it.total - s.total) }
            .minOrNull()

        return AutomaticDriverPacePolicy.choose(
            totalLaps = c.laps,
            currentLap = lap,
            fuelKg = s.fuel,
            tyreWearPercent = s.wear,
            tyre = s.tyre,
            weather = weather,
            position = s.position,
            driverSpeed = s.p.driverSpeed,
            wetSkill = s.p.wetSkill,
            overtaking = s.p.overtaking,
            nearestRivalGapMs = nearestRivalGapMs
        )
    }

    private fun rainPenalty(p: RaceParticipant, tyre: Tyre, rain: Weather): Long =
        RaceWeatherPerformance.rainPenaltyMs(p, tyre, rain)

    // Legacy fixed-ms weather tyre deltas are intentionally retired.
    // TyreModel.performanceMultiplier() is the single source of truth and scales
    // with the GP average lap time.

    private fun componentLabel(component: com.f1teammanager.core.manager.CarComponent): String = when (component) {
        com.f1teammanager.core.manager.CarComponent.ENGINE -> "motor"
        com.f1teammanager.core.manager.CarComponent.CHASSIS -> "chassi"
        com.f1teammanager.core.manager.CarComponent.FRONT_WING -> "asa dianteira"
        com.f1teammanager.core.manager.CarComponent.REAR_WING -> "asa traseira"
        com.f1teammanager.core.manager.CarComponent.BRAKES -> "freios"
        com.f1teammanager.core.manager.CarComponent.ELECTRIC_POWER_UNIT -> "MGU-K - ERS"
    }

    private fun nextTyre(t: Tyre) = when (t) {
        Tyre.SOFT -> Tyre.MEDIUM
        Tyre.MEDIUM -> Tyre.HARD
        Tyre.HARD -> Tyre.MEDIUM
        Tyre.INTERMEDIATE -> Tyre.WET
        Tyre.WET -> Tyre.INTERMEDIATE
    }

    private fun finish(): SessionSnapshot {
        finished = true
        return snapshot("RESULT", emptyList())
    }

    private fun currentClassification(): List<FinishEntry> {
        // Live timing and final results must use the same canonical timing basis.
        // Sorting live entries by the cached `position` field can display an order
        // that disagrees with the actual completed laps and accumulated time,
        // especially after a pause, pit stop, neutralisation or late mechanical event.
        val running = states.values.filterNot { it.dnf }
            .sortedWith(compareByDescending<S> { it.laps }.thenBy { it.total }.thenBy { it.grid })
        val dnfs = states.values.filter { it.dnf }
            .sortedWith(compareByDescending<S> { it.laps }.thenBy { it.total }.thenBy { it.grid })
        return (running + dnfs).mapIndexed { i, s ->
            FinishEntry(i + 1, s.p.driverId, s.p.driverName, s.p.teamName, s.laps, s.total, if (s.dnf) "DNF • ${s.dnfReason}" else if (finished) "FINISHED" else "RUNNING", s.tyre, s.stops)
        }
    }

    private fun currentCarStatus(): List<RaceCarStatus> {
        val activeCircuit = circuit ?: return emptyList()
        return currentClassification().map { f ->
        val s = states.getValue(f.driverId)
        RaceCarStatus(
            f.driverId, f.driverName, f.position, s.tyre, s.wear, FuelModel.fuelPercent(s.fuel),
            s.stops, s.stint, s.last, s.ers.toInt().coerceIn(0, 100), s.drsActive,
            if (s.dnf) "DNF" else "OK", s.lastPitLossSec, s.ersActive,
            if (s.ersActive) PitwallPaceModel(random).ersGainMs(s.p, activeCircuit, s.ers).toInt() else 0, if (s.drsActive) PitwallPaceModel(random).drsGainMs(s.p, activeCircuit).toInt() else 0,
            s.componentReliability[com.f1teammanager.core.manager.CarComponent.ENGINE]?.toInt() ?: s.p.engineReliability,
            s.componentReliability[com.f1teammanager.core.manager.CarComponent.CHASSIS]?.toInt() ?: s.p.chassisReliability,
            s.componentReliability[com.f1teammanager.core.manager.CarComponent.FRONT_WING]?.toInt() ?: s.p.frontWingReliability,
            s.componentReliability[com.f1teammanager.core.manager.CarComponent.REAR_WING]?.toInt() ?: s.p.rearWingReliability,
            s.componentReliability[com.f1teammanager.core.manager.CarComponent.BRAKES]?.toInt() ?: s.p.brakesReliability,
            s.componentReliability[com.f1teammanager.core.manager.CarComponent.ELECTRIC_POWER_UNIT]?.toInt() ?: s.p.electricPowerUnitReliability,
            ReliabilityModel.average(s.componentReliability)
        )
        }
    }

    private fun currentAlerts(): List<DriverAlert> = states.values
        .filter { it.p.driverId in plans.keys && !it.dnf }
        .flatMap { s ->
            buildList {
                if (!s.fuelSavingAccepted && FuelModel.fuelPercent(s.fuel) <= 25) add(DriverAlert(lap, s.p.driverId, DriverAlertType.FUEL_LOW, "${s.p.driverName}: combustível em ${FuelModel.fuelPercent(s.fuel)}%", if (FuelModel.fuelPercent(s.fuel) <= 12) 3 else 1))
                val manualMode = plans[s.p.driverId]?.let { it.weatherManualMode || it.activePlan == "MANUAL" } == true
                val warningLimit = if (manualMode) TyreModel.MANUAL_TYRE_WARNING_WEAR_PERCENT else TyreModel.AUTOMATIC_TYRE_CHANGE_WEAR_PERCENT
                if (s.wear >= 65) add(DriverAlert(lap, s.p.driverId, if (s.wear >= warningLimit) DriverAlertType.TYRE_CRITICAL else DriverAlertType.TYRE_DEGRADING, "${s.p.driverName}: ${tyreLabel(s.tyre)} em ${s.wear}%${if (s.wear >= warningLimit) " • troca recomendada" else ""}", if (s.wear >= warningLimit) 3 else 2))
            }
        }
        .sortedByDescending { it.severity }

    private fun maskedQualifying(): QualifyingResult? {
        val g = grid ?: return null
        if (qualifyingStage >= 3) return g
        val phases = g.phases.mapIndexed { i, p ->
            when {
                i < qualifyingStage -> p
                i == qualifyingStage -> QualifyingPhase(p.name, liveQualifyingEntries(), emptyList())
                else -> QualifyingPhase(p.name, emptyList(), emptyList())
            }
        }
        return QualifyingResult(emptyList(), phases)
    }

    private fun qualifyingDurationMsForSnapshot(): Long =
        if (qualifyingStage >= 3) Q3_DURATION_MS else qualifyingDuration(qualifyingStage)

    private fun snapshot(phase: String, newEvents: List<LapEvent>): SessionSnapshot = SessionSnapshot(
        phase = phase,
        lap = lap,
        totalLaps = circuit?.laps ?: 0,
        grid = maskedQualifying(),
        classification = currentClassification(),
        carStatus = currentCarStatus(),
        events = newEvents,
        neutral = neutral,
        decision = pending,
        plans = plans.mapValues { it.value.copy() },
        alerts = currentAlerts(),
        completed = finished,
        weather = weather,
        qualifyingElapsedMs = qualifyingElapsedMs,
        qualifyingDurationMs = if (qualifyingStage >= 3) Q3_DURATION_MS else qualifyingDuration(qualifyingStage),
        qualifyingPhaseIndex = qualifyingPhaseIndex(),
        qualifyingRunning = qualifyingActive,
        qualifyingRemainingMs = (qualifyingDurationMsForSnapshot() - qualifyingElapsedMs).coerceAtLeast(0L),
        qualifyingReferenceLapMs = circuit?.baseLapTimeMs ?: 0L,
        qualifyingLapsByDriver = qualifyingLapCountByDriver.toMap(),
        qualifyingDiscardedLapsByDriver = qualifyingDiscardedLapCountByDriver.toMap(),
        qualifyingLapsByDriverByPhase = qualifyingLapCountByStage.map { it.toMap() },
        qualifyingDiscardedLapsByDriverByPhase = qualifyingDiscardedLapCountByStage.map { it.toMap() },
        qualifyingTyres = qualifyingTyres.toMap(),
        aiTyreStrategies = aiStrategies.mapValues { (_, state) ->
            state.plan.copy(sequence = state.plan.sequence.toList(), stintLaps = state.plan.stintLaps.toList())
        },
    )

    private fun tyreLabel(t: Tyre) = when (t) {
        Tyre.SOFT -> "SOFT"
        Tyre.MEDIUM -> "MEDIUM"
        Tyre.HARD -> "HARD"
        Tyre.INTERMEDIATE -> "INTERMEDIÁRIO"
        Tyre.WET -> "WET"
    }
}
