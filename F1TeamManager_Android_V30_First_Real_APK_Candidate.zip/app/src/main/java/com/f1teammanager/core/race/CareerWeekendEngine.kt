package com.f1teammanager.core.race

import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

data class RaceCarStatus(
    val driverId: Int,
    val driverName: String,
    val position: Int,
    val tyre: Tyre,
    val tyreWear: Int,
    val fuelPercent: Int,
    val pitStops: Int,
    val stintLaps: Int,
    val lastLapMs: Long,
    val ersPercent: Int,
    val drsActive: Boolean,
    val status: String,
    val lastPitLossSec: Int = 0,
    val ersActive: Boolean = false,
    val ersGainMs: Int = 0,
    val drsGainMs: Int = 0,
)

/** V33: automatic lap simulation with live classification, tyre/fuel consequences and manager control. */
class CareerWeekendEngine(private val seed: Int = 20261003) {
    data class DriverPlan(var mode: DriverStrategyMode = DriverStrategyMode.BALANCED, var tyre: Tyre = Tyre.MEDIUM)
    data class Decision(val request: ManagerDecisionRequest, val driverName: String)
    data class SessionSnapshot(
        val phase: String,
        val lap: Int,
        val totalLaps: Int,
        val grid: QualifyingResult?,
        val classification: List<FinishEntry>,
        val carStatus: List<RaceCarStatus>,
        val events: List<LapEvent>,
        val neutral: Neutralisation,
        val decision: Decision?,
        val plans: Map<Int, DriverPlan>,
        val alerts: List<DriverAlert>,
        val completed: Boolean,
        val weather: Weather,
    )

    private data class S(
        val p: RaceParticipant,
        val grid: Int,
        var total: Long = 0,
        var last: Long = 0,
        var best: Long = Long.MAX_VALUE,
        var laps: Int = 0,
        var stint: Int = 0,
        var stops: Int = 0,
        var dnf: Boolean = false,
        var wear: Int = 0,
        var tyre: Tyre = Tyre.MEDIUM,
        var fuel: Double = 100.0,
        var lastPos: Int = Int.MAX_VALUE,
        var position: Int = grid,
        var ers: Double = 100.0,
        var drsActive: Boolean = false,
        var ersActive: Boolean = false,
        var dnfReason: String = "",
        var bypassCriticalOnce: Boolean = false,
        var lastFuelAlertLap: Int = -99,
        var lastTyreAlertLap: Int = -99,
        var lastPitLossSec: Int = 0,
    )

    private val random = Random(seed)
    private var circuit: RaceCircuit? = null
    private var states = mutableMapOf<Int, S>()
    private var grid: QualifyingResult? = null
    private var lap = 0
    private var neutral = Neutralisation.GREEN
    private var neutralEnd = 0
    private var weather = Weather.DRY
    private var pending: Decision? = null
    private var events = mutableListOf<LapEvent>()
    private var finished = false
    private var fastestId: Int? = null
    private var fastest = Long.MAX_VALUE
    private var qualifyingStage = 0
    private val plans = mutableMapOf<Int, DriverPlan>()

    fun start(participants: List<RaceParticipant>, c: RaceCircuit, playerTeamId: Int): SessionSnapshot {
        require(participants.size == 80) { "O campeonato deve iniciar com 80 pilotos; recebido ${participants.size}" }
        circuit = c
        lap = 0
        neutral = Neutralisation.GREEN
        neutralEnd = 0
        weather = Weather.DRY
        pending = null
        events = mutableListOf()
        finished = false
        fastestId = null
        fastest = Long.MAX_VALUE
        qualifyingStage = 0
        grid = RaceWeekendEngine(seed).qualify(participants, c)
        states = participants.associate { p ->
            val g = grid!!.grid.first { it.driverId == p.driverId }.position
            p.driverId to S(p = p, grid = g)
        }.toMutableMap()
        plans.clear()
        participants.filter { it.teamId == playerTeamId }.forEach { plans[it.driverId] = DriverPlan() }
        return snapshot("QUALIFYING", emptyList())
    }

    fun simulateQualifyingPhase(): SessionSnapshot {
        require(!finished) { "Fim de semana concluído" }
        require(qualifyingStage < 3) { "Qualificação já concluída" }
        qualifyingStage++
        return snapshot("QUALIFYING", emptyList())
    }

    fun qualifyingComplete(): Boolean = qualifyingStage >= 3

    fun setPlan(driverId: Int, mode: DriverStrategyMode? = null, tyre: Tyre? = null): SessionSnapshot {
        val plan = plans[driverId] ?: error("Piloto não pertence à equipe do jogador")
        if (mode != null) plan.mode = mode
        if (tyre != null) plan.tyre = tyre
        states[driverId]?.tyre = plan.tyre
        return snapshot("RACE", emptyList())
    }

    fun snapshotForUi(): SessionSnapshot = snapshot(if (finished) "RESULT" else "RACE", emptyList())

    fun setStrategy(driverId: Int, mode: DriverStrategyMode): SessionSnapshot {
        val plan = plans[driverId] ?: error("Piloto não pertence à equipe do jogador")
        plan.mode = mode
        return snapshot("RACE", emptyList())
    }

    fun pitNow(driverId: Int, tyre: Tyre = plans[driverId]?.tyre ?: Tyre.MEDIUM): SessionSnapshot {
        val s = states[driverId] ?: error("Piloto inexistente")
        require(!s.dnf && !finished) { "Piloto não está em corrida" }
        pit(s, tyre)
        // The selected compound becomes the driver's active race plan too.
        // Without this, a later BOX decision could silently mount the old tyre again.
        plans[driverId]?.tyre = tyre
        pending = null
        return snapshot("RACE", emptyList())
    }

    fun advance(): SessionSnapshot {
        check(!finished) { "Fim de semana concluído" }
        check(pending == null) { "Resolva a decisão pendente" }
        val c = circuit ?: error("Circuito não iniciado")
        if (lap == 0) lap = 1 else lap++
        if (lap > c.laps) return finish()
        val before = events.size

        if (neutral != Neutralisation.GREEN && lap > neutralEnd) {
            events += LapEvent(lap, null, if (neutral == Neutralisation.SAFETY_CAR) EventType.SAFETY_CAR_ENDED else EventType.VSC_ENDED, "Neutralização encerrada")
            neutral = Neutralisation.GREEN
        }

        if (weather == Weather.DRY && lap >= 5 && random.nextDouble() < .08) weather = Weather.CLOUDY
        else if (weather == Weather.CLOUDY && lap >= 8 && random.nextDouble() < .10) weather = Weather.LIGHT_RAIN
        else if (weather == Weather.LIGHT_RAIN && random.nextDouble() < .08) weather = Weather.MEDIUM_RAIN
        else if (weather == Weather.MEDIUM_RAIN && random.nextDouble() < .07) weather = Weather.HEAVY_RAIN
        else if (weather == Weather.HEAVY_RAIN && random.nextDouble() < .05) weather = Weather.MEDIUM_RAIN

        if (neutral == Neutralisation.GREEN) {
            val r = random.nextDouble()
            if (r < .009 * c.safetyCarRisk) {
                neutral = Neutralisation.SAFETY_CAR
                neutralEnd = min(c.laps, lap + random.nextInt(2, 5))
                events += LapEvent(lap, null, EventType.SAFETY_CAR_DEPLOYED, "Safety Car")
                if (pauseForPlayer("Safety Car na pista. Box, manter ou estender?", ManagerDecisionType.SAFETY_CAR)) return snapshot("RACE", events.drop(before))
            } else if (r < .024 * c.safetyCarRisk) {
                neutral = Neutralisation.VSC
                neutralEnd = min(c.laps, lap + random.nextInt(1, 3))
                events += LapEvent(lap, null, EventType.VSC_DEPLOYED, "VSC")
                if (pauseForPlayer("VSC ativo. Aproveitar a janela estratégica?", ManagerDecisionType.VSC)) return snapshot("RACE", events.drop(before))
            } else if (r < .026 && lap > 5) {
                events += LapEvent(lap, null, EventType.RED_FLAG_DEPLOYED, "Bandeira vermelha")
                if (pauseForPlayer("Bandeira vermelha. Escolha pneus e postura para a relargada.", ManagerDecisionType.RED_FLAG)) return snapshot("RACE", events.drop(before))
            }
        }

        val active = states.values.filterNot { it.dnf }.sortedWith(compareBy<S> { it.total }.thenBy { it.grid })
        for (s in active) {
            val plan = plans[s.p.driverId]
            val aiMode = aiMode(s, weather)
            val aiWeatherTyre = when (weather) {
                Weather.HEAVY_RAIN -> Tyre.WET
                Weather.LIGHT_RAIN, Weather.MEDIUM_RAIN -> Tyre.INTERMEDIATE
                Weather.CLOUDY, Weather.DRY -> null
            }
            if (plan == null && !s.dnf && lap < c.laps) {
                if (aiWeatherTyre != null && s.tyre != aiWeatherTyre) pit(s, aiWeatherTyre)
                else if (s.wear >= 72 || s.fuel <= 18.0) pit(s, nextTyre(s.tyre))
            }
            if (plan != null && lap < c.laps && !s.bypassCriticalOnce) {
                if ((weather == Weather.LIGHT_RAIN || weather == Weather.MEDIUM_RAIN) && s.tyre != Tyre.INTERMEDIATE && lap != s.lastTyreAlertLap) {
                    s.lastTyreAlertLap = lap
                    events += LapEvent(lap, s.p.driverId, EventType.WEATHER_CHANGE, "Rádio: chuva fraca/média — intermediário recomendado")
                }
                if (weather == Weather.HEAVY_RAIN && s.tyre != Tyre.WET && lap != s.lastTyreAlertLap) {
                    s.lastTyreAlertLap = lap
                    events += LapEvent(lap, s.p.driverId, EventType.WEATHER_CHANGE, "Rádio: chuva forte — WET recomendado")
                }
                if (s.fuel <= 25.0 && lap != s.lastFuelAlertLap) {
                    s.lastFuelAlertLap = lap
                    events += LapEvent(lap, s.p.driverId, EventType.WEAR_WARNING, "Rádio: combustível baixo (${s.fuel.toInt()}%)")
                }
                if (s.wear >= 65 && lap != s.lastTyreAlertLap) {
                    s.lastTyreAlertLap = lap
                    events += LapEvent(lap, s.p.driverId, EventType.WEAR_WARNING, "Rádio: ${s.tyre} perdendo desempenho (${s.wear}%)")
                }
                if (s.fuel <= 12.0) {
                    if (pauseForDriver(s, "Combustível crítico: ${s.fuel.toInt()}%. Box agora ou correr o risco de ficar sem combustível.", ManagerDecisionType.FUEL_CRITICAL)) return snapshot("RACE", events.drop(before))
                }
                if (s.wear >= 85) {
                    if (pauseForDriver(s, "Pneu crítico: ${s.wear}%. O desempenho está despencando.", ManagerDecisionType.TYRE_CRITICAL)) return snapshot("RACE", events.drop(before))
                }
            }

            s.bypassCriticalOnce = false
            val mode = plan?.mode ?: aiMode
            // Estratégia do piloto e ERS são sistemas independentes.
            // Ataque/Equilibrado/Defesa alteram apenas ritmo + consumo de pneu/combustível.
            // ERS é a bateria elétrica e atua automaticamente para reduzir o tempo da volta.
            val ersAvailable = s.ers >= 12.0
            val ersBoost = if (ersAvailable) -180L else 0L
            s.ersActive = ersAvailable

            // DRS é automático e independente da estratégia. A regra é <= 1,000 s do carro à frente.
            // O ganho é sempre negativo em ms: reduz o tempo da volta.
            val orderedBeforeLap = states.values.filterNot { it.dnf }
                .sortedWith(compareBy<S> { it.total }.thenBy { it.grid })
            val idxBeforeLap = orderedBeforeLap.indexOfFirst { it.p.driverId == s.p.driverId }
            val aheadBeforeLap = if (idxBeforeLap > 0) orderedBeforeLap[idxBeforeLap - 1] else null
            val gapBeforeLap = aheadBeforeLap?.let { (s.total - it.total).coerceAtLeast(0L) }
            s.drsActive = aheadBeforeLap != null && gapBeforeLap != null && gapBeforeLap <= 1000L && lap > 2
            val drsBoost = if (s.drsActive) -280L else 0L
            val fuelPenalty = when {
                s.fuel < 15.0 -> (15.0 - s.fuel) * 65.0
                s.fuel < 30.0 -> (30.0 - s.fuel) * 16.0
                else -> 0.0
            }
            val lifePenalty = max(0, s.stint - s.tyre.targetLaps) * 75.0
            val tyrePenalty = s.wear * s.tyre.wearMultiplier * 22.0 + lifePenalty
            val pace = PitwallPaceModel(random)
            val remainingFuel = max(0.0, s.fuel)
            var lapMs = pace.lapTime(s.p, c, remainingFuel, s.stint, s.tyre, false)
            lapMs += (weatherTyreDelta(s.tyre, weather) + tyrePenalty + fuelPenalty).toLong()
            lapMs += when (mode) {
                DriverStrategyMode.ATTACK -> -120
                DriverStrategyMode.BALANCED -> 0
                DriverStrategyMode.DEFENSE -> 80
            }
            lapMs += ersBoost + drsBoost
            lapMs += when (neutral) {
                Neutralisation.SAFETY_CAR -> 9000
                Neutralisation.VSC -> 4500
                Neutralisation.GREEN -> 0
            }
            lapMs += when (weather) {
                Weather.DRY -> 0
                Weather.CLOUDY -> 120
                Weather.LIGHT_RAIN -> rainPenalty(s.p, s.tyre, Weather.LIGHT_RAIN)
                Weather.MEDIUM_RAIN -> rainPenalty(s.p, s.tyre, Weather.MEDIUM_RAIN)
                Weather.HEAVY_RAIN -> rainPenalty(s.p, s.tyre, Weather.HEAVY_RAIN)
            }

            s.total += lapMs.coerceAtLeast(45000)
            s.last = lapMs
            s.laps = lap
            s.stint++
            // Estratégia do piloto: ataque consome mais, equilibrado normal, defesa economiza.
            val baseFuelUse = (100.0 / c.laps) * when (mode) {
                DriverStrategyMode.ATTACK -> 1.10
                DriverStrategyMode.BALANCED -> 1.00
                DriverStrategyMode.DEFENSE -> 0.90
            }
            // Pneus consomem mais no sol e menos com pista molhada. WET quase não
            // consome em chuva forte, como definido na regra do jogo.
            val weatherFuelFactor = when (weather) {
                Weather.DRY -> 1.12
                Weather.CLOUDY -> 1.04
                Weather.LIGHT_RAIN -> 0.90
                Weather.MEDIUM_RAIN -> 0.78
                Weather.HEAVY_RAIN -> if (s.tyre == Tyre.WET) 0.45 else 0.65
            }
            val fuelUse = baseFuelUse * weatherFuelFactor
            s.fuel = max(0.0, s.fuel - fuelUse)
            // Desgaste dos pneus: seco consome mais; chuva prolonga a vida.
            // O composto define a diferença: Soft alto, Medium normal, Hard lento.
            // Intermediário/Wet têm comportamento próprio conforme a intensidade da chuva.
            val wearFactor = when (weather) {
                Weather.DRY -> when (s.tyre) {
                    Tyre.SOFT -> 1.35
                    Tyre.MEDIUM -> 1.10
                    Tyre.HARD -> 0.72
                    Tyre.INTERMEDIATE, Tyre.WET -> 1.35
                }
                Weather.CLOUDY -> when (s.tyre) {
                    Tyre.SOFT -> 1.15
                    Tyre.MEDIUM -> 1.00
                    Tyre.HARD -> 0.68
                    Tyre.INTERMEDIATE, Tyre.WET -> 1.20
                }
                Weather.LIGHT_RAIN, Weather.MEDIUM_RAIN -> when (s.tyre) {
                    Tyre.INTERMEDIATE -> 0.90
                    Tyre.WET -> 0.90
                    Tyre.SOFT -> 0.78
                    Tyre.MEDIUM -> 0.70
                    Tyre.HARD -> 0.62
                }
                Weather.HEAVY_RAIN -> when (s.tyre) {
                    Tyre.WET -> 0.35
                    Tyre.INTERMEDIATE -> 0.90
                    Tyre.SOFT -> 0.55
                    Tyre.MEDIUM -> 0.50
                    Tyre.HARD -> 0.45
                }
            }
            val strategyWearFactor = when (mode) {
                DriverStrategyMode.ATTACK -> 1.15
                DriverStrategyMode.BALANCED -> 1.00
                DriverStrategyMode.DEFENSE -> 0.85
            }
            val wearIncrement = kotlin.math.ceil(100.0 / s.tyre.targetLaps * wearFactor * strategyWearFactor).toInt().coerceAtLeast(1)
            s.wear = min(100, s.wear + wearIncrement)

            // ERS recarrega automaticamente quando não está em uso e descarrega quando entrega potência.
            val ersDelta = if (s.ersActive) -12.0 else 8.0
            s.ers = (s.ers + ersDelta).coerceIn(0.0, 100.0)

            if (lap < c.laps && s.fuel <= 0.0) {
                s.dnf = true
                s.dnfReason = "SEM COMBUSTÍVEL"
                events += LapEvent(lap, s.p.driverId, EventType.DNF, "${s.p.driverName} ficou sem combustível")
            } else if (s.wear >= 100) {
                s.dnf = true
                s.dnfReason = "PNEU DEGRADADO"
                events += LapEvent(lap, s.p.driverId, EventType.DNF, "${s.p.driverName} perdeu o pneu por degradação")
            }

            if (lapMs < s.best) {
                s.best = lapMs
                if (lapMs < fastest) {
                    fastest = lapMs
                    fastestId = s.p.driverId
                }
            }
        }

        val after = states.values.filterNot { it.dnf }.sortedWith(compareBy<S> { it.total }.thenBy { it.grid })
        after.forEachIndexed { i, s ->
            if (s.lastPos != Int.MAX_VALUE && s.lastPos > i + 1) {
                events += LapEvent(lap, s.p.driverId, EventType.OVERTAKE, "${s.p.driverName} ganhou ${s.lastPos - (i + 1)} posição(ões)")
            }
            s.lastPos = i + 1
        }
        val orderedNow = states.values.filterNot { it.dnf }.sortedWith(compareBy<S> { it.total }.thenBy { it.grid })
        orderedNow.forEachIndexed { index, car ->
            car.position = index + 1
            val ahead = orderedNow.getOrNull(index - 1)
            // DRS is automatic and only available when the car is <= 1.000s behind the car ahead.
            car.drsActive = car.position > 1 && ahead != null && (car.total - ahead.total) in 0L..1000L && lap > 2
        }
        if (lap >= c.laps) return finish()
        return snapshot("RACE", events.drop(before))
    }

    fun choose(action: ManagerDecisionAction): SessionSnapshot {
        val d = pending ?: error("Nenhuma decisão pendente")
        if (d.request.type == ManagerDecisionType.RED_FLAG) {
            val tyre = when (action) {
                ManagerDecisionAction.CHANGE_TYRE_SOFT, ManagerDecisionAction.RESTART_ATTACK -> Tyre.SOFT
                ManagerDecisionAction.CHANGE_TYRE_MEDIUM, ManagerDecisionAction.RESTART_BALANCED -> Tyre.MEDIUM
                ManagerDecisionAction.CHANGE_TYRE_HARD, ManagerDecisionAction.RESTART_DEFENSE -> Tyre.HARD
                else -> states[d.request.driverId]?.tyre ?: Tyre.MEDIUM
            }
            val posture = when (action) {
                ManagerDecisionAction.CHANGE_TYRE_SOFT, ManagerDecisionAction.RESTART_ATTACK -> DriverPosture.ATTACK
                ManagerDecisionAction.CHANGE_TYRE_HARD, ManagerDecisionAction.RESTART_DEFENSE -> DriverPosture.DEFENSE
                else -> DriverPosture.BALANCED
            }
            return chooseRedFlag(tyre, posture)
        }
        val s = states[d.request.driverId]
        if (s != null) when (action) {
            ManagerDecisionAction.BOX -> {
                val tyre = plans[s.p.driverId]?.tyre ?: nextTyre(s.tyre)
                pit(s, tyre)
                plans[s.p.driverId]?.tyre = tyre
            }
            ManagerDecisionAction.SAVE_FUEL -> { plans[s.p.driverId]?.mode = DriverStrategyMode.DEFENSE; s.bypassCriticalOnce = true }
            ManagerDecisionAction.CHANGE_STRATEGY -> { plans[s.p.driverId]?.mode = DriverStrategyMode.BALANCED; s.bypassCriticalOnce = true }
            ManagerDecisionAction.EXTEND_STINT, ManagerDecisionAction.STAY_OUT -> s.bypassCriticalOnce = true
            ManagerDecisionAction.RESTART_ATTACK -> plans[s.p.driverId]?.mode = DriverStrategyMode.ATTACK
            ManagerDecisionAction.RESTART_BALANCED -> plans[s.p.driverId]?.mode = DriverStrategyMode.BALANCED
            ManagerDecisionAction.RESTART_DEFENSE -> plans[s.p.driverId]?.mode = DriverStrategyMode.DEFENSE
            ManagerDecisionAction.CHANGE_TYRE_SOFT -> { pit(s, Tyre.SOFT); plans[s.p.driverId]?.tyre = Tyre.SOFT }
            ManagerDecisionAction.CHANGE_TYRE_MEDIUM -> { pit(s, Tyre.MEDIUM); plans[s.p.driverId]?.tyre = Tyre.MEDIUM }
            ManagerDecisionAction.CHANGE_TYRE_HARD -> { pit(s, Tyre.HARD); plans[s.p.driverId]?.tyre = Tyre.HARD }
            ManagerDecisionAction.CHANGE_TYRE_INTERMEDIATE -> { pit(s, Tyre.INTERMEDIATE); plans[s.p.driverId]?.tyre = Tyre.INTERMEDIATE }
            ManagerDecisionAction.CHANGE_TYRE_WET -> { pit(s, Tyre.WET); plans[s.p.driverId]?.tyre = Tyre.WET }
        }
        pending = null
        return snapshot("RACE", emptyList())
    }

    fun chooseRedFlag(tyre: Tyre, posture: DriverPosture): SessionSnapshot {
        val d = pending ?: error("Nenhuma decisão pendente")
        require(d.request.type == ManagerDecisionType.RED_FLAG)
        val s = states[d.request.driverId]
        if (s != null) {
            s.tyre = tyre
            s.wear = 0
            s.stint = 0
            plans[s.p.driverId]?.let { it.mode = posture.toMode(); it.tyre = tyre }
            events += LapEvent(lap, s.p.driverId, EventType.PIT_STOP, "Relargada: $tyre / $posture")
        }
        pending = null
        neutral = Neutralisation.GREEN
        return snapshot("RACE", emptyList())
    }

    fun result(): RaceResult {
        check(finished) { "Corrida ainda não terminou" }
        val classification = currentClassification()
        val base = RaceResult(
            classification,
            events,
            fastestId,
            weather,
            emptyMap(),
            events.count { it.type == EventType.SAFETY_CAR_DEPLOYED },
            events.count { it.type == EventType.VSC_DEPLOYED },
        )
        return base.copy(points = ChampionshipEngine.award(base))
    }

    private fun DriverPosture.toMode() = when (this) {
        DriverPosture.ATTACK -> DriverStrategyMode.ATTACK
        DriverPosture.BALANCED -> DriverStrategyMode.BALANCED
        DriverPosture.DEFENSE -> DriverStrategyMode.DEFENSE
    }

    private fun pauseForPlayer(message: String, type: ManagerDecisionType): Boolean {
        val s = states.values.filter { plans.containsKey(it.p.driverId) && !it.dnf }.minByOrNull { it.total } ?: return false
        pending = Decision(ManagerDecisionRequest(lap, type, s.p.driverId, message, options(type)), s.p.driverName)
        return true
    }

    private fun pauseForDriver(s: S, message: String, type: ManagerDecisionType): Boolean {
        pending = Decision(ManagerDecisionRequest(lap, type, s.p.driverId, message, options(type)), s.p.driverName)
        return true
    }

    private fun options(t: ManagerDecisionType) = when (t) {
        ManagerDecisionType.RED_FLAG -> listOf(ManagerDecisionAction.CHANGE_TYRE_SOFT, ManagerDecisionAction.CHANGE_TYRE_MEDIUM, ManagerDecisionAction.CHANGE_TYRE_HARD)
        ManagerDecisionType.FUEL_CRITICAL -> listOf(ManagerDecisionAction.SAVE_FUEL, ManagerDecisionAction.BOX, ManagerDecisionAction.STAY_OUT)
        ManagerDecisionType.TYRE_CRITICAL -> listOf(ManagerDecisionAction.BOX, ManagerDecisionAction.CHANGE_TYRE_HARD, ManagerDecisionAction.STAY_OUT)
        else -> listOf(ManagerDecisionAction.BOX, ManagerDecisionAction.STAY_OUT, ManagerDecisionAction.EXTEND_STINT)
    }

    private fun pit(s: S, tyre: Tyre) {
        s.stops++
        s.stint = 0
        s.tyre = tyre
        s.wear = 0
        s.lastPitLossSec = 21
        s.total += 21_000L
        events += LapEvent(lap, s.p.driverId, EventType.PIT_STOP, "Pit stop ${s.stops}: ${tyreLabel(tyre)} (+21s)")
    }


    private fun aiMode(s:S, weather:Weather): DriverStrategyMode {
        if (weather == Weather.HEAVY_RAIN) return when {
            s.p.wetSkill >= 90 -> DriverStrategyMode.ATTACK
            s.p.wetSkill >= 78 -> DriverStrategyMode.BALANCED
            else -> DriverStrategyMode.DEFENSE
        }
        if (s.fuel <= 22.0) return DriverStrategyMode.DEFENSE
        if (s.wear >= 78) return DriverStrategyMode.DEFENSE
        return when {
            s.position <= 6 && s.p.driverSpeed >= 88 -> DriverStrategyMode.ATTACK
            s.position in 7..20 && s.p.overtaking >= 88 -> DriverStrategyMode.ATTACK
            s.position >= 45 && s.p.driverSpeed >= 82 -> DriverStrategyMode.ATTACK
            else -> DriverStrategyMode.BALANCED
        }
    }

    private fun rainPenalty(p: RaceParticipant, tyre: Tyre, rain: Weather): Long {
        val required = when (rain) {
            Weather.LIGHT_RAIN -> 82
            Weather.MEDIUM_RAIN -> 90
            Weather.HEAVY_RAIN -> 100
            else -> 0
        }
        val tyreMismatch = max(0, required - tyre.wetSuitability)
        val wetSkill = (p.wetSkill * 0.55 + p.racecraft * 0.20 + p.consistency * 0.25)
        val driverPenalty = max(0.0, (required - wetSkill))
        return (tyreMismatch * 32.0 + driverPenalty * 24.0).toLong()
    }

    private fun weatherTyreDelta(tyre: Tyre, weather: Weather): Int = when (weather) {
        Weather.DRY -> when (tyre) {
            Tyre.SOFT -> -650      // mais velocidade
            Tyre.MEDIUM -> -250    // mais velocidade
            Tyre.HARD -> 0         // sem ganho
            Tyre.INTERMEDIATE, Tyre.WET -> 1500 // +++ms no seco
        }
        Weather.CLOUDY -> when (tyre) {
            Tyre.SOFT -> -450
            Tyre.MEDIUM -> -150
            Tyre.HARD -> 80
            Tyre.INTERMEDIATE, Tyre.WET -> 900
        }
        Weather.LIGHT_RAIN -> when (tyre) {
            Tyre.SOFT, Tyre.MEDIUM, Tyre.HARD -> 900
            Tyre.INTERMEDIATE -> -500  // melhor pneu
            Tyre.WET -> 180            // velocidade normal
        }
        Weather.MEDIUM_RAIN -> when (tyre) {
            Tyre.SOFT, Tyre.MEDIUM, Tyre.HARD -> 1100
            Tyre.INTERMEDIATE -> -550  // melhor pneu
            Tyre.WET -> 180            // velocidade normal
        }
        Weather.HEAVY_RAIN -> when (tyre) {
            Tyre.SOFT, Tyre.MEDIUM, Tyre.HARD -> 1500
            Tyre.INTERMEDIATE -> 0      // velocidade normal
            Tyre.WET -> -650            // mais velocidade
        }
    }

    private fun nextTyre(t: Tyre) = when (t) {
        Tyre.SOFT -> Tyre.MEDIUM
        Tyre.MEDIUM -> Tyre.HARD
        Tyre.HARD -> Tyre.MEDIUM
        Tyre.INTERMEDIATE -> Tyre.WET
        Tyre.WET -> Tyre.INTERMEDIATE
    }

    private fun finish(): SessionSnapshot {
        finished = true
        return snapshot("RESULT", emptyList())
    }

    private fun currentClassification(): List<FinishEntry> {
        val running = states.values.filterNot { it.dnf }.sortedWith(compareByDescending<S> { it.laps }.thenBy { it.total }.thenBy { it.grid })
        val dnfs = states.values.filter { it.dnf }.sortedWith(compareByDescending<S> { it.laps }.thenBy { it.total }.thenBy { it.grid })
        return (running + dnfs).mapIndexed { i, s ->
            FinishEntry(i + 1, s.p.driverId, s.p.driverName, s.p.teamName, s.laps, s.total, if (s.dnf) "DNF • ${s.dnfReason}" else if (finished) "FINISHED" else "RUNNING", s.tyre, s.stops)
        }
    }

    private fun currentCarStatus(): List<RaceCarStatus> = currentClassification().map { f ->
        val s = states.getValue(f.driverId)
        RaceCarStatus(
            f.driverId, f.driverName, f.position, s.tyre, s.wear, s.fuel.toInt().coerceIn(0, 100),
            s.stops, s.stint, s.last, s.ers.toInt().coerceIn(0, 100), s.drsActive,
            if (s.dnf) "DNF" else "OK", s.lastPitLossSec, s.ersActive,
            if (s.ersActive) 180 else 0, if (s.drsActive) 280 else 0
        )
    }

    private fun currentAlerts(): List<DriverAlert> = states.values
        .filter { it.p.driverId in plans.keys && !it.dnf }
        .flatMap { s ->
            buildList {
                if (s.fuel <= 25.0) add(DriverAlert(lap, s.p.driverId, DriverAlertType.FUEL_LOW, "${s.p.driverName}: combustível em ${s.fuel.toInt()}%", if (s.fuel <= 12.0) 3 else 1))
                if (s.wear >= 65) add(DriverAlert(lap, s.p.driverId, if (s.wear >= 85) DriverAlertType.TYRE_CRITICAL else DriverAlertType.TYRE_DEGRADING, "${s.p.driverName}: ${tyreLabel(s.tyre)} em ${s.wear}%", if (s.wear >= 85) 3 else 2))
            }
        }
        .sortedByDescending { it.severity }

    private fun maskedQualifying(): QualifyingResult? {
        val g = grid ?: return null
        if (qualifyingStage >= 3) return g
        val phases = g.phases.mapIndexed { i, p ->
            if (i < qualifyingStage) p else QualifyingPhase(p.name, emptyList(), emptyList())
        }
        return QualifyingResult(emptyList(), phases)
    }

    private fun snapshot(phase: String, newEvents: List<LapEvent>): SessionSnapshot = SessionSnapshot(
        phase = phase,
        lap = lap,
        totalLaps = circuit?.laps ?: 0,
        grid = maskedQualifying(),
        classification = currentClassification(),
        carStatus = currentCarStatus(),
        events = newEvents,
        neutral = neutral,
        decision = pending,
        plans = plans.mapValues { it.value.copy() },
        alerts = currentAlerts(),
        completed = finished,
        weather = weather,
    )

    private fun tyreLabel(t: Tyre) = when (t) {
        Tyre.SOFT -> "SOFT"
        Tyre.MEDIUM -> "MEDIUM"
        Tyre.HARD -> "HARD"
        Tyre.INTERMEDIATE -> "INTERMEDIÁRIO"
        Tyre.WET -> "WET"
    }
}
