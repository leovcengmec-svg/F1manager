package com.f1teammanager.core.season

/** Team-specific chassis catalog. UI must never assume Ferrari's SF-26 is universal. */
data class CarSpec(
    val teamId: Int,
    val model: String,
    val topSpeed: Int,
    val acceleration: Int,
    val lowSpeed: Int,
    val highSpeed: Int,
    val braking: Int,
    val consistency: Int
)

object CarCatalog {
    private val models = mapOf(
        1 to CarSpec(1, "SF-26", 91, 90, 89, 92, 90, 91),
        2 to CarSpec(2, "MCL40", 92, 92, 91, 90, 91, 92),
        3 to CarSpec(3, "FW48", 87, 88, 84, 87, 86, 86),
        4 to CarSpec(4, "W17", 94, 93, 92, 94, 93, 94),
        5 to CarSpec(5, "RB22", 93, 94, 95, 93, 94, 93),
        6 to CarSpec(6, "B195", 82, 81, 84, 83, 80, 82),
        7 to CarSpec(7, "R26", 84, 85, 86, 84, 83, 84),
        8 to CarSpec(8, "97T", 80, 82, 88, 79, 81, 80),
        9 to CarSpec(9, "E20", 81, 80, 84, 82, 80, 81),
        10 to CarSpec(10, "BT52", 86, 89, 78, 82, 83, 80),
        11 to CarSpec(11, "026", 78, 79, 82, 80, 77, 78),
        12 to CarSpec(12, "199", 79, 80, 83, 79, 78, 80),
        13 to CarSpec(13, "M191", 76, 77, 80, 77, 75, 77),
        14 to CarSpec(14, "STR14", 82, 83, 84, 81, 81, 82),
        15 to CarSpec(15, "C20", 80, 81, 82, 79, 79, 81),
        16 to CarSpec(16, "F1.08", 83, 84, 82, 84, 83, 82),
        17 to CarSpec(17, "C42", 81, 80, 82, 81, 80, 81),
        18 to CarSpec(18, "AMR26", 89, 88, 87, 90, 88, 89),
        19 to CarSpec(19, "VJM11", 77, 78, 80, 78, 77, 76),
        20 to CarSpec(20, "RP20", 80, 81, 82, 80, 79, 79),
        21 to CarSpec(21, "BGP001", 84, 86, 83, 85, 84, 84),
        22 to CarSpec(22, "TF109", 79, 80, 79, 81, 78, 80),
        23 to CarSpec(23, "RA106", 81, 82, 80, 82, 80, 81),
        24 to CarSpec(24, "R5", 76, 77, 78, 76, 75, 76),
        25 to CarSpec(25, "SF3", 78, 79, 81, 78, 77, 79),
        26 to CarSpec(26, "A23", 74, 76, 77, 75, 73, 75),
        27 to CarSpec(27, "AP04", 75, 76, 79, 75, 74, 75),
        28 to CarSpec(28, "007", 82, 82, 83, 82, 81, 82),
        29 to CarSpec(29, "T51", 72, 73, 76, 71, 70, 73),
        30 to CarSpec(30, "250F", 70, 70, 74, 69, 69, 71),
        31 to CarSpec(31, "F1.08", 82, 83, 81, 83, 82, 81),
        32 to CarSpec(32, "F1-26", 78, 80, 78, 79, 77, 78),
        33 to CarSpec(33, "Type 251", 69, 70, 72, 68, 67, 69),
        34 to CarSpec(34, "CT05", 77, 78, 79, 76, 75, 76),
        35 to CarSpec(35, "R26", 88, 87, 86, 89, 87, 88),
        36 to CarSpec(36, "SA07", 75, 76, 78, 75, 73, 75),
        37 to CarSpec(37, "A26", 80, 81, 82, 80, 79, 80),
        38 to CarSpec(38, "CS-26", 76, 77, 79, 76, 74, 76),
        39 to CarSpec(39, "I26", 75, 76, 78, 75, 73, 75),
        40 to CarSpec(40, "R26", 77, 78, 80, 77, 75, 77)
    )

    fun forTeam(teamId: Int): CarSpec = models[teamId] ?: error("Modelo de carro inexistente para equipe $teamId")
}
