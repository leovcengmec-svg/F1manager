package com.f1teammanager.core.manager

import kotlin.math.roundToInt

import com.f1teammanager.core.race.RaceParticipant
import com.f1teammanager.core.season.WorldDatabase

/**
 * Converts the persistent driver-market contracts into the actual race grid.
 * The market is the source of truth after V9; WorldDatabase supplies immutable
 * driver attributes and team base data.
 */
class DynamicGridEngine {
    data class GridDriver(
        val driverId: Int,
        val driverName: String,
        val teamId: Int,
        val teamName: String
    )

    fun validate(market: DriverMarketState): List<String> {
        val errors = mutableListOf<String>()
        val known = WorldDatabase.allDrivers.map { it.id }.toSet()
        val duplicates = market.contracts.groupBy { it.driverId }.filterValues { it.size > 1 }
        if (duplicates.isNotEmpty()) errors += "Pilotos duplicados: ${duplicates.keys}"
        market.contracts.filter { it.driverId !in known }.forEach { errors += "Piloto desconhecido: ${it.driverId}" }
        market.contracts.groupBy { it.teamId }.forEach { (team, list) ->
            if (team !in WorldDatabase.teams.map { it.id }) errors += "Equipe desconhecida: $team"
            if (list.size > 2) errors += "Equipe $team com ${list.size} pilotos"
        }
        if (market.contracts.size != 80) errors += "Grid possui ${market.contracts.size} pilotos; esperado 80"
        val free = market.freeAgents.toSet()
        val allTracked = market.contracts.map { it.driverId }.toSet() + free
        if (allTracked.size != 100) errors += "Mercado rastreia ${allTracked.size} pilotos; esperado 100"
        if (free.size != 20) errors += "Mercado possui ${free.size} pilotos fora do grid; esperado 20"
        if ((market.contracts.map { it.driverId }.toSet() intersect free).isNotEmpty()) errors += "Piloto aparece no grid e como livre"
        return errors
    }

    fun snapshot(market: DriverMarketState, driverOverrides: Map<Int, com.f1teammanager.core.season.DriverDefinition> = emptyMap()): List<GridDriver> {
        val errors = validate(market)
        require(errors.isEmpty()) { errors.joinToString("; ") }
        return market.contracts.sortedWith(compareBy<DriverDeal> { it.teamId }.thenBy { it.driverId }).map { deal ->
            val d = driverOverrides[deal.driverId] ?: WorldDatabase.allDrivers.first { it.id == deal.driverId }
            val t = WorldDatabase.teams.first { it.id == deal.teamId }
            GridDriver(d.id, d.name, t.id, t.name)
        }
    }

    fun participants(
        market: DriverMarketState,
        playerTeamId: Int,
        seasonRound: Int = 1,
        season: Int = 2026,
        elapsedWeeks: Int? = null,
        driverOverrides: Map<Int, com.f1teammanager.core.season.DriverDefinition> = emptyMap(),
        playerGarage: TeamGarage,
        facilities: TeamFacilitiesState = TeamFacilitiesState()
    ): List<RaceParticipant> {
        val errors = validate(market)
        require(errors.isEmpty()) { errors.joinToString("; ") }
        val slotByDriver = market.contracts.groupBy { it.teamId }
            .mapValues { (_, deals) -> deals.sortedBy { it.driverId }.mapIndexed { index, deal -> deal.driverId to index }.toMap() }
        return market.contracts.map { deal ->
            val d = driverOverrides[deal.driverId] ?: WorldDatabase.allDrivers.first { it.id == deal.driverId }
            val t = WorldDatabase.teams.first { it.id == deal.teamId }
            val player = playerTeamId == deal.teamId
            val driverSlot = slotByDriver[deal.teamId]?.get(deal.driverId) ?: 0
            val physical = if (player) {
                if (driverSlot == 0) playerGarage.car1 else playerGarage.car2
            } else null
            val aiState = if (player) null else AITeamDevelopmentEngine().simulateFinancial(
                t, (elapsedWeeks ?: (seasonRound - 1)).coerceAtLeast(0), season
            )
            val aiGarage = aiState?.garage
            val aiPhysical = if (!player) {
                if (driverSlot == 0) aiGarage!!.car1 else aiGarage!!.car2
            } else null
            val activeFacilities = if (player) facilities else (aiState?.facilities ?: FacilityEngine.initial(t.initialLevel))
            require(physical != null || !player) { "Motor de corrida exige garagem física para a equipe do jogador" }

            val source = physical ?: aiPhysical!!
            // Facilities influence the actual race-facing car, never the stored piece values.
            // Wind Tunnel affects only the aerodynamic contribution; Simulator is a small
            // global track-performance modifier. This keeps the physical garage as source
            // of truth while making the facilities part of the same race chain.
            val tunnel = FacilityEngine.windTunnelPerformanceMultiplier(activeFacilities)
            val simulator = FacilityEngine.simulatorPerformanceMultiplier(activeFacilities)
            val adjustedChassis = (source.chassis * tunnel * simulator).roundToInt().coerceIn(1,100)
            val adjustedFrontWing = (source.frontWing * tunnel * simulator).roundToInt().coerceIn(1,100)
            val adjustedRearWing = (source.rearWing * tunnel * simulator).roundToInt().coerceIn(1,100)
            val adjustedEngine = (source.engine * simulator).roundToInt().coerceIn(1,100)
            val adjustedBrakes = (source.brakes * simulator).roundToInt().coerceIn(1,100)
            val adjustedEpu = (source.electricPowerUnit * simulator).roundToInt().coerceIn(1,100)
            val componentReliabilities = CarComponent.values().associateWith { source.componentReliability(it).coerceIn(40,100) }
            val reliability = componentReliabilities.values.average().toInt().coerceIn(40,100)
            RaceParticipant(
                driverId=d.id, driverName=d.name, teamId=t.id, teamName=t.name,
                driverSpeed=d.speed, qualifying=d.qualifying, overtaking=d.overtaking,
                defense=d.defense, consistency=d.consistency,
                enginePerformance=adjustedEngine, chassisPerformance=adjustedChassis,
                tyreGrip=d.tyre, tyreWear=d.tyre, reliability=reliability, chassisWear=0, wetSkill=d.wet,
                frontWingPerformance=adjustedFrontWing,
                rearWingPerformance=adjustedRearWing,
                brakesPerformance=adjustedBrakes,
                electricPowerUnitPerformance=adjustedEpu,
                engineReliability=componentReliabilities.getValue(CarComponent.ENGINE),
                chassisReliability=componentReliabilities.getValue(CarComponent.CHASSIS),
                frontWingReliability=componentReliabilities.getValue(CarComponent.FRONT_WING),
                rearWingReliability=componentReliabilities.getValue(CarComponent.REAR_WING),
                brakesReliability=componentReliabilities.getValue(CarComponent.BRAKES),
                electricPowerUnitReliability=componentReliabilities.getValue(CarComponent.ELECTRIC_POWER_UNIT)
            )
        }
    }

}
