package com.f1teammanager.core.manager

import com.f1teammanager.core.race.RaceParticipant
import com.f1teammanager.core.season.WorldDatabase

/**
 * Converts the persistent driver-market contracts into the actual race grid.
 * The market is the source of truth after V9; WorldDatabase supplies immutable
 * driver attributes and team base data.
 */
class DynamicGridEngine {
    data class GridDriver(
        val driverId: Int,
        val driverName: String,
        val teamId: Int,
        val teamName: String
    )

    fun validate(market: DriverMarketState): List<String> {
        val errors = mutableListOf<String>()
        val known = WorldDatabase.drivers.map { it.id }.toSet()
        val duplicates = market.contracts.groupBy { it.driverId }.filterValues { it.size > 1 }
        if (duplicates.isNotEmpty()) errors += "Pilotos duplicados: ${duplicates.keys}"
        market.contracts.filter { it.driverId !in known }.forEach { errors += "Piloto desconhecido: ${it.driverId}" }
        market.contracts.groupBy { it.teamId }.forEach { (team, list) ->
            if (team !in WorldDatabase.teams.map { it.id }) errors += "Equipe desconhecida: $team"
            if (list.size > 2) errors += "Equipe $team com ${list.size} pilotos"
        }
        if (market.contracts.size != 80) errors += "Grid possui ${market.contracts.size} pilotos; esperado 80"
        val missing = known - market.contracts.map { it.driverId }.toSet()
        if (missing.isNotEmpty()) errors += "Pilotos sem contrato: $missing"
        return errors
    }

    fun snapshot(market: DriverMarketState): List<GridDriver> {
        val errors = validate(market)
        require(errors.isEmpty()) { errors.joinToString("; ") }
        return market.contracts.sortedWith(compareBy<DriverDeal> { it.teamId }.thenBy { it.driverId }).map { deal ->
            val d = WorldDatabase.drivers.first { it.id == deal.driverId }
            val t = WorldDatabase.teams.first { it.id == deal.teamId }
            GridDriver(d.id, d.name, t.id, t.name)
        }
    }

    fun participants(market: DriverMarketState, playerCar: TeamCarState? = null, playerTeamId: Int? = null, performanceModifier: Int = 0, seasonRound: Int = 1): List<RaceParticipant> {
        val errors = validate(market)
        require(errors.isEmpty()) { errors.joinToString("; ") }
        return market.contracts.map { deal ->
            val d = WorldDatabase.drivers.first { it.id == deal.driverId }
            val t = WorldDatabase.teams.first { it.id == deal.teamId }
            val player = playerCar != null && playerTeamId == deal.teamId
            val aiProgress = if (player) 0 else ((seasonRound - 1) * 0.65).toInt().coerceAtMost(18)
            val aiComponentBonus = (aiProgress + ((t.id * 3 + seasonRound) % 3)).coerceAtMost(14)
            val rawCarBase = if (player) {
                (
                    playerCar!!.chassis * .18 + playerCar.frontWing * .18 + playerCar.rearWing * .17 +
                    playerCar.engine * .18 + playerCar.brakes * .10 + playerCar.electricPowerUnit * .12 +
                    playerCar.reliability * .07 + performanceModifier * .20
                ).toInt()
            } else {
                // IA desenvolve os mesmos seis componentes ao longo da temporada.
                val componentProgress = aiProgress
                ((t.chassis + componentProgress) * .18 +
                    (t.frontWing + componentProgress) * .18 +
                    (t.rearWing + componentProgress) * .17 +
                    (t.engine + componentProgress) * .18 +
                    (t.brakes + componentProgress) * .10 +
                    (t.electricPowerUnit + componentProgress) * .12 +
                    (t.reliability + aiProgress/2) * .07).toInt() + aiComponentBonus
            }
            // V37: o piloto modula a qualidade efetiva do carro. Um piloto forte
            // consegue extrair mais de um carro ruim; um piloto fraco não extrai
            // todo o potencial de um carro excelente.
            val driverExtraction = ((d.speed - 70) * 0.22 + (d.consistency - 70) * 0.10).toInt()
            val carBase = (rawCarBase + driverExtraction).coerceIn(1,100)
            val engine = if (player) playerCar!!.engine else (t.engine + aiProgress).coerceIn(1,100)
            val reliability = if (player) (playerCar!!.reliability + performanceModifier / 3).coerceIn(1,100) else (t.reliability + aiProgress/2).coerceIn(1,100)
            RaceParticipant(
                driverId=d.id, driverName=d.name, teamId=t.id, teamName=t.name,
                driverSpeed=d.speed, qualifying=d.qualifying, overtaking=d.overtaking,
                defense=d.defense, consistency=d.consistency, carSpeed=carBase,
                enginePower=engine, tyreGrip=d.tyre, tyreWear=d.tyre,
                racecraft=d.experience.coerceIn(1,100), reliability=reliability, chassisWear=0, wetSkill=d.wet
            )
        }
    }
}
