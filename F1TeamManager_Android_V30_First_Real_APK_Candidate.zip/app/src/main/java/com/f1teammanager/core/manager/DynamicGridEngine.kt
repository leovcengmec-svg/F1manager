package com.f1teammanager.core.manager

import com.f1teammanager.core.race.RaceParticipant
import com.f1teammanager.core.season.WorldDatabase

/**
 * Converts the persistent driver-market contracts into the actual race grid.
 * The market is the source of truth after V9; WorldDatabase supplies immutable
 * driver attributes and team base data.
 */
class DynamicGridEngine {
    data class GridDriver(
        val driverId: Int,
        val driverName: String,
        val teamId: Int,
        val teamName: String
    )

    fun validate(market: DriverMarketState): List<String> {
        val errors = mutableListOf<String>()
        val known = WorldDatabase.drivers.map { it.id }.toSet()
        val duplicates = market.contracts.groupBy { it.driverId }.filterValues { it.size > 1 }
        if (duplicates.isNotEmpty()) errors += "Pilotos duplicados: ${duplicates.keys}"
        market.contracts.filter { it.driverId !in known }.forEach { errors += "Piloto desconhecido: ${it.driverId}" }
        market.contracts.groupBy { it.teamId }.forEach { (team, list) ->
            if (team !in WorldDatabase.teams.map { it.id }) errors += "Equipe desconhecida: $team"
            if (list.size > 2) errors += "Equipe $team com ${list.size} pilotos"
        }
        if (market.contracts.size != 80) errors += "Grid possui ${market.contracts.size} pilotos; esperado 80"
        val missing = known - market.contracts.map { it.driverId }.toSet()
        if (missing.isNotEmpty()) errors += "Pilotos sem contrato: $missing"
        return errors
    }

    fun snapshot(market: DriverMarketState): List<GridDriver> {
        val errors = validate(market)
        require(errors.isEmpty()) { errors.joinToString("; ") }
        return market.contracts.sortedWith(compareBy<DriverDeal> { it.teamId }.thenBy { it.driverId }).map { deal ->
            val d = WorldDatabase.drivers.first { it.id == deal.driverId }
            val t = WorldDatabase.teams.first { it.id == deal.teamId }
            GridDriver(d.id, d.name, t.id, t.name)
        }
    }

    fun participants(market: DriverMarketState, playerCar: TeamCarState? = null, playerTeamId: Int? = null, performanceModifier: Int = 0): List<RaceParticipant> {
        val errors = validate(market)
        require(errors.isEmpty()) { errors.joinToString("; ") }
        return market.contracts.map { deal ->
            val d = WorldDatabase.drivers.first { it.id == deal.driverId }
            val t = WorldDatabase.teams.first { it.id == deal.teamId }
            val player = playerCar != null && playerTeamId == deal.teamId
            val carBase = if (player) {
                (
                    playerCar!!.chassis * .18 + playerCar.frontWing * .18 + playerCar.rearWing * .17 +
                    playerCar.engine * .18 + playerCar.brakes * .10 + playerCar.electricPowerUnit * .12 +
                    playerCar.reliability * .07 + performanceModifier * .20
                ).toInt().coerceIn(1,100)
            } else t.baseCar
            val engine = if (player) playerCar!!.engine else t.engine
            val reliability = if (player) (playerCar!!.reliability + performanceModifier / 3).coerceIn(1,100) else t.reliability
            RaceParticipant(
                driverId=d.id, driverName=d.name, teamId=t.id, teamName=t.name,
                driverSpeed=d.speed, qualifying=d.qualifying, overtaking=d.overtaking,
                defense=d.defense, consistency=d.consistency, carSpeed=carBase,
                enginePower=engine, tyreGrip=d.tyre, tyreWear=d.tyre,
                racecraft=d.experience.coerceIn(1,100), reliability=reliability, chassisWear=0
            )
        }
    }
}
