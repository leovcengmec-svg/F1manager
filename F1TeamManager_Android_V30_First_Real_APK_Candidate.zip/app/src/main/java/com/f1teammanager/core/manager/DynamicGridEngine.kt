package com.f1teammanager.core.manager

import com.f1teammanager.core.race.RaceParticipant
import com.f1teammanager.core.season.WorldDatabase

/**
 * Converts the persistent driver-market contracts into the actual race grid.
 * The market is the source of truth after V9; WorldDatabase supplies immutable
 * driver attributes and team base data.
 */
class DynamicGridEngine {
    data class GridDriver(
        val driverId: Int,
        val driverName: String,
        val teamId: Int,
        val teamName: String
    )

    fun validate(market: DriverMarketState): List<String> {
        val errors = mutableListOf<String>()
        val known = WorldDatabase.allDrivers.map { it.id }.toSet()
        val duplicates = market.contracts.groupBy { it.driverId }.filterValues { it.size > 1 }
        if (duplicates.isNotEmpty()) errors += "Pilotos duplicados: ${duplicates.keys}"
        market.contracts.filter { it.driverId !in known }.forEach { errors += "Piloto desconhecido: ${it.driverId}" }
        market.contracts.groupBy { it.teamId }.forEach { (team, list) ->
            if (team !in WorldDatabase.teams.map { it.id }) errors += "Equipe desconhecida: $team"
            if (list.size > 2) errors += "Equipe $team com ${list.size} pilotos"
        }
        if (market.contracts.size != 80) errors += "Grid possui ${market.contracts.size} pilotos; esperado 80"
        val free = market.freeAgents.toSet()
        val allTracked = market.contracts.map { it.driverId }.toSet() + free
        if (allTracked.size != 100) errors += "Mercado rastreia ${allTracked.size} pilotos; esperado 100"
        if (free.size != 20) errors += "Mercado possui ${free.size} pilotos fora do grid; esperado 20"
        if ((market.contracts.map { it.driverId }.toSet() intersect free).isNotEmpty()) errors += "Piloto aparece no grid e como livre"
        return errors
    }

    fun snapshot(market: DriverMarketState, driverOverrides: Map<Int, com.f1teammanager.core.season.DriverDefinition> = emptyMap()): List<GridDriver> {
        val errors = validate(market)
        require(errors.isEmpty()) { errors.joinToString("; ") }
        return market.contracts.sortedWith(compareBy<DriverDeal> { it.teamId }.thenBy { it.driverId }).map { deal ->
            val d = driverOverrides[deal.driverId] ?: WorldDatabase.allDrivers.first { it.id == deal.driverId }
            val t = WorldDatabase.teams.first { it.id == deal.teamId }
            GridDriver(d.id, d.name, t.id, t.name)
        }
    }

    fun participants(market: DriverMarketState, playerCar: TeamCarState? = null, playerTeamId: Int? = null, performanceModifier: Int = 0, seasonRound: Int = 1, season: Int = 2026, elapsedWeeks: Int? = null, driverOverrides: Map<Int, com.f1teammanager.core.season.DriverDefinition> = emptyMap()): List<RaceParticipant> {
        val errors = validate(market)
        require(errors.isEmpty()) { errors.joinToString("; ") }
        return market.contracts.map { deal ->
            val d = driverOverrides[deal.driverId] ?: WorldDatabase.allDrivers.first { it.id == deal.driverId }
            val t = WorldDatabase.teams.first { it.id == deal.teamId }
            val player = playerCar != null && playerTeamId == deal.teamId
            val aiCar = if (player) null else AITeamDevelopmentEngine().simulate(t, (elapsedWeeks ?: (seasonRound - 1)).coerceAtLeast(0), season)
            val w = weightsForSeason(season)
            val rawCarBase = if (player) {
                (
                    playerCar!!.chassis * w.chassis + playerCar.frontWing * w.frontWing + playerCar.rearWing * w.rearWing +
                    playerCar.engine * w.engine + playerCar.brakes * w.brakes + playerCar.electricPowerUnit * w.electric +
                    playerCar.reliability * w.reliability + performanceModifier * .20
                ).toInt()
            } else {
                val c = aiCar!!
                (c.chassis * w.chassis + c.frontWing * w.frontWing + c.rearWing * w.rearWing +
                    c.engine * w.engine + c.brakes * w.brakes + c.electricPowerUnit * w.electric +
                    c.reliability * w.reliability).toInt()
            }
            // O carro entra no motor como qualidade própria da equipe.
            // A habilidade do piloto é aplicada separadamente pelo motor de corrida,
            // evitando que ela seja contabilizada duas vezes na mesma variável.
            val carBase = rawCarBase.coerceIn(1,100)
            val engine = if (player) playerCar!!.engine else aiCar!!.engine.coerceIn(1,100)
            val reliability = if (player) (playerCar!!.reliability + performanceModifier / 3).coerceIn(1,100) else aiCar!!.reliability.coerceIn(1,100)
            RaceParticipant(
                driverId=d.id, driverName=d.name, teamId=t.id, teamName=t.name,
                driverSpeed=d.speed, qualifying=d.qualifying, overtaking=d.overtaking,
                defense=d.defense, consistency=d.consistency, carSpeed=carBase,
                enginePower=engine, tyreGrip=d.tyre, tyreWear=d.tyre,
                racecraft=d.experience.coerceIn(1,100), reliability=reliability, chassisWear=0, wetSkill=d.wet
            )
        }
    }

    private data class Weights(val chassis:Double,val frontWing:Double,val rearWing:Double,val engine:Double,val brakes:Double,val electric:Double,val reliability:Double)

    private fun weightsForSeason(season:Int): Weights = when (CarDevelopmentEngine().regulationForSeason(season)) {
        CarRegulationFocus.AERODYNAMICS -> Weights(.20,.21,.20,.16,.08,.10,.05)
        CarRegulationFocus.POWER -> Weights(.15,.14,.13,.23,.08,.18,.09)
        CarRegulationFocus.CORNERING -> Weights(.22,.21,.20,.15,.12,.06,.04)
        CarRegulationFocus.EFFICIENCY -> Weights(.16,.15,.14,.17,.08,.18,.12)
        CarRegulationFocus.BALANCED -> Weights(.18,.18,.17,.18,.10,.12,.07)
    }

}
