package com.f1teammanager.core.manager

class FinanceEngine {
    fun applyQualifying(state:TeamManagerState, bestQualifyingPosition:Int):TeamManagerState {
        if (bestQualifyingPosition <= 0) return state
        val sponsors = state.sponsors.filter { it.active }.ifEmpty { listOf(state.sponsor).filter { it.active } }
        val bonus = sponsors.sumOf { s -> if (s.qualifyingTarget > 0 && bestQualifyingPosition <= s.qualifyingTarget) s.qualifyingBonus else 0L }
        return if (bonus > 0) state.copy(finance=state.finance.transact(bonus,"Bônus por meta de qualificação")) else state
    }

    fun applyRace(state:TeamManagerState, finishPosition:Int, teamPoints:Int, isDnf:Boolean):TeamManagerState {
        val sponsors = state.sponsors.filter { it.active }.ifEmpty { listOf(state.sponsor).filter { it.active } }
        val sponsorRace = sponsors.sumOf { it.racePayment }
        val pointsBonus = sponsors.sumOf { it.pointsBonus } * teamPoints
        val objectiveBonus = sponsors.sumOf { sponsor ->
            var bonus = 0L
            if (sponsor.raceTarget > 0 && !isDnf && finishPosition <= sponsor.raceTarget) bonus += sponsor.raceTargetBonus
            bonus
        }
        val prize=when {
            isDnf -> 250_000L
            finishPosition<=3 -> 2_500_000L
            finishPosition<=10 -> 1_500_000L
            finishPosition<=20 -> 900_000L
            else -> 500_000L
        }
        val raceCost=850_000L + if(isDnf) 450_000L else 0L
        val f=state.finance
            .transact(sponsorRace,"Patrocínios fixos GP")
            .transact(pointsBonus,"Bônus por pontos")
            .transact(objectiveBonus,"Bônus por meta de corrida")
            .transact(prize,"Premiação GP")
            .transact(-raceCost,"Custos GP")
        val nextSponsors = state.sponsors.mapNotNull { sponsor ->
            if (!sponsor.active) sponsor
            else {
                val remaining = sponsor.racesRemaining - 1
                if (remaining > 0) sponsor.copy(racesRemaining=remaining) else null
            }
        }.sortedBy { it.slot }
        val primary = nextSponsors.firstOrNull { it.slot == 1 }
            ?: SponsorContract("Patrocinador Base",0,0,0,1,0,1,0,0,0,0,false,0)
        return state.copy(finance=f, sponsors=nextSponsors, sponsor=primary)
    }
}
