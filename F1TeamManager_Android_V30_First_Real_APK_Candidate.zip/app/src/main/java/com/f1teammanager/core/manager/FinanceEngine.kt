package com.f1teammanager.core.manager

class FinanceEngine {
    /**
     * Assesses each calendar week exactly once. Unpaid maintenance remains a durable
     * obligation and is settled oldest-first when cash becomes available.
     */
    fun applyWeeklyFacilityMaintenance(state: TeamManagerState, season: Int, week: Int): TeamManagerState {
        if (week !in 1..60) return state
        val key = "$season:$week"
        var finance = state.finance
        if (key !in finance.facilityMaintenanceWeeks) {
            val amount = FacilityEngine.weeklyMaintenanceTotal(state.facilities)
            finance = finance.copy(
                facilityMaintenanceWeeks = finance.facilityMaintenanceWeeks + key,
                facilityMaintenanceOutstanding = if (amount > 0L) finance.facilityMaintenanceOutstanding + (key to amount) else finance.facilityMaintenanceOutstanding
            )
            if (amount > 0L) finance = finance.copy(transactions = (finance.transactions + "OBRIGAÇÃO MANUTENÇÃO: €$amount — semana $week — temporada $season").takeLast(100))
        }
        val ordered = finance.facilityMaintenanceOutstanding.keys.sortedWith(compareBy<String>({ it.substringBefore(':').toIntOrNull() ?: Int.MAX_VALUE }, { it.substringAfter(':').toIntOrNull() ?: Int.MAX_VALUE }))
        for (dueKey in ordered) {
            val amount = finance.facilityMaintenanceOutstanding[dueKey] ?: continue
            if (amount <= 0L) { finance = finance.copy(facilityMaintenanceOutstanding = finance.facilityMaintenanceOutstanding - dueKey); continue }
            if (finance.budget.coerceAtLeast(0L) < amount) continue
            finance = finance.transact(-amount, "Manutenção semanal das instalações — semana ${dueKey.substringAfter(':')} — temporada ${dueKey.substringBefore(':')}")
                .copy(facilityMaintenanceOutstanding = finance.facilityMaintenanceOutstanding - dueKey)
        }
        finance = finance.copy(budget = finance.budget.coerceAtLeast(0L))
        return state.copy(finance = finance)
    }
    /**
     * Salary is paid after each completed GP, never at season opening.
     * Integer remainder is settled on GP 30 so annual salary totals exactly match the contract.
     */
    fun applyDriverSalariesForRace(state: TeamManagerState, season: Int, round: Int): TeamManagerState {
        if (round !in 1..30) return state
        val ledgerKey = "$season:$round"
        if (ledgerKey in state.finance.salaryPaidRounds) return state
        val active = state.driverMarket.contracts.filter { it.teamId == state.playerTeamId && it.activeIn(season) }
        val total = active.sumOf { contract ->
            val annual = contract.salary.coerceAtLeast(0L)
            annual / 30L + if (round == 30) annual % 30L else 0L
        }
        var finance = SalaryLedger.apply(state.finance, season, round, total)
        finance = SignatureFeeAccounting.recognizeForRace(finance, season, round)
        return state.copy(finance=finance)
    }

    /** Register a signing fee for installment payments over GPs remaining after signature. */
    fun applySignatureFee(
        finance: TeamFinanceState, fee: Long, description: String,
        paymentSeason: Int = (Regex("20\\d{2}").findAll(description).lastOrNull()?.value?.toIntOrNull() ?: 2026),
        nextRound: Int = 1
    ): TeamFinanceState {
        if (fee <= 0L) return finance
        val remaining = (31 - nextRound).coerceIn(1, 30)
        return SignatureFeeAccounting.register(finance, fee, description, paymentSeason, nextRound, remaining)
    }

    fun applySeasonConstructorsPrize(state: TeamManagerState, season: Int, position: Int): TeamManagerState {
        if (season in state.finance.seasonPrizesPaid) return state
        val prize = SeasonPrizeEngine.prizeForPosition(position)
        val f = state.finance.transact(prize, "Premiação de construtores — $season — ${position}º lugar")
            .copy(seasonPrizesPaid = state.finance.seasonPrizesPaid + season)
        return state.copy(finance = f)
    }

    fun applyQualifying(state:TeamManagerState, bestQualifyingPosition:Int):TeamManagerState {
        if (bestQualifyingPosition <= 0) return state
        val sponsors = state.sponsors.filter { it.active && it.racesRemaining > 0 }.ifEmpty { listOf(state.sponsor).filter { it.active && it.racesRemaining > 0 } }
        val bonus = sponsors.sumOf { s -> if (s.qualifyingTarget > 0 && bestQualifyingPosition >= (if(s.qualifyingTargetMin>0) s.qualifyingTargetMin else 1) && bestQualifyingPosition <= (if(s.qualifyingTargetMax>0) s.qualifyingTargetMax else s.qualifyingTarget)) s.qualifyingBonus else 0L }
        return if (bonus > 0) state.copy(finance=state.finance.transact(bonus,"Bônus por meta de qualificação")) else state
    }

    fun applyRace(state:TeamManagerState, finishPosition:Int, teamPoints:Int, isDnf:Boolean, season:Int?=null, round:Int?=null):TeamManagerState {
        // A durable accounting marker makes a repeated GP callback a no-op after the
        // resulting finance state has been saved and restored. Keep the old signature
        // compatible for legacy callers that do not supply a GP identity.
        val settlementKey = if (season != null && round != null && round in 1..30) "GP_SETTLEMENT:$season:$round" else null
        if (settlementKey != null && settlementKey in state.finance.raceSettlementKeys) return state
        val sponsors = state.sponsors.filter { it.active && it.racesRemaining > 0 }.ifEmpty { listOf(state.sponsor).filter { it.active && it.racesRemaining > 0 } }
        val sponsorRace = sponsors.sumOf { it.racePayment }
        val pointsBonus = sponsors.sumOf { it.pointsBonus } * teamPoints
        val objectiveBonus = sponsors.sumOf { sponsor ->
            var bonus = 0L
            if (sponsor.raceTarget > 0 && !isDnf && finishPosition <= sponsor.raceTarget) bonus += sponsor.raceTargetBonus
            bonus
        }
        val prize=when {
            isDnf -> 250_000L
            finishPosition<=3 -> 2_500_000L
            finishPosition<=10 -> 1_500_000L
            finishPosition<=20 -> 900_000L
            else -> 500_000L
        }
        val raceCost=RaceOperatingCost.forTeam(state.playerTeamId) + if(isDnf) 450_000L else 0L
        val f=state.finance
            .transact(sponsorRace,"Patrocínios fixos GP")
            .transact(pointsBonus,"Bônus por pontos")
            .transact(objectiveBonus,"Bônus por meta de corrida")
            .transact(prize,"Premiação GP")
            .transact(-raceCost,"Custos GP")
        // Persist marker in the same immutable finance value returned to the caller.
        // It is written after the accounting changes and survives normal finance saves.
        val committedFinance = if (settlementKey != null) f.copy(
            transactions = (f.transactions + "+0:$settlementKey").takeLast(100),
            raceSettlementKeys = f.raceSettlementKeys + settlementKey
        ) else f
        val updatedSponsors = state.sponsors.mapNotNull { s ->
            if (!s.active) s
            else {
                val remaining = (s.racesRemaining - 1).coerceAtLeast(0)
                if (remaining == 0) null else s.copy(racesRemaining = remaining)
            }
        }
        val primary = updatedSponsors.firstOrNull { it.slot == 1 }
            ?: SponsorContract("Patrocinador Base",0,0,0,1,0,1,0,0,0,0,false)
        return state.copy(finance=committedFinance, sponsors=updatedSponsors, sponsor=primary)
    }
}
