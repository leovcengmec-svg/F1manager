package com.f1teammanager.core.manager

class FinanceEngine {
    /** Canonical cash credit used by player and AI for the same income event. */
    fun applyCashCreditFinance(finance: TeamFinanceState, amount: Long, description: String): TeamFinanceState =
        if (amount <= 0L) finance else finance.transact(amount, description)

    /** Canonical sponsor signing credit; both team types use the same description and accounting. */
    fun applySponsorshipUpfrontFinance(finance: TeamFinanceState, upfront: Long, sponsorName: String, slot: Int): TeamFinanceState =
        applyCashCreditFinance(finance, upfront, "Entrada patrocínio: $sponsorName (slot $slot)")

    /** Canonical annual-event budget adjustment; the recorded delta and resulting balance agree. */
    fun applyAnnualEventBudgetFinance(finance: TeamFinanceState, targetBudget: Long, description: String): TeamFinanceState {
        val safeBudget = targetBudget.coerceAtLeast(0L)
        val delta = safeBudget - finance.budget
        val adjusted = if (delta == 0L) finance.copy(budget = safeBudget) else finance.transact(delta, description)
        return adjusted.copy(budget = safeBudget)
    }
    /** Canonical cash-debit amount rule also used by the AI's deterministic development replay. */
    fun cashDebitBalance(balance: Long, requested: Long, allowPartial: Boolean = false): Long {
        if (requested <= 0L) return balance.coerceAtLeast(0L)
        val available = balance.coerceAtLeast(0L)
        if (!allowPartial && available < requested) return available
        return (available - requested.coerceAtMost(available)).coerceAtLeast(0L)
    }

    /** Shared cash debit rule used by player and AI for discretionary spending. */
    fun applyCashDebitFinance(finance: TeamFinanceState, requested: Long, description: String, allowPartial: Boolean = false): TeamFinanceState {
        if (requested <= 0L) return finance
        val available = finance.budget.coerceAtLeast(0L)
        if (!allowPartial && available < requested) return finance.copy(
            transactions = (finance.transactions + "BLOQUEADO/INSUFICIENTE: €$requested não pagos — $description").takeLast(20000)
        )
        val resultingBalance = cashDebitBalance(finance.budget, requested, allowPartial)
        val paid = available - resultingBalance
        var next = if (paid > 0L) finance.transact(-paid, description) else finance
        if (paid < requested) {
            next = next.copy(transactions = (next.transactions + "BLOQUEADO/INSUFICIENTE: €${requested-paid} não pagos — $description").takeLast(20000))
        }
        return next.copy(budget = resultingBalance)
    }

    /** Shared, idempotent end-of-season constructors prize accounting. */
    fun applyConstructorsPrizeFinance(finance: TeamFinanceState, season: Int, position: Int): TeamFinanceState {
        if (season in finance.seasonPrizesPaid) return finance
        val prize = SeasonPrizeEngine.prizeForPosition(position)
        return finance.transact(prize, "Premiação de construtores — $season — ${position}º lugar")
            .copy(seasonPrizesPaid = finance.seasonPrizesPaid + season)
    }
    /** Effective balance after all mandatory obligations not yet settled. */
    fun effectiveClosingBalance(finance: TeamFinanceState): Long {
        val unpaidSalaryLiability = finance.salaryOutstanding.values.sumOf { it.coerceAtLeast(0L) }
        val unpaidMaintenanceLiability = finance.facilityMaintenanceOutstanding.values.sumOf { it.coerceAtLeast(0L) }
        val totalLiabilities = unpaidSalaryLiability + unpaidMaintenanceLiability
        return finance.budget - totalLiabilities
    }

    fun requiresSeasonEndPenalty(finance: TeamFinanceState): Boolean = effectiveClosingBalance(finance) < 0L

    /** Canonical qualifying bonus rule shared by player and AI. */
    fun qualifyingBonus(sponsors: List<SponsorContract>, bestQualifyingPosition: Int): Long {
        if (bestQualifyingPosition <= 0) return 0L
        return sponsors.filter { it.active && it.racesRemaining > 0 }.sumOf { sponsor ->
            val minPosition = if (sponsor.qualifyingTargetMin > 0) sponsor.qualifyingTargetMin else 1
            val maxPosition = if (sponsor.qualifyingTargetMax > 0) sponsor.qualifyingTargetMax else sponsor.qualifyingTarget
            if (sponsor.qualifyingTarget > 0 && bestQualifyingPosition in minPosition..maxPosition) sponsor.qualifyingBonus else 0L
        }
    }

    /** Canonical race settlement for every team. Both player and AI call this exact function. */
    fun settleRaceFinance(
        finance: TeamFinanceState, teamId: Int, sponsors: List<SponsorContract>,
        finishPosition: Int, teamPoints: Int, isDnf: Boolean,
        season: Int, round: Int, bestQualifyingPosition: Int
    ): TeamFinanceState {
        if (round !in 1..30) return finance
        val settlementKey = "GP_SETTLEMENT:$season:$round"
        if (settlementKey in finance.raceSettlementKeys) return finance
        val active = sponsors.filter { it.active && it.racesRemaining > 0 }
        // Points earned no longer generate a sponsor bonus. Keep teamPoints in the
        // settlement signature for compatibility with existing player/AI callers.
        val fixedSponsorPayment = active.sumOf { it.racePayment }
        val objectiveBonus = active.sumOf { sponsor ->
            val minPosition = if (sponsor.raceTargetMin > 0) sponsor.raceTargetMin else 1
            val maxPosition = if (sponsor.raceTargetMax > 0) sponsor.raceTargetMax else sponsor.raceTarget
            if (!isDnf && sponsor.raceTarget > 0 && finishPosition in minPosition..maxPosition) sponsor.raceTargetBonus else 0L
        }
        val qualifying = qualifyingBonus(active, bestQualifyingPosition)
        val prize = when {
            isDnf -> 250_000L
            finishPosition <= 3 -> 2_500_000L
            finishPosition <= 10 -> 1_500_000L
            finishPosition <= 20 -> 900_000L
            else -> 500_000L
        }
        val operatingCost = RaceOperatingCost.forTeam(teamId) + if (isDnf) 450_000L else 0L
        val settled = finance
            .transact(fixedSponsorPayment, "Patrocínios fixos GP $round")
            .transact(objectiveBonus, "Bônus por meta de corrida GP $round")
            .transact(qualifying, "Bônus por meta de qualificação GP $round")
            .transact(prize, "Premiação GP $round")
            .transact(-operatingCost, if (isDnf) "Custos operacionais e penalidade DNF GP $round" else "Custos operacionais GP $round")
        return settled.copy(
            transactions = (settled.transactions + "+0:$settlementKey").takeLast(20000),
            raceSettlementKeys = settled.raceSettlementKeys + settlementKey
        )
    }

    /** Shared weekly merchandise credit, including durable idempotency. */
    fun applyWeeklyCommercialRevenueFinance(finance: TeamFinanceState, teamId: Int, season: Int, week: Int, level: Int): TeamFinanceState {
        if (week !in 1..60) return finance
        val key = "$season:$week"
        if (key in finance.commercialRevenueWeeks) return finance
        val amount = FacilityEngine.weeklyMerchandiseRevenue(teamId, season, week, level)
        val credited = if (amount > 0L) finance.transact(amount, "Vendas nas lojas da equipe — Centro Comercial nível $level — semana $week — temporada $season") else finance
        return credited.copy(commercialRevenueWeeks = credited.commercialRevenueWeeks + key)
    }

    /** Shared maintenance assessment and oldest-first debt settlement. */
    fun applyWeeklyFacilityMaintenanceFinance(finance: TeamFinanceState, facilities: TeamFacilitiesState, season: Int, week: Int): TeamFinanceState {
        if (week !in 1..60) return finance
        val key = "$season:$week"
        var next = finance
        if (key !in next.facilityMaintenanceWeeks) {
            val amount = FacilityEngine.weeklyMaintenanceTotal(facilities)
            next = next.copy(
                facilityMaintenanceWeeks = next.facilityMaintenanceWeeks + key,
                facilityMaintenanceOutstanding = if (amount > 0L) next.facilityMaintenanceOutstanding + (key to amount) else next.facilityMaintenanceOutstanding
            )
            if (amount > 0L) next = next.copy(transactions = (next.transactions + "OBRIGAÇÃO MANUTENÇÃO: €$amount — semana $week — temporada $season").takeLast(20000))
        }
        val ordered = next.facilityMaintenanceOutstanding.keys.sortedWith(compareBy<String>({ it.substringBefore(':').toIntOrNull() ?: Int.MAX_VALUE }, { it.substringAfter(':').toIntOrNull() ?: Int.MAX_VALUE }))
        for (dueKey in ordered) {
            val amount = next.facilityMaintenanceOutstanding[dueKey] ?: continue
            if (amount <= 0L) { next = next.copy(facilityMaintenanceOutstanding = next.facilityMaintenanceOutstanding - dueKey); continue }
            if (next.budget.coerceAtLeast(0L) < amount) continue
            next = next.transact(-amount, "Manutenção semanal das instalações — semana ${dueKey.substringAfter(':')} — temporada ${dueKey.substringBefore(':')}")
                .copy(facilityMaintenanceOutstanding = next.facilityMaintenanceOutstanding - dueKey)
        }
        return next.copy(budget = next.budget.coerceAtLeast(0L))
    }
    /**
     * Assesses each calendar week exactly once. Unpaid maintenance remains a durable
     * obligation and is settled oldest-first when cash becomes available.
     */
    fun applyWeeklyFacilityMaintenance(state: TeamManagerState, season: Int, week: Int): TeamManagerState {
        val finance = applyWeeklyFacilityMaintenanceFinance(state.finance, state.facilities, season, week)
        return if (finance == state.finance) state else state.copy(finance = finance)
    }
    /** Credits weekly merchandise sales exactly once for each season/week. */
    fun applyWeeklyCommercialRevenue(state: TeamManagerState, season: Int, week: Int): TeamManagerState {
        val level = state.facilities.level(FacilityType.MARKETING)
        val finance = applyWeeklyCommercialRevenueFinance(state.finance, state.playerTeamId, season, week, level)
        return if (finance == state.finance) state else state.copy(finance = finance)
    }

    /**
     * Salary is paid after each completed GP, never at season opening.
     * Integer remainder is settled on GP 30 so annual salary totals exactly match the contract.
     */
    fun applyDriverSalariesForRace(state: TeamManagerState, season: Int, round: Int): TeamManagerState {
        if (round !in 1..30) return state
        val ledgerKey = "$season:$round"
        if (ledgerKey in state.finance.salaryPaidRounds) return state
        val active = state.driverMarket.contracts.filter { it.teamId == state.playerTeamId && it.activeIn(season) }
        val total = active.sumOf { contract ->
            val annual = contract.salary.coerceAtLeast(0L)
            annual / 30L + if (round == 30) annual % 30L else 0L
        }
        var finance = SalaryLedger.apply(state.finance, season, round, total)
        finance = SignatureFeeAccounting.recognizeForRace(finance, season, round)
        return state.copy(finance=finance)
    }

    /** Register a signing fee for installment payments over GPs remaining after signature. */
    fun applySignatureFee(
        finance: TeamFinanceState, fee: Long, description: String,
        paymentSeason: Int = (Regex("20\\d{2}").findAll(description).lastOrNull()?.value?.toIntOrNull() ?: 2026),
        nextRound: Int = 1
    ): TeamFinanceState {
        if (fee <= 0L) return finance
        val remaining = (31 - nextRound).coerceIn(1, 30)
        return SignatureFeeAccounting.register(finance, fee, description, paymentSeason, nextRound, remaining)
    }

    fun applySeasonConstructorsPrize(state: TeamManagerState, season: Int, position: Int): TeamManagerState {
        val f = applyConstructorsPrizeFinance(state.finance, season, position)
        return if (f == state.finance) state else state.copy(finance = f)
    }

    fun applyQualifyingFinance(finance: TeamFinanceState, sponsors: List<SponsorContract>, bestQualifyingPosition: Int): TeamFinanceState {
        val bonus = qualifyingBonus(sponsors, bestQualifyingPosition)
        return if (bonus > 0L) finance.transact(bonus, "Bônus por meta de qualificação") else finance
    }

    fun applyQualifying(state: TeamManagerState, bestQualifyingPosition: Int): TeamManagerState {
        val sponsors = state.sponsors.filter { it.active && it.racesRemaining > 0 }
            .ifEmpty { listOf(state.sponsor).filter { it.active && it.racesRemaining > 0 } }
        val finance = applyQualifyingFinance(state.finance, sponsors, bestQualifyingPosition)
        return if (finance == state.finance) state else state.copy(finance = finance)
    }

    fun applyRace(state: TeamManagerState, finishPosition: Int, teamPoints: Int, isDnf: Boolean, season: Int? = null, round: Int? = null, bestQualifyingPosition: Int = 0): TeamManagerState {
        val settlementKey = if (season != null && round != null && round in 1..30) "GP_SETTLEMENT:$season:$round" else null
        if (settlementKey != null && settlementKey in state.finance.raceSettlementKeys) return state
        val sponsors = state.sponsors.filter { it.active && it.racesRemaining > 0 }
            .ifEmpty { listOf(state.sponsor).filter { it.active && it.racesRemaining > 0 } }
        val finance = if (season != null && round != null) {
            settleRaceFinance(state.finance, state.playerTeamId, sponsors, finishPosition, teamPoints, isDnf, season, round,
                bestQualifyingPosition = bestQualifyingPosition)
        } else {
            // Legacy calls without a GP identity still use the canonical settlement math,
            // but cannot be made idempotent without a season/round key.
            settleRaceWithoutMarker(state.finance, state.playerTeamId, sponsors, finishPosition, teamPoints, isDnf)
        }
        val updatedSponsors = state.sponsors.mapNotNull { sponsor ->
            if (!sponsor.active) sponsor else {
                val remaining = (sponsor.racesRemaining - 1).coerceAtLeast(0)
                if (remaining == 0) null else sponsor.copy(racesRemaining = remaining)
            }
        }
        val primary = updatedSponsors.firstOrNull { it.slot == 1 }
            ?: SponsorContract("Patrocinador Base", 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, false)
        return state.copy(finance = finance, sponsors = updatedSponsors, sponsor = primary)
    }

    private fun settleRaceWithoutMarker(
        finance: TeamFinanceState, teamId: Int, sponsors: List<SponsorContract>,
        finishPosition: Int, teamPoints: Int, isDnf: Boolean
    ): TeamFinanceState {
        val active = sponsors.filter { it.active && it.racesRemaining > 0 }
        val income = active.sumOf { it.racePayment } +
            active.sumOf { if (!isDnf && it.raceTarget > 0 && finishPosition <= it.raceTarget) it.raceTargetBonus else 0L }
        val prize = when { isDnf -> 250_000L; finishPosition <= 3 -> 2_500_000L; finishPosition <= 10 -> 1_500_000L; finishPosition <= 20 -> 900_000L; else -> 500_000L }
        val cost = RaceOperatingCost.forTeam(teamId) + if (isDnf) 450_000L else 0L
        return finance.transact(income, "Patrocínios e bônus GP").transact(prize, "Premiação GP").transact(-cost, "Custos GP")
    }
}
