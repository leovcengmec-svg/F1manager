package com.f1teammanager.core.manager

class FinanceEngine {
    /** Charges the two active driver salaries once at the start of a season. */
    fun applyAnnualDriverSalaries(state: TeamManagerState, season: Int): TeamManagerState {
        val active = state.driverMarket.contracts.filter { it.teamId == state.playerTeamId && it.activeIn(season) }
        if (active.isEmpty()) return state
        val total = active.sumOf { it.salary }
        if (total <= 0L) return state
        val f = state.finance.transact(-total, "Salários anuais dos pilotos — temporada $season")
        return state.copy(finance = f)
    }

    fun applySeasonConstructorsPrize(state: TeamManagerState, season: Int, position: Int): TeamManagerState {
        if (season in state.finance.seasonPrizesPaid) return state
        val prize = SeasonPrizeEngine.prizeForPosition(position)
        val f = state.finance.transact(prize, "Premiação de construtores — $season — ${position}º lugar")
            .copy(seasonPrizesPaid = state.finance.seasonPrizesPaid + season)
        return state.copy(finance = f)
    }

    fun applyQualifying(state:TeamManagerState, bestQualifyingPosition:Int):TeamManagerState {
        if (bestQualifyingPosition <= 0) return state
        val sponsors = state.sponsors.filter { it.active && it.racesRemaining > 0 }.ifEmpty { listOf(state.sponsor).filter { it.active && it.racesRemaining > 0 } }
        val bonus = sponsors.sumOf { s -> if (s.qualifyingTarget > 0 && bestQualifyingPosition <= s.qualifyingTarget) s.qualifyingBonus else 0L }
        return if (bonus > 0) state.copy(finance=state.finance.transact(bonus,"Bônus por meta de qualificação")) else state
    }

    fun applyRace(state:TeamManagerState, finishPosition:Int, teamPoints:Int, isDnf:Boolean):TeamManagerState {
        val sponsors = state.sponsors.filter { it.active && it.racesRemaining > 0 }.ifEmpty { listOf(state.sponsor).filter { it.active && it.racesRemaining > 0 } }
        val sponsorRace = sponsors.sumOf { it.racePayment }
        val pointsBonus = sponsors.sumOf { it.pointsBonus } * teamPoints
        val objectiveBonus = sponsors.sumOf { sponsor ->
            var bonus = 0L
            if (sponsor.raceTarget > 0 && !isDnf && finishPosition <= sponsor.raceTarget) bonus += sponsor.raceTargetBonus
            bonus
        }
        val prize=when {
            isDnf -> 250_000L
            finishPosition<=3 -> 2_500_000L
            finishPosition<=10 -> 1_500_000L
            finishPosition<=20 -> 900_000L
            else -> 500_000L
        }
        val raceCost=850_000L + if(isDnf) 450_000L else 0L
        val f=state.finance
            .transact(sponsorRace,"Patrocínios fixos GP")
            .transact(pointsBonus,"Bônus por pontos")
            .transact(objectiveBonus,"Bônus por meta de corrida")
            .transact(prize,"Premiação GP")
            .transact(-raceCost,"Custos GP")
        val updatedSponsors = state.sponsors.mapNotNull { s ->
            if (!s.active) s
            else {
                val remaining = (s.racesRemaining - 1).coerceAtLeast(0)
                if (remaining == 0) null else s.copy(racesRemaining = remaining)
            }
        }
        val primary = updatedSponsors.firstOrNull { it.slot == 1 }
            ?: SponsorContract("Patrocinador Base",0,0,0,1,0,1,0,0,0,0,false)
        return state.copy(finance=f, sponsors=updatedSponsors, sponsor=primary)
    }
}
