package com.f1teammanager.core.manager

class FinanceEngine {
    fun applyRace(state:TeamManagerState, finishPosition:Int, teamPoints:Int, isDnf:Boolean):TeamManagerState {
        val sponsor=state.sponsor.racePayment
        val prize=when {
            isDnf -> 250_000L
            finishPosition<=3 -> 2_500_000L
            finishPosition<=10 -> 1_500_000L
            finishPosition<=20 -> 900_000L
            else -> 500_000L
        }
        val raceCost=850_000L + if(isDnf) 450_000L else 0L
        val pointsBonus=teamPoints*15_000L
        val f=state.finance.transact(sponsor,"Patrocínio GP").transact(prize,"Premiação GP").transact(pointsBonus,"Bônus por pontos").transact(-raceCost,"Custos GP")
        return state.copy(finance=f)
    }
}
