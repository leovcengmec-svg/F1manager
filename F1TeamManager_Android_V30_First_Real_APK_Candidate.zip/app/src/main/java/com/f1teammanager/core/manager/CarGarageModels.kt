package com.f1teammanager.core.manager

import kotlin.math.roundToInt

/**
 * New garage model: a team owns two physical cars.  P&D will create projects;
 * the Factory will later manufacture physical PieceUnits that can be assigned
 * independently to Car 1 or Car 2.
 */
enum class GarageCarId { CAR_1, CAR_2 }

data class CarPiece(
    val pieceId: String,
    val component: CarComponent,
    val version: Int,
    val performance: Int,
    val reliability: Int = 100,
    val manufacturedWeek: Int = 0,
    /** Season tag prevents an uninstalled old part from counting as new annual development. */
    val manufacturedSeason: Int = 0
)

data class PhysicalCar(
    val id: GarageCarId,
    val engine: Int,
    val chassis: Int,
    val frontWing: Int,
    val rearWing: Int,
    val brakes: Int,
    val electricPowerUnit: Int,
    val reliability: Int = 100,
    val componentReliabilities: Map<CarComponent, Int> = emptyMap(),
    val installedPieces: Map<CarComponent, String> = emptyMap(),
    val installedPieceVersions: Map<CarComponent, Int> = emptyMap()
) {
    val overall: Int
        get() = (engine + chassis + frontWing + rearWing + brakes + electricPowerUnit + 3) / 6

    fun componentReliability(component: CarComponent): Int = (componentReliabilities[component] ?: reliability).coerceIn(1, 100)

    fun componentValue(component: CarComponent): Int = when (component) {
        CarComponent.ENGINE -> engine
        CarComponent.CHASSIS -> chassis
        CarComponent.FRONT_WING -> frontWing
        CarComponent.REAR_WING -> rearWing
        CarComponent.BRAKES -> brakes
        CarComponent.ELECTRIC_POWER_UNIT -> electricPowerUnit
    }
}

data class TeamGarage(
    val car1: PhysicalCar,
    val car2: PhysicalCar
) {
    val teamAverageOverall: Int get() = (car1.overall + car2.overall + 1) / 2

    fun car(id: GarageCarId): PhysicalCar = if (id == GarageCarId.CAR_1) car1 else car2

    /**
     * Installs a freshly manufactured physical piece directly on the selected car.
     * There is deliberately no intermediate stock/inventory state.
     */
    fun install(piece: CarPiece, target: GarageCarId): TeamGarage {
        val updated = when (target) {
            GarageCarId.CAR_1 -> installOn(car1, piece)
            GarageCarId.CAR_2 -> installOn(car2, piece)
        }
        return if (target == GarageCarId.CAR_1) copy(car1 = updated)
        else copy(car2 = updated)
    }

    private fun installOn(car: PhysicalCar, piece: CarPiece): PhysicalCar {
        val reliabilities = car.componentReliabilities + (piece.component to piece.reliability.coerceIn(1,100))
        val averageReliability = reliabilities.values.average().roundToInt().coerceIn(1,100)
        return when (piece.component) {
            CarComponent.ENGINE -> car.copy(engine = piece.performance, reliability = averageReliability, componentReliabilities = reliabilities, installedPieces = car.installedPieces + (piece.component to piece.pieceId), installedPieceVersions = car.installedPieceVersions + (piece.component to piece.version))
            CarComponent.CHASSIS -> car.copy(chassis = piece.performance, reliability = averageReliability, componentReliabilities = reliabilities, installedPieces = car.installedPieces + (piece.component to piece.pieceId), installedPieceVersions = car.installedPieceVersions + (piece.component to piece.version))
            CarComponent.FRONT_WING -> car.copy(frontWing = piece.performance, reliability = averageReliability, componentReliabilities = reliabilities, installedPieces = car.installedPieces + (piece.component to piece.pieceId), installedPieceVersions = car.installedPieceVersions + (piece.component to piece.version))
            CarComponent.REAR_WING -> car.copy(rearWing = piece.performance, reliability = averageReliability, componentReliabilities = reliabilities, installedPieces = car.installedPieces + (piece.component to piece.pieceId), installedPieceVersions = car.installedPieceVersions + (piece.component to piece.version))
            CarComponent.BRAKES -> car.copy(brakes = piece.performance, reliability = averageReliability, componentReliabilities = reliabilities, installedPieces = car.installedPieces + (piece.component to piece.pieceId), installedPieceVersions = car.installedPieceVersions + (piece.component to piece.version))
            CarComponent.ELECTRIC_POWER_UNIT -> car.copy(electricPowerUnit = piece.performance, reliability = averageReliability, componentReliabilities = reliabilities, installedPieces = car.installedPieces + (piece.component to piece.pieceId), installedPieceVersions = car.installedPieceVersions + (piece.component to piece.version))
        }
    }
}

object TeamGarageFactory {

    fun fromCarState(car: TeamCarState, teamId: Int, season: Int): TeamGarage {
        fun physical(id: GarageCarId): PhysicalCar {
            val rel = car.reliability.coerceIn(1, 100)
            val values = CarComponent.values().associateWith { rel }
            val performance = mapOf(
                CarComponent.ENGINE to car.engine,
                CarComponent.CHASSIS to car.chassis,
                CarComponent.FRONT_WING to car.frontWing,
                CarComponent.REAR_WING to car.rearWing,
                CarComponent.BRAKES to car.brakes,
                CarComponent.ELECTRIC_POWER_UNIT to car.electricPowerUnit
            )
            // Legacy saves without a physical-garage schema keep their already-earned
            // performance as an explicitly labelled migration baseline. New/blank cars
            // (all values zero) receive no synthetic installed pieces.
            val migratedPieces = performance.filterValues { it > 0 }.keys.associateWith { c ->
                "LEGACY-MIGRATED-${season}-${teamId}-${id.name}-${c.name}"
            }
            return PhysicalCar(
                id = id, engine = car.engine.coerceIn(0,100), chassis = car.chassis.coerceIn(0,100),
                frontWing = car.frontWing.coerceIn(0,100), rearWing = car.rearWing.coerceIn(0,100),
                brakes = car.brakes.coerceIn(0,100), electricPowerUnit = car.electricPowerUnit.coerceIn(0,100),
                reliability = rel, componentReliabilities = values,
                installedPieces = migratedPieces,
                installedPieceVersions = migratedPieces.keys.associateWith { 1 }
            )
        }
        return TeamGarage(physical(GarageCarId.CAR_1), physical(GarageCarId.CAR_2))
    }
    /**
     * Player and AI cars both start at their team's published base performance.
     * All six baseline components are represented as installed V0 hardware; V0 is a
     * piece version, not a performance value. The first research creates design V1,
     * and a manufactured V1 only changes the physical car when installed.
     */
    fun fromInitial(
        team: com.f1teammanager.core.season.TeamDefinition,
        playerCareer: Boolean = false
    ): TeamGarage {
        val opening = InitialTeamProfile.values(team)
        val openingValues = mapOf(
            CarComponent.ENGINE to opening.engine,
            CarComponent.CHASSIS to opening.chassis,
            CarComponent.FRONT_WING to opening.frontWing,
            CarComponent.REAR_WING to opening.rearWing,
            CarComponent.BRAKES to opening.brakes,
            CarComponent.ELECTRIC_POWER_UNIT to opening.electricPowerUnit
        )
        val performance = openingValues
        val initialReliability = InitialTeamProfile.reliability(team, opening.overall)
        fun car(id: GarageCarId): PhysicalCar {
            // Keep the physical dashboard aligned with the canonical opening profile's
            // reliability tiers; component reliability stays independent of performance.
            val values = CarComponent.values().associateWith { initialReliability }
            val installed = performance.keys.associateWith { component ->
                val owner = if (playerCareer) "INITIAL-PLAYER" else "INITIAL-AI"
                "$owner-V0-${team.id}-${id.name}-${component.name}"
            }
            return PhysicalCar(
                id = id,
                engine = performance.getValue(CarComponent.ENGINE),
                chassis = performance.getValue(CarComponent.CHASSIS),
                frontWing = performance.getValue(CarComponent.FRONT_WING),
                rearWing = performance.getValue(CarComponent.REAR_WING),
                brakes = performance.getValue(CarComponent.BRAKES),
                electricPowerUnit = performance.getValue(CarComponent.ELECTRIC_POWER_UNIT),
                reliability = initialReliability.coerceIn(1,100),
                componentReliabilities = values,
                installedPieces = installed,
                installedPieceVersions = installed.keys.associateWith { 0 }
            )
        }
        return TeamGarage(car1 = car(GarageCarId.CAR_1), car2 = car(GarageCarId.CAR_2))
    }
}
