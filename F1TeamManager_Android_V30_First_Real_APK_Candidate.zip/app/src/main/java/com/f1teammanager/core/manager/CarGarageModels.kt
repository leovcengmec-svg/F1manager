package com.f1teammanager.core.manager

import kotlin.math.roundToInt

/**
 * New garage model: a team owns two physical cars.  P&D will create projects;
 * the Factory will later manufacture physical PieceUnits that can be assigned
 * independently to Car 1 or Car 2.
 */
enum class GarageCarId { CAR_1, CAR_2 }

data class CarPiece(
    val pieceId: String,
    val component: CarComponent,
    val version: Int,
    val performance: Int,
    val reliability: Int = 100,
    val manufacturedWeek: Int = 0
)

data class PhysicalCar(
    val id: GarageCarId,
    val engine: Int,
    val chassis: Int,
    val frontWing: Int,
    val rearWing: Int,
    val brakes: Int,
    val electricPowerUnit: Int,
    val reliability: Int = 100,
    val componentReliabilities: Map<CarComponent, Int> = emptyMap(),
    val installedPieces: Map<CarComponent, String> = emptyMap(),
    val installedPieceVersions: Map<CarComponent, Int> = emptyMap()
) {
    val overall: Int
        get() = (engine + chassis + frontWing + rearWing + brakes + electricPowerUnit + 3) / 6

    fun componentReliability(component: CarComponent): Int = (componentReliabilities[component] ?: reliability).coerceIn(1, 100)

    fun componentValue(component: CarComponent): Int = when (component) {
        CarComponent.ENGINE -> engine
        CarComponent.CHASSIS -> chassis
        CarComponent.FRONT_WING -> frontWing
        CarComponent.REAR_WING -> rearWing
        CarComponent.BRAKES -> brakes
        CarComponent.ELECTRIC_POWER_UNIT -> electricPowerUnit
    }
}

data class TeamGarage(
    val car1: PhysicalCar,
    val car2: PhysicalCar
) {
    val teamAverageOverall: Int get() = (car1.overall + car2.overall + 1) / 2

    fun car(id: GarageCarId): PhysicalCar = if (id == GarageCarId.CAR_1) car1 else car2

    /**
     * Installs a freshly manufactured physical piece directly on the selected car.
     * There is deliberately no intermediate stock/inventory state.
     */
    fun install(piece: CarPiece, target: GarageCarId): TeamGarage {
        val updated = when (target) {
            GarageCarId.CAR_1 -> installOn(car1, piece)
            GarageCarId.CAR_2 -> installOn(car2, piece)
        }
        return if (target == GarageCarId.CAR_1) copy(car1 = updated)
        else copy(car2 = updated)
    }

    private fun installOn(car: PhysicalCar, piece: CarPiece): PhysicalCar {
        val reliabilities = car.componentReliabilities + (piece.component to piece.reliability.coerceIn(1,100))
        val averageReliability = reliabilities.values.average().roundToInt().coerceIn(1,100)
        return when (piece.component) {
            CarComponent.ENGINE -> car.copy(engine = piece.performance, reliability = averageReliability, componentReliabilities = reliabilities, installedPieces = car.installedPieces + (piece.component to piece.pieceId), installedPieceVersions = car.installedPieceVersions + (piece.component to piece.version))
            CarComponent.CHASSIS -> car.copy(chassis = piece.performance, reliability = averageReliability, componentReliabilities = reliabilities, installedPieces = car.installedPieces + (piece.component to piece.pieceId), installedPieceVersions = car.installedPieceVersions + (piece.component to piece.version))
            CarComponent.FRONT_WING -> car.copy(frontWing = piece.performance, reliability = averageReliability, componentReliabilities = reliabilities, installedPieces = car.installedPieces + (piece.component to piece.pieceId), installedPieceVersions = car.installedPieceVersions + (piece.component to piece.version))
            CarComponent.REAR_WING -> car.copy(rearWing = piece.performance, reliability = averageReliability, componentReliabilities = reliabilities, installedPieces = car.installedPieces + (piece.component to piece.pieceId), installedPieceVersions = car.installedPieceVersions + (piece.component to piece.version))
            CarComponent.BRAKES -> car.copy(brakes = piece.performance, reliability = averageReliability, componentReliabilities = reliabilities, installedPieces = car.installedPieces + (piece.component to piece.pieceId), installedPieceVersions = car.installedPieceVersions + (piece.component to piece.version))
            CarComponent.ELECTRIC_POWER_UNIT -> car.copy(electricPowerUnit = piece.performance, reliability = averageReliability, componentReliabilities = reliabilities, installedPieces = car.installedPieces + (piece.component to piece.pieceId), installedPieceVersions = car.installedPieceVersions + (piece.component to piece.version))
        }
    }
}

object TeamGarageFactory {

    fun fromCarState(car: TeamCarState, teamId: Int, season: Int): TeamGarage {
        fun physical(id: GarageCarId): PhysicalCar {
            val rel = car.reliability.coerceIn(1, 100)
            val values = CarComponent.values().associateWith { rel }
            return PhysicalCar(
                id = id, engine = car.engine, chassis = car.chassis,
                frontWing = car.frontWing, rearWing = car.rearWing,
                brakes = car.brakes, electricPowerUnit = car.electricPowerUnit,
                reliability = rel, componentReliabilities = values,
                installedPieces = CarComponent.values().associateWith { c -> "SEASON-${season}-${teamId}-${id.name}-${c.name}" },
                installedPieceVersions = CarComponent.values().associateWith { 1 }
            )
        }
        return TeamGarage(physical(GarageCarId.CAR_1), physical(GarageCarId.CAR_2))
    }
    fun fromInitial(team: com.f1teammanager.core.season.TeamDefinition): TeamGarage {
        val v = InitialTeamProfile.values(team)
        val (relMin, relMax) = when (team.initialLevel) {
            InitialTeamProfile.FORTE -> 75 to 85
            InitialTeamProfile.MEDIO -> 65 to 78
            else -> 55 to 70
        }
        fun reliability(slot: Int, carOffset: Int): Int {
            val span = relMax - relMin + 1
            return relMin + ((team.id * 29 + slot * 19 + slot * slot * 5 + carOffset * 11 + team.id * slot * 7) % span)
        }
        fun car(id: GarageCarId, offset: Int): PhysicalCar {
            val values = mapOf(
                CarComponent.ENGINE to reliability(1, offset),
                CarComponent.CHASSIS to reliability(2, offset),
                CarComponent.FRONT_WING to reliability(3, offset),
                CarComponent.REAR_WING to reliability(4, offset),
                CarComponent.BRAKES to reliability(5, offset),
                CarComponent.ELECTRIC_POWER_UNIT to reliability(6, offset)
            )
            val avg = values.values.average().roundToInt()
            return PhysicalCar(
                id = id,
                engine = (v.engine + offset).coerceIn(40, 100),
                chassis = (v.chassis + offset).coerceIn(40, 100),
                frontWing = (v.frontWing + offset).coerceIn(40, 100),
                rearWing = (v.rearWing + offset).coerceIn(40, 100),
                brakes = (v.brakes + offset).coerceIn(40, 100),
                electricPowerUnit = (v.electricPowerUnit + offset).coerceIn(40, 100),
                reliability = avg,
                componentReliabilities = values,
                installedPieces = CarComponent.values().associateWith { c -> "INIT-${team.id}-${id.name}-${c.name}" },
                installedPieceVersions = CarComponent.values().associateWith { 1 }
            )
        }
        // Car 2 starts very close to Car 1, but is intentionally not guaranteed
        // to be identical. Future manufactured pieces can make the difference grow.
        return TeamGarage(car1 = car(GarageCarId.CAR_1, 0), car2 = car(GarageCarId.CAR_2, 0))
    }
}
