package com.f1teammanager.core.manager

/**
 * Physical factory pipeline. A completed R&D design must be manufactured into
 * physical pieces before any car can receive it.
 */
data class FactoryOrder(
    val orderId: String,
    val designId: String,
    val component: CarComponent,
    val version: Int,
    val performance: Int,
    val reliability: Int,
    val quantity: Int,
    val remainingUnits: Int,
    val totalWeeks: Int,
    val remainingWeeks: Int,
    val costPerUnit: Long,
    val startedWeek: Int
)

data class TeamFactoryState(
    val activeOrders: List<FactoryOrder> = emptyList()
)

/** Official factory progression. Values are deliberately explicit so balance is
 * visible and testable rather than hidden behind generic percentages.
 *
 * level | parallel orders | max units/order | time multiplier | cost multiplier | stock cap
 */
object FactorySpecification {
    data class Level(
        val level: Int,
        val parallelOrders: Int,
        val maxUnitsPerOrder: Int,
        val timeMultiplier: Double,
        val costMultiplier: Double,
        val inventoryCapacity: Int
    )

    private val levels = listOf(
        Level(0, 1, 1, 1.00, 1.00, 30),
        Level(1, 1, 1, 0.95, 0.985, 40),
        Level(2, 1, 2, 0.90, 0.970, 50),
        Level(3, 2, 2, 0.90, 0.955, 60),
        Level(4, 2, 3, 0.85, 0.940, 70),
        Level(5, 2, 3, 0.85, 0.925, 80),
        Level(6, 3, 4, 0.80, 0.910, 90),
        Level(7, 3, 4, 0.80, 0.895, 100),
        Level(8, 4, 5, 0.75, 0.880, 110),
        Level(9, 5, 5, 0.70, 0.865, 130),
        Level(10, 6, 6, 0.65, 0.850, 150)
    )

    fun level(value: Int): Level = levels[value.coerceIn(0, 10)]
}
