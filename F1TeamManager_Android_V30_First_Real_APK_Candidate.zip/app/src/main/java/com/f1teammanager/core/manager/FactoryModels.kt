package com.f1teammanager.core.manager

/**
 * Physical factory pipeline. A completed R&D design must be manufactured into
 * physical pieces before any car can receive it.
 */
data class FactoryOrder(
    val orderId: String,
    val designId: String,
    val component: CarComponent,
    val version: Int,
    val performance: Int,
    val reliability: Int,
    val quantity: Int,
    val remainingUnits: Int,
    val totalWeeks: Int,
    val remainingWeeks: Int,
    val costPerUnit: Long,
    val startedWeek: Int
)

data class TeamFactoryState(
    val activeOrders: List<FactoryOrder> = emptyList(),
    /** Completed physical pieces awaiting the manager's explicit Car 1/Car 2 assignment.
     * This is NOT inventory/stock: the piece has completed manufacturing and exists only
     * as a pending installation decision until the manager assigns it to a physical car.
     */
    val pendingInstallations: List<CarPiece> = emptyList()
)

/** Official factory progression. Values are deliberately explicit so balance is
 * visible and testable rather than hidden behind generic percentages.
 *
 * level | parallel orders | max units/order | time multiplier | cost multiplier
 */
object FactorySpecification {
    data class Level(
        val level: Int,
        val parallelOrders: Int,
        val maxUnitsPerOrder: Int,
        val timeMultiplier: Double,
        val costMultiplier: Double
    )

    private val levels = listOf(
        Level(0, 1, 1, 1.00, 1.00),
        Level(1, 1, 1, 0.95, 0.985),
        Level(2, 1, 2, 0.90, 0.970),
        Level(3, 2, 2, 0.90, 0.955),
        Level(4, 2, 3, 0.85, 0.940),
        Level(5, 2, 3, 0.85, 0.925),
        Level(6, 3, 4, 0.80, 0.910),
        Level(7, 3, 4, 0.80, 0.895),
        Level(8, 4, 5, 0.75, 0.880),
        Level(9, 5, 5, 0.70, 0.865),
        Level(10, 6, 6, 0.65, 0.850)
    )

    fun level(value: Int): Level = levels[value.coerceIn(0, 10)]
}
