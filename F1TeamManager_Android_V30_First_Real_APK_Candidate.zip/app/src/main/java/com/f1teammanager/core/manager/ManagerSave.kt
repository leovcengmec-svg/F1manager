package com.f1teammanager.core.manager

import java.io.File

object ManagerSave {
    fun save(file:File,state:TeamManagerState){
        file.parentFile?.mkdirs(); val f=state.finance
        file.writeText(buildString {
            appendLine("F1TM_MANAGER_V8")
            appendLine("season=${state.season}"); appendLine("round=${state.round}"); appendLine("team=${state.playerTeamId}"); appendLine("budget=${f.budget}")
            appendLine("aero=${state.car.aerodynamics}"); appendLine("chassis=${state.car.chassis}"); appendLine("engine=${state.car.engine}"); appendLine("reliability=${state.car.reliability}")
            appendLine("frontWing=${state.car.frontWing}"); appendLine("rearWing=${state.car.rearWing}"); appendLine("brakes=${state.car.brakes}"); appendLine("electricPowerUnit=${state.car.electricPowerUnit}")
            appendLine("reputation=${state.manager.reputation}"); appendLine("experience=${state.manager.experience}")
            appendLine("facilities=${state.car.facilities.entries.joinToString(","){it.key.name+":"+it.value}}")
            appendLine("nextSeasonInvestment=${state.car.nextSeasonInvestment}")
            appendLine("nextSeasonFocus=${state.car.nextSeasonFocus.name}")
            appendLine("developmentKnowledge=${state.car.developmentKnowledge.entries.joinToString(","){it.key.name+":"+it.value}}")
            appendLine("seasonDevelopmentGain=${state.car.seasonDevelopmentGain}")
            state.car.activeProject?.let { appendLine("project=${it.component.name}|${it.remainingWeeks}|${it.totalWeeks}|${it.level}|${it.intensity.name}|${it.expectedGain}|${it.cost}") }
            appendLine("marketContracts=" + state.driverMarket.contracts.joinToString(";") { listOf(it.driverId,it.teamId,it.years,it.salary,it.marketValue,it.buyout,it.seasonSigned,it.role.name).joinToString(",") })
            appendLine("marketFree=" + state.driverMarket.freeAgents.joinToString(","))
            appendLine("marketScheduled=" + state.driverMarket.scheduled.joinToString(";") { listOf(it.driverId,it.fromTeamId,it.toTeamId,it.startSeason,it.years,it.salary,it.role.name,it.signedSeason,it.buyoutPaid,it.replaceDriverId).joinToString(",") })
            appendLine("marketRoles=" + state.driverMarket.rolePreferences.entries.joinToString(",") { "${it.key}:${it.value.name}" })
            appendLine("marketPending=" + state.driverMarket.pending.joinToString(";") { listOf(it.driverId,it.fromTeamId,it.toTeamId,it.years,it.salary,it.role.name,it.marketValue,it.buyout,it.interestScore,it.round,it.expiresAfterWeek,it.status.name,it.seasonTarget).joinToString(",") })
            appendLine("marketScouting=" + state.driverMarket.scouting.joinToString(";") { listOf(it.driverId,it.teamId,it.cost,it.createdWeek,it.expiresWeek,it.expectedSalary,it.marketValue,it.buyout,it.rolePreference.name,it.interest).joinToString(",") })
        })
    }
    fun load(file:File):TeamManagerState?=runCatching {
        val lines=file.readLines(); require(lines.firstOrNull()=="F1TM_MANAGER_V8" || lines.firstOrNull()=="F1TM_MANAGER_V7")
        val m=lines.filter{it.contains('=')}.associate{val p=it.split('=',limit=2);p[0] to p[1]}
        val raw=m["facilities"].orEmpty().split(',').mapNotNull { part -> part.split(':',limit=2).takeIf{it.size==2}?.let{it[0] to it[1].toIntOrNull()} }.toMap()
        val facilities=Facility.values().associateWith { raw[it.name] ?: 1 }
        val project=m["project"]?.split('|')?.let { parts ->
            if (parts.size >= 4) DevelopmentProject(
                CarComponent.valueOf(parts[0]), parts[1].toInt(), parts[2].toInt(), parts[3].toInt(),
                runCatching { DevelopmentIntensity.valueOf(parts.getOrNull(4) ?: "STANDARD") }.getOrDefault(DevelopmentIntensity.STANDARD),
                parts.getOrNull(5)?.toIntOrNull() ?: 4,
                parts.getOrNull(6)?.toLongOrNull() ?: 0L
            ) else null
        }
        val knowledge=m["developmentKnowledge"].orEmpty().split(',').mapNotNull { part -> part.split(':',limit=2).takeIf{it.size==2}?.let{runCatching{CarComponent.valueOf(it[0]) to it[1].toInt()}.getOrNull()} }.toMap()
        val car=TeamCarState(m["aero"]!!.toInt(),m["chassis"]!!.toInt(),m["engine"]!!.toInt(),m["reliability"]!!.toInt(),facilities,project,
            m["frontWing"]?.toIntOrNull() ?: m["aero"]!!.toInt(),m["rearWing"]?.toIntOrNull() ?: m["aero"]!!.toInt(),m["brakes"]?.toIntOrNull() ?: m["chassis"]!!.toInt(),m["electricPowerUnit"]?.toIntOrNull() ?: m["engine"]!!.toInt(),
            m["nextSeasonInvestment"]?.toLongOrNull() ?: 0L,
            runCatching { CarDevelopmentFocus.valueOf(m["nextSeasonFocus"] ?: "BALANCED") }.getOrDefault(CarDevelopmentFocus.BALANCED),
            knowledge,
            m["seasonDevelopmentGain"]?.toIntOrNull() ?: 0)
        val contracts=m["marketContracts"].orEmpty().split(';').filter{it.isNotBlank()}.mapNotNull { row ->
            val p=row.split(','); if(p.size<8) null else runCatching { DriverDeal(p[0].toInt(),p[1].toInt(),p[2].toInt(),p[3].toLong(),p[4].toLong(),p[5].toLong(),p[6].toInt(),DriverTeamRole.valueOf(p[7])) }.getOrNull()
        }
        val free=m["marketFree"].orEmpty().split(',').mapNotNull{it.toIntOrNull()}
        val scheduled=m["marketScheduled"].orEmpty().split(';').filter{it.isNotBlank()}.mapNotNull { row ->
            val p=row.split(','); if(p.size<9) null else runCatching { FutureDriverDeal(p[0].toInt(),p[1].toInt(),p[2].toInt(),p[3].toInt(),p[4].toInt(),p[5].toLong(),DriverTeamRole.valueOf(p[6]),p[7].toInt(),p[8].toLong(),p.getOrNull(9)?.toIntOrNull()) }.getOrNull()
        }
        val roles=m["marketRoles"].orEmpty().split(',').mapNotNull{part -> val p=part.split(':'); if(p.size==2) runCatching{p[0].toInt() to DriverRolePreference.valueOf(p[1])}.getOrNull() else null}.toMap()
        val pending=m["marketPending"].orEmpty().split(';').filter{it.isNotBlank()}.mapNotNull { row ->
            val p=row.split(','); if(p.size<13) null else runCatching { DriverOffer(p[0].toInt(),p[1].toInt(),p[2].toInt(),p[3].toInt(),p[4].toLong(),DriverTeamRole.valueOf(p[5]),p[6].toLong(),p[7].toLong(),p[8].toInt(),p[9].toInt(),p[10].toInt(),NegotiationStatus.valueOf(p[11]),p[12].toInt()) }.getOrNull()
        }
        val scouting=m["marketScouting"].orEmpty().split(';').filter{it.isNotBlank()}.mapNotNull { row ->
            val p=row.split(','); if(p.size<10) null else runCatching { ScoutingReport(p[0].toInt(),p[1].toInt(),p[2].toLong(),p[3].toInt(),p[4].toInt(),p[5].toLong(),p[6].toLong(),p[7].toLong(),DriverRolePreference.valueOf(p[8]),p[9].toInt()) }.getOrNull()
        }
        val market=if (m["marketContracts"].isNullOrBlank()) DriverMarketEngine().initialState(m["season"]!!.toInt()) else DriverMarketState(contracts=contracts,pending=pending,freeAgents=free,scheduled=scheduled,rolePreferences=roles,scouting=scouting).normalized()
        TeamManagerState(m["season"]!!.toInt(),m["round"]!!.toInt(),m["team"]!!.toInt(),car,TeamFinanceState(m["budget"]!!.toLong()),ManagerProfile(reputation=m["reputation"]!!.toInt(),experience=m["experience"]!!.toInt()),driverMarket=market)
    }.getOrNull()
}
