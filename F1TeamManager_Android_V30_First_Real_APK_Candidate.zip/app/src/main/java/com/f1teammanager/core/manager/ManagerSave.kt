package com.f1teammanager.core.manager

import java.io.File

object ManagerSave {
    fun save(file:File,state:TeamManagerState){
        file.parentFile?.mkdirs(); val f=state.finance
        file.writeText(buildString {
            appendLine("F1TM_MANAGER_V8")
            appendLine("season=${state.season}"); appendLine("round=${state.round}"); appendLine("team=${state.playerTeamId}"); appendLine("budget=${f.budget}")
            appendLine("aero=${state.car.aerodynamics}"); appendLine("chassis=${state.car.chassis}"); appendLine("engine=${state.car.engine}"); appendLine("reliability=${state.car.reliability}")
            appendLine("frontWing=${state.car.frontWing}"); appendLine("rearWing=${state.car.rearWing}"); appendLine("brakes=${state.car.brakes}"); appendLine("electricPowerUnit=${state.car.electricPowerUnit}")
            appendLine("reputation=${state.manager.reputation}"); appendLine("experience=${state.manager.experience}")
            appendLine("facilities=${state.car.facilities.entries.joinToString(","){it.key.name+":"+it.value}}")
            appendLine("nextSeasonInvestment=${state.car.nextSeasonInvestment}")
            appendLine("nextSeasonFocus=${state.car.nextSeasonFocus.name}")
            appendLine("developmentKnowledge=${state.car.developmentKnowledge.entries.joinToString(","){it.key.name+":"+it.value}}")
            appendLine("seasonDevelopmentGain=${state.car.seasonDevelopmentGain}")
            state.car.activeProject?.let { appendLine("project=${it.component.name}|${it.remainingWeeks}|${it.totalWeeks}|${it.level}|${it.intensity.name}|${it.expectedGain}|${it.cost}") }
        })
    }
    fun load(file:File):TeamManagerState?=runCatching {
        val lines=file.readLines(); require(lines.firstOrNull()=="F1TM_MANAGER_V8" || lines.firstOrNull()=="F1TM_MANAGER_V7")
        val m=lines.filter{it.contains('=')}.associate{val p=it.split('=',limit=2);p[0] to p[1]}
        val raw=m["facilities"].orEmpty().split(',').mapNotNull { part -> part.split(':',limit=2).takeIf{it.size==2}?.let{it[0] to it[1].toIntOrNull()} }.toMap()
        val facilities=Facility.values().associateWith { raw[it.name] ?: 1 }
        val project=m["project"]?.split('|')?.let { parts ->
            if (parts.size >= 4) DevelopmentProject(
                CarComponent.valueOf(parts[0]), parts[1].toInt(), parts[2].toInt(), parts[3].toInt(),
                runCatching { DevelopmentIntensity.valueOf(parts.getOrNull(4) ?: "STANDARD") }.getOrDefault(DevelopmentIntensity.STANDARD),
                parts.getOrNull(5)?.toIntOrNull() ?: 4,
                parts.getOrNull(6)?.toLongOrNull() ?: 0L
            ) else null
        }
        val knowledge=m["developmentKnowledge"].orEmpty().split(',').mapNotNull { part -> part.split(':',limit=2).takeIf{it.size==2}?.let{runCatching{CarComponent.valueOf(it[0]) to it[1].toInt()}.getOrNull()} }.toMap()
        val car=TeamCarState(m["aero"]!!.toInt(),m["chassis"]!!.toInt(),m["engine"]!!.toInt(),m["reliability"]!!.toInt(),facilities,project,
            m["frontWing"]?.toIntOrNull() ?: m["aero"]!!.toInt(),m["rearWing"]?.toIntOrNull() ?: m["aero"]!!.toInt(),m["brakes"]?.toIntOrNull() ?: m["chassis"]!!.toInt(),m["electricPowerUnit"]?.toIntOrNull() ?: m["engine"]!!.toInt(),
            m["nextSeasonInvestment"]?.toLongOrNull() ?: 0L,
            runCatching { CarDevelopmentFocus.valueOf(m["nextSeasonFocus"] ?: "BALANCED") }.getOrDefault(CarDevelopmentFocus.BALANCED),
            knowledge,
            m["seasonDevelopmentGain"]?.toIntOrNull() ?: 0)
        TeamManagerState(m["season"]!!.toInt(),m["round"]!!.toInt(),m["team"]!!.toInt(),car,TeamFinanceState(m["budget"]!!.toLong()),ManagerProfile(reputation=m["reputation"]!!.toInt(),experience=m["experience"]!!.toInt()))
    }.getOrNull()
}
