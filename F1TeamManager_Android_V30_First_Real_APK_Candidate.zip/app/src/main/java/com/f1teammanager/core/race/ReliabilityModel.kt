package com.f1teammanager.core.race

import com.f1teammanager.core.manager.CarComponent
import kotlin.random.Random

/**
 * V91 - Reliability model.
 * Factory reliability is 40..100. Zero exists only as a race failure state.
 * Wear is calculated per lap and the random margin is re-drawn every lap.
 */
object ReliabilityModel {
    data class LapDegradation(
        val amount: Double,
        val stressEvent: Boolean,
        val stressAmount: Double
    )

    fun category(value: Int): String = when (value.coerceIn(40, 100)) {
        in 40..51 -> "MUITO_BAIXA"
        in 52..63 -> "BAIXA"
        in 64..75 -> "MEDIA"
        in 76..87 -> "ALTA"
        else -> "MUITO_ALTA"
    }

    /**
     * Normal wear is intentionally small. Lower factory reliability increases
     * the wear rate. GP length adapts naturally because this is applied once
     * for every completed lap.
     */
    fun degrade(
        factoryReliability: Int,
        currentReliability: Double,
        component: CarComponent,
        random: Random,
        raceReliabilityRisk: Double = 1.0
    ): LapDegradation {
        val factory = factoryReliability.coerceIn(40, 100)
        val current = currentReliability.coerceIn(0.0, 100.0)
        val critical = component == CarComponent.ENGINE ||
            component == CarComponent.CHASSIS ||
            component == CarComponent.BRAKES

        val baseWear = 0.12 + (100 - factory) * 0.001
        val margin = if (critical) random.nextDouble(0.90, 1.10) else random.nextDouble(0.80, 1.20)

        // Small, rare stress event. It is not a guaranteed failure and exists
        // so even excellent parts retain a non-zero chance of reaching zero.
        val stressChance = ((0.005 + (100 - factory) * 0.00007) * raceReliabilityRisk.coerceIn(0.50, 1.50))
            .coerceIn(0.0001, 0.02)
        val stressEvent = random.nextDouble() < stressChance
        val stressAmount = if (stressEvent) random.nextDouble(8.0, 25.0) else 0.0

        val wear = (baseWear * margin + stressAmount).coerceAtMost(current)
        return LapDegradation(wear, stressEvent, stressAmount)
    }

    fun performanceLossPercent(component: CarComponent, currentReliability: Double): Double {
        val maxLoss = when (component) {
            CarComponent.ENGINE -> 0.0040
            CarComponent.CHASSIS -> 0.0035
            CarComponent.FRONT_WING -> 0.0025
            CarComponent.REAR_WING -> 0.0020
            CarComponent.BRAKES -> 0.0030
            CarComponent.ELECTRIC_POWER_UNIT -> 0.0020
        }
        return maxLoss * (1.0 - currentReliability.coerceIn(0.0, 100.0) / 100.0)
    }

    fun average(values: Map<CarComponent, Double>): Int =
        values.values.average().coerceIn(0.0, 100.0).toInt()
}
