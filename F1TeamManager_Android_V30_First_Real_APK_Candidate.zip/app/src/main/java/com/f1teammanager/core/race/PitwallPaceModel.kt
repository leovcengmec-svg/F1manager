package com.f1teammanager.core.race

import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

/**
 * Reimplementação Kotlin dos principais termos do pace.py do Pitwall.
 * A escala foi preservada conceitualmente: piloto + carro + motor +
 * pneu + combustível + desgaste + consistência + dirty air.
 */
class PitwallPaceModel(private val random: Random) {
    companion object {
        const val TYRE_DEGRADATION_MS_PER_LAP = 15.0
        const val DIRTY_AIR_THRESHOLD_MS = 1500L
        const val DIRTY_AIR_PENALTY_MS = 500L
    }

    /** Racecraft é uma capacidade derivada, não um 8º atributo do piloto. */
    fun derivedRacecraft(p: RaceParticipant): Double =
        p.overtaking * 0.45 + p.defense * 0.35 + p.consistency * 0.20

    /** Eficiência ofensiva combinada do DRS; 1.0 = referência. */
    fun drsAttackEfficiency(p: RaceParticipant): Double {
        val wing =
            CarComponentInfluence.frontWingDrsEfficiency(p.frontWingPerformance) * 0.40 +
                CarComponentInfluence.rearWingDrsEfficiency(p.rearWingPerformance) * 0.60
        return (1.0 + (wing - 0.888) * 0.80).coerceIn(0.75, 1.18)
    }

    /**
     * Motor: potência e velocidade. O tempo médio de referência do próprio GP
     * é a base; não há classificação por reta/curva nem fator geométrico.
     */
    fun engineEffect(p: RaceParticipant, c: RaceCircuit): Long =
        (c.baseLapTimeMs.toDouble() * CarComponentInfluence.engineLapModifier(p.enginePerformance)).toLong()

    /** Chassi: desempenho geral. A estabilidade é tratada separadamente abaixo. */
    fun chassisEffect(p: RaceParticipant, c: RaceCircuit): Long =
        (c.baseLapTimeMs.toDouble() * CarComponentInfluence.chassisLapModifier(p.chassisPerformance)).toLong()

    /** Asa dianteira: velocidade/aerodinâmica representada pelo tempo médio do GP. */
    fun frontWingEffect(p: RaceParticipant, c: RaceCircuit): Long =
        (c.baseLapTimeMs.toDouble() * CarComponentInfluence.frontWingLapModifier(p.frontWingPerformance)).toLong()

    /**
     * DRS combinado: asa dianteira 40% + asa traseira 60%.
     * A traseira é deliberadamente o componente principal do DRS.
     */
    /**
     * DRS potential is proportional to the GP reference lap time.
     * It is a situational attack aid, not a fixed 280 ms bonus.
     */
    fun drsGainMs(p: RaceParticipant, c: RaceCircuit): Long {
        val base = c.baseLapTimeMs * 0.015
        val efficiency =
            CarComponentInfluence.frontWingDrsEfficiency(p.frontWingPerformance) * 0.40 +
                CarComponentInfluence.rearWingDrsEfficiency(p.rearWingPerformance) * 0.60
        return (base * efficiency).toLong()
    }

    /** ERS potential is proportional to the GP reference lap time. */
    fun ersGainMs(p: RaceParticipant, c: RaceCircuit, chargePercent: Double): Long {
        val base = c.baseLapTimeMs * 0.010
        val efficiency = CarComponentInfluence.electricPowerUnitErsEfficiency(p.electricPowerUnitPerformance) / 0.90
        val charge = chargePercent.coerceIn(0.0, 100.0) / 100.0
        return (base * efficiency * charge).toLong()
    }

    fun consistencyPenalty(p: RaceParticipant): Long {
        val bounded = p.consistency.coerceIn(40,100)
        val influence = DriverAttributeInfluence.consistency(bounded)
        val pilotAmplitude = (55.0 * (1.0 - influence * 5.0)).coerceIn(25.0, 220.0)
        val chassisReduction = CarComponentInfluence.chassisStabilityReduction(p.chassisPerformance)
        val amplitude = pilotAmplitude * (1.0 - chassisReduction)
        val errorRoll = random.nextDouble()
        val errorChance = (0.018 * (1.0 - influence * 5.0)).coerceIn(0.002, 0.045)
        val errorPenalty = if (errorRoll < errorChance) random.nextLong(80L, 420L) else 0L
        return random.nextDouble(-amplitude, amplitude).toLong() + errorPenalty
    }

    fun tyreWear(lapsOnStint: Int, tyre: Tyre, tyreWearRating: Int): Long {
        val influence = DriverAttributeInfluence.tyre(tyreWearRating)
        val multiplier = (tyre.wearMultiplier * (1.0 - influence)).coerceAtLeast(0.5)
        return max(0.0, lapsOnStint.toDouble())
            .times(TYRE_DEGRADATION_MS_PER_LAP * multiplier).toLong()
    }

    /**
     * Base pace only: GP reference plus the weather-specific car/driver blend
     * (65/35 dry/cloudy, 55/45 light/medium rain, 50/50 heavy rain), followed
     * by consistency/dirty air/setup.
     * Tyre, fuel and Attack/Balanced/Defense are deliberately excluded here and
     * are applied once by TyreModel using the GP-average reference.
     */
    private data class CircuitDemand(
        val power: Double = 1.0,
        val aero: Double = 1.0,
        val mechanical: Double = 1.0,
        val braking: Double = 1.0,
        val energy: Double = 1.0,
        val rearWing: Double = 0.25
    )

    /** Circuit-specific sensitivity. Names come from the permanent 50-venue calendar. */
    private fun circuitDemand(circuit: RaceCircuit): CircuitDemand {
        val name = circuit.name.lowercase()
        return when {
            listOf("monza", "spa", "baku", "jeddah", "las vegas", "silverstone", "gilles-villeneuve", "montreal", "red bull ring").any(name::contains) ->
                CircuitDemand(power = 1.24, aero = 0.82, mechanical = 0.88, braking = 0.92, energy = 1.18, rearWing = 0.18)
            listOf("monte carlo", "monaco", "marina bay", "hungaroring", "zandvoort", "singapore", "jerez", "mugello").any(name::contains) ->
                CircuitDemand(power = 0.82, aero = 1.22, mechanical = 1.20, braking = 1.18, energy = 0.88, rearWing = 0.34)
            listOf("sakhir", "bahrain", "shanghai", "cota", "interlagos", "suzuka", "imola", "barcelona").any(name::contains) ->
                CircuitDemand(power = 1.04, aero = 1.08, mechanical = 1.08, braking = 1.08, energy = 1.02, rearWing = 0.28)
            else -> CircuitDemand()
        }
    }

    private fun carTimeModifier(p: RaceParticipant, circuit: RaceCircuit): Double {
        val demand = circuitDemand(circuit)
        return CarComponentInfluence.engineLapModifier(p.enginePerformance) * demand.power +
            CarComponentInfluence.chassisLapModifier(p.chassisPerformance) * demand.mechanical +
            CarComponentInfluence.frontWingLapModifier(p.frontWingPerformance) * demand.aero +
            CarComponentInfluence.rearWingLapModifier(p.rearWingPerformance) * demand.rearWing +
            CarComponentInfluence.brakeLapModifier(p.brakesPerformance) * demand.braking +
            CarComponentInfluence.electricPowerUnitLapModifier(p.electricPowerUnitPerformance) * demand.energy -
            p.facilityPaceBonus.coerceIn(0.0, 0.015)
    }

    fun lapTime(
        p: RaceParticipant,
        c: RaceCircuit,
        fuelKg: Double,
        stintLaps: Int,
        tyre: Tyre,
        dirtyAir: Boolean,
        setupBonusMs: Long = 0,
        weather: Weather = Weather.DRY
    ): Long {
        val dirty = if (dirtyAir) DIRTY_AIR_PENALTY_MS else 0L
        val driverModifier = DriverAttributeInfluence.velocity(p.driverSpeed)
        val weightedBase = c.baseLapTimeMs.toDouble() * RacePerformanceWeights.combinedTimeMultiplier(
            carTimeModifier(p, c), driverModifier, weather
        )
        // Apply consistency, traffic and setup once after the weighted base pace.
        val contextualDelta = consistencyPenalty(p) + dirty - setupBonusMs
        return max(45_000L, weightedBase.toLong() + contextualDelta)
    }

    fun qualifyingLapTime(p: RaceParticipant, c: RaceCircuit, weather: Weather = Weather.DRY): Long {
        val speed = DriverAttributeInfluence.velocity(p.driverSpeed)
        val quali = DriverAttributeInfluence.qualifying(p.qualifying)
        val driverModifier = speed * 0.40 + quali * 0.60
        val weightedBase = c.baseLapTimeMs.toDouble() * RacePerformanceWeights.combinedTimeMultiplier(
            carTimeModifier(p, c), driverModifier, weather
        )
        val jitter = random.nextInt(-80,81)
        return max(45_000L, (weightedBase + Tyre.MEDIUM.gripClassMs + jitter).toLong())
    }
}
