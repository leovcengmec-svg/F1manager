package com.f1teammanager.core.race

import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

/**
 * Reimplementação Kotlin dos principais termos do pace.py do Pitwall.
 * A escala foi preservada conceitualmente: piloto + carro + motor +
 * pneu + combustível + desgaste + consistência + dirty air.
 */
class PitwallPaceModel(private val random: Random) {
    companion object {
        const val PACE_CENTER = 50
        const val DRIVER_PACE_MS_PER_POINT = 1800.0 / 99.0
        const val CAR_PACE_MS_PER_POINT = 6200.0 / 99.0
        const val QUALIFYING_DRIVER_FACTOR = 0.9
        const val FUEL_PENALTY_MS_PER_KG = 30.0
        const val TYRE_DEGRADATION_MS_PER_LAP = 15.0
        const val DIRTY_AIR_THRESHOLD_MS = 1500L
        const val DIRTY_AIR_PENALTY_MS = 500L
        const val ENGINE_MAX_EFFECT_MS = 8.0
    }

    /** Habilidade global de corrida: velocidade pura + consistência + racecraft.
     *  O piloto melhora ou piora o ritmo do carro, mas não substitui a qualidade
     *  do equipamento. O carro continua sendo o maior componente do tempo de volta.
     */
    fun driverRaceScore(p: RaceParticipant): Double =
        p.driverSpeed * 0.55 + p.consistency * 0.15 + p.racecraft * 0.20 +
            p.overtaking * 0.05 + p.defense * 0.05

    fun driverBonus(p: RaceParticipant): Long =
        ((driverRaceScore(p) - PACE_CENTER) * DRIVER_PACE_MS_PER_POINT).toLong()

    fun carBonus(p: RaceParticipant): Long =
        ((p.carSpeed.coerceIn(1,100) - PACE_CENTER) * CAR_PACE_MS_PER_POINT).toLong()

    fun engineEffect(p: RaceParticipant, c: RaceCircuit): Long =
        ((p.enginePower - PACE_CENTER) * ENGINE_MAX_EFFECT_MS * c.powerFactor).toLong().let { -it }

    fun consistencyPenalty(p: RaceParticipant): Long {
        val bounded = p.consistency.coerceIn(40,100)
        val influence = DriverAttributeInfluence.consistency(bounded)
        val amplitude = (55.0 * (1.0 - influence * 5.0)).coerceIn(25.0, 220.0)
        val errorRoll = random.nextDouble()
        val errorChance = (0.018 * (1.0 - influence * 5.0)).coerceIn(0.002, 0.045)
        val errorPenalty = if (errorRoll < errorChance) random.nextLong(80L, 420L) else 0L
        return random.nextDouble(-amplitude, amplitude).toLong() + errorPenalty
    }

    fun qualifyingReduction(p: RaceParticipant): Long {
        val q = p.qualifying.coerceIn(40,100)
        val influence = DriverAttributeInfluence.qualifying(q)
        val cap = ((influence + 0.030) / 0.053 * 260.0).coerceIn(0.0, 260.0).toLong()
        return if (cap == 0L) 0L else random.nextLong(0L, cap + 1L)
    }

    fun tyreWear(lapsOnStint: Int, tyre: Tyre, tyreWearRating: Int): Long {
        val influence = DriverAttributeInfluence.tyre(tyreWearRating)
        val multiplier = (tyre.wearMultiplier * (1.0 - influence)).coerceAtLeast(0.5)
        return max(0.0, lapsOnStint.toDouble()).
            times(TYRE_DEGRADATION_MS_PER_LAP * multiplier).toLong()
    }

    fun lapTime(
        p: RaceParticipant,
        c: RaceCircuit,
        fuelKg: Double,
        stintLaps: Int,
        tyre: Tyre,
        dirtyAir: Boolean,
        setupBonusMs: Long = 0
    ): Long {
        val fuel = (fuelKg * FUEL_PENALTY_MS_PER_KG).toLong()
        val dirty = if (dirtyAir) DIRTY_AIR_PENALTY_MS else 0L
        val tyreGrip = tyre.gripClassMs + ((75 - p.tyreGrip) * 10)
        val base = c.baseLapTimeMs - driverBonus(p) - carBonus(p) +
            engineEffect(p,c) + tyreGrip + fuel +
            tyreWear(stintLaps,tyre,p.tyreWear) +
            consistencyPenalty(p) + dirty - setupBonusMs
        val velocityModifier = DriverAttributeInfluence.velocity(p.driverSpeed)
        return max(45_000L, (base.toDouble() * (1.0 - velocityModifier)).toLong())
    }

    fun qualifyingLapTime(p: RaceParticipant, c: RaceCircuit): Long {
        val driver = (driverBonus(p) * QUALIFYING_DRIVER_FACTOR).toLong()
        val jitter = random.nextInt(-80,81)
        return max(45_000L,
            c.baseLapTimeMs - driver - carBonus(p) -
                qualifyingReduction(p) + engineEffect(p,c) +
                Tyre.MEDIUM.gripClassMs + jitter)
    }
}
