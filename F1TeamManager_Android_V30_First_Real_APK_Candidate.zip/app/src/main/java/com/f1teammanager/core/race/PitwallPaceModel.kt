package com.f1teammanager.core.race

import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

/**
 * Reimplementação Kotlin dos principais termos do pace.py do Pitwall.
 * A escala foi preservada conceitualmente: piloto + carro + motor +
 * pneu + combustível + desgaste + consistência + dirty air.
 */
class PitwallPaceModel(private val random: Random) {
    companion object {
        const val PACE_CENTER = 50
        const val DRIVER_PACE_MS_PER_POINT = 2000.0 / 99.0
        const val CAR_PACE_MS_PER_POINT = 5000.0 / 99.0
        const val QUALIFYING_DRIVER_FACTOR = 0.9
        const val FUEL_PENALTY_MS_PER_KG = 30.0
        const val TYRE_DEGRADATION_MS_PER_LAP = 15.0
        const val DIRTY_AIR_THRESHOLD_MS = 1500L
        const val DIRTY_AIR_PENALTY_MS = 500L
        const val ENGINE_MAX_EFFECT_MS = 2000.0
    }

    fun driverBonus(p: RaceParticipant): Long =
        ((p.driverSpeed - PACE_CENTER) * DRIVER_PACE_MS_PER_POINT).toLong()

    fun carBonus(p: RaceParticipant): Long {
        val extraction = ((p.driverSpeed - 70) * 0.22 + (p.consistency - 70) * 0.10)
        val effectiveCar = (p.carSpeed + extraction).coerceIn(1.0, 100.0)
        return ((effectiveCar - PACE_CENTER) * CAR_PACE_MS_PER_POINT).toLong()
    }

    fun engineEffect(p: RaceParticipant, c: RaceCircuit): Long =
        ((ENGINE_MAX_EFFECT_MS * c.powerFactor / 10.0) * (50 - p.enginePower) / 100.0).toLong()

    fun consistencyPenalty(p: RaceParticipant): Long {
        val bounded = p.consistency.coerceIn(1,100)
        val maxPenalty = 180.0 - ((bounded - 1) / 99.0) * 90.0
        return random.nextInt(0, maxPenalty.toInt() + 1).toLong()
    }

    fun qualifyingReduction(p: RaceParticipant): Long {
        val q = p.qualifying.coerceIn(1,100)
        val cap = ((q - 1) / 99.0 * 240.0).toInt()
        return if (cap == 0) 0 else random.nextInt(0, cap + 1).toLong()
    }

    fun tyreWear(lapsOnStint: Int, tyre: Tyre, tyreWearRating: Int): Long {
        val qualityAdjustment = ((75 - tyreWearRating) / 50.0) * 0.35
        val multiplier = max(0.5, tyre.wearMultiplier + qualityAdjustment)
        return max(0.0, lapsOnStint.toDouble()).
            times(TYRE_DEGRADATION_MS_PER_LAP * multiplier).toLong()
    }

    fun lapTime(
        p: RaceParticipant,
        c: RaceCircuit,
        fuelKg: Double,
        stintLaps: Int,
        tyre: Tyre,
        dirtyAir: Boolean,
        setupBonusMs: Long = 0
    ): Long {
        val fuel = (fuelKg * FUEL_PENALTY_MS_PER_KG).toLong()
        val dirty = if (dirtyAir) DIRTY_AIR_PENALTY_MS else 0L
        val tyreGrip = tyre.gripClassMs +
            ((75 - p.tyreGrip) * 10)
        return max(
            45_000L,
            c.baseLapTimeMs - driverBonus(p) - carBonus(p) +
                engineEffect(p,c) + tyreGrip + fuel +
                tyreWear(stintLaps,tyre,p.tyreWear) +
                consistencyPenalty(p) + dirty - setupBonusMs
        )
    }

    fun qualifyingLapTime(p: RaceParticipant, c: RaceCircuit): Long {
        val driver = (driverBonus(p) * QUALIFYING_DRIVER_FACTOR).toLong()
        val jitter = random.nextInt(-80,81)
        return max(45_000L,
            c.baseLapTimeMs - driver - carBonus(p) -
                qualifyingReduction(p) + engineEffect(p,c) +
                Tyre.MEDIUM.gripClassMs + jitter)
    }
}
