package com.f1teammanager.core.race

import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

/**
 * V19: race session that can pause at manager decisions.
 * It deliberately keeps DRS/ERS automatic: the manager only chooses strategy.
 */
class InteractiveRaceSession(
    private val participants: List<RaceParticipant>,
    private val circuit: RaceCircuit,
    seed: Int = 20261003
) {
    private val random = Random(seed)
    private val pace = PitwallPaceModel(random)
    private val states = participants.associate { p ->
        p.driverId to SessionDriverState(p)
    }.toMutableMap()
    private val _events = mutableListOf<LapEvent>()
    private val _alerts = mutableListOf<DriverAlert>()
    private var configured = false
    private var started = false
    private var neutral = Neutralisation.GREEN
    private var neutralEndLap = 0
    private var lapStartTotalsMs: Map<Int, Long> = emptyMap()
    // Race-control decisions raised before lap execution must resume the same lap.
    private var pausedBeforeLapExecution = false
    private var pending: PendingManagerDecision? = null
    private var raceFinished = false
    private var fastestDriverId: Int? = null
    private var fastest = Long.MAX_VALUE

    var currentLap: Int = 0
        private set

    var grid: List<QualifyingEntry> = emptyList()
        private set

    var status: SessionStatus = SessionStatus.CONFIGURING
        private set

    val events: List<LapEvent> get() = _events.toList()
    val alerts: List<DriverAlert> get() = _alerts.toList()
    val pendingDecision: PendingManagerDecision? get() = pending

    fun configure(strategies: Map<Int, ManagerStrategy>) {
        participants.forEach { p ->
            val strategy = strategies[p.driverId] ?: ManagerStrategy(p.driverId)
            states[p.driverId]!!.strategy = strategy
            // This session's initial conditions are dry; a wet compound cannot be selected by an automatic setup.
            states[p.driverId]!!.tyre = TyreModel.compoundForWeather(Weather.DRY, strategy.startingTyre, circuit.laps)
        }
        configured = true
        status = SessionStatus.READY
    }

    fun start(): QualifyingResult {
        check(configured) { "Configure a estratégia antes de iniciar" }
        check(!started) { "Sessão já iniciada" }
        val q = participants.map { p ->
            val pace = PitwallPaceModel(random)
            val t = pace.qualifyingLapTime(p, circuit, Weather.DRY)
            QualifyingEntry(p.driverId, 0, t)
        }.sortedBy { it.lapTimeMs }.mapIndexed { i, e -> e.copy(position = i + 1) }
        grid = q
        q.forEach { states[it.driverId]!!.grid = it.position; states[it.driverId]!!.position = it.position }
        started = true
        status = SessionStatus.RUNNING
        return QualifyingResult(q)
    }

    fun tick(): PitWallSnapshot {
        check(started) { "Sessão ainda não iniciou" }
        check(!raceFinished) { "Corrida já terminou" }
        if (pending != null) return snapshot()

        if (!pausedBeforeLapExecution) {
            currentLap++
            if (currentLap > circuit.laps) {
                raceFinished = true
                status = SessionStatus.FINISHED
                return snapshot()
            }
            lapStartTotalsMs = states.values.filterNot { it.dnf }.associate { it.p.driverId to it.totalMs }

            if (neutral != Neutralisation.GREEN && currentLap > neutralEndLap) {
                val ended = neutral
                neutral = Neutralisation.GREEN
                _events += LapEvent(currentLap, null,
                    if (ended == Neutralisation.SAFETY_CAR) EventType.SAFETY_CAR_ENDED else EventType.VSC_ENDED,
                    if (ended == Neutralisation.SAFETY_CAR) "Safety Car recolhido — pelotão liberado" else "VSC encerrado")
            }

            // Simulated race-control event. It pauses before the lap's normal execution.
            if (neutral == Neutralisation.GREEN && currentLap > 3 && random.nextDouble() < circuit.safetyCarRisk * 0.025) {
                neutral = if (random.nextBoolean()) Neutralisation.VSC else Neutralisation.SAFETY_CAR
                neutralEndLap = currentLap + if (neutral == Neutralisation.SAFETY_CAR) random.nextInt(2, 5) else random.nextInt(1, 3)
                val type = if (neutral == Neutralisation.VSC) ManagerDecisionType.VSC else ManagerDecisionType.SAFETY_CAR
                _events += LapEvent(currentLap, null,
                    if (neutral == Neutralisation.SAFETY_CAR) EventType.SAFETY_CAR_DEPLOYED else EventType.VSC_DEPLOYED,
                    if (neutral == Neutralisation.SAFETY_CAR) "Safety Car — pelotão agrupando" else "VSC implantado")
                pending = PendingManagerDecision(type, currentLap, null,
                    if (neutral == Neutralisation.VSC) "VSC: decisão do gestor" else "Safety Car: decisão do gestor")
                status = SessionStatus.PAUSED_FOR_MANAGER_DECISION
                pausedBeforeLapExecution = true
                return snapshot()
            }
        } else {
            // No car was advanced while the manager decision was open; keep this lap's
            // original clock and apply the chosen race-control state before executing it.
            lapStartTotalsMs = states.values.filterNot { it.dnf }.associate { it.p.driverId to it.totalMs }
            pausedBeforeLapExecution = false
        }

        executeLap()
        if (currentLap == circuit.laps) {
            raceFinished = true
            status = SessionStatus.FINISHED
        }
        return snapshot()
    }

    fun resolve(decision: ManagerDecision) {
        val p = pending ?: error("Não existe decisão pendente")
        require(p.type == decision.type) { "Decisão incompatível: ${decision.type} / ${p.type}" }
        when (decision.type) {
            ManagerDecisionType.VSC, ManagerDecisionType.SAFETY_CAR -> when (decision.neutralisationAction) {
                NeutralisationAction.BOX -> states.values.forEach { it.forcePit = true }
                NeutralisationAction.EXTEND -> states.values.forEach { it.extendStint = true }
                NeutralisationAction.MAINTAIN, null -> Unit
            }
            ManagerDecisionType.RED_FLAG -> {
                val tyre = when (decision.restartTyre) {
                    RedFlagTyre.SOFT -> Tyre.SOFT
                    RedFlagTyre.MEDIUM -> Tyre.MEDIUM
                    RedFlagTyre.HARD -> Tyre.HARD
                    null -> Tyre.MEDIUM
                }
                states.values.forEach {
                    it.tyre = tyre
                    it.tyreWear = 0
                    decision.restartPosture?.let { posture -> it.strategy = it.strategy.copy(posture = posture) }
                }
            }
            ManagerDecisionType.FUEL_CRITICAL, ManagerDecisionType.TYRE_CRITICAL, ManagerDecisionType.WEATHER_CHANGE, ManagerDecisionType.MECHANICAL_ALERT -> {
                if (decision.keepRunning) states.values.forEach { it.forcePit = false }
                else states.values.forEach { it.forcePit = true }
            }
        }
        pending = null
        status = SessionStatus.RUNNING
    }

    fun injectRedFlagDecision() {
        check(pending == null) { "Já existe uma decisão pendente" }
        pending = PendingManagerDecision(ManagerDecisionType.RED_FLAG, currentLap, null, "Bandeira vermelha: escolha pneus e postura")
        status = SessionStatus.PAUSED_FOR_MANAGER_DECISION
    }

    fun snapshot(driverId: Int? = participants.firstOrNull()?.driverId): PitWallSnapshot {
        val s = states[driverId] ?: states.values.first()
        return PitWallSnapshot(
            currentLap, circuit.laps, s.position, s.tyre, s.tyreWear,
            FuelModel.fuelPercent(s.fuelKg),
            s.strategy.posture, neutral, _alerts.filter { it.driverId == s.p.driverId }.takeLast(5), pending
        )
    }

    private fun executeLap() {
        states.values.filter { !it.dnf }.forEach { s ->
            // No-refuelling model: every lap consumes fuel according to race distance,
            // strategy and weather. Neutralisations naturally consume less.
            // Neutralisation is race control, not weather: it must never change tyre eligibility.
            val weather = Weather.DRY
            val neutralFuelFactor = when (neutral) {
                Neutralisation.GREEN -> 1.0
                Neutralisation.VSC -> 0.80
                Neutralisation.SAFETY_CAR -> 0.65
            }
            s.fuelKg = max(0.0, s.fuelKg - FuelModel.consumptionPerLap(circuit.laps, when (s.strategy.posture) { DriverPosture.ATTACK -> DriverStrategyMode.ATTACK; DriverPosture.BALANCED -> DriverStrategyMode.BALANCED; DriverPosture.DEFENSE -> DriverStrategyMode.DEFENSE }, weather, s.tyre) * neutralFuelFactor)
            if (s.forcePit && currentLap < circuit.laps) {
                s.totalMs += 22_000
                s.forcePit = false
                s.tyre = nextTyre(s)
                s.tyreWear = 0
                _events += LapEvent(currentLap, s.p.driverId, EventType.PIT_STOP, "Pit stop por decisão do gestor")
            }
            if (!s.extendStint && s.tyreWear >= 78 && currentLap < circuit.laps) {
                _alerts += DriverAlert(currentLap, s.p.driverId, DriverAlertType.TYRE_CRITICAL, "Pneu perdeu desempenho; pit stop recomendado", 3)
                pending = PendingManagerDecision(ManagerDecisionType.TYRE_CRITICAL, currentLap, s.p.driverId, "Pneu crítico: decidir pit stop")
                status = SessionStatus.PAUSED_FOR_MANAGER_DECISION
            } else if (s.tyreWear >= 60) {
                _alerts += DriverAlert(currentLap, s.p.driverId, DriverAlertType.TYRE_DEGRADING, "Pneu começando a perder desempenho", 2)
            }
            if (s.fuelKg <= 18.0 && !s.fuelAlertSent) {
                _alerts += DriverAlert(currentLap, s.p.driverId, DriverAlertType.FUEL_LOW, "Combustível baixo", 2)
                s.fuelAlertSent = true
            }
            val postureBonus = 0L // Strategy is applied once by TyreModel below.
            val dirty = false
            var lapMs = pace.lapTime(s.p, circuit, s.fuelKg, s.stintLaps, s.tyre, dirty, weather = weather)
            lapMs = TyreModel.applyLapModifiers(
                carDriverLapMs = lapMs,
                gpAverageLapMs = circuit.baseLapTimeMs,
                tyre = s.tyre,
                weather = weather,
                wearPercent = s.tyreWear,
                mode = when (s.strategy.posture) {
                    DriverPosture.ATTACK -> DriverStrategyMode.ATTACK
                    DriverPosture.BALANCED -> DriverStrategyMode.BALANCED
                    DriverPosture.DEFENSE -> DriverStrategyMode.DEFENSE
                }
            )
            lapMs = (lapMs + circuit.baseLapTimeMs * (TyreModel.fuelPenaltyMultiplier(FuelModel.fuelPercent(s.fuelKg).toDouble()) - 1.0)).toLong().coerceAtLeast(45_000L)
            when (neutral) {
                Neutralisation.SAFETY_CAR -> {
                    lapMs += SafetyCarGroupingModel.SAFETY_CAR_PACE_PENALTY_MS
                    val ownStartTotal = lapStartTotalsMs[s.p.driverId]
                    val leaderStartTotal = lapStartTotalsMs.values.minOrNull()
                    if (ownStartTotal != null && leaderStartTotal != null) {
                        val gap = (ownStartTotal - leaderStartTotal).coerceAtLeast(0L)
                        lapMs = SafetyCarGroupingModel.applyCatchUp(lapMs, gap, circuit.baseLapTimeMs)
                    }
                }
                Neutralisation.VSC -> lapMs += 4_500L
                Neutralisation.GREEN -> Unit
            }
            lapMs += postureBonus
            s.totalMs += lapMs
            s.lastLapMs = lapMs
            val mode = when (s.strategy.posture) {
                DriverPosture.ATTACK -> DriverStrategyMode.ATTACK
                DriverPosture.BALANCED -> DriverStrategyMode.BALANCED
                DriverPosture.DEFENSE -> DriverStrategyMode.DEFENSE
            }
            val driverWearFactor = (1.0 - DriverAttributeInfluence.tyre(s.p.tyreWear)).coerceIn(0.90, 1.10)
            val increment = 100.0 / s.tyre.targetLaps * TyreModel.tyreWeatherWearFactor(s.tyre, Weather.DRY) *
                TyreModel.strategyWearFactor(mode) * driverWearFactor
            s.tyreWear = min(100, (s.tyreWear + increment).toInt())
            s.stintLaps++
            if (lapMs < fastest) { fastest = lapMs; fastestDriverId = s.p.driverId }
        }
        val ordered = states.values.filter { !it.dnf }.sortedWith(compareBy<SessionDriverState> { it.totalMs }.thenBy { it.grid })
        ordered.forEachIndexed { idx, s -> s.position = idx + 1 }
    }

    private fun nextTyre(s: SessionDriverState): Tyre = when (s.tyre) {
        Tyre.SOFT -> Tyre.MEDIUM
        Tyre.MEDIUM -> Tyre.HARD
        Tyre.HARD -> Tyre.MEDIUM
        Tyre.INTERMEDIATE -> Tyre.MEDIUM
        Tyre.WET -> Tyre.MEDIUM
    }

    private data class SessionDriverState(val p: RaceParticipant) {
        var strategy: ManagerStrategy = ManagerStrategy(p.driverId)
        var grid: Int = 99
        var position: Int = 99
        var totalMs: Long = 0
        var lastLapMs: Long = 0
        var fuelKg: Double = 110.0
        var tyre: Tyre = Tyre.MEDIUM
        var tyreWear: Int = 0
        var stintLaps: Int = 0
        var dnf: Boolean = false
        var forcePit: Boolean = false
        var extendStint: Boolean = false
        var fuelAlertSent: Boolean = false
    }
}

enum class SessionStatus { CONFIGURING, READY, RUNNING, PAUSED_FOR_MANAGER_DECISION, FINISHED }
