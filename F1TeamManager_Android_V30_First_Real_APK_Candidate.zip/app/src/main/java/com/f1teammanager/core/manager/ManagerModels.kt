package com.f1teammanager.core.manager

enum class CarComponent {
    ENGINE, CHASSIS, FRONT_WING, REAR_WING, BRAKES, ELECTRIC_POWER_UNIT
}
enum class CarDevelopmentFocus { BALANCED, POWER, AERODYNAMICS, CORNERING }
enum class CarRegulationFocus { BALANCED, AERODYNAMICS, POWER, CORNERING, EFFICIENCY }
enum class DevelopmentIntensity { QUICK, STANDARD, ADVANCED, AGGRESSIVE }
enum class Facility { FACTORY, WIND_TUNNEL, SIMULATOR, TESTING }
enum class ManagementAction { DEVELOP_AERO, DEVELOP_CHASSIS, DEVELOP_ENGINE, DEVELOP_RELIABILITY, UPGRADE_FACTORY, UPGRADE_WIND_TUNNEL, UPGRADE_SIMULATOR, UPGRADE_TESTING, HIRE_BEST_TECHNICAL, HIRE_BEST_COMMERCIAL, HIRE_BEST_PRINCIPAL }

data class DriverContract(val driverId:Int, val years:Int, val salary:Int)
data class DevelopmentProject(
    val component:CarComponent,
    val remainingWeeks:Int,
    val totalWeeks:Int,
    val level:Int,
    val intensity:DevelopmentIntensity = DevelopmentIntensity.STANDARD,
    val expectedGain:Int = 4,
    val cost:Long = 0L
) {
    /** Compatibility with older saves/tests: a development round is now a week. */
    val remainingRounds:Int get() = remainingWeeks
}
data class TeamCarState(
    val aerodynamics:Int,
    val chassis:Int,
    val engine:Int,
    val reliability:Int,
    val facilities:Map<Facility,Int> = Facility.values().associateWith { 1 },
    val activeProject:DevelopmentProject? = null,
    val frontWing:Int = aerodynamics,
    val rearWing:Int = aerodynamics,
    val brakes:Int = chassis,
    val electricPowerUnit:Int = engine,
    val nextSeasonInvestment:Long = 0L,
    val nextSeasonFocus:CarDevelopmentFocus = CarDevelopmentFocus.BALANCED,
    val developmentKnowledge:Map<CarComponent,Int> = emptyMap(),
    val seasonDevelopmentGain:Int = 0
) {
    fun normalized() = copy(
        aerodynamics=aerodynamics.coerceIn(1,100), chassis=chassis.coerceIn(1,100),
        engine=engine.coerceIn(1,100), reliability=reliability.coerceIn(1,100),
        frontWing=frontWing.coerceIn(1,100), rearWing=rearWing.coerceIn(1,100),
        brakes=brakes.coerceIn(1,100), electricPowerUnit=electricPowerUnit.coerceIn(1,100),
        facilities=facilities.mapValues { it.value.coerceIn(1,10) },
        nextSeasonInvestment=nextSeasonInvestment.coerceIn(0,35_000_000L),
        developmentKnowledge=developmentKnowledge.mapValues { it.value.coerceIn(0,8) },
        seasonDevelopmentGain=seasonDevelopmentGain.coerceIn(0,24)
    )
}

data class TeamFinanceState(
    val budget:Long,
    val seasonIncome:Long=0,
    val seasonExpenses:Long=0,
    val raceIncome:Long=0,
    val raceExpenses:Long=0,
    val transactions:List<String> = emptyList()
) {
    fun transact(amount:Long, description:String):TeamFinanceState {
        return if (amount >= 0) copy(budget=budget+amount, seasonIncome=seasonIncome+amount, raceIncome=raceIncome+amount,
            transactions=(transactions+"+$amount:$description").takeLast(100))
        else copy(budget=budget+amount, seasonExpenses=seasonExpenses-amount, raceExpenses=raceExpenses-amount,
            transactions=(transactions+"$amount:$description").takeLast(100))
    }
}

data class ManagerProfile(val id:Int=1, val name:String="Chefe de Equipe", val reputation:Int=50, val experience:Int=0)

data class TeamManagerState(
    val season:Int=2026,
    val round:Int=1,
    val playerTeamId:Int=1,
    val car:TeamCarState,
    val finance:TeamFinanceState,
    val manager:ManagerProfile=ManagerProfile(),
    val contracts:List<DriverContract> = emptyList(),
    val driverMarket:DriverMarketState = DriverMarketState(),
    val staff:List<StaffMember> = emptyList(),
    val sponsor:SponsorContract = SponsorContract("Patrocinador Base",0,0,0,1,0,1,0,0,0,0,false),
    val sponsors:List<SponsorContract> = emptyList(),
    val engineSupplier:SupplierContract = SupplierContract(SupplierType.ENGINE,"Apex Power",85,85,10_000_000,1),
    val tyreSupplier:SupplierContract = SupplierContract(SupplierType.TYRE,"Pirelli",85,85,8_000_000,1),
    val history:List<String> = emptyList()
)
