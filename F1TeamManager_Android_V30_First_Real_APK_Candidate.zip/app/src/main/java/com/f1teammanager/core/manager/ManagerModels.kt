package com.f1teammanager.core.manager

enum class CarComponent {
    ENGINE, CHASSIS, FRONT_WING, REAR_WING, BRAKES, ELECTRIC_POWER_UNIT
}
enum class CarDevelopmentFocus { BALANCED, POWER, AERODYNAMICS, CORNERING }
enum class CarRegulationFocus { BALANCED, AERODYNAMICS, POWER, CORNERING, EFFICIENCY }
enum class DevelopmentIntensity { QUICK, STANDARD, ADVANCED, AGGRESSIVE }
enum class Facility { FACTORY, WIND_TUNNEL, SIMULATOR, TESTING }

data class DriverContract(val driverId:Int, val years:Int, val salary:Int)
data class DevelopmentProject(
    val component:CarComponent,
    val remainingWeeks:Int,
    val totalWeeks:Int,
    val level:Int,
    val intensity:DevelopmentIntensity = DevelopmentIntensity.STANDARD,
    val expectedGain:Int = 4,
    val cost:Long = 0L
) {
    /** Compatibility with older saves/tests: a development round is now a week. */
    val remainingRounds:Int get() = remainingWeeks
}
data class TeamCarState(
    val aerodynamics:Int,
    val chassis:Int,
    val engine:Int,
    val reliability:Int,
    val facilities:Map<Facility,Int> = Facility.values().associateWith { 1 },
    val activeProject:DevelopmentProject? = null,
    val frontWing:Int = aerodynamics,
    val rearWing:Int = aerodynamics,
    val brakes:Int = chassis,
    val electricPowerUnit:Int = engine,
    val nextSeasonInvestment:Long = 0L,
    val nextSeasonFocus:CarDevelopmentFocus = CarDevelopmentFocus.BALANCED,
    val developmentKnowledge:Map<CarComponent,Int> = emptyMap(),
    val seasonDevelopmentGain:Int = 0,
) {
    fun normalized() = copy(
        aerodynamics=aerodynamics.coerceIn(1,100), chassis=chassis.coerceIn(1,100),
        engine=engine.coerceIn(1,100), reliability=reliability.coerceIn(1,100),
        frontWing=frontWing.coerceIn(1,100), rearWing=rearWing.coerceIn(1,100),
        brakes=brakes.coerceIn(1,100), electricPowerUnit=electricPowerUnit.coerceIn(1,100),
        facilities=facilities.mapValues { it.value.coerceIn(0,10) },
        nextSeasonInvestment=nextSeasonInvestment.coerceIn(0,35_000_000L),
        developmentKnowledge=developmentKnowledge.mapValues { it.value.coerceIn(0,8) },
        seasonDevelopmentGain=seasonDevelopmentGain.coerceIn(0,140)
    )
}

data class SignatureFeeSchedule(val id:String, val amount:Long, val season:Int, val recognizedRounds:Set<Int> = emptySet())

data class TeamFinanceState(
    val budget:Long,
    val seasonIncome:Long=0,
    val seasonExpenses:Long=0,
    val raceIncome:Long=0,
    val raceExpenses:Long=0,
    val transactions:List<String> = emptyList(),
    val seasonPrizesPaid:Set<Int> = emptySet(),
    /** Persistent accounting schedule; independent of the bounded display transaction history. */
    val signatureFeeSchedules:List<SignatureFeeSchedule> = emptyList(),
    /** Durable idempotency ledger, independent of bounded transaction history. Keys are season:GP. */
    val salaryPaidRounds:Set<String> = emptySet(),
    /** Mandatory salary obligations not yet paid, keyed by season:GP; persisted independently of display history. */
    val salaryOutstanding:Map<String,Long> = emptyMap()
) {
    fun resetForNewSeason(): TeamFinanceState = copy(
        seasonIncome = 0L,
        seasonExpenses = 0L,
        raceIncome = 0L,
        raceExpenses = 0L
    )

    fun transact(amount:Long, description:String):TeamFinanceState {
        return if (amount >= 0) copy(budget=budget+amount, seasonIncome=seasonIncome+amount, raceIncome=raceIncome+amount,
            transactions=(transactions+"+$amount:$description").takeLast(100))
        else copy(budget=budget+amount, seasonExpenses=seasonExpenses-amount, raceExpenses=raceExpenses-amount,
            transactions=(transactions+"$amount:$description").takeLast(100))
    }
}

/** Deterministic salary ledger shared by player and AI finance. Unpaid obligations are never lost. */
internal object SalaryLedger {
    fun apply(finance: TeamFinanceState, season: Int, round: Int, requested: Long): TeamFinanceState {
        if (round !in 1..30) return finance
        val currentKey = "$season:$round"
        if (currentKey !in finance.salaryPaidRounds && currentKey !in finance.salaryOutstanding && requested > 0L) {
            // Record the whole installment; never make a partial payment and then lose the remainder.
            var next = finance.copy(salaryOutstanding = finance.salaryOutstanding + (currentKey to requested))
            return settle(next, currentKey, season, round)
        }
        if (currentKey in finance.salaryPaidRounds) return finance
        val pending = if (currentKey in finance.salaryOutstanding) finance else finance.copy(
            salaryPaidRounds = if (requested <= 0L) finance.salaryPaidRounds + currentKey else finance.salaryPaidRounds
        )
        return settle(pending, currentKey, season, round)
    }

    private fun settle(finance: TeamFinanceState, currentKey: String, season: Int, round: Int): TeamFinanceState {
        var next = finance
        val ordered = next.salaryOutstanding.keys.sortedWith(compareBy<String>({ it.substringBefore(':').toIntOrNull() ?: Int.MAX_VALUE }, { it.substringAfter(':').toIntOrNull() ?: Int.MAX_VALUE }))
        for (key in ordered) {
            val amount = next.salaryOutstanding[key] ?: continue
            if (amount <= 0L) {
                next = next.copy(salaryOutstanding = next.salaryOutstanding - key, salaryPaidRounds = next.salaryPaidRounds + key)
                continue
            }
            if (next.budget.coerceAtLeast(0L) < amount) break
            val s = key.substringBefore(':').toIntOrNull() ?: continue
            val r = key.substringAfter(':').toIntOrNull() ?: continue
            next = next.transact(-amount, "Salários dos pilotos — GP $r/30 — temporada $s")
                .copy(salaryOutstanding = next.salaryOutstanding - key, salaryPaidRounds = next.salaryPaidRounds + key)
        }
        if (currentKey in next.salaryOutstanding) {
            val amount = next.salaryOutstanding[currentKey] ?: 0L
            val marker = "OBRIGAÇÃO PENDENTE: €$amount de salários — GP $round/30 — temporada $season"
            if (marker !in next.transactions) next = next.copy(transactions = (next.transactions + marker).takeLast(100))
        }
        return next.copy(budget = next.budget.coerceAtLeast(0L))
    }
}

/**
 * Recognition schedule for signing fees. Cash is charged at signing; this ledger only
 * recognizes the accounting expense over 30 GPs in the target season and never changes cash.
 * Entries are kept in the finance transaction history so the current save format remains compatible.
 */
internal object SignatureFeeAccounting {
    private fun parseTargetSeason(description:String):Int? =
        Regex("(?:temporada|para|—)\\s*(20\\d{2})", RegexOption.IGNORE_CASE)
            .findAll(description).lastOrNull()?.groupValues?.getOrNull(1)?.toIntOrNull()

    fun register(finance:TeamFinanceState, fee:Long, description:String, targetSeason:Int? = parseTargetSeason(description)):TeamFinanceState {
        if (fee <= 0L || targetSeason == null) return finance
        val id = java.util.Base64.getUrlEncoder().withoutPadding().encodeToString(description.toByteArray(Charsets.UTF_8)) + ":$targetSeason:$fee"
        if (finance.signatureFeeSchedules.any { it.id == id }) return finance
        return finance.copy(signatureFeeSchedules=finance.signatureFeeSchedules + SignatureFeeSchedule(id, fee, targetSeason))
    }

    fun recognizeForRace(finance:TeamFinanceState, season:Int, round:Int):TeamFinanceState {
        if (round !in 1..30) return finance
        var next = finance
        // One-time migration for saves created before the explicit schedule existed.
        val knownIds = next.signatureFeeSchedules.map { it.id }.toSet()
        val legacyFees = next.transactions.mapNotNull { entry ->
            val colon = entry.indexOf(':')
            if (colon <= 1 || !entry.startsWith('-')) return@mapNotNull null
            val description = entry.substring(colon + 1)
            if (!description.contains("Taxa de assinatura", ignoreCase = true)) return@mapNotNull null
            val target = parseTargetSeason(description) ?: return@mapNotNull null
            val amount = entry.substring(1, colon).toLongOrNull() ?: return@mapNotNull null
            if (amount <= 0L) return@mapNotNull null
            val id = java.util.Base64.getUrlEncoder().withoutPadding().encodeToString(description.toByteArray(Charsets.UTF_8)) + ":$target:$amount"
            if (id in knownIds) null else SignatureFeeSchedule(id, amount, target)
        }
        if (legacyFees.isNotEmpty()) next = next.copy(signatureFeeSchedules=next.signatureFeeSchedules + legacyFees.distinctBy { it.id })

        val updated = next.signatureFeeSchedules.map { schedule ->
            if (schedule.season != season || round in schedule.recognizedRounds) schedule
            else {
                val installment = schedule.amount / 30L + if (round == 30) schedule.amount % 30L else 0L
                val marker = "AMORTIZAÇÃO TAXA ASSINATURA [${schedule.id}] GP $round/30 — temporada $season — €$installment (despesa contábil; sem nova saída de caixa)"
                next = next.copy(transactions=(next.transactions + "0:$marker").takeLast(100))
                schedule.copy(recognizedRounds=schedule.recognizedRounds + round)
            }
        }
        return next.copy(signatureFeeSchedules=updated)
    }
}

data class ManagerProfile(val id:Int=1, val name:String="Chefe de Equipe", val reputation:Int=50, val experience:Int=0)

data class TeamManagerState(
    val season:Int=2026,
    val round:Int=1,
    val playerTeamId:Int=1,
    val car:TeamCarState,
    val facilities:TeamFacilitiesState = TeamFacilitiesState(),
    /** Two-car physical garage is the sole race-performance source; TeamCarState is the seasonal development state. */
    val garage:TeamGarage? = null,
    /** New R&D pipeline: projects become designs and never mutate a physical car directly. */
    val research:TeamResearchState = TeamResearchState(),
    val factory:TeamFactoryState = TeamFactoryState(),
    val finance:TeamFinanceState,
    val manager:ManagerProfile=ManagerProfile(),
    val contracts:List<DriverContract> = emptyList(),
    val driverMarket:DriverMarketState = DriverMarketState(),
    val staff:List<StaffMember> = emptyList(),
    val sponsor:SponsorContract = SponsorContract("Patrocinador Base",0,0,0,1,0,1,0,0,0,0,false),
    val sponsors:List<SponsorContract> = emptyList(),
    val engineSupplier:SupplierContract = SupplierContract(SupplierType.ENGINE,"Apex Power",85,85,10_000_000,1),
    val tyreSupplier:SupplierContract = SupplierContract(SupplierType.TYRE,"Pirelli",85,85,8_000_000,1),
    val history:List<String> = emptyList(),
    /** Persistent driver attributes used by the manager-season simulation path. */
    val driverEvolutionAttributes:Map<Int,List<Int>> = emptyMap(),
    val driverEvolutionAnnualGains:Map<Int,List<Int>> = emptyMap(),
    val driverEvolutionBanks:Map<Int,Double> = emptyMap(),
    /** Frozen opening-season target (1..80) derived from the team-strength ranking at season start. */
    val driverEvolutionSeasonTargets:Map<Int,Int> = emptyMap(),
    /** Career-cycle phase: GROWING, PEAK or REGRESSION. */
    val driverEvolutionPhases:Map<Int,String> = emptyMap(),
    /** GP counter inside the current career-cycle phase. */
    val driverEvolutionPhaseGps:Map<Int,Int> = emptyMap(),
    /** Overall at the exact start of the current phase; frozen until the phase ends. */
    val driverEvolutionPhaseStart:Map<Int,Int> = emptyMap(),
    /** Target Overall of the current phase (class ceiling or class floor). */
    val driverEvolutionPhaseTarget:Map<Int,Int> = emptyMap(),
    /** Accumulated evidence used only to anticipate an early phase transition. */
    val driverEvolutionPhasePressure:Map<Int,Double> = emptyMap(),
    /** Persistent facility programs that accelerate selected drivers. */
    val driverDevelopment:DriverDevelopmentState = DriverDevelopmentState(),
    /** Annual technical-investment ceiling shared by P&D, fabrication and facility upgrades. */
    val technicalInvestment:TechnicalInvestmentState = TechnicalInvestmentEngine.create(2026, 40)
)
