package com.f1teammanager.core.manager

enum class CarComponent {
    ENGINE, CHASSIS, FRONT_WING, REAR_WING, BRAKES, ELECTRIC_POWER_UNIT
}
enum class CarDevelopmentFocus { BALANCED, POWER, AERODYNAMICS, CORNERING }
enum class CarRegulationFocus { BALANCED, AERODYNAMICS, POWER, CORNERING, EFFICIENCY }
enum class DevelopmentIntensity { QUICK, STANDARD, ADVANCED, AGGRESSIVE }
enum class Facility { FACTORY, WIND_TUNNEL, SIMULATOR, TESTING }

data class DriverContract(val driverId:Int, val years:Int, val salary:Int)
data class DevelopmentProject(
    val component:CarComponent,
    val remainingWeeks:Int,
    val totalWeeks:Int,
    val level:Int,
    val intensity:DevelopmentIntensity = DevelopmentIntensity.STANDARD,
    val expectedGain:Int = 4,
    val cost:Long = 0L
) {
    /** Compatibility with older saves/tests: a development round is now a week. */
    val remainingRounds:Int get() = remainingWeeks
}
data class TeamCarState(
    val aerodynamics:Int,
    val chassis:Int,
    val engine:Int,
    val reliability:Int,
    val facilities:Map<Facility,Int> = Facility.values().associateWith { 1 },
    val activeProject:DevelopmentProject? = null,
    val frontWing:Int = aerodynamics,
    val rearWing:Int = aerodynamics,
    val brakes:Int = chassis,
    val electricPowerUnit:Int = engine,
    val nextSeasonInvestment:Long = 0L,
    /** Cash baseline frozen at the first next-season investment; prevents the phase cap from resetting or shrinking after each purchase. */
    val nextSeasonInvestmentBudgetBase:Long = 0L,
    val nextSeasonFocus:CarDevelopmentFocus = CarDevelopmentFocus.BALANCED,
    val developmentKnowledge:Map<CarComponent,Int> = emptyMap(),
    val seasonDevelopmentGain:Int = 0,
) {
    fun normalized() = copy(
        aerodynamics=aerodynamics.coerceIn(1,100), chassis=chassis.coerceIn(1,100),
        engine=engine.coerceIn(1,100), reliability=reliability.coerceIn(1,100),
        frontWing=frontWing.coerceIn(1,100), rearWing=rearWing.coerceIn(1,100),
        brakes=brakes.coerceIn(1,100), electricPowerUnit=electricPowerUnit.coerceIn(1,100),
        facilities=facilities.mapValues { it.value.coerceIn(0,10) },
        nextSeasonInvestment=nextSeasonInvestment.coerceIn(0,150_000_000L),
        developmentKnowledge=developmentKnowledge.mapValues { it.value.coerceIn(0,8) },
        seasonDevelopmentGain=seasonDevelopmentGain.coerceIn(0,140)
    )
}

data class SignatureFeeSchedule(val id:String, val amount:Long, val season:Int, val recognizedRounds:Set<Int> = emptySet(), val startRound:Int = 1, val installmentCount:Int = 30, val paidRounds:Set<Int> = emptySet())

data class TeamFinanceState(
    val budget:Long,
    val seasonIncome:Long=0,
    val seasonExpenses:Long=0,
    val raceIncome:Long=0,
    val raceExpenses:Long=0,
    val transactions:List<String> = emptyList(),
    val seasonPrizesPaid:Set<Int> = emptySet(),
    /** Persistent accounting schedule; independent of the bounded display transaction history. */
    val signatureFeeSchedules:List<SignatureFeeSchedule> = emptyList(),
    /** Durable idempotency ledger, independent of bounded transaction history. Keys are season:GP. */
    val salaryPaidRounds:Set<String> = emptySet(),
    /** Mandatory salary obligations not yet paid, keyed by season:GP; persisted independently of display history. */
    val salaryOutstanding:Map<String,Long> = emptyMap(),
    /** Permanent idempotency ledger for race settlement, independent of bounded transaction history. */
    val raceSettlementKeys:Set<String> = emptySet(),
    /** Weekly facility maintenance assessment keys (season:week), independent of bounded transaction history. */
    val facilityMaintenanceWeeks:Set<String> = emptySet(),
    /** Unpaid weekly facility maintenance obligations, keyed by season:week. */
    val facilityMaintenanceOutstanding:Map<String,Long> = emptyMap(),
    /** Durable idempotency ledger for weekly merchandise revenue (season:week). */
    val commercialRevenueWeeks:Set<String> = emptySet()
) {
    fun resetForNewSeason(): TeamFinanceState = copy(
        seasonIncome = 0L,
        seasonExpenses = 0L,
        raceIncome = 0L,
        raceExpenses = 0L
    )

    fun transact(amount:Long, description:String):TeamFinanceState {
        return if (amount >= 0) copy(budget=budget+amount, seasonIncome=seasonIncome+amount, raceIncome=raceIncome+amount,
            transactions=(transactions+"+$amount:$description").takeLast(2000))
        else copy(budget=budget+amount, seasonExpenses=seasonExpenses-amount, raceExpenses=raceExpenses-amount,
            transactions=(transactions+"$amount:$description").takeLast(2000))
    }
}

/** Deterministic salary ledger shared by player and AI finance. Unpaid obligations are never lost. */
internal object SalaryLedger {
    fun apply(finance: TeamFinanceState, season: Int, round: Int, requested: Long): TeamFinanceState {
        if (round !in 1..30) return finance
        val currentKey = "$season:$round"
        if (currentKey !in finance.salaryPaidRounds && currentKey !in finance.salaryOutstanding && requested > 0L) {
            // Record the whole installment; never make a partial payment and then lose the remainder.
            var next = finance.copy(salaryOutstanding = finance.salaryOutstanding + (currentKey to requested))
            return settle(next, currentKey, season, round)
        }
        if (currentKey in finance.salaryPaidRounds) return finance
        val pending = if (currentKey in finance.salaryOutstanding) finance else finance.copy(
            salaryPaidRounds = if (requested <= 0L) finance.salaryPaidRounds + currentKey else finance.salaryPaidRounds
        )
        return settle(pending, currentKey, season, round)
    }

    private fun settle(finance: TeamFinanceState, currentKey: String, season: Int, round: Int): TeamFinanceState {
        var next = finance
        val ordered = next.salaryOutstanding.keys.sortedWith(compareBy<String>({ it.substringBefore(':').toIntOrNull() ?: Int.MAX_VALUE }, { it.substringAfter(':').toIntOrNull() ?: Int.MAX_VALUE }))
        for (key in ordered) {
            val amount = next.salaryOutstanding[key] ?: continue
            if (amount <= 0L) {
                next = next.copy(salaryOutstanding = next.salaryOutstanding - key, salaryPaidRounds = next.salaryPaidRounds + key)
                continue
            }
            if (next.budget.coerceAtLeast(0L) < amount) break
            val s = key.substringBefore(':').toIntOrNull() ?: continue
            val r = key.substringAfter(':').toIntOrNull() ?: continue
            next = next.transact(-amount, "Salários dos pilotos — GP $r/30 — temporada $s")
                .copy(salaryOutstanding = next.salaryOutstanding - key, salaryPaidRounds = next.salaryPaidRounds + key)
        }
        if (currentKey in next.salaryOutstanding) {
            val amount = next.salaryOutstanding[currentKey] ?: 0L
            val marker = "OBRIGAÇÃO PENDENTE: €$amount de salários — GP $round/30 — temporada $season"
            if (marker !in next.transactions) next = next.copy(transactions = (next.transactions + marker).takeLast(2000))
        }
        return next.copy(budget = next.budget.coerceAtLeast(0L))
    }
}

/**
 * Signing fees are paid from cash in equal installments over the GPs remaining after
 * signature. The schedule is durable and idempotent; accounting recognition is no longer
 * mistaken for a cash payment.
 */
internal object SignatureFeeAccounting {
    fun register(
        finance:TeamFinanceState, fee:Long, description:String, targetSeason:Int? = null,
        startRound:Int = 1, installmentCount:Int = (31 - startRound).coerceIn(1, 30)
    ):TeamFinanceState {
        if (fee <= 0L) return finance
        val season = targetSeason ?: Regex("(?:temporada|para|—)\\s*(20\\d{2})", RegexOption.IGNORE_CASE)
            .findAll(description).lastOrNull()?.groupValues?.getOrNull(1)?.toIntOrNull() ?: return finance
        val id = java.util.Base64.getUrlEncoder().withoutPadding().encodeToString(description.toByteArray(Charsets.UTF_8)) + ":$season:$fee:$startRound:$installmentCount"
        if (finance.signatureFeeSchedules.any { it.id == id }) return finance
        return finance.copy(signatureFeeSchedules=finance.signatureFeeSchedules + SignatureFeeSchedule(
            id=id, amount=fee, season=season, startRound=startRound.coerceIn(1,30),
            installmentCount=installmentCount.coerceIn(1,30)
        ))
    }

    fun recognizeForRace(finance:TeamFinanceState, season:Int, round:Int):TeamFinanceState {
        if (round !in 1..30) return finance
        var next = finance
        val updated = next.signatureFeeSchedules.map { schedule ->
            if (schedule.season != season || round < schedule.startRound) return@map schedule
            val count = schedule.installmentCount.coerceIn(1, 30)
            var paidRounds = schedule.paidRounds
            // Retry every unpaid installment whose due GP has passed, oldest first.
            // This prevents a temporarily insufficient balance from silently erasing a fee.
            val lastDueRound = minOf(round, schedule.startRound + count - 1)
            for (dueRound in schedule.startRound..lastDueRound) {
                if (dueRound in paidRounds) continue
                val base = schedule.amount / count
                val installment = base + if (dueRound == schedule.startRound + count - 1) schedule.amount % count else 0L
                if (next.budget.coerceAtLeast(0L) < installment) {
                    val marker = "TAXA DE CONTRATAÇÃO PENDENTE: €$installment — GP $dueRound/$count — $season — ${schedule.id}"
                    if (marker !in next.transactions) next = next.copy(transactions=(next.transactions + marker).takeLast(2000))
                    // Do not skip this installment; older obligations must be paid first.
                    break
                }
                next = next.transact(-installment, "Parcela taxa de contratação — GP $dueRound (liquidada no GP $round) — temporada $season")
                next = next.copy(transactions=(next.transactions + "0:PARCELA TAXA [${schedule.id}] GP $dueRound/$count — €$installment").takeLast(2000))
                paidRounds = paidRounds + dueRound
            }
            schedule.copy(paidRounds = paidRounds)
        }
        return next.copy(signatureFeeSchedules=updated)
    }
}

data class ManagerProfile(val id:Int=1, val name:String="Chefe de Equipe", val reputation:Int=50, val experience:Int=0)

data class TeamManagerState(
    val season:Int=2026,
    val round:Int=1,
    val playerTeamId:Int=1,
    val car:TeamCarState,
    val facilities:TeamFacilitiesState = TeamFacilitiesState(),
    val facilityUpgrade:FacilityUpgradeState? = null,
    /** Two-car physical garage is the sole race-performance source; TeamCarState is the seasonal development state. */
    val garage:TeamGarage? = null,
    /** New R&D pipeline: projects become designs and never mutate a physical car directly. */
    val research:TeamResearchState = TeamResearchState(),
    val factory:TeamFactoryState = TeamFactoryState(),
    val finance:TeamFinanceState,
    val manager:ManagerProfile=ManagerProfile(),
    val contracts:List<DriverContract> = emptyList(),
    val driverMarket:DriverMarketState = DriverMarketState(),
    val staff:List<StaffMember> = emptyList(),
    val sponsor:SponsorContract = SponsorContract("Patrocinador Base",0,0,0,1,0,1,0,0,0,0,false),
    val sponsors:List<SponsorContract> = emptyList(),
    val engineSupplier:SupplierContract = SupplierContract(SupplierType.ENGINE,"Apex Power",85,85,10_000_000,1),
    val tyreSupplier:SupplierContract = SupplierContract(SupplierType.TYRE,"Pirelli",85,85,8_000_000,1),
    val history:List<String> = emptyList(),
    /** Persistent driver attributes used by the manager-season simulation path. */
    val driverEvolutionAttributes:Map<Int,List<Int>> = emptyMap(),
    val driverEvolutionAnnualGains:Map<Int,List<Int>> = emptyMap(),
    val driverEvolutionBanks:Map<Int,Double> = emptyMap(),
    /** Frozen opening-season target (1..80) derived from the team-strength ranking at season start. */
    val driverEvolutionSeasonTargets:Map<Int,Int> = emptyMap(),
    /** Career-cycle phase: GROWING, PEAK or REGRESSION. */
    val driverEvolutionPhases:Map<Int,String> = emptyMap(),
    /** GP counter inside the current career-cycle phase. */
    val driverEvolutionPhaseGps:Map<Int,Int> = emptyMap(),
    /** Overall at the exact start of the current phase; frozen until the phase ends. */
    val driverEvolutionPhaseStart:Map<Int,Int> = emptyMap(),
    /** Target Overall of the current phase (class ceiling or class floor). */
    val driverEvolutionPhaseTarget:Map<Int,Int> = emptyMap(),
    /** Accumulated evidence used only to anticipate an early phase transition. */
    val driverEvolutionPhasePressure:Map<Int,Double> = emptyMap(),
    /** Durable career-state marker: driver evolution already applied for season:round. */
    val driverEvolutionProcessedRounds:Set<String> = emptySet(),
    /** Persistent facility programs that accelerate selected drivers. */
    val driverDevelopment:DriverDevelopmentState = DriverDevelopmentState(),
    /** Annual technical-investment ceiling shared by P&D, fabrication and facility upgrades. */
    val technicalInvestment:TechnicalInvestmentState = TechnicalInvestmentEngine.create(2026, 40)
)
