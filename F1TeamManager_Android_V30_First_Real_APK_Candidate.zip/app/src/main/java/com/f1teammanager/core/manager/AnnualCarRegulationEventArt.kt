package com.f1teammanager.core.manager

import androidx.annotation.DrawableRes
import com.f1teammanager.R

/**
 * V445: maps each regulation catalog event to existing bundled artwork.
 * No new image files are generated: the same six generic component illustrations
 * are reused across the three rules for each component.
 */
object AnnualCarRegulationEventArt {
    @DrawableRes
    fun drawableFor(event: AnnualCarRegulationEngine.Event): Int = drawableFor(event.component)

    @DrawableRes
    fun drawableFor(eventId: String): Int {
        val event = AnnualCarRegulationEngine.catalog().firstOrNull { it.id == eventId }
            ?: return R.drawable.event_annual_car_loss
        return drawableFor(event.component)
    }

    @DrawableRes
    fun drawableFor(component: CarComponent): Int = when (component) {
        CarComponent.ENGINE -> R.drawable.event_engine_failure
        CarComponent.CHASSIS -> R.drawable.event_suspension_damage
        CarComponent.FRONT_WING -> R.drawable.event_front_wing_damage
        CarComponent.REAR_WING -> R.drawable.event_loose_part
        CarComponent.BRAKES -> R.drawable.event_critical_degradation
        CarComponent.ELECTRIC_POWER_UNIT -> R.drawable.event_electric_failure
    }
}
