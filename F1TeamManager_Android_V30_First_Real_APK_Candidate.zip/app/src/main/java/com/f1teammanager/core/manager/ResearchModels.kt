package com.f1teammanager.core.manager

enum class ResearchFocus { PERFORMANCE, RELIABILITY, BALANCED }
enum class ResearchComplexity { SIMPLE, MEDIUM, ADVANCED, EXPERIMENTAL }
enum class ResearchOutcome { SUCCESS, PARTIAL, FAILURE }

data class ResearchProject(
    val projectId: String,
    val component: CarComponent,
    val version: Int,
    val basePerformance: Int,
    val baseReliability: Int,
    val targetPerformance: Int,
    val targetReliability: Int,
    val totalWeeks: Int,
    val remainingWeeks: Int,
    val cost: Long,
    val startedWeek: Int,
    val focus: ResearchFocus = ResearchFocus.BALANCED,
    val complexity: ResearchComplexity = ResearchComplexity.MEDIUM,
    val outcome: ResearchOutcome = ResearchOutcome.SUCCESS
) {
    fun normalized() = copy(
        basePerformance=basePerformance.coerceIn(40,100),
        baseReliability=baseReliability.coerceIn(40,100),
        targetPerformance=targetPerformance.coerceIn(40,100),
        targetReliability=targetReliability.coerceIn(40,100)
    )
}

data class ResearchDesign(
    val designId: String,
    val component: CarComponent,
    val version: Int,
    val performance: Int,
    val reliability: Int,
    val researchSeason: Int,
    val completedWeek: Int
) {
    fun normalized() = copy(performance=performance.coerceIn(40,100), reliability=reliability.coerceIn(40,100))
}

data class TeamResearchState(
    val activeProjects: List<ResearchProject> = emptyList(),
    val completedDesigns: List<ResearchDesign> = emptyList(),
    /** Week in which each component becomes eligible for a new research. */
    val cooldownUntil: Map<CarComponent, Int> = emptyMap()
) {
    val activeProject: ResearchProject? get() = activeProjects.firstOrNull()
    fun normalized() = copy(
        activeProjects=activeProjects.map { it.normalized() },
        completedDesigns=completedDesigns.map { it.normalized() }
    )
}


/** Resolves the actual week at which a research project finishes during a multi-week jump. */
object ResearchCompletionWeekPolicy {
    fun completionWeek(currentWeek: Int, targetWeek: Int, remainingWeeks: Int): Int {
        val current = currentWeek.coerceIn(0, 56)
        val target = targetWeek.coerceIn(current, 56)
        if (target <= current) return current
        // ResearchEngine decrements once per advanced week and completes when the
        // pre-advance remaining counter reaches one. A removed project therefore
        // completed currentWeek + remainingWeeks, not necessarily targetWeek.
        return (current + remainingWeeks.coerceAtLeast(1)).coerceIn(current + 1, target)
    }
}
