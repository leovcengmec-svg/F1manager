package com.f1teammanager.core.manager

enum class ResearchFocus { PERFORMANCE, RELIABILITY, BALANCED }
enum class ResearchComplexity { SIMPLE, MEDIUM, ADVANCED, EXPERIMENTAL }
enum class ResearchOutcome { SUCCESS, PARTIAL, FAILURE }

data class ResearchProject(
    val projectId: String,
    val component: CarComponent,
    val version: Int,
    val basePerformance: Int,
    val baseReliability: Int,
    val targetPerformance: Int,
    val targetReliability: Int,
    val totalWeeks: Int,
    val remainingWeeks: Int,
    val cost: Long,
    val startedWeek: Int,
    val focus: ResearchFocus = ResearchFocus.BALANCED,
    val complexity: ResearchComplexity = ResearchComplexity.MEDIUM,
    val outcome: ResearchOutcome = ResearchOutcome.SUCCESS
)

data class ResearchDesign(
    val designId: String,
    val component: CarComponent,
    val version: Int,
    val performance: Int,
    val reliability: Int,
    val researchSeason: Int,
    val completedWeek: Int
)

data class TeamResearchState(
    val activeProjects: List<ResearchProject> = emptyList(),
    val completedDesigns: List<ResearchDesign> = emptyList(),
    /** Week in which each component becomes eligible for a new research. */
    val cooldownUntil: Map<CarComponent, Int> = emptyMap()
) {
    val activeProject: ResearchProject? get() = activeProjects.firstOrNull()
}
