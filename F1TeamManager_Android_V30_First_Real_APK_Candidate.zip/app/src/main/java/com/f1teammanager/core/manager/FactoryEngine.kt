package com.f1teammanager.core.manager

import com.f1teammanager.core.season.WorldDatabase
import kotlin.math.ceil

/**
 * Fábrica: transforma desenhos tecnológicos em peças físicas.
 * Ela nunca aumenta o desempenho de um desenho e nunca instala uma peça
 * automaticamente em qualquer carro.
 */
class FactoryEngine {
    data class ManufacturingOption(
        val quantity: Int,
        val weeks: Int,
        val costPerUnit: Long
    )

    fun specification(facilities: TeamFacilitiesState): FactorySpecification.Level =
        FactorySpecification.level(facilities.level(FacilityType.FACTORY))

    fun options(design: ResearchDesign): List<ManufacturingOption> = options(design, TeamFacilitiesState(), 40)

    fun options(design: ResearchDesign, facilities: TeamFacilitiesState, ranking: Int = 40): List<ManufacturingOption> {
        val spec = specification(facilities)
        return (1..spec.maxUnitsPerOrder).map { quantity ->
            ManufacturingOption(
                quantity = quantity,
                weeks = manufacturingWeeks(quantity, spec),
                costPerUnit = manufacturingCost(design, spec, ranking)
            )
        }
    }

    fun manufacturingWeeks(quantity: Int, facilities: TeamFacilitiesState): Int =
        manufacturingWeeks(quantity, specification(facilities))

    private fun manufacturingWeeks(quantity: Int, spec: FactorySpecification.Level): Int {
        val baseWeeks = ceil(quantity.coerceAtLeast(1) * 1.5).toInt()
        return ceil(baseWeeks * spec.timeMultiplier).toInt().coerceAtLeast(1)
    }

    fun manufacturingCost(design: ResearchDesign, facilities: TeamFacilitiesState, ranking: Int = 40): Long =
        manufacturingCost(design, specification(facilities), ranking)

    /** Fabrication discount by technical ranking: smaller than the R&D discount. */
    fun fabricationDiscountPercentForRank(ranking: Int): Int = when (ranking.coerceIn(1, 40)) {
        in 1..10 -> 0
        in 11..20 -> 10
        in 21..30 -> 20
        else -> 30
    }

    private fun manufacturingCost(design: ResearchDesign, spec: FactorySpecification.Level, ranking: Int): Long {
        val base = (4_000_000L + design.performance.coerceIn(40, 100) * 100_000L)
            .coerceIn(8_000_000L, 14_000_000L)
        val facilityAdjusted = (base * spec.costMultiplier).toLong()
        return (facilityAdjusted * (100 - fabricationDiscountPercentForRank(ranking)).toLong() / 100L).coerceAtLeast(1_000_000L)
    }

    fun start(
        state: TeamManagerState,
        design: ResearchDesign,
        option: ManufacturingOption,
        currentWeek: Int
    ): TeamManagerState {
        val spec = specification(state.facilities)
        val ranking = TechnicalInvestmentEngine.seasonRanking(state.playerTeamId, state.car)[state.playerTeamId] ?: 40
        require(option.quantity in 1..spec.maxUnitsPerOrder) { "A Fábrica permite até ${spec.maxUnitsPerOrder} unidade(s) por ordem no nível ${spec.level}." }
        require(state.factory.activeOrders.size < spec.parallelOrders) {
            "A Fábrica está ocupada. Capacidade atual: ${spec.parallelOrders} ordem(ns) simultânea(s)."
        }
        require(state.research.completedDesigns.any { it.designId == design.designId }) { "Projeto não disponível para fabricação." }
        require(option.weeks == manufacturingWeeks(option.quantity, spec)) { "Tempo de fabricação inválido para o nível atual da Fábrica." }
        require(option.costPerUnit == manufacturingCost(design, spec, ranking)) { "Custo de fabricação inválido para o nível atual da Fábrica." }

        val total = option.costPerUnit * option.quantity
        require(state.finance.budget >= total) { "Orçamento insuficiente para fabricar as peças." }
        val technical = TechnicalInvestmentEngine.ensureSeason(state.technicalInvestment, state.season, TechnicalInvestmentEngine.seasonRanking(state.playerTeamId, state.car)[state.playerTeamId] ?: 40)
        val technicalAfter = technical.withSpend(TechnicalInvestmentCategory.FABRICATION, total)

        val order = FactoryOrder(
            orderId = "F-${state.season}-${currentWeek}-${design.designId}-${state.factory.activeOrders.size + 1}",
            designId = design.designId,
            component = design.component,
            version = design.version,
            performance = design.performance,
            reliability = design.reliability,
            quantity = option.quantity,
            remainingUnits = option.quantity,
            totalWeeks = option.weeks,
            remainingWeeks = option.weeks,
            costPerUnit = option.costPerUnit,
            startedWeek = currentWeek
        )

        return state.copy(
            factory = state.factory.copy(activeOrders = state.factory.activeOrders + order),
            // O design tecnológico permanece no histórico e pode gerar novas unidades físicas.
            // A Fábrica consome dinheiro e capacidade, não o conhecimento da equipe.
            research = state.research,
            technicalInvestment = technicalAfter,
            finance = state.finance.transact(-total, "Fábrica ${componentLabel(design.component)} V${design.version} x${option.quantity}")
        )
    }

    fun advanceWeeks(state: TeamManagerState, weeks: Int, currentWeek: Int): TeamManagerState {
        if (weeks <= 0 || state.factory.activeOrders.isEmpty()) return state
        var current = state
        var weekCursor = currentWeek
        repeat(weeks) {
            weekCursor = (weekCursor + 1).coerceAtMost(56)
            val completionWeek = weekCursor
            if (current.factory.activeOrders.isEmpty()) return@repeat
            val completed = mutableListOf<FactoryOrder>()
            val active = current.factory.activeOrders.map { order ->
                if (order.remainingWeeks > 1) order.copy(remainingWeeks = order.remainingWeeks - 1)
                else {
                    completed += order
                    null
                }
            }.filterNotNull()

            val garage = current.garage ?: TeamGarageFactory.fromCarState(
                current.car, current.playerTeamId, current.season
            )
            val completionHistory = mutableListOf<String>()
            completed.forEach { order ->
                repeat(order.remainingUnits) { n ->
                    val piece = CarPiece(
                        pieceId = "${order.orderId}-U${n + 1}",
                        component = order.component,
                        version = order.version,
                        performance = order.performance,
                        reliability = order.reliability,
                        manufacturedWeek = completionWeek
                    )
                    // No stock: manufacturing creates the physical piece, but the
                    // MANAGER remains responsible for choosing Car 1 or Car 2.
                    // The pending list is a handoff state, not an inventory system.
                    completionHistory += "Fábrica concluída: ${componentLabel(piece.component)} V${piece.version} pronta para instalação. O Manager deve escolher Carro 1 ou Carro 2."
                }
            }
            current = current.copy(
                factory = current.factory.copy(
                    activeOrders = active,
                    pendingInstallations = current.factory.pendingInstallations + completed.flatMap { order ->
                        (0 until order.remainingUnits).map { n ->
                            CarPiece(
                                pieceId = "${order.orderId}-U${n + 1}",
                                component = order.component,
                                version = order.version,
                                performance = order.performance,
                                reliability = order.reliability,
                                manufacturedWeek = completionWeek
                            )
                        }
                    }
                ),
                garage = garage,
                history = current.history + completionHistory
            )
        }
        return current
    }

    private fun componentLabel(c: CarComponent): String = when (c) {
        CarComponent.ENGINE -> "Motor - ICE"
        CarComponent.CHASSIS -> "Chassi"
        CarComponent.FRONT_WING -> "Asa dianteira"
        CarComponent.REAR_WING -> "Asa traseira"
        CarComponent.BRAKES -> "Freios"
        CarComponent.ELECTRIC_POWER_UNIT -> "MGU-K - ERS"
    }
}
