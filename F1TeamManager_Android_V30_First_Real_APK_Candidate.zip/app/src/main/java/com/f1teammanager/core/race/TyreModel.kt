package com.f1teammanager.core.race

import kotlin.math.pow

/** Fonte única das regras de pneus da corrida. */
object TyreModel {
    val dryCompounds = listOf(Tyre.SOFT, Tyre.MEDIUM, Tyre.HARD)
    val wetCompounds = listOf(Tyre.INTERMEDIATE, Tyre.WET)
    val planIds = listOf("A", "B", "C", "D")

    /** Approved strategy influence, relative to the GP average lap time. */
    fun strategyMultiplier(mode: DriverStrategyMode): Double = when (mode) {
        DriverStrategyMode.ATTACK -> 0.990
        DriverStrategyMode.BALANCED -> 1.000
        DriverStrategyMode.DEFENSE -> 1.010
    }

    /**
     * New-tyre performance is proportional to the GP average lap time.
     * Lower multiplier = faster lap. Slicks are inappropriate in rain; rain tyres
     * are inappropriate on dry track.
     */
    fun performanceMultiplier(tyre: Tyre, weather: Weather): Double = when (weather) {
        Weather.DRY, Weather.CLOUDY -> when (tyre) {
            Tyre.SOFT -> 0.980
            Tyre.MEDIUM -> 0.990
            Tyre.HARD -> 1.000
            Tyre.INTERMEDIATE -> 1.080
            Tyre.WET -> 1.120
        }
        Weather.LIGHT_RAIN -> when (tyre) {
            Tyre.SOFT, Tyre.MEDIUM, Tyre.HARD -> 1.080
            Tyre.INTERMEDIATE -> 1.000
            Tyre.WET -> 1.060
        }
        Weather.MEDIUM_RAIN -> when (tyre) {
            Tyre.SOFT, Tyre.MEDIUM, Tyre.HARD -> 1.150
            Tyre.INTERMEDIATE -> 1.000
            Tyre.WET -> 1.050
        }
        Weather.HEAVY_RAIN -> when (tyre) {
            Tyre.SOFT, Tyre.MEDIUM, Tyre.HARD -> 1.300
            Tyre.INTERMEDIATE -> 1.100
            Tyre.WET -> 1.000
        }
    }

    /** Degradation is also relative to the GP average lap time, not fixed ms. */
    fun degradationMultiplier(wearPercent: Int): Double {
        val w = wearPercent.coerceIn(0, 100) / 100.0
        return when {
            w <= 0.20 -> 1.000
            w <= 0.40 -> 1.0025
            w <= 0.60 -> 1.0075
            w <= 0.80 -> 1.0150
            else -> 1.0300
        }
    }

    /** Applies tyre, degradation and strategy to the already calculated car/driver pace. */
    fun applyLapModifiers(
        carDriverLapMs: Long,
        gpAverageLapMs: Long,
        tyre: Tyre,
        weather: Weather,
        wearPercent: Int,
        mode: DriverStrategyMode
    ): Long {
        val base = carDriverLapMs.coerceAtLeast(45_000L).toDouble()
        val reference = gpAverageLapMs.coerceAtLeast(45_000L).toDouble()
        val tyreFactor = performanceMultiplier(tyre, weather)
        val degradation = degradationMultiplier(wearPercent)
        val strategy = strategyMultiplier(mode)
        // All three approved influences scale from the GP average-lap reference.
        // Their deltas are applied to the current car/driver pace so they remain
        // proportional across fast and slow circuits without using fixed milliseconds.
        val tyreDelta = reference * (tyreFactor - 1.0)
        val degradationDelta = reference * (degradation - 1.0)
        val strategyDelta = reference * (strategy - 1.0)
        return (base + tyreDelta + degradationDelta + strategyDelta).toLong().coerceAtLeast(45_000L)
    }

    /** Fuel effect relative to GP average lap time, continuously interpolated. */
    fun fuelMultiplier(fuelPercent: Double): Double {
        val x = fuelPercent.coerceIn(0.0, 100.0)
        val points = listOf(
            0.0 to 1.000,
            10.0 to 1.001,
            25.0 to 1.003,
            50.0 to 1.007,
            75.0 to 1.011,
            100.0 to 1.015
        )
        val upper = points.firstOrNull { x <= it.first } ?: points.last()
        val lower = points.lastOrNull { it.first <= x } ?: points.first()
        if (upper.first == lower.first) return upper.second
        val t = (x - lower.first) / (upper.first - lower.first)
        return lower.second + (upper.second - lower.second) * t
    }

    fun fuelPenaltyMultiplier(fuelPercent: Double): Double = fuelMultiplier(fuelPercent)

    fun tyreWeatherWearFactor(tyre: Tyre, weather: Weather): Double = when (weather) {
        Weather.DRY -> when (tyre) {
            Tyre.SOFT, Tyre.MEDIUM, Tyre.HARD -> 1.0
            Tyre.INTERMEDIATE, Tyre.WET -> 2.50
        }
        Weather.CLOUDY -> when (tyre) {
            Tyre.SOFT, Tyre.MEDIUM, Tyre.HARD -> 1.0
            Tyre.INTERMEDIATE, Tyre.WET -> 1.80
        }
        Weather.LIGHT_RAIN, Weather.MEDIUM_RAIN, Weather.HEAVY_RAIN -> when (tyre) {
            // Slicks do NOT wear faster because of rain; they simply lose performance.
            Tyre.SOFT, Tyre.MEDIUM, Tyre.HARD -> 1.0
            Tyre.INTERMEDIATE, Tyre.WET -> 0.90
        }
    }

    fun strategyWearFactor(mode: DriverStrategyMode): Double = when (mode) {
        DriverStrategyMode.ATTACK -> 1.10
        DriverStrategyMode.BALANCED -> 1.00
        DriverStrategyMode.DEFENSE -> 0.90
    }

    fun buildDryPlans(totalLaps: Int): Map<String, TyrePlan> {
        require(totalLaps > 0) { "A corrida precisa ter pelo menos 1 volta" }

        data class Candidate(val sequence: List<Tyre>, val capacity: Int, val stops: Int, val score: Double)
        val candidates = mutableListOf<Candidate>()

        fun generate(prefix: List<Tyre>) {
            if (prefix.isNotEmpty()) {
                val capacity = prefix.sumOf { it.targetLaps }
                if (capacity >= totalLaps) {
                    val performance = prefix.sumOf {
                        when (it) {
                            Tyre.SOFT -> 3.0
                            Tyre.MEDIUM -> 2.0
                            Tyre.HARD -> 1.0
                            else -> 0.0
                        }
                    }
                    val over = capacity - totalLaps
                    candidates += Candidate(prefix, capacity, prefix.size - 1, prefix.size * 100.0 + over * 0.8 - performance * 4.0)
                }
            }
            if (prefix.size >= 4) return
            dryCompounds.forEach { generate(prefix + it) }
        }
        generate(emptyList())

        val distinct = candidates.distinctBy { it.sequence }
            .sortedWith(compareBy<Candidate> { it.score }.thenBy { it.capacity })

        // Primeiro escolhemos a melhor estratégia geral e, depois, a melhor estratégia
        // que contém cada composto seco. Assim A/B/C/D são realmente diferentes e o
        // conjunto sempre cobre Soft, Medium e Hard sem criar planos artificiais.
        val selected = mutableListOf<Candidate>()
        fun addBest(predicate: (Candidate) -> Boolean) {
            distinct.firstOrNull { it.sequence !in selected.map { s -> s.sequence } && predicate(it) }?.let { selected += it }
        }
        addBest { true }
        dryCompounds.forEach { compound -> addBest { compound in it.sequence } }
        if (selected.size < 4) {
            distinct.forEach {
                if (selected.size < 4 && it.sequence !in selected.map { s -> s.sequence }) selected += it
            }
        }
        require(selected.size >= 4) { "Não foi possível gerar 4 planos de pneus válidos para ${totalLaps} voltas" }

        return planIds.mapIndexed { index, id ->
            val candidate = selected[index]
            TyrePlan(id, candidate.sequence, candidate.sequence.map { it.targetLaps })
        }.associateBy { it.id }
    }
}
