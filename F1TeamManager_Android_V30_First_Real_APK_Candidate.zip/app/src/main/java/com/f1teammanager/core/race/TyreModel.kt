package com.f1teammanager.core.race

import kotlin.math.pow

/** Resultado compartilhado da validação do plano livre (interface e motor). */
data class FreeTyrePlanValidation(
    val requiredLaps: Int,
    val plannedLaps: Int,
    val coveragePercent: Int,
    val coverageComplete: Boolean,
    val safe: Boolean,
    val valid: Boolean,
    val status: String,
    val issues: List<String>
)

/** Fonte única das regras de pneus da corrida. */
object TyreModel {
    val dryCompounds = listOf(Tyre.SOFT, Tyre.MEDIUM, Tyre.HARD)
    val wetCompounds = listOf(Tyre.INTERMEDIATE, Tyre.WET)
    val planIds = listOf("A", "B", "C", "D")
    const val MANUAL_TYRE_WARNING_WEAR_PERCENT = 80
    const val AUTOMATIC_TYRE_CHANGE_WEAR_PERCENT = 85
    private const val PIT_LOSS_MS = 21_000L

    /** Nublado é pista seca; compostos de chuva não devem ser escolhidos pela IA. */
    fun isDryTrack(weather: Weather): Boolean = weather == Weather.DRY || weather == Weather.CLOUDY

    /** Canonical compound correction for automated decisions; cloudy is always dry. */
    fun compoundForWeather(weather: Weather, requested: Tyre, remainingLaps: Int): Tyre = when {
        isDryTrack(weather) && requested in wetCompounds -> dryCompoundForRemainingLaps(remainingLaps)
        weather == Weather.HEAVY_RAIN && requested != Tyre.WET -> Tyre.WET
        weather in listOf(Weather.LIGHT_RAIN, Weather.MEDIUM_RAIN) && requested != Tyre.INTERMEDIATE -> Tyre.INTERMEDIATE
        else -> requested
    }

    fun dryCompoundForRemainingLaps(remainingLaps: Int): Tyre = when {
        remainingLaps <= 12 -> Tyre.SOFT
        remainingLaps <= 24 -> Tyre.MEDIUM
        else -> Tyre.HARD
    }

    /** Approved strategy influence, relative to the GP average lap time. */
    fun strategyMultiplier(mode: DriverStrategyMode): Double = when (mode) {
        DriverStrategyMode.ATTACK -> 0.990
        DriverStrategyMode.BALANCED -> 1.000
        DriverStrategyMode.DEFENSE -> 1.010
    }

    /**
     * New-tyre performance is proportional to the GP average lap time.
     * Lower multiplier = faster lap. Slicks are inappropriate in rain; rain tyres
     * are inappropriate on dry track.
     */
    fun performanceMultiplier(tyre: Tyre, weather: Weather): Double = when (weather) {
        Weather.DRY, Weather.CLOUDY -> when (tyre) {
            Tyre.SOFT -> 0.980
            Tyre.MEDIUM -> 0.990
            Tyre.HARD -> 1.000
            // Compostos de chuva no seco provocam perda severa de ritmo.
            // Penalidade explícita: +18% intermediário e +28% WET antes de degradação.
            Tyre.INTERMEDIATE -> 1.180
            Tyre.WET -> 1.280
        }
        Weather.LIGHT_RAIN -> when (tyre) {
            Tyre.SOFT, Tyre.MEDIUM, Tyre.HARD -> 1.080
            Tyre.INTERMEDIATE -> 1.000
            Tyre.WET -> 1.060
        }
        Weather.MEDIUM_RAIN -> when (tyre) {
            Tyre.SOFT, Tyre.MEDIUM, Tyre.HARD -> 1.150
            Tyre.INTERMEDIATE -> 1.000
            Tyre.WET -> 1.050
        }
        Weather.HEAVY_RAIN -> when (tyre) {
            Tyre.SOFT, Tyre.MEDIUM, Tyre.HARD -> 1.300
            Tyre.INTERMEDIATE -> 1.100
            Tyre.WET -> 1.000
        }
    }

    /** Degradation is also relative to the GP average lap time, not fixed ms. */
    fun degradationMultiplier(wearPercent: Int): Double {
        val w = wearPercent.coerceIn(0, 100) / 100.0
        return when {
            w <= 0.20 -> 1.000
            w <= 0.40 -> 1.0025
            w <= 0.60 -> 1.0075
            w <= 0.80 -> 1.0150
            else -> 1.0300
        }
    }

    /** Applies tyre, degradation and strategy to the already calculated car/driver pace. */
    fun applyLapModifiers(
        carDriverLapMs: Long,
        gpAverageLapMs: Long,
        tyre: Tyre,
        weather: Weather,
        wearPercent: Int,
        mode: DriverStrategyMode
    ): Long {
        val base = carDriverLapMs.coerceAtLeast(45_000L).toDouble()
        val reference = gpAverageLapMs.coerceAtLeast(45_000L).toDouble()
        val tyreFactor = performanceMultiplier(tyre, weather)
        val degradation = degradationMultiplier(wearPercent)
        val strategy = strategyMultiplier(mode)
        // All three approved influences scale from the GP average-lap reference.
        // Their deltas are applied to the current car/driver pace so they remain
        // proportional across fast and slow circuits without using fixed milliseconds.
        val tyreDelta = reference * (tyreFactor - 1.0)
        val degradationDelta = reference * (degradation - 1.0)
        val strategyDelta = reference * (strategy - 1.0)
        return (base + tyreDelta + degradationDelta + strategyDelta).toLong().coerceAtLeast(45_000L)
    }

    /** Fuel effect relative to GP average lap time, continuously interpolated. */
    fun fuelMultiplier(fuelPercent: Double): Double {
        val x = fuelPercent.coerceIn(0.0, 100.0)
        val points = listOf(
            0.0 to 1.000,
            10.0 to 1.001,
            25.0 to 1.003,
            50.0 to 1.007,
            75.0 to 1.011,
            100.0 to 1.015
        )
        val upper = points.firstOrNull { x <= it.first } ?: points.last()
        val lower = points.lastOrNull { it.first <= x } ?: points.first()
        if (upper.first == lower.first) return upper.second
        val t = (x - lower.first) / (upper.first - lower.first)
        return lower.second + (upper.second - lower.second) * t
    }

    fun fuelPenaltyMultiplier(fuelPercent: Double): Double = fuelMultiplier(fuelPercent)

    fun tyreWeatherWearFactor(tyre: Tyre, weather: Weather): Double = when (weather) {
        Weather.DRY -> when (tyre) {
            Tyre.SOFT, Tyre.MEDIUM, Tyre.HARD -> 1.0
            // Sobre-aquecimento e desgaste extremo quando a pista está seca.
            Tyre.INTERMEDIATE, Tyre.WET -> 4.00
        }
        Weather.CLOUDY -> when (tyre) {
            Tyre.SOFT, Tyre.MEDIUM, Tyre.HARD -> 1.0
            // Nublado é pista seca: ainda há forte degradação de pneus de chuva.
            Tyre.INTERMEDIATE, Tyre.WET -> 3.00
        }
        Weather.LIGHT_RAIN, Weather.MEDIUM_RAIN, Weather.HEAVY_RAIN -> when (tyre) {
            // Slicks do NOT wear faster because of rain; they simply lose performance.
            Tyre.SOFT, Tyre.MEDIUM, Tyre.HARD -> 1.0
            Tyre.INTERMEDIATE, Tyre.WET -> 0.90
        }
    }

    fun strategyWearFactor(mode: DriverStrategyMode): Double = when (mode) {
        DriverStrategyMode.ATTACK -> 1.10
        DriverStrategyMode.BALANCED -> 1.00
        DriverStrategyMode.DEFENSE -> 0.90
    }

    /**
     * Gera quatro planos A/B/C/D coerentes com a intensidade da chuva.
     * Chuva fraca/moderada: somente INTERMEDIÁRIO.
     * Chuva forte: somente WET.
     * Os planos variam o número/distribuição dos stints, nunca oferecem o composto
     * inadequado como alternativa dentro dos planos automáticos.
     */
    /** Vida útil estimada até o limite operacional de troca, já considerando clima e ritmo. */
    fun estimatedStintLifeLaps(
        tyre: Tyre,
        weather: Weather,
        mode: DriverStrategyMode = DriverStrategyMode.BALANCED,
        driverTyreWear: Int = 50,
        wearLimitPercent: Int = AUTOMATIC_TYRE_CHANGE_WEAR_PERCENT
    ): Int {
        val driverFactor = (1.0 - DriverAttributeInfluence.tyre(driverTyreWear)).coerceIn(0.90, 1.10)
        val perLapWear = (100.0 / tyre.targetLaps.coerceAtLeast(1)) *
            tyreWeatherWearFactor(tyre, weather) * strategyWearFactor(mode) * driverFactor
        return (wearLimitPercent.coerceIn(1, 99) / perLapWear).toInt().coerceAtLeast(1)
    }

    /**
     * Valida um plano livre para a distância exata que falta no GP.
     * Um plano só é aprovado quando cobre todas as voltas, possui de 1 a 6 stints,
     * respeita a janela de desgaste automático (85%) e usa compostos adequados ao clima.
     */
    fun validateFreePlan(
        requiredLaps: Int,
        weather: Weather,
        mode: DriverStrategyMode,
        driverTyreWear: Int,
        sequence: List<Tyre>,
        stintLaps: List<Int>
    ): FreeTyrePlanValidation {
        val required = requiredLaps.coerceAtLeast(0)
        val planned = stintLaps.sum()
        val issues = mutableListOf<String>()

        if (required <= 0) issues += "Não há voltas restantes para planejar."
        if (sequence.isEmpty()) issues += "Adicione pelo menos um stint."
        if (sequence.size > 6) issues += "O limite é de seis stints."
        if (sequence.size != stintLaps.size) issues += "Cada stint precisa ter um composto e uma quantidade de voltas."
        if (stintLaps.any { it <= 0 }) issues += "Cada stint precisa ter pelo menos uma volta."
        if (planned < required) issues += "Faltam ${required - planned} voltas para cobrir o GP."
        if (planned > required) issues += "O plano excede o GP em ${planned - required} voltas."

        sequence.indices.forEach { index ->
            val tyre = sequence[index]
            val laps = stintLaps.getOrNull(index) ?: return@forEach
            if (laps <= 0) return@forEach
            val suitable = when (weather) {
                Weather.DRY, Weather.CLOUDY -> tyre in dryCompounds
                Weather.LIGHT_RAIN, Weather.MEDIUM_RAIN -> tyre == Tyre.INTERMEDIATE
                Weather.HEAVY_RAIN -> tyre == Tyre.WET
            }
            if (!suitable) {
                val expected = when (weather) {
                    Weather.DRY, Weather.CLOUDY -> "Macio, Médio ou Duro"
                    Weather.LIGHT_RAIN, Weather.MEDIUM_RAIN -> "Intermediário"
                    Weather.HEAVY_RAIN -> "Chuva (WET)"
                }
                issues += "Stint ${index + 1}: composto ${tyre.name} incompatível com o clima; esperado $expected."
            }
            val maxLife = estimatedStintLifeLaps(
                tyre, weather, mode, driverTyreWear, AUTOMATIC_TYRE_CHANGE_WEAR_PERCENT
            )
            if (laps > maxLife) {
                issues += "Stint ${index + 1}: $laps voltas excedem a janela segura de $maxLife voltas (${tyre.name})."
            }
        }

        val countValid = sequence.size in 1..6 && sequence.size == stintLaps.size && stintLaps.all { it > 0 }
        val coverageComplete = required > 0 && planned == required && countValid
        val safe = countValid && issues.none {
            it.contains("incompatível") || it.contains("excedem a janela")
        }
        val valid = coverageComplete && safe && issues.isEmpty()
        val coverage = if (required > 0) ((planned.coerceAtLeast(0) * 100.0) / required).toInt().coerceIn(0, 100) else 0
        val status = when {
            sequence.isEmpty() -> "ADICIONE STINTS PARA COMEÇAR"
            planned < required -> "FALTAM ${required - planned} VOLTAS • COBERTURA $coverage%"
            planned > required -> "EXCEDE ${planned - required} VOLTAS • AJUSTE O PLANO"
            !countValid -> "ESTRUTURA INVÁLIDA • REVISE OS STINTS"
            !safe -> "100% COBERTO, MAS HÁ STINT INSEGURO"
            valid -> "APTO • COBRE 100% DO GP"
            else -> "REVISE O PLANO PARA VALIDAR"
        }
        return FreeTyrePlanValidation(required, planned, coverage, coverageComplete, safe, valid, status, issues)
    }

    /**
     * Builds an independent race strategy for an AI driver. The plan is based on
     * that driver's tyre management, pace and race craft, the team's car strength,
     * grid position and a stable per-driver seed. Unlike the old AI rule, this does
     * not cycle through a fixed SOFT/MEDIUM/HARD sequence.
     */
    fun buildAiRaceStrategy(
        totalLaps: Int,
        weather: Weather,
        driverTyreWear: Int,
        driverSpeed: Int,
        consistency: Int,
        overtaking: Int,
        defense: Int,
        teamPace: Int,
        gridPosition: Int,
        fieldSize: Int,
        strategySeed: Int
    ): TyrePlan {
        require(totalLaps > 0) { "A estratégia da IA precisa cobrir pelo menos uma volta" }

        val tyreSkill = driverTyreWear.coerceIn(40, 100)
        val carStrength = teamPace.coerceIn(40, 100)
        val gridPressure = if (fieldSize > 1) {
            ((gridPosition.coerceIn(1, fieldSize) - (fieldSize + 1) / 2.0) / fieldSize) * 12.0
        } else 0.0
        // Positive values favour an attacking race: softer opening compounds and
        // a greater willingness to trade a pit stop for pace. Tyre-management skill
        // deliberately pushes the profile toward longer, lower-risk stints.
        val seedOffset = Math.floorMod(strategySeed, 17) - 8
        val aggression = (
            (driverSpeed.coerceIn(40, 100) - 60) * 0.22 +
                (overtaking.coerceIn(40, 100) - 60) * 0.12 +
                (consistency.coerceIn(40, 100) - 60) * 0.08 +
                (defense.coerceIn(40, 100) - 60) * 0.06 +
                (carStrength - 60) * 0.20 +
                (50 - tyreSkill) * 0.22 +
                gridPressure + seedOffset * 0.55
            ).coerceIn(-24.0, 24.0)
        val mode = when {
            aggression >= 9.0 -> DriverStrategyMode.ATTACK
            aggression <= -9.0 -> DriverStrategyMode.DEFENSE
            else -> DriverStrategyMode.BALANCED
        }
        val preferredStart = when {
            aggression >= 10.0 || (driverTyreWear <= 38 && driverSpeed >= 70) -> Tyre.SOFT
            aggression <= -4.0 || (driverTyreWear >= 65 && driverSpeed <= 78) -> Tyre.HARD
            else -> Tyre.MEDIUM
        }

        if (!isDryTrack(weather)) {
            val compound = if (weather == Weather.HEAVY_RAIN) Tyre.WET else Tyre.INTERMEDIATE
            val maxStint = estimatedStintLifeLaps(compound, weather, mode, tyreSkill)
            val minimumStints = ((totalLaps + maxStint - 1) / maxStint).coerceAtLeast(1)
            val extraStint = when {
                aggression >= 15.0 && totalLaps - minimumStints * maxStint > -maxStint / 3 -> 1
                aggression <= -12.0 -> 0
                Math.floorMod(strategySeed, 4) == 0 -> 1
                else -> 0
            }
            val stintCount = (minimumStints + extraStint).coerceAtMost(6).coerceAtMost(totalLaps)
            require(stintCount * maxStint >= totalLaps) {
                "A estratégia de chuva não cobre as $totalLaps voltas"
            }
            val laps = MutableList(stintCount) { totalLaps / stintCount }
            var remaining = totalLaps - laps.sum()
            val offset = Math.floorMod(strategySeed, stintCount)
            var cursor = 0
            while (remaining > 0) {
                val index = (offset + cursor) % stintCount
                if (laps[index] < maxStint) {
                    laps[index]++
                    remaining--
                }
                cursor++
                if (cursor > stintCount * maxStint * 2) break
            }
            require(remaining == 0 && laps.all { it in 1..maxStint }) {
                "Não foi possível distribuir os stints de chuva com segurança"
            }
            return TyrePlan("AI", List(stintCount) { compound }, laps)
        }

        data class Candidate(val sequence: List<Tyre>, val stintLaps: List<Int>, val score: Double)
        val candidates = mutableListOf<Candidate>()
        val dryWearFactor = (1.0 - DriverAttributeInfluence.tyre(tyreSkill)).coerceIn(0.90, 1.10)
        val maxLife = dryCompounds.associateWith {
            estimatedStintLifeLaps(it, weather, mode, tyreSkill, AUTOMATIC_TYRE_CHANGE_WEAR_PERCENT)
        }

        fun allocate(sequence: List<Tyre>): List<Int>? {
            val capacities = sequence.map { maxLife.getValue(it) }
            if (capacities.sum() < totalLaps) return null
            val allocated = MutableList(sequence.size) { 0 }
            repeat(totalLaps) {
                val nextStint = sequence.indices
                    .filter { allocated[it] < capacities[it] }
                    .minByOrNull { index ->
                        val tyre = sequence[index]
                        val nextLap = allocated[index] + 1
                        val wear = (nextLap * 100.0 / tyre.targetLaps * dryWearFactor)
                            .toInt().coerceIn(0, AUTOMATIC_TYRE_CHANGE_WEAR_PERCENT)
                        val projected = applyLapModifiers(
                            90_000L, 90_000L, tyre, weather, wear, mode
                        ).toDouble()
                        // Stable, very small tie-breaker avoids every AI car choosing
                        // the first slot when two compounds have equal marginal pace.
                        projected + Math.floorMod(strategySeed + index * 7 + nextLap * 3, 11) * 0.7
                    } ?: return null
                allocated[nextStint]++
            }
            return allocated.takeIf { it.all { laps -> laps > 0 } }
        }

        fun score(sequence: List<Tyre>, stintLaps: List<Int>): Double {
            var projectedTime = 0.0
            sequence.indices.forEach { index ->
                val tyre = sequence[index]
                repeat(stintLaps[index]) { lapIndex ->
                    val wear = ((lapIndex + 1) * 100.0 / tyre.targetLaps * dryWearFactor)
                        .toInt().coerceIn(0, AUTOMATIC_TYRE_CHANGE_WEAR_PERCENT)
                    projectedTime += applyLapModifiers(90_000L, 90_000L, tyre, weather, wear, mode)
                }
            }
            val stops = (sequence.size - 1).coerceAtLeast(0)
            val softStints = sequence.count { it == Tyre.SOFT }
            val hardStints = sequence.count { it == Tyre.HARD }
            val startBias = if (sequence.first() == preferredStart) -8_500.0 else 2_000.0
            val compoundPreferenceBias = when (preferredStart) {
                Tyre.SOFT -> -1_100.0 * softStints + 650.0 * hardStints
                Tyre.MEDIUM -> -850.0 * sequence.count { it == Tyre.MEDIUM } + 250.0 * softStints
                Tyre.HARD -> -1_100.0 * hardStints + 650.0 * softStints
                else -> 0.0
            }
            val stopPreferenceBias = -aggression * 900.0 * stops
            val raceStyleBias = stopPreferenceBias + compoundPreferenceBias
            val stableTieBreak = Math.floorMod(strategySeed * 31 + sequence.hashCode(), 997) * 1.1
            return projectedTime + stops * PIT_LOSS_MS + startBias + raceStyleBias + stableTieBreak
        }

        fun generate(prefix: List<Tyre>) {
            if (prefix.isNotEmpty()) {
                val laps = allocate(prefix)
                if (laps != null) candidates += Candidate(prefix, laps, score(prefix, laps))
            }
            if (prefix.size >= 4) return
            dryCompounds.forEach { compound ->
                if (prefix.lastOrNull() != compound) generate(prefix + compound)
            }
        }
        generate(emptyList())
        val best = candidates.minByOrNull { it.score }
        if (best != null) return TyrePlan("AI", best.sequence, best.stintLaps)

        // Extremely long custom events may exceed the normal four-stint race plan.
        // Keep the fallback safe and compliant by alternating HARD/MEDIUM instead
        // of reverting to a single-compound sequence.
        val fallbackCompounds = if (Math.floorMod(strategySeed, 2) == 0) {
            listOf(Tyre.HARD, Tyre.MEDIUM)
        } else {
            listOf(Tyre.MEDIUM, Tyre.HARD)
        }
        val fallbackSequence = mutableListOf<Tyre>()
        val fallbackLaps = mutableListOf<Int>()
        var remainingFallbackLaps = totalLaps
        while (remainingFallbackLaps > 0) {
            val tyre = fallbackCompounds[fallbackSequence.size % fallbackCompounds.size]
            val stintLaps = minOf(maxLife.getValue(tyre), remainingFallbackLaps)
            fallbackSequence += tyre
            fallbackLaps += stintLaps
            remainingFallbackLaps -= stintLaps
        }
        return TyrePlan("AI", fallbackSequence, fallbackLaps)
    }

    /**
     * Gera quatro planos A/B/C/D coerentes com a intensidade da chuva.
     * Os stints respeitam o limite operacional de 85% de desgaste e a soma
     * das voltas planejadas é sempre exatamente a distância restante.
     */
    fun buildPlansForWeather(totalLaps: Int, weather: Weather): Map<String, TyrePlan> {
        if (isDryTrack(weather)) return buildDryPlans(totalLaps)
        require(totalLaps > 0) { "A corrida precisa ter pelo menos 1 volta" }

        val idealTyre = when (weather) {
            Weather.LIGHT_RAIN, Weather.MEDIUM_RAIN -> Tyre.INTERMEDIATE
            Weather.HEAVY_RAIN -> Tyre.WET
            else -> return buildDryPlans(totalLaps)
        }
        val maxStintLaps = estimatedStintLifeLaps(idealTyre, weather)
        val minimumStints = ((totalLaps + maxStintLaps - 1) / maxStintLaps).coerceAtLeast(1)
        require(minimumStints <= 4) {
            "Não é possível cobrir $totalLaps voltas com quatro stints de $idealTyre até 85% de desgaste"
        }

        fun distribution(stintCount: Int, variant: Int): List<Int> {
            val laps = MutableList(stintCount) { 1 }
            var remaining = totalLaps - stintCount
            // Distribui de forma equilibrada, sem ultrapassar a janela de 85%.
            while (remaining > 0) {
                var changed = false
                for (offset in 0 until stintCount) {
                    val index = (offset + variant) % stintCount
                    if (laps[index] < maxStintLaps && remaining > 0) {
                        laps[index]++
                        remaining--
                        changed = true
                    }
                }
                if (!changed) break
            }
            require(remaining == 0) { "Plano de chuva excedeu a capacidade de quatro stints" }
            return laps
        }

        return planIds.mapIndexed { index, id ->
            val stintCount = (minimumStints + index).coerceAtMost(minOf(4, totalLaps))
            val laps = distribution(stintCount, index)
            require(laps.sum() == totalLaps && laps.all { it in 1..maxStintLaps }) {
                "Plano $id inválido para $idealTyre: $laps / $totalLaps voltas"
            }
            TyrePlan(id, List(stintCount) { idealTyre }, laps)
        }.associateBy { it.id }
    }

    fun buildDryPlans(totalLaps: Int): Map<String, TyrePlan> {
        require(totalLaps > 0) { "A corrida precisa ter pelo menos 1 volta" }

        data class Candidate(val sequence: List<Tyre>, val laps: List<Int>, val projectedTimeMs: Long)
        val candidates = mutableListOf<Candidate>()
        val weather = Weather.DRY
        val mode = DriverStrategyMode.BALANCED
        val maxLife = dryCompounds.associateWith { estimatedStintLifeLaps(it, weather, mode) }

        fun allocate(sequence: List<Tyre>): List<Int>? {
            if (sequence.size > totalLaps) return null
            val capacities = sequence.map { maxLife.getValue(it) }
            if (capacities.sum() < totalLaps) return null
            val laps = MutableList(sequence.size) { 1 }
            var remaining = totalLaps - sequence.size
            while (remaining > 0) {
                var changed = false
                for (i in sequence.indices) {
                    if (laps[i] < capacities[i] && remaining > 0) {
                        laps[i]++
                        remaining--
                        changed = true
                    }
                }
                if (!changed) return null
            }
            return laps
        }

        fun projectedTime(sequence: List<Tyre>, stintLaps: List<Int>): Long {
            var total = 0L
            sequence.indices.forEach { stintIndex ->
                val tyre = sequence[stintIndex]
                val wearPerLap = 100.0 / tyre.targetLaps.coerceAtLeast(1)
                repeat(stintLaps[stintIndex]) { lapIndex ->
                    val wear = ((lapIndex + 1) * wearPerLap).toInt().coerceAtMost(AUTOMATIC_TYRE_CHANGE_WEAR_PERCENT)
                    // Usa a mesma escala relativa ao tempo médio da volta adotada pela simulação.
                    total += applyLapModifiers(90_000L, 90_000L, tyre, weather, wear, mode)
                }
            }
            return total + (sequence.size - 1).coerceAtLeast(0) * PIT_LOSS_MS
        }

        fun generate(prefix: List<Tyre>) {
            if (prefix.isNotEmpty()) {
                val laps = allocate(prefix)
                if (laps != null) candidates += Candidate(prefix, laps, projectedTime(prefix, laps))
            }
            if (prefix.size >= 4) return
            dryCompounds.forEach { compound ->
                if (prefix.lastOrNull() != compound) generate(prefix + compound)
            }
        }
        generate(emptyList())

        val distinct = candidates.distinctBy { it.sequence }
            .sortedWith(compareBy<Candidate> { it.projectedTimeMs }.thenBy { it.sequence.size })
        val selected = mutableListOf<Candidate>()
        fun addBest(predicate: (Candidate) -> Boolean) {
            distinct.firstOrNull { candidate -> selected.none { it.sequence == candidate.sequence } && predicate(candidate) }
                ?.let(selected::add)
        }
        addBest { true }
        // Mantém alternativas estratégicas que cobrem os três compostos secos,
        // mas agora cada alternativa é ranqueada pelo tempo estimado + perda no box.
        dryCompounds.forEach { compound -> addBest { compound in it.sequence } }
        if (selected.size < 4) distinct.forEach { candidate ->
            if (selected.size < 4 && selected.none { it.sequence == candidate.sequence }) selected += candidate
        }
        // Em uma volta restante existem apenas três opções fisicamente distintas
        // (um composto por stint); ainda assim, a interface mantém os quatro IDs.
        while (selected.size < 4) selected += distinct[selected.size % distinct.size]

        return planIds.mapIndexed { index, id ->
            val candidate = selected[index]
            TyrePlan(id, candidate.sequence, candidate.laps)
        }.associateBy { it.id }
    }
}
