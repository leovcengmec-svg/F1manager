package com.f1teammanager.core.manager

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

/** Regulation event card intentionally matches the existing AnnualTeamEventCard layout. */
@Composable
fun AnnualCarRegulationEventCard(
    event: AnnualCarRegulationEngine.Event,
    season: Int,
    modifier: Modifier = Modifier,
) {
    Card(modifier = modifier.fillMaxWidth()) {
        Column {
            Image(
                painter = painterResource(AnnualCarRegulationEventArt.drawableFor(event)),
                contentDescription = "Ilustração genérica: ${event.component.displayNameForRegulation()}",
                modifier = Modifier.fillMaxWidth().height(164.dp),
                contentScale = ContentScale.Crop,
            )
            Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
                Text(event.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(
                    "Componente: ${event.component.displayNameForRegulation()}",
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(top = 6.dp),
                )
                Text(
                    "Redução de desempenho: ${event.reductionPercent}%",
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(top = 4.dp),
                )
                Text(
                    "Temporada $season • Regulamento anual • ${event.id}",
                    style = MaterialTheme.typography.labelSmall,
                    modifier = Modifier.padding(top = 8.dp),
                )
            }
        }
    }
}

private fun CarComponent.displayNameForRegulation(): String = when (this) {
    CarComponent.ENGINE -> "Motor"
    CarComponent.CHASSIS -> "Chassi"
    CarComponent.FRONT_WING -> "Asa dianteira"
    CarComponent.REAR_WING -> "Asa traseira"
    CarComponent.BRAKES -> "Freios"
    CarComponent.ELECTRIC_POWER_UNIT -> "MGU-K / unidade de potência elétrica"
}
