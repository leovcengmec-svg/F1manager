package com.f1teammanager.core.manager

import androidx.compose.foundation.Image
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

/** Regulation event card intentionally matches the existing AnnualTeamEventCard layout. */
@Composable
fun AnnualCarRegulationEventCard(
    event: AnnualCarRegulationEngine.Event,
    season: Int,
    modifier: Modifier = Modifier,
) {
    val cardShape = RoundedCornerShape(16.dp)
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = cardShape,
        colors = CardDefaults.cardColors(containerColor = Color(0xFF15171D)),
        border = BorderStroke(1.dp, Color(0xFF2B2F36)),
    ) {
        Column {
            // The artwork contains its own red title/ribbon at the bottom. Match the
            // source 600×330 ratio instead of cropping it into a shorter fixed-height box.
            Image(
                painter = painterResource(AnnualCarRegulationEventArt.drawableFor(event)),
                contentDescription = "Ilustração: ${event.component.displayNameForRegulation()}",
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(600f / 330f)
                    .background(Color(0xFF0B1016))
                    .clip(RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp)),
                contentScale = ContentScale.Fit,
            )
            Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp)) {
                Text(
                    event.name,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    lineHeight = MaterialTheme.typography.titleMedium.lineHeight
                )
                Text(
                    "Componente: ${event.component.displayNameForRegulation()}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color(0xFFE8E9ED),
                    modifier = Modifier.padding(top = 6.dp),
                )
                Text(
                    "Redução de desempenho: ${event.reductionPercent}%",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color(0xFFE8E9ED),
                    modifier = Modifier.padding(top = 4.dp),
                )
                Text(
                    "Temporada $season • Regulamento anual • ${event.id}",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color(0xFFB0BDCC),
                    modifier = Modifier.padding(top = 8.dp),
                )
            }
        }
    }
}

private fun CarComponent.displayNameForRegulation(): String = when (this) {
    CarComponent.ENGINE -> "Motor"
    CarComponent.CHASSIS -> "Chassi"
    CarComponent.FRONT_WING -> "Asa dianteira"
    CarComponent.REAR_WING -> "Asa traseira"
    CarComponent.BRAKES -> "Freios"
    CarComponent.ELECTRIC_POWER_UNIT -> "MGU-K / unidade de potência elétrica"
}
