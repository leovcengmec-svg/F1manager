package com.f1teammanager.core.manager

import com.f1teammanager.core.race.RaceCircuit
import com.f1teammanager.core.race.RaceResult
import com.f1teammanager.core.race.RaceWeekendEngine
import com.f1teammanager.core.season.SeasonState
import com.f1teammanager.core.season.WorldDatabase
import com.f1teammanager.core.season.toParticipant

class ManagerSeasonEngine(private val seed:Int=20261003) {
    private val development=CarDevelopmentEngine()
    private val finance=FinanceEngine()
    private val ai=AIManagerEngine()
    private val dynamicGrid=DynamicGridEngine()

    data class RoundOutcome(val state:TeamManagerState,val season:SeasonState,val race:RaceResult)

    fun currentGrid(manager: TeamManagerState): List<DynamicGridEngine.GridDriver> {
        val market = if (manager.driverMarket.contracts.isEmpty()) {
            DriverMarketEngine().initialState(manager.season)
        } else manager.driverMarket
        return dynamicGrid.snapshot(market)
    }

    fun validateGrid(manager: TeamManagerState): List<String> {
        val market = if (manager.driverMarket.contracts.isEmpty()) DriverMarketEngine().initialState(manager.season) else manager.driverMarket
        return dynamicGrid.validate(market)
    }

    fun runRound(manager:TeamManagerState, season:SeasonState):RoundOutcome {
        require(manager.round == season.currentRound) { "Estado do manager e temporada fora de sincronia" }
        require(manager.round in 1..WorldDatabase.rounds.size) { "Temporada encerrada" }
        val rd=WorldDatabase.rounds[manager.round-1]
        val team=WorldDatabase.teams.first { it.id==manager.playerTeamId }
        val performanceModifier=ai.performanceModifier(manager.staff,manager.sponsor,manager.engineSupplier,manager.tyreSupplier)
        val participants=dynamicGrid.participants(
            manager.driverMarket, manager.car, manager.playerTeamId, performanceModifier, manager.round, manager.season, (rd.weekOfSeason - 1).coerceAtLeast(0)
        ).map { p ->
            if (p.teamId==manager.playerTeamId) p.copy(
                reliability=(p.reliability + (manager.engineSupplier.reliability-50)/10).coerceIn(1,100)
            ) else p
        }
        val circuit=RaceCircuit(rd.round,rd.circuit,rd.laps,rd.baseLapTimeMs,rd.powerFactor,rd.overtakingFactor,crashRisk=rd.crashRisk,reliabilityRisk=rd.reliabilityRisk,safetyCarRisk=rd.safetyCarRisk)
        val race=RaceWeekendEngine(seed+manager.round).race(participants,circuit)
        val playerEntries=race.classification.filter { it.teamName==team.name }
        val teamPoints=playerEntries.sumOf { race.points[it.driverId] ?: 0 }
        val bestFinish=playerEntries.minOfOrNull { if(it.status=="DNF") 999 else it.position } ?: 999
        val dnf=playerEntries.all { it.status=="DNF" }
        var next=finance.applyRace(manager,bestFinish,teamPoints,dnf)
        next=development.advanceRound(next)
        next=next.copy(round=manager.round+1, manager=next.manager.copy(experience=next.manager.experience+1,reputation=(next.manager.reputation + if(teamPoints>0) 1 else 0).coerceAtMost(100)))
        val seasonNext=advanceSeason(season,race)
        return RoundOutcome(next,seasonNext,race)
    }


    private fun advanceSeason(state:SeasonState,race:RaceResult):SeasonState {
        val points=state.standings.toMutableMap(); val wins=state.wins.toMutableMap(); val pods=state.podiums.toMutableMap(); val starts=state.starts.toMutableMap()
        race.classification.forEach { f ->
            if(f.status!="DNF") starts[f.driverId]=(starts[f.driverId]?:0)+1
            points[f.driverId]=(points[f.driverId]?:0)+(race.points[f.driverId]?:0)
            if(f.status!="DNF" && f.position==1) wins[f.driverId]=(wins[f.driverId]?:0)+1
            if(f.status!="DNF" && f.position<=3) pods[f.driverId]=(pods[f.driverId]?:0)+1
        }
        return state.copy(currentRound=state.currentRound+1,standings=points,wins=wins,podiums=pods,starts=starts)
    }
}
