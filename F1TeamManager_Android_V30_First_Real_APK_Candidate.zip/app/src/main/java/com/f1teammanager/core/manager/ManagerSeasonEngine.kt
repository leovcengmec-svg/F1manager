package com.f1teammanager.core.manager

import com.f1teammanager.core.race.RaceCircuit
import com.f1teammanager.core.race.RaceResult
import com.f1teammanager.core.race.CareerWeekendEngine
import com.f1teammanager.core.season.SeasonState
import com.f1teammanager.core.season.WorldDatabase
import com.f1teammanager.core.season.toParticipant
import com.f1teammanager.core.season.DriverDefinition
import com.f1teammanager.core.season.DriverEvolutionEngine

class ManagerSeasonEngine(private val seed:Int=20261003) {
    private val development=CarDevelopmentEngine()
    private val finance=FinanceEngine()
    private val ai=AIManagerEngine()
    private val dynamicGrid=DynamicGridEngine()
    private val aiSponsorship=TeamSponsorshipEngine(seed + 6000)
    private val aiFinance=AITeamFinancialEngine(seed + 7000)
    private val aiDevelopmentFinance=AITeamDevelopmentEngine(seed + 8000)

    data class RoundOutcome(val state:TeamManagerState,val season:SeasonState,val race:RaceResult)

    fun currentGrid(manager: TeamManagerState): List<DynamicGridEngine.GridDriver> {
        val market = if (manager.driverMarket.contracts.isEmpty()) {
            DriverMarketEngine().initialState(manager.season)
        } else manager.driverMarket
        return dynamicGrid.snapshot(market)
    }

    fun validateGrid(manager: TeamManagerState): List<String> {
        val market = if (manager.driverMarket.contracts.isEmpty()) DriverMarketEngine().initialState(manager.season) else manager.driverMarket
        return dynamicGrid.validate(market)
    }

    fun runRound(manager:TeamManagerState, season:SeasonState):RoundOutcome {
        require(manager.round == season.currentRound) { "Estado do manager e temporada fora de sincronia" }
        require(manager.round in 1..WorldDatabase.rounds.size) { "Temporada encerrada" }
        var managerState = if (manager.round == 1) finance.applyAnnualDriverSalaries(manager, manager.season) else manager
        if (manager.round == 1) aiFinance.ensureAllTeams(manager.season, manager.playerTeamId, manager.driverMarket)
        val rd=WorldDatabase.rounds[manager.round-1]
        val team=WorldDatabase.teams.first { it.id==manager.playerTeamId }
        val performanceModifier=ai.performanceModifier(manager.staff,manager.sponsor,manager.engineSupplier,manager.tyreSupplier)
        val driverOverrides = manager.driverEvolutionAttributes.mapNotNull { (id,a) ->
            val base = WorldDatabase.allDrivers.firstOrNull { it.id == id } ?: return@mapNotNull null
            if (a.size != 7) return@mapNotNull null
            id to base.copy(speed=a[0], qualifying=a[1], overtaking=a[2], defense=a[3], consistency=a[4], wet=a[5], tyre=a[6])
        }.toMap()
        val participants=dynamicGrid.participants(
            manager.driverMarket, manager.car, manager.playerTeamId, performanceModifier, manager.round, manager.season, (rd.weekOfSeason - 1).coerceAtLeast(0), driverOverrides
        ).map { p ->
            if (p.teamId==manager.playerTeamId) p.copy(
                reliability=(p.reliability + (manager.engineSupplier.reliability-50)/10).coerceIn(1,100)
            ) else p
        }
        val circuit=RaceCircuit(rd.round,rd.circuit,rd.laps,rd.baseLapTimeMs,rd.powerFactor,rd.overtakingFactor,crashRisk=rd.crashRisk,reliabilityRisk=rd.reliabilityRisk,safetyCarRisk=rd.safetyCarRisk)
        val race=simulateHeadlessWeekend(participants,circuit,team.id,seed+manager.round)
        val playerEntries=race.classification.filter { it.teamName==team.name }
        val teamPoints=playerEntries.sumOf { race.points[it.driverId] ?: 0 }
        val bestFinish=playerEntries.minOfOrNull { if(it.status=="DNF") 999 else it.position } ?: 999
        val dnf=playerEntries.all { it.status=="DNF" }
        var next=finance.applyRace(managerState,bestFinish,teamPoints,dnf)
        val carBefore = next.car
        next=development.advanceWeeks(next, 1)
        val carAfter = next.car
        next=applyDriverEvolution(next, race)

        // Persist only real, material changes in the seasonal news feed.
        var marketState = next.driverMarket
        val week = rd.weekOfSeason
        val teamOverallBefore = (carBefore.aerodynamics + carBefore.chassis + carBefore.engine + carBefore.reliability) / 4
        val teamOverallAfter = (carAfter.aerodynamics + carAfter.chassis + carAfter.engine + carAfter.reliability) / 4
        if (teamOverallAfter != teamOverallBefore) {
            val teamName = team.name
            val direction = if (teamOverallAfter > teamOverallBefore) "subiu" else "caiu"
            marketState = marketState.copy(notifications = marketState.notifications + MarketNotification(
                next.season, week, "EVOLUÇÃO DE EQUIPE",
                "$teamName evoluiu. Overall da equipe $direction de $teamOverallBefore para $teamOverallAfter.", true, MarketNewsCategory.TEAM_EVOLUTION
            )).normalized()
        }

        // AI teams use the same virtual R&D model as the race grid. Compare the
        // virtual state week-to-week so every relevant AI development can reach
        // the central news feed, not only the player's team.
        val aiDevelopment = AITeamDevelopmentEngine(seed + manager.round)
        val elapsed = (week - 1).coerceAtLeast(0)
        WorldDatabase.teams.filter { it.id != next.playerTeamId }.forEach { aiTeam ->
            val beforeAi = aiDevelopment.simulate(aiTeam, (elapsed - 1).coerceAtLeast(0), next.season)
            val afterAi = aiDevelopment.simulate(aiTeam, elapsed, next.season)
            val beforeAiOverall = (beforeAi.aerodynamics + beforeAi.chassis + beforeAi.engine + beforeAi.reliability) / 4
            val afterAiOverall = (afterAi.aerodynamics + afterAi.chassis + afterAi.engine + afterAi.reliability) / 4
            if (afterAiOverall != beforeAiOverall) {
                val changed = listOf(
                    CarComponent.FRONT_WING to (afterAi.frontWing - beforeAi.frontWing),
                    CarComponent.REAR_WING to (afterAi.rearWing - beforeAi.rearWing),
                    CarComponent.CHASSIS to (afterAi.chassis - beforeAi.chassis),
                    CarComponent.ENGINE to (afterAi.engine - beforeAi.engine),
                    CarComponent.BRAKES to (afterAi.brakes - beforeAi.brakes),
                    CarComponent.ELECTRIC_POWER_UNIT to (afterAi.electricPowerUnit - beforeAi.electricPowerUnit)
                ).filter { it.second != 0 }.maxByOrNull { kotlin.math.abs(it.second) }
                val componentName = when (changed?.first) {
                    CarComponent.FRONT_WING -> "Asa dianteira"
                    CarComponent.REAR_WING -> "Asa traseira"
                    CarComponent.CHASSIS -> "Chassi"
                    CarComponent.ENGINE -> "Unidade de potência"
                    CarComponent.BRAKES -> "Freios"
                    CarComponent.ELECTRIC_POWER_UNIT -> "Unidade elétrica"
                    else -> "carro"
                }
                val direction = if (afterAiOverall > beforeAiOverall) "subiu" else "caiu"
                marketState = marketState.copy(notifications = marketState.notifications + MarketNotification(
                    next.season, week, "EVOLUÇÃO DE EQUIPE",
                    "${aiTeam.name} evoluiu o $componentName. Overall da equipe $direction de $beforeAiOverall para $afterAiOverall.", true, MarketNewsCategory.TEAM_EVOLUTION
                )).normalized()
            }
        }
        WorldDatabase.allDrivers.forEach { d ->
            val before = manager.driverEvolutionAttributes[d.id] ?: listOf(d.speed,d.qualifying,d.overtaking,d.defense,d.consistency,d.wet,d.tyre)
            val after = next.driverEvolutionAttributes[d.id] ?: before
            val overallBefore = before.sum() / 7
            val overallAfter = after.sum() / 7
            val delta = overallAfter - overallBefore
            if (delta != 0) {
                val sign = if (delta > 0) "evoluiu" else "regrediu"
                val amount = kotlin.math.abs(delta)
                marketState = marketState.copy(notifications = marketState.notifications + MarketNotification(
                    next.season, week, "EVOLUÇÃO DE PILOTO",
                    "${d.name} $sign para Overall $overallAfter, ${if (delta > 0) "+$amount" else "-$amount"} ponto(s).", true, MarketNewsCategory.DRIVER_EVOLUTION
                )).normalized()
            }
        }
        val currentWeek = rd.weekOfSeason
        val marketBeforeAi = marketState
        marketState = DriverMarketEngine(seed + manager.round).processAiMarketWeek(marketState, next.season, currentWeek, next.playerTeamId)
        val marketEngine = DriverMarketEngine(seed + manager.round)
        WorldDatabase.teams.filter { it.id != next.playerTeamId }.forEach { aiTeam ->
            aiFinance.applyNewDeals(aiTeam.id, next.season, marketBeforeAi, marketState, marketEngine)
        }
        next = next.copy(driverMarket = marketState)
        next=next.copy(round=manager.round+1, manager=next.manager.copy(experience=next.manager.experience+1,reputation=(next.manager.reputation + if(teamPoints>0) 1 else 0).coerceAtMost(100)))
        aiSponsorship.advanceAllTeams(next.season, manager.round, next.playerTeamId)
        WorldDatabase.teams.filter { it.id != next.playerTeamId }.forEach { aiTeam ->
            val devBudget = aiDevelopmentFinance.simulateFinancial(aiTeam, elapsed + 1, next.season).budget
            aiFinance.applyDevelopmentCost(aiTeam.id, next.season, devBudget)
        }
        WorldDatabase.teams.filter { it.id != next.playerTeamId }.forEach { aiTeam ->
            val sponsorState = aiSponsorship.forTeam(aiTeam.id, next.season)
            aiFinance.applySponsorshipSignings(aiTeam.id, next.season, sponsorState)
            val aiMarket = next.driverMarket
            aiFinance.applyRace(aiTeam.id, next.season, manager.round, sponsorState, aiMarket, bestFinish = 20, points = 0)
        }
        var seasonNext=advanceSeason(season,race)
        // GP 30 closes the season. Resolve all future contracts first, then reset
        // championship counters and reopen the new season at GP 1. Salaries are
        // intentionally charged on the first GP of the new season, not here.
        if (manager.round == WorldDatabase.rounds.size) {
            val nextSeasonNumber = season.season + 1
            // Final Constructors' standings are derived from the completed
            // drivers' championship using the contracts that were active in
            // the just-finished season. The prize is credited once, before
            // the market transition and next-season opening.
            val currentSeasonTeamPoints = next.driverMarket.contracts
                .filter { it.activeIn(season.season) }
                .groupBy { it.teamId }
                .mapValues { (_, deals) -> deals.sumOf { seasonNext.standings[it.driverId] ?: 0 } }
            val settlements = SeasonSettlementEngine.settleAll(currentSeasonTeamPoints)
            settlements.forEach { settlement ->
                if (settlement.teamId == next.playerTeamId) {
                    next = finance.applySeasonConstructorsPrize(next, season.season, settlement.position)
                } else {
                    aiFinance.applySeasonConstructorsPrize(settlement.teamId, season.season, settlement.position)
                }
            }
            // Debt is allowed during the season. The technical penalty is applied
            // to the newly constructed next-season car, after normal construction.
            WorldDatabase.teams.filter { it.id != next.playerTeamId }.forEach { aiTeam ->
                aiFinance.applyEndOfSeasonFinancialPenalty(aiTeam.id, season.season)
            }
            // Build the next-season car first. The financial penalty is then
            // applied to that finished car, so it cannot be overwritten by
            // the normal annual construction process.
            next = development.startNextSeason(next, nextSeasonNumber)
            next = FinancialSeasonClosureEngine.applyPlayerPenalty(next)
            val nextBudgets = WorldDatabase.teams.associate { aiTeam ->
                aiTeam.id to if (aiTeam.id == next.playerTeamId) next.finance.budget else aiFinance.state(aiTeam.id, season.season).finance.budget
            }
            val transitionedMarket = DriverMarketEngine(seed + 90000 + nextSeasonNumber).applySeasonTransition(
                next.driverMarket, nextSeasonNumber, nextBudgets
            )
            next = next.copy(
                season = nextSeasonNumber,
                round = 1,
                driverMarket = transitionedMarket
            )
            seasonNext = SeasonState(season = nextSeasonNumber, currentRound = 1)
        }
        return RoundOutcome(next,seasonNext,race)
    }

    /** Run the same full-field interactive race engine used by MainActivity,
     * automatically resolving manager decisions for audit/headless seasons. */
    private fun simulateHeadlessWeekend(
        participants: List<com.f1teammanager.core.race.RaceParticipant>,
        circuit: RaceCircuit,
        playerTeamId: Int,
        raceSeed: Int
    ): RaceResult {
        val engine = CareerWeekendEngine(raceSeed)
        var snapshot = engine.start(participants, circuit, playerTeamId)
        repeat(3) { snapshot = engine.simulateQualifyingPhase() }
        var guard = 0
        while (!snapshot.completed) {
            require(++guard <= circuit.laps * 8 + 100) { "Corrida headless excedeu o limite de segurança" }
            val decision = snapshot.decision
            snapshot = if (decision != null) {
                if (decision.request.type == com.f1teammanager.core.race.ManagerDecisionType.RED_FLAG) {
                    engine.chooseRedFlag(com.f1teammanager.core.race.Tyre.MEDIUM, com.f1teammanager.core.race.DriverPosture.BALANCED)
                } else {
                    engine.choose(com.f1teammanager.core.race.ManagerDecisionAction.STAY_OUT)
                }
            } else {
                engine.advance()
            }
        }
        return engine.result()
    }

    fun applyDriverEvolution(manager: TeamManagerState, race: RaceResult): TeamManagerState {
        val attrs = manager.driverEvolutionAttributes.toMutableMap()
        val annual = manager.driverEvolutionAnnualGains.toMutableMap()
        val banks = manager.driverEvolutionBanks.toMutableMap()
        val active = manager.driverMarket.contracts.map { it.driverId }.toSet()
        val teamByDriver = manager.driverMarket.contracts.associate { it.driverId to it.teamId }
        val byTeam = race.classification.groupBy { teamByDriver[it.driverId] ?: -1 }
        WorldDatabase.allDrivers.forEach { base ->
            val currentA = attrs[base.id]?.toIntArray() ?: intArrayOf(base.speed,base.qualifying,base.overtaking,base.defense,base.consistency,base.wet,base.tyre)
            var current = base.copy(speed=currentA[0],qualifying=currentA[1],overtaking=currentA[2],defense=currentA[3],consistency=currentA[4],wet=currentA[5],tyre=currentA[6])
            val gains = (annual[base.id]?.toIntArray() ?: IntArray(7))
            val cap = com.f1teammanager.core.season.DriverProfileCatalog.maxAnnualGain(current.evolution)
            var bank = banks[base.id] ?: 0.0
            val intended = if (base.id in active) {
                val own = race.classification.firstOrNull { it.driverId == base.id }
                if (own == null) 0 else {
                    val teammate = byTeam[teamByDriver[base.id] ?: -1].orEmpty().filter { it.driverId != base.id }.map { if (it.status.startsWith("DNF")) 80 else it.position }
                    val target = DriverEvolutionEngine.Target(
                        ((WorldDatabase.teams.firstOrNull { it.id == (teamByDriver[base.id] ?: 0) }?.baseCar ?: 50).let { 81 - ((it.coerceIn(1,100) - 1) * 79 / 99) }).coerceIn(1,80)
                    )
                    DriverEvolutionEngine.weeklyDelta(current,target, listOf(if (own.status.startsWith("DNF")) 80 else own.position), emptyList(), teammate, race.points[base.id] ?: 0, 1, gains.sum())
                }
            } else {
                bank += cap.toDouble() * 7.0 / WorldDatabase.rounds.size.coerceAtLeast(1) * 0.70
                0
            }
            if (base.id in active) {
                bank += cap.toDouble() * 7.0 / WorldDatabase.rounds.size.coerceAtLeast(1) * (if (intended > 0) 1.0 else 0.0)
            }
            var delta = intended
            while (bank >= 1.0 && gains.any { it < cap }) { delta++; bank -= 1.0 }
            if (delta > 0) current = DriverEvolutionEngine.applyPositiveGain(current,delta,gains,kotlin.random.Random(seed + manager.season*1000 + manager.round*97 + base.id*31))
            attrs[base.id] = listOf(current.speed,current.qualifying,current.overtaking,current.defense,current.consistency,current.wet,current.tyre)
            annual[base.id] = gains.toList()
            banks[base.id] = bank
        }
        return manager.copy(driverEvolutionAttributes=attrs,driverEvolutionAnnualGains=annual,driverEvolutionBanks=banks)
    }

    private fun advanceSeason(state:SeasonState,race:RaceResult):SeasonState {
        val points=state.standings.toMutableMap(); val wins=state.wins.toMutableMap(); val pods=state.podiums.toMutableMap(); val starts=state.starts.toMutableMap()
        race.classification.forEach { f ->
            if(f.status!="DNF") starts[f.driverId]=(starts[f.driverId]?:0)+1
            points[f.driverId]=(points[f.driverId]?:0)+(race.points[f.driverId]?:0)
            if(f.status!="DNF" && f.position==1) wins[f.driverId]=(wins[f.driverId]?:0)+1
            if(f.status!="DNF" && f.position<=3) pods[f.driverId]=(pods[f.driverId]?:0)+1
        }
        return state.copy(currentRound=state.currentRound+1,standings=points,wins=wins,podiums=pods,starts=starts)
    }
}
