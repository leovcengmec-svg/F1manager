package com.f1teammanager.core.manager

import com.f1teammanager.core.race.RaceCircuit
import com.f1teammanager.core.race.RaceResult
import com.f1teammanager.core.race.RaceWeekendEngine
import com.f1teammanager.core.season.SeasonState
import com.f1teammanager.core.season.WorldDatabase
import com.f1teammanager.core.season.toParticipant
import com.f1teammanager.core.season.DriverDefinition
import com.f1teammanager.core.season.DriverEvolutionEngine

class ManagerSeasonEngine(private val seed:Int=20261003) {
    private val development=CarDevelopmentEngine()
    private val finance=FinanceEngine()
    private val ai=AIManagerEngine()
    private val dynamicGrid=DynamicGridEngine()

    data class RoundOutcome(val state:TeamManagerState,val season:SeasonState,val race:RaceResult)

    fun currentGrid(manager: TeamManagerState): List<DynamicGridEngine.GridDriver> {
        val market = if (manager.driverMarket.contracts.isEmpty()) {
            DriverMarketEngine().initialState(manager.season)
        } else manager.driverMarket
        return dynamicGrid.snapshot(market)
    }

    fun validateGrid(manager: TeamManagerState): List<String> {
        val market = if (manager.driverMarket.contracts.isEmpty()) DriverMarketEngine().initialState(manager.season) else manager.driverMarket
        return dynamicGrid.validate(market)
    }

    fun runRound(manager:TeamManagerState, season:SeasonState):RoundOutcome {
        require(manager.round == season.currentRound) { "Estado do manager e temporada fora de sincronia" }
        require(manager.round in 1..WorldDatabase.rounds.size) { "Temporada encerrada" }
        val rd=WorldDatabase.rounds[manager.round-1]
        val team=WorldDatabase.teams.first { it.id==manager.playerTeamId }
        val performanceModifier=ai.performanceModifier(manager.staff,manager.sponsor,manager.engineSupplier,manager.tyreSupplier)
        val driverOverrides = manager.driverEvolutionAttributes.mapNotNull { (id,a) ->
            val base = WorldDatabase.allDrivers.firstOrNull { it.id == id } ?: return@mapNotNull null
            if (a.size != 7) return@mapNotNull null
            id to base.copy(speed=a[0], qualifying=a[1], overtaking=a[2], defense=a[3], consistency=a[4], wet=a[5], tyre=a[6])
        }.toMap()
        val participants=dynamicGrid.participants(
            manager.driverMarket, manager.car, manager.playerTeamId, performanceModifier, manager.round, manager.season, (rd.weekOfSeason - 1).coerceAtLeast(0), driverOverrides
        ).map { p ->
            if (p.teamId==manager.playerTeamId) p.copy(
                reliability=(p.reliability + (manager.engineSupplier.reliability-50)/10).coerceIn(1,100)
            ) else p
        }
        val circuit=RaceCircuit(rd.round,rd.circuit,rd.laps,rd.baseLapTimeMs,rd.powerFactor,rd.overtakingFactor,crashRisk=rd.crashRisk,reliabilityRisk=rd.reliabilityRisk,safetyCarRisk=rd.safetyCarRisk)
        val race=RaceWeekendEngine(seed+manager.round).race(participants,circuit)
        val playerEntries=race.classification.filter { it.teamName==team.name }
        val teamPoints=playerEntries.sumOf { race.points[it.driverId] ?: 0 }
        val bestFinish=playerEntries.minOfOrNull { if(it.status=="DNF") 999 else it.position } ?: 999
        val dnf=playerEntries.all { it.status=="DNF" }
        var next=finance.applyRace(manager,bestFinish,teamPoints,dnf)
        val carBefore = next.car
        next=development.advanceRound(next)
        val carAfter = next.car
        next=applyDriverEvolution(next, race)

        // Persist only real, material changes in the seasonal news feed.
        var marketState = next.driverMarket
        val week = rd.weekOfSeason
        val teamOverallBefore = (carBefore.aerodynamics + carBefore.chassis + carBefore.engine + carBefore.reliability) / 4
        val teamOverallAfter = (carAfter.aerodynamics + carAfter.chassis + carAfter.engine + carAfter.reliability) / 4
        if (teamOverallAfter != teamOverallBefore) {
            val teamName = team.name
            marketState = marketState.copy(notifications = marketState.notifications + MarketNotification(
                next.season, week, "EVOLUÇÃO DE EQUIPE",
                "$teamName evoluiu. Overall da equipe subiu de $teamOverallBefore para $teamOverallAfter.", true, MarketNewsCategory.TEAM_EVOLUTION
            )).normalized()
        }
        WorldDatabase.allDrivers.forEach { d ->
            val before = manager.driverEvolutionAttributes[d.id] ?: listOf(d.speed,d.qualifying,d.overtaking,d.defense,d.consistency,d.wet,d.tyre)
            val after = next.driverEvolutionAttributes[d.id] ?: before
            val overallBefore = before.sum() / 7
            val overallAfter = after.sum() / 7
            val delta = overallAfter - overallBefore
            if (kotlin.math.abs(delta) >= 2) {
                val sign = if (delta > 0) "evoluiu" else "regrediu"
                val amount = kotlin.math.abs(delta)
                marketState = marketState.copy(notifications = marketState.notifications + MarketNotification(
                    next.season, week, "EVOLUÇÃO DE PILOTO",
                    "${d.name} $sign para Overall $overallAfter, ${if (delta > 0) "+$amount" else "-$amount"} ponto(s).", true, MarketNewsCategory.DRIVER_EVOLUTION
                )).normalized()
            }
        }
        val currentWeek = rd.weekOfSeason
        marketState = DriverMarketEngine(seed + manager.round).processAiMarketWeek(marketState, next.season, currentWeek, next.playerTeamId)
        next = next.copy(driverMarket = marketState)
        next=next.copy(round=manager.round+1, manager=next.manager.copy(experience=next.manager.experience+1,reputation=(next.manager.reputation + if(teamPoints>0) 1 else 0).coerceAtMost(100)))
        val seasonNext=advanceSeason(season,race)
        return RoundOutcome(next,seasonNext,race)
    }

    fun applyDriverEvolution(manager: TeamManagerState, race: RaceResult): TeamManagerState {
        val attrs = manager.driverEvolutionAttributes.toMutableMap()
        val annual = manager.driverEvolutionAnnualGains.toMutableMap()
        val banks = manager.driverEvolutionBanks.toMutableMap()
        val active = manager.driverMarket.contracts.map { it.driverId }.toSet()
        val teamByDriver = manager.driverMarket.contracts.associate { it.driverId to it.teamId }
        val byTeam = race.classification.groupBy { teamByDriver[it.driverId] ?: -1 }
        WorldDatabase.allDrivers.forEach { base ->
            val currentA = attrs[base.id]?.toIntArray() ?: intArrayOf(base.speed,base.qualifying,base.overtaking,base.defense,base.consistency,base.wet,base.tyre)
            var current = base.copy(speed=currentA[0],qualifying=currentA[1],overtaking=currentA[2],defense=currentA[3],consistency=currentA[4],wet=currentA[5],tyre=currentA[6])
            val gains = (annual[base.id]?.toIntArray() ?: IntArray(7))
            val cap = com.f1teammanager.core.season.DriverProfileCatalog.maxAnnualGain(current.evolution)
            var bank = banks[base.id] ?: 0.0
            val intended = if (base.id in active) {
                val own = race.classification.firstOrNull { it.driverId == base.id }
                if (own == null) 0 else {
                    val teammate = byTeam[teamByDriver[base.id] ?: -1].orEmpty().filter { it.driverId != base.id }.map { if (it.status.startsWith("DNF")) 80 else it.position }
                    val target = DriverEvolutionEngine.Target(
                        ((WorldDatabase.teams.firstOrNull { it.id == (teamByDriver[base.id] ?: 0) }?.baseCar ?: 50).let { 81 - ((it.coerceIn(1,100) - 1) * 79 / 99) }).coerceIn(1,80)
                    )
                    DriverEvolutionEngine.weeklyDelta(current,target, listOf(if (own.status.startsWith("DNF")) 80 else own.position), emptyList(), teammate, race.points[base.id] ?: 0, 1, gains.sum())
                }
            } else {
                bank += cap.toDouble() * 7.0 / WorldDatabase.rounds.size.coerceAtLeast(1) * 0.70
                0
            }
            if (base.id in active) {
                bank += cap.toDouble() * 7.0 / WorldDatabase.rounds.size.coerceAtLeast(1) * (if (intended > 0) 1.0 else 0.0)
            }
            var delta = intended
            while (bank >= 1.0 && gains.any { it < cap }) { delta++; bank -= 1.0 }
            if (delta > 0) current = DriverEvolutionEngine.applyPositiveGain(current,delta,gains,kotlin.random.Random(seed + manager.season*1000 + manager.round*97 + base.id*31))
            attrs[base.id] = listOf(current.speed,current.qualifying,current.overtaking,current.defense,current.consistency,current.wet,current.tyre)
            annual[base.id] = gains.toList()
            banks[base.id] = bank
        }
        return manager.copy(driverEvolutionAttributes=attrs,driverEvolutionAnnualGains=annual,driverEvolutionBanks=banks)
    }

    private fun advanceSeason(state:SeasonState,race:RaceResult):SeasonState {
        val points=state.standings.toMutableMap(); val wins=state.wins.toMutableMap(); val pods=state.podiums.toMutableMap(); val starts=state.starts.toMutableMap()
        race.classification.forEach { f ->
            if(f.status!="DNF") starts[f.driverId]=(starts[f.driverId]?:0)+1
            points[f.driverId]=(points[f.driverId]?:0)+(race.points[f.driverId]?:0)
            if(f.status!="DNF" && f.position==1) wins[f.driverId]=(wins[f.driverId]?:0)+1
            if(f.status!="DNF" && f.position<=3) pods[f.driverId]=(pods[f.driverId]?:0)+1
        }
        return state.copy(currentRound=state.currentRound+1,standings=points,wins=wins,podiums=pods,starts=starts)
    }
}
