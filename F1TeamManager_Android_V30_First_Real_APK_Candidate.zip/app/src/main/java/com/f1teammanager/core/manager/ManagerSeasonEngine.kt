package com.f1teammanager.core.manager

import com.f1teammanager.core.race.RaceCircuit
import com.f1teammanager.core.race.RaceResult
import com.f1teammanager.core.race.CareerWeekendEngine
import com.f1teammanager.core.season.SeasonState
import com.f1teammanager.core.season.WorldDatabase
import com.f1teammanager.core.season.SeasonCalendar
import com.f1teammanager.core.season.DriverDefinition
import com.f1teammanager.core.season.DriverEvolutionEngine
import com.f1teammanager.core.season.DriverProfileCatalog
import kotlin.math.abs

class ManagerSeasonEngine(private val seed:Int=20261003, private val regulationSeed:Int=seed) {
    private val development=CarDevelopmentEngine()
    private val finance=FinanceEngine()
    private val dynamicGrid=DynamicGridEngine()
    private val aiSponsorship=TeamSponsorshipEngine(seed + 6000)
    private val aiFinance=AITeamFinancialEngine(seed + 7000)
    private val aiDevelopmentFinance=AITeamDevelopmentEngine(seed + 8000, regulationSeed)

    companion object {
        /** V726 removes pilot-skill adjustments from season goals; older frozen maps must be rebuilt. */
        private const val CAR_ONLY_TARGET_VERSION = 1
    }

    data class RoundOutcome(val state:TeamManagerState,val season:SeasonState,val race:RaceResult)

    fun currentGrid(manager: TeamManagerState): List<DynamicGridEngine.GridDriver> {
        val market = if (manager.driverMarket.contracts.isEmpty()) {
            DriverMarketEngine().initialState(manager.season)
        } else manager.driverMarket
        return dynamicGrid.snapshot(market)
    }

    fun validateGrid(manager: TeamManagerState): List<String> {
        val market = if (manager.driverMarket.contracts.isEmpty()) DriverMarketEngine().initialState(manager.season) else manager.driverMarket
        return dynamicGrid.validate(market)
    }

    fun runRound(manager:TeamManagerState, season:SeasonState):RoundOutcome {
        val calendar = SeasonCalendar.forSeason(season.season)
        require(manager.round == season.currentRound) { "Estado do manager e temporada fora de sincronia" }
        require(manager.round in 1..calendar.size) { "Temporada encerrada" }
        var managerState = manager.normalized()
        if (managerState.round == 1) {
            val ranking = TechnicalInvestmentEngine.seasonRanking(managerState.playerTeamId, managerState.car)[managerState.playerTeamId] ?: 40
            managerState = managerState.copy(
                technicalInvestment = TechnicalInvestmentEngine.ensureSeason(
                    managerState.technicalInvestment, managerState.season, ranking
                )
            )
        }
        if (managerState.garage == null) {
            managerState = managerState.copy(garage = TeamGarageFactory.fromCarState(managerState.car, managerState.playerTeamId, managerState.season))
        }
        if (managerState.round == 1) aiFinance.ensureAllTeams(managerState.season, managerState.playerTeamId, managerState.driverMarket)
        val rd=calendar[managerState.round-1]
        val team=WorldDatabase.teams.first { it.id==managerState.playerTeamId }
        val aiGarages = mutableMapOf<Int, TeamGarage>()
        val aiFacilities = mutableMapOf<Int, TeamFacilitiesState>()
        WorldDatabase.teams.filter { it.id != managerState.playerTeamId }.forEach { aiTeam ->
            val capacity = aiFinance.developmentCapacity(aiTeam.id, managerState.season)
            val aiState = aiDevelopmentFinance.simulateFinancial(aiTeam, (rd.weekOfSeason - 1).coerceAtLeast(0), managerState.season, capacity, aiFinance.facilities(aiTeam.id), aiFinance.nextSeasonInvestmentsForTeam(aiTeam.id))
            aiGarages[aiTeam.id] = aiState.garage ?: TeamGarageFactory.fromInitial(aiTeam)
            aiFacilities[aiTeam.id] = aiState.facilities
        }
        // Advance AI driver programmes before the GP, so a programme completed during
        // the elapsed calendar weeks affects this weekend just like the player's programme.
        managerState = advanceAiDriverDevelopment(managerState, aiFacilities, rd.weekOfSeason)
        val driverOverrides = managerState.driverEvolutionAttributes.mapNotNull { (id,a) ->
            val base = WorldDatabase.allDrivers.firstOrNull { it.id == id } ?: return@mapNotNull null
            if (a.size != 7) return@mapNotNull null
            val ratings = a.map { it.coerceIn(40, 100) }
            id to base.copy(
                speed=ratings[0], qualifying=ratings[1], overtaking=ratings[2], defense=ratings[3], consistency=ratings[4], wet=ratings[5], tyre=ratings[6],
                driverClass=com.f1teammanager.core.season.DriverClassProgressionEngine.canonicalClass(
                    managerState.driverEvolutionClasses[id] ?: base.driverClass
                ) ?: base.driverClass
            ).normalized()
        }.toMap()
        // Build targets from the exact garages prepared for the opening GP only. Reuse
        // the saved map on later rounds so driver growth cannot move its own goalposts.
        val hasFrozenSeasonTargets = managerState.driverEvolutionSeasonTargetsVersion >= CAR_ONLY_TARGET_VERSION &&
            managerState.driverEvolutionSeasonTargets.size == WorldDatabase.allDrivers.size
        managerState = managerState.copy(
            driverEvolutionSeasonTargets = if (hasFrozenSeasonTargets) managerState.driverEvolutionSeasonTargets
                else buildSeasonTargets(managerState, aiGarages),
            driverEvolutionSeasonTargetsVersion = CAR_ONLY_TARGET_VERSION,
            driverEvolutionPhases = WorldDatabase.allDrivers.associate { d ->
                d.id to (managerState.driverEvolutionPhases[d.id] ?: DriverEvolutionEngine.initialPhase(d))
            }
        )
        val participants=dynamicGrid.participants(
            managerState.driverMarket,
            managerState.playerTeamId,
            managerState.round,
            managerState.season,
            (rd.weekOfSeason - 1).coerceAtLeast(0),
            driverOverrides,
            managerState.garage!!,
            managerState.facilities,
            aiGarages,
            aiFacilities
        ).map { p ->
            if (p.teamId==manager.playerTeamId) p.copy(
                reliability=(p.reliability + (manager.engineSupplier.reliability-50)/10).coerceIn(40,100)
            ) else p
        }
        val circuit=RaceCircuit(rd.round,rd.circuit,rd.laps,rd.baseLapTimeMs,crashRisk=rd.crashRisk,reliabilityRisk=rd.reliabilityRisk,safetyCarRisk=rd.safetyCarRisk)
        val race=simulateHeadlessWeekend(participants, circuit, team.id, seed, manager.season, manager.round)
        val playerEntries=race.classification.filter { it.teamName==team.name }
        val teamPoints=playerEntries.sumOf { race.points[it.driverId] ?: 0 }
        val bestFinish=playerEntries.minOfOrNull { if(it.status=="DNF") 999 else it.position } ?: 999
        val dnf=playerEntries.all { it.status=="DNF" }
        var next=managerState
        // Assess every calendar week through this GP; the persistent week ledger makes replay safe.
        for (maintenanceWeek in 1..rd.weekOfSeason) {
            next = finance.applyWeeklyFacilityMaintenance(next, next.season, maintenanceWeek)
            WorldDatabase.teams.filter { it.id != next.playerTeamId }.forEach { aiTeam ->
                aiFinance.beginSeason(aiTeam.id, next.season, next.driverMarket)
                // AI teams receive the same idempotent weekly shop revenue as the player.
                // This path is also used by headless season simulation/audits.
                aiFinance.applyWeeklyCommercialRevenue(aiTeam.id, next.season, maintenanceWeek)
                aiFinance.applyWeeklyFacilityMaintenance(aiTeam.id, next.season, maintenanceWeek)
            }
        }
        val playerQualifyingBest = race.qualifying?.grid.orEmpty()
            .filter { q -> WorldDatabase.allDrivers.firstOrNull { it.id == q.driverId }?.teamId == team.id }
            .minOfOrNull { it.position } ?: 0
        next=finance.applyRace(next,bestFinish,teamPoints,dnf, managerState.season, managerState.round, playerQualifyingBest)
        // Retry pending maintenance after this GP's income is credited; the week key prevents a second assessment.
        next=finance.applyWeeklyFacilityMaintenance(next, next.season, rd.weekOfSeason)
        next=finance.applyDriverSalariesForRace(next, managerState.season, managerState.round)
        // Weekly progression now advances the canonical physical pipeline:
        // P&D -> Design -> Factory -> physical Piece -> manager assignment -> Garage.
        // No legacy TeamCarState mutation is allowed here.
        val carBefore = next.car
        next = ResearchEngine().advanceWeeks(next, 1, next.season, rd.weekOfSeason - 1)
        next = FactoryEngine().advanceWeeks(next, 1, rd.weekOfSeason - 1)
        next = syncLegacyCarFromGarage(next)
        val carAfter = next.car
        val performanceSeason = advanceSeason(season, race)
        next=applyDriverEvolution(next, race, performanceSeason, aiFacilities)

        // Persist only real, material changes in the seasonal news feed.
        var marketState = next.driverMarket
        val week = rd.weekOfSeason
        val teamOverallBefore = (carBefore.aerodynamics + carBefore.chassis + carBefore.engine + carBefore.reliability) / 4
        val teamOverallAfter = (carAfter.aerodynamics + carAfter.chassis + carAfter.engine + carAfter.reliability) / 4
        if (teamOverallAfter != teamOverallBefore) {
            val teamName = team.name
            val direction = if (teamOverallAfter > teamOverallBefore) "subiu" else "caiu"
            marketState = marketState.copy(notifications = marketState.notifications + MarketNotification(
                next.season, week, "EVOLUÇÃO DE EQUIPE",
                "$teamName evoluiu. Overall da equipe $direction de $teamOverallBefore para $teamOverallAfter.", true, MarketNewsCategory.TEAM_EVOLUTION
            )).normalized()
        }

        // AI technical development publishes the real physical pipeline.
        // No direct "evolution" news is emitted merely because a virtual aggregate changed.
        val aiDevelopment = AITeamDevelopmentEngine(seed + manager.round, regulationSeed)
        val elapsed = (week - 1).coerceAtLeast(0)
        WorldDatabase.teams.filter { it.id != next.playerTeamId }.forEach { aiTeam ->
            val facilitiesBefore = aiFinance.facilities(aiTeam.id)
            val planningCapacity = aiFinance.developmentCapacity(aiTeam.id, next.season)
            val currentAiOverall = aiDevelopment.simulateFinancial(
                aiTeam, elapsed, next.season, planningCapacity, facilitiesBefore,
                aiFinance.nextSeasonInvestmentsForTeam(aiTeam.id)
            ).garage?.teamAverageOverall ?: InitialTeamProfile.values(aiTeam).overall
            val facilityStateAfter = aiFinance.advanceFacilityDevelopment(
                aiTeam.id, next.season, week, currentAiOverall, next.driverMarket, aiSponsorship
            )
            val facilitiesAfter = aiFinance.facilities(aiTeam.id)
            FacilityType.values().forEach { type ->
                val beforeLevel = facilitiesBefore.level(type)
                val afterLevel = facilitiesAfter.level(type)
                if (afterLevel > beforeLevel) {
                    marketState = marketState.copy(notifications = marketState.notifications + MarketNotification(
                        next.season, week, "MELHORIA DE INSTALAÇÃO",
                        "${aiTeam.name} melhorou ${FacilityEngine.label(type)} do nível $beforeLevel para o nível $afterLevel.",
                        true, MarketNewsCategory.TEAM_EVOLUTION
                    )).normalized()
                }
            }
            val capacity = aiFinance.developmentCapacity(aiTeam.id, next.season)
            val afterAi = aiDevelopment.simulateFinancial(
                aiTeam, elapsed, next.season, capacity, aiFinance.facilities(aiTeam.id),
                aiFinance.nextSeasonInvestmentsForTeam(aiTeam.id)
            )
            aiFinance.setFacilities(aiTeam.id, afterAi.facilities)
            aiSponsorship.setMarketingLevel(aiTeam.id, afterAi.facilities.level(FacilityType.MARKETING))
            val events = afterAi.events.filter { it.week == elapsed }
            events.forEach { event ->
                val componentName = when (event.component) {
                    CarComponent.FRONT_WING -> "Asa dianteira"
                    CarComponent.REAR_WING -> "Asa traseira"
                    CarComponent.CHASSIS -> "Chassi"
                    CarComponent.ENGINE -> "Motor - ICE"
                    CarComponent.BRAKES -> "Freios"
                    CarComponent.ELECTRIC_POWER_UNIT -> "MGU-K - ERS"
                }
                val displayWeek = week
                val notification: MarketNotification? = when (event.type) {
                    AITeamDevelopmentEngine.DevelopmentEvent.Type.DESIGN_COMPLETED -> MarketNotification(
                        next.season, displayWeek, "P&D CONCLUÍDO",
                        "${aiTeam.name} concluiu $componentName V${event.version}. Design pronto para a Fábrica: P${event.performance} / C${event.reliability}.",
                        true, MarketNewsCategory.TEAM_EVOLUTION, aiTeam.id
                    )
                    AITeamDevelopmentEngine.DevelopmentEvent.Type.FACTORY_COMPLETED -> null
                    AITeamDevelopmentEngine.DevelopmentEvent.Type.PIECE_INSTALLED -> {
                        val target = event.target?.let { if (it == GarageCarId.CAR_1) "Carro 1" else "Carro 2" } ?: "carro"
                        MarketNotification(
                            next.season, displayWeek, "PEÇA INSTALADA",
                            "${aiTeam.name} instalou $componentName V${event.version} no $target.",
                            true, MarketNewsCategory.TEAM_EVOLUTION, aiTeam.id
                        )
                    }
                }
                if (notification != null) {
                    marketState = marketState.copy(notifications = marketState.notifications + notification)
                }
                if (event.type == AITeamDevelopmentEngine.DevelopmentEvent.Type.PIECE_INSTALLED &&
                    (event.afterOverall ?: 0) > (event.beforeOverall ?: 0)) {
                    marketState = marketState.copy(notifications = marketState.notifications + MarketNotification(
                        next.season, displayWeek, "EVOLUÇÃO DE EQUIPE",
                        "${aiTeam.name} evoluiu o desempenho. Overall da equipe subiu de ${event.beforeOverall} para ${event.afterOverall}.",
                        true, MarketNewsCategory.TEAM_EVOLUTION, aiTeam.id
                    ))
                }
            }
        }
        // Driver Overall movement news is already emitted by applyDriverEvolution above,
        // with its explicit Motivo. Do not add a second, reasonless duplicate here.
        val currentWeek = rd.weekOfSeason
        val marketBeforeAi = marketState
        val teamMarketPoints = WorldDatabase.teams.associate { marketTeam ->
            marketTeam.id to marketState.contracts.filter { it.teamId == marketTeam.id && it.activeIn(next.season) }
                .sumOf { performanceSeason.standings[it.driverId] ?: 0 }
        }
        val liveMarketAttributes = next.driverEvolutionAttributes.mapValues { (_, values) -> values.toList() }
        // V660: evaluate transfers against the physical cars that will exist next season,
        // using the same construction ladder and the upcoming technical regulation.
        val nextSeasonCarStrength = buildNextSeasonCarStrengths(managerState, aiGarages)
        marketState = DriverMarketEngine(seed + manager.round).processAiMarketWeek(
            marketState, next.season, currentWeek, next.playerTeamId, teamMarketPoints, liveMarketAttributes,
            performanceSeason.standings, nextSeasonCarStrength
        )
        val marketEngine = DriverMarketEngine(seed + manager.round)
        WorldDatabase.teams.filter { it.id != next.playerTeamId }.forEach { aiTeam ->
            aiFinance.applyNewDeals(aiTeam.id, next.season, marketBeforeAi, marketState, marketEngine)
        }
        next = next.copy(driverMarket = marketState)
        next=next.copy(round=manager.round+1, manager=next.manager.copy(experience=next.manager.experience+1,reputation=(next.manager.reputation + if(teamPoints>0) 1 else 0).coerceAtMost(100)))
        WorldDatabase.teams.filter { it.id != next.playerTeamId }.forEach { aiTeam ->
            aiSponsorship.setMarketingLevel(aiTeam.id, aiFinance.facilities(aiTeam.id).level(FacilityType.MARKETING))
        }
        // AI contracts must still be active while this GP is settled. The helper
        // advances/deals with expirations only after applyRace receives the old portfolio.
        WorldDatabase.teams.filter { it.id != next.playerTeamId }.forEach { aiTeam ->
            val capacity = aiFinance.developmentCapacity(aiTeam.id, next.season)
            aiFinance.applySponsorshipSignings(aiTeam.id, next.season, aiSponsorship.forTeam(aiTeam.id, next.season))
            val devBudget = aiDevelopmentFinance.simulateFinancial(aiTeam, elapsed + 1, next.season, capacity, aiFinance.facilities(aiTeam.id), aiFinance.nextSeasonInvestmentsForTeam(aiTeam.id)).budget
            aiFinance.applyDevelopmentCost(aiTeam.id, next.season, devBudget, capacity, next.driverMarket, aiSponsorship, week)
        }
        WorldDatabase.teams.filter { it.id != next.playerTeamId }.forEach { aiTeam ->
            val aiMarket = next.driverMarket
            val aiEntries = race.classification.filter { entry ->
                WorldDatabase.allDrivers.firstOrNull { it.name == entry.driverName }?.teamId == aiTeam.id || entry.teamName == aiTeam.name
            }
            val aiBestFinish = aiEntries.minOfOrNull { if (it.status.startsWith("DNF")) 999 else it.position } ?: 999
            val aiDnf = aiEntries.isNotEmpty() && aiEntries.all { it.status.startsWith("DNF") }
            val aiQualifyingBest = race.qualifying?.grid.orEmpty()
                .filter { q -> WorldDatabase.allDrivers.firstOrNull { it.id == q.driverId }?.teamId == aiTeam.id }
                .minOfOrNull { it.position } ?: 0
            val aiPoints = aiEntries.sumOf { race.points[it.driverId] ?: 0 }
            aiSponsorship.settleRaceThenAdvance(aiTeam.id, next.season, manager.round) { sponsorState ->
                // Signing credits are idempotent and refer to the portfolio that was
                // active for this GP. Replacements created after settlement are credited
                // on the next weekly finance pass, before their first GP.
                aiFinance.applySponsorshipSignings(aiTeam.id, next.season, sponsorState)
                aiFinance.applyRace(aiTeam.id, next.season, manager.round, sponsorState, aiMarket, aiBestFinish, aiPoints, aiDnf, aiQualifyingBest)
            }
            // Retry old weekly maintenance obligations after GP income/premiums have settled.
            aiFinance.applyWeeklyFacilityMaintenance(aiTeam.id, next.season, rd.weekOfSeason)
            val capacity = aiFinance.developmentCapacity(aiTeam.id, next.season)
            val aiGarage = aiDevelopmentFinance.simulateFinancial(
                aiTeam, elapsed + 1, next.season, capacity, aiFinance.facilities(aiTeam.id),
                aiFinance.nextSeasonInvestmentsForTeam(aiTeam.id)
            ).garage ?: TeamGarageFactory.fromInitial(aiTeam)
            aiFinance.considerNextSeasonInvestment(aiTeam.id, next.season, manager.round, aiGarage.teamAverageOverall, aiMarket, aiSponsorship)
        }
        var seasonNext=advanceSeason(season,race)
        // GP 30 closes the season. Resolve all future contracts first, then reset
        // championship counters and reopen the new season at GP 1. Salaries are
        // intentionally charged on the first GP of the new season, not here.
        if (manager.round == calendar.size) {
            val nextSeasonNumber = season.season + 1
            // Final Constructors' standings are derived from the completed
            // drivers' championship using the contracts that were active in
            // the just-finished season. The prize is credited once, before
            // the market transition and next-season opening.
            val currentSeasonTeamPoints = next.driverMarket.contracts
                .filter { it.activeIn(season.season) }
                .groupBy { it.teamId }
                .mapValues { (_, deals) -> deals.sumOf { seasonNext.standings[it.driverId] ?: 0 } }
            val settlements = SeasonSettlementEngine.settleAll(currentSeasonTeamPoints)
            settlements.forEach { settlement ->
                if (settlement.teamId == next.playerTeamId) {
                    next = finance.applySeasonConstructorsPrize(next, season.season, settlement.position)
                } else {
                    aiFinance.applySeasonConstructorsPrize(settlement.teamId, season.season, settlement.position)
                }
            }
            // Debt is allowed during the season. The technical penalty is applied
            // to the newly constructed next-season car, after normal construction.
            WorldDatabase.teams.filter { it.id != next.playerTeamId }.forEach { aiTeam ->
                aiFinance.applyEndOfSeasonFinancialPenalty(aiTeam.id, season.season)
            }
            // Annual positive-growth allowances belong only to the season that just ended.
            // Historical attributes/banks remain; only the per-season allowance resets.
            next = next.copy(
                driverEvolutionAnnualGains = next.driverEvolutionAnnualGains.mapValues { IntArray(7).toList() },
                driverEvolutionBanks = next.driverEvolutionBanks,
                driverEvolutionSeasonTargets = emptyMap(),
                driverEvolutionSeasonTargetsVersion = 0
            )
            val championDriverId = seasonNext.standings.entries.sortedWith(
                compareByDescending<Map.Entry<Int, Int>> { it.value }
                    .thenByDescending { seasonNext.wins[it.key] ?: 0 }
                    .thenByDescending { seasonNext.podiums[it.key] ?: 0 }
                    .thenBy { it.key }
            ).firstOrNull()?.key
            if (championDriverId != null) {
                next = next.copy(driverCareerTitles = next.driverCareerTitles + championDriverId)
            }
            next = reviewDriverClassesAfterSeason(next, season.season, championDriverId)
            // Build the next-season car first. The physical garage is rebuilt from the same
            // canonical next-season car, so the Race Engine cannot run a stale physical chassis.
            next = development.startNextSeason(next, nextSeasonNumber)
            // Keep the headless/alternate season engine aligned with the canonical career
            // transition: build first, apply the same season rule to both physical cars,
            // then synchronize the legacy projection. This also enforces decennial
            // exclusivity and the stable per-team 0–8% adaptation penalty on this path.
            val seasonRule = AnnualCarRegulationEngine.generateForCalendarYear(nextSeasonNumber, regulationSeed)
            val teamSeed = next.playerTeamId
            val regulatedGarage = AnnualCarRegulationEngine.applyToGarage(
                next.garage ?: TeamGarageFactory.fromCarState(next.car, next.playerTeamId, nextSeasonNumber),
                seasonRule,
                teamSeed
            )
            fun baselineVersions(car: PhysicalCar) = car.installedPieces.keys.associateWith { 0 }
            val baselineGarage = regulatedGarage.copy(
                car1 = regulatedGarage.car1.copy(installedPieceVersions = baselineVersions(regulatedGarage.car1)),
                car2 = regulatedGarage.car2.copy(installedPieceVersions = baselineVersions(regulatedGarage.car2))
            )
            val regulatedLegacy = AnnualCarRegulationEngine.applyToCar(next.car, seasonRule, teamSeed)
            val synchronizedNext = syncLegacyCarFromGarage(next.copy(
                car = regulatedLegacy,
                garage = baselineGarage,
                history = next.history + "Regulamento ${nextSeasonNumber} aplicado após a construção do carro novo."
            ))
            next = synchronizedNext
            val nextRanking = TechnicalInvestmentEngine.seasonRanking(next.playerTeamId, next.car)[next.playerTeamId] ?: 40
            next = next.copy(
                technicalInvestment = TechnicalInvestmentEngine.create(nextSeasonNumber, nextRanking)
            )
            next = FinancialSeasonClosureEngine.applyPlayerPenalty(next)
            val nextBudgets = WorldDatabase.teams.associate { aiTeam ->
                aiTeam.id to if (aiTeam.id == next.playerTeamId) next.finance.budget else aiFinance.state(aiTeam.id, season.season).finance.budget
            }
            val outgoingTeamMarketPoints = WorldDatabase.teams.associate { marketTeam ->
                marketTeam.id to next.driverMarket.contracts.filter { it.teamId == marketTeam.id && it.activeIn(season.season) }
                    .sumOf { season.standings[it.driverId] ?: 0 }
            }
            val liveMarketAttributes = next.driverEvolutionAttributes.mapValues { (_, values) -> values.toList() }
            val transitionedMarket = DriverMarketEngine(seed + 90000 + nextSeasonNumber).applySeasonTransition(
                next.driverMarket, nextSeasonNumber, nextBudgets, next.playerTeamId,
                outgoingTeamMarketPoints, liveMarketAttributes, season.standings
            )
            next = next.copy(
                season = nextSeasonNumber,
                round = 1,
                driverMarket = transitionedMarket
            )
            next = applyAgeCycleTransitionsAtBoundary(next, nextSeasonNumber)
            seasonNext = SeasonState(season = nextSeasonNumber, currentRound = 1)
        }
        return RoundOutcome(next,seasonNext,race)
    }

    /**
     * Compatibility projection only: TeamCarState is kept synchronized with the
     * physical garage for older UI/financial consumers. Race performance never
     * reads this projection; it reads Car 1 / Car 2 from TeamGarage.
     */
    private fun syncLegacyCarFromGarage(state: TeamManagerState): TeamManagerState {
        val g = state.garage ?: return state
        fun avg(component: CarComponent): Int =
            ((g.car1.componentValue(component) + g.car2.componentValue(component)) / 2.0).toInt().coerceIn(40,100)
        val nextCar = state.car.copy(
            aerodynamics = ((avg(CarComponent.FRONT_WING) + avg(CarComponent.REAR_WING)) / 2.0).toInt(),
            chassis = avg(CarComponent.CHASSIS),
            engine = avg(CarComponent.ENGINE),
            reliability = ((g.car1.reliability + g.car2.reliability) / 2.0).toInt().coerceIn(40,100),
            frontWing = avg(CarComponent.FRONT_WING),
            rearWing = avg(CarComponent.REAR_WING),
            brakes = avg(CarComponent.BRAKES),
            electricPowerUnit = avg(CarComponent.ELECTRIC_POWER_UNIT)
        ).normalized()
        return state.copy(car = nextCar)
    }

    /** Run the same full-field interactive race engine used by MainActivity,
     * automatically resolving manager decisions for audit/headless seasons. */
    private fun simulateHeadlessWeekend(
        participants: List<com.f1teammanager.core.race.RaceParticipant>,
        circuit: RaceCircuit,
        playerTeamId: Int,
        careerSeed: Int,
        season: Int,
        round: Int
    ): RaceResult {
        val weekendSeed = com.f1teammanager.core.race.RaceWeekendSeed.forWeekend(
            careerSeed = careerSeed,
            season = season,
            round = round,
            circuitName = circuit.name
        )
        val engine = CareerWeekendEngine(careerSeed + round)
        var snapshot = engine.start(participants, circuit, playerTeamId, weekendSeed)
        repeat(3) { snapshot = engine.simulateQualifyingPhase() }
        var guard = 0
        while (!snapshot.completed) {
            require(++guard <= circuit.laps * 8 + 100) { "Corrida headless excedeu o limite de segurança" }
            val decision = snapshot.decision
            snapshot = if (decision != null) {
                if (decision.request.type == com.f1teammanager.core.race.ManagerDecisionType.RED_FLAG) {
                    engine.chooseRedFlag(com.f1teammanager.core.race.Tyre.MEDIUM)
                } else {
                    engine.choose(com.f1teammanager.core.race.ManagerDecisionAction.STAY_OUT)
                }
            } else {
                engine.advance()
            }
        }
        return engine.result()
    }

    /**
     * Deterministic next-season car projection for the driver market. The projection
     * uses the exact physical construction pipeline, committed investment, focus and
     * technical knowledge, then applies the next season's regulation to every team.
     */
    private fun buildNextSeasonCarStrengths(
        manager: TeamManagerState,
        currentAiGarages: Map<Int, TeamGarage>
    ): Map<Int, Int> {
        val targetSeason = manager.season + 1
        val rule = AnnualCarRegulationEngine.generateForCalendarYear(targetSeason, regulationSeed)
        return WorldDatabase.teams.associate { team ->
            val isPlayer = team.id == manager.playerTeamId
            val previousGarage = if (isPlayer) {
                manager.garage ?: TeamGarageFactory.fromCarState(manager.car, team.id, manager.season)
            } else {
                currentAiGarages[team.id] ?: TeamGarageFactory.fromInitial(team)
            }
            val investment = if (isPlayer) manager.car.nextSeasonInvestment
                else aiFinance.nextSeasonInvestmentsForTeam(team.id)[manager.season] ?: 0L
            val focus = if (isPlayer) manager.car.nextSeasonFocus else CarDevelopmentFocus.BALANCED
            val knowledge = if (isPlayer) manager.car.developmentKnowledge else emptyMap()
            val previousOverall = previousGarage.teamAverageOverall
            val maximumOverall = (previousOverall + NextSeasonCarGrowthPolicy.maximumGain(previousOverall)).coerceAtMost(100)
            val built = if (isPlayer) development.buildNextSeasonGarage(
                previousGarage, investment, focus, knowledge,
                maximumOverall = maximumOverall
            ) else development.buildAiNextSeasonGarage(previousGarage, investment, knowledge)
            val regulated = AnnualCarRegulationEngine.applyToGarage(
                built, rule, team.id.hashCode()
            )
            team.id to regulated.teamAverageOverall.coerceIn(40, 100)
        }
    }

    /**
     * Builds the season's expectations exclusively from the 40-team car order using
     * physical garages prepared for the opening GP. Teammates receive the same target;
     * driver attributes affect results, not expectations. Goals are reused until reset.
     */
    private fun buildSeasonTargets(
        manager: TeamManagerState,
        currentAiGarages: Map<Int, TeamGarage>
    ): Map<Int,Int> {
        val carStrengthByTeam = WorldDatabase.teams.associate { team ->
            val strength = if (team.id == manager.playerTeamId) {
                (manager.garage ?: TeamGarageFactory.fromCarState(manager.car, manager.playerTeamId, manager.season)).teamAverageOverall.toDouble()
            } else {
                (currentAiGarages[team.id]?.teamAverageOverall ?: InitialTeamProfile.values(team).overall).toDouble()
            }
            team.id to strength
        }

        val activeContracts = manager.driverMarket.contracts.filter { it.activeIn(manager.season) }
        check(activeContracts.size == DriverEvolutionEngine.DRIVER_GRID_SIZE &&
            activeContracts.map { it.driverId }.distinct().size == DriverEvolutionEngine.DRIVER_GRID_SIZE) {
            "Metas individuais: o campeonato de pilotos precisa conter exatamente 80 pilotos ativos; construtores usam a escala separada de 1 a 40."
        }
        val inputs = activeContracts.map { deal ->
            DriverEvolutionEngine.TargetInput(
                driverId = deal.driverId,
                teamId = deal.teamId,
                carStrength = carStrengthByTeam[deal.teamId] ?: 50.0
            )
        }
        check(inputs.size == DriverEvolutionEngine.DRIVER_GRID_SIZE) {
            "Metas individuais: não foi possível montar as 80 metas do campeonato de pilotos."
        }
        val individualTargets = DriverEvolutionEngine.buildIndividualTargets(inputs)
        check(individualTargets.size == DriverEvolutionEngine.DRIVER_GRID_SIZE) {
            "Metas individuais: a geração não retornou exatamente 80 pilotos."
        }
        fun encode(target: DriverEvolutionEngine.Target): Int =
            target.qualifyingPosition.coerceIn(1, DriverEvolutionEngine.DRIVER_GRID_SIZE) * 100 +
                target.racePosition.coerceIn(1, DriverEvolutionEngine.DRIVER_GRID_SIZE)

        // Free agents have no active-team target; their separate training path is used.
        return WorldDatabase.allDrivers.associate { driver ->
            driver.id to (individualTargets[driver.id]?.let(::encode) ?: 8080)
        }
    }

    private fun seasonTargetForDriver(manager: TeamManagerState, driverId: Int): DriverEvolutionEngine.Target {
        val encoded = manager.driverEvolutionSeasonTargets[driverId] ?: 8080
        return if (encoded in 1..80) {
            // Backward-compatible read for saves created before individual target bands.
            DriverEvolutionEngine.Target(encoded)
        } else {
            val qualifying = (encoded / 100).coerceIn(1, DriverEvolutionEngine.DRIVER_GRID_SIZE)
            val race = (encoded % 100).coerceIn(1, DriverEvolutionEngine.DRIVER_GRID_SIZE)
            DriverEvolutionEngine.Target(
                ((qualifying + race + 1) / 2).coerceIn(1, DriverEvolutionEngine.DRIVER_GRID_SIZE),
                qualifying, race
            )
        }
    }

    /**
     * Advances each AI team's persistent facility queue before the race weekend.
     * Uses the exact player DriverDevelopmentEngine specification and the same
     * annual per-attribute allowance as natural development.
     */
    private fun advanceAiDriverDevelopment(
        manager: TeamManagerState,
        aiFacilities: Map<Int, TeamFacilitiesState>,
        eventWeek: Int
    ): TeamManagerState {
        val attrs = manager.driverEvolutionAttributes.mapValues { it.value.toMutableList() }.toMutableMap()
        val annual = manager.driverEvolutionAnnualGains.mapValues { it.value.toMutableList() }.toMutableMap()
        val activeDeals = manager.driverMarket.contracts.filter { it.activeIn(manager.season) }
        val aiPrograms = manager.driverMarket.aiDriverDevelopment.toMutableMap()
        val aiProgramLastTick = manager.driverMarket.aiDriverDevelopmentLastTick.toMutableMap()
        val absoluteWeek = manager.season * 56 + eventWeek
        val definitions = WorldDatabase.allDrivers.associate { base ->
            val values = attrs[base.id] ?: base.ratingsForManager().toList()
            base.copy(
                speed=values[0], qualifying=values[1], overtaking=values[2], defense=values[3],
                consistency=values[4], wet=values[5], tyre=values[6],
                driverClass = manager.driverEvolutionClasses[base.id] ?: base.driverClass
            ).normalized().let { base.id to it }
        }
        val attributeArrays = attrs.mapValues { it.value.toIntArray() }.toMutableMap()
        val annualArrays = annual.mapValues { it.value.toIntArray() }.toMutableMap()
        val notices = mutableListOf<MarketNotification>()

        WorldDatabase.teams.filter { it.id != manager.playerTeamId }.forEach { aiTeam ->
            val level = (aiFacilities[aiTeam.id] ?: FacilityEngine.initial(aiTeam.initialLevel))
                .level(FacilityType.DRIVER_DEVELOPMENT)
            var queue = aiPrograms[aiTeam.id] ?: DriverDevelopmentState()
            val teamIds = activeDeals.filter { it.teamId == aiTeam.id }.map { it.driverId }.toSet()
            val orphanedPrograms = queue.programs.filter { it.driverId !in teamIds }
            if (orphanedPrograms.isNotEmpty()) {
                queue = queue.copy(programs = queue.programs.filter { it.driverId in teamIds }).normalized()
                orphanedPrograms.forEach { orphaned ->
                    val name = WorldDatabase.allDrivers.firstOrNull { it.id == orphaned.driverId }?.name ?: "Piloto ${orphaned.driverId}"
                    val newTeamId = activeDeals.firstOrNull { it.driverId == orphaned.driverId }?.teamId
                    val destination = newTeamId?.let { WorldDatabase.teams.firstOrNull { team -> team.id == it }?.name } ?: "mercado de pilotos"
                    notices += MarketNotification(
                        manager.season, eventWeek, "PROGRAMA DE DESENVOLVIMENTO CANCELADO",
                        "${aiTeam.name}: o programa de $name foi cancelado porque o piloto deixou a equipe e passou para $destination. A vaga foi liberada.",
                        true, MarketNewsCategory.DRIVER_EVENTS,
                        relatedTeamId = manager.playerTeamId.takeIf { it == aiTeam.id || it == newTeamId }
                    )
                }
            }
            val previousTick = aiProgramLastTick[aiTeam.id]
            val elapsedWeeks = if (previousTick == null) 0 else (absoluteWeek - previousTick).coerceIn(0, 56)
            val result = DriverDevelopmentEngine.advanceWeeks(
                queue, elapsedWeeks, eventWeek, definitions.filterKeys { it in teamIds },
                attributeArrays, seed + manager.season * 1009 + eventWeek * 37 + aiTeam.id * 7919,
                annualArrays
            )
            queue = result.state
            result.attributes.forEach { (id, values) -> attributeArrays[id] = values }
            result.annualGains.forEach { (id, values) -> annualArrays[id] = values }
            result.completed.forEach { done ->
                val name = definitions[done.driverId]?.name ?: "Piloto ${done.driverId}"
                notices += MarketNotification(
                    manager.season, eventWeek, "PROGRAMA DE DESENVOLVIMENTO CONCLUÍDO",
                    "${aiTeam.name}: programa de ${name} concluído; ${done.appliedPoints} ponto(s) aplicado(s).",
                    true, MarketNewsCategory.DRIVER_EVENTS
                )
            }

            val capacity = DriverDevelopmentEngine.capacity(level)
            while (level > 0 && queue.programs.size < capacity) {
                val activeIds = queue.programs.map { it.driverId }.toSet()
                val candidate = teamIds.filterNot { it in activeIds }.mapNotNull { id ->
                    val driver = definitions[id] ?: return@mapNotNull null
                    val ratings = attributeArrays[id] ?: driver.ratingsForManager()
                    val overall = DriverProfileCatalog.overall(ratings)
                    val potential = driver.potentialOverall.coerceIn(overall, 100)
                    val age = DriverEvolutionEngine.careerAge(driver, manager.season)
                    val gap = (potential - overall).coerceAtLeast(0)
                    val yearly = annualArrays[id] ?: IntArray(7)
                    val hasAnnualRoom = ratings.indices.any { ratings[it] < 100 && yearly[it] < DriverProfileCatalog.maxAnnualGain(driver.evolution) }
                    if (!hasAnnualRoom) return@mapNotNull null
                    val priority = gap * 3 + (if (age <= 25) 18 else if (age <= 29) 8 else 0) +
                        (if (driver.evolution == "Prodígio") 12 else 0)
                    Triple(id, priority, overall)
                }.filter { it.second > 0 }
                    .sortedWith(compareByDescending<Triple<Int,Int,Int>> { it.second }.thenBy { it.third })
                    .firstOrNull() ?: break
                val next = runCatching {
                    DriverDevelopmentEngine.start(queue, level, candidate.first, eventWeek, teamIds)
                }.getOrDefault(queue)
                if (next.programs.size == queue.programs.size) break
                queue = next
            }
            aiPrograms[aiTeam.id] = queue.normalized()
            aiProgramLastTick[aiTeam.id] = absoluteWeek
        }
        attrs.clear(); attributeArrays.forEach { (id, values) -> attrs[id] = values.toList().toMutableList() }
        annual.clear(); annualArrays.forEach { (id, values) -> annual[id] = values.toList().toMutableList() }
        return manager.copy(
            driverEvolutionAttributes = attrs,
            driverEvolutionAnnualGains = annual,
            driverMarket = manager.driverMarket.copy(
                notifications = (manager.driverMarket.notifications + notices).takeLast(1000),
                aiDriverDevelopment = aiPrograms,
                aiDriverDevelopmentLastTick = aiProgramLastTick
            ).normalized()
        ).normalized()
    }

    /** Apply cycle rollover before the first GP of the new season in the simulation path. */
    private fun applyAgeCycleTransitionsAtBoundary(
        manager: TeamManagerState,
        targetSeason: Int
    ): TeamManagerState {
        val attrs = manager.driverEvolutionAttributes.toMutableMap()
        val cycles = manager.driverAgeCycleIndices.toMutableMap()
        val banks = manager.driverEvolutionBanks.toMutableMap()
        val ageBanks = manager.driverAgeDeclineBanks.toMutableMap()
        val ageLosses = manager.driverAgePhysicalLosses.mapValues { it.value.toMutableList() }.toMutableMap()
        val agePeaks = manager.driverAgePhysicalPeaks.mapValues { it.value.toMutableList() }.toMutableMap()
        val phases = manager.driverEvolutionPhases.toMutableMap()
        val phaseGps = manager.driverEvolutionPhaseGps.toMutableMap()
        val notifications = mutableListOf<MarketNotification>()
        val history = manager.history.toMutableList()
        var transitioned = false

        WorldDatabase.allDrivers.forEach { base ->
            val previousCycle = cycles[base.id] ?: DriverEvolutionEngine.careerCycleIndex(base, targetSeason - 1)
            val targetCycle = DriverEvolutionEngine.careerCycleIndex(base, targetSeason)
            if (targetCycle <= previousCycle) {
                cycles.putIfAbsent(base.id, targetCycle)
                return@forEach
            }
            val current = attrs[base.id]?.takeIf { it.size == 7 }?.toIntArray() ?: base.ratingsForManager()
            val reset = IntArray(7) { index ->
                (current[index].coerceIn(40, 100) * 70 / 100).coerceAtLeast(40)
            }
            val delta = IntArray(7) { index -> reset[index] - current[index] }
            attrs[base.id] = reset.toList()
            cycles[base.id] = targetCycle
            banks[base.id] = 0.0
            ageBanks[base.id] = 0.0
            ageLosses[base.id] = IntArray(7).toMutableList()
            agePeaks[base.id] = reset.toMutableList()
            phases[base.id] = "REGRESSION"
            phaseGps[base.id] = 0
            val detail = DriverEvolutionEngine.describeAttributeDeltas(delta)
            val historyMessage = "${base.name} concluiu a temporada aos 45 anos e iniciou o ciclo aos 18; redução de 30% nos sete atributos, com piso 40 ($detail). Identidade, classe e perfil de evolução preservados."
            val beforeOverall = DriverProfileCatalog.overall(current)
            val afterOverall = DriverProfileCatalog.overall(reset)
            val teamName = manager.driverMarket.contracts
                .firstOrNull { it.driverId == base.id && it.activeIn(targetSeason) }
                ?.let { deal -> WorldDatabase.teams.firstOrNull { it.id == deal.teamId }?.name }
                ?: "Sem equipe"
            val cycleReason = "reinício do ciclo etário: concluiu a temporada aos 45 anos e iniciou novo ciclo aos 18, " +
                "com redução de 30% em cada atributo, aplicada individualmente e limitada ao piso 40; " +
                "identidade, classe e perfil de evolução preservados"
            val overallNews = DriverEvolutionEngine.overallSeasonMovementNews(
                base.name, teamName, targetSeason, beforeOverall, afterOverall, cycleReason
            )
            if (overallNews != null) {
                notifications += MarketNotification(
                    targetSeason, 1, DriverEvolutionEngine.newsTitle(afterOverall - beforeOverall),
                    overallNews, true, MarketNewsCategory.DRIVER_EVOLUTION
                )
            }
            history += historyMessage
            transitioned = true
        }
        if (!transitioned) return manager.copy(driverAgeCycleIndices = cycles)
        return manager.copy(
            driverEvolutionAttributes = attrs,
            driverAgeCycleIndices = cycles,
            driverEvolutionBanks = banks,
            driverAgeDeclineBanks = ageBanks,
            driverAgePhysicalLosses = ageLosses,
            driverAgePhysicalPeaks = agePeaks,
            driverEvolutionPhases = phases,
            driverEvolutionPhaseGps = phaseGps,
            driverMarket = manager.driverMarket.copy(
                notifications = (manager.driverMarket.notifications + notifications).takeLast(1000)
            ).normalized(),
            history = history.takeLast(5000)
        ).normalized()
    }

    fun applyDriverEvolution(
        manager: TeamManagerState,
        race: RaceResult,
        performanceSeason: SeasonState,
        aiFacilities: Map<Int, TeamFacilitiesState> = emptyMap()
    ): TeamManagerState {
        // One idempotent evolution tick per driver and GP: active drivers use results;
        // free agents use the same 100% natural-growth baseline without race evidence.
        val evolutionKey = "${manager.season}:${manager.round}"
        if (evolutionKey in manager.driverEvolutionProcessedRounds) return manager.normalized()
        val attrs = manager.driverEvolutionAttributes.mapValues { (_, values) ->
            values.map { it.coerceIn(40, 100) }
        }.toMutableMap()
        val annual = manager.driverEvolutionAnnualGains.toMutableMap()
        val banks = manager.driverEvolutionBanks.toMutableMap()
        val ageBanks = manager.driverAgeDeclineBanks.toMutableMap()
        val ageLosses = manager.driverAgePhysicalLosses.mapValues { it.value.toIntArray() }.toMutableMap()
        val agePeaks = manager.driverAgePhysicalPeaks.mapValues { (_, values) ->
            values.map { it.coerceIn(40, 100) }.toIntArray()
        }.toMutableMap()
        val ageCycles = manager.driverAgeCycleIndices.toMutableMap()
        val phases = manager.driverEvolutionPhases.toMutableMap()
        val phaseGps = manager.driverEvolutionPhaseGps.toMutableMap()
        val performance = manager.driverClassPerformance.mapValues { it.value.toMutableMap() }.toMutableMap()
        val activeDeals = manager.driverMarket.contracts.filter { it.activeIn(manager.season) }
        val active = activeDeals.map { it.driverId }.toSet()
        check(active.size == 80) { "Evolução: esperado 80 pilotos ativos, encontrado ${active.size}" }
        val freeDrivers = WorldDatabase.allDrivers.map { it.id }.filterNot { it in active }.toSet()
        check(active.size + freeDrivers.size == WorldDatabase.allDrivers.size) {
            "Evolução: a divisão entre pilotos contratados e livres não cobre o elenco completo"
        }
        val teamByDriver = activeDeals.associate { it.driverId to it.teamId }
        val qualifyingGrid = race.qualifying?.grid?.associateBy { it.driverId }.orEmpty()
        val classification = race.classification.associateBy { it.driverId }
        val evolutionNotices = mutableListOf<MarketNotification>()
        val eventWeek = SeasonCalendar.forSeason(manager.season).firstOrNull { it.round == manager.round }?.weekOfSeason ?: manager.round

        WorldDatabase.allDrivers.forEach { base ->
            val a = attrs[base.id]?.takeIf { it.size == 7 }?.toIntArray() ?: base.ratingsForManager()
            val driverClass = com.f1teammanager.core.season.DriverClassProgressionEngine.canonicalClass(
                manager.driverEvolutionClasses[base.id] ?: base.driverClass
            ) ?: base.driverClass
            val current = base.copy(
                speed=a[0], qualifying=a[1], overtaking=a[2], defense=a[3], consistency=a[4], wet=a[5], tyre=a[6],
                driverClass=driverClass
            ).normalized()
            val beforeOverall = DriverProfileCatalog.overall(a)
            val annualArray = (annual[base.id] ?: IntArray(7).toList()).toIntArray().also {
                if (it.size != 7) java.util.Arrays.fill(it, 0)
            }
            val random = kotlin.random.Random(seed + manager.season*1000 + manager.round*97 + base.id*31)
            val tick = if (base.id in active) {
                val target = seasonTargetForDriver(manager,base.id)
                val q = qualifyingGrid[base.id]?.position ?: target.qualifyingPosition
                val raceRow = classification[base.id]
                val r = DriverEvolutionEngine.racePositionForEvolution(
                    target, raceRow?.position, raceRow?.status
                )
                val index = DriverEvolutionEngine.gpPerformanceIndex(target, q, r)
                val seasonScores = performance.getOrPut(base.id) { mutableMapOf() }
                val old = seasonScores[manager.season] ?: DriverSeasonPerformance()
                seasonScores[manager.season] = DriverSeasonPerformance(old.sum + index, old.raceCount + 1)
                val seasonAverage = seasonScores[manager.season]!!.let { it.sum / it.raceCount.coerceAtLeast(1) }
                // Facility levels do not grant passive driver growth. Both player and AI
                // receive only explicit, persistent development programmes below.
                DriverEvolutionEngine.applyPerformanceTick(
                    driver = current,
                    performanceIndex = index,
                    currentBank = banks[base.id] ?: 0.0,
                    annualGains = annualArray,
                    random = random,
                    facilityGrowthEfficiency = 1.0,
                    seasonPerformanceAverage = seasonAverage,
                    careerAge = DriverEvolutionEngine.careerAge(current, manager.season),
                    currentAgeBank = ageBanks[base.id] ?: 0.0,
                    currentAgePhysicalLosses = ageLosses[base.id] ?: IntArray(7),
                    currentAgePhysicalPeaks = agePeaks[base.id] ?: intArrayOf(current.speed, current.qualifying, current.overtaking, current.defense, current.consistency, current.wet, current.tyre),
                    currentAgeCycleIndex = ageCycles[base.id] ?: DriverEvolutionEngine.careerCycleIndex(current, manager.season),
                    careerCycleIndex = DriverEvolutionEngine.careerCycleIndex(current, manager.season)
                )
            } else {
                // Uncontracted drivers train independently at the same 100% baseline,
                // with age/potential controls; no fabricated GP result or class-review sample.
                DriverEvolutionEngine.applyFreeDriverTick(
                    driver = current,
                    currentBank = banks[base.id] ?: 0.0,
                    annualGains = annualArray,
                    random = random,
                    careerAge = DriverEvolutionEngine.careerAge(current, manager.season),
                    currentAgeBank = ageBanks[base.id] ?: 0.0,
                    currentAgePhysicalLosses = ageLosses[base.id] ?: IntArray(7),
                    currentAgePhysicalPeaks = agePeaks[base.id] ?: intArrayOf(current.speed, current.qualifying, current.overtaking, current.defense, current.consistency, current.wet, current.tyre),
                    currentAgeCycleIndex = ageCycles[base.id] ?: DriverEvolutionEngine.careerCycleIndex(current, manager.season),
                    careerCycleIndex = DriverEvolutionEngine.careerCycleIndex(current, manager.season)
                )
            }
            ageBanks[base.id] = tick.ageBank
            ageLosses[base.id] = tick.agePhysicalLosses
            agePeaks[base.id] = tick.agePhysicalPeaks
            ageCycles[base.id] = tick.ageCycleIndex
            val afterOverall = DriverProfileCatalog.overall(intArrayOf(tick.driver.speed, tick.driver.qualifying, tick.driver.overtaking, tick.driver.defense, tick.driver.consistency, tick.driver.wet, tick.driver.tyre))
            val teamName = teamByDriver[base.id]?.let { id -> WorldDatabase.teams.firstOrNull { it.id == id }?.name } ?: "Sem equipe"
            val overallNews = DriverEvolutionEngine.overallMovementNews(
                base.name, teamName, manager.round, beforeOverall, afterOverall,
                DriverEvolutionEngine.overallMovementReason(tick, afterOverall - beforeOverall)
            )
            if (overallNews != null) {
                val delta = afterOverall - beforeOverall
                evolutionNotices += MarketNotification(
                    manager.season, eventWeek, DriverEvolutionEngine.newsTitle(delta),
                    overallNews, true, MarketNewsCategory.DRIVER_EVOLUTION
                )
            }
            attrs[base.id] = tick.driver.ratingsForManager().toList()
            annual[base.id] = annualArray.toList()
            banks[base.id] = tick.bank
            phases[base.id] = tick.phase
            phaseGps[base.id] = (phaseGps[base.id] ?: 0) + 1
        }
        return manager.copy(
            driverEvolutionAttributes=attrs,
            driverEvolutionAnnualGains=annual,
            driverEvolutionBanks=banks,
            driverAgeDeclineBanks=ageBanks,
            driverAgePhysicalLosses=ageLosses.mapValues { it.value.toList() },
            driverAgePhysicalPeaks=agePeaks.mapValues { it.value.toList() },
            driverAgeCycleIndices=ageCycles,
            driverEvolutionPhases=phases,
            driverEvolutionPhaseGps=phaseGps,
            driverClassPerformance=performance.mapValues { it.value.toMap() },
            driverEvolutionProcessedRounds=manager.driverEvolutionProcessedRounds + evolutionKey,
            driverMarket = manager.driverMarket.copy(
                notifications = (manager.driverMarket.notifications + evolutionNotices).takeLast(1000)
            ).normalized()
        ).normalized()
    }

    /** Promotion and relegation are evaluated once, after two consecutive seasons. */
    private fun reviewDriverClassesAfterSeason(
        manager: TeamManagerState,
        completedSeason: Int,
        championDriverId: Int?
    ): TeamManagerState {
        // Class reviews occur on a strict two-season cadence (2027, 2029, 2031...).
        if (completedSeason % 2 == 0) return manager
        if (manager.driverClassProgressionReviewedSeason >= completedSeason) return manager
        val performance = manager.driverClassPerformance
        val classes = manager.driverEvolutionClasses.toMutableMap()
        val titleWinners = manager.driverCareerTitles.toMutableSet().apply { championDriverId?.let(::add) }
        val history = manager.history.toMutableList()
        val notifications = manager.driverMarket.notifications.toMutableList()
        val expectedRounds = SeasonCalendar.forSeason(completedSeason).size
        WorldDatabase.allDrivers.forEach { base ->
            val storedClass = classes[base.id] ?: base.driverClass
            val currentClass = com.f1teammanager.core.season.DriverClassProgressionEngine.canonicalClass(storedClass)
                ?: base.driverClass
            if (storedClass != currentClass) classes[base.id] = currentClass
            val ratings = manager.driverEvolutionAttributes[base.id]?.toIntArray() ?: base.ratingsForManager()
            fun sample(seasonNumber: Int): com.f1teammanager.core.season.DriverClassProgressionEngine.SeasonPerformance? {
                val entry = performance[base.id]?.get(seasonNumber) ?: return null
                if (entry.raceCount <= 0) return null
                return com.f1teammanager.core.season.DriverClassProgressionEngine.SeasonPerformance(
                    seasonNumber, entry.sum / entry.raceCount.toDouble(), entry.raceCount
                )
            }
            val decision = com.f1teammanager.core.season.DriverClassProgressionEngine.evaluate(
                driverClass = currentClass,
                overall = DriverProfileCatalog.overall(ratings),
                previous = sample(completedSeason - 1),
                latest = sample(completedSeason),
                expectedSeasonRounds = expectedRounds,
                isChampion = base.id in titleWinners
            )
            if (decision.changed) {
                classes[base.id] = decision.resultingClass
                val label = if (decision.direction == com.f1teammanager.core.season.DriverClassProgressionEngine.Direction.PROMOTION)
                    "PROMOVIDO" else "REBAIXADO"
                val message = "${base.name} foi ${if (decision.direction == com.f1teammanager.core.season.DriverClassProgressionEngine.Direction.PROMOTION) "promovido" else "rebaixado"} de ${decision.previousClass} para ${decision.resultingClass} após duas temporadas (índice médio ${decision.twoSeasonAverage.toInt()})."
                history += "$label: $message"
                notifications += MarketNotification(
                    completedSeason + 1, 1,
                    if (decision.direction == com.f1teammanager.core.season.DriverClassProgressionEngine.Direction.PROMOTION) "PROMOÇÃO DE CLASSE" else "REBAIXAMENTO DE CLASSE",
                    message, true, MarketNewsCategory.DRIVER_EVENTS
                )
            }
        }
        return manager.copy(
            driverEvolutionClasses = classes,
            driverCareerTitles = titleWinners,
            driverClassProgressionReviewedSeason = completedSeason,
            driverMarket = manager.driverMarket.copy(notifications = notifications.takeLast(1000)).normalized(),
            history = history.takeLast(5000)
        )
    }

    private fun DriverDefinition.ratingsForManager(): IntArray = intArrayOf(speed,qualifying,overtaking,defense,consistency,wet,tyre)
    private fun advanceSeason(state:SeasonState,race:RaceResult):SeasonState {
        val points=state.standings.toMutableMap(); val wins=state.wins.toMutableMap(); val pods=state.podiums.toMutableMap(); val starts=state.starts.toMutableMap()
        race.classification.forEach { f ->
            if(f.status!="DNF") starts[f.driverId]=(starts[f.driverId]?:0)+1
            points[f.driverId]=(points[f.driverId]?:0)+(race.points[f.driverId]?:0)
            if(f.status!="DNF" && f.position==1) wins[f.driverId]=(wins[f.driverId]?:0)+1
            if(f.status!="DNF" && f.position<=3) pods[f.driverId]=(pods[f.driverId]?:0)+1
        }
        return state.copy(currentRound=state.currentRound+1,standings=points,wins=wins,podiums=pods,starts=starts)
    }

}
