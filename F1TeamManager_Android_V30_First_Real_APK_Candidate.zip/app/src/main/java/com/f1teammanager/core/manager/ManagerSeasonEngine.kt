package com.f1teammanager.core.manager

import com.f1teammanager.core.race.RaceCircuit
import com.f1teammanager.core.race.RaceResult
import com.f1teammanager.core.race.CareerWeekendEngine
import com.f1teammanager.core.season.SeasonState
import com.f1teammanager.core.season.WorldDatabase
import com.f1teammanager.core.season.SeasonCalendar
import com.f1teammanager.core.season.DriverDefinition
import com.f1teammanager.core.season.DriverEvolutionEngine
import com.f1teammanager.core.season.DriverProfileCatalog
import kotlin.math.abs

class ManagerSeasonEngine(private val seed:Int=20261003) {
    private val development=CarDevelopmentEngine()
    private val finance=FinanceEngine()
    private val dynamicGrid=DynamicGridEngine()
    private val aiSponsorship=TeamSponsorshipEngine(seed + 6000)
    private val aiFinance=AITeamFinancialEngine(seed + 7000)
    private val aiDevelopmentFinance=AITeamDevelopmentEngine(seed + 8000)

    data class RoundOutcome(val state:TeamManagerState,val season:SeasonState,val race:RaceResult)

    fun currentGrid(manager: TeamManagerState): List<DynamicGridEngine.GridDriver> {
        val market = if (manager.driverMarket.contracts.isEmpty()) {
            DriverMarketEngine().initialState(manager.season)
        } else manager.driverMarket
        return dynamicGrid.snapshot(market)
    }

    fun validateGrid(manager: TeamManagerState): List<String> {
        val market = if (manager.driverMarket.contracts.isEmpty()) DriverMarketEngine().initialState(manager.season) else manager.driverMarket
        return dynamicGrid.validate(market)
    }

    fun runRound(manager:TeamManagerState, season:SeasonState):RoundOutcome {
        val calendar = SeasonCalendar.forSeason(season.season)
        require(manager.round == season.currentRound) { "Estado do manager e temporada fora de sincronia" }
        require(manager.round in 1..calendar.size) { "Temporada encerrada" }
        var managerState = if (manager.round == 1) finance.applyAnnualDriverSalaries(manager, manager.season) else manager
        if (managerState.round == 1) {
            val ranking = TechnicalInvestmentEngine.seasonRanking(managerState.playerTeamId, managerState.car)[managerState.playerTeamId] ?: 40
            managerState = managerState.copy(
                technicalInvestment = TechnicalInvestmentEngine.ensureSeason(
                    managerState.technicalInvestment, managerState.season, ranking
                )
            )
        }
        if (managerState.garage == null) {
            managerState = managerState.copy(garage = TeamGarageFactory.fromCarState(managerState.car, managerState.playerTeamId, managerState.season))
        }
        if (manager.round == 1 && managerState.driverEvolutionSeasonTargets.size != WorldDatabase.allDrivers.size) {
            managerState = managerState.copy(
                driverEvolutionSeasonTargets = buildSeasonTargets(managerState),
                driverEvolutionPhases = WorldDatabase.allDrivers.associate { d ->
                    d.id to (managerState.driverEvolutionPhases[d.id] ?: "GROWING")
                }
            )
        }
        if (manager.round == 1) aiFinance.ensureAllTeams(manager.season, manager.playerTeamId, manager.driverMarket)
        val rd=calendar[manager.round-1]
        val team=WorldDatabase.teams.first { it.id==manager.playerTeamId }
        val driverOverrides = manager.driverEvolutionAttributes.mapNotNull { (id,a) ->
            val base = WorldDatabase.allDrivers.firstOrNull { it.id == id } ?: return@mapNotNull null
            if (a.size != 7) return@mapNotNull null
            id to base.copy(speed=a[0], qualifying=a[1], overtaking=a[2], defense=a[3], consistency=a[4], wet=a[5], tyre=a[6])
        }.toMap()
        val aiGarages = mutableMapOf<Int, TeamGarage>()
        val aiFacilities = mutableMapOf<Int, TeamFacilitiesState>()
        WorldDatabase.teams.filter { it.id != managerState.playerTeamId }.forEach { aiTeam ->
            val capacity = aiFinance.developmentCapacity(aiTeam.id, managerState.season)
            val aiState = aiDevelopmentFinance.simulateFinancial(aiTeam, (rd.weekOfSeason - 1).coerceAtLeast(0), managerState.season, capacity)
            aiGarages[aiTeam.id] = aiState.garage ?: TeamGarageFactory.fromInitial(aiTeam)
            aiFacilities[aiTeam.id] = aiState.facilities
        }
        val participants=dynamicGrid.participants(
            managerState.driverMarket,
            managerState.playerTeamId,
            managerState.round,
            managerState.season,
            (rd.weekOfSeason - 1).coerceAtLeast(0),
            driverOverrides,
            managerState.garage!!,
            managerState.facilities,
            aiGarages,
            aiFacilities
        ).map { p ->
            if (p.teamId==manager.playerTeamId) p.copy(
                reliability=(p.reliability + (manager.engineSupplier.reliability-50)/10).coerceIn(1,100)
            ) else p
        }
        val circuit=RaceCircuit(rd.round,rd.circuit,rd.laps,rd.baseLapTimeMs,crashRisk=rd.crashRisk,reliabilityRisk=rd.reliabilityRisk,safetyCarRisk=rd.safetyCarRisk)
        val race=simulateHeadlessWeekend(participants,circuit,team.id,seed+manager.round)
        val playerEntries=race.classification.filter { it.teamName==team.name }
        val teamPoints=playerEntries.sumOf { race.points[it.driverId] ?: 0 }
        val bestFinish=playerEntries.minOfOrNull { if(it.status=="DNF") 999 else it.position } ?: 999
        val dnf=playerEntries.all { it.status=="DNF" }
        var next=finance.applyRace(managerState,bestFinish,teamPoints,dnf)
        // Weekly progression now advances the canonical physical pipeline:
        // P&D -> Design -> Factory -> physical Piece -> manager assignment -> Garage.
        // No legacy TeamCarState mutation is allowed here.
        val carBefore = next.car
        next = ResearchEngine().advanceWeeks(next, 1, next.season, rd.weekOfSeason - 1)
        next = FactoryEngine().advanceWeeks(next, 1, rd.weekOfSeason - 1)
        next = syncLegacyCarFromGarage(next)
        val carAfter = next.car
        val performanceSeason = advanceSeason(season, race)
        next=applyDriverEvolution(next, race, performanceSeason)

        // Persist only real, material changes in the seasonal news feed.
        var marketState = next.driverMarket
        val week = rd.weekOfSeason
        val teamOverallBefore = (carBefore.aerodynamics + carBefore.chassis + carBefore.engine + carBefore.reliability) / 4
        val teamOverallAfter = (carAfter.aerodynamics + carAfter.chassis + carAfter.engine + carAfter.reliability) / 4
        if (teamOverallAfter != teamOverallBefore) {
            val teamName = team.name
            val direction = if (teamOverallAfter > teamOverallBefore) "subiu" else "caiu"
            marketState = marketState.copy(notifications = marketState.notifications + MarketNotification(
                next.season, week, "EVOLUÇÃO DE EQUIPE",
                "$teamName evoluiu. Overall da equipe $direction de $teamOverallBefore para $teamOverallAfter.", true, MarketNewsCategory.TEAM_EVOLUTION
            )).normalized()
        }

        // AI technical development publishes the real physical pipeline.
        // No direct "evolution" news is emitted merely because a virtual aggregate changed.
        val aiDevelopment = AITeamDevelopmentEngine(seed + manager.round)
        val elapsed = (week - 1).coerceAtLeast(0)
        WorldDatabase.teams.filter { it.id != next.playerTeamId }.forEach { aiTeam ->
            aiFinance.advanceFacilityDevelopment(aiTeam.id, next.season, week)
            val capacity = aiFinance.developmentCapacity(aiTeam.id, next.season)
            val afterAi = aiDevelopment.simulateFinancial(
                aiTeam, elapsed, next.season, capacity, aiFinance.facilities(aiTeam.id)
            )
            aiFinance.setFacilities(aiTeam.id, afterAi.facilities)
            aiSponsorship.setMarketingLevel(aiTeam.id, afterAi.facilities.level(FacilityType.MARKETING))
            val events = afterAi.events.filter { it.week == elapsed }
            events.forEach { event ->
                val componentName = when (event.component) {
                    CarComponent.FRONT_WING -> "Asa dianteira"
                    CarComponent.REAR_WING -> "Asa traseira"
                    CarComponent.CHASSIS -> "Chassi"
                    CarComponent.ENGINE -> "Unidade de potência"
                    CarComponent.BRAKES -> "Freios"
                    CarComponent.ELECTRIC_POWER_UNIT -> "Unidade elétrica"
                }
                val displayWeek = week
                val notification = when (event.type) {
                    AITeamDevelopmentEngine.DevelopmentEvent.Type.DESIGN_COMPLETED -> MarketNotification(
                        next.season, displayWeek, "P&D CONCLUÍDO",
                        "${aiTeam.name} concluiu $componentName V${event.version}. Design pronto para a Fábrica: P${event.performance} / C${event.reliability}.",
                        true, MarketNewsCategory.TEAM_EVOLUTION
                    )
                    AITeamDevelopmentEngine.DevelopmentEvent.Type.FACTORY_COMPLETED -> MarketNotification(
                        next.season, displayWeek, "FABRICAÇÃO CONCLUÍDA",
                        "${aiTeam.name} fabricou $componentName V${event.version}. Peça física instalada diretamente no carro.",
                        true, MarketNewsCategory.TEAM_EVOLUTION
                    )
                    AITeamDevelopmentEngine.DevelopmentEvent.Type.PIECE_INSTALLED -> {
                        val target = event.target?.let { if (it == GarageCarId.CAR_1) "Carro 1" else "Carro 2" } ?: "carro"
                        MarketNotification(
                            next.season, displayWeek, "PEÇA INSTALADA",
                            "${aiTeam.name} instalou $componentName V${event.version} no $target.",
                            true, MarketNewsCategory.TEAM_EVOLUTION
                        )
                    }
                }
                marketState = marketState.copy(notifications = marketState.notifications + notification)
                if (event.type == AITeamDevelopmentEngine.DevelopmentEvent.Type.PIECE_INSTALLED &&
                    (event.afterOverall ?: 0) > (event.beforeOverall ?: 0)) {
                    marketState = marketState.copy(notifications = marketState.notifications + MarketNotification(
                        next.season, displayWeek, "EVOLUÇÃO DE EQUIPE",
                        "${aiTeam.name} evoluiu o desempenho. Overall da equipe subiu de ${event.beforeOverall} para ${event.afterOverall}.",
                        true, MarketNewsCategory.TEAM_EVOLUTION
                    ))
                }
            }
        }
        WorldDatabase.allDrivers.forEach { d ->
            val before = manager.driverEvolutionAttributes[d.id] ?: listOf(d.speed,d.qualifying,d.overtaking,d.defense,d.consistency,d.wet,d.tyre)
            val after = next.driverEvolutionAttributes[d.id] ?: before
            val overallBefore = before.sum() / 7
            val overallAfter = after.sum() / 7
            val delta = overallAfter - overallBefore
            if (delta > 0) {
                val teamName = manager.driverMarket.contracts.firstOrNull { it.driverId == d.id && it.activeIn(next.season) }
                    ?.let { WorldDatabase.teams.firstOrNull { team -> team.id == it.teamId }?.name } ?: "Sem equipe"
                marketState = marketState.copy(notifications = marketState.notifications + MarketNotification(
                    next.season, week, "EVOLUÇÃO DE PILOTO",
                    "${d.name} — $teamName — GP ${manager.round}: Overall $overallBefore → $overallAfter (+$delta).", true, MarketNewsCategory.DRIVER_EVOLUTION
                )).normalized()
            }
        }
        val currentWeek = rd.weekOfSeason
        val marketBeforeAi = marketState
        marketState = DriverMarketEngine(seed + manager.round).processAiMarketWeek(marketState, next.season, currentWeek, next.playerTeamId)
        val marketEngine = DriverMarketEngine(seed + manager.round)
        WorldDatabase.teams.filter { it.id != next.playerTeamId }.forEach { aiTeam ->
            aiFinance.applyNewDeals(aiTeam.id, next.season, marketBeforeAi, marketState, marketEngine)
        }
        next = next.copy(driverMarket = marketState)
        next=next.copy(round=manager.round+1, manager=next.manager.copy(experience=next.manager.experience+1,reputation=(next.manager.reputation + if(teamPoints>0) 1 else 0).coerceAtMost(100)))
        WorldDatabase.teams.filter { it.id != next.playerTeamId }.forEach { aiTeam ->
            aiSponsorship.setMarketingLevel(aiTeam.id, aiFinance.facilities(aiTeam.id).level(FacilityType.MARKETING))
        }
        aiSponsorship.advanceAllTeams(next.season, manager.round, next.playerTeamId)
        WorldDatabase.teams.filter { it.id != next.playerTeamId }.forEach { aiTeam ->
            val capacity = aiFinance.developmentCapacity(aiTeam.id, next.season)
            val devBudget = aiDevelopmentFinance.simulateFinancial(aiTeam, elapsed + 1, next.season, capacity).budget
            aiFinance.applyDevelopmentCost(aiTeam.id, next.season, devBudget, capacity)
        }
        WorldDatabase.teams.filter { it.id != next.playerTeamId }.forEach { aiTeam ->
            val sponsorState = aiSponsorship.forTeam(aiTeam.id, next.season)
            aiFinance.applySponsorshipSignings(aiTeam.id, next.season, sponsorState)
            val aiMarket = next.driverMarket
            aiFinance.applyRace(aiTeam.id, next.season, manager.round, sponsorState, aiMarket, bestFinish = 20, points = 0)
        }
        var seasonNext=advanceSeason(season,race)
        // GP 30 closes the season. Resolve all future contracts first, then reset
        // championship counters and reopen the new season at GP 1. Salaries are
        // intentionally charged on the first GP of the new season, not here.
        if (manager.round == calendar.size) {
            val nextSeasonNumber = season.season + 1
            // Final Constructors' standings are derived from the completed
            // drivers' championship using the contracts that were active in
            // the just-finished season. The prize is credited once, before
            // the market transition and next-season opening.
            val currentSeasonTeamPoints = next.driverMarket.contracts
                .filter { it.activeIn(season.season) }
                .groupBy { it.teamId }
                .mapValues { (_, deals) -> deals.sumOf { seasonNext.standings[it.driverId] ?: 0 } }
            val settlements = SeasonSettlementEngine.settleAll(currentSeasonTeamPoints)
            settlements.forEach { settlement ->
                if (settlement.teamId == next.playerTeamId) {
                    next = finance.applySeasonConstructorsPrize(next, season.season, settlement.position)
                } else {
                    aiFinance.applySeasonConstructorsPrize(settlement.teamId, season.season, settlement.position)
                }
            }
            // Debt is allowed during the season. The technical penalty is applied
            // to the newly constructed next-season car, after normal construction.
            WorldDatabase.teams.filter { it.id != next.playerTeamId }.forEach { aiTeam ->
                aiFinance.applyEndOfSeasonFinancialPenalty(aiTeam.id, season.season)
            }
            // Annual positive-growth allowances belong only to the season that just ended.
            // Historical attributes/banks remain; only the per-season allowance resets.
            next = next.copy(
                driverEvolutionAnnualGains = next.driverEvolutionAnnualGains.mapValues { IntArray(7).toList() },
                driverEvolutionBanks = next.driverEvolutionBanks,
                driverEvolutionSeasonTargets = emptyMap()
            )
            // Build the next-season car first. The physical garage is rebuilt from the same
            // canonical next-season car, so the Race Engine cannot run a stale physical chassis.
            next = development.startNextSeason(next, nextSeasonNumber)
            val nextRanking = TechnicalInvestmentEngine.seasonRanking(next.playerTeamId, next.car)[next.playerTeamId] ?: 40
            next = next.copy(
                technicalInvestment = TechnicalInvestmentEngine.create(nextSeasonNumber, nextRanking)
            )
            next = FinancialSeasonClosureEngine.applyPlayerPenalty(next)
            val nextBudgets = WorldDatabase.teams.associate { aiTeam ->
                aiTeam.id to if (aiTeam.id == next.playerTeamId) next.finance.budget else aiFinance.state(aiTeam.id, season.season).finance.budget
            }
            val transitionedMarket = DriverMarketEngine(seed + 90000 + nextSeasonNumber).applySeasonTransition(
                next.driverMarket, nextSeasonNumber, nextBudgets
            )
            next = next.copy(
                season = nextSeasonNumber,
                round = 1,
                driverMarket = transitionedMarket
            )
            seasonNext = SeasonState(season = nextSeasonNumber, currentRound = 1)
        }
        return RoundOutcome(next,seasonNext,race)
    }

    /**
     * Compatibility projection only: TeamCarState is kept synchronized with the
     * physical garage for older UI/financial consumers. Race performance never
     * reads this projection; it reads Car 1 / Car 2 from TeamGarage.
     */
    private fun syncLegacyCarFromGarage(state: TeamManagerState): TeamManagerState {
        val g = state.garage ?: return state
        fun avg(component: CarComponent): Int =
            ((g.car1.componentValue(component) + g.car2.componentValue(component)) / 2.0).toInt().coerceIn(1,100)
        val nextCar = state.car.copy(
            aerodynamics = ((avg(CarComponent.FRONT_WING) + avg(CarComponent.REAR_WING)) / 2.0).toInt(),
            chassis = avg(CarComponent.CHASSIS),
            engine = avg(CarComponent.ENGINE),
            reliability = ((g.car1.reliability + g.car2.reliability) / 2.0).toInt().coerceIn(1,100),
            frontWing = avg(CarComponent.FRONT_WING),
            rearWing = avg(CarComponent.REAR_WING),
            brakes = avg(CarComponent.BRAKES),
            electricPowerUnit = avg(CarComponent.ELECTRIC_POWER_UNIT)
        ).normalized()
        return state.copy(car = nextCar)
    }

    /** Run the same full-field interactive race engine used by MainActivity,
     * automatically resolving manager decisions for audit/headless seasons. */
    private fun simulateHeadlessWeekend(
        participants: List<com.f1teammanager.core.race.RaceParticipant>,
        circuit: RaceCircuit,
        playerTeamId: Int,
        raceSeed: Int
    ): RaceResult {
        val engine = CareerWeekendEngine(raceSeed)
        var snapshot = engine.start(participants, circuit, playerTeamId)
        repeat(3) { snapshot = engine.simulateQualifyingPhase() }
        var guard = 0
        while (!snapshot.completed) {
            require(++guard <= circuit.laps * 8 + 100) { "Corrida headless excedeu o limite de segurança" }
            val decision = snapshot.decision
            snapshot = if (decision != null) {
                if (decision.request.type == com.f1teammanager.core.race.ManagerDecisionType.RED_FLAG) {
                    engine.chooseRedFlag(com.f1teammanager.core.race.Tyre.MEDIUM, com.f1teammanager.core.race.DriverPosture.BALANCED)
                } else {
                    engine.choose(com.f1teammanager.core.race.ManagerDecisionAction.STAY_OUT)
                }
            } else {
                engine.advance()
            }
        }
        return engine.result()
    }

    /** Build once at season start: opening team-strength rank defines the two driver slots. */
    private fun buildSeasonTargets(manager: TeamManagerState): Map<Int,Int> {
        fun strength(team: com.f1teammanager.core.season.TeamDefinition): Int {
            if (team.id == manager.playerTeamId) {
                val g = manager.garage ?: TeamGarageFactory.fromCarState(manager.car, manager.playerTeamId, manager.season)
                return g.teamAverageOverall
            }
            val c = InitialTeamProfile.values(team)
            return (c.chassis + c.engine + c.frontWing + c.rearWing + c.brakes + c.electricPowerUnit + 3) / 6
        }
        val rankedTeams = WorldDatabase.teams.sortedWith(
            compareByDescending<com.f1teammanager.core.season.TeamDefinition> { strength(it) }.thenBy { it.id }
        )
        val activeContracts = manager.driverMarket.contracts.filter { it.activeIn(manager.season) }
        val ranked = rankedTeams.flatMapIndexed { index, team ->
            val teamDrivers = activeContracts.filter { it.teamId == team.id }.map { it.driverId }.take(2)
            teamDrivers.mapIndexed { order, driverId ->
                driverId to (((index * 2) + order + 1).coerceIn(1, 80))
            }
        }.toMap().toMutableMap()
        // Free drivers have no team target in the active season; keep them at the
        // bottom expectation without allowing the target map to be rebuilt mid-season.
        WorldDatabase.allDrivers.forEach { driver -> ranked.putIfAbsent(driver.id, 80) }
        return ranked
    }

    private fun seasonTargetForDriver(manager: TeamManagerState, driverId: Int): DriverEvolutionEngine.Target {
        val target = manager.driverEvolutionSeasonTargets[driverId]
            ?: buildSeasonTargets(manager)[driverId]
            ?: 80
        return DriverEvolutionEngine.Target(target.coerceIn(1, 80))
    }

    fun applyDriverEvolution(manager: TeamManagerState, race: RaceResult, performanceSeason: SeasonState): TeamManagerState {
        val attrs = manager.driverEvolutionAttributes.toMutableMap()
        val annual = manager.driverEvolutionAnnualGains.toMutableMap()
        val banks = manager.driverEvolutionBanks.toMutableMap()
        val phases = manager.driverEvolutionPhases.toMutableMap()
        val phaseGps = manager.driverEvolutionPhaseGps.toMutableMap()
        val phaseStart = manager.driverEvolutionPhaseStart.toMutableMap()
        val phaseTarget = manager.driverEvolutionPhaseTarget.toMutableMap()
        val pressure = manager.driverEvolutionPhasePressure.toMutableMap()
        val active = manager.driverMarket.contracts.filter { it.activeIn(manager.season) }.map { it.driverId }.toSet()
        check(active.size == 80) { "Evolução: esperado 80 pilotos ativos, encontrado ${active.size}" }
        val teamByDriver = manager.driverMarket.contracts.filter { it.activeIn(manager.season) }.associate { it.driverId to it.teamId }
        val driverDevelopmentEfficiency = FacilityEngine.driverDevelopmentEfficiency(manager.facilities)
        val qualifyingGrid = race.qualifying?.grid?.associateBy { it.driverId }.orEmpty()
        val classification = race.classification.associateBy { it.driverId }

        fun initialize(id:Int, current:DriverDefinition): String {
            val phase = phases[id] ?: "GROWING"
            if (!phaseStart.containsKey(id)) phaseStart[id] = DriverProfileCatalog.overall(current.ratingsForManager())
            if (!phaseTarget.containsKey(id)) phaseTarget[id] = DriverProfileCatalog.ceiling(current.driverClass)
            if (!phaseGps.containsKey(id)) phaseGps[id] = 0
            return phase
        }

        WorldDatabase.allDrivers.forEach { base ->
            val a = attrs[base.id]?.toIntArray() ?: intArrayOf(base.speed,base.qualifying,base.overtaking,base.defense,base.consistency,base.wet,base.tyre)
            var current = base.copy(speed=a[0],qualifying=a[1],overtaking=a[2],defense=a[3],consistency=a[4],wet=a[5],tyre=a[6])
            var phase = initialize(base.id, current)
            var gps = phaseGps[base.id] ?: 0
            var bank = banks[base.id] ?: 0.0
            val rng = kotlin.random.Random(seed + manager.season*1000 + manager.round*97 + base.id*31)
            val annualArray = (annual[base.id] ?: IntArray(7).toList()).toIntArray().also { if (it.size != 7) java.util.Arrays.fill(it, 0) }
            val tierIndex: Double = if (base.id in active) {
                val q = qualifyingGrid[base.id]?.position ?: 80
                val r = classification[base.id]?.position ?: 80
                DriverEvolutionEngine.gpPerformanceIndex(seasonTargetForDriver(manager,base.id).championshipPosition,q,r)
            } else 100.0
            val regression = phase == "REGRESSION"
            val multiplier = if (base.id in active) DriverEvolutionEngine.phaseMultiplier(tierIndex, regression) else 0.70
            val anticipation = if (base.id in active) DriverEvolutionEngine.anticipationFactor(tierIndex, regression) else 1.0

            val target = if (phase == "REGRESSION") DriverProfileCatalog.minimumOverall(current.driverClass) else DriverProfileCatalog.ceiling(current.driverClass)
            if (phaseTarget[base.id] != target) {
                phaseTarget[base.id] = target
                phaseStart[base.id] = DriverProfileCatalog.overall(current.ratingsForManager())
                gps = 0
                bank = 0.0
            }
            val startOverall = phaseStart[base.id] ?: DriverProfileCatalog.overall(current.ratingsForManager())
            val phaseSeasons = when (phase) {
                "REGRESSION" -> DriverEvolutionEngine.regressionSeasons(current.evolution)
                "PEAK" -> 2
                else -> DriverEvolutionEngine.ascentSeasons(current.evolution)
            }
            val phaseGpsTotal = phaseSeasons * 30
            val distanceOverall = abs(target - startOverall)
            val totalBudget = distanceOverall.toDouble() * 7.0
            val basePerGp = if (phase == "PEAK" || distanceOverall == 0) 0.0 else totalBudget / phaseGpsTotal.coerceAtLeast(1).toDouble()

            if (phase != "PEAK") {
                bank += basePerGp * multiplier * anticipation * driverDevelopmentEfficiency
                val whole = bank.toInt()
                if (whole > 0) {
                    if (phase == "GROWING") current = DriverEvolutionEngine.applyPositiveGain(current, whole, annualArray, rng)
                    else current = DriverEvolutionEngine.applyRegression(current, whole, rng)
                    bank -= whole.toDouble()
                }
            }

            val overallAfter = DriverProfileCatalog.overall(current.ratingsForManager())
            val reachedTarget = if (phase == "REGRESSION") overallAfter <= target else overallAfter >= target
            gps++

            // Very poor performance accumulates phase pressure and can bring the driver
            // into regression earlier than the nominal ascent duration. Good performance
            // dissipates that pressure. It never skips the two full peak seasons once the
            // peak has actually been reached.
            var p = pressure[base.id] ?: 0.0
            if (phase == "GROWING") {
                p += when {
                    tierIndex < 60 -> 1.0
                    tierIndex < 75 -> 0.35
                    tierIndex >= 105 -> -0.70
                    tierIndex >= 92 -> -0.35
                    else -> -0.10
                }
                p = p.coerceIn(0.0, 12.0)
                if (p >= 12.0) {
                    phase = "REGRESSION"
                    gps = 0
                    phaseStart[base.id] = overallAfter
                    phaseTarget[base.id] = DriverProfileCatalog.minimumOverall(current.driverClass)
                    bank = 0.0
                    p = 0.0
                } else if (reachedTarget || gps >= phaseGpsTotal) {
                    phase = "PEAK"
                    gps = 0
                    phaseStart[base.id] = overallAfter
                    phaseTarget[base.id] = DriverProfileCatalog.ceiling(current.driverClass)
                    bank = 0.0
                    p = 0.0
                }
            } else if (phase == "REGRESSION") {
                if (reachedTarget || gps >= phaseGpsTotal) {
                    phase = "GROWING"
                    gps = 0
                    phaseStart[base.id] = overallAfter
                    phaseTarget[base.id] = DriverProfileCatalog.ceiling(current.driverClass)
                    bank = 0.0
                    p = 0.0
                }
            } else { // PEAK: exactly two seasons at the peak, then regression.
                if (gps >= phaseGpsTotal) {
                    phase = "REGRESSION"
                    gps = 0
                    phaseStart[base.id] = overallAfter
                    phaseTarget[base.id] = DriverProfileCatalog.minimumOverall(current.driverClass)
                    bank = 0.0
                    p = 0.0
                }
            }

            attrs[base.id] = listOf(current.speed,current.qualifying,current.overtaking,current.defense,current.consistency,current.wet,current.tyre)
            annual[base.id] = annualArray.toList()
            banks[base.id] = bank
            phases[base.id] = phase
            phaseGps[base.id] = gps
            phaseStart[base.id] = phaseStart[base.id] ?: overallAfter
            phaseTarget[base.id] = phaseTarget[base.id] ?: target
            pressure[base.id] = p
        }
        return manager.copy(
            driverEvolutionAttributes=attrs,
            driverEvolutionAnnualGains=annual,
            driverEvolutionBanks=banks,
            driverEvolutionPhases=phases,
            driverEvolutionPhaseGps=phaseGps,
            driverEvolutionPhaseStart=phaseStart,
            driverEvolutionPhaseTarget=phaseTarget,
            driverEvolutionPhasePressure=pressure
        )
    }

    private fun DriverDefinition.ratingsForManager(): IntArray = intArrayOf(speed,qualifying,overtaking,defense,consistency,wet,tyre)
    private fun advanceSeason(state:SeasonState,race:RaceResult):SeasonState {
        val points=state.standings.toMutableMap(); val wins=state.wins.toMutableMap(); val pods=state.podiums.toMutableMap(); val starts=state.starts.toMutableMap()
        race.classification.forEach { f ->
            if(f.status!="DNF") starts[f.driverId]=(starts[f.driverId]?:0)+1
            points[f.driverId]=(points[f.driverId]?:0)+(race.points[f.driverId]?:0)
            if(f.status!="DNF" && f.position==1) wins[f.driverId]=(wins[f.driverId]?:0)+1
            if(f.status!="DNF" && f.position<=3) pods[f.driverId]=(pods[f.driverId]?:0)+1
        }
        return state.copy(currentRound=state.currentRound+1,standings=points,wins=wins,podiums=pods,starts=starts)
    }

}
