package com.f1teammanager.core.manager

import com.f1teammanager.core.season.TeamDefinition
import com.f1teammanager.core.season.WorldDatabase

/**
 * Annual technical-investment controller.
 *
 * The ceiling is determined once at the opening of each season from the same
 * team-strength ranking used by the driver's season-target system. The ceiling
 * is shared by P&D/design, physical fabrication and facility upgrades.
 *
 * Money is charged when a project/order/upgrade is STARTED. Once started it is
 * allowed to finish even if the remaining annual ceiling is subsequently zero.
 */
data class TechnicalInvestmentState(
    val season: Int,
    val ranking: Int,
    val level: Int,
    val annualCap: Long,
    val researchDesignSpent: Long = 0L,
    val fabricationSpent: Long = 0L,
    val facilityUpgradeSpent: Long = 0L
) {
    val totalSpent: Long
        get() = researchDesignSpent + fabricationSpent + facilityUpgradeSpent

    val available: Long
        get() = (annualCap - totalSpent).coerceAtLeast(0L)

    val usedPercent: Int
        get() = if (annualCap <= 0L) 100 else ((totalSpent * 100L) / annualCap).coerceIn(0L, 100L).toInt()

    fun withSpend(category: TechnicalInvestmentCategory, amount: Long): TechnicalInvestmentState {
        require(amount > 0L) { "Investimento técnico inválido." }
        require(amount <= available) {
            "Limite anual de investimento técnico atingido. Disponível: €${available / 1_000_000}M."
        }
        return when (category) {
            TechnicalInvestmentCategory.RESEARCH_DESIGN ->
                copy(researchDesignSpent = researchDesignSpent + amount)
            TechnicalInvestmentCategory.FABRICATION ->
                copy(fabricationSpent = fabricationSpent + amount)
            TechnicalInvestmentCategory.FACILITY_UPGRADE ->
                copy(facilityUpgradeSpent = facilityUpgradeSpent + amount)
        }
    }
}

enum class TechnicalInvestmentCategory {
    RESEARCH_DESIGN, FABRICATION, FACILITY_UPGRADE
}

object TechnicalInvestmentEngine {
    /**
     * Five annual levels:
     * 1 = ranks 33–40 -> €400M
     * 2 = ranks 25–32 -> €350M
     * 3 = ranks 17–24 -> €300M
     * 4 = ranks 9–16  -> €250M
     * 5 = ranks 1–8   -> €200M
     */
    fun levelForRank(rank: Int): Int = when (rank.coerceIn(1, 40)) {
        in 1..8 -> 5
        in 9..16 -> 4
        in 17..24 -> 3
        in 25..32 -> 2
        else -> 1
    }

    fun capForRank(rank: Int): Long = when (levelForRank(rank)) {
        5 -> 200_000_000L
        4 -> 250_000_000L
        3 -> 300_000_000L
        2 -> 350_000_000L
        else -> 400_000_000L
    }

    fun create(season: Int, ranking: Int): TechnicalInvestmentState {
        val normalizedRank = ranking.coerceIn(1, 40)
        return TechnicalInvestmentState(
            season = season,
            ranking = normalizedRank,
            level = levelForRank(normalizedRank),
            annualCap = capForRank(normalizedRank)
        )
    }

    fun ensureSeason(state: TechnicalInvestmentState?, season: Int, ranking: Int): TechnicalInvestmentState {
        return if (state == null || state.season != season) create(season, ranking) else state
    }

    /**
     * Same strength source used by CareerPreferences.initializeDriverSeasonTargets:
     * InitialTeamProfile for AI/world teams, with an optional current player-car
     * override so the player's actual opening car remains the same ranking input.
     */
    fun seasonRanking(playerTeamId: Int? = null, playerCar: TeamCarState? = null): Map<Int, Int> {
        fun strength(team: TeamDefinition): Double {
            if (team.id == playerTeamId && playerCar != null) {
                return (playerCar.chassis + playerCar.engine + playerCar.frontWing +
                    playerCar.rearWing + playerCar.brakes + playerCar.electricPowerUnit) / 6.0
            }
            val c = InitialTeamProfile.values(team)
            return (c.chassis + c.engine + c.frontWing + c.rearWing +
                c.brakes + c.electricPowerUnit) / 6.0
        }
        return WorldDatabase.teams
            .sortedWith(compareByDescending<TeamDefinition> { strength(it) }.thenBy { it.id })
            .mapIndexed { index, team -> team.id to (index + 1) }
            .toMap()
    }

    fun forTeam(season: Int, teamId: Int, playerTeamId: Int? = null, playerCar: TeamCarState? = null): TechnicalInvestmentState {
        val rank = seasonRanking(playerTeamId, playerCar)[teamId] ?: 40
        return create(season, rank)
    }
}
