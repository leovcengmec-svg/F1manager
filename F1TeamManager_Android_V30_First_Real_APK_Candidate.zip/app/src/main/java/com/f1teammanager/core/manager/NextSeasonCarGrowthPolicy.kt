package com.f1teammanager.core.manager

/**
 * AI next-car growth ambition for the ten-year technical cycle.
 * This is a requested target, not a free performance bonus: the universal investment
 * table still determines the built Overall and actual cash/reserves can limit spending.
 */
object NextSeasonCarGrowthPolicy {
    fun maximumGain(currentOverall: Int): Int = when (currentOverall.coerceIn(0, 100)) {
        in 0..69 -> 7
        in 70..89 -> 5
        in 90..96 -> 2
        else -> 1
    }
}
