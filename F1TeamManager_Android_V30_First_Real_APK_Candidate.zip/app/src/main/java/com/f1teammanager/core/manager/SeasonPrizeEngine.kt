package com.f1teammanager.core.manager

/** End-of-season Constructors' Championship prize money. Values are intentionally
 * distinct for all 40 positions and paid exactly once per season. */
object SeasonPrizeEngine {
    fun prizeForPosition(position: Int): Long {
        require(position in 1..40) { "Posição inválida: $position" }
        // Keep every position distinct while preserving the approved 10M floor.
        return when (position) {
            1 -> 100_000_000L
            2 -> 90_000_000L
            3 -> 82_000_000L
            4 -> 75_000_000L
            5 -> 69_000_000L
            6 -> 63_000_000L
            7 -> 58_000_000L
            8 -> 53_000_000L
            9 -> 48_000_000L
            10 -> 44_000_000L
            11 -> 41_000_000L
            12 -> 39_000_000L
            13 -> 37_000_000L
            14 -> 35_000_000L
            15 -> 33_000_000L
            16 -> 31_000_000L
            17 -> 29_000_000L
            18 -> 27_000_000L
            19 -> 25_000_000L
            20 -> 23_000_000L
            21 -> 22_000_000L
            22 -> 21_000_000L
            23 -> 20_000_000L
            24 -> 19_000_000L
            25 -> 18_000_000L
            26 -> 17_000_000L
            27 -> 16_000_000L
            28 -> 15_000_000L
            29 -> 14_000_000L
            30 -> 13_000_000L
            31 -> 12_500_000L
            32 -> 12_000_000L
            33 -> 11_500_000L
            34 -> 11_000_000L
            35 -> 10_800_000L
            36 -> 10_600_000L
            37 -> 10_400_000L
            38 -> 10_200_000L
            39 -> 10_100_000L
            else -> 10_000_000L
        }
    }

    fun rankTeams(teamPoints: Map<Int, Int>): List<Pair<Int, Long>> =
        com.f1teammanager.core.season.WorldDatabase.teams
            .map { team -> team.id to (teamPoints[team.id] ?: 0) }
            .sortedWith(compareByDescending<Pair<Int,Int>> { it.second }.thenBy { it.first })
            .mapIndexed { index, entry -> entry.first to prizeForPosition(index + 1) }
}
