package com.f1teammanager.core.manager

/** End-of-season Constructors' Championship prize money. Values are intentionally
 * distinct for all 40 positions and paid exactly once per season. */
object SeasonPrizeEngine {
    fun prizeForPosition(position: Int): Long {
        require(position in 1..40) { "Posição inválida: $position" }
        // Top 10 have deliberately larger gaps; positions 11–20 step down
        // steadily, then the remaining places taper gradually to the €40M floor.
        val millions = when (position) {
            1 -> 100.0
            2 -> 92.0
            3 -> 86.0
            4 -> 81.0
            5 -> 77.0
            6 -> 73.0
            7 -> 69.0
            8 -> 65.0
            9 -> 62.0
            10 -> 60.0
            in 11..20 -> 58.5 - (position - 11) * 1.5
            else -> 44.75 - (position - 21) * 0.25
        }
        return (millions * 1_000_000L).toLong()
    }

    fun rankTeams(teamPoints: Map<Int, Int>): List<Pair<Int, Long>> =
        com.f1teammanager.core.season.WorldDatabase.teams
            .map { team -> team.id to (teamPoints[team.id] ?: 0) }
            .sortedWith(compareByDescending<Pair<Int,Int>> { it.second }.thenBy { it.first })
            .mapIndexed { index, entry -> entry.first to prizeForPosition(index + 1) }
}
