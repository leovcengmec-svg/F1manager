package com.f1teammanager.core.manager

import com.f1teammanager.core.season.TeamDefinition

/**
 * Regras oficiais de início de carreira.
 *
 * Forte  = carro 56..60 + instalações 2
 * Médio  = carro 48..55 + instalações 1
 * Fraco  = carro 40..47 + instalações 0
 *
 * Os seis componentes oficiais recebem valores individuais determinísticos
 * dentro da faixa da equipe. Isso evita um carro "chapado" e garante que
 * equipes do mesmo nível tenham Overalls iniciais diferentes.
 */
object InitialTeamProfile {
    const val FORTE = 2
    const val MEDIO = 1
    const val FRACO = 0

    data class CarValues(
        val engine: Int,
        val chassis: Int,
        val frontWing: Int,
        val rearWing: Int,
        val brakes: Int,
        val electricPowerUnit: Int
    ) {
        val overall: Double
            get() = (engine + chassis + frontWing + rearWing + brakes + electricPowerUnit) / 6.0
    }

    fun values(team: TeamDefinition): CarValues {
        val (min, max) = when (team.initialLevel) {
            FORTE -> 56 to 60
            MEDIO -> 48 to 55
            else -> 40 to 47
        }
        val span = max - min + 1
        fun value(slot: Int): Int = min + ((team.id * 37 + slot * 17 + team.id * slot * 7 + slot * slot * 3) % span)
        return CarValues(
            engine = value(1),
            chassis = value(2),
            frontWing = value(3),
            rearWing = value(4),
            brakes = value(5),
            electricPowerUnit = value(6)
        )
    }

    fun facilities(level: Int): Map<Facility, Int> =
        Facility.values().associateWith { level.coerceIn(0, 2) }

    fun teamFacilities(level: Int): TeamFacilitiesState = FacilityEngine.initial(level)

    fun carState(team: TeamDefinition): TeamCarState {
        val c = values(team)
        val reliability = c.overall.toInt().coerceIn(1, 100)
        return TeamCarState(
            aerodynamics = ((c.frontWing + c.rearWing) / 2).coerceIn(1, 100),
            chassis = c.chassis,
            engine = c.engine,
            reliability = reliability,
            facilities = facilities(team.initialLevel),
            frontWing = c.frontWing,
            rearWing = c.rearWing,
            brakes = c.brakes,
            electricPowerUnit = c.electricPowerUnit
        ).normalized()
    }
}
