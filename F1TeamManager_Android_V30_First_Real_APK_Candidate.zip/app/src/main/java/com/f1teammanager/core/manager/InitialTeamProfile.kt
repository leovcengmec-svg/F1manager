package com.f1teammanager.core.manager

import com.f1teammanager.core.season.TeamDefinition
import kotlin.random.Random

/**
 * Regras oficiais de início de carreira.
 *
 * O jogador e as equipes rivais começam com desempenho-base coerente com o nível
 * Forte/Médio/Fraco da equipe escolhida. As versões das peças começam em V0; a primeira
 * pesquisa bem-sucedida cria o design V1, que só troca o componente após fabricar/instalar.
 *
 * Perfil de força inicial usado para ranking, carro inicial e IA:
 * Forte  = referência 56..60 + confiabilidade 65..74 + instalações 2
 * Médio  = referência 48..55 + confiabilidade 55..64 + instalações 1
 * Fraco  = referência 40..47 + confiabilidade 45..54 + instalações 0
 *
 * Os valores do perfil são o desempenho inicial real do carro. V0 é a versão-base
 * instalada, não um desempenho zero. Desempenho só muda quando uma peça melhorada
 * é pesquisada, fabricada e instalada.
 */
object InitialTeamProfile {
    const val FORTE = 2
    const val MEDIO = 1
    const val FRACO = 0

    data class CarValues(
        val engine: Int,
        val chassis: Int,
        val frontWing: Int,
        val rearWing: Int,
        val brakes: Int,
        val electricPowerUnit: Int
    ) {
        val overall: Int
            get() = (engine + chassis + frontWing + rearWing + brakes + electricPowerUnit + 3) / 6
    }

    @Volatile private var careerSeed: Int = 20261008

    /** Configured once per career/season. A new career receives a new seed, so
     * teams in the same level do not always receive the same opening car. */
    fun configureCareerSeed(seed: Int) { careerSeed = if (seed == 0) 1 else seed }

    fun values(team: TeamDefinition): CarValues {
        val (min, max) = when (team.initialLevel) {
            FORTE -> 56 to 60
            MEDIO -> 48 to 55
            else -> 40 to 47
        }
        val span = max - min + 1
        fun value(slot: Int): Int {
            val seed = careerSeed + team.id * 997 + slot * 313 + team.id * slot * 71
            return min + Random(seed).nextInt(span)
        }
        return CarValues(
            engine = value(1),
            chassis = value(2),
            frontWing = value(3),
            rearWing = value(4),
            brakes = value(5),
            electricPowerUnit = value(6)
        )
    }


    /**
     * Official season-start reliability. Reliability is deliberately independent
     * from raw car performance: teams in the same class start close to one another,
     * but a stronger car is not automatically a more reliable car.
     *
     * Forte: 65..74
     * Médio: 55..64
     * Fraco: 45..54
     */
    fun reliability(team: TeamDefinition, overall: Int = values(team).overall): Int {
        val (min, max) = when (team.initialLevel) {
            FORTE -> 65 to 74
            MEDIO -> 55 to 64
            else -> 45 to 54
        }
        val span = max - min + 1
        val seed = team.id * 53 + overall * 11 + team.id * team.id * 3
        return min + Math.floorMod(seed, span)
    }


    /**
     * Opening ranking uses the canonical Forte/Médio/Fraco team profile, not a mutable
     * career snapshot. This keeps hard-mode selection aligned with the base hardware.
     * The values are deterministic for the configured career seed.
     */
    fun openingRanking(teams: List<TeamDefinition>): List<TeamDefinition> =
        teams.sortedWith(
            compareByDescending<TeamDefinition> { values(it).overall }
                .thenBy { it.id }
        )

    /** Exactly the bottom N teams in the canonical opening-car ranking. */
    fun weakestInitialTeams(teams: List<TeamDefinition>, count: Int): List<TeamDefinition> {
        if (count <= 0 || teams.isEmpty()) return emptyList()
        return openingRanking(teams).takeLast(count.coerceAtMost(teams.size))
    }

    /** Stable opening position (1 = strongest, team count = weakest). */
    fun openingRank(teams: List<TeamDefinition>, teamId: Int): Int =
        openingRanking(teams).indexOfFirst { it.id == teamId }.let { if (it < 0) teams.size else it + 1 }

    /** Single official team-start strength source used by non-car systems.
     *  The level is the canonical season-start classification; no legacy baseCar.
     */
    fun strength(team: TeamDefinition): Int = when (team.initialLevel) {
        FORTE -> 100
        MEDIO -> 75
        else -> 50
    }

    /** Canonical opening cash for every team, used by both player and AI. */
    fun initialBudget(team: TeamDefinition): Long = when (team.initialLevel) {
        FORTE -> 100_000_000L
        MEDIO -> 83_750_000L
        else -> 67_500_000L
    }

    fun facilities(level: Int): Map<Facility, Int> =
        Facility.values().associateWith { level.coerceIn(0, 2) }

    fun teamFacilities(level: Int): TeamFacilitiesState = FacilityEngine.initial(level)

    /** Canonical aggregate projection for the initial car, player or AI. */
    fun aiCarState(team: TeamDefinition): TeamCarState = carState(team)

    /**
     * Legacy aggregate projection of the team's actual opening performance.
     * Piece version is managed by the physical garage and starts at V0; it must not
     * be confused with the team's performance value.
     */
    fun carState(team: TeamDefinition): TeamCarState {
        val profile = values(team)
        return TeamCarState(
            aerodynamics = (profile.frontWing + profile.rearWing) / 2,
            chassis = profile.chassis,
            engine = profile.engine,
            reliability = reliability(team, profile.overall),
            facilities = facilities(team.initialLevel),
            frontWing = profile.frontWing,
            rearWing = profile.rearWing,
            brakes = profile.brakes,
            electricPowerUnit = profile.electricPowerUnit
        ).normalized()
    }
}
