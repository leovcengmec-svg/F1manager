package com.f1teammanager.core.manager

import com.f1teammanager.core.season.TeamDefinition
import kotlin.random.Random

/**
 * Regras oficiais de início de carreira.
 *
 * Forte  = carro 56..60 + confiabilidade 65..74 + instalações 2
 * Médio  = carro 48..55 + confiabilidade 55..64 + instalações 1
 * Fraco  = carro 40..47 + confiabilidade 45..54 + instalações 0
 *
 * Os seis componentes oficiais recebem valores individuais pseudoaleatórios
 * dentro da faixa da equipe, usando o seed persistido da carreira. Assim a
 * mesma equipe não fica pré-programada para ser sempre a mais forte.
 */
object InitialTeamProfile {
    const val FORTE = 2
    const val MEDIO = 1
    const val FRACO = 0

    data class CarValues(
        val engine: Int,
        val chassis: Int,
        val frontWing: Int,
        val rearWing: Int,
        val brakes: Int,
        val electricPowerUnit: Int
    ) {
        val overall: Int
            get() = (engine + chassis + frontWing + rearWing + brakes + electricPowerUnit + 3) / 6
    }

    @Volatile private var careerSeed: Int = 20261008

    /** Configured once per career/season. A new career receives a new seed, so
     * teams in the same level do not always receive the same opening car. */
    fun configureCareerSeed(seed: Int) { careerSeed = if (seed == 0) 1 else seed }

    fun values(team: TeamDefinition): CarValues {
        val (min, max) = when (team.initialLevel) {
            FORTE -> 56 to 60
            MEDIO -> 48 to 55
            else -> 40 to 47
        }
        val span = max - min + 1
        fun value(slot: Int): Int {
            val seed = careerSeed + team.id * 997 + slot * 313 + team.id * slot * 71
            return min + Random(seed).nextInt(span)
        }
        return CarValues(
            engine = value(1),
            chassis = value(2),
            frontWing = value(3),
            rearWing = value(4),
            brakes = value(5),
            electricPowerUnit = value(6)
        )
    }


    /**
     * Official season-start reliability. Reliability is deliberately independent
     * from raw car performance: teams in the same class start close to one another,
     * but a stronger car is not automatically a more reliable car.
     *
     * Forte: 65..74
     * Médio: 55..64
     * Fraco: 45..54
     */
    fun reliability(team: TeamDefinition, overall: Int = values(team).overall): Int {
        val (min, max) = when (team.initialLevel) {
            FORTE -> 65 to 74
            MEDIO -> 55 to 64
            else -> 45 to 54
        }
        val span = max - min + 1
        val seed = team.id * 53 + overall * 11 + team.id * team.id * 3
        return min + Math.floorMod(seed, span)
    }


    /** Single official team-start strength source used by non-car systems.
     *  The level is the canonical season-start classification; no legacy baseCar.
     */
    fun strength(team: TeamDefinition): Int = when (team.initialLevel) {
        FORTE -> 100
        MEDIO -> 75
        else -> 50
    }

    /** Canonical opening cash for every team, used by both player and AI. */
    fun initialBudget(team: TeamDefinition): Long = when (team.initialLevel) {
        FORTE -> 100_000_000L
        MEDIO -> 83_750_000L
        else -> 67_500_000L
    }

    fun facilities(level: Int): Map<Facility, Int> =
        Facility.values().associateWith { level.coerceIn(0, 2) }

    fun teamFacilities(level: Int): TeamFacilitiesState = FacilityEngine.initial(level)

    fun carState(team: TeamDefinition): TeamCarState {
        val c = values(team)
        val reliability = reliability(team, c.overall)
        return TeamCarState(
            aerodynamics = ((c.frontWing + c.rearWing) / 2).coerceIn(1, 100),
            chassis = c.chassis,
            engine = c.engine,
            reliability = reliability,
            facilities = facilities(team.initialLevel),
            frontWing = c.frontWing,
            rearWing = c.rearWing,
            brakes = c.brakes,
            electricPowerUnit = c.electricPowerUnit
        ).normalized()
    }
}
