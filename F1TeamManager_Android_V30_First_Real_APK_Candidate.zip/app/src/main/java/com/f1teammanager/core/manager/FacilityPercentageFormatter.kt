package com.f1teammanager.core.manager

/** Shared display formatter for facility-effect percentages (pt-BR, one decimal). */
object FacilityPercentageFormatter {
    fun format(value: Double): String =
        String.format(java.util.Locale("pt", "BR"), "%.1f", value)
}
