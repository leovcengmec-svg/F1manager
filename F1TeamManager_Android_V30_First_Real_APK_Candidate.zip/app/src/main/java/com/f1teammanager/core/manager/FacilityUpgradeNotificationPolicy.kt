package com.f1teammanager.core.manager

/**
 * Owns the event identity and recovery rules for player facility upgrades.
 * AI notices use the same broad legacy title, so a HOME card must be matched
 * to the player's own start notice rather than selected by title alone.
 */
object FacilityUpgradeNotificationPolicy {
    const val STARTED_TITLE = "MELHORIA DE INSTALAÇÃO"
    const val COMPLETED_TITLE = "MELHORIA DE INSTALAÇÃO CONCLUÍDA"

    fun isCompletionNotice(notice: MarketNotification): Boolean {
        val title = notice.title.trim()
        return title.equals(COMPLETED_TITLE, ignoreCase = true) ||
            (title.equals(STARTED_TITLE, ignoreCase = true) &&
                notice.message.contains("concluída: nível", ignoreCase = true))
    }

    /** Returns true for an explicit player completion or a legacy completion paired with that player's start event. */
    fun isPlayerCompletionNotice(
        notice: MarketNotification,
        playerTeamName: String,
        allNotifications: List<MarketNotification>
    ): Boolean {
        if (!isCompletionNotice(notice) || playerTeamName.isBlank()) return false
        if (notice.message.startsWith("$playerTeamName:", ignoreCase = true) ||
            notice.message.startsWith("$playerTeamName ", ignoreCase = true)) return true

        val completedTransition = transitionInCompletionMessage(notice.message) ?: return false
        return allNotifications.any { started ->
            started.season == notice.season &&
                started.title.trim().equals(STARTED_TITLE, ignoreCase = true) &&
                playerTeamFromStartNotice(started.message).equals(playerTeamName, ignoreCase = true) &&
                started.message.contains("iniciou a melhoria de ${completedTransition.facilityLabel}", ignoreCase = true) &&
                started.message.contains("do nível ${completedTransition.previousLevel} para ${completedTransition.targetLevel}", ignoreCase = true)
        }
    }

    /**
     * Repairs saves where an upgrade is already reflected in the saved facility level
     * but an older build did not persist a player-specific V614 completion alert.
     * It never treats an active upgrade as complete and is idempotent once the
     * explicit completion title has been stored.
     */
    fun recoverMissingPlayerCompletionNotices(
        notifications: List<MarketNotification>,
        playerTeamName: String,
        season: Int,
        currentWeek: Int,
        facilities: TeamFacilitiesState,
        activeUpgrade: FacilityUpgradeState?
    ): List<MarketNotification> {
        if (playerTeamName.isBlank()) return emptyList()
        val recovered = mutableListOf<MarketNotification>()
        val starts = notifications.filter { notice ->
            notice.season == season &&
                notice.title.trim().equals(STARTED_TITLE, ignoreCase = true) &&
                playerTeamFromStartNotice(notice.message).equals(playerTeamName, ignoreCase = true) &&
                notice.message.contains("iniciou a melhoria de", ignoreCase = true)
        }

        starts.forEach startedLoop@ { started ->
            FacilityType.values().forEach typeLoop@ { type ->
                val label = FacilityEngine.label(type)
                val pattern = Regex(
                    "iniciou a melhoria de ${Regex.escape(label)} do nível (\\d+) para (\\d+)",
                    RegexOption.IGNORE_CASE
                )
                val match = pattern.find(started.message) ?: return@typeLoop
                val previousLevel = match.groupValues[1].toIntOrNull() ?: return@typeLoop
                val targetLevel = match.groupValues[2].toIntOrNull() ?: return@typeLoop
                if (targetLevel != previousLevel + 1 || targetLevel !in 1..10) return@typeLoop
                if (activeUpgrade?.facility == type && activeUpgrade.previousLevel == previousLevel && activeUpgrade.targetLevel == targetLevel) return@typeLoop
                if (facilities.level(type) < targetLevel) return@typeLoop

                val transition = "$label concluída: nível $previousLevel → $targetLevel"
                // A generic legacy completion may have been marked read in News Center,
                // while its old HOME card was never shown. Create one explicit V614
                // player-owned completion event so the HOME card gets a fresh read key.
                val hasCompletion = (notifications + recovered).any { notice ->
                    notice.season == season &&
                        notice.title.trim().equals(COMPLETED_TITLE, ignoreCase = true) &&
                        notice.message.contains(transition, ignoreCase = true) &&
                        isPlayerCompletionNotice(notice, playerTeamName, notifications + recovered)
                }
                if (!hasCompletion) {
                    recovered += MarketNotification(
                        season = season,
                        week = currentWeek.coerceIn(1, 56),
                        title = COMPLETED_TITLE,
                        message = "$playerTeamName: $transition após 12 semanas. Aviso recuperado do estado salvo.",
                        important = true,
                        category = MarketNewsCategory.TEAM_EVOLUTION
                    )
                }
            }
        }
        return recovered
    }

    private fun playerTeamFromStartNotice(message: String): String =
        message.substringBefore(" iniciou a melhoria de", missingDelimiterValue = "").trim()

    private data class CompletedTransition(
        val facilityLabel: String,
        val previousLevel: Int,
        val targetLevel: Int
    )

    private fun transitionInCompletionMessage(message: String): CompletedTransition? =
        FacilityType.values().firstNotNullOfOrNull { type ->
            val label = FacilityEngine.label(type)
            val pattern = Regex(
                "${Regex.escape(label)} concluída: nível (\\d+) → (\\d+)",
                RegexOption.IGNORE_CASE
            )
            val match = pattern.find(message) ?: return@firstNotNullOfOrNull null
            CompletedTransition(
                facilityLabel = label,
                previousLevel = match.groupValues[1].toIntOrNull() ?: return@firstNotNullOfOrNull null,
                targetLevel = match.groupValues[2].toIntOrNull() ?: return@firstNotNullOfOrNull null
            )
        }
}
