package com.f1teammanager.core.season

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

/** Performance-driven pilot growth/regression. Class changes are reviewed separately. */
object DriverEvolutionEngine {
    /** The driver championship always contains 80 slots; constructor ranking is a separate 1..40 table. */
    const val DRIVER_GRID_SIZE = 80
    /** Free agents retain the same natural growth rate as contracted drivers. */
    const val FREE_DRIVER_GROWTH_RATE = 1.0
    const val AGE_CYCLE_START = 16
    const val AGE_CYCLE_END = 45
    const val AGE_CYCLE_RESET_REDUCTION_RATE = 0.30
    /** Natural aging can affect every one of the seven driver attributes. */
    private val AGE_ATTRIBUTE_INDICES: IntArray = IntArray(7) { it }
    private val ATTRIBUTE_LABELS = listOf("VEL", "CLA", "ULT", "DEF", "CON", "CHU", "PNE")
    private const val FREE_DRIVER_NEUTRAL_PERFORMANCE_INDEX = 105.0

    /** Official career starting age comes from the 2026 roster supplied by the user. */
    fun careerStartAge(driver: DriverDefinition): Int =
        DriverAgeCatalog.age(driver.name)
            ?: (AGE_CYCLE_START + Math.floorMod(driver.name.hashCode() xor driver.id, AGE_CYCLE_END - AGE_CYCLE_START + 1))

    /** Age cycle runs from the official 2026 age through a full season at 45, then restarts at 16. */
    fun careerCycleIndex(driver: DriverDefinition, season: Int): Int {
        val elapsed = (season - 2026).coerceAtLeast(0)
        val firstCycleYears = (AGE_CYCLE_END + 1 - careerStartAge(driver)).coerceAtLeast(1)
        if (elapsed < firstCycleYears) return 0
        return 1 + (elapsed - firstCycleYears) / (AGE_CYCLE_END - AGE_CYCLE_START + 1)
    }

    fun careerAge(driver: DriverDefinition, season: Int): Int {
        val elapsed = (season - 2026).coerceAtLeast(0)
        val startAge = careerStartAge(driver)
        val firstCycleYears = (AGE_CYCLE_END + 1 - startAge).coerceAtLeast(1)
        return if (elapsed < firstCycleYears) startAge + elapsed
        else AGE_CYCLE_START + ((elapsed - firstCycleYears) % (AGE_CYCLE_END - AGE_CYCLE_START + 1))
    }

    /** Natural development slows after the usual peak years. */
    fun ageGrowthFactor(age: Int): Double = when (age) {
        in Int.MIN_VALUE..21 -> 1.15
        in 22..25 -> 1.05
        in 26..29 -> 0.90
        in 30..32 -> 0.70
        in 33..35 -> 0.48
        in 36..38 -> 0.24
        else -> 0.10
    }

    /** Independent per-GP physical aging pressure; sporting gains are tracked separately. */
    fun ageDeclineRate(age: Int): Double = when (age) {
        in Int.MIN_VALUE..33 -> 0.0
        in 34..35 -> 0.12
        in 36..38 -> 0.30
        in 39..41 -> 0.48
        else -> 0.70
    }

    /**
     * Season expectation derived solely from constructor strength. Qualifying and race
     * share the same car-based center; neither driver's qualifying skill nor Overall
     * changes the target. Each center is wrapped in a tolerance band so finishing anywhere
     * inside that band is considered an expected weekend rather than a miss against one
     * fixed position.
     */
    data class Target(
        val championshipPosition: Int,
        val qualifyingPosition: Int = championshipPosition,
        val racePosition: Int = championshipPosition
    ) {
        val qualifyingMargin: Int get() = positionMargin(qualifyingPosition)
        val raceMargin: Int get() = positionMargin(racePosition)
        val qualifyingMinPosition: Int get() = (qualifyingPosition - qualifyingMargin).coerceAtLeast(1)
        val qualifyingMaxPosition: Int get() = (qualifyingPosition + qualifyingMargin).coerceAtMost(DRIVER_GRID_SIZE)
        val raceMinPosition: Int get() = (racePosition - raceMargin).coerceAtLeast(1)
        val raceMaxPosition: Int get() = (racePosition + raceMargin).coerceAtMost(DRIVER_GRID_SIZE)
    }

    /** Input for season expectations. Car strength is the only permitted performance input. */
    data class TargetInput(
        val driverId: Int,
        val teamId: Int,
        val carStrength: Double
    )

    /**
     * Builds driver expectations exclusively from the 40-car order.
     * Each constructor occupies a two-position block on the 1..80 driver scale;
     * both drivers receive the rounded midpoint of that block for qualifying and race.
     *
     * Driver Overall, qualifying skill, class, potential and other pilot attributes are
     * intentionally absent from TargetInput. They affect actual results, never the goal.
     * Thus a fast and a weak driver in the same car start with exactly the same target.
     */
    fun buildIndividualTargets(inputs: List<TargetInput>): Map<Int, Target> {
        val valid = inputs
            .filter { it.driverId > 0 && it.teamId > 0 }
            .distinctBy { it.driverId }
        if (valid.size != DRIVER_GRID_SIZE) return emptyMap()

        val byTeam = valid.groupBy { it.teamId }
        if (byTeam.size != 40 || byTeam.values.any { it.size != 2 }) return emptyMap()

        val constructorRanks = byTeam.entries
            .map { (teamId, drivers) ->
                teamId to drivers.map { it.carStrength.coerceIn(0.0, 100.0) }.average()
            }
            .sortedWith(compareByDescending<Pair<Int, Double>> { it.second }.thenBy { it.first })
            .mapIndexed { index, (teamId, _) -> teamId to (index + 1) }
            .toMap()

        val targets = linkedMapOf<Int, Target>()
        byTeam.forEach { (teamId, drivers) ->
            val teamRank = constructorRanks.getValue(teamId)
            // Constructor rank R owns driver-grid slots (2R-1, 2R). Since the target
            // is an integer and must be identical for both teammates, use the midpoint
            // rounded upward: P2, P4, ... P80. No driver attribute breaks the tie.
            val center = (teamRank * 2).coerceIn(1, DRIVER_GRID_SIZE)
            val target = Target(
                championshipPosition = center,
                qualifyingPosition = center,
                racePosition = center
            )
            drivers.forEach { input -> targets[input.driverId] = target }
        }
        return targets
    }

    /** Uniform ±3 tolerance: the same expectation width applies throughout P1..P80. */
    private fun positionMargin(@Suppress("UNUSED_PARAMETER") position: Int): Int = 3
    data class PerformanceInput(
        val championshipPosition:Int,
        val points:Int,
        val averageRacePosition:Double,
        val wins:Int,
        val podiums:Int,
        val averageQualifyingPosition:Double,
        val teammateAveragePosition:Double?,
        val teammateComparisons:Int
    )
    data class Evaluation(val index:Double, val tier:String, val multiplier:Double, val delta:Int)

    /** Distinct headline so regressions are visible as first-class market news. */
    fun newsTitle(overallDelta: Int): String =
        if (overallDelta < 0) "REGRESSÃO DE PILOTO" else "EVOLUÇÃO DE PILOTO"

    /**
     * Central News is intentionally an Overall-only feed. Attribute-level ticks may
     * still update the driver's seven ratings and their ledgers, but they must not
     * create a card unless the displayed integer Overall actually changes.
     */
    fun overallMovementNews(
        driverName: String,
        teamName: String,
        round: Int,
        beforeOverall: Int,
        afterOverall: Int,
        reason: String? = null
    ): String? {
        val delta = afterOverall - beforeOverall
        if (delta == 0) return null
        val movement = if (delta > 0) "evoluiu Overall" else "perdeu Overall"
        val signedDelta = if (delta > 0) "+$delta" else delta.toString()
        val reasonText = reason?.takeIf { it.isNotBlank() }?.let { " Motivo: $it." }.orEmpty()
        return "$driverName — $teamName — GP $round: $movement $beforeOverall → $afterOverall ($signedDelta).$reasonText"
    }

    /**
     * Normalizes pending driver-evolution messages before publication. Only a real
     * integer Overall transition is accepted. Attribute-only changes and delta-zero
     * messages are discarded, while the full legacy Motivo suffix is preserved.
     */
    fun normalizeOverallMovementNews(message: String): String? {
        val match = Regex("Overall\\s+(\\d+)\\s*(?:→|->)\\s*(\\d+)", RegexOption.IGNORE_CASE)
            .find(message) ?: return null
        val before = match.groupValues[1].toIntOrNull() ?: return null
        val after = match.groupValues[2].toIntOrNull() ?: return null
        val delta = after - before
        if (delta == 0) return null

        // V725/V727 also stored a development-center message without the legacy
        // colon separator. Stop the prefix immediately before Overall in that format.
        val colonBeforeMovement = message.indexOf(':').takeIf { it >= 0 && it < match.range.first }
        val prefix = (colonBeforeMovement?.let { message.substring(0, it) }
            ?: message.substring(0, match.range.first))
            .trim().trimEnd('—', '-', ':').trim()
        if (prefix.isBlank()) return null

        val movement = if (delta > 0) "evoluiu Overall" else "perdeu Overall"
        val signedDelta = if (delta > 0) "+$delta" else delta.toString()
        val reasonMarker = Regex("Motivo:\\s*", RegexOption.IGNORE_CASE).find(message)
        val storedReason = reasonMarker?.let { message.substring(it.range.last + 1).trim().trimEnd('.') }
        // Older V727 development-center cards had a clear cause in their text but
        // did not serialize Motivo:. Recover only that unambiguous case; do not invent
        // a reason for generic reasonless GP cards.
        val reason = storedReason?.takeIf { it.isNotBlank() } ?: if (
            message.contains("após desenvolvimento", ignoreCase = true) ||
            message.contains("programa de desenvolvimento concluído", ignoreCase = true)
        ) {
            "programa de desenvolvimento de piloto concluído"
        } else null
        if (reason.isNullOrBlank()) return null
        return "$prefix: $movement $before → $after ($signedDelta). Motivo: $reason."
    }

    /**
     * Season-boundary counterpart to [overallMovementNews]. Cycle rollover is not a GP,
     * but it is still reported only when the displayed Overall actually changes.
     */
    fun overallSeasonMovementNews(
        driverName: String,
        teamName: String,
        seasonNumber: Int,
        beforeOverall: Int,
        afterOverall: Int,
        reason: String
    ): String? {
        val delta = afterOverall - beforeOverall
        if (delta == 0) return null
        val movement = if (delta > 0) "evoluiu Overall" else "perdeu Overall"
        val signedDelta = if (delta > 0) "+$delta" else delta.toString()
        val reasonText = reason.takeIf { it.isNotBlank() }?.let { " Motivo: $it." }.orEmpty()
        return "$driverName — $teamName — abertura da temporada $seasonNumber: $movement $beforeOverall → $afterOverall ($signedDelta).$reasonText"
    }

    /**
     * Identifies V725–V727 attribute-only cards already stored in older saves.
     * These are hidden in the pilot-evolution feed; non-movement driver events such
     * as class changes and development-program events remain available.
     */
    fun isLegacyAttributeMovementNews(title: String, message: String): Boolean {
        val normalizedTitle = title.trim().uppercase()
        if (normalizedTitle in setOf(
                "EVOLUÇÃO ESPORTIVA",
                "REGRESSÃO ESPORTIVA",
                "REGRESSÃO POR IDADE",
                "REINÍCIO DO CICLO ETÁRIO",
                "EVOLUÇÃO DE PILOTO",
                "REGRESSÃO DE PILOTO"
            )) return true

        val hasOverallTransition = Regex(
            "Overall\\s+\\d+\\s*(?:→|->)\\s*\\d+",
            RegexOption.IGNORE_CASE
        ).containsMatchIn(message)
        if (hasOverallTransition) return true // if normalization rejected it, it was +0/invalid

        return message.contains("desenvolvimento esportivo independente da idade", ignoreCase = true) ||
            message.contains("regressão esportiva independente da idade", ignoreCase = true) ||
            message.contains("declínio natural da idade (", ignoreCase = true) ||
            (message.contains("reinício do ciclo etário", ignoreCase = true) &&
                message.contains("redução de 30%", ignoreCase = true) &&
                message.contains("atributo", ignoreCase = true))
    }

    /** Human-readable cause for an Overall movement; individual attribute names stay out of News. */
    fun overallMovementReason(tick: TickResult, overallDelta: Int): String {
        if (tick.ageCycleRestarted) return "reinício do ciclo etário aos 16 anos com redução de 30% em cada atributo"
        val ageLoss = tick.ageAttributeLossesThisTick.sum()
        val performanceDelta = tick.performanceAttributeDeltas.sum()
        return when {
            overallDelta < 0 && ageLoss > 0 && performanceDelta >= 0 -> "declínio natural da idade"
            overallDelta < 0 && performanceDelta < 0 -> "desempenho esportivo abaixo das expectativas"
            overallDelta < 0 -> "declínio natural da idade/forma esportiva"
            overallDelta > 0 && performanceDelta > 0 -> "desempenho esportivo acima das expectativas"
            overallDelta > 0 -> "evolução natural do piloto"
            else -> "sem alteração no Overall"
        }
    }

    fun performanceTier(index: Double): String = when {
        index >= 115.0 -> "Excepcional"
        index >= 105.0 -> "Excelente"
        index >= 98.0 -> "Muito bom"
        index >= 92.0 -> "Bom"
        index >= 85.0 -> "Normal"
        index >= 75.0 -> "Abaixo do esperado"
        index >= 60.0 -> "Ruim"
        else -> "Muito ruim"
    }

    /**
     * Legacy display multiplier retained for compatibility with summary screens.
     * Actual progression now uses performanceEvolutionRate and the shared per-GP tick.
     * Performance below/above expectation slows/accelerates growth; the evolution
     * category independently limits annual gains per attribute.
     */
    fun performanceUtilization(index: Double): Double = when {
        index >= 115.0 -> 1.25
        index >= 105.0 -> 1.15
        index >= 98.0 -> 1.05
        index >= 92.0 -> 1.00
        index >= 85.0 -> 0.85
        index >= 75.0 -> 0.65
        index >= 60.0 -> 0.45
        else -> 0.30
    }

    /**
     * Range-aware per-GP evaluation. A result inside the driver's own target band is
     * neutral (105, the normal growth baseline); performance is rewarded/penalized only outside the tolerance band.
     * Missing rows use the individual target center, never a synthetic grid position.
     */
    fun gpPerformanceIndex(target: Target, qualifyingPosition: Int, racePosition: Int): Double {
        val qCenter = target.qualifyingPosition.coerceIn(1, DRIVER_GRID_SIZE)
        val rCenter = target.racePosition.coerceIn(1, DRIVER_GRID_SIZE)
        val q = if (qualifyingPosition <= 0) qCenter else qualifyingPosition.coerceIn(1, DRIVER_GRID_SIZE)
        val r = if (racePosition <= 0) rCenter else racePosition.coerceIn(1, DRIVER_GRID_SIZE)
        val qualifyingScore = positionBandScore(q, qCenter, target.qualifyingMargin)
        val raceScore = positionBandScore(r, rCenter, target.raceMargin)
        return (qualifyingScore * 0.40 + raceScore * 0.60).coerceIn(25.0, 150.0)
    }

    private fun positionBandScore(actual: Int, center: Int, margin: Int): Double {
        val minPosition = (center - margin).coerceAtLeast(1)
        val maxPosition = (center + margin).coerceAtMost(DRIVER_GRID_SIZE)
        return when {
            actual < minPosition -> 105.0 + (minPosition - actual) * 5.0
            actual > maxPosition -> 105.0 - (actual - maxPosition) * 5.0
            else -> 105.0
        }
    }

    /**
     * Separate season-level exceptional-performance score used only to unlock the
     * optional +5 class band. The regular GP index above intentionally keeps its
     * ±3-position tolerance and remains the source for normal growth/regression.
     * The car-only target center remains the reference (five points per place above/below
     * target). A pole and a race win each add a separate 50-point achievement bonus, so a
     * driver whose car target is already P1 can still demonstrate exceptional results.
     * The 40/60 qualifying/race weights remain identical to the sporting model.
     */
    fun classUnlockPerformanceIndex(
        target: Target,
        qualifyingPosition: Int,
        racePosition: Int
    ): Double {
        val qCenter = target.qualifyingPosition.coerceIn(1, DRIVER_GRID_SIZE)
        val rCenter = target.racePosition.coerceIn(1, DRIVER_GRID_SIZE)
        val q = if (qualifyingPosition <= 0) qCenter else qualifyingPosition.coerceIn(1, DRIVER_GRID_SIZE)
        val r = if (racePosition <= 0) rCenter else racePosition.coerceIn(1, DRIVER_GRID_SIZE)
        // The regular GP index deliberately treats the full target band as neutral.
        // The +5 class band needs a distinct signal: reward overperformance against
        // the car-only target, while also recognizing pole positions and race wins.
        // This lets a driver in the strongest car earn the band through poles/wins,
        // even when P1 is already the car-derived target and cannot be beaten.
        val qScore = (100.0 + (qCenter - q) * 5.0 + if (q == 1) 50.0 else 0.0)
            .coerceIn(25.0, 150.0)
        val rScore = (100.0 + (rCenter - r) * 5.0 + if (r == 1) 50.0 else 0.0)
            .coerceIn(25.0, 150.0)
        return (qScore * 0.40 + rScore * 0.60).coerceIn(25.0, 150.0)
    }

    /**
     * Mechanical/equipment DNFs are not driver-performance evidence. Keep that GP's
     * race component neutral at the driver's target while preserving qualifying evidence.
     * Driver-caused accidents remain a sporting result and are still evaluated.
     */
    fun racePositionForEvolution(target: Target, actualPosition: Int?, status: String?): Int {
        val position = actualPosition?.takeIf { it in 1..DRIVER_GRID_SIZE } ?: target.racePosition
        val normalized = status.orEmpty().uppercase()
        if (!normalized.startsWith("DNF")) return position
        val equipmentOrExternalFailure = listOf(
            "PANE", "FALHA", "SEM COMBUSTÍVEL", "PNEU DEGRADADO", "COLISÃO"
        ).any(normalized::contains)
        return if (equipmentOrExternalFailure) target.racePosition.coerceIn(1, DRIVER_GRID_SIZE) else position
    }

    /**
     * Legacy center-only scoring retained for compatibility with older integrations.
     * Active career and Team Principal progression use the range-aware Target overload.
     * Missing positions are treated as neutral against the legacy center.
     */
    fun gpPerformanceIndex(targetPosition:Int, qualifyingPosition:Int, racePosition:Int): Double {
        val target = targetPosition.coerceIn(1,DRIVER_GRID_SIZE)
        val q = if (qualifyingPosition <= 0) target else qualifyingPosition.coerceIn(1,DRIVER_GRID_SIZE)
        val r = if (racePosition <= 0) target else racePosition.coerceIn(1,DRIVER_GRID_SIZE)
        val qualifyingScore = (100.0 + (target - q) * 5.0).coerceIn(25.0,150.0)
        val raceScore = (100.0 + (target - r) * 5.0).coerceIn(25.0,150.0)
        return (qualifyingScore * 0.40 + raceScore * 0.60).coerceIn(25.0,150.0)
    }

    /**
     * V649 phase tokens are performance states, not an age/career clock. The old
     * PEAK token is accepted as STABLE so existing saves never enter timed decline.
     */
    fun normalizePhase(phase: String?): String = when (phase) {
        "GROWING", "REGRESSION", "STABLE" -> phase
        "PEAK" -> "STABLE"
        else -> "GROWING"
    }

    /** A pilot starts developing only while there is meaningful room below potential. */
    fun initialPhase(driver: DriverDefinition): String {
        val current = DriverProfileCatalog.overall(driver.ratings())
        return if (driver.potentialOverall.coerceIn(current, 100) - current <= 1) "STABLE" else "GROWING"
    }

    /**
     * Signed, performance-driven development rate per completed GP. A neutral
     * weekend preserves most progress; repeated poor performances are required
     * before the negative fractional bank becomes an attribute loss.
     */
    fun performanceEvolutionRate(index: Double): Double = when {
        index >= 115.0 -> 1.30
        index >= 105.0 -> 1.00
        index >= 98.0 -> 0.50
        index >= 92.0 -> 0.20
        index >= 85.0 -> 0.0
        index >= 75.0 -> -0.20
        index >= 60.0 -> -0.45
        else -> -0.70
    }

    /** Minimum real GP sample before a season average can unlock the extra class band. */
    const val CLASS_MARGIN_MINIMUM_GP_SAMPLE = 5

    /** Performance unlocks the extra Overall band in one-point steps after a real sample. */
    fun performanceClassMargin(
        seasonPerformanceAverage: Double?,
        completedGps: Int = CLASS_MARGIN_MINIMUM_GP_SAMPLE
    ): Int {
        if (completedGps < CLASS_MARGIN_MINIMUM_GP_SAMPLE) return 0
        val average = seasonPerformanceAverage?.takeIf { it.isFinite() } ?: return 0
        // The class-unlock score is car-relative and starts at 100 for a result
        // exactly on the car-derived target. This calibration lets a driver in a
        // front-running car earn the first extra point through consistently meeting
        // that target, while requiring progressively stronger results for +2..+5.
        return when {
            average >= 125.0 -> 5
            average >= 120.0 -> 4
            average >= 115.0 -> 3
            average >= 110.0 -> 2
            average >= 105.0 -> 1
            else -> 0
        }
    }

    /**
     * Maximum temporary class margin available to natural or facility development.
     * Médio always develops normally; Forte does so while free. Forte under contract
     * and every Pro driver must earn each additional point through season performance.
     * Lenda already occupies the global Overall ceiling and receives no extra band.
     */
    fun classGrowthMargin(
        driverClass: String,
        isContracted: Boolean,
        seasonPerformanceAverage: Double?,
        earnedClassMargin: Int = 0,
        completedGps: Int = CLASS_MARGIN_MINIMUM_GP_SAMPLE
    ): Int {
        val canonical = DriverClassProgressionEngine.canonicalClass(driverClass) ?: driverClass
        val earned = earnedClassMargin.coerceIn(0, 5)
        val measured = performanceClassMargin(seasonPerformanceAverage, completedGps)
        return when (canonical) {
            "Médio" -> 5
            "Forte" -> if (isContracted) maxOf(measured, earned) else 5
            "Pro" -> maxOf(measured, earned)
            "Lenda" -> 0
            else -> 0
        }
    }

    /** Monotonic high-water mark; a margin earned after a valid GP sample never shrinks. */
    fun nextEarnedClassMargin(
        previousMargin: Int,
        seasonPerformanceAverage: Double?,
        completedGps: Int = CLASS_MARGIN_MINIMUM_GP_SAMPLE
    ): Int = maxOf(
        previousMargin.coerceIn(0, 5),
        performanceClassMargin(seasonPerformanceAverage, completedGps)
    )

    /**
     * Class is a soft growth-speed factor only for classes whose extra band must be
     * earned by results. Médio and free Forte drivers retain their normal speed.
     */
    fun classGrowthFactor(driverClass: String, currentOverall: Int, isContracted: Boolean = true): Double {
        val canonical = DriverClassProgressionEngine.canonicalClass(driverClass) ?: driverClass
        if (canonical == "Médio" || (canonical == "Forte" && !isContracted) || canonical == "Lenda") return 1.0
        val excess = (currentOverall - DriverProfileCatalog.ceiling(canonical)).coerceAtLeast(0)
        return when {
            excess <= 0 -> 1.0
            excess <= 2 -> 0.90
            excess <= 4 -> 0.80
            else -> 0.70
        }
    }

    data class TickResult(
        val driver: DriverDefinition,
        val bank: Double,
        val phase: String,
        val attributeDelta: Int,
        /** Fractional age-pressure bank, stored separately from form/performance regression. */
        val ageBank: Double = 0.0,
        /** Legacy-named persisted ledger; now tracks age losses across all seven attributes. */
        val agePhysicalLosses: IntArray = IntArray(7),
        /** Legacy-named high-water marks; records all seven physical attribute peaks within the current age cycle. */
        val agePhysicalPeaks: IntArray = IntArray(7),
        val ageCycleIndex: Int = 0,
        val ageCycleRestarted: Boolean = false,
        val ageRecoveredPoints: Int = 0,
        /** Attribute changes from natural/performance development, positive or negative. */
        val performanceAttributeDeltas: IntArray = IntArray(7),
        /** Age-only losses applied on this GP, represented as positive loss counts. */
        val ageAttributeLossesThisTick: IntArray = IntArray(7),
        /** Legacy recovery ledger retained for save/test compatibility; V725 no longer recovers 50%. */
        val ageCycleRecoveryByAttribute: IntArray = IntArray(7),
        /** Negative per-attribute deltas applied once when the pilot restarts at age 16. */
        val ageCycleResetByAttribute: IntArray = IntArray(7)
    )

    /** Natural aging draws losses from all seven attributes, never from sporting form. */
    private fun applyAgeAttributeRegression(
        driver: DriverDefinition,
        intendedLoss: Int,
        random: Random
    ): Pair<DriverDefinition, IntArray> {
        if (intendedLoss <= 0) return driver to IntArray(7)
        val values = driver.ratings()
        val losses = IntArray(7)
        var remaining = intendedLoss
        while (remaining > 0) {
            val eligible = AGE_ATTRIBUTE_INDICES.filter { values[it] > 40 }
            if (eligible.isEmpty()) break
            val chosen = eligible[random.nextInt(eligible.size)]
            values[chosen] = (values[chosen] - 1).coerceAtLeast(40)
            losses[chosen]++
            remaining--
        }
        return driver.withRatings(values) to losses
    }

    /** Format exactly which of the seven attributes changed in an evolution event. */
    fun describeAttributeDeltas(deltas: IntArray): String {
        require(deltas.size == 7) { "O detalhamento precisa conter os sete atributos" }
        return ATTRIBUTE_LABELS.indices.mapNotNull { index ->
            val delta = deltas[index]
            if (delta == 0) null else "${ATTRIBUTE_LABELS[index]} ${if (delta > 0) "+" else ""}$delta"
        }.joinToString(", ")
    }

    /**
     * A news reason is assembled from the actual ledgers, not inferred from age or
     * the net Overall alone. Free agents have natural development and aging only;
     * contracted drivers can also have sporting-performance growth/regression.
     */
    fun describeTickCauses(tick: TickResult, freeAgent: Boolean): String {
        val parts = mutableListOf<String>()
        val cycleReset = tick.ageCycleResetByAttribute
        if (cycleReset.any { it < 0 }) {
            parts += "reinício aos 16 anos: redução de 30% nos sete atributos (${describeAttributeDeltas(cycleReset)})"
        }
        val performance = tick.performanceAttributeDeltas
        if (performance.any { it != 0 }) {
            val label = when {
                freeAgent -> "desenvolvimento natural"
                performance.any { it < 0 } -> "desempenho abaixo das expectativas"
                else -> "desempenho acima das expectativas"
            }
            parts += "$label: ${describeAttributeDeltas(performance)}"
        }
        val ageLosses = tick.ageAttributeLossesThisTick
        if (ageLosses.any { it > 0 }) {
            parts += "declínio natural da idade: ${describeAttributeDeltas(IntArray(7) { -ageLosses[it] })}"
        }
        return parts.joinToString("; ").ifBlank { "sem alteração de atributo neste GP" }
    }

    fun hasAttributeMovement(tick: TickResult): Boolean =
        tick.performanceAttributeDeltas.any { it != 0 } ||
            tick.ageAttributeLossesThisTick.any { it > 0 } ||
            tick.ageCycleRecoveryByAttribute.any { it > 0 } ||
            tick.ageCycleResetByAttribute.any { it < 0 }

    /**
     * Shared GP progression path. Performance/form regression and natural aging are
     * separate ledgers. The cycle transition is an explicit 30% attribute reset,
     * independent of performance development and applied exactly once at age 45 -> 16.
     */
    fun applyPerformanceTick(
        driver: DriverDefinition,
        performanceIndex: Double,
        currentBank: Double,
        annualGains: IntArray,
        random: Random,
        facilityGrowthEfficiency: Double = 1.0,
        /** Average exceptional-performance score in the current season; unlocks the optional class band. */
        seasonPerformanceAverage: Double? = null,
        /** Persisted high-water class margin already earned during this season. */
        earnedClassMargin: Int = 0,
        /** Number of real qualifying/race samples behind the seasonal unlock average. */
        seasonPerformanceSamples: Int = CLASS_MARGIN_MINIMUM_GP_SAMPLE,
        careerAge: Int? = null,
        currentAgeBank: Double = 0.0,
        currentAgePhysicalLosses: IntArray = IntArray(7),
        currentAgePhysicalPeaks: IntArray = driver.ratings(),
        currentAgeCycleIndex: Int? = null,
        careerCycleIndex: Int? = null,
        /** Whether the driver has an active team contract this season. */
        isContracted: Boolean = true
    ): TickResult {
        require(annualGains.size == 7) { "O controle anual precisa ter sete atributos" }
        require(currentAgePhysicalLosses.size == 7) { "O histórico de perdas físicas precisa ter sete atributos" }
        require(currentAgePhysicalPeaks.size == 7) { "O pico físico precisa ter sete atributos" }

        val beforeOverall = DriverProfileCatalog.overall(driver.ratings())
        val rawRate = performanceEvolutionRate(performanceIndex)
        val age = careerAge
        val growthFactor = age?.let(::ageGrowthFactor) ?: 1.0
        val agingPressure = age?.let(::ageDeclineRate) ?: 0.0
        val classRateFactor = if (rawRate > 0.0) classGrowthFactor(driver.driverClass, beforeOverall, isContracted) else 1.0
        val performanceRate = if (rawRate > 0.0) rawRate * growthFactor * classRateFactor else rawRate
        val annualProfileBudget = DriverProfileCatalog.maxAnnualGain(driver.evolution) * 7.0 / 150.0

        var updated = driver.normalized()
        var bank = currentBank
        var ageBank = currentAgeBank.coerceIn(0.0, 0.99)
        var ageLosses = currentAgePhysicalLosses.copyOf().also { values ->
            values.indices.forEach { values[it] = values[it].coerceAtLeast(0) }
        }
        var agePeaks = currentAgePhysicalPeaks.copyOf().also { values ->
            val current = driver.ratings()
            values.indices.forEach { values[it] = max(values[it].coerceIn(40, 100), current[it]) }
        }
        val resultingCycle = careerCycleIndex ?: currentAgeCycleIndex ?: 0
        val cycleRestarted = careerCycleIndex != null && currentAgeCycleIndex != null && careerCycleIndex > currentAgeCycleIndex
        val cycleRecoveryByAttribute = IntArray(7) // deliberately zero in V725; no 50% recovery remains

        if (cycleRestarted) {
            val ratingsBeforeReset = updated.ratings()
            val resetRatings = IntArray(7) { index ->
                (ratingsBeforeReset[index].coerceIn(40, 100) * 70 / 100).coerceAtLeast(40)
            }
            updated = updated.withRatings(resetRatings)
            val resetDeltas = IntArray(7) { index -> resetRatings[index] - ratingsBeforeReset[index] }
            val resetOverall = DriverProfileCatalog.overall(resetRatings)
            val resetLosses = IntArray(7)
            // New age cycle starts clean: old age-loss pressure and peaks never leak
            // into the new cycle. The historical snapshot records the old and new state.
            return TickResult(
                driver = updated,
                bank = 0.0,
                phase = "REGRESSION",
                attributeDelta = resetOverall - beforeOverall,
                ageBank = 0.0,
                agePhysicalLosses = resetLosses,
                agePhysicalPeaks = resetRatings.copyOf(),
                ageCycleIndex = resultingCycle,
                ageCycleRestarted = true,
                ageRecoveredPoints = 0,
                performanceAttributeDeltas = IntArray(7),
                ageAttributeLossesThisTick = IntArray(7),
                ageCycleRecoveryByAttribute = cycleRecoveryByAttribute,
                ageCycleResetByAttribute = resetDeltas
            )
        }

        val classMargin = classGrowthMargin(
            driver.driverClass, isContracted, seasonPerformanceAverage, earnedClassMargin, seasonPerformanceSamples
        )
        val performanceCeiling = (DriverProfileCatalog.ceiling(driver.driverClass) + classMargin).coerceAtMost(100)
        val growthCeiling = minOf(driver.potentialOverall.coerceIn(40, 100), performanceCeiling)
        when {
            performanceRate > 0.0 && DriverProfileCatalog.overall(updated.ratings()) < growthCeiling -> {
                bank += annualProfileBudget * performanceRate
            }
            performanceRate < 0.0 -> bank -= annualProfileBudget * -performanceRate
            performanceRate > 0.0 && DriverProfileCatalog.overall(updated.ratings()) >= driver.potentialOverall -> bank = 0.0
        }

        // Apply performance-driven development/regression independently from age.
        val ratingsBeforePerformance = updated.ratings()
        if (bank >= 1.0) {
            val requested = bank.toInt()
            val before = updated.ratings()
            updated = applyPositiveGain(
                updated, requested, annualGains, random,
                perAttributeCap = DriverProfileCatalog.maxAnnualGain(driver.evolution),
                allowClassCeilingExceed = classMargin > 0,
                classCeilingMargin = classMargin,
                bypassClassCeiling = false
            )
            val applied = (updated.ratings().sum() - before.sum()).coerceAtLeast(0)
            bank = if (applied > 0) bank - applied else bank.coerceAtMost(0.99)
        } else if (bank <= -1.0) {
            val requested = (-bank).toInt()
            val before = updated.ratings()
            updated = applyRegression(updated, requested, random)
            val removed = (before.sum() - updated.ratings().sum()).coerceAtLeast(0)
            bank = if (removed > 0) bank + removed else 0.0
        }
        val ratingsAfterPerformance = updated.ratings()
        val performanceAttributeDeltas = IntArray(7) { index ->
            ratingsAfterPerformance[index] - ratingsBeforePerformance[index]
        }

        // Natural aging draws its own losses across all seven attributes and has a
        // separate ledger, so cycle recovery never reverses sporting-performance losses.
        if (agingPressure > 0.0) ageBank += annualProfileBudget * agingPressure
        var ageAttributeLossesThisTick = IntArray(7)
        if (ageBank >= 1.0) {
            val requested = ageBank.toInt()
            val ageRegression = applyAgeAttributeRegression(updated, requested, random)
            ageAttributeLossesThisTick = ageRegression.second.copyOf()
            updated = ageRegression.first
            val removed = ageRegression.second.sum()
            ageRegression.second.indices.forEach { index ->
                ageLosses[index] = (ageLosses[index] + ageRegression.second[index]).coerceAtMost(100)
            }
            ageBank = if (removed > 0) (ageBank - removed).coerceAtMost(0.99) else 0.99
        }

        val afterRatings = updated.ratings()
        AGE_ATTRIBUTE_INDICES.forEach { index ->
            agePeaks[index] = max(agePeaks[index], afterRatings[index]).coerceIn(40, 100)
        }
        val afterOverall = DriverProfileCatalog.overall(afterRatings)
        val netCareerRate = performanceRate - agingPressure
        val nextPhase = when {
            afterOverall >= updated.potentialOverall -> "STABLE"
            netCareerRate < 0.0 -> "REGRESSION"
            netCareerRate >= 0.50 -> "GROWING"
            else -> "STABLE"
        }
        return TickResult(
            driver = updated,
            bank = bank.coerceIn(-0.99, 0.99),
            phase = nextPhase,
            attributeDelta = afterOverall - beforeOverall,
            ageBank = ageBank.coerceIn(0.0, 0.99),
            agePhysicalLosses = ageLosses,
            agePhysicalPeaks = agePeaks,
            ageCycleIndex = resultingCycle,
            ageCycleRestarted = cycleRestarted,
            ageRecoveredPoints = 0,
            performanceAttributeDeltas = performanceAttributeDeltas,
            ageAttributeLossesThisTick = ageAttributeLossesThisTick,
            ageCycleRecoveryByAttribute = cycleRecoveryByAttribute,
            ageCycleResetByAttribute = IntArray(7)
        )
    }

    /**
     * Free agents progress at 100% of the same natural rate as contracted drivers.
     * Their class-specific ceiling still applies: Médio and free Forte can use the full
     * five-point band, while Pro needs real season performance before crossing its cap.
     * A negative performance bank earned while previously contracted is not carried into
     * the free-agent phase because no current team results exist to justify that penalty.
     */
    fun applyFreeDriverTick(
        driver: DriverDefinition,
        currentBank: Double,
        annualGains: IntArray,
        random: Random,
        careerAge: Int? = null,
        currentAgeBank: Double = 0.0,
        currentAgePhysicalLosses: IntArray = IntArray(7),
        currentAgePhysicalPeaks: IntArray = driver.ratings(),
        currentAgeCycleIndex: Int? = null,
        careerCycleIndex: Int? = null,
        /** Last completed season's real evidence; Pro free agents need this to use the +5 band. */
        seasonPerformanceAverage: Double? = null,
        earnedClassMargin: Int = 0,
        seasonPerformanceSamples: Int = 0
    ): TickResult = applyPerformanceTick(
        driver = driver,
        performanceIndex = FREE_DRIVER_NEUTRAL_PERFORMANCE_INDEX,
        currentBank = currentBank.coerceAtLeast(0.0),
        annualGains = annualGains,
        random = random,
        facilityGrowthEfficiency = FREE_DRIVER_GROWTH_RATE,
        careerAge = careerAge,
        currentAgeBank = currentAgeBank,
        currentAgePhysicalLosses = currentAgePhysicalLosses,
        currentAgePhysicalPeaks = currentAgePhysicalPeaks,
        currentAgeCycleIndex = currentAgeCycleIndex,
        careerCycleIndex = careerCycleIndex,
        seasonPerformanceAverage = seasonPerformanceAverage,
        earnedClassMargin = earnedClassMargin,
        seasonPerformanceSamples = seasonPerformanceSamples,
        isContracted = false
    )

    fun minimumOverall(driverClass:String):Int = DriverProfileCatalog.minimumOverall(driverClass)

    /** Performance regression has a global safety floor; class changes follow two seasons. */
    @Suppress("UNUSED_PARAMETER")
    fun minimumOverall(driver:DriverDefinition):Int = 40

    @Suppress("UNUSED_PARAMETER")
    fun evaluate(driver:DriverDefinition, target:Target, input:PerformanceInput): Evaluation {
        val championship = ratio(target.championshipPosition.toDouble(), input.championshipPosition.toDouble())
        val expectedPoints = (((81-target.championshipPosition).coerceAtLeast(1)/80.0)*450.0)
        val points = ratio(expectedPoints,input.points.toDouble().coerceAtLeast(0.0),0.35)
        val race = ratio(target.championshipPosition.toDouble(),input.averageRacePosition.coerceAtLeast(1.0))
        val expectedWins = ((81-target.championshipPosition).coerceAtLeast(1)/80.0)*12.0
        val expectedPodiums = ((81-target.championshipPosition).coerceAtLeast(1)/80.0)*25.0
        val achievement=(ratio(expectedWins,input.wins.toDouble(),0.35)+ratio(expectedPodiums,input.podiums.toDouble(),0.35))/2.0
        val qualifying=ratio(target.championshipPosition.toDouble(),input.averageQualifyingPosition.coerceAtLeast(1.0))
        val teammate=if(input.teammateAveragePosition!=null&&input.teammateComparisons>0) ratio(input.teammateAveragePosition,input.averageRacePosition.coerceAtLeast(1.0)) else 100.0
        val index=championship*.30+points*.20+race*.15+achievement*.15+qualifying*.10+teammate*.10
        val tier=performanceTier(index); val multiplier=performanceUtilization(index)
        return Evaluation(index.coerceIn(0.0,150.0),tier,multiplier,0)
    }

    fun applyPositiveGain(driver:DriverDefinition,intendedGain:Int,annualGains:IntArray,random:Random,perAttributeCap:Int=DriverProfileCatalog.maxAnnualGain(driver.evolution), allowClassCeilingExceed:Boolean=false, classCeilingMargin:Int=0, bypassClassCeiling:Boolean=false):DriverDefinition {
        if(intendedGain<=0)return driver.normalized(); require(annualGains.size==7)
        val next=driver.ratings(); val potential=driver.potentialOverall.coerceIn(DriverProfileCatalog.overall(next),100)
        val targetSum=potential*7
        var remaining=intendedGain
        while(remaining>0 && next.sum()<targetSum){
            val currentOverall = DriverProfileCatalog.overall(next)
            val classCeiling = DriverProfileCatalog.ceiling(driver.driverClass)
            val effectiveCeiling = (classCeiling + if (allowClassCeilingExceed) classCeilingMargin.coerceIn(0, 5) else 0).coerceAtMost(100)
            if (!bypassClassCeiling && currentOverall >= effectiveCeiling) break
            val eligible=(0..6).filter{next[it]<100&&annualGains[it]<perAttributeCap}
            if(eligible.isEmpty())break
            // Preserve the driver's natural profile while giving underdeveloped
            // attributes a modest balancing chance. The shared performance tick applies
            // the class soft threshold before this attribute allocation.
            val weights=eligible.map{ i ->
                val natural=driver.ratings()[i].toDouble(); val head=(100-next[i]).toDouble()
                0.35 + natural/100.0*0.65 + head/60.0*0.80
            }
            val total=weights.sum(); var pick=random.nextDouble()*total; var chosen=eligible.last()
            for(k in eligible.indices){ pick-=weights[k]; if(pick<=0){chosen=eligible[k];break} }
            next[chosen]++; annualGains[chosen]++; remaining--
        }
        return driver.withRatings(next)
    }

    fun applyRegression(driver:DriverDefinition,intendedLoss:Int,random:Random):DriverDefinition {
        if(intendedLoss<=0)return driver.normalized()
        val next=driver.ratings()
        val floor=minimumOverall(driver)
        repeat(intendedLoss){
            // Career regression has a global safety floor of Overall 40. Class
            // eligibility is reviewed independently after two seasons of performance.
            if ((next.sum()-1) / 7 < floor) return@repeat
            val eligible=(0..6).filter{next[it]>40}
            if(eligible.isEmpty())return@repeat
            val excess=(next.sum()/7 - floor).coerceAtLeast(0).toDouble()
            val weights: List<Double> = eligible.map{ i ->
                0.35 + (next[i]-40)/60.0 + excess/50.0
            }
            val total=weights.sum(); var pick=random.nextDouble()*total; var chosen=eligible.last()
            for(k in eligible.indices){pick-=weights[k];if(pick<=0){chosen=eligible[k];break}}
            next[chosen]--
        }
        return driver.withRatings(next)
    }

    @Suppress("UNUSED_PARAMETER")
    fun recoveryCap(driver:DriverDefinition):Int=1
    fun applyDelta(driver:DriverDefinition,delta:Int):DriverDefinition=if(delta>0)applyPositiveGain(driver,delta,IntArray(7),Random.Default) else applyRegression(driver,-delta,Random.Default)
    private fun ratio(expected:Double,actual:Double,floor:Double=.50):Double{if(expected<=0)return 100.0;if(actual<=0)return 150.0;return(expected/actual*100.0).coerceIn(floor*100.0,150.0)}
    private fun DriverDefinition.ratings():IntArray = com.f1teammanager.core.AttributeBounds.ratings(
        intArrayOf(speed,qualifying,overtaking,defense,consistency,wet,tyre)
    )
    private fun DriverDefinition.withRatings(a:IntArray):DriverDefinition = copy(
        speed=a[0].coerceIn(40,100), qualifying=a[1].coerceIn(40,100),
        overtaking=a[2].coerceIn(40,100), defense=a[3].coerceIn(40,100),
        consistency=a[4].coerceIn(40,100), wet=a[5].coerceIn(40,100), tyre=a[6].coerceIn(40,100)
    ).normalized()
}
