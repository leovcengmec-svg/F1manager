package com.f1teammanager.core.season

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.random.Random

/** Continuous career-cycle evolution. Class and evolution type remain immutable. */
object DriverEvolutionEngine {
    data class Target(val championshipPosition:Int)
    data class PerformanceInput(
        val championshipPosition:Int,
        val points:Int,
        val averageRacePosition:Double,
        val wins:Int,
        val podiums:Int,
        val averageQualifyingPosition:Double,
        val teammateAveragePosition:Double?,
        val teammateComparisons:Int
    )
    data class Evaluation(val index:Double, val tier:String, val multiplier:Double, val delta:Int)

    fun performanceTier(index: Double): String = when {
        index >= 115.0 -> "Excepcional"
        index >= 105.0 -> "Excelente"
        index >= 98.0 -> "Muito bom"
        index >= 92.0 -> "Bom"
        index >= 85.0 -> "Normal"
        index >= 75.0 -> "Abaixo do esperado"
        index >= 60.0 -> "Ruim"
        else -> "Muito ruim"
    }

    fun performanceUtilization(index: Double): Double = when (performanceTier(index)) {
        "Excepcional" -> 1.00
        "Excelente" -> 0.90
        "Muito bom" -> 0.80
        "Bom" -> 0.70
        "Normal" -> 0.60
        "Abaixo do esperado" -> 0.45
        "Ruim" -> 0.30
        else -> 0.15
    }

    /** GP performance is deliberately 40% qualifying + 60% race. */
    fun gpPerformanceIndex(targetPosition:Int, qualifyingPosition:Int, racePosition:Int): Double {
        val target = targetPosition.coerceIn(1,80).toDouble()
        val q = if (qualifyingPosition <= 0) 80.0 else qualifyingPosition.coerceIn(1,80).toDouble()
        val r = if (racePosition <= 0) 80.0 else racePosition.coerceIn(1,80).toDouble()
        val qualifyingScore = (target / q * 100.0).coerceIn(0.0,150.0)
        val raceScore = (target / r * 100.0).coerceIn(0.0,150.0)
        return (qualifyingScore * 0.40 + raceScore * 0.60).coerceIn(0.0,150.0)
    }

    /** In ascent, good performance accelerates; in regression it slows the fall. */
    fun phaseMultiplier(index:Double, regression:Boolean=false):Double {
        return if (!regression) performanceUtilization(index) else when (performanceTier(index)) {
            "Excepcional" -> 0.15
            "Excelente" -> 0.20
            "Muito bom" -> 0.30
            "Bom" -> 0.45
            "Normal" -> 0.60
            "Abaixo do esperado" -> 0.80
            "Ruim" -> 1.05
            else -> 1.25
        }
    }

    /** Additional phase-compression factor. Repeated exceptional/very-bad GPs may hit the
     * target before the nominal phase duration, but never skip the scheduled peak phase. */
    fun anticipationFactor(index:Double, regression:Boolean=false):Double = if (!regression) when {
        index >= 115 -> 1.20
        index >= 105 -> 1.10
        index >= 98 -> 1.05
        else -> 1.0
    } else when {
        index < 60 -> 1.20
        index < 75 -> 1.10
        index < 85 -> 1.03
        else -> 1.0
    }

    fun ascentSeasons(evolution:String):Int = when(evolution) {
        "Prodígio" -> 5; "Auge rápido" -> 6; "Auge moderado" -> 7
        "Auge tardio" -> 8; "Normal" -> 9; else -> 10
    }
    fun regressionSeasons(evolution:String):Int = when(evolution) {
        "Prodígio" -> 5; "Auge rápido" -> 5; "Auge moderado" -> 6
        "Auge tardio" -> 6; "Normal" -> 7; else -> 7
    }
    fun minimumOverall(driverClass:String):Int = when(driverClass) {
        "Fraco" -> 40; "Médio" -> 45; "Forte" -> 50; "Pro" -> 55; else -> 60
    }

    fun evaluate(driver:DriverDefinition, target:Target, input:PerformanceInput): Evaluation {
        val championship = ratio(target.championshipPosition.toDouble(), input.championshipPosition.toDouble())
        val expectedPoints = (((81-target.championshipPosition).coerceAtLeast(1)/80.0)*450.0)
        val points = ratio(expectedPoints,input.points.toDouble().coerceAtLeast(0.0),0.35)
        val race = ratio(target.championshipPosition.toDouble(),input.averageRacePosition.coerceAtLeast(1.0))
        val expectedWins = ((81-target.championshipPosition).coerceAtLeast(1)/80.0)*12.0
        val expectedPodiums = ((81-target.championshipPosition).coerceAtLeast(1)/80.0)*25.0
        val achievement=(ratio(expectedWins,input.wins.toDouble(),0.35)+ratio(expectedPodiums,input.podiums.toDouble(),0.35))/2.0
        val qualifying=ratio(target.championshipPosition.toDouble(),input.averageQualifyingPosition.coerceAtLeast(1.0))
        val teammate=if(input.teammateAveragePosition!=null&&input.teammateComparisons>0) ratio(input.teammateAveragePosition,input.averageRacePosition.coerceAtLeast(1.0)) else 100.0
        val index=championship*.30+points*.20+race*.15+achievement*.15+qualifying*.10+teammate*.10
        val tier=performanceTier(index); val multiplier=performanceUtilization(index)
        return Evaluation(index.coerceIn(0.0,150.0),tier,multiplier,0)
    }

    fun applyPositiveGain(driver:DriverDefinition,intendedGain:Int,annualGains:IntArray,random:Random,perAttributeCap:Int=DriverProfileCatalog.maxAnnualGain(driver.evolution)):DriverDefinition {
        if(intendedGain<=0)return driver; require(annualGains.size==7)
        val next=driver.ratings(); val ceiling=DriverProfileCatalog.ceiling(driver.driverClass)
        var remaining=intendedGain
        while(remaining>0){
            val eligible=(0..6).filter{next[it]<ceiling&&next[it]<100&&annualGains[it]<perAttributeCap}
            if(eligible.isEmpty())break
            // Preserve the driver's natural profile while giving lower attributes a modest balancing chance.
            val weights=eligible.map{ i ->
                val natural=driver.ratings()[i].toDouble(); val head=(ceiling-next[i]).toDouble()
                0.35 + natural/100.0*0.65 + head/(ceiling-40).coerceAtLeast(1).toDouble()*0.80
            }
            val total=weights.sum(); var pick=random.nextDouble()*total; var chosen=eligible.last()
            for(k in eligible.indices){ pick-=weights[k]; if(pick<=0){chosen=eligible[k];break} }
            next[chosen]++; annualGains[chosen]++; remaining--
        }
        return driver.withRatings(next)
    }

    fun applyRegression(driver:DriverDefinition,intendedLoss:Int,random:Random):DriverDefinition {
        if(intendedLoss<=0)return driver
        val next=driver.ratings(); val floor=minimumOverall(driver.driverClass)
        repeat(intendedLoss){
            val eligible=(0..6).filter{next[it]>40}
            if(eligible.isEmpty())return@repeat
            val weights: List<Double> = eligible.map{ i ->
                val excess=(next.sum()/7 - floor).coerceAtLeast(0).toDouble()
                0.35 + (next[i]-40)/60.0 + excess/50.0
            }
            val total=weights.sum(); var pick=random.nextDouble()*total; var chosen=eligible.last()
            for(k in eligible.indices){pick-=weights[k];if(pick<=0){chosen=eligible[k];break}}
            next[chosen]--
        }
        return driver.withRatings(next)
    }

    fun recoveryCap(driver:DriverDefinition):Int=1
    fun applyDelta(driver:DriverDefinition,delta:Int):DriverDefinition=if(delta>0)applyPositiveGain(driver,delta,IntArray(7),Random(20261006)) else applyRegression(driver,-delta,Random(20261006))
    private fun ratio(expected:Double,actual:Double,floor:Double=.50):Double{if(expected<=0)return 100.0;if(actual<=0)return 150.0;return(expected/actual*100.0).coerceIn(floor*100.0,150.0)}
    private fun DriverDefinition.ratings():IntArray=intArrayOf(speed,qualifying,overtaking,defense,consistency,wet,tyre)
    private fun DriverDefinition.withRatings(a:IntArray):DriverDefinition=copy(speed=a[0],qualifying=a[1],overtaking=a[2],defense=a[3],consistency=a[4],wet=a[5],tyre=a[6])
}
