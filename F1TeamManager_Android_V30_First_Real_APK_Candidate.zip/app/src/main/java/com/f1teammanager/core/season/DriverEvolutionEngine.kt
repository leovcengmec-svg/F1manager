package com.f1teammanager.core.season

import kotlin.math.abs
import kotlin.math.roundToInt
import kotlin.random.Random

/** Stage 1 continuous driver evolution. Class and evolution type are immutable. */
object DriverEvolutionEngine {
    data class Target(val championshipPosition:Int)
    data class PerformanceInput(
        val championshipPosition:Int,
        val points:Int,
        val averageRacePosition:Double,
        val wins:Int,
        val podiums:Int,
        val averageQualifyingPosition:Double,
        val teammateAveragePosition:Double?,
        val teammateComparisons:Int
    )
    data class Evaluation(val index:Double, val tier:String, val multiplier:Double, val delta:Int)

    private val positiveAttributeOrder = intArrayOf(0,1,2,3,4,5,6)
    private val regressionOrder = intArrayOf(2,3,5,6,4,1,0)

    fun evaluate(driver:DriverDefinition, target:Target, input:PerformanceInput): Evaluation {
        val championship = ratio(target.championshipPosition.toDouble(), input.championshipPosition.toDouble())
        val expectedPoints = ((81 - target.championshipPosition).coerceAtLeast(1) * 7.5)
        val points = ratio(expectedPoints, input.points.toDouble().coerceAtLeast(0.0), floor=0.35)
        val race = ratio(target.championshipPosition.toDouble(), input.averageRacePosition.coerceAtLeast(1.0))
        val expectedWins = ((81 - target.championshipPosition).coerceAtLeast(1) / 80.0) * 12.0
        val expectedPodiums = ((81 - target.championshipPosition).coerceAtLeast(1) / 80.0) * 25.0
        val achievement = (ratio(expectedWins, input.wins.toDouble(), floor=0.35) + ratio(expectedPodiums, input.podiums.toDouble(), floor=0.35)) / 2.0
        val qualifying = ratio(target.championshipPosition.toDouble(), input.averageQualifyingPosition.coerceAtLeast(1.0))
        val teammate = if (input.teammateAveragePosition != null && input.teammateComparisons > 0) ratio(input.teammateAveragePosition, input.averageRacePosition.coerceAtLeast(1.0)) else 100.0
        val index = championship * .30 + points * .20 + race * .15 + achievement * .15 + qualifying * .10 + teammate * .10
        val tier = when { index >= 115.0 -> "Excepcional"; index >= 105.0 -> "Excelente"; index >= 92.0 -> "Esperado"; index >= 75.0 -> "Abaixo do esperado"; else -> "Muito ruim" }
        val multiplier = when (tier) { "Excepcional" -> 1.25; "Excelente" -> 1.10; "Esperado" -> 1.00; "Abaixo do esperado" -> .75; else -> .50 }
        val overall = DriverProfileCatalog.overall(driver.ratings())
        val ceiling = DriverProfileCatalog.ceiling(driver.driverClass)
        val maxGain = DriverProfileCatalog.maxAnnualGain(driver.evolution)
        val delta = evolutionDelta(overall, ceiling, maxGain, tier, multiplier)
        return Evaluation(index.coerceIn(0.0,150.0), tier, multiplier, delta)
    }

    /** Continuous in-season tick. The caller persists fractional progress and annual per-attribute gains. */
    fun weeklyDelta(
        driver: DriverDefinition,
        target: Target,
        recentRacePositions: List<Int>,
        recentQualifyingPositions: List<Int>,
        teammatePositions: List<Int>,
        pointsScored: Int,
        racesCount: Int,
        accumulatedDelta: Int
    ): Int {
        if (recentRacePositions.isEmpty()) return 0
        val targetPos = target.championshipPosition.coerceIn(1, 80)
        val avgRace = recentRacePositions.map { it.coerceIn(1, 80) }.average()
        val avgQual = recentQualifyingPositions.takeIf { it.isNotEmpty() }?.map { it.coerceIn(1, 80) }?.average() ?: avgRace
        val expectedPointsPerRace = ((81 - targetPos).coerceAtLeast(1) / 80.0) * 2.5
        val pointsRate = if (racesCount <= 0) 1.0 else pointsScored.toDouble() / racesCount.toDouble().coerceAtLeast(1.0)
        val raceScore = (targetPos.toDouble() / avgRace * 100.0).coerceIn(50.0, 150.0)
        val qualScore = (targetPos.toDouble() / avgQual * 100.0).coerceIn(50.0, 150.0)
        val pointsScore = if (expectedPointsPerRace <= 0.0) 100.0 else (pointsRate / expectedPointsPerRace * 100.0).coerceIn(50.0, 150.0)
        val teammateScore = if (teammatePositions.isEmpty()) 100.0 else (teammatePositions.map { it.coerceIn(1, 80) }.average() / avgRace * 100.0).coerceIn(50.0, 150.0)
        val index = raceScore * .45 + qualScore * .20 + pointsScore * .20 + teammateScore * .15
        val tier = when { index >= 115.0 -> "Excepcional"; index >= 105.0 -> "Excelente"; index >= 92.0 -> "Esperado"; index >= 75.0 -> "Abaixo do esperado"; else -> "Muito ruim" }
        val ceiling = DriverProfileCatalog.ceiling(driver.driverClass)
        val overall = DriverProfileCatalog.overall(driver.ratings())
        if (overall >= ceiling && tier != "Muito ruim" && tier != "Abaixo do esperado") return 0
        val gainRate = when (driver.evolution) { "Prodígio" -> 0.38; "Auge rápido" -> 0.34; "Auge moderado" -> 0.28; "Auge tardio" -> if (racesCount < 10) 0.18 else 0.30; "Normal" -> 0.23; "Demorado" -> 0.17; else -> 0.23 }
        val pressure = when (tier) { "Excepcional" -> 1.35; "Excelente" -> 1.10; "Esperado" -> 0.70; "Abaixo do esperado" -> -0.65; else -> -1.00 }
        val raw = gainRate * pressure
        val sign = if (raw >= 0) 1 else -1
        val magnitude = abs(raw)
        val immediate = if (magnitude >= 0.85) sign else 0
        val maxAnnual = DriverProfileCatalog.maxAnnualGain(driver.evolution)
        if (sign > 0 && accumulatedDelta >= maxAnnual) return 0
        if (sign < 0 && accumulatedDelta <= -maxAnnual) return 0
        return immediate
    }

    /**
     * Applies positive evolution point-by-point. Each point first chooses an attribute
     * randomly; if that attribute is blocked by its class ceiling or annual allowance,
     * the unused point is immediately redirected to another eligible attribute.
     * No positive point is lost while any eligible attribute remains.
     */
    fun applyPositiveGain(
        driver: DriverDefinition,
        intendedGain: Int,
        annualGains: IntArray,
        random: Random
    ): DriverDefinition {
        if (intendedGain <= 0) return driver
        require(annualGains.size == 7) { "annualGains deve possuir 7 posições" }
        val next = driver.ratings().copyOf()
        val ceiling = DriverProfileCatalog.ceiling(driver.driverClass)
        val perAttributeCap = DriverProfileCatalog.maxAnnualGain(driver.evolution)
        var remaining = intendedGain
        var guard = 0
        while (remaining > 0 && guard++ < 1000) {
            val eligible = positiveAttributeOrder.filter { i -> next[i] < ceiling && next[i] < 100 && annualGains[i] < perAttributeCap }
            if (eligible.isEmpty()) break
            val first = eligible[random.nextInt(eligible.size)]
            val ordered = listOf(first) + eligible.filter { it != first }.shuffled(random)
            var applied = false
            for (i in ordered) {
                if (next[i] < ceiling && next[i] < 100 && annualGains[i] < perAttributeCap) {
                    next[i]++
                    annualGains[i]++
                    remaining--
                    applied = true
                    break
                }
            }
            if (!applied) break
        }
        return driver.withRatings(next)
    }

    /** Regression is intentionally not redistributed: if the selected attribute reaches 40, the loss is simply capped there. */
    fun applyRegression(driver: DriverDefinition, intendedLoss: Int, random: Random): DriverDefinition {
        if (intendedLoss <= 0) return driver
        val next = driver.ratings().copyOf()
        repeat(intendedLoss) {
            val i = regressionOrder[random.nextInt(regressionOrder.size)]
            if (next[i] > 40) next[i]--
        }
        return driver.withRatings(next)
    }

    /** Compatibility helper retained for older callers/tests. */
    fun applyDelta(driver:DriverDefinition, delta:Int): DriverDefinition {
        return if (delta > 0) applyPositiveGain(driver, delta, IntArray(7), Random(20261006)) else applyRegression(driver, -delta, Random(20261006))
    }

    private fun evolutionDelta(overall:Int, ceiling:Int, maxGain:Int, tier:String, multiplier:Double):Int {
        if (overall >= ceiling) return when (tier) { "Excepcional", "Excelente" -> 0; "Esperado" -> -1; "Abaixo do esperado" -> -2; else -> -3 }
        val recovery = overall <= 49
        return when (tier) { "Excepcional", "Excelente", "Esperado" -> (maxGain * multiplier).roundToInt().coerceAtLeast(1); "Abaixo do esperado" -> if (recovery) 0 else -1; else -> if (recovery) -1 else -2 }.coerceIn(-3, maxGain + 2)
    }
    private fun ratio(expected:Double, actual:Double, floor:Double=0.50):Double { if (expected <= 0.0) return 100.0; if (actual <= 0.0) return 150.0; return (expected / actual * 100.0).coerceIn(floor * 100.0, 150.0) }
    private fun DriverDefinition.ratings(): IntArray = intArrayOf(speed, qualifying, overtaking, defense, consistency, wet, tyre)
    private fun DriverDefinition.withRatings(a:IntArray): DriverDefinition = copy(speed=a[0], qualifying=a[1], overtaking=a[2], defense=a[3], consistency=a[4], wet=a[5], tyre=a[6])
}
