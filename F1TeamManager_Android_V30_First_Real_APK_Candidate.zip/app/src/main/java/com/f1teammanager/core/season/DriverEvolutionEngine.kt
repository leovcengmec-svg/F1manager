package com.f1teammanager.core.season

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.random.Random

/** Continuous career-cycle evolution. Class and evolution type remain immutable. */
object DriverEvolutionEngine {
    data class Target(val championshipPosition:Int)
    data class PerformanceInput(
        val championshipPosition:Int,
        val points:Int,
        val averageRacePosition:Double,
        val wins:Int,
        val podiums:Int,
        val averageQualifyingPosition:Double,
        val teammateAveragePosition:Double?,
        val teammateComparisons:Int
    )
    data class Evaluation(val index:Double, val tier:String, val multiplier:Double, val delta:Int)

    fun performanceTier(index: Double): String = when {
        index >= 115.0 -> "Excepcional"
        index >= 105.0 -> "Excelente"
        index >= 98.0 -> "Muito bom"
        index >= 92.0 -> "Bom"
        index >= 85.0 -> "Normal"
        index >= 75.0 -> "Abaixo do esperado"
        index >= 60.0 -> "Ruim"
        else -> "Muito ruim"
    }

    /**
     * Growth-rate multiplier. A driver performing at the team's expected level
     * (index ~= 100) should progress at roughly the designed 5-year rate, rather
     * than being penalized by an 0.80 multiplier. Performance below/above expectation
     * slows/accelerates the rate; evolution category still independently limits annual
     * gains per attribute.
     */
    fun performanceUtilization(index: Double): Double = when {
        index >= 115.0 -> 1.25
        index >= 105.0 -> 1.15
        index >= 98.0 -> 1.05
        index >= 92.0 -> 1.00
        index >= 85.0 -> 0.85
        index >= 75.0 -> 0.65
        index >= 60.0 -> 0.45
        else -> 0.30
    }

    /**
     * Per-GP performance is 40% qualifying + 60% race, measured against the
     * team-strength target. The previous target/actual ratio was too punitive near
     * the top of the grid: P2 against a P1 target scored 50. We now use a position
     * delta around a neutral 100, so one position off target is a small deviation.
     * Missing positions (<=0) are treated as neutral target performance; callers
     * should pass the target when a result record is absent.
     */
    fun gpPerformanceIndex(targetPosition:Int, qualifyingPosition:Int, racePosition:Int): Double {
        val target = targetPosition.coerceIn(1,80)
        val q = if (qualifyingPosition <= 0) target else qualifyingPosition.coerceIn(1,80)
        val r = if (racePosition <= 0) target else racePosition.coerceIn(1,80)
        val qualifyingScore = (100.0 + (target - q) * 5.0).coerceIn(25.0,150.0)
        val raceScore = (100.0 + (target - r) * 5.0).coerceIn(25.0,150.0)
        return (qualifyingScore * 0.40 + raceScore * 0.60).coerceIn(25.0,150.0)
    }

    /** In ascent, good performance accelerates; in regression it slows the fall. */
    fun phaseMultiplier(index:Double, regression:Boolean=false):Double {
        return if (!regression) performanceUtilization(index) else when (performanceTier(index)) {
            "Excepcional" -> 0.15
            "Excelente" -> 0.20
            "Muito bom" -> 0.30
            "Bom" -> 0.45
            "Normal" -> 0.60
            "Abaixo do esperado" -> 0.80
            "Ruim" -> 1.05
            else -> 1.25
        }
    }

    /** Performance changes the amount of attribute growth/loss per GP, never the fixed
     * 5-year growth, 2-year peak, 5-year regression career-cycle schedule. */
    fun anticipationFactor(index:Double, regression:Boolean=false):Double = if (!regression) when {
        index >= 115 -> 1.20
        index >= 105 -> 1.10
        index >= 92 -> 1.05
        else -> 1.0
    } else when {
        index < 60 -> 1.20
        index < 75 -> 1.10
        index < 85 -> 1.03
        else -> 1.0
    }

    /** Reject unknown persisted phase tokens safely. Fresh careers seed GROWING, while
     * malformed/incomplete runtime state falls back without interpreting it as regression. */
    fun normalizePhase(phase: String?): String = when (phase) {
        "GROWING", "PEAK", "REGRESSION" -> phase
        else -> "GROWING"
    }

    /** Official career-cycle duration: 5 growing years, 2 peak years, 5 regression years.
     * Evolution category controls annual attribute gain caps only, not cycle duration. */
    fun phaseDurationSeasons(phase: String): Int = when (phase) {
        "GROWING" -> 5
        "PEAK" -> 2
        "REGRESSION" -> 5
        else -> 5 // safe default for incomplete state; fresh careers initialize GROWING
    }

    // Kept as compatibility helpers: the cycle duration is no longer category-dependent.
    @Suppress("UNUSED_PARAMETER")
    fun ascentSeasons(evolution: String): Int = 5
    @Suppress("UNUSED_PARAMETER")
    fun regressionSeasons(evolution: String): Int = 5
    fun minimumOverall(driverClass:String):Int = when(driverClass) {
        "Fraco" -> 40; "Médio" -> 45; "Forte" -> 50; "Pro" -> 55; else -> 60
    }

    fun evaluate(driver:DriverDefinition, target:Target, input:PerformanceInput): Evaluation {
        val championship = ratio(target.championshipPosition.toDouble(), input.championshipPosition.toDouble())
        val expectedPoints = (((81-target.championshipPosition).coerceAtLeast(1)/80.0)*450.0)
        val points = ratio(expectedPoints,input.points.toDouble().coerceAtLeast(0.0),0.35)
        val race = ratio(target.championshipPosition.toDouble(),input.averageRacePosition.coerceAtLeast(1.0))
        val expectedWins = ((81-target.championshipPosition).coerceAtLeast(1)/80.0)*12.0
        val expectedPodiums = ((81-target.championshipPosition).coerceAtLeast(1)/80.0)*25.0
        val achievement=(ratio(expectedWins,input.wins.toDouble(),0.35)+ratio(expectedPodiums,input.podiums.toDouble(),0.35))/2.0
        val qualifying=ratio(target.championshipPosition.toDouble(),input.averageQualifyingPosition.coerceAtLeast(1.0))
        val teammate=if(input.teammateAveragePosition!=null&&input.teammateComparisons>0) ratio(input.teammateAveragePosition,input.averageRacePosition.coerceAtLeast(1.0)) else 100.0
        val index=championship*.30+points*.20+race*.15+achievement*.15+qualifying*.10+teammate*.10
        val tier=performanceTier(index); val multiplier=performanceUtilization(index)
        return Evaluation(index.coerceIn(0.0,150.0),tier,multiplier,0)
    }

    fun applyPositiveGain(driver:DriverDefinition,intendedGain:Int,annualGains:IntArray,random:Random,perAttributeCap:Int=DriverProfileCatalog.maxAnnualGain(driver.evolution)):DriverDefinition {
        if(intendedGain<=0)return driver; require(annualGains.size==7)
        val next=driver.ratings(); val ceiling=DriverProfileCatalog.ceiling(driver.driverClass)
        var remaining=intendedGain
        while(remaining>0){
            val eligible=(0..6).filter{next[it]<ceiling&&next[it]<100&&annualGains[it]<perAttributeCap}
            if(eligible.isEmpty())break
            // Preserve the driver's natural profile while giving lower attributes a modest balancing chance.
            val weights=eligible.map{ i ->
                val natural=driver.ratings()[i].toDouble(); val head=(ceiling-next[i]).toDouble()
                0.35 + natural/100.0*0.65 + head/(ceiling-40).coerceAtLeast(1).toDouble()*0.80
            }
            val total=weights.sum(); var pick=random.nextDouble()*total; var chosen=eligible.last()
            for(k in eligible.indices){ pick-=weights[k]; if(pick<=0){chosen=eligible[k];break} }
            next[chosen]++; annualGains[chosen]++; remaining--
        }
        return driver.withRatings(next)
    }

    fun applyRegression(driver:DriverDefinition,intendedLoss:Int,random:Random):DriverDefinition {
        if(intendedLoss<=0)return driver
        val next=driver.ratings()
        val floor=minimumOverall(driver.driverClass)
        repeat(intendedLoss){
            // Class minimum is an Overall floor (Fraco 40, Médio 45, Forte 50,
            // Pro 55, Lenda 60), not merely a per-attribute floor of 40.
            // Do not allow one more point loss if it would make the integer Overall
            // shown in UI drop below the class minimum.
            if ((next.sum()-1) / 7 < floor) return@repeat
            val eligible=(0..6).filter{next[it]>40}
            if(eligible.isEmpty())return@repeat
            val excess=(next.sum()/7 - floor).coerceAtLeast(0).toDouble()
            val weights: List<Double> = eligible.map{ i ->
                0.35 + (next[i]-40)/60.0 + excess/50.0
            }
            val total=weights.sum(); var pick=random.nextDouble()*total; var chosen=eligible.last()
            for(k in eligible.indices){pick-=weights[k];if(pick<=0){chosen=eligible[k];break}}
            next[chosen]--
        }
        return driver.withRatings(next)
    }

    fun recoveryCap(driver:DriverDefinition):Int=1
    fun applyDelta(driver:DriverDefinition,delta:Int):DriverDefinition=if(delta>0)applyPositiveGain(driver,delta,IntArray(7),Random.Default) else applyRegression(driver,-delta,Random.Default)
    private fun ratio(expected:Double,actual:Double,floor:Double=.50):Double{if(expected<=0)return 100.0;if(actual<=0)return 150.0;return(expected/actual*100.0).coerceIn(floor*100.0,150.0)}
    private fun DriverDefinition.ratings():IntArray=intArrayOf(speed,qualifying,overtaking,defense,consistency,wet,tyre)
    private fun DriverDefinition.withRatings(a:IntArray):DriverDefinition=copy(speed=a[0],qualifying=a[1],overtaking=a[2],defense=a[3],consistency=a[4],wet=a[5],tyre=a[6])
}
