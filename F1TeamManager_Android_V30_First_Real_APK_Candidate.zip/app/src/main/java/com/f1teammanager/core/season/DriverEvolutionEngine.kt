package com.f1teammanager.core.season

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.random.Random

/** Performance-driven pilot growth/regression. Class changes are reviewed separately. */
object DriverEvolutionEngine {
    /** The driver championship always contains 80 slots; constructor ranking is a separate 1..40 table. */
    const val DRIVER_GRID_SIZE = 80
    /** Free agents develop independently at 120% of the natural baseline while unsigned. */
    const val FREE_DRIVER_GROWTH_RATE = 1.20
    private const val FREE_DRIVER_NEUTRAL_PERFORMANCE_INDEX = 105.0

    /**
     * Individual season expectation. Qualifying and race use separate centers because
     * a driver's qualifying skill and overall race ability are not interchangeable.
     * The centers are wrapped in a tolerance band; finishing anywhere inside that band
     * is considered an expected weekend rather than a miss against one fixed position.
     */
    data class Target(
        val championshipPosition: Int,
        val qualifyingPosition: Int = championshipPosition,
        val racePosition: Int = championshipPosition
    ) {
        val qualifyingMargin: Int get() = positionMargin(qualifyingPosition)
        val raceMargin: Int get() = positionMargin(racePosition)
        val qualifyingMinPosition: Int get() = (qualifyingPosition - qualifyingMargin).coerceAtLeast(1)
        val qualifyingMaxPosition: Int get() = (qualifyingPosition + qualifyingMargin).coerceAtMost(DRIVER_GRID_SIZE)
        val raceMinPosition: Int get() = (racePosition - raceMargin).coerceAtLeast(1)
        val raceMaxPosition: Int get() = (racePosition + raceMargin).coerceAtMost(DRIVER_GRID_SIZE)
    }

    /** Input used to anchor two driver expectations to one constructor/car ranking. */
    data class TargetInput(
        val driverId: Int,
        val teamId: Int,
        val carStrength: Double,
        val driverOverall: Int,
        val qualifyingStrength: Int
    )

    /**
     * Creates the 80-driver expectation from the 40-car order, not from a blended
     * 80-driver score. Each constructor occupies two baseline positions:
     * P(2 * teamRank - 1) and P(2 * teamRank). Talent may adjust an individual
     * expectation by at most three places, so a strong driver cannot turn a midfield
     * car into a front-running car on paper.
     *
     * Example: constructor P22 starts at driver P43/P44. Individual skill can move
     * those centers only within P40..P47. Constructor and driver championship scales
     * remain separate (1..40 and 1..80 respectively).
     */
    fun buildIndividualTargets(inputs: List<TargetInput>): Map<Int, Target> {
        val valid = inputs
            .filter { it.driverId > 0 && it.teamId > 0 }
            .distinctBy { it.driverId }
        if (valid.size != DRIVER_GRID_SIZE) return emptyMap()

        val byTeam = valid.groupBy { it.teamId }
        if (byTeam.size != 40 || byTeam.values.any { it.size != 2 }) return emptyMap()

        val constructorRanks = byTeam.entries
            .map { (teamId, drivers) ->
                teamId to drivers.map { it.carStrength.coerceIn(0.0, 100.0) }.average()
            }
            .sortedWith(compareByDescending<Pair<Int, Double>> { it.second }.thenBy { it.first })
            .mapIndexed { index, (teamId, _) -> teamId to (index + 1) }
            .toMap()

        val averageRaceSkill = valid.map { it.driverOverall.coerceIn(40, 100).toDouble() }.average()
        val averageQualifyingSkill = valid.map { it.qualifyingStrength.coerceIn(40, 100).toDouble() }.average()

        fun individualAdjustment(skill: Int, gridAverage: Double): Int =
            ((gridAverage - skill.coerceIn(40, 100)) / 8.0).roundToInt().coerceIn(-3, 3)

        val targets = linkedMapOf<Int, Target>()
        byTeam.forEach { (teamId, drivers) ->
            val teamRank = constructorRanks.getValue(teamId)
            val firstDriverPosition = teamRank * 2 - 1

            val qualifyingOrder = drivers.sortedWith(
                compareByDescending<TargetInput> { it.qualifyingStrength.coerceIn(40, 100) }
                    .thenBy { it.driverId }
            )
            val raceOrder = drivers.sortedWith(
                compareByDescending<TargetInput> { it.driverOverall.coerceIn(40, 100) }
                    .thenBy { it.driverId }
            )
            val qualifyingSlot = qualifyingOrder.mapIndexed { index, input -> input.driverId to index }.toMap()
            val raceSlot = raceOrder.mapIndexed { index, input -> input.driverId to index }.toMap()

            drivers.forEach { input ->
                val qualifyingBase = firstDriverPosition + qualifyingSlot.getValue(input.driverId)
                val raceBase = firstDriverPosition + raceSlot.getValue(input.driverId)
                val qualifying = (qualifyingBase + individualAdjustment(input.qualifyingStrength, averageQualifyingSkill))
                    .coerceIn(1, DRIVER_GRID_SIZE)
                val race = (raceBase + individualAdjustment(input.driverOverall, averageRaceSkill))
                    .coerceIn(1, DRIVER_GRID_SIZE)
                targets[input.driverId] = Target(
                    championshipPosition = ((qualifying + race + 1) / 2).coerceIn(1, DRIVER_GRID_SIZE),
                    qualifyingPosition = qualifying,
                    racePosition = race
                )
            }
        }
        return targets
    }

    /** Uniform ±3 tolerance: the same expectation width applies throughout P1..P80. */
    private fun positionMargin(@Suppress("UNUSED_PARAMETER") position: Int): Int = 3
    data class PerformanceInput(
        val championshipPosition:Int,
        val points:Int,
        val averageRacePosition:Double,
        val wins:Int,
        val podiums:Int,
        val averageQualifyingPosition:Double,
        val teammateAveragePosition:Double?,
        val teammateComparisons:Int
    )
    data class Evaluation(val index:Double, val tier:String, val multiplier:Double, val delta:Int)

    fun performanceTier(index: Double): String = when {
        index >= 115.0 -> "Excepcional"
        index >= 105.0 -> "Excelente"
        index >= 98.0 -> "Muito bom"
        index >= 92.0 -> "Bom"
        index >= 85.0 -> "Normal"
        index >= 75.0 -> "Abaixo do esperado"
        index >= 60.0 -> "Ruim"
        else -> "Muito ruim"
    }

    /**
     * Legacy display multiplier retained for compatibility with summary screens.
     * Actual progression now uses performanceEvolutionRate and the shared per-GP tick.
     * Performance below/above expectation slows/accelerates growth; the evolution
     * category independently limits annual gains per attribute.
     */
    fun performanceUtilization(index: Double): Double = when {
        index >= 115.0 -> 1.25
        index >= 105.0 -> 1.15
        index >= 98.0 -> 1.05
        index >= 92.0 -> 1.00
        index >= 85.0 -> 0.85
        index >= 75.0 -> 0.65
        index >= 60.0 -> 0.45
        else -> 0.30
    }

    /**
     * Range-aware per-GP evaluation. A result inside the driver's own target band is
     * neutral (105, the normal growth baseline); performance is rewarded/penalized only outside the tolerance band.
     * Missing rows use the individual target center, never a synthetic grid position.
     */
    fun gpPerformanceIndex(target: Target, qualifyingPosition: Int, racePosition: Int): Double {
        val qCenter = target.qualifyingPosition.coerceIn(1, DRIVER_GRID_SIZE)
        val rCenter = target.racePosition.coerceIn(1, DRIVER_GRID_SIZE)
        val q = if (qualifyingPosition <= 0) qCenter else qualifyingPosition.coerceIn(1, DRIVER_GRID_SIZE)
        val r = if (racePosition <= 0) rCenter else racePosition.coerceIn(1, DRIVER_GRID_SIZE)
        val qualifyingScore = positionBandScore(q, qCenter, target.qualifyingMargin)
        val raceScore = positionBandScore(r, rCenter, target.raceMargin)
        return (qualifyingScore * 0.40 + raceScore * 0.60).coerceIn(25.0, 150.0)
    }

    private fun positionBandScore(actual: Int, center: Int, margin: Int): Double {
        val minPosition = (center - margin).coerceAtLeast(1)
        val maxPosition = (center + margin).coerceAtMost(DRIVER_GRID_SIZE)
        return when {
            actual < minPosition -> 105.0 + (minPosition - actual) * 5.0
            actual > maxPosition -> 105.0 - (actual - maxPosition) * 5.0
            else -> 105.0
        }
    }

    /**
     * Mechanical/equipment DNFs are not driver-performance evidence. Keep that GP's
     * race component neutral at the driver's target while preserving qualifying evidence.
     * Driver-caused accidents remain a sporting result and are still evaluated.
     */
    fun racePositionForEvolution(target: Target, actualPosition: Int?, status: String?): Int {
        val position = actualPosition?.takeIf { it in 1..DRIVER_GRID_SIZE } ?: target.racePosition
        val normalized = status.orEmpty().uppercase()
        if (!normalized.startsWith("DNF")) return position
        val equipmentOrExternalFailure = listOf(
            "PANE", "FALHA", "SEM COMBUSTÍVEL", "PNEU DEGRADADO", "COLISÃO"
        ).any(normalized::contains)
        return if (equipmentOrExternalFailure) target.racePosition.coerceIn(1, DRIVER_GRID_SIZE) else position
    }

    /**
     * Legacy center-only scoring retained for compatibility with older integrations.
     * Active career and Team Principal progression use the range-aware Target overload.
     * Missing positions are treated as neutral against the legacy center.
     */
    fun gpPerformanceIndex(targetPosition:Int, qualifyingPosition:Int, racePosition:Int): Double {
        val target = targetPosition.coerceIn(1,DRIVER_GRID_SIZE)
        val q = if (qualifyingPosition <= 0) target else qualifyingPosition.coerceIn(1,DRIVER_GRID_SIZE)
        val r = if (racePosition <= 0) target else racePosition.coerceIn(1,DRIVER_GRID_SIZE)
        val qualifyingScore = (100.0 + (target - q) * 5.0).coerceIn(25.0,150.0)
        val raceScore = (100.0 + (target - r) * 5.0).coerceIn(25.0,150.0)
        return (qualifyingScore * 0.40 + raceScore * 0.60).coerceIn(25.0,150.0)
    }

    /**
     * V649 phase tokens are performance states, not an age/career clock. The old
     * PEAK token is accepted as STABLE so existing saves never enter timed decline.
     */
    fun normalizePhase(phase: String?): String = when (phase) {
        "GROWING", "REGRESSION", "STABLE" -> phase
        "PEAK" -> "STABLE"
        else -> "GROWING"
    }

    /** A pilot starts developing only while there is meaningful room below potential. */
    fun initialPhase(driver: DriverDefinition): String {
        val current = DriverProfileCatalog.overall(driver.ratings())
        return if (driver.potentialOverall.coerceIn(current, 100) - current <= 1) "STABLE" else "GROWING"
    }

    /**
     * Signed, performance-driven development rate per completed GP. A neutral
     * weekend preserves most progress; repeated poor performances are required
     * before the negative fractional bank becomes an attribute loss.
     */
    fun performanceEvolutionRate(index: Double): Double = when {
        index >= 115.0 -> 1.30
        index >= 105.0 -> 1.00
        index >= 98.0 -> 0.50
        index >= 92.0 -> 0.20
        index >= 85.0 -> 0.0
        index >= 75.0 -> -0.20
        index >= 60.0 -> -0.45
        else -> -0.70
    }

    /**
     * Class is a soft threshold, not a hard progression wall. Good drivers may
     * exceed it while retaining at least 60% of their natural growth, so a high-
     * potential driver in a weak team is not trapped by a delayed class promotion.
     */
    fun classGrowthFactor(driverClass: String, currentOverall: Int): Double {
        val excess = (currentOverall - DriverProfileCatalog.ceiling(driverClass)).coerceAtLeast(0)
        return when {
            excess <= 0 -> 1.0
            excess <= 2 -> 0.90
            excess <= 4 -> 0.80
            excess <= 7 -> 0.70
            else -> 0.60
        }
    }

    data class TickResult(
        val driver: DriverDefinition,
        val bank: Double,
        val phase: String,
        val attributeDelta: Int
    )

    /** The one shared GP progression path used by career and Team Principal simulation. */
    fun applyPerformanceTick(
        driver: DriverDefinition,
        performanceIndex: Double,
        currentBank: Double,
        annualGains: IntArray,
        random: Random,
        facilityGrowthEfficiency: Double = 1.0
    ): TickResult {
        require(annualGains.size == 7) { "O controle anual precisa ter sete atributos" }
        val before = driver.ratings()
        val beforeOverall = DriverProfileCatalog.overall(before)
        val rate = performanceEvolutionRate(performanceIndex)
        val annualProfileBudget = DriverProfileCatalog.maxAnnualGain(driver.evolution) * 7.0 / 150.0
        var bank = currentBank

        when {
            rate > 0.0 && beforeOverall < driver.potentialOverall -> {
                val classFactor = classGrowthFactor(driver.driverClass, beforeOverall)
                bank += annualProfileBudget * rate * classFactor * facilityGrowthEfficiency.coerceIn(0.5, 1.6)
            }
            rate < 0.0 -> bank -= annualProfileBudget * -rate
            rate > 0.0 && beforeOverall >= driver.potentialOverall -> bank = 0.0
        }

        var updated = driver
        if (bank >= 1.0) {
            val requested = bank.toInt()
            updated = applyPositiveGain(
                driver, requested, annualGains, random,
                perAttributeCap = DriverProfileCatalog.maxAnnualGain(driver.evolution)
            )
            val applied = (updated.ratings().sum() - before.sum()).coerceAtLeast(0)
            // Preserve only a fractional remainder when annual attribute caps block
            // growth; it can resume after the seasonal allowance resets.
            bank = if (applied > 0) bank - applied else bank.coerceAtMost(0.99)
        } else if (bank <= -1.0) {
            val requested = (-bank).toInt()
            updated = applyRegression(driver, requested, random)
            val removed = (before.sum() - updated.ratings().sum()).coerceAtLeast(0)
            bank = if (removed > 0) bank + removed else 0.0
        }

        val afterOverall = DriverProfileCatalog.overall(updated.ratings())
        val nextPhase = when {
            afterOverall >= updated.potentialOverall -> "STABLE"
            rate < 0.0 -> "REGRESSION"
            rate >= 0.50 -> "GROWING"
            else -> "STABLE"
        }
        return TickResult(updated, bank.coerceIn(-0.99, 0.99), nextPhase, afterOverall - beforeOverall)
    }

    /**
     * Free-agent development has no qualifying/race evidence to score. Give it a
     * neutral full natural-growth reference, then scale only its positive growth
     * by FREE_DRIVER_GROWTH_RATE (1.20 in the current balance). Potential, class soft-ceiling and annual caps
     * are still enforced by the shared tick; no sporting-performance sample is made.
     */
    fun applyFreeDriverTick(
        driver: DriverDefinition,
        currentBank: Double,
        annualGains: IntArray,
        random: Random
    ): TickResult = applyPerformanceTick(
        driver = driver,
        performanceIndex = FREE_DRIVER_NEUTRAL_PERFORMANCE_INDEX,
        currentBank = currentBank,
        annualGains = annualGains,
        random = random,
        facilityGrowthEfficiency = FREE_DRIVER_GROWTH_RATE
    )

    fun minimumOverall(driverClass:String):Int = DriverProfileCatalog.minimumOverall(driverClass)

    /** Performance regression has a global safety floor; class changes follow two seasons. */
    @Suppress("UNUSED_PARAMETER")
    fun minimumOverall(driver:DriverDefinition):Int = 40

    @Suppress("UNUSED_PARAMETER")
    fun evaluate(driver:DriverDefinition, target:Target, input:PerformanceInput): Evaluation {
        val championship = ratio(target.championshipPosition.toDouble(), input.championshipPosition.toDouble())
        val expectedPoints = (((81-target.championshipPosition).coerceAtLeast(1)/80.0)*450.0)
        val points = ratio(expectedPoints,input.points.toDouble().coerceAtLeast(0.0),0.35)
        val race = ratio(target.championshipPosition.toDouble(),input.averageRacePosition.coerceAtLeast(1.0))
        val expectedWins = ((81-target.championshipPosition).coerceAtLeast(1)/80.0)*12.0
        val expectedPodiums = ((81-target.championshipPosition).coerceAtLeast(1)/80.0)*25.0
        val achievement=(ratio(expectedWins,input.wins.toDouble(),0.35)+ratio(expectedPodiums,input.podiums.toDouble(),0.35))/2.0
        val qualifying=ratio(target.championshipPosition.toDouble(),input.averageQualifyingPosition.coerceAtLeast(1.0))
        val teammate=if(input.teammateAveragePosition!=null&&input.teammateComparisons>0) ratio(input.teammateAveragePosition,input.averageRacePosition.coerceAtLeast(1.0)) else 100.0
        val index=championship*.30+points*.20+race*.15+achievement*.15+qualifying*.10+teammate*.10
        val tier=performanceTier(index); val multiplier=performanceUtilization(index)
        return Evaluation(index.coerceIn(0.0,150.0),tier,multiplier,0)
    }

    fun applyPositiveGain(driver:DriverDefinition,intendedGain:Int,annualGains:IntArray,random:Random,perAttributeCap:Int=DriverProfileCatalog.maxAnnualGain(driver.evolution)):DriverDefinition {
        if(intendedGain<=0)return driver; require(annualGains.size==7)
        val next=driver.ratings(); val potential=driver.potentialOverall.coerceIn(DriverProfileCatalog.overall(next),100)
        val targetSum=potential*7
        var remaining=intendedGain
        while(remaining>0 && next.sum()<targetSum){
            val eligible=(0..6).filter{next[it]<100&&annualGains[it]<perAttributeCap}
            if(eligible.isEmpty())break
            // Preserve the driver's natural profile while giving underdeveloped
            // attributes a modest balancing chance. The shared performance tick applies
            // the class soft threshold before this attribute allocation.
            val weights=eligible.map{ i ->
                val natural=driver.ratings()[i].toDouble(); val head=(100-next[i]).toDouble()
                0.35 + natural/100.0*0.65 + head/60.0*0.80
            }
            val total=weights.sum(); var pick=random.nextDouble()*total; var chosen=eligible.last()
            for(k in eligible.indices){ pick-=weights[k]; if(pick<=0){chosen=eligible[k];break} }
            next[chosen]++; annualGains[chosen]++; remaining--
        }
        return driver.withRatings(next)
    }

    fun applyRegression(driver:DriverDefinition,intendedLoss:Int,random:Random):DriverDefinition {
        if(intendedLoss<=0)return driver
        val next=driver.ratings()
        val floor=minimumOverall(driver)
        repeat(intendedLoss){
            // Career regression has a global safety floor of Overall 40. Class
            // eligibility is reviewed independently after two seasons of performance.
            if ((next.sum()-1) / 7 < floor) return@repeat
            val eligible=(0..6).filter{next[it]>40}
            if(eligible.isEmpty())return@repeat
            val excess=(next.sum()/7 - floor).coerceAtLeast(0).toDouble()
            val weights: List<Double> = eligible.map{ i ->
                0.35 + (next[i]-40)/60.0 + excess/50.0
            }
            val total=weights.sum(); var pick=random.nextDouble()*total; var chosen=eligible.last()
            for(k in eligible.indices){pick-=weights[k];if(pick<=0){chosen=eligible[k];break}}
            next[chosen]--
        }
        return driver.withRatings(next)
    }

    @Suppress("UNUSED_PARAMETER")
    fun recoveryCap(driver:DriverDefinition):Int=1
    fun applyDelta(driver:DriverDefinition,delta:Int):DriverDefinition=if(delta>0)applyPositiveGain(driver,delta,IntArray(7),Random.Default) else applyRegression(driver,-delta,Random.Default)
    private fun ratio(expected:Double,actual:Double,floor:Double=.50):Double{if(expected<=0)return 100.0;if(actual<=0)return 150.0;return(expected/actual*100.0).coerceIn(floor*100.0,150.0)}
    private fun DriverDefinition.ratings():IntArray=intArrayOf(speed,qualifying,overtaking,defense,consistency,wet,tyre)
    private fun DriverDefinition.withRatings(a:IntArray):DriverDefinition=copy(speed=a[0],qualifying=a[1],overtaking=a[2],defense=a[3],consistency=a[4],wet=a[5],tyre=a[6])
}
