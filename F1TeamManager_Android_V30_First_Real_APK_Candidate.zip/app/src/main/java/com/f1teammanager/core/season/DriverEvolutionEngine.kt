package com.f1teammanager.core.season

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.random.Random

/** Performance-driven pilot growth/regression. Class changes are reviewed separately. */
object DriverEvolutionEngine {
    /** The driver championship always contains 80 slots; constructor ranking is a separate 1..40 table. */
    const val DRIVER_GRID_SIZE = 80
    /** Free agents retain the same natural growth rate as contracted drivers. */
    const val FREE_DRIVER_GROWTH_RATE = 1.0
    const val AGE_CYCLE_START = 18
    const val AGE_CYCLE_END = 43
    const val AGE_CYCLE_RECOVERY_RATE = 0.50
    /** Speed, overtaking and defense are the physical/reflex attributes affected by age. */
    private val AGE_PHYSICAL_ATTRIBUTE_INDICES: IntArray = intArrayOf(0, 2, 3)
    private const val FREE_DRIVER_NEUTRAL_PERFORMANCE_INDEX = 105.0

    /** Official career starting age comes from the 2026 roster supplied by the user. */
    fun careerStartAge(driver: DriverDefinition): Int =
        DriverAgeCatalog.age(driver.name) ?: 24

    /** Age cycle runs from the official 2026 age through 43, then restarts at 18. */
    fun careerCycleIndex(driver: DriverDefinition, season: Int): Int {
        val elapsed = (season - 2026).coerceAtLeast(0)
        val firstCycleYears = (AGE_CYCLE_END + 1 - careerStartAge(driver)).coerceAtLeast(1)
        if (elapsed < firstCycleYears) return 0
        return 1 + (elapsed - firstCycleYears) / (AGE_CYCLE_END - AGE_CYCLE_START + 1)
    }

    fun careerAge(driver: DriverDefinition, season: Int): Int {
        val elapsed = (season - 2026).coerceAtLeast(0)
        val startAge = careerStartAge(driver)
        val firstCycleYears = (AGE_CYCLE_END + 1 - startAge).coerceAtLeast(1)
        return if (elapsed < firstCycleYears) startAge + elapsed
        else AGE_CYCLE_START + ((elapsed - firstCycleYears) % (AGE_CYCLE_END - AGE_CYCLE_START + 1))
    }

    /** Natural development slows after the usual peak years. */
    fun ageGrowthFactor(age: Int): Double = when (age) {
        in Int.MIN_VALUE..21 -> 1.15
        in 22..25 -> 1.05
        in 26..29 -> 0.90
        in 30..32 -> 0.70
        in 33..35 -> 0.48
        in 36..38 -> 0.24
        else -> 0.10
    }

    /** Small per-GP aging pressure; good form can offset it, but not indefinitely. */
    fun ageDeclineRate(age: Int): Double = when (age) {
        in Int.MIN_VALUE..33 -> 0.0
        in 34..35 -> 0.08
        in 36..38 -> 0.20
        in 39..41 -> 0.38
        else -> 0.55
    }

    /**
     * Individual season expectation. Qualifying and race use separate centers because
     * a driver's qualifying skill and overall race ability are not interchangeable.
     * The centers are wrapped in a tolerance band; finishing anywhere inside that band
     * is considered an expected weekend rather than a miss against one fixed position.
     */
    data class Target(
        val championshipPosition: Int,
        val qualifyingPosition: Int = championshipPosition,
        val racePosition: Int = championshipPosition
    ) {
        val qualifyingMargin: Int get() = positionMargin(qualifyingPosition)
        val raceMargin: Int get() = positionMargin(racePosition)
        val qualifyingMinPosition: Int get() = (qualifyingPosition - qualifyingMargin).coerceAtLeast(1)
        val qualifyingMaxPosition: Int get() = (qualifyingPosition + qualifyingMargin).coerceAtMost(DRIVER_GRID_SIZE)
        val raceMinPosition: Int get() = (racePosition - raceMargin).coerceAtLeast(1)
        val raceMaxPosition: Int get() = (racePosition + raceMargin).coerceAtMost(DRIVER_GRID_SIZE)
    }

    /** Input used to anchor two driver expectations to one constructor/car ranking. */
    data class TargetInput(
        val driverId: Int,
        val teamId: Int,
        val carStrength: Double,
        val driverOverall: Int,
        val qualifyingStrength: Int
    )

    /**
     * Creates the 80-driver expectation from the 40-car order, not from a blended
     * 80-driver score. Each constructor occupies two baseline positions:
     * P(2 * teamRank - 1) and P(2 * teamRank). Talent may adjust an individual
     * expectation by at most three places, so a strong driver cannot turn a midfield
     * car into a front-running car on paper.
     *
     * Example: constructor P22 starts at driver P43/P44. Individual skill can move
     * those centers only within P40..P47. Constructor and driver championship scales
     * remain separate (1..40 and 1..80 respectively).
     */
    fun buildIndividualTargets(inputs: List<TargetInput>): Map<Int, Target> {
        val valid = inputs
            .filter { it.driverId > 0 && it.teamId > 0 }
            .distinctBy { it.driverId }
        if (valid.size != DRIVER_GRID_SIZE) return emptyMap()

        val byTeam = valid.groupBy { it.teamId }
        if (byTeam.size != 40 || byTeam.values.any { it.size != 2 }) return emptyMap()

        val constructorRanks = byTeam.entries
            .map { (teamId, drivers) ->
                teamId to drivers.map { it.carStrength.coerceIn(0.0, 100.0) }.average()
            }
            .sortedWith(compareByDescending<Pair<Int, Double>> { it.second }.thenBy { it.first })
            .mapIndexed { index, (teamId, _) -> teamId to (index + 1) }
            .toMap()

        val averageRaceSkill = valid.map { it.driverOverall.coerceIn(40, 100).toDouble() }.average()
        val averageQualifyingSkill = valid.map { it.qualifyingStrength.coerceIn(40, 100).toDouble() }.average()

        fun individualAdjustment(skill: Int, gridAverage: Double): Int =
            ((gridAverage - skill.coerceIn(40, 100)) / 8.0).roundToInt().coerceIn(-3, 3)

        val targets = linkedMapOf<Int, Target>()
        byTeam.forEach { (teamId, drivers) ->
            val teamRank = constructorRanks.getValue(teamId)
            val firstDriverPosition = teamRank * 2 - 1

            val qualifyingOrder = drivers.sortedWith(
                compareByDescending<TargetInput> { it.qualifyingStrength.coerceIn(40, 100) }
                    .thenBy { it.driverId }
            )
            val raceOrder = drivers.sortedWith(
                compareByDescending<TargetInput> { it.driverOverall.coerceIn(40, 100) }
                    .thenBy { it.driverId }
            )
            val qualifyingSlot = qualifyingOrder.mapIndexed { index, input -> input.driverId to index }.toMap()
            val raceSlot = raceOrder.mapIndexed { index, input -> input.driverId to index }.toMap()

            drivers.forEach { input ->
                val qualifyingBase = firstDriverPosition + qualifyingSlot.getValue(input.driverId)
                val raceBase = firstDriverPosition + raceSlot.getValue(input.driverId)
                val qualifying = (qualifyingBase + individualAdjustment(input.qualifyingStrength, averageQualifyingSkill))
                    .coerceIn(1, DRIVER_GRID_SIZE)
                val race = (raceBase + individualAdjustment(input.driverOverall, averageRaceSkill))
                    .coerceIn(1, DRIVER_GRID_SIZE)
                targets[input.driverId] = Target(
                    championshipPosition = ((qualifying + race + 1) / 2).coerceIn(1, DRIVER_GRID_SIZE),
                    qualifyingPosition = qualifying,
                    racePosition = race
                )
            }
        }
        return targets
    }

    /** Uniform ±3 tolerance: the same expectation width applies throughout P1..P80. */
    private fun positionMargin(@Suppress("UNUSED_PARAMETER") position: Int): Int = 3
    data class PerformanceInput(
        val championshipPosition:Int,
        val points:Int,
        val averageRacePosition:Double,
        val wins:Int,
        val podiums:Int,
        val averageQualifyingPosition:Double,
        val teammateAveragePosition:Double?,
        val teammateComparisons:Int
    )
    data class Evaluation(val index:Double, val tier:String, val multiplier:Double, val delta:Int)

    /** Distinct headline so regressions are visible as first-class market news. */
    fun newsTitle(overallDelta: Int): String =
        if (overallDelta < 0) "REGRESSÃO DE PILOTO" else "EVOLUÇÃO DE PILOTO"

    fun performanceTier(index: Double): String = when {
        index >= 115.0 -> "Excepcional"
        index >= 105.0 -> "Excelente"
        index >= 98.0 -> "Muito bom"
        index >= 92.0 -> "Bom"
        index >= 85.0 -> "Normal"
        index >= 75.0 -> "Abaixo do esperado"
        index >= 60.0 -> "Ruim"
        else -> "Muito ruim"
    }

    /**
     * Legacy display multiplier retained for compatibility with summary screens.
     * Actual progression now uses performanceEvolutionRate and the shared per-GP tick.
     * Performance below/above expectation slows/accelerates growth; the evolution
     * category independently limits annual gains per attribute.
     */
    fun performanceUtilization(index: Double): Double = when {
        index >= 115.0 -> 1.25
        index >= 105.0 -> 1.15
        index >= 98.0 -> 1.05
        index >= 92.0 -> 1.00
        index >= 85.0 -> 0.85
        index >= 75.0 -> 0.65
        index >= 60.0 -> 0.45
        else -> 0.30
    }

    /**
     * Range-aware per-GP evaluation. A result inside the driver's own target band is
     * neutral (105, the normal growth baseline); performance is rewarded/penalized only outside the tolerance band.
     * Missing rows use the individual target center, never a synthetic grid position.
     */
    fun gpPerformanceIndex(target: Target, qualifyingPosition: Int, racePosition: Int): Double {
        val qCenter = target.qualifyingPosition.coerceIn(1, DRIVER_GRID_SIZE)
        val rCenter = target.racePosition.coerceIn(1, DRIVER_GRID_SIZE)
        val q = if (qualifyingPosition <= 0) qCenter else qualifyingPosition.coerceIn(1, DRIVER_GRID_SIZE)
        val r = if (racePosition <= 0) rCenter else racePosition.coerceIn(1, DRIVER_GRID_SIZE)
        val qualifyingScore = positionBandScore(q, qCenter, target.qualifyingMargin)
        val raceScore = positionBandScore(r, rCenter, target.raceMargin)
        return (qualifyingScore * 0.40 + raceScore * 0.60).coerceIn(25.0, 150.0)
    }

    private fun positionBandScore(actual: Int, center: Int, margin: Int): Double {
        val minPosition = (center - margin).coerceAtLeast(1)
        val maxPosition = (center + margin).coerceAtMost(DRIVER_GRID_SIZE)
        return when {
            actual < minPosition -> 105.0 + (minPosition - actual) * 5.0
            actual > maxPosition -> 105.0 - (actual - maxPosition) * 5.0
            else -> 105.0
        }
    }

    /**
     * Mechanical/equipment DNFs are not driver-performance evidence. Keep that GP's
     * race component neutral at the driver's target while preserving qualifying evidence.
     * Driver-caused accidents remain a sporting result and are still evaluated.
     */
    fun racePositionForEvolution(target: Target, actualPosition: Int?, status: String?): Int {
        val position = actualPosition?.takeIf { it in 1..DRIVER_GRID_SIZE } ?: target.racePosition
        val normalized = status.orEmpty().uppercase()
        if (!normalized.startsWith("DNF")) return position
        val equipmentOrExternalFailure = listOf(
            "PANE", "FALHA", "SEM COMBUSTÍVEL", "PNEU DEGRADADO", "COLISÃO"
        ).any(normalized::contains)
        return if (equipmentOrExternalFailure) target.racePosition.coerceIn(1, DRIVER_GRID_SIZE) else position
    }

    /**
     * Legacy center-only scoring retained for compatibility with older integrations.
     * Active career and Team Principal progression use the range-aware Target overload.
     * Missing positions are treated as neutral against the legacy center.
     */
    fun gpPerformanceIndex(targetPosition:Int, qualifyingPosition:Int, racePosition:Int): Double {
        val target = targetPosition.coerceIn(1,DRIVER_GRID_SIZE)
        val q = if (qualifyingPosition <= 0) target else qualifyingPosition.coerceIn(1,DRIVER_GRID_SIZE)
        val r = if (racePosition <= 0) target else racePosition.coerceIn(1,DRIVER_GRID_SIZE)
        val qualifyingScore = (100.0 + (target - q) * 5.0).coerceIn(25.0,150.0)
        val raceScore = (100.0 + (target - r) * 5.0).coerceIn(25.0,150.0)
        return (qualifyingScore * 0.40 + raceScore * 0.60).coerceIn(25.0,150.0)
    }

    /**
     * V649 phase tokens are performance states, not an age/career clock. The old
     * PEAK token is accepted as STABLE so existing saves never enter timed decline.
     */
    fun normalizePhase(phase: String?): String = when (phase) {
        "GROWING", "REGRESSION", "STABLE" -> phase
        "PEAK" -> "STABLE"
        else -> "GROWING"
    }

    /** A pilot starts developing only while there is meaningful room below potential. */
    fun initialPhase(driver: DriverDefinition): String {
        val current = DriverProfileCatalog.overall(driver.ratings())
        return if (driver.potentialOverall.coerceIn(current, 100) - current <= 1) "STABLE" else "GROWING"
    }

    /**
     * Signed, performance-driven development rate per completed GP. A neutral
     * weekend preserves most progress; repeated poor performances are required
     * before the negative fractional bank becomes an attribute loss.
     */
    fun performanceEvolutionRate(index: Double): Double = when {
        index >= 115.0 -> 1.30
        index >= 105.0 -> 1.00
        index >= 98.0 -> 0.50
        index >= 92.0 -> 0.20
        index >= 85.0 -> 0.0
        index >= 75.0 -> -0.20
        index >= 60.0 -> -0.45
        else -> -0.70
    }

    /**
     * Class is a soft threshold, not a hard progression wall. Good drivers may
     * exceed it while retaining at least 60% of their natural growth, so a high-
     * potential driver in a weak team is not trapped by a delayed class promotion.
     */
    fun classGrowthFactor(driverClass: String, currentOverall: Int): Double {
        val excess = (currentOverall - DriverProfileCatalog.ceiling(driverClass)).coerceAtLeast(0)
        return when {
            excess <= 0 -> 1.0
            excess <= 2 -> 0.90
            excess <= 4 -> 0.80
            excess <= 7 -> 0.70
            else -> 0.60
        }
    }

    data class TickResult(
        val driver: DriverDefinition,
        val bank: Double,
        val phase: String,
        val attributeDelta: Int,
        /** Fractional age-pressure bank, stored separately from form/performance regression. */
        val ageBank: Double = 0.0,
        /** Unrecovered points lost specifically to aging, indexed like DriverDefinition.ratings(). */
        val agePhysicalLosses: IntArray = IntArray(7),
        /** Lifetime high-water marks for physical attributes; recovery cannot exceed these. */
        val agePhysicalPeaks: IntArray = IntArray(7),
        val ageCycleIndex: Int = 0,
        val ageCycleRestarted: Boolean = false,
        val ageRecoveredPoints: Int = 0
    )

    /**
     * Apply only age-related recovery at a cycle boundary; skill/mental attributes are untouched.
     * The 50% target is rounded once over the combined physical-loss ledger, then distributed
     * across attributes by largest fractional remainder. This avoids losing every odd point
     * when each attribute is rounded down independently.
     */
    private fun recoverAgePhysicalLosses(
        driver: DriverDefinition,
        losses: IntArray,
        peaks: IntArray
    ): Triple<DriverDefinition, IntArray, Int> {
        val ratings = driver.ratings()
        val remaining = losses.copyOf()
        val capacities = IntArray(7)
        val recoveredByAttribute = IntArray(7)
        val fractionalRemainders = DoubleArray(7)

        val totalPhysicalLoss = AGE_PHYSICAL_ATTRIBUTE_INDICES.sumOf { index ->
            remaining[index].coerceAtLeast(0).toLong()
        }

        AGE_PHYSICAL_ATTRIBUTE_INDICES.forEach { index ->
            val loss = remaining[index].coerceAtLeast(0)
            val exactRequest = loss * AGE_CYCLE_RECOVERY_RATE
            val wholeRequest = exactRequest.toInt()
            val capacity = min(
                loss,
                (peaks[index].coerceIn(40, 100) - ratings[index]).coerceAtLeast(0)
            )
            capacities[index] = capacity
            fractionalRemainders[index] = exactRequest - wholeRequest
            recoveredByAttribute[index] = min(wholeRequest, capacity)
        }

        val totalCapacity = AGE_PHYSICAL_ATTRIBUTE_INDICES.sumOf { capacities[it] }
        val aggregateTarget = (totalPhysicalLoss.toDouble() * AGE_CYCLE_RECOVERY_RATE)
            .roundToInt()
            .coerceAtMost(totalCapacity)
        var pointsToDistribute = (aggregateTarget - recoveredByAttribute.sum()).coerceAtLeast(0)

        // Largest-remainder apportionment keeps the aggregate as close as possible to 50%.
        // Ties are deterministic: larger losses first, then the stable attribute index.
        val allocationOrder = AGE_PHYSICAL_ATTRIBUTE_INDICES.sortedWith(
            compareByDescending<Int> { fractionalRemainders[it] }
                .thenByDescending { remaining[it] }
                .thenBy { it }
        )
        while (pointsToDistribute > 0) {
            var madeProgress = false
            for (index in allocationOrder) {
                if (pointsToDistribute == 0) break
                if (recoveredByAttribute[index] < capacities[index]) {
                    recoveredByAttribute[index]++
                    pointsToDistribute--
                    madeProgress = true
                }
            }
            if (!madeProgress) break
        }

        AGE_PHYSICAL_ATTRIBUTE_INDICES.forEach { index ->
            val recovered = recoveredByAttribute[index]
            ratings[index] = (ratings[index] + recovered).coerceIn(40, 100)
            remaining[index] = (remaining[index] - recovered).coerceAtLeast(0)
        }
        val recoveredTotal = AGE_PHYSICAL_ATTRIBUTE_INDICES.sumOf { recoveredByAttribute[it] }
        return Triple(driver.withRatings(ratings), remaining, recoveredTotal)
    }

    /** Age regression is restricted to physical/reflex attributes and is tracked separately. */
    private fun applyAgePhysicalRegression(
        driver: DriverDefinition,
        intendedLoss: Int,
        random: Random
    ): Pair<DriverDefinition, IntArray> {
        if (intendedLoss <= 0) return driver to IntArray(7)
        val values = driver.ratings()
        val losses = IntArray(7)
        var remaining = intendedLoss
        while (remaining > 0) {
            val eligible = AGE_PHYSICAL_ATTRIBUTE_INDICES.filter { values[it] > 40 }
            if (eligible.isEmpty()) break
            val chosen = eligible[random.nextInt(eligible.size)]
            values[chosen] = (values[chosen] - 1).coerceAtLeast(40)
            losses[chosen]++
            remaining--
        }
        return driver.withRatings(values) to losses
    }

    /**
     * Shared GP progression path. Performance/form regression and natural aging are
     * separate ledgers so a new age cycle can recover 50% of age-related physical loss
     * without undoing skill/mental losses caused by poor sporting performance.
     */
    fun applyPerformanceTick(
        driver: DriverDefinition,
        performanceIndex: Double,
        currentBank: Double,
        annualGains: IntArray,
        random: Random,
        facilityGrowthEfficiency: Double = 1.0,
        /** Average GP performance in the current season; grants a small temporary class-ceiling margin. */
        seasonPerformanceAverage: Double? = null,
        careerAge: Int? = null,
        currentAgeBank: Double = 0.0,
        currentAgePhysicalLosses: IntArray = IntArray(7),
        currentAgePhysicalPeaks: IntArray = driver.ratings(),
        currentAgeCycleIndex: Int? = null,
        careerCycleIndex: Int? = null
    ): TickResult {
        require(annualGains.size == 7) { "O controle anual precisa ter sete atributos" }
        require(currentAgePhysicalLosses.size == 7) { "O histórico de perdas físicas precisa ter sete atributos" }
        require(currentAgePhysicalPeaks.size == 7) { "O pico físico precisa ter sete atributos" }

        val beforeOverall = DriverProfileCatalog.overall(driver.ratings())
        val rawRate = performanceEvolutionRate(performanceIndex)
        val age = careerAge
        val growthFactor = age?.let(::ageGrowthFactor) ?: 1.0
        val agingPressure = age?.let(::ageDeclineRate) ?: 0.0
        val performanceRate = if (rawRate > 0.0) rawRate * growthFactor else rawRate
        val annualProfileBudget = DriverProfileCatalog.maxAnnualGain(driver.evolution) * 7.0 / 150.0

        var updated = driver.normalized()
        var bank = currentBank
        var ageBank = currentAgeBank.coerceIn(0.0, 0.99)
        var ageLosses = currentAgePhysicalLosses.copyOf().also { values ->
            values.indices.forEach { values[it] = values[it].coerceAtLeast(0) }
        }
        var agePeaks = currentAgePhysicalPeaks.copyOf().also { values ->
            val current = driver.ratings()
            values.indices.forEach { values[it] = max(values[it].coerceIn(40, 100), current[it]) }
        }
        val resultingCycle = careerCycleIndex ?: currentAgeCycleIndex ?: 0
        val cycleRestarted = careerCycleIndex != null && currentAgeCycleIndex != null && careerCycleIndex > currentAgeCycleIndex
        var recoveredPoints = 0

        if (cycleRestarted) {
            val recovery = recoverAgePhysicalLosses(updated, ageLosses, agePeaks)
            updated = recovery.first
            ageLosses = recovery.second
            recoveredPoints = recovery.third
            // The age bank belongs to the previous cycle; fractional pressure must not
            // immediately age the pilot again after the cycle restart.
            ageBank = 0.0
        }

        val classMargin = when {
            (seasonPerformanceAverage ?: performanceIndex) >= 130.0 -> 3
            (seasonPerformanceAverage ?: performanceIndex) >= 120.0 -> 2
            (seasonPerformanceAverage ?: performanceIndex) >= 110.0 -> 1
            else -> 0
        }
        val performanceCeiling = (DriverProfileCatalog.ceiling(driver.driverClass) + classMargin).coerceAtMost(100)
        when {
            performanceRate > 0.0 && DriverProfileCatalog.overall(updated.ratings()) < minOf(
                driver.potentialOverall.coerceIn(40, 100), performanceCeiling
            ) -> {
                bank += annualProfileBudget * performanceRate
            }
            performanceRate < 0.0 -> bank -= annualProfileBudget * -performanceRate
            performanceRate > 0.0 && DriverProfileCatalog.overall(updated.ratings()) >= driver.potentialOverall -> bank = 0.0
        }

        // Apply performance-driven development/regression independently from age.
        if (bank >= 1.0) {
            val requested = bank.toInt()
            val before = updated.ratings()
            updated = applyPositiveGain(
                updated, requested, annualGains, random,
                perAttributeCap = DriverProfileCatalog.maxAnnualGain(driver.evolution),
                allowClassCeilingExceed = classMargin > 0,
                classCeilingMargin = classMargin
            )
            val applied = (updated.ratings().sum() - before.sum()).coerceAtLeast(0)
            bank = if (applied > 0) bank - applied else bank.coerceAtMost(0.99)
        } else if (bank <= -1.0) {
            val requested = (-bank).toInt()
            val before = updated.ratings()
            updated = applyRegression(updated, requested, random)
            val removed = (before.sum() - updated.ratings().sum()).coerceAtLeast(0)
            bank = if (removed > 0) bank + removed else 0.0
        }

        // Natural aging only degrades physical/reflex attributes and keeps its own ledger.
        if (agingPressure > 0.0) ageBank += annualProfileBudget * agingPressure
        if (ageBank >= 1.0) {
            val requested = ageBank.toInt()
            val ageRegression = applyAgePhysicalRegression(updated, requested, random)
            updated = ageRegression.first
            val removed = ageRegression.second.sum()
            ageRegression.second.indices.forEach { index ->
                ageLosses[index] = (ageLosses[index] + ageRegression.second[index]).coerceAtMost(100)
            }
            ageBank = if (removed > 0) (ageBank - removed).coerceAtMost(0.99) else 0.99
        }

        val afterRatings = updated.ratings()
        AGE_PHYSICAL_ATTRIBUTE_INDICES.forEach { index ->
            agePeaks[index] = max(agePeaks[index], afterRatings[index]).coerceIn(40, 100)
        }
        val afterOverall = DriverProfileCatalog.overall(afterRatings)
        val netCareerRate = performanceRate - agingPressure
        val nextPhase = when {
            afterOverall >= updated.potentialOverall -> "STABLE"
            netCareerRate < 0.0 -> "REGRESSION"
            netCareerRate >= 0.50 -> "GROWING"
            else -> "STABLE"
        }
        return TickResult(
            driver = updated,
            bank = bank.coerceIn(-0.99, 0.99),
            phase = nextPhase,
            attributeDelta = afterOverall - beforeOverall,
            ageBank = ageBank.coerceIn(0.0, 0.99),
            agePhysicalLosses = ageLosses,
            agePhysicalPeaks = agePeaks,
            ageCycleIndex = resultingCycle,
            ageCycleRestarted = cycleRestarted,
            ageRecoveredPoints = recoveredPoints
        )
    }

    /** Free agents progress at 100% of the same natural rate as contracted drivers. */
    fun applyFreeDriverTick(
        driver: DriverDefinition,
        currentBank: Double,
        annualGains: IntArray,
        random: Random,
        careerAge: Int? = null,
        currentAgeBank: Double = 0.0,
        currentAgePhysicalLosses: IntArray = IntArray(7),
        currentAgePhysicalPeaks: IntArray = driver.ratings(),
        currentAgeCycleIndex: Int? = null,
        careerCycleIndex: Int? = null
    ): TickResult = applyPerformanceTick(
        driver = driver,
        performanceIndex = FREE_DRIVER_NEUTRAL_PERFORMANCE_INDEX,
        currentBank = currentBank,
        annualGains = annualGains,
        random = random,
        facilityGrowthEfficiency = FREE_DRIVER_GROWTH_RATE,
        careerAge = careerAge,
        currentAgeBank = currentAgeBank,
        currentAgePhysicalLosses = currentAgePhysicalLosses,
        currentAgePhysicalPeaks = currentAgePhysicalPeaks,
        currentAgeCycleIndex = currentAgeCycleIndex,
        careerCycleIndex = careerCycleIndex
    )

    fun minimumOverall(driverClass:String):Int = DriverProfileCatalog.minimumOverall(driverClass)

    /** Performance regression has a global safety floor; class changes follow two seasons. */
    @Suppress("UNUSED_PARAMETER")
    fun minimumOverall(driver:DriverDefinition):Int = 40

    @Suppress("UNUSED_PARAMETER")
    fun evaluate(driver:DriverDefinition, target:Target, input:PerformanceInput): Evaluation {
        val championship = ratio(target.championshipPosition.toDouble(), input.championshipPosition.toDouble())
        val expectedPoints = (((81-target.championshipPosition).coerceAtLeast(1)/80.0)*450.0)
        val points = ratio(expectedPoints,input.points.toDouble().coerceAtLeast(0.0),0.35)
        val race = ratio(target.championshipPosition.toDouble(),input.averageRacePosition.coerceAtLeast(1.0))
        val expectedWins = ((81-target.championshipPosition).coerceAtLeast(1)/80.0)*12.0
        val expectedPodiums = ((81-target.championshipPosition).coerceAtLeast(1)/80.0)*25.0
        val achievement=(ratio(expectedWins,input.wins.toDouble(),0.35)+ratio(expectedPodiums,input.podiums.toDouble(),0.35))/2.0
        val qualifying=ratio(target.championshipPosition.toDouble(),input.averageQualifyingPosition.coerceAtLeast(1.0))
        val teammate=if(input.teammateAveragePosition!=null&&input.teammateComparisons>0) ratio(input.teammateAveragePosition,input.averageRacePosition.coerceAtLeast(1.0)) else 100.0
        val index=championship*.30+points*.20+race*.15+achievement*.15+qualifying*.10+teammate*.10
        val tier=performanceTier(index); val multiplier=performanceUtilization(index)
        return Evaluation(index.coerceIn(0.0,150.0),tier,multiplier,0)
    }

    fun applyPositiveGain(driver:DriverDefinition,intendedGain:Int,annualGains:IntArray,random:Random,perAttributeCap:Int=DriverProfileCatalog.maxAnnualGain(driver.evolution), allowClassCeilingExceed:Boolean=false, classCeilingMargin:Int=0):DriverDefinition {
        if(intendedGain<=0)return driver.normalized(); require(annualGains.size==7)
        val next=driver.ratings(); val potential=driver.potentialOverall.coerceIn(DriverProfileCatalog.overall(next),100)
        val targetSum=potential*7
        var remaining=intendedGain
        while(remaining>0 && next.sum()<targetSum){
            val currentOverall = DriverProfileCatalog.overall(next)
            val classCeiling = DriverProfileCatalog.ceiling(driver.driverClass)
            val effectiveCeiling = (classCeiling + if (allowClassCeilingExceed) classCeilingMargin.coerceIn(0, 3) else 0).coerceAtMost(100)
            if (currentOverall >= effectiveCeiling) break
            val eligible=(0..6).filter{next[it]<100&&annualGains[it]<perAttributeCap}
            if(eligible.isEmpty())break
            // Preserve the driver's natural profile while giving underdeveloped
            // attributes a modest balancing chance. The shared performance tick applies
            // the class soft threshold before this attribute allocation.
            val weights=eligible.map{ i ->
                val natural=driver.ratings()[i].toDouble(); val head=(100-next[i]).toDouble()
                0.35 + natural/100.0*0.65 + head/60.0*0.80
            }
            val total=weights.sum(); var pick=random.nextDouble()*total; var chosen=eligible.last()
            for(k in eligible.indices){ pick-=weights[k]; if(pick<=0){chosen=eligible[k];break} }
            next[chosen]++; annualGains[chosen]++; remaining--
        }
        return driver.withRatings(next)
    }

    fun applyRegression(driver:DriverDefinition,intendedLoss:Int,random:Random):DriverDefinition {
        if(intendedLoss<=0)return driver.normalized()
        val next=driver.ratings()
        val floor=minimumOverall(driver)
        repeat(intendedLoss){
            // Career regression has a global safety floor of Overall 40. Class
            // eligibility is reviewed independently after two seasons of performance.
            if ((next.sum()-1) / 7 < floor) return@repeat
            val eligible=(0..6).filter{next[it]>40}
            if(eligible.isEmpty())return@repeat
            val excess=(next.sum()/7 - floor).coerceAtLeast(0).toDouble()
            val weights: List<Double> = eligible.map{ i ->
                0.35 + (next[i]-40)/60.0 + excess/50.0
            }
            val total=weights.sum(); var pick=random.nextDouble()*total; var chosen=eligible.last()
            for(k in eligible.indices){pick-=weights[k];if(pick<=0){chosen=eligible[k];break}}
            next[chosen]--
        }
        return driver.withRatings(next)
    }

    @Suppress("UNUSED_PARAMETER")
    fun recoveryCap(driver:DriverDefinition):Int=1
    fun applyDelta(driver:DriverDefinition,delta:Int):DriverDefinition=if(delta>0)applyPositiveGain(driver,delta,IntArray(7),Random.Default) else applyRegression(driver,-delta,Random.Default)
    private fun ratio(expected:Double,actual:Double,floor:Double=.50):Double{if(expected<=0)return 100.0;if(actual<=0)return 150.0;return(expected/actual*100.0).coerceIn(floor*100.0,150.0)}
    private fun DriverDefinition.ratings():IntArray = com.f1teammanager.core.AttributeBounds.ratings(
        intArrayOf(speed,qualifying,overtaking,defense,consistency,wet,tyre)
    )
    private fun DriverDefinition.withRatings(a:IntArray):DriverDefinition = copy(
        speed=a[0].coerceIn(40,100), qualifying=a[1].coerceIn(40,100),
        overtaking=a[2].coerceIn(40,100), defense=a[3].coerceIn(40,100),
        consistency=a[4].coerceIn(40,100), wet=a[5].coerceIn(40,100), tyre=a[6].coerceIn(40,100)
    ).normalized()
}
