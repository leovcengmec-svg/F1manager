package com.f1teammanager.core.season

import kotlin.math.roundToInt

/** Stage 1 seasonal driver evolution. Class and evolution type are immutable. */
object DriverEvolutionEngine {
    data class Target(val championshipPosition:Int)
    data class PerformanceInput(
        val championshipPosition:Int,
        val points:Int,
        val averageRacePosition:Double,
        val wins:Int,
        val podiums:Int,
        val averageQualifyingPosition:Double,
        val teammateAveragePosition:Double?,
        val teammateComparisons:Int
    )
    data class Evaluation(val index:Double, val tier:String, val multiplier:Double, val delta:Int)

    fun evaluate(driver:DriverDefinition, target:Target, input:PerformanceInput): Evaluation {
        val championship = ratio(target.championshipPosition.toDouble(), input.championshipPosition.toDouble())
        val expectedPoints = ((81 - target.championshipPosition).coerceAtLeast(1) * 7.5)
        val points = ratio(expectedPoints, input.points.toDouble().coerceAtLeast(0.0), floor=0.35)
        val race = ratio(target.championshipPosition.toDouble(), input.averageRacePosition.coerceAtLeast(1.0))
        val expectedWins = ((81 - target.championshipPosition).coerceAtLeast(1) / 80.0) * 12.0
        val expectedPodiums = ((81 - target.championshipPosition).coerceAtLeast(1) / 80.0) * 25.0
        val achievement = (
            ratio(expectedWins, input.wins.toDouble(), floor=0.35) +
            ratio(expectedPodiums, input.podiums.toDouble(), floor=0.35)
        ) / 2.0
        val qualifying = ratio(target.championshipPosition.toDouble(), input.averageQualifyingPosition.coerceAtLeast(1.0))
        val teammate = if (input.teammateAveragePosition != null && input.teammateComparisons > 0) {
            ratio(input.teammateAveragePosition, input.averageRacePosition.coerceAtLeast(1.0))
        } else 100.0
        val index = championship * .30 + points * .20 + race * .15 + achievement * .15 + qualifying * .10 + teammate * .10
        val tier = when {
            index >= 115.0 -> "Excepcional"
            index >= 105.0 -> "Excelente"
            index >= 92.0 -> "Esperado"
            index >= 75.0 -> "Abaixo do esperado"
            else -> "Muito ruim"
        }
        val multiplier = when (tier) {
            "Excepcional" -> 1.25
            "Excelente" -> 1.10
            "Esperado" -> 1.00
            "Abaixo do esperado" -> .75
            else -> .50
        }
        val overall = DriverProfileCatalog.overall(driver.ratings())
        val ceiling = DriverProfileCatalog.ceiling(driver.driverClass)
        val maxGain = DriverProfileCatalog.maxAnnualGain(driver.evolution)
        val delta = evolutionDelta(overall, ceiling, maxGain, tier, multiplier)
        return Evaluation(index.coerceIn(0.0,150.0), tier, multiplier, delta)
    }

    fun applyDelta(driver:DriverDefinition, delta:Int): DriverDefinition {
        if (delta == 0) return driver
        val current = driver.ratings()
        val weights = intArrayOf(100, 96, 92, 88, 104, 90, 94)
        val totalWeight = weights.sum()
        val next = IntArray(7)
        for (i in current.indices) {
            val adjustment = (delta.toDouble() * weights[i] / totalWeight).roundToInt()
            next[i] = (current[i] + adjustment).coerceIn(40, 100)
        }
        val ceiling = DriverProfileCatalog.ceiling(driver.driverClass)
        while (next.sum() > ceiling * 7) {
            val i = next.indices.maxByOrNull { next[it] } ?: break
            if (next[i] <= 40) break
            next[i]--
        }
        return driver.withRatings(next)
    }

    private fun evolutionDelta(overall:Int, ceiling:Int, maxGain:Int, tier:String, multiplier:Double):Int {
        // Reaching the ceiling starts a peak phase; it does not force immediate decline.
        if (overall >= ceiling) {
            return when (tier) {
                "Excepcional", "Excelente" -> 0
                "Esperado" -> -1
                "Abaixo do esperado" -> -2
                else -> -3
            }
        }
        // Recovery zone: after substantial regression, good seasons can rebuild the driver.
        val recovery = overall <= 49
        return when (tier) {
            "Excepcional", "Excelente", "Esperado" -> (maxGain * multiplier).roundToInt().coerceAtLeast(1)
            "Abaixo do esperado" -> if (recovery) 0 else -1
            else -> if (recovery) -1 else -2
        }.coerceIn(-3, maxGain + 2)
    }

    private fun ratio(expected:Double, actual:Double, floor:Double=0.50):Double {
        if (expected <= 0.0) return 100.0
        if (actual <= 0.0) return 150.0
        return (expected / actual * 100.0).coerceIn(floor * 100.0, 150.0)
    }

    private fun DriverDefinition.ratings(): IntArray = intArrayOf(speed, qualifying, overtaking, defense, consistency, wet, tyre)
    private fun DriverDefinition.withRatings(a:IntArray): DriverDefinition = copy(
        speed=a[0], qualifying=a[1], overtaking=a[2], defense=a[3], consistency=a[4], wet=a[5], tyre=a[6]
    )
}
