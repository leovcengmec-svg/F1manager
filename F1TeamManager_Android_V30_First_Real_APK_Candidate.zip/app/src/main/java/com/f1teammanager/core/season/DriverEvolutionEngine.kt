package com.f1teammanager.core.season

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.random.Random

/** Performance-driven pilot growth/regression. Class changes are reviewed separately. */
object DriverEvolutionEngine {
    /** Free agents keep developing without race feedback at 90% of the natural rate. */
    const val FREE_DRIVER_GROWTH_RATE = 0.90
    private const val FREE_DRIVER_NEUTRAL_PERFORMANCE_INDEX = 105.0

    data class Target(val championshipPosition:Int)
    data class PerformanceInput(
        val championshipPosition:Int,
        val points:Int,
        val averageRacePosition:Double,
        val wins:Int,
        val podiums:Int,
        val averageQualifyingPosition:Double,
        val teammateAveragePosition:Double?,
        val teammateComparisons:Int
    )
    data class Evaluation(val index:Double, val tier:String, val multiplier:Double, val delta:Int)

    fun performanceTier(index: Double): String = when {
        index >= 115.0 -> "Excepcional"
        index >= 105.0 -> "Excelente"
        index >= 98.0 -> "Muito bom"
        index >= 92.0 -> "Bom"
        index >= 85.0 -> "Normal"
        index >= 75.0 -> "Abaixo do esperado"
        index >= 60.0 -> "Ruim"
        else -> "Muito ruim"
    }

    /**
     * Legacy display multiplier retained for compatibility with summary screens.
     * Actual progression now uses performanceEvolutionRate and the shared per-GP tick.
     * Performance below/above expectation slows/accelerates growth; the evolution
     * category independently limits annual gains per attribute.
     */
    fun performanceUtilization(index: Double): Double = when {
        index >= 115.0 -> 1.25
        index >= 105.0 -> 1.15
        index >= 98.0 -> 1.05
        index >= 92.0 -> 1.00
        index >= 85.0 -> 0.85
        index >= 75.0 -> 0.65
        index >= 60.0 -> 0.45
        else -> 0.30
    }

    /**
     * Per-GP performance is 40% qualifying + 60% race, measured against the
     * team-strength target. The previous target/actual ratio was too punitive near
     * the top of the grid: P2 against a P1 target scored 50. We now use a position
     * delta around a neutral 100, so one position off target is a small deviation.
     * Missing positions (<=0) are treated as neutral target performance; callers
     * should pass the target when a result record is absent.
     */
    fun gpPerformanceIndex(targetPosition:Int, qualifyingPosition:Int, racePosition:Int): Double {
        val target = targetPosition.coerceIn(1,80)
        val q = if (qualifyingPosition <= 0) target else qualifyingPosition.coerceIn(1,80)
        val r = if (racePosition <= 0) target else racePosition.coerceIn(1,80)
        val qualifyingScore = (100.0 + (target - q) * 5.0).coerceIn(25.0,150.0)
        val raceScore = (100.0 + (target - r) * 5.0).coerceIn(25.0,150.0)
        return (qualifyingScore * 0.40 + raceScore * 0.60).coerceIn(25.0,150.0)
    }

    /**
     * V649 phase tokens are performance states, not an age/career clock. The old
     * PEAK token is accepted as STABLE so existing saves never enter timed decline.
     */
    fun normalizePhase(phase: String?): String = when (phase) {
        "GROWING", "REGRESSION", "STABLE" -> phase
        "PEAK" -> "STABLE"
        else -> "GROWING"
    }

    /** A pilot starts developing only while there is meaningful room below potential. */
    fun initialPhase(driver: DriverDefinition): String {
        val current = DriverProfileCatalog.overall(driver.ratings())
        return if (driver.potentialOverall.coerceIn(current, 100) - current <= 1) "STABLE" else "GROWING"
    }

    /**
     * Signed, performance-driven development rate per completed GP. A neutral
     * weekend preserves most progress; repeated poor performances are required
     * before the negative fractional bank becomes an attribute loss.
     */
    fun performanceEvolutionRate(index: Double): Double = when {
        index >= 115.0 -> 1.30
        index >= 105.0 -> 1.00
        index >= 98.0 -> 0.50
        index >= 92.0 -> 0.20
        index >= 85.0 -> 0.0
        index >= 75.0 -> -0.20
        index >= 60.0 -> -0.45
        else -> -0.70
    }

    /**
     * Class is a soft threshold, not a hard progression wall. Good drivers may
     * exceed it, but every additional point becomes harder until two-season
     * sporting evidence earns a promotion.
     */
    fun classGrowthFactor(driverClass: String, currentOverall: Int): Double {
        val excess = (currentOverall - DriverProfileCatalog.ceiling(driverClass)).coerceAtLeast(0)
        return when {
            excess <= 0 -> 1.0
            excess <= 2 -> 0.65
            excess <= 4 -> 0.40
            excess <= 7 -> 0.25
            else -> 0.15
        }
    }

    data class TickResult(
        val driver: DriverDefinition,
        val bank: Double,
        val phase: String,
        val attributeDelta: Int
    )

    /** The one shared GP progression path used by career and Team Principal simulation. */
    fun applyPerformanceTick(
        driver: DriverDefinition,
        performanceIndex: Double,
        currentBank: Double,
        annualGains: IntArray,
        random: Random,
        facilityGrowthEfficiency: Double = 1.0
    ): TickResult {
        require(annualGains.size == 7) { "O controle anual precisa ter sete atributos" }
        val before = driver.ratings()
        val beforeOverall = DriverProfileCatalog.overall(before)
        val rate = performanceEvolutionRate(performanceIndex)
        val annualProfileBudget = DriverProfileCatalog.maxAnnualGain(driver.evolution) * 7.0 / 150.0
        var bank = currentBank

        when {
            rate > 0.0 && beforeOverall < driver.potentialOverall -> {
                val classFactor = classGrowthFactor(driver.driverClass, beforeOverall)
                bank += annualProfileBudget * rate * classFactor * facilityGrowthEfficiency.coerceIn(0.5, 1.6)
            }
            rate < 0.0 -> bank -= annualProfileBudget * -rate
            rate > 0.0 && beforeOverall >= driver.potentialOverall -> bank = 0.0
        }

        var updated = driver
        if (bank >= 1.0) {
            val requested = bank.toInt()
            updated = applyPositiveGain(
                driver, requested, annualGains, random,
                perAttributeCap = DriverProfileCatalog.maxAnnualGain(driver.evolution)
            )
            val applied = (updated.ratings().sum() - before.sum()).coerceAtLeast(0)
            // Preserve only a fractional remainder when annual attribute caps block
            // growth; it can resume after the seasonal allowance resets.
            bank = if (applied > 0) bank - applied else bank.coerceAtMost(0.99)
        } else if (bank <= -1.0) {
            val requested = (-bank).toInt()
            updated = applyRegression(driver, requested, random)
            val removed = (before.sum() - updated.ratings().sum()).coerceAtLeast(0)
            bank = if (removed > 0) bank + removed else 0.0
        }

        val afterOverall = DriverProfileCatalog.overall(updated.ratings())
        val nextPhase = when {
            afterOverall >= updated.potentialOverall -> "STABLE"
            rate < 0.0 -> "REGRESSION"
            rate >= 0.50 -> "GROWING"
            else -> "STABLE"
        }
        return TickResult(updated, bank.coerceIn(-0.99, 0.99), nextPhase, afterOverall - beforeOverall)
    }

    /**
     * Free-agent development has no qualifying/race evidence to score. Give it a
     * neutral full natural-growth reference, then scale only its positive growth
     * by FREE_DRIVER_GROWTH_RATE. Potential, class soft-ceiling and annual caps
     * are still enforced by the shared tick; no sporting-performance sample is made.
     */
    fun applyFreeDriverTick(
        driver: DriverDefinition,
        currentBank: Double,
        annualGains: IntArray,
        random: Random
    ): TickResult = applyPerformanceTick(
        driver = driver,
        performanceIndex = FREE_DRIVER_NEUTRAL_PERFORMANCE_INDEX,
        currentBank = currentBank,
        annualGains = annualGains,
        random = random,
        facilityGrowthEfficiency = FREE_DRIVER_GROWTH_RATE
    )

    fun minimumOverall(driverClass:String):Int = DriverProfileCatalog.minimumOverall(driverClass)

    /** Performance regression has a global safety floor; class changes follow two seasons. */
    @Suppress("UNUSED_PARAMETER")
    fun minimumOverall(driver:DriverDefinition):Int = 40

    @Suppress("UNUSED_PARAMETER")
    fun evaluate(driver:DriverDefinition, target:Target, input:PerformanceInput): Evaluation {
        val championship = ratio(target.championshipPosition.toDouble(), input.championshipPosition.toDouble())
        val expectedPoints = (((81-target.championshipPosition).coerceAtLeast(1)/80.0)*450.0)
        val points = ratio(expectedPoints,input.points.toDouble().coerceAtLeast(0.0),0.35)
        val race = ratio(target.championshipPosition.toDouble(),input.averageRacePosition.coerceAtLeast(1.0))
        val expectedWins = ((81-target.championshipPosition).coerceAtLeast(1)/80.0)*12.0
        val expectedPodiums = ((81-target.championshipPosition).coerceAtLeast(1)/80.0)*25.0
        val achievement=(ratio(expectedWins,input.wins.toDouble(),0.35)+ratio(expectedPodiums,input.podiums.toDouble(),0.35))/2.0
        val qualifying=ratio(target.championshipPosition.toDouble(),input.averageQualifyingPosition.coerceAtLeast(1.0))
        val teammate=if(input.teammateAveragePosition!=null&&input.teammateComparisons>0) ratio(input.teammateAveragePosition,input.averageRacePosition.coerceAtLeast(1.0)) else 100.0
        val index=championship*.30+points*.20+race*.15+achievement*.15+qualifying*.10+teammate*.10
        val tier=performanceTier(index); val multiplier=performanceUtilization(index)
        return Evaluation(index.coerceIn(0.0,150.0),tier,multiplier,0)
    }

    fun applyPositiveGain(driver:DriverDefinition,intendedGain:Int,annualGains:IntArray,random:Random,perAttributeCap:Int=DriverProfileCatalog.maxAnnualGain(driver.evolution)):DriverDefinition {
        if(intendedGain<=0)return driver; require(annualGains.size==7)
        val next=driver.ratings(); val potential=driver.potentialOverall.coerceIn(DriverProfileCatalog.overall(next),100)
        val targetSum=potential*7
        var remaining=intendedGain
        while(remaining>0 && next.sum()<targetSum){
            val eligible=(0..6).filter{next[it]<100&&annualGains[it]<perAttributeCap}
            if(eligible.isEmpty())break
            // Preserve the driver's natural profile while giving underdeveloped
            // attributes a modest balancing chance. The shared performance tick applies
            // the class soft threshold before this attribute allocation.
            val weights=eligible.map{ i ->
                val natural=driver.ratings()[i].toDouble(); val head=(100-next[i]).toDouble()
                0.35 + natural/100.0*0.65 + head/60.0*0.80
            }
            val total=weights.sum(); var pick=random.nextDouble()*total; var chosen=eligible.last()
            for(k in eligible.indices){ pick-=weights[k]; if(pick<=0){chosen=eligible[k];break} }
            next[chosen]++; annualGains[chosen]++; remaining--
        }
        return driver.withRatings(next)
    }

    fun applyRegression(driver:DriverDefinition,intendedLoss:Int,random:Random):DriverDefinition {
        if(intendedLoss<=0)return driver
        val next=driver.ratings()
        val floor=minimumOverall(driver)
        repeat(intendedLoss){
            // Career regression has a global safety floor of Overall 40. Class
            // eligibility is reviewed independently after two seasons of performance.
            if ((next.sum()-1) / 7 < floor) return@repeat
            val eligible=(0..6).filter{next[it]>40}
            if(eligible.isEmpty())return@repeat
            val excess=(next.sum()/7 - floor).coerceAtLeast(0).toDouble()
            val weights: List<Double> = eligible.map{ i ->
                0.35 + (next[i]-40)/60.0 + excess/50.0
            }
            val total=weights.sum(); var pick=random.nextDouble()*total; var chosen=eligible.last()
            for(k in eligible.indices){pick-=weights[k];if(pick<=0){chosen=eligible[k];break}}
            next[chosen]--
        }
        return driver.withRatings(next)
    }

    @Suppress("UNUSED_PARAMETER")
    fun recoveryCap(driver:DriverDefinition):Int=1
    fun applyDelta(driver:DriverDefinition,delta:Int):DriverDefinition=if(delta>0)applyPositiveGain(driver,delta,IntArray(7),Random.Default) else applyRegression(driver,-delta,Random.Default)
    private fun ratio(expected:Double,actual:Double,floor:Double=.50):Double{if(expected<=0)return 100.0;if(actual<=0)return 150.0;return(expected/actual*100.0).coerceIn(floor*100.0,150.0)}
    private fun DriverDefinition.ratings():IntArray=intArrayOf(speed,qualifying,overtaking,defense,consistency,wet,tyre)
    private fun DriverDefinition.withRatings(a:IntArray):DriverDefinition=copy(speed=a[0],qualifying=a[1],overtaking=a[2],defense=a[3],consistency=a[4],wet=a[5],tyre=a[6])
}
