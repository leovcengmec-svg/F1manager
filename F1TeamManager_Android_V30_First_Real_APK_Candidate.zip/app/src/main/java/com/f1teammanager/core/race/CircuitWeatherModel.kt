package com.f1teammanager.core.race

import java.text.Normalizer
import kotlin.random.Random

/**
 * V632: circuit-aware weather probability model. A weekend no longer starts dry
 * by default everywhere, but wet conditions are uncommon on arid venues and more
 * likely on variable/wet venues. All weather RNG is isolated from race-performance,
 * incidents and driver-evolution RNG streams.
 */
data class CircuitWeatherProfile(
    val qualifyingRainStartChance: Double,
    val raceRainStartChance: Double,
    val cloudyStartChance: Double,
    val qualifyingTransitionChance: Double,
    val raceTransitionChance: Double
) {
    init {
        require(qualifyingRainStartChance in 0.0..1.0)
        require(raceRainStartChance in 0.0..1.0)
        require(cloudyStartChance in 0.0..1.0)
        require(qualifyingTransitionChance in 0.0..1.0)
        require(raceTransitionChance in 0.0..1.0)
        require(qualifyingRainStartChance + cloudyStartChance <= 1.0)
        require(raceRainStartChance + cloudyStartChance <= 1.0)
    }
}

object CircuitWeatherModel {
    private val arid = CircuitWeatherProfile(
        qualifyingRainStartChance = 0.010,
        raceRainStartChance = 0.020,
        cloudyStartChance = 0.10,
        qualifyingTransitionChance = 0.020,
        raceTransitionChance = 0.012
    )
    private val dry = CircuitWeatherProfile(
        qualifyingRainStartChance = 0.020,
        raceRainStartChance = 0.040,
        cloudyStartChance = 0.12,
        qualifyingTransitionChance = 0.030,
        raceTransitionChance = 0.018
    )
    private val standard = CircuitWeatherProfile(
        qualifyingRainStartChance = 0.040,
        raceRainStartChance = 0.075,
        cloudyStartChance = 0.16,
        qualifyingTransitionChance = 0.040,
        raceTransitionChance = 0.025
    )
    private val variable = CircuitWeatherProfile(
        qualifyingRainStartChance = 0.080,
        raceRainStartChance = 0.120,
        cloudyStartChance = 0.19,
        qualifyingTransitionChance = 0.050,
        raceTransitionChance = 0.030
    )
    private val wet = CircuitWeatherProfile(
        qualifyingRainStartChance = 0.130,
        raceRainStartChance = 0.200,
        cloudyStartChance = 0.22,
        qualifyingTransitionChance = 0.060,
        raceTransitionChance = 0.040
    )

    /**
     * A weather front should be temporary, not lock a whole Grand Prix into rain.
     * At the six-lap checkpoint, a wet track has a much higher chance of moving
     * toward cloudy conditions. The hard cap also prevents an unlucky RNG streak
     * from keeping one continuous rain spell beyond 18 laps.
     */
    const val MAX_CONTINUOUS_RAIN_LAPS = 18
    private const val RAIN_CLEAR_TRANSITION_CHANCE = 0.52

    /** Resolve a profile from the canonical circuit label used by the 50-GP calendar. */
    fun profileForCircuit(circuitName: String): CircuitWeatherProfile {
        val name = normalize(circuitName)
        return when {
            containsAny(name, "sakhir", "bahrain", "jeddah", "yas marina", "lusail", "las vegas", "dubai autodrome", "buddh") -> arid
            containsAny(name, "spa-francorchamps", "spa francorchamps", "silverstone", "suzuka", "interlagos", "sepang", "portimao", "fuji speedway", "assen", "watkins glen", "gilles-villeneuve", "nurburgring", "nurburgring gp") -> wet
            containsAny(name, "albert park", "shanghai", "miami", "monte carlo", "monaco", "zandvoort", "marina bay", "singapore", "cota", "circuit of the americas", "istanbul", "korea international", "sochi", "kyalami", "red bull ring", "hungaroring", "magny-cours", "magny cours", "hockenheimring", "motorland aragon", "motorland aragon", "jacarepagua", "jacarepagua", "and erstorp", "anderstorp", "estoril") -> variable
            containsAny(name, "monza", "barcelona", "madring", "madrid", "mugello", "jerez", "vallelunga", "long beach", "indianapolis", "hermanos rodriguez", "mexico", "paul ricard") -> dry
            else -> standard
        }
    }

    fun profileForCircuit(circuit: RaceCircuit): CircuitWeatherProfile = profileForCircuit(circuit.name)

    fun qualifyingStartWeather(circuit: RaceCircuit, random: Random): Weather {
        val profile = profileForCircuit(circuit)
        return rollStartWeather(profile, profile.qualifyingRainStartChance, random)
    }

    fun raceStartWeather(circuit: RaceCircuit, random: Random): Weather {
        val profile = profileForCircuit(circuit)
        return rollStartWeather(profile, profile.raceRainStartChance, random)
    }

    private fun rollStartWeather(profile: CircuitWeatherProfile, rainChance: Double, random: Random): Weather {
        val draw = random.nextDouble()
        return when {
            draw < rainChance -> {
                val intensity = random.nextDouble()
                when {
                    intensity < 0.05 -> Weather.HEAVY_RAIN
                    intensity < 0.30 -> Weather.MEDIUM_RAIN
                    else -> Weather.LIGHT_RAIN
                }
            }
            draw < rainChance + profile.cloudyStartChance -> Weather.CLOUDY
            else -> Weather.DRY
        }
    }

    /** One transition attempt at a five-minute qualifying checkpoint. */
    fun nextQualifyingWeather(current: Weather, random: Random): Weather = when (current) {
        Weather.DRY -> if (random.nextDouble() < 0.22) Weather.LIGHT_RAIN else Weather.CLOUDY
        Weather.CLOUDY -> if (random.nextDouble() < 0.54) Weather.LIGHT_RAIN else Weather.DRY
        Weather.LIGHT_RAIN -> if (random.nextDouble() < 0.36) Weather.MEDIUM_RAIN else Weather.CLOUDY
        Weather.MEDIUM_RAIN -> {
            val draw = random.nextDouble()
            when {
                draw < 0.16 -> Weather.HEAVY_RAIN
                draw < 0.76 -> Weather.LIGHT_RAIN
                else -> Weather.CLOUDY
            }
        }
        Weather.HEAVY_RAIN -> Weather.MEDIUM_RAIN
    }

    /** True for weather states that require wet-weather tyres. */
    fun isRain(weather: Weather): Boolean = weather in setOf(
        Weather.LIGHT_RAIN, Weather.MEDIUM_RAIN, Weather.HEAVY_RAIN
    )

    /**
     * Race weather is checked every six laps. Dry/cloudy fronts remain uncommon,
     * while an active rain spell gets a realistic opportunity to clear. Once the
     * same wet spell reaches 18 laps, clearing is mandatory.
     */
    fun shouldTransitionDuringRace(
        current: Weather,
        profile: CircuitWeatherProfile,
        random: Random,
        continuousRainLaps: Int = 0
    ): Boolean = if (isRain(current)) {
        continuousRainLaps >= MAX_CONTINUOUS_RAIN_LAPS || random.nextDouble() < RAIN_CLEAR_TRANSITION_CHANCE
    } else {
        random.nextDouble() < profile.raceTransitionChance
    }

    /** Progresses rain toward cloudy/dry conditions; no direct dry-to-rain jump. */
    fun nextRaceWeather(
        current: Weather,
        random: Random,
        continuousRainLaps: Int = 0
    ): Weather {
        if (isRain(current) && continuousRainLaps >= MAX_CONTINUOUS_RAIN_LAPS) return Weather.CLOUDY
        return when (current) {
            Weather.DRY -> Weather.CLOUDY
            Weather.CLOUDY -> if (random.nextDouble() < 0.24) Weather.LIGHT_RAIN else Weather.DRY
            Weather.LIGHT_RAIN -> if (random.nextDouble() < 0.15) Weather.MEDIUM_RAIN else Weather.CLOUDY
            Weather.MEDIUM_RAIN -> {
                val draw = random.nextDouble()
                when {
                    draw < 0.05 -> Weather.HEAVY_RAIN
                    draw < 0.35 -> Weather.LIGHT_RAIN
                    else -> Weather.CLOUDY
                }
            }
            Weather.HEAVY_RAIN -> if (random.nextDouble() < 0.65) Weather.MEDIUM_RAIN else Weather.LIGHT_RAIN
        }
    }

    private fun normalize(value: String): String = Normalizer.normalize(value.lowercase(), Normalizer.Form.NFD)
        .replace(Regex("\\p{Mn}+"), "")
        .replace('–', '-')
        .trim()

    private fun containsAny(value: String, vararg needles: String): Boolean = needles.any { value.contains(it) }
}
