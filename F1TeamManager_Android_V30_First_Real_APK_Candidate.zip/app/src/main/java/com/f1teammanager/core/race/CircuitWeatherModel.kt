package com.f1teammanager.core.race

import java.text.Normalizer
import kotlin.random.Random

/**
 * V632: circuit-aware weather probability model. A weekend no longer starts dry
 * by default everywhere, but wet conditions are uncommon on arid venues and more
 * likely on variable/wet venues. All weather RNG is isolated from race-performance,
 * incidents and driver-evolution RNG streams.
 */
data class CircuitWeatherProfile(
    val qualifyingRainStartChance: Double,
    val raceRainStartChance: Double,
    val cloudyStartChance: Double,
    val qualifyingTransitionChance: Double,
    val raceTransitionChance: Double
) {
    init {
        require(qualifyingRainStartChance in 0.0..1.0)
        require(raceRainStartChance in 0.0..1.0)
        require(cloudyStartChance in 0.0..1.0)
        require(qualifyingTransitionChance in 0.0..1.0)
        require(raceTransitionChance in 0.0..1.0)
        require(qualifyingRainStartChance + cloudyStartChance <= 1.0)
        require(raceRainStartChance + cloudyStartChance <= 1.0)
    }
}

object CircuitWeatherModel {
    private val arid = CircuitWeatherProfile(
        qualifyingRainStartChance = 0.015,
        raceRainStartChance = 0.025,
        cloudyStartChance = 0.13,
        qualifyingTransitionChance = 0.022,
        raceTransitionChance = 0.010
    )
    private val dry = CircuitWeatherProfile(
        qualifyingRainStartChance = 0.028,
        raceRainStartChance = 0.050,
        cloudyStartChance = 0.17,
        qualifyingTransitionChance = 0.030,
        raceTransitionChance = 0.013
    )
    private val standard = CircuitWeatherProfile(
        qualifyingRainStartChance = 0.060,
        raceRainStartChance = 0.105,
        cloudyStartChance = 0.21,
        qualifyingTransitionChance = 0.042,
        raceTransitionChance = 0.018
    )
    private val variable = CircuitWeatherProfile(
        qualifyingRainStartChance = 0.115,
        raceRainStartChance = 0.190,
        cloudyStartChance = 0.25,
        qualifyingTransitionChance = 0.058,
        raceTransitionChance = 0.026
    )
    private val wet = CircuitWeatherProfile(
        qualifyingRainStartChance = 0.180,
        raceRainStartChance = 0.290,
        cloudyStartChance = 0.27,
        qualifyingTransitionChance = 0.075,
        raceTransitionChance = 0.034
    )

    /** Resolve a profile from the canonical circuit label used by the 50-GP calendar. */
    fun profileForCircuit(circuitName: String): CircuitWeatherProfile {
        val name = normalize(circuitName)
        return when {
            containsAny(name, "sakhir", "bahrain", "jeddah", "yas marina", "lusail", "las vegas", "dubai autodrome", "buddh") -> arid
            containsAny(name, "spa-francorchamps", "spa francorchamps", "silverstone", "suzuka", "interlagos", "sepang", "portimao", "fuji speedway", "assen", "watkins glen", "gilles-villeneuve", "nurburgring", "nurburgring gp") -> wet
            containsAny(name, "albert park", "shanghai", "miami", "monte carlo", "monaco", "zandvoort", "marina bay", "singapore", "cota", "circuit of the americas", "istanbul", "korea international", "sochi", "kyalami", "red bull ring", "hungaroring", "magny-cours", "magny cours", "hockenheimring", "motorland aragon", "motorland aragon", "jacarepagua", "jacarepagua", "and erstorp", "anderstorp", "estoril") -> variable
            containsAny(name, "monza", "barcelona", "madring", "madrid", "mugello", "jerez", "vallelunga", "long beach", "indianapolis", "hermanos rodriguez", "mexico", "paul ricard") -> dry
            else -> standard
        }
    }

    fun profileForCircuit(circuit: RaceCircuit): CircuitWeatherProfile = profileForCircuit(circuit.name)

    fun qualifyingStartWeather(circuit: RaceCircuit, random: Random): Weather {
        val profile = profileForCircuit(circuit)
        return rollStartWeather(profile, profile.qualifyingRainStartChance, random)
    }

    fun raceStartWeather(circuit: RaceCircuit, random: Random): Weather {
        val profile = profileForCircuit(circuit)
        return rollStartWeather(profile, profile.raceRainStartChance, random)
    }

    private fun rollStartWeather(profile: CircuitWeatherProfile, rainChance: Double, random: Random): Weather {
        val draw = random.nextDouble()
        return when {
            draw < rainChance -> {
                val intensity = random.nextDouble()
                when {
                    intensity < 0.05 -> Weather.HEAVY_RAIN
                    intensity < 0.30 -> Weather.MEDIUM_RAIN
                    else -> Weather.LIGHT_RAIN
                }
            }
            draw < rainChance + profile.cloudyStartChance -> Weather.CLOUDY
            else -> Weather.DRY
        }
    }

    /** One transition attempt at a five-minute qualifying checkpoint. */
    fun nextQualifyingWeather(current: Weather, random: Random): Weather = when (current) {
        Weather.DRY -> if (random.nextDouble() < 0.22) Weather.LIGHT_RAIN else Weather.CLOUDY
        Weather.CLOUDY -> if (random.nextDouble() < 0.54) Weather.LIGHT_RAIN else Weather.DRY
        Weather.LIGHT_RAIN -> if (random.nextDouble() < 0.36) Weather.MEDIUM_RAIN else Weather.CLOUDY
        Weather.MEDIUM_RAIN -> {
            val draw = random.nextDouble()
            when {
                draw < 0.16 -> Weather.HEAVY_RAIN
                draw < 0.76 -> Weather.LIGHT_RAIN
                else -> Weather.CLOUDY
            }
        }
        Weather.HEAVY_RAIN -> Weather.MEDIUM_RAIN
    }

    /** One transition attempt every six race laps; no direct dry-to-heavy-rain jump. */
    fun nextRaceWeather(current: Weather, random: Random): Weather = when (current) {
        Weather.DRY -> Weather.CLOUDY
        Weather.CLOUDY -> if (random.nextDouble() < 0.32) Weather.LIGHT_RAIN else Weather.DRY
        Weather.LIGHT_RAIN -> if (random.nextDouble() < 0.30) Weather.MEDIUM_RAIN else Weather.CLOUDY
        Weather.MEDIUM_RAIN -> {
            val draw = random.nextDouble()
            when {
                draw < 0.12 -> Weather.HEAVY_RAIN
                draw < 0.68 -> Weather.LIGHT_RAIN
                else -> Weather.CLOUDY
            }
        }
        Weather.HEAVY_RAIN -> if (random.nextDouble() < 0.72) Weather.MEDIUM_RAIN else Weather.LIGHT_RAIN
    }

    private fun normalize(value: String): String = Normalizer.normalize(value.lowercase(), Normalizer.Form.NFD)
        .replace(Regex("\\p{Mn}+"), "")
        .replace('–', '-')
        .trim()

    private fun containsAny(value: String, vararg needles: String): Boolean = needles.any { value.contains(it) }
}
