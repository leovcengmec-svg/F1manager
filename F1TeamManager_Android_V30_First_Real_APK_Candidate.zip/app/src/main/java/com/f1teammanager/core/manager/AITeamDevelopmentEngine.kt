package com.f1teammanager.core.manager

import com.f1teammanager.core.season.TeamDefinition
import kotlin.math.roundToInt

/**
 * Deterministic AI development using the same conceptual chain as the player:
 * P&D -> design -> factory -> physical pieces -> installation on Car 1/Car 2.
 * The legacy TeamCarState remains only as a compatibility/financial bridge.
 */
class AITeamDevelopmentEngine(private val seed:Int = 20261005, private val regulationSeed:Int = seed) {
    data class DevelopmentEvent(
        val week: Int,
        val type: Type,
        val component: CarComponent,
        val version: Int,
        val performance: Int,
        val reliability: Int,
        val target: GarageCarId? = null,
        val beforeOverall: Int? = null,
        val afterOverall: Int? = null,
        val pieceId: String? = null
    ) {
        enum class Type { DESIGN_COMPLETED, FACTORY_COMPLETED, PIECE_INSTALLED }
    }

    data class SimulatedState(
        val car:TeamCarState,
        val budget:Long,
        val garage:TeamGarage? = null,
        val facilities:TeamFacilitiesState = TeamFacilitiesState(),
        val events: List<DevelopmentEvent> = emptyList()
    )

    private val development = CarDevelopmentEngine()

    /**
     * The official starting car is defined by InitialTeamProfile (Forte/Médio/Fraco).
     * InitialTeamProfile is the single official starting-team strength source.
     */
    private fun initialCarStrength(team: TeamDefinition): Int =
        InitialTeamProfile.values(team).overall

    fun simulateFinancial(team:TeamDefinition, elapsedWeeks:Int, season:Int): SimulatedState =
        simulateFinancial(team, elapsedWeeks, season, InitialTeamProfile.initialBudget(team))

    /**
     * Simulates the AI technical pipeline against a caller-provided real cash
     * capacity. The caller must pass current cash + already-spent AI development
     * in this season. This preserves cumulative development spending while making
     * the pipeline unable to spend money that the team does not actually have.
     */
    fun simulateFinancial(team:TeamDefinition, elapsedWeeks:Int, season:Int, startingBudget:Long, startingFacilities:TeamFacilitiesState? = null, nextSeasonInvestments: Map<Int, Long> = emptyMap()): SimulatedState {
        val weeks = elapsedWeeks.coerceAtLeast(0)
        var legacy = initialCar(team)
        var budget = startingBudget.coerceAtLeast(0L)
        var garage = TeamGarageFactory.fromInitial(team)
        // Historical replay must start from the team's canonical baseline. The optional
        // startingFacilities argument is the authoritative persisted state for the target
        // season; seeding the historical loop with it causes replayed prior seasons to
        // overwrite upgrades (including annual-event upgrades) made in the live career.
        var facilities = FacilityEngine.initial(team.initialLevel)
        if (season < 2026) return SimulatedState(legacy, budget, garage, startingFacilities ?: facilities)

        // Preserve the established season-to-season chain: the completed physical
        // garage of season N is the input for season N+1. The old TeamCarState is
        // derived only as a compatibility/financial summary.
        for (s in 2026 until season) {
            val full = simulatePhysicalSeason(team, garage, 56, s, budget, seedOffset = s * 101, facilities = facilities)
            garage = full.garage
            facilities = full.facilities
            legacy = legacyFromGarage(garage).normalized()
            val nextCarInvestment = nextSeasonInvestments[s] ?: 0L
            val carriedLegacy = development.carryAiCarToNextSeason(legacy, s + 1, nextCarInvestment)
            garage = carryAiGarageToNextSeason(garage, s + 1, team.id, nextCarInvestment, legacy.developmentKnowledge)
            // Every AI team receives the same championship rule as the player, after
            // its next-season car is built and before the new season is simulated.
            val rule = AnnualCarRegulationEngine.generateForCalendarYear(s + 1, regulationSeed)
            val teamRegulationSeed = team.id.hashCode()
            garage = AnnualCarRegulationEngine.applyToGarage(garage, rule, teamRegulationSeed)
            legacy = AnnualCarRegulationEngine.applyToCar(carriedLegacy, rule, teamRegulationSeed).let { regulated ->
                legacyFromGarage(garage).copy(
                    aerodynamics = regulated.aerodynamics,
                    chassis = regulated.chassis,
                    engine = regulated.engine,
                    reliability = regulated.reliability
                ).normalized()
            }
            budget = InitialTeamProfile.initialBudget(team)
            if (FinancialSeasonClosureEngine.aiPenaltyActive(team.id, s + 1)) {
                legacy = FinancialSeasonClosureEngine.applyCarPenalty(legacy, -1L).car
                garage = applyGaragePenalty(garage, -1)
            }
        }
        // Reconstructed car/garage history feeds the next-season car chain, but it must
        // never replace live facility levels supplied by the career's persistent ledger.
        if (startingFacilities != null) facilities = startingFacilities
        val current = simulatePhysicalSeason(team, garage, weeks, season, budget, seedOffset = season * 101, facilities = facilities)
        garage = current.garage
        facilities = current.facilities
        legacy = if (weeks == 0 && season > 2026) legacy
                 else legacyFromGarage(garage).normalized()
        return SimulatedState(legacy, current.budget, garage, facilities, current.events)
    }

    fun simulate(team:TeamDefinition, elapsedWeeks:Int, season:Int): TeamCarState = simulateFinancial(team, elapsedWeeks, season).car

    fun simulateGarage(team:TeamDefinition, elapsedWeeks:Int, season:Int): TeamGarage =
        simulateFinancial(team, elapsedWeeks, season).garage ?: TeamGarageFactory.fromInitial(team)


    /**
     * Replays an AI season from the physical car left by a departing Team Principal.
     * This prevents a team from snapping back to its original starter car after a hire.
     */
    fun simulateFinancialFromHandoff(
        team: TeamDefinition,
        elapsedWeeks: Int,
        season: Int,
        handoff: TeamPrincipalTeamHandoff,
        startingBudget: Long,
        startingFacilities: TeamFacilitiesState? = null,
        nextSeasonInvestments: Map<Int, Long> = emptyMap()
    ): SimulatedState {
        require(handoff.teamId == team.id) { "O checkpoint Team Principal pertence a outra equipe." }
        require(season > handoff.closingSeason) { "O checkpoint precisa ser anterior à temporada simulada." }
        val firstNextSeason = handoff.closingSeason + 1
        var garage = carryAiGarageToNextSeason(
            handoff.garage, firstNextSeason, team.id, handoff.nextSeasonInvestment,
            handoff.technicalKnowledge
        )
        var facilities = handoff.facilities
        var currentSeason = firstNextSeason
        fun applyRegulation(targetSeason: Int, source: TeamGarage): TeamGarage {
            val rule = AnnualCarRegulationEngine.generateForCalendarYear(targetSeason, regulationSeed)
            var regulated = AnnualCarRegulationEngine.applyToGarage(source, rule, team.id.hashCode())
            if (FinancialSeasonClosureEngine.aiPenaltyActive(team.id, targetSeason)) {
                regulated = applyGaragePenalty(regulated, -1)
            }
            return regulated
        }
        garage = applyRegulation(firstNextSeason, garage)

        // Seasons between the checkpoint and the requested season are deterministic
        // full-year replays; the requested season itself uses its live week and cash capacity.
        while (currentSeason < season) {
            val historical = simulatePhysicalSeason(
                team, garage, 56, currentSeason, InitialTeamProfile.initialBudget(team),
                seedOffset = currentSeason * 101, facilities = facilities
            )
            garage = historical.garage
            facilities = historical.facilities
            val next = currentSeason + 1
            garage = carryAiGarageToNextSeason(
                garage, next, team.id, nextSeasonInvestments[currentSeason] ?: 0L,
                handoff.technicalKnowledge
            )
            garage = applyRegulation(next, garage)
            currentSeason = next
        }
        val current = simulatePhysicalSeason(
            team, garage, elapsedWeeks.coerceAtLeast(0), season, startingBudget.coerceAtLeast(0L),
            seedOffset = season * 101, facilities = startingFacilities ?: facilities
        )
        val car = legacyFromGarage(current.garage).copy(
            nextSeasonInvestment = nextSeasonInvestments[season] ?: 0L,
            nextSeasonFocus = CarDevelopmentFocus.BALANCED,
            developmentKnowledge = handoff.technicalKnowledge
        ).normalized()
        return SimulatedState(car, current.budget, current.garage, current.facilities, current.events)
    }

    private data class AiPhysicalState(
        val garage:TeamGarage,
        val budget:Long,
        val facilities:TeamFacilitiesState,
        val events: List<DevelopmentEvent> = emptyList()
    )

    private fun simulatePhysicalSeason(team:TeamDefinition, initial:TeamGarage, elapsedWeeks:Int, season:Int, startingBudget:Long, seedOffset:Int, facilities:TeamFacilitiesState): AiPhysicalState {
        var state = AiPhysicalState(initial, startingBudget, facilities)
        var researchComponent:CarComponent? = null
        var researchRemaining = 0
        var researchPerformance = 0
        var researchReliability = 50
        var researchVersion = 1

        // AI must obey the same per-component research/version rules as the player.
        // The old implementation used one global version counter, which could make
        // a first Chassi upgrade appear as V4 simply because three other components
        // had been researched before it. It also had no component cooldown, allowing
        // the same component to be researched again as soon as the pipeline freed.
        val componentVersions = CarComponent.values().associateWith { component ->
            maxOf(
                initial.car1.installedPieceVersions[component] ?: 0,
                initial.car2.installedPieceVersions[component] ?: 0
            )
        }.toMutableMap()
        val cooldownUntil = mutableMapOf<CarComponent, Int>()
        var factoryComponent:CarComponent? = null
        var factoryRemaining = 0
        var factoryPerformance = 0
        var factoryReliability = 100
        var factoryQuantity = 0
        var factoryOrderId = ""
        var technicalSpent = 0L
        val ranking = TechnicalInvestmentEngine.seasonRanking()[team.id] ?: 40
        val technicalCap = TechnicalInvestmentEngine.capForRank(ranking)
        var plannedFactoryCost = 0L

        for (week in 1..elapsedWeeks) {
            // Research completion creates a design, never a direct car change.
            if (researchComponent != null) {
                if (researchRemaining > 1) {
                    researchRemaining--
                } else {
                    val plannedQuantity = if (initialCarStrength(team) >= 58 && Math.floorMod(seed + seedOffset + team.id + week, 100) < 60) 2 else 1
                    val plannedDesign = ResearchDesign(
                        "AI-${team.id}-${season}-${week}",
                        researchComponent!!,
                        researchVersion,
                        researchPerformance,
                        researchReliability,
                        season,
                        week
                    )
                    val factoryUnitCost = FactoryEngine().manufacturingCost(plannedDesign, facilities, ranking)
                    plannedFactoryCost = factoryUnitCost * plannedQuantity
                    if (technicalSpent + plannedFactoryCost <= technicalCap && state.budget >= plannedFactoryCost) {
                        state = state.copy(budget = FinanceEngine().cashDebitBalance(state.budget, plannedFactoryCost))
                        technicalSpent += plannedFactoryCost
                    } else {
                        // The design remains valid, but the AI cannot open a fabrication
                        // order beyond the same annual technical ceiling as the player.
                        researchComponent = null
                        researchRemaining = 0
                        plannedFactoryCost = 0L
                        continue
                    }
                    factoryComponent = researchComponent
                    // Keep a real temporal gap: the design is completed first, then
                    // the physical manufacturing completes in a later week.
                    factoryRemaining = maxOf(2, FacilityEngine.factoryWeeks(if (initialCarStrength(team) >= 56) 1 else 2, facilities))
                    // The new version becomes the installed technology only after a
                    // successful design. Failed research does not consume a version.
                    componentVersions[researchComponent!!] = researchVersion
                    cooldownUntil[researchComponent!!] = week + 4
                    state = state.copy(events = state.events + DevelopmentEvent(
                        week = week,
                        type = DevelopmentEvent.Type.DESIGN_COMPLETED,
                        component = researchComponent!!,
                        version = researchVersion,
                        performance = researchPerformance,
                        reliability = researchReliability
                    ))
                    factoryPerformance = researchPerformance
                    factoryReliability = researchReliability
                    factoryQuantity = plannedQuantity
                    factoryOrderId = "AI-F-${season}-${week}-${team.id}-${researchComponent!!.name}-V${researchVersion}"
                    researchComponent = null
                    researchRemaining = 0
                }
            }

            // Factory completion immediately installs the physical piece: there is
            // deliberately no intermediate inventory/stock state.
            if (factoryComponent != null) {
                if (factoryRemaining > 1) {
                    factoryRemaining--
                } else {
                    repeat(factoryQuantity) { n ->
                        val piece = CarPiece("$factoryOrderId-U${n + 1}", factoryComponent!!, researchVersion, factoryPerformance, factoryReliability, week)
                        val target = targetCar(team, piece, week, season, seedOffset)
                        val beforeOverall = state.garage.teamAverageOverall
                        val installedGarage = state.garage.install(piece, target)
                        val afterOverall = installedGarage.teamAverageOverall
                        state = state.copy(
                            garage = installedGarage,
                            events = state.events + DevelopmentEvent(
                                week = week,
                                type = DevelopmentEvent.Type.FACTORY_COMPLETED,
                                component = piece.component,
                                version = piece.version,
                                performance = piece.performance,
                                reliability = piece.reliability,
                                target = target,
                                beforeOverall = beforeOverall,
                                afterOverall = afterOverall,
                                pieceId = piece.pieceId
                            ) + DevelopmentEvent(
                                week = week,
                                type = DevelopmentEvent.Type.PIECE_INSTALLED,
                                component = piece.component,
                                version = piece.version,
                                performance = piece.performance,
                                reliability = piece.reliability,
                                target = target,
                                beforeOverall = beforeOverall,
                                afterOverall = afterOverall,
                                pieceId = piece.pieceId
                            )
                        )
                    }
                    factoryComponent = null
                    factoryRemaining = 0
                    factoryQuantity = 0
                }
            }

            // One research project at a time, started only when the pipeline is free.
            // A component also has the same four-week post-completion cooldown used
            // by the player's ResearchEngine. This prevents the AI from spamming the
            // same technology every time the factory becomes available.
            if (researchComponent == null && factoryComponent == null) {
                val eligibleComponents = CarComponent.values().filter {
                    week >= (cooldownUntil[it] ?: 0)
                }
                if (eligibleComponents.isEmpty()) continue
                val component = chooseComponent(team, state.garage, season, week, seedOffset, eligibleComponents)
                // IA chooses the same P&D inputs available to the player:
                // complexity, focus, component and investment. The mechanics below
                // are the ResearchEngine mechanics, not a separate AI formula.
                val research = ResearchEngine()
                val complexity = chooseResearchComplexity(team, state.budget)
                val researchLevel = facilities.level(FacilityType.RESEARCH)
                val duration = research.calculatedWeeks(researchLevel, complexity)
                // Apply the same ranking discount as the player's ResearchEngine options.
                // Ranking 1-10: 0%; 11-20: 20%; 21-30: 40%; 31-40: 60%.
                val cost = research.adjustedCost(research.baseCost(complexity), ranking)
                val maxRange = research.maxImprovement(researchLevel)
                val baseGain = if (maxRange.first == maxRange.last) maxRange.first
                               else maxRange.first + Math.floorMod(seed + seedOffset + team.id * 13 + week * 17, maxRange.last - maxRange.first + 1)
                val bonusRange = research.complexityBonus(complexity)
                val bonusGain = if (bonusRange.first == bonusRange.last) bonusRange.first
                                else bonusRange.first + Math.floorMod(seed + seedOffset + team.id * 19 + week * 23, bonusRange.last - bonusRange.first + 1)
                val totalGain = baseGain + bonusGain
                val outcomeRoll = Math.floorMod(seed + seedOffset + team.id * 29 + week * 31, 100)
                val failure = research.failureChance(researchLevel, complexity)
                val partial = when (complexity) {
                    ResearchComplexity.SIMPLE -> 10
                    ResearchComplexity.MEDIUM -> 15
                    ResearchComplexity.ADVANCED -> 20
                    ResearchComplexity.EXPERIMENTAL -> 25
                }.let { (it - researchLevel).coerceAtLeast(5) }
                val outcome = when {
                    outcomeRoll < failure -> ResearchOutcome.FAILURE
                    outcomeRoll < failure + partial -> ResearchOutcome.PARTIAL
                    else -> ResearchOutcome.SUCCESS
                }
                val effectiveGain = when (outcome) {
                    ResearchOutcome.SUCCESS -> totalGain
                    ResearchOutcome.PARTIAL -> (totalGain * 0.5).roundToInt()
                    ResearchOutcome.FAILURE -> 0
                }
                val focus = chooseResearchFocus(state.garage, component)
                val (performanceGain, reliabilityGain) = research.splitGain(effectiveGain, focus)
                val basePerformance = maxOf(
                    state.garage.car1.componentValue(component),
                    state.garage.car2.componentValue(component)
                )
                val baseReliability = maxOf(
                    state.garage.car1.componentReliability(component),
                    state.garage.car2.componentReliability(component)
                )
                val plannedReliability = (baseReliability + reliabilityGain).coerceAtMost(100)
                val plannedPerformance = (basePerformance + performanceGain).coerceAtMost(100)
                val nextVersion = (componentVersions[component] ?: 0) + 1
                val plannedQuantity = if (initialCarStrength(team) >= 58 && Math.floorMod(seed + seedOffset + team.id + week, 100) < 60) 2 else 1
                val estimatedDesign = ResearchDesign("AI-PREVIEW-${team.id}-${season}-${week}", component, nextVersion, plannedPerformance, plannedReliability, season, week)
                val estimatedFactory = FactoryEngine().manufacturingCost(estimatedDesign, facilities, ranking) * plannedQuantity
                if (technicalSpent + cost + estimatedFactory <= technicalCap && state.budget >= cost + estimatedFactory) {
                    researchComponent = component
                    researchRemaining = duration
                    researchPerformance = plannedPerformance
                    researchReliability = plannedReliability
                    researchVersion = nextVersion
                    state = state.copy(budget = FinanceEngine().cashDebitBalance(state.budget, cost))
                    technicalSpent += cost
                }
            }
        }
        return state
    }

    private fun carryAiGarageToNextSeason(
        garage: TeamGarage,
        nextSeason: Int,
        teamId: Int,
        invested: Long = 0L,
        technicalKnowledge: Map<CarComponent, Int> = emptyMap()
    ): TeamGarage {
        val investmentSteps = development.nextSeasonInvestmentSteps(garage.teamAverageOverall, invested)
        // AI and player call the same canonical physical-component rollover rule.
        // AI currently uses the balanced focus, just as its investment policy specifies.
        fun carry(car: PhysicalCar, v:Int, component: CarComponent):Int =
            development.nextSeasonPhysicalComponentValue(
                previousValue = v,
                installed = component in car.installedPieces,
                investmentSteps = investmentSteps,
                focus = CarDevelopmentFocus.BALANCED,
                component = component,
                technicalKnowledge = technicalKnowledge[component] ?: 0
            )
        fun carryReliability(v:Int):Int = (v + investmentSteps / 2).coerceIn(1,100)
        fun carryCar(car:PhysicalCar):PhysicalCar {
            val reliabilities = CarComponent.values().associateWith { c -> carryReliability(car.componentReliability(c)) }
            return PhysicalCar(
                id = car.id,
                engine = carry(car, car.engine, CarComponent.ENGINE),
                chassis = carry(car, car.chassis, CarComponent.CHASSIS),
                frontWing = carry(car, car.frontWing, CarComponent.FRONT_WING),
                rearWing = carry(car, car.rearWing, CarComponent.REAR_WING),
                brakes = carry(car, car.brakes, CarComponent.BRAKES),
                electricPowerUnit = carry(car, car.electricPowerUnit, CarComponent.ELECTRIC_POWER_UNIT),
                reliability = reliabilities.values.average().roundToInt().coerceIn(1,100),
                componentReliabilities = reliabilities,
                installedPieces = car.installedPieces,
                installedPieceVersions = car.installedPieceVersions
            )
        }
        return TeamGarage(carryCar(garage.car1), carryCar(garage.car2))
    }

    private fun chooseResearchFocus(garage:TeamGarage, component:CarComponent):ResearchFocus {
        val performance = maxOf(garage.car1.componentValue(component), garage.car2.componentValue(component))
        val reliability = maxOf(garage.car1.componentReliability(component), garage.car2.componentReliability(component))
        return when {
            reliability <= performance - 10 -> ResearchFocus.RELIABILITY
            performance <= reliability - 10 -> ResearchFocus.PERFORMANCE
            reliability < 70 -> ResearchFocus.RELIABILITY
            else -> ResearchFocus.PERFORMANCE
        }
    }

    private fun chooseResearchComplexity(team:TeamDefinition, budget:Long):ResearchComplexity {
        val strength = initialCarStrength(team)
        return when {
            budget >= 120_000_000L && strength >= 58 -> ResearchComplexity.ADVANCED
            budget >= 40_000_000L -> ResearchComplexity.MEDIUM
            else -> ResearchComplexity.SIMPLE
        }
    }

    private fun chooseComponent(team:TeamDefinition, garage:TeamGarage, season:Int, week:Int, seedOffset:Int, eligibleComponents: List<CarComponent> = CarComponent.values().toList()):CarComponent {
        val eligible = eligibleComponents.ifEmpty { CarComponent.values().toList() }
        val values = eligible.sortedBy { averageComponent(garage, it) }
        val weakest = values.first()
        val regulation = development.regulationForSeason(season)
        val preferred = when(regulation) {
            CarRegulationFocus.AERODYNAMICS -> listOf(CarComponent.FRONT_WING,CarComponent.REAR_WING,CarComponent.CHASSIS)
            CarRegulationFocus.POWER -> listOf(CarComponent.ENGINE,CarComponent.ELECTRIC_POWER_UNIT,CarComponent.CHASSIS)
            CarRegulationFocus.CORNERING -> listOf(CarComponent.CHASSIS,CarComponent.BRAKES,CarComponent.FRONT_WING)
            CarRegulationFocus.EFFICIENCY -> listOf(CarComponent.ELECTRIC_POWER_UNIT,CarComponent.ENGINE,CarComponent.BRAKES)
            CarRegulationFocus.BALANCED -> emptyList()
        }
        val strategic = preferred.firstOrNull { it in eligible && averageComponent(garage,it) <= averageComponent(garage,weakest) + 3 } ?: weakest
        return if (Math.floorMod(seed + seedOffset + team.id * 37 + week * 11, 100) < 70) strategic else weakest
    }

    private fun averageComponent(g:TeamGarage, c:CarComponent):Int =
        (g.car1.componentValue(c) + g.car2.componentValue(c)) / 2


    private fun targetCar(team:TeamDefinition, piece:CarPiece, week:Int, season:Int, seedOffset:Int):GarageCarId {
        val a = stateValuePlaceholder(team.id, piece.component, week, seedOffset)
        return if (a % 2 == 0) GarageCarId.CAR_1 else GarageCarId.CAR_2
    }

    private fun stateValuePlaceholder(teamId:Int, component:CarComponent, week:Int, seedOffset:Int):Int =
        Math.floorMod(seed + seedOffset + teamId * 19 + component.ordinal * 31 + week * 7, 100)

    private fun initialCar(team:TeamDefinition):TeamCarState = InitialTeamProfile.aiCarState(team)


    private fun legacyFromGarage(g:TeamGarage):TeamCarState {
        val avg = { c:CarComponent -> (g.car1.componentValue(c) + g.car2.componentValue(c)) / 2 }
        val aero = (avg(CarComponent.FRONT_WING) + avg(CarComponent.REAR_WING)) / 2
        val chassis = (avg(CarComponent.CHASSIS) + avg(CarComponent.BRAKES)) / 2
        val engine = (avg(CarComponent.ENGINE) + avg(CarComponent.ELECTRIC_POWER_UNIT)) / 2
        return TeamCarState(
            aerodynamics=aero, chassis=chassis, engine=engine,
            reliability=((g.car1.reliability + g.car2.reliability) / 2),
            frontWing=avg(CarComponent.FRONT_WING), rearWing=avg(CarComponent.REAR_WING),
            brakes=avg(CarComponent.BRAKES), electricPowerUnit=avg(CarComponent.ELECTRIC_POWER_UNIT)
        ).normalized()
    }

    private fun applyGaragePenalty(g:TeamGarage, amount:Int):TeamGarage =
        g.copy(
            car1=g.car1.copy(
                engine=if (CarComponent.ENGINE in g.car1.installedPieces) (g.car1.engine+amount).coerceIn(1,100) else 0,
                chassis=if (CarComponent.CHASSIS in g.car1.installedPieces) (g.car1.chassis+amount).coerceIn(1,100) else 0
            ),
            car2=g.car2.copy(
                engine=if (CarComponent.ENGINE in g.car2.installedPieces) (g.car2.engine+amount).coerceIn(1,100) else 0,
                chassis=if (CarComponent.CHASSIS in g.car2.installedPieces) (g.car2.chassis+amount).coerceIn(1,100) else 0
            )
        )
}
