package com.f1teammanager.core.manager

import com.f1teammanager.core.season.TeamDefinition
import kotlin.math.roundToInt

/**
 * Deterministic AI development using the same conceptual chain as the player:
 * P&D -> design -> factory -> physical pieces -> installation on Car 1/Car 2.
 * The legacy TeamCarState remains only as a compatibility/financial bridge.
 */
class AITeamDevelopmentEngine(private val seed:Int = 20261005) {
    data class SimulatedState(
        val car:TeamCarState,
        val budget:Long,
        val garage:TeamGarage? = null,
        val facilities:TeamFacilitiesState = TeamFacilitiesState()
    )

    private val development = CarDevelopmentEngine()

    /**
     * The official starting car is defined by InitialTeamProfile (Forte/Médio/Fraco).
     * WorldDatabase.baseCar is team prestige/current-world strength and must never
     * be used to bypass the starting-car margins in the physical development chain.
     */
    private fun initialCarStrength(team: TeamDefinition): Int =
        InitialTeamProfile.values(team).overall

    fun simulateFinancial(team:TeamDefinition, elapsedWeeks:Int, season:Int): SimulatedState {
        val weeks = elapsedWeeks.coerceAtLeast(0)
        var legacy = initialCar(team)
        var budget = initialBudget(team.baseCar)
        var garage = TeamGarageFactory.fromInitial(team)
        if (season < 2026) return SimulatedState(legacy, budget, garage, FacilityEngine.initial(team.initialLevel))

        // Preserve the established season-to-season chain: the completed physical
        // garage of season N is the input for season N+1. The old TeamCarState is
        // derived only as a compatibility/financial summary.
        for (s in 2026 until season) {
            val full = simulatePhysicalSeason(team, garage, 56, s, budget, seedOffset = s * 101)
            garage = full.garage
            legacy = legacyFromGarage(garage).normalized()
            val carriedLegacy = development.carryAiCarToNextSeason(legacy, s + 1)
            garage = carryAiGarageToNextSeason(garage, s + 1, team.id)
            legacy = carriedLegacy
            budget = initialBudget(team.baseCar)
            if (FinancialSeasonClosureEngine.aiPenaltyActive(team.id, s + 1)) {
                legacy = FinancialSeasonClosureEngine.applyCarPenalty(legacy, -1L).car
                garage = applyGaragePenalty(garage, -1)
            }
        }
        val current = simulatePhysicalSeason(team, garage, weeks, season, budget, seedOffset = season * 101)
        garage = current.garage
        legacy = if (weeks == 0 && season > 2026) legacy
                 else legacyFromGarage(garage).normalized()
        return SimulatedState(legacy, current.budget, garage, FacilityEngine.initial(team.initialLevel))
    }

    fun simulate(team:TeamDefinition, elapsedWeeks:Int, season:Int): TeamCarState = simulateFinancial(team, elapsedWeeks, season).car

    fun simulateGarage(team:TeamDefinition, elapsedWeeks:Int, season:Int): TeamGarage =
        simulateFinancial(team, elapsedWeeks, season).garage ?: TeamGarageFactory.fromInitial(team)

    private data class AiPhysicalState(val garage:TeamGarage, val budget:Long)

    private fun simulatePhysicalSeason(team:TeamDefinition, initial:TeamGarage, elapsedWeeks:Int, season:Int, startingBudget:Long, seedOffset:Int): AiPhysicalState {
        var state = AiPhysicalState(initial, startingBudget)
        val facilities = FacilityEngine.initial(team.initialLevel)
        var researchComponent:CarComponent? = null
        var researchRemaining = 0
        var researchPerformance = 0
        var researchReliability = 100
        var researchVersion = 1
        var factoryComponent:CarComponent? = null
        var factoryRemaining = 0
        var factoryPerformance = 0
        var factoryReliability = 100
        var factoryQuantity = 0
        var factoryOrderId = ""

        for (week in 1..elapsedWeeks) {
            // Research completion creates a design, never a direct car change.
            if (researchComponent != null) {
                if (researchRemaining > 1) {
                    researchRemaining--
                } else {
                    factoryComponent = researchComponent
                    factoryRemaining = FacilityEngine.factoryWeeks(if (initialCarStrength(team) >= 56) 1 else 2, facilities)
                    factoryPerformance = researchPerformance
                    factoryReliability = researchReliability
                    factoryQuantity = if (initialCarStrength(team) >= 58 && Math.floorMod(seed + seedOffset + team.id + week, 100) < 60) 2 else 1
                    factoryOrderId = "AI-F-${season}-${week}-${team.id}-${researchComponent!!.name}-V${researchVersion}"
                    researchComponent = null
                    researchRemaining = 0
                }
            }

            // Factory manufactures physical pieces; only after completion do they
            // enter inventory and become eligible for installation.
            if (factoryComponent != null) {
                if (factoryRemaining > 1) {
                    factoryRemaining--
                } else {
                    val produced = (0 until factoryQuantity).map { n ->
                        CarPiece("$factoryOrderId-U${n + 1}", factoryComponent!!, researchVersion, factoryPerformance, factoryReliability, week)
                    }
                    state = state.copy(garage = state.garage.copy(inventory = (state.garage.inventory + produced).takeLast(120)))
                    factoryComponent = null
                    factoryRemaining = 0
                    factoryQuantity = 0
                }
            }

            // Install only inventory pieces. AI never mutates a car directly.
            val available = state.garage.inventory.firstOrNull()
            if (available != null && shouldInstall(team, available, week, season, seedOffset)) {
                val target = targetCar(team, available, week, season, seedOffset)
                state = state.copy(garage = state.garage.install(available, target))
            }

            // One research project at a time, started only when the pipeline is free.
            if (researchComponent == null && factoryComponent == null) {
                val component = chooseComponent(team, state.garage, season, week, seedOffset)
                val rawDuration = when {
                    initialCarStrength(team) >= 59 -> 1
                    initialCarStrength(team) >= 52 -> 2
                    initialCarStrength(team) < 47 -> 3
                    else -> 2
                }
                val duration = FacilityEngine.researchWeeks(rawDuration, facilities, component)
                val rawGain = when {
                    initialCarStrength(team) >= 59 -> 5 + Math.floorMod(seed + seedOffset + team.id + week, 4)
                    initialCarStrength(team) >= 52 -> 4 + Math.floorMod(seed + seedOffset + team.id + week, 3)
                    else -> 2 + Math.floorMod(seed + seedOffset + team.id + week, 3)
                }
                val gain = FacilityEngine.researchGain(rawGain, facilities, component)
                val cost = when (duration) { 1 -> 5_000_000L; 2 -> 12_000_000L; else -> 18_000_000L }
                if (state.budget >= cost) {
                    researchComponent = component
                    researchRemaining = duration
                    researchPerformance = (state.garage.teamAverageOverall.toInt() + gain).coerceAtMost(100)
                    researchReliability = (94 + Math.floorMod(seed + team.id + component.ordinal + week, 7)).coerceIn(1,100)
                    researchVersion++
                    state = state.copy(budget = state.budget - cost)
                }
            }
        }
        return state
    }

    private fun carryAiGarageToNextSeason(garage:TeamGarage, nextSeason:Int, teamId:Int):TeamGarage {
        fun carry(v:Int):Int = (50 + (v - 50) * CarDevelopmentEngine.ANNUAL_CONTINUITY_FACTOR)
            .toInt().coerceIn(1,100)
        fun carryCar(car:PhysicalCar):PhysicalCar {
            val reliabilities = CarComponent.values().associateWith { c -> carry(car.componentReliability(c)) }
            return PhysicalCar(
                id = car.id,
                engine = carry(car.engine),
                chassis = carry(car.chassis),
                frontWing = carry(car.frontWing),
                rearWing = carry(car.rearWing),
                brakes = carry(car.brakes),
                electricPowerUnit = carry(car.electricPowerUnit),
                reliability = reliabilities.values.average().roundToInt().coerceIn(1,100),
                componentReliabilities = reliabilities,
                installedPieces = CarComponent.values().associateWith { c ->
                    "AI-SEASON-${nextSeason}-${teamId}-${car.id.name}-${c.name}"
                }
            )
        }
        return TeamGarage(carryCar(garage.car1), carryCar(garage.car2))
    }

    private fun chooseComponent(team:TeamDefinition, garage:TeamGarage, season:Int, week:Int, seedOffset:Int):CarComponent {
        val values = CarComponent.values().sortedBy { averageComponent(garage, it) }
        val weakest = values.first()
        val regulation = development.regulationForSeason(season)
        val preferred = when(regulation) {
            CarRegulationFocus.AERODYNAMICS -> listOf(CarComponent.FRONT_WING,CarComponent.REAR_WING,CarComponent.CHASSIS)
            CarRegulationFocus.POWER -> listOf(CarComponent.ENGINE,CarComponent.ELECTRIC_POWER_UNIT,CarComponent.CHASSIS)
            CarRegulationFocus.CORNERING -> listOf(CarComponent.CHASSIS,CarComponent.BRAKES,CarComponent.FRONT_WING)
            CarRegulationFocus.EFFICIENCY -> listOf(CarComponent.ELECTRIC_POWER_UNIT,CarComponent.ENGINE,CarComponent.BRAKES)
            CarRegulationFocus.BALANCED -> emptyList()
        }
        val strategic = preferred.firstOrNull { averageComponent(garage,it) <= averageComponent(garage,weakest) + 3 } ?: weakest
        return if (Math.floorMod(seed + seedOffset + team.id * 37 + week * 11, 100) < 70) strategic else weakest
    }

    private fun averageComponent(g:TeamGarage, c:CarComponent):Int =
        (g.car1.componentValue(c) + g.car2.componentValue(c)) / 2

    private fun shouldInstall(team:TeamDefinition, piece:CarPiece, week:Int, season:Int, seedOffset:Int):Boolean =
        Math.floorMod(seed + seedOffset + team.id * 13 + week * 17 + piece.component.ordinal * 7, 100) < if (initialCarStrength(team) >= 55) 92 else 78

    private fun targetCar(team:TeamDefinition, piece:CarPiece, week:Int, season:Int, seedOffset:Int):GarageCarId {
        val a = stateValuePlaceholder(team.id, piece.component, week, seedOffset)
        return if (a % 2 == 0) GarageCarId.CAR_1 else GarageCarId.CAR_2
    }

    private fun stateValuePlaceholder(teamId:Int, component:CarComponent, week:Int, seedOffset:Int):Int =
        Math.floorMod(seed + seedOffset + teamId * 19 + component.ordinal * 31 + week * 7, 100)

    private fun initialCar(team:TeamDefinition):TeamCarState = InitialTeamProfile.carState(team)

    private fun initialBudget(strength:Int):Long = 35_000_000L + strength.coerceIn(50,100) * 650_000L

    private fun legacyFromGarage(g:TeamGarage):TeamCarState {
        val avg = { c:CarComponent -> (g.car1.componentValue(c) + g.car2.componentValue(c)) / 2 }
        val aero = (avg(CarComponent.FRONT_WING) + avg(CarComponent.REAR_WING)) / 2
        val chassis = (avg(CarComponent.CHASSIS) + avg(CarComponent.BRAKES)) / 2
        val engine = (avg(CarComponent.ENGINE) + avg(CarComponent.ELECTRIC_POWER_UNIT)) / 2
        return TeamCarState(
            aerodynamics=aero, chassis=chassis, engine=engine,
            reliability=((g.car1.reliability + g.car2.reliability) / 2),
            frontWing=avg(CarComponent.FRONT_WING), rearWing=avg(CarComponent.REAR_WING),
            brakes=avg(CarComponent.BRAKES), electricPowerUnit=avg(CarComponent.ELECTRIC_POWER_UNIT)
        ).normalized()
    }

    private fun applyGaragePenalty(g:TeamGarage, amount:Int):TeamGarage =
        g.copy(
            car1=g.car1.copy(engine=(g.car1.engine+amount).coerceIn(40,100), chassis=(g.car1.chassis+amount).coerceIn(40,100)),
            car2=g.car2.copy(engine=(g.car2.engine+amount).coerceIn(40,100), chassis=(g.car2.chassis+amount).coerceIn(40,100))
        )
}
