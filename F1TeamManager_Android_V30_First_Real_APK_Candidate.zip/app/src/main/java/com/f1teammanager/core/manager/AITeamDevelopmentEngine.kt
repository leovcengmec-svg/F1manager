package com.f1teammanager.core.manager

import com.f1teammanager.core.season.TeamDefinition
import java.security.MessageDigest
import kotlin.math.roundToInt

/**
 * Deterministic AI development using the same conceptual chain as the player:
 * P&D -> design -> factory -> physical pieces -> installation on Car 1/Car 2.
 * The legacy TeamCarState remains only as a compatibility/financial bridge.
 */
internal fun selectAffordableFactoryQuantity(
    unitCost: Long,
    desiredQuantity: Int,
    technicalSpent: Long,
    technicalCap: Long,
    availableBudget: Long,
    maxAllowed: Int = 6
): Int {
    if (unitCost <= 0L || availableBudget < unitCost) return 0
    val desired = desiredQuantity.coerceIn(1, maxAllowed.coerceIn(1, 6))
    return (desired downTo 1).firstOrNull { quantity ->
        technicalSpent.coerceAtLeast(0L) + unitCost * quantity <= technicalCap.coerceAtLeast(0L) &&
            unitCost * quantity <= availableBudget.coerceAtLeast(0L)
    } ?: 0
}

data class AITeamDevelopmentHistoricalCheckpoint(
    val teamId: Int,
    val openingSeason: Int,
    val fingerprint: String,
    val garage: TeamGarage,
    val facilities: TeamFacilitiesState,
    val legacyCar: TeamCarState,
    /** True only for the authoritative garage frozen after GP30 settlement. */
    val canonicalSeasonOpening: Boolean = false
)

/** Durable cache contract. Missing or stale checkpoints are always safe to rebuild. */
interface AITeamDevelopmentCheckpointStore {
    fun loadCandidates(teamId: Int, beforeSeason: Int): List<AITeamDevelopmentHistoricalCheckpoint>
    fun save(checkpoint: AITeamDevelopmentHistoricalCheckpoint)

    /** Returns the exact season-opening checkpoint when its fingerprint still matches. */
    fun loadOpening(teamId: Int, openingSeason: Int, fingerprint: String): AITeamDevelopmentHistoricalCheckpoint? =
        loadCandidates(teamId, openingSeason + 1).firstOrNull {
            it.openingSeason == openingSeason && it.fingerprint == fingerprint
        }

    /** Canonical GP30 snapshot takes precedence over replay-derived checkpoints. */
    fun loadCanonicalOpening(teamId: Int, openingSeason: Int): AITeamDevelopmentHistoricalCheckpoint? =
        loadCandidates(teamId, openingSeason + 1).firstOrNull {
            it.openingSeason == openingSeason && it.canonicalSeasonOpening
        }
}

class AITeamDevelopmentEngine(
    private val seed:Int = 20261005,
    private val regulationSeed:Int = seed,
    private val checkpointStore: AITeamDevelopmentCheckpointStore? = null,
    /** Stable persisted career identity; isolates checkpoints and static caches across careers. */
    private val careerScope: String = "DEFAULT"
) {
    data class DevelopmentEvent(
        val week: Int,
        val type: Type,
        val component: CarComponent,
        val version: Int,
        val performance: Int,
        val reliability: Int,
        val target: GarageCarId? = null,
        val beforeOverall: Int? = null,
        val afterOverall: Int? = null,
        val pieceId: String? = null
    ) {
        enum class Type { DESIGN_COMPLETED, FACTORY_COMPLETED, PIECE_INSTALLED }
    }

    data class SimulatedState(
        val car:TeamCarState,
        val budget:Long,
        val garage:TeamGarage? = null,
        val facilities:TeamFacilitiesState = TeamFacilitiesState(),
        val events: List<DevelopmentEvent> = emptyList(),
        /** Cumulative current-season research/design spend reconstructed by the physical pipeline. */
        val researchSpent: Long = 0L,
        /** Cumulative current-season physical manufacturing spend reconstructed by the physical pipeline. */
        val fabricationSpent: Long = 0L
    )

    private val development = CarDevelopmentEngine()

    private data class PhysicalSimulationKey(
        val teamId: Int,
        val season: Int,
        val weeks: Int,
        val startingBudget: Long,
        val openingGarageFingerprint: Int,
        val facilitiesFingerprint: Int,
        val investmentFingerprint: Int,
        val rankingFingerprint: Int,
        val seed: Int,
        val regulationSeed: Int,
        val careerScope: String
    )

    private data class HistoricalOpeningState(
        val garage: TeamGarage,
        val facilities: TeamFacilitiesState,
        val legacyCar: TeamCarState
    )

    /** Bounded caches shared by the overview, ranking, season engine and market. */
    private object PhysicalSimulationMemoryCache {
        private const val MAX_ENTRIES = 96
        private val entries = object : LinkedHashMap<PhysicalSimulationKey, SimulatedState>(128, .75f, true) {}
        @Synchronized fun get(key: PhysicalSimulationKey): SimulatedState? = entries[key]
        @Synchronized fun put(key: PhysicalSimulationKey, value: SimulatedState) {
            entries[key] = value
            while (entries.size > MAX_ENTRIES) entries.entries.iterator().let { it.next(); it.remove() }
        }
    }

    private object HistoricalOpeningMemoryCache {
        private const val MAX_ENTRIES = 160
        private val entries = object : LinkedHashMap<String, HistoricalOpeningState>(192, .75f, true) {}
        @Synchronized fun get(key: String): HistoricalOpeningState? = entries[key]
        @Synchronized fun put(key: String, value: HistoricalOpeningState) {
            entries[key] = value
            while (entries.size > MAX_ENTRIES) entries.entries.iterator().let { it.next(); it.remove() }
        }
    }

    private fun openingCheckpointFingerprint(
        team: TeamDefinition,
        openingSeason: Int,
        nextSeasonInvestments: Map<Int, Long>,
        rankingFingerprint: Int
    ): String {
        val investmentPrefix = nextSeasonInvestments.filterKeys { it < openingSeason }.toSortedMap()
            .entries.joinToString(",") { "${it.key}:${it.value}" }
        val penaltyFingerprint = FinancialSeasonClosureEngine.aiPenaltyFingerprint(team.id, openingSeason)
        val source = listOf(
            "AI_PHYSICAL_CHECKPOINT_V3", careerScope, team.id, team.hashCode(), openingSeason,
            seed, regulationSeed, rankingFingerprint, investmentPrefix, penaltyFingerprint
        ).joinToString("|")
        return MessageDigest.getInstance("SHA-256")
            .digest(source.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it.toInt() and 0xff) }
    }

    /**
     * Persists the exact physical opening garage calculated at GP30. The same checkpoint
     * is then consumed by the next season's live race grid and all read-only projections,
     * instead of reconstructing the previous season with a synthetic initial budget.
     */
    fun persistCanonicalSeasonOpening(
        team: TeamDefinition,
        openingSeason: Int,
        garage: TeamGarage,
        facilities: TeamFacilitiesState,
        nextSeasonInvestments: Map<Int, Long>,
        investmentRankingSnapshot: Map<Int, Int>,
        handoff: TeamPrincipalTeamHandoff? = null
    ): AITeamDevelopmentHistoricalCheckpoint {
        val rankingFingerprint = investmentRankingSnapshot[team.id] ?: 40
        val fingerprint = handoff?.let {
            handoffOpeningFingerprint(team, it, openingSeason, nextSeasonInvestments, rankingFingerprint)
        } ?: openingCheckpointFingerprint(team, openingSeason, nextSeasonInvestments, rankingFingerprint)
        val normalizedGarage = garage.normalized()
        val checkpoint = AITeamDevelopmentHistoricalCheckpoint(
            teamId = team.id,
            openingSeason = openingSeason,
            fingerprint = fingerprint,
            garage = normalizedGarage,
            facilities = facilities,
            legacyCar = legacyFromGarage(normalizedGarage).normalized(),
            canonicalSeasonOpening = true
        )
        checkpointStore?.save(checkpoint)
        val state = HistoricalOpeningState(normalizedGarage, facilities, checkpoint.legacyCar)
        val cacheKey = "${team.id}:canonical:$openingSeason"
        HistoricalOpeningMemoryCache.put(cacheKey, state)
        return checkpoint
    }

    fun simulateFinancial(team:TeamDefinition, elapsedWeeks:Int, season:Int): SimulatedState =
        simulateFinancial(team, elapsedWeeks, season, InitialTeamProfile.initialBudget(team))

    /**
     * Simulates the AI technical pipeline against a caller-provided real cash
     * capacity. The caller must pass current cash + already-spent AI development
     * in this season. This preserves cumulative development spending while making
     * the pipeline unable to spend money that the team does not actually have.
     */
    fun simulateFinancial(
        team: TeamDefinition,
        elapsedWeeks: Int,
        season: Int,
        startingBudget: Long,
        startingFacilities: TeamFacilitiesState? = null,
        nextSeasonInvestments: Map<Int, Long> = emptyMap(),
        investmentRankingSnapshot: Map<Int, Int>? = null,
        /** Read-only projections must not publish simulated values to the career-wide live ranking. */
        publishLiveOverall: Boolean = false
    ): SimulatedState {
        val weeks = elapsedWeeks.coerceAtLeast(0)
        val currentSeasonStartingBudget = startingBudget.coerceAtLeast(0L)
        if (season < 2026) {
            val baselineGarage = TeamGarageFactory.fromInitial(team)
            val baselineFacilities = startingFacilities ?: FacilityEngine.initial(team.initialLevel)
            return SimulatedState(initialCar(team), currentSeasonStartingBudget, baselineGarage, baselineFacilities)
        }

        // The investment-cost ranking is frozen for this request. Previously the
        // global live ranking could change between historical weeks while replaying
        // one team's history, making the same career depend on call order.
        val investmentRanking = (investmentRankingSnapshot ?: TechnicalInvestmentEngine.seasonRanking()).toSortedMap()
        // simulatePhysicalSeason uses only this team's rank when selecting research
        // and manufacturing costs. Other teams moving in the ranking must not
        // invalidate this team's deterministic historical checkpoint.
        val rankingFingerprint = investmentRanking[team.id] ?: 40
        val opening = historicalOpeningState(team, season, nextSeasonInvestments, investmentRanking, rankingFingerprint)
        val garageAtOpening = opening.garage
        val currentFacilities = startingFacilities ?: opening.facilities
        val key = PhysicalSimulationKey(
            teamId = team.id,
            season = season,
            weeks = weeks,
            startingBudget = currentSeasonStartingBudget,
            openingGarageFingerprint = garageAtOpening.hashCode(),
            facilitiesFingerprint = currentFacilities.hashCode(),
            investmentFingerprint = nextSeasonInvestments.toSortedMap().hashCode(),
            rankingFingerprint = rankingFingerprint,
            seed = seed,
            regulationSeed = regulationSeed,
            careerScope = careerScope
        )
        PhysicalSimulationMemoryCache.get(key)?.let { cached ->
            if (publishLiveOverall) cached.garage?.let { TechnicalInvestmentEngine.recordLiveOverall(team.id, it.teamAverageOverall.toDouble()) }
            return cached
        }

        val result = if (weeks == 0) {
            SimulatedState(
                car = if (season > 2026) opening.legacyCar.normalized() else legacyFromGarage(garageAtOpening).normalized(),
                budget = currentSeasonStartingBudget,
                garage = garageAtOpening,
                facilities = currentFacilities
            )
        } else {
            val current = simulatePhysicalSeason(
                team, garageAtOpening, weeks, season, currentSeasonStartingBudget,
                seedOffset = season * 101, facilities = currentFacilities,
                investmentRanking = investmentRanking
            )
            SimulatedState(
                car = legacyFromGarage(current.garage).normalized(),
                budget = current.budget,
                garage = current.garage,
                facilities = current.facilities,
                events = current.events,
                researchSpent = current.researchSpent,
                fabricationSpent = current.fabricationSpent
            )
        }
        if (publishLiveOverall) result.garage?.let { TechnicalInvestmentEngine.recordLiveOverall(team.id, it.teamAverageOverall.toDouble()) }
        PhysicalSimulationMemoryCache.put(key, result)
        return result
    }

    /**
     * Returns the garage/facilities at the opening of targetSeason. A durable
     * checkpoint is written at every rollover, so a 15th-season career normally
     * advances only the latest completed season instead of replaying all 14.
     */
    private fun historicalOpeningState(
        team: TeamDefinition,
        targetSeason: Int,
        nextSeasonInvestments: Map<Int, Long>,
        investmentRanking: Map<Int, Int>,
        rankingFingerprint: Int
    ): HistoricalOpeningState {
        if (targetSeason <= 2026) return HistoricalOpeningState(
            TeamGarageFactory.fromInitial(team), FacilityEngine.initial(team.initialLevel), initialCar(team)
        )

        fun fingerprint(openingSeason: Int): String = openingCheckpointFingerprint(
            team, openingSeason, nextSeasonInvestments, rankingFingerprint
        )

        // The canonical GP30 garage is authoritative even when the new season's live
        // technical ranking differs from the ranking fingerprint captured at closure.
        // It already contains committed investment, regulation and closure penalty.
        HistoricalOpeningMemoryCache.get("${team.id}:canonical:$targetSeason")?.let { return it }
        checkpointStore?.loadCanonicalOpening(team.id, targetSeason)?.let { checkpoint ->
            val state = HistoricalOpeningState(
                checkpoint.garage.normalized(), checkpoint.facilities, checkpoint.legacyCar.normalized()
            )
            HistoricalOpeningMemoryCache.put("${team.id}:canonical:$targetSeason", state)
            return state
        }

        // Fingerprinted replay checkpoints remain a compatibility fallback for saves
        // created before V732 or for incomplete careers without a GP30 snapshot.
        val exactFingerprint = fingerprint(targetSeason)
        HistoricalOpeningMemoryCache.get("${team.id}:$targetSeason:$exactFingerprint")?.let { return it }
        checkpointStore?.loadOpening(team.id, targetSeason, exactFingerprint)?.let { checkpoint ->
            val state = HistoricalOpeningState(
                checkpoint.garage.normalized(), checkpoint.facilities, checkpoint.legacyCar.normalized()
            )
            HistoricalOpeningMemoryCache.put("${team.id}:$targetSeason:$exactFingerprint", state)
            return state
        }

        // Use the newest in-memory checkpoint first, then the newest compatible
        // durable one. Fingerprints protect against imported saves and changed inputs.
        for (openingSeason in (targetSeason - 1 downTo 2027)) {
            val expected = fingerprint(openingSeason)
            HistoricalOpeningMemoryCache.get("${team.id}:$openingSeason:$expected")?.let { return it }
        }

        var openingSeason = 2026
        var garage = TeamGarageFactory.fromInitial(team)
        var facilities = FacilityEngine.initial(team.initialLevel)
        var legacyCar = initialCar(team)
        val reusable = checkpointStore?.loadCandidates(team.id, targetSeason)
            ?.sortedByDescending { it.openingSeason }
            ?.firstOrNull { checkpoint ->
                checkpoint.openingSeason in 2027 until targetSeason &&
                    checkpoint.fingerprint == fingerprint(checkpoint.openingSeason)
            }
        if (reusable != null) {
            openingSeason = reusable.openingSeason
            garage = reusable.garage.normalized()
            facilities = reusable.facilities
            legacyCar = reusable.legacyCar.normalized()
            HistoricalOpeningMemoryCache.put(
                "${team.id}:$openingSeason:${reusable.fingerprint}", HistoricalOpeningState(garage, facilities, legacyCar)
            )
        }

        for (historicalSeason in openingSeason until targetSeason) {
            val full = simulatePhysicalSeason(
                team, garage, 56, historicalSeason, InitialTeamProfile.initialBudget(team),
                seedOffset = historicalSeason * 101, facilities = facilities,
                investmentRanking = investmentRanking
            )
            garage = full.garage
            facilities = full.facilities
            legacyCar = legacyFromGarage(garage).normalized()
            val nextCarInvestment = nextSeasonInvestments[historicalSeason] ?: 0L
            val carriedLegacy = development.carryAiCarToNextSeason(legacyCar, historicalSeason + 1, nextCarInvestment)
            garage = carryAiGarageToNextSeason(garage, historicalSeason + 1, team.id, nextCarInvestment, legacyCar.developmentKnowledge)
            val rule = AnnualCarRegulationEngine.generateForCalendarYear(historicalSeason + 1, regulationSeed)
            val teamRegulationSeed = team.id.hashCode()
            garage = AnnualCarRegulationEngine.applyToGarage(garage, rule, teamRegulationSeed)
            legacyCar = AnnualCarRegulationEngine.applyToCar(carriedLegacy, rule, teamRegulationSeed).let { regulated ->
                legacyFromGarage(garage).copy(
                    aerodynamics = regulated.aerodynamics,
                    chassis = regulated.chassis,
                    engine = regulated.engine,
                    reliability = regulated.reliability
                ).normalized()
            }
            if (FinancialSeasonClosureEngine.aiPenaltyActive(team.id, historicalSeason + 1)) {
                // The physical garage is authoritative; this call is retained for
                // parity with the legacy penalty path before the physical penalty.
                legacyCar = FinancialSeasonClosureEngine.applyCarPenalty(legacyCar, -1L).car
                garage = FinancialSeasonClosureEngine.applyGaragePenalty(garage)
            }

            val nextOpeningSeason = historicalSeason + 1
            val nextFingerprint = fingerprint(nextOpeningSeason)
            val state = HistoricalOpeningState(garage, facilities, legacyCar)
            HistoricalOpeningMemoryCache.put("${team.id}:$nextOpeningSeason:$nextFingerprint", state)
            checkpointStore?.save(
                AITeamDevelopmentHistoricalCheckpoint(team.id, nextOpeningSeason, nextFingerprint, garage, facilities, legacyCar)
            )
        }
        return HistoricalOpeningMemoryCache.get("${team.id}:$targetSeason:${fingerprint(targetSeason)}")
            ?: HistoricalOpeningState(garage, facilities, legacyCar)
    }

    fun simulate(team:TeamDefinition, elapsedWeeks:Int, season:Int): TeamCarState = simulateFinancial(team, elapsedWeeks, season).car

    fun simulateGarage(team:TeamDefinition, elapsedWeeks:Int, season:Int): TeamGarage =
        simulateFinancial(team, elapsedWeeks, season).garage ?: TeamGarageFactory.fromInitial(team)


    /**
     * Replays an AI season from the physical car left by a departing Team Principal.
     * This prevents a team from snapping back to its original starter car after a hire.
     */
    private fun handoffOpeningFingerprint(
        team: TeamDefinition,
        handoff: TeamPrincipalTeamHandoff,
        openingSeason: Int,
        nextSeasonInvestments: Map<Int, Long>,
        rankingFingerprint: Int
    ): String {
        val investmentPrefix = nextSeasonInvestments.filterKeys { it < openingSeason }.toSortedMap()
            .entries.joinToString(",") { "${it.key}:${it.value}" }
        val source = listOf(
            "AI_HANDOFF_CHECKPOINT_V1", careerScope, team.id, team.hashCode(), handoff.encode(),
            openingSeason, seed, regulationSeed, rankingFingerprint, investmentPrefix,
            FinancialSeasonClosureEngine.aiPenaltyFingerprint(team.id, openingSeason)
        ).joinToString("|")
        return MessageDigest.getInstance("SHA-256")
            .digest(source.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it.toInt() and 0xff) }
    }

    /**
     * Reuses the exact handoff opening state and advances only missing seasons.
     * Team Principal careers can keep a handoff active for many seasons; without this
     * checkpoint path, every screen/market projection replayed every season since the
     * last handoff. The normal and handoff checkpoint fingerprints are disjoint.
     */
    private fun historicalOpeningStateFromHandoff(
        team: TeamDefinition,
        handoff: TeamPrincipalTeamHandoff,
        targetSeason: Int,
        nextSeasonInvestments: Map<Int, Long>,
        rankingSnapshot: Map<Int, Int>
    ): HistoricalOpeningState {
        val firstNextSeason = handoff.closingSeason + 1
        val rankingFingerprint = rankingSnapshot[team.id] ?: 40
        val canonicalKey = "${team.id}:canonical:$targetSeason"
        HistoricalOpeningMemoryCache.get(canonicalKey)?.let { return it }
        checkpointStore?.loadCanonicalOpening(team.id, targetSeason)?.let { checkpoint ->
            val state = HistoricalOpeningState(
                checkpoint.garage.normalized(), checkpoint.facilities, checkpoint.legacyCar.normalized()
            )
            HistoricalOpeningMemoryCache.put(canonicalKey, state)
            return state
        }
        if (targetSeason <= firstNextSeason) {
            var garage = carryAiGarageToNextSeason(
                handoff.garage, firstNextSeason, team.id, handoff.nextSeasonInvestment,
                handoff.technicalKnowledge
            )
            val rule = AnnualCarRegulationEngine.generateForCalendarYear(firstNextSeason, regulationSeed)
            garage = AnnualCarRegulationEngine.applyToGarage(garage, rule, team.id.hashCode())
            if (FinancialSeasonClosureEngine.aiPenaltyActive(team.id, firstNextSeason)) {
                garage = FinancialSeasonClosureEngine.applyGaragePenalty(garage)
            }
            return HistoricalOpeningState(garage, handoff.facilities, legacyFromGarage(garage).normalized())
        }

        fun fingerprint(openingSeason: Int) = handoffOpeningFingerprint(
            team, handoff, openingSeason, nextSeasonInvestments, rankingFingerprint
        )
        val exactFingerprint = fingerprint(targetSeason)
        HistoricalOpeningMemoryCache.get("${team.id}:handoff:$targetSeason:$exactFingerprint")?.let { return it }
        checkpointStore?.loadOpening(team.id, targetSeason, exactFingerprint)?.let { checkpoint ->
            val state = HistoricalOpeningState(
                checkpoint.garage.normalized(), checkpoint.facilities, checkpoint.legacyCar.normalized()
            )
            HistoricalOpeningMemoryCache.put("${team.id}:handoff:$targetSeason:$exactFingerprint", state)
            return state
        }
        for (openingSeason in (targetSeason - 1 downTo firstNextSeason)) {
            val expected = fingerprint(openingSeason)
            HistoricalOpeningMemoryCache.get("${team.id}:handoff:$openingSeason:$expected")?.let { return it }
        }

        var openingSeason = firstNextSeason
        var garage = carryAiGarageToNextSeason(
            handoff.garage, firstNextSeason, team.id, handoff.nextSeasonInvestment,
            handoff.technicalKnowledge
        )
        var facilities = handoff.facilities
        fun applyRegulation(season: Int, source: TeamGarage): TeamGarage {
            var regulated = AnnualCarRegulationEngine.applyToGarage(
                source, AnnualCarRegulationEngine.generateForCalendarYear(season, regulationSeed), team.id.hashCode()
            )
            if (FinancialSeasonClosureEngine.aiPenaltyActive(team.id, season)) {
                regulated = FinancialSeasonClosureEngine.applyGaragePenalty(regulated)
            }
            return regulated
        }
        garage = applyRegulation(firstNextSeason, garage)
        var legacyCar = legacyFromGarage(garage).normalized()

        val reusable = checkpointStore?.loadCandidates(team.id, targetSeason)
            ?.sortedByDescending { it.openingSeason }
            ?.firstOrNull { checkpoint ->
                checkpoint.openingSeason in firstNextSeason until targetSeason &&
                    checkpoint.fingerprint == fingerprint(checkpoint.openingSeason)
            }
        if (reusable != null) {
            openingSeason = reusable.openingSeason
            garage = reusable.garage.normalized()
            facilities = reusable.facilities
            legacyCar = reusable.legacyCar.normalized()
            HistoricalOpeningMemoryCache.put(
                "${team.id}:handoff:$openingSeason:${reusable.fingerprint}",
                HistoricalOpeningState(garage, facilities, legacyCar)
            )
        } else {
            val firstFingerprint = fingerprint(firstNextSeason)
            val firstState = HistoricalOpeningState(garage, facilities, legacyCar)
            HistoricalOpeningMemoryCache.put("${team.id}:handoff:$firstNextSeason:$firstFingerprint", firstState)
            checkpointStore?.save(
                AITeamDevelopmentHistoricalCheckpoint(team.id, firstNextSeason, firstFingerprint, garage, facilities, legacyCar)
            )
        }

        while (openingSeason < targetSeason) {
            val full = simulatePhysicalSeason(
                team, garage, 56, openingSeason, InitialTeamProfile.initialBudget(team),
                seedOffset = openingSeason * 101, facilities = facilities,
                investmentRanking = rankingSnapshot
            )
            garage = full.garage
            facilities = full.facilities
            val nextSeason = openingSeason + 1
            garage = carryAiGarageToNextSeason(
                garage, nextSeason, team.id, nextSeasonInvestments[openingSeason] ?: 0L,
                handoff.technicalKnowledge
            )
            garage = applyRegulation(nextSeason, garage)
            legacyCar = legacyFromGarage(garage).normalized()
            openingSeason = nextSeason
            val nextFingerprint = fingerprint(openingSeason)
            val state = HistoricalOpeningState(garage, facilities, legacyCar)
            HistoricalOpeningMemoryCache.put("${team.id}:handoff:$openingSeason:$nextFingerprint", state)
            checkpointStore?.save(
                AITeamDevelopmentHistoricalCheckpoint(team.id, openingSeason, nextFingerprint, garage, facilities, legacyCar)
            )
        }
        return HistoricalOpeningMemoryCache.get("${team.id}:handoff:$targetSeason:${fingerprint(targetSeason)}")
            ?: HistoricalOpeningState(garage, facilities, legacyCar)
    }

    /**
     * Replays an AI season from the physical car left by a departing Team Principal.
     * Handoff state is checkpointed per season, preserving full garage/facility queues
     * while preventing repeated replay of the entire post-handoff career.
     */
    fun simulateFinancialFromHandoff(
        team: TeamDefinition,
        elapsedWeeks: Int,
        season: Int,
        handoff: TeamPrincipalTeamHandoff,
        startingBudget: Long,
        startingFacilities: TeamFacilitiesState? = null,
        nextSeasonInvestments: Map<Int, Long> = emptyMap(),
        investmentRankingSnapshot: Map<Int, Int>? = null,
        /** Read-only projections must not publish simulated values to the career-wide live ranking. */
        publishLiveOverall: Boolean = false
    ): SimulatedState {
        require(handoff.teamId == team.id) { "O checkpoint Team Principal pertence a outra equipe." }
        require(season > handoff.closingSeason) { "O checkpoint precisa ser anterior à temporada simulada." }
        val weeks = elapsedWeeks.coerceAtLeast(0)
        val currentSeasonBudget = startingBudget.coerceAtLeast(0L)
        val rankingSnapshot = (investmentRankingSnapshot ?: TechnicalInvestmentEngine.seasonRanking()).toSortedMap()
        val rankingFingerprint = rankingSnapshot[team.id] ?: 40
        val opening = historicalOpeningStateFromHandoff(
            team, handoff, season, nextSeasonInvestments, rankingSnapshot
        )
        val currentFacilities = startingFacilities ?: opening.facilities
        val key = PhysicalSimulationKey(
            teamId = team.id,
            season = season,
            weeks = weeks,
            startingBudget = currentSeasonBudget,
            openingGarageFingerprint = 31 * opening.garage.hashCode() + handoff.technicalKnowledge.toSortedMap().hashCode(),
            facilitiesFingerprint = currentFacilities.hashCode(),
            investmentFingerprint = nextSeasonInvestments.toSortedMap().hashCode(),
            rankingFingerprint = rankingFingerprint,
            seed = seed,
            regulationSeed = regulationSeed,
            careerScope = careerScope
        )
        PhysicalSimulationMemoryCache.get(key)?.let { cached ->
            if (publishLiveOverall) cached.garage?.let { TechnicalInvestmentEngine.recordLiveOverall(team.id, it.teamAverageOverall.toDouble()) }
            return cached
        }
        val current = if (weeks == 0) {
            SimulatedState(
                car = legacyFromGarage(opening.garage).copy(
                    nextSeasonInvestment = nextSeasonInvestments[season] ?: 0L,
                    nextSeasonFocus = CarDevelopmentFocus.BALANCED,
                    developmentKnowledge = handoff.technicalKnowledge
                ).normalized(),
                budget = currentSeasonBudget,
                garage = opening.garage,
                facilities = currentFacilities
            )
        } else {
            val simulated = simulatePhysicalSeason(
                team, opening.garage, weeks, season, currentSeasonBudget,
                seedOffset = season * 101, facilities = currentFacilities,
                investmentRanking = rankingSnapshot
            )
            val car = legacyFromGarage(simulated.garage).copy(
                nextSeasonInvestment = nextSeasonInvestments[season] ?: 0L,
                nextSeasonFocus = CarDevelopmentFocus.BALANCED,
                developmentKnowledge = handoff.technicalKnowledge
            ).normalized()
            SimulatedState(
                car, simulated.budget, simulated.garage, simulated.facilities, simulated.events,
                simulated.researchSpent, simulated.fabricationSpent
            )
        }
        if (publishLiveOverall) current.garage?.let { TechnicalInvestmentEngine.recordLiveOverall(team.id, it.teamAverageOverall.toDouble()) }
        PhysicalSimulationMemoryCache.put(key, current)
        return current
    }

    private data class AiPhysicalState(
        val garage:TeamGarage,
        val budget:Long,
        val facilities:TeamFacilitiesState,
        val events: List<DevelopmentEvent> = emptyList(),
        val researchSpent: Long = 0L,
        val fabricationSpent: Long = 0L
    )

    private data class AiFactoryBatch(
        val component: CarComponent,
        val version: Int,
        val performance: Int,
        val reliability: Int,
        val quantity: Int,
        val remainingWeeks: Int,
        val orderId: String
    )

    private data class AiResearchProject(
        val component: CarComponent,
        val version: Int,
        val performance: Int,
        val reliability: Int,
        val plannedQuantity: Int,
        val remainingWeeks: Int
    )

    private fun simulatePhysicalSeason(team:TeamDefinition, initial:TeamGarage, elapsedWeeks:Int, season:Int, startingBudget:Long, seedOffset:Int, facilities:TeamFacilitiesState, investmentRanking: Map<Int, Int>? = null): AiPhysicalState {
        var state = AiPhysicalState(initial, startingBudget, facilities)
        val researchProjects = mutableListOf<AiResearchProject>()

        // AI must obey the same per-component research/version rules as the player.
        // The old implementation used one global version counter, which could make
        // a first Chassi upgrade appear as V4 simply because three other components
        // had been researched before it. It also had no component cooldown, allowing
        // the same component to be researched again as soon as the pipeline freed.
        val componentVersions = CarComponent.values().associateWith { component ->
            maxOf(
                initial.car1.installedPieceVersions[component] ?: 0,
                initial.car2.installedPieceVersions[component] ?: 0
            )
        }.toMutableMap()
        val cooldownUntil = mutableMapOf<CarComponent, Int>()
        val readyDesigns = mutableListOf<AiResearchProject>()
        val factoryOrders = mutableListOf<AiFactoryBatch>()
        var technicalSpent = 0L
        val ranking = investmentRanking?.get(team.id) ?: TechnicalInvestmentEngine.seasonRanking()[team.id] ?: 40
        val technicalCap = TechnicalInvestmentEngine.ANNUAL_TECHNICAL_CAP

        for (week in 1..elapsedWeeks) {
            // Advance all physical factory orders independently. At higher Factory
            // levels more than one order can exist at the same time, matching the
            // player's parallel-order capacity.
            val continuingOrders = mutableListOf<AiFactoryBatch>()
            factoryOrders.forEach { order ->
                if (order.remainingWeeks > 1) {
                    continuingOrders += order.copy(remainingWeeks = order.remainingWeeks - 1)
                } else {
                    repeat(order.quantity) { n ->
                        val piece = CarPiece(
                            "${order.orderId}-U${n + 1}", order.component, order.version,
                            order.performance, order.reliability, week, season
                        )
                        val target = targetCar(team, piece, week, season, seedOffset)
                        val beforeOverall = state.garage.teamAverageOverall
                        val installedGarage = state.garage.install(piece, target)
                        val afterOverall = installedGarage.teamAverageOverall
                        state = state.copy(
                            garage = installedGarage,
                            events = state.events + DevelopmentEvent(
                                week = week, type = DevelopmentEvent.Type.FACTORY_COMPLETED,
                                component = piece.component, version = piece.version,
                                performance = piece.performance, reliability = piece.reliability,
                                target = target, beforeOverall = beforeOverall,
                                afterOverall = afterOverall, pieceId = piece.pieceId
                            ) + DevelopmentEvent(
                                week = week, type = DevelopmentEvent.Type.PIECE_INSTALLED,
                                component = piece.component, version = piece.version,
                                performance = piece.performance, reliability = piece.reliability,
                                target = target, beforeOverall = beforeOverall,
                                afterOverall = afterOverall, pieceId = piece.pieceId
                            )
                        )
                    }
                }
            }
            factoryOrders.clear()
            factoryOrders.addAll(continuingOrders)

            // Advance every active R&D project independently. The Research Center
            // supports 1/2/3 concurrent projects by level; completed designs can wait
            // in the ready queue if the physical Factory has no free order slot.
            val continuingResearch = mutableListOf<AiResearchProject>()
            val completedResearch = mutableListOf<AiResearchProject>()
            researchProjects.forEach { project ->
                if (project.remainingWeeks > 1) {
                    continuingResearch += project.copy(remainingWeeks = project.remainingWeeks - 1)
                } else {
                    completedResearch += project
                }
            }
            researchProjects.clear()
            researchProjects.addAll(continuingResearch)
            completedResearch.forEach { project ->
                // A completed design is retained until the physical Factory has a
                // free order slot and the budget/technical cap can fund production.
                readyDesigns += project
                componentVersions[project.component] = project.version
                cooldownUntil[project.component] = week + 4
                state = state.copy(events = state.events + DevelopmentEvent(
                    week = week,
                    type = DevelopmentEvent.Type.DESIGN_COMPLETED,
                    component = project.component,
                    version = project.version,
                    performance = project.performance,
                    reliability = project.reliability
                ))
            }

            // Dispatch completed designs into the physical factory. The queue lets
            // research capacity operate independently from factory capacity, just as
            // it does for the player. An unaffordable design waits instead of vanishing.
            val factoryCapacity = FactorySpecification.level(facilities.level(FacilityType.FACTORY)).parallelOrders
            while (readyDesigns.isNotEmpty() && factoryOrders.size < factoryCapacity) {
                val project = readyDesigns.first()
                val factorySpec = FactorySpecification.level(facilities.level(FacilityType.FACTORY))
                val plannedQuantity = project.plannedQuantity.coerceIn(1, factorySpec.maxUnitsPerOrder)
                val plannedDesign = ResearchDesign(
                    "AI-${team.id}-${season}-${week}-${project.component.name}-V${project.version}",
                    project.component, project.version, project.performance, project.reliability, season, week
                )
                val factoryUnitCost = FactoryEngine().manufacturingCost(plannedDesign, facilities, ranking)
                val actualQuantity = selectAffordableFactoryQuantity(
                    unitCost = factoryUnitCost,
                    desiredQuantity = plannedQuantity,
                    technicalSpent = technicalSpent,
                    technicalCap = technicalCap,
                    availableBudget = state.budget,
                    maxAllowed = factorySpec.maxUnitsPerOrder
                )
                if (actualQuantity <= 0) break
                val actualFactoryCost = factoryUnitCost * actualQuantity
                state = state.copy(
                    budget = FinanceEngine().cashDebitBalance(state.budget, actualFactoryCost),
                    fabricationSpent = state.fabricationSpent + actualFactoryCost
                )
                technicalSpent += actualFactoryCost
                readyDesigns.removeAt(0)
                val orderId = "AI-F-${season}-${week}-${team.id}-${project.component.name}-V${project.version}"
                factoryOrders += AiFactoryBatch(
                    component = project.component,
                    version = project.version,
                    performance = project.performance,
                    reliability = project.reliability,
                    quantity = actualQuantity,
                    remainingWeeks = FactoryEngine().manufacturingWeeks(actualQuantity, facilities),
                    orderId = orderId
                )
            }

            // Factory completion above immediately installs the physical pieces;
            // no inventory/stock exists in the AI simulation.

            // Start one new design per week until the Research Center's own
            // concurrency limit. Its capacity remains independent from the factory;
            // completed designs wait in readyDesigns until a production slot opens.
            val researchCapacity = ResearchEngine().activeProjectCapacity(facilities.level(FacilityType.RESEARCH))
            if (researchProjects.size < researchCapacity) {
                val activeComponents = (researchProjects.map { it.component } + readyDesigns.map { it.component } + factoryOrders.map { it.component }).toSet()
                val eligibleComponents = CarComponent.values().filter {
                    week >= (cooldownUntil[it] ?: 0) && it !in activeComponents
                }
                if (eligibleComponents.isEmpty()) continue
                val component = chooseComponent(team, state.garage, season, week, seedOffset, eligibleComponents)
                // IA chooses the same P&D inputs available to the player:
                // complexity, focus, component and investment. The mechanics below
                // are the ResearchEngine mechanics, not a separate AI formula.
                val research = ResearchEngine()
                val currentOverall = state.garage.teamAverageOverall
                val complexity = chooseResearchComplexity(currentOverall, state.budget)
                val researchLevel = facilities.level(FacilityType.RESEARCH)
                val duration = research.calculatedWeeks(facilities, component, complexity)
                // The AI uses the same P&D + Wind Tunnel + Simulator time and
                // facility-adjusted price as the player's ResearchEngine options.
                val cost = research.facilityAdjustedCost(research.baseCost(complexity), facilities, ranking)
                val basePerformance = maxOf(
                    state.garage.car1.componentValue(component),
                    state.garage.car2.componentValue(component)
                )
                val baseReliability = maxOf(
                    state.garage.car1.componentReliability(component),
                    state.garage.car2.componentReliability(component)
                )
                val maxRange = research.maxImprovement(facilities, component, basePerformance)
                val baseGain = if (maxRange.first == maxRange.last) maxRange.first
                               else maxRange.first + Math.floorMod(seed + seedOffset + team.id * 13 + week * 17, maxRange.last - maxRange.first + 1)
                val bonusRange = research.complexityBonus(complexity, basePerformance)
                val bonusGain = if (bonusRange.first == bonusRange.last) bonusRange.first
                                else bonusRange.first + Math.floorMod(seed + seedOffset + team.id * 19 + week * 23, bonusRange.last - bonusRange.first + 1)
                val totalGain = baseGain + bonusGain
                val outcomeRoll = Math.floorMod(seed + seedOffset + team.id * 29 + week * 31, 100)
                val failure = research.failureChance(researchLevel, complexity)
                val partial = when (complexity) {
                    ResearchComplexity.SIMPLE -> 10
                    ResearchComplexity.MEDIUM -> 15
                    ResearchComplexity.ADVANCED -> 20
                    ResearchComplexity.EXPERIMENTAL -> 25
                }.let { (it - researchLevel).coerceAtLeast(5) }
                val outcome = when {
                    outcomeRoll < failure -> ResearchOutcome.FAILURE
                    outcomeRoll < failure + partial -> ResearchOutcome.PARTIAL
                    else -> ResearchOutcome.SUCCESS
                }
                val effectiveGain = when (outcome) {
                    ResearchOutcome.SUCCESS -> totalGain
                    ResearchOutcome.PARTIAL -> (totalGain * 0.5).roundToInt()
                    ResearchOutcome.FAILURE -> 0
                }
                val focus = chooseResearchFocus(state.garage, component)
                val (performanceGain, reliabilityGain) = research.splitGain(effectiveGain, focus)
                val plannedReliability = (baseReliability + reliabilityGain).coerceAtMost(100)
                val plannedPerformance = (basePerformance + performanceGain).coerceAtMost(100)
                val nextVersion = (componentVersions[component] ?: 0) + 1
                // Desired batch size scales with the official Factory specification.
                // The live cash and annual technical cap still reduce it safely.
                val factorySpec = FactorySpecification.level(facilities.level(FacilityType.FACTORY))
                val quantityRoll = Math.floorMod(seed + seedOffset + team.id + week, 100)
                val desiredQuantity = when (factorySpec.maxUnitsPerOrder) {
                    1 -> 1
                    2 -> if (quantityRoll < 55) 2 else 1
                    3 -> when { quantityRoll < 25 -> 3; quantityRoll < 75 -> 2; else -> 1 }
                    4 -> when { quantityRoll < 15 -> 4; quantityRoll < 45 -> 3; quantityRoll < 80 -> 2; else -> 1 }
                    5 -> when { quantityRoll < 10 -> 5; quantityRoll < 30 -> 4; quantityRoll < 60 -> 3; quantityRoll < 85 -> 2; else -> 1 }
                    else -> when { quantityRoll < 10 -> 6; quantityRoll < 25 -> 5; quantityRoll < 45 -> 4; quantityRoll < 70 -> 3; quantityRoll < 90 -> 2; else -> 1 }
                }
                val estimatedDesign = ResearchDesign("AI-PREVIEW-${team.id}-${season}-${week}", component, nextVersion, plannedPerformance, plannedReliability, season, week)
                val unitFactoryCost = FactoryEngine().manufacturingCost(estimatedDesign, facilities, ranking)
                val plannedQuantity = selectAffordableFactoryQuantity(
                    unitCost = unitFactoryCost,
                    desiredQuantity = desiredQuantity,
                    // Reserve the just-selected design cost before deciding how many
                    // physical units the shared annual cap can still support.
                    technicalSpent = technicalSpent + cost,
                    technicalCap = technicalCap,
                    availableBudget = (state.budget - cost).coerceAtLeast(0L),
                    maxAllowed = factorySpec.maxUnitsPerOrder
                )
                val estimatedFactory = unitFactoryCost * plannedQuantity
                if (plannedQuantity > 0 && technicalSpent + cost + estimatedFactory <= technicalCap && state.budget >= cost + estimatedFactory) {
                    researchProjects += AiResearchProject(
                        component = component,
                        version = nextVersion,
                        performance = plannedPerformance,
                        reliability = plannedReliability,
                        plannedQuantity = plannedQuantity,
                        remainingWeeks = duration
                    )
                    state = state.copy(
                        budget = FinanceEngine().cashDebitBalance(state.budget, cost),
                        researchSpent = state.researchSpent + cost
                    )
                    technicalSpent += cost
                }
            }
        }
        return state
    }

    private fun carryAiGarageToNextSeason(
        garage: TeamGarage,
        nextSeason: Int,
        teamId: Int,
        invested: Long = 0L,
        technicalKnowledge: Map<CarComponent, Int> = emptyMap()
    ): TeamGarage {
        // AI rollover uses the same official Overall x investment table and annual
        // Overall loss/growth bounds as the player. No component-wise euro penalty.
        return development.buildAiNextSeasonGarage(
            previousGarage = garage,
            invested = invested,
            technicalKnowledge = technicalKnowledge
        )
    }

    private fun chooseResearchFocus(garage:TeamGarage, component:CarComponent):ResearchFocus {
        val performance = maxOf(garage.car1.componentValue(component), garage.car2.componentValue(component))
        val reliability = maxOf(garage.car1.componentReliability(component), garage.car2.componentReliability(component))
        return when {
            reliability <= performance - 10 -> ResearchFocus.RELIABILITY
            performance <= reliability - 10 -> ResearchFocus.PERFORMANCE
            reliability < 70 -> ResearchFocus.RELIABILITY
            else -> ResearchFocus.PERFORMANCE
        }
    }

    private fun chooseResearchComplexity(currentOverall: Int, budget: Long): ResearchComplexity {
        val strength = currentOverall.coerceIn(40, 100)
        return when {
            budget >= 120_000_000L && strength >= 80 -> ResearchComplexity.ADVANCED
            budget >= 55_000_000L && strength >= 55 -> ResearchComplexity.MEDIUM
            else -> ResearchComplexity.SIMPLE
        }
    }

    private fun chooseComponent(team:TeamDefinition, garage:TeamGarage, season:Int, week:Int, seedOffset:Int, eligibleComponents: List<CarComponent> = CarComponent.values().toList()):CarComponent {
        val eligible = eligibleComponents.ifEmpty { CarComponent.values().toList() }
        val values = eligible.sortedBy { averageComponent(garage, it) }
        val weakest = values.first()
        val regulation = development.regulationForSeason(season)
        val preferred = when(regulation) {
            CarRegulationFocus.AERODYNAMICS -> listOf(CarComponent.FRONT_WING,CarComponent.REAR_WING,CarComponent.CHASSIS)
            CarRegulationFocus.POWER -> listOf(CarComponent.ENGINE,CarComponent.ELECTRIC_POWER_UNIT,CarComponent.CHASSIS)
            CarRegulationFocus.CORNERING -> listOf(CarComponent.CHASSIS,CarComponent.BRAKES,CarComponent.FRONT_WING)
            CarRegulationFocus.EFFICIENCY -> listOf(CarComponent.ELECTRIC_POWER_UNIT,CarComponent.ENGINE,CarComponent.BRAKES)
            CarRegulationFocus.BALANCED -> emptyList()
        }
        val strategic = preferred.firstOrNull { it in eligible && averageComponent(garage,it) <= averageComponent(garage,weakest) + 3 } ?: weakest
        return if (Math.floorMod(seed + seedOffset + team.id * 37 + week * 11, 100) < 70) strategic else weakest
    }

    private fun averageComponent(g:TeamGarage, c:CarComponent):Int =
        (g.car1.componentValue(c) + g.car2.componentValue(c)) / 2


    private fun targetCar(team:TeamDefinition, piece:CarPiece, week:Int, season:Int, seedOffset:Int):GarageCarId {
        val a = stateValuePlaceholder(team.id, piece.component, week, seedOffset)
        return if (a % 2 == 0) GarageCarId.CAR_1 else GarageCarId.CAR_2
    }

    private fun stateValuePlaceholder(teamId:Int, component:CarComponent, week:Int, seedOffset:Int):Int =
        Math.floorMod(seed + seedOffset + teamId * 19 + component.ordinal * 31 + week * 7, 100)

    private fun initialCar(team:TeamDefinition):TeamCarState = InitialTeamProfile.aiCarState(team)


    private fun legacyFromGarage(g:TeamGarage):TeamCarState {
        val avg = { c:CarComponent -> (g.car1.componentValue(c) + g.car2.componentValue(c)) / 2 }
        val aero = (avg(CarComponent.FRONT_WING) + avg(CarComponent.REAR_WING)) / 2
        val chassis = (avg(CarComponent.CHASSIS) + avg(CarComponent.BRAKES)) / 2
        val engine = (avg(CarComponent.ENGINE) + avg(CarComponent.ELECTRIC_POWER_UNIT)) / 2
        return TeamCarState(
            aerodynamics=aero, chassis=chassis, engine=engine,
            reliability=((g.car1.reliability + g.car2.reliability) / 2),
            frontWing=avg(CarComponent.FRONT_WING), rearWing=avg(CarComponent.REAR_WING),
            brakes=avg(CarComponent.BRAKES), electricPowerUnit=avg(CarComponent.ELECTRIC_POWER_UNIT)
        ).normalized()
    }

}
