package com.f1teammanager.core.manager

import com.f1teammanager.core.season.TeamDefinition

/**
 * Deterministic R&D simulation for teams controlled by the AI.
 * It uses the same project durations/cost bands as the player's R&D, but runs
 * as a virtual weekly program so every team has its own development history.
 */
class AITeamDevelopmentEngine(private val seed:Int = 20261005) {
    data class SimulatedState(val car:TeamCarState, val budget:Long)

    private val development = CarDevelopmentEngine()

    /**
     * Simulates the requested season from the team's historical car chain.
     * AI teams no longer restart from TeamDefinition.baseCar every season:
     * previous-season development is completed, the canonical 70% carry-over
     * is applied, and any recorded previous-season debt penalty is then applied.
     */
    fun simulateFinancial(team:TeamDefinition, elapsedWeeks:Int, season:Int): SimulatedState {
        var car = initialCar(team)
        var budget = initialBudget(team.baseCar)
        if (season < 2026) return SimulatedState(car, budget)

        for (s in 2026 until season) {
            val full = simulateFromCar(team, car, 56, s, budget)
            car = development.carryAiCarToNextSeason(full.car, s + 1)
            budget = initialBudget(team.baseCar)
            if (FinancialSeasonClosureEngine.aiPenaltyActive(team.id, s + 1)) {
                car = FinancialSeasonClosureEngine.applyCarPenalty(car, -1L).car
            }
        }
        return simulateFromCar(team, car, elapsedWeeks.coerceAtLeast(0), season, budget)
    }

    fun simulate(team:TeamDefinition, elapsedWeeks:Int, season:Int): TeamCarState = simulateFinancial(team, elapsedWeeks, season).car

    private fun initialCar(team:TeamDefinition): TeamCarState = TeamCarState(
        aerodynamics=team.baseCar,
        chassis=team.chassis,
        engine=team.engine,
        reliability=team.reliability,
        facilities=initialFacilities(team.baseCar),
        frontWing=team.frontWing,
        rearWing=team.rearWing,
        brakes=team.brakes,
        electricPowerUnit=team.electricPowerUnit
    ).normalized()

    private fun simulateFromCar(team:TeamDefinition, startingCar:TeamCarState, elapsedWeeks:Int, season:Int, startingBudget:Long):SimulatedState {
        if (elapsedWeeks <= 0) return SimulatedState(startingCar, startingBudget)
        var state = SimulatedState(startingCar, startingBudget)
        for (week in 1..elapsedWeeks) {
            if (state.car.activeProject == null) state = startProject(team, state, week, season)
            state = advanceOneWeek(state)
        }
        return state.copy(car=state.car.normalized())
    }

    private fun initialFacilities(strength:Int): Map<Facility,Int> {
        val tier = ((strength - 50) / 12).coerceIn(0,4)
        return mapOf(
            Facility.FACTORY to (3 + tier).coerceIn(1,8),
            Facility.WIND_TUNNEL to (2 + tier).coerceIn(1,8),
            Facility.SIMULATOR to (2 + (tier / 2)).coerceIn(1,8),
            Facility.TESTING to (2 + tier).coerceIn(1,8)
        )
    }

    private fun initialBudget(strength:Int):Long =
        (35_000_000L + strength.coerceIn(50,100) * 650_000L)

    private fun startProject(team:TeamDefinition, state:SimulatedState, week:Int, season:Int):SimulatedState {
        val car=state.car
        val candidates=CarComponent.values().sortedWith(compareBy<CarComponent> { development.componentLevel(car,it) }.thenBy { it.ordinal })
        val regulation=development.regulationForSeason(season)
        val preferred=when(regulation) {
            CarRegulationFocus.AERODYNAMICS -> listOf(CarComponent.FRONT_WING,CarComponent.REAR_WING,CarComponent.CHASSIS)
            CarRegulationFocus.POWER -> listOf(CarComponent.ENGINE,CarComponent.ELECTRIC_POWER_UNIT,CarComponent.CHASSIS)
            CarRegulationFocus.CORNERING -> listOf(CarComponent.CHASSIS,CarComponent.BRAKES,CarComponent.FRONT_WING)
            CarRegulationFocus.EFFICIENCY -> listOf(CarComponent.ELECTRIC_POWER_UNIT,CarComponent.ENGINE,CarComponent.BRAKES)
            CarRegulationFocus.BALANCED -> emptyList()
        }
        val weakest=candidates.first()
        val strategic=preferred.firstOrNull { development.componentLevel(car,it) <= development.componentLevel(car,weakest)+3 } ?: weakest
        val component=if ((seed+team.id*37+week*11)%100 < 68) strategic else weakest
        val options=development.options(TeamManagerState(car=car,finance=TeamFinanceState(state.budget),playerTeamId=team.id),component)
        val strength=team.baseCar
        val intensity=when {
            strength>=90 && state.budget>=options.first { it.intensity==DevelopmentIntensity.AGGRESSIVE }.cost && (seed+team.id+week)%100<55 -> DevelopmentIntensity.AGGRESSIVE
            strength>=78 && (seed+team.id*3+week)%100<62 -> DevelopmentIntensity.ADVANCED
            (seed+team.id*5+week)%100<82 -> DevelopmentIntensity.STANDARD
            else -> DevelopmentIntensity.QUICK
        }
        val option=options.first { it.intensity==intensity }
        if (state.budget < option.cost || car.seasonDevelopmentGain >= 140) return state
        val facility=car.facilities[facilityFor(component)] ?: 1
        val spread=option.maxGain-option.minGain
        val roll=((seed*13 + team.id*97 + week*31 + component.ordinal*17) and Int.MAX_VALUE)%100
        val facilityBonus=((facility-1)/2).coerceAtMost(3)
        val qualityBonus=when {
            strength>=90 -> 2
            strength>=80 -> 1
            strength<65 -> -1
            else -> 0
        }
        val gain=(option.minGain + (spread*roll/100) + facilityBonus + qualityBonus).coerceIn(option.minGain,option.maxGain)
        val project=DevelopmentProject(component,option.weeks,option.weeks,facility,intensity,gain,option.cost)
        return state.copy(car=car.copy(activeProject=project),budget=state.budget-option.cost)
    }

    private fun advanceOneWeek(state:SimulatedState):SimulatedState {
        val p=state.car.activeProject ?: return state
        if (p.remainingWeeks>1) return state.copy(car=state.car.copy(activeProject=p.copy(remainingWeeks=p.remainingWeeks-1)))
        val gain=p.expectedGain.coerceAtLeast(1)
        val c=when(p.component) {
            CarComponent.ENGINE -> state.car.copy(engine=state.car.engine+gain,activeProject=null)
            CarComponent.CHASSIS -> state.car.copy(chassis=state.car.chassis+gain,activeProject=null)
            CarComponent.FRONT_WING -> state.car.copy(frontWing=state.car.frontWing+gain,aerodynamics=maxOf(state.car.aerodynamics,state.car.frontWing+gain),activeProject=null)
            CarComponent.REAR_WING -> state.car.copy(rearWing=state.car.rearWing+gain,aerodynamics=maxOf(state.car.aerodynamics,state.car.rearWing+gain),activeProject=null)
            CarComponent.BRAKES -> state.car.copy(brakes=state.car.brakes+gain,activeProject=null)
            CarComponent.ELECTRIC_POWER_UNIT -> state.car.copy(electricPowerUnit=state.car.electricPowerUnit+gain,activeProject=null)
        }
        return state.copy(car=c.copy(
            developmentKnowledge=c.developmentKnowledge.toMutableMap().apply { this[p.component]=((this[p.component]?:0)+1).coerceAtMost(8) },
            seasonDevelopmentGain=(c.seasonDevelopmentGain+gain).coerceAtMost(140)
        ).normalized())
    }

    private fun facilityFor(component:CarComponent):Facility = when(component) {
        CarComponent.FRONT_WING,CarComponent.REAR_WING -> Facility.WIND_TUNNEL
        CarComponent.CHASSIS -> Facility.FACTORY
        CarComponent.ENGINE -> Facility.TESTING
        CarComponent.BRAKES -> Facility.TESTING
        CarComponent.ELECTRIC_POWER_UNIT -> Facility.SIMULATOR
    }
}
