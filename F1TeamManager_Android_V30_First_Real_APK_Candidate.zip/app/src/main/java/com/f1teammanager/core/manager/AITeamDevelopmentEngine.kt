package com.f1teammanager.core.manager

import com.f1teammanager.core.season.TeamDefinition
import kotlin.math.roundToInt

/**
 * Deterministic AI development using the same conceptual chain as the player:
 * P&D -> design -> factory -> physical pieces -> installation on Car 1/Car 2.
 * The legacy TeamCarState remains only as a compatibility/financial bridge.
 */
internal fun selectAffordableFactoryQuantity(
    unitCost: Long,
    desiredQuantity: Int,
    technicalSpent: Long,
    technicalCap: Long,
    availableBudget: Long,
    maxAllowed: Int = 6
): Int {
    if (unitCost <= 0L || availableBudget < unitCost) return 0
    val desired = desiredQuantity.coerceIn(1, maxAllowed.coerceIn(1, 6))
    return (desired downTo 1).firstOrNull { quantity ->
        technicalSpent.coerceAtLeast(0L) + unitCost * quantity <= technicalCap.coerceAtLeast(0L) &&
            unitCost * quantity <= availableBudget.coerceAtLeast(0L)
    } ?: 0
}

class AITeamDevelopmentEngine(private val seed:Int = 20261005, private val regulationSeed:Int = seed) {
    data class DevelopmentEvent(
        val week: Int,
        val type: Type,
        val component: CarComponent,
        val version: Int,
        val performance: Int,
        val reliability: Int,
        val target: GarageCarId? = null,
        val beforeOverall: Int? = null,
        val afterOverall: Int? = null,
        val pieceId: String? = null
    ) {
        enum class Type { DESIGN_COMPLETED, FACTORY_COMPLETED, PIECE_INSTALLED }
    }

    data class SimulatedState(
        val car:TeamCarState,
        val budget:Long,
        val garage:TeamGarage? = null,
        val facilities:TeamFacilitiesState = TeamFacilitiesState(),
        val events: List<DevelopmentEvent> = emptyList()
    )

    private val development = CarDevelopmentEngine()

    fun simulateFinancial(team:TeamDefinition, elapsedWeeks:Int, season:Int): SimulatedState =
        simulateFinancial(team, elapsedWeeks, season, InitialTeamProfile.initialBudget(team))

    /**
     * Simulates the AI technical pipeline against a caller-provided real cash
     * capacity. The caller must pass current cash + already-spent AI development
     * in this season. This preserves cumulative development spending while making
     * the pipeline unable to spend money that the team does not actually have.
     */
    fun simulateFinancial(team:TeamDefinition, elapsedWeeks:Int, season:Int, startingBudget:Long, startingFacilities:TeamFacilitiesState? = null, nextSeasonInvestments: Map<Int, Long> = emptyMap()): SimulatedState {
        val weeks = elapsedWeeks.coerceAtLeast(0)
        var legacy = initialCar(team)
        val currentSeasonStartingBudget = startingBudget.coerceAtLeast(0L)
        var historicalSeasonBudget = InitialTeamProfile.initialBudget(team)
        var garage = TeamGarageFactory.fromInitial(team)
        // Historical replay must start from the team's canonical baseline. The optional
        // startingFacilities argument is the authoritative persisted state for the target
        // season; seeding the historical loop with it causes replayed prior seasons to
        // overwrite upgrades (including annual-event upgrades) made in the live career.
        var facilities = FacilityEngine.initial(team.initialLevel)
        if (season < 2026) return SimulatedState(legacy, currentSeasonStartingBudget, garage, startingFacilities ?: facilities)

        // Preserve the established season-to-season chain: the completed physical
        // garage of season N is the input for season N+1. The old TeamCarState is
        // derived only as a compatibility/financial summary.
        for (s in 2026 until season) {
            val full = simulatePhysicalSeason(team, garage, 56, s, historicalSeasonBudget, seedOffset = s * 101, facilities = facilities)
            garage = full.garage
            facilities = full.facilities
            legacy = legacyFromGarage(garage).normalized()
            val nextCarInvestment = nextSeasonInvestments[s] ?: 0L
            val carriedLegacy = development.carryAiCarToNextSeason(legacy, s + 1, nextCarInvestment)
            garage = carryAiGarageToNextSeason(garage, s + 1, team.id, nextCarInvestment, legacy.developmentKnowledge)
            // Every AI team receives the same championship rule as the player, after
            // its next-season car is built and before the new season is simulated.
            val rule = AnnualCarRegulationEngine.generateForCalendarYear(s + 1, regulationSeed)
            val teamRegulationSeed = team.id.hashCode()
            garage = AnnualCarRegulationEngine.applyToGarage(garage, rule, teamRegulationSeed)
            legacy = AnnualCarRegulationEngine.applyToCar(carriedLegacy, rule, teamRegulationSeed).let { regulated ->
                legacyFromGarage(garage).copy(
                    aerodynamics = regulated.aerodynamics,
                    chassis = regulated.chassis,
                    engine = regulated.engine,
                    reliability = regulated.reliability
                ).normalized()
            }
            // Historical seasons replay from the canonical opening budget. This
            // must never overwrite the live capacity supplied for the current season.
            historicalSeasonBudget = InitialTeamProfile.initialBudget(team)
            if (FinancialSeasonClosureEngine.aiPenaltyActive(team.id, s + 1)) {
                legacy = FinancialSeasonClosureEngine.applyCarPenalty(legacy, -1L).car
                garage = FinancialSeasonClosureEngine.applyGaragePenalty(garage)
            }
        }
        // Reconstructed car/garage history feeds the next-season car chain, but it must
        // never replace live facility levels supplied by the career's persistent ledger.
        if (startingFacilities != null) facilities = startingFacilities
        val current = simulatePhysicalSeason(team, garage, weeks, season, currentSeasonStartingBudget, seedOffset = season * 101, facilities = facilities)
        garage = current.garage
        facilities = current.facilities
        legacy = if (weeks == 0 && season > 2026) legacy
                 else legacyFromGarage(garage).normalized()
        TechnicalInvestmentEngine.recordLiveOverall(team.id, garage.teamAverageOverall.toDouble())
        return SimulatedState(legacy, current.budget, garage, facilities, current.events)
    }

    fun simulate(team:TeamDefinition, elapsedWeeks:Int, season:Int): TeamCarState = simulateFinancial(team, elapsedWeeks, season).car

    fun simulateGarage(team:TeamDefinition, elapsedWeeks:Int, season:Int): TeamGarage =
        simulateFinancial(team, elapsedWeeks, season).garage ?: TeamGarageFactory.fromInitial(team)


    /**
     * Replays an AI season from the physical car left by a departing Team Principal.
     * This prevents a team from snapping back to its original starter car after a hire.
     */
    fun simulateFinancialFromHandoff(
        team: TeamDefinition,
        elapsedWeeks: Int,
        season: Int,
        handoff: TeamPrincipalTeamHandoff,
        startingBudget: Long,
        startingFacilities: TeamFacilitiesState? = null,
        nextSeasonInvestments: Map<Int, Long> = emptyMap()
    ): SimulatedState {
        require(handoff.teamId == team.id) { "O checkpoint Team Principal pertence a outra equipe." }
        require(season > handoff.closingSeason) { "O checkpoint precisa ser anterior à temporada simulada." }
        val firstNextSeason = handoff.closingSeason + 1
        var garage = carryAiGarageToNextSeason(
            handoff.garage, firstNextSeason, team.id, handoff.nextSeasonInvestment,
            handoff.technicalKnowledge
        )
        var facilities = handoff.facilities
        var currentSeason = firstNextSeason
        fun applyRegulation(targetSeason: Int, source: TeamGarage): TeamGarage {
            val rule = AnnualCarRegulationEngine.generateForCalendarYear(targetSeason, regulationSeed)
            var regulated = AnnualCarRegulationEngine.applyToGarage(source, rule, team.id.hashCode())
            if (FinancialSeasonClosureEngine.aiPenaltyActive(team.id, targetSeason)) {
                regulated = FinancialSeasonClosureEngine.applyGaragePenalty(regulated)
            }
            return regulated
        }
        garage = applyRegulation(firstNextSeason, garage)

        // Seasons between the checkpoint and the requested season are deterministic
        // full-year replays; the requested season itself uses its live week and cash capacity.
        while (currentSeason < season) {
            val historical = simulatePhysicalSeason(
                team, garage, 56, currentSeason, InitialTeamProfile.initialBudget(team),
                seedOffset = currentSeason * 101, facilities = facilities
            )
            garage = historical.garage
            facilities = historical.facilities
            val next = currentSeason + 1
            garage = carryAiGarageToNextSeason(
                garage, next, team.id, nextSeasonInvestments[currentSeason] ?: 0L,
                handoff.technicalKnowledge
            )
            garage = applyRegulation(next, garage)
            currentSeason = next
        }
        val current = simulatePhysicalSeason(
            team, garage, elapsedWeeks.coerceAtLeast(0), season, startingBudget.coerceAtLeast(0L),
            seedOffset = season * 101, facilities = startingFacilities ?: facilities
        )
        val car = legacyFromGarage(current.garage).copy(
            nextSeasonInvestment = nextSeasonInvestments[season] ?: 0L,
            nextSeasonFocus = CarDevelopmentFocus.BALANCED,
            developmentKnowledge = handoff.technicalKnowledge
        ).normalized()
        TechnicalInvestmentEngine.recordLiveOverall(team.id, current.garage.teamAverageOverall.toDouble())
        return SimulatedState(car, current.budget, current.garage, current.facilities, current.events)
    }

    private data class AiPhysicalState(
        val garage:TeamGarage,
        val budget:Long,
        val facilities:TeamFacilitiesState,
        val events: List<DevelopmentEvent> = emptyList()
    )

    private data class AiFactoryBatch(
        val component: CarComponent,
        val version: Int,
        val performance: Int,
        val reliability: Int,
        val quantity: Int,
        val remainingWeeks: Int,
        val orderId: String
    )

    private data class AiResearchProject(
        val component: CarComponent,
        val version: Int,
        val performance: Int,
        val reliability: Int,
        val plannedQuantity: Int,
        val remainingWeeks: Int
    )

    private fun simulatePhysicalSeason(team:TeamDefinition, initial:TeamGarage, elapsedWeeks:Int, season:Int, startingBudget:Long, seedOffset:Int, facilities:TeamFacilitiesState): AiPhysicalState {
        var state = AiPhysicalState(initial, startingBudget, facilities)
        val researchProjects = mutableListOf<AiResearchProject>()

        // AI must obey the same per-component research/version rules as the player.
        // The old implementation used one global version counter, which could make
        // a first Chassi upgrade appear as V4 simply because three other components
        // had been researched before it. It also had no component cooldown, allowing
        // the same component to be researched again as soon as the pipeline freed.
        val componentVersions = CarComponent.values().associateWith { component ->
            maxOf(
                initial.car1.installedPieceVersions[component] ?: 0,
                initial.car2.installedPieceVersions[component] ?: 0
            )
        }.toMutableMap()
        val cooldownUntil = mutableMapOf<CarComponent, Int>()
        val readyDesigns = mutableListOf<AiResearchProject>()
        val factoryOrders = mutableListOf<AiFactoryBatch>()
        var technicalSpent = 0L
        val ranking = TechnicalInvestmentEngine.seasonRanking()[team.id] ?: 40
        val technicalCap = TechnicalInvestmentEngine.ANNUAL_TECHNICAL_CAP

        for (week in 1..elapsedWeeks) {
            // Advance all physical factory orders independently. At higher Factory
            // levels more than one order can exist at the same time, matching the
            // player's parallel-order capacity.
            val continuingOrders = mutableListOf<AiFactoryBatch>()
            factoryOrders.forEach { order ->
                if (order.remainingWeeks > 1) {
                    continuingOrders += order.copy(remainingWeeks = order.remainingWeeks - 1)
                } else {
                    repeat(order.quantity) { n ->
                        val piece = CarPiece(
                            "${order.orderId}-U${n + 1}", order.component, order.version,
                            order.performance, order.reliability, week, season
                        )
                        val target = targetCar(team, piece, week, season, seedOffset)
                        val beforeOverall = state.garage.teamAverageOverall
                        val installedGarage = state.garage.install(piece, target)
                        val afterOverall = installedGarage.teamAverageOverall
                        state = state.copy(
                            garage = installedGarage,
                            events = state.events + DevelopmentEvent(
                                week = week, type = DevelopmentEvent.Type.FACTORY_COMPLETED,
                                component = piece.component, version = piece.version,
                                performance = piece.performance, reliability = piece.reliability,
                                target = target, beforeOverall = beforeOverall,
                                afterOverall = afterOverall, pieceId = piece.pieceId
                            ) + DevelopmentEvent(
                                week = week, type = DevelopmentEvent.Type.PIECE_INSTALLED,
                                component = piece.component, version = piece.version,
                                performance = piece.performance, reliability = piece.reliability,
                                target = target, beforeOverall = beforeOverall,
                                afterOverall = afterOverall, pieceId = piece.pieceId
                            )
                        )
                    }
                }
            }
            factoryOrders.clear()
            factoryOrders.addAll(continuingOrders)

            // Advance every active R&D project independently. The Research Center
            // supports 1/2/3 concurrent projects by level; completed designs can wait
            // in the ready queue if the physical Factory has no free order slot.
            val continuingResearch = mutableListOf<AiResearchProject>()
            val completedResearch = mutableListOf<AiResearchProject>()
            researchProjects.forEach { project ->
                if (project.remainingWeeks > 1) {
                    continuingResearch += project.copy(remainingWeeks = project.remainingWeeks - 1)
                } else {
                    completedResearch += project
                }
            }
            researchProjects.clear()
            researchProjects.addAll(continuingResearch)
            completedResearch.forEach { project ->
                // A completed design is retained until the physical Factory has a
                // free order slot and the budget/technical cap can fund production.
                readyDesigns += project
                componentVersions[project.component] = project.version
                cooldownUntil[project.component] = week + 4
                state = state.copy(events = state.events + DevelopmentEvent(
                    week = week,
                    type = DevelopmentEvent.Type.DESIGN_COMPLETED,
                    component = project.component,
                    version = project.version,
                    performance = project.performance,
                    reliability = project.reliability
                ))
            }

            // Dispatch completed designs into the physical factory. The queue lets
            // research capacity operate independently from factory capacity, just as
            // it does for the player. An unaffordable design waits instead of vanishing.
            val factoryCapacity = FactorySpecification.level(facilities.level(FacilityType.FACTORY)).parallelOrders
            while (readyDesigns.isNotEmpty() && factoryOrders.size < factoryCapacity) {
                val project = readyDesigns.first()
                val factorySpec = FactorySpecification.level(facilities.level(FacilityType.FACTORY))
                val plannedQuantity = project.plannedQuantity.coerceIn(1, factorySpec.maxUnitsPerOrder)
                val plannedDesign = ResearchDesign(
                    "AI-${team.id}-${season}-${week}-${project.component.name}-V${project.version}",
                    project.component, project.version, project.performance, project.reliability, season, week
                )
                val factoryUnitCost = FactoryEngine().manufacturingCost(plannedDesign, facilities, ranking)
                val actualQuantity = selectAffordableFactoryQuantity(
                    unitCost = factoryUnitCost,
                    desiredQuantity = plannedQuantity,
                    technicalSpent = technicalSpent,
                    technicalCap = technicalCap,
                    availableBudget = state.budget,
                    maxAllowed = factorySpec.maxUnitsPerOrder
                )
                if (actualQuantity <= 0) break
                val actualFactoryCost = factoryUnitCost * actualQuantity
                state = state.copy(budget = FinanceEngine().cashDebitBalance(state.budget, actualFactoryCost))
                technicalSpent += actualFactoryCost
                readyDesigns.removeAt(0)
                val orderId = "AI-F-${season}-${week}-${team.id}-${project.component.name}-V${project.version}"
                factoryOrders += AiFactoryBatch(
                    component = project.component,
                    version = project.version,
                    performance = project.performance,
                    reliability = project.reliability,
                    quantity = actualQuantity,
                    remainingWeeks = FactoryEngine().manufacturingWeeks(actualQuantity, facilities),
                    orderId = orderId
                )
            }

            // Factory completion above immediately installs the physical pieces;
            // no inventory/stock exists in the AI simulation.

            // Start one new design per week until the Research Center's own
            // concurrency limit. Its capacity remains independent from the factory;
            // completed designs wait in readyDesigns until a production slot opens.
            val researchCapacity = ResearchEngine().activeProjectCapacity(facilities.level(FacilityType.RESEARCH))
            if (researchProjects.size < researchCapacity) {
                val activeComponents = (researchProjects.map { it.component } + readyDesigns.map { it.component } + factoryOrders.map { it.component }).toSet()
                val eligibleComponents = CarComponent.values().filter {
                    week >= (cooldownUntil[it] ?: 0) && it !in activeComponents
                }
                if (eligibleComponents.isEmpty()) continue
                val component = chooseComponent(team, state.garage, season, week, seedOffset, eligibleComponents)
                // IA chooses the same P&D inputs available to the player:
                // complexity, focus, component and investment. The mechanics below
                // are the ResearchEngine mechanics, not a separate AI formula.
                val research = ResearchEngine()
                val currentOverall = state.garage.teamAverageOverall
                val complexity = chooseResearchComplexity(currentOverall, state.budget)
                val researchLevel = facilities.level(FacilityType.RESEARCH)
                val duration = research.calculatedWeeks(facilities, component, complexity)
                // The AI uses the same P&D + Wind Tunnel + Simulator time and
                // facility-adjusted price as the player's ResearchEngine options.
                val cost = research.facilityAdjustedCost(research.baseCost(complexity), facilities, ranking)
                val basePerformance = maxOf(
                    state.garage.car1.componentValue(component),
                    state.garage.car2.componentValue(component)
                )
                val baseReliability = maxOf(
                    state.garage.car1.componentReliability(component),
                    state.garage.car2.componentReliability(component)
                )
                val maxRange = research.maxImprovement(facilities, component, basePerformance)
                val baseGain = if (maxRange.first == maxRange.last) maxRange.first
                               else maxRange.first + Math.floorMod(seed + seedOffset + team.id * 13 + week * 17, maxRange.last - maxRange.first + 1)
                val bonusRange = research.complexityBonus(complexity, basePerformance)
                val bonusGain = if (bonusRange.first == bonusRange.last) bonusRange.first
                                else bonusRange.first + Math.floorMod(seed + seedOffset + team.id * 19 + week * 23, bonusRange.last - bonusRange.first + 1)
                val totalGain = baseGain + bonusGain
                val outcomeRoll = Math.floorMod(seed + seedOffset + team.id * 29 + week * 31, 100)
                val failure = research.failureChance(researchLevel, complexity)
                val partial = when (complexity) {
                    ResearchComplexity.SIMPLE -> 10
                    ResearchComplexity.MEDIUM -> 15
                    ResearchComplexity.ADVANCED -> 20
                    ResearchComplexity.EXPERIMENTAL -> 25
                }.let { (it - researchLevel).coerceAtLeast(5) }
                val outcome = when {
                    outcomeRoll < failure -> ResearchOutcome.FAILURE
                    outcomeRoll < failure + partial -> ResearchOutcome.PARTIAL
                    else -> ResearchOutcome.SUCCESS
                }
                val effectiveGain = when (outcome) {
                    ResearchOutcome.SUCCESS -> totalGain
                    ResearchOutcome.PARTIAL -> (totalGain * 0.5).roundToInt()
                    ResearchOutcome.FAILURE -> 0
                }
                val focus = chooseResearchFocus(state.garage, component)
                val (performanceGain, reliabilityGain) = research.splitGain(effectiveGain, focus)
                val plannedReliability = (baseReliability + reliabilityGain).coerceAtMost(100)
                val plannedPerformance = (basePerformance + performanceGain).coerceAtMost(100)
                val nextVersion = (componentVersions[component] ?: 0) + 1
                // Desired batch size scales with the official Factory specification.
                // The live cash and annual technical cap still reduce it safely.
                val factorySpec = FactorySpecification.level(facilities.level(FacilityType.FACTORY))
                val quantityRoll = Math.floorMod(seed + seedOffset + team.id + week, 100)
                val desiredQuantity = when (factorySpec.maxUnitsPerOrder) {
                    1 -> 1
                    2 -> if (quantityRoll < 55) 2 else 1
                    3 -> when { quantityRoll < 25 -> 3; quantityRoll < 75 -> 2; else -> 1 }
                    4 -> when { quantityRoll < 15 -> 4; quantityRoll < 45 -> 3; quantityRoll < 80 -> 2; else -> 1 }
                    5 -> when { quantityRoll < 10 -> 5; quantityRoll < 30 -> 4; quantityRoll < 60 -> 3; quantityRoll < 85 -> 2; else -> 1 }
                    else -> when { quantityRoll < 10 -> 6; quantityRoll < 25 -> 5; quantityRoll < 45 -> 4; quantityRoll < 70 -> 3; quantityRoll < 90 -> 2; else -> 1 }
                }
                val estimatedDesign = ResearchDesign("AI-PREVIEW-${team.id}-${season}-${week}", component, nextVersion, plannedPerformance, plannedReliability, season, week)
                val unitFactoryCost = FactoryEngine().manufacturingCost(estimatedDesign, facilities, ranking)
                val plannedQuantity = selectAffordableFactoryQuantity(
                    unitCost = unitFactoryCost,
                    desiredQuantity = desiredQuantity,
                    // Reserve the just-selected design cost before deciding how many
                    // physical units the shared annual cap can still support.
                    technicalSpent = technicalSpent + cost,
                    technicalCap = technicalCap,
                    availableBudget = (state.budget - cost).coerceAtLeast(0L),
                    maxAllowed = factorySpec.maxUnitsPerOrder
                )
                val estimatedFactory = unitFactoryCost * plannedQuantity
                if (plannedQuantity > 0 && technicalSpent + cost + estimatedFactory <= technicalCap && state.budget >= cost + estimatedFactory) {
                    researchProjects += AiResearchProject(
                        component = component,
                        version = nextVersion,
                        performance = plannedPerformance,
                        reliability = plannedReliability,
                        plannedQuantity = plannedQuantity,
                        remainingWeeks = duration
                    )
                    state = state.copy(budget = FinanceEngine().cashDebitBalance(state.budget, cost))
                    technicalSpent += cost
                }
            }
        }
        return state
    }

    private fun carryAiGarageToNextSeason(
        garage: TeamGarage,
        nextSeason: Int,
        teamId: Int,
        invested: Long = 0L,
        technicalKnowledge: Map<CarComponent, Int> = emptyMap()
    ): TeamGarage {
        // AI builds toward its planned performance target. Any unspent part of that
        // target becomes a transparent component loss: €1M shortfall = 1 point,
        // capped at 10 points per installed component and per season rollover.
        return development.buildAiNextSeasonGarage(
            previousGarage = garage,
            invested = invested,
            technicalKnowledge = technicalKnowledge
        )
    }

    private fun chooseResearchFocus(garage:TeamGarage, component:CarComponent):ResearchFocus {
        val performance = maxOf(garage.car1.componentValue(component), garage.car2.componentValue(component))
        val reliability = maxOf(garage.car1.componentReliability(component), garage.car2.componentReliability(component))
        return when {
            reliability <= performance - 10 -> ResearchFocus.RELIABILITY
            performance <= reliability - 10 -> ResearchFocus.PERFORMANCE
            reliability < 70 -> ResearchFocus.RELIABILITY
            else -> ResearchFocus.PERFORMANCE
        }
    }

    private fun chooseResearchComplexity(currentOverall: Int, budget: Long): ResearchComplexity {
        val strength = currentOverall.coerceIn(40, 100)
        return when {
            budget >= 120_000_000L && strength >= 80 -> ResearchComplexity.ADVANCED
            budget >= 55_000_000L && strength >= 55 -> ResearchComplexity.MEDIUM
            else -> ResearchComplexity.SIMPLE
        }
    }

    private fun chooseComponent(team:TeamDefinition, garage:TeamGarage, season:Int, week:Int, seedOffset:Int, eligibleComponents: List<CarComponent> = CarComponent.values().toList()):CarComponent {
        val eligible = eligibleComponents.ifEmpty { CarComponent.values().toList() }
        val values = eligible.sortedBy { averageComponent(garage, it) }
        val weakest = values.first()
        val regulation = development.regulationForSeason(season)
        val preferred = when(regulation) {
            CarRegulationFocus.AERODYNAMICS -> listOf(CarComponent.FRONT_WING,CarComponent.REAR_WING,CarComponent.CHASSIS)
            CarRegulationFocus.POWER -> listOf(CarComponent.ENGINE,CarComponent.ELECTRIC_POWER_UNIT,CarComponent.CHASSIS)
            CarRegulationFocus.CORNERING -> listOf(CarComponent.CHASSIS,CarComponent.BRAKES,CarComponent.FRONT_WING)
            CarRegulationFocus.EFFICIENCY -> listOf(CarComponent.ELECTRIC_POWER_UNIT,CarComponent.ENGINE,CarComponent.BRAKES)
            CarRegulationFocus.BALANCED -> emptyList()
        }
        val strategic = preferred.firstOrNull { it in eligible && averageComponent(garage,it) <= averageComponent(garage,weakest) + 3 } ?: weakest
        return if (Math.floorMod(seed + seedOffset + team.id * 37 + week * 11, 100) < 70) strategic else weakest
    }

    private fun averageComponent(g:TeamGarage, c:CarComponent):Int =
        (g.car1.componentValue(c) + g.car2.componentValue(c)) / 2


    private fun targetCar(team:TeamDefinition, piece:CarPiece, week:Int, season:Int, seedOffset:Int):GarageCarId {
        val a = stateValuePlaceholder(team.id, piece.component, week, seedOffset)
        return if (a % 2 == 0) GarageCarId.CAR_1 else GarageCarId.CAR_2
    }

    private fun stateValuePlaceholder(teamId:Int, component:CarComponent, week:Int, seedOffset:Int):Int =
        Math.floorMod(seed + seedOffset + teamId * 19 + component.ordinal * 31 + week * 7, 100)

    private fun initialCar(team:TeamDefinition):TeamCarState = InitialTeamProfile.aiCarState(team)


    private fun legacyFromGarage(g:TeamGarage):TeamCarState {
        val avg = { c:CarComponent -> (g.car1.componentValue(c) + g.car2.componentValue(c)) / 2 }
        val aero = (avg(CarComponent.FRONT_WING) + avg(CarComponent.REAR_WING)) / 2
        val chassis = (avg(CarComponent.CHASSIS) + avg(CarComponent.BRAKES)) / 2
        val engine = (avg(CarComponent.ENGINE) + avg(CarComponent.ELECTRIC_POWER_UNIT)) / 2
        return TeamCarState(
            aerodynamics=aero, chassis=chassis, engine=engine,
            reliability=((g.car1.reliability + g.car2.reliability) / 2),
            frontWing=avg(CarComponent.FRONT_WING), rearWing=avg(CarComponent.REAR_WING),
            brakes=avg(CarComponent.BRAKES), electricPowerUnit=avg(CarComponent.ELECTRIC_POWER_UNIT)
        ).normalized()
    }

}
