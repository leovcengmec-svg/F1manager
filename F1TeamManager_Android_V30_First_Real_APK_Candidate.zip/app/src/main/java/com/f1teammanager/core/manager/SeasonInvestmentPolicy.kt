package com.f1teammanager.core.manager

/**
 * Shared financial guardrails for next-season car investment.
 *
 * There is no per-phase percentage cap. Investment is limited only by cash
 * remaining after the protected operating reserve and the independent €150M
 * absolute ceiling. The round argument remains for call-site compatibility.
 */
object SeasonInvestmentPolicy {
    fun phasePercent(round: Int): Int = when (round.coerceIn(1, 30)) {
        in 1..8 -> 10
        in 9..15 -> 15
        in 16..22 -> 25
        else -> 35
    }

    fun protectedCash(budget: Long): Long {
        if (budget <= 0L) return 0L
        // Keep at least 20% of available cash for current-season operations.
        return (budget / 5L).coerceAtLeast(2_000_000L).coerceAtMost(budget)
    }


    /** Real cash ring-fenced for the next-season car, without creating artificial funds. */
    fun aiNextCarReserve(budget: Long): Long {
        val cash = budget.coerceAtLeast(0L)
        return (cash / 10L).coerceAtLeast(2_000_000L).coerceAtMost(cash)
    }

    /** Cash the deterministic AI P&D replay may consume after operating and car reserves. */
    fun aiDevelopmentSpendableCash(budget: Long): Long {
        val cash = budget.coerceAtLeast(0L)
        val protected = maxOf(protectedCash(cash), aiNextCarReserve(cash)).coerceAtMost(cash)
        return (cash - protected).coerceAtLeast(0L)
    }

    fun maximumCumulativeInvestment(budget: Long, round: Int, overallCap: Long): Long {
        if (budget <= 0L || overallCap <= 0L) return 0L
        val spendableBudget = (budget - protectedCash(budget)).coerceAtLeast(0L)
        return spendableBudget.coerceAtMost(overallCap)
    }

    /**
     * Minimum liquidity target for AI discretionary spending.
     *
     * Keep the next GP's expected salary installment and race operating cost,
     * plus a small cash buffer. Reserving every remaining GP's costs up front
     * incorrectly assumes zero future sponsor/race income; that made AI teams
     * unable to invest in next season's car even late in the championship.
     */
    fun aiOperatingReserve(annualDriverSalaries: Long, round: Int, raceCostPerGp: Long = 850_000L): Long {
        val salaryInstallment = annualDriverSalaries.coerceAtLeast(0L) / 30L
        val nextRaceCost = raceCostPerGp.coerceAtLeast(0L)
        // At the end of the season there is no further GP operating cost to reserve.
        val raceReserve = if (round.coerceIn(1, 30) >= 30) 0L else nextRaceCost
        return (salaryInstallment + raceReserve + 2_000_000L).coerceAtLeast(2_000_000L)
    }

    fun aiSpendableCash(budget: Long, annualDriverSalaries: Long, round: Int, raceCostPerGp: Long = 850_000L): Long =
        (budget.coerceAtLeast(0L) - aiOperatingReserve(annualDriverSalaries, round, raceCostPerGp)).coerceAtLeast(0L)

    /**
     * Final amount allowed for one AI contribution after the ambition target has
     * been chosen. Keeps the transfer inside cash, absolute-cap and target boundaries.
     */
    fun allowedNextCarInvestmentAmount(
        roomUnderCaps: Long,
        spendableCash: Long,
        targetCost: Long,
        alreadyInvested: Long,
        desiredChunk: Long
    ): Long {
        val targetGap = (targetCost.coerceAtLeast(0L) - alreadyInvested.coerceAtLeast(0L)).coerceAtLeast(0L)
        return minOf(
            roomUnderCaps.coerceAtLeast(0L),
            spendableCash.coerceAtLeast(0L),
            targetGap,
            desiredChunk.coerceAtLeast(0L)
        ).coerceAtLeast(0L)
    }

    /**
     * Contribution target for the next-season car, based on the remaining amount
     * needed to preserve current performance, spread over the remaining GPs.
     * This is a target only; callers must still apply cash, reserve and absolute cap.
     */
    fun plannedNextCarContribution(referenceCost: Long, alreadyInvested: Long, round: Int, minimumChunk: Long): Long {
        val gap = (referenceCost.coerceAtLeast(0L) - alreadyInvested.coerceAtLeast(0L)).coerceAtLeast(0L)
        if (gap == 0L) return 0L
        val remainingGps = (31 - round.coerceIn(1, 30)).coerceAtLeast(1)
        val perGpTarget = (gap + remainingGps - 1L) / remainingGps
        return maxOf(minimumChunk.coerceAtLeast(0L), perGpTarget)
    }
}
