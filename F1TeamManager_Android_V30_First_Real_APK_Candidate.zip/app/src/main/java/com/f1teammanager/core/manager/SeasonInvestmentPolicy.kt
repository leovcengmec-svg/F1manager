package com.f1teammanager.core.manager

/**
 * Shared financial guardrails for next-season car investment.
 *
 * The cap is cumulative for the whole season (it never resets per GP). It is
 * based on cash left after a protected operating buffer, and is deliberately
 * stricter early in the championship so current-season development remains viable.
 */
object SeasonInvestmentPolicy {
    fun phasePercent(round: Int): Int = when (round.coerceIn(1, 30)) {
        in 1..8 -> 10
        in 9..15 -> 15
        in 16..22 -> 25
        else -> 35
    }

    fun protectedCash(budget: Long): Long {
        if (budget <= 0L) return 0L
        // Keep at least 20% of available cash for current-season operations.
        return (budget / 5L).coerceAtLeast(2_000_000L).coerceAtMost(budget)
    }

    fun maximumCumulativeInvestment(budget: Long, round: Int, overallCap: Long): Long {
        if (budget <= 0L || overallCap <= 0L) return 0L
        val freeBudget = (budget - protectedCash(budget)).coerceAtLeast(0L)
        val phaseCap = freeBudget * phasePercent(round) / 100L
        return phaseCap.coerceAtMost(overallCap)
    }

    /** Minimum liquidity target used by AI discretionary-spending decisions. */
    fun aiOperatingReserve(annualDriverSalaries: Long, round: Int, raceCostPerGp: Long = 850_000L): Long {
        val remainingGps = (31 - round.coerceIn(1, 30)).coerceAtLeast(0)
        val salaryRunway = (annualDriverSalaries.coerceAtLeast(0L) * remainingGps) / 30L
        val raceRunway = raceCostPerGp.coerceAtLeast(0L) * remainingGps
        return (salaryRunway + raceRunway + 2_000_000L).coerceAtLeast(2_000_000L)
    }

    fun aiSpendableCash(budget: Long, annualDriverSalaries: Long, round: Int, raceCostPerGp: Long = 850_000L): Long =
        (budget.coerceAtLeast(0L) - aiOperatingReserve(annualDriverSalaries, round, raceCostPerGp)).coerceAtLeast(0L)
}
