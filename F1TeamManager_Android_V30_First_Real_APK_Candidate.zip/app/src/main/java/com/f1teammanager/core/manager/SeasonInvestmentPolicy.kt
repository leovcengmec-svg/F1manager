package com.f1teammanager.core.manager

/**
 * Shared financial guardrails for next-season car investment.
 *
 * Shared priority table for AI technical development and next-season car investment.
 * The phase percentage is an allocation priority for next-car investment, not a
 * cumulative project cap: current-season development retains the remainder after
 * payroll/race operating reserves, while the next-car share is protected from P&D.
 * The next car still has an independent €150M absolute ceiling.
 */
object SeasonInvestmentPolicy {
    /** AI's fixed strategic split of its annual discretionary development envelope. */
    const val AI_NEXT_SEASON_CAR_PERCENT = 40
    const val AI_CURRENT_SEASON_CAR_PERCENT = 40
    const val AI_FACILITIES_PERCENT = 20

    fun phasePercent(round: Int): Int = AI_NEXT_SEASON_CAR_PERCENT

    fun aiCurrentCarAnnualLimit(annualCap: Long): Long =
        annualCap.coerceAtLeast(0L) * AI_CURRENT_SEASON_CAR_PERCENT / 100L

    fun aiFacilitiesAnnualLimit(annualCap: Long): Long =
        annualCap.coerceAtLeast(0L) * AI_FACILITIES_PERCENT / 100L

    fun aiNextSeasonCarAnnualLimit(annualCap: Long): Long =
        annualCap.coerceAtLeast(0L) * AI_NEXT_SEASON_CAR_PERCENT / 100L

    fun remainingAiCurrentCarAllocation(investment: TechnicalInvestmentState): Long =
        (aiCurrentCarAnnualLimit(investment.annualCap) - investment.researchDesignSpent - investment.fabricationSpent).coerceAtLeast(0L)

    fun remainingAiFacilitiesAllocation(investment: TechnicalInvestmentState): Long =
        (aiFacilitiesAnnualLimit(investment.annualCap) - investment.facilityUpgradeSpent).coerceAtLeast(0L)

    fun protectedCash(budget: Long): Long {
        if (budget <= 0L) return 0L
        // Keep at least 20% of available cash for current-season operations.
        return (budget / 5L).coerceAtLeast(2_000_000L).coerceAtMost(budget)
    }


    /**
     * Percent of current liquidity prioritized for next-season car funding.
     * This is deliberately a funding allocation, not a hard cap on cumulative
     * investment: unused allocation remains available later if income arrives.
     */
    fun nextCarPriorityPercent(round: Int): Int = AI_NEXT_SEASON_CAR_PERCENT

    /** Cash kept aside from current-season discretionary technical spending. */
    fun aiNextCarReserve(budget: Long, round: Int = 1): Long {
        val cash = budget.coerceAtLeast(0L)
        return (cash * nextCarPriorityPercent(round).toLong() / 100L).coerceAtMost(cash)
    }

    /** Cash available for current-season technical development after both priorities. */
    fun aiDevelopmentSpendableCash(budget: Long, round: Int = 1): Long {
        val cash = budget.coerceAtLeast(0L)
        val protected = maxOf(protectedCash(cash), aiNextCarReserve(cash, round)).coerceAtMost(cash)
        return (cash - protected).coerceAtLeast(0L)
    }

    fun maximumCumulativeInvestment(budget: Long, round: Int, overallCap: Long): Long {
        // This method now returns only the absolute project ceiling. Available cash
        // and protected operating reserve are validated independently at each debit.
        // Never freeze a cumulative ceiling from an earlier cash snapshot: incoming
        // sponsorship/prizes must be able to restore investment capacity.
        return overallCap.coerceAtLeast(0L)
    }

    /**
     * Minimum liquidity target for AI discretionary spending.
     *
     * Keep the next GP's expected salary installment and race operating cost,
     * plus a small cash buffer. Reserving every remaining GP's costs up front
     * incorrectly assumes zero future sponsor/race income; that made AI teams
     * unable to invest in next season's car even late in the championship.
     */
    fun aiOperatingReserve(annualDriverSalaries: Long, round: Int, raceCostPerGp: Long = 850_000L): Long {
        val salaryInstallment = annualDriverSalaries.coerceAtLeast(0L) / 30L
        val nextRaceCost = raceCostPerGp.coerceAtLeast(0L)
        // At the end of the season there is no further GP operating cost to reserve.
        val raceReserve = if (round.coerceIn(1, 30) >= 30) 0L else nextRaceCost
        return (salaryInstallment + raceReserve + 2_000_000L).coerceAtLeast(2_000_000L)
    }

    fun aiSpendableCash(budget: Long, annualDriverSalaries: Long, round: Int, raceCostPerGp: Long = 850_000L): Long =
        (budget.coerceAtLeast(0L) - aiOperatingReserve(annualDriverSalaries, round, raceCostPerGp)).coerceAtLeast(0L)

    /**
     * Final amount allowed for one AI contribution after the ambition target has
     * been chosen. Keeps the transfer inside cash, absolute-cap and target boundaries.
     */
    fun allowedNextCarInvestmentAmount(
        roomUnderCaps: Long,
        spendableCash: Long,
        targetCost: Long,
        alreadyInvested: Long,
        desiredChunk: Long
    ): Long {
        val targetGap = (targetCost.coerceAtLeast(0L) - alreadyInvested.coerceAtLeast(0L)).coerceAtLeast(0L)
        return minOf(
            roomUnderCaps.coerceAtLeast(0L),
            spendableCash.coerceAtLeast(0L),
            targetGap,
            desiredChunk.coerceAtLeast(0L)
        ).coerceAtLeast(0L)
    }

    /**
     * Contribution target for the next-season car, based on the remaining amount
     * needed to preserve current performance, spread over the remaining GPs.
     * This is a target only; callers must still apply cash, reserve and absolute cap.
     */
    fun plannedNextCarContribution(referenceCost: Long, alreadyInvested: Long, round: Int, minimumChunk: Long): Long {
        val gap = (referenceCost.coerceAtLeast(0L) - alreadyInvested.coerceAtLeast(0L)).coerceAtLeast(0L)
        if (gap == 0L) return 0L
        val remainingGps = (31 - round.coerceIn(1, 30)).coerceAtLeast(1)
        val perGpTarget = (gap + remainingGps - 1L) / remainingGps
        return maxOf(minimumChunk.coerceAtLeast(0L), perGpTarget)
    }
}
