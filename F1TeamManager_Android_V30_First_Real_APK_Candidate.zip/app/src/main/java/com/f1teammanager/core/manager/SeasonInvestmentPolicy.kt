package com.f1teammanager.core.manager

/**
 * Financial guardrails for two independent annual investment envelopes:
 * €200M for current-car development and facilities, plus €150M for next-season car construction.
 * Cash allocation is guided by a dynamic AI mindset; percentages are priorities, not mandatory spend.
 */
enum class AIInvestmentMindset(val label: String, val currentAndFacilitiesPercent: Int, val currentCarPercentOfPool: Int, val facilitiesPercentOfPool: Int, val nextCarPercent: Int) {
    STANDARD("Padrão", 50, 60, 40, 50),
    DOMINANT_CAR("Carro dominante", 30, 30, 70, 70),
    TITLE_FIGHT("Disputa pelo título", 60, 70, 30, 40),
    NEXT_SEASON_REBUILD("Preparação da próxima temporada", 40, 0, 100, 60)
}

object SeasonInvestmentPolicy {
    /** AI's reference priorities; these percentages must not be enforced as hard category caps. */
    const val AI_NEXT_SEASON_CAR_PERCENT = 50
    const val AI_CURRENT_SEASON_CAR_PERCENT = 60
    const val AI_FACILITIES_PERCENT = 40
    const val AI_ANNUAL_TECHNICAL_ENVELOPE = 200_000_000L

    fun phasePercent(round: Int): Int = AI_NEXT_SEASON_CAR_PERCENT

    /** Strategic mindset selection. Ranking is the current technical/competitive tier (1 = strongest). */
    fun selectAiMindset(round: Int, ranking: Int, currentOverall: Int, gapToSecondBest: Int = 0, inTitleFight: Boolean = false): AIInvestmentMindset {
        val rank = ranking.coerceIn(1, 40)
        if (gapToSecondBest >= 5 && currentOverall >= 75 && rank <= 8) return AIInvestmentMindset.DOMINANT_CAR
        if (inTitleFight) return AIInvestmentMindset.TITLE_FIGHT
        if (round >= 21 && rank >= 17) return AIInvestmentMindset.NEXT_SEASON_REBUILD
        return AIInvestmentMindset.STANDARD
    }

    fun nextCarAnnualCap(): Long = AI_NEXT_CAR_ABSOLUTE_CAP

    /** The technical envelope is independent from next-car construction. */
    fun remainingCurrentAndFacilityEnvelope(annualCap: Long, alreadySpent: Long): Long =
        (annualCap.coerceAtLeast(0L) - alreadySpent.coerceAtLeast(0L)).coerceAtLeast(0L)

    /** Informational target for planning and UI; never use as a hard category ceiling. */
    fun aiCurrentCarAnnualLimit(annualCap: Long): Long =
        annualCap.coerceAtLeast(0L) * AI_CURRENT_SEASON_CAR_PERCENT / 100L

    /** Informational target for planning and UI; facilities may exceed it from shared headroom. */
    fun aiFacilitiesAnnualLimit(annualCap: Long): Long =
        annualCap.coerceAtLeast(0L) * AI_FACILITIES_PERCENT / 100L

    /** Informational target for planning and UI; next-car investments can exceed it up to €150M. */
    fun aiNextSeasonCarAnnualLimit(annualCap: Long): Long = AI_NEXT_CAR_ABSOLUTE_CAP

    /** Reference target only. Live AI P&D can use the shared envelope left by other priorities. */
    fun remainingAiCurrentCarAllocation(investment: TechnicalInvestmentState): Long =
        (aiCurrentCarAnnualLimit(investment.annualCap) - investment.researchDesignSpent - investment.fabricationSpent).coerceAtLeast(0L)

    fun remainingAiFacilitiesAllocation(investment: TechnicalInvestmentState): Long =
        (aiFacilitiesAnnualLimit(investment.annualCap) - investment.facilityUpgradeSpent).coerceAtLeast(0L)

    fun protectedCash(budget: Long): Long {
        if (budget <= 0L) return 0L
        // Player-facing reserve: preserve the established 20% rule.
        return (budget / 5L).coerceAtLeast(2_000_000L).coerceAtMost(budget)
    }

    /** AI liquidity buffer with a ceiling: a rich team should not freeze 20% of a
     * multi-hundred-million balance when its actual annual operating runway is finite. */
    fun aiProtectedCash(budget: Long): Long {
        val cash = budget.coerceAtLeast(0L)
        if (cash == 0L) return 0L
        return minOf((cash / 5L).coerceAtLeast(2_000_000L), 50_000_000L, cash)
    }


    /**
     * Default share of discretionary liquidity prioritized for next-season car funding.
     * The strategic mindset overload selects 40%, 50%, 60% or 70% as appropriate.
     */
    fun nextCarPriorityPercent(round: Int): Int = 50

    fun nextCarPriorityPercent(mindset: AIInvestmentMindset): Int = mindset.nextCarPercent

    /**
     * Releases the cash-priority reservation when the independent next-car annual
     * envelope is fully consumed. AIInvestmentMindset is an enum (not a data class),
     * so callers must derive this effective percentage instead of calling copy().
     */
    fun effectiveNextCarPriorityPercent(
        mindset: AIInvestmentMindset,
        nextCarAlreadyInvested: Long
    ): Int = if (nextCarAlreadyInvested >= AI_NEXT_CAR_ABSOLUTE_CAP) 0
        else mindset.nextCarPercent.coerceIn(0, 100)

    /**
     * Protected next-car priority within its independent €150M annual envelope.
     * The selected strategic mindset controls the cash share; it never consumes the
     * separate €200M current-car/facilities envelope.
     */
    fun aiNextCarReserve(
        budget: Long,
        round: Int = 1,
        alreadyInvested: Long = 0L,
        annualEnvelopeRemaining: Long = AI_NEXT_CAR_ABSOLUTE_CAP,
        targetSatisfied: Boolean = false,
        priorityPercent: Int = 50
    ): Long {
        val cash = budget.coerceAtLeast(0L)
        val projectRoom = (AI_NEXT_CAR_ABSOLUTE_CAP - alreadyInvested.coerceAtLeast(0L)).coerceAtLeast(0L)
        val envelopeRoom = (AI_NEXT_CAR_ABSOLUTE_CAP - alreadyInvested.coerceAtLeast(0L)).coerceAtLeast(0L)
        if (targetSatisfied) return 0L
        // Priority percentage controls how much discretionary cash is ring-fenced;
        // the only cumulative ceiling is the independent €150M annual project cap.
        val priorityGap = projectRoom
        // Ring-fence the share selected by the active strategic mindset.
        // Operating reserves are protected independently by the caller.
        val priorityCash = cash * priorityPercent.coerceIn(0, 100).toLong() / 100L
        return minOf(cash, projectRoom, priorityGap, priorityCash, envelopeRoom).coerceAtLeast(0L)
    }

    /** Cash available for current-season technical development after operating and next-car reserves. */
    fun aiDevelopmentSpendableCash(
        budget: Long,
        round: Int = 1,
        nextCarAlreadyInvested: Long = 0L,
        annualEnvelopeRemaining: Long = 200_000_000L,
        nextCarPriorityPercent: Int = 50
    ): Long {
        val cash = budget.coerceAtLeast(0L)
        val protected = maxOf(
            aiProtectedCash(cash),
            aiNextCarReserve(cash, round, nextCarAlreadyInvested, annualEnvelopeRemaining, priorityPercent = nextCarPriorityPercent)
        ).coerceAtMost(cash)
        return (cash - protected).coerceAtLeast(0L)
    }

    /**
     * Remaining room in the independent €200M current-car/facilities envelope.
     * Next-car funding has its own €150M ledger and is not deducted here.
     */
    fun aiCurrentAndFacilityEnvelopeRemaining(
        budget: Long,
        round: Int,
        nextCarAlreadyInvested: Long,
        annualEnvelopeRemaining: Long,
        nextCarTargetSatisfied: Boolean = false
    ): Long {
        // Next-car funding has its own €150M envelope and never consumes this €200M pool.
        return annualEnvelopeRemaining.coerceAtLeast(0L)
    }

    /**
     * A facility upgrade can use any genuinely uncommitted amount in the shared
     * current-car/facility pool. The 20% facilities share is a priority reference,
     * not a yearly cap.
     */
    fun allowedAiFacilityInvestmentAmount(
        requestedCost: Long,
        spendableCash: Long,
        annualEnvelopeRemaining: Long,
        forecastHeadroom: Long = Long.MAX_VALUE
    ): Long = minOf(
        requestedCost.coerceAtLeast(0L),
        spendableCash.coerceAtLeast(0L),
        annualEnvelopeRemaining.coerceAtLeast(0L),
        forecastHeadroom.coerceAtLeast(0L)
    ).coerceAtLeast(0L)

    const val AI_NEXT_CAR_ABSOLUTE_CAP = 150_000_000L

    /** Independent €200M envelope for current-car work and facilities. Legacy third argument is ignored. */
    fun remainingAnnualTechnicalEnvelope(
        annualCap: Long,
        alreadySpentTechnical: Long,
        @Suppress("UNUSED_PARAMETER") nextCarAlreadyInvested: Long
    ): Long = (annualCap.coerceAtLeast(0L) - alreadySpentTechnical.coerceAtLeast(0L)).coerceAtLeast(0L)

    fun maximumCumulativeInvestment(budget: Long, round: Int, overallCap: Long): Long {
        // This method now returns only the absolute project ceiling. Available cash
        // and protected operating reserve are validated independently at each debit.
        // Never freeze a cumulative ceiling from an earlier cash snapshot: incoming
        // sponsorship/prizes must be able to restore investment capacity.
        return overallCap.coerceAtLeast(0L)
    }

    /**
     * Minimum liquidity target for AI discretionary spending.
     *
     * Keep the next GP's expected salary installment and race operating cost,
     * plus a small cash buffer. Reserving every remaining GP's costs up front
     * incorrectly assumes zero future sponsor/race income; that made AI teams
     * unable to invest in next season's car even late in the championship.
     */
    fun aiOperatingReserve(annualDriverSalaries: Long, round: Int, raceCostPerGp: Long = 850_000L): Long {
        val salaryInstallment = annualDriverSalaries.coerceAtLeast(0L) / 30L
        val nextRaceCost = raceCostPerGp.coerceAtLeast(0L)
        // At the end of the season there is no further GP operating cost to reserve.
        val raceReserve = if (round.coerceIn(1, 30) >= 30) 0L else nextRaceCost
        return (salaryInstallment + raceReserve + 2_000_000L).coerceAtLeast(2_000_000L)
    }

    fun aiSpendableCash(budget: Long, annualDriverSalaries: Long, round: Int, raceCostPerGp: Long = 850_000L): Long =
        (budget.coerceAtLeast(0L) - aiOperatingReserve(annualDriverSalaries, round, raceCostPerGp)).coerceAtLeast(0L)

    /**
     * Final amount allowed for one AI contribution after the ambition target has
     * been chosen. Keeps the transfer inside cash, absolute-cap and target boundaries.
     */
    fun allowedNextCarInvestmentAmount(
        roomUnderCaps: Long,
        spendableCash: Long,
        targetCost: Long,
        alreadyInvested: Long,
        desiredChunk: Long
    ): Long {
        val targetGap = (targetCost.coerceAtLeast(0L) - alreadyInvested.coerceAtLeast(0L)).coerceAtLeast(0L)
        return minOf(
            roomUnderCaps.coerceAtLeast(0L),
            spendableCash.coerceAtLeast(0L),
            targetGap,
            desiredChunk.coerceAtLeast(0L)
        ).coerceAtLeast(0L)
    }

    /**
     * Contribution target for the next-season car, based on the remaining amount
     * needed to preserve current performance, spread over the remaining GPs.
     * This is a target only; callers must still apply cash, reserve and absolute cap.
     */
    fun plannedNextCarContribution(referenceCost: Long, alreadyInvested: Long, round: Int, minimumChunk: Long): Long {
        val gap = (referenceCost.coerceAtLeast(0L) - alreadyInvested.coerceAtLeast(0L)).coerceAtLeast(0L)
        if (gap == 0L) return 0L
        val remainingGps = (31 - round.coerceIn(1, 30)).coerceAtLeast(1)
        val perGpTarget = (gap + remainingGps - 1L) / remainingGps
        return maxOf(minimumChunk.coerceAtLeast(0L), perGpTarget)
    }
}
