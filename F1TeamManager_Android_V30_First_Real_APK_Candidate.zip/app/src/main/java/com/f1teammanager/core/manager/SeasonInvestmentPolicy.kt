package com.f1teammanager.core.manager

/**
 * Shared financial guardrails for the AI's annual technical investment envelope.
 *
 * The 40/40/20 split is a strategic starting priority, never three independent
 * spending caps. Current-car development, next-car construction and facilities
 * draw from one €200M annual envelope. Unused category capacity is released to
 * the other categories, while operating cash and the €150M next-car project ceiling
 * remain protected.
 */
object SeasonInvestmentPolicy {
    /** AI's reference priorities; these percentages must not be enforced as hard category caps. */
    const val AI_NEXT_SEASON_CAR_PERCENT = 40
    const val AI_CURRENT_SEASON_CAR_PERCENT = 40
    const val AI_FACILITIES_PERCENT = 20

    fun phasePercent(round: Int): Int = AI_NEXT_SEASON_CAR_PERCENT

    /** Informational target for planning and UI; never use as a hard category ceiling. */
    fun aiCurrentCarAnnualLimit(annualCap: Long): Long =
        annualCap.coerceAtLeast(0L) * AI_CURRENT_SEASON_CAR_PERCENT / 100L

    /** Informational target for planning and UI; facilities may exceed it from shared headroom. */
    fun aiFacilitiesAnnualLimit(annualCap: Long): Long =
        annualCap.coerceAtLeast(0L) * AI_FACILITIES_PERCENT / 100L

    /** Informational target for planning and UI; next-car investments can exceed it up to €150M. */
    fun aiNextSeasonCarAnnualLimit(annualCap: Long): Long =
        annualCap.coerceAtLeast(0L) * AI_NEXT_SEASON_CAR_PERCENT / 100L

    /** Reference target only. Live AI P&D can use the shared envelope left by other priorities. */
    fun remainingAiCurrentCarAllocation(investment: TechnicalInvestmentState): Long =
        (aiCurrentCarAnnualLimit(investment.annualCap) - investment.researchDesignSpent - investment.fabricationSpent).coerceAtLeast(0L)

    fun remainingAiFacilitiesAllocation(investment: TechnicalInvestmentState): Long =
        (aiFacilitiesAnnualLimit(investment.annualCap) - investment.facilityUpgradeSpent).coerceAtLeast(0L)

    fun protectedCash(budget: Long): Long {
        if (budget <= 0L) return 0L
        // Player-facing reserve: preserve the established 20% rule.
        return (budget / 5L).coerceAtLeast(2_000_000L).coerceAtMost(budget)
    }

    /** AI liquidity buffer with a ceiling: a rich team should not freeze 20% of a
     * multi-hundred-million balance when its actual annual operating runway is finite. */
    fun aiProtectedCash(budget: Long): Long {
        val cash = budget.coerceAtLeast(0L)
        if (cash == 0L) return 0L
        return minOf((cash / 5L).coerceAtLeast(2_000_000L), 50_000_000L, cash)
    }


    /**
     * Percent of current liquidity prioritized for next-season car funding.
     * This is deliberately a funding allocation, not a hard cap on cumulative
     * investment: unused allocation remains available later if income arrives.
     */
    fun nextCarPriorityPercent(round: Int): Int = AI_NEXT_SEASON_CAR_PERCENT

    /**
     * Cash kept aside for the next-season car. The reserve is 40% of the current
     * uncommitted annual envelope, not a fixed €80M cumulative allocation. As other
     * categories spend less, the protected amount can be redirected to the next car.
     */
    fun aiNextCarReserve(
        budget: Long,
        round: Int = 1,
        alreadyInvested: Long = 0L,
        annualEnvelopeRemaining: Long = 200_000_000L
    ): Long {
        val cash = budget.coerceAtLeast(0L)
        val projectRoom = (AI_NEXT_CAR_ABSOLUTE_CAP - alreadyInvested.coerceAtLeast(0L)).coerceAtLeast(0L)
        val envelopeRoom = annualEnvelopeRemaining.coerceAtLeast(0L)
        // Protect 40% of the *currently uncommitted shared envelope*. Recalculate
        // after every spend/income event: if current-car P&D or facilities use less
        // than their reference share, the next car can receive more than €80M over
        // the season, up to the single-project ceiling and the global €200M envelope.
        val priorityCash = cash * nextCarPriorityPercent(round).toLong() / 100L
        val priorityEnvelope = envelopeRoom * nextCarPriorityPercent(round).toLong() / 100L
        return minOf(cash, projectRoom, priorityCash, priorityEnvelope).coerceAtLeast(0L)
    }

    /** Cash available for current-season technical development after both priorities. */
    fun aiDevelopmentSpendableCash(
        budget: Long,
        round: Int = 1,
        nextCarAlreadyInvested: Long = 0L,
        annualEnvelopeRemaining: Long = 200_000_000L
    ): Long {
        val cash = budget.coerceAtLeast(0L)
        val protected = maxOf(
            aiProtectedCash(cash),
            aiNextCarReserve(cash, round, nextCarAlreadyInvested, annualEnvelopeRemaining)
        ).coerceAtMost(cash)
        return (cash - protected).coerceAtLeast(0L)
    }

    /**
     * Shared room for current-car development and facilities after protecting the
     * next-car priority. Those two categories compete for this pool; neither gets a
     * separate hard ceiling, so an idle category releases capacity to the other.
     */
    fun aiCurrentAndFacilityEnvelopeRemaining(
        budget: Long,
        round: Int,
        nextCarAlreadyInvested: Long,
        annualEnvelopeRemaining: Long
    ): Long {
        val remaining = annualEnvelopeRemaining.coerceAtLeast(0L)
        val nextCarPriority = aiNextCarReserve(
            budget, round, nextCarAlreadyInvested, remaining
        )
        return (remaining - nextCarPriority).coerceAtLeast(0L)
    }

    /**
     * A facility upgrade can use any genuinely uncommitted amount in the shared
     * current-car/facility pool. The 20% facilities share is a priority reference,
     * not a yearly cap.
     */
    fun allowedAiFacilityInvestmentAmount(
        requestedCost: Long,
        spendableCash: Long,
        annualEnvelopeRemaining: Long,
        forecastHeadroom: Long = Long.MAX_VALUE
    ): Long = minOf(
        requestedCost.coerceAtLeast(0L),
        spendableCash.coerceAtLeast(0L),
        annualEnvelopeRemaining.coerceAtLeast(0L),
        forecastHeadroom.coerceAtLeast(0L)
    ).coerceAtLeast(0L)

    const val AI_NEXT_CAR_ABSOLUTE_CAP = 150_000_000L

    /** One €200M envelope shared by current-car work, facilities and next-car funding. */
    fun remainingAnnualTechnicalEnvelope(
        annualCap: Long,
        alreadySpentTechnical: Long,
        nextCarAlreadyInvested: Long
    ): Long = (annualCap.coerceAtLeast(0L) - alreadySpentTechnical.coerceAtLeast(0L) -
        nextCarAlreadyInvested.coerceAtLeast(0L)).coerceAtLeast(0L)

    fun maximumCumulativeInvestment(budget: Long, round: Int, overallCap: Long): Long {
        // This method now returns only the absolute project ceiling. Available cash
        // and protected operating reserve are validated independently at each debit.
        // Never freeze a cumulative ceiling from an earlier cash snapshot: incoming
        // sponsorship/prizes must be able to restore investment capacity.
        return overallCap.coerceAtLeast(0L)
    }

    /**
     * Minimum liquidity target for AI discretionary spending.
     *
     * Keep the next GP's expected salary installment and race operating cost,
     * plus a small cash buffer. Reserving every remaining GP's costs up front
     * incorrectly assumes zero future sponsor/race income; that made AI teams
     * unable to invest in next season's car even late in the championship.
     */
    fun aiOperatingReserve(annualDriverSalaries: Long, round: Int, raceCostPerGp: Long = 850_000L): Long {
        val salaryInstallment = annualDriverSalaries.coerceAtLeast(0L) / 30L
        val nextRaceCost = raceCostPerGp.coerceAtLeast(0L)
        // At the end of the season there is no further GP operating cost to reserve.
        val raceReserve = if (round.coerceIn(1, 30) >= 30) 0L else nextRaceCost
        return (salaryInstallment + raceReserve + 2_000_000L).coerceAtLeast(2_000_000L)
    }

    fun aiSpendableCash(budget: Long, annualDriverSalaries: Long, round: Int, raceCostPerGp: Long = 850_000L): Long =
        (budget.coerceAtLeast(0L) - aiOperatingReserve(annualDriverSalaries, round, raceCostPerGp)).coerceAtLeast(0L)

    /**
     * Final amount allowed for one AI contribution after the ambition target has
     * been chosen. Keeps the transfer inside cash, absolute-cap and target boundaries.
     */
    fun allowedNextCarInvestmentAmount(
        roomUnderCaps: Long,
        spendableCash: Long,
        targetCost: Long,
        alreadyInvested: Long,
        desiredChunk: Long
    ): Long {
        val targetGap = (targetCost.coerceAtLeast(0L) - alreadyInvested.coerceAtLeast(0L)).coerceAtLeast(0L)
        return minOf(
            roomUnderCaps.coerceAtLeast(0L),
            spendableCash.coerceAtLeast(0L),
            targetGap,
            desiredChunk.coerceAtLeast(0L)
        ).coerceAtLeast(0L)
    }

    /**
     * Contribution target for the next-season car, based on the remaining amount
     * needed to preserve current performance, spread over the remaining GPs.
     * This is a target only; callers must still apply cash, reserve and absolute cap.
     */
    fun plannedNextCarContribution(referenceCost: Long, alreadyInvested: Long, round: Int, minimumChunk: Long): Long {
        val gap = (referenceCost.coerceAtLeast(0L) - alreadyInvested.coerceAtLeast(0L)).coerceAtLeast(0L)
        if (gap == 0L) return 0L
        val remainingGps = (31 - round.coerceIn(1, 30)).coerceAtLeast(1)
        val perGpTarget = (gap + remainingGps - 1L) / remainingGps
        return maxOf(minimumChunk.coerceAtLeast(0L), perGpTarget)
    }
}
