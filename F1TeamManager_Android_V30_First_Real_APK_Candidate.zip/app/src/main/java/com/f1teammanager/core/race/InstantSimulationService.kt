package com.f1teammanager.core.race

/**
 * V362: single contract boundary for instant qualifying + race before career effects.
 * It deliberately reuses CareerWeekendEngine; it does not create a second race model
 * and does not touch UI state or persistence.
 */
object InstantSimulationService {
    data class ValidatedWeekend(
        val qualifying: CareerWeekendEngine.SessionSnapshot,
        val race: CareerWeekendEngine.SessionSnapshot,
        val result: RaceResult
    )

    /**
     * Public entry point for a truly instant weekend from the career calendar.
     * Unlike completeStartedWeekend(), this method owns session initialization, so
     * callers do not need to enter the interactive qualifying screen first.
     */
    fun simulateWeekendInstantly(
        engine: CareerWeekendEngine,
        participants: List<RaceParticipant>,
        circuit: RaceCircuit,
        playerTeamId: Int,
        weekendSeed: Int? = null
    ): ValidatedWeekend {
        // V375 preflight: validate the complete roster and circuit before engine.start()
        // mutates session state. A malformed team roster must never produce a plausible
        // qualifying/race result that can later be committed to the career.
        require(participants.size == 80) { "A simulação instantânea exige os 80 pilotos do campeonato" }
        require(participants.map { it.driverId }.distinct().size == participants.size) {
            "A lista de participantes contém identificações duplicadas"
        }
        require(participants.all { it.driverId > 0 && it.teamId > 0 }) {
            "A lista de participantes contém identificações inválidas"
        }
        require(participants.all { it.driverName.isNotBlank() && it.teamName.isNotBlank() }) {
            "A lista de participantes contém piloto ou equipe sem nome"
        }
        require(participants.map { it.teamId }.distinct().size == 40) {
            "O grid deve conter exatamente 40 equipes"
        }
        require(participants.groupBy { it.teamId }.values.all { roster ->
            roster.size == 2 && roster.map { it.driverId }.distinct().size == 2 &&
                roster.map { it.teamName.trim().lowercase() }.distinct().size == 1
        }) {
            "Cada equipe deve possuir exatamente dois pilotos e um nome consistente"
        }
        require(participants.count { it.teamId == playerTeamId } == 2) {
            "A equipe do jogador deve possuir exatamente dois pilotos no grid"
        }
        require(circuit.id > 0 && circuit.name.isNotBlank() && circuit.laps > 0 && circuit.baseLapTimeMs > 0L) {
            "O circuito possui identificação, nome, distância ou tempo-base inválido"
        }
        require(listOf(circuit.crashRisk, circuit.reliabilityRisk, circuit.safetyCarRisk).all {
            it.isFinite() && it in 0.0..1.25
        }) {
            "Os multiplicadores de risco do circuito devem ser finitos e estar entre 0 e 1,25"
        }
        require(playerTeamId > 0) { "A equipe do jogador possui identificação inválida" }
        // Always initialize a fresh weekend for the requested career round. This
        // prevents a stale engine from the previous GP being reused after returning
        // to the calendar or after a process/UI lifecycle transition.
        if (weekendSeed == null) {
            engine.start(participants, circuit, playerTeamId)
        } else {
            engine.start(participants, circuit, playerTeamId, weekendSeed)
        }
        return completeStartedWeekend(engine, circuit)
    }

    fun completeStartedWeekend(engine: CareerWeekendEngine, circuit: RaceCircuit): ValidatedWeekend {
        require(circuit.laps > 0) { "O GP precisa ter pelo menos uma volta programada" }
        val configured = engine.configuredCircuit()
            ?: error("O motor precisa ser iniciado com um circuito antes da simulação instantânea")
        require(configured == circuit) {
            "O circuito informado não corresponde ao circuito usado para iniciar o motor " +
                "(esperado ${configured.id}/${configured.name}/${configured.laps} voltas; " +
                "recebido ${circuit.id}/${circuit.name}/${circuit.laps} voltas)"
        }
        val weekend = engine.simulateWeekendInstantly()
        val grid = weekend.qualifying.grid ?: error("A qualificação instantânea não gerou grid")
        val gridIds = grid.grid.map { it.driverId }
        require(gridIds.size == 80 && gridIds.distinct().size == 80) {
            "O grid da qualificação deve conter exatamente 80 pilotos únicos"
        }
        require(grid.grid.map { it.position }.sorted() == (1..80).toList()) {
            "O grid da qualificação contém posições ausentes ou duplicadas"
        }
        require(grid.phases.size == 3) { "A qualificação deve conter Q1, Q2 e Q3" }
        require(grid.phases[0].entries.size == 80) { "Q1 deve conter 80 pilotos" }
        require(grid.phases[1].entries.size == 50) { "Q2 deve conter 50 pilotos" }
        require(grid.phases[2].entries.size == 20) { "Q3 deve conter 20 pilotos" }
        val q1Ids = grid.phases[0].entries.map { it.driverId }.toSet()
        val q2Ids = grid.phases[1].entries.map { it.driverId }.toSet()
        val q3Ids = grid.phases[2].entries.map { it.driverId }.toSet()
        require(q1Ids.size == 80 && q2Ids.size == 50 && q3Ids.size == 20) {
            "Uma fase da qualificação contém pilotos duplicados"
        }
        require(q2Ids.all { it in q1Ids } && q3Ids.all { it in q2Ids }) {
            "A progressão entre Q1, Q2 e Q3 é inconsistente"
        }
        grid.phases.forEachIndexed { index, phase ->
            require(phase.entries.map { it.position }.sorted() == (1..phase.entries.size).toList()) {
                "A fase ${index + 1} contém posições ausentes ou duplicadas"
            }
            require(phase.entries.all { it.lapTimeMs > 0L }) {
                "A fase ${index + 1} contém tempo de volta inválido"
            }
        }
        val expectedQ1Eliminated = q1Ids - q2Ids
        val expectedQ2Eliminated = q2Ids - q3Ids
        require(grid.phases[0].eliminatedDriverIds.toSet() == expectedQ1Eliminated &&
            grid.phases[0].eliminatedDriverIds.size == expectedQ1Eliminated.size) {
            "A lista de eliminados da Q1 não corresponde aos classificados para a Q2"
        }
        require(grid.phases[1].eliminatedDriverIds.toSet() == expectedQ2Eliminated &&
            grid.phases[1].eliminatedDriverIds.size == expectedQ2Eliminated.size) {
            "A lista de eliminados da Q2 não corresponde aos classificados para a Q3"
        }
        require(gridIds.toSet() == q1Ids) { "O grid final não corresponde à lista de participantes de Q1" }

        val result = weekend.result
        RaceResultValidator.requireValid(result, circuit.laps)
        val resultIds = result.classification.map { it.driverId }
        require(resultIds.size == 80 && resultIds.toSet() == gridIds.toSet()) {
            "A classificação final não corresponde aos 80 pilotos do grid"
        }
        require(result.classification.map { it.position }.sorted() == (1..80).toList()) {
            "A classificação final contém posições ausentes ou duplicadas"
        }
        require(result.classification.maxOfOrNull { it.laps } == circuit.laps) {
            "Nenhum piloto completou a distância programada"
        }
        require(result.qualifying?.grid?.map { it.driverId }?.toSet() == gridIds.toSet()) {
            "O resultado da corrida perdeu a referência ao grid de qualificação"
        }
        return ValidatedWeekend(weekend.qualifying, weekend.race, result)
    }
}
