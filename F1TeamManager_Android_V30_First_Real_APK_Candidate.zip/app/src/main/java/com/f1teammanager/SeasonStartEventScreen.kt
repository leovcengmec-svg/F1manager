package com.f1teammanager

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.SportsMotorsports
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.f1teammanager.core.season.DriverDefinition
import com.f1teammanager.core.season.TeamDefinition
import com.f1teammanager.core.season.WorldDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * V416 — season-start event front-end.
 * Standalone Compose screen designed from the approved reference image.
 * No vertical or horizontal scrolling is used. The caller owns first-week gating and persistence.
 */
private val SeasonBg = Color(0xFF070B10)
private val SeasonPanel = Color(0xFF0D141D)
private val SeasonPanel2 = Color(0xFF121C27)
private val SeasonLine = Color(0xFF243342)
private val SeasonRed = Color(0xFFF20D22)
private val SeasonText = Color(0xFFF5F7FA)
private val SeasonMuted = Color(0xFFB0BDCC)
private val SeasonGreen = Color(0xFF16C7A0)
private val SeasonOrange = Color(0xFFFF8617)

@Composable
fun SeasonStartEventScreen(
    season: Int,
    teams: List<TeamDefinition> = WorldDatabase.teams,
    drivers: List<DriverDefinition> = WorldDatabase.allDrivers,
    onStartSeason: () -> Unit,
    onBack: (() -> Unit)? = null
) {
    val teamScores = remember(teams, drivers) {
        teams.associate { team ->
            val roster = drivers.filter { it.teamId == team.id }
            val carScore = (team.engine + team.chassis + team.reliability + team.frontWing + team.rearWing + team.brakes + team.electricPowerUnit) / 7.0
            val driverScore = if (roster.isEmpty()) 0.0 else roster.map { driverRating(it) }.average()
            team.id to (carScore * 0.58 + driverScore * 0.42)
        }
    }
    val contenders = remember(teams, teamScores) {
        teams.sortedByDescending { teamScores[it.id] ?: 0.0 }.take(4)
    }
    val featuredDrivers = remember(drivers, teamScores) {
        drivers.filter { it.teamId > 0 }
            .sortedByDescending { driverRating(it) * 0.72 + (teamScores[it.teamId] ?: 0.0) * 0.28 }
            .distinctBy { it.id }.take(5)
    }

    BoxWithConstraints(Modifier.fillMaxSize().background(SeasonBg)) {
        val compact = maxHeight < 780.dp
        val pagePad = if (compact) 7.dp else 10.dp
        val sectionGap = if (compact) 4.dp else 6.dp
        Column(
            modifier = Modifier.fillMaxSize().padding(horizontal = pagePad, vertical = 3.dp),
            verticalArrangement = Arrangement.spacedBy(sectionGap)
        ) {
            // Top line
            Row(Modifier.fillMaxWidth().height(if (compact) 28.dp else 32.dp), verticalAlignment = Alignment.CenterVertically) {
                if (onBack != null) {
                    Text("‹", color = SeasonText, fontSize = 29.sp, modifier = Modifier.width(27.dp).clickable { onBack.invoke() })
                }
                Text("INÍCIO DA TEMPORADA", color = SeasonMuted, fontSize = if (compact) 12.sp else 14.sp,
                    fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f), maxLines = 1)
                Text("F1 MANAGER", color = SeasonRed, fontSize = if (compact) 10.sp else 12.sp, fontWeight = FontWeight.Black)
            }

            // Hero banner: actual team-car assets form the visual backdrop when available.
            SeasonHeroBanner(season, contenders, compact, Modifier.fillMaxWidth().weight(if (compact) 2.4f else 2.65f).heightIn(min = 120.dp))

            // Team cards
            Column(Modifier.fillMaxWidth().weight(if (compact) 2.25f else 2.45f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                SeasonSectionHeading("CANDIDATAS AO TÍTULO", trophy = true, compact = compact)
                Row(Modifier.fillMaxWidth().weight(1f), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    contenders.forEachIndexed { index, team ->
                        SeasonTeamCard(team, index + 1, teamScores[team.id] ?: 0.0, compact, Modifier.weight(1f).fillMaxHeight())
                    }
                }
            }

            // Driver cards
            Column(Modifier.fillMaxWidth().weight(if (compact) 2.55f else 2.8f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                SeasonSectionHeading("PILOTOS EM DESTAQUE", trophy = false, compact = compact)
                Row(Modifier.fillMaxWidth().weight(1f), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    featuredDrivers.forEachIndexed { index, driver ->
                        SeasonDriverCard(driver, index + 1, teams.firstOrNull { it.id == driver.teamId }, compact, Modifier.weight(1f).fillMaxHeight())
                    }
                }
            }

            SeasonOutlook(compact, Modifier.fillMaxWidth().weight(if (compact) 0.72f else 0.82f).heightIn(min = 48.dp))

            Button(
                onClick = onStartSeason,
                modifier = Modifier.fillMaxWidth().height(if (compact) 44.dp else 50.dp),
                shape = RoundedCornerShape(13.dp),
                colors = ButtonDefaults.buttonColors(containerColor = SeasonRed, contentColor = Color.White),
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)
            ) {
                Text("COMEÇAR A TEMPORADA  ›", fontSize = if (compact) 14.sp else 16.sp, fontWeight = FontWeight.Black,
                    textAlign = TextAlign.Center, maxLines = 1)
            }
        }
    }
}

@Composable
private fun SeasonHeroBanner(season: Int, teams: List<TeamDefinition>, compact: Boolean, modifier: Modifier = Modifier) {
    BoxWithConstraints(modifier.clip(RoundedCornerShape(16.dp)).background(SeasonPanel).border(1.dp, SeasonLine, RoundedCornerShape(16.dp))) {
        val context = LocalContext.current
        val team = teams.firstOrNull()
        var carBitmap by remember(team?.id) { mutableStateOf<Bitmap?>(null) }
        LaunchedEffect(team?.id, team?.name) {
            carBitmap = if (team == null) null else withContext(Dispatchers.IO) { ExternalAssets.loadTeamCarVisual(context, team.id, team.name) }
        }
        if (carBitmap != null) {
            Image(carBitmap!!.asImageBitmap(), contentDescription = "Carro de destaque da temporada", modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop, alpha = 0.42f)
        }
        Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(listOf(Color(0xF5070B10), Color(0xC9070B10), Color(0x25070B10)))))
        Column(Modifier.fillMaxSize().padding(if (compact) 10.dp else 13.dp), verticalArrangement = Arrangement.Center) {
            Text("F1", color = SeasonRed, fontSize = if (compact) 22.sp else 28.sp, fontWeight = FontWeight.Black, lineHeight = if (compact) 23.sp else 29.sp)
            Text("ESPECIAL  •  $season", color = SeasonRed, fontSize = if (compact) 9.sp else 11.sp, fontWeight = FontWeight.Black)
            Text("NOVA TEMPORADA", color = SeasonText, fontSize = if (compact) 20.sp else 25.sp, fontWeight = FontWeight.Black, maxLines = 1, softWrap = false)
            Text("A DISPUTA VAI COMEÇAR", color = SeasonRed, fontSize = if (compact) 12.sp else 15.sp, fontWeight = FontWeight.Black, maxLines = 1)
            Spacer(Modifier.height(3.dp))
            Text("As equipes estão prontas, os pilotos chegam preparados e a luta pelo campeonato promete ser intensa.",
                color = SeasonMuted, fontSize = if (compact) 10.sp else 12.sp, lineHeight = if (compact) 12.sp else 15.sp,
                modifier = Modifier.fillMaxWidth(0.67f))
        }
    }
}

@Composable
private fun SeasonSectionHeading(title: String, trophy: Boolean, compact: Boolean) {
    Row(Modifier.fillMaxWidth().height(if (compact) 27.dp else 32.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Box(Modifier.size(if (compact) 24.dp else 29.dp).clip(RoundedCornerShape(7.dp)).background(SeasonPanel2), contentAlignment = Alignment.Center) {
            if (trophy) Icon(Icons.Filled.EmojiEvents, contentDescription = "Troféu", tint = SeasonText, modifier = Modifier.fillMaxSize(0.67f))
            else Icon(Icons.Filled.SportsMotorsports, contentDescription = "Pilotos", tint = SeasonText, modifier = Modifier.fillMaxSize(0.7f))
        }
        Text(title, color = SeasonText, fontSize = if (compact) 12.sp else 15.sp, fontWeight = FontWeight.Black,
            maxLines = 1, softWrap = false, modifier = Modifier.weight(1f))
    }
}

@Composable
private fun SeasonTeamCard(team: TeamDefinition, rank: Int, score: Double, compact: Boolean, modifier: Modifier = Modifier) {
    val accent = when (rank) { 1 -> SeasonRed; 2 -> Color(0xFF2478DB); 3 -> SeasonGreen; else -> SeasonOrange }
    Column(modifier.clip(RoundedCornerShape(12.dp)).background(Brush.verticalGradient(listOf(accent.copy(alpha = 0.18f), SeasonPanel, Color(0xFF070C12))))
        .border(1.dp, if (rank == 1) accent.copy(alpha = 0.8f) else SeasonLine, RoundedCornerShape(12.dp)).padding(if (compact) 5.dp else 7.dp),
        verticalArrangement = Arrangement.spacedBy(if (compact) 2.dp else 3.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
            Text(rank.toString(), color = Color.White, fontSize = if (compact) 9.sp else 11.sp, fontWeight = FontWeight.Black,
                modifier = Modifier.clip(RoundedCornerShape(5.dp)).background(accent).padding(horizontal = 5.dp, vertical = 2.dp))
            SeasonTeamLogo(team, Modifier.size(if (compact) 22.dp else 27.dp))
        }
        SeasonTeamCar(team, Modifier.fillMaxWidth().weight(1f, fill = true).heightIn(min = 22.dp))
        Text(team.name.uppercase(), color = SeasonText, fontSize = if (compact) 8.sp else 10.sp, fontWeight = FontWeight.Black,
            maxLines = 2, lineHeight = if (compact) 9.sp else 11.sp, softWrap = true, modifier = Modifier.fillMaxWidth())
        Box(Modifier.fillMaxWidth().height(5.dp).clip(RoundedCornerShape(5.dp)).background(Color(0xFF243140))) {
            Box(Modifier.fillMaxHeight().fillMaxWidth((score / 100.0).toFloat().coerceIn(0.12f, 1f)).clip(RoundedCornerShape(5.dp)).background(accent))
        }
        Text(when (rank) { 1 -> "PRINCIPAL CANDIDATA AO TÍTULO"; 2 -> "BRIGA DIRETA PELO TÍTULO"; 3 -> "FORTE CONCORRENTE"; else -> "PODE SURPREENDER" },
            color = SeasonMuted, fontSize = if (compact) 6.sp else 7.sp, lineHeight = if (compact) 7.sp else 8.sp,
            modifier = Modifier.fillMaxWidth(), softWrap = true)
    }
}

@Composable
private fun SeasonDriverCard(driver: DriverDefinition, rank: Int, team: TeamDefinition?, compact: Boolean, modifier: Modifier = Modifier) {
    val accent = if (rank == 1) SeasonRed else listOf(Color(0xFF2478DB), Color(0xFF566779), SeasonOrange, Color(0xFF842A34))[((rank - 2).coerceAtLeast(0)) % 4]
    Column(modifier.clip(RoundedCornerShape(10.dp)).background(SeasonPanel).border(1.dp, if (rank == 1) accent.copy(alpha = 0.65f) else SeasonLine, RoundedCornerShape(10.dp))) {
        Box(Modifier.fillMaxWidth().weight(0.9f).background(Brush.verticalGradient(listOf(accent.copy(alpha = 0.25f), SeasonPanel2)))) {
            DriverPortrait(driver, Modifier.fillMaxSize())
            Text(rank.toString(), color = Color.White, fontSize = if (compact) 8.sp else 10.sp, fontWeight = FontWeight.Black,
                modifier = Modifier.align(Alignment.TopStart).padding(3.dp).clip(RoundedCornerShape(4.dp)).background(accent).padding(horizontal = 4.dp, vertical = 2.dp))
        }
        Column(Modifier.fillMaxWidth().weight(1.05f).padding(horizontal = if (compact) 4.dp else 5.dp, vertical = 3.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            val displayName = driver.name.trim().split(Regex("\\s+")).filter { it.isNotBlank() }
                .let { parts -> if (parts.size <= 1) parts.joinToString(" ") else parts.first() + "\n" + parts.drop(1).joinToString(" ") }
            Text(displayName.uppercase(), color = SeasonText, fontSize = if (compact) 7.sp else 9.sp, fontWeight = FontWeight.Black,
                lineHeight = if (compact) 8.sp else 10.sp, modifier = Modifier.fillMaxWidth(), maxLines = 2, softWrap = true)
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(2.dp), modifier = Modifier.fillMaxWidth()) {
                CountryFlag(driver.country, Modifier.size(width = if (compact) 13.dp else 16.dp, height = if (compact) 9.dp else 11.dp))
                Text(team?.name ?: "SEM EQUIPE", color = accent, fontSize = if (compact) 5.sp else 6.sp, lineHeight = if (compact) 6.sp else 7.sp,
                    modifier = Modifier.weight(1f), softWrap = true)
            }
            Text(when (rank) { 1 -> "CANDIDATO AO TÍTULO"; 2 -> "BRIGA PELO CAMPEONATO"; 3 -> "NA LUTA PELO TÍTULO"; 4 -> "PODE SURPREENDER"; else -> "POTENCIAL DE VITÓRIAS" },
                color = SeasonMuted, fontSize = if (compact) 5.sp else 6.sp, lineHeight = if (compact) 6.sp else 7.sp,
                modifier = Modifier.fillMaxWidth(), softWrap = true)
        }
    }
}

@Composable
private fun SeasonOutlook(compact: Boolean, modifier: Modifier = Modifier) {
    Row(modifier.clip(RoundedCornerShape(12.dp)).background(SeasonPanel).border(1.dp, SeasonLine, RoundedCornerShape(12.dp)).padding(horizontal = if (compact) 7.dp else 10.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Box(Modifier.size(if (compact) 30.dp else 37.dp).clip(RoundedCornerShape(8.dp)).background(SeasonPanel2), contentAlignment = Alignment.Center) {
            Icon(Icons.Filled.BarChart, contentDescription = "Expectativa", tint = SeasonMuted, modifier = Modifier.fillMaxSize(0.65f))
        }
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(1.dp)) {
            Text("EXPECTATIVA PARA A TEMPORADA", color = SeasonText, fontSize = if (compact) 8.sp else 10.sp, fontWeight = FontWeight.Black, maxLines = 1)
            Text("Equipes competitivas, grid equilibrado e pilotos preparados para disputar vitórias.", color = SeasonMuted,
                fontSize = if (compact) 7.sp else 9.sp, lineHeight = if (compact) 8.sp else 11.sp, modifier = Modifier.fillMaxWidth(), softWrap = true)
        }
    }
}

@Composable
private fun SeasonTeamLogo(team: TeamDefinition, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    var bitmap by remember(team.id) { mutableStateOf<Bitmap?>(null) }
    LaunchedEffect(team.id, team.name) { bitmap = withContext(Dispatchers.IO) { ExternalAssets.loadTeamLogo(context, team.id, team.name) } }
    if (bitmap != null) Image(bitmap!!.asImageBitmap(), contentDescription = "Escudo ${team.name}", modifier = modifier, contentScale = ContentScale.Fit)
    else Box(modifier.background(SeasonPanel2, RoundedCornerShape(5.dp)), contentAlignment = Alignment.Center) {
        Text(team.name.take(2).uppercase(), color = SeasonMuted, fontSize = 8.sp, fontWeight = FontWeight.Black)
    }
}

@Composable
private fun SeasonTeamCar(team: TeamDefinition, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    var bitmap by remember(team.id) { mutableStateOf<Bitmap?>(null) }
    LaunchedEffect(team.id, team.name) { bitmap = withContext(Dispatchers.IO) { ExternalAssets.loadTeamCarVisual(context, team.id, team.name) } }
    if (bitmap != null) Image(bitmap!!.asImageBitmap(), contentDescription = "Carro ${team.name}", modifier = modifier, contentScale = ContentScale.Fit)
    else Box(modifier, contentAlignment = Alignment.Center) { Text("F1", color = SeasonMuted.copy(alpha = 0.5f), fontSize = 16.sp, fontWeight = FontWeight.Black) }
}

@Composable
private fun DriverPortrait(driver: DriverDefinition, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    var bitmap by remember(driver.id) { mutableStateOf<Bitmap?>(null) }
    LaunchedEffect(driver.id, driver.name) { bitmap = withContext(Dispatchers.IO) { ExternalAssets.loadDriverPhoto(context, driver.id, driver.name) } }
    if (bitmap != null) Image(bitmap!!.asImageBitmap(), contentDescription = "Foto de ${driver.name}", modifier = modifier, contentScale = ContentScale.Crop)
    else Box(modifier, contentAlignment = Alignment.Center) {
        Text(driver.name.split(" ").mapNotNull { it.firstOrNull() }.take(2).joinToString(""), color = SeasonMuted, fontSize = 20.sp, fontWeight = FontWeight.Black)
    }
}

@Composable
private fun CountryFlag(country: String, modifier: Modifier = Modifier) {
    val code = when (country.trim().lowercase()) {
        "brasil" -> "br"; "reino unido" -> "gb"; "itália", "italia" -> "it"; "mônaco", "monaco" -> "mc";
        "países baixos", "paises baixos" -> "nl"; "espanha" -> "es"; "austrália", "australia" -> "au";
        "frança", "franca" -> "fr"; "alemanha" -> "de"; "áustria", "austria" -> "at"; "canadá", "canada" -> "ca";
        "tailândia", "tailandia" -> "th"; "argentina" -> "ar"; "nova zelândia", "nova zelandia" -> "nz";
        "suíça", "suica" -> "ch"; "suécia", "suecia" -> "se"; "noruega" -> "no"; "irlanda" -> "ie"; "bulgária", "bulgaria" -> "bg";
        "índia", "india" -> "in"; "japão", "japao" -> "jp"; "estados unidos" -> "us"; "malásia", "malasia" -> "my";
        "colômbia", "colombia" -> "co"; else -> ""
    }
    val context = LocalContext.current
    var bitmap by remember(code) { mutableStateOf<Bitmap?>(null) }
    LaunchedEffect(code) { bitmap = if (code.isBlank()) null else withContext(Dispatchers.IO) { ExternalAssets.loadCountryFlag(context, code) } }
    if (bitmap != null) Image(bitmap!!.asImageBitmap(), contentDescription = "Bandeira $country", modifier = modifier, contentScale = ContentScale.Crop)
    else Box(modifier.background(SeasonPanel2, RoundedCornerShape(2.dp)))
}

private fun driverRating(driver: DriverDefinition): Double =
    (driver.speed + driver.qualifying + driver.overtaking + driver.defense + driver.consistency + driver.wet + driver.tyre) / 7.0
