package com.f1teammanager

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val MenuRed = Color(0xFFE10600)
private val MenuWhite = Color(0xFFF5F6F8)
private val MenuMuted = Color(0xFFB8BBC2)

/** Menu de abertura: UI real em Compose, com cards clicáveis independentes e sem rolagem. */
@Composable
internal fun MainMenuScreen(
    hasCareer: Boolean,
    onNewGame: () -> Unit,
    onContinue: () -> Unit,
    onSettings: () -> Unit
) {
    BoxWithConstraints(modifier = Modifier.fillMaxSize().background(Color(0xFF08090C))) {
        Image(
            painter = painterResource(id = R.drawable.menu_garage_background),
            contentDescription = "Garagem de Fórmula 1",
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xAA050609), Color(0x33050910), Color(0xDD050609)))))
        val compact = maxHeight < 760.dp
        Column(
            modifier = Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()
                .padding(horizontal = 20.dp, vertical = if (compact) 10.dp else 18.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = androidx.compose.foundation.layout.Arrangement.SpaceBetween
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth().weight(0.95f), verticalArrangement = Arrangement.Center) {
                Text("F1", color = MenuRed, fontSize = if (compact) 64.sp else 78.sp, lineHeight = if (compact) 64.sp else 78.sp, fontWeight = FontWeight.Black)
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
                    Text("TEAM", color = MenuWhite, fontSize = if (compact) 27.sp else 32.sp, fontWeight = FontWeight.Black, maxLines = 1)
                    Spacer(Modifier.width(7.dp))
                    Text("MANAGER", color = MenuRed, fontSize = if (compact) 27.sp else 32.sp, fontWeight = FontWeight.Black, maxLines = 1)
                }
                Spacer(Modifier.height(8.dp))
                Box(Modifier.fillMaxWidth(0.82f).height(3.dp).background(MenuRed))
                Spacer(Modifier.height(10.dp))
                Text("GERENCIE   •   DESENVOLVA   •   VENÇA", color = MenuMuted, fontSize = if (compact) 10.sp else 12.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, maxLines = 1)
            }
            Column(modifier = Modifier.fillMaxWidth().weight(0.92f), verticalArrangement = Arrangement.spacedBy(if (compact) 8.dp else 10.dp)) {
                MenuOptionCard("NOVO JOGO", "INICIE UMA NOVA CARREIRA", MenuRed, Icons.Filled.Flag, true, onNewGame, compact, Modifier.weight(1f))
                MenuOptionCard("CONTINUAR JOGO", if (hasCareer) "RETOME SUA CARREIRA" else "NENHUMA CARREIRA SALVA", MenuRed, Icons.Filled.FolderOpen, hasCareer, onContinue, compact, Modifier.weight(1f))
                MenuOptionCard("CONFIGURAÇÕES", "AJUSTE O JOGO", MenuRed, Icons.Filled.Settings, true, onSettings, compact, Modifier.weight(1f))
            }
            Text("F1 TEAM MANAGER  •  CARREIRA ESTRATÉGICA", color=Color(0x99FFFFFF), fontSize=9.sp, fontWeight=FontWeight.SemiBold, textAlign=TextAlign.Center, modifier=Modifier.padding(top=8.dp))
        }
    }
}

@Composable
private fun MenuOptionCard(
    title: String,
    subtitle: String,
    accent: Color,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    enabled: Boolean,
    onClick: () -> Unit,
    compact: Boolean,
    modifier: Modifier = Modifier
) {
    val shape = RoundedCornerShape(topStart = 18.dp, topEnd = 10.dp, bottomEnd = 18.dp, bottomStart = 10.dp)
    Row(
        modifier = modifier.fillMaxWidth().clip(shape)
            .background(Brush.linearGradient(listOf(Color(0xEE17191F), Color(0xF5080A0E))))
            .border(1.dp, Color(0xAA8A8F98), shape)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = if (compact) 13.dp else 16.dp, vertical = if (compact) 5.dp else 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.width(if (compact) 5.dp else 6.dp).fillMaxHeight().clip(RoundedCornerShape(4.dp)).background(if (enabled) accent else Color(0xFF555861)))
        Spacer(Modifier.width(if (compact) 12.dp else 16.dp))
        Icon(icon, contentDescription = null, tint = if (enabled) accent else Color(0xFF777B83), modifier = Modifier.size(if (compact) 30.dp else 36.dp))
        Spacer(Modifier.width(if (compact) 12.dp else 16.dp))
        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.Center) {
            Text(title, color = if (enabled) MenuWhite else Color(0xFF92959C), fontSize = if (compact) 15.sp else 17.sp, lineHeight = if (compact) 18.sp else 20.sp, fontWeight = FontWeight.Black, maxLines = 1, softWrap = false, overflow = TextOverflow.Clip)
            Spacer(Modifier.height(3.dp))
            Text(subtitle, color = MenuMuted, fontSize = if (compact) 8.sp else 10.sp, lineHeight = if (compact) 10.sp else 12.sp, fontWeight = FontWeight.Medium, maxLines = 1, softWrap = false, overflow = TextOverflow.Clip)
        }
        Spacer(Modifier.width(5.dp))
        Icon(Icons.Filled.ChevronRight, contentDescription = null, tint = if (enabled) accent else Color(0xFF555861), modifier = Modifier.size(if (compact) 26.dp else 30.dp))
    }
}

@Composable
internal fun InitialSettingsScreen(onBack: () -> Unit) {
    Box(Modifier.fillMaxSize().background(Color(0xFF08090C)).statusBarsPadding().navigationBarsPadding().padding(20.dp)) {
        Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.clickable(onClick = onBack).padding(vertical = 8.dp)) {
                Icon(Icons.Filled.ArrowBack, contentDescription = "Voltar", tint = MenuRed)
                Spacer(Modifier.width(12.dp))
                Text("CONFIGURAÇÕES", color = MenuWhite, fontSize = 21.sp, fontWeight = FontWeight.Black)
            }
            Text("As preferências gerais serão conectadas aqui sem alterar os dados da carreira.", color = MenuMuted, fontSize = 14.sp, lineHeight = 20.sp)
        }
    }
}
