# V319 — Redesenho compacto da seleção de pneus para BOX

- Cabeçalho reorganizado com título em duas linhas e marca F1 MANAGER, sem fixar um circuito que não esteja presente no snapshot.
- Reduzido o limite máximo do diálogo e ajustados padding e espaçamento vertical para a altura útil do POCO X7 Pro.
- Cards dos cinco compostos mais baixos, mantendo composto, vida estimada, destaque de recomendação e seleção por toque.
- Reduzida a altura dos botões de plano, manter plano, confirmar composto e sair sem BOX.
- Mantidos os dados dinâmicos, recomendações meteorológicas e callbacks do motor.
- Mantida a rolagem vertical para que as ações continuem acessíveis em ecrãs mais baixos.
