# V321 — Correção dos erros de compilação reportados

- Corrigidas referências inexistentes a `RaceCarStatus.teamName` nos cards fixos dos pilotos; a equipa é resolvida pelo `DriverDefinition.teamId` e `WorldDatabase.teams`.
- Corrigido o fechamento extra de bloco no fim do componente `Race`, que provocava `Syntax error: Expecting a top level declaration`.
- Preservada a correção V320: o card do evento aparece antes do card de decisão do manager.
- Nome oficial do ZIP preservado.
