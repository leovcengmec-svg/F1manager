# Auditoria V320

## Correção
- A renderização do card do manager está condicionada a `activeRaceEventCard == null`.
- O card de evento é renderizado sempre que existe evento ativo e não há um diálogo de pneus aberto, mesmo que `s.decision` já esteja preenchido.
- O callback `onContinue` remove apenas o primeiro lote da fila; a decisão pendente continua intacta e aparece após o evento.
- O coordenador de pausa já considera evento e decisão; nenhuma alteração necessária nesse efeito.

## Validação
- Verificados os dois condicionais e os callbacks no código.
- Verificado versionCode 320 / versionName 0.320.0.
- Integridade do ZIP verificada.
- Compilação Android e teste físico não executados.
