package com.f1teammanager

import android.util.AtomicFile
import com.f1teammanager.core.manager.AITeamDevelopmentCheckpointStore
import com.f1teammanager.core.manager.AITeamDevelopmentHistoricalCheckpoint
import com.f1teammanager.core.manager.CarComponent
import com.f1teammanager.core.manager.GarageCarId
import com.f1teammanager.core.manager.PhysicalCar
import com.f1teammanager.core.manager.TeamFacilitiesState
import com.f1teammanager.core.manager.TeamGarage
import com.f1teammanager.core.manager.TeamCarState
import com.f1teammanager.core.manager.FacilityType
import org.json.JSONObject
import java.io.File

/**
 * Small, disposable, crash-safe disk cache for deterministic AI car-development
 * checkpoints. The career/save remains authoritative; corrupt or mismatched cache
 * files are ignored and rebuilt by AITeamDevelopmentEngine.
 */
class AiDevelopmentCheckpointStore(private val directory: File) : AITeamDevelopmentCheckpointStore {
    private val lock = Any()

    override fun loadCandidates(teamId: Int, beforeSeason: Int): List<AITeamDevelopmentHistoricalCheckpoint> = synchronized(lock) {
        if (!directory.exists()) return@synchronized emptyList()
        val prefix = "team_${teamId}_opening_"
        directory.listFiles()
            ?.filter { it.isFile && it.name.startsWith(prefix) && it.name.endsWith(".json") }
            ?.mapNotNull(::readCheckpoint)
            ?.filter { it.teamId == teamId && it.openingSeason < beforeSeason }
            ?.sortedByDescending { it.openingSeason }
            .orEmpty()
    }

    override fun save(checkpoint: AITeamDevelopmentHistoricalCheckpoint) = synchronized(lock) {
        if (!directory.exists() && !directory.mkdirs()) return@synchronized
        val file = checkpointFile(checkpoint)
        val atomic = AtomicFile(file)
        val bytes = encodeCheckpoint(checkpoint).toByteArray(Charsets.UTF_8)
        var stream: java.io.FileOutputStream? = null
        try {
            stream = atomic.startWrite()
            stream.write(bytes)
            atomic.finishWrite(stream)
            stream = null
            prune(checkpoint.teamId)
        } catch (_: Throwable) {
            stream?.let { atomic.failWrite(it) }
        }
    }

    // Fingerprint is part of the filename because the game has two deterministic AI
    // simulation paths with different seeds. They must never overwrite each other's
    // checkpoints even though they share the same disposable checkpoint directory.
    private fun checkpointFile(checkpoint: AITeamDevelopmentHistoricalCheckpoint) =
        File(directory, "team_${checkpoint.teamId}_opening_${checkpoint.openingSeason}_${checkpoint.fingerprint.take(16)}.json")

    private fun prune(teamId: Int) {
        val prefix = "team_${teamId}_opening_"
        val files = directory.listFiles()
            ?.filter { it.isFile && it.name.startsWith(prefix) && it.name.endsWith(".json") }
            ?.sortedWith(
                compareByDescending<File> { it.name.substringAfter("_opening_").substringBefore("_").toIntOrNull() ?: 0 }
                    .thenByDescending { it.lastModified() }
            )
            .orEmpty()
        // Keep a small rolling window per team. Eight entries safely accommodate
        // separate simulation seeds/scopes while bounding disk growth over decades.
        files.drop(8).forEach { stale -> runCatching { AtomicFile(stale).delete() } }
    }

    private fun encodeCheckpoint(checkpoint: AITeamDevelopmentHistoricalCheckpoint): String {
        val json = JSONObject()
            .put("schema", 3)
            .put("canonicalSeasonOpening", checkpoint.canonicalSeasonOpening)
            .put("teamId", checkpoint.teamId)
            .put("openingSeason", checkpoint.openingSeason)
            .put("fingerprint", checkpoint.fingerprint)
            .put("car1", encodeCar(checkpoint.garage.car1))
            .put("car2", encodeCar(checkpoint.garage.car2))
            .put("legacyCar", encodeLegacyCar(checkpoint.legacyCar))
        val facilityLevels = JSONObject()
        FacilityType.values().forEach { facilityLevels.put(it.name, checkpoint.facilities.level(it)) }
        json.put("facilities", facilityLevels)
        return json.toString()
    }

    private fun encodeCar(car: PhysicalCar): JSONObject {
        val reliabilities = JSONObject()
        CarComponent.values().forEach { component ->
            reliabilities.put(component.name, car.componentReliabilities[component] ?: car.reliability)
        }
        val installed = JSONObject()
        car.installedPieces.forEach { (component, pieceId) -> installed.put(component.name, pieceId) }
        val versions = JSONObject()
        car.installedPieceVersions.forEach { (component, version) -> versions.put(component.name, version) }
        return JSONObject()
            .put("id", car.id.name)
            .put("engine", car.engine)
            .put("chassis", car.chassis)
            .put("frontWing", car.frontWing)
            .put("rearWing", car.rearWing)
            .put("brakes", car.brakes)
            .put("electricPowerUnit", car.electricPowerUnit)
            .put("reliability", car.reliability)
            .put("componentReliabilities", reliabilities)
            .put("installedPieces", installed)
            .put("installedPieceVersions", versions)
    }

    private fun readCheckpoint(file: File): AITeamDevelopmentHistoricalCheckpoint? = runCatching {
        val json = JSONObject(AtomicFile(file).openRead().bufferedReader(Charsets.UTF_8).use { it.readText() })
        require(json.optInt("schema") in 2..3)
        val teamId = json.getInt("teamId")
        val openingSeason = json.getInt("openingSeason")
        val fingerprint = json.getString("fingerprint")
        val car1 = decodeCar(json.getJSONObject("car1"))
        val car2 = decodeCar(json.getJSONObject("car2"))
        val levelsJson = json.optJSONObject("facilities") ?: JSONObject()
        val levels = FacilityType.values().associateWith { type -> levelsJson.optInt(type.name, 0).coerceIn(0, 10) }
        AITeamDevelopmentHistoricalCheckpoint(
            teamId = teamId,
            openingSeason = openingSeason,
            fingerprint = fingerprint,
            garage = TeamGarage(car1, car2).normalized(),
            facilities = TeamFacilitiesState(levels),
            legacyCar = json.optJSONObject("legacyCar")?.let(::decodeLegacyCar)
                ?: TeamCarState(
                    aerodynamics = car1.frontWing,
                    chassis = car1.chassis,
                    engine = car1.engine,
                    reliability = ((car1.reliability + car2.reliability) / 2),
                    frontWing = car1.frontWing,
                    rearWing = car1.rearWing,
                    brakes = car1.brakes,
                    electricPowerUnit = car1.electricPowerUnit
                ).normalized(),
            canonicalSeasonOpening = json.optBoolean("canonicalSeasonOpening", false)
        )
    }.getOrNull()

    private fun decodeCar(json: JSONObject): PhysicalCar {
        val reliabilityJson = json.optJSONObject("componentReliabilities") ?: JSONObject()
        val installedJson = json.optJSONObject("installedPieces") ?: JSONObject()
        val versionsJson = json.optJSONObject("installedPieceVersions") ?: JSONObject()
        val reliabilities = CarComponent.values().mapNotNull { component ->
            if (reliabilityJson.has(component.name)) component to reliabilityJson.optInt(component.name, 100) else null
        }.toMap()
        val installed = CarComponent.values().mapNotNull { component ->
            installedJson.optString(component.name).takeIf { it.isNotBlank() }?.let { component to it }
        }.toMap()
        val versions = CarComponent.values().mapNotNull { component ->
            if (versionsJson.has(component.name)) component to versionsJson.optInt(component.name, 0) else null
        }.toMap()
        return PhysicalCar(
            id = GarageCarId.valueOf(json.getString("id")),
            engine = json.getInt("engine"),
            chassis = json.getInt("chassis"),
            frontWing = json.getInt("frontWing"),
            rearWing = json.getInt("rearWing"),
            brakes = json.getInt("brakes"),
            electricPowerUnit = json.getInt("electricPowerUnit"),
            reliability = json.optInt("reliability", 100),
            componentReliabilities = reliabilities,
            installedPieces = installed,
            installedPieceVersions = versions
        ).normalized()
    }

    private fun encodeLegacyCar(car: TeamCarState): JSONObject = JSONObject()
        .put("aerodynamics", car.aerodynamics)
        .put("chassis", car.chassis)
        .put("engine", car.engine)
        .put("reliability", car.reliability)
        .put("frontWing", car.frontWing)
        .put("rearWing", car.rearWing)
        .put("brakes", car.brakes)
        .put("electricPowerUnit", car.electricPowerUnit)

    private fun decodeLegacyCar(json: JSONObject): TeamCarState = TeamCarState(
        aerodynamics = json.optInt("aerodynamics", 40),
        chassis = json.optInt("chassis", 40),
        engine = json.optInt("engine", 40),
        reliability = json.optInt("reliability", 100),
        frontWing = json.optInt("frontWing", json.optInt("aerodynamics", 40)),
        rearWing = json.optInt("rearWing", json.optInt("aerodynamics", 40)),
        brakes = json.optInt("brakes", json.optInt("chassis", 40)),
        electricPowerUnit = json.optInt("electricPowerUnit", json.optInt("engine", 40))
    ).normalized()
}
