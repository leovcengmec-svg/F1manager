package com.f1teammanager

import android.content.Context
import com.f1teammanager.core.manager.DevelopmentProject
import com.f1teammanager.core.manager.TeamCarState
import com.f1teammanager.core.manager.TeamFinanceState
import com.f1teammanager.core.manager.SponsorContract
import com.f1teammanager.core.race.RaceResult
import com.f1teammanager.core.race.Tyre
import com.f1teammanager.core.season.WorldDatabase

/** Persistent career metadata, championship ledger, race archive and car P&D state. */
class CareerPreferences(context: Context) {
    private val prefs = context.getSharedPreferences("f1tm_career", Context.MODE_PRIVATE)

    var hasCareer: Boolean
        get() = prefs.getBoolean("hasCareer", false)
        private set(value) = prefs.edit().putBoolean("hasCareer", value).apply()
    var teamId: Int
        get() = prefs.getInt("teamId", 1)
        private set(value) = prefs.edit().putInt("teamId", value).apply()
    var roundIndex: Int
        get() = prefs.getInt("roundIndex", 0)
        private set(value) = prefs.edit().putInt("roundIndex", value.coerceIn(0, WorldDatabase.rounds.lastIndex)).apply()
    var season: Int
        get() = prefs.getInt("season", 2026)
        private set(value) = prefs.edit().putInt("season", value).apply()

    private fun readMap(key: String): Map<Int, Int> = prefs.getString(key, "").orEmpty().split(',').mapNotNull { token ->
        val p = token.split(':')
        if (p.size == 2) p[0].toIntOrNull()?.let { id -> p[1].toIntOrNull()?.let { value -> id to value } } else null
    }.toMap()
    private fun writeMap(key: String, value: Map<Int, Int>) = prefs.edit().putString(key, value.entries.sortedBy { it.key }.joinToString(",") { "${it.key}:${it.value}" }).apply()
    fun driverPoints(): Map<Int, Int> = readMap("driverPoints")
    fun constructorPoints(): Map<Int, Int> = readMap("constructorPoints")

    fun recordRace(round: Int, result: RaceResult) {
        val drivers = driverPoints().toMutableMap()
        result.points.forEach { (id, pts) -> drivers[id] = (drivers[id] ?: 0) + pts }
        writeMap("driverPoints", drivers)
        val teams = constructorPoints().toMutableMap()
        result.classification.forEach { f ->
            val tid = WorldTeamResolver.teamIdFor(f.driverId)
            teams[tid] = (teams[tid] ?: 0) + (result.points[f.driverId] ?: 0)
        }
        writeMap("constructorPoints", teams)
        val encoded = result.classification.joinToString(";") { f ->
            listOf(f.position, f.driverId, f.laps, f.totalTimeMs, f.status.replace(";", ","), f.tyre.name, f.pitStops, result.points[f.driverId] ?: 0).joinToString(",")
        }
        prefs.edit().putString("race_$round", encoded).apply()
    }

    fun raceHistory(round: Int): RaceResult? = runCatching {
        val raw = prefs.getString("race_$round", null) ?: return null
        val classification = raw.split(';').filter { it.isNotBlank() }.map { row ->
            val p = row.split(',')
            val id = p[1].toInt()
            val driver = WorldDatabase.drivers.first { it.id == id }
            val team = WorldDatabase.teams.first { it.id == driver.teamId }
            FinishEntryCompat(p[0].toInt(), id, driver.name, team.name, p[2].toInt(), p[3].toLong(), p[4], Tyre.valueOf(p[5]), p[6].toInt())
        }
        val points = raw.split(';').filter { it.isNotBlank() }.associate { row -> val p=row.split(','); p[1].toInt() to p[7].toInt() }
        RaceResult(classification.map { it.toFinish() }, emptyList(), null, com.f1teammanager.core.race.Weather.DRY, points, 0, 0)
    }.getOrNull()

    private data class FinishEntryCompat(val position:Int,val driverId:Int,val driverName:String,val teamName:String,val laps:Int,val totalTimeMs:Long,val status:String,val tyre:Tyre,val pitStops:Int) {
        fun toFinish() = com.f1teammanager.core.race.FinishEntry(position,driverId,driverName,teamName,laps,totalTimeMs,status,tyre,pitStops)
    }

    fun loadCar(forTeamId: Int): TeamCarState? = runCatching {
        if (prefs.getInt("carTeam", -1) != forTeamId) return null
        TeamCarState(
            aerodynamics=prefs.getInt("carAero", 70), chassis=prefs.getInt("carChassis",70), engine=prefs.getInt("carEngine",70), reliability=prefs.getInt("carReliability",70),
            frontWing=prefs.getInt("carFrontWing",70), rearWing=prefs.getInt("carRearWing",70), brakes=prefs.getInt("carBrakes",70), electricPowerUnit=prefs.getInt("carErs",70),
            activeProject=if (prefs.getString("projectComponent", null) != null) DevelopmentProject(
                com.f1teammanager.core.manager.CarComponent.valueOf(prefs.getString("projectComponent", "ENGINE")!!),
                prefs.getInt("projectRemaining", 1), prefs.getInt("projectTotal", 1), prefs.getInt("projectLevel", 1)
            ) else null
        ).normalized()
    }.getOrNull()

    fun saveCar(forTeamId:Int, car:TeamCarState) {
        val e=prefs.edit().putInt("carTeam",forTeamId).putInt("carAero",car.aerodynamics).putInt("carChassis",car.chassis).putInt("carEngine",car.engine).putInt("carReliability",car.reliability)
            .putInt("carFrontWing",car.frontWing).putInt("carRearWing",car.rearWing).putInt("carBrakes",car.brakes).putInt("carErs",car.electricPowerUnit)
        if (car.activeProject == null) e.remove("projectComponent").remove("projectRemaining").remove("projectTotal").remove("projectLevel")
        else car.activeProject.let { e.putString("projectComponent",it.component.name).putInt("projectRemaining",it.remainingWeeks).putInt("projectTotal",it.totalWeeks).putInt("projectLevel",it.level) }
        e.apply()
    }


    fun loadFinance(forTeamId:Int, fallback:TeamFinanceState): TeamFinanceState {
        if (prefs.getInt("financeTeam", -1) != forTeamId) return fallback
        return TeamFinanceState(
            budget=prefs.getLong("budget", fallback.budget),
            seasonIncome=prefs.getLong("seasonIncome", fallback.seasonIncome),
            seasonExpenses=prefs.getLong("seasonExpenses", fallback.seasonExpenses),
            raceIncome=prefs.getLong("raceIncome", fallback.raceIncome),
            raceExpenses=prefs.getLong("raceExpenses", fallback.raceExpenses)
        )
    }
    fun saveFinance(forTeamId:Int, finance:TeamFinanceState) {
        prefs.edit().putInt("financeTeam",forTeamId).putLong("budget",finance.budget).putLong("seasonIncome",finance.seasonIncome).putLong("seasonExpenses",finance.seasonExpenses).putLong("raceIncome",finance.raceIncome).putLong("raceExpenses",finance.raceExpenses).apply()
    }
    fun loadSponsor(forTeamId:Int, fallback:SponsorContract): SponsorContract {
        if (prefs.getInt("sponsorTeam", -1) != forTeamId) return fallback
        return SponsorContract(prefs.getString("sponsorName",fallback.name) ?: fallback.name,prefs.getLong("sponsorUpfront",fallback.upfront),prefs.getLong("sponsorRace",fallback.racePayment),prefs.getLong("sponsorPoints",fallback.pointsBonus),prefs.getInt("sponsorYears",fallback.years),prefs.getInt("sponsorRep",fallback.minimumReputation))
    }
    fun saveSponsor(forTeamId:Int, sponsor:SponsorContract) {
        prefs.edit().putInt("sponsorTeam",forTeamId).putString("sponsorName",sponsor.name).putLong("sponsorUpfront",sponsor.upfront).putLong("sponsorRace",sponsor.racePayment).putLong("sponsorPoints",sponsor.pointsBonus).putInt("sponsorYears",sponsor.years).putInt("sponsorRep",sponsor.minimumReputation).apply()
    }

    fun startNewCareer(selectedTeamId: Int) {
        teamId = selectedTeamId; roundIndex = 0; season = 2026; hasCareer = true
        writeMap("driverPoints", emptyMap()); writeMap("constructorPoints", emptyMap())
        for (r in 1..WorldDatabase.rounds.size) prefs.edit().remove("race_$r").apply()
        val t=WorldDatabase.teams.first { it.id==selectedTeamId }
        saveCar(selectedTeamId, TeamCarState(t.baseCar,t.chassis,t.engine,t.reliability,frontWing=t.frontWing,rearWing=t.rearWing,brakes=t.brakes,electricPowerUnit=t.electricPowerUnit))
        saveFinance(selectedTeamId, TeamFinanceState(75_000_000L)); saveSponsor(selectedTeamId, SponsorContract("Patrocinador Base",1_000_000,2_000_000,15_000,1,0))
    }

    fun advanceRound() {
        if (roundIndex < WorldDatabase.rounds.lastIndex) roundIndex += 1 else { season += 1; roundIndex = 0; writeMap("driverPoints", emptyMap()); writeMap("constructorPoints", emptyMap()) }
    }
}
private object WorldTeamResolver { fun teamIdFor(driverId: Int): Int = ((driverId - 1) / 2) + 1 }
