package com.f1teammanager

import android.content.Context
import com.f1teammanager.core.manager.DevelopmentProject
import com.f1teammanager.core.manager.FinanceEngine
import com.f1teammanager.core.manager.TeamManagerState
import com.f1teammanager.core.manager.DevelopmentIntensity
import com.f1teammanager.core.manager.ResearchProject
import com.f1teammanager.core.manager.ResearchDesign
import com.f1teammanager.core.manager.TeamResearchState
import com.f1teammanager.core.manager.CarPiece
import com.f1teammanager.core.manager.FactoryOrder
import com.f1teammanager.core.manager.TeamFactoryState
import com.f1teammanager.core.manager.TeamGarage
import com.f1teammanager.core.manager.PhysicalCar
import com.f1teammanager.core.manager.GarageCarId
import com.f1teammanager.core.manager.CarComponent
import com.f1teammanager.core.manager.ResearchFocus
import com.f1teammanager.core.manager.ResearchComplexity
import com.f1teammanager.core.manager.ResearchOutcome
import com.f1teammanager.core.manager.CarDevelopmentFocus
import com.f1teammanager.core.manager.TeamCarState
import com.f1teammanager.core.manager.TeamFinanceState
import com.f1teammanager.core.manager.TeamFacilitiesState
import com.f1teammanager.core.manager.FacilityType
import com.f1teammanager.core.manager.InitialTeamProfile
import com.f1teammanager.core.manager.SponsorContract
import com.f1teammanager.core.race.RaceResult
import com.f1teammanager.core.race.QualifyingResult
import com.f1teammanager.core.season.RoundDefinition
import com.f1teammanager.core.race.Tyre
import com.f1teammanager.core.season.WorldDatabase
import com.f1teammanager.core.season.DriverEvolutionEngine
import com.f1teammanager.core.season.DriverProfileCatalog
import com.f1teammanager.core.manager.DriverMarketState
import com.f1teammanager.core.manager.DriverMarketEngine
import com.f1teammanager.core.manager.DriverDeal
import com.f1teammanager.core.manager.DriverOffer
import com.f1teammanager.core.manager.FutureDriverDeal
import com.f1teammanager.core.manager.DriverTeamRole
import com.f1teammanager.core.manager.DriverRolePreference
import com.f1teammanager.core.manager.NegotiationStatus
import com.f1teammanager.core.manager.ScoutingReport
import com.f1teammanager.core.manager.MarketNotification
import com.f1teammanager.core.manager.MarketNewsCategory
import com.f1teammanager.core.season.SeasonCalendar

/** Persistent career metadata, championship ledger, race archive and car P&D state. */
class CareerPreferences(context: Context) {
    val history = HistoricalDatabase(context)
    private val prefs = context.getSharedPreferences("f1tm_career", Context.MODE_PRIVATE)

    init {
        // Restore the persisted calendar draw before any property/core engine can
        // ask SeasonCalendar for the current season.
        val storedSeason = prefs.getInt("season", 2026)
        val storedSeed = prefs.getInt("calendarSeed_$storedSeason", 0)
        if (storedSeed != 0) {
            SeasonCalendar.configureSeasonSeed(storedSeason, storedSeed)
            com.f1teammanager.core.manager.InitialTeamProfile.configureCareerSeed(storedSeed)
        }
    }

    private fun newCalendarSeed(season: Int): Int {
        val seed = kotlin.random.Random.nextInt().let { if (it == 0) 1 else it }
        prefs.edit().putInt("calendarSeed_$season", seed).apply()
        SeasonCalendar.configureSeasonSeed(season, seed)
        com.f1teammanager.core.manager.InitialTeamProfile.configureCareerSeed(seed)
        return seed
    }

    var hasCareer: Boolean
        get() = prefs.getBoolean("hasCareer", false)
        private set(value) = prefs.edit().putBoolean("hasCareer", value).apply()
    var teamId: Int
        get() = prefs.getInt("teamId", 1)
        private set(value) = prefs.edit().putInt("teamId", value).apply()
    var roundIndex: Int
        get() = prefs.getInt("roundIndex", 0)
        private set(value) = prefs.edit().putInt("roundIndex", value.coerceIn(0, SeasonCalendar.forSeason(season).lastIndex)).apply()
    /** Current calendar week. Race weekends occupy specific weeks; the other weeks are free development weeks. */
    var currentWeek: Int
        get() = prefs.getInt("currentWeek", SeasonCalendar.forSeason(season).first().weekOfSeason.coerceAtLeast(1) - 2).coerceIn(1, 56)
        private set(value) = prefs.edit().putInt("currentWeek", value.coerceIn(1, 56)).apply()
    var season: Int
        get() = prefs.getInt("season", 2026)
        private set(value) = prefs.edit().putInt("season", value).apply()

    private fun readMap(key: String): Map<Int, Int> = prefs.getString(key, "").orEmpty().split(',').mapNotNull { token ->
        val p = token.split(':')
        if (p.size == 2) p[0].toIntOrNull()?.let { id -> p[1].toIntOrNull()?.let { value -> id to value } } else null
    }.toMap()
    private fun writeMap(key: String, value: Map<Int, Int>) = prefs.edit().putString(key, value.entries.sortedBy { it.key }.joinToString(",") { "${it.key}:${it.value}" }).apply()

    private fun readDoubleMap(key: String): Map<Int, Double> = prefs.getString(key, "").orEmpty().split(',').mapNotNull { token ->
        val p=token.split(':')
        if (p.size != 2) null else p[0].toIntOrNull()?.let { id -> p[1].toDoubleOrNull()?.let { value -> id to value } }
    }.toMap()
    private fun writeDoubleMap(key: String, value: Map<Int, Double>) = prefs.edit().putString(key, value.entries.sortedBy { it.key }.joinToString(",") { "${it.key}:${it.value}" }).apply()
    fun driverPoints(): Map<Int, Int> = readMap("driverPoints")
    fun constructorPoints(): Map<Int, Int> = readMap("constructorPoints")

    /** V36 canonical financial settlement ledger for every team, including AI. */
    fun aiTeamBudget(teamId: Int): Long {
        val raw = prefs.getString("aiTeamBudgets", "").orEmpty()
        return raw.split(";").firstOrNull { it.startsWith("$teamId:") }?.substringAfter(":")?.toLongOrNull()
            ?: WorldDatabase.teams.firstOrNull { it.id == teamId }?.let { InitialTeamProfile.initialBudget(it) }
                ?: 0L
    }

    fun loadAiFinanceSnapshot(): String = prefs.getString("aiFinanceSnapshot", "").orEmpty()
    fun saveAiFinanceSnapshot(raw:String) { prefs.edit().putString("aiFinanceSnapshot", raw).apply() }
    fun loadAiSponsorshipSnapshot(): String = prefs.getString("aiSponsorshipSnapshot", "").orEmpty()
    fun saveAiSponsorshipSnapshot(raw:String) { prefs.edit().putString("aiSponsorshipSnapshot", raw).apply() }

    private fun saveAiTeamBudgets(values: Map<Int, Long>) {
        prefs.edit().putString("aiTeamBudgets", values.toSortedMap().entries.joinToString(";") { "${it.key}:${it.value}" }).apply()
    }

    /**
     * The only Android-facing season-prize entry point. It settles all 40 teams
     * atomically from the same constructor standings used by the history.
     * Idempotency is per season and per team, so reopening GP30 cannot duplicate money.
     */
    fun settleConstructorsSeason(seasonToClose: Int): List<com.f1teammanager.core.manager.SeasonSettlementEngine.Settlement> {
        require(season == seasonToClose) { "Temporada de fechamento divergente" }
        if (!history.isSeasonFinalized(seasonToClose)) {
            history.finalizeSeason(seasonToClose, driverPoints(), constructorPoints(), loadDriverMarket())
        }
        val settlements = com.f1teammanager.core.manager.SeasonSettlementEngine.settleAll(constructorPoints())
        val paid = prefs.getString("constructorPrizePaidTeams_$seasonToClose", "").orEmpty().split(",").mapNotNull { it.toIntOrNull() }.toMutableSet()
        var aiBudgets = WorldDatabase.teams.filter { it.id != teamId }.associate { it.id to aiTeamBudget(it.id) }.toMutableMap()
        val playerFinance = loadFinance(teamId, TeamFinanceState(0L))
        var player = playerFinance
        settlements.forEach { settlement ->
            if (settlement.teamId == teamId) {
                if (teamId !in paid) {
                    player = FinanceEngine().applySeasonConstructorsPrize(
                        TeamManagerState(playerTeamId=teamId, season=seasonToClose, round=SeasonCalendar.forSeason(season).size,
                            car=TeamCarState(70,70,70,70), finance=player, driverMarket=loadDriverMarket() ?: DriverMarketEngine().initialState(seasonToClose)),
                        seasonToClose, settlement.position
                    ).finance
                }
            } else if (settlement.teamId !in paid) {
                aiBudgets[settlement.teamId] = aiBudgets.getValue(settlement.teamId) + settlement.prize
            }
        }
        if (teamId !in paid) {
            saveFinance(teamId, player)
        }
        paid.addAll(settlements.map { it.teamId })
        prefs.edit().putString("constructorPrizePaidTeams_$seasonToClose", paid.sorted().joinToString(",")).apply()
        saveAiTeamBudgets(aiBudgets)
        return settlements
    }
    fun previousDriverPositions(): Map<Int, Int> = readMap("previousDriverPositions")
    fun previousConstructorPositions(): Map<Int, Int> = readMap("previousConstructorPositions")

    fun loadDriverMarket(): DriverMarketState? = runCatching {
        val rawContracts = prefs.getString("marketContracts", null) ?: return null
        val contracts = rawContracts.split(';').filter { it.isNotBlank() }.mapNotNull { row ->
            val p=row.split(','); runCatching {
                if (p.size >= 8) DriverDeal(p[0].toInt(),p[1].toInt(),p[2].toInt(),p[3].toLong(),p[4].toLong(),p[6].toInt(),DriverTeamRole.valueOf(p[7]))
                else if (p.size >= 7) DriverDeal(p[0].toInt(),p[1].toInt(),p[2].toInt(),p[3].toLong(),p[4].toLong(),p[5].toInt(),DriverTeamRole.EQUAL)
                else null
            }.getOrNull()
        }
        val free=prefs.getString("marketFree", "").orEmpty().split(',').mapNotNull{it.toIntOrNull()}
        val scheduled=prefs.getString("marketScheduled", "").orEmpty().split(';').filter{it.isNotBlank()}.mapNotNull { row ->
            val p=row.split(','); runCatching {
                if (p.size >= 10) FutureDriverDeal(p[0].toInt(),p[1].toInt(),p[2].toInt(),p[3].toInt(),p[4].toInt(),p[5].toLong(),DriverTeamRole.valueOf(p[6]),p[7].toInt(),p.getOrNull(9)?.toIntOrNull())
                else if (p.size >= 9) FutureDriverDeal(p[0].toInt(),p[1].toInt(),p[2].toInt(),p[3].toInt(),p[4].toInt(),p[5].toLong(),DriverTeamRole.valueOf(p[6]),p[7].toInt(),null)
                else null
            }.getOrNull()
        }
        val roles=prefs.getString("marketRoles", "").orEmpty().split(',').mapNotNull{part -> val p=part.split(':'); if(p.size==2) runCatching{p[0].toInt() to DriverRolePreference.valueOf(p[1])}.getOrNull() else null}.toMap()
        val pending=prefs.getString("marketPending", "").orEmpty().split(';').filter{it.isNotBlank()}.mapNotNull { row ->
            val p=row.split(','); runCatching {
                if (p.size >= 13 && runCatching { NegotiationStatus.valueOf(p[10]) }.isSuccess) DriverOffer(p[0].toInt(),p[1].toInt(),p[2].toInt(),p[3].toInt(),p[4].toLong(),DriverTeamRole.valueOf(p[5]),p[6].toLong(),p[7].toInt(),p[8].toInt(),p[9].toInt(),NegotiationStatus.valueOf(p[10]),p[11].toInt(),p.getOrNull(12)?.toIntOrNull(),p.getOrNull(13)?.toIntOrNull() ?: 0)
                else if (p.size >= 13) DriverOffer(p[0].toInt(),p[1].toInt(),p[2].toInt(),p[3].toInt(),p[4].toLong(),DriverTeamRole.valueOf(p[5]),p[6].toLong(),p[8].toInt(),p[9].toInt(),p[10].toInt(),NegotiationStatus.valueOf(p[11]),p[12].toInt(),null,0)
                else null
            }.getOrNull()
        }
        val scouting=prefs.getString("marketScouting", "").orEmpty().split(';').filter{it.isNotBlank()}.mapNotNull { row ->
            val p=row.split(','); runCatching {
                if (p.size >= 12) ScoutingReport(p[0].toInt(),p[1].toInt(),p[2].toLong(),p[3].toInt(),p[4].toInt(),p[5].toLong(),p[6].toLong(),DriverRolePreference.valueOf(p[8]),p[9].toInt(),p[10].toInt(),p[11])
                else if (p.size >= 10) ScoutingReport(p[0].toInt(),p[1].toInt(),p[2].toLong(),p[3].toInt(),p[4].toInt(),p[5].toLong(),p[6].toLong(),DriverRolePreference.valueOf(p[8]),p[9].toInt(),2026,"")
                else if (p.size >= 9) ScoutingReport(p[0].toInt(),p[1].toInt(),p[2].toLong(),p[3].toInt(),p[4].toInt(),p[5].toLong(),p[6].toLong(),DriverRolePreference.valueOf(p[7]),p[8].toInt(),2026,"")
                else null
            }.getOrNull()
        }
        val notifications=prefs.getString("marketNotifications", "").orEmpty().split(';').filter{it.isNotBlank()}.mapNotNull { row ->
            val p=row.split('|', limit=6); if(p.size<5) null else runCatching { MarketNotification(p[0].toInt(),p[1].toInt(),p[2],p[3],p[4].toBoolean(), p.getOrNull(5)?.let { runCatching { com.f1teammanager.core.manager.MarketNewsCategory.valueOf(it) }.getOrNull() } ?: com.f1teammanager.core.manager.MarketNewsCategory.MARKET) }.getOrNull()
        }
        DriverMarketState(contracts=contracts,freeAgents=free,scheduled=scheduled,rolePreferences=roles,pending=pending,scouting=scouting,notifications=notifications).normalized()
    }.getOrNull()

    fun loadReadNewsKeys(): Set<String> = prefs.getString("marketNewsReadKeys", "").orEmpty()
        .split(";").filter { it.isNotBlank() }.toSet()

    fun markNewsRead(keys: Collection<String>) {
        if (keys.isEmpty()) return
        val merged = (loadReadNewsKeys() + keys).toList().takeLast(300).toSet()
        prefs.edit().putString("marketNewsReadKeys", merged.joinToString(";")).apply()
    }

    fun saveDriverMarket(state: DriverMarketState) {
        val s = state.normalized()
        prefs.edit()
            .putString("marketContracts", s.contracts.joinToString(";") { listOf(it.driverId,it.teamId,it.years,it.salary,it.marketValue,it.seasonSigned,it.role.name).joinToString(",") })
            .putString("marketFree", s.freeAgents.joinToString(","))
            .putString("marketScheduled", s.scheduled.joinToString(";") { listOf(it.driverId,it.fromTeamId,it.toTeamId,it.startSeason,it.years,it.salary,it.role.name,it.signedSeason,it.replaceDriverId).joinToString(",") })
            .putString("marketRoles", s.rolePreferences.entries.joinToString(",") { "${it.key}:${it.value.name}" })
            .putString("marketPending", s.pending.joinToString(";") { listOf(it.driverId,it.fromTeamId,it.toTeamId,it.years,it.salary,it.role.name,it.marketValue,it.interestScore,it.round,it.expiresAfterWeek,it.status.name,it.seasonTarget,it.replaceDriverId,it.proposerTeamId).joinToString(",") })
            .putString("marketScouting", s.scouting.joinToString(";") { listOf(it.driverId,it.teamId,it.cost,it.createdWeek,it.expiresWeek,it.expectedSalary,it.marketValue,it.rolePreference.name,it.interest,it.season,it.attributeRanges).joinToString(",") })
            .putString("marketNotifications", s.notifications.joinToString(";") { listOf(it.season,it.week,it.title.replace(";", ",").replace("|", "/"),it.message.replace(";", ",").replace("|", "/"),it.important,it.category.name).joinToString("|") })
            .apply()
    }

    fun recordRace(round: Int, result: RaceResult, seasonRound: RoundDefinition? = null, qualifying: QualifyingResult? = null) {
        // Capture the championship order BEFORE adding this GP. The standings screen
        // uses this snapshot to show who went up, down or stayed in the same place
        // after each completed race.
        val oldDriverPoints = driverPoints()
        val oldConstructorPoints = constructorPoints()
        val activeIdsForStandings = loadDriverMarket()?.contracts?.filter { it.activeIn(season) }?.map { it.driverId }?.distinct()
            ?: WorldDatabase.drivers.map { it.id }
        val oldDriverOrder = activeIdsForStandings
            .map { it to (oldDriverPoints[it] ?: 0) }
            .sortedWith(compareByDescending<Pair<Int,Int>> { it.second }.thenBy { it.first })
            .mapIndexed { index, row -> row.first to index + 1 }
            .toMap()
        val oldConstructorOrder = WorldDatabase.teams
            .map { it.id to (oldConstructorPoints[it.id] ?: 0) }
            .sortedWith(compareByDescending<Pair<Int,Int>> { it.second }.thenBy { it.first })
            .mapIndexed { index, row -> row.first to index + 1 }
            .toMap()
        writeMap("previousDriverPositions", oldDriverOrder)
        writeMap("previousConstructorPositions", oldConstructorOrder)

        val drivers = oldDriverPoints.toMutableMap()
        result.points.forEach { (id, pts) -> drivers[id] = (drivers[id] ?: 0) + pts }
        writeMap("driverPoints", drivers)
        val teams = oldConstructorPoints.toMutableMap()
        val activeMarket = loadDriverMarket()
        result.classification.forEach { f ->
            val tid = activeMarket?.contracts?.firstOrNull { it.driverId == f.driverId && it.activeIn(season) }?.teamId
                ?: WorldDatabase.teams.firstOrNull { it.name.equals(f.teamName, ignoreCase = true) }?.id
                ?: WorldTeamResolver.teamIdFor(f.driverId)
            teams[tid] = (teams[tid] ?: 0) + (result.points[f.driverId] ?: 0)
        }
        writeMap("constructorPoints", teams)
        val encoded = result.classification.joinToString(";") { f ->
            val teamId = activeMarket?.contracts?.firstOrNull { it.driverId == f.driverId && it.activeIn(season) }?.teamId
                ?: WorldDatabase.teams.firstOrNull { it.name.equals(f.teamName, ignoreCase = true) }?.id
                ?: WorldTeamResolver.teamIdFor(f.driverId)
            listOf(f.position, f.driverId, f.laps, f.totalTimeMs, f.status.replace(";", ","), f.tyre.name, f.pitStops, result.points[f.driverId] ?: 0, teamId).joinToString(",")
        }
        prefs.edit().putString("race_$round", encoded).apply()
        if (seasonRound != null) {
            history.recordRace(season, seasonRound, result, qualifying, activeMarket)
            // The season archive is created immediately when GP 30 finishes.
            // Returning to the calendar later must not be required to create history.
            if (seasonRound.round == SeasonCalendar.forSeason(season).size) {
                history.finalizeSeason(season, drivers, teams, activeMarket)
            }
        }
    }

    fun raceHistory(round: Int): RaceResult? = runCatching {
        val raw = prefs.getString("race_$round", null) ?: return null
        val classification = raw.split(';').filter { it.isNotBlank() }.map { row ->
            val p = row.split(',')
            val id = p[1].toInt()
            val driver = WorldDatabase.drivers.first { it.id == id }
            val teamId = p.getOrNull(8)?.toIntOrNull() ?: driver.teamId
            val team = WorldDatabase.teams.first { it.id == teamId }
            FinishEntryCompat(p[0].toInt(), id, driver.name, team.name, p[2].toInt(), p[3].toLong(), p[4], Tyre.valueOf(p[5]), p[6].toInt())
        }
        val points = raw.split(';').filter { it.isNotBlank() }.associate { row -> val p=row.split(','); p[1].toInt() to p[7].toInt() }
        RaceResult(classification.map { it.toFinish() }, emptyList(), null, com.f1teammanager.core.race.Weather.DRY, points, 0, 0)
    }.getOrNull()

    private data class FinishEntryCompat(val position:Int,val driverId:Int,val driverName:String,val teamName:String,val laps:Int,val totalTimeMs:Long,val status:String,val tyre:Tyre,val pitStops:Int) {
        fun toFinish() = com.f1teammanager.core.race.FinishEntry(position,driverId,driverName,teamName,laps,totalTimeMs,status,tyre,pitStops)
    }

    fun loadCar(forTeamId: Int): TeamCarState? = runCatching {
        if (prefs.getInt("carTeam", -1) != forTeamId) return null
        TeamCarState(
            aerodynamics=prefs.getInt("carAero", 70), chassis=prefs.getInt("carChassis",70), engine=prefs.getInt("carEngine",70), reliability=prefs.getInt("carReliability",70),
            frontWing=prefs.getInt("carFrontWing",70), rearWing=prefs.getInt("carRearWing",70), brakes=prefs.getInt("carBrakes",70), electricPowerUnit=prefs.getInt("carErs",70),
            activeProject=if (prefs.getString("projectComponent", null) != null) DevelopmentProject(
                CarComponent.valueOf(prefs.getString("projectComponent", "ENGINE")!!),
                prefs.getInt("projectRemaining", 1), prefs.getInt("projectTotal", 1), prefs.getInt("projectLevel", 1),
                runCatching { DevelopmentIntensity.valueOf(prefs.getString("projectIntensity", "STANDARD")!!) }.getOrDefault(DevelopmentIntensity.STANDARD),
                prefs.getInt("projectGain", 4), prefs.getLong("projectCost", 0L)
            ) else null,
            nextSeasonInvestment=prefs.getLong("nextSeasonInvestment",0L),
            nextSeasonFocus=runCatching { CarDevelopmentFocus.valueOf(prefs.getString("nextSeasonFocus", "BALANCED")!!) }.getOrDefault(CarDevelopmentFocus.BALANCED),
            developmentKnowledge=loadKnowledge(),
            seasonDevelopmentGain=prefs.getInt("seasonDevelopmentGain",0)
        ).normalized()
    }.getOrNull()

    fun saveCar(forTeamId:Int, car:TeamCarState) {
        val e=prefs.edit().putInt("carTeam",forTeamId).putInt("carAero",car.aerodynamics).putInt("carChassis",car.chassis).putInt("carEngine",car.engine).putInt("carReliability",car.reliability)
            .putInt("carFrontWing",car.frontWing).putInt("carRearWing",car.rearWing).putInt("carBrakes",car.brakes).putInt("carErs",car.electricPowerUnit)
        if (car.activeProject == null) e.remove("projectComponent").remove("projectRemaining").remove("projectTotal").remove("projectLevel").remove("projectIntensity").remove("projectGain").remove("projectCost")
        else car.activeProject.let { e.putString("projectComponent",it.component.name).putInt("projectRemaining",it.remainingWeeks).putInt("projectTotal",it.totalWeeks).putInt("projectLevel",it.level).putString("projectIntensity",it.intensity.name).putInt("projectGain",it.expectedGain).putLong("projectCost",it.cost) }
        e.putLong("nextSeasonInvestment",car.nextSeasonInvestment).putString("nextSeasonFocus",car.nextSeasonFocus.name).putString("developmentKnowledge",car.developmentKnowledge.entries.joinToString(",") { "${it.key.name}:${it.value}" }).putInt("seasonDevelopmentGain",car.seasonDevelopmentGain).apply()
    }


    private fun loadKnowledge(): Map<CarComponent,Int> = prefs.getString("developmentKnowledge", "").orEmpty().split(',').mapNotNull { token ->
        val p=token.split(':')
        if (p.size==2) runCatching { CarComponent.valueOf(p[0]) to p[1].toInt().coerceIn(0,8) }.getOrNull() else null
    }.toMap()

    fun loadResearch(forTeamId: Int): TeamResearchState? = runCatching {
        if (prefs.getInt("researchTeam", -1) != forTeamId) return null
        val activeRows = prefs.getString("researchActiveProjects", "").orEmpty().split(";").filter { it.isNotBlank() }
        val projects = activeRows.mapNotNull { row ->
            val p=row.split("|")
            if (p.size < 13) null else runCatching {
                ResearchProject(p[0],CarComponent.valueOf(p[1]),p[2].toInt(),p[3].toInt(),p[4].toInt(),p[5].toInt(),p[6].toInt(),p[7].toInt(),p[8].toInt(),p[9].toLong(),p[10].toInt(),ResearchFocus.valueOf(p[11]),ResearchComplexity.valueOf(p[12]),p.getOrNull(13)?.let(ResearchOutcome::valueOf) ?: ResearchOutcome.SUCCESS)
            }.getOrNull()
        }
        val legacy = if (projects.isEmpty()) prefs.getString("researchActive", null)?.split("|")?.takeIf { it.size >= 11 }?.let { p ->
            runCatching { ResearchProject(p[0],CarComponent.valueOf(p[1]),p[2].toInt(),p[3].toInt(),p[3].toInt(),p[4].toInt(),p[4].toInt(),p[6].toInt(),p[7].toInt(),p[8].toLong(),p[9].toInt(),ResearchFocus.PERFORMANCE,ResearchComplexity.MEDIUM) }.getOrNull()
        } else null
        val designs = prefs.getString("researchDesigns", "").orEmpty().split(";").filter { it.isNotBlank() }.mapNotNull { row ->
            val p=row.split("|"); if (p.size < 7) null else runCatching { ResearchDesign(p[0],CarComponent.valueOf(p[1]),p[2].toInt(),p[3].toInt(),p[4].toInt(),p[5].toInt(),p[6].toInt()) }.getOrNull()
        }
        val cooldowns = prefs.getString("researchCooldowns", "").orEmpty().split(",").filter { it.isNotBlank() }.mapNotNull { token ->
            val p=token.split(":"); if (p.size != 2) null else runCatching { CarComponent.valueOf(p[0]) to p[1].toInt() }.getOrNull()
        }.toMap()
        TeamResearchState((projects + listOfNotNull(legacy)).distinctBy { it.projectId }, designs, cooldowns)
    }.getOrNull()

    fun saveResearch(forTeamId: Int, research: TeamResearchState) {
        val e = prefs.edit().putInt("researchTeam", forTeamId)
        if (research.activeProjects.isEmpty()) e.remove("researchActiveProjects")
        else e.putString("researchActiveProjects", research.activeProjects.joinToString(";") { p ->
            listOf(p.projectId,p.component.name,p.version,p.basePerformance,p.baseReliability,p.targetPerformance,p.targetReliability,p.totalWeeks,p.remainingWeeks,p.cost,p.startedWeek,p.focus.name,p.complexity.name,p.outcome.name).joinToString("|")
        })
        e.remove("researchActive")
        e.putString("researchDesigns", research.completedDesigns.joinToString(";") { d ->
            listOf(d.designId,d.component.name,d.version,d.performance,d.reliability,d.researchSeason,d.completedWeek).joinToString("|")
        })
        e.putString("researchCooldowns", research.cooldownUntil.entries.joinToString(",") { "${it.key.name}:${it.value}" }).apply()
    }

    fun loadFactory(forTeamId: Int): TeamFactoryState? = runCatching {
        if (prefs.getInt("factoryTeam", -1) != forTeamId) return null
        val orders = prefs.getString("factoryOrders", "").orEmpty().split(";").filter { it.isNotBlank() }.mapNotNull { row ->
            val p=row.split("|")
            if (p.size < 12) null else runCatching {
                FactoryOrder(p[0],p[1],CarComponent.valueOf(p[2]),p[3].toInt(),p[4].toInt(),p[5].toInt(),p[6].toInt(),p[7].toInt(),p[8].toInt(),p[9].toInt(),p[10].toLong(),p[11].toInt())
            }.getOrNull()
        }
        val pending = prefs.getString("factoryPendingInstallations", "").orEmpty().split(";").filter { it.isNotBlank() }.mapNotNull { row ->
            val p=row.split("|")
            if (p.size < 6) null else runCatching {
                CarPiece(p[0], CarComponent.valueOf(p[1]), p[2].toInt(), p[3].toInt(), p[4].toInt(), p[5].toInt())
            }.getOrNull()
        }
        TeamFactoryState(orders, pending)
    }.getOrNull()

    fun saveFactory(forTeamId: Int, factory: TeamFactoryState) {
        prefs.edit().putInt("factoryTeam",forTeamId)
            .putString("factoryOrders", factory.activeOrders.joinToString(";") { o -> listOf(o.orderId,o.designId,o.component.name,o.version,o.performance,o.reliability,o.quantity,o.remainingUnits,o.totalWeeks,o.remainingWeeks,o.costPerUnit,o.startedWeek).joinToString("|") })
            .putString("factoryPendingInstallations", factory.pendingInstallations.joinToString(";") { p -> listOf(p.pieceId,p.component.name,p.version,p.performance,p.reliability,p.manufacturedWeek).joinToString("|") })
            .apply()
    }

    fun loadGarage(forTeamId: Int): TeamGarage? = runCatching {
        if (prefs.getInt("garageTeam", -1) != forTeamId) return null
        fun loadComponentReliabilities(prefix: String, fallback: Int): Map<CarComponent, Int> = CarComponent.values().associateWith { c -> prefs.getInt("${prefix}Rel_${c.name}", fallback).coerceIn(1,100) }
        fun loadCar(id: GarageCarId): PhysicalCar {
            val prefix = if (id == GarageCarId.CAR_1) "g1" else "g2"
            val installed = prefs.getString("${prefix}Installed", "").orEmpty().split(",").filter { it.isNotBlank() }.mapNotNull { token ->
                val p=token.split(":")
                if (p.size != 2) null else runCatching { CarComponent.valueOf(p[0]) to p[1] }.getOrNull()
            }.toMap()
            return PhysicalCar(
                id=id, engine=prefs.getInt("${prefix}Engine",70), chassis=prefs.getInt("${prefix}Chassis",70),
                frontWing=prefs.getInt("${prefix}FrontWing",70), rearWing=prefs.getInt("${prefix}RearWing",70),
                brakes=prefs.getInt("${prefix}Brakes",70), electricPowerUnit=prefs.getInt("${prefix}Electric",70),
                reliability=prefs.getInt("${prefix}Reliability",100), componentReliabilities=loadComponentReliabilities(prefix, prefs.getInt("${prefix}Reliability",100)), installedPieces=installed,
                installedPieceVersions=CarComponent.values().associateWith { c -> prefs.getInt("${prefix}Version_${c.name}", 1).coerceAtLeast(1) }
            )
        }
        TeamGarage(loadCar(GarageCarId.CAR_1),loadCar(GarageCarId.CAR_2))
    }.getOrNull()

    fun saveGarage(forTeamId: Int, garage: TeamGarage) {
        fun putCar(e: android.content.SharedPreferences.Editor, car: PhysicalCar, prefix: String) {
            e.putInt("${prefix}Engine",car.engine).putInt("${prefix}Chassis",car.chassis)
                .putInt("${prefix}FrontWing",car.frontWing).putInt("${prefix}RearWing",car.rearWing)
                .putInt("${prefix}Brakes",car.brakes).putInt("${prefix}Electric",car.electricPowerUnit)
                .putInt("${prefix}Reliability",car.reliability)
                .also { editor ->
                    car.componentReliabilities.forEach { (c,v) -> editor.putInt("${prefix}Rel_${c.name}",v) }
                    car.installedPieceVersions.forEach { (c,v) -> editor.putInt("${prefix}Version_${c.name}",v.coerceAtLeast(1)) }
                }
                .putString("${prefix}Installed",car.installedPieces.entries.joinToString(",") { "${it.key.name}:${it.value}" })
        }
        prefs.edit().putInt("garageTeam",forTeamId).also { e ->
            putCar(e,garage.car1,"g1")
            putCar(e,garage.car2,"g2")
        }.apply()
    }

    fun loadFacilities(forTeamId:Int): TeamFacilitiesState? = runCatching {
        if (prefs.getInt("facilitiesTeam", -1) != forTeamId) return null
        val raw = prefs.getString("facilities", "").orEmpty()
        val levels = raw.split(",").filter { it.isNotBlank() }.mapNotNull { token ->
            val p = token.split(":")
            if (p.size != 2) null else runCatching { FacilityType.valueOf(p[0]) to p[1].toInt().coerceIn(0,10) }.getOrNull()
        }.toMap()
        TeamFacilitiesState(FacilityType.values().associateWith { levels[it] ?: 0 })
    }.getOrNull()

    fun saveFacilities(forTeamId:Int, facilities:TeamFacilitiesState) {
        prefs.edit().putInt("facilitiesTeam",forTeamId)
            .putString("facilities", facilities.levels.entries.sortedBy { it.key.ordinal }.joinToString(",") { "${it.key.name}:${it.value.coerceIn(0,10)}" })
            .apply()
    }

    fun loadTechnicalInvestment(forTeamId:Int): com.f1teammanager.core.manager.TechnicalInvestmentState? = runCatching {
        val raw = prefs.getString("technicalInvestment_$forTeamId", null) ?: return null
        val p = raw.split(",")
        if (p.size < 7) return null
        com.f1teammanager.core.manager.TechnicalInvestmentState(
            season = p[0].toInt(),
            ranking = p[1].toInt(),
            level = p[2].toInt(),
            annualCap = p[3].toLong(),
            researchDesignSpent = p[4].toLong(),
            fabricationSpent = p[5].toLong(),
            facilityUpgradeSpent = p[6].toLong()
        )
    }.getOrNull()

    fun saveTechnicalInvestment(forTeamId:Int, state: com.f1teammanager.core.manager.TechnicalInvestmentState) {
        prefs.edit().putString(
            "technicalInvestment_$forTeamId",
            listOf(state.season, state.ranking, state.level, state.annualCap,
                state.researchDesignSpent, state.fabricationSpent, state.facilityUpgradeSpent).joinToString(",")
        ).apply()
    }

    fun loadDriverDevelopment(forTeamId:Int): com.f1teammanager.core.manager.DriverDevelopmentState = runCatching {
        if (prefs.getInt("driverDevelopmentTeam", -1) != forTeamId) return com.f1teammanager.core.manager.DriverDevelopmentState()
        val programs = prefs.getString("driverDevelopmentPrograms", "").orEmpty().split(";").filter { it.isNotBlank() }.mapNotNull { row ->
            val p = row.split("|")
            if (p.size < 5) null else runCatching {
                com.f1teammanager.core.manager.DriverDevelopmentProgram(p[0].toInt(), p[1].toInt(), p[2].toInt(), p[3].toInt(), p[4].toInt())
            }.getOrNull()
        }
        val reserve = prefs.getString("driverDevelopmentReserve", "").orEmpty().split(";").filter { it.isNotBlank() }.mapNotNull { row ->
            val p = row.split(":")
            if (p.size != 2) null else runCatching { p[0].toInt() to p[1].toInt().coerceAtLeast(0) }.getOrNull()
        }.toMap()
        com.f1teammanager.core.manager.DriverDevelopmentState(programs, reserve).normalized()
    }.getOrDefault(com.f1teammanager.core.manager.DriverDevelopmentState())

    fun saveDriverDevelopment(forTeamId:Int, state:com.f1teammanager.core.manager.DriverDevelopmentState) {
        val normalized = state.normalized()
        prefs.edit().putInt("driverDevelopmentTeam",forTeamId)
            .putString("driverDevelopmentPrograms", normalized.programs.joinToString(";") { listOf(it.driverId,it.startedWeek,it.totalWeeks,it.remainingWeeks,it.points).joinToString("|") })
            .putString("driverDevelopmentReserve", normalized.reservePoints.entries.sortedBy { it.key }.joinToString(";") { "${it.key}:${it.value}" })
            .apply()
    }

    fun getInt(key:String, fallback:Int): Int = prefs.getInt(key,fallback)
    fun putInt(key:String, value:Int) { prefs.edit().putInt(key,value).apply() }

    fun loadFinance(forTeamId:Int, fallback:TeamFinanceState): TeamFinanceState {
        if (prefs.getInt("financeTeam", -1) != forTeamId) return fallback
        return TeamFinanceState(
            budget=prefs.getLong("budget", fallback.budget),
            seasonIncome=prefs.getLong("seasonIncome", fallback.seasonIncome),
            seasonExpenses=prefs.getLong("seasonExpenses", fallback.seasonExpenses),
            raceIncome=prefs.getLong("raceIncome", fallback.raceIncome),
            raceExpenses=prefs.getLong("raceExpenses", fallback.raceExpenses),
            seasonPrizesPaid=prefs.getString("seasonPrizesPaid", "").orEmpty().split(",").mapNotNull { it.toIntOrNull() }.toSet()
        )
    }
    fun saveFinance(forTeamId:Int, finance:TeamFinanceState) {
        prefs.edit().putInt("financeTeam",forTeamId).putLong("budget",finance.budget).putLong("seasonIncome",finance.seasonIncome).putLong("seasonExpenses",finance.seasonExpenses).putLong("raceIncome",finance.raceIncome).putLong("raceExpenses",finance.raceExpenses)
            .putString("seasonPrizesPaid", finance.seasonPrizesPaid.sorted().joinToString(","))
            .apply()
    }

    /** Charges annual driver salaries exactly once for the requested season. */
    fun applyAnnualDriverSalariesOnce(forTeamId:Int, seasonToCharge:Int, finance:TeamFinanceState, market:DriverMarketState): TeamFinanceState {
        val key = "annualDriverSalarySeason_$forTeamId"
        if (prefs.getInt(key, 0) == seasonToCharge) return finance
        val total = market.contracts.filter { it.teamId == forTeamId && it.activeIn(seasonToCharge) }.sumOf { it.salary.toLong() }
        val next = if (total > 0L) finance.transact(-total, "Salários anuais dos pilotos — temporada $seasonToCharge") else finance
        prefs.edit().putInt(key, seasonToCharge).apply()
        saveFinance(forTeamId, next)
        return next
    }

    /** Qualifying sponsor bonus is a GP/season-round transaction and is persisted idempotently. */
    fun applyQualifyingBonusOnce(forTeamId:Int, seasonToApply:Int, roundToApply:Int, finance:TeamFinanceState, sponsors:List<SponsorContract>, bestPosition:Int): TeamFinanceState {
        if (bestPosition <= 0) return finance
        val key = "qualifyingBonusPaid_${seasonToApply}_$roundToApply"
        if (prefs.getBoolean(key, false)) return finance
        val bonus = sponsors.filter { it.active && it.racesRemaining > 0 }.sumOf { s -> if (s.qualifyingTarget > 0 && bestPosition <= s.qualifyingTarget) s.qualifyingBonus else 0L }
        val next = if (bonus > 0L) finance.transact(bonus, "Bônus por meta de qualificação — GP $roundToApply") else finance
        prefs.edit().putBoolean(key, true).apply()
        saveFinance(forTeamId, next)
        return next
    }
    fun loadSponsor(forTeamId:Int, fallback:SponsorContract): SponsorContract {
        if (prefs.getInt("sponsorTeam", -1) != forTeamId) return fallback
        return SponsorContract(
            prefs.getString("sponsorName",fallback.name) ?: fallback.name,
            prefs.getLong("sponsorUpfront",fallback.upfront),
            prefs.getLong("sponsorRace",fallback.racePayment),
            prefs.getLong("sponsorPoints",fallback.pointsBonus),
            prefs.getInt("sponsorYears",fallback.years),
            prefs.getInt("sponsorRep",fallback.minimumReputation),
            prefs.getInt("sponsorSlot",fallback.slot),
            prefs.getInt("sponsorQualTarget",fallback.qualifyingTarget),
            prefs.getLong("sponsorQualBonus",fallback.qualifyingBonus),
            prefs.getInt("sponsorRaceTarget",fallback.raceTarget),
            prefs.getLong("sponsorRaceTargetBonus",fallback.raceTargetBonus),
            prefs.getBoolean("sponsorActive",fallback.active),
            prefs.getInt("sponsorRaces",fallback.races),
            prefs.getInt("sponsorRacesRemaining",fallback.racesRemaining),
            fallback.category,
            prefs.getInt("sponsorQualTargetMin",fallback.qualifyingTargetMin),
            prefs.getInt("sponsorQualTargetMax",fallback.qualifyingTargetMax),
            prefs.getInt("sponsorRaceTargetMin",fallback.raceTargetMin),
            prefs.getInt("sponsorRaceTargetMax",fallback.raceTargetMax)
        )
    }
    fun loadSponsors(forTeamId:Int): List<SponsorContract> {
        if (prefs.getInt("sponsorTeam", -1) != forTeamId) return emptyList()
        return (1..5).mapNotNull { slot ->
            val name=prefs.getString("sponsor_${slot}_name",null) ?: return@mapNotNull null
            SponsorContract(name, prefs.getLong("sponsor_${slot}_upfront",0), prefs.getLong("sponsor_${slot}_race",0), prefs.getLong("sponsor_${slot}_points",0), prefs.getInt("sponsor_${slot}_years",1), prefs.getInt("sponsor_${slot}_rep",0), slot, prefs.getInt("sponsor_${slot}_qualTarget",0), prefs.getLong("sponsor_${slot}_qualBonus",0), prefs.getInt("sponsor_${slot}_raceTarget",0), prefs.getLong("sponsor_${slot}_raceTargetBonus",0), prefs.getBoolean("sponsor_${slot}_active",true), prefs.getInt("sponsor_${slot}_races",5), prefs.getInt("sponsor_${slot}_racesRemaining",prefs.getInt("sponsor_${slot}_races",5)), prefs.getString("sponsor_${slot}_category","BASICO") ?: "BASICO", prefs.getInt("sponsor_${slot}_qualTargetMin",prefs.getInt("sponsor_${slot}_qualTarget",0)), prefs.getInt("sponsor_${slot}_qualTargetMax",prefs.getInt("sponsor_${slot}_qualTarget",0)), prefs.getInt("sponsor_${slot}_raceTargetMin",prefs.getInt("sponsor_${slot}_raceTarget",0)), prefs.getInt("sponsor_${slot}_raceTargetMax",prefs.getInt("sponsor_${slot}_raceTarget",0)))
        }
    }
    fun saveSponsor(forTeamId:Int, sponsor:SponsorContract) = saveSponsors(forTeamId, listOf(sponsor))
    fun saveSponsors(forTeamId:Int, sponsors:List<SponsorContract>) {
        val e=prefs.edit().putInt("sponsorTeam",forTeamId)
        for (slot in 1..5) {
            val s=sponsors.firstOrNull { it.slot==slot }
            if (s==null) {
                listOf("name","upfront","race","points","years","rep","qualTarget","qualBonus","raceTarget","raceTargetBonus","qualTargetMin","qualTargetMax","raceTargetMin","raceTargetMax","active","races","racesRemaining","category").forEach { e.remove("sponsor_${slot}_$it") }
            } else {
                e.putString("sponsor_${slot}_name",s.name).putLong("sponsor_${slot}_upfront",s.upfront).putLong("sponsor_${slot}_race",s.racePayment).putLong("sponsor_${slot}_points",s.pointsBonus).putInt("sponsor_${slot}_years",s.years).putInt("sponsor_${slot}_rep",s.minimumReputation).putInt("sponsor_${slot}_qualTarget",s.qualifyingTarget).putLong("sponsor_${slot}_qualBonus",s.qualifyingBonus).putInt("sponsor_${slot}_raceTarget",s.raceTarget).putLong("sponsor_${slot}_raceTargetBonus",s.raceTargetBonus).putInt("sponsor_${slot}_qualTargetMin",s.qualifyingTargetMin).putInt("sponsor_${slot}_qualTargetMax",s.qualifyingTargetMax).putInt("sponsor_${slot}_raceTargetMin",s.raceTargetMin).putInt("sponsor_${slot}_raceTargetMax",s.raceTargetMax).putBoolean("sponsor_${slot}_active",s.active).putInt("sponsor_${slot}_races",s.races).putInt("sponsor_${slot}_racesRemaining",s.racesRemaining).putString("sponsor_${slot}_category",s.category)
            }
        }
        // Keep legacy primary sponsor keys synchronized.
        val primary=sponsors.firstOrNull { it.slot==1 }
        if (primary==null) { e.remove("sponsorName").remove("sponsorUpfront").remove("sponsorRace").remove("sponsorPoints").remove("sponsorYears").remove("sponsorRep").remove("sponsorSlot").remove("sponsorQualTarget").remove("sponsorQualBonus").remove("sponsorRaceTarget").remove("sponsorRaceTargetBonus").remove("sponsorActive").remove("sponsorRaces").remove("sponsorRacesRemaining") }
        else { e.putString("sponsorName",primary.name).putLong("sponsorUpfront",primary.upfront).putLong("sponsorRace",primary.racePayment).putLong("sponsorPoints",primary.pointsBonus).putInt("sponsorYears",primary.years).putInt("sponsorRep",primary.minimumReputation).putInt("sponsorSlot",primary.slot).putInt("sponsorQualTarget",primary.qualifyingTarget).putLong("sponsorQualBonus",primary.qualifyingBonus).putInt("sponsorRaceTarget",primary.raceTarget).putLong("sponsorRaceTargetBonus",primary.raceTargetBonus).putBoolean("sponsorActive",primary.active).putInt("sponsorRaces",primary.races).putInt("sponsorRacesRemaining",primary.racesRemaining).putInt("sponsorQualTargetMin",primary.qualifyingTargetMin).putInt("sponsorQualTargetMax",primary.qualifyingTargetMax).putInt("sponsorRaceTargetMin",primary.raceTargetMin).putInt("sponsorRaceTargetMax",primary.raceTargetMax) }
        e.apply()
    }

    /** Current persisted attributes for all 100 drivers. */
    fun driverAttributes(): Map<Int, IntArray> {
        val raw = prefs.getString("driverAttributes", "").orEmpty()
        val parsed = raw.split(';').mapNotNull { token ->
            val p = token.split(':', limit = 2)
            if (p.size != 2) return@mapNotNull null
            val id = p[0].toIntOrNull() ?: return@mapNotNull null
            val values = p[1].split(',').mapNotNull { it.toIntOrNull() }
            if (values.size != 7) null else id to values.toIntArray()
        }.toMap()
        if (parsed.size == WorldDatabase.allDrivers.size) return parsed
        val initialized = WorldDatabase.allDrivers.associate { it.id to intArrayOf(it.speed,it.qualifying,it.overtaking,it.defense,it.consistency,it.wet,it.tyre) }
        saveDriverAttributes(initialized)
        return initialized
    }

    fun saveDriverAttributes(values: Map<Int, IntArray>) {
        prefs.edit().putString("driverAttributes", values.toSortedMap().entries.joinToString(";") { (id,a) -> "$id:${a.joinToString(",")}" }).apply()
    }

    private fun saveSeasonStartDriverAttributes(season: Int, values: Map<Int, IntArray>) {
        prefs.edit().putString("driverSeasonStartAttributes_$season", values.toSortedMap().entries.joinToString(";") { (id,a) -> "$id:${a.joinToString(",")}" }).apply()
    }

    fun seasonStartDriverDefinition(driverId: Int, season: Int = this.season): com.f1teammanager.core.season.DriverDefinition {
        val base = WorldDatabase.allDrivers.first { it.id == driverId }
        val raw = prefs.getString("driverSeasonStartAttributes_$season", "").orEmpty()
        val a = raw.split(';').mapNotNull { token ->
            val p = token.split(':', limit = 2)
            if (p.size != 2 || p[0].toIntOrNull() != driverId) return@mapNotNull null
            val values = p[1].split(',').mapNotNull { it.toIntOrNull() }
            if (values.size == 7) values.toIntArray() else null
        }.firstOrNull() ?: intArrayOf(base.speed,base.qualifying,base.overtaking,base.defense,base.consistency,base.wet,base.tyre)
        return base.copy(speed=a[0],qualifying=a[1],overtaking=a[2],defense=a[3],consistency=a[4],wet=a[5],tyre=a[6])
    }

    /** Current driver-rating projection used by the active evolution state machine. */
    private fun ratingsForEvolution(driver: com.f1teammanager.core.season.DriverDefinition): IntArray =
        intArrayOf(driver.speed, driver.qualifying, driver.overtaking, driver.defense, driver.consistency, driver.wet, driver.tyre)

    private fun readDriverEvolutionPhases(): MutableMap<Int,String> = prefs.getString("driverEvolutionPhases", "").orEmpty().split(';').mapNotNull { token ->
        val p=token.split(':', limit=2); if (p.size==2) p[0].toIntOrNull()?.let { it to p[1] } else null
    }.toMap().toMutableMap()

    private fun saveDriverEvolutionPhases(values: Map<Int,String>) {
        prefs.edit().putString("driverEvolutionPhases", values.toSortedMap().entries.joinToString(";") { "${it.key}:${it.value}" }).apply()
    }

    fun driverDefinition(driverId:Int): com.f1teammanager.core.season.DriverDefinition {
        val base = WorldDatabase.allDrivers.first { it.id == driverId }
        val a = driverAttributes()[driverId] ?: intArrayOf(base.speed,base.qualifying,base.overtaking,base.defense,base.consistency,base.wet,base.tyre)
        return base.copy(speed=a[0],qualifying=a[1],overtaking=a[2],defense=a[3],consistency=a[4],wet=a[5],tyre=a[6])
    }

    fun currentDrivers(): List<com.f1teammanager.core.season.DriverDefinition> =
        WorldDatabase.allDrivers.map { driverDefinition(it.id) }

    private fun readSeasonTargets(): Map<Int, DriverEvolutionEngine.Target> {
        return prefs.getString("driverSeasonTargets_$season", "").orEmpty().split(',').mapNotNull { token ->
            val p=token.split(':'); if(p.size!=2) null else p[0].toIntOrNull()?.let { id -> p[1].toIntOrNull()?.let { pos -> id to DriverEvolutionEngine.Target(pos) } }
        }.toMap()
    }

    /**
     * Creates the immutable season targets from the opening-season team-strength ranking.
     * Driver Overall is intentionally NOT used here. Each team occupies two championship
     * target slots according to its strength rank, so expectations are anchored to the
     * competitive level of the team rather than the driver's rating.
     */
    fun initializeDriverSeasonTargets(playerCar: TeamCarState? = null) {
        val market = loadDriverMarket()
        val active = market?.contracts?.filter { it.activeIn(season) }
            ?: WorldDatabase.drivers.map { d -> com.f1teammanager.core.manager.DriverDeal(d.id,d.teamId,1,0L,0L,season) }

        fun strength(team: com.f1teammanager.core.season.TeamDefinition): Double {
            if (team.id == teamId && playerCar != null) {
                return (playerCar.chassis + playerCar.engine + playerCar.frontWing +
                    playerCar.rearWing + playerCar.brakes + playerCar.electricPowerUnit) / 6.0
            }
            val c = com.f1teammanager.core.manager.InitialTeamProfile.values(team)
            return (c.chassis + c.engine + c.frontWing + c.rearWing + c.brakes + c.electricPowerUnit) / 6.0
        }

        val teamRank = WorldDatabase.teams
            .sortedWith(compareByDescending<com.f1teammanager.core.season.TeamDefinition> { strength(it) }.thenBy { it.id })
            .mapIndexed { index, team -> team.id to (index + 1) }
            .toMap()

        val targets = active.mapNotNull { deal ->
            val team = WorldDatabase.teams.firstOrNull { it.id == deal.teamId } ?: return@mapNotNull null
            val rank = teamRank[team.id] ?: return@mapNotNull null
            val order = team.driverIds.indexOf(deal.driverId).takeIf { it >= 0 } ?: 0
            deal.driverId to DriverEvolutionEngine.Target(((rank - 1) * 2 + order + 1).coerceIn(1, 80))
        }.toMap()

        prefs.edit().putString(
            "driverSeasonTargets_$season",
            targets.entries.sortedBy { it.key }.joinToString(",") { "${it.key}:${it.value.championshipPosition}" }
        ).apply()
    }

    /**
     * Applies one in-season evolution tick after a completed GP. Evolution is continuous
     * during the championship; GP30 only closes the season and does not perform a second
     * evolution pass. The fractional bank makes changes gradual while keeping the official
     * annual gain ceiling from DriverProfileCatalog.
     */
    private fun readAnnualAttributeGains(): MutableMap<Int, IntArray> {
        val raw = prefs.getString("driverEvolutionAttributeGains_$season", "").orEmpty()
        val out = mutableMapOf<Int, IntArray>()
        raw.split(';').filter { it.isNotBlank() }.forEach { token ->
            val p = token.split(':')
            if (p.size == 2) {
                val id = p[0].toIntOrNull()
                val values = p[1].split(',').mapNotNull { it.toIntOrNull() }
                if (id != null && values.size == 7) out[id] = values.toIntArray()
            }
        }
        return out
    }

    private fun writeAnnualAttributeGains(values: Map<Int, IntArray>) {
        prefs.edit().putString(
            "driverEvolutionAttributeGains_$season",
            values.toSortedMap().entries.joinToString(";") { (id, a) -> "$id:${a.joinToString(",")}" }
        ).apply()
    }

    /**
     * Applies one in-season evolution tick after a completed GP.
     * Positive evolution uses the full intended gain, with per-attribute class-ceiling
     * redistribution. Regression is independent and is capped at the floor 40.
     */
    fun applyDriverRaceEvolution(round: Int): List<String> {
        // One evolution tick per completed GP, even if the result flow is reopened.
        val processedRounds = readMap("driverEvolutionProcessedRounds_$season")
        if (processedRounds[round] == 1) return emptyList()
        val targets = readSeasonTargets().ifEmpty { initializeDriverSeasonTargets(); readSeasonTargets() }
        val races = history.raceRecords(season)
        val qualifying = history.qualifyingRecords(season)
        val attrs = driverAttributes().toMutableMap()
        val banks = readDoubleMap("driverEvolutionBank_$season").toMutableMap()
        val phases = readDriverEvolutionPhases()
        val phaseGps = readMap("driverEvolutionPhaseGps") .toMutableMap()
        val phaseStart = readMap("driverEvolutionPhaseStart") .toMutableMap()
        val phaseTarget = readMap("driverEvolutionPhaseTarget") .toMutableMap()
        val pressure = readDoubleMap("driverEvolutionPhasePressure").toMutableMap()
        val activeDriverIds = loadDriverMarket()?.contracts?.filter { it.activeIn(season) }?.map { it.driverId }?.toSet()
            ?: races.filter { it.round == round }.map { it.driverId }.toSet()
        val changes = mutableListOf<String>()

        WorldDatabase.allDrivers.forEach { base ->
            val id = base.id
            val currentAttrs = attrs[id] ?: intArrayOf(base.speed,base.qualifying,base.overtaking,base.defense,base.consistency,base.wet,base.tyre)
            var current = base.copy(speed=currentAttrs[0],qualifying=currentAttrs[1],overtaking=currentAttrs[2],defense=currentAttrs[3],consistency=currentAttrs[4],wet=currentAttrs[5],tyre=currentAttrs[6])
            var phase = phases[id] ?: "GROWING"
            var gps = phaseGps[id] ?: 0
            var bank = banks[id] ?: 0.0
            val rng = kotlin.random.Random(20261006 + season*1000 + round*97 + id*31)

            if (!phaseStart.containsKey(id)) phaseStart[id] = DriverProfileCatalog.overall(ratingsForEvolution(current))
            val regression = phase == "REGRESSION"
            val target = if (regression) DriverProfileCatalog.minimumOverall(current.driverClass) else DriverProfileCatalog.ceiling(current.driverClass)
            if (!phaseTarget.containsKey(id)) phaseTarget[id] = target
            if (phaseTarget[id] != target) {
                phaseStart[id] = DriverProfileCatalog.overall(ratingsForEvolution(current)); phaseTarget[id] = target; gps = 0; bank = 0.0
            }

            val index = if (id in activeDriverIds) {
                val rr = races.firstOrNull { it.season == season && it.round == round && it.driverId == id }
                val qq = qualifying.firstOrNull { it.season == season && it.round == round && it.driverId == id }
                DriverEvolutionEngine.gpPerformanceIndex(targets[id]?.championshipPosition ?: 80, qq?.position ?: 80, rr?.position ?: 80)
            } else 100.0
            val multiplier = if (id in activeDriverIds) DriverEvolutionEngine.phaseMultiplier(index, regression) else 0.70
            val anticipation = if (id in activeDriverIds) DriverEvolutionEngine.anticipationFactor(index, regression) else 1.0
            val phaseSeasons = when (phase) {
                "REGRESSION" -> DriverEvolutionEngine.regressionSeasons(current.evolution)
                "PEAK" -> 2
                else -> DriverEvolutionEngine.ascentSeasons(current.evolution)
            }
            val totalGps = phaseSeasons * 30
            val start = phaseStart[id] ?: DriverProfileCatalog.overall(ratingsForEvolution(current))
            val distance = kotlin.math.abs(target - start)
            val perGp = if (phase == "PEAK" || distance == 0) 0.0 else distance.toDouble()*7.0/totalGps.toDouble().coerceAtLeast(1.0)
            bank += perGp * multiplier * anticipation
            val whole = bank.toInt()
            if (whole > 0 && phase != "PEAK") {
                val before = current
                current = if (phase == "GROWING") DriverEvolutionEngine.applyPositiveGain(current, whole, IntArray(7), rng)
                    else DriverEvolutionEngine.applyRegression(current, whole, rng)
                val actual = DriverProfileCatalog.overall(ratingsForEvolution(current)) - DriverProfileCatalog.overall(ratingsForEvolution(before))
                if (actual != 0) bank -= whole.toDouble()
                else bank -= whole.toDouble().coerceAtMost(bank)
            }

            gps++
            val afterOverall = DriverProfileCatalog.overall(ratingsForEvolution(current))
            val reached = if (phase == "REGRESSION") afterOverall <= target else afterOverall >= target
            var pp = pressure[id] ?: 0.0
            if (phase == "GROWING") {
                pp = (pp + when { index < 60 -> 1.0; index < 75 -> 0.35; index >= 105 -> -0.70; index >= 92 -> -0.35; else -> -0.10 }).coerceIn(0.0,12.0)
                if (pp >= 12.0) {
                    phase="REGRESSION"; gps=0; phaseStart[id]=afterOverall; phaseTarget[id]=DriverProfileCatalog.minimumOverall(current.driverClass); bank=0.0; pp=0.0
                } else if (reached || gps >= totalGps) {
                    phase="PEAK"; gps=0; phaseStart[id]=afterOverall; phaseTarget[id]=DriverProfileCatalog.ceiling(current.driverClass); bank=0.0; pp=0.0
                }
            } else if (phase == "REGRESSION") {
                if (reached || gps >= totalGps) {
                    phase="GROWING"; gps=0; phaseStart[id]=afterOverall; phaseTarget[id]=DriverProfileCatalog.ceiling(current.driverClass); bank=0.0; pp=0.0
                }
            } else if (gps >= totalGps) {
                phase="REGRESSION"; gps=0; phaseStart[id]=afterOverall; phaseTarget[id]=DriverProfileCatalog.minimumOverall(current.driverClass); bank=0.0; pp=0.0
            }

            val beforeOverall = DriverProfileCatalog.overall(currentAttrs)
            if (afterOverall > beforeOverall) {
                val team = loadDriverMarket()?.contracts?.firstOrNull { it.driverId == id && it.activeIn(season) }
                    ?.let { WorldDatabase.teams.firstOrNull { t -> t.id == it.teamId }?.name } ?: "Sem equipe"
                changes += "${base.name} — $team — GP $round: Overall $beforeOverall → $afterOverall (+${afterOverall-beforeOverall})."
            }
            attrs[id] = ratingsForEvolution(current)
            phases[id] = phase; phaseGps[id]=gps; phaseStart[id]=phaseStart[id] ?: afterOverall; phaseTarget[id]=phaseTarget[id] ?: target
            pressure[id]=pp; banks[id]=bank
        }
        saveDriverAttributes(attrs); saveDriverEvolutionPhases(phases)
        writeDoubleMap("driverEvolutionBank_$season", banks)
        writeMap("driverEvolutionPhaseGps",phaseGps); writeMap("driverEvolutionPhaseStart",phaseStart); writeMap("driverEvolutionPhaseTarget",phaseTarget)
        writeDoubleMap("driverEvolutionPhasePressure",pressure)
        writeMap("driverEvolutionProcessedRounds_$season", processedRounds + (round to 1))
        if (changes.isNotEmpty()) {
            val market = loadDriverMarket()
            if (market != null) {
                val week = SeasonCalendar.forSeason(season).firstOrNull { it.round == round }?.weekOfSeason ?: currentWeek
                val notices = changes.mapNotNull { change ->
                    val existing = market.notifications.any {
                        it.season == season && it.week == week && it.category == MarketNewsCategory.DRIVER_EVOLUTION && it.message == change
                    }
                    if (existing) null else MarketNotification(
                        season, week, "EVOLUÇÃO DE PILOTOS", change, true, MarketNewsCategory.DRIVER_EVOLUTION
                    )
                }
                if (notices.isNotEmpty()) saveDriverMarket(market.copy(notifications = (market.notifications + notices).takeLast(200)).normalized())
            }
        }
        return changes
    }

    /** Regression is now processed per GP by applyDriverRaceEvolution. Kept as a
     * compatibility entry point so old UI flows cannot apply a second annual loss. */
    fun applySeasonEndRegression(seasonToClose:Int): Int = 0

    fun startNewCareer(selectedTeamId: Int) {
        teamId = selectedTeamId; roundIndex = 0; currentWeek = 1; season = 2026; hasCareer = true
        // Every new career receives a fresh draw of 30 unique venues from the
        // permanent 50-GP database. The seed is persisted so the same career keeps
        // exactly the same calendar after restarts/reloads.
        newCalendarSeed(season)
        writeMap("driverPoints", emptyMap()); writeMap("constructorPoints", emptyMap())
        for (r in 1..SeasonCalendar.forSeason(season).size) prefs.edit().remove("race_$r").apply()
        history.clear()
        prefs.edit().remove("driverEvolutionAppliedSeason").remove("driverRegressionAppliedSeason").remove("driverEvolutionBank_$season").remove("driverEvolutionAccumulated_$season").remove("driverEvolutionAttributeGains_$season").apply()
        val openingAttrs = WorldDatabase.allDrivers.associate { it.id to intArrayOf(it.speed,it.qualifying,it.overtaking,it.defense,it.consistency,it.wet,it.tyre) }
        saveDriverAttributes(openingAttrs)
        saveSeasonStartDriverAttributes(season, openingAttrs)
        initializeDriverSeasonTargets()
        val t=WorldDatabase.teams.first { it.id==selectedTeamId }
        saveCar(selectedTeamId, com.f1teammanager.core.manager.InitialTeamProfile.carState(t))
        saveGarage(selectedTeamId, com.f1teammanager.core.manager.TeamGarageFactory.fromInitial(t))
        saveResearch(selectedTeamId, TeamResearchState())
        saveDriverDevelopment(selectedTeamId, com.f1teammanager.core.manager.DriverDevelopmentState())
        saveTechnicalInvestment(selectedTeamId, com.f1teammanager.core.manager.TechnicalInvestmentEngine.forTeam(season, selectedTeamId, selectedTeamId, com.f1teammanager.core.manager.InitialTeamProfile.carState(t)))
        saveFinance(selectedTeamId, TeamFinanceState(com.f1teammanager.core.manager.InitialTeamProfile.initialBudget(t)));
        prefs.edit().remove("aiTeamBudgets").remove("constructorPrizePaidTeams_2026").remove("aiFinanceSnapshot").remove("aiSponsorshipSnapshot").apply()
        putInt("annualDriverSalarySeason_${selectedTeamId}",0); saveSponsors(selectedTeamId, emptyList())
        saveDriverMarket(com.f1teammanager.core.manager.DriverMarketEngine().initialState(season))
    }

    /** True after GP 30 has been archived, while the game is still on the completed season. */
    fun isSeasonEnded(): Boolean =
        roundIndex == SeasonCalendar.forSeason(season).lastIndex && history.isSeasonFinalized(season)

    /**
     * Advance to the next GP after a completed race.
     * GP 30 is deliberately different: it only archives the season and leaves the
     * current year/round intact until the manager explicitly starts the next season.
     */
    fun completeCurrentRace() {
        if (roundIndex < SeasonCalendar.forSeason(season).lastIndex) {
            roundIndex += 1
            // Do NOT move currentWeek here. The completed GP happened in the current
            // week; the manager must return to the calendar and manually advance the
            // remaining free weeks until the next GP week.
        } else {
            history.finalizeSeason(season, driverPoints(), constructorPoints(), loadDriverMarket())
            // Stay on the completed season. No automatic year change here.
        }
    }

    /** Explicit player action: starts the archived season's successor. */
    fun startNextSeason() {
        require(isSeasonEnded()) { "A temporada atual ainda não foi encerrada." }
        season += 1
        roundIndex = 0
        currentWeek = 1
        // A new season gets a new 30/50 draw while remaining fixed for that season.
        newCalendarSeed(season)
        writeMap("driverPoints", emptyMap())
        writeMap("constructorPoints", emptyMap())
        for (r in 1..SeasonCalendar.forSeason(season).size) prefs.edit().remove("race_$r").apply()
        prefs.edit().remove("driverEvolutionAppliedSeason").remove("driverRegressionAppliedSeason").remove("driverEvolutionBank_$season").remove("driverEvolutionAccumulated_$season").remove("driverEvolutionAttributeGains_$season").apply()
        saveSeasonStartDriverAttributes(season, driverAttributes())
        initializeDriverSeasonTargets()
        val nextCar = loadCar(teamId)
        saveTechnicalInvestment(teamId, com.f1teammanager.core.manager.TechnicalInvestmentEngine.forTeam(season, teamId, teamId, nextCar))
        loadDriverMarket()?.let { saveDriverMarket(com.f1teammanager.core.manager.DriverMarketEngine().applySeasonTransition(it, season)) }
    }

    /** Advance one or more real calendar weeks. Returns the number of weeks actually advanced. */
    fun advanceCalendarWeeks(weeks: Int): Int {
        val old = currentWeek
        currentWeek = (currentWeek + weeks.coerceAtLeast(0)).coerceAtMost(56)
        return currentWeek - old
    }

    fun jumpToWeek(week: Int): Int {
        val old = currentWeek
        currentWeek = week
        return currentWeek - old
    }
}
private object WorldTeamResolver { fun teamIdFor(driverId: Int): Int = ((driverId - 1) / 2) + 1 }
