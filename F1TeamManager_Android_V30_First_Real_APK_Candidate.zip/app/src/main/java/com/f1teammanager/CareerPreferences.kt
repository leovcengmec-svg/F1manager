package com.f1teammanager

import android.content.Context
import com.f1teammanager.core.manager.DevelopmentProject
import com.f1teammanager.core.manager.DevelopmentIntensity
import com.f1teammanager.core.manager.CarComponent
import com.f1teammanager.core.manager.CarDevelopmentFocus
import com.f1teammanager.core.manager.TeamCarState
import com.f1teammanager.core.manager.TeamFinanceState
import com.f1teammanager.core.manager.SponsorContract
import com.f1teammanager.core.race.RaceResult
import com.f1teammanager.core.race.QualifyingResult
import com.f1teammanager.core.season.RoundDefinition
import com.f1teammanager.core.race.Tyre
import com.f1teammanager.core.season.WorldDatabase
import com.f1teammanager.core.season.DriverEvolutionEngine
import com.f1teammanager.core.season.DriverProfileCatalog
import com.f1teammanager.core.manager.DriverMarketState
import com.f1teammanager.core.manager.DriverMarketEngine
import com.f1teammanager.core.manager.DriverDeal
import com.f1teammanager.core.manager.DriverOffer
import com.f1teammanager.core.manager.FutureDriverDeal
import com.f1teammanager.core.manager.DriverTeamRole
import com.f1teammanager.core.manager.DriverRolePreference
import com.f1teammanager.core.manager.NegotiationStatus
import com.f1teammanager.core.manager.ScoutingReport
import com.f1teammanager.core.manager.MarketNotification
import com.f1teammanager.core.manager.MarketNewsCategory

/** Persistent career metadata, championship ledger, race archive and car P&D state. */
class CareerPreferences(context: Context) {
    val history = HistoricalDatabase(context)
    private val prefs = context.getSharedPreferences("f1tm_career", Context.MODE_PRIVATE)

    var hasCareer: Boolean
        get() = prefs.getBoolean("hasCareer", false)
        private set(value) = prefs.edit().putBoolean("hasCareer", value).apply()
    var teamId: Int
        get() = prefs.getInt("teamId", 1)
        private set(value) = prefs.edit().putInt("teamId", value).apply()
    var roundIndex: Int
        get() = prefs.getInt("roundIndex", 0)
        private set(value) = prefs.edit().putInt("roundIndex", value.coerceIn(0, WorldDatabase.rounds.lastIndex)).apply()
    /** Current calendar week. Race weekends occupy specific weeks; the other weeks are free development weeks. */
    var currentWeek: Int
        get() = prefs.getInt("currentWeek", WorldDatabase.rounds.first().weekOfSeason.coerceAtLeast(1) - 2).coerceIn(1, 56)
        private set(value) = prefs.edit().putInt("currentWeek", value.coerceIn(1, 56)).apply()
    var season: Int
        get() = prefs.getInt("season", 2026)
        private set(value) = prefs.edit().putInt("season", value).apply()

    private fun readMap(key: String): Map<Int, Int> = prefs.getString(key, "").orEmpty().split(',').mapNotNull { token ->
        val p = token.split(':')
        if (p.size == 2) p[0].toIntOrNull()?.let { id -> p[1].toIntOrNull()?.let { value -> id to value } } else null
    }.toMap()
    private fun writeMap(key: String, value: Map<Int, Int>) = prefs.edit().putString(key, value.entries.sortedBy { it.key }.joinToString(",") { "${it.key}:${it.value}" }).apply()

    private fun readDoubleMap(key: String): Map<Int, Double> = prefs.getString(key, "").orEmpty().split(',').mapNotNull { token ->
        val p=token.split(':')
        if (p.size != 2) null else p[0].toIntOrNull()?.let { id -> p[1].toDoubleOrNull()?.let { value -> id to value } }
    }.toMap()
    private fun writeDoubleMap(key: String, value: Map<Int, Double>) = prefs.edit().putString(key, value.entries.sortedBy { it.key }.joinToString(",") { "${it.key}:${it.value}" }).apply()
    fun driverPoints(): Map<Int, Int> = readMap("driverPoints")
    fun constructorPoints(): Map<Int, Int> = readMap("constructorPoints")

    /** V36 canonical financial settlement ledger for every team, including AI. */
    fun aiTeamBudget(teamId: Int): Long {
        val raw = prefs.getString("aiTeamBudgets", "").orEmpty()
        return raw.split(";").firstOrNull { it.startsWith("$teamId:") }?.substringAfter(":")?.toLongOrNull()
            ?: (35_000_000L + (WorldDatabase.teams.firstOrNull { it.id == teamId }?.baseCar?.coerceIn(50,100) ?: 50) * 650_000L)
    }

    private fun saveAiTeamBudgets(values: Map<Int, Long>) {
        prefs.edit().putString("aiTeamBudgets", values.toSortedMap().entries.joinToString(";") { "${it.key}:${it.value}" }).apply()
    }

    /**
     * The only Android-facing season-prize entry point. It settles all 40 teams
     * atomically from the same constructor standings used by the history.
     * Idempotency is per season and per team, so reopening GP30 cannot duplicate money.
     */
    fun settleConstructorsSeason(seasonToClose: Int): List<com.f1teammanager.core.manager.SeasonSettlementEngine.Settlement> {
        require(season == seasonToClose) { "Temporada de fechamento divergente" }
        if (!history.isSeasonFinalized(seasonToClose)) {
            history.finalizeSeason(seasonToClose, driverPoints(), constructorPoints(), loadDriverMarket())
        }
        val settlements = com.f1teammanager.core.manager.SeasonSettlementEngine.settleAll(constructorPoints())
        val paid = prefs.getString("constructorPrizePaidTeams_$seasonToClose", "").orEmpty().split(",").mapNotNull { it.toIntOrNull() }.toMutableSet()
        var aiBudgets = WorldDatabase.teams.filter { it.id != teamId }.associate { it.id to aiTeamBudget(it.id) }.toMutableMap()
        val playerFinance = loadFinance(teamId, TeamFinanceState(0L))
        var player = playerFinance
        settlements.forEach { settlement ->
            if (settlement.teamId == teamId) {
                if (teamId !in paid) {
                    player = FinanceEngine().applySeasonConstructorsPrize(
                        TeamManagerState(playerTeamId=teamId, season=seasonToClose, round=WorldDatabase.rounds.size,
                            car=TeamCarState(70,70,70,70), finance=player, driverMarket=loadDriverMarket() ?: DriverMarketEngine().initialState(seasonToClose)),
                        seasonToClose, settlement.position
                    ).finance
                }
            } else if (settlement.teamId !in paid) {
                aiBudgets[settlement.teamId] = aiBudgets.getValue(settlement.teamId) + settlement.prize
            }
        }
        if (teamId !in paid) {
            saveFinance(teamId, player)
        }
        paid.addAll(settlements.map { it.teamId })
        prefs.edit().putString("constructorPrizePaidTeams_$seasonToClose", paid.sorted().joinToString(",")).apply()
        saveAiTeamBudgets(aiBudgets)
        return settlements
    }
    fun previousDriverPositions(): Map<Int, Int> = readMap("previousDriverPositions")
    fun previousConstructorPositions(): Map<Int, Int> = readMap("previousConstructorPositions")

    fun loadDriverMarket(): DriverMarketState? = runCatching {
        val rawContracts = prefs.getString("marketContracts", null) ?: return null
        val contracts = rawContracts.split(';').filter { it.isNotBlank() }.mapNotNull { row ->
            val p=row.split(','); runCatching {
                if (p.size >= 8) DriverDeal(p[0].toInt(),p[1].toInt(),p[2].toInt(),p[3].toLong(),p[4].toLong(),p[6].toInt(),DriverTeamRole.valueOf(p[7]))
                else if (p.size >= 7) DriverDeal(p[0].toInt(),p[1].toInt(),p[2].toInt(),p[3].toLong(),p[4].toLong(),p[5].toInt(),DriverTeamRole.EQUAL)
                else null
            }.getOrNull()
        }
        val free=prefs.getString("marketFree", "").orEmpty().split(',').mapNotNull{it.toIntOrNull()}
        val scheduled=prefs.getString("marketScheduled", "").orEmpty().split(';').filter{it.isNotBlank()}.mapNotNull { row ->
            val p=row.split(','); runCatching {
                if (p.size >= 10) FutureDriverDeal(p[0].toInt(),p[1].toInt(),p[2].toInt(),p[3].toInt(),p[4].toInt(),p[5].toLong(),DriverTeamRole.valueOf(p[6]),p[7].toInt(),p.getOrNull(9)?.toIntOrNull())
                else if (p.size >= 9) FutureDriverDeal(p[0].toInt(),p[1].toInt(),p[2].toInt(),p[3].toInt(),p[4].toInt(),p[5].toLong(),DriverTeamRole.valueOf(p[6]),p[7].toInt(),null)
                else null
            }.getOrNull()
        }
        val roles=prefs.getString("marketRoles", "").orEmpty().split(',').mapNotNull{part -> val p=part.split(':'); if(p.size==2) runCatching{p[0].toInt() to DriverRolePreference.valueOf(p[1])}.getOrNull() else null}.toMap()
        val pending=prefs.getString("marketPending", "").orEmpty().split(';').filter{it.isNotBlank()}.mapNotNull { row ->
            val p=row.split(','); runCatching {
                if (p.size >= 13 && runCatching { NegotiationStatus.valueOf(p[10]) }.isSuccess) DriverOffer(p[0].toInt(),p[1].toInt(),p[2].toInt(),p[3].toInt(),p[4].toLong(),DriverTeamRole.valueOf(p[5]),p[6].toLong(),p[7].toInt(),p[8].toInt(),p[9].toInt(),NegotiationStatus.valueOf(p[10]),p[11].toInt(),p.getOrNull(12)?.toIntOrNull())
                else if (p.size >= 13) DriverOffer(p[0].toInt(),p[1].toInt(),p[2].toInt(),p[3].toInt(),p[4].toLong(),DriverTeamRole.valueOf(p[5]),p[6].toLong(),p[8].toInt(),p[9].toInt(),p[10].toInt(),NegotiationStatus.valueOf(p[11]),p[12].toInt(),null)
                else null
            }.getOrNull()
        }
        val scouting=prefs.getString("marketScouting", "").orEmpty().split(';').filter{it.isNotBlank()}.mapNotNull { row ->
            val p=row.split(','); runCatching {
                if (p.size >= 12) ScoutingReport(p[0].toInt(),p[1].toInt(),p[2].toLong(),p[3].toInt(),p[4].toInt(),p[5].toLong(),p[6].toLong(),DriverRolePreference.valueOf(p[8]),p[9].toInt(),p[10].toInt(),p[11])
                else if (p.size >= 10) ScoutingReport(p[0].toInt(),p[1].toInt(),p[2].toLong(),p[3].toInt(),p[4].toInt(),p[5].toLong(),p[6].toLong(),DriverRolePreference.valueOf(p[8]),p[9].toInt(),2026,"")
                else if (p.size >= 9) ScoutingReport(p[0].toInt(),p[1].toInt(),p[2].toLong(),p[3].toInt(),p[4].toInt(),p[5].toLong(),p[6].toLong(),DriverRolePreference.valueOf(p[7]),p[8].toInt(),2026,"")
                else null
            }.getOrNull()
        }
        val notifications=prefs.getString("marketNotifications", "").orEmpty().split(';').filter{it.isNotBlank()}.mapNotNull { row ->
            val p=row.split('|', limit=6); if(p.size<5) null else runCatching { MarketNotification(p[0].toInt(),p[1].toInt(),p[2],p[3],p[4].toBoolean(), p.getOrNull(5)?.let { runCatching { com.f1teammanager.core.manager.MarketNewsCategory.valueOf(it) }.getOrNull() } ?: com.f1teammanager.core.manager.MarketNewsCategory.MARKET) }.getOrNull()
        }
        DriverMarketState(contracts=contracts,freeAgents=free,scheduled=scheduled,rolePreferences=roles,pending=pending,scouting=scouting,notifications=notifications).normalized()
    }.getOrNull()

    fun loadReadNewsKeys(): Set<String> = prefs.getString("marketNewsReadKeys", "").orEmpty()
        .split(";").filter { it.isNotBlank() }.toSet()

    fun markNewsRead(keys: Collection<String>) {
        if (keys.isEmpty()) return
        val merged = (loadReadNewsKeys() + keys).takeLast(300)
        prefs.edit().putString("marketNewsReadKeys", merged.joinToString(";")).apply()
    }

    fun saveDriverMarket(state: DriverMarketState) {
        val s=state.normalized()
        prefs.edit()
            .putString("marketContracts", s.contracts.joinToString(";") { listOf(it.driverId,it.teamId,it.years,it.salary,it.marketValue,it.seasonSigned,it.role.name).joinToString(",") })
            .putString("marketFree", s.freeAgents.joinToString(","))
            .putString("marketScheduled", s.scheduled.joinToString(";") { listOf(it.driverId,it.fromTeamId,it.toTeamId,it.startSeason,it.years,it.salary,it.role.name,it.signedSeason,it.replaceDriverId).joinToString(",") })
            .putString("marketRoles", s.rolePreferences.entries.joinToString(",") { "${it.key}:${it.value.name}" })
            .putString("marketPending", s.pending.joinToString(";") { listOf(it.driverId,it.fromTeamId,it.toTeamId,it.years,it.salary,it.role.name,it.marketValue,it.interestScore,it.round,it.expiresAfterWeek,it.status.name,it.seasonTarget,it.replaceDriverId).joinToString(",") })
            .putString("marketScouting", s.scouting.joinToString(";") { listOf(it.driverId,it.teamId,it.cost,it.createdWeek,it.expiresWeek,it.expectedSalary,it.marketValue,it.rolePreference.name,it.interest,it.season,it.attributeRanges).joinToString(",") })
            .putString("marketNotifications", s.notifications.joinToString(";") { listOf(it.season,it.week,it.title.replace(";", ",").replace("|", "/"),it.message.replace(";", ",").replace("|", "/"),it.important,it.category.name).joinToString("|") })
            .apply()
    }


    fun recordRace(round: Int, result: RaceResult, seasonRound: RoundDefinition? = null, qualifying: QualifyingResult? = null) {
        // Capture the championship order BEFORE adding this GP. The standings screen
        // uses this snapshot to show who went up, down or stayed in the same place
        // after each completed race.
        val oldDriverPoints = driverPoints()
        val oldConstructorPoints = constructorPoints()
        val activeIdsForStandings = loadDriverMarket()?.contracts?.filter { it.activeIn(season) }?.map { it.driverId }?.distinct()
            ?: WorldDatabase.drivers.map { it.id }
        val oldDriverOrder = activeIdsForStandings
            .map { it to (oldDriverPoints[it] ?: 0) }
            .sortedWith(compareByDescending<Pair<Int,Int>> { it.second }.thenBy { it.first })
            .mapIndexed { index, row -> row.first to index + 1 }
            .toMap()
        val oldConstructorOrder = WorldDatabase.teams
            .map { it.id to (oldConstructorPoints[it.id] ?: 0) }
            .sortedWith(compareByDescending<Pair<Int,Int>> { it.second }.thenBy { it.first })
            .mapIndexed { index, row -> row.first to index + 1 }
            .toMap()
        writeMap("previousDriverPositions", oldDriverOrder)
        writeMap("previousConstructorPositions", oldConstructorOrder)

        val drivers = oldDriverPoints.toMutableMap()
        result.points.forEach { (id, pts) -> drivers[id] = (drivers[id] ?: 0) + pts }
        writeMap("driverPoints", drivers)
        val teams = oldConstructorPoints.toMutableMap()
        val activeMarket = loadDriverMarket()
        result.classification.forEach { f ->
            val tid = activeMarket?.contracts?.firstOrNull { it.driverId == f.driverId && it.activeIn(season) }?.teamId
                ?: WorldDatabase.teams.firstOrNull { it.name.equals(f.teamName, ignoreCase = true) }?.id
                ?: WorldTeamResolver.teamIdFor(f.driverId)
            teams[tid] = (teams[tid] ?: 0) + (result.points[f.driverId] ?: 0)
        }
        writeMap("constructorPoints", teams)
        val encoded = result.classification.joinToString(";") { f ->
            val teamId = activeMarket?.contracts?.firstOrNull { it.driverId == f.driverId && it.activeIn(season) }?.teamId
                ?: WorldDatabase.teams.firstOrNull { it.name.equals(f.teamName, ignoreCase = true) }?.id
                ?: WorldTeamResolver.teamIdFor(f.driverId)
            listOf(f.position, f.driverId, f.laps, f.totalTimeMs, f.status.replace(";", ","), f.tyre.name, f.pitStops, result.points[f.driverId] ?: 0, teamId).joinToString(",")
        }
        prefs.edit().putString("race_$round", encoded).apply()
        if (seasonRound != null) {
            history.recordRace(season, seasonRound, result, qualifying, activeMarket)
            // The season archive is created immediately when GP 30 finishes.
            // Returning to the calendar later must not be required to create history.
            if (seasonRound.round == WorldDatabase.rounds.size) {
                history.finalizeSeason(season, drivers, teams, activeMarket)
            }
        }
    }

    fun raceHistory(round: Int): RaceResult? = runCatching {
        val raw = prefs.getString("race_$round", null) ?: return null
        val classification = raw.split(';').filter { it.isNotBlank() }.map { row ->
            val p = row.split(',')
            val id = p[1].toInt()
            val driver = WorldDatabase.drivers.first { it.id == id }
            val teamId = p.getOrNull(8)?.toIntOrNull() ?: driver.teamId
            val team = WorldDatabase.teams.first { it.id == teamId }
            FinishEntryCompat(p[0].toInt(), id, driver.name, team.name, p[2].toInt(), p[3].toLong(), p[4], Tyre.valueOf(p[5]), p[6].toInt())
        }
        val points = raw.split(';').filter { it.isNotBlank() }.associate { row -> val p=row.split(','); p[1].toInt() to p[7].toInt() }
        RaceResult(classification.map { it.toFinish() }, emptyList(), null, com.f1teammanager.core.race.Weather.DRY, points, 0, 0)
    }.getOrNull()

    private data class FinishEntryCompat(val position:Int,val driverId:Int,val driverName:String,val teamName:String,val laps:Int,val totalTimeMs:Long,val status:String,val tyre:Tyre,val pitStops:Int) {
        fun toFinish() = com.f1teammanager.core.race.FinishEntry(position,driverId,driverName,teamName,laps,totalTimeMs,status,tyre,pitStops)
    }

    fun loadCar(forTeamId: Int): TeamCarState? = runCatching {
        if (prefs.getInt("carTeam", -1) != forTeamId) return null
        TeamCarState(
            aerodynamics=prefs.getInt("carAero", 70), chassis=prefs.getInt("carChassis",70), engine=prefs.getInt("carEngine",70), reliability=prefs.getInt("carReliability",70),
            frontWing=prefs.getInt("carFrontWing",70), rearWing=prefs.getInt("carRearWing",70), brakes=prefs.getInt("carBrakes",70), electricPowerUnit=prefs.getInt("carErs",70),
            activeProject=if (prefs.getString("projectComponent", null) != null) DevelopmentProject(
                CarComponent.valueOf(prefs.getString("projectComponent", "ENGINE")!!),
                prefs.getInt("projectRemaining", 1), prefs.getInt("projectTotal", 1), prefs.getInt("projectLevel", 1),
                runCatching { DevelopmentIntensity.valueOf(prefs.getString("projectIntensity", "STANDARD")!!) }.getOrDefault(DevelopmentIntensity.STANDARD),
                prefs.getInt("projectGain", 4), prefs.getLong("projectCost", 0L)
            ) else null,
            nextSeasonInvestment=prefs.getLong("nextSeasonInvestment",0L),
            nextSeasonFocus=runCatching { CarDevelopmentFocus.valueOf(prefs.getString("nextSeasonFocus", "BALANCED")!!) }.getOrDefault(CarDevelopmentFocus.BALANCED),
            developmentKnowledge=loadKnowledge(),
            seasonDevelopmentGain=prefs.getInt("seasonDevelopmentGain",0)
        ).normalized()
    }.getOrNull()

    fun saveCar(forTeamId:Int, car:TeamCarState) {
        val e=prefs.edit().putInt("carTeam",forTeamId).putInt("carAero",car.aerodynamics).putInt("carChassis",car.chassis).putInt("carEngine",car.engine).putInt("carReliability",car.reliability)
            .putInt("carFrontWing",car.frontWing).putInt("carRearWing",car.rearWing).putInt("carBrakes",car.brakes).putInt("carErs",car.electricPowerUnit)
        if (car.activeProject == null) e.remove("projectComponent").remove("projectRemaining").remove("projectTotal").remove("projectLevel").remove("projectIntensity").remove("projectGain").remove("projectCost")
        else car.activeProject.let { e.putString("projectComponent",it.component.name).putInt("projectRemaining",it.remainingWeeks).putInt("projectTotal",it.totalWeeks).putInt("projectLevel",it.level).putString("projectIntensity",it.intensity.name).putInt("projectGain",it.expectedGain).putLong("projectCost",it.cost) }
        e.putLong("nextSeasonInvestment",car.nextSeasonInvestment).putString("nextSeasonFocus",car.nextSeasonFocus.name).putString("developmentKnowledge",car.developmentKnowledge.entries.joinToString(",") { "${it.key.name}:${it.value}" }).putInt("seasonDevelopmentGain",car.seasonDevelopmentGain).apply()
    }


    private fun loadKnowledge(): Map<CarComponent,Int> = prefs.getString("developmentKnowledge", "").orEmpty().split(',').mapNotNull { token ->
        val p=token.split(':')
        if (p.size==2) runCatching { CarComponent.valueOf(p[0]) to p[1].toInt().coerceIn(0,8) }.getOrNull() else null
    }.toMap()

    fun getInt(key:String, fallback:Int): Int = prefs.getInt(key,fallback)
    fun putInt(key:String, value:Int) { prefs.edit().putInt(key,value).apply() }

    fun loadFinance(forTeamId:Int, fallback:TeamFinanceState): TeamFinanceState {
        if (prefs.getInt("financeTeam", -1) != forTeamId) return fallback
        return TeamFinanceState(
            budget=prefs.getLong("budget", fallback.budget),
            seasonIncome=prefs.getLong("seasonIncome", fallback.seasonIncome),
            seasonExpenses=prefs.getLong("seasonExpenses", fallback.seasonExpenses),
            raceIncome=prefs.getLong("raceIncome", fallback.raceIncome),
            raceExpenses=prefs.getLong("raceExpenses", fallback.raceExpenses),
            seasonPrizesPaid=prefs.getString("seasonPrizesPaid", "").orEmpty().split(",").mapNotNull { it.toIntOrNull() }.toSet()
        )
    }
    fun saveFinance(forTeamId:Int, finance:TeamFinanceState) {
        prefs.edit().putInt("financeTeam",forTeamId).putLong("budget",finance.budget).putLong("seasonIncome",finance.seasonIncome).putLong("seasonExpenses",finance.seasonExpenses).putLong("raceIncome",finance.raceIncome).putLong("raceExpenses",finance.raceExpenses)
            .putString("seasonPrizesPaid", finance.seasonPrizesPaid.sorted().joinToString(","))
            .apply()
    }
    fun loadSponsor(forTeamId:Int, fallback:SponsorContract): SponsorContract {
        if (prefs.getInt("sponsorTeam", -1) != forTeamId) return fallback
        return SponsorContract(
            prefs.getString("sponsorName",fallback.name) ?: fallback.name,
            prefs.getLong("sponsorUpfront",fallback.upfront),
            prefs.getLong("sponsorRace",fallback.racePayment),
            prefs.getLong("sponsorPoints",fallback.pointsBonus),
            prefs.getInt("sponsorYears",fallback.years),
            prefs.getInt("sponsorRep",fallback.minimumReputation),
            prefs.getInt("sponsorSlot",fallback.slot),
            prefs.getInt("sponsorQualTarget",fallback.qualifyingTarget),
            prefs.getLong("sponsorQualBonus",fallback.qualifyingBonus),
            prefs.getInt("sponsorRaceTarget",fallback.raceTarget),
            prefs.getLong("sponsorRaceTargetBonus",fallback.raceTargetBonus),
            prefs.getBoolean("sponsorActive",fallback.active),
            prefs.getInt("sponsorRaces",fallback.races),
            prefs.getInt("sponsorRacesRemaining",fallback.racesRemaining)
        )
    }
    fun loadSponsors(forTeamId:Int): List<SponsorContract> {
        if (prefs.getInt("sponsorTeam", -1) != forTeamId) return emptyList()
        return (1..5).mapNotNull { slot ->
            val name=prefs.getString("sponsor_${slot}_name",null) ?: return@mapNotNull null
            SponsorContract(name, prefs.getLong("sponsor_${slot}_upfront",0), prefs.getLong("sponsor_${slot}_race",0), prefs.getLong("sponsor_${slot}_points",0), prefs.getInt("sponsor_${slot}_years",1), prefs.getInt("sponsor_${slot}_rep",0), slot, prefs.getInt("sponsor_${slot}_qualTarget",0), prefs.getLong("sponsor_${slot}_qualBonus",0), prefs.getInt("sponsor_${slot}_raceTarget",0), prefs.getLong("sponsor_${slot}_raceTargetBonus",0), prefs.getBoolean("sponsor_${slot}_active",true), prefs.getInt("sponsor_${slot}_races",5), prefs.getInt("sponsor_${slot}_racesRemaining",prefs.getInt("sponsor_${slot}_races",5)))
        }
    }
    fun saveSponsor(forTeamId:Int, sponsor:SponsorContract) = saveSponsors(forTeamId, listOf(sponsor))
    fun saveSponsors(forTeamId:Int, sponsors:List<SponsorContract>) {
        val e=prefs.edit().putInt("sponsorTeam",forTeamId)
        for (slot in 1..5) {
            val s=sponsors.firstOrNull { it.slot==slot }
            if (s==null) {
                listOf("name","upfront","race","points","years","rep","qualTarget","qualBonus","raceTarget","raceTargetBonus","active","races","racesRemaining").forEach { e.remove("sponsor_${slot}_$it") }
            } else {
                e.putString("sponsor_${slot}_name",s.name).putLong("sponsor_${slot}_upfront",s.upfront).putLong("sponsor_${slot}_race",s.racePayment).putLong("sponsor_${slot}_points",s.pointsBonus).putInt("sponsor_${slot}_years",s.years).putInt("sponsor_${slot}_rep",s.minimumReputation).putInt("sponsor_${slot}_qualTarget",s.qualifyingTarget).putLong("sponsor_${slot}_qualBonus",s.qualifyingBonus).putInt("sponsor_${slot}_raceTarget",s.raceTarget).putLong("sponsor_${slot}_raceTargetBonus",s.raceTargetBonus).putBoolean("sponsor_${slot}_active",s.active).putInt("sponsor_${slot}_races",s.races).putInt("sponsor_${slot}_racesRemaining",s.racesRemaining)
            }
        }
        // Keep legacy primary sponsor keys synchronized.
        val primary=sponsors.firstOrNull { it.slot==1 }
        if (primary==null) { e.remove("sponsorName").remove("sponsorUpfront").remove("sponsorRace").remove("sponsorPoints").remove("sponsorYears").remove("sponsorRep").remove("sponsorSlot").remove("sponsorQualTarget").remove("sponsorQualBonus").remove("sponsorRaceTarget").remove("sponsorRaceTargetBonus").remove("sponsorActive").remove("sponsorRaces").remove("sponsorRacesRemaining") }
        else { e.putString("sponsorName",primary.name).putLong("sponsorUpfront",primary.upfront).putLong("sponsorRace",primary.racePayment).putLong("sponsorPoints",primary.pointsBonus).putInt("sponsorYears",primary.years).putInt("sponsorRep",primary.minimumReputation).putInt("sponsorSlot",primary.slot).putInt("sponsorQualTarget",primary.qualifyingTarget).putLong("sponsorQualBonus",primary.qualifyingBonus).putInt("sponsorRaceTarget",primary.raceTarget).putLong("sponsorRaceTargetBonus",primary.raceTargetBonus).putBoolean("sponsorActive",primary.active).putInt("sponsorRaces",primary.races).putInt("sponsorRacesRemaining",primary.racesRemaining) }
        e.apply()
    }

    /** Current persisted attributes for all 100 drivers. */
    fun driverAttributes(): Map<Int, IntArray> {
        val raw = prefs.getString("driverAttributes", "").orEmpty()
        val parsed = raw.split(';').mapNotNull { token ->
            val p = token.split(':', limit = 2)
            if (p.size != 2) return@mapNotNull null
            val id = p[0].toIntOrNull() ?: return@mapNotNull null
            val values = p[1].split(',').mapNotNull { it.toIntOrNull() }
            if (values.size != 7) null else id to values.toIntArray()
        }.toMap()
        if (parsed.size == WorldDatabase.allDrivers.size) return parsed
        val initialized = WorldDatabase.allDrivers.associate { it.id to intArrayOf(it.speed,it.qualifying,it.overtaking,it.defense,it.consistency,it.wet,it.tyre) }
        saveDriverAttributes(initialized)
        return initialized
    }

    fun saveDriverAttributes(values: Map<Int, IntArray>) {
        prefs.edit().putString("driverAttributes", values.toSortedMap().entries.joinToString(";") { (id,a) -> "$id:${a.joinToString(",")}" }).apply()
    }

    fun driverDefinition(driverId:Int): com.f1teammanager.core.season.DriverDefinition {
        val base = WorldDatabase.allDrivers.first { it.id == driverId }
        val a = driverAttributes()[driverId] ?: intArrayOf(base.speed,base.qualifying,base.overtaking,base.defense,base.consistency,base.wet,base.tyre)
        return base.copy(speed=a[0],qualifying=a[1],overtaking=a[2],defense=a[3],consistency=a[4],wet=a[5],tyre=a[6])
    }

    fun currentDrivers(): List<com.f1teammanager.core.season.DriverDefinition> =
        WorldDatabase.allDrivers.map { driverDefinition(it.id) }

    private fun readSeasonTargets(): Map<Int, DriverEvolutionEngine.Target> {
        return prefs.getString("driverSeasonTargets_$season", "").orEmpty().split(',').mapNotNull { token ->
            val p=token.split(':'); if(p.size!=2) null else p[0].toIntOrNull()?.let { id -> p[1].toIntOrNull()?.let { pos -> id to DriverEvolutionEngine.Target(pos) } }
        }.toMap()
    }

    fun initializeDriverSeasonTargets(playerCar: TeamCarState? = null) {
        val market = loadDriverMarket()
        val active = market?.contracts?.filter { it.activeIn(season) }
            ?: WorldDatabase.drivers.map { d -> com.f1teammanager.core.manager.DriverDeal(d.id,d.teamId,1,0L,0L,season) }
        val scores = active.mapNotNull { deal ->
            val d = WorldDatabase.allDrivers.firstOrNull { it.id == deal.driverId } ?: return@mapNotNull null
            val team = WorldDatabase.teams.firstOrNull { it.id == deal.teamId } ?: return@mapNotNull null
            val teamStrength = if (deal.teamId == teamId && playerCar != null) {
                (playerCar.aerodynamics + playerCar.chassis + playerCar.engine + playerCar.reliability + playerCar.frontWing + playerCar.rearWing + playerCar.brakes + playerCar.electricPowerUnit) / 8.0
            } else team.baseCar.toDouble()
            val a = driverAttributes()[d.id] ?: intArrayOf(d.speed,d.qualifying,d.overtaking,d.defense,d.consistency,d.wet,d.tyre)
            val overall = a.sum() / 7.0
            d.id to (teamStrength * .60 + overall * .40)
        }.sortedByDescending { it.second }
        val targets = scores.mapIndexed { index, row -> row.first to DriverEvolutionEngine.Target(index+1) }.toMap()
        prefs.edit().putString("driverSeasonTargets_$season", targets.entries.sortedBy { it.key }.joinToString(",") { "${it.key}:${it.value.championshipPosition}" }).apply()
    }

    /**
     * Applies one in-season evolution tick after a completed GP. Evolution is continuous
     * during the championship; GP30 only closes the season and does not perform a second
     * evolution pass. The fractional bank makes changes gradual while keeping the official
     * annual gain ceiling from DriverProfileCatalog.
     */
    private fun readAnnualAttributeGains(): MutableMap<Int, IntArray> {
        val raw = prefs.getString("driverEvolutionAttributeGains_$season", "").orEmpty()
        val out = mutableMapOf<Int, IntArray>()
        raw.split(';').filter { it.isNotBlank() }.forEach { token ->
            val p = token.split(':')
            if (p.size == 2) {
                val id = p[0].toIntOrNull()
                val values = p[1].split(',').mapNotNull { it.toIntOrNull() }
                if (id != null && values.size == 7) out[id] = values.toIntArray()
            }
        }
        return out
    }

    private fun writeAnnualAttributeGains(values: Map<Int, IntArray>) {
        prefs.edit().putString(
            "driverEvolutionAttributeGains_$season",
            values.toSortedMap().entries.joinToString(";") { (id, a) -> "$id:${a.joinToString(",")}" }
        ).apply()
    }

    /**
     * Applies one in-season evolution tick after a completed GP.
     * Positive evolution uses the full intended gain, with per-attribute class-ceiling
     * redistribution. Regression is independent and is capped at the floor 40.
     */
    fun applyDriverRaceEvolution(round: Int): List<String> {
        val targets = readSeasonTargets().ifEmpty { initializeDriverSeasonTargets(); readSeasonTargets() }
        val races = history.raceRecords(season)
        val qualifying = history.qualifyingRecords(season)
        val attrs = driverAttributes().toMutableMap()
        val banks = readDoubleMap("driverEvolutionBank_$season").toMutableMap()
        val annual = readAnnualAttributeGains()
        val changes = mutableListOf<String>()

        // All 100 registered drivers evolve every GP tick. The 80 active drivers
        // use real race performance; drivers without an active contract use natural
        // evolution at 70% utilization because they have no race performance.
        val activeDriverIds = loadDriverMarket()?.contracts
            ?.filter { it.activeIn(season) }
            ?.map { it.driverId }
            ?.toSet()
            ?: races.filter { it.round == round }.map { it.driverId }.toSet()

        WorldDatabase.allDrivers.forEach { base ->
            val id = base.id
            val isActive = id in activeDriverIds
            val currentAttrs = attrs[id] ?: intArrayOf(base.speed,base.qualifying,base.overtaking,base.defense,base.consistency,base.wet,base.tyre)
            val current = base.copy(speed=currentAttrs[0],qualifying=currentAttrs[1],overtaking=currentAttrs[2],defense=currentAttrs[3],consistency=currentAttrs[4],wet=currentAttrs[5],tyre=currentAttrs[6])
            val gainCap = DriverProfileCatalog.maxAnnualGain(current.evolution)
            val gainUsage = annual.getOrPut(id) { IntArray(7) }

            val utilization: Double
            val evaluationTier: String
            if (isActive) {
                val target = targets[id] ?: DriverEvolutionEngine.Target(80)
                val seasonRaces = races.filter { it.season == season && it.round <= round }
                val seasonQualifying = qualifying.filter { it.season == season && it.round <= round }
                val driverSeasonRows = seasonRaces.filter { it.driverId == id }.sortedBy { it.round }
                val driverQualRows = seasonQualifying.filter { it.driverId == id }.sortedBy { it.round }
                val points = driverSeasonRows.sumOf { it.points }
                val wins = driverSeasonRows.count { it.position == 1 && !it.status.startsWith("DNF") }
                val podiums = driverSeasonRows.count { it.position in 1..3 && !it.status.startsWith("DNF") }
                val avgRace = driverSeasonRows.map { if (it.status.startsWith("DNF")) 80 else it.position }.average()
                val avgQual = driverQualRows.takeIf { it.isNotEmpty() }?.map { it.position }?.average() ?: avgRace
                val teammatePositions = driverSeasonRows.mapNotNull { own ->
                    seasonRaces.firstOrNull { other ->
                        other.round == own.round && other.teamId == own.teamId && other.driverId != own.driverId
                    }?.let { if (it.status.startsWith("DNF")) 80 else it.position }
                }
                val currentChampionshipPosition = seasonRaces
                    .groupBy { it.driverId }
                    .map { (driverId, rows) -> driverId to rows.sumOf { it.points } }
                    .sortedWith(compareByDescending<Pair<Int,Int>> { it.second }.thenBy { it.first })
                    .indexOfFirst { it.first == id }
                    .let { if (it >= 0) it + 1 else target.championshipPosition }
                val evaluation = DriverEvolutionEngine.evaluate(
                    current,
                    target,
                    DriverEvolutionEngine.PerformanceInput(
                        championshipPosition = currentChampionshipPosition.coerceIn(1, 80),
                        points = points,
                        averageRacePosition = avgRace,
                        wins = wins,
                        podiums = podiums,
                        averageQualifyingPosition = avgQual,
                        teammateAveragePosition = teammatePositions.takeIf { it.isNotEmpty() }?.average(),
                        teammateComparisons = teammatePositions.size
                    )
                )
                utilization = DriverEvolutionEngine.performanceUtilization(evaluation.index)
                evaluationTier = evaluation.tier
            } else {
                utilization = 0.70
                evaluationTier = "Livre — evolução natural"
            }

            // The annual cap is per attribute. The weekly/GP budget therefore spans
            // all seven attributes; applyPositiveGain redistributes points while
            // respecting each attribute's individual cap and class ceiling.
            val naturalPerRace = (gainCap.toDouble() * 7.0) / WorldDatabase.rounds.size.toDouble().coerceAtLeast(1.0)
            var bank = (banks[id] ?: 0.0) + naturalPerRace * utilization
            var delta = 0
            while (bank >= 1.0 && gainUsage.any { it < gainCap }) {
                delta++
                bank -= 1.0
            }

            val random = kotlin.random.Random(20261006 + season * 1000 + round * 97 + id * 31)
            var next = current
            if (delta > 0) {
                next = DriverEvolutionEngine.applyPositiveGain(next, delta, gainUsage, random)
                val actual = intArrayOf(next.speed,next.qualifying,next.overtaking,next.defense,next.consistency,next.wet,next.tyre)
                    .zip(intArrayOf(current.speed,current.qualifying,current.overtaking,current.defense,current.consistency,current.wet,current.tyre))
                    .sumOf { (a,b) -> a-b }
                if (actual > 0) changes += "${current.name}: +$actual distribuído entre atributos (GP $round, desempenho $evaluationTier)"
                if (actual < delta) bank += (delta - actual).toDouble()
            }
            attrs[id] = intArrayOf(next.speed,next.qualifying,next.overtaking,next.defense,next.consistency,next.wet,next.tyre)
            val beforeOverall = (current.speed + current.qualifying + current.overtaking + current.defense + current.consistency + current.wet + current.tyre) / 7
            val afterOverall = (next.speed + next.qualifying + next.overtaking + next.defense + next.consistency + next.wet + next.tyre) / 7
            if (afterOverall != beforeOverall) {
                val market = loadDriverMarket()
                if (market != null) {
                    val direction = if (afterOverall > beforeOverall) "evoluiu para" else "regrediu para"
                    val delta = afterOverall - beforeOverall
                    val signed = if (delta > 0) "+$delta" else delta.toString()
                    saveDriverMarket(market.copy(notifications = market.notifications + MarketNotification(
                        season, round, "EVOLUÇÃO DE PILOTO",
                        "${current.name} $direction Overall $afterOverall ($signed ponto(s)).", true, MarketNewsCategory.DRIVER_EVOLUTION
                    )).normalized())
                }
            }
            banks[id] = bank
        }
        saveDriverAttributes(attrs)
        writeAnnualAttributeGains(annual)
        writeDoubleMap("driverEvolutionBank_$season", banks)
        return changes
    }

    fun startNewCareer(selectedTeamId: Int) {
        teamId = selectedTeamId; roundIndex = 0; currentWeek = 1; season = 2026; hasCareer = true
        writeMap("driverPoints", emptyMap()); writeMap("constructorPoints", emptyMap())
        for (r in 1..WorldDatabase.rounds.size) prefs.edit().remove("race_$r").apply()
        history.clear()
        prefs.edit().remove("driverEvolutionAppliedSeason").remove("driverEvolutionBank_$season").remove("driverEvolutionAccumulated_$season").remove("driverEvolutionAttributeGains_$season").apply()
        saveDriverAttributes(WorldDatabase.allDrivers.associate { it.id to intArrayOf(it.speed,it.qualifying,it.overtaking,it.defense,it.consistency,it.wet,it.tyre) })
        initializeDriverSeasonTargets()
        val t=WorldDatabase.teams.first { it.id==selectedTeamId }
        saveCar(selectedTeamId, TeamCarState(t.baseCar,t.chassis,t.engine,t.reliability,frontWing=t.frontWing,rearWing=t.rearWing,brakes=t.brakes,electricPowerUnit=t.electricPowerUnit))
        saveFinance(selectedTeamId, TeamFinanceState(75_000_000L));
        prefs.edit().remove("aiTeamBudgets").remove("constructorPrizePaidTeams_2026").apply()
        putInt("annualDriverSalarySeason_${selectedTeamId}",0); saveSponsors(selectedTeamId, emptyList())
        saveDriverMarket(com.f1teammanager.core.manager.DriverMarketEngine().initialState(season))
    }

    /** True after GP 30 has been archived, while the game is still on the completed season. */
    fun isSeasonEnded(): Boolean =
        roundIndex == WorldDatabase.rounds.lastIndex && history.isSeasonFinalized(season)

    /**
     * Advance to the next GP after a completed race.
     * GP 30 is deliberately different: it only archives the season and leaves the
     * current year/round intact until the manager explicitly starts the next season.
     */
    fun completeCurrentRace() {
        if (roundIndex < WorldDatabase.rounds.lastIndex) {
            roundIndex += 1
            // Do NOT move currentWeek here. The completed GP happened in the current
            // week; the manager must return to the calendar and manually advance the
            // remaining free weeks until the next GP week.
        } else {
            history.finalizeSeason(season, driverPoints(), constructorPoints(), loadDriverMarket())
            // Stay on the completed season. No automatic year change here.
        }
    }

    /** Explicit player action: starts the archived season's successor. */
    fun startNextSeason() {
        require(isSeasonEnded()) { "A temporada atual ainda não foi encerrada." }
        season += 1
        roundIndex = 0
        currentWeek = 1
        writeMap("driverPoints", emptyMap())
        writeMap("constructorPoints", emptyMap())
        for (r in 1..WorldDatabase.rounds.size) prefs.edit().remove("race_$r").apply()
        prefs.edit().remove("driverEvolutionAppliedSeason").remove("driverEvolutionBank_$season").remove("driverEvolutionAccumulated_$season").remove("driverEvolutionAttributeGains_$season").apply()
        initializeDriverSeasonTargets()
        loadDriverMarket()?.let { saveDriverMarket(com.f1teammanager.core.manager.DriverMarketEngine().applySeasonTransition(it, season)) }
    }

    /** Advance one or more real calendar weeks. Returns the number of weeks actually advanced. */
    fun advanceCalendarWeeks(weeks: Int): Int {
        val old = currentWeek
        currentWeek = (currentWeek + weeks.coerceAtLeast(0)).coerceAtMost(56)
        return currentWeek - old
    }

    fun jumpToWeek(week: Int): Int {
        val old = currentWeek
        currentWeek = week
        return currentWeek - old
    }
}
private object WorldTeamResolver { fun teamIdFor(driverId: Int): Int = ((driverId - 1) / 2) + 1 }
