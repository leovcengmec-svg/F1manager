package com.f1teammanager

import android.content.Context
import android.util.AtomicFile
import java.io.File
import org.json.JSONArray
import org.json.JSONObject
import com.f1teammanager.core.manager.DevelopmentProject
import com.f1teammanager.core.manager.FinanceEngine
import com.f1teammanager.core.manager.AITeamFinancialEngine
import com.f1teammanager.core.manager.SeasonSettlementEngine
import com.f1teammanager.core.manager.TeamManagerState
import com.f1teammanager.core.manager.DevelopmentIntensity
import com.f1teammanager.core.manager.ResearchProject
import com.f1teammanager.core.manager.ResearchDesign
import com.f1teammanager.core.manager.TeamResearchState
import com.f1teammanager.core.manager.CarPiece
import com.f1teammanager.core.manager.FactoryOrder
import com.f1teammanager.core.manager.TeamFactoryState
import com.f1teammanager.core.manager.TeamGarage
import com.f1teammanager.core.manager.TeamGarageFactory
import com.f1teammanager.core.manager.PhysicalCar
import com.f1teammanager.core.manager.GarageCarId
import com.f1teammanager.core.manager.CarComponent
import com.f1teammanager.core.manager.ResearchFocus
import com.f1teammanager.core.manager.ResearchComplexity
import com.f1teammanager.core.manager.ResearchOutcome
import com.f1teammanager.core.manager.CarDevelopmentFocus
import com.f1teammanager.core.manager.TeamCarState
import com.f1teammanager.core.manager.TeamFinanceState
import com.f1teammanager.core.manager.TeamFacilitiesState
import com.f1teammanager.core.manager.FacilityType
import com.f1teammanager.core.manager.FacilityUpgradeState
import com.f1teammanager.core.manager.InitialTeamProfile
import com.f1teammanager.core.manager.SponsorContract
import com.f1teammanager.core.manager.SponsorContractPricing
import com.f1teammanager.core.race.RaceResult
import com.f1teammanager.core.race.FinishEntry
import com.f1teammanager.core.race.LapEvent
import com.f1teammanager.core.race.EventType
import com.f1teammanager.core.race.Weather
import com.f1teammanager.core.race.QualifyingEntry
import com.f1teammanager.core.race.QualifyingPhase
import com.f1teammanager.core.race.QualifyingResult
import com.f1teammanager.core.season.RoundDefinition
import com.f1teammanager.core.race.Tyre
import com.f1teammanager.core.season.WorldDatabase
import com.f1teammanager.core.season.DriverEvolutionEngine
import com.f1teammanager.core.season.DriverClassProgressionEngine
import com.f1teammanager.core.season.DriverProfileCatalog
import com.f1teammanager.core.manager.DriverMarketState
import com.f1teammanager.core.manager.DriverMarketEngine
import com.f1teammanager.core.manager.DriverDeal
import com.f1teammanager.core.manager.DriverOffer
import com.f1teammanager.core.manager.FutureDriverDeal
import com.f1teammanager.core.manager.DriverTeamRole
import com.f1teammanager.core.manager.SignatureFeeSchedule
import com.f1teammanager.core.manager.SignatureFeeAccounting
import com.f1teammanager.core.manager.SalaryLedger
import com.f1teammanager.core.manager.TeamPrincipalCareerEngine
import com.f1teammanager.core.manager.TeamPrincipalCareerState
import com.f1teammanager.core.manager.TeamPrincipalTeamHandoff
import com.f1teammanager.core.manager.DriverRolePreference
import com.f1teammanager.core.manager.NegotiationStatus
import com.f1teammanager.core.manager.ScoutingReport
import com.f1teammanager.core.manager.MarketNotification
import com.f1teammanager.core.manager.MarketNewsCategory
import com.f1teammanager.core.season.SeasonCalendar

/** Public, validated metadata used by the save manager without mutating the active career. */
data class CareerSaveMetadata(
    val mode: String,
    val teamId: Int,
    val season: Int,
    val careerId: String,
    val schema: Int
) {
    fun modeLabel(): String = when (mode) {
        "FREE" -> "LIVRE"
        "HARD" -> "DIFÍCIL"
        "TEAM_PRINCIPAL" -> "TIME PRINCIPAL"
        else -> "MODO DESCONHECIDO"
    }
}

/** A durable marker for an unfinished weekend. The full live engine is intentionally not serialized. */
data class ActiveWeekendCheckpoint(val season: Int, val round: Int, val startedAt: Long)


/** Live board-confidence projection and matching dismissal-risk forecast for the Team Principal UI. */
data class TeamPrincipalLiveBoardAssessment(
    val support: Int,
    val dismissalRisk: Int
)

/** Persistent career metadata, championship ledger, race archive and car P&D state. */
class CareerPreferences(context: Context) {
    val history = HistoricalDatabase(context)
    private val transitionContext = context.applicationContext
    private val prefs = context.getSharedPreferences("f1tm_career", Context.MODE_PRIVATE)
    // Coordinates career preferences and the three historical archive locations
    // behind one durable commit point during import.
    private val careerImportJournalFile = File(transitionContext.filesDir, "f1tm_career_import.transaction")
    private val careerImportJournalAtomic = AtomicFile(careerImportJournalFile)

    init {
        // Resolve an interrupted multi-file career import before exposing any save state.
        // HistoricalDatabase is initialized first and uses this same journal to decide
        // whether to keep or roll back the staged archive.
        recoverInterruptedCareerImportTransaction()
        // If the process died while an offer was being staged, restore the exact
        // pre-transaction career before exposing any state to the UI.
        recoverInterruptedTeamPrincipalOfferTransaction()
        // Keep the team selector and the new career on the exact same initial-car
        // draw. Previously the selector used the fallback seed, then startNewCareer
        // generated a different seed; this changed the car overalls and reordered
        // the teams immediately after selection.
        val hasSavedCareer = prefs.getBoolean("hasCareer", false)
        val storedSeason = prefs.getInt("season", 2026)
        val storedSeasonSeed = prefs.getInt("calendarSeed_$storedSeason", 0)
        val pendingSeed = prefs.getInt("pendingCareerSeed", 0)

        // The opening-car seed is immutable for the whole career. Calendar seeds
        // intentionally change each season for schedule variation, but must never
        // reorder the original car-strength ranking or regenerate initial garages.
        val openingSeed = if (hasSavedCareer) {
            val savedOpeningSeed = prefs.getInt("openingCarSeed", 0)
            val migratedSeed = savedOpeningSeed.takeIf { it != 0 }
                ?: prefs.getInt("calendarSeed_2026", 0).takeIf { it != 0 }
                ?: storedSeasonSeed.takeIf { it != 0 }
                ?: pendingSeed.takeIf { it != 0 }
                ?: kotlin.random.Random.nextInt().let { if (it == 0) 1 else it }
            if (savedOpeningSeed == 0) {
                check(prefs.edit().putInt("openingCarSeed", migratedSeed).commit()) {
                    "Não foi possível preservar a semente do carro inicial"
                }
            }
            migratedSeed
        } else {
            val safePending = pendingSeed.takeIf { it != 0 }
                ?: kotlin.random.Random.nextInt().let { if (it == 0) 1 else it }
            prefs.edit().putInt("pendingCareerSeed", safePending).apply()
            safePending
        }

        if (!hasSavedCareer) {
            prefs.edit().putInt("pendingCareerSeed", openingSeed).apply()
        } else if (storedSeasonSeed != 0) {
            SeasonCalendar.configureSeasonSeed(storedSeason, storedSeasonSeed)
        }
        InitialTeamProfile.configureCareerSeed(openingSeed)
        // One-time migration for V648 and earlier saves: correct the opening class
        // bands and retire random legacy class overrides without deleting career history.
        if (hasSavedCareer) migrateDriverClassSystemV649()
    }

    /** Persisted regulatory draw: reopening a career never rerolls a season rule. */
    fun loadCarRegulationRule(seasonNumber: Int): com.f1teammanager.core.manager.AnnualCarRegulationEngine.SeasonRule? {
        if (seasonNumber < 1) return null
        val encoded = prefs.getString("carRegulationRule_$seasonNumber", null) ?: return null
        val decoded = com.f1teammanager.core.manager.AnnualCarRegulationEngine.decode(encoded) ?: return null
        // Reject V443 drafts that accidentally treated the calendar year as an ordinal.
        val expectedIndex = com.f1teammanager.core.manager.AnnualCarRegulationEngine.seasonIndexForCalendarYear(seasonNumber)
        return decoded.takeIf { it.season == expectedIndex }
    }

    fun ensureCarRegulationRule(seasonNumber: Int): com.f1teammanager.core.manager.AnnualCarRegulationEngine.SeasonRule {
        require(seasonNumber >= 1)
        loadCarRegulationRule(seasonNumber)?.let { return it }
        // One seed per career: every team shares the same annual rule, but a new
        // career gets a different deterministic sequence. Existing saved rules win.
        val seed = carRegulationSeed()
        val rule = com.f1teammanager.core.manager.AnnualCarRegulationEngine.generateForCalendarYear(seasonNumber, seed)
        check(prefs.edit().putString("carRegulationRule_$seasonNumber",
            com.f1teammanager.core.manager.AnnualCarRegulationEngine.encode(rule)).commit()) {
            "Não foi possível salvar o regulamento da temporada $seasonNumber"
        }
        return rule
    }


    /** Stable championship-wide seed for annual car regulations, persisted per career. */
    fun carRegulationSeed(): Int {
        val existing = prefs.getInt("carRegulationSeed", 0)
        if (existing != 0) return existing
        val seasonNow = prefs.getInt("season", 2026)
        val fallback = prefs.getInt("calendarSeed_$seasonNow", 0).takeIf { it != 0 }
            ?: prefs.getInt("pendingCareerSeed", 0).takeIf { it != 0 }
            ?: kotlin.random.Random.nextInt().let { if (it == 0) 1 else it }
        check(prefs.edit().putInt("carRegulationSeed", fallback).commit()) {
            "Não foi possível salvar a semente dos regulamentos anuais"
        }
        return fallback
    }

    /**
     * Prepare the exact opening-car seed before the team-selection screen is shown.
     * This is important when starting a new career while another career already
     * exists: the old career's calendar seed must not be used by the selector if
     * startNewCareer will later use a fresh seed.
     */
    fun prepareNewCareerSelection(): Int {
        // Every explicit entry into Novo Jogo is a new, provisional universe.
        // Never reuse pendingCareerSeed left behind by a canceled selection.
        val previousPending = prefs.getInt("pendingCareerSeed", 0)
            .takeIf { it != 0 } ?: prefs.getInt("openingCarSeed", 0)
        val candidate = kotlin.random.Random.nextInt()
        // A distinct seed alone is not enough: different seeds can still produce
        // the same visible ordering or the same three challenge teams. Guarantee
        // that both change when the dataset admits another ordering.
        val seed = InitialTeamProfile.freshRankingSeed(
            teams = WorldDatabase.teams,
            previousSeed = previousPending,
            candidateSeed = candidate,
            challengeCount = 3
        )
        check(prefs.edit().putInt("pendingCareerSeed", seed).commit()) {
            "Não foi possível preparar a semente da nova carreira"
        }
        // Preview uses this seed explicitly; don't mutate the active career's global seed
        // unless the player confirms a team in startNewCareer().
        return seed
    }

    private fun newCalendarSeed(season: Int): Int {
        val seed = kotlin.random.Random.nextInt().let { if (it == 0) 1 else it }
        prefs.edit().putInt("calendarSeed_$season", seed).apply()
        SeasonCalendar.configureSeasonSeed(season, seed)
        // Do not reconfigure InitialTeamProfile here: this seed belongs only to
        // this season's calendar, not to the immutable opening-car ranking.
        return seed
    }

    var hasCareer: Boolean
        get() = prefs.getBoolean("hasCareer", false)
        private set(value) = prefs.edit().putBoolean("hasCareer", value).apply()
    var teamId: Int
        get() = prefs.getInt("teamId", 1)
        private set(value) = prefs.edit().putInt("teamId", value).apply()
    var roundIndex: Int
        get() = prefs.getInt("roundIndex", 0)
        private set(value) = prefs.edit().putInt("roundIndex", value.coerceIn(0, SeasonCalendar.forSeason(season).lastIndex)).apply()
    /** Current calendar week. Race weekends occupy specific weeks; the other weeks are free development weeks. */
    var currentWeek: Int
        get() = prefs.getInt("currentWeek", SeasonCalendar.forSeason(season).first().weekOfSeason.coerceAtLeast(1) - 2).coerceIn(1, 56)
        private set(value) = prefs.edit().putInt("currentWeek", value.coerceIn(1, 56)).apply()
    var season: Int
        get() = prefs.getInt("season", 2026)
        private set(value) = prefs.edit().putInt("season", value).apply()


    /** Raw state is kept separate so the active game mode, not just stale data, controls visibility. */
    private fun rawTeamPrincipalCareer(): TeamPrincipalCareerState? =
        TeamPrincipalCareerState.decode(prefs.getString("teamPrincipalCareer", null))

    /** True only when the active save is a Team Principal career. Older TP saves without the mode key
     * are migrated safely; a fresh Free/Hard career explicitly stores its mode and clears TP state. */
    fun isTeamPrincipalMode(): Boolean {
        val state = rawTeamPrincipalCareer()
        val mode = prefs.getString("activeGameMode", null)
        if (mode == null && state != null) {
            // Migrate older TP saves that predate the explicit mode marker.
            check(prefs.edit().putString("activeGameMode", "TEAM_PRINCIPAL").commit()) {
                "Não foi possível migrar o modo da carreira Team Principal."
            }
            return true
        }
        return TeamPrincipalCareerEngine.isActiveMode(mode, state != null)
    }

    fun setActiveGameMode(mode: String) {
        require(mode in setOf("FREE", "HARD", "TEAM_PRINCIPAL")) { "Modo de jogo inválido." }
        check(prefs.edit().putString("activeGameMode", mode).commit()) {
            "Não foi possível salvar o modo de jogo ativo."
        }
    }

    /** Mode is a first-class part of a career, not a UI selection left over from another game. */
    fun activeGameMode(): String {
        val stored = prefs.getString("activeGameMode", null)
        if (stored in setOf("FREE", "HARD", "TEAM_PRINCIPAL")) return stored!!
        val legacyPrincipal = rawTeamPrincipalCareer() != null
        val migrated = if (legacyPrincipal) "TEAM_PRINCIPAL" else "FREE"
        check(prefs.edit().putString("activeGameMode", migrated).commit()) {
            "Não foi possível identificar e persistir o modo da carreira."
        }
        return migrated
    }

    /** Stable identity prevents two careers with the same team/year/date from overwriting each other. */
    fun careerSaveId(): String {
        prefs.getString("careerId", null)?.takeIf { it.isNotBlank() }?.let { return it }
        val id = java.util.UUID.randomUUID().toString()
        check(prefs.edit().putString("careerId", id).commit()) {
            "Não foi possível identificar esta carreira para o salvamento."
        }
        return id
    }

    fun teamPrincipalCareer(): TeamPrincipalCareerState? =
        if (isTeamPrincipalMode()) rawTeamPrincipalCareer() else null

    fun startTeamPrincipalCareer(selectedTeamId: Int) {
        com.f1teammanager.core.manager.TechnicalInvestmentEngine.resetLiveOverallRegistry()
        val openingRanks = InitialTeamProfile.openingRanking(WorldDatabase.teams)
            .mapIndexed { index, team -> team.id to (index + 1) }.toMap()
        val openingFacilities = loadFacilities(selectedTeamId)?.levels?.mapValues { it.value } ?: emptyMap()
        val state = TeamPrincipalCareerEngine.initial(selectedTeamId, season, openingRanks, openingFacilities)
        check(prefs.edit()
            .putString("teamPrincipalCareer", state.encode())
            .putString("activeGameMode", "TEAM_PRINCIPAL")
            .commit()) {
            "Não foi possível iniciar o registro do Modo Team Principal."
        }
    }

    /**
     * Calibrates next-season board goals after the finalized new-car strength ranking is known.
     * The state stores a season marker so reveal/start screens, recompositions and save reloads
     * cannot silently regenerate or soften objectives more than once.
     */
    fun prepareTeamPrincipalObjectivesForOpening(
        openingSeason: Int,
        openingRankByTeam: Map<Int, Int>
    ): TeamPrincipalCareerState? {
        val state = teamPrincipalCareer() ?: return null
        if (state.dismissed) return state
        val teamDefinition = WorldDatabase.teams.firstOrNull { it.id == state.teamId } ?: return state
        val facilities = loadFacilities(state.teamId)?.levels
            ?: InitialTeamProfile.teamFacilities(teamDefinition.initialLevel).levels
        val finance = loadFinance(state.teamId, TeamFinanceState(InitialTeamProfile.initialBudget(teamDefinition)))
        val previousSeasonPoints = history.constructorSeasonRecords(openingSeason - 1)
            .firstOrNull { it.teamId == state.teamId }?.points
            ?: state.objectives.firstOrNull { it.kind == "points_gain" }?.target
            ?: 0
        val updated = TeamPrincipalCareerEngine.prepareObjectivesForOpeningSeason(
            state, openingSeason, openingRankByTeam, facilities, previousSeasonPoints, FinanceEngine().effectiveClosingBalance(finance)
        )
        if (updated != state) {
            check(prefs.edit().putString("teamPrincipalCareer", updated.encode()).commit()) {
                "Não foi possível salvar os objetivos da diretoria calibrados para a temporada $openingSeason."
            }
        }
        return updated
    }

    /** Uses the official season table (including sporting tie-breaks) once finalized; otherwise uses live points. */
    private fun teamPrincipalRanksForSeason(targetSeason: Int, points: Map<Int, Int>): Map<Int, Int> {
        val official = history.constructorSeasonRecords(targetSeason).associate { it.teamId to it.position }
        if (official.size >= WorldDatabase.teams.size) return official
        return WorldDatabase.teams.sortedWith(
            compareByDescending<com.f1teammanager.core.season.TeamDefinition> { points[it.id] ?: 0 }
                .thenBy { it.id }
        ).mapIndexed { index, team -> team.id to (index + 1) }.toMap()
    }

    /** Live forecast uses the same inputs and shared scoring as the end-of-season decision. */
    fun teamPrincipalLiveBoardAssessment(): TeamPrincipalLiveBoardAssessment? {
        val state = teamPrincipalCareer() ?: return null
        if (state.dismissed) return TeamPrincipalLiveBoardAssessment(state.boardSupport.coerceIn(0, 100), 100)
        val points = constructorPoints()
        val currentRanks = teamPrincipalRanksForSeason(season, points)
        val rank = currentRanks[state.teamId] ?: 40
        val team = WorldDatabase.teams.firstOrNull { it.id == state.teamId } ?: return null
        val finance = loadFinance(state.teamId, TeamFinanceState(InitialTeamProfile.initialBudget(team)))
        val effectiveBalance = FinanceEngine().effectiveClosingBalance(finance)
        val cashTarget = state.objectives.firstOrNull { it.kind == "cash" }?.target?.toLong() ?: 0L
        val financialStress = TeamPrincipalCareerEngine.financialStressPercent(effectiveBalance, cashTarget)
        val facilities = loadFacilities(state.teamId)?.levels?.mapValues { it.value } ?: emptyMap()
        val research = loadResearch(state.teamId) ?: TeamResearchState()
        val factory = loadFactory(state.teamId) ?: TeamFactoryState()
        val completedResearch = research.completedDesigns.count { it.researchSeason == season }
        val researchProgress = research.activeProjects.mapNotNull { project ->
            if (project.totalWeeks <= 0) null else
                ((project.totalWeeks - project.remainingWeeks).coerceAtLeast(0) * 100 / project.totalWeeks).coerceIn(0, 100).coerceAtLeast(1)
        }.maxOrNull() ?: 0
        val currentSeasonPieces = factory.pendingInstallations.count { it.manufacturedSeason == season }
        val manufacturingProgress = factory.activeOrders.mapNotNull { order ->
            if (order.totalWeeks <= 0) null else
                ((order.totalWeeks - order.remainingWeeks).coerceAtLeast(0) * 100 / order.totalWeeks).coerceIn(0, 100).coerceAtLeast(1)
        }.maxOrNull() ?: 0
        val raceRecords = history.raceRecords(season).filter { it.teamId == state.teamId }
        val qualifyingRecords = history.qualifyingRecords(season).filter { it.teamId == state.teamId }
        val hasSeasonEvidence = raceRecords.isNotEmpty() || qualifyingRecords.isNotEmpty()
        val raceScore = TeamPrincipalCareerEngine.performanceScore(raceRecords.map { it.position }, state.objectiveRank)
        val qualifyingScore = TeamPrincipalCareerEngine.performanceScore(qualifyingRecords.map { it.position }, state.objectiveRank)
        val objectiveResults = TeamPrincipalCareerEngine.evaluateObjectives(
            state, rank, points[state.teamId] ?: 0, effectiveBalance, facilities,
            completedResearch, currentSeasonPieces
        )
        val objectiveCompletion = if (hasSeasonEvidence) TeamPrincipalCareerEngine.objectiveCompletionPercent(objectiveResults) else 50
        val facilityUpgradeProgress = loadFacilityUpgrade(state.teamId)?.let { upgrade ->
            if (upgrade.totalWeeks <= 0) 0 else
                ((upgrade.totalWeeks - upgrade.remainingWeeks).coerceAtLeast(0) * 100 / upgrade.totalWeeks).coerceIn(0, 100).coerceAtLeast(1)
        } ?: 0
        val facilityInvestment = if (hasSeasonEvidence)
            TeamPrincipalCareerEngine.facilityInvestmentScore(state.objectives, objectiveResults, facilityUpgradeProgress) else 1
        val developmentProgress = if (hasSeasonEvidence)
            TeamPrincipalCareerEngine.developmentProgressScore(completedResearch, researchProgress, currentSeasonPieces, manufacturingProgress) else 1
        val previousRecord = state.records.lastOrNull()
        val repeatedFailure = previousRecord != null &&
            previousRecord.teamId == state.teamId && previousRecord.teamRank >= previousRecord.objectiveRank + 2 && rank >= state.objectiveRank + 2
        // The UI displays the same projected support that will be persisted at season close.
        // Before the first sporting evidence, retain the contract's 50-point opening baseline.
        val projectedSupport = if (hasSeasonEvidence)
            TeamPrincipalCareerEngine.projectedBoardSupport(state, rank, objectiveResults) else state.boardSupport.coerceIn(0, 100)
        val dismissalRisk = TeamPrincipalCareerEngine.dismissalProbabilityPercent(
            projectedSupport, rank, state.objectiveRank, repeatedFailure, raceScore,
            qualifyingScore, financialStress, developmentProgress, facilityInvestment, objectiveCompletion
        )
        return TeamPrincipalLiveBoardAssessment(projectedSupport, dismissalRisk)
    }

    /** Backward-compatible accessor for callers that only need the dismissal-risk percentage. */
    fun teamPrincipalDismissalRiskEstimate(): Int? = teamPrincipalLiveBoardAssessment()?.dismissalRisk

    /** Records the finished season once, updates board support and creates offers only when the signed term ends. */
    fun recordTeamPrincipalSeason(): TeamPrincipalCareerState? {
        val state = teamPrincipalCareer() ?: return null
        if (state.dismissed || season <= state.lastProcessedSeason) return state
        val points = constructorPoints()
        val currentRanks = teamPrincipalRanksForSeason(season, points)
        val rank = currentRanks[state.teamId] ?: 40
        // Evaluate both drivers across every completed GP using the shared career scoring.
        val raceRecords = history.raceRecords(season).filter { it.teamId == state.teamId }
        val qualifyingRecords = history.qualifyingRecords(season).filter { it.teamId == state.teamId }
        val racePerformance = TeamPrincipalCareerEngine.performanceScore(raceRecords.map { it.position }, state.objectiveRank)
        val qualifyingPerformance = TeamPrincipalCareerEngine.performanceScore(qualifyingRecords.map { it.position }, state.objectiveRank)
        val finance = loadFinance(
            state.teamId, TeamFinanceState(InitialTeamProfile.initialBudget(WorldDatabase.teams.first { it.id == state.teamId }))
        )
        val effectiveClosingBalance = FinanceEngine().effectiveClosingBalance(finance)
        val research = loadResearch(state.teamId) ?: TeamResearchState()
        val factory = loadFactory(state.teamId) ?: TeamFactoryState()
        val researchProgress = research.activeProjects.mapNotNull { project ->
            if (project.totalWeeks <= 0) null else
                ((project.totalWeeks - project.remainingWeeks).coerceAtLeast(0) * 100 / project.totalWeeks).coerceIn(0, 100).coerceAtLeast(1)
        }.maxOrNull() ?: 0
        val currentSeasonPieces = factory.pendingInstallations.count { it.manufacturedSeason == season }
        val manufacturingProgress = factory.activeOrders.mapNotNull { order ->
            if (order.totalWeeks <= 0) null else
                ((order.totalWeeks - order.remainingWeeks).coerceAtLeast(0) * 100 / order.totalWeeks).coerceIn(0, 100).coerceAtLeast(1)
        }.maxOrNull() ?: 0
        val facilityUpgradeProgress = loadFacilityUpgrade(state.teamId)?.let { upgrade ->
            if (upgrade.totalWeeks <= 0) 0 else
                ((upgrade.totalWeeks - upgrade.remainingWeeks).coerceAtLeast(0) * 100 / upgrade.totalWeeks).coerceIn(0, 100).coerceAtLeast(1)
        } ?: 0
        val updated = TeamPrincipalCareerEngine.recordSeason(
            state, season, rank, currentRanks,
            constructorPoints = points[state.teamId] ?: 0,
            cashBalance = effectiveClosingBalance,
            facilityLevels = loadFacilities(state.teamId)?.levels?.mapValues { it.value } ?: emptyMap(),
            completedResearchCount = research.completedDesigns.count { it.researchSeason == season },
            manufacturedPiecesReady = currentSeasonPieces,
            researchProgressPercent = researchProgress,
            manufacturingProgressPercent = manufacturingProgress,
            facilityUpgradeProgressPercent = facilityUpgradeProgress,
            racePerformance = racePerformance,
            qualifyingPerformance = qualifyingPerformance
        )
        if (updated != state) {
            var editor = prefs.edit().putString("teamPrincipalCareer", updated.encode())
            if (updated.reviewPending && updated.offersSeason == season) {
                val teamById = WorldDatabase.teams.associateBy { it.id }
                val offerSummary = updated.contractOffers.joinToString("; ") { offer ->
                    "${teamById[offer.teamId]?.name ?: "Equipe ${offer.teamId}"} (${offer.years} ${if (offer.years == 1) "ano" else "anos"})"
                }
                val title = if (updated.dismissed) "DEMISSÃO DO TEAM PRINCIPAL" else "PROPOSTAS DE TEAM PRINCIPAL"
                val lead = if (updated.dismissed) {
                    "A diretoria encerrou seu contrato. O apoio atual está em ${updated.boardSupport}%. Oportunidades disponíveis: "
                } else {
                    "Seu contrato terminou. Apoio da diretoria: ${updated.boardSupport}%. Você recebeu ${updated.contractOffers.size} proposta(s): "
                }
                val market = loadDriverMarket() ?: DriverMarketState()
                val duplicateExists = market.notifications.any { it.season == season && it.title == title }
                if (!duplicateExists) {
                    val notice = MarketNotification(
                        season = season, week = 56, title = title,
                        message = "$lead$offerSummary. Abra Minha Carreira para comparar as condições e escolher o próximo contrato.",
                        important = true, category = com.f1teammanager.core.manager.MarketNewsCategory.MARKET
                    )
                    editor = driverMarketEditor(editor, market.copy(notifications = (market.notifications + notice).takeLast(1000)))
                }
            }
            check(editor.commit()) {
                "Não foi possível registrar o resultado contratual e seus avisos para a temporada $season."
            }
        }
        return updated
    }

    fun renewTeamPrincipalContract(contractYears: Int? = null): TeamPrincipalCareerState? {
        val state = teamPrincipalCareer() ?: return null
        val offeredCurrentYears = state.contractOffers.firstOrNull { it.isCurrentTeam && it.teamId == state.teamId }?.years
        require(offeredCurrentYears != null) { "A equipe atual não apresentou uma renovação nesta janela." }
        val points = constructorPoints()
        val rank = teamPrincipalRanksForSeason(season, points)[state.teamId] ?: 40
        val teamDefinition = WorldDatabase.teams.first { it.id == state.teamId }
        val actualFacilities = loadFacilities(state.teamId)?.levels ?: InitialTeamProfile.teamFacilities(teamDefinition.initialLevel).levels
        val actualFinance = loadFinance(state.teamId, TeamFinanceState(InitialTeamProfile.initialBudget(teamDefinition)))
        val previousPoints = points[state.teamId] ?: history.constructorSeasonRecords(season - 1).firstOrNull { it.teamId == state.teamId }?.points ?: 0
        val years = (contractYears ?: offeredCurrentYears).coerceIn(1, 2)
        require(years == offeredCurrentYears) { "A duração não corresponde à proposta de renovação recebida." }
        val updated = TeamPrincipalCareerEngine.renew(state, season + 1, rank, actualFacilities, previousPoints, FinanceEngine().effectiveClosingBalance(actualFinance), years)
        check(prefs.edit().putString("teamPrincipalCareer", updated.encode()).commit()) {
            "Não foi possível registrar a renovação do contrato."
        }
        return updated
    }

    /**
     * Queue a signed Team Principal contract for the next season. The active team and
     * current-season career identity are deliberately unchanged until the season journal
     * commits the boundary.
     */
    fun scheduleTeamPrincipalOffer(
        newTeamId: Int,
        contractYears: Int = 1,
        destinationFacilityLevels: Map<FacilityType, Int>? = null,
        destinationCashBalance: Long? = null
    ): TeamPrincipalCareerState {
        val state = teamPrincipalCareer() ?: error("Carreira Team Principal não encontrada.")
        require(WorldDatabase.teams.any { it.id == newTeamId }) { "Equipe de destino inválida." }
        require(newTeamId != teamId) { "Você já trabalha nessa equipe." }
        require(newTeamId in state.offerTeamIds) { "Essa equipe não enviou uma proposta válida." }
        val signedYears = state.contractOffers.firstOrNull { it.teamId == newTeamId }?.years ?: 1
        require(contractYears in 1..2 && contractYears == signedYears) { "A duração informada não corresponde à proposta recebida." }
        check(prefs.getInt("teamPrincipalPendingTeamId", 0) == 0) {
            "Já existe uma mudança de equipe agendada para a próxima temporada."
        }
        val points = constructorPoints()
        val rank = teamPrincipalRanksForSeason(season, points)[newTeamId] ?: 40
        val destinationDefinition = WorldDatabase.teams.first { it.id == newTeamId }
        val destinationFacilities = destinationFacilityLevels
            ?: loadFacilities(newTeamId)?.levels
            ?: InitialTeamProfile.teamFacilities(destinationDefinition.initialLevel).levels
        val destinationCash = destinationCashBalance ?: aiTeamBudget(newTeamId)
        val destinationPreviousPoints = points[newTeamId]
            ?: history.constructorSeasonRecords(season).firstOrNull { it.teamId == newTeamId }?.points
            ?: 0
        val futureCareer = TeamPrincipalCareerEngine.acceptOffer(
            state, newTeamId, season + 1, rank, destinationFacilities, destinationPreviousPoints, destinationCash, signedYears
        )
        val waitingCareer = state.copy(reviewPending = false, dismissed = false, offerTeamIds = emptyList(), contractOffers = emptyList(), offersSeason = 0)
        check(prefs.edit()
            .putInt("teamPrincipalPendingTeamId", newTeamId)
            .putString("teamPrincipalPendingCareer", futureCareer.encode())
            .putString("teamPrincipalCareer", waitingCareer.encode())
            .commit()) {
            "Não foi possível gravar o contrato futuro do Team Principal."
        }
        return futureCareer
    }

    fun pendingTeamPrincipalOffer(): Pair<Int, TeamPrincipalCareerState>? {
        val id = prefs.getInt("teamPrincipalPendingTeamId", 0)
        if (id <= 0) return null
        val state = TeamPrincipalCareerState.decode(prefs.getString("teamPrincipalPendingCareer", null)) ?: return null
        if (state.teamId != id || state.contractStartSeason != season + 1) return null
        return id to state
    }

    /** Called inside the season-transition journal, so failure restores the old team and pending offer. */
    fun activatePendingTeamPrincipalOffer(targetSeason: Int): Boolean {
        val pending = pendingTeamPrincipalOffer() ?: return false
        val id = pending.first
        val state = pending.second
        if (state.contractStartSeason != targetSeason) return false
        val committed = prefs.edit()
            .putInt("teamId", id)
            .putString("teamPrincipalCareer", state.encode())
            .putInt("teamPrincipalAutoFillRosterSeason", targetSeason)
            .remove("teamPrincipalPendingTeamId")
            .remove("teamPrincipalPendingCareer")
            .remove("teamPrincipalHandoff_$id")
            .commit()
        return committed
    }

    fun hasPendingTeamPrincipalOffer(): Boolean = pendingTeamPrincipalOffer() != null

    /** Backward-compatible entry point: accepted offers are now scheduled, not activated early. */
    fun acceptTeamPrincipalOffer(newTeamId: Int, contractYears: Int = 1): TeamPrincipalCareerState? =
        scheduleTeamPrincipalOffer(newTeamId, contractYears)

    private fun teamPrincipalOfferTransactionPrefs() = snapshotContext.getSharedPreferences(
        "f1tm_team_principal_offer_transaction", Context.MODE_PRIVATE
    )

    fun beginTeamPrincipalOfferTransaction() {
        val backup = teamPrincipalOfferTransactionPrefs()
        require(!backup.getBoolean("__ready", false)) {
            "Há uma transação Team Principal interrompida; ela precisa ser recuperada antes de continuar."
        }
        val editor = backup.edit().clear()
        prefs.all.forEach { (key, value) ->
            when (value) {
                is String -> editor.putString(key, value)
                is Int -> editor.putInt(key, value)
                is Long -> editor.putLong(key, value)
                is Float -> editor.putFloat(key, value)
                is Boolean -> editor.putBoolean(key, value)
                is Set<*> -> editor.putStringSet(key, value.filterIsInstance<String>().toMutableSet())
            }
        }
        editor.putBoolean("__ready", true)
        check(editor.commit()) { "Não foi possível criar o ponto de restauração da contratação." }
    }

    fun completeTeamPrincipalOfferTransaction() {
        check(teamPrincipalOfferTransactionPrefs().edit().clear().commit()) {
            "O contrato foi preparado, mas não foi possível encerrar o registro transacional."
        }
    }

    fun rollbackTeamPrincipalOfferTransaction(): Boolean {
        val backup = teamPrincipalOfferTransactionPrefs()
        if (!backup.getBoolean("__ready", false)) return true
        val editor = prefs.edit().clear()
        backup.all.forEach { (key, value) ->
            if (key == "__ready") return@forEach
            when (value) {
                is String -> editor.putString(key, value)
                is Int -> editor.putInt(key, value)
                is Long -> editor.putLong(key, value)
                is Float -> editor.putFloat(key, value)
                is Boolean -> editor.putBoolean(key, value)
                is Set<*> -> editor.putStringSet(key, value.filterIsInstance<String>().toMutableSet())
            }
        }
        val restored = editor.commit()
        return restored && backup.edit().clear().commit()
    }

    private fun recoverInterruptedTeamPrincipalOfferTransaction() {
        val backup = teamPrincipalOfferTransactionPrefs()
        if (backup.getBoolean("__ready", false)) {
            check(rollbackTeamPrincipalOfferTransaction()) {
                "Uma contratação Team Principal interrompida não pôde ser revertida. Preserve este save e tente novamente."
            }
        }
    }

    fun teamPrincipalReviewPending(): Boolean = teamPrincipalCareer()?.reviewPending == true

    fun saveTeamPrincipalHandoff(
        teamId: Int, closingSeason: Int, car: TeamCarState, garage: TeamGarage,
        facilities: TeamFacilitiesState
    ) {
        val handoff = TeamPrincipalTeamHandoff(
            teamId = teamId, closingSeason = closingSeason, garage = garage,
            facilities = facilities, nextSeasonInvestment = car.nextSeasonInvestment,
            technicalKnowledge = car.developmentKnowledge
        )
        check(prefs.edit().putString("teamPrincipalHandoff_$teamId", handoff.encode()).commit()) {
            "Não foi possível preservar o carro físico de $teamId após a troca de Team Principal."
        }
    }

    fun loadTeamPrincipalHandoff(teamId: Int): TeamPrincipalTeamHandoff? =
        TeamPrincipalTeamHandoff.decode(prefs.getString("teamPrincipalHandoff_$teamId", null))
            ?.takeIf { it.teamId == teamId }

    private fun readMap(key: String): Map<Int, Int> = prefs.getString(key, "").orEmpty().split(',').mapNotNull { token ->
        val p = token.split(':')
        if (p.size == 2) p[0].toIntOrNull()?.let { id -> p[1].toIntOrNull()?.let { value -> id to value } } else null
    }.toMap()
    private fun writeMap(key: String, value: Map<Int, Int>) = prefs.edit().putString(key, value.entries.sortedBy { it.key }.joinToString(",") { "${it.key}:${it.value}" }).apply()

    private fun readDoubleMap(key: String): Map<Int, Double> = prefs.getString(key, "").orEmpty().split(',').mapNotNull { token ->
        val p=token.split(':')
        if (p.size != 2) null else p[0].toIntOrNull()?.let { id -> p[1].toDoubleOrNull()?.let { value -> id to value } }
    }.toMap()
    private fun writeDoubleMap(key: String, value: Map<Int, Double>) = prefs.edit().putString(key, value.entries.sortedBy { it.key }.joinToString(",") { "${it.key}:${it.value}" }).apply()

    /** Per-driver seven-attribute ledger used for age-only physical regression/recovery. */
    private fun readDriverAgeAttributeMap(key: String): MutableMap<Int, IntArray> =
        prefs.getString(key, "").orEmpty().split(';').mapNotNull { token ->
            val parts = token.split(':', limit = 2)
            if (parts.size != 2) null else {
                val id = parts[0].toIntOrNull()
                val values = parts[1].split(',').mapNotNull { it.toIntOrNull() }
                if (id == null || values.size != 7) null else id to values.toIntArray()
            }
        }.toMap().toMutableMap()

    private fun encodeDriverAgeAttributeMap(values: Map<Int, IntArray>): String =
        values.toSortedMap().entries.joinToString(";") { (id, ratings) -> "$id:${ratings.joinToString(",")}" }

    fun driverAgePhysicalLosses(): Map<Int, List<Int>> =
        readDriverAgeAttributeMap("driverAgePhysicalLosses").mapValues { it.value.toList() }

    fun driverAgePhysicalPeaks(): Map<Int, List<Int>> =
        readDriverAgeAttributeMap("driverAgePhysicalPeaks").mapValues { it.value.toList() }

    fun driverAgeCycleIndices(): Map<Int, Int> = readMap("driverAgeCycleIndices")
    fun driverAgeDeclineBanks(): Map<Int, Double> = readDoubleMap("driverAgeDeclineBanks")

    fun driverPoints(): Map<Int, Int> = readMap("driverPoints")
    fun constructorPoints(): Map<Int, Int> = readMap("constructorPoints")

    /** Roster the team will actually have after accepted future contracts are applied. */
    fun projectedDriverRosterForSeason(targetSeason: Int, forTeamId: Int = teamId): List<Int> {
        // A legacy/partially migrated save may not yet have the structured market blob.
        // Project the canonical starter grid in memory rather than permanently blocking
        // season progression; this fallback does not overwrite or mutate the saved career.
        val market = loadDriverMarket() ?: DriverMarketEngine().initialState(targetSeason)
        val future = market.scheduled.filter { it.startSeason <= targetSeason }
        val leavingIds = future.filter { it.fromTeamId == forTeamId && it.toTeamId != forTeamId }
            .map { it.driverId }.toSet()
        val replacedIds = future.filter { it.toTeamId == forTeamId }.mapNotNull { it.replaceDriverId }.toSet()
        val retained = market.contracts.filter { it.teamId == forTeamId && it.activeIn(targetSeason) }
            .map { it.driverId }.filterNot { it in leavingIds || it in replacedIds }
        val incoming = future.filter { it.toTeamId == forTeamId }.map { it.driverId }
        return (retained + incoming).distinct()
    }

    /** V36 canonical financial settlement ledger for every team, including AI. */
    fun aiTeamBudget(teamId: Int): Long {
        val raw = prefs.getString("aiTeamBudgets", "").orEmpty()
        return raw.split(";").firstOrNull { it.startsWith("$teamId:") }?.substringAfter(":")?.toLongOrNull()
            ?: WorldDatabase.teams.firstOrNull { it.id == teamId }?.let { InitialTeamProfile.initialBudget(it) }
                ?: 0L
    }

    fun loadAiFinanceSnapshot(): String = prefs.getString("aiFinanceSnapshot", "").orEmpty()
    fun saveAiFinanceSnapshot(raw:String): Boolean = prefs.edit().putString("aiFinanceSnapshot", raw).commit()
    fun loadAiSponsorshipSnapshot(): String = prefs.getString("aiSponsorshipSnapshot", "").orEmpty()
    fun saveAiSponsorshipSnapshot(raw:String): Boolean = prefs.edit().putString("aiSponsorshipSnapshot", raw).commit()

    /**
     * Random event seed is generated once per career-season and persisted. It is never
     * a source-code constant: new careers receive a fresh seed, while reloads and
     * week advances reuse the same seed and cannot reroll already scheduled events.
     */
    fun annualEventSeed(seasonNumber: Int): Int {
        require(seasonNumber >= 1)
        val key = "annualEventSeed_$seasonNumber"
        val existing = prefs.getInt(key, 0)
        if (existing != 0) return existing
        val generated = kotlin.random.Random.nextInt().let { if (it == 0) 1 else it }
        prefs.edit().putInt(key, generated).commit()
        return prefs.getInt(key, generated)
    }

    /** V260: persist the season event calendar so loading a career never rerolls it. */
    fun loadAnnualEventCalendar(seasonNumber: Int): List<com.f1teammanager.core.manager.AnnualTeamEventSeasonCalendar.Slot> {
        val raw = prefs.getString("annualEventCalendar_$seasonNumber", null) ?: return emptyList()
        return raw.split(";").mapNotNull { entry ->
            val parts = entry.split(",")
            if (parts.size != 3) null else runCatching {
                com.f1teammanager.core.manager.AnnualTeamEventSeasonCalendar.Slot(
                    week = parts[0].toInt(),
                    kind = com.f1teammanager.core.manager.AnnualTeamEventEngine.Kind.valueOf(parts[1]),
                    ordinal = parts[2].toInt()
                ).takeIf { it.week in 1..56 && it.ordinal > 0 }
            }.getOrNull()
        }.distinctBy { it.week to it.ordinal }.sortedBy { it.week }
    }

    /** Writes only when absent, preserving the original draw for the entire season. */
    fun ensureAnnualEventCalendar(seasonNumber: Int, seed: Int): List<com.f1teammanager.core.manager.AnnualTeamEventSeasonCalendar.Slot> {
        require(seasonNumber >= 1)
        val existing = loadAnnualEventCalendar(seasonNumber)
        if (prefs.contains("annualEventCalendar_$seasonNumber")) return existing
        val generated = com.f1teammanager.core.manager.AnnualTeamEventSeasonCalendar.generate(seasonNumber, seed)
        val serialized = generated.joinToString(";") { "${it.week},${it.kind.name},${it.ordinal}" }
        prefs.edit().putString("annualEventCalendar_$seasonNumber", serialized).commit()
        return loadAnnualEventCalendar(seasonNumber)
    }

    /**
     * V264: returns only the events scheduled for a specific week that have not
     * been recorded as processed. This is a read-only claim check: callers must
     * apply and persist effects before calling markAnnualEventKeysProcessed.
     */
    fun pendingAnnualEventsForWeek(
        seasonNumber: Int,
        week: Int,
        seed: Int
    ): List<com.f1teammanager.core.manager.AnnualTeamEventSeasonCalendar.Slot> {
        if (seasonNumber < 1 || week !in 1..56) return emptyList()
        val calendar = ensureAnnualEventCalendar(seasonNumber, seed)
        val processed = loadProcessedAnnualEventKeys(seasonNumber)
        return calendar.filter { slot ->
            slot.week == week &&
                "${slot.week}:${slot.kind.name}:${slot.ordinal}" !in processed
        }
    }

    /** V264: stable keys for a due batch; persist only after successful effects. */
    fun annualEventKeysFor(
        slots: List<com.f1teammanager.core.manager.AnnualTeamEventSeasonCalendar.Slot>
    ): Set<String> = slots.map { "${it.week}:${it.kind.name}:${it.ordinal}" }.toSet()

    /** Event/week idempotency ledger, persisted separately from the generated calendar. */
    fun loadProcessedAnnualEventKeys(seasonNumber: Int): Set<String> =
        prefs.getString("annualEventProcessed_$seasonNumber", "").orEmpty().split("|").filter { it.isNotBlank() }.toSet()

    fun markAnnualEventKeysProcessed(seasonNumber: Int, keys: Set<String>) {
        require(seasonNumber >= 1)
        val merged = (loadProcessedAnnualEventKeys(seasonNumber) + keys).toSortedSet().toList().takeLast(1000)
        prefs.edit().putString("annualEventProcessed_$seasonNumber", merged.joinToString("|")).commit()
    }

    private fun saveAiTeamBudgets(values: Map<Int, Long>) {
        check(prefs.edit().putString("aiTeamBudgets", values.toSortedMap().entries.joinToString(";") { "${it.key}:${it.value}" }).commit()) {
            "Não foi possível sincronizar o caixa das equipes controladas pela IA."
        }
    }

    /**
     * Durable, immutable ranking used exclusively for constructor-prize settlement.
     * It is written BEFORE any payout so a process death can replay only missing
     * team ledgers, even when the historical race archive is incomplete.
     */
    private fun loadConstructorPrizeRanking(seasonNumber: Int): Map<Int, Int>? {
        val raw = prefs.getString("constructorPrizeRanking_$seasonNumber", null) ?: return null
        val parsed = raw.split(",").mapNotNull { token ->
            val pair = token.split(":")
            if (pair.size != 2) null else runCatching { pair[0].toInt() to pair[1].toInt() }.getOrNull()
        }.toMap()
        val teamIds = WorldDatabase.teams.map { it.id }.toSet()
        val positions = parsed.values.toList()
        return parsed.takeIf {
            it.size == teamIds.size && it.keys == teamIds &&
                positions.toSet() == (1..teamIds.size).toSet()
        }
    }

    private fun saveConstructorPrizeRanking(seasonNumber: Int, positions: Map<Int, Int>) {
        val teamIds = WorldDatabase.teams.map { it.id }.toSet()
        require(positions.size == teamIds.size && positions.keys == teamIds &&
            positions.values.toSet() == (1..teamIds.size).toSet()) {
            "A classificação de premiação precisa conter as 40 equipes e posições únicas."
        }
        val encoded = positions.toSortedMap().entries.joinToString(",") { "${it.key}:${it.value}" }
        check(prefs.edit().putString("constructorPrizeRanking_$seasonNumber", encoded).commit()) {
            "Não foi possível congelar a classificação de premiação da temporada $seasonNumber."
        }
    }

    private fun constructorPrizeRankingSeasons(): Set<Int> = prefs.all.keys
        .filter { it.startsWith("constructorPrizeRanking_") }
        .mapNotNull { it.removePrefix("constructorPrizeRanking_").toIntOrNull() }
        .toSet()

    /**
     * Canonical, idempotent constructors-prize settlement for the player and all AI teams.
     * Ranking is calculated once. Each team's own finance ledger is the payment authority;
     * the legacy AI budget cache is synchronized from those real balances after settlement.
     * This also repairs older saves whose legacy paid-team marker was written before an
     * AI finance snapshot durably received every award.
     */
    fun settleConstructorsSeason(
        seasonToClose: Int,
        aiFinance: AITeamFinancialEngine
    ): List<SeasonSettlementEngine.Settlement> {
        // Give the normal historical archive its chance to finalize first. Prize
        // settlement still has a standings-based fallback if a race shard is missing.
        if (seasonToClose == season && !history.isSeasonFinalized(seasonToClose)) {
            history.finalizeSeason(seasonToClose, driverPoints(), constructorPoints(), loadDriverMarket())
        }
        // Prefer a previously frozen prize ranking. It is the recovery authority if a
        // prior attempt paid some teams and the app closed before all 40 ledgers saved.
        val archivedPositions = history.constructorSeasonRecords(seasonToClose)
            .takeIf { history.isSeasonFinalized(seasonToClose) && it.size >= WorldDatabase.teams.size }
            ?.associate { it.teamId to it.position }
            ?.takeIf { positions ->
                val ids = WorldDatabase.teams.map { it.id }.toSet()
                positions.size == ids.size && positions.keys == ids &&
                    positions.values.toSet() == (1..ids.size).toSet()
            }

        val positions = loadConstructorPrizeRanking(seasonToClose)
            ?: archivedPositions
            ?: run {
                check(seasonToClose == season) {
                    "A classificação histórica de construtores está incompleta para $seasonToClose; não é seguro inventar uma premiação retroativa."
                }
                // The live constructor-points table is the authoritative in-career
                // standings source at GP30. Do not block the prize because a race shard
                // or annual summary failed to persist; all 40 teams are ranked, with
                // zero-point teams retained by SeasonSettlementEngine.
                val live = SeasonSettlementEngine.settleAll(constructorPoints())
                    .associate { it.teamId to it.position }
                saveConstructorPrizeRanking(seasonToClose, live)
                live
            }

        // Freeze archived/live positions before the first financial write. If the app
        // dies midway through the 40 payouts, a retry uses exactly the same order.
        if (loadConstructorPrizeRanking(seasonToClose) == null) {
            saveConstructorPrizeRanking(seasonToClose, positions)
        }

        val settlements = WorldDatabase.teams.map { team ->
            val position = positions[team.id]
                ?: error("Equipe ${team.id} ausente da classificação final de $seasonToClose.")
            SeasonSettlementEngine.Settlement(
                teamId = team.id,
                position = position,
                prize = com.f1teammanager.core.manager.SeasonPrizeEngine.prizeForPosition(position)
            )
        }.sortedBy { it.position }

        val playerSettlement = settlements.firstOrNull { it.teamId == teamId }
            ?: error("Equipe do jogador ausente da classificação final de construtores.")
        val playerFinance = loadFinance(teamId, TeamFinanceState(0L))
        val updatedPlayerFinance = FinanceEngine().applyConstructorsPrizeFinance(
            playerFinance, seasonToClose, playerSettlement.position
        )
        if (updatedPlayerFinance != playerFinance) {
            check(financeEditor(teamId, updatedPlayerFinance).commit()) {
                "Não foi possível gravar a premiação de construtores da equipe do jogador."
            }
        }

        // Each AI team's finance ledger is independently idempotent. The old summary
        // cache is never used to decide whether a prize has already been paid.
        settlements.filter { it.teamId != teamId }.forEach { settlement ->
            aiFinance.applySeasonConstructorsPrize(
                settlement.teamId, seasonToClose, settlement.position
            )
        }
        check(saveAiFinanceSnapshot(aiFinance.exportSnapshot())) {
            "Não foi possível persistir a premiação das equipes controladas pela IA."
        }
        syncAiTeamBudgetBalances(aiFinance.allStates().associate { it.teamId to it.finance.budget })

        val paid = prefs.getString("constructorPrizePaidTeams_$seasonToClose", "")
            .orEmpty().split(",").mapNotNull { it.toIntOrNull() }.toMutableSet()
        paid.addAll(settlements.map { it.teamId })
        check(prefs.edit().putString(
            "constructorPrizePaidTeams_$seasonToClose", paid.sorted().joinToString(",")
        ).commit()) { "Não foi possível confirmar o registro de premiações da temporada $seasonToClose." }
        return settlements
    }

    /**
     * Replays only finalized historical seasons whose canonical finance ledgers are missing
     * a prize marker. This repairs an older finalization journal that may have marked
     * season_prizes complete before the AI finance snapshot durably received every award.
     */
    fun reconcileFinalizedConstructorPrizes(
        aiFinance: AITeamFinancialEngine,
        throughSeason: Int
    ): List<Int> {
        if (throughSeason <= 0) return emptyList()
        val archivedSeasons = history.constructorSeasonRecords().map { it.season }.toSet()
        val knownSeasons = (archivedSeasons + constructorPrizeRankingSeasons())
            .filter { it <= throughSeason }
            .filter { it in constructorPrizeRankingSeasons() || history.isSeasonFinalized(it) }
            .sorted()
        val reconciled = mutableListOf<Int>()
        knownSeasons.forEach { closedSeason ->
            val frozenRanking = loadConstructorPrizeRanking(closedSeason)
            val completeArchive = history.isSeasonFinalized(closedSeason)
            if (frozenRanking == null && !completeArchive) return@forEach
            val playerPaid = closedSeason in loadFinance(teamId, TeamFinanceState(0L)).seasonPrizesPaid
            val aiStates = aiFinance.allStates().filter { it.teamId != teamId }
            val expectedAiCount = (WorldDatabase.teams.size - 1).coerceAtLeast(0)
            val aiPaidCount = aiStates.count { closedSeason in it.finance.seasonPrizesPaid }
            if (!playerPaid || aiStates.size < expectedAiCount || aiPaidCount < expectedAiCount) {
                settleConstructorsSeason(closedSeason, aiFinance)
                reconciled += closedSeason
            }
        }
        return reconciled
    }

    /** Keep offseason market/handoff cash in sync with the canonical AI finance ledger. */
    fun syncAiTeamBudgetBalances(values: Map<Int, Long>) {
        if (values.isEmpty()) return
        saveAiTeamBudgets(values.mapValues { it.value.coerceAtLeast(0L) })
    }

    fun previousDriverPositions(): Map<Int, Int> = readMap("previousDriverPositions")
    fun previousConstructorPositions(): Map<Int, Int> = readMap("previousConstructorPositions")

    fun loadDriverMarket(): DriverMarketState? = runCatching {
        val rawContracts = prefs.getString("marketContracts", null) ?: return null
        val contracts = rawContracts.split(';').filter { it.isNotBlank() }.mapNotNull { row ->
            val p=row.split(','); runCatching {
                if (p.size >= 8) DriverDeal(p[0].toInt(),p[1].toInt(),p[2].toInt(),p[3].toLong(),p[4].toLong(),p[6].toInt(),DriverTeamRole.valueOf(p[7]))
                else if (p.size >= 7) DriverDeal(p[0].toInt(),p[1].toInt(),p[2].toInt(),p[3].toLong(),p[4].toLong(),p[5].toInt(),runCatching { DriverTeamRole.valueOf(p[6]) }.getOrDefault(DriverTeamRole.EQUAL))
                else null
            }.getOrNull()
        }
        val free=prefs.getString("marketFree", "").orEmpty().split(',').mapNotNull{it.toIntOrNull()}
        val scheduled=prefs.getString("marketScheduled", "").orEmpty().split(';').filter{it.isNotBlank()}.mapNotNull { row ->
            val p=row.split(','); runCatching {
                if (p.size >= 10) FutureDriverDeal(p[0].toInt(),p[1].toInt(),p[2].toInt(),p[3].toInt(),p[4].toInt(),p[5].toLong(),DriverTeamRole.valueOf(p[6]),p[7].toInt(),p.getOrNull(9)?.toIntOrNull())
                else if (p.size >= 9) FutureDriverDeal(p[0].toInt(),p[1].toInt(),p[2].toInt(),p[3].toInt(),p[4].toInt(),p[5].toLong(),DriverTeamRole.valueOf(p[6]),p[7].toInt(),p[8].toIntOrNull())
                else null
            }.getOrNull()
        }
        val roles=prefs.getString("marketRoles", "").orEmpty().split(',').mapNotNull{part -> val p=part.split(':'); if(p.size==2) runCatching{p[0].toInt() to DriverRolePreference.valueOf(p[1])}.getOrNull() else null}.toMap()
        val pending=prefs.getString("marketPending", "").orEmpty().split(';').filter{it.isNotBlank()}.mapNotNull { row ->
            val p=row.split(','); runCatching {
                if (p.size >= 13 && runCatching { NegotiationStatus.valueOf(p[10]) }.isSuccess) DriverOffer(p[0].toInt(),p[1].toInt(),p[2].toInt(),p[3].toInt(),p[4].toLong(),DriverTeamRole.valueOf(p[5]),p[6].toLong(),p[7].toInt(),p[8].toInt(),p[9].toInt(),NegotiationStatus.valueOf(p[10]),p[11].toInt(),p.getOrNull(12)?.toIntOrNull(),p.getOrNull(13)?.toIntOrNull() ?: 0)
                else if (p.size >= 13) DriverOffer(p[0].toInt(),p[1].toInt(),p[2].toInt(),p[3].toInt(),p[4].toLong(),DriverTeamRole.valueOf(p[5]),p[6].toLong(),p[8].toInt(),p[9].toInt(),p[10].toInt(),NegotiationStatus.valueOf(p[11]),p[12].toInt(),null,0)
                else null
            }.getOrNull()
        }
        val scouting=prefs.getString("marketScouting", "").orEmpty().split(';').filter{it.isNotBlank()}.mapNotNull { row ->
            val p=row.split(','); runCatching {
                if (p.size >= 12) ScoutingReport(p[0].toInt(),p[1].toInt(),p[2].toLong(),p[3].toInt(),p[4].toInt(),p[5].toLong(),p[6].toLong(),DriverRolePreference.valueOf(p[8]),p[9].toInt(),p[10].toInt(),p[11])
                else if (p.size >= 10) ScoutingReport(p[0].toInt(),p[1].toInt(),p[2].toLong(),p[3].toInt(),p[4].toInt(),p[5].toLong(),p[6].toLong(),DriverRolePreference.valueOf(p[8]),p[9].toInt(),2026,"")
                else if (p.size >= 9) ScoutingReport(p[0].toInt(),p[1].toInt(),p[2].toLong(),p[3].toInt(),p[4].toInt(),p[5].toLong(),p[6].toLong(),DriverRolePreference.valueOf(p[7]),p[8].toInt(),2026,"")
                else null
            }.getOrNull()
        }
        val notifications=prefs.getString("marketNotifications", "").orEmpty().split(';').filter{it.isNotBlank()}.mapNotNull { row ->
            val p=row.split('|', limit=7); if(p.size<5) null else runCatching { MarketNotification(p[0].toInt(),p[1].toInt(),p[2],p[3],p[4].toBoolean(), p.getOrNull(5)?.let { runCatching { com.f1teammanager.core.manager.MarketNewsCategory.valueOf(it) }.getOrNull() } ?: com.f1teammanager.core.manager.MarketNewsCategory.MARKET, p.getOrNull(6)?.takeIf { it.isNotBlank() }?.toIntOrNull()) }.getOrNull()
        }
        val renewalEvaluations = prefs.getString("marketRenewalEvaluations", "").orEmpty().split(",").filter { it.isNotBlank() }.toSet()
        DriverMarketState(contracts=contracts,freeAgents=free,scheduled=scheduled,rolePreferences=roles,pending=pending,scouting=scouting,notifications=notifications,renewalEvaluations=renewalEvaluations).normalized()
    }.getOrNull()

    fun loadReadNewsKeys(): Set<String> = prefs.getString("marketNewsReadKeys", "").orEmpty()
        .split(";").filter { it.isNotBlank() }.toSet()

    fun markNewsRead(keys: Collection<String>) {
        if (keys.isEmpty()) return
        val merged = (loadReadNewsKeys() + keys).toList().takeLast(5000).toSet()
        prefs.edit().putString("marketNewsReadKeys", merged.joinToString(";")).apply()
    }

    fun saveDriverMarket(state: DriverMarketState) {
        driverMarketEditor(prefs.edit(), state).apply()
    }

    private fun driverMarketEditor(
        editor: android.content.SharedPreferences.Editor,
        state: DriverMarketState
    ): android.content.SharedPreferences.Editor {
        val s = state.normalized()
        return editor
            .putString("marketContracts", s.contracts.joinToString(";") { listOf(it.driverId,it.teamId,it.years,it.salary,it.marketValue,it.seasonSigned,it.role.name).joinToString(",") })
            .putString("marketFree", s.freeAgents.joinToString(","))
            .putString("marketScheduled", s.scheduled.joinToString(";") { listOf(it.driverId,it.fromTeamId,it.toTeamId,it.startSeason,it.years,it.salary,it.role.name,it.signedSeason,it.replaceDriverId).joinToString(",") })
            .putString("marketRoles", s.rolePreferences.entries.joinToString(",") { "${it.key}:${it.value.name}" })
            .putString("marketPending", s.pending.joinToString(";") { listOf(it.driverId,it.fromTeamId,it.toTeamId,it.years,it.salary,it.role.name,it.marketValue,it.interestScore,it.round,it.expiresAfterWeek,it.status.name,it.seasonTarget,it.replaceDriverId,it.proposerTeamId).joinToString(",") })
            .putString("marketScouting", s.scouting.joinToString(";") { listOf(it.driverId,it.teamId,it.cost,it.createdWeek,it.expiresWeek,it.expectedSalary,it.marketValue,it.rolePreference.name,it.interest,it.season,it.attributeRanges).joinToString(",") })
            .putString("marketNotifications", s.notifications.joinToString(";") { listOf(it.season,it.week,it.title.replace(";", ",").replace("|", "/"),it.message.replace(";", ",").replace("|", "/"),it.important,it.category.name,it.relatedTeamId ?: "").joinToString("|") })
            .putString("marketRenewalEvaluations", s.renewalEvaluations.joinToString(","))
    }

    /** Commit market updates and removal of a durable pending-news outbox together. */
    private fun saveDriverMarketAndClearPendingNews(state: DriverMarketState, pendingKey: String): Boolean =
        driverMarketEditor(prefs.edit(), state).remove(pendingKey).commit()

    /** Stable key for a result; round numbers repeat every season. */
    private fun raceResultKey(seasonNumber: Int, round: Int): String =
        com.f1teammanager.core.manager.RaceResultStoragePolicy.canonicalKey(seasonNumber, round)

    /**
     * A result is committed per season and round. The legacy `race_$round` keys
     * are considered only for season 1 because they contain no season identity and
     * otherwise could incorrectly block the same round in every later season.
     */
    fun isRaceRecorded(round: Int): Boolean {
        if (round !in 1..SeasonCalendar.forSeason(season).size) return false
        return prefs.contains(raceResultKey(season, round)) || (season == 1 && prefs.contains("race_$round"))
    }

    /**
     * V648 recovery policy: an unfinished qualifying/race session is not resumed after
     * process death because the engine's PRNG, partial-lap work queue, incident schedule,
     * tyre/fuel internal precision and pending decision state are not fully represented
     * by the UI snapshot. Startup discards only this unfinished weekend and restarts at
     * qualifying; no championship or cash effects are applied to an incomplete session.
     */
    fun markWeekendSessionStarted(seasonNumber: Int, roundNumber: Int): Boolean {
        if (seasonNumber != season || roundNumber !in 1..SeasonCalendar.forSeason(seasonNumber).size) return false
        val value = JSONObject().put("season", seasonNumber).put("round", roundNumber)
            .put("startedAt", System.currentTimeMillis()).toString()
        return prefs.edit().putString(ACTIVE_WEEKEND_SESSION_KEY, value).commit()
    }

    fun activeWeekendCheckpoint(): ActiveWeekendCheckpoint? {
        val raw = prefs.getString(ACTIVE_WEEKEND_SESSION_KEY, null) ?: return null
        return runCatching {
            val json = JSONObject(raw)
            ActiveWeekendCheckpoint(json.getInt("season"), json.getInt("round"), json.getLong("startedAt"))
                .takeIf { it.season > 0 && it.round in 1..SeasonCalendar.forSeason(it.season).size }
        }.getOrNull()
    }

    fun clearWeekendSessionCheckpoint(seasonNumber: Int? = null, roundNumber: Int? = null): Boolean {
        val current = activeWeekendCheckpoint() ?: return true
        if (seasonNumber != null && current.season != seasonNumber) return true
        if (roundNumber != null && current.round != roundNumber) return true
        return prefs.edit().remove(ACTIVE_WEEKEND_SESSION_KEY).commit()
    }

    private companion object {
        const val ACTIVE_WEEKEND_SESSION_KEY = "active_weekend_session_checkpoint"
    }

    /**
     * Persist the exact completed weekend before applying any career effects. The key is
     * season/round scoped so a stale result can never be attached to a later GP.
     */
    fun savePendingRaceFinalization(seasonNumber: Int, round: Int, totalLaps: Int, result: RaceResult): Boolean {
        if (seasonNumber <= 0 || round !in 1..SeasonCalendar.forSeason(seasonNumber).size || totalLaps <= 0) return false
        return runCatching {
            val root = JSONObject()
                .put("season", seasonNumber)
                .put("round", round)
                .put("totalLaps", totalLaps)
                .put("weather", result.weather.name)
                .put("fastestLapDriverId", result.fastestLapDriverId ?: JSONObject.NULL)
                .put("fastestLapTimeMs", result.fastestLapTimeMs)
                .put("safetyCarLaps", result.safetyCarLaps)
                .put("vscLaps", result.vscLaps)
            val classification = JSONArray()
            result.classification.forEach { entry ->
                classification.put(JSONObject().put("position", entry.position).put("driverId", entry.driverId)
                    .put("driverName", entry.driverName).put("teamName", entry.teamName).put("laps", entry.laps)
                    .put("totalTimeMs", entry.totalTimeMs).put("status", entry.status)
                    .put("tyre", entry.tyre.name).put("pitStops", entry.pitStops))
            }
            root.put("classification", classification)
            val events = JSONArray()
            result.events.forEach { event ->
                events.put(JSONObject().put("lap", event.lap).put("driverId", event.driverId ?: JSONObject.NULL)
                    .put("type", event.type.name).put("detail", event.detail))
            }
            root.put("events", events)
            val points = JSONObject()
            result.points.forEach { (driverId, value) -> points.put(driverId.toString(), value) }
            root.put("points", points)
            val qualifying = result.qualifying
            if (qualifying == null) root.put("qualifying", JSONObject.NULL) else {
                fun entriesJson(entries: List<QualifyingEntry>) = JSONArray().also { array -> entries.forEach { e ->
                    array.put(JSONObject().put("driverId", e.driverId).put("position", e.position).put("lapTimeMs", e.lapTimeMs))
                } }
                val q = JSONObject().put("grid", entriesJson(qualifying.grid))
                val phases = JSONArray()
                qualifying.phases.forEach { phase ->
                    phases.put(JSONObject().put("name", phase.name).put("entries", entriesJson(phase.entries))
                        .put("eliminatedDriverIds", JSONArray().also { ids -> phase.eliminatedDriverIds.forEach { ids.put(it) } }))
                }
                q.put("phases", phases)
                root.put("qualifying", q)
            }
            prefs.edit().putString(pendingRaceKey(seasonNumber, round), root.toString()).commit()
        }.getOrDefault(false)
    }

    fun loadPendingRaceFinalization(seasonNumber: Int, round: Int): PendingRaceFinalization? {
        val raw = prefs.getString(pendingRaceKey(seasonNumber, round), null) ?: return null
        return runCatching {
        val root = JSONObject(raw)
        if (root.getInt("season") != seasonNumber || root.getInt("round") != round) error("Pending race identity mismatch")
        val classification = root.getJSONArray("classification").let { array ->
            (0 until array.length()).map { i -> array.getJSONObject(i).let { item ->
                FinishEntry(item.getInt("position"), item.getInt("driverId"), item.getString("driverName"),
                    item.getString("teamName"), item.getInt("laps"), item.getLong("totalTimeMs"),
                    item.getString("status"), Tyre.valueOf(item.getString("tyre")), item.getInt("pitStops"))
            } }
        }
        val events = root.getJSONArray("events").let { array ->
            (0 until array.length()).map { i -> array.getJSONObject(i).let { item ->
                LapEvent(item.getInt("lap"), if (item.isNull("driverId")) null else item.getInt("driverId"),
                    EventType.valueOf(item.getString("type")), item.getString("detail"))
            } }
        }
        val pointsObject = root.getJSONObject("points")
        val points = pointsObject.keys().asSequence().associate { key -> key.toInt() to pointsObject.getInt(key) }
        val qualifying = if (root.isNull("qualifying")) null else root.getJSONObject("qualifying").let { q ->
            fun parseEntries(array: JSONArray) = (0 until array.length()).map { i -> array.getJSONObject(i).let { e ->
                QualifyingEntry(e.getInt("driverId"), e.getInt("position"), e.getLong("lapTimeMs"))
            } }
            val grid = parseEntries(q.getJSONArray("grid"))
            val phasesJson = q.getJSONArray("phases")
            val phases = (0 until phasesJson.length()).map { i -> phasesJson.getJSONObject(i).let { phase ->
                val eliminated = phase.getJSONArray("eliminatedDriverIds")
                QualifyingPhase(phase.getString("name"), parseEntries(phase.getJSONArray("entries")),
                    (0 until eliminated.length()).map { eliminated.getInt(it) })
            } }
            QualifyingResult(grid, phases)
        }
        val fastest = if (root.isNull("fastestLapDriverId")) null else root.getInt("fastestLapDriverId")
        val result = RaceResult(classification, events, fastest, Weather.valueOf(root.getString("weather")), points,
            root.getInt("safetyCarLaps"), root.getInt("vscLaps"), root.getLong("fastestLapTimeMs"), qualifying)
        PendingRaceFinalization(seasonNumber, round, root.getInt("totalLaps"), result)
        }.getOrNull()
    }

    fun clearPendingRaceFinalization(seasonNumber: Int, round: Int): Boolean =
        prefs.edit().remove(pendingRaceKey(seasonNumber, round)).commit()

    private fun pendingRaceKey(seasonNumber: Int, round: Int) = "pending_race_result_${seasonNumber}_$round"

    /** Durable per-step journal for recovering a GP finalization after process death. */
    private fun raceFinalizationKey(seasonNumber: Int, round: Int, step: String) =
        "race_finalize_${seasonNumber}_${round}_$step"

    fun isRaceFinalizationStepDone(seasonNumber: Int, round: Int, step: String): Boolean =
        prefs.getBoolean(raceFinalizationKey(seasonNumber, round, step), false)

    /**
     * Persist a finalization journal marker synchronously and report whether the
     * commit reached SharedPreferences storage. Callers must not present the GP as
     * finalized when this returns false.
     */
    fun markRaceFinalizationStepDone(seasonNumber: Int, round: Int, step: String): Boolean =
        prefs.edit().putBoolean(raceFinalizationKey(seasonNumber, round, step), true).commit()

    fun isRaceFinalized(seasonNumber: Int, round: Int): Boolean =
        isRaceFinalizationStepDone(seasonNumber, round, "complete")

    fun isRaceResultAcknowledged(seasonNumber: Int, round: Int): Boolean =
        prefs.getBoolean("race_result_acknowledged_${seasonNumber}_$round", false)

    fun markRaceResultAcknowledged(seasonNumber: Int, round: Int): Boolean =
        prefs.edit().putBoolean("race_result_acknowledged_${seasonNumber}_$round", true).commit()

    /**
     * Acknowledge the completed result and advance the calendar in one durable
     * SharedPreferences transaction. This removes the old crash window where the
     * acknowledgement could be saved but roundIndex could remain on the same GP.
     * Repeated calls are safe: a round already passed is acknowledged without
     * advancing the calendar a second time. GP 30 remains on the completed season.
     */
    @Synchronized
    fun acknowledgeRaceAndAdvance(seasonNumber: Int, round: Int): Boolean {
        if (seasonNumber != season) return false
        val totalRounds = SeasonCalendar.forSeason(seasonNumber).size
        if (round !in 1..totalRounds || !isRaceFinalized(seasonNumber, round)) return false

        val currentIndex = roundIndex
        if (currentIndex < round - 1) return false
        val nextIndex = when {
            round == totalRounds -> currentIndex
            currentIndex == round - 1 -> round
            else -> currentIndex
        }
        val editor = prefs.edit()
            .putBoolean("race_result_acknowledged_${seasonNumber}_$round", true)
        if (round < totalRounds && nextIndex != currentIndex) {
            editor.putInt("roundIndex", nextIndex)
        }
        if (!editor.commit()) return false

        // The season archive is normally finalized by recordRace at GP 30. Reconcile
        // it here as a defensive recovery in case a legacy save missed that archive.
        if (round == totalRounds) {
            history.finalizeSeason(seasonNumber, driverPoints(), constructorPoints(), loadDriverMarket())
        }
        return true
    }

    @Synchronized
    fun recordRace(round: Int, result: RaceResult, seasonRound: RoundDefinition? = null, qualifying: QualifyingResult? = null) {
        // V361: the championship transaction and the historical archive are two
        // different storage systems. If the process died after the points transaction
        // committed but before HistoricalDatabase finished, the canonical race marker
        // exists while the archive may be missing the GP. Reconcile the archive on a
        // repeated callback instead of returning before repairing it. HistoricalDatabase
        // replaces the same season/round rows, so this replay is idempotent and does not
        // add championship points a second time.
        if (isRaceRecorded(round)) {
            if (seasonRound != null) {
                val activeMarket = loadDriverMarket()
                history.recordRace(season, seasonRound, result, qualifying, activeMarket)
                if (seasonRound.round == SeasonCalendar.forSeason(season).size) {
                    history.finalizeSeason(season, driverPoints(), constructorPoints(), activeMarket)
                }
            }
            return
        }
        // Capture the championship order BEFORE adding this GP. The standings screen
        // uses this snapshot to show who went up, down or stayed in the same place
        // after each completed race.
        val oldDriverPoints = driverPoints()
        val oldConstructorPoints = constructorPoints()
        val activeIdsForStandings = loadDriverMarket()?.contracts?.filter { it.activeIn(season) }?.map { it.driverId }?.distinct()
            ?: WorldDatabase.drivers.map { it.id }
        val oldDriverOrder = activeIdsForStandings
            .map { it to (oldDriverPoints[it] ?: 0) }
            .sortedWith(compareByDescending<Pair<Int,Int>> { it.second }.thenBy { it.first })
            .mapIndexed { index, row -> row.first to index + 1 }
            .toMap()
        val oldConstructorOrder = WorldDatabase.teams
            .map { it.id to (oldConstructorPoints[it.id] ?: 0) }
            .sortedWith(compareByDescending<Pair<Int,Int>> { it.second }.thenBy { it.first })
            .mapIndexed { index, row -> row.first to index + 1 }
            .toMap()
        val drivers = oldDriverPoints.toMutableMap()
        result.points.forEach { (id, pts) -> drivers[id] = (drivers[id] ?: 0) + pts }
        val teams = oldConstructorPoints.toMutableMap()
        val activeMarket = loadDriverMarket()
        result.classification.forEach { f ->
            val tid = activeMarket?.contracts?.firstOrNull { it.driverId == f.driverId && it.activeIn(season) }?.teamId
                ?: WorldDatabase.teams.firstOrNull { it.name.equals(f.teamName, ignoreCase = true) }?.id
                ?: WorldTeamResolver.teamIdFor(f.driverId)
            teams[tid] = (teams[tid] ?: 0) + (result.points[f.driverId] ?: 0)
        }
        val encoded = result.classification.joinToString(";") { f ->
            val teamId = activeMarket?.contracts?.firstOrNull { it.driverId == f.driverId && it.activeIn(season) }?.teamId
                ?: WorldDatabase.teams.firstOrNull { it.name.equals(f.teamName, ignoreCase = true) }?.id
                ?: WorldTeamResolver.teamIdFor(f.driverId)
            listOf(f.position, f.driverId, f.laps, f.totalTimeMs, f.status.replace(";", ","), f.tyre.name, f.pitStops, result.points[f.driverId] ?: 0, teamId).joinToString(",")
        }
        // V359: standings snapshots, both point tables, and the canonical race
        // result are committed in one SharedPreferences transaction. Previously,
        // each map and the result marker were written independently, so process death
        // could leave points partially applied while the race still looked unrecorded.
        fun encodeIntMap(value: Map<Int, Int>) = value.entries.sortedBy { it.key }
            .joinToString(",") { "${it.key}:${it.value}" }
        val committed = prefs.edit()
            .putString("previousDriverPositions", encodeIntMap(oldDriverOrder))
            .putString("previousConstructorPositions", encodeIntMap(oldConstructorOrder))
            .putString("driverPoints", encodeIntMap(drivers))
            .putString("constructorPoints", encodeIntMap(teams))
            .putString(raceResultKey(season, round), encoded)
            // Retain legacy alias for older readers/imports during the migration window.
            .putString("race_$round", encoded)
            .commit()
        check(committed) { "Não foi possível confirmar atomicamente o resultado e a pontuação do GP $round/temporada $season" }
        if (seasonRound != null) {
            history.recordRace(season, seasonRound, result, qualifying, activeMarket)
            // The season archive is created immediately when GP 30 finishes.
            // Returning to the calendar later must not be required to create history.
            if (seasonRound.round == SeasonCalendar.forSeason(season).size) {
                history.finalizeSeason(season, drivers, teams, activeMarket)
            }
        }
    }

    fun raceHistory(round: Int): RaceResult? = runCatching {
        val raw = prefs.getString(raceResultKey(season, round), null)
            ?: com.f1teammanager.core.manager.RaceResultStoragePolicy.legacyReadKey(season, round)
                ?.let { legacyKey -> prefs.getString(legacyKey, null) }
            ?: return null
        val classification = raw.split(';').filter { it.isNotBlank() }.map { row ->
            val p = row.split(',')
            val id = p[1].toInt()
            val driver = WorldDatabase.drivers.first { it.id == id }
            val teamId = p.getOrNull(8)?.toIntOrNull() ?: driver.teamId
            val team = WorldDatabase.teams.first { it.id == teamId }
            FinishEntryCompat(p[0].toInt(), id, driver.name, team.name, p[2].toInt(), p[3].toLong(), p[4], Tyre.valueOf(p[5]), p[6].toInt())
        }
        val points = raw.split(';').filter { it.isNotBlank() }.associate { row -> val p=row.split(','); p[1].toInt() to p[7].toInt() }
        RaceResult(classification.map { it.toFinish() }, emptyList(), null, com.f1teammanager.core.race.Weather.DRY, points, 0, 0)
    }.getOrNull()

    private data class FinishEntryCompat(val position:Int,val driverId:Int,val driverName:String,val teamName:String,val laps:Int,val totalTimeMs:Long,val status:String,val tyre:Tyre,val pitStops:Int) {
        fun toFinish() = com.f1teammanager.core.race.FinishEntry(position,driverId,driverName,teamName,laps,totalTimeMs,status,tyre,pitStops)
    }

    fun loadCar(forTeamId: Int): TeamCarState? = runCatching {
        if (prefs.getInt("carTeam", -1) != forTeamId) return null
        val rawLoaded = TeamCarState(
            aerodynamics=prefs.getInt("carAero", 70), chassis=prefs.getInt("carChassis",70), engine=prefs.getInt("carEngine",70), reliability=prefs.getInt("carReliability",70),
            frontWing=prefs.getInt("carFrontWing",70), rearWing=prefs.getInt("carRearWing",70), brakes=prefs.getInt("carBrakes",70), electricPowerUnit=prefs.getInt("carErs",70),
            activeProject=if (prefs.getString("projectComponent", null) != null) DevelopmentProject(
                CarComponent.valueOf(prefs.getString("projectComponent", "ENGINE")!!),
                prefs.getInt("projectRemaining", 1), prefs.getInt("projectTotal", 1), prefs.getInt("projectLevel", 1),
                runCatching { DevelopmentIntensity.valueOf(prefs.getString("projectIntensity", "STANDARD")!!) }.getOrDefault(DevelopmentIntensity.STANDARD),
                prefs.getInt("projectGain", 4), prefs.getLong("projectCost", 0L)
            ) else null,
            nextSeasonInvestment=prefs.getLong("nextSeasonInvestment",0L),
            nextSeasonInvestmentBudgetBase=prefs.getLong("nextSeasonInvestmentBudgetBase",0L),
            nextSeasonFocus=runCatching { CarDevelopmentFocus.valueOf(prefs.getString("nextSeasonFocus", "BALANCED")!!) }.getOrDefault(CarDevelopmentFocus.BALANCED),
            developmentKnowledge=loadKnowledge(),
            seasonDevelopmentGain=prefs.getInt("seasonDevelopmentGain",0)
        )
        val performance = listOf(rawLoaded.engine, rawLoaded.chassis, rawLoaded.frontWing, rawLoaded.rearWing, rawLoaded.brakes, rawLoaded.electricPowerUnit)
        val loaded = rawLoaded.normalized()
        if (performance.any { it != 0 }) loaded
        else {
            // V561 incorrectly wrote a zero-performance legacy projection. Recover from
            // the physical garage first (including its own V561 migration), then fall back
            // to the official selected-team profile. Persist once so subsequent readers agree.
            val garage = loadGarage(forTeamId)
            val restored = if (garage != null) {
                fun average(component: CarComponent) = ((garage.car1.componentValue(component) + garage.car2.componentValue(component)) / 2.0).toInt()
                loaded.copy(
                    aerodynamics = (average(CarComponent.FRONT_WING) + average(CarComponent.REAR_WING)) / 2,
                    engine = average(CarComponent.ENGINE), chassis = average(CarComponent.CHASSIS),
                    frontWing = average(CarComponent.FRONT_WING), rearWing = average(CarComponent.REAR_WING),
                    brakes = average(CarComponent.BRAKES), electricPowerUnit = average(CarComponent.ELECTRIC_POWER_UNIT),
                    reliability = ((garage.car1.reliability + garage.car2.reliability) / 2).coerceIn(40,100)
                ).normalized()
            } else {
                WorldDatabase.teams.firstOrNull { it.id == forTeamId }?.let { InitialTeamProfile.carState(it) } ?: loaded
            }
            if (restored !== loaded) saveCar(forTeamId, restored)
            restored
        }
    }.getOrNull()

    /** V270: persist annual-event car stats per team without overwriting the player's single-car save slot. */
    fun loadAnnualEventCarStats(forTeamId: Int, fallback: TeamCarState): TeamCarState {
        val raw = prefs.getString("annualEventCarStats_$forTeamId", null) ?: return fallback
        val a = raw.split(',').mapNotNull { it.toIntOrNull() }
        if (a.size != 8) return fallback
        return fallback.copy(engine=a[0], chassis=a[1], frontWing=a[2], rearWing=a[3], brakes=a[4], electricPowerUnit=a[5], reliability=a[6], aerodynamics=a[7]).normalized()
    }

    fun saveAnnualEventCarStats(forTeamId: Int, car: TeamCarState) {
        val normalized = car.normalized()
        prefs.edit().putString("annualEventCarStats_$forTeamId", listOf(normalized.engine,normalized.chassis,normalized.frontWing,normalized.rearWing,normalized.brakes,normalized.electricPowerUnit,normalized.reliability,normalized.aerodynamics).joinToString(",")).commit()
    }

    private fun carEditor(forTeamId: Int, car: TeamCarState): android.content.SharedPreferences.Editor =
        carEditor(prefs.edit(), forTeamId, car)

    private fun carEditor(editor: android.content.SharedPreferences.Editor, forTeamId: Int, source: TeamCarState): android.content.SharedPreferences.Editor {
        val car = source.normalized()
        val e = editor.putInt("carTeam", forTeamId)
            .putInt("carAero", car.aerodynamics).putInt("carChassis", car.chassis)
            .putInt("carEngine", car.engine).putInt("carReliability", car.reliability)
            .putInt("carFrontWing", car.frontWing).putInt("carRearWing", car.rearWing)
            .putInt("carBrakes", car.brakes).putInt("carErs", car.electricPowerUnit)
        if (car.activeProject == null) {
            e.remove("projectComponent").remove("projectRemaining").remove("projectTotal")
                .remove("projectLevel").remove("projectIntensity").remove("projectGain").remove("projectCost")
        } else car.activeProject.let {
            e.putString("projectComponent", it.component.name).putInt("projectRemaining", it.remainingWeeks)
                .putInt("projectTotal", it.totalWeeks).putInt("projectLevel", it.level)
                .putString("projectIntensity", it.intensity.name).putInt("projectGain", it.expectedGain)
                .putLong("projectCost", it.cost)
        }
        return e.putLong("nextSeasonInvestment", car.nextSeasonInvestment)
            .putLong("nextSeasonInvestmentBudgetBase", car.nextSeasonInvestmentBudgetBase)
            .putString("nextSeasonFocus", car.nextSeasonFocus.name)
            .putString("developmentKnowledge", car.developmentKnowledge.entries.joinToString(",") { "${it.key.name}:${it.value}" })
            .putInt("seasonDevelopmentGain", car.seasonDevelopmentGain)
    }

    fun saveCar(forTeamId: Int, car: TeamCarState) {
        carEditor(forTeamId, car).apply()
    }

    /**
     * Atomically persists a next-season investment together with its debit.
     * A process death must never leave the car investment saved without the
     * corresponding finance transaction (or vice versa).
     */
    fun saveCarAndFinance(forTeamId: Int, car: TeamCarState, finance: TeamFinanceState): Boolean {
        val savedCar = car.normalized()
        val combined = prefs.edit()
            .putInt("carTeam", forTeamId).putInt("carAero", savedCar.aerodynamics)
            .putInt("carChassis", savedCar.chassis).putInt("carEngine", savedCar.engine)
            .putInt("carReliability", savedCar.reliability).putInt("carFrontWing", savedCar.frontWing)
            .putInt("carRearWing", savedCar.rearWing).putInt("carBrakes", savedCar.brakes).putInt("carErs", savedCar.electricPowerUnit)
            .putLong("nextSeasonInvestment", savedCar.nextSeasonInvestment)
            .putLong("nextSeasonInvestmentBudgetBase", savedCar.nextSeasonInvestmentBudgetBase)
            .putString("nextSeasonFocus", savedCar.nextSeasonFocus.name)
            .putString("developmentKnowledge", savedCar.developmentKnowledge.entries.joinToString(",") { "${it.key.name}:${it.value}" })
            .putInt("seasonDevelopmentGain", savedCar.seasonDevelopmentGain)
        if (savedCar.activeProject == null) {
            combined.remove("projectComponent").remove("projectRemaining").remove("projectTotal")
                .remove("projectLevel").remove("projectIntensity").remove("projectGain").remove("projectCost")
        } else savedCar.activeProject.let { project ->
            combined.putString("projectComponent", project.component.name)
                .putInt("projectRemaining", project.remainingWeeks).putInt("projectTotal", project.totalWeeks)
                .putInt("projectLevel", project.level).putString("projectIntensity", project.intensity.name)
                .putInt("projectGain", project.expectedGain).putLong("projectCost", project.cost)
        }
        combined.putInt("financeTeam", forTeamId).putLong("budget", finance.budget)
            .putLong("seasonIncome", finance.seasonIncome).putLong("seasonExpenses", finance.seasonExpenses)
            .putLong("raceIncome", finance.raceIncome).putLong("raceExpenses", finance.raceExpenses)
            .putString("seasonPrizesPaid", finance.seasonPrizesPaid.sorted().joinToString(","))
            .putString("financeTransactions", finance.transactions.takeLast(20000).joinToString("\n"))
            .putString("signatureFeeSchedules", finance.signatureFeeSchedules.joinToString(";") { sch ->
                listOf(java.util.Base64.getUrlEncoder().withoutPadding().encodeToString(sch.id.toByteArray(Charsets.UTF_8)), sch.amount, sch.season, sch.recognizedRounds.sorted().joinToString(","), sch.startRound, sch.installmentCount, sch.paidRounds.sorted().joinToString(",")).joinToString(":")
            })
            .putString("salaryPaidRounds", finance.salaryPaidRounds.sorted().joinToString(","))
            .putString("salaryOutstanding", finance.salaryOutstanding.entries.sortedBy { it.key }.joinToString(",") { "${it.key.substringBefore(":")}:${it.key.substringAfter(":")}:${it.value}" })
            .putString("raceSettlementKeys", finance.raceSettlementKeys.sorted().joinToString(","))
            .putString("facilityMaintenanceWeeks", finance.facilityMaintenanceWeeks.sorted().joinToString(","))
            .putString("facilityMaintenanceOutstanding", finance.facilityMaintenanceOutstanding.entries.sortedBy { it.key }.joinToString(",") { "${it.key.substringBefore(":")}:${it.key.substringAfter(":")}:${it.value}" })
            .putString("commercialRevenueWeeks", finance.commercialRevenueWeeks.sorted().joinToString(","))
        return combined.commit()
    }



    private fun loadKnowledge(): Map<CarComponent,Int> = prefs.getString("developmentKnowledge", "").orEmpty().split(',').mapNotNull { token ->
        val p=token.split(':')
        if (p.size==2) runCatching { CarComponent.valueOf(p[0]) to p[1].toInt().coerceIn(0,8) }.getOrNull() else null
    }.toMap()

    fun loadResearch(forTeamId: Int): TeamResearchState? = runCatching {
        if (prefs.getInt("researchTeam", -1) != forTeamId) return null
        val activeRows = prefs.getString("researchActiveProjects", "").orEmpty().split(";").filter { it.isNotBlank() }
        val projects = activeRows.mapNotNull { row ->
            val p=row.split("|")
            if (p.size < 13) null else runCatching {
                ResearchProject(p[0],CarComponent.valueOf(p[1]),p[2].toInt(),p[3].toInt(),p[4].toInt(),p[5].toInt(),p[6].toInt(),p[7].toInt(),p[8].toInt(),p[9].toLong(),p[10].toInt(),ResearchFocus.valueOf(p[11]),ResearchComplexity.valueOf(p[12]),p.getOrNull(13)?.let(ResearchOutcome::valueOf) ?: ResearchOutcome.SUCCESS)
            }.getOrNull()
        }
        val legacy = if (projects.isEmpty()) prefs.getString("researchActive", null)?.split("|")?.takeIf { it.size >= 11 }?.let { p ->
            runCatching { ResearchProject(p[0],CarComponent.valueOf(p[1]),p[2].toInt(),p[3].toInt(),p[3].toInt(),p[4].toInt(),p[4].toInt(),p[6].toInt(),p[7].toInt(),p[8].toLong(),p[9].toInt(),ResearchFocus.PERFORMANCE,ResearchComplexity.MEDIUM) }.getOrNull()
        } else null
        val designs = prefs.getString("researchDesigns", "").orEmpty().split(";").filter { it.isNotBlank() }.mapNotNull { row ->
            val p=row.split("|"); if (p.size < 7) null else runCatching { ResearchDesign(p[0],CarComponent.valueOf(p[1]),p[2].toInt(),p[3].toInt(),p[4].toInt(),p[5].toInt(),p[6].toInt()) }.getOrNull()
        }
        val cooldowns = prefs.getString("researchCooldowns", "").orEmpty().split(",").filter { it.isNotBlank() }.mapNotNull { token ->
            val p=token.split(":"); if (p.size != 2) null else runCatching { CarComponent.valueOf(p[0]) to p[1].toInt() }.getOrNull()
        }.toMap()
        TeamResearchState((projects + listOfNotNull(legacy)).distinctBy { it.projectId }, designs, cooldowns).normalized()
    }.getOrNull()

    private fun researchEditor(e: android.content.SharedPreferences.Editor, forTeamId: Int, source: TeamResearchState): android.content.SharedPreferences.Editor {
        val research = source.normalized()
        e.putInt("researchTeam", forTeamId)
        if (research.activeProjects.isEmpty()) e.remove("researchActiveProjects")
        else e.putString("researchActiveProjects", research.activeProjects.joinToString(";") { p ->
            listOf(p.projectId,p.component.name,p.version,p.basePerformance,p.baseReliability,p.targetPerformance,p.targetReliability,p.totalWeeks,p.remainingWeeks,p.cost,p.startedWeek,p.focus.name,p.complexity.name,p.outcome.name).joinToString("|")
        })
        e.remove("researchActive")
        e.putString("researchDesigns", research.completedDesigns.joinToString(";") { d ->
            listOf(d.designId,d.component.name,d.version,d.performance,d.reliability,d.researchSeason,d.completedWeek).joinToString("|")
        })
        return e.putString("researchCooldowns", research.cooldownUntil.entries.joinToString(",") { "${it.key.name}:${it.value}" })
    }

    fun saveResearch(forTeamId: Int, research: TeamResearchState) {
        researchEditor(prefs.edit(), forTeamId, research.normalized()).apply()
    }

    fun loadFactory(forTeamId: Int): TeamFactoryState? = runCatching {
        if (prefs.getInt("factoryTeam", -1) != forTeamId) return null
        val orders = prefs.getString("factoryOrders", "").orEmpty().split(";").filter { it.isNotBlank() }.mapNotNull { row ->
            val p=row.split("|")
            if (p.size < 12) null else runCatching {
                FactoryOrder(p[0],p[1],CarComponent.valueOf(p[2]),p[3].toInt(),p[4].toInt(),p[5].toInt(),p[6].toInt(),p[7].toInt(),p[8].toInt(),p[9].toInt(),p[10].toLong(),p[11].toInt())
            }.getOrNull()
        }
        val pending = prefs.getString("factoryPendingInstallations", "").orEmpty().split(";").filter { it.isNotBlank() }.mapNotNull { row ->
            val p=row.split("|")
            if (p.size < 6) null else runCatching {
                CarPiece(p[0], CarComponent.valueOf(p[1]), p[2].toInt(), p[3].toInt(), p[4].toInt(), p[5].toInt(), p.getOrNull(6)?.toIntOrNull() ?: 0)
            }.getOrNull()
        }
        TeamFactoryState(orders, pending).normalized()
    }.getOrNull()

    private fun factoryEditor(e: android.content.SharedPreferences.Editor, forTeamId: Int, source: TeamFactoryState): android.content.SharedPreferences.Editor {
        val factory = source.normalized()
        return e.putInt("factoryTeam",forTeamId)
            .putString("factoryOrders", factory.activeOrders.joinToString(";") { o -> listOf(o.orderId,o.designId,o.component.name,o.version,o.performance,o.reliability,o.quantity,o.remainingUnits,o.totalWeeks,o.remainingWeeks,o.costPerUnit,o.startedWeek).joinToString("|") })
            .putString("factoryPendingInstallations", factory.pendingInstallations.joinToString(";") { p -> listOf(p.pieceId,p.component.name,p.version,p.performance,p.reliability,p.manufacturedWeek,p.manufacturedSeason).joinToString("|") })
    }

    fun saveFactory(forTeamId: Int, factory: TeamFactoryState) {
        factoryEditor(prefs.edit(), forTeamId, factory.normalized()).apply()
    }

    fun loadGarage(forTeamId: Int): TeamGarage? = runCatching {
        if (prefs.getInt("garageTeam", -1) != forTeamId) return null
        fun loadComponentReliabilities(prefix: String, fallback: Int): Map<CarComponent, Int> = CarComponent.values().associateWith { c -> prefs.getInt("${prefix}Rel_${c.name}", fallback).coerceIn(40,100) }
        fun loadCar(id: GarageCarId): PhysicalCar {
            val prefix = if (id == GarageCarId.CAR_1) "g1" else "g2"
            val parsedInstalled = prefs.getString("${prefix}Installed", "").orEmpty().split(",").filter { it.isNotBlank() }.mapNotNull { token ->
                val p=token.split(":", limit=2)
                if (p.size != 2) null else runCatching { CarComponent.valueOf(p[0]) to p[1] }.getOrNull()
            }.toMap().toMutableMap()
            val performance = mapOf(
                CarComponent.ENGINE to prefs.getInt("${prefix}Engine",0),
                CarComponent.CHASSIS to prefs.getInt("${prefix}Chassis",0),
                CarComponent.FRONT_WING to prefs.getInt("${prefix}FrontWing",0),
                CarComponent.REAR_WING to prefs.getInt("${prefix}RearWing",0),
                CarComponent.BRAKES to prefs.getInt("${prefix}Brakes",0),
                CarComponent.ELECTRIC_POWER_UNIT to prefs.getInt("${prefix}Electric",0)
            )
            // Legacy saves could persist numeric performance before the physical-piece
            // ledger existed. Preserve that career progress but explicitly mark each such
            // component as a migrated legacy baseline, not as a newly researched piece.
            performance.forEach { (component, value) ->
                if (value > 0 && component !in parsedInstalled) {
                    parsedInstalled[component] = "LEGACY-MIGRATED-${forTeamId}-${id.name}-${component.name}"
                }
            }
            val installed = parsedInstalled.toMap()
            val installedVersions = installed.keys.associateWith { c ->
                val versionKey = "${prefix}Version_${c.name}"
                // V0 is a valid new-season baseline for a real installed component.
                // A key that predates version tracking still defaults to legacy V1.
                if (prefs.contains(versionKey)) prefs.getInt(versionKey, 1).coerceAtLeast(0) else 1
            }
            return PhysicalCar(
                id=id, engine=performance.getValue(CarComponent.ENGINE), chassis=performance.getValue(CarComponent.CHASSIS),
                frontWing=performance.getValue(CarComponent.FRONT_WING), rearWing=performance.getValue(CarComponent.REAR_WING),
                brakes=performance.getValue(CarComponent.BRAKES), electricPowerUnit=performance.getValue(CarComponent.ELECTRIC_POWER_UNIT),
                reliability=prefs.getInt("${prefix}Reliability",100).coerceIn(40,100),
                componentReliabilities=loadComponentReliabilities(prefix, prefs.getInt("${prefix}Reliability",100)),
                installedPieces=installed, installedPieceVersions=installedVersions
            )
        }
        val loaded = TeamGarage(loadCar(GarageCarId.CAR_1),loadCar(GarageCarId.CAR_2))
        fun values(car: PhysicalCar) = listOf(car.engine, car.chassis, car.frontWing, car.rearWing, car.brakes, car.electricPowerUnit)
        fun untouchedLegacyStarter(car: PhysicalCar): Boolean =
            car.installedPieces.isNotEmpty() &&
                car.installedPieces.values.all { it.startsWith("INIT-") } &&
                car.installedPieceVersions.values.all { it <= 1 } &&
                values(car).all { it in 40..60 }
        fun moveStarterToV0(car: PhysicalCar): PhysicalCar {
            val installed = CarComponent.values().associateWith { component ->
                "INITIAL-PLAYER-V0-MIGRATED-${forTeamId}-${car.id.name}-${component.name}"
            }
            return car.copy(installedPieces = installed, installedPieceVersions = installed.keys.associateWith { 0 })
        }
        val migratedRaw = when {
            // V561 mistakenly persisted a blank (all-zero) player garage. Restore the
            // canonical team profile while assigning baseline piece version V0.
            values(loaded.car1).all { it == 0 } && values(loaded.car2).all { it == 0 } &&
                loaded.car1.installedPieces.isEmpty() && loaded.car2.installedPieces.isEmpty() -> {
                val team = WorldDatabase.teams.firstOrNull { it.id == forTeamId }
                team?.let { TeamGarageFactory.fromInitial(it, playerCareer = true) } ?: loaded
            }
            // Older starter saves had synthetic INIT-* parts at V1. Keep their opening
            // performance, but correct the base component version to V0.
            untouchedLegacyStarter(loaded.car1) && untouchedLegacyStarter(loaded.car2) ->
                TeamGarage(moveStarterToV0(loaded.car1), moveStarterToV0(loaded.car2))
            else -> loaded
        }
        val migrated = migratedRaw.normalized()
        if (migrated != loaded) saveGarage(forTeamId, migrated)
        migrated
    }.getOrNull()

    private fun garageEditor(e: android.content.SharedPreferences.Editor, forTeamId: Int, source: TeamGarage): android.content.SharedPreferences.Editor {
        val garage = source.normalized()
        fun putCar(source: PhysicalCar, prefix: String) {
            val car = source.normalized()
            // Rebuild keys exactly from the snapshot so removed pieces cannot leave stale V/rel metadata.
            CarComponent.values().forEach { c -> e.remove("${prefix}Version_${c.name}").remove("${prefix}Rel_${c.name}") }
            e.putInt("${prefix}Engine",car.engine.coerceIn(40,100)).putInt("${prefix}Chassis",car.chassis.coerceIn(40,100))
                .putInt("${prefix}FrontWing",car.frontWing.coerceIn(40,100)).putInt("${prefix}RearWing",car.rearWing.coerceIn(40,100))
                .putInt("${prefix}Brakes",car.brakes.coerceIn(40,100)).putInt("${prefix}Electric",car.electricPowerUnit.coerceIn(40,100))
                .putInt("${prefix}Reliability",car.reliability.coerceIn(40,100))
            car.componentReliabilities.forEach { (c,v) -> e.putInt("${prefix}Rel_${c.name}",v.coerceIn(40,100)) }
            car.installedPieces.keys.forEach { c ->
                // Persist V0 after season reset; installed-piece version zero is intentional.
                e.putInt("${prefix}Version_${c.name}", (car.installedPieceVersions[c] ?: 1).coerceAtLeast(0))
            }
            e.putString("${prefix}Installed",car.installedPieces.entries.joinToString(",") { "${it.key.name}:${it.value}" })
        }
        e.putInt("garageTeam",forTeamId)
        putCar(garage.car1,"g1"); putCar(garage.car2,"g2")
        return e
    }

    fun saveGarage(forTeamId: Int, garage: TeamGarage) {
        garageEditor(prefs.edit(), forTeamId, garage.normalized()).apply()
    }

    private fun technicalInvestmentEditor(e: android.content.SharedPreferences.Editor, forTeamId: Int, state: com.f1teammanager.core.manager.TechnicalInvestmentState): android.content.SharedPreferences.Editor =
        e.putString("technicalInvestment_$forTeamId", listOf(state.season, state.ranking, state.level, state.annualCap,
            state.researchDesignSpent, state.fabricationSpent, state.facilityUpgradeSpent).joinToString(","))

    /**
     * Atomically commits the P&D -> design -> factory -> physical garage and its financial
     * changes in one SharedPreferences transaction. The pending-piece queue and installed
     * garage snapshot can no longer be saved on opposite sides of a process interruption.
     */
    fun saveEngineeringBundle(
        forTeamId: Int,
        research: TeamResearchState,
        factory: TeamFactoryState,
        technicalInvestment: com.f1teammanager.core.manager.TechnicalInvestmentState,
        garage: TeamGarage,
        finance: TeamFinanceState,
        legacyCar: TeamCarState? = null
    ): Boolean {
        val e = prefs.edit()
        if (legacyCar != null) carEditor(e, forTeamId, legacyCar)
        researchEditor(e, forTeamId, research)
        factoryEditor(e, forTeamId, factory)
        technicalInvestmentEditor(e, forTeamId, technicalInvestment)
        garageEditor(e, forTeamId, garage)
        financeEditor(e, forTeamId, finance)
        return e.commit()
    }

    /**
     * Initializes all player-facing career systems in a single durable commit.
     * This prevents a new career from mixing its blank garage with old factory orders,
     * facility levels, active projects, or finance ledgers if the process is interrupted.
     */
    private fun saveFreshCareerCore(
        forTeamId: Int,
        car: TeamCarState,
        garage: TeamGarage,
        research: TeamResearchState,
        factory: TeamFactoryState,
        technicalInvestment: com.f1teammanager.core.manager.TechnicalInvestmentState,
        finance: TeamFinanceState,
        facilities: TeamFacilitiesState,
        driverDevelopment: com.f1teammanager.core.manager.DriverDevelopmentState,
        sponsors: List<SponsorContract>,
        market: DriverMarketState
    ): Boolean {
        val e = prefs.edit()
        carEditor(e, forTeamId, car)
        garageEditor(e, forTeamId, garage)
        researchEditor(e, forTeamId, research)
        factoryEditor(e, forTeamId, factory)
        technicalInvestmentEditor(e, forTeamId, technicalInvestment)
        financeEditor(e, forTeamId, finance)
        e.putInt("facilitiesTeam", forTeamId)
            .putString("facilities", facilities.levels.entries.sortedBy { it.key.ordinal }
                .joinToString(",") { "${it.key.name}:${it.value.coerceIn(0,10)}" })
        val development = driverDevelopment.normalized()
        e.putInt("driverDevelopmentTeam", forTeamId)
            .putString("driverDevelopmentPrograms", development.programs.joinToString(";") {
                listOf(it.driverId,it.startedWeek,it.totalWeeks,it.remainingWeeks,it.points).joinToString("|")
            })
            .putString("driverDevelopmentReserve", development.reservePoints.entries.sortedBy { it.key }
                .joinToString(";") { "${it.key}:${it.value}" })
        sponsorEditor(e, forTeamId, sponsors)
        driverMarketEditor(e, market)
        val normalizedCar = car.normalized()
        e.putString("annualEventCarStats_$forTeamId", listOf(
            normalizedCar.engine, normalizedCar.chassis, normalizedCar.frontWing, normalizedCar.rearWing, normalizedCar.brakes,
            normalizedCar.electricPowerUnit, normalizedCar.reliability, normalizedCar.aerodynamics
        ).joinToString(","))
        e.remove("facilityUpgrade_$forTeamId").remove("marketNewsReadKeys")
        return e.commit()
    }

    /** Atomic persistence for ordinary week advancement and facility transactions. */
    fun saveCareerStepBundle(
        forTeamId: Int,
        car: TeamCarState,
        garage: TeamGarage,
        research: TeamResearchState,
        factory: TeamFactoryState,
        technicalInvestment: com.f1teammanager.core.manager.TechnicalInvestmentState,
        finance: TeamFinanceState,
        facilities: TeamFacilitiesState,
        driverDevelopment: com.f1teammanager.core.manager.DriverDevelopmentState,
        driverMarket: DriverMarketState,
        sponsors: List<SponsorContract>,
        facilityUpgrade: FacilityUpgradeState?
    ): Boolean {
        val e = prefs.edit()
        carEditor(e, forTeamId, car)
        garageEditor(e, forTeamId, garage)
        researchEditor(e, forTeamId, research)
        factoryEditor(e, forTeamId, factory)
        technicalInvestmentEditor(e, forTeamId, technicalInvestment)
        financeEditor(e, forTeamId, finance)
        e.putInt("facilitiesTeam", forTeamId)
            .putString("facilities", facilities.levels.entries.sortedBy { it.key.ordinal }
                .joinToString(",") { "${it.key.name}:${it.value.coerceIn(0,10)}" })
        val development = driverDevelopment.normalized()
        e.putInt("driverDevelopmentTeam", forTeamId)
            .putString("driverDevelopmentPrograms", development.programs.joinToString(";") {
                listOf(it.driverId,it.startedWeek,it.totalWeeks,it.remainingWeeks,it.points).joinToString("|")
            })
            .putString("driverDevelopmentReserve", development.reservePoints.entries.sortedBy { it.key }
                .joinToString(";") { "${it.key}:${it.value}" })
        driverMarketEditor(e, driverMarket)
        sponsorEditor(e, forTeamId, sponsors)
        if (facilityUpgrade == null) e.remove("facilityUpgrade_$forTeamId")
        else e.putString("facilityUpgrade_$forTeamId", listOf(
            facilityUpgrade.facility.name, facilityUpgrade.previousLevel, facilityUpgrade.targetLevel,
            facilityUpgrade.remainingWeeks, facilityUpgrade.totalWeeks, facilityUpgrade.cost,
            facilityUpgrade.startedSeason, facilityUpgrade.startedWeek
        ).joinToString("|"))
        return e.commit()
    }

    fun loadFacilities(forTeamId:Int): TeamFacilitiesState? = runCatching {
        if (prefs.getInt("facilitiesTeam", -1) != forTeamId) return null
        val raw = prefs.getString("facilities", "").orEmpty()
        val levels = raw.split(",").filter { it.isNotBlank() }.mapNotNull { token ->
            val p = token.split(":")
            if (p.size != 2) null else runCatching { FacilityType.valueOf(p[0]) to p[1].toInt().coerceIn(0,10) }.getOrNull()
        }.toMap()
        TeamFacilitiesState(FacilityType.values().associateWith { levels[it] ?: 0 })
    }.getOrNull()

    fun saveFacilities(forTeamId:Int, facilities:TeamFacilitiesState) {
        prefs.edit().putInt("facilitiesTeam",forTeamId)
            .putString("facilities", facilities.levels.entries.sortedBy { it.key.ordinal }.joinToString(",") { "${it.key.name}:${it.value.coerceIn(0,10)}" })
            .apply()
    }

    fun loadFacilityUpgrade(forTeamId: Int): FacilityUpgradeState? = runCatching {
        val raw = prefs.getString("facilityUpgrade_$forTeamId", null) ?: return null
        val p = raw.split("|")
        if (p.size != 8) return null
        FacilityUpgradeState(FacilityType.valueOf(p[0]), p[1].toInt(), p[2].toInt(), p[3].toInt(), p[4].toInt(), p[5].toLong(), p[6].toInt(), p[7].toInt())
    }.getOrNull()

    fun saveFacilityUpgrade(forTeamId: Int, upgrade: FacilityUpgradeState?) {
        val editor = prefs.edit()
        if (upgrade == null) editor.remove("facilityUpgrade_$forTeamId")
        else editor.putString("facilityUpgrade_$forTeamId", listOf(upgrade.facility.name, upgrade.previousLevel, upgrade.targetLevel, upgrade.remainingWeeks, upgrade.totalWeeks, upgrade.cost, upgrade.startedSeason, upgrade.startedWeek).joinToString("|"))
        editor.apply()
    }

    fun loadTechnicalInvestment(forTeamId:Int): com.f1teammanager.core.manager.TechnicalInvestmentState? = runCatching {
        val raw = prefs.getString("technicalInvestment_$forTeamId", null) ?: return null
        val p = raw.split(",")
        if (p.size < 7) return null
        com.f1teammanager.core.manager.TechnicalInvestmentState(
            season = p[0].toInt(),
            ranking = p[1].toInt(),
            level = p[2].toInt(),
            // Non-destructive migration from legacy rank-dependent annual caps.
            annualCap = com.f1teammanager.core.manager.TechnicalInvestmentEngine.ANNUAL_TECHNICAL_CAP,
            researchDesignSpent = p[4].toLong(),
            fabricationSpent = p[5].toLong(),
            facilityUpgradeSpent = p[6].toLong()
        )
    }.getOrNull()

    fun saveTechnicalInvestment(forTeamId:Int, state: com.f1teammanager.core.manager.TechnicalInvestmentState) {
        technicalInvestmentEditor(prefs.edit(), forTeamId, state).apply()
    }

    fun loadDriverDevelopment(forTeamId:Int): com.f1teammanager.core.manager.DriverDevelopmentState = runCatching {
        if (prefs.getInt("driverDevelopmentTeam", -1) != forTeamId) return com.f1teammanager.core.manager.DriverDevelopmentState()
        val programs = prefs.getString("driverDevelopmentPrograms", "").orEmpty().split(";").filter { it.isNotBlank() }.mapNotNull { row ->
            val p = row.split("|")
            if (p.size < 5) null else runCatching {
                com.f1teammanager.core.manager.DriverDevelopmentProgram(p[0].toInt(), p[1].toInt(), p[2].toInt(), p[3].toInt(), p[4].toInt())
            }.getOrNull()
        }
        val reserve = prefs.getString("driverDevelopmentReserve", "").orEmpty().split(";").filter { it.isNotBlank() }.mapNotNull { row ->
            val p = row.split(":")
            if (p.size != 2) null else runCatching { p[0].toInt() to p[1].toInt().coerceAtLeast(0) }.getOrNull()
        }.toMap()
        com.f1teammanager.core.manager.DriverDevelopmentState(programs, reserve).normalized()
    }.getOrDefault(com.f1teammanager.core.manager.DriverDevelopmentState())

    fun saveDriverDevelopment(forTeamId:Int, state:com.f1teammanager.core.manager.DriverDevelopmentState) {
        val normalized = state.normalized()
        prefs.edit().putInt("driverDevelopmentTeam",forTeamId)
            .putString("driverDevelopmentPrograms", normalized.programs.joinToString(";") { listOf(it.driverId,it.startedWeek,it.totalWeeks,it.remainingWeeks,it.points).joinToString("|") })
            .putString("driverDevelopmentReserve", normalized.reservePoints.entries.sortedBy { it.key }.joinToString(";") { "${it.key}:${it.value}" })
            .apply()
    }

    fun getInt(key:String, fallback:Int): Int = prefs.getInt(key,fallback)
    fun putInt(key:String, value:Int) { prefs.edit().putInt(key,value).apply() }

    fun loadFinance(forTeamId:Int, fallback:TeamFinanceState): TeamFinanceState {
        if (prefs.getInt("financeTeam", -1) != forTeamId) return fallback
        return TeamFinanceState(
            budget=prefs.getLong("budget", fallback.budget),
            seasonIncome=prefs.getLong("seasonIncome", fallback.seasonIncome),
            seasonExpenses=prefs.getLong("seasonExpenses", fallback.seasonExpenses),
            raceIncome=prefs.getLong("raceIncome", fallback.raceIncome),
            raceExpenses=prefs.getLong("raceExpenses", fallback.raceExpenses),
            transactions=prefs.getString("financeTransactions", "").orEmpty().split("\n").filter { it.isNotBlank() }.takeLast(20000),
            seasonPrizesPaid=prefs.getString("seasonPrizesPaid", "").orEmpty().split(",").mapNotNull { it.toIntOrNull() }.toSet(),
            signatureFeeSchedules=prefs.getString("signatureFeeSchedules", "").orEmpty().split(";").filter { it.isNotBlank() }.mapNotNull { row ->
                val q=row.split(":", limit=7)
                if (q.size < 4) null else runCatching { SignatureFeeSchedule(String(java.util.Base64.getUrlDecoder().decode(q[0]), Charsets.UTF_8), q[1].toLong(), q[2].toInt(), q[3].split(",").mapNotNull { it.toIntOrNull() }.toSet(), q.getOrNull(4)?.toIntOrNull() ?: 1, q.getOrNull(5)?.toIntOrNull() ?: 30, if (q.size >= 7) q[6].split(",").mapNotNull { it.toIntOrNull() }.toSet() else (1..30).toSet()) }.getOrNull()
            },
            salaryPaidRounds=prefs.getString("salaryPaidRounds", "").orEmpty().split(",").filter { it.matches(Regex("20\\d{2}:\\d{1,2}")) }.toSet(),
            salaryOutstanding=prefs.getString("salaryOutstanding", "").orEmpty().split(",").filter { it.isNotBlank() }.mapNotNull { token -> val q=token.split(":"); if(q.size==3) runCatching { (q[0]+":"+q[1]) to q[2].toLong() }.getOrNull() else null }.toMap(),
            raceSettlementKeys=prefs.getString("raceSettlementKeys", "").orEmpty().split(",").filter { it.isNotBlank() }.toSet(),
            facilityMaintenanceWeeks=prefs.getString("facilityMaintenanceWeeks", "").orEmpty().split(",").filter { it.matches(Regex("20\\d{2}:\\d{1,2}")) }.toSet(),
            facilityMaintenanceOutstanding=prefs.getString("facilityMaintenanceOutstanding", "").orEmpty().split(",").filter { it.isNotBlank() }.mapNotNull { token -> val q=token.split(":"); if(q.size==3) runCatching { (q[0]+":"+q[1]) to q[2].toLong() }.getOrNull() else null }.toMap(),
            commercialRevenueWeeks=prefs.getString("commercialRevenueWeeks", "").orEmpty().split(",").filter { it.matches(Regex("20\\d{2}:\\d{1,2}")) }.toSet()
        )
    }
    private fun financeEditor(forTeamId:Int, finance:TeamFinanceState): android.content.SharedPreferences.Editor =
        financeEditor(prefs.edit(), forTeamId, finance)

    private fun financeEditor(editor: android.content.SharedPreferences.Editor, forTeamId:Int, finance:TeamFinanceState): android.content.SharedPreferences.Editor =
        editor.putInt("financeTeam",forTeamId).putLong("budget",finance.budget).putLong("seasonIncome",finance.seasonIncome).putLong("seasonExpenses",finance.seasonExpenses).putLong("raceIncome",finance.raceIncome).putLong("raceExpenses",finance.raceExpenses)
            .putString("seasonPrizesPaid", finance.seasonPrizesPaid.sorted().joinToString(","))
            .putString("financeTransactions", finance.transactions.takeLast(20000).joinToString("\n"))
            .putString("signatureFeeSchedules", finance.signatureFeeSchedules.joinToString(";") { sch -> listOf(java.util.Base64.getUrlEncoder().withoutPadding().encodeToString(sch.id.toByteArray(Charsets.UTF_8)), sch.amount, sch.season, sch.recognizedRounds.sorted().joinToString(","), sch.startRound, sch.installmentCount, sch.paidRounds.sorted().joinToString(",")).joinToString(":") })
            .putString("salaryPaidRounds", finance.salaryPaidRounds.sorted().joinToString(","))
            .putString("salaryOutstanding", finance.salaryOutstanding.entries.sortedBy { it.key }.joinToString(",") { "${it.key.substringBefore(":")}:${it.key.substringAfter(":")}:${it.value}" })
            .putString("raceSettlementKeys", finance.raceSettlementKeys.sorted().joinToString(","))
            .putString("facilityMaintenanceWeeks", finance.facilityMaintenanceWeeks.sorted().joinToString(","))
            .putString("facilityMaintenanceOutstanding", finance.facilityMaintenanceOutstanding.entries.sortedBy { it.key }.joinToString(",") { "${it.key.substringBefore(":")}:${it.key.substringAfter(":")}:${it.value}" })
            .putString("commercialRevenueWeeks", finance.commercialRevenueWeeks.sorted().joinToString(","))

    fun saveFinance(forTeamId:Int, finance:TeamFinanceState) { financeEditor(forTeamId, finance).apply() }

    /**
     * Atomically persists the player's GP finance settlement and the sponsor contracts
     * whose remaining-race counters were decremented by that same settlement.
     */
    fun saveFinanceAndSponsors(forTeamId: Int, finance: TeamFinanceState, sponsors: List<SponsorContract>): Boolean =
        sponsorEditor(financeEditor(forTeamId, finance), forTeamId, sponsors).commit()

    /** Salary is paid after the GP completes; each season/round is idempotent across restarts. */
    fun applyDriverSalaryForRaceOnce(forTeamId:Int, seasonToCharge:Int, roundToCharge:Int, finance:TeamFinanceState, market:DriverMarketState): TeamFinanceState {
        if (roundToCharge !in 1..30) return finance
        val key = "driverSalaryPaid_${forTeamId}_${seasonToCharge}_$roundToCharge"
        if (prefs.getBoolean(key, false)) return finance
        // Migration safety: if V154 already charged the whole annual salary at season start,
        // suppress all remaining per-GP charges for that same season to avoid double billing.
        val legacyAnnualKey = "annualDriverSalarySeason_$forTeamId"
        val migrationKey = "driverSalaryLegacyMigrated_${forTeamId}_${seasonToCharge}"
        if (!prefs.getBoolean(migrationKey, false) && prefs.getInt(legacyAnnualKey, 0) == seasonToCharge) {
            val editor = prefs.edit().putBoolean(migrationKey, true)
            (1..30).forEach { legacyRound -> editor.putBoolean("driverSalaryPaid_${forTeamId}_${seasonToCharge}_$legacyRound", true) }
            check(editor.commit()) { "Não foi possível persistir a migração dos salários da temporada $seasonToCharge" }
            return finance
        }
        val annual = market.contracts.filter { it.teamId == forTeamId && it.activeIn(seasonToCharge) }
            .sumOf { it.salary.coerceAtLeast(0L) }
        val requested = annual / 30L + if (roundToCharge == 30) annual % 30L else 0L
        var next = SalaryLedger.apply(finance, seasonToCharge, roundToCharge, requested)
        next = SignatureFeeAccounting.recognizeForRace(next, seasonToCharge, roundToCharge)
        // Persist outstanding obligations and paid markers atomically; unpaid rounds remain retryable.
        val editor = financeEditor(forTeamId, next)
        if ("$seasonToCharge:$roundToCharge" in next.salaryPaidRounds) editor.putBoolean(key, true)
        check(editor.commit()) {
            "Não foi possível persistir o pagamento salarial do GP $roundToCharge/temporada $seasonToCharge"
        }
        return next
    }

    /** Compatibility shim for older callers: deliberately no longer charges annual salaries upfront. */
    @Deprecated("Use applyDriverSalaryForRaceOnce after a completed GP")
    fun applyAnnualDriverSalariesOnce(forTeamId:Int, seasonToCharge:Int, finance:TeamFinanceState, market:DriverMarketState): TeamFinanceState = finance

    /** Qualifying sponsor bonus is a GP/season-round transaction and is persisted idempotently. */
    fun applyQualifyingBonusOnce(forTeamId:Int, seasonToApply:Int, roundToApply:Int, finance:TeamFinanceState, sponsors:List<SponsorContract>, bestPosition:Int): TeamFinanceState {
        if (bestPosition <= 0) return finance
        val key = "qualifyingBonusPaid_${seasonToApply}_$roundToApply"
        if (prefs.getBoolean(key, false)) return finance
        val bonus = FinanceEngine().qualifyingBonus(sponsors, bestPosition)
        val next = if (bonus > 0L) FinanceEngine().applyCashCreditFinance(finance, bonus, "Bônus por meta de qualificação — GP $roundToApply") else finance
        // Persist the finance state and the idempotency marker in one SharedPreferences commit.
        // A failed commit must abort race finalization; returning `next` would let the
        // in-memory career advance while the durable marker remains absent.
        check(financeEditor(forTeamId, next).putBoolean(key, true).commit()) {
            "Não foi possível persistir o bônus de qualificação do GP $roundToApply/temporada $seasonToApply"
        }
        return next
    }
    fun loadSponsor(forTeamId:Int, fallback:SponsorContract): SponsorContract {
        if (prefs.getInt("sponsorTeam", -1) != forTeamId) return fallback
        val stored = SponsorContract(
            prefs.getString("sponsorName",fallback.name) ?: fallback.name,
            prefs.getLong("sponsorUpfront",fallback.upfront),
            prefs.getLong("sponsorRace",fallback.racePayment),
            prefs.getLong("sponsorPoints",fallback.pointsBonus),
            prefs.getInt("sponsorYears",fallback.years),
            prefs.getInt("sponsorRep",fallback.minimumReputation),
            prefs.getInt("sponsorSlot",fallback.slot),
            prefs.getInt("sponsorQualTarget",fallback.qualifyingTarget),
            prefs.getLong("sponsorQualBonus",fallback.qualifyingBonus),
            prefs.getInt("sponsorRaceTarget",fallback.raceTarget),
            prefs.getLong("sponsorRaceTargetBonus",fallback.raceTargetBonus),
            prefs.getBoolean("sponsorActive",fallback.active),
            prefs.getInt("sponsorRaces",fallback.races),
            prefs.getInt("sponsorRacesRemaining",fallback.racesRemaining),
            fallback.category,
            prefs.getInt("sponsorQualTargetMin",fallback.qualifyingTargetMin),
            prefs.getInt("sponsorQualTargetMax",fallback.qualifyingTargetMax),
            prefs.getInt("sponsorRaceTargetMin",fallback.raceTargetMin),
            prefs.getInt("sponsorRaceTargetMax",fallback.raceTargetMax)
        )
        val marketingLevel = loadFacilities(forTeamId)?.level(FacilityType.MARKETING)
            ?: (WorldDatabase.teams.firstOrNull { it.id == forTeamId }?.initialLevel ?: 0)
        val migrated = SponsorContractPricing.ensureEntryAndGp(stored, forTeamId, season, marketingLevel)
        if (migrated != stored) {
            prefs.edit().putLong("sponsorUpfront", migrated.upfront).putLong("sponsorRace", migrated.racePayment).apply()
        }
        return migrated
    }
    fun loadSponsors(forTeamId:Int): List<SponsorContract> {
        if (prefs.getInt("sponsorTeam", -1) != forTeamId) return emptyList()
        val stored = (1..5).mapNotNull { slot ->
            val name=prefs.getString("sponsor_${slot}_name",null) ?: return@mapNotNull null
            SponsorContract(name, prefs.getLong("sponsor_${slot}_upfront",0), prefs.getLong("sponsor_${slot}_race",0), prefs.getLong("sponsor_${slot}_points",0), prefs.getInt("sponsor_${slot}_years",1), prefs.getInt("sponsor_${slot}_rep",0), slot, prefs.getInt("sponsor_${slot}_qualTarget",0), prefs.getLong("sponsor_${slot}_qualBonus",0), prefs.getInt("sponsor_${slot}_raceTarget",0), prefs.getLong("sponsor_${slot}_raceTargetBonus",0), prefs.getBoolean("sponsor_${slot}_active",true), prefs.getInt("sponsor_${slot}_races",5), prefs.getInt("sponsor_${slot}_racesRemaining",prefs.getInt("sponsor_${slot}_races",5)), prefs.getString("sponsor_${slot}_category","BASICO") ?: "BASICO", prefs.getInt("sponsor_${slot}_qualTargetMin",prefs.getInt("sponsor_${slot}_qualTarget",0)), prefs.getInt("sponsor_${slot}_qualTargetMax",prefs.getInt("sponsor_${slot}_qualTarget",0)), prefs.getInt("sponsor_${slot}_raceTargetMin",prefs.getInt("sponsor_${slot}_raceTarget",0)), prefs.getInt("sponsor_${slot}_raceTargetMax",prefs.getInt("sponsor_${slot}_raceTarget",0)))
        }
        val marketingLevel = loadFacilities(forTeamId)?.level(FacilityType.MARKETING)
            ?: (WorldDatabase.teams.firstOrNull { it.id == forTeamId }?.initialLevel ?: 0)
        val migrated = stored.map { SponsorContractPricing.ensureEntryAndGp(it, forTeamId, season, marketingLevel) }
        if (migrated != stored) saveSponsors(forTeamId, migrated)
        return migrated
    }
    fun saveSponsor(forTeamId:Int, sponsor:SponsorContract) = saveSponsors(forTeamId, listOf(sponsor))
    fun saveSponsors(forTeamId:Int, sponsors:List<SponsorContract>) {
        sponsorEditor(prefs.edit(), forTeamId, sponsors).apply()
    }

    private fun sponsorEditor(
        editor: android.content.SharedPreferences.Editor,
        forTeamId: Int,
        sponsors: List<SponsorContract>
    ): android.content.SharedPreferences.Editor {
        val e=editor.putInt("sponsorTeam",forTeamId)
        for (slot in 1..5) {
            val s=sponsors.firstOrNull { it.slot==slot }
            if (s==null) {
                listOf("name","upfront","race","points","years","rep","qualTarget","qualBonus","raceTarget","raceTargetBonus","qualTargetMin","qualTargetMax","raceTargetMin","raceTargetMax","active","races","racesRemaining","category").forEach { e.remove("sponsor_${slot}_$it") }
            } else {
                e.putString("sponsor_${slot}_name",s.name).putLong("sponsor_${slot}_upfront",s.upfront).putLong("sponsor_${slot}_race",s.racePayment).putLong("sponsor_${slot}_points",s.pointsBonus).putInt("sponsor_${slot}_years",s.years).putInt("sponsor_${slot}_rep",s.minimumReputation).putInt("sponsor_${slot}_qualTarget",s.qualifyingTarget).putLong("sponsor_${slot}_qualBonus",s.qualifyingBonus).putInt("sponsor_${slot}_raceTarget",s.raceTarget).putLong("sponsor_${slot}_raceTargetBonus",s.raceTargetBonus).putInt("sponsor_${slot}_qualTargetMin",s.qualifyingTargetMin).putInt("sponsor_${slot}_qualTargetMax",s.qualifyingTargetMax).putInt("sponsor_${slot}_raceTargetMin",s.raceTargetMin).putInt("sponsor_${slot}_raceTargetMax",s.raceTargetMax).putBoolean("sponsor_${slot}_active",s.active).putInt("sponsor_${slot}_races",s.races).putInt("sponsor_${slot}_racesRemaining",s.racesRemaining).putString("sponsor_${slot}_category",s.category)
            }
        }
        // Keep legacy primary sponsor keys synchronized.
        val primary=sponsors.firstOrNull { it.slot==1 }
        if (primary==null) { e.remove("sponsorName").remove("sponsorUpfront").remove("sponsorRace").remove("sponsorPoints").remove("sponsorYears").remove("sponsorRep").remove("sponsorSlot").remove("sponsorQualTarget").remove("sponsorQualBonus").remove("sponsorRaceTarget").remove("sponsorRaceTargetBonus").remove("sponsorActive").remove("sponsorRaces").remove("sponsorRacesRemaining") }
        else { e.putString("sponsorName",primary.name).putLong("sponsorUpfront",primary.upfront).putLong("sponsorRace",primary.racePayment).putLong("sponsorPoints",primary.pointsBonus).putInt("sponsorYears",primary.years).putInt("sponsorRep",primary.minimumReputation).putInt("sponsorSlot",primary.slot).putInt("sponsorQualTarget",primary.qualifyingTarget).putLong("sponsorQualBonus",primary.qualifyingBonus).putInt("sponsorRaceTarget",primary.raceTarget).putLong("sponsorRaceTargetBonus",primary.raceTargetBonus).putBoolean("sponsorActive",primary.active).putInt("sponsorRaces",primary.races).putInt("sponsorRacesRemaining",primary.racesRemaining).putInt("sponsorQualTargetMin",primary.qualifyingTargetMin).putInt("sponsorQualTargetMax",primary.qualifyingTargetMax).putInt("sponsorRaceTargetMin",primary.raceTargetMin).putInt("sponsorRaceTargetMax",primary.raceTargetMax) }
        return e
    }

    /** Current persisted attributes for all 100 drivers. Canonical values are seeded by
     * startNewCareer(); cross-version saves are not the validation baseline for updates. */
    fun driverAttributes(): Map<Int, IntArray> {
        val raw = prefs.getString("driverAttributes", "").orEmpty()
        val merged = DriverAttributePersistence.merge(raw, WorldDatabase.allDrivers)
        // Repair partial/corrupt records individually, preserving valid progression for
        // the other 99 drivers. The new-career flow resets the full roster to the current
        // canonical profiles, so no name-specific legacy-save heuristic belongs here.
        if (merged.second) saveDriverAttributes(merged.first)
        return merged.first
    }

    /** Persistent class overrides generated by annual calendar events. */
    fun driverClassOverrides(): Map<Int, String> = prefs.getString("annualDriverClassOverrides", "").orEmpty()
        .split(';').mapNotNull { row ->
            val p = row.split(':', limit = 2)
            val id = p.getOrNull(0)?.toIntOrNull() ?: return@mapNotNull null
            val driverClass = p.getOrNull(1)?.let(DriverClassProgressionEngine::canonicalClass) ?: return@mapNotNull null
            id to driverClass
        }.toMap()

    fun saveDriverClassOverride(driverId: Int, driverClass: String) {
        val officialClass = DriverClassProgressionEngine.canonicalClass(driverClass) ?: return
        val values = driverClassOverrides().toMutableMap(); values[driverId] = officialClass
        prefs.edit().putString("annualDriverClassOverrides", values.toSortedMap().entries.joinToString(";") { "${it.key}:${it.value}" }).commit()
    }

    /** V276: atomically commit annual driver effects and their idempotency keys. */
    fun commitAnnualDriverStateAndKeys(
        seasonNumber: Int,
        attributes: Map<Int, IntArray>,
        classOverrides: Map<Int, String>,
        processedKeys: Set<String>
    ) {
        require(seasonNumber >= 1)
        // V281: merge the incoming batch with the existing roster. A partial batch
        // must never replace the whole 100-driver snapshot and erase valid progress.
        val roster = WorldDatabase.allDrivers
        val knownDriverIds = roster.map { it.id }.toSet()
        val existingRawAttributes = prefs.getString("driverAttributes", "").orEmpty()
        val existingAttributes = DriverAttributePersistence.merge(existingRawAttributes, roster).first
        val validAttributes = roster.associate { driver ->
            val incoming = attributes[driver.id]
            val prior = existingAttributes[driver.id]
            val chosen = when {
                incoming != null && incoming.size == 7 -> incoming
                prior != null && prior.size == 7 -> prior
                else -> intArrayOf(driver.speed, driver.qualifying, driver.overtaking, driver.defense,
                    driver.consistency, driver.wet, driver.tyre)
            }
            driver.id to chosen.copyOf().also { values ->
                values.indices.forEach { i -> values[i] = values[i].coerceIn(40, 100) }
            }
        }
        // Merge overrides too, so an event affecting one pilot cannot erase other
        // pilots' class changes. Invalid and unknown records are excluded.
        val validClasses = (driverClassOverrides() + classOverrides).entries.mapNotNull { (id, driverClass) ->
            if (id !in knownDriverIds) return@mapNotNull null
            DriverClassProgressionEngine.canonicalClass(driverClass)?.let { id to it }
        }.toMap()
        val mergedKeys = (loadProcessedAnnualEventKeys(seasonNumber) + processedKeys.filter { it.isNotBlank() })
            .toSortedSet().toList().takeLast(1000)
        prefs.edit()
            .putString("driverAttributes", validAttributes.toSortedMap().entries.joinToString(";") { (id, a) -> "$id:${a.joinToString(",")}" })
            .putString("annualDriverClassOverrides", validClasses.toSortedMap().entries.joinToString(";") { "${it.key}:${it.value}" })
            .putString("annualEventProcessed_$seasonNumber", mergedKeys.joinToString("|"))
            .commit()
    }

    fun saveDriverAttributes(values: Map<Int, IntArray>) {
        prefs.edit().putString("driverAttributes", DriverAttributePersistence.serialize(values)).apply()
    }

    private fun saveSeasonStartDriverAttributes(season: Int, values: Map<Int, IntArray>) {
        // V279: capture the class at the same season boundary as the seven attributes.
        // Annual events may change the live class mid-season; the evolution baseline
        // must continue to represent the season opening state until the next season.
        val overrides = driverClassOverrides()
        val currentClasses = WorldDatabase.allDrivers.associate { driver ->
            driver.id to (overrides[driver.id] ?: driver.driverClass)
        }
        prefs.edit()
            .putString("driverSeasonStartAttributes_$season", values.toSortedMap().entries.joinToString(";") { (id,a) -> "$id:${a.joinToString(",") { it.coerceIn(40,100).toString() }}" })
            .putString("driverSeasonStartClasses_$season", currentClasses.toSortedMap().entries.joinToString(";") { (id, driverClass) -> "$id:$driverClass" })
            .commit()
    }

    fun seasonStartDriverDefinition(driverId: Int, season: Int = this.season): com.f1teammanager.core.season.DriverDefinition {
        val base = WorldDatabase.allDrivers.first { it.id == driverId }
        val raw = prefs.getString("driverSeasonStartAttributes_$season", "").orEmpty()
        val a = raw.split(';').mapNotNull { token ->
            val p = token.split(':', limit = 2)
            if (p.size != 2 || p[0].toIntOrNull() != driverId) return@mapNotNull null
            val values = p[1].split(',').mapNotNull { it.toIntOrNull() }
            if (values.size == 7) values.toIntArray() else null
        }.firstOrNull() ?: intArrayOf(base.speed,base.qualifying,base.overtaking,base.defense,base.consistency,base.wet,base.tyre)
        val seasonClasses = prefs.getString("driverSeasonStartClasses_$season", "").orEmpty()
            .split(';').mapNotNull { token ->
                val p = token.split(':', limit = 2)
                if (p.size == 2 && p[0].toIntOrNull() == driverId)
                    DriverClassProgressionEngine.canonicalClass(p[1])?.let { driverId to it } else null
            }.toMap()
        // Backward compatibility for saves created before V279: use the current
        // override only if no opening-class snapshot exists for this season.
        val openingClass = seasonClasses[driverId]
            ?: driverClassOverrides()[driverId]
            ?: base.driverClass
        return base.copy(speed=a[0],qualifying=a[1],overtaking=a[2],defense=a[3],consistency=a[4],wet=a[5],tyre=a[6], driverClass=openingClass).normalized()
    }

    /** Current driver-rating projection used by the active evolution state machine. */
    private fun ratingsForEvolution(driver: com.f1teammanager.core.season.DriverDefinition): IntArray =
        intArrayOf(driver.speed, driver.qualifying, driver.overtaking, driver.defense, driver.consistency, driver.wet, driver.tyre)

    private fun readDriverEvolutionPhases(): MutableMap<Int,String> = prefs.getString("driverEvolutionPhases", "").orEmpty().split(';').mapNotNull { token ->
        val p=token.split(':', limit=2); if (p.size==2) p[0].toIntOrNull()?.let { it to p[1] } else null
    }.toMap().toMutableMap()

    private fun saveDriverEvolutionPhases(values: Map<Int,String>) {
        prefs.edit().putString("driverEvolutionPhases", values.toSortedMap().entries.joinToString(";") { "${it.key}:${it.value}" }).apply()
    }

    private fun readDriverClassSeasonPerformance(seasonNumber: Int): MutableMap<Int, Pair<Double, Int>> {
        return prefs.getString("driverClassPerformance_$seasonNumber", "").orEmpty()
            .split(';').mapNotNull { token ->
                val p = token.split(':', limit = 3)
                if (p.size != 3) null else {
                    val id = p[0].toIntOrNull()
                    val sum = p[1].toDoubleOrNull()
                    val count = p[2].toIntOrNull()
                    if (id == null || sum == null || count == null || count <= 0 || !sum.isFinite()) null
                    else id to (sum to count)
                }
            }.toMap().toMutableMap()
    }

    private fun encodeDriverClassSeasonPerformance(values: Map<Int, Pair<Double, Int>>): String =
        values.toSortedMap().entries.joinToString(";") { (id, value) ->
            "$id:${value.first}:${value.second}"
        }

    private data class DriverClassChange(
        val driverId: Int,
        val driverName: String,
        val previousClass: String,
        val resultingClass: String,
        val direction: DriverClassProgressionEngine.Direction,
        val twoSeasonAverage: Double
    )

    /**
     * V649 migration is intentionally one-time. V648 allowed progression above a
     * class without earning a promotion; these old values are normalized to the
     * driver's registered opening class. Future above-band growth is retained and
     * promotion is earned through two newly measured complete seasons.
     */
    private fun migrateDriverClassSystemV649() {
        if (prefs.getBoolean("driverClassSystemV649", false)) return
        val existing = driverAttributes()
        val normalized = WorldDatabase.allDrivers.associate { base ->
            val source = existing[base.id] ?: intArrayOf(
                base.speed, base.qualifying, base.overtaking, base.defense,
                base.consistency, base.wet, base.tyre
            )
            base.id to DriverProfileCatalog.normalizeRatingsToClassBand(source, base.driverClass)
        }
        val phases = WorldDatabase.allDrivers.associate { base ->
            val attrs = normalized.getValue(base.id)
            val current = DriverProfileCatalog.overall(attrs)
            base.id to if (base.potentialOverall - current > 1) "GROWING" else "STABLE"
        }
        val phaseGps = WorldDatabase.allDrivers.associate { it.id to 0 }
        val editor = prefs.edit()
            .putString("driverAttributes", DriverAttributePersistence.serialize(normalized))
            // All previous random class events are retired. The canonical catalog class
            // becomes the baseline until a two-season sporting review changes it.
            .putString("annualDriverClassOverrides", "")
            .putString("driverEvolutionPhases", phases.toSortedMap().entries.joinToString(";") { "${it.key}:${it.value}" })
            .putString("driverEvolutionPhaseGps", phaseGps.toSortedMap().entries.joinToString(",") { "${it.key}:${it.value}" })
            .putString("driverEvolutionBank_${prefs.getInt("season", 2026)}", "")
            .putString("driverEvolutionAttributeGains_${prefs.getInt("season", 2026)}", "")
            .putInt("driverClassProgressionReviewedSeason", 0)
            .remove("driverEvolutionPhaseStart")
            .remove("driverEvolutionPhaseTarget")
            .remove("driverEvolutionPhasePressure")
            .putBoolean("driverClassSystemV649", true)
        prefs.all.keys.filter { it.startsWith("driverClassPerformance_") }.forEach(editor::remove)
        check(editor.commit()) { "Não foi possível migrar a classificação e evolução dos pilotos para V649." }
    }

    /** Applies promotion/demotion once, at the explicit end-of-season boundary. */
    private fun reviewDriverClassesForCompletedSeason(completedSeason: Int): List<DriverClassChange> {
        if (prefs.getInt("driverClassProgressionReviewedSeason", 0) >= completedSeason) return emptyList()
        val previous = readDriverClassSeasonPerformance(completedSeason - 1)
        val latest = readDriverClassSeasonPerformance(completedSeason)
        val attributes = driverAttributes()
        val classOverrides = driverClassOverrides().toMutableMap()
        val expectedRounds = SeasonCalendar.forSeason(completedSeason).size
        val championDriverId = history.driverChampions(completedSeason).singleOrNull()?.driverId
        val changes = mutableListOf<DriverClassChange>()

        WorldDatabase.allDrivers.forEach { base ->
            val currentClass = classOverrides[base.id] ?: base.driverClass
            val values = attributes[base.id] ?: intArrayOf(
                base.speed, base.qualifying, base.overtaking, base.defense,
                base.consistency, base.wet, base.tyre
            )
            val overall = DriverProfileCatalog.overall(values)
            fun evidence(map: Map<Int, Pair<Double, Int>>, seasonNumber: Int) = map[base.id]?.let { (sum, count) ->
                if (count <= 0) null else DriverClassProgressionEngine.SeasonPerformance(
                    seasonNumber, sum / count.toDouble(), count
                )
            }
            val decision = DriverClassProgressionEngine.evaluate(
                driverClass = currentClass,
                overall = overall,
                previous = evidence(previous, completedSeason - 1),
                latest = evidence(latest, completedSeason),
                expectedSeasonRounds = expectedRounds,
                isChampion = base.id == championDriverId
            )
            if (decision.changed) {
                classOverrides[base.id] = decision.resultingClass
                changes += DriverClassChange(
                    base.id, base.name, decision.previousClass, decision.resultingClass,
                    decision.direction, decision.twoSeasonAverage
                )
            }
        }

        val commit = prefs.edit()
            .putString("annualDriverClassOverrides", classOverrides.toSortedMap().entries.joinToString(";") { "${it.key}:${it.value}" })
            .putInt("driverClassProgressionReviewedSeason", completedSeason)
        check(commit.commit()) { "Não foi possível confirmar a avaliação de classe da temporada $completedSeason." }
        return changes
    }

    fun driverDefinition(driverId:Int): com.f1teammanager.core.season.DriverDefinition {
        val base = WorldDatabase.allDrivers.first { it.id == driverId }
        val a = driverAttributes()[driverId] ?: intArrayOf(base.speed,base.qualifying,base.overtaking,base.defense,base.consistency,base.wet,base.tyre)
        val classOverride = driverClassOverrides()[driverId]
        return base.copy(speed=a[0],qualifying=a[1],overtaking=a[2],defense=a[3],consistency=a[4],wet=a[5],tyre=a[6], driverClass=classOverride ?: base.driverClass).normalized()
    }

    /**
     * Canonical career roster adapter. WorldDatabase remains the immutable source for
     * driver identity and base attributes; active contracts are the source of truth for
     * team assignment. This keeps Team, Home, qualifying, race, and driver details in
     * sync after the offseason transfer transition.
     */
    fun currentDrivers(): List<com.f1teammanager.core.season.DriverDefinition> {
        // Batch-read preference-backed maps once. Calling driverDefinition() inside this
        // 100-item projection reparsed/merged the entire attribute blob and class map
        // for every pilot (quadratic work on roster, strategy, and race screens).
        val roster = WorldDatabase.allDrivers
        val attributes = driverAttributes()
        val classOverrides = driverClassOverrides()
        val market = loadDriverMarket()
        val activeDeals = market?.contracts?.filter { it.activeIn(season) }?.associateBy { it.driverId }.orEmpty()
        val freeAgents = market?.freeAgents?.toSet().orEmpty()
        return roster.map { base ->
            val a = attributes[base.id] ?: intArrayOf(base.speed,base.qualifying,base.overtaking,base.defense,base.consistency,base.wet,base.tyre)
            val contractTeam = activeDeals[base.id]?.teamId
            val resolvedTeam = when {
                contractTeam != null -> contractTeam
                base.id in freeAgents -> 0
                else -> base.teamId // compatibility fallback for saves predating the market
            }
            base.copy(speed=a[0],qualifying=a[1],overtaking=a[2],defense=a[3],consistency=a[4],wet=a[5],tyre=a[6],
                driverClass=classOverrides[base.id] ?: base.driverClass, teamId=resolvedTeam).normalized()
        }
    }

    private fun readSeasonTargets(): Map<Int, DriverEvolutionEngine.Target> {
        return prefs.getString("driverSeasonTargets_$season", "").orEmpty().split(',').mapNotNull { token ->
            val p = token.split(':')
            when {
                p.size == 2 -> {
                    val id = p[0].toIntOrNull() ?: return@mapNotNull null
                    val position = p[1].toIntOrNull() ?: return@mapNotNull null
                    id to DriverEvolutionEngine.Target(position.coerceIn(1, DriverEvolutionEngine.DRIVER_GRID_SIZE))
                }
                p.size >= 4 -> {
                    val id = p[0].toIntOrNull() ?: return@mapNotNull null
                    val championship = p[1].toIntOrNull() ?: return@mapNotNull null
                    val qualifying = p[2].toIntOrNull() ?: return@mapNotNull null
                    val race = p[3].toIntOrNull() ?: return@mapNotNull null
                    id to DriverEvolutionEngine.Target(
                        championship.coerceIn(1, DriverEvolutionEngine.DRIVER_GRID_SIZE),
                        qualifying.coerceIn(1, DriverEvolutionEngine.DRIVER_GRID_SIZE),
                        race.coerceIn(1, DriverEvolutionEngine.DRIVER_GRID_SIZE)
                    )
                }
                else -> null
            }
        }.toMap()
    }

    /**
     * Builds the season's individual expectations once, anchored to the 40-team car order.
     * Existing V680 saves (target version 2) are recalibrated once on first launch after the
     * update. Version 3 targets then remain fixed for the whole season so driver growth or
     * a mid-season upgrade cannot continually move the same driver's own performance goal.
     */
    fun initializeDriverSeasonTargets(playerCar: TeamCarState? = null) {
        val savedTargets = readSeasonTargets()
        val savedTargetVersion = prefs.getInt("driverSeasonTargetsVersion_$season", 0)
        if (savedTargetVersion >= 3 && savedTargets.size == DriverEvolutionEngine.DRIVER_GRID_SIZE) return

        val market = loadDriverMarket()
        val active = market?.contracts?.filter { it.activeIn(season) }
            ?: WorldDatabase.drivers.map { d -> com.f1teammanager.core.manager.DriverDeal(d.id,d.teamId,1,0L,0L,season) }
        check(active.size == DriverEvolutionEngine.DRIVER_GRID_SIZE &&
            active.map { it.driverId }.distinct().size == DriverEvolutionEngine.DRIVER_GRID_SIZE) {
            "Metas individuais: o campeonato de pilotos precisa conter exatamente 80 pilotos ativos; classificação de construtores (1–40) não pode ser reutilizada."
        }
        val attributes = driverAttributes()
        val roster = WorldDatabase.allDrivers.associateBy { it.id }

        fun carStrength(teamId: Int): Double {
            val team = WorldDatabase.teams.firstOrNull { it.id == teamId } ?: return 50.0
            val resolved = if (teamId == this.teamId) {
                playerCar ?: loadCar(teamId) ?: InitialTeamProfile.carState(team)
            } else {
                // AI teams use their per-team annual car snapshot; loadCar() is the
                // single active player-car slot and must not be treated as an AI garage.
                loadAnnualEventCarStats(teamId, InitialTeamProfile.carState(team))
            }
            return (resolved.chassis + resolved.engine + resolved.frontWing +
                resolved.rearWing + resolved.brakes + resolved.electricPowerUnit) / 6.0
        }

        val carStrengths = WorldDatabase.teams.associate { it.id to carStrength(it.id) }
        val inputs = active.mapNotNull { deal ->
            val driver = roster[deal.driverId] ?: return@mapNotNull null
            val ratings = attributes[deal.driverId] ?: intArrayOf(
                driver.speed, driver.qualifying, driver.overtaking, driver.defense,
                driver.consistency, driver.wet, driver.tyre
            )
            DriverEvolutionEngine.TargetInput(
                driverId = deal.driverId,
                teamId = deal.teamId,
                carStrength = carStrengths[deal.teamId] ?: 50.0,
                driverOverall = DriverProfileCatalog.overall(ratings),
                qualifyingStrength = ratings[1]
            )
        }
        check(inputs.size == DriverEvolutionEngine.DRIVER_GRID_SIZE) {
            "Metas individuais: não foi possível montar as 80 metas do campeonato de pilotos."
        }
        val targets = DriverEvolutionEngine.buildIndividualTargets(inputs)
        check(targets.size == DriverEvolutionEngine.DRIVER_GRID_SIZE) {
            "Metas individuais: a geração não retornou exatamente 80 pilotos."
        }

        prefs.edit()
            .putString(
                "driverSeasonTargets_$season",
                targets.entries.sortedBy { it.key }.joinToString(",") { (id, target) ->
                    "${id}:${target.championshipPosition.coerceIn(1, DriverEvolutionEngine.DRIVER_GRID_SIZE)}:" +
                        "${target.qualifyingPosition.coerceIn(1, DriverEvolutionEngine.DRIVER_GRID_SIZE)}:" +
                        "${target.racePosition.coerceIn(1, DriverEvolutionEngine.DRIVER_GRID_SIZE)}"
                }
            )
            .putInt("driverSeasonTargetsVersion_$season", 3)
            .apply()
    }

    /**
     * Applies one in-season evolution tick after a completed GP. Evolution is continuous
     * during the championship; GP30 only closes the season and does not perform a second
     * evolution pass. The fractional bank makes changes gradual while keeping the official
     * annual gain ceiling from DriverProfileCatalog.
     */
    private fun readAnnualAttributeGains(): MutableMap<Int, IntArray> {
        val raw = prefs.getString("driverEvolutionAttributeGains_$season", "").orEmpty()
        val out = mutableMapOf<Int, IntArray>()
        raw.split(';').filter { it.isNotBlank() }.forEach { token ->
            val p = token.split(':')
            if (p.size == 2) {
                val id = p[0].toIntOrNull()
                val values = p[1].split(',').mapNotNull { it.toIntOrNull() }
                if (id != null && values.size == 7) out[id] = values.toIntArray()
            }
        }
        return out
    }

    private fun writeAnnualAttributeGains(values: Map<Int, IntArray>) {
        prefs.edit().putString(
            "driverEvolutionAttributeGains_$season",
            values.toSortedMap().entries.joinToString(";") { (id, a) -> "$id:${a.joinToString(",")}" }
        ).apply()
    }

    fun driverAnnualAttributeGains(): Map<Int, IntArray> =
        readAnnualAttributeGains().mapValues { it.value.copyOf() }

    /** Training-center changes and annual caps are committed together. */
    fun saveDriverDevelopmentResult(attributes: Map<Int, IntArray>, annualGains: Map<Int, IntArray>) {
        val valid = attributes.filterKeys { id -> WorldDatabase.allDrivers.any { it.id == id } }
            .filterValues { it.size == 7 && it.all { value -> value in 40..100 } }
        val validGains = annualGains.filterKeys { id -> WorldDatabase.allDrivers.any { it.id == id } }
            .filterValues { it.size == 7 && it.all { value -> value >= 0 } }
        val editor = prefs.edit()
            .putString("driverAttributes", DriverAttributePersistence.serialize(valid))
            .putString("driverEvolutionAttributeGains_$season", validGains.toSortedMap().entries.joinToString(";") { (id, values) -> "$id:${values.joinToString(",")}" })
        check(editor.commit()) { "Não foi possível salvar o desenvolvimento e os limites anuais dos pilotos." }
    }

    private fun pendingDriverEvolutionNewsKey(seasonNumber: Int, round: Int) =
        "driverEvolutionPendingNews_${seasonNumber}_$round"

    /**
     * Replays the durable outbox after a crash between driver-stat evolution and
     * publication of its news cards. The outbox is cleared in the same commit that
     * saves the market notifications, so recovery cannot silently lose the news.
     */
    private fun flushPendingDriverEvolutionNews(seasonNumber: Int, round: Int) {
        val key = pendingDriverEvolutionNewsKey(seasonNumber, round)
        val raw = prefs.getString(key, null) ?: return
        val changes = raw.split("\n").filter { it.isNotBlank() }.mapNotNull { encoded ->
            runCatching { String(java.util.Base64.getDecoder().decode(encoded), Charsets.UTF_8) }.getOrNull()
        }
        val market = loadDriverMarket()
            ?: error("Não foi possível recuperar o mercado de pilotos para publicar notícias de evolução")
        val week = SeasonCalendar.forSeason(seasonNumber).firstOrNull { it.round == round }?.weekOfSeason ?: currentWeek
        val notices = changes.mapNotNull { change ->
            val exists = market.notifications.any {
                it.season == seasonNumber && it.week == week && it.category == MarketNewsCategory.DRIVER_EVOLUTION && it.message == change
            }
            if (exists) null else MarketNotification(
                seasonNumber,
                week,
                DriverEvolutionEngine.newsTitle(if (change.contains("perdeu Overall", ignoreCase = true)) -1 else 1),
                change,
                true,
                MarketNewsCategory.DRIVER_EVOLUTION
            )
        }
        val updated = if (notices.isEmpty()) market else market.copy(
            notifications = (market.notifications + notices).takeLast(1000)
        ).normalized()
        check(saveDriverMarketAndClearPendingNews(updated, key)) {
            "Não foi possível confirmar as notícias de evolução do GP $round/temporada $seasonNumber"
        }
    }

    /**
     * Applies one in-season evolution tick after a completed GP.
     * Positive evolution uses the full intended gain, with per-attribute class-ceiling
     * redistribution. Regression is independent and is capped at the floor 40.
     */
    fun applyDriverRaceEvolution(
        round: Int,
        teamFacilitiesById: Map<Int, TeamFacilitiesState> = emptyMap()
    ): List<String> {
        // One deterministic evolution tick per driver/GP. Contracted drivers add
        // performance evidence; free agents develop separately without race samples.
        val processedRounds = readMap("driverEvolutionProcessedRounds_$season")
        if (processedRounds[round] == 1) {
            flushPendingDriverEvolutionNews(season, round)
            return emptyList()
        }
        // Targets are frozen after the season's first valid grid. Upgrades and driver
        // development affect race performance, not the expectation retroactively.
        initializeDriverSeasonTargets(loadCar(teamId))
        val targets = readSeasonTargets().ifEmpty { initializeDriverSeasonTargets(loadCar(teamId)); readSeasonTargets() }
        val races = history.raceRecords(season)
        val qualifying = history.qualifyingRecords(season)
        val attrs = driverAttributes().toMutableMap()
        val classOverrides = driverClassOverrides()
        val annualGains = readAnnualAttributeGains()
        val banks = readDoubleMap("driverEvolutionBank_$season").toMutableMap()
        val ageBanks = readDoubleMap("driverAgeDeclineBanks").toMutableMap()
        val ageLosses = readDriverAgeAttributeMap("driverAgePhysicalLosses")
        val agePeaks = readDriverAgeAttributeMap("driverAgePhysicalPeaks")
        val ageCycles = readMap("driverAgeCycleIndices").toMutableMap()
        val phases = readDriverEvolutionPhases()
        val phaseGps = readMap("driverEvolutionPhaseGps").toMutableMap()
        val classPerformance = readDriverClassSeasonPerformance(season)
        val driverMarket = loadDriverMarket()
        val activeDeals = driverMarket?.contracts?.filter { it.activeIn(season) }.orEmpty()
        val activeDriverIds = if (driverMarket != null) activeDeals.map { it.driverId }.toSet()
            else races.filter { it.round == round }.map { it.driverId }.toSet()
        val teamByDriver = activeDeals.associate { it.driverId to it.teamId }
        val playerTeamDefinition = WorldDatabase.teams.firstOrNull { it.id == teamId }
        val playerFacilities = teamFacilitiesById[teamId]
            ?: loadFacilities(teamId)
            ?: playerTeamDefinition?.let { InitialTeamProfile.teamFacilities(it.initialLevel) }
            ?: TeamFacilitiesState()
        val changes = mutableListOf<String>()

        WorldDatabase.allDrivers.forEach { base ->
            val id = base.id
            val currentAttrs = attrs[id] ?: intArrayOf(base.speed,base.qualifying,base.overtaking,base.defense,base.consistency,base.wet,base.tyre)
            val effectiveClass = classOverrides[id] ?: base.driverClass
            val current = base.copy(
                speed=currentAttrs[0], qualifying=currentAttrs[1], overtaking=currentAttrs[2],
                defense=currentAttrs[3], consistency=currentAttrs[4], wet=currentAttrs[5], tyre=currentAttrs[6],
                driverClass=effectiveClass
            )
            if (id !in activeDriverIds) {
                // Only classify a driver as a free agent when the market snapshot
                // is available. Free agents receive the full natural development rate, but
                // no synthetic result is added to the two-season class evidence.
                if (driverMarket == null) return@forEach
                val tick = DriverEvolutionEngine.applyFreeDriverTick(
                    driver = current,
                    currentBank = banks[id] ?: 0.0,
                    annualGains = annualGains.getOrPut(id) { IntArray(7) },
                    random = kotlin.random.Random(annualEventSeed(season) + season*1000 + round*97 + id*31),
                    careerAge = DriverEvolutionEngine.careerAge(current, season),
                    currentAgeBank = ageBanks[id] ?: 0.0,
                    currentAgePhysicalLosses = ageLosses[id] ?: IntArray(7),
                    currentAgePhysicalPeaks = agePeaks[id] ?: intArrayOf(current.speed, current.qualifying, current.overtaking, current.defense, current.consistency, current.wet, current.tyre),
                    currentAgeCycleIndex = ageCycles[id] ?: DriverEvolutionEngine.careerCycleIndex(current, season),
                    careerCycleIndex = DriverEvolutionEngine.careerCycleIndex(current, season)
                )
                val updated = tick.driver
                val updatedAttrs = ratingsForEvolution(updated)
                val beforeOverall = DriverProfileCatalog.overall(currentAttrs)
                val afterOverall = DriverProfileCatalog.overall(updatedAttrs)
                if (afterOverall != beforeOverall || tick.ageRecoveredPoints > 0) {
                    val delta = afterOverall - beforeOverall
                    val movement = when {
                        delta > 0 -> "evoluiu"
                        delta < 0 -> "perdeu Overall"
                        else -> "recuperou atributos físicos"
                    }
                    val reason = if (tick.ageCycleRestarted && tick.ageRecoveredPoints > 0)
                        "reinício do ciclo: recuperação parcial de ${tick.ageRecoveredPoints} pontos físicos"
                    else if (delta > 0) "treinamento e potencial" else "declínio natural/forma esportiva"
                    changes += "${base.name} — Sem equipe — GP $round: ${movement}. Overall $beforeOverall → $afterOverall (${if (delta > 0) "+" else ""}$delta; $reason)."
                }
                attrs[id] = updatedAttrs
                banks[id] = tick.bank
                ageBanks[id] = tick.ageBank
                ageLosses[id] = tick.agePhysicalLosses
                agePeaks[id] = tick.agePhysicalPeaks
                ageCycles[id] = tick.ageCycleIndex
                phases[id] = tick.phase
                phaseGps[id] = (phaseGps[id] ?: 0) + 1
                return@forEach
            }
            val target = targets[id] ?: DriverEvolutionEngine.Target(80)
            val raceResult = races.firstOrNull { it.season == season && it.round == round && it.driverId == id }
            val qualifyingResult = qualifying.firstOrNull { it.season == season && it.round == round && it.driverId == id }
            // Missing race/qualifying rows are not evidence. Do not fabricate a
            // neutral weekend that could count toward a two-season class review.
            if (raceResult == null && qualifyingResult == null) return@forEach
            val evolutionRacePosition = DriverEvolutionEngine.racePositionForEvolution(
                target, raceResult?.position, raceResult?.status
            )
            val index = DriverEvolutionEngine.gpPerformanceIndex(
                target,
                qualifyingResult?.position ?: target.qualifyingPosition,
                evolutionRacePosition
            )

            val accumulated = classPerformance[id] ?: (0.0 to 0)
            classPerformance[id] = (accumulated.first + index) to (accumulated.second + 1)

            val beforeOverall = DriverProfileCatalog.overall(currentAttrs)
            val rng = kotlin.random.Random(annualEventSeed(season) + season*1000 + round*97 + id*31)
            val driverTeamId = teamByDriver[id]
            val driverFacilities = when {
                driverTeamId == null -> TeamFacilitiesState()
                driverTeamId == teamId -> playerFacilities
                teamFacilitiesById.containsKey(driverTeamId) -> teamFacilitiesById.getValue(driverTeamId)
                else -> WorldDatabase.teams.firstOrNull { it.id == driverTeamId }
                    ?.let { InitialTeamProfile.teamFacilities(it.initialLevel) } ?: TeamFacilitiesState()
            }
            val facilityFactor = if (driverTeamId == null) 1.0
                else com.f1teammanager.core.manager.FacilityEngine.driverDevelopmentEfficiency(driverFacilities)
            val tick = DriverEvolutionEngine.applyPerformanceTick(
                driver = current,
                performanceIndex = index,
                currentBank = banks[id] ?: 0.0,
                annualGains = annualGains.getOrPut(id) { IntArray(7) },
                random = rng,
                facilityGrowthEfficiency = facilityFactor,
                careerAge = DriverEvolutionEngine.careerAge(current, season),
                currentAgeBank = ageBanks[id] ?: 0.0,
                currentAgePhysicalLosses = ageLosses[id] ?: IntArray(7),
                currentAgePhysicalPeaks = agePeaks[id] ?: intArrayOf(current.speed, current.qualifying, current.overtaking, current.defense, current.consistency, current.wet, current.tyre),
                currentAgeCycleIndex = ageCycles[id] ?: DriverEvolutionEngine.careerCycleIndex(current, season),
                careerCycleIndex = DriverEvolutionEngine.careerCycleIndex(current, season)
            )
            val updated = tick.driver
            val updatedAttrs = ratingsForEvolution(updated)
            val afterOverall = DriverProfileCatalog.overall(updatedAttrs)
            if (afterOverall != beforeOverall || tick.ageRecoveredPoints > 0) {
                val team = loadDriverMarket()?.contracts?.firstOrNull { it.driverId == id && it.activeIn(season) }
                    ?.let { deal -> WorldDatabase.teams.firstOrNull { t -> t.id == deal.teamId }?.name } ?: "Sem equipe"
                val delta = afterOverall - beforeOverall
                val movement = when {
                    delta > 0 -> "evoluiu"
                    delta < 0 -> "perdeu Overall"
                    else -> "recuperou atributos físicos"
                }
                val age = DriverEvolutionEngine.careerAge(current, season)
                val reason = when {
                    tick.ageCycleRestarted && tick.ageRecoveredPoints > 0 -> "reinício do ciclo: recuperação parcial de ${tick.ageRecoveredPoints} pontos físicos"
                    delta < 0 && age >= 34 && index >= 85.0 -> "declínio natural da idade"
                    delta < 0 -> "desempenho abaixo das expectativas"
                    else -> "desempenho acima das expectativas"
                }
                changes += "${base.name} — $team — GP $round: ${movement}. Overall $beforeOverall → $afterOverall (${if (delta > 0) "+" else ""}$delta; $reason)."
            }
            attrs[id] = updatedAttrs
            banks[id] = tick.bank
            ageBanks[id] = tick.ageBank
            ageLosses[id] = tick.agePhysicalLosses
            agePeaks[id] = tick.agePhysicalPeaks
            ageCycles[id] = tick.ageCycleIndex
            phases[id] = tick.phase
            phaseGps[id] = (phaseGps[id] ?: 0) + 1
        }

        fun encodeIntMap(values: Map<Int, Int>) = values.toSortedMap().entries.joinToString(",") { "${it.key}:${it.value}" }
        fun encodeDoubleMap(values: Map<Int, Double>) = values.toSortedMap().entries.joinToString(",") { "${it.key}:${it.value}" }
        val evolutionCommit = prefs.edit()
            .putString("driverAttributes", DriverAttributePersistence.serialize(attrs))
            .putString("driverEvolutionPhases", phases.toSortedMap().entries.joinToString(";") { "${it.key}:${it.value}" })
            .putString("driverEvolutionBank_$season", encodeDoubleMap(banks))
            .putString("driverAgeDeclineBanks", ageBanks.toSortedMap().entries.joinToString(",") { "${it.key}:${it.value}" })
            .putString("driverAgePhysicalLosses", encodeDriverAgeAttributeMap(ageLosses))
            .putString("driverAgePhysicalPeaks", encodeDriverAgeAttributeMap(agePeaks))
            .putString("driverAgeCycleIndices", encodeIntMap(ageCycles))
            .putString("driverEvolutionAttributeGains_$season", annualGains.toSortedMap().entries.joinToString(";") { (id, a) -> "$id:${a.joinToString(",")}" })
            .putString("driverEvolutionPhaseGps", encodeIntMap(phaseGps))
            .putString("driverClassPerformance_$season", encodeDriverClassSeasonPerformance(classPerformance))
            .putString("driverEvolutionProcessedRounds_$season", encodeIntMap(processedRounds + (round to 1)))
            .putString(pendingDriverEvolutionNewsKey(season, round), changes.joinToString("\n") {
                java.util.Base64.getEncoder().encodeToString(it.toByteArray(Charsets.UTF_8))
            })
        check(evolutionCommit.commit()) {
            "Não foi possível persistir a evolução dos pilotos do GP $round/temporada $season"
        }
        flushPendingDriverEvolutionNews(season, round)
        return changes
    }

    /** Regression is now processed per GP by applyDriverRaceEvolution. Kept as a
     * compatibility entry point so old UI flows cannot apply a second annual loss. */
    fun applySeasonEndRegression(seasonToClose:Int): Int = 0

    fun startNewCareer(selectedTeamId: Int) {
        com.f1teammanager.core.manager.TechnicalInvestmentEngine.resetLiveOverallRegistry()
        // Every new career chooses its mode after this reset; never inherit Team Principal state.
        val teamPrincipalCleanup = prefs.edit()
            .remove("teamPrincipalCareer")
            .remove("teamPrincipalPendingTeamId")
            .remove("teamPrincipalPendingCareer")
            .putString("activeGameMode", "FREE")
            .putString("careerId", java.util.UUID.randomUUID().toString())
        prefs.all.keys.filter { it.startsWith("teamPrincipalHandoff_") }.forEach(teamPrincipalCleanup::remove)
        check(teamPrincipalCleanup.commit()) {
            "Não foi possível limpar o estado de carreira gerencial anterior."
        }
        teamId = selectedTeamId; roundIndex = 0; currentWeek = 1; season = 2026; hasCareer = true
        // Reuse the seed already used by the team selector so its performance
        // ranking remains identical when the career opens. This seed also draws
        // the career calendar and is persisted for reload consistency.
        val openingSeed = prefs.getInt("pendingCareerSeed", 0).let { pending ->
            if (pending != 0) pending else kotlin.random.Random.nextInt().let { if (it == 0) 1 else it }
        }
        val staleAnnualKeys = prefs.all.keys.filter { key ->
            key.startsWith("annualEventCalendar_") || key.startsWith("annualEventProcessed_") ||
                key.startsWith("annualEventSeed_") || key.startsWith("seasonStartEventSeen_") ||
                key.startsWith("seasonEndEventSeen_") || key.startsWith("carRegulationEventSeen_") ||
                key.startsWith("seasonCarRevealSnapshot_") || key.startsWith("seasonCarRevealSeen_") ||
                key.startsWith("carRegulationRule_") || key.startsWith("driverClassPerformance_") ||
                key == "driverClassProgressionReviewedSeason" || key == "driverClassSystemV649" ||
                key == "annualDriverClassOverrides"
        }
        if (staleAnnualKeys.isNotEmpty()) {
            val annualEditor = prefs.edit()
            staleAnnualKeys.forEach { annualEditor.remove(it) }
            check(annualEditor.commit()) { "Não foi possível limpar os eventos anuais da carreira anterior" }
        }
        val staleTransitionKeys = listOf("seasonTransitionPendingFrom", "seasonTransitionPendingTo", "seasonTransitionStage")
        check(prefs.edit().also { editor -> staleTransitionKeys.forEach(editor::remove) }.commit()) {
            "Não foi possível limpar o diário de virada da carreira anterior."
        }
        check(prefsSnapshot().edit().clear().commit()) {
            "Não foi possível limpar o snapshot da virada anterior."
        }
        prefs.edit().putInt("calendarSeed_$season", openingSeed)
            .putInt("openingCarSeed", openingSeed)
            .putInt("carRegulationSeed", openingSeed)
            .remove("pendingCareerSeed").apply()
        SeasonCalendar.configureSeasonSeed(season, openingSeed)
        InitialTeamProfile.configureCareerSeed(openingSeed)
        writeMap("driverPoints", emptyMap()); writeMap("constructorPoints", emptyMap())
        for (r in 1..SeasonCalendar.forSeason(season).size) prefs.edit().remove("race_$r").apply()
        history.clear()
        // A fresh career must not inherit any completed-GP ledger from the previous
        // save. Otherwise the same season/round keys can block its first races or
        // make the app recover a result belonging to the old team/career.
        val staleRaceKeys = prefs.all.keys.filter { key ->
            key.startsWith("race_finalize_") || key.startsWith("pending_race_result_") ||
                key.startsWith("race_result_acknowledged_") || key.startsWith("qualifyingBonusPaid_") ||
                key.startsWith("driverSalaryPaid_") || key.startsWith("driverEvolutionPendingNews_") ||
                Regex("race_20\\d{2}_\\d+").matches(key)
        }
        if (staleRaceKeys.isNotEmpty()) {
            val ledgerEditor = prefs.edit()
            staleRaceKeys.forEach { ledgerEditor.remove(it) }
            check(ledgerEditor.commit()) { "Não foi possível limpar os registros de corrida da carreira anterior" }
        }
        val staleEvolutionKeys = prefs.all.keys.filter { key ->
            key == "driverEvolutionAppliedSeason" || key == "driverRegressionAppliedSeason" ||
                key == "driverEvolutionPhases" || key == "driverEvolutionPhaseGps" ||
                key == "driverEvolutionPhaseStart" || key == "driverEvolutionPhaseTarget" ||
                key == "driverEvolutionPhasePressure" || key.startsWith("driverEvolutionBank_") ||
                key == "driverAgeDeclineBanks" || key == "driverAgePhysicalLosses" ||
                key == "driverAgePhysicalPeaks" || key == "driverAgeCycleIndices" ||
                key.startsWith("driverEvolutionAccumulated_") || key.startsWith("driverEvolutionAttributeGains_") ||
                key.startsWith("driverEvolutionProcessedRounds_") || key.startsWith("driverSeasonStartAttributes_") ||
                key.startsWith("driverSeasonStartClasses_")
        }
        if (staleEvolutionKeys.isNotEmpty()) {
            val editor = prefs.edit()
            staleEvolutionKeys.forEach(editor::remove)
            check(editor.commit()) { "Não foi possível limpar a evolução de pilotos da carreira anterior." }
        }
        val openingAttrs = WorldDatabase.allDrivers.associate { it.id to intArrayOf(it.speed,it.qualifying,it.overtaking,it.defense,it.consistency,it.wet,it.tyre) }
        val initialPhases = WorldDatabase.allDrivers.associate { it.id to DriverEvolutionEngine.initialPhase(it) }
        val initialEvolutionCommit = prefs.edit()
            .putString("driverEvolutionPhases", initialPhases.toSortedMap().entries.joinToString(";") { "${it.key}:${it.value}" })
            .putString("driverEvolutionPhaseGps", WorldDatabase.allDrivers.associate { it.id to 0 }.toSortedMap().entries.joinToString(",") { "${it.key}:${it.value}" })
            .putBoolean("driverClassSystemV649", true)
            .putInt("driverClassProgressionReviewedSeason", 0)
        check(initialEvolutionCommit.commit()) { "Não foi possível inicializar os estágios de carreira dos pilotos." }
        saveDriverAttributes(openingAttrs)
        saveSeasonStartDriverAttributes(season, openingAttrs)
        val t=WorldDatabase.teams.first { it.id==selectedTeamId }
        val initialCar = com.f1teammanager.core.manager.InitialTeamProfile.carState(t)
        val initialGarage = com.f1teammanager.core.manager.TeamGarageFactory.fromInitial(t, playerCareer = true)
        val initialFacilities = com.f1teammanager.core.manager.InitialTeamProfile.teamFacilities(t.initialLevel)
        val initialTechnical = com.f1teammanager.core.manager.TechnicalInvestmentEngine.forTeam(
            season, selectedTeamId, selectedTeamId, initialCar
        )
        val initialMarket = com.f1teammanager.core.manager.DriverMarketEngine().initialState(season)
        check(saveFreshCareerCore(
            selectedTeamId, initialCar, initialGarage, TeamResearchState(), TeamFactoryState(),
            initialTechnical, TeamFinanceState(com.f1teammanager.core.manager.InitialTeamProfile.initialBudget(t)),
            initialFacilities, com.f1teammanager.core.manager.DriverDevelopmentState(), emptyList(), initialMarket
        )) { "Não foi possível inicializar a carreira de forma atômica." }
        // Build driver-specific qualifying/race bands only after the fresh 80-driver
        // contract snapshot and the real opening car have been committed.
        initializeDriverSeasonTargets(initialCar)
        val freshCareerEditor = prefs.edit()
            .remove("aiTeamBudgets")
            .remove("aiFinanceSnapshot")
            .remove("aiSponsorshipSnapshot")
            .remove("annualEventCarStats_$selectedTeamId")
            .putInt("annualDriverSalarySeason_${selectedTeamId}",0)
        // Prize-ranking snapshots and paid-team summaries are career-specific. A new
        // career must not inherit a frozen ranking from an earlier save in the same year.
        prefs.all.keys.filter {
            it.startsWith("constructorPrizeRanking_") || it.startsWith("constructorPrizePaidTeams_")
        }.forEach { freshCareerEditor.remove(it) }
        check(freshCareerEditor.commit()) { "Não foi possível limpar os ledgers de premiação da carreira anterior." }
    }

    /** True after GP 30 has been archived, while the game is still on the completed season. */
    fun isSeasonEnded(): Boolean =
        roundIndex == SeasonCalendar.forSeason(season).lastIndex && history.isSeasonFinalized(season)

    /** Season-start and season-end presentation events are persisted independently per season. */
    fun hasSeenSeasonStartEvent(seasonNumber: Int = season): Boolean =
        prefs.getBoolean("seasonStartEventSeen_$seasonNumber", false)

    fun markSeasonStartEventSeen(seasonNumber: Int = season) {
        require(seasonNumber >= 1)
        check(prefs.edit().putBoolean("seasonStartEventSeen_$seasonNumber", true).commit()) {
            "Não foi possível salvar a apresentação de início da temporada $seasonNumber"
        }
    }

    fun shouldShowSeasonStartEvent(seasonNumber: Int = season): Boolean =
        hasCareer && currentWeek == 1 && roundIndex == 0 && !hasSeenSeasonStartEvent(seasonNumber)

    /** Persists the already-calculated new-car values; viewing the reveal never reruns the season engine. */
    fun saveSeasonCarRevealSnapshot(snapshot: com.f1teammanager.core.manager.SeasonCarRevealSnapshot) {
        val encoded = listOf(
            snapshot.season, snapshot.teamId, snapshot.startingOverall, snapshot.investmentOverall,
            snapshot.inheritedOverall, snapshot.finalOverall, snapshot.startingReliability,
            snapshot.finalReliability, snapshot.investmentAmount, snapshot.investmentSteps
        ).joinToString("|")
        check(prefs.edit().putString("seasonCarRevealSnapshot_${snapshot.season}", encoded).commit()) {
            "Não foi possível salvar a apresentação do carro da temporada ${snapshot.season}."
        }
    }

    fun loadSeasonCarRevealSnapshot(seasonNumber: Int = season): com.f1teammanager.core.manager.SeasonCarRevealSnapshot? = runCatching {
        val values = prefs.getString("seasonCarRevealSnapshot_$seasonNumber", null)?.split('|') ?: return null
        require(values.size == 10)
        com.f1teammanager.core.manager.SeasonCarRevealSnapshot(
            season = values[0].toInt(), teamId = values[1].toInt(),
            startingOverall = values[2].toInt(), investmentOverall = values[3].toInt(),
            inheritedOverall = values[4].toInt(), finalOverall = values[5].toInt(),
            startingReliability = values[6].toInt(), finalReliability = values[7].toInt(),
            investmentAmount = values[8].toLong(), investmentSteps = values[9].toInt()
        ).takeIf { it.season == seasonNumber }
    }.getOrNull()

    fun hasSeenSeasonCarRevealEvent(seasonNumber: Int = season): Boolean =
        prefs.getBoolean("seasonCarRevealSeen_$seasonNumber", false)

    fun markSeasonCarRevealEventSeen(seasonNumber: Int = season) {
        require(seasonNumber >= 1)
        check(prefs.edit().putBoolean("seasonCarRevealSeen_$seasonNumber", true).commit()) {
            "Não foi possível confirmar a apresentação do carro da temporada $seasonNumber."
        }
    }

    fun shouldShowSeasonCarRevealEvent(seasonNumber: Int = season): Boolean =
        hasCareer && currentWeek == 1 && roundIndex == 0 &&
            loadSeasonCarRevealSnapshot(seasonNumber) != null && !hasSeenSeasonCarRevealEvent(seasonNumber)

    /** Regulation presentation is shown before the season-start presentation, once per season. */
    fun hasSeenCarRegulationEvent(seasonNumber: Int = season): Boolean =
        prefs.getBoolean("carRegulationEventSeen_$seasonNumber", false)

    fun markCarRegulationEventSeen(seasonNumber: Int = season) {
        require(seasonNumber >= 1)
        check(prefs.edit().putBoolean("carRegulationEventSeen_$seasonNumber", true).commit()) {
            "Não foi possível salvar a apresentação do regulamento da temporada $seasonNumber"
        }
    }

    fun shouldShowCarRegulationEvent(seasonNumber: Int = season): Boolean {
        if (!hasCareer || currentWeek != 1 || roundIndex != 0 || hasSeenCarRegulationEvent(seasonNumber)) return false
        val rule = ensureCarRegulationRule(seasonNumber)
        return rule.annualEvents.isNotEmpty() || rule.decennialRevolution
    }

    fun hasSeenSeasonEndEvent(seasonNumber: Int = season): Boolean =
        prefs.getBoolean("seasonEndEventSeen_$seasonNumber", false)

    fun markSeasonEndEventSeen(seasonNumber: Int = season) {
        require(seasonNumber >= 1)
        check(prefs.edit().putBoolean("seasonEndEventSeen_$seasonNumber", true).commit()) {
            "Não foi possível salvar a retrospectiva da temporada $seasonNumber"
        }
    }

    fun shouldShowSeasonEndEvent(seasonNumber: Int = season): Boolean =
        isSeasonEnded() && !hasSeenSeasonEndEvent(seasonNumber)

    /**
     * Advance to the next GP after a completed race.
     * GP 30 is deliberately different: it only archives the season and leaves the
     * current year/round intact until the manager explicitly starts the next season.
     */
    fun completeCurrentRace() {
        if (roundIndex < SeasonCalendar.forSeason(season).lastIndex) {
            roundIndex += 1
            // Do NOT move currentWeek here. The completed GP happened in the current
            // week; the manager must return to the calendar and manually advance the
            // remaining free weeks until the next GP week.
        } else {
            history.finalizeSeason(season, driverPoints(), constructorPoints(), loadDriverMarket())
            // Stay on the completed season. No automatic year change here.
        }
    }

    /**
     * V427 durable season-transition journal. Stages are persisted synchronously so a
     * restart can identify an interrupted boundary instead of silently treating it as complete.
     * This journal deliberately does not claim to replay a partially committed transition;
     * callers must resume/repair it before allowing another transition.
     */
    private fun snapshotCareerForSeasonTransition(): Boolean {
        // SharedPreferences cannot copy its own map through Editor; use a dedicated file
        // so the recovery snapshot is committed independently before the journal starts.
        val snapshot = prefs.all
        val backupPrefs = prefsSnapshot()
        val editor = backupPrefs.edit().clear()
        snapshot.forEach { (key, value) ->
            when (value) {
                is String -> editor.putString(key, value)
                is Int -> editor.putInt(key, value)
                is Long -> editor.putLong(key, value)
                is Float -> editor.putFloat(key, value)
                is Boolean -> editor.putBoolean(key, value)
                is Set<*> -> editor.putStringSet(key, value.filterIsInstance<String>().toMutableSet())
            }
        }
        editor.putBoolean("__season_transition_snapshot_ready", true)
        return editor.commit()
    }

    private fun prefsSnapshot() = snapshotContext.getSharedPreferences(
        "f1tm_career_transition_backup", Context.MODE_PRIVATE
    )

    private val snapshotContext: Context get() = transitionContext

    private fun restoreCareerSeasonTransitionSnapshot(): Boolean {
        val backup = prefsSnapshot()
        if (!backup.getBoolean("__season_transition_snapshot_ready", false)) return false
        val editor = prefs.edit().clear()
        backup.all.forEach { (key, value) ->
            if (key == "__season_transition_snapshot_ready") return@forEach
            when (value) {
                is String -> editor.putString(key, value)
                is Int -> editor.putInt(key, value)
                is Long -> editor.putLong(key, value)
                is Float -> editor.putFloat(key, value)
                is Boolean -> editor.putBoolean(key, value)
                is Set<*> -> editor.putStringSet(key, value.filterIsInstance<String>().toMutableSet())
            }
        }
        return editor.commit()
    }

    fun beginSeasonTransitionJournal(fromSeason: Int): Int {
        val pendingFrom = prefs.getInt("seasonTransitionPendingFrom", 0)
        val pendingTo = prefs.getInt("seasonTransitionPendingTo", 0)
        if (pendingFrom != 0 && pendingTo != 0) {
            val stage = prefs.getString("seasonTransitionStage", "PREPARED") ?: "PREPARED"
            if (stage == "STATE_PERSISTED") return pendingTo
            // Any earlier checkpoint means some of the canonical keys may have been
            // written. Restore the pre-transition snapshot, then safely retry from the
            // archived season instead of replaying operations over a mixed state.
            check(restoreCareerSeasonTransitionSnapshot()) {
                "Virada interrompida sem snapshot íntegro. A carreira foi bloqueada para evitar corrupção de dados."
            }
            val restoredSeason = prefs.getInt("season", pendingFrom)
            require(restoredSeason == pendingFrom && isSeasonEnded()) {
                "O snapshot restaurado não corresponde à temporada encerrada."
            }
        }
        require(isSeasonEnded()) { "A temporada atual ainda não foi encerrada." }
        val sourceSeason = prefs.getInt("season", fromSeason)
        check(snapshotCareerForSeasonTransition()) { "Não foi possível salvar o snapshot de segurança da virada." }
        val target = sourceSeason + 1
        check(prefs.edit().putInt("seasonTransitionPendingFrom", sourceSeason)
            .putInt("seasonTransitionPendingTo", target)
            .putString("seasonTransitionStage", "PREPARED").commit()) {
            "Não foi possível gravar o diário da virada."
        }
        return target
    }

    private val seasonTransitionStages = listOf(
        "PREPARED", "SEASON_ADVANCED", "CAREER_RESET_DONE", "MANAGER_STATE_READY",
        "CAR_SAVED", "GARAGE_SAVED", "FACILITIES_SAVED", "TECHNICAL_INVESTMENT_SAVED",
        "RESEARCH_SAVED", "FACTORY_SAVED", "DRIVER_DEVELOPMENT_SAVED", "MARKET_SAVED",
        "FINANCE_SAVED", "SPONSORS_SAVED", "STATE_PERSISTED"
    )

    /**
     * Persist only a monotonic checkpoint. Repeating the current checkpoint is safe,
     * but skipping ahead or moving backwards would make crash recovery ambiguous.
     */
    fun markSeasonTransitionStage(stage: String): Boolean {
        val requestedIndex = seasonTransitionStages.indexOf(stage)
        require(requestedIndex >= 0) { "Etapa de virada inválida." }
        val current = prefs.getString("seasonTransitionStage", null) ?: return false
        val currentIndex = seasonTransitionStages.indexOf(current)
        if (currentIndex < 0 || requestedIndex < currentIndex || requestedIndex > currentIndex + 1) return false
        if (requestedIndex == currentIndex) return true
        return prefs.edit().putString("seasonTransitionStage", stage).commit()
    }

    fun pendingSeasonTransition(): Triple<Int, Int, String>? {
        val from = prefs.getInt("seasonTransitionPendingFrom", 0)
        val to = prefs.getInt("seasonTransitionPendingTo", 0)
        if (from == 0 || to == 0) return null
        return Triple(from, to, prefs.getString("seasonTransitionStage", "PREPARED") ?: "PREPARED")
    }

    /**
     * Roll back an interrupted transition to the exact pre-transition career snapshot.
     * This is only valid before STATE_PERSISTED; committed transitions must be finalized,
     * never rolled back after the durable commit point.
     */
    fun rollbackSeasonTransitionJournal(): Boolean {
        val pending = pendingSeasonTransition() ?: return true
        if (pending.third == "STATE_PERSISTED") return false
        if (!restoreCareerSeasonTransitionSnapshot()) return false
        // The restored career snapshot predates the journal, so it also removes its keys.
        // Clear the backup only after the career restore has committed successfully.
        return prefsSnapshot().edit().clear().commit()
    }

    fun completeSeasonTransitionJournal(): Boolean {
        // Remove the rollback image first. If this fails, the STATE_PERSISTED journal
        // remains available for a safe cleanup retry. If the process dies after this
        // commit, the canonical state is already complete and only journal cleanup remains.
        if (!prefsSnapshot().edit().clear().commit()) return false
        return prefs.edit().remove("seasonTransitionPendingFrom")
            .remove("seasonTransitionPendingTo").remove("seasonTransitionStage").commit()
    }

    /** Explicit player action: starts the archived season's successor. */
    fun startNextSeason() {
        require(isSeasonEnded()) { "A temporada atual ainda não foi encerrada." }
        if (isTeamPrincipalMode()) {
            require(TeamPrincipalCareerEngine.mayAdvanceWithContractDecision(teamPrincipalCareer())) {
                "Resolva sua avaliação contratual antes de iniciar a próxima temporada: renove com a equipe atual ou aceite uma proposta externa."
            }
        }
        val targetSeason = season + 1
        val pendingPrincipalOffer = pendingTeamPrincipalOffer()
            ?.takeIf { it.second.contractStartSeason == targetSeason }
        val targetTeamId = pendingPrincipalOffer?.first ?: teamId
        val activatedPrincipalMove = prefs.getInt("teamPrincipalAutoFillRosterSeason", 0) == targetSeason
        // An accepted move hands the incoming team's seat management over only at the
        // season boundary. Its roster is completed by the automatic offseason market below.
        val projectedRoster = projectedDriverRosterForSeason(targetSeason, targetTeamId)
        require(com.f1teammanager.core.manager.TeamPrincipalCareerEngine.mayAdvanceWithProjectedRoster(
            projectedRoster.size, acceptedHandoffForTargetSeason = pendingPrincipalOffer != null || activatedPrincipalMove
        )) {
            "Não é possível iniciar $targetSeason: sua equipe tem ${projectedRoster.size} piloto(s) confirmado(s). Conclua as contratações/renovações no Mercado de Pilotos. Nenhum dado foi alterado."
        }
        val previousSeason = season
        // Class promotion/relegation is reviewed only at this boundary and only from
        // two consecutive seasons of persisted GP performance evidence.
        val classChanges = reviewDriverClassesForCompletedSeason(previousSeason)
        // Preserve outgoing-season sporting context before the annual point maps are reset.
        // The driver market uses this snapshot to distinguish initial reputation from the
        // team that actually performed well in this career.
        val outgoingDriverPoints = driverPoints()
        val outgoingConstructorPoints = constructorPoints()
        val outgoingDriverAttributes = driverAttributes().mapValues { (_, values) -> values.toList() }
        season += 1
        // Keep fractional evolution progress across the season boundary while resetting
        // only the annual caps/idempotency records. Phase/career-cycle maps are persistent.
        val previousEvolutionBank = prefs.getString("driverEvolutionBank_$previousSeason", null)
        if (!previousEvolutionBank.isNullOrBlank()) {
            check(prefs.edit().putString("driverEvolutionBank_$season", previousEvolutionBank).commit()) {
                "Não foi possível transportar o progresso fracionário de evolução dos pilotos."
            }
        }
        roundIndex = 0
        currentWeek = 1
        // A new season gets a new 30/50 draw while remaining fixed for that season.
        newCalendarSeed(season)
        writeMap("driverPoints", emptyMap())
        writeMap("constructorPoints", emptyMap())
        for (r in 1..SeasonCalendar.forSeason(season).size) prefs.edit().remove("race_$r").apply()
        val staleEvolutionKeys = prefs.all.keys.filter { key ->
            key == "driverEvolutionAppliedSeason" || key == "driverRegressionAppliedSeason" ||
                key.startsWith("driverEvolutionAccumulated_") ||
                (key.startsWith("driverEvolutionAttributeGains_") && key != "driverEvolutionAttributeGains_$season") ||
                (key.startsWith("driverEvolutionProcessedRounds_") && key != "driverEvolutionProcessedRounds_$season") ||
                (key.startsWith("driverSeasonStartAttributes_") && key != "driverSeasonStartAttributes_$season") ||
                (key.startsWith("driverSeasonStartClasses_") && key != "driverSeasonStartClasses_$season")
        }
        if (staleEvolutionKeys.isNotEmpty()) {
            val editor = prefs.edit()
            staleEvolutionKeys.forEach(editor::remove)
            check(editor.commit()) { "Não foi possível limpar os registros anuais de evolução dos pilotos." }
        }
        // Retain only the performance-driven phase and fractional bank. No time-based
        // growth/peak/regression cycle is carried between seasons.
        saveSeasonStartDriverAttributes(season, driverAttributes())
        val nextCar = loadCar(teamId)
        saveTechnicalInvestment(teamId, com.f1teammanager.core.manager.TechnicalInvestmentEngine.forTeam(season, teamId, teamId, nextCar))
        val marketBudgets = WorldDatabase.teams.associate { marketTeam ->
            marketTeam.id to if (marketTeam.id == teamId) {
                loadFinance(teamId, TeamFinanceState(InitialTeamProfile.initialBudget(marketTeam))).budget
            } else {
                aiTeamBudget(marketTeam.id)
            }
        }
        loadDriverMarket()?.let { market ->
            val principalIncomingTeamNeedsRosterFill =
                prefs.getInt("teamPrincipalAutoFillRosterSeason", 0) == season
            val transitionedMarket = com.f1teammanager.core.manager.DriverMarketEngine().applySeasonTransition(
                market, season, marketBudgets, teamId, outgoingConstructorPoints, outgoingDriverAttributes, outgoingDriverPoints,
                automaticVacancyFillTeamIds = if (principalIncomingTeamNeedsRosterFill) setOf(teamId) else emptySet()
            )
            // A handoff must never deadlock on a financially distressed incoming team. The
            // offseason market gets the normal AI vacancy-fill attempt; if the market cannot
            // afford or persuade enough drivers, the season still advances and an explicit
            // notification tells the new principal to finish the roster manually.
            val marketReadyToCommit = if (principalIncomingTeamNeedsRosterFill) {
                val incomingRosterSize = com.f1teammanager.core.manager.DriverMarketEngine()
                    .roster(transitionedMarket, teamId, season = season).size
                if (incomingRosterSize < 2) {
                    val teamName = WorldDatabase.teams.firstOrNull { it.id == teamId }?.name ?: "equipe de destino"
                    transitionedMarket.copy(
                        notifications = transitionedMarket.notifications + com.f1teammanager.core.manager.MarketNotification(
                            season, 1, "ELENCO INCOMPLETO APÓS A TRANSFERÊNCIA",
                            "Você assumiu a $teamName com $incomingRosterSize piloto(s) confirmado(s). O mercado automático não conseguiu completar o elenco dentro das condições financeiras/contratuais. A temporada foi iniciada para evitar bloquear a carreira; abra o Mercado de Pilotos e complete as vagas antes de disputar o GP.",
                            true
                        )
                    ).normalized()
                } else transitionedMarket
            } else transitionedMarket
            val classNotifications = classChanges.map { change ->
                val title = if (change.direction == DriverClassProgressionEngine.Direction.PROMOTION)
                    "PROMOÇÃO DE CLASSE" else "REBAIXAMENTO DE CLASSE"
                val action = if (change.direction == DriverClassProgressionEngine.Direction.PROMOTION)
                    "promovido" else "rebaixado"
                MarketNotification(
                    season, 1, title,
                    "${change.driverName} foi $action de ${change.previousClass} para ${change.resultingClass} após duas temporadas de desempenho consistente (índice médio ${change.twoSeasonAverage.toInt()}).",
                    true, MarketNewsCategory.DRIVER_EVOLUTION
                )
            }
            val marketWithClassNews = if (classNotifications.isEmpty()) marketReadyToCommit else marketReadyToCommit.copy(
                notifications = (marketReadyToCommit.notifications + classNotifications).takeLast(1000)
            ).normalized()
            saveDriverMarket(marketWithClassNews)
            if (principalIncomingTeamNeedsRosterFill) {
                check(prefs.edit().remove("teamPrincipalAutoFillRosterSeason").commit()) {
                    "A equipe foi preparada, mas não foi possível encerrar o registro de integração do Team Principal."
                }
            }
        }
        // The contract transition may move the player to another team and alter the 80-driver
        // grid. Freeze new individual expectations only after the new car and contracts exist.
        initializeDriverSeasonTargets(nextCar)
    }

    /** Advance one or more real calendar weeks. Returns the number of weeks actually advanced. */
    fun advanceCalendarWeeks(weeks: Int): Int {
        val old = currentWeek
        currentWeek = (currentWeek + weeks.coerceAtLeast(0)).coerceAtMost(56)
        return currentWeek - old
    }

    fun jumpToWeek(week: Int): Int {
        val old = currentWeek
        currentWeek = week
        return currentWeek - old
    }

    /**
     * Serialize every durable career preference and the historical archive into one portable save.
     * Schema 3 added a checksum and required-system manifest. Schema 4 adds the complete
     * legacy-v2 plus V3 race/season-shard archive as a checksummed bundle.
     */
    fun exportCareerBackup(): org.json.JSONObject {
        check(hasCareer) { "Não existe uma carreira ativa para salvar." }
        check(pendingSeasonTransition() == null) {
            "A virada de temporada ainda está em andamento. Aguarde a conclusão antes de exportar o save."
        }
        check(!teamPrincipalOfferTransactionPrefs().getBoolean("__ready", false)) {
            "Há uma negociação interrompida que precisa ser recuperada antes de exportar o save."
        }
        check(activeWeekendCheckpoint() == null) {
            "Há um fim de semana de GP em andamento. Conclua a corrida ou retorne ao calendário antes de exportar o save."
        }
        val mode = activeGameMode()
        val careerId = careerSaveId()
        val values = encodePreferenceSnapshot(prefs.all)
        assertCompleteSystemSnapshot(values, teamId)

        // The full legacy v2 archive and every V3 race/season shard travel together.
        val historyBundle = history.exportArchiveBundle()
        val integrity = org.json.JSONObject()
            .put("preferenceCount", values.length())
            .put("preferenceSha256", preferenceSnapshotSha256(values))
            .put("historicalArchiveSha256", sha256Text(""))
            .put("historicalArchiveBundleSha256", historyBundleFingerprint(historyBundle))
            .put("systems", org.json.JSONArray(listOf(
                "car", "garage", "finance", "facilities", "research", "factory",
                "technicalInvestment", "driverDevelopment", "sponsors", "driverMarket",
                "driverAttributes", "raceAndSeasonHistory", "raceHistoryV3Shards"
            )))
        val payload = org.json.JSONObject()
            .put("format", "F1TM_SAVE")
            .put("schema", 4)
            .put("mode", mode)
            .put("careerId", careerId)
            .put("teamId", teamId)
            .put("season", season)
            .put("createdAt", System.currentTimeMillis())
            .put("preferences", values)
            .put("historicalArchive", "") // retained for schema-1..3 compatibility
            .put("historicalArchiveBundle", historyBundle)
            .put("integrity", integrity)

        inspectCareerBackup(payload)
        return payload
    }

    /** Serialize all Android SharedPreferences types with deterministic set ordering. */
    private fun encodePreferenceSnapshot(source: Map<String, *>): org.json.JSONObject {
        val values = org.json.JSONObject()
        source.toSortedMap().forEach { (key, value) ->
            val item = org.json.JSONObject()
            when (value) {
                is String -> item.put("type", "string").put("value", value)
                is Int -> item.put("type", "int").put("value", value)
                is Long -> item.put("type", "long").put("value", value)
                is Float -> item.put("type", "float").put("value", value.toDouble())
                is Boolean -> item.put("type", "boolean").put("value", value)
                is Set<*> -> item.put("type", "set").put("value", org.json.JSONArray(value.filterIsInstance<String>().sorted()))
                else -> error("Tipo de preferência não suportado no save: $key (${value?.javaClass?.simpleName ?: "null"}).")
            }
            values.put(key, item)
        }
        return values
    }

    /** Canonical digest: independent of JSON key order and SharedPreferences set iteration order. */
    private fun preferenceSnapshotSha256(values: org.json.JSONObject): String {
        val canonical = StringBuilder()
        fun token(value: String) { canonical.append(value.length).append(':').append(value).append('|') }
        values.keys().asSequence().toList().sorted().forEach { key ->
            val item = values.optJSONObject(key) ?: error("Preferência inválida no snapshot: $key")
            val type = item.optString("type")
            val raw = item.opt("value")
            val normalized = when (type) {
                "string" -> raw as? String ?: error("Valor textual inválido no save: $key")
                "int" -> (raw as? Number)?.toInt()?.toString() ?: error("Valor inteiro inválido no save: $key")
                "long" -> (raw as? Number)?.toLong()?.toString() ?: error("Valor longo inválido no save: $key")
                "float" -> (raw as? Number)?.toFloat()?.toBits()?.toString() ?: error("Valor decimal inválido no save: $key")
                "boolean" -> raw as? Boolean ?: error("Valor lógico inválido no save: $key")
                "set" -> {
                    val array = raw as? org.json.JSONArray ?: error("Conjunto inválido no save: $key")
                    (0 until array.length()).map { array.getString(it) }.sorted()
                        .joinToString("") { value -> "${value.length}:$value;" }
                }
                else -> error("Tipo de dado desconhecido no backup: $key")
            }
            token(key); token(type); token(normalized.toString())
        }
        return sha256Text(canonical.toString())
    }

    private fun sha256Text(value: String): String = java.security.MessageDigest.getInstance("SHA-256")
        .digest(value.toByteArray(Charsets.UTF_8))
        .joinToString("") { byte -> (byte.toInt() and 0xff).toString(16).padStart(2, '0') }

    /** Confirm that the backup actually contains the canonical state for every core game system. */
    private fun assertCompleteSystemSnapshot(values: org.json.JSONObject, expectedTeamId: Int, requireCurrentIdentity: Boolean = true) {
        val teamMarkers = listOf(
            "carTeam" to "carro", "garageTeam" to "garagem", "financeTeam" to "finanças",
            "facilitiesTeam" to "instalações", "researchTeam" to "P&D", "factoryTeam" to "fábrica",
            "driverDevelopmentTeam" to "desenvolvimento de pilotos", "sponsorTeam" to "patrocínios"
        )
        teamMarkers.forEach { (key, label) ->
            val item = values.optJSONObject(key) ?: error("Save incompleto: estado de $label ausente ($key).")
            require(item.optString("type") == "int" && (item.opt("value") as? Number)?.toInt() == expectedTeamId) {
                "Save incompleto: o estado de $label não corresponde à equipe $expectedTeamId."
            }
        }
        val requiredStrings = listOf(
            "carAero", "carChassis", "carEngine", "carReliability", "carFrontWing", "carRearWing", "carBrakes", "carErs",
            "budget", "seasonIncome", "seasonExpenses", "financeTransactions", "signatureFeeSchedules", "salaryPaidRounds",
            "salaryOutstanding", "raceSettlementKeys", "facilityMaintenanceWeeks", "facilityMaintenanceOutstanding", "commercialRevenueWeeks",
            "facilities", "researchDesigns", "researchCooldowns", "factoryOrders", "factoryPendingInstallations",
            "g1Installed", "g2Installed", "g1Reliability", "g2Reliability",
            "g1Engine", "g1Chassis", "g1FrontWing", "g1RearWing", "g1Brakes", "g1Electric",
            "g2Engine", "g2Chassis", "g2FrontWing", "g2RearWing", "g2Brakes", "g2Electric",
            "driverDevelopmentPrograms", "driverDevelopmentReserve", "driverAttributes",
            "marketContracts", "marketFree", "marketScheduled", "marketRoles", "marketPending", "marketScouting",
            "marketNotifications", "marketRenewalEvaluations", "developmentKnowledge",
            "technicalInvestment_$expectedTeamId", "roundIndex", "currentWeek"
        )
        val integerKeys = setOf(
            "carAero", "carChassis", "carEngine", "carReliability", "carFrontWing", "carRearWing", "carBrakes", "carErs",
            "g1Reliability", "g2Reliability", "g1Engine", "g1Chassis", "g1FrontWing", "g1RearWing", "g1Brakes", "g1Electric",
            "g2Engine", "g2Chassis", "g2FrontWing", "g2RearWing", "g2Brakes", "g2Electric",
            "roundIndex", "currentWeek", "openingCarSeed"
        )
        val requiredReliabilityKeys = listOf("g1", "g2").flatMap { prefix ->
            listOf("ENGINE", "CHASSIS", "FRONT_WING", "REAR_WING", "BRAKES", "ELECTRIC_POWER_UNIT")
                .map { "${prefix}Rel_$it" }
        }
        (requiredReliabilityKeys + listOf("g1Version_ENGINE", "g1Version_CHASSIS", "g1Version_FRONT_WING", "g1Version_REAR_WING", "g1Version_BRAKES", "g1Version_ELECTRIC_POWER_UNIT", "g2Version_ENGINE", "g2Version_CHASSIS", "g2Version_FRONT_WING", "g2Version_REAR_WING", "g2Version_BRAKES", "g2Version_ELECTRIC_POWER_UNIT"))
            .forEach { key ->
                val item = values.optJSONObject(key)
                // Reliability is required for every component. Version markers are required only when a piece is installed.
                val isReliability = "Rel_" in key
                if (isReliability) require(item?.optString("type") == "int") { "Save incompleto: confiabilidade de peça ausente ($key)." }
                else if (item != null) require(item.optString("type") == "int") { "Save incompleto: versão de peça inválida ($key)." }
            }
        val numericFinanceKeys = setOf("budget", "seasonIncome", "seasonExpenses")
        requiredStrings.forEach { key ->
            val item = values.optJSONObject(key) ?: error("Save incompleto: dado obrigatório ausente ($key).")
            val type = item.optString("type")
            when {
                key in integerKeys -> require(type == "int" || (key == "openingCarSeed" && type == "long")) {
                    "Save incompleto: valor numérico inválido ($key)."
                }
                key in numericFinanceKeys -> require(type in setOf("long", "int")) {
                    "Save incompleto: dado financeiro inválido ($key)."
                }
                else -> require(type == "string") { "Save incompleto: dado textual inválido ($key)." }
            }
        }
        // Empty research queues and annual-event performance snapshots are valid states;
        // when present, they still must retain the expected serialized types.
        listOf("researchActiveProjects", "annualEventCarStats_$expectedTeamId").forEach { key ->
            val item = values.optJSONObject(key)
            if (item != null) require(item.optString("type") == "string") {
                "Save incompleto: dado opcional inválido ($key)."
            }
        }
        if (requireCurrentIdentity) {
            listOf("openingCarSeed" to "int", "careerId" to "string", "activeGameMode" to "string").forEach { (key, type) ->
                val item = values.optJSONObject(key) ?: error("Save incompleto: identidade da carreira ausente ($key).")
                require(item.optString("type") == type) { "Save incompleto: identidade da carreira inválida ($key)." }
            }
        }
    }

    /** Infer the mode of older schema-1 saves without touching the active career. */
    private fun resolveBackupMode(values: org.json.JSONObject): String {
        val modeItem = values.optJSONObject("activeGameMode")
        val storedMode = if (modeItem != null && modeItem.optString("type") == "string") {
            modeItem.optString("value").takeIf { it.isNotBlank() }
        } else null
        if (storedMode != null) {
            require(storedMode in setOf("FREE", "HARD", "TEAM_PRINCIPAL")) { "Modo de jogo inválido no save." }
            return storedMode
        }
        val principalRaw = values.optJSONObject("teamPrincipalCareer")?.optString("value").orEmpty()
        return if (principalRaw.isNotBlank()) "TEAM_PRINCIPAL" else "FREE"
    }

    /** Full validation is shared by import and the save-list preview; it never mutates live state. */
    private fun historyBundleFingerprint(bundle: org.json.JSONObject): String {
        val files = bundle.optJSONArray("files") ?: error("Backup sem lista de arquivos históricos.")
        val canonical = (0 until files.length()).map { files.getJSONObject(it) }
            .sortedBy { it.getString("path") }
            .joinToString("\n") { "${it.getString("path")}:${it.getString("sha256")}" }
        return sha256Text("${bundle.optInt("version")}|${files.length()}|$canonical")
    }

    fun inspectCareerBackup(payload: org.json.JSONObject): CareerSaveMetadata {
        require(payload.optString("format") == "F1TM_SAVE") { "Formato de save não reconhecido." }
        val schema = payload.optInt("schema", -1)
        require(schema in 1..4) { "Versão de save não compatível." }
        val values = payload.optJSONObject("preferences") ?: error("Backup sem preferências da carreira.")
        require(values.has("hasCareer") && values.has("teamId") && values.has("season")) { "Backup incompleto." }

        fun prefValue(key: String): Pair<String, Any?> {
            val item = values.optJSONObject(key) ?: error("Campo obrigatório ausente: $key")
            val type = item.optString("type")
            val value = item.opt("value")
            when (type) {
                "string" -> require(value is String) { "Campo $key inválido." }
                "int" -> require(value is Number) { "Campo $key inválido." }
                "long", "float" -> require(value is Number) { "Campo $key inválido." }
                "boolean" -> require(value is Boolean) { "Campo $key inválido." }
                "set" -> require(value is org.json.JSONArray) { "Campo $key inválido." }
                else -> error("Tipo de dado desconhecido no backup: $key")
            }
            return type to value
        }
        val hasCareer = prefValue("hasCareer").second as Boolean
        require(hasCareer) { "O arquivo não contém uma carreira ativa." }
        val team = (prefValue("teamId").second as Number).toInt()
        val year = (prefValue("season").second as Number).toInt()
        require(WorldDatabase.teams.any { it.id == team } && year in 2026..2200) { "Equipe ou temporada inválida." }
        val transitionFrom = values.optJSONObject("seasonTransitionPendingFrom")?.opt("value") as? Number
        val transitionTo = values.optJSONObject("seasonTransitionPendingTo")?.opt("value") as? Number
        require((transitionFrom?.toInt() ?: 0) == 0 && (transitionTo?.toInt() ?: 0) == 0) {
            "Este save foi capturado durante uma virada de temporada incompleta. Conclua a virada e exporte novamente."
        }
        val mode = resolveBackupMode(values)
        val principalRaw = values.optJSONObject("teamPrincipalCareer")?.optString("value").orEmpty()
        val pendingPrincipalRaw = values.optJSONObject("teamPrincipalPendingCareer")?.optString("value").orEmpty()
        val pendingPrincipalTeam = values.optJSONObject("teamPrincipalPendingTeamId")?.opt("value")
        if (mode == "TEAM_PRINCIPAL") {
            val principal = TeamPrincipalCareerState.decode(principalRaw)
                ?: error("Save marcado como Time Principal, mas os dados da carreira gerencial estão ausentes ou inválidos.")
            require(principal.teamId == team) { "A equipe ativa não corresponde à carreira Time Principal do save." }
            if (pendingPrincipalRaw.isNotBlank()) {
                val pendingState = TeamPrincipalCareerState.decode(pendingPrincipalRaw)
                    ?: error("A proposta de mudança de equipe do Time Principal está corrompida.")
                require(pendingPrincipalTeam is Number) { "A proposta pendente não contém a equipe de destino." }
                require(pendingState.teamId == (pendingPrincipalTeam as Number).toInt()) {
                    "A equipe de destino não corresponde à proposta pendente do Time Principal."
                }
            } else {
                require(pendingPrincipalTeam == null) { "O save contém uma equipe pendente sem contrato correspondente." }
            }
        } else {
            require(principalRaw.isBlank() && pendingPrincipalRaw.isBlank() && pendingPrincipalTeam == null) {
                "O save contém dados de Time Principal incompatíveis com o modo ${if (mode == "HARD") "Difícil" else "Livre"}."
            }
            require(values.keys().asSequence().none { it.startsWith("teamPrincipalHandoff_") && values.optJSONObject(it)?.optString("value").orEmpty().isNotBlank() }) {
                "O save contém handoffs de Time Principal em um modo diferente."
            }
        }

        val topTeam = payload.optInt("teamId", team)
        val topSeason = payload.optInt("season", year)
        require(topTeam == team && topSeason == year) { "Os metadados do save não correspondem à carreira salva." }
        val topMode = payload.optString("mode", "")
        if (schema >= 2) {
            val modeItem = values.optJSONObject("activeGameMode")
            require(modeItem != null && modeItem.optString("type") == "string" && modeItem.optString("value") == mode) {
                "O save não contém um marcador interno de modo válido."
            }
            require(topMode in setOf("FREE", "HARD", "TEAM_PRINCIPAL") && topMode == mode) {
                "O modo declarado no arquivo não corresponde aos dados internos da carreira."
            }
        } else if (topMode.isNotBlank()) require(topMode == mode) { "O modo declarado no arquivo não corresponde à carreira." }

        // Validate every serialized preference type before the active save can be replaced.
        val keys = values.keys()
        while (keys.hasNext()) prefValue(keys.next())
        // Legacy schema 1/2 files are still accepted only when their active-team systems are complete.
        // That prevents a valid-looking partial JSON from silently restoring default finances/parts.
        assertCompleteSystemSnapshot(values, team, requireCurrentIdentity = schema >= 2)
        val archive = payload.optString("historicalArchive", "")
        if (archive.isNotBlank()) {
            val bytes = android.util.Base64.decode(archive, android.util.Base64.DEFAULT)
            require(bytes.isNotEmpty()) { "O histórico do save está vazio ou inválido." }
        }
        if (schema >= 3) {
            val integrity = payload.optJSONObject("integrity") ?: error("Save V3 sem manifesto de integridade.")
            require(integrity.optInt("preferenceCount", -1) == values.length()) {
                "Save incompleto: a quantidade de preferências não corresponde ao manifesto."
            }
            require(integrity.optString("preferenceSha256") == preferenceSnapshotSha256(values)) {
                "Save corrompido: a verificação SHA-256 dos dados da carreira falhou."
            }
            require(integrity.optString("historicalArchiveSha256") == sha256Text(archive)) {
                "Save corrompido: a verificação SHA-256 do histórico falhou."
            }
            val systems = integrity.optJSONArray("systems") ?: error("Save sem inventário de sistemas.")
            val declared = (0 until systems.length()).map { systems.getString(it) }.toSet()
            val requiredSystems = setOf("car", "garage", "finance", "facilities", "research", "factory", "technicalInvestment", "driverDevelopment", "sponsors", "driverMarket", "driverAttributes", "raceAndSeasonHistory")
            require(declared.containsAll(requiredSystems)) { "Save incompleto: o manifesto não declara todos os sistemas de carreira." }
            if (schema >= 4) {
                val bundle = payload.optJSONObject("historicalArchiveBundle")
                    ?: error("Save V4 sem o arquivo histórico completo.")
                require(history.validateArchiveBundle(bundle)) {
                    "Save corrompido: o pacote de histórico contém arquivos inválidos."
                }
                require(integrity.optString("historicalArchiveBundleSha256") == historyBundleFingerprint(bundle)) {
                    "Save corrompido: a verificação SHA-256 do histórico completo falhou."
                }
                require("raceHistoryV3Shards" in declared) {
                    "Save incompleto: o manifesto não declara os arquivos históricos V3."
                }
            }
        }
        val preferenceCareerId = values.optJSONObject("careerId")?.takeIf { it.optString("type") == "string" }?.optString("value").orEmpty()
        val topCareerId = payload.optString("careerId", "")
        val rawCareerId = topCareerId.ifBlank { preferenceCareerId }
        if (schema >= 2) {
            require(rawCareerId.isNotBlank() && preferenceCareerId.isNotBlank()) { "O save não possui identificador de carreira." }
            require(topCareerId == preferenceCareerId) { "O identificador externo não corresponde à carreira salva." }
        }
        return CareerSaveMetadata(
            mode = mode,
            teamId = team,
            season = year,
            careerId = rawCareerId.ifBlank {
                java.util.UUID.nameUUIDFromBytes(payload.toString().toByteArray(Charsets.UTF_8)).toString()
            },
            schema = schema
        )
    }

    private fun readCareerImportJournal(): Pair<String, org.json.JSONObject>? {
        if (!careerImportJournalFile.exists() && !File(careerImportJournalFile.path + ".bak").exists()) return null
        val raw = careerImportJournalAtomic.openRead().bufferedReader(Charsets.UTF_8).use { it.readText() }
        val separator = raw.indexOf('\n')
        require(separator > 0 && separator < raw.lastIndex) { "Diário de importação de carreira inválido." }
        val status = raw.substring(0, separator)
        require(status == "PREPARED" || status == "COMMITTED") { "Estado desconhecido no diário de importação." }
        return status to org.json.JSONObject(raw.substring(separator + 1))
    }

    /** The history store reads only this first line to honor the same commit point. */
    private fun writeCareerImportJournal(status: String, oldPreferences: org.json.JSONObject) {
        require(status == "PREPARED" || status == "COMMITTED")
        val output = careerImportJournalAtomic.startWrite()
        try {
            output.write((status + "\n" + oldPreferences.toString()).toByteArray(Charsets.UTF_8))
            careerImportJournalAtomic.finishWrite(output)
        } catch (failure: Throwable) {
            careerImportJournalAtomic.failWrite(output)
            throw failure
        }
    }

    private fun restorePreferenceSnapshot(snapshot: org.json.JSONObject) {
        val editor = prefs.edit().clear()
        val keys = snapshot.keys()
        while (keys.hasNext()) {
            val key = keys.next()
            val item = snapshot.getJSONObject(key)
            val value = item.opt("value")
            when (item.optString("type")) {
                "string" -> editor.putString(key, value as String)
                "int" -> editor.putInt(key, (value as Number).toInt())
                "long" -> editor.putLong(key, (value as Number).toLong())
                "float" -> editor.putFloat(key, (value as Number).toFloat())
                "boolean" -> editor.putBoolean(key, value as Boolean)
                "set" -> {
                    val array = value as org.json.JSONArray
                    editor.putStringSet(key, (0 until array.length()).map { array.getString(it) }.toMutableSet())
                }
                else -> error("Tipo inválido no snapshot anterior da carreira: $key")
            }
        }
        check(editor.commit()) { "Não foi possível restaurar as preferências anteriores da carreira." }
    }

    private fun deleteCareerImportJournal() {
        careerImportJournalAtomic.delete()
    }

    private fun recoverInterruptedCareerImportTransaction() {
        val journal = readCareerImportJournal() ?: return
        when (journal.first) {
            "PREPARED" -> {
                restorePreferenceSnapshot(journal.second)
                check(history.rollbackArchiveBundleReplacement()) {
                    "Não foi possível recuperar o histórico anterior à importação interrompida."
                }
            }
            "COMMITTED" -> {
                // HistoricalDatabase has already kept the new archive and cleaned its
                // staged marker during construction. Finish only auxiliary cleanup.
                history.finalizeArchiveBundleReplacement()
                check(teamPrincipalOfferTransactionPrefs().edit().clear().commit()) {
                    "Não foi possível concluir a limpeza da transação de ofertas após importação."
                }
                check(prefsSnapshot().edit().clear().commit()) {
                    "Não foi possível concluir a limpeza do snapshot anterior após importação."
                }
            }
        }
        deleteCareerImportJournal()
    }

    /** Validates the complete payload before replacing live preferences or the historical archive. */
    fun importCareerBackup(payload: org.json.JSONObject): Boolean {
        val metadata = inspectCareerBackup(payload)
        val values = payload.getJSONObject("preferences")
        val editor = prefs.edit().clear()
        val keys = values.keys()
        while (keys.hasNext()) {
            val key = keys.next(); val item = values.getJSONObject(key); val value = item.opt("value")
            when (item.optString("type")) {
                "string" -> editor.putString(key, value as String)
                "int" -> editor.putInt(key, (value as Number).toInt())
                "long" -> editor.putLong(key, (value as Number).toLong())
                "float" -> editor.putFloat(key, (value as Number).toFloat())
                "boolean" -> editor.putBoolean(key, value as Boolean)
                "set" -> {
                    val array = value as org.json.JSONArray
                    editor.putStringSet(key, (0 until array.length()).map { array.getString(it) }.toMutableSet())
                }
                else -> error("Tipo de dado desconhecido no backup.")
            }
        }
        // Normalize legacy saves into the explicit mode/identity model during import.
        editor.putString("activeGameMode", metadata.mode)
            .putString("careerId", metadata.careerId)
        val archiveText = payload.optString("historicalArchive", "")
        val archiveBytes = if (archiveText.isNotBlank()) android.util.Base64.decode(archiveText, android.util.Base64.DEFAULT) else byteArrayOf()
        val importedHistoryBundle = if (metadata.schema >= 4) {
            payload.getJSONObject("historicalArchiveBundle")
        } else {
            // Legacy backups only knew the v2 archive. Restore exactly that archive
            // and clear local V3 shards instead of mixing history from another career.
            history.legacyOnlyArchiveBundle(archiveBytes)
        }

        val oldPreferences = encodePreferenceSnapshot(prefs.all)
        val offerBackupPrefs = teamPrincipalOfferTransactionPrefs()
        val transitionBackupPrefs = prefsSnapshot()
        // Write PREPARED before changing either preferences or archive. The archive
        // store reads the same marker during construction, giving both stores one
        // process-death recovery decision instead of independent partial rollbacks.
        writeCareerImportJournal("PREPARED", oldPreferences)
        try {
            check(editor.commit()) { "Não foi possível gravar a carreira importada." }
            history.replaceArchiveBundle(importedHistoryBundle, deferCommit = true)
            val restoredSnapshot = encodePreferenceSnapshot(prefs.all)
            // Schema 1 predates stable career identity/mode markers. The importer normalizes
            // those two values; compare against that normalized expected snapshot, while
            // requiring every other persisted field to survive the round trip unchanged.
            val expectedSnapshot = org.json.JSONObject(values.toString())
                .put("activeGameMode", org.json.JSONObject().put("type", "string").put("value", metadata.mode))
                .put("careerId", org.json.JSONObject().put("type", "string").put("value", metadata.careerId))
            check(preferenceSnapshotSha256(restoredSnapshot) == preferenceSnapshotSha256(expectedSnapshot)) {
                "A verificação após importação falhou: nem todos os dados persistidos foram restaurados."
            }
            val restoredHistoryBundle = history.exportArchiveBundle()
            check(historyBundleFingerprint(restoredHistoryBundle) == historyBundleFingerprint(importedHistoryBundle)) {
                "A verificação após importação falhou: o histórico completo restaurado não corresponde ao save."
            }

            // This atomic status flip is the single commit point for both stores.
            writeCareerImportJournal("COMMITTED", oldPreferences)
            history.finalizeArchiveBundleReplacement()
            check(offerBackupPrefs.edit().clear().commit()) {
                "Não foi possível limpar uma transação local antiga após importar a carreira."
            }
            check(transitionBackupPrefs.edit().clear().commit()) {
                "Não foi possível limpar um snapshot local antigo após importar a carreira."
            }
            deleteCareerImportJournal()
        } catch (failure: Throwable) {
            if (runCatching { readCareerImportJournal()?.first == "COMMITTED" }.getOrDefault(false)) {
                // The commit point has passed. Keep the new career/archive; startup
                // will finish any cleanup still protected by the COMMITTED journal.
                runCatching { history.finalizeArchiveBundleReplacement() }
                runCatching { offerBackupPrefs.edit().clear().commit() }
                runCatching { transitionBackupPrefs.edit().clear().commit() }
                return true
            }
            val rollbackResult = runCatching {
                restorePreferenceSnapshot(oldPreferences)
                check(history.rollbackArchiveBundleReplacement()) {
                    "Não foi possível restaurar o histórico anterior após falha na importação."
                }
            }
            rollbackResult.onSuccess {
                runCatching { deleteCareerImportJournal() }
            }.onFailure { rollbackFailure -> failure.addSuppressed(rollbackFailure) }
            throw failure
        }
        // A V648-or-earlier backup may be imported while this CareerPreferences
        // instance is already alive. Apply the same one-time V649 migration now;
        // waiting for the next process start would expose incompatible Overalls.
        if (prefs.getBoolean("hasCareer", false) && !prefs.getBoolean("driverClassSystemV649", false)) {
            migrateDriverClassSystemV649()
        }
        return true
    }

}
private object WorldTeamResolver { fun teamIdFor(driverId: Int): Int = ((driverId - 1) / 2) + 1 }
