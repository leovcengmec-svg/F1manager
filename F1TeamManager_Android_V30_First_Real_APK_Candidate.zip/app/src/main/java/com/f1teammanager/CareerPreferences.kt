package com.f1teammanager

import android.content.Context
import com.f1teammanager.core.manager.DevelopmentProject
import com.f1teammanager.core.manager.DevelopmentIntensity
import com.f1teammanager.core.manager.CarComponent
import com.f1teammanager.core.manager.CarDevelopmentFocus
import com.f1teammanager.core.manager.TeamCarState
import com.f1teammanager.core.manager.TeamFinanceState
import com.f1teammanager.core.manager.SponsorContract
import com.f1teammanager.core.race.RaceResult
import com.f1teammanager.core.race.QualifyingResult
import com.f1teammanager.core.season.RoundDefinition
import com.f1teammanager.core.race.Tyre
import com.f1teammanager.core.season.WorldDatabase

/** Persistent career metadata, championship ledger, race archive and car P&D state. */
class CareerPreferences(context: Context) {
    val history = HistoricalDatabase(context)
    private val prefs = context.getSharedPreferences("f1tm_career", Context.MODE_PRIVATE)

    var hasCareer: Boolean
        get() = prefs.getBoolean("hasCareer", false)
        private set(value) = prefs.edit().putBoolean("hasCareer", value).apply()
    var teamId: Int
        get() = prefs.getInt("teamId", 1)
        private set(value) = prefs.edit().putInt("teamId", value).apply()
    var roundIndex: Int
        get() = prefs.getInt("roundIndex", 0)
        private set(value) = prefs.edit().putInt("roundIndex", value.coerceIn(0, WorldDatabase.rounds.lastIndex)).apply()
    /** Current calendar week. Race weekends occupy specific weeks; the other weeks are free development weeks. */
    var currentWeek: Int
        get() = prefs.getInt("currentWeek", WorldDatabase.rounds.first().weekOfSeason.coerceAtLeast(1) - 2).coerceIn(1, 56)
        private set(value) = prefs.edit().putInt("currentWeek", value.coerceIn(1, 56)).apply()
    var season: Int
        get() = prefs.getInt("season", 2026)
        private set(value) = prefs.edit().putInt("season", value).apply()

    private fun readMap(key: String): Map<Int, Int> = prefs.getString(key, "").orEmpty().split(',').mapNotNull { token ->
        val p = token.split(':')
        if (p.size == 2) p[0].toIntOrNull()?.let { id -> p[1].toIntOrNull()?.let { value -> id to value } } else null
    }.toMap()
    private fun writeMap(key: String, value: Map<Int, Int>) = prefs.edit().putString(key, value.entries.sortedBy { it.key }.joinToString(",") { "${it.key}:${it.value}" }).apply()
    fun driverPoints(): Map<Int, Int> = readMap("driverPoints")
    fun constructorPoints(): Map<Int, Int> = readMap("constructorPoints")

    fun recordRace(round: Int, result: RaceResult, seasonRound: RoundDefinition? = null, qualifying: QualifyingResult? = null) {
        val drivers = driverPoints().toMutableMap()
        result.points.forEach { (id, pts) -> drivers[id] = (drivers[id] ?: 0) + pts }
        writeMap("driverPoints", drivers)
        val teams = constructorPoints().toMutableMap()
        result.classification.forEach { f ->
            val tid = WorldTeamResolver.teamIdFor(f.driverId)
            teams[tid] = (teams[tid] ?: 0) + (result.points[f.driverId] ?: 0)
        }
        writeMap("constructorPoints", teams)
        val encoded = result.classification.joinToString(";") { f ->
            listOf(f.position, f.driverId, f.laps, f.totalTimeMs, f.status.replace(";", ","), f.tyre.name, f.pitStops, result.points[f.driverId] ?: 0).joinToString(",")
        }
        prefs.edit().putString("race_$round", encoded).apply()
        if (seasonRound != null) {
            history.recordRace(season, seasonRound, result, qualifying)
            // The season archive is created immediately when GP 30 finishes.
            // Returning to the calendar later must not be required to create history.
            if (seasonRound.round == WorldDatabase.rounds.size) {
                history.finalizeSeason(season, drivers, teams)
            }
        }
    }

    fun raceHistory(round: Int): RaceResult? = runCatching {
        val raw = prefs.getString("race_$round", null) ?: return null
        val classification = raw.split(';').filter { it.isNotBlank() }.map { row ->
            val p = row.split(',')
            val id = p[1].toInt()
            val driver = WorldDatabase.drivers.first { it.id == id }
            val team = WorldDatabase.teams.first { it.id == driver.teamId }
            FinishEntryCompat(p[0].toInt(), id, driver.name, team.name, p[2].toInt(), p[3].toLong(), p[4], Tyre.valueOf(p[5]), p[6].toInt())
        }
        val points = raw.split(';').filter { it.isNotBlank() }.associate { row -> val p=row.split(','); p[1].toInt() to p[7].toInt() }
        RaceResult(classification.map { it.toFinish() }, emptyList(), null, com.f1teammanager.core.race.Weather.DRY, points, 0, 0)
    }.getOrNull()

    private data class FinishEntryCompat(val position:Int,val driverId:Int,val driverName:String,val teamName:String,val laps:Int,val totalTimeMs:Long,val status:String,val tyre:Tyre,val pitStops:Int) {
        fun toFinish() = com.f1teammanager.core.race.FinishEntry(position,driverId,driverName,teamName,laps,totalTimeMs,status,tyre,pitStops)
    }

    fun loadCar(forTeamId: Int): TeamCarState? = runCatching {
        if (prefs.getInt("carTeam", -1) != forTeamId) return null
        TeamCarState(
            aerodynamics=prefs.getInt("carAero", 70), chassis=prefs.getInt("carChassis",70), engine=prefs.getInt("carEngine",70), reliability=prefs.getInt("carReliability",70),
            frontWing=prefs.getInt("carFrontWing",70), rearWing=prefs.getInt("carRearWing",70), brakes=prefs.getInt("carBrakes",70), electricPowerUnit=prefs.getInt("carErs",70),
            activeProject=if (prefs.getString("projectComponent", null) != null) DevelopmentProject(
                CarComponent.valueOf(prefs.getString("projectComponent", "ENGINE")!!),
                prefs.getInt("projectRemaining", 1), prefs.getInt("projectTotal", 1), prefs.getInt("projectLevel", 1),
                runCatching { DevelopmentIntensity.valueOf(prefs.getString("projectIntensity", "STANDARD")!!) }.getOrDefault(DevelopmentIntensity.STANDARD),
                prefs.getInt("projectGain", 4), prefs.getLong("projectCost", 0L)
            ) else null,
            nextSeasonInvestment=prefs.getLong("nextSeasonInvestment",0L),
            nextSeasonFocus=runCatching { CarDevelopmentFocus.valueOf(prefs.getString("nextSeasonFocus", "BALANCED")!!) }.getOrDefault(CarDevelopmentFocus.BALANCED),
            developmentKnowledge=loadKnowledge(),
            seasonDevelopmentGain=prefs.getInt("seasonDevelopmentGain",0)
        ).normalized()
    }.getOrNull()

    fun saveCar(forTeamId:Int, car:TeamCarState) {
        val e=prefs.edit().putInt("carTeam",forTeamId).putInt("carAero",car.aerodynamics).putInt("carChassis",car.chassis).putInt("carEngine",car.engine).putInt("carReliability",car.reliability)
            .putInt("carFrontWing",car.frontWing).putInt("carRearWing",car.rearWing).putInt("carBrakes",car.brakes).putInt("carErs",car.electricPowerUnit)
        if (car.activeProject == null) e.remove("projectComponent").remove("projectRemaining").remove("projectTotal").remove("projectLevel").remove("projectIntensity").remove("projectGain").remove("projectCost")
        else car.activeProject.let { e.putString("projectComponent",it.component.name).putInt("projectRemaining",it.remainingWeeks).putInt("projectTotal",it.totalWeeks).putInt("projectLevel",it.level).putString("projectIntensity",it.intensity.name).putInt("projectGain",it.expectedGain).putLong("projectCost",it.cost) }
        e.putLong("nextSeasonInvestment",car.nextSeasonInvestment).putString("nextSeasonFocus",car.nextSeasonFocus.name).putString("developmentKnowledge",car.developmentKnowledge.entries.joinToString(",") { "${it.key.name}:${it.value}" }).putInt("seasonDevelopmentGain",car.seasonDevelopmentGain).apply()
    }


    private fun loadKnowledge(): Map<CarComponent,Int> = prefs.getString("developmentKnowledge", "").orEmpty().split(',').mapNotNull { token ->
        val p=token.split(':')
        if (p.size==2) runCatching { CarComponent.valueOf(p[0]) to p[1].toInt().coerceIn(0,8) }.getOrNull() else null
    }.toMap()

    fun loadFinance(forTeamId:Int, fallback:TeamFinanceState): TeamFinanceState {
        if (prefs.getInt("financeTeam", -1) != forTeamId) return fallback
        return TeamFinanceState(
            budget=prefs.getLong("budget", fallback.budget),
            seasonIncome=prefs.getLong("seasonIncome", fallback.seasonIncome),
            seasonExpenses=prefs.getLong("seasonExpenses", fallback.seasonExpenses),
            raceIncome=prefs.getLong("raceIncome", fallback.raceIncome),
            raceExpenses=prefs.getLong("raceExpenses", fallback.raceExpenses)
        )
    }
    fun saveFinance(forTeamId:Int, finance:TeamFinanceState) {
        prefs.edit().putInt("financeTeam",forTeamId).putLong("budget",finance.budget).putLong("seasonIncome",finance.seasonIncome).putLong("seasonExpenses",finance.seasonExpenses).putLong("raceIncome",finance.raceIncome).putLong("raceExpenses",finance.raceExpenses).apply()
    }
    fun loadSponsor(forTeamId:Int, fallback:SponsorContract): SponsorContract {
        if (prefs.getInt("sponsorTeam", -1) != forTeamId) return fallback
        return SponsorContract(
            prefs.getString("sponsorName",fallback.name) ?: fallback.name,
            prefs.getLong("sponsorUpfront",fallback.upfront),
            prefs.getLong("sponsorRace",fallback.racePayment),
            prefs.getLong("sponsorPoints",fallback.pointsBonus),
            prefs.getInt("sponsorYears",fallback.years),
            prefs.getInt("sponsorRep",fallback.minimumReputation),
            prefs.getInt("sponsorSlot",fallback.slot),
            prefs.getInt("sponsorQualTarget",fallback.qualifyingTarget),
            prefs.getLong("sponsorQualBonus",fallback.qualifyingBonus),
            prefs.getInt("sponsorRaceTarget",fallback.raceTarget),
            prefs.getLong("sponsorRaceTargetBonus",fallback.raceTargetBonus),
            prefs.getBoolean("sponsorActive",fallback.active),
            prefs.getInt("sponsorRaces",fallback.races),
            prefs.getInt("sponsorRacesRemaining",fallback.racesRemaining)
        )
    }
    fun loadSponsors(forTeamId:Int): List<SponsorContract> {
        if (prefs.getInt("sponsorTeam", -1) != forTeamId) return emptyList()
        return (1..5).mapNotNull { slot ->
            val name=prefs.getString("sponsor_${slot}_name",null) ?: return@mapNotNull null
            SponsorContract(name, prefs.getLong("sponsor_${slot}_upfront",0), prefs.getLong("sponsor_${slot}_race",0), prefs.getLong("sponsor_${slot}_points",0), prefs.getInt("sponsor_${slot}_years",1), prefs.getInt("sponsor_${slot}_rep",0), slot, prefs.getInt("sponsor_${slot}_qualTarget",0), prefs.getLong("sponsor_${slot}_qualBonus",0), prefs.getInt("sponsor_${slot}_raceTarget",0), prefs.getLong("sponsor_${slot}_raceTargetBonus",0), prefs.getBoolean("sponsor_${slot}_active",true), prefs.getInt("sponsor_${slot}_races",5), prefs.getInt("sponsor_${slot}_racesRemaining",prefs.getInt("sponsor_${slot}_races",5)))
        }
    }
    fun saveSponsor(forTeamId:Int, sponsor:SponsorContract) = saveSponsors(forTeamId, listOf(sponsor))
    fun saveSponsors(forTeamId:Int, sponsors:List<SponsorContract>) {
        val e=prefs.edit().putInt("sponsorTeam",forTeamId)
        for (slot in 1..5) {
            val s=sponsors.firstOrNull { it.slot==slot }
            if (s==null) {
                listOf("name","upfront","race","points","years","rep","qualTarget","qualBonus","raceTarget","raceTargetBonus","active","races","racesRemaining").forEach { e.remove("sponsor_${slot}_$it") }
            } else {
                e.putString("sponsor_${slot}_name",s.name).putLong("sponsor_${slot}_upfront",s.upfront).putLong("sponsor_${slot}_race",s.racePayment).putLong("sponsor_${slot}_points",s.pointsBonus).putInt("sponsor_${slot}_years",s.years).putInt("sponsor_${slot}_rep",s.minimumReputation).putInt("sponsor_${slot}_qualTarget",s.qualifyingTarget).putLong("sponsor_${slot}_qualBonus",s.qualifyingBonus).putInt("sponsor_${slot}_raceTarget",s.raceTarget).putLong("sponsor_${slot}_raceTargetBonus",s.raceTargetBonus).putBoolean("sponsor_${slot}_active",s.active).putInt("sponsor_${slot}_races",s.races).putInt("sponsor_${slot}_racesRemaining",s.racesRemaining)
            }
        }
        // Keep legacy primary sponsor keys synchronized.
        val primary=sponsors.firstOrNull { it.slot==1 }
        if (primary==null) { e.remove("sponsorName").remove("sponsorUpfront").remove("sponsorRace").remove("sponsorPoints").remove("sponsorYears").remove("sponsorRep").remove("sponsorSlot").remove("sponsorQualTarget").remove("sponsorQualBonus").remove("sponsorRaceTarget").remove("sponsorRaceTargetBonus").remove("sponsorActive").remove("sponsorRaces").remove("sponsorRacesRemaining") }
        else { e.putString("sponsorName",primary.name).putLong("sponsorUpfront",primary.upfront).putLong("sponsorRace",primary.racePayment).putLong("sponsorPoints",primary.pointsBonus).putInt("sponsorYears",primary.years).putInt("sponsorRep",primary.minimumReputation).putInt("sponsorSlot",primary.slot).putInt("sponsorQualTarget",primary.qualifyingTarget).putLong("sponsorQualBonus",primary.qualifyingBonus).putInt("sponsorRaceTarget",primary.raceTarget).putLong("sponsorRaceTargetBonus",primary.raceTargetBonus).putBoolean("sponsorActive",primary.active).putInt("sponsorRaces",primary.races).putInt("sponsorRacesRemaining",primary.racesRemaining) }
        e.apply()
    }

    fun startNewCareer(selectedTeamId: Int) {
        teamId = selectedTeamId; roundIndex = 0; currentWeek = 1; season = 2026; hasCareer = true
        writeMap("driverPoints", emptyMap()); writeMap("constructorPoints", emptyMap())
        for (r in 1..WorldDatabase.rounds.size) prefs.edit().remove("race_$r").apply()
        history.clear()
        val t=WorldDatabase.teams.first { it.id==selectedTeamId }
        saveCar(selectedTeamId, TeamCarState(t.baseCar,t.chassis,t.engine,t.reliability,frontWing=t.frontWing,rearWing=t.rearWing,brakes=t.brakes,electricPowerUnit=t.electricPowerUnit))
        saveFinance(selectedTeamId, TeamFinanceState(75_000_000L)); saveSponsors(selectedTeamId, emptyList())
    }

    /** Advance to the next GP after a completed race, preserving the current calendar week. */
    fun completeCurrentRace() {
        if (roundIndex < WorldDatabase.rounds.lastIndex) {
            roundIndex += 1
            // Do NOT move currentWeek here. The completed GP happened in the current
            // week; the manager must return to the calendar and manually advance the
            // remaining free weeks until the next GP week.
        } else {
            history.finalizeSeason(season, driverPoints(), constructorPoints())
            season += 1
            roundIndex = 0
            currentWeek = 1
            writeMap("driverPoints", emptyMap())
            writeMap("constructorPoints", emptyMap())
        }
    }

    /** Legacy full advance kept for compatibility with other game flows. */
    fun advanceRound() {
        if (roundIndex < WorldDatabase.rounds.lastIndex) {
            roundIndex += 1
            currentWeek = WorldDatabase.rounds[roundIndex].weekOfSeason
        } else {
            history.finalizeSeason(season, driverPoints(), constructorPoints())
            season += 1
            roundIndex = 0
            currentWeek = 1
            writeMap("driverPoints", emptyMap())
            writeMap("constructorPoints", emptyMap())
        }
    }

    /** Advance one or more real calendar weeks. Returns the number of weeks actually advanced. */
    fun advanceCalendarWeeks(weeks: Int): Int {
        val old = currentWeek
        currentWeek = (currentWeek + weeks.coerceAtLeast(0)).coerceAtMost(56)
        return currentWeek - old
    }

    fun jumpToWeek(week: Int): Int {
        val old = currentWeek
        currentWeek = week
        return currentWeek - old
    }
}
private object WorldTeamResolver { fun teamIdFor(driverId: Int): Int = ((driverId - 1) / 2) + 1 }
