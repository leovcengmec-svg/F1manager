package com.f1teammanager

import android.content.Context
import com.f1teammanager.core.manager.DevelopmentProject
import com.f1teammanager.core.manager.FinanceEngine
import com.f1teammanager.core.manager.TeamManagerState
import com.f1teammanager.core.manager.DevelopmentIntensity
import com.f1teammanager.core.manager.ResearchProject
import com.f1teammanager.core.manager.ResearchDesign
import com.f1teammanager.core.manager.TeamResearchState
import com.f1teammanager.core.manager.CarPiece
import com.f1teammanager.core.manager.FactoryOrder
import com.f1teammanager.core.manager.TeamFactoryState
import com.f1teammanager.core.manager.TeamGarage
import com.f1teammanager.core.manager.PhysicalCar
import com.f1teammanager.core.manager.GarageCarId
import com.f1teammanager.core.manager.CarComponent
import com.f1teammanager.core.manager.ResearchFocus
import com.f1teammanager.core.manager.ResearchComplexity
import com.f1teammanager.core.manager.ResearchOutcome
import com.f1teammanager.core.manager.CarDevelopmentFocus
import com.f1teammanager.core.manager.TeamCarState
import com.f1teammanager.core.manager.TeamFinanceState
import com.f1teammanager.core.manager.TeamFacilitiesState
import com.f1teammanager.core.manager.FacilityType
import com.f1teammanager.core.manager.SponsorContract
import com.f1teammanager.core.race.RaceResult
import com.f1teammanager.core.race.QualifyingResult
import com.f1teammanager.core.season.RoundDefinition
import com.f1teammanager.core.race.Tyre
import com.f1teammanager.core.season.WorldDatabase
import com.f1teammanager.core.season.DriverEvolutionEngine
import com.f1teammanager.core.season.DriverProfileCatalog
import com.f1teammanager.core.manager.DriverMarketState
import com.f1teammanager.core.manager.DriverMarketEngine
import com.f1teammanager.core.manager.DriverDeal
import com.f1teammanager.core.manager.DriverOffer
import com.f1teammanager.core.manager.FutureDriverDeal
import com.f1teammanager.core.manager.DriverTeamRole
import com.f1teammanager.core.manager.DriverRolePreference
import com.f1teammanager.core.manager.NegotiationStatus
import com.f1teammanager.core.manager.ScoutingReport
import com.f1teammanager.core.manager.MarketNotification
import com.f1teammanager.core.manager.MarketNewsCategory
import com.f1teammanager.core.season.SeasonCalendar

/** Persistent career metadata, championship ledger, race archive and car P&D state. */
class CareerPreferences(context: Context) {
    val history = HistoricalDatabase(context)
    private val prefs = context.getSharedPreferences("f1tm_career", Context.MODE_PRIVATE)

    var hasCareer: Boolean
        get() = prefs.getBoolean("hasCareer", false)
        private set(value) = prefs.edit().putBoolean("hasCareer", value).apply()
    var teamId: Int
        get() = prefs.getInt("teamId", 1)
        private set(value) = prefs.edit().putInt("teamId", value).apply()
    var roundIndex: Int
        get() = prefs.getInt("roundIndex", 0)
        private set(value) = prefs.edit().putInt("roundIndex", value.coerceIn(0, SeasonCalendar.forSeason(season).lastIndex)).apply()
    /** Current calendar week. Race weekends occupy specific weeks; the other weeks are free development weeks. */
    var currentWeek: Int
        get() = prefs.getInt("currentWeek", SeasonCalendar.forSeason(season).first().weekOfSeason.coerceAtLeast(1) - 2).coerceIn(1, 56)
        private set(value) = prefs.edit().putInt("currentWeek", value.coerceIn(1, 56)).apply()
    var season: Int
        get() = prefs.getInt("season", 2026)
        private set(value) = prefs.edit().putInt("season", value).apply()

    private fun readMap(key: String): Map<Int, Int> = prefs.getString(key, "").orEmpty().split(',').mapNotNull { token ->
        val p = token.split(':')
        if (p.size == 2) p[0].toIntOrNull()?.let { id -> p[1].toIntOrNull()?.let { value -> id to value } } else null
    }.toMap()
    private fun writeMap(key: String, value: Map<Int, Int>) = prefs.edit().putString(key, value.entries.sortedBy { it.key }.joinToString(",") { "${it.key}:${it.value}" }).apply()

    private fun readDoubleMap(key: String): Map<Int, Double> = prefs.getString(key, "").orEmpty().split(',').mapNotNull { token ->
        val p=token.split(':')
        if (p.size != 2) null else p[0].toIntOrNull()?.let { id -> p[1].toDoubleOrNull()?.let { value -> id to value } }
    }.toMap()
    private fun writeDoubleMap(key: String, value: Map<Int, Double>) = prefs.edit().putString(key, value.entries.sortedBy { it.key }.joinToString(",") { "${it.key}:${it.value}" }).apply()
    fun driverPoints(): Map<Int, Int> = readMap("driverPoints")
    fun constructorPoints(): Map<Int, Int> = readMap("constructorPoints")

    /** V36 canonical financial settlement ledger for every team, including AI. */
    fun aiTeamBudget(teamId: Int): Long {
        val raw = prefs.getString("aiTeamBudgets", "").orEmpty()
        return raw.split(";").firstOrNull { it.startsWith("$teamId:") }?.substringAfter(":")?.toLongOrNull()
            ?: (35_000_000L + (WorldDatabase.teams.firstOrNull { it.id == teamId }?.baseCar?.coerceIn(50,100) ?: 50) * 650_000L)
    }

    fun loadAiFinanceSnapshot(): String = prefs.getString("aiFinanceSnapshot", "").orEmpty()
    fun saveAiFinanceSnapshot(raw:String) { prefs.edit().putString("aiFinanceSnapshot", raw).apply() }
    fun loadAiSponsorshipSnapshot(): String = prefs.getString("aiSponsorshipSnapshot", "").orEmpty()
    fun saveAiSponsorshipSnapshot(raw:String) { prefs.edit().putString("aiSponsorshipSnapshot", raw).apply() }

    private fun saveAiTeamBudgets(values: Map<Int, Long>) {
        prefs.edit().putString("aiTeamBudgets", values.toSortedMap().entries.joinToString(";") { "${it.key}:${it.value}" }).apply()
    }

    /**
     * The only Android-facing season-prize entry point. It settles all 40 teams
     * atomically from the same constructor standings used by the history.
     * Idempotency is per season and per team, so reopening GP30 cannot duplicate money.
     */
    fun settleConstructorsSeason(seasonToClose: Int): List<com.f1teammanager.core.manager.SeasonSettlementEngine.Settlement> {
        require(season == seasonToClose) { "Temporada de fechamento divergente" }
        if (!history.isSeasonFinalized(seasonToClose)) {
            history.finalizeSeason(seasonToClose, driverPoints(), constructorPoints(), loadDriverMarket())
        }
        val settlements = com.f1teammanager.core.manager.SeasonSettlementEngine.settleAll(constructorPoints())
        val paid = prefs.getString("constructorPrizePaidTeams_$seasonToClose", "").orEmpty().split(",").mapNotNull { it.toIntOrNull() }.toMutableSet()
        var aiBudgets = WorldDatabase.teams.filter { it.id != teamId }.associate { it.id to aiTeamBudget(it.id) }.toMutableMap()
        val playerFinance = loadFinance(teamId, TeamFinanceState(0L))
        var player = playerFinance
        settlements.forEach { settlement ->
            if (settlement.teamId == teamId) {
                if (teamId !in paid) {
                    player = FinanceEngine().applySeasonConstructorsPrize(
                        TeamManagerState(playerTeamId=teamId, season=seasonToClose, round=SeasonCalendar.forSeason(season).size,
                            car=TeamCarState(70,70,70,70), finance=player, driverMarket=loadDriverMarket() ?: DriverMarketEngine().initialState(seasonToClose)),
                        seasonToClose, settlement.position
                    ).finance
                }
            } else if (settlement.teamId !in paid) {
                aiBudgets[settlement.teamId] = aiBudgets.getValue(settlement.teamId) + settlement.prize
            }
        }
        if (teamId !in paid) {
            saveFinance(teamId, player)
        }
        paid.addAll(settlements.map { it.teamId })
        prefs.edit().putString("constructorPrizePaidTeams_$seasonToClose", paid.sorted().joinToString(",")).apply()
        saveAiTeamBudgets(aiBudgets)
        return settlements
    }
    fun previousDriverPositions(): Map<Int, Int> = readMap("previousDriverPositions")
    fun previousConstructorPositions(): Map<Int, Int> = readMap("previousConstructorPositions")

    fun loadDriverMarket(): DriverMarketState? = runCatching {
        val rawContracts = prefs.getString("marketContracts", null) ?: return null
        val contracts = rawContracts.split(';').filter { it.isNotBlank() }.mapNotNull { row ->
            val p=row.split(','); runCatching {
                if (p.size >= 8) DriverDeal(p[0].toInt(),p[1].toInt(),p[2].toInt(),p[3].toLong(),p[4].toLong(),p[6].toInt(),DriverTeamRole.valueOf(p[7]))
                else if (p.size >= 7) DriverDeal(p[0].toInt(),p[1].toInt(),p[2].toInt(),p[3].toLong(),p[4].toLong(),p[5].toInt(),DriverTeamRole.EQUAL)
                else null
            }.getOrNull()
        }
        val free=prefs.getString("marketFree", "").orEmpty().split(',').mapNotNull{it.toIntOrNull()}
        val scheduled=prefs.getString("marketScheduled", "").orEmpty().split(';').filter{it.isNotBlank()}.mapNotNull { row ->
            val p=row.split(','); runCatching {
                if (p.size >= 10) FutureDriverDeal(p[0].toInt(),p[1].toInt(),p[2].toInt(),p[3].toInt(),p[4].toInt(),p[5].toLong(),DriverTeamRole.valueOf(p[6]),p[7].toInt(),p.getOrNull(9)?.toIntOrNull())
                else if (p.size >= 9) FutureDriverDeal(p[0].toInt(),p[1].toInt(),p[2].toInt(),p[3].toInt(),p[4].toInt(),p[5].toLong(),DriverTeamRole.valueOf(p[6]),p[7].toInt(),null)
                else null
            }.getOrNull()
        }
        val roles=prefs.getString("marketRoles", "").orEmpty().split(',').mapNotNull{part -> val p=part.split(':'); if(p.size==2) runCatching{p[0].toInt() to DriverRolePreference.valueOf(p[1])}.getOrNull() else null}.toMap()
        val pending=prefs.getString("marketPending", "").orEmpty().split(';').filter{it.isNotBlank()}.mapNotNull { row ->
            val p=row.split(','); runCatching {
                if (p.size >= 13 && runCatching { NegotiationStatus.valueOf(p[10]) }.isSuccess) DriverOffer(p[0].toInt(),p[1].toInt(),p[2].toInt(),p[3].toInt(),p[4].toLong(),DriverTeamRole.valueOf(p[5]),p[6].toLong(),p[7].toInt(),p[8].toInt(),p[9].toInt(),NegotiationStatus.valueOf(p[10]),p[11].toInt(),p.getOrNull(12)?.toIntOrNull(),p.getOrNull(13)?.toIntOrNull() ?: 0)
                else if (p.size >= 13) DriverOffer(p[0].toInt(),p[1].toInt(),p[2].toInt(),p[3].toInt(),p[4].toLong(),DriverTeamRole.valueOf(p[5]),p[6].toLong(),p[8].toInt(),p[9].toInt(),p[10].toInt(),NegotiationStatus.valueOf(p[11]),p[12].toInt(),null,0)
                else null
            }.getOrNull()
        }
        val scouting=prefs.getString("marketScouting", "").orEmpty().split(';').filter{it.isNotBlank()}.mapNotNull { row ->
            val p=row.split(','); runCatching {
                if (p.size >= 12) ScoutingReport(p[0].toInt(),p[1].toInt(),p[2].toLong(),p[3].toInt(),p[4].toInt(),p[5].toLong(),p[6].toLong(),DriverRolePreference.valueOf(p[8]),p[9].toInt(),p[10].toInt(),p[11])
                else if (p.size >= 10) ScoutingReport(p[0].toInt(),p[1].toInt(),p[2].toLong(),p[3].toInt(),p[4].toInt(),p[5].toLong(),p[6].toLong(),DriverRolePreference.valueOf(p[8]),p[9].toInt(),2026,"")
                else if (p.size >= 9) ScoutingReport(p[0].toInt(),p[1].toInt(),p[2].toLong(),p[3].toInt(),p[4].toInt(),p[5].toLong(),p[6].toLong(),DriverRolePreference.valueOf(p[7]),p[8].toInt(),2026,"")
                else null
            }.getOrNull()
        }
        val notifications=prefs.getString("marketNotifications", "").orEmpty().split(';').filter{it.isNotBlank()}.mapNotNull { row ->
            val p=row.split('|', limit=6); if(p.size<5) null else runCatching { MarketNotification(p[0].toInt(),p[1].toInt(),p[2],p[3],p[4].toBoolean(), p.getOrNull(5)?.let { runCatching { com.f1teammanager.core.manager.MarketNewsCategory.valueOf(it) }.getOrNull() } ?: com.f1teammanager.core.manager.MarketNewsCategory.MARKET) }.getOrNull()
        }
        DriverMarketState(contracts=contracts,freeAgents=free,scheduled=scheduled,rolePreferences=roles,pending=pending,scouting=scouting,notifications=notifications).normalized()
    }.getOrNull()

    fun loadReadNewsKeys(): Set<String> = prefs.getString("marketNewsReadKeys", "").orEmpty()
        .split(";").filter { it.isNotBlank() }.toSet()

    fun markNewsRead(keys: Collection<String>) {
        if (keys.isEmpty()) return
        val merged = (loadReadNewsKeys() + keys).toList().takeLast(300).toSet()
        prefs.edit().putString("marketNewsReadKeys", merged.joinToString(";")).apply()
    }

    fun saveDriverMarket(state: DriverMarketState) {
        val s=state.normalized()
        prefs.edit()
            .putString("marketContracts", s.contracts.joinToString(";") { listOf(it.driverId,it.teamId,it.years,it.salary,it.marketValue,it.seasonSigned,it.role.name).joinToString(",") })
            .putString("marketFree", s.freeAgents.joinToString(","))
            .putString("marketScheduled", s.scheduled.joinToString(";") { listOf(it.driverId,it.fromTeamId,it.toTeamId,it.startSeason,it.years,it.salary,it.role.name,it.signedSeason,it.replaceDriverId).joinToString(",") })
            .putString("marketRoles", s.rolePreferences.entries.joinToString(",") { "${it.key}:${it.value.name}" })
            .putString("marketPending", s.pending.joinToString(";") { listOf(it.driverId,it.fromTeamId,it.toTeamId,it.years,it.salary,it.role.name,it.marketValue,it.interestScore,it.round,it.expiresAfterWeek,it.status.name,it.seasonTarget,it.replaceDriverId,it.proposerTeamId).joinToString(",") })
            .putString("marketScouting", s.scouting.joinToString(";") { listOf(it.driverId,it.teamId,it.cost,it.createdWeek,it.expiresWeek,it.expectedSalary,it.marketValue,it.rolePreference.name,it.interest,it.season,it.attributeRanges).joinToString(",") })
            .putString("marketNotifications", s.notifications.joinToString(";") { listOf(it.season,it.week,it.title.replace(";", ",").replace("|", "/"),it.message.replace(";", ",").replace("|", "/"),it.important,it.category.name).joinToString("|") })
            .apply()
    }


    fun recordRace(round: Int, result: RaceResult, seasonRound: RoundDefinition? = null, qualifying: QualifyingResult? = null) {
        // Capture the championship order BEFORE adding this GP. The standings screen
        // uses this snapshot to show who went up, down or stayed in the same place
        // after each completed race.
        val oldDriverPoints = driverPoints()
        val oldConstructorPoints = constructorPoints()
        val activeIdsForStandings = loadDriverMarket()?.contracts?.filter { it.activeIn(season) }?.map { it.driverId }?.distinct()
            ?: WorldDatabase.drivers.map { it.id }
        val oldDriverOrder = activeIdsForStandings
            .map { it to (oldDriverPoints[it] ?: 0) }
            .sortedWith(compareByDescending<Pair<Int,Int>> { it.second }.thenBy { it.first })
            .mapIndexed { index, row -> row.first to index + 1 }
            .toMap()
        val oldConstructorOrder = WorldDatabase.teams
            .map { it.id to (oldConstructorPoints[it.id] ?: 0) }
            .sortedWith(compareByDescending<Pair<Int,Int>> { it.second }.thenBy { it.first })
            .mapIndexed { index, row -> row.first to index + 1 }
            .toMap()
        writeMap("previousDriverPositions", oldDriverOrder)
        writeMap("previousConstructorPositions", oldConstructorOrder)

        val drivers = oldDriverPoints.toMutableMap()
        result.points.forEach { (id, pts) -> drivers[id] = (drivers[id] ?: 0) + pts }
        writeMap("driverPoints", drivers)
        val teams = oldConstructorPoints.toMutableMap()
        val activeMarket = loadDriverMarket()
        result.classification.forEach { f ->
            val tid = activeMarket?.contracts?.firstOrNull { it.driverId == f.driverId && it.activeIn(season) }?.teamId
                ?: WorldDatabase.teams.firstOrNull { it.name.equals(f.teamName, ignoreCase = true) }?.id
                ?: WorldTeamResolver.teamIdFor(f.driverId)
            teams[tid] = (teams[tid] ?: 0) + (result.points[f.driverId] ?: 0)
        }
        writeMap("constructorPoints", teams)
        val encoded = result.classification.joinToString(";") { f ->
            val teamId = activeMarket?.contracts?.firstOrNull { it.driverId == f.driverId && it.activeIn(season) }?.teamId
                ?: WorldDatabase.teams.firstOrNull { it.name.equals(f.teamName, ignoreCase = true) }?.id
                ?: WorldTeamResolver.teamIdFor(f.driverId)
            listOf(f.position, f.driverId, f.laps, f.totalTimeMs, f.status.replace(";", ","), f.tyre.name, f.pitStops, result.points[f.driverId] ?: 0, teamId).joinToString(",")
        }
        prefs.edit().putString("race_$round", encoded).apply()
        if (seasonRound != null) {
            history.recordRace(season, seasonRound, result, qualifying, activeMarket)
            // The season archive is created immediately when GP 30 finishes.
            // Returning to the calendar later must not be required to create history.
            if (seasonRound.round == SeasonCalendar.forSeason(season).size) {
                history.finalizeSeason(season, drivers, teams, activeMarket)
            }
        }
    }

    fun raceHistory(round: Int): RaceResult? = runCatching {
        val raw = prefs.getString("race_$round", null) ?: return null
        val classification = raw.split(';').filter { it.isNotBlank() }.map { row ->
            val p = row.split(',')
            val id = p[1].toInt()
            val driver = WorldDatabase.drivers.first { it.id == id }
            val teamId = p.getOrNull(8)?.toIntOrNull() ?: driver.teamId
            val team = WorldDatabase.teams.first { it.id == teamId }
            FinishEntryCompat(p[0].toInt(), id, driver.name, team.name, p[2].toInt(), p[3].toLong(), p[4], Tyre.valueOf(p[5]), p[6].toInt())
        }
        val points = raw.split(';').filter { it.isNotBlank() }.associate { row -> val p=row.split(','); p[1].toInt() to p[7].toInt() }
        RaceResult(classification.map { it.toFinish() }, emptyList(), null, com.f1teammanager.core.race.Weather.DRY, points, 0, 0)
    }.getOrNull()

    private data class FinishEntryCompat(val position:Int,val driverId:Int,val driverName:String,val teamName:String,val laps:Int,val totalTimeMs:Long,val status:String,val tyre:Tyre,val pitStops:Int) {
        fun toFinish() = com.f1teammanager.core.race.FinishEntry(position,driverId,driverName,teamName,laps,totalTimeMs,status,tyre,pitStops)
    }

    fun loadCar(forTeamId: Int): TeamCarState? = runCatching {
        if (prefs.getInt("carTeam", -1) != forTeamId) return null
        TeamCarState(
            aerodynamics=prefs.getInt("carAero", 70), chassis=prefs.getInt("carChassis",70), engine=prefs.getInt("carEngine",70), reliability=prefs.getInt("carReliability",70),
            frontWing=prefs.getInt("carFrontWing",70), rearWing=prefs.getInt("carRearWing",70), brakes=prefs.getInt("carBrakes",70), electricPowerUnit=prefs.getInt("carErs",70),
            activeProject=if (prefs.getString("projectComponent", null) != null) DevelopmentProject(
                CarComponent.valueOf(prefs.getString("projectComponent", "ENGINE")!!),
                prefs.getInt("projectRemaining", 1), prefs.getInt("projectTotal", 1), prefs.getInt("projectLevel", 1),
                runCatching { DevelopmentIntensity.valueOf(prefs.getString("projectIntensity", "STANDARD")!!) }.getOrDefault(DevelopmentIntensity.STANDARD),
                prefs.getInt("projectGain", 4), prefs.getLong("projectCost", 0L)
            ) else null,
            nextSeasonInvestment=prefs.getLong("nextSeasonInvestment",0L),
            nextSeasonFocus=runCatching { CarDevelopmentFocus.valueOf(prefs.getString("nextSeasonFocus", "BALANCED")!!) }.getOrDefault(CarDevelopmentFocus.BALANCED),
            developmentKnowledge=loadKnowledge(),
            seasonDevelopmentGain=prefs.getInt("seasonDevelopmentGain",0)
        ).normalized()
    }.getOrNull()

    fun saveCar(forTeamId:Int, car:TeamCarState) {
        val e=prefs.edit().putInt("carTeam",forTeamId).putInt("carAero",car.aerodynamics).putInt("carChassis",car.chassis).putInt("carEngine",car.engine).putInt("carReliability",car.reliability)
            .putInt("carFrontWing",car.frontWing).putInt("carRearWing",car.rearWing).putInt("carBrakes",car.brakes).putInt("carErs",car.electricPowerUnit)
        if (car.activeProject == null) e.remove("projectComponent").remove("projectRemaining").remove("projectTotal").remove("projectLevel").remove("projectIntensity").remove("projectGain").remove("projectCost")
        else car.activeProject.let { e.putString("projectComponent",it.component.name).putInt("projectRemaining",it.remainingWeeks).putInt("projectTotal",it.totalWeeks).putInt("projectLevel",it.level).putString("projectIntensity",it.intensity.name).putInt("projectGain",it.expectedGain).putLong("projectCost",it.cost) }
        e.putLong("nextSeasonInvestment",car.nextSeasonInvestment).putString("nextSeasonFocus",car.nextSeasonFocus.name).putString("developmentKnowledge",car.developmentKnowledge.entries.joinToString(",") { "${it.key.name}:${it.value}" }).putInt("seasonDevelopmentGain",car.seasonDevelopmentGain).apply()
    }


    private fun loadKnowledge(): Map<CarComponent,Int> = prefs.getString("developmentKnowledge", "").orEmpty().split(',').mapNotNull { token ->
        val p=token.split(':')
        if (p.size==2) runCatching { CarComponent.valueOf(p[0]) to p[1].toInt().coerceIn(0,8) }.getOrNull() else null
    }.toMap()

    fun loadResearch(forTeamId: Int): TeamResearchState? = runCatching {
        if (prefs.getInt("researchTeam", -1) != forTeamId) return null
        val activeRows = prefs.getString("researchActiveProjects", "").orEmpty().split(";").filter { it.isNotBlank() }
        val projects = activeRows.mapNotNull { row ->
            val p=row.split("|")
            if (p.size < 13) null else runCatching {
                ResearchProject(p[0],CarComponent.valueOf(p[1]),p[2].toInt(),p[3].toInt(),p[4].toInt(),p[5].toInt(),p[6].toInt(),p[7].toInt(),p[8].toInt(),p[9].toLong(),p[10].toInt(),ResearchFocus.valueOf(p[11]),ResearchComplexity.valueOf(p[12]),p.getOrNull(13)?.let(ResearchOutcome::valueOf) ?: ResearchOutcome.SUCCESS)
            }.getOrNull()
        }
        val legacy = if (projects.isEmpty()) prefs.getString("researchActive", null)?.split("|")?.takeIf { it.size >= 11 }?.let { p ->
            runCatching { ResearchProject(p[0],CarComponent.valueOf(p[1]),p[2].toInt(),p[3].toInt(),p[3].toInt(),p[4].toInt(),p[4].toInt(),p[6].toInt(),p[7].toInt(),p[8].toLong(),p[9].toInt(),ResearchFocus.PERFORMANCE,ResearchComplexity.MEDIUM) }.getOrNull()
        } else null
        val designs = prefs.getString("researchDesigns", "").orEmpty().split(";").filter { it.isNotBlank() }.mapNotNull { row ->
            val p=row.split("|"); if (p.size < 7) null else runCatching { ResearchDesign(p[0],CarComponent.valueOf(p[1]),p[2].toInt(),p[3].toInt(),p[4].toInt(),p[5].toInt(),p[6].toInt()) }.getOrNull()
        }
        val cooldowns = prefs.getString("researchCooldowns", "").orEmpty().split(",").filter { it.isNotBlank() }.mapNotNull { token ->
            val p=token.split(":"); if (p.size != 2) null else runCatching { CarComponent.valueOf(p[0]) to p[1].toInt() }.getOrNull()
        }.toMap()
        TeamResearchState((projects + listOfNotNull(legacy)).distinctBy { it.projectId }, designs, cooldowns)
    }.getOrNull()

    fun saveResearch(forTeamId: Int, research: TeamResearchState) {
        val e=prefs.edit().putInt("researchTeam",forTeamId)
        if (research.activeProjects.isEmpty()) e.remove("researchActiveProjects") else e.putString("researchActiveProjects", research.activeProjects.joinToString(";") { p -> listOf(p.projectId,p.component.name,p.version,p.basePerformance,p.baseReliability,p.targetPerformance,p.targetReliability,p.totalWeeks,p.remainingWeeks,p.cost,p.startedWeek,p.focus.name,p.complexity.name,p.outcome.name).joinToString("|") })
        e.remove("researchActive")
        e.putString("researchDesigns", research.completedDesigns.joinToString(";") { d -> listOf(d.designId,d.component.name,d.version,d.performance,d.reliability,d.researchSeason,d.completedWeek).joinToString("|") })
        e.putString("researchCooldowns", research.cooldownUntil.entries.joinToString(",") { "${it.key.name}:${it.value}" }).apply()
    }

    fun loadFactory(forTeamId: Int): TeamFactoryState? = runCatching {
        if (prefs.getInt("factoryTeam", -1) != forTeamId) return null
        val orders = prefs.getString("factoryOrders", "").orEmpty().split(";").filter { it.isNotBlank() }.mapNotNull { row ->
            val p=row.split("|")
            if (p.size < 12) null else runCatching {
                FactoryOrder(p[0],p[1],CarComponent.valueOf(p[2]),p[3].toInt(),p[4].toInt(),p[5].toInt(),p[6].toInt(),p[7].toInt(),p[8].toInt(),p[9].toInt(),p[10].toLong(),p[11].toInt())
            }.getOrNull()
        }
        TeamFactoryState(orders)
    }.getOrNull()

    fun saveFactory(forTeamId: Int, factory: TeamFactoryState) {
        prefs.edit().putInt("factoryTeam",forTeamId)
            .putString("factoryOrders", factory.activeOrders.joinToString(";") { o -> listOf(o.orderId,o.designId,o.component.name,o.version,o.performance,o.reliability,o.quantity,o.remainingUnits,o.totalWeeks,o.remainingWeeks,o.costPerUnit,o.startedWeek).joinToString("|") })
            .apply()
    }

    fun loadGarage(forTeamId: Int): TeamGarage? = runCatching {
        if (prefs.getInt("garageTeam", -1) != forTeamId) return null
        fun loadComponentReliabilities(prefix: String, fallback: Int): Map<CarComponent, Int> = CarComponent.values().associateWith { c -> prefs.getInt("${prefix}Rel_${c.name}", fallback).coerceIn(1,100) }
        fun loadCar(id: GarageCarId): PhysicalCar {
            val prefix = if (id == GarageCarId.CAR_1) "g1" else "g2"
            val installed = prefs.getString("${prefix}Installed", "").orEmpty().split(",").filter { it.isNotBlank() }.mapNotNull { token ->
                val p=token.split(":")
                if (p.size != 2) null else runCatching { CarComponent.valueOf(p[0]) to p[1] }.getOrNull()
            }.toMap()
            return PhysicalCar(
                id=id, engine=prefs.getInt("${prefix}Engine",70), chassis=prefs.getInt("${prefix}Chassis",70),
                frontWing=prefs.getInt("${prefix}FrontWing",70), rearWing=prefs.getInt("${prefix}RearWing",70),
                brakes=prefs.getInt("${prefix}Brakes",70), electricPowerUnit=prefs.getInt("${prefix}Electric",70),
                reliability=prefs.getInt("${prefix}Reliability",100), componentReliabilities=loadComponentReliabilities(prefix, prefs.getInt("${prefix}Reliability",100)), installedPieces=installed
            )
        }
        val inventory = prefs.getString("garageInventory", "").orEmpty().split(";").filter { it.isNotBlank() }.mapNotNull { row ->
            val p=row.split("|")
            if (p.size < 6) null else runCatching { CarPiece(p[0],CarComponent.valueOf(p[1]),p[2].toInt(),p[3].toInt(),p[4].toInt(),p[5].toInt()) }.getOrNull()
        }
        TeamGarage(loadCar(GarageCarId.CAR_1),loadCar(GarageCarId.CAR_2),inventory)
    }.getOrNull()

    fun saveGarage(forTeamId: Int, garage: TeamGarage) {
        fun putCar(e: android.content.SharedPreferences.Editor, car: PhysicalCar, prefix: String) {
            e.putInt("${prefix}Engine",car.engine).putInt("${prefix}Chassis",car.chassis)
                .putInt("${prefix}FrontWing",car.frontWing).putInt("${prefix}RearWing",car.rearWing)
                .putInt("${prefix}Brakes",car.brakes).putInt("${prefix}Electric",car.electricPowerUnit)
                .putInt("${prefix}Reliability",car.reliability)
                .also { editor -> car.componentReliabilities.forEach { (c,v) -> editor.putInt("${prefix}Rel_${c.name}",v) } }
                .putString("${prefix}Installed",car.installedPieces.entries.joinToString(",") { "${it.key.name}:${it.value}" })
        }
        prefs.edit().putInt("garageTeam",forTeamId).also { e ->
            putCar(e,garage.car1,"g1"); putCar(e,garage.car2,"g2")
            e.putString("garageInventory",garage.inventory.joinToString(";") { p -> listOf(p.pieceId,p.component.name,p.version,p.performance,p.reliability,p.manufacturedWeek).joinToString("|") })
        }.apply()
    }

    fun loadFacilities(forTeamId:Int): TeamFacilitiesState? = runCatching {
        if (prefs.getInt("facilitiesTeam", -1) != forTeamId) return null
        val raw = prefs.getString("facilities", "").orEmpty()
        val levels = raw.split(",").filter { it.isNotBlank() }.mapNotNull { token ->
            val p = token.split(":")
            if (p.size != 2) null else runCatching { FacilityType.valueOf(p[0]) to p[1].toInt().coerceIn(0,10) }.getOrNull()
        }.toMap()
        TeamFacilitiesState(FacilityType.values().associateWith { levels[it] ?: 0 })
    }.getOrNull()

    fun saveFacilities(forTeamId:Int, facilities:TeamFacilitiesState) {
        prefs.edit().putInt("facilitiesTeam",forTeamId)
            .putString("facilities", facilities.levels.entries.sortedBy { it.key.ordinal }.joinToString(",") { "${it.key.name}:${it.value.coerceIn(0,10)}" })
            .apply()
    }

    fun getInt(key:String, fallback:Int): Int = prefs.getInt(key,fallback)
    fun putInt(key:String, value:Int) { prefs.edit().putInt(key,value).apply() }

    fun loadFinance(forTeamId:Int, fallback:TeamFinanceState): TeamFinanceState {
        if (prefs.getInt("financeTeam", -1) != forTeamId) return fallback
        return TeamFinanceState(
            budget=prefs.getLong("budget", fallback.budget),
            seasonIncome=prefs.getLong("seasonIncome", fallback.seasonIncome),
            seasonExpenses=prefs.getLong("seasonExpenses", fallback.seasonExpenses),
            raceIncome=prefs.getLong("raceIncome", fallback.raceIncome),
            raceExpenses=prefs.getLong("raceExpenses", fallback.raceExpenses),
            seasonPrizesPaid=prefs.getString("seasonPrizesPaid", "").orEmpty().split(",").mapNotNull { it.toIntOrNull() }.toSet()
        )
    }
    fun saveFinance(forTeamId:Int, finance:TeamFinanceState) {
        prefs.edit().putInt("financeTeam",forTeamId).putLong("budget",finance.budget).putLong("seasonIncome",finance.seasonIncome).putLong("seasonExpenses",finance.seasonExpenses).putLong("raceIncome",finance.raceIncome).putLong("raceExpenses",finance.raceExpenses)
            .putString("seasonPrizesPaid", finance.seasonPrizesPaid.sorted().joinToString(","))
            .apply()
    }

    /** Charges annual driver salaries exactly once for the requested season. */
    fun applyAnnualDriverSalariesOnce(forTeamId:Int, seasonToCharge:Int, finance:TeamFinanceState, market:DriverMarketState): TeamFinanceState {
        val key = "annualDriverSalarySeason_$forTeamId"
        if (prefs.getInt(key, 0) == seasonToCharge) return finance
        val total = market.contracts.filter { it.teamId == forTeamId && it.activeIn(seasonToCharge) }.sumOf { it.salary.toLong() }
        val next = if (total > 0L) finance.transact(-total, "Salários anuais dos pilotos — temporada $seasonToCharge") else finance
        prefs.edit().putInt(key, seasonToCharge).apply()
        saveFinance(forTeamId, next)
        return next
    }

    /** Qualifying sponsor bonus is a GP/season-round transaction and is persisted idempotently. */
    fun applyQualifyingBonusOnce(forTeamId:Int, seasonToApply:Int, roundToApply:Int, finance:TeamFinanceState, sponsors:List<SponsorContract>, bestPosition:Int): TeamFinanceState {
        if (bestPosition <= 0) return finance
        val key = "qualifyingBonusPaid_${seasonToApply}_$roundToApply"
        if (prefs.getBoolean(key, false)) return finance
        val bonus = sponsors.filter { it.active && it.racesRemaining > 0 }.sumOf { s -> if (s.qualifyingTarget > 0 && bestPosition <= s.qualifyingTarget) s.qualifyingBonus else 0L }
        val next = if (bonus > 0L) finance.transact(bonus, "Bônus por meta de qualificação — GP $roundToApply") else finance
        prefs.edit().putBoolean(key, true).apply()
        saveFinance(forTeamId, next)
        return next
    }
    fun loadSponsor(forTeamId:Int, fallback:SponsorContract): SponsorContract {
        if (prefs.getInt("sponsorTeam", -1) != forTeamId) return fallback
        return SponsorContract(
            prefs.getString("sponsorName",fallback.name) ?: fallback.name,
            prefs.getLong("sponsorUpfront",fallback.upfront),
            prefs.getLong("sponsorRace",fallback.racePayment),
            prefs.getLong("sponsorPoints",fallback.pointsBonus),
            prefs.getInt("sponsorYears",fallback.years),
            prefs.getInt("sponsorRep",fallback.minimumReputation),
            prefs.getInt("sponsorSlot",fallback.slot),
            prefs.getInt("sponsorQualTarget",fallback.qualifyingTarget),
            prefs.getLong("sponsorQualBonus",fallback.qualifyingBonus),
            prefs.getInt("sponsorRaceTarget",fallback.raceTarget),
            prefs.getLong("sponsorRaceTargetBonus",fallback.raceTargetBonus),
            prefs.getBoolean("sponsorActive",fallback.active),
            prefs.getInt("sponsorRaces",fallback.races),
            prefs.getInt("sponsorRacesRemaining",fallback.racesRemaining)
        )
    }
    fun loadSponsors(forTeamId:Int): List<SponsorContract> {
        if (prefs.getInt("sponsorTeam", -1) != forTeamId) return emptyList()
        return (1..5).mapNotNull { slot ->
            val name=prefs.getString("sponsor_${slot}_name",null) ?: return@mapNotNull null
            SponsorContract(name, prefs.getLong("sponsor_${slot}_upfront",0), prefs.getLong("sponsor_${slot}_race",0), prefs.getLong("sponsor_${slot}_points",0), prefs.getInt("sponsor_${slot}_years",1), prefs.getInt("sponsor_${slot}_rep",0), slot, prefs.getInt("sponsor_${slot}_qualTarget",0), prefs.getLong("sponsor_${slot}_qualBonus",0), prefs.getInt("sponsor_${slot}_raceTarget",0), prefs.getLong("sponsor_${slot}_raceTargetBonus",0), prefs.getBoolean("sponsor_${slot}_active",true), prefs.getInt("sponsor_${slot}_races",5), prefs.getInt("sponsor_${slot}_racesRemaining",prefs.getInt("sponsor_${slot}_races",5)), prefs.getString("sponsor_${slot}_category","BASICO") ?: "BASICO")
        }
    }
    fun saveSponsor(forTeamId:Int, sponsor:SponsorContract) = saveSponsors(forTeamId, listOf(sponsor))
    fun saveSponsors(forTeamId:Int, sponsors:List<SponsorContract>) {
        val e=prefs.edit().putInt("sponsorTeam",forTeamId)
        for (slot in 1..5) {
            val s=sponsors.firstOrNull { it.slot==slot }
            if (s==null) {
                listOf("name","upfront","race","points","years","rep","qualTarget","qualBonus","raceTarget","raceTargetBonus","active","races","racesRemaining","category").forEach { e.remove("sponsor_${slot}_$it") }
            } else {
                e.putString("sponsor_${slot}_name",s.name).putLong("sponsor_${slot}_upfront",s.upfront).putLong("sponsor_${slot}_race",s.racePayment).putLong("sponsor_${slot}_points",s.pointsBonus).putInt("sponsor_${slot}_years",s.years).putInt("sponsor_${slot}_rep",s.minimumReputation).putInt("sponsor_${slot}_qualTarget",s.qualifyingTarget).putLong("sponsor_${slot}_qualBonus",s.qualifyingBonus).putInt("sponsor_${slot}_raceTarget",s.raceTarget).putLong("sponsor_${slot}_raceTargetBonus",s.raceTargetBonus).putBoolean("sponsor_${slot}_active",s.active).putInt("sponsor_${slot}_races",s.races).putInt("sponsor_${slot}_racesRemaining",s.racesRemaining).putString("sponsor_${slot}_category",s.category)
            }
        }
        // Keep legacy primary sponsor keys synchronized.
        val primary=sponsors.firstOrNull { it.slot==1 }
        if (primary==null) { e.remove("sponsorName").remove("sponsorUpfront").remove("sponsorRace").remove("sponsorPoints").remove("sponsorYears").remove("sponsorRep").remove("sponsorSlot").remove("sponsorQualTarget").remove("sponsorQualBonus").remove("sponsorRaceTarget").remove("sponsorRaceTargetBonus").remove("sponsorActive").remove("sponsorRaces").remove("sponsorRacesRemaining") }
        else { e.putString("sponsorName",primary.name).putLong("sponsorUpfront",primary.upfront).putLong("sponsorRace",primary.racePayment).putLong("sponsorPoints",primary.pointsBonus).putInt("sponsorYears",primary.years).putInt("sponsorRep",primary.minimumReputation).putInt("sponsorSlot",primary.slot).putInt("sponsorQualTarget",primary.qualifyingTarget).putLong("sponsorQualBonus",primary.qualifyingBonus).putInt("sponsorRaceTarget",primary.raceTarget).putLong("sponsorRaceTargetBonus",primary.raceTargetBonus).putBoolean("sponsorActive",primary.active).putInt("sponsorRaces",primary.races).putInt("sponsorRacesRemaining",primary.racesRemaining) }
        e.apply()
    }

    /** Current persisted attributes for all 100 drivers. */
    fun driverAttributes(): Map<Int, IntArray> {
        val raw = prefs.getString("driverAttributes", "").orEmpty()
        val parsed = raw.split(';').mapNotNull { token ->
            val p = token.split(':', limit = 2)
            if (p.size != 2) return@mapNotNull null
            val id = p[0].toIntOrNull() ?: return@mapNotNull null
            val values = p[1].split(',').mapNotNull { it.toIntOrNull() }
            if (values.size != 7) null else id to values.toIntArray()
        }.toMap()
        if (parsed.size == WorldDatabase.allDrivers.size) return parsed
        val initialized = WorldDatabase.allDrivers.associate { it.id to intArrayOf(it.speed,it.qualifying,it.overtaking,it.defense,it.consistency,it.wet,it.tyre) }
        saveDriverAttributes(initialized)
        return initialized
    }

    fun saveDriverAttributes(values: Map<Int, IntArray>) {
        prefs.edit().putString("driverAttributes", values.toSortedMap().entries.joinToString(";") { (id,a) -> "$id:${a.joinToString(",")}" }).apply()
    }

    private fun readDriverEvolutionPhases(): MutableMap<Int,String> = prefs.getString("driverEvolutionPhases", "").orEmpty().split(';').mapNotNull { token ->
        val p=token.split(':', limit=2); if (p.size==2) p[0].toIntOrNull()?.let { it to p[1] } else null
    }.toMap().toMutableMap()

    private fun saveDriverEvolutionPhases(values: Map<Int,String>) {
        prefs.edit().putString("driverEvolutionPhases", values.toSortedMap().entries.joinToString(";") { "${it.key}:${it.value}" }).apply()
    }

    fun driverDefinition(driverId:Int): com.f1teammanager.core.season.DriverDefinition {
        val base = WorldDatabase.allDrivers.first { it.id == driverId }
        val a = driverAttributes()[driverId] ?: intArrayOf(base.speed,base.qualifying,base.overtaking,base.defense,base.consistency,base.wet,base.tyre)
        return base.copy(speed=a[0],qualifying=a[1],overtaking=a[2],defense=a[3],consistency=a[4],wet=a[5],tyre=a[6])
    }

    fun currentDrivers(): List<com.f1teammanager.core.season.DriverDefinition> =
        WorldDatabase.allDrivers.map { driverDefinition(it.id) }

    private fun readSeasonTargets(): Map<Int, DriverEvolutionEngine.Target> {
        return prefs.getString("driverSeasonTargets_$season", "").orEmpty().split(',').mapNotNull { token ->
            val p=token.split(':'); if(p.size!=2) null else p[0].toIntOrNull()?.let { id -> p[1].toIntOrNull()?.let { pos -> id to DriverEvolutionEngine.Target(pos) } }
        }.toMap()
    }

    /**
     * Creates the immutable season targets from the opening-season team-strength ranking.
     * Driver Overall is intentionally NOT used here. Each team occupies two championship
     * target slots according to its strength rank, so expectations are anchored to the
     * competitive level of the team rather than the driver's rating.
     */
    fun initializeDriverSeasonTargets(playerCar: TeamCarState? = null) {
        val market = loadDriverMarket()
        val active = market?.contracts?.filter { it.activeIn(season) }
            ?: WorldDatabase.drivers.map { d -> com.f1teammanager.core.manager.DriverDeal(d.id,d.teamId,1,0L,0L,season) }

        fun strength(team: com.f1teammanager.core.season.TeamDefinition): Double {
            if (team.id == teamId && playerCar != null) {
                return (playerCar.chassis + playerCar.engine + playerCar.frontWing +
                    playerCar.rearWing + playerCar.brakes + playerCar.electricPowerUnit) / 6.0
            }
            val c = com.f1teammanager.core.manager.InitialTeamProfile.values(team)
            return (c.chassis + c.engine + c.frontWing + c.rearWing + c.brakes + c.electricPowerUnit) / 6.0
        }

        val teamRank = WorldDatabase.teams
            .sortedWith(compareByDescending<com.f1teammanager.core.season.TeamDefinition> { strength(it) }.thenBy { it.id })
            .mapIndexed { index, team -> team.id to (index + 1) }
            .toMap()

        val targets = active.mapNotNull { deal ->
            val team = WorldDatabase.teams.firstOrNull { it.id == deal.teamId } ?: return@mapNotNull null
            val rank = teamRank[team.id] ?: return@mapNotNull null
            val order = team.driverIds.indexOf(deal.driverId).takeIf { it >= 0 } ?: 0
            deal.driverId to DriverEvolutionEngine.Target(((rank - 1) * 2 + order + 1).coerceIn(1, 80))
        }.toMap()

        prefs.edit().putString(
            "driverSeasonTargets_$season",
            targets.entries.sortedBy { it.key }.joinToString(",") { "${it.key}:${it.value.championshipPosition}" }
        ).apply()
    }

    /**
     * Applies one in-season evolution tick after a completed GP. Evolution is continuous
     * during the championship; GP30 only closes the season and does not perform a second
     * evolution pass. The fractional bank makes changes gradual while keeping the official
     * annual gain ceiling from DriverProfileCatalog.
     */
    private fun readAnnualAttributeGains(): MutableMap<Int, IntArray> {
        val raw = prefs.getString("driverEvolutionAttributeGains_$season", "").orEmpty()
        val out = mutableMapOf<Int, IntArray>()
        raw.split(';').filter { it.isNotBlank() }.forEach { token ->
            val p = token.split(':')
            if (p.size == 2) {
                val id = p[0].toIntOrNull()
                val values = p[1].split(',').mapNotNull { it.toIntOrNull() }
                if (id != null && values.size == 7) out[id] = values.toIntArray()
            }
        }
        return out
    }

    private fun writeAnnualAttributeGains(values: Map<Int, IntArray>) {
        prefs.edit().putString(
            "driverEvolutionAttributeGains_$season",
            values.toSortedMap().entries.joinToString(";") { (id, a) -> "$id:${a.joinToString(",")}" }
        ).apply()
    }

    /**
     * Applies one in-season evolution tick after a completed GP.
     * Positive evolution uses the full intended gain, with per-attribute class-ceiling
     * redistribution. Regression is independent and is capped at the floor 40.
     */
    fun applyDriverRaceEvolution(round: Int): List<String> {
        val targets = readSeasonTargets().ifEmpty { initializeDriverSeasonTargets(); readSeasonTargets() }
        val races = history.raceRecords(season)
        val qualifying = history.qualifyingRecords(season)
        val attrs = driverAttributes().toMutableMap()
        val banks = readDoubleMap("driverEvolutionBank_$season").toMutableMap()
        val annual = readAnnualAttributeGains()
        val phases = readDriverEvolutionPhases()
        val changes = mutableListOf<String>()
        val evolutionNews = mutableListOf<String>()
        var processedDrivers = 0
        var changedDrivers = 0
        var changedPoints = 0

        // All 100 registered drivers evolve every GP tick. The 80 active drivers
        // use real race performance; drivers without an active contract use natural
        // evolution at 70% utilization because they have no race performance.
        val activeDriverIds = loadDriverMarket()?.contracts
            ?.filter { it.activeIn(season) }
            ?.map { it.driverId }
            ?.toSet()
            ?: races.filter { it.round == round }.map { it.driverId }.toSet()

        WorldDatabase.allDrivers.forEach { base ->
            val id = base.id
            val isActive = id in activeDriverIds
            val currentAttrs = attrs[id] ?: intArrayOf(base.speed,base.qualifying,base.overtaking,base.defense,base.consistency,base.wet,base.tyre)
            val current = base.copy(speed=currentAttrs[0],qualifying=currentAttrs[1],overtaking=currentAttrs[2],defense=currentAttrs[3],consistency=currentAttrs[4],wet=currentAttrs[5],tyre=currentAttrs[6])
            val gainCap = DriverProfileCatalog.maxAnnualGain(current.evolution)
            val gainUsage = annual.getOrPut(id) { IntArray(7) }

            val utilization: Double
            val evaluationTier: String
            if (isActive) {
                val target = targets[id] ?: DriverEvolutionEngine.Target(80)
                val seasonRaces = races.filter { it.season == season && it.round <= round }
                val seasonQualifying = qualifying.filter { it.season == season && it.round <= round }
                val driverSeasonRows = seasonRaces.filter { it.driverId == id }.sortedBy { it.round }
                val driverQualRows = seasonQualifying.filter { it.driverId == id }.sortedBy { it.round }
                val points = driverSeasonRows.sumOf { it.points }
                val wins = driverSeasonRows.count { it.position == 1 && !it.status.startsWith("DNF") }
                val podiums = driverSeasonRows.count { it.position in 1..3 && !it.status.startsWith("DNF") }
                val avgRace = driverSeasonRows.map { if (it.status.startsWith("DNF")) 80 else it.position }.average()
                val avgQual = driverQualRows.takeIf { it.isNotEmpty() }?.map { it.position }?.average() ?: avgRace
                val teammatePositions = driverSeasonRows.mapNotNull { own ->
                    seasonRaces.firstOrNull { other ->
                        other.round == own.round && other.teamId == own.teamId && other.driverId != own.driverId
                    }?.let { if (it.status.startsWith("DNF")) 80 else it.position }
                }
                val currentChampionshipPosition = seasonRaces
                    .groupBy { it.driverId }
                    .map { (driverId, rows) -> driverId to rows.sumOf { it.points } }
                    .sortedWith(compareByDescending<Pair<Int,Int>> { it.second }.thenBy { it.first })
                    .indexOfFirst { it.first == id }
                    .let { if (it >= 0) it + 1 else target.championshipPosition }
                val evaluation = DriverEvolutionEngine.evaluate(
                    current,
                    target,
                    DriverEvolutionEngine.PerformanceInput(
                        championshipPosition = currentChampionshipPosition.coerceIn(1, 80),
                        points = points,
                        averageRacePosition = avgRace,
                        wins = wins,
                        podiums = podiums,
                        averageQualifyingPosition = avgQual,
                        teammateAveragePosition = teammatePositions.takeIf { it.isNotEmpty() }?.average(),
                        teammateComparisons = teammatePositions.size
                    )
                )
                utilization = DriverEvolutionEngine.performanceUtilization(evaluation.index)
                evaluationTier = evaluation.tier
            } else {
                utilization = 0.70
                evaluationTier = "Livre — evolução natural"
            }

            // The annual cap is per attribute. The weekly/GP budget therefore spans
            // all seven attributes; applyPositiveGain redistributes points while
            // respecting each attribute's individual cap and class ceiling.
            val naturalPerRace = (gainCap.toDouble() * 7.0) / SeasonCalendar.forSeason(season).size.toDouble().coerceAtLeast(1.0)
            var bank = (banks[id] ?: 0.0) + naturalPerRace * utilization
            var delta = 0
            while (bank >= 1.0 && gainUsage.any { it < gainCap }) {
                delta++
                bank -= 1.0
            }

            val random = kotlin.random.Random(20261006 + season * 1000 + round * 97 + id * 31)
            var next = current
            if (delta > 0) {
                next = DriverEvolutionEngine.applyPositiveGain(next, delta, gainUsage, random)
                val actual = intArrayOf(next.speed,next.qualifying,next.overtaking,next.defense,next.consistency,next.wet,next.tyre)
                    .zip(intArrayOf(current.speed,current.qualifying,current.overtaking,current.defense,current.consistency,current.wet,current.tyre))
                    .sumOf { (a,b) -> a-b }
                if (actual > 0) changes += "${current.name}: +$actual distribuído entre atributos (GP $round, desempenho $evaluationTier)"
                if (actual < delta) bank += (delta - actual).toDouble()
            }
            attrs[id] = intArrayOf(next.speed,next.qualifying,next.overtaking,next.defense,next.consistency,next.wet,next.tyre)
            val nextOverall = DriverProfileCatalog.overall(intArrayOf(next.speed,next.qualifying,next.overtaking,next.defense,next.consistency,next.wet,next.tyre))
            val currentPhase = phases[id] ?: "GROWING"
            phases[id] = DriverEvolutionEngine.phaseFor(nextOverall, DriverProfileCatalog.ceiling(next.driverClass), currentPhase)
            processedDrivers++
            val beforeValues = intArrayOf(current.speed,current.qualifying,current.overtaking,current.defense,current.consistency,current.wet,current.tyre)
            val afterValues = intArrayOf(next.speed,next.qualifying,next.overtaking,next.defense,next.consistency,next.wet,next.tyre)
            val attributeNames = arrayOf("Velocidade","Classificação","Ultrapassagem","Defesa","Consistência","Chuva","Pneus")
            val attributeChanges = attributeNames.indices.mapNotNull { i ->
                if (afterValues[i] != beforeValues[i]) "${attributeNames[i]} ${beforeValues[i]}→${afterValues[i]}" else null
            }
            if (attributeChanges.isNotEmpty()) {
                changedDrivers++
                val actualDelta = afterValues.zip(beforeValues).sumOf { (a,b) -> a-b }
                changedPoints += actualDelta
                evolutionNews += "${current.name}: ${attributeChanges.joinToString(", ")}"
            }
            banks[id] = bank
        }
        saveDriverAttributes(attrs)
        saveDriverEvolutionPhases(phases)
        writeAnnualAttributeGains(annual)
        writeDoubleMap("driverEvolutionBank_$season", banks)

        // The news feed is an audit surface for the evolution engine. Do not wait
        // for the integer Overall to change: an attribute can move while the
        // seven-attribute average remains on the same integer. Publish one
        // consolidated GP event so the feed stays useful even with 100 drivers.
        val market = loadDriverMarket()
        if (market != null) {
            val headline = if (changedDrivers > 0) {
                "GP $round processado: $changedDrivers de $processedDrivers pilotos receberam evolução (+$changedPoints ponto(s) distribuídos)."
            } else {
                "GP $round processado: evolução calculada para $processedDrivers pilotos; nenhum atributo cruzou o próximo ponto inteiro nesta rodada."
            }
            val details = evolutionNews.take(12).joinToString(" • ")
            val suffix = if (evolutionNews.size > 12) " • +${evolutionNews.size - 12} piloto(s)" else ""
            val message = if (details.isBlank()) headline else "$headline $details$suffix"
            saveDriverMarket(market.copy(notifications = market.notifications + MarketNotification(
                season, round, "EVOLUÇÃO DE PILOTOS", message, true, MarketNewsCategory.DRIVER_EVOLUTION
            )).normalized())
        }
        return changes
    }

    /** Applies the canonical end-of-season regression once, preserving the career phase. */
    fun applySeasonEndRegression(seasonToClose:Int): Int {
        if (seasonToClose != season) return 0
        if (prefs.getInt("driverRegressionAppliedSeason", 0) == seasonToClose) return 0
        val attrs = driverAttributes().toMutableMap()
        val phases = readDriverEvolutionPhases()
        val rng = kotlin.random.Random(20261006 + seasonToClose * 7919)
        var changed = 0
        WorldDatabase.allDrivers.forEach { base ->
            val a=attrs[base.id] ?: intArrayOf(base.speed,base.qualifying,base.overtaking,base.defense,base.consistency,base.wet,base.tyre)
            var current=base.copy(speed=a[0],qualifying=a[1],overtaking=a[2],defense=a[3],consistency=a[4],wet=a[5],tyre=a[6])
            var phase=phases[base.id] ?: "GROWING"
            val ceiling=DriverProfileCatalog.ceiling(current.driverClass)
            val overall=DriverProfileCatalog.overall(current.ratings())
            phase=DriverEvolutionEngine.phaseFor(overall,ceiling,phase)
            if (phase=="REGRESSION") {
                val before=current.ratings().sum()
                current=DriverEvolutionEngine.applyRegression(current,1,rng)
                changed += before-current.ratings().sum()
                val after=DriverProfileCatalog.overall(current.ratings())
                phase=if(after<=49) "RECOVERY" else "REGRESSION"
            }
            attrs[base.id]=current.ratings().toList()
            phases[base.id]=phase
        }
        saveDriverAttributes(attrs)
        saveDriverEvolutionPhases(phases)
        prefs.edit().putInt("driverRegressionAppliedSeason",seasonToClose).apply()
        return changed
    }

    /**
     * One-time compatibility audit for careers created before V51. Older builds
     * could persist driver evolution while failing to expose it in the in-memory
     * news feed, and they only published news when the integer Overall changed.
     * Reconstruct a compact audit event from the persisted attribute state so an
     * existing career can immediately prove whether evolution has already occurred.
     */
    fun ensureDriverEvolutionAuditNews() {
        val market = loadDriverMarket() ?: return
        if (market.notifications.any { it.season == season && it.category == MarketNewsCategory.DRIVER_EVOLUTION }) return
        val completedRounds = history.raceRecords(season).map { it.round }.distinct().sorted()
        val lastRound = completedRounds.lastOrNull() ?: return
        val attrs = driverAttributes()
        val changes = WorldDatabase.allDrivers.mapNotNull { base ->
            val current = attrs[base.id] ?: return@mapNotNull null
            val before = intArrayOf(base.speed,base.qualifying,base.overtaking,base.defense,base.consistency,base.wet,base.tyre)
            val names = arrayOf("Velocidade","Classificação","Ultrapassagem","Defesa","Consistência","Chuva","Pneus")
            val details = names.indices.mapNotNull { i ->
                if (current[i] != before[i]) "${names[i]} ${before[i]}→${current[i]}" else null
            }
            if (details.isEmpty()) null else base.name to details.joinToString(", ")
        }
        val totalPoints = changes.sumOf { (_, details) ->
            details.split(", ").sumOf { part ->
                val values = Regex("(\\d+)→(\\d+)").find(part)?.groupValues
                if (values != null) values[2].toInt() - values[1].toInt() else 0
            }
        }
        val roundWeek = SeasonCalendar.forSeason(season).firstOrNull { it.round == lastRound }?.weekOfSeason ?: currentWeek
        val details = changes.take(12).joinToString(" • ") { "${it.first}: ${it.second}" }
        val suffix = if (changes.size > 12) " • +${changes.size - 12} piloto(s)" else ""
        val message = if (changes.isEmpty()) {
            "Auditoria retroativa após GP $lastRound: nenhum atributo persistido está diferente da base inicial."
        } else {
            "Auditoria retroativa após GP $lastRound: ${changes.size} piloto(s) já apresentam alterações de atributos (+$totalPoints ponto(s) líquidos). $details$suffix"
        }
        saveDriverMarket(market.copy(notifications = market.notifications + MarketNotification(
            season, roundWeek, "EVOLUÇÃO DE PILOTOS", message, true, MarketNewsCategory.DRIVER_EVOLUTION
        )).normalized())
    }

    fun startNewCareer(selectedTeamId: Int) {
        teamId = selectedTeamId; roundIndex = 0; currentWeek = 1; season = 2026; hasCareer = true
        writeMap("driverPoints", emptyMap()); writeMap("constructorPoints", emptyMap())
        for (r in 1..SeasonCalendar.forSeason(season).size) prefs.edit().remove("race_$r").apply()
        history.clear()
        prefs.edit().remove("driverEvolutionAppliedSeason").remove("driverRegressionAppliedSeason").remove("driverEvolutionBank_$season").remove("driverEvolutionAccumulated_$season").remove("driverEvolutionAttributeGains_$season").apply()
        saveDriverAttributes(WorldDatabase.allDrivers.associate { it.id to intArrayOf(it.speed,it.qualifying,it.overtaking,it.defense,it.consistency,it.wet,it.tyre) })
        initializeDriverSeasonTargets()
        val t=WorldDatabase.teams.first { it.id==selectedTeamId }
        saveCar(selectedTeamId, com.f1teammanager.core.manager.InitialTeamProfile.carState(t))
        saveGarage(selectedTeamId, com.f1teammanager.core.manager.TeamGarageFactory.fromInitial(t))
        saveResearch(selectedTeamId, TeamResearchState())
        saveFinance(selectedTeamId, TeamFinanceState(75_000_000L));
        prefs.edit().remove("aiTeamBudgets").remove("constructorPrizePaidTeams_2026").remove("aiFinanceSnapshot").remove("aiSponsorshipSnapshot").apply()
        putInt("annualDriverSalarySeason_${selectedTeamId}",0); saveSponsors(selectedTeamId, emptyList())
        saveDriverMarket(com.f1teammanager.core.manager.DriverMarketEngine().initialState(season))
    }

    /** True after GP 30 has been archived, while the game is still on the completed season. */
    fun isSeasonEnded(): Boolean =
        roundIndex == SeasonCalendar.forSeason(season).lastIndex && history.isSeasonFinalized(season)

    /**
     * Advance to the next GP after a completed race.
     * GP 30 is deliberately different: it only archives the season and leaves the
     * current year/round intact until the manager explicitly starts the next season.
     */
    fun completeCurrentRace() {
        if (roundIndex < SeasonCalendar.forSeason(season).lastIndex) {
            roundIndex += 1
            // Do NOT move currentWeek here. The completed GP happened in the current
            // week; the manager must return to the calendar and manually advance the
            // remaining free weeks until the next GP week.
        } else {
            history.finalizeSeason(season, driverPoints(), constructorPoints(), loadDriverMarket())
            // Stay on the completed season. No automatic year change here.
        }
    }

    /** Explicit player action: starts the archived season's successor. */
    fun startNextSeason() {
        require(isSeasonEnded()) { "A temporada atual ainda não foi encerrada." }
        season += 1
        roundIndex = 0
        currentWeek = 1
        writeMap("driverPoints", emptyMap())
        writeMap("constructorPoints", emptyMap())
        for (r in 1..SeasonCalendar.forSeason(season).size) prefs.edit().remove("race_$r").apply()
        prefs.edit().remove("driverEvolutionAppliedSeason").remove("driverRegressionAppliedSeason").remove("driverEvolutionBank_$season").remove("driverEvolutionAccumulated_$season").remove("driverEvolutionAttributeGains_$season").apply()
        initializeDriverSeasonTargets()
        loadDriverMarket()?.let { saveDriverMarket(com.f1teammanager.core.manager.DriverMarketEngine().applySeasonTransition(it, season)) }
    }

    /** Advance one or more real calendar weeks. Returns the number of weeks actually advanced. */
    fun advanceCalendarWeeks(weeks: Int): Int {
        val old = currentWeek
        currentWeek = (currentWeek + weeks.coerceAtLeast(0)).coerceAtMost(56)
        return currentWeek - old
    }

    fun jumpToWeek(week: Int): Int {
        val old = currentWeek
        currentWeek = week
        return currentWeek - old
    }
}
private object WorldTeamResolver { fun teamIdFor(driverId: Int): Int = ((driverId - 1) / 2) + 1 }
