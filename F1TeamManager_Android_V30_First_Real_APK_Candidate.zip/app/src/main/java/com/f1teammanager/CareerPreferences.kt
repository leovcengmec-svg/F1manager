package com.f1teammanager

import android.content.Context
import java.io.File
import org.json.JSONArray
import org.json.JSONObject
import com.f1teammanager.core.manager.DevelopmentProject
import com.f1teammanager.core.manager.FinanceEngine
import com.f1teammanager.core.manager.TeamManagerState
import com.f1teammanager.core.manager.DevelopmentIntensity
import com.f1teammanager.core.manager.ResearchProject
import com.f1teammanager.core.manager.ResearchDesign
import com.f1teammanager.core.manager.TeamResearchState
import com.f1teammanager.core.manager.CarPiece
import com.f1teammanager.core.manager.FactoryOrder
import com.f1teammanager.core.manager.TeamFactoryState
import com.f1teammanager.core.manager.TeamGarage
import com.f1teammanager.core.manager.PhysicalCar
import com.f1teammanager.core.manager.GarageCarId
import com.f1teammanager.core.manager.CarComponent
import com.f1teammanager.core.manager.ResearchFocus
import com.f1teammanager.core.manager.ResearchComplexity
import com.f1teammanager.core.manager.ResearchOutcome
import com.f1teammanager.core.manager.CarDevelopmentFocus
import com.f1teammanager.core.manager.TeamCarState
import com.f1teammanager.core.manager.TeamFinanceState
import com.f1teammanager.core.manager.TeamFacilitiesState
import com.f1teammanager.core.manager.FacilityType
import com.f1teammanager.core.manager.FacilityUpgradeState
import com.f1teammanager.core.manager.InitialTeamProfile
import com.f1teammanager.core.manager.SponsorContract
import com.f1teammanager.core.race.RaceResult
import com.f1teammanager.core.race.FinishEntry
import com.f1teammanager.core.race.LapEvent
import com.f1teammanager.core.race.EventType
import com.f1teammanager.core.race.Weather
import com.f1teammanager.core.race.QualifyingEntry
import com.f1teammanager.core.race.QualifyingPhase
import com.f1teammanager.core.race.QualifyingResult
import com.f1teammanager.core.season.RoundDefinition
import com.f1teammanager.core.race.Tyre
import com.f1teammanager.core.season.WorldDatabase
import com.f1teammanager.core.season.DriverEvolutionEngine
import com.f1teammanager.core.season.DriverProfileCatalog
import com.f1teammanager.core.manager.DriverMarketState
import com.f1teammanager.core.manager.DriverMarketEngine
import com.f1teammanager.core.manager.DriverDeal
import com.f1teammanager.core.manager.DriverOffer
import com.f1teammanager.core.manager.FutureDriverDeal
import com.f1teammanager.core.manager.DriverTeamRole
import com.f1teammanager.core.manager.SignatureFeeSchedule
import com.f1teammanager.core.manager.SignatureFeeAccounting
import com.f1teammanager.core.manager.SalaryLedger
import com.f1teammanager.core.manager.DriverRolePreference
import com.f1teammanager.core.manager.NegotiationStatus
import com.f1teammanager.core.manager.ScoutingReport
import com.f1teammanager.core.manager.MarketNotification
import com.f1teammanager.core.manager.MarketNewsCategory
import com.f1teammanager.core.season.SeasonCalendar

/** Persistent career metadata, championship ledger, race archive and car P&D state. */
class CareerPreferences(context: Context) {
    val history = HistoricalDatabase(context)
    private val transitionContext = context.applicationContext
    private val prefs = context.getSharedPreferences("f1tm_career", Context.MODE_PRIVATE)

    init {
        // Keep the team selector and the new career on the exact same initial-car
        // draw. Previously the selector used the fallback seed, then startNewCareer
        // generated a different seed; this changed the car overalls and reordered
        // the teams immediately after selection.
        val storedSeason = prefs.getInt("season", 2026)
        val storedSeed = prefs.getInt("calendarSeed_$storedSeason", 0)
        val seed = if (prefs.getBoolean("hasCareer", false) && storedSeed != 0) {
            storedSeed
        } else {
            val pending = prefs.getInt("pendingCareerSeed", 0)
            if (pending != 0) pending else kotlin.random.Random.nextInt().let { generated ->
                val safe = if (generated == 0) 1 else generated
                prefs.edit().putInt("pendingCareerSeed", safe).apply()
                safe
            }
        }
        if (!prefs.getBoolean("hasCareer", false)) {
            prefs.edit().putInt("pendingCareerSeed", seed).apply()
        } else if (storedSeed != 0) {
            SeasonCalendar.configureSeasonSeed(storedSeason, storedSeed)
        }
        com.f1teammanager.core.manager.InitialTeamProfile.configureCareerSeed(seed)
    }

    /** Persisted regulatory draw: reopening a career never rerolls a season rule. */
    fun loadCarRegulationRule(seasonNumber: Int): com.f1teammanager.core.manager.AnnualCarRegulationEngine.SeasonRule? {
        if (seasonNumber < 1) return null
        val encoded = prefs.getString("carRegulationRule_$seasonNumber", null) ?: return null
        val decoded = com.f1teammanager.core.manager.AnnualCarRegulationEngine.decode(encoded) ?: return null
        // Reject V443 drafts that accidentally treated the calendar year as an ordinal.
        val expectedIndex = com.f1teammanager.core.manager.AnnualCarRegulationEngine.seasonIndexForCalendarYear(seasonNumber)
        return decoded.takeIf { it.season == expectedIndex }
    }

    fun ensureCarRegulationRule(seasonNumber: Int): com.f1teammanager.core.manager.AnnualCarRegulationEngine.SeasonRule {
        require(seasonNumber >= 1)
        loadCarRegulationRule(seasonNumber)?.let { return it }
        // Regulatory rules are global to the championship, not tied to each team's
        // calendar draw. Match the shared seed used by AI season-chain simulation.
        val seed = 20261005
        val rule = com.f1teammanager.core.manager.AnnualCarRegulationEngine.generateForCalendarYear(seasonNumber, seed)
        check(prefs.edit().putString("carRegulationRule_$seasonNumber",
            com.f1teammanager.core.manager.AnnualCarRegulationEngine.encode(rule)).commit()) {
            "Não foi possível salvar o regulamento da temporada $seasonNumber"
        }
        return rule
    }

    private fun newCalendarSeed(season: Int): Int {
        val seed = kotlin.random.Random.nextInt().let { if (it == 0) 1 else it }
        prefs.edit().putInt("calendarSeed_$season", seed).apply()
        SeasonCalendar.configureSeasonSeed(season, seed)
        com.f1teammanager.core.manager.InitialTeamProfile.configureCareerSeed(seed)
        return seed
    }

    var hasCareer: Boolean
        get() = prefs.getBoolean("hasCareer", false)
        private set(value) = prefs.edit().putBoolean("hasCareer", value).apply()
    var teamId: Int
        get() = prefs.getInt("teamId", 1)
        private set(value) = prefs.edit().putInt("teamId", value).apply()
    var roundIndex: Int
        get() = prefs.getInt("roundIndex", 0)
        private set(value) = prefs.edit().putInt("roundIndex", value.coerceIn(0, SeasonCalendar.forSeason(season).lastIndex)).apply()
    /** Current calendar week. Race weekends occupy specific weeks; the other weeks are free development weeks. */
    var currentWeek: Int
        get() = prefs.getInt("currentWeek", SeasonCalendar.forSeason(season).first().weekOfSeason.coerceAtLeast(1) - 2).coerceIn(1, 56)
        private set(value) = prefs.edit().putInt("currentWeek", value.coerceIn(1, 56)).apply()
    var season: Int
        get() = prefs.getInt("season", 2026)
        private set(value) = prefs.edit().putInt("season", value).apply()

    private fun readMap(key: String): Map<Int, Int> = prefs.getString(key, "").orEmpty().split(',').mapNotNull { token ->
        val p = token.split(':')
        if (p.size == 2) p[0].toIntOrNull()?.let { id -> p[1].toIntOrNull()?.let { value -> id to value } } else null
    }.toMap()
    private fun writeMap(key: String, value: Map<Int, Int>) = prefs.edit().putString(key, value.entries.sortedBy { it.key }.joinToString(",") { "${it.key}:${it.value}" }).apply()

    private fun readDoubleMap(key: String): Map<Int, Double> = prefs.getString(key, "").orEmpty().split(',').mapNotNull { token ->
        val p=token.split(':')
        if (p.size != 2) null else p[0].toIntOrNull()?.let { id -> p[1].toDoubleOrNull()?.let { value -> id to value } }
    }.toMap()
    private fun writeDoubleMap(key: String, value: Map<Int, Double>) = prefs.edit().putString(key, value.entries.sortedBy { it.key }.joinToString(",") { "${it.key}:${it.value}" }).apply()
    fun driverPoints(): Map<Int, Int> = readMap("driverPoints")
    fun constructorPoints(): Map<Int, Int> = readMap("constructorPoints")

    /** V36 canonical financial settlement ledger for every team, including AI. */
    fun aiTeamBudget(teamId: Int): Long {
        val raw = prefs.getString("aiTeamBudgets", "").orEmpty()
        return raw.split(";").firstOrNull { it.startsWith("$teamId:") }?.substringAfter(":")?.toLongOrNull()
            ?: WorldDatabase.teams.firstOrNull { it.id == teamId }?.let { InitialTeamProfile.initialBudget(it) }
                ?: 0L
    }

    fun loadAiFinanceSnapshot(): String = prefs.getString("aiFinanceSnapshot", "").orEmpty()
    fun saveAiFinanceSnapshot(raw:String): Boolean = prefs.edit().putString("aiFinanceSnapshot", raw).commit()
    fun loadAiSponsorshipSnapshot(): String = prefs.getString("aiSponsorshipSnapshot", "").orEmpty()
    fun saveAiSponsorshipSnapshot(raw:String): Boolean = prefs.edit().putString("aiSponsorshipSnapshot", raw).commit()

    /**
     * Random event seed is generated once per career-season and persisted. It is never
     * a source-code constant: new careers receive a fresh seed, while reloads and
     * week advances reuse the same seed and cannot reroll already scheduled events.
     */
    fun annualEventSeed(seasonNumber: Int): Int {
        require(seasonNumber >= 1)
        val key = "annualEventSeed_$seasonNumber"
        val existing = prefs.getInt(key, 0)
        if (existing != 0) return existing
        val generated = kotlin.random.Random.nextInt().let { if (it == 0) 1 else it }
        prefs.edit().putInt(key, generated).commit()
        return prefs.getInt(key, generated)
    }

    /** V260: persist the season event calendar so loading a career never rerolls it. */
    fun loadAnnualEventCalendar(seasonNumber: Int): List<com.f1teammanager.core.manager.AnnualTeamEventSeasonCalendar.Slot> {
        val raw = prefs.getString("annualEventCalendar_$seasonNumber", null) ?: return emptyList()
        return raw.split(";").mapNotNull { entry ->
            val parts = entry.split(",")
            if (parts.size != 3) null else runCatching {
                com.f1teammanager.core.manager.AnnualTeamEventSeasonCalendar.Slot(
                    week = parts[0].toInt(),
                    kind = com.f1teammanager.core.manager.AnnualTeamEventEngine.Kind.valueOf(parts[1]),
                    ordinal = parts[2].toInt()
                ).takeIf { it.week in 1..56 && it.ordinal > 0 }
            }.getOrNull()
        }.distinctBy { it.week to it.ordinal }.sortedBy { it.week }
    }

    /** Writes only when absent, preserving the original draw for the entire season. */
    fun ensureAnnualEventCalendar(seasonNumber: Int, seed: Int): List<com.f1teammanager.core.manager.AnnualTeamEventSeasonCalendar.Slot> {
        require(seasonNumber >= 1)
        val existing = loadAnnualEventCalendar(seasonNumber)
        if (prefs.contains("annualEventCalendar_$seasonNumber")) return existing
        val generated = com.f1teammanager.core.manager.AnnualTeamEventSeasonCalendar.generate(seasonNumber, seed)
        val serialized = generated.joinToString(";") { "${it.week},${it.kind.name},${it.ordinal}" }
        prefs.edit().putString("annualEventCalendar_$seasonNumber", serialized).commit()
        return loadAnnualEventCalendar(seasonNumber)
    }

    /**
     * V264: returns only the events scheduled for a specific week that have not
     * been recorded as processed. This is a read-only claim check: callers must
     * apply and persist effects before calling markAnnualEventKeysProcessed.
     */
    fun pendingAnnualEventsForWeek(
        seasonNumber: Int,
        week: Int,
        seed: Int
    ): List<com.f1teammanager.core.manager.AnnualTeamEventSeasonCalendar.Slot> {
        if (seasonNumber < 1 || week !in 1..56) return emptyList()
        val calendar = ensureAnnualEventCalendar(seasonNumber, seed)
        val processed = loadProcessedAnnualEventKeys(seasonNumber)
        return calendar.filter { slot ->
            slot.week == week &&
                "${slot.week}:${slot.kind.name}:${slot.ordinal}" !in processed
        }
    }

    /** V264: stable keys for a due batch; persist only after successful effects. */
    fun annualEventKeysFor(
        slots: List<com.f1teammanager.core.manager.AnnualTeamEventSeasonCalendar.Slot>
    ): Set<String> = slots.map { "${it.week}:${it.kind.name}:${it.ordinal}" }.toSet()

    /** Event/week idempotency ledger, persisted separately from the generated calendar. */
    fun loadProcessedAnnualEventKeys(seasonNumber: Int): Set<String> =
        prefs.getString("annualEventProcessed_$seasonNumber", "").orEmpty().split("|").filter { it.isNotBlank() }.toSet()

    fun markAnnualEventKeysProcessed(seasonNumber: Int, keys: Set<String>) {
        require(seasonNumber >= 1)
        val merged = (loadProcessedAnnualEventKeys(seasonNumber) + keys).toSortedSet().toList().takeLast(1000)
        prefs.edit().putString("annualEventProcessed_$seasonNumber", merged.joinToString("|")).commit()
    }

    private fun saveAiTeamBudgets(values: Map<Int, Long>) {
        prefs.edit().putString("aiTeamBudgets", values.toSortedMap().entries.joinToString(";") { "${it.key}:${it.value}" }).apply()
    }

    /**
     * The only Android-facing season-prize entry point. It settles all 40 teams
     * atomically from the same constructor standings used by the history.
     * Idempotency is per season and per team, so reopening GP30 cannot duplicate money.
     */
    fun settleConstructorsSeason(seasonToClose: Int): List<com.f1teammanager.core.manager.SeasonSettlementEngine.Settlement> {
        require(season == seasonToClose) { "Temporada de fechamento divergente" }
        if (!history.isSeasonFinalized(seasonToClose)) {
            history.finalizeSeason(seasonToClose, driverPoints(), constructorPoints(), loadDriverMarket())
        }
        val settlements = com.f1teammanager.core.manager.SeasonSettlementEngine.settleAll(constructorPoints())
        val paid = prefs.getString("constructorPrizePaidTeams_$seasonToClose", "").orEmpty().split(",").mapNotNull { it.toIntOrNull() }.toMutableSet()
        var aiBudgets = WorldDatabase.teams.filter { it.id != teamId }.associate { it.id to aiTeamBudget(it.id) }.toMutableMap()
        val playerFinance = loadFinance(teamId, TeamFinanceState(0L))
        var player = playerFinance
        settlements.forEach { settlement ->
            if (settlement.teamId == teamId) {
                if (teamId !in paid) {
                    player = FinanceEngine().applySeasonConstructorsPrize(
                        TeamManagerState(playerTeamId=teamId, season=seasonToClose, round=SeasonCalendar.forSeason(season).size,
                            car=TeamCarState(70,70,70,70), finance=player, driverMarket=loadDriverMarket() ?: DriverMarketEngine().initialState(seasonToClose)),
                        seasonToClose, settlement.position
                    ).finance
                }
            } else if (settlement.teamId !in paid) {
                aiBudgets[settlement.teamId] = aiBudgets.getValue(settlement.teamId) + settlement.prize
            }
        }
        if (teamId !in paid) {
            saveFinance(teamId, player)
        }
        paid.addAll(settlements.map { it.teamId })
        prefs.edit().putString("constructorPrizePaidTeams_$seasonToClose", paid.sorted().joinToString(",")).apply()
        saveAiTeamBudgets(aiBudgets)
        return settlements
    }
    fun previousDriverPositions(): Map<Int, Int> = readMap("previousDriverPositions")
    fun previousConstructorPositions(): Map<Int, Int> = readMap("previousConstructorPositions")

    fun loadDriverMarket(): DriverMarketState? = runCatching {
        val rawContracts = prefs.getString("marketContracts", null) ?: return null
        val contracts = rawContracts.split(';').filter { it.isNotBlank() }.mapNotNull { row ->
            val p=row.split(','); runCatching {
                if (p.size >= 8) DriverDeal(p[0].toInt(),p[1].toInt(),p[2].toInt(),p[3].toLong(),p[4].toLong(),p[6].toInt(),DriverTeamRole.valueOf(p[7]))
                else if (p.size >= 7) DriverDeal(p[0].toInt(),p[1].toInt(),p[2].toInt(),p[3].toLong(),p[4].toLong(),p[5].toInt(),runCatching { DriverTeamRole.valueOf(p[6]) }.getOrDefault(DriverTeamRole.EQUAL))
                else null
            }.getOrNull()
        }
        val free=prefs.getString("marketFree", "").orEmpty().split(',').mapNotNull{it.toIntOrNull()}
        val scheduled=prefs.getString("marketScheduled", "").orEmpty().split(';').filter{it.isNotBlank()}.mapNotNull { row ->
            val p=row.split(','); runCatching {
                if (p.size >= 10) FutureDriverDeal(p[0].toInt(),p[1].toInt(),p[2].toInt(),p[3].toInt(),p[4].toInt(),p[5].toLong(),DriverTeamRole.valueOf(p[6]),p[7].toInt(),p.getOrNull(9)?.toIntOrNull())
                else if (p.size >= 9) FutureDriverDeal(p[0].toInt(),p[1].toInt(),p[2].toInt(),p[3].toInt(),p[4].toInt(),p[5].toLong(),DriverTeamRole.valueOf(p[6]),p[7].toInt(),p[8].toIntOrNull())
                else null
            }.getOrNull()
        }
        val roles=prefs.getString("marketRoles", "").orEmpty().split(',').mapNotNull{part -> val p=part.split(':'); if(p.size==2) runCatching{p[0].toInt() to DriverRolePreference.valueOf(p[1])}.getOrNull() else null}.toMap()
        val pending=prefs.getString("marketPending", "").orEmpty().split(';').filter{it.isNotBlank()}.mapNotNull { row ->
            val p=row.split(','); runCatching {
                if (p.size >= 13 && runCatching { NegotiationStatus.valueOf(p[10]) }.isSuccess) DriverOffer(p[0].toInt(),p[1].toInt(),p[2].toInt(),p[3].toInt(),p[4].toLong(),DriverTeamRole.valueOf(p[5]),p[6].toLong(),p[7].toInt(),p[8].toInt(),p[9].toInt(),NegotiationStatus.valueOf(p[10]),p[11].toInt(),p.getOrNull(12)?.toIntOrNull(),p.getOrNull(13)?.toIntOrNull() ?: 0)
                else if (p.size >= 13) DriverOffer(p[0].toInt(),p[1].toInt(),p[2].toInt(),p[3].toInt(),p[4].toLong(),DriverTeamRole.valueOf(p[5]),p[6].toLong(),p[8].toInt(),p[9].toInt(),p[10].toInt(),NegotiationStatus.valueOf(p[11]),p[12].toInt(),null,0)
                else null
            }.getOrNull()
        }
        val scouting=prefs.getString("marketScouting", "").orEmpty().split(';').filter{it.isNotBlank()}.mapNotNull { row ->
            val p=row.split(','); runCatching {
                if (p.size >= 12) ScoutingReport(p[0].toInt(),p[1].toInt(),p[2].toLong(),p[3].toInt(),p[4].toInt(),p[5].toLong(),p[6].toLong(),DriverRolePreference.valueOf(p[8]),p[9].toInt(),p[10].toInt(),p[11])
                else if (p.size >= 10) ScoutingReport(p[0].toInt(),p[1].toInt(),p[2].toLong(),p[3].toInt(),p[4].toInt(),p[5].toLong(),p[6].toLong(),DriverRolePreference.valueOf(p[8]),p[9].toInt(),2026,"")
                else if (p.size >= 9) ScoutingReport(p[0].toInt(),p[1].toInt(),p[2].toLong(),p[3].toInt(),p[4].toInt(),p[5].toLong(),p[6].toLong(),DriverRolePreference.valueOf(p[7]),p[8].toInt(),2026,"")
                else null
            }.getOrNull()
        }
        val notifications=prefs.getString("marketNotifications", "").orEmpty().split(';').filter{it.isNotBlank()}.mapNotNull { row ->
            val p=row.split('|', limit=6); if(p.size<5) null else runCatching { MarketNotification(p[0].toInt(),p[1].toInt(),p[2],p[3],p[4].toBoolean(), p.getOrNull(5)?.let { runCatching { com.f1teammanager.core.manager.MarketNewsCategory.valueOf(it) }.getOrNull() } ?: com.f1teammanager.core.manager.MarketNewsCategory.MARKET) }.getOrNull()
        }
        DriverMarketState(contracts=contracts,freeAgents=free,scheduled=scheduled,rolePreferences=roles,pending=pending,scouting=scouting,notifications=notifications).normalized()
    }.getOrNull()

    fun loadReadNewsKeys(): Set<String> = prefs.getString("marketNewsReadKeys", "").orEmpty()
        .split(";").filter { it.isNotBlank() }.toSet()

    fun markNewsRead(keys: Collection<String>) {
        if (keys.isEmpty()) return
        val merged = (loadReadNewsKeys() + keys).toList().takeLast(5000).toSet()
        prefs.edit().putString("marketNewsReadKeys", merged.joinToString(";")).apply()
    }

    fun saveDriverMarket(state: DriverMarketState) {
        driverMarketEditor(prefs.edit(), state).apply()
    }

    private fun driverMarketEditor(
        editor: android.content.SharedPreferences.Editor,
        state: DriverMarketState
    ): android.content.SharedPreferences.Editor {
        val s = state.normalized()
        return editor
            .putString("marketContracts", s.contracts.joinToString(";") { listOf(it.driverId,it.teamId,it.years,it.salary,it.marketValue,it.seasonSigned,it.role.name).joinToString(",") })
            .putString("marketFree", s.freeAgents.joinToString(","))
            .putString("marketScheduled", s.scheduled.joinToString(";") { listOf(it.driverId,it.fromTeamId,it.toTeamId,it.startSeason,it.years,it.salary,it.role.name,it.signedSeason,it.replaceDriverId).joinToString(",") })
            .putString("marketRoles", s.rolePreferences.entries.joinToString(",") { "${it.key}:${it.value.name}" })
            .putString("marketPending", s.pending.joinToString(";") { listOf(it.driverId,it.fromTeamId,it.toTeamId,it.years,it.salary,it.role.name,it.marketValue,it.interestScore,it.round,it.expiresAfterWeek,it.status.name,it.seasonTarget,it.replaceDriverId,it.proposerTeamId).joinToString(",") })
            .putString("marketScouting", s.scouting.joinToString(";") { listOf(it.driverId,it.teamId,it.cost,it.createdWeek,it.expiresWeek,it.expectedSalary,it.marketValue,it.rolePreference.name,it.interest,it.season,it.attributeRanges).joinToString(",") })
            .putString("marketNotifications", s.notifications.joinToString(";") { listOf(it.season,it.week,it.title.replace(";", ",").replace("|", "/"),it.message.replace(";", ",").replace("|", "/"),it.important,it.category.name).joinToString("|") })
    }

    /** Commit market updates and removal of a durable pending-news outbox together. */
    private fun saveDriverMarketAndClearPendingNews(state: DriverMarketState, pendingKey: String): Boolean =
        driverMarketEditor(prefs.edit(), state).remove(pendingKey).commit()

    /** Stable key for a result; round numbers repeat every season. */
    private fun raceResultKey(seasonNumber: Int, round: Int): String =
        com.f1teammanager.core.manager.RaceResultStoragePolicy.canonicalKey(seasonNumber, round)

    /**
     * A result is committed per season and round. The legacy `race_$round` keys
     * are considered only for season 1 because they contain no season identity and
     * otherwise could incorrectly block the same round in every later season.
     */
    fun isRaceRecorded(round: Int): Boolean {
        if (round !in 1..SeasonCalendar.forSeason(season).size) return false
        return prefs.contains(raceResultKey(season, round)) || (season == 1 && prefs.contains("race_$round"))
    }

    /**
     * Persist the exact completed weekend before applying any career effects. The key is
     * season/round scoped so a stale result can never be attached to a later GP.
     */
    fun savePendingRaceFinalization(seasonNumber: Int, round: Int, totalLaps: Int, result: RaceResult): Boolean {
        if (seasonNumber <= 0 || round !in 1..SeasonCalendar.forSeason(seasonNumber).size || totalLaps <= 0) return false
        return runCatching {
            val root = JSONObject()
                .put("season", seasonNumber)
                .put("round", round)
                .put("totalLaps", totalLaps)
                .put("weather", result.weather.name)
                .put("fastestLapDriverId", result.fastestLapDriverId ?: JSONObject.NULL)
                .put("fastestLapTimeMs", result.fastestLapTimeMs)
                .put("safetyCarLaps", result.safetyCarLaps)
                .put("vscLaps", result.vscLaps)
            val classification = JSONArray()
            result.classification.forEach { entry ->
                classification.put(JSONObject().put("position", entry.position).put("driverId", entry.driverId)
                    .put("driverName", entry.driverName).put("teamName", entry.teamName).put("laps", entry.laps)
                    .put("totalTimeMs", entry.totalTimeMs).put("status", entry.status)
                    .put("tyre", entry.tyre.name).put("pitStops", entry.pitStops))
            }
            root.put("classification", classification)
            val events = JSONArray()
            result.events.forEach { event ->
                events.put(JSONObject().put("lap", event.lap).put("driverId", event.driverId ?: JSONObject.NULL)
                    .put("type", event.type.name).put("detail", event.detail))
            }
            root.put("events", events)
            val points = JSONObject()
            result.points.forEach { (driverId, value) -> points.put(driverId.toString(), value) }
            root.put("points", points)
            val qualifying = result.qualifying
            if (qualifying == null) root.put("qualifying", JSONObject.NULL) else {
                fun entriesJson(entries: List<QualifyingEntry>) = JSONArray().also { array -> entries.forEach { e ->
                    array.put(JSONObject().put("driverId", e.driverId).put("position", e.position).put("lapTimeMs", e.lapTimeMs))
                } }
                val q = JSONObject().put("grid", entriesJson(qualifying.grid))
                val phases = JSONArray()
                qualifying.phases.forEach { phase ->
                    phases.put(JSONObject().put("name", phase.name).put("entries", entriesJson(phase.entries))
                        .put("eliminatedDriverIds", JSONArray().also { ids -> phase.eliminatedDriverIds.forEach { ids.put(it) } }))
                }
                q.put("phases", phases)
                root.put("qualifying", q)
            }
            prefs.edit().putString(pendingRaceKey(seasonNumber, round), root.toString()).commit()
        }.getOrDefault(false)
    }

    fun loadPendingRaceFinalization(seasonNumber: Int, round: Int): PendingRaceFinalization? {
        val raw = prefs.getString(pendingRaceKey(seasonNumber, round), null) ?: return null
        return runCatching {
        val root = JSONObject(raw)
        if (root.getInt("season") != seasonNumber || root.getInt("round") != round) error("Pending race identity mismatch")
        val classification = root.getJSONArray("classification").let { array ->
            (0 until array.length()).map { i -> array.getJSONObject(i).let { item ->
                FinishEntry(item.getInt("position"), item.getInt("driverId"), item.getString("driverName"),
                    item.getString("teamName"), item.getInt("laps"), item.getLong("totalTimeMs"),
                    item.getString("status"), Tyre.valueOf(item.getString("tyre")), item.getInt("pitStops"))
            } }
        }
        val events = root.getJSONArray("events").let { array ->
            (0 until array.length()).map { i -> array.getJSONObject(i).let { item ->
                LapEvent(item.getInt("lap"), if (item.isNull("driverId")) null else item.getInt("driverId"),
                    EventType.valueOf(item.getString("type")), item.getString("detail"))
            } }
        }
        val pointsObject = root.getJSONObject("points")
        val points = pointsObject.keys().asSequence().associate { key -> key.toInt() to pointsObject.getInt(key) }
        val qualifying = if (root.isNull("qualifying")) null else root.getJSONObject("qualifying").let { q ->
            fun parseEntries(array: JSONArray) = (0 until array.length()).map { i -> array.getJSONObject(i).let { e ->
                QualifyingEntry(e.getInt("driverId"), e.getInt("position"), e.getLong("lapTimeMs"))
            } }
            val grid = parseEntries(q.getJSONArray("grid"))
            val phasesJson = q.getJSONArray("phases")
            val phases = (0 until phasesJson.length()).map { i -> phasesJson.getJSONObject(i).let { phase ->
                val eliminated = phase.getJSONArray("eliminatedDriverIds")
                QualifyingPhase(phase.getString("name"), parseEntries(phase.getJSONArray("entries")),
                    (0 until eliminated.length()).map { eliminated.getInt(it) })
            } }
            QualifyingResult(grid, phases)
        }
        val fastest = if (root.isNull("fastestLapDriverId")) null else root.getInt("fastestLapDriverId")
        val result = RaceResult(classification, events, fastest, Weather.valueOf(root.getString("weather")), points,
            root.getInt("safetyCarLaps"), root.getInt("vscLaps"), root.getLong("fastestLapTimeMs"), qualifying)
        PendingRaceFinalization(seasonNumber, round, root.getInt("totalLaps"), result)
        }.getOrNull()
    }

    fun clearPendingRaceFinalization(seasonNumber: Int, round: Int): Boolean =
        prefs.edit().remove(pendingRaceKey(seasonNumber, round)).commit()

    private fun pendingRaceKey(seasonNumber: Int, round: Int) = "pending_race_result_${seasonNumber}_$round"

    /** Durable per-step journal for recovering a GP finalization after process death. */
    private fun raceFinalizationKey(seasonNumber: Int, round: Int, step: String) =
        "race_finalize_${seasonNumber}_${round}_$step"

    fun isRaceFinalizationStepDone(seasonNumber: Int, round: Int, step: String): Boolean =
        prefs.getBoolean(raceFinalizationKey(seasonNumber, round, step), false)

    /**
     * Persist a finalization journal marker synchronously and report whether the
     * commit reached SharedPreferences storage. Callers must not present the GP as
     * finalized when this returns false.
     */
    fun markRaceFinalizationStepDone(seasonNumber: Int, round: Int, step: String): Boolean =
        prefs.edit().putBoolean(raceFinalizationKey(seasonNumber, round, step), true).commit()

    fun isRaceFinalized(seasonNumber: Int, round: Int): Boolean =
        isRaceFinalizationStepDone(seasonNumber, round, "complete")

    fun isRaceResultAcknowledged(seasonNumber: Int, round: Int): Boolean =
        prefs.getBoolean("race_result_acknowledged_${seasonNumber}_$round", false)

    fun markRaceResultAcknowledged(seasonNumber: Int, round: Int): Boolean =
        prefs.edit().putBoolean("race_result_acknowledged_${seasonNumber}_$round", true).commit()

    /**
     * Acknowledge the completed result and advance the calendar in one durable
     * SharedPreferences transaction. This removes the old crash window where the
     * acknowledgement could be saved but roundIndex could remain on the same GP.
     * Repeated calls are safe: a round already passed is acknowledged without
     * advancing the calendar a second time. GP 30 remains on the completed season.
     */
    @Synchronized
    fun acknowledgeRaceAndAdvance(seasonNumber: Int, round: Int): Boolean {
        if (seasonNumber != season) return false
        val totalRounds = SeasonCalendar.forSeason(seasonNumber).size
        if (round !in 1..totalRounds || !isRaceFinalized(seasonNumber, round)) return false

        val currentIndex = roundIndex
        if (currentIndex < round - 1) return false
        val nextIndex = when {
            round == totalRounds -> currentIndex
            currentIndex == round - 1 -> round
            else -> currentIndex
        }
        val editor = prefs.edit()
            .putBoolean("race_result_acknowledged_${seasonNumber}_$round", true)
        if (round < totalRounds && nextIndex != currentIndex) {
            editor.putInt("roundIndex", nextIndex)
        }
        if (!editor.commit()) return false

        // The season archive is normally finalized by recordRace at GP 30. Reconcile
        // it here as a defensive recovery in case a legacy save missed that archive.
        if (round == totalRounds) {
            history.finalizeSeason(seasonNumber, driverPoints(), constructorPoints(), loadDriverMarket())
        }
        return true
    }

    @Synchronized
    fun recordRace(round: Int, result: RaceResult, seasonRound: RoundDefinition? = null, qualifying: QualifyingResult? = null) {
        // V361: the championship transaction and the historical archive are two
        // different storage systems. If the process died after the points transaction
        // committed but before HistoricalDatabase finished, the canonical race marker
        // exists while the archive may be missing the GP. Reconcile the archive on a
        // repeated callback instead of returning before repairing it. HistoricalDatabase
        // replaces the same season/round rows, so this replay is idempotent and does not
        // add championship points a second time.
        if (isRaceRecorded(round)) {
            if (seasonRound != null) {
                val activeMarket = loadDriverMarket()
                history.recordRace(season, seasonRound, result, qualifying, activeMarket)
                if (seasonRound.round == SeasonCalendar.forSeason(season).size) {
                    history.finalizeSeason(season, driverPoints(), constructorPoints(), activeMarket)
                }
            }
            return
        }
        // Capture the championship order BEFORE adding this GP. The standings screen
        // uses this snapshot to show who went up, down or stayed in the same place
        // after each completed race.
        val oldDriverPoints = driverPoints()
        val oldConstructorPoints = constructorPoints()
        val activeIdsForStandings = loadDriverMarket()?.contracts?.filter { it.activeIn(season) }?.map { it.driverId }?.distinct()
            ?: WorldDatabase.drivers.map { it.id }
        val oldDriverOrder = activeIdsForStandings
            .map { it to (oldDriverPoints[it] ?: 0) }
            .sortedWith(compareByDescending<Pair<Int,Int>> { it.second }.thenBy { it.first })
            .mapIndexed { index, row -> row.first to index + 1 }
            .toMap()
        val oldConstructorOrder = WorldDatabase.teams
            .map { it.id to (oldConstructorPoints[it.id] ?: 0) }
            .sortedWith(compareByDescending<Pair<Int,Int>> { it.second }.thenBy { it.first })
            .mapIndexed { index, row -> row.first to index + 1 }
            .toMap()
        val drivers = oldDriverPoints.toMutableMap()
        result.points.forEach { (id, pts) -> drivers[id] = (drivers[id] ?: 0) + pts }
        val teams = oldConstructorPoints.toMutableMap()
        val activeMarket = loadDriverMarket()
        result.classification.forEach { f ->
            val tid = activeMarket?.contracts?.firstOrNull { it.driverId == f.driverId && it.activeIn(season) }?.teamId
                ?: WorldDatabase.teams.firstOrNull { it.name.equals(f.teamName, ignoreCase = true) }?.id
                ?: WorldTeamResolver.teamIdFor(f.driverId)
            teams[tid] = (teams[tid] ?: 0) + (result.points[f.driverId] ?: 0)
        }
        val encoded = result.classification.joinToString(";") { f ->
            val teamId = activeMarket?.contracts?.firstOrNull { it.driverId == f.driverId && it.activeIn(season) }?.teamId
                ?: WorldDatabase.teams.firstOrNull { it.name.equals(f.teamName, ignoreCase = true) }?.id
                ?: WorldTeamResolver.teamIdFor(f.driverId)
            listOf(f.position, f.driverId, f.laps, f.totalTimeMs, f.status.replace(";", ","), f.tyre.name, f.pitStops, result.points[f.driverId] ?: 0, teamId).joinToString(",")
        }
        // V359: standings snapshots, both point tables, and the canonical race
        // result are committed in one SharedPreferences transaction. Previously,
        // each map and the result marker were written independently, so process death
        // could leave points partially applied while the race still looked unrecorded.
        fun encodeIntMap(value: Map<Int, Int>) = value.entries.sortedBy { it.key }
            .joinToString(",") { "${it.key}:${it.value}" }
        val committed = prefs.edit()
            .putString("previousDriverPositions", encodeIntMap(oldDriverOrder))
            .putString("previousConstructorPositions", encodeIntMap(oldConstructorOrder))
            .putString("driverPoints", encodeIntMap(drivers))
            .putString("constructorPoints", encodeIntMap(teams))
            .putString(raceResultKey(season, round), encoded)
            // Retain legacy alias for older readers/imports during the migration window.
            .putString("race_$round", encoded)
            .commit()
        check(committed) { "Não foi possível confirmar atomicamente o resultado e a pontuação do GP $round/temporada $season" }
        if (seasonRound != null) {
            history.recordRace(season, seasonRound, result, qualifying, activeMarket)
            // The season archive is created immediately when GP 30 finishes.
            // Returning to the calendar later must not be required to create history.
            if (seasonRound.round == SeasonCalendar.forSeason(season).size) {
                history.finalizeSeason(season, drivers, teams, activeMarket)
            }
        }
    }

    fun raceHistory(round: Int): RaceResult? = runCatching {
        val raw = prefs.getString(raceResultKey(season, round), null)
            ?: com.f1teammanager.core.manager.RaceResultStoragePolicy.legacyReadKey(season, round)
                ?.let { legacyKey -> prefs.getString(legacyKey, null) }
            ?: return null
        val classification = raw.split(';').filter { it.isNotBlank() }.map { row ->
            val p = row.split(',')
            val id = p[1].toInt()
            val driver = WorldDatabase.drivers.first { it.id == id }
            val teamId = p.getOrNull(8)?.toIntOrNull() ?: driver.teamId
            val team = WorldDatabase.teams.first { it.id == teamId }
            FinishEntryCompat(p[0].toInt(), id, driver.name, team.name, p[2].toInt(), p[3].toLong(), p[4], Tyre.valueOf(p[5]), p[6].toInt())
        }
        val points = raw.split(';').filter { it.isNotBlank() }.associate { row -> val p=row.split(','); p[1].toInt() to p[7].toInt() }
        RaceResult(classification.map { it.toFinish() }, emptyList(), null, com.f1teammanager.core.race.Weather.DRY, points, 0, 0)
    }.getOrNull()

    private data class FinishEntryCompat(val position:Int,val driverId:Int,val driverName:String,val teamName:String,val laps:Int,val totalTimeMs:Long,val status:String,val tyre:Tyre,val pitStops:Int) {
        fun toFinish() = com.f1teammanager.core.race.FinishEntry(position,driverId,driverName,teamName,laps,totalTimeMs,status,tyre,pitStops)
    }

    fun loadCar(forTeamId: Int): TeamCarState? = runCatching {
        if (prefs.getInt("carTeam", -1) != forTeamId) return null
        TeamCarState(
            aerodynamics=prefs.getInt("carAero", 70), chassis=prefs.getInt("carChassis",70), engine=prefs.getInt("carEngine",70), reliability=prefs.getInt("carReliability",70),
            frontWing=prefs.getInt("carFrontWing",70), rearWing=prefs.getInt("carRearWing",70), brakes=prefs.getInt("carBrakes",70), electricPowerUnit=prefs.getInt("carErs",70),
            activeProject=if (prefs.getString("projectComponent", null) != null) DevelopmentProject(
                CarComponent.valueOf(prefs.getString("projectComponent", "ENGINE")!!),
                prefs.getInt("projectRemaining", 1), prefs.getInt("projectTotal", 1), prefs.getInt("projectLevel", 1),
                runCatching { DevelopmentIntensity.valueOf(prefs.getString("projectIntensity", "STANDARD")!!) }.getOrDefault(DevelopmentIntensity.STANDARD),
                prefs.getInt("projectGain", 4), prefs.getLong("projectCost", 0L)
            ) else null,
            nextSeasonInvestment=prefs.getLong("nextSeasonInvestment",0L),
            nextSeasonInvestmentBudgetBase=prefs.getLong("nextSeasonInvestmentBudgetBase",0L),
            nextSeasonFocus=runCatching { CarDevelopmentFocus.valueOf(prefs.getString("nextSeasonFocus", "BALANCED")!!) }.getOrDefault(CarDevelopmentFocus.BALANCED),
            developmentKnowledge=loadKnowledge(),
            seasonDevelopmentGain=prefs.getInt("seasonDevelopmentGain",0)
        ).normalized()
    }.getOrNull()

    /** V270: persist annual-event car stats per team without overwriting the player's single-car save slot. */
    fun loadAnnualEventCarStats(forTeamId: Int, fallback: TeamCarState): TeamCarState {
        val raw = prefs.getString("annualEventCarStats_$forTeamId", null) ?: return fallback
        val a = raw.split(',').mapNotNull { it.toIntOrNull() }
        if (a.size != 8) return fallback
        return fallback.copy(engine=a[0], chassis=a[1], frontWing=a[2], rearWing=a[3], brakes=a[4], electricPowerUnit=a[5], reliability=a[6], aerodynamics=a[7]).normalized()
    }

    fun saveAnnualEventCarStats(forTeamId: Int, car: TeamCarState) {
        prefs.edit().putString("annualEventCarStats_$forTeamId", listOf(car.engine,car.chassis,car.frontWing,car.rearWing,car.brakes,car.electricPowerUnit,car.reliability,car.aerodynamics).joinToString(",")).commit()
    }

    private fun carEditor(forTeamId: Int, car: TeamCarState): android.content.SharedPreferences.Editor {
        val e = prefs.edit().putInt("carTeam", forTeamId)
            .putInt("carAero", car.aerodynamics).putInt("carChassis", car.chassis)
            .putInt("carEngine", car.engine).putInt("carReliability", car.reliability)
            .putInt("carFrontWing", car.frontWing).putInt("carRearWing", car.rearWing)
            .putInt("carBrakes", car.brakes).putInt("carErs", car.electricPowerUnit)
        if (car.activeProject == null) {
            e.remove("projectComponent").remove("projectRemaining").remove("projectTotal")
                .remove("projectLevel").remove("projectIntensity").remove("projectGain").remove("projectCost")
        } else car.activeProject.let {
            e.putString("projectComponent", it.component.name).putInt("projectRemaining", it.remainingWeeks)
                .putInt("projectTotal", it.totalWeeks).putInt("projectLevel", it.level)
                .putString("projectIntensity", it.intensity.name).putInt("projectGain", it.expectedGain)
                .putLong("projectCost", it.cost)
        }
        return e.putLong("nextSeasonInvestment", car.nextSeasonInvestment)
            .putLong("nextSeasonInvestmentBudgetBase", car.nextSeasonInvestmentBudgetBase)
            .putString("nextSeasonFocus", car.nextSeasonFocus.name)
            .putString("developmentKnowledge", car.developmentKnowledge.entries.joinToString(",") { "${it.key.name}:${it.value}" })
            .putInt("seasonDevelopmentGain", car.seasonDevelopmentGain)
    }

    fun saveCar(forTeamId: Int, car: TeamCarState) {
        carEditor(forTeamId, car).apply()
    }

    /**
     * Atomically persists a next-season investment together with its debit.
     * A process death must never leave the car investment saved without the
     * corresponding finance transaction (or vice versa).
     */
    fun saveCarAndFinance(forTeamId: Int, car: TeamCarState, finance: TeamFinanceState): Boolean {
        val combined = prefs.edit()
            .putInt("carTeam", forTeamId).putInt("carAero", car.aerodynamics)
            .putInt("carChassis", car.chassis).putInt("carEngine", car.engine)
            .putInt("carReliability", car.reliability).putInt("carFrontWing", car.frontWing)
            .putInt("carRearWing", car.rearWing).putInt("carBrakes", car.brakes).putInt("carErs", car.electricPowerUnit)
            .putLong("nextSeasonInvestment", car.nextSeasonInvestment)
            .putLong("nextSeasonInvestmentBudgetBase", car.nextSeasonInvestmentBudgetBase)
            .putString("nextSeasonFocus", car.nextSeasonFocus.name)
            .putString("developmentKnowledge", car.developmentKnowledge.entries.joinToString(",") { "${it.key.name}:${it.value}" })
            .putInt("seasonDevelopmentGain", car.seasonDevelopmentGain)
        if (car.activeProject == null) {
            combined.remove("projectComponent").remove("projectRemaining").remove("projectTotal")
                .remove("projectLevel").remove("projectIntensity").remove("projectGain").remove("projectCost")
        } else car.activeProject.let { project ->
            combined.putString("projectComponent", project.component.name)
                .putInt("projectRemaining", project.remainingWeeks).putInt("projectTotal", project.totalWeeks)
                .putInt("projectLevel", project.level).putString("projectIntensity", project.intensity.name)
                .putInt("projectGain", project.expectedGain).putLong("projectCost", project.cost)
        }
        combined.putInt("financeTeam", forTeamId).putLong("budget", finance.budget)
            .putLong("seasonIncome", finance.seasonIncome).putLong("seasonExpenses", finance.seasonExpenses)
            .putLong("raceIncome", finance.raceIncome).putLong("raceExpenses", finance.raceExpenses)
            .putString("seasonPrizesPaid", finance.seasonPrizesPaid.sorted().joinToString(","))
            .putString("financeTransactions", finance.transactions.takeLast(500).joinToString("\n"))
            .putString("signatureFeeSchedules", finance.signatureFeeSchedules.joinToString(";") { sch ->
                listOf(java.util.Base64.getUrlEncoder().withoutPadding().encodeToString(sch.id.toByteArray(Charsets.UTF_8)), sch.amount, sch.season, sch.recognizedRounds.sorted().joinToString(","), sch.startRound, sch.installmentCount, sch.paidRounds.sorted().joinToString(",")).joinToString(":")
            })
            .putString("salaryPaidRounds", finance.salaryPaidRounds.sorted().joinToString(","))
            .putString("salaryOutstanding", finance.salaryOutstanding.entries.sortedBy { it.key }.joinToString(",") { "${it.key.substringBefore(":")}:${it.key.substringAfter(":")}:${it.value}" })
            .putString("raceSettlementKeys", finance.raceSettlementKeys.sorted().joinToString(","))
            .putString("facilityMaintenanceWeeks", finance.facilityMaintenanceWeeks.sorted().joinToString(","))
            .putString("facilityMaintenanceOutstanding", finance.facilityMaintenanceOutstanding.entries.sortedBy { it.key }.joinToString(",") { "${it.key.substringBefore(":")}:${it.key.substringAfter(":")}:${it.value}" })
        return combined.commit()
    }



    private fun loadKnowledge(): Map<CarComponent,Int> = prefs.getString("developmentKnowledge", "").orEmpty().split(',').mapNotNull { token ->
        val p=token.split(':')
        if (p.size==2) runCatching { CarComponent.valueOf(p[0]) to p[1].toInt().coerceIn(0,8) }.getOrNull() else null
    }.toMap()

    fun loadResearch(forTeamId: Int): TeamResearchState? = runCatching {
        if (prefs.getInt("researchTeam", -1) != forTeamId) return null
        val activeRows = prefs.getString("researchActiveProjects", "").orEmpty().split(";").filter { it.isNotBlank() }
        val projects = activeRows.mapNotNull { row ->
            val p=row.split("|")
            if (p.size < 13) null else runCatching {
                ResearchProject(p[0],CarComponent.valueOf(p[1]),p[2].toInt(),p[3].toInt(),p[4].toInt(),p[5].toInt(),p[6].toInt(),p[7].toInt(),p[8].toInt(),p[9].toLong(),p[10].toInt(),ResearchFocus.valueOf(p[11]),ResearchComplexity.valueOf(p[12]),p.getOrNull(13)?.let(ResearchOutcome::valueOf) ?: ResearchOutcome.SUCCESS)
            }.getOrNull()
        }
        val legacy = if (projects.isEmpty()) prefs.getString("researchActive", null)?.split("|")?.takeIf { it.size >= 11 }?.let { p ->
            runCatching { ResearchProject(p[0],CarComponent.valueOf(p[1]),p[2].toInt(),p[3].toInt(),p[3].toInt(),p[4].toInt(),p[4].toInt(),p[6].toInt(),p[7].toInt(),p[8].toLong(),p[9].toInt(),ResearchFocus.PERFORMANCE,ResearchComplexity.MEDIUM) }.getOrNull()
        } else null
        val designs = prefs.getString("researchDesigns", "").orEmpty().split(";").filter { it.isNotBlank() }.mapNotNull { row ->
            val p=row.split("|"); if (p.size < 7) null else runCatching { ResearchDesign(p[0],CarComponent.valueOf(p[1]),p[2].toInt(),p[3].toInt(),p[4].toInt(),p[5].toInt(),p[6].toInt()) }.getOrNull()
        }
        val cooldowns = prefs.getString("researchCooldowns", "").orEmpty().split(",").filter { it.isNotBlank() }.mapNotNull { token ->
            val p=token.split(":"); if (p.size != 2) null else runCatching { CarComponent.valueOf(p[0]) to p[1].toInt() }.getOrNull()
        }.toMap()
        TeamResearchState((projects + listOfNotNull(legacy)).distinctBy { it.projectId }, designs, cooldowns)
    }.getOrNull()

    fun saveResearch(forTeamId: Int, research: TeamResearchState) {
        val e = prefs.edit().putInt("researchTeam", forTeamId)
        if (research.activeProjects.isEmpty()) e.remove("researchActiveProjects")
        else e.putString("researchActiveProjects", research.activeProjects.joinToString(";") { p ->
            listOf(p.projectId,p.component.name,p.version,p.basePerformance,p.baseReliability,p.targetPerformance,p.targetReliability,p.totalWeeks,p.remainingWeeks,p.cost,p.startedWeek,p.focus.name,p.complexity.name,p.outcome.name).joinToString("|")
        })
        e.remove("researchActive")
        e.putString("researchDesigns", research.completedDesigns.joinToString(";") { d ->
            listOf(d.designId,d.component.name,d.version,d.performance,d.reliability,d.researchSeason,d.completedWeek).joinToString("|")
        })
        e.putString("researchCooldowns", research.cooldownUntil.entries.joinToString(",") { "${it.key.name}:${it.value}" }).apply()
    }

    fun loadFactory(forTeamId: Int): TeamFactoryState? = runCatching {
        if (prefs.getInt("factoryTeam", -1) != forTeamId) return null
        val orders = prefs.getString("factoryOrders", "").orEmpty().split(";").filter { it.isNotBlank() }.mapNotNull { row ->
            val p=row.split("|")
            if (p.size < 12) null else runCatching {
                FactoryOrder(p[0],p[1],CarComponent.valueOf(p[2]),p[3].toInt(),p[4].toInt(),p[5].toInt(),p[6].toInt(),p[7].toInt(),p[8].toInt(),p[9].toInt(),p[10].toLong(),p[11].toInt())
            }.getOrNull()
        }
        val pending = prefs.getString("factoryPendingInstallations", "").orEmpty().split(";").filter { it.isNotBlank() }.mapNotNull { row ->
            val p=row.split("|")
            if (p.size < 6) null else runCatching {
                CarPiece(p[0], CarComponent.valueOf(p[1]), p[2].toInt(), p[3].toInt(), p[4].toInt(), p[5].toInt())
            }.getOrNull()
        }
        TeamFactoryState(orders, pending)
    }.getOrNull()

    fun saveFactory(forTeamId: Int, factory: TeamFactoryState) {
        prefs.edit().putInt("factoryTeam",forTeamId)
            .putString("factoryOrders", factory.activeOrders.joinToString(";") { o -> listOf(o.orderId,o.designId,o.component.name,o.version,o.performance,o.reliability,o.quantity,o.remainingUnits,o.totalWeeks,o.remainingWeeks,o.costPerUnit,o.startedWeek).joinToString("|") })
            .putString("factoryPendingInstallations", factory.pendingInstallations.joinToString(";") { p -> listOf(p.pieceId,p.component.name,p.version,p.performance,p.reliability,p.manufacturedWeek).joinToString("|") })
            .apply()
    }

    fun loadGarage(forTeamId: Int): TeamGarage? = runCatching {
        if (prefs.getInt("garageTeam", -1) != forTeamId) return null
        fun loadComponentReliabilities(prefix: String, fallback: Int): Map<CarComponent, Int> = CarComponent.values().associateWith { c -> prefs.getInt("${prefix}Rel_${c.name}", fallback).coerceIn(1,100) }
        fun loadCar(id: GarageCarId): PhysicalCar {
            val prefix = if (id == GarageCarId.CAR_1) "g1" else "g2"
            val installed = prefs.getString("${prefix}Installed", "").orEmpty().split(",").filter { it.isNotBlank() }.mapNotNull { token ->
                val p=token.split(":")
                if (p.size != 2) null else runCatching { CarComponent.valueOf(p[0]) to p[1] }.getOrNull()
            }.toMap()
            return PhysicalCar(
                id=id, engine=prefs.getInt("${prefix}Engine",70), chassis=prefs.getInt("${prefix}Chassis",70),
                frontWing=prefs.getInt("${prefix}FrontWing",70), rearWing=prefs.getInt("${prefix}RearWing",70),
                brakes=prefs.getInt("${prefix}Brakes",70), electricPowerUnit=prefs.getInt("${prefix}Electric",70),
                reliability=prefs.getInt("${prefix}Reliability",100), componentReliabilities=loadComponentReliabilities(prefix, prefs.getInt("${prefix}Reliability",100)), installedPieces=installed,
                installedPieceVersions=CarComponent.values().associateWith { c -> prefs.getInt("${prefix}Version_${c.name}", 1).coerceAtLeast(1) }
            )
        }
        TeamGarage(loadCar(GarageCarId.CAR_1),loadCar(GarageCarId.CAR_2))
    }.getOrNull()

    fun saveGarage(forTeamId: Int, garage: TeamGarage) {
        fun putCar(e: android.content.SharedPreferences.Editor, car: PhysicalCar, prefix: String) {
            e.putInt("${prefix}Engine",car.engine).putInt("${prefix}Chassis",car.chassis)
                .putInt("${prefix}FrontWing",car.frontWing).putInt("${prefix}RearWing",car.rearWing)
                .putInt("${prefix}Brakes",car.brakes).putInt("${prefix}Electric",car.electricPowerUnit)
                .putInt("${prefix}Reliability",car.reliability)
                .also { editor ->
                    car.componentReliabilities.forEach { (c,v) -> editor.putInt("${prefix}Rel_${c.name}",v) }
                    car.installedPieceVersions.forEach { (c,v) -> editor.putInt("${prefix}Version_${c.name}",v.coerceAtLeast(1)) }
                }
                .putString("${prefix}Installed",car.installedPieces.entries.joinToString(",") { "${it.key.name}:${it.value}" })
        }
        prefs.edit().putInt("garageTeam",forTeamId).also { e ->
            putCar(e,garage.car1,"g1")
            putCar(e,garage.car2,"g2")
        }.apply()
    }

    fun loadFacilities(forTeamId:Int): TeamFacilitiesState? = runCatching {
        if (prefs.getInt("facilitiesTeam", -1) != forTeamId) return null
        val raw = prefs.getString("facilities", "").orEmpty()
        val levels = raw.split(",").filter { it.isNotBlank() }.mapNotNull { token ->
            val p = token.split(":")
            if (p.size != 2) null else runCatching { FacilityType.valueOf(p[0]) to p[1].toInt().coerceIn(0,10) }.getOrNull()
        }.toMap()
        TeamFacilitiesState(FacilityType.values().associateWith { levels[it] ?: 0 })
    }.getOrNull()

    fun saveFacilities(forTeamId:Int, facilities:TeamFacilitiesState) {
        prefs.edit().putInt("facilitiesTeam",forTeamId)
            .putString("facilities", facilities.levels.entries.sortedBy { it.key.ordinal }.joinToString(",") { "${it.key.name}:${it.value.coerceIn(0,10)}" })
            .apply()
    }

    fun loadFacilityUpgrade(forTeamId: Int): FacilityUpgradeState? = runCatching {
        val raw = prefs.getString("facilityUpgrade_$forTeamId", null) ?: return null
        val p = raw.split("|")
        if (p.size != 8) return null
        FacilityUpgradeState(FacilityType.valueOf(p[0]), p[1].toInt(), p[2].toInt(), p[3].toInt(), p[4].toInt(), p[5].toLong(), p[6].toInt(), p[7].toInt())
    }.getOrNull()

    fun saveFacilityUpgrade(forTeamId: Int, upgrade: FacilityUpgradeState?) {
        val editor = prefs.edit()
        if (upgrade == null) editor.remove("facilityUpgrade_$forTeamId")
        else editor.putString("facilityUpgrade_$forTeamId", listOf(upgrade.facility.name, upgrade.previousLevel, upgrade.targetLevel, upgrade.remainingWeeks, upgrade.totalWeeks, upgrade.cost, upgrade.startedSeason, upgrade.startedWeek).joinToString("|"))
        editor.apply()
    }

    fun loadTechnicalInvestment(forTeamId:Int): com.f1teammanager.core.manager.TechnicalInvestmentState? = runCatching {
        val raw = prefs.getString("technicalInvestment_$forTeamId", null) ?: return null
        val p = raw.split(",")
        if (p.size < 7) return null
        com.f1teammanager.core.manager.TechnicalInvestmentState(
            season = p[0].toInt(),
            ranking = p[1].toInt(),
            level = p[2].toInt(),
            annualCap = p[3].toLong(),
            researchDesignSpent = p[4].toLong(),
            fabricationSpent = p[5].toLong(),
            facilityUpgradeSpent = p[6].toLong()
        )
    }.getOrNull()

    fun saveTechnicalInvestment(forTeamId:Int, state: com.f1teammanager.core.manager.TechnicalInvestmentState) {
        prefs.edit().putString(
            "technicalInvestment_$forTeamId",
            listOf(state.season, state.ranking, state.level, state.annualCap,
                state.researchDesignSpent, state.fabricationSpent, state.facilityUpgradeSpent).joinToString(",")
        ).apply()
    }

    fun loadDriverDevelopment(forTeamId:Int): com.f1teammanager.core.manager.DriverDevelopmentState = runCatching {
        if (prefs.getInt("driverDevelopmentTeam", -1) != forTeamId) return com.f1teammanager.core.manager.DriverDevelopmentState()
        val programs = prefs.getString("driverDevelopmentPrograms", "").orEmpty().split(";").filter { it.isNotBlank() }.mapNotNull { row ->
            val p = row.split("|")
            if (p.size < 5) null else runCatching {
                com.f1teammanager.core.manager.DriverDevelopmentProgram(p[0].toInt(), p[1].toInt(), p[2].toInt(), p[3].toInt(), p[4].toInt())
            }.getOrNull()
        }
        val reserve = prefs.getString("driverDevelopmentReserve", "").orEmpty().split(";").filter { it.isNotBlank() }.mapNotNull { row ->
            val p = row.split(":")
            if (p.size != 2) null else runCatching { p[0].toInt() to p[1].toInt().coerceAtLeast(0) }.getOrNull()
        }.toMap()
        com.f1teammanager.core.manager.DriverDevelopmentState(programs, reserve).normalized()
    }.getOrDefault(com.f1teammanager.core.manager.DriverDevelopmentState())

    fun saveDriverDevelopment(forTeamId:Int, state:com.f1teammanager.core.manager.DriverDevelopmentState) {
        val normalized = state.normalized()
        prefs.edit().putInt("driverDevelopmentTeam",forTeamId)
            .putString("driverDevelopmentPrograms", normalized.programs.joinToString(";") { listOf(it.driverId,it.startedWeek,it.totalWeeks,it.remainingWeeks,it.points).joinToString("|") })
            .putString("driverDevelopmentReserve", normalized.reservePoints.entries.sortedBy { it.key }.joinToString(";") { "${it.key}:${it.value}" })
            .apply()
    }

    fun getInt(key:String, fallback:Int): Int = prefs.getInt(key,fallback)
    fun putInt(key:String, value:Int) { prefs.edit().putInt(key,value).apply() }

    fun loadFinance(forTeamId:Int, fallback:TeamFinanceState): TeamFinanceState {
        if (prefs.getInt("financeTeam", -1) != forTeamId) return fallback
        return TeamFinanceState(
            budget=prefs.getLong("budget", fallback.budget),
            seasonIncome=prefs.getLong("seasonIncome", fallback.seasonIncome),
            seasonExpenses=prefs.getLong("seasonExpenses", fallback.seasonExpenses),
            raceIncome=prefs.getLong("raceIncome", fallback.raceIncome),
            raceExpenses=prefs.getLong("raceExpenses", fallback.raceExpenses),
            transactions=prefs.getString("financeTransactions", "").orEmpty().split("\n").filter { it.isNotBlank() }.takeLast(500),
            seasonPrizesPaid=prefs.getString("seasonPrizesPaid", "").orEmpty().split(",").mapNotNull { it.toIntOrNull() }.toSet(),
            signatureFeeSchedules=prefs.getString("signatureFeeSchedules", "").orEmpty().split(";").filter { it.isNotBlank() }.mapNotNull { row ->
                val q=row.split(":", limit=7)
                if (q.size < 4) null else runCatching { SignatureFeeSchedule(String(java.util.Base64.getUrlDecoder().decode(q[0]), Charsets.UTF_8), q[1].toLong(), q[2].toInt(), q[3].split(",").mapNotNull { it.toIntOrNull() }.toSet(), q.getOrNull(4)?.toIntOrNull() ?: 1, q.getOrNull(5)?.toIntOrNull() ?: 30, if (q.size >= 7) q[6].split(",").mapNotNull { it.toIntOrNull() }.toSet() else (1..30).toSet()) }.getOrNull()
            },
            salaryPaidRounds=prefs.getString("salaryPaidRounds", "").orEmpty().split(",").filter { it.matches(Regex("20\\d{2}:\\d{1,2}")) }.toSet(),
            salaryOutstanding=prefs.getString("salaryOutstanding", "").orEmpty().split(",").filter { it.isNotBlank() }.mapNotNull { token -> val q=token.split(":"); if(q.size==3) runCatching { (q[0]+":"+q[1]) to q[2].toLong() }.getOrNull() else null }.toMap(),
            raceSettlementKeys=prefs.getString("raceSettlementKeys", "").orEmpty().split(",").filter { it.isNotBlank() }.toSet(),
            facilityMaintenanceWeeks=prefs.getString("facilityMaintenanceWeeks", "").orEmpty().split(",").filter { it.matches(Regex("20\\d{2}:\\d{1,2}")) }.toSet(),
            facilityMaintenanceOutstanding=prefs.getString("facilityMaintenanceOutstanding", "").orEmpty().split(",").filter { it.isNotBlank() }.mapNotNull { token -> val q=token.split(":"); if(q.size==3) runCatching { (q[0]+":"+q[1]) to q[2].toLong() }.getOrNull() else null }.toMap()
        )
    }
    private fun financeEditor(forTeamId:Int, finance:TeamFinanceState): android.content.SharedPreferences.Editor =
        prefs.edit().putInt("financeTeam",forTeamId).putLong("budget",finance.budget).putLong("seasonIncome",finance.seasonIncome).putLong("seasonExpenses",finance.seasonExpenses).putLong("raceIncome",finance.raceIncome).putLong("raceExpenses",finance.raceExpenses)
            .putString("seasonPrizesPaid", finance.seasonPrizesPaid.sorted().joinToString(","))
            .putString("financeTransactions", finance.transactions.takeLast(500).joinToString("\n"))
            .putString("signatureFeeSchedules", finance.signatureFeeSchedules.joinToString(";") { sch -> listOf(java.util.Base64.getUrlEncoder().withoutPadding().encodeToString(sch.id.toByteArray(Charsets.UTF_8)), sch.amount, sch.season, sch.recognizedRounds.sorted().joinToString(","), sch.startRound, sch.installmentCount, sch.paidRounds.sorted().joinToString(",")).joinToString(":") })
            .putString("salaryPaidRounds", finance.salaryPaidRounds.sorted().joinToString(","))
            .putString("salaryOutstanding", finance.salaryOutstanding.entries.sortedBy { it.key }.joinToString(",") { "${it.key.substringBefore(":")}:${it.key.substringAfter(":")}:${it.value}" })
            .putString("raceSettlementKeys", finance.raceSettlementKeys.sorted().joinToString(","))
            .putString("facilityMaintenanceWeeks", finance.facilityMaintenanceWeeks.sorted().joinToString(","))
            .putString("facilityMaintenanceOutstanding", finance.facilityMaintenanceOutstanding.entries.sortedBy { it.key }.joinToString(",") { "${it.key.substringBefore(":")}:${it.key.substringAfter(":")}:${it.value}" })

    fun saveFinance(forTeamId:Int, finance:TeamFinanceState) { financeEditor(forTeamId, finance).apply() }

    /**
     * Atomically persists the player's GP finance settlement and the sponsor contracts
     * whose remaining-race counters were decremented by that same settlement.
     */
    fun saveFinanceAndSponsors(forTeamId: Int, finance: TeamFinanceState, sponsors: List<SponsorContract>): Boolean =
        sponsorEditor(financeEditor(forTeamId, finance), forTeamId, sponsors).commit()

    /** Salary is paid after the GP completes; each season/round is idempotent across restarts. */
    fun applyDriverSalaryForRaceOnce(forTeamId:Int, seasonToCharge:Int, roundToCharge:Int, finance:TeamFinanceState, market:DriverMarketState): TeamFinanceState {
        if (roundToCharge !in 1..30) return finance
        val key = "driverSalaryPaid_${forTeamId}_${seasonToCharge}_$roundToCharge"
        if (prefs.getBoolean(key, false)) return finance
        // Migration safety: if V154 already charged the whole annual salary at season start,
        // suppress all remaining per-GP charges for that same season to avoid double billing.
        val legacyAnnualKey = "annualDriverSalarySeason_$forTeamId"
        val migrationKey = "driverSalaryLegacyMigrated_${forTeamId}_${seasonToCharge}"
        if (!prefs.getBoolean(migrationKey, false) && prefs.getInt(legacyAnnualKey, 0) == seasonToCharge) {
            val editor = prefs.edit().putBoolean(migrationKey, true)
            (1..30).forEach { legacyRound -> editor.putBoolean("driverSalaryPaid_${forTeamId}_${seasonToCharge}_$legacyRound", true) }
            check(editor.commit()) { "Não foi possível persistir a migração dos salários da temporada $seasonToCharge" }
            return finance
        }
        val annual = market.contracts.filter { it.teamId == forTeamId && it.activeIn(seasonToCharge) }
            .sumOf { it.salary.coerceAtLeast(0L) }
        val requested = annual / 30L + if (roundToCharge == 30) annual % 30L else 0L
        var next = SalaryLedger.apply(finance, seasonToCharge, roundToCharge, requested)
        next = SignatureFeeAccounting.recognizeForRace(next, seasonToCharge, roundToCharge)
        // Persist outstanding obligations and paid markers atomically; unpaid rounds remain retryable.
        val editor = financeEditor(forTeamId, next)
        if ("$seasonToCharge:$roundToCharge" in next.salaryPaidRounds) editor.putBoolean(key, true)
        check(editor.commit()) {
            "Não foi possível persistir o pagamento salarial do GP $roundToCharge/temporada $seasonToCharge"
        }
        return next
    }

    /** Compatibility shim for older callers: deliberately no longer charges annual salaries upfront. */
    @Deprecated("Use applyDriverSalaryForRaceOnce after a completed GP")
    fun applyAnnualDriverSalariesOnce(forTeamId:Int, seasonToCharge:Int, finance:TeamFinanceState, market:DriverMarketState): TeamFinanceState = finance

    /** Qualifying sponsor bonus is a GP/season-round transaction and is persisted idempotently. */
    fun applyQualifyingBonusOnce(forTeamId:Int, seasonToApply:Int, roundToApply:Int, finance:TeamFinanceState, sponsors:List<SponsorContract>, bestPosition:Int): TeamFinanceState {
        if (bestPosition <= 0) return finance
        val key = "qualifyingBonusPaid_${seasonToApply}_$roundToApply"
        if (prefs.getBoolean(key, false)) return finance
        val bonus = sponsors.filter { it.active && it.racesRemaining > 0 }.sumOf { s -> if (s.qualifyingTarget > 0 && bestPosition <= s.qualifyingTarget) s.qualifyingBonus else 0L }
        val next = if (bonus > 0L) finance.transact(bonus, "Bônus por meta de qualificação — GP $roundToApply") else finance
        // Persist the finance state and the idempotency marker in one SharedPreferences commit.
        // A failed commit must abort race finalization; returning `next` would let the
        // in-memory career advance while the durable marker remains absent.
        check(financeEditor(forTeamId, next).putBoolean(key, true).commit()) {
            "Não foi possível persistir o bônus de qualificação do GP $roundToApply/temporada $seasonToApply"
        }
        return next
    }
    fun loadSponsor(forTeamId:Int, fallback:SponsorContract): SponsorContract {
        if (prefs.getInt("sponsorTeam", -1) != forTeamId) return fallback
        return SponsorContract(
            prefs.getString("sponsorName",fallback.name) ?: fallback.name,
            prefs.getLong("sponsorUpfront",fallback.upfront),
            prefs.getLong("sponsorRace",fallback.racePayment),
            prefs.getLong("sponsorPoints",fallback.pointsBonus),
            prefs.getInt("sponsorYears",fallback.years),
            prefs.getInt("sponsorRep",fallback.minimumReputation),
            prefs.getInt("sponsorSlot",fallback.slot),
            prefs.getInt("sponsorQualTarget",fallback.qualifyingTarget),
            prefs.getLong("sponsorQualBonus",fallback.qualifyingBonus),
            prefs.getInt("sponsorRaceTarget",fallback.raceTarget),
            prefs.getLong("sponsorRaceTargetBonus",fallback.raceTargetBonus),
            prefs.getBoolean("sponsorActive",fallback.active),
            prefs.getInt("sponsorRaces",fallback.races),
            prefs.getInt("sponsorRacesRemaining",fallback.racesRemaining),
            fallback.category,
            prefs.getInt("sponsorQualTargetMin",fallback.qualifyingTargetMin),
            prefs.getInt("sponsorQualTargetMax",fallback.qualifyingTargetMax),
            prefs.getInt("sponsorRaceTargetMin",fallback.raceTargetMin),
            prefs.getInt("sponsorRaceTargetMax",fallback.raceTargetMax)
        )
    }
    fun loadSponsors(forTeamId:Int): List<SponsorContract> {
        if (prefs.getInt("sponsorTeam", -1) != forTeamId) return emptyList()
        return (1..5).mapNotNull { slot ->
            val name=prefs.getString("sponsor_${slot}_name",null) ?: return@mapNotNull null
            SponsorContract(name, prefs.getLong("sponsor_${slot}_upfront",0), prefs.getLong("sponsor_${slot}_race",0), prefs.getLong("sponsor_${slot}_points",0), prefs.getInt("sponsor_${slot}_years",1), prefs.getInt("sponsor_${slot}_rep",0), slot, prefs.getInt("sponsor_${slot}_qualTarget",0), prefs.getLong("sponsor_${slot}_qualBonus",0), prefs.getInt("sponsor_${slot}_raceTarget",0), prefs.getLong("sponsor_${slot}_raceTargetBonus",0), prefs.getBoolean("sponsor_${slot}_active",true), prefs.getInt("sponsor_${slot}_races",5), prefs.getInt("sponsor_${slot}_racesRemaining",prefs.getInt("sponsor_${slot}_races",5)), prefs.getString("sponsor_${slot}_category","BASICO") ?: "BASICO", prefs.getInt("sponsor_${slot}_qualTargetMin",prefs.getInt("sponsor_${slot}_qualTarget",0)), prefs.getInt("sponsor_${slot}_qualTargetMax",prefs.getInt("sponsor_${slot}_qualTarget",0)), prefs.getInt("sponsor_${slot}_raceTargetMin",prefs.getInt("sponsor_${slot}_raceTarget",0)), prefs.getInt("sponsor_${slot}_raceTargetMax",prefs.getInt("sponsor_${slot}_raceTarget",0)))
        }
    }
    fun saveSponsor(forTeamId:Int, sponsor:SponsorContract) = saveSponsors(forTeamId, listOf(sponsor))
    fun saveSponsors(forTeamId:Int, sponsors:List<SponsorContract>) {
        sponsorEditor(prefs.edit(), forTeamId, sponsors).apply()
    }

    private fun sponsorEditor(
        editor: android.content.SharedPreferences.Editor,
        forTeamId: Int,
        sponsors: List<SponsorContract>
    ): android.content.SharedPreferences.Editor {
        val e=editor.putInt("sponsorTeam",forTeamId)
        for (slot in 1..5) {
            val s=sponsors.firstOrNull { it.slot==slot }
            if (s==null) {
                listOf("name","upfront","race","points","years","rep","qualTarget","qualBonus","raceTarget","raceTargetBonus","qualTargetMin","qualTargetMax","raceTargetMin","raceTargetMax","active","races","racesRemaining","category").forEach { e.remove("sponsor_${slot}_$it") }
            } else {
                e.putString("sponsor_${slot}_name",s.name).putLong("sponsor_${slot}_upfront",s.upfront).putLong("sponsor_${slot}_race",s.racePayment).putLong("sponsor_${slot}_points",s.pointsBonus).putInt("sponsor_${slot}_years",s.years).putInt("sponsor_${slot}_rep",s.minimumReputation).putInt("sponsor_${slot}_qualTarget",s.qualifyingTarget).putLong("sponsor_${slot}_qualBonus",s.qualifyingBonus).putInt("sponsor_${slot}_raceTarget",s.raceTarget).putLong("sponsor_${slot}_raceTargetBonus",s.raceTargetBonus).putInt("sponsor_${slot}_qualTargetMin",s.qualifyingTargetMin).putInt("sponsor_${slot}_qualTargetMax",s.qualifyingTargetMax).putInt("sponsor_${slot}_raceTargetMin",s.raceTargetMin).putInt("sponsor_${slot}_raceTargetMax",s.raceTargetMax).putBoolean("sponsor_${slot}_active",s.active).putInt("sponsor_${slot}_races",s.races).putInt("sponsor_${slot}_racesRemaining",s.racesRemaining).putString("sponsor_${slot}_category",s.category)
            }
        }
        // Keep legacy primary sponsor keys synchronized.
        val primary=sponsors.firstOrNull { it.slot==1 }
        if (primary==null) { e.remove("sponsorName").remove("sponsorUpfront").remove("sponsorRace").remove("sponsorPoints").remove("sponsorYears").remove("sponsorRep").remove("sponsorSlot").remove("sponsorQualTarget").remove("sponsorQualBonus").remove("sponsorRaceTarget").remove("sponsorRaceTargetBonus").remove("sponsorActive").remove("sponsorRaces").remove("sponsorRacesRemaining") }
        else { e.putString("sponsorName",primary.name).putLong("sponsorUpfront",primary.upfront).putLong("sponsorRace",primary.racePayment).putLong("sponsorPoints",primary.pointsBonus).putInt("sponsorYears",primary.years).putInt("sponsorRep",primary.minimumReputation).putInt("sponsorSlot",primary.slot).putInt("sponsorQualTarget",primary.qualifyingTarget).putLong("sponsorQualBonus",primary.qualifyingBonus).putInt("sponsorRaceTarget",primary.raceTarget).putLong("sponsorRaceTargetBonus",primary.raceTargetBonus).putBoolean("sponsorActive",primary.active).putInt("sponsorRaces",primary.races).putInt("sponsorRacesRemaining",primary.racesRemaining).putInt("sponsorQualTargetMin",primary.qualifyingTargetMin).putInt("sponsorQualTargetMax",primary.qualifyingTargetMax).putInt("sponsorRaceTargetMin",primary.raceTargetMin).putInt("sponsorRaceTargetMax",primary.raceTargetMax) }
        return e
    }

    /** Current persisted attributes for all 100 drivers. */
    fun driverAttributes(): Map<Int, IntArray> {
        val raw = prefs.getString("driverAttributes", "").orEmpty()
        val merged = DriverAttributePersistence.merge(raw, WorldDatabase.allDrivers)
        // V278: repair partial/corrupt records per driver instead of resetting all
        // 100 drivers and silently erasing valid progression for the entire roster.
        if (merged.second) saveDriverAttributes(merged.first)
        return merged.first
    }

    /** Persistent class overrides generated by annual calendar events. */
    fun driverClassOverrides(): Map<Int, String> = prefs.getString("annualDriverClassOverrides", "").orEmpty()
        .split(';').mapNotNull { row -> val p=row.split(':', limit=2); if (p.size==2 && p[0].toIntOrNull()!=null && p[1] in listOf("Fraco","Médio","Forte","Pro","Lenda")) p[0].toInt() to p[1] else null }.toMap()

    fun saveDriverClassOverride(driverId: Int, driverClass: String) {
        if (driverClass !in listOf("Fraco","Médio","Forte","Pro","Lenda")) return
        val values = driverClassOverrides().toMutableMap(); values[driverId] = driverClass
        prefs.edit().putString("annualDriverClassOverrides", values.toSortedMap().entries.joinToString(";") { "${it.key}:${it.value}" }).commit()
    }

    /** V276: atomically commit annual driver effects and their idempotency keys. */
    fun commitAnnualDriverStateAndKeys(
        seasonNumber: Int,
        attributes: Map<Int, IntArray>,
        classOverrides: Map<Int, String>,
        processedKeys: Set<String>
    ) {
        require(seasonNumber >= 1)
        // V281: merge the incoming batch with the existing roster. A partial batch
        // must never replace the whole 100-driver snapshot and erase valid progress.
        val roster = WorldDatabase.allDrivers
        val knownDriverIds = roster.map { it.id }.toSet()
        val existingRawAttributes = prefs.getString("driverAttributes", "").orEmpty()
        val existingAttributes = DriverAttributePersistence.merge(existingRawAttributes, roster).first
        val validAttributes = roster.associate { driver ->
            val incoming = attributes[driver.id]
            val prior = existingAttributes[driver.id]
            val chosen = when {
                incoming != null && incoming.size == 7 -> incoming
                prior != null && prior.size == 7 -> prior
                else -> intArrayOf(driver.speed, driver.qualifying, driver.overtaking, driver.defense,
                    driver.consistency, driver.wet, driver.tyre)
            }
            driver.id to chosen.copyOf().also { values ->
                values.indices.forEach { i -> values[i] = values[i].coerceIn(1, 100) }
            }
        }
        // Merge overrides too, so an event affecting one pilot cannot erase other
        // pilots' class changes. Invalid and unknown records are excluded.
        val validClasses = (driverClassOverrides() + classOverrides)
            .filterKeys { it in knownDriverIds }
            .filterValues { it in listOf("Fraco", "Médio", "Forte", "Pro", "Lenda") }
        val mergedKeys = (loadProcessedAnnualEventKeys(seasonNumber) + processedKeys.filter { it.isNotBlank() })
            .toSortedSet().toList().takeLast(1000)
        prefs.edit()
            .putString("driverAttributes", validAttributes.toSortedMap().entries.joinToString(";") { (id, a) -> "$id:${a.joinToString(",")}" })
            .putString("annualDriverClassOverrides", validClasses.toSortedMap().entries.joinToString(";") { "${it.key}:${it.value}" })
            .putString("annualEventProcessed_$seasonNumber", mergedKeys.joinToString("|"))
            .commit()
    }

    fun saveDriverAttributes(values: Map<Int, IntArray>) {
        prefs.edit().putString("driverAttributes", DriverAttributePersistence.serialize(values)).apply()
    }

    private fun saveSeasonStartDriverAttributes(season: Int, values: Map<Int, IntArray>) {
        // V279: capture the class at the same season boundary as the seven attributes.
        // Annual events may change the live class mid-season; the evolution baseline
        // must continue to represent the season opening state until the next season.
        val overrides = driverClassOverrides()
        val currentClasses = WorldDatabase.allDrivers.associate { driver ->
            driver.id to (overrides[driver.id] ?: driver.driverClass)
        }
        prefs.edit()
            .putString("driverSeasonStartAttributes_$season", values.toSortedMap().entries.joinToString(";") { (id,a) -> "$id:${a.joinToString(",")}" })
            .putString("driverSeasonStartClasses_$season", currentClasses.toSortedMap().entries.joinToString(";") { (id, driverClass) -> "$id:$driverClass" })
            .commit()
    }

    fun seasonStartDriverDefinition(driverId: Int, season: Int = this.season): com.f1teammanager.core.season.DriverDefinition {
        val base = WorldDatabase.allDrivers.first { it.id == driverId }
        val raw = prefs.getString("driverSeasonStartAttributes_$season", "").orEmpty()
        val a = raw.split(';').mapNotNull { token ->
            val p = token.split(':', limit = 2)
            if (p.size != 2 || p[0].toIntOrNull() != driverId) return@mapNotNull null
            val values = p[1].split(',').mapNotNull { it.toIntOrNull() }
            if (values.size == 7) values.toIntArray() else null
        }.firstOrNull() ?: intArrayOf(base.speed,base.qualifying,base.overtaking,base.defense,base.consistency,base.wet,base.tyre)
        val seasonClasses = prefs.getString("driverSeasonStartClasses_$season", "").orEmpty()
            .split(';').mapNotNull { token ->
                val p = token.split(':', limit = 2)
                if (p.size == 2 && p[0].toIntOrNull() == driverId &&
                    p[1] in listOf("Fraco", "Médio", "Forte", "Pro", "Lenda")) driverId to p[1] else null
            }.toMap()
        // Backward compatibility for saves created before V279: use the current
        // override only if no opening-class snapshot exists for this season.
        val openingClass = seasonClasses[driverId]
            ?: driverClassOverrides()[driverId]
            ?: base.driverClass
        return base.copy(speed=a[0],qualifying=a[1],overtaking=a[2],defense=a[3],consistency=a[4],wet=a[5],tyre=a[6], driverClass=openingClass)
    }

    /** Current driver-rating projection used by the active evolution state machine. */
    private fun ratingsForEvolution(driver: com.f1teammanager.core.season.DriverDefinition): IntArray =
        intArrayOf(driver.speed, driver.qualifying, driver.overtaking, driver.defense, driver.consistency, driver.wet, driver.tyre)

    private fun readDriverEvolutionPhases(): MutableMap<Int,String> = prefs.getString("driverEvolutionPhases", "").orEmpty().split(';').mapNotNull { token ->
        val p=token.split(':', limit=2); if (p.size==2) p[0].toIntOrNull()?.let { it to p[1] } else null
    }.toMap().toMutableMap()

    private fun saveDriverEvolutionPhases(values: Map<Int,String>) {
        prefs.edit().putString("driverEvolutionPhases", values.toSortedMap().entries.joinToString(";") { "${it.key}:${it.value}" }).apply()
    }

    fun driverDefinition(driverId:Int): com.f1teammanager.core.season.DriverDefinition {
        val base = WorldDatabase.allDrivers.first { it.id == driverId }
        val a = driverAttributes()[driverId] ?: intArrayOf(base.speed,base.qualifying,base.overtaking,base.defense,base.consistency,base.wet,base.tyre)
        val classOverride = driverClassOverrides()[driverId]
        return base.copy(speed=a[0],qualifying=a[1],overtaking=a[2],defense=a[3],consistency=a[4],wet=a[5],tyre=a[6], driverClass=classOverride ?: base.driverClass)
    }

    /**
     * Canonical career roster adapter. WorldDatabase remains the immutable source for
     * driver identity and base attributes; active contracts are the source of truth for
     * team assignment. This keeps Team, Home, qualifying, race, and driver details in
     * sync after the offseason transfer transition.
     */
    fun currentDrivers(): List<com.f1teammanager.core.season.DriverDefinition> {
        val market = loadDriverMarket()
        val activeDeals = market?.contracts?.filter { it.activeIn(season) }?.associateBy { it.driverId }.orEmpty()
        val freeAgents = market?.freeAgents?.toSet().orEmpty()
        return WorldDatabase.allDrivers.map { base ->
            val current = driverDefinition(base.id)
            val contractTeam = activeDeals[base.id]?.teamId
            val resolvedTeam = when {
                contractTeam != null -> contractTeam
                base.id in freeAgents -> 0
                else -> base.teamId // compatibility fallback for saves predating the market
            }
            current.copy(teamId = resolvedTeam)
        }
    }

    private fun readSeasonTargets(): Map<Int, DriverEvolutionEngine.Target> {
        return prefs.getString("driverSeasonTargets_$season", "").orEmpty().split(',').mapNotNull { token ->
            val p=token.split(':'); if(p.size!=2) null else p[0].toIntOrNull()?.let { id -> p[1].toIntOrNull()?.let { pos -> id to DriverEvolutionEngine.Target(pos) } }
        }.toMap()
    }

    /**
     * Creates the immutable season targets from the opening-season team-strength ranking.
     * Driver Overall is intentionally NOT used here. Each team occupies two championship
     * target slots according to its strength rank, so expectations are anchored to the
     * competitive level of the team rather than the driver's rating.
     */
    fun initializeDriverSeasonTargets(playerCar: TeamCarState? = null) {
        val market = loadDriverMarket()
        val active = market?.contracts?.filter { it.activeIn(season) }
            ?: WorldDatabase.drivers.map { d -> com.f1teammanager.core.manager.DriverDeal(d.id,d.teamId,1,0L,0L,season) }

        fun strength(team: com.f1teammanager.core.season.TeamDefinition): Double {
            if (team.id == teamId && playerCar != null) {
                return (playerCar.chassis + playerCar.engine + playerCar.frontWing +
                    playerCar.rearWing + playerCar.brakes + playerCar.electricPowerUnit) / 6.0
            }
            val c = com.f1teammanager.core.manager.InitialTeamProfile.values(team)
            return (c.chassis + c.engine + c.frontWing + c.rearWing + c.brakes + c.electricPowerUnit) / 6.0
        }

        val teamRank = WorldDatabase.teams
            .sortedWith(compareByDescending<com.f1teammanager.core.season.TeamDefinition> { strength(it) }.thenBy { it.id })
            .mapIndexed { index, team -> team.id to (index + 1) }
            .toMap()

        val targets = active.mapNotNull { deal ->
            val team = WorldDatabase.teams.firstOrNull { it.id == deal.teamId } ?: return@mapNotNull null
            val rank = teamRank[team.id] ?: return@mapNotNull null
            val order = team.driverIds.indexOf(deal.driverId).takeIf { it >= 0 } ?: 0
            deal.driverId to DriverEvolutionEngine.Target(((rank - 1) * 2 + order + 1).coerceIn(1, 80))
        }.toMap()

        prefs.edit().putString(
            "driverSeasonTargets_$season",
            targets.entries.sortedBy { it.key }.joinToString(",") { "${it.key}:${it.value.championshipPosition}" }
        ).apply()
    }

    /**
     * Applies one in-season evolution tick after a completed GP. Evolution is continuous
     * during the championship; GP30 only closes the season and does not perform a second
     * evolution pass. The fractional bank makes changes gradual while keeping the official
     * annual gain ceiling from DriverProfileCatalog.
     */
    private fun readAnnualAttributeGains(): MutableMap<Int, IntArray> {
        val raw = prefs.getString("driverEvolutionAttributeGains_$season", "").orEmpty()
        val out = mutableMapOf<Int, IntArray>()
        raw.split(';').filter { it.isNotBlank() }.forEach { token ->
            val p = token.split(':')
            if (p.size == 2) {
                val id = p[0].toIntOrNull()
                val values = p[1].split(',').mapNotNull { it.toIntOrNull() }
                if (id != null && values.size == 7) out[id] = values.toIntArray()
            }
        }
        return out
    }

    private fun writeAnnualAttributeGains(values: Map<Int, IntArray>) {
        prefs.edit().putString(
            "driverEvolutionAttributeGains_$season",
            values.toSortedMap().entries.joinToString(";") { (id, a) -> "$id:${a.joinToString(",")}" }
        ).apply()
    }

    private fun pendingDriverEvolutionNewsKey(seasonNumber: Int, round: Int) =
        "driverEvolutionPendingNews_${seasonNumber}_$round"

    /**
     * Replays the durable outbox after a crash between driver-stat evolution and
     * publication of its news cards. The outbox is cleared in the same commit that
     * saves the market notifications, so recovery cannot silently lose the news.
     */
    private fun flushPendingDriverEvolutionNews(seasonNumber: Int, round: Int) {
        val key = pendingDriverEvolutionNewsKey(seasonNumber, round)
        val raw = prefs.getString(key, null) ?: return
        val changes = raw.split("\n").filter { it.isNotBlank() }.mapNotNull { encoded ->
            runCatching { String(java.util.Base64.getDecoder().decode(encoded), Charsets.UTF_8) }.getOrNull()
        }
        val market = loadDriverMarket()
            ?: error("Não foi possível recuperar o mercado de pilotos para publicar notícias de evolução")
        val week = SeasonCalendar.forSeason(seasonNumber).firstOrNull { it.round == round }?.weekOfSeason ?: currentWeek
        val notices = changes.mapNotNull { change ->
            val exists = market.notifications.any {
                it.season == seasonNumber && it.week == week && it.category == MarketNewsCategory.DRIVER_EVOLUTION && it.message == change
            }
            if (exists) null else MarketNotification(
                seasonNumber, week, "EVOLUÇÃO DE PILOTO", change, true, MarketNewsCategory.DRIVER_EVOLUTION
            )
        }
        val updated = if (notices.isEmpty()) market else market.copy(
            notifications = (market.notifications + notices).takeLast(1000)
        ).normalized()
        check(saveDriverMarketAndClearPendingNews(updated, key)) {
            "Não foi possível confirmar as notícias de evolução do GP $round/temporada $seasonNumber"
        }
    }

    /**
     * Applies one in-season evolution tick after a completed GP.
     * Positive evolution uses the full intended gain, with per-attribute class-ceiling
     * redistribution. Regression is independent and is capped at the floor 40.
     */
    fun applyDriverRaceEvolution(round: Int): List<String> {
        // One evolution tick per completed GP, even if the result flow is reopened.
        val processedRounds = readMap("driverEvolutionProcessedRounds_$season")
        if (processedRounds[round] == 1) {
            flushPendingDriverEvolutionNews(season, round)
            return emptyList()
        }
        val targets = readSeasonTargets().ifEmpty { initializeDriverSeasonTargets(); readSeasonTargets() }
        val races = history.raceRecords(season)
        val qualifying = history.qualifyingRecords(season)
        val attrs = driverAttributes().toMutableMap()
        val banks = readDoubleMap("driverEvolutionBank_$season").toMutableMap()
        val phases = readDriverEvolutionPhases()
        val phaseGps = readMap("driverEvolutionPhaseGps") .toMutableMap()
        val phaseStart = readMap("driverEvolutionPhaseStart") .toMutableMap()
        val phaseTarget = readMap("driverEvolutionPhaseTarget") .toMutableMap()
        val pressure = readDoubleMap("driverEvolutionPhasePressure").toMutableMap()
        val activeDriverIds = loadDriverMarket()?.contracts?.filter { it.activeIn(season) }?.map { it.driverId }?.toSet()
            ?: races.filter { it.round == round }.map { it.driverId }.toSet()
        val changes = mutableListOf<String>()

        WorldDatabase.allDrivers.forEach { base ->
            val id = base.id
            val currentAttrs = attrs[id] ?: intArrayOf(base.speed,base.qualifying,base.overtaking,base.defense,base.consistency,base.wet,base.tyre)
            // V277: use the persisted annual-event class when calculating evolution
            // floors/ceilings; otherwise the old base class silently overrides the event.
            val effectiveClass = driverClassOverrides()[id] ?: base.driverClass
            var current = base.copy(speed=currentAttrs[0],qualifying=currentAttrs[1],overtaking=currentAttrs[2],defense=currentAttrs[3],consistency=currentAttrs[4],wet=currentAttrs[5],tyre=currentAttrs[6],driverClass=effectiveClass)
            var phase = phases[id] ?: "GROWING"
            var gps = phaseGps[id] ?: 0
            var bank = banks[id] ?: 0.0
            val rng = kotlin.random.Random(annualEventSeed(season) + season*1000 + round*97 + id*31)

            if (!phaseStart.containsKey(id)) phaseStart[id] = DriverProfileCatalog.overall(ratingsForEvolution(current))
            val regression = phase == "REGRESSION"
            val target = if (regression) DriverProfileCatalog.minimumOverall(current.driverClass) else DriverProfileCatalog.ceiling(current.driverClass)
            if (!phaseTarget.containsKey(id)) phaseTarget[id] = target
            if (phaseTarget[id] != target) {
                phaseStart[id] = DriverProfileCatalog.overall(ratingsForEvolution(current)); phaseTarget[id] = target; gps = 0; bank = 0.0
            }

            val index = if (id in activeDriverIds) {
                val rr = races.firstOrNull { it.season == season && it.round == round && it.driverId == id }
                val qq = qualifying.firstOrNull { it.season == season && it.round == round && it.driverId == id }
                DriverEvolutionEngine.gpPerformanceIndex(targets[id]?.championshipPosition ?: 80, qq?.position ?: 80, rr?.position ?: 80)
            } else 100.0
            val multiplier = if (id in activeDriverIds) DriverEvolutionEngine.phaseMultiplier(index, regression) else 0.70
            val anticipation = if (id in activeDriverIds) DriverEvolutionEngine.anticipationFactor(index, regression) else 1.0
            val phaseSeasons = when (phase) {
                "REGRESSION" -> DriverEvolutionEngine.regressionSeasons(current.evolution)
                "PEAK" -> 2
                else -> DriverEvolutionEngine.ascentSeasons(current.evolution)
            }
            val totalGps = phaseSeasons * 30
            val start = phaseStart[id] ?: DriverProfileCatalog.overall(ratingsForEvolution(current))
            val distance = kotlin.math.abs(target - start)
            val perGp = if (phase == "PEAK" || distance == 0) 0.0 else distance.toDouble()*7.0/totalGps.toDouble().coerceAtLeast(1.0)
            bank += perGp * multiplier * anticipation
            val whole = bank.toInt()
            if (whole > 0 && phase != "PEAK") {
                val before = current
                current = if (phase == "GROWING") DriverEvolutionEngine.applyPositiveGain(current, whole, IntArray(7), rng)
                    else DriverEvolutionEngine.applyRegression(current, whole, rng)
                val actual = DriverProfileCatalog.overall(ratingsForEvolution(current)) - DriverProfileCatalog.overall(ratingsForEvolution(before))
                if (actual != 0) bank -= whole.toDouble()
                else bank -= whole.toDouble().coerceAtMost(bank)
            }

            gps++
            val afterOverall = DriverProfileCatalog.overall(ratingsForEvolution(current))
            val reached = if (phase == "REGRESSION") afterOverall <= target else afterOverall >= target
            var pp = pressure[id] ?: 0.0
            if (phase == "GROWING") {
                pp = (pp + when { index < 60 -> 1.0; index < 75 -> 0.35; index >= 105 -> -0.70; index >= 92 -> -0.35; else -> -0.10 }).coerceIn(0.0,12.0)
                if (pp >= 12.0) {
                    phase="REGRESSION"; gps=0; phaseStart[id]=afterOverall; phaseTarget[id]=DriverProfileCatalog.minimumOverall(current.driverClass); bank=0.0; pp=0.0
                } else if (reached || gps >= totalGps) {
                    phase="PEAK"; gps=0; phaseStart[id]=afterOverall; phaseTarget[id]=DriverProfileCatalog.ceiling(current.driverClass); bank=0.0; pp=0.0
                }
            } else if (phase == "REGRESSION") {
                if (reached || gps >= totalGps) {
                    phase="GROWING"; gps=0; phaseStart[id]=afterOverall; phaseTarget[id]=DriverProfileCatalog.ceiling(current.driverClass); bank=0.0; pp=0.0
                }
            } else if (gps >= totalGps) {
                phase="REGRESSION"; gps=0; phaseStart[id]=afterOverall; phaseTarget[id]=DriverProfileCatalog.minimumOverall(current.driverClass); bank=0.0; pp=0.0
            }

            val beforeOverall = DriverProfileCatalog.overall(currentAttrs)
            // Central de Notícias: one card per driver/GP, and only when the
            // same integer Overall shown by the UI actually increases. Attribute
            // changes that leave Overall unchanged and regressions are not news.
            if (afterOverall > beforeOverall) {
                val team = loadDriverMarket()?.contracts?.firstOrNull { it.driverId == id && it.activeIn(season) }
                    ?.let { deal -> WorldDatabase.teams.firstOrNull { t -> t.id == deal.teamId }?.name } ?: "Sem equipe"
                val delta = afterOverall - beforeOverall
                changes += "${base.name} — $team — GP $round: Overall $beforeOverall → $afterOverall (+$delta)."
            }
            attrs[id] = ratingsForEvolution(current)
            phases[id] = phase; phaseGps[id]=gps; phaseStart[id]=phaseStart[id] ?: afterOverall; phaseTarget[id]=phaseTarget[id] ?: target
            pressure[id]=pp; banks[id]=bank
        }
        // Commit all evolution state and its idempotency marker atomically. Previously
        // each map was written with a separate apply(); process death between those writes
        // could persist changed ratings without the processed-round marker, applying the
        // same evolution twice after recovery (or persist the marker without all attributes).
        fun encodeIntMap(values: Map<Int, Int>) = values.toSortedMap().entries.joinToString(",") { "${it.key}:${it.value}" }
        fun encodeDoubleMap(values: Map<Int, Double>) = values.toSortedMap().entries.joinToString(",") { "${it.key}:${it.value}" }
        val evolutionCommit = prefs.edit()
            .putString("driverAttributes", DriverAttributePersistence.serialize(attrs))
            .putString("driverEvolutionPhases", phases.toSortedMap().entries.joinToString(";") { "${it.key}:${it.value}" })
            .putString("driverEvolutionBank_$season", encodeDoubleMap(banks))
            .putString("driverEvolutionPhaseGps", encodeIntMap(phaseGps))
            .putString("driverEvolutionPhaseStart", encodeIntMap(phaseStart))
            .putString("driverEvolutionPhaseTarget", encodeIntMap(phaseTarget))
            .putString("driverEvolutionPhasePressure", encodeDoubleMap(pressure))
            .putString("driverEvolutionProcessedRounds_$season", encodeIntMap(processedRounds + (round to 1)))
            .putString(pendingDriverEvolutionNewsKey(season, round), changes.joinToString("\n") {
                java.util.Base64.getEncoder().encodeToString(it.toByteArray(Charsets.UTF_8))
            })
        check(evolutionCommit.commit()) {
            "Não foi possível persistir a evolução dos pilotos do GP $round/temporada $season"
        }
        // Even an empty change list gets a durable outbox record so retries can
        // distinguish “no news” from “news still waiting to be published”.
        flushPendingDriverEvolutionNews(season, round)
        return changes
    }

    /** Regression is now processed per GP by applyDriverRaceEvolution. Kept as a
     * compatibility entry point so old UI flows cannot apply a second annual loss. */
    fun applySeasonEndRegression(seasonToClose:Int): Int = 0

    fun startNewCareer(selectedTeamId: Int) {
        teamId = selectedTeamId; roundIndex = 0; currentWeek = 1; season = 2026; hasCareer = true
        // Reuse the seed already used by the team selector so its performance
        // ranking remains identical when the career opens. This seed also draws
        // the career calendar and is persisted for reload consistency.
        val openingSeed = prefs.getInt("pendingCareerSeed", 0).let { pending ->
            if (pending != 0) pending else kotlin.random.Random.nextInt().let { if (it == 0) 1 else it }
        }
        val staleAnnualKeys = prefs.all.keys.filter { key ->
            key.startsWith("annualEventCalendar_") || key.startsWith("annualEventProcessed_") ||
                key.startsWith("annualEventSeed_") || key.startsWith("seasonStartEventSeen_") ||
                key.startsWith("seasonEndEventSeen_")
        }
        if (staleAnnualKeys.isNotEmpty()) {
            val annualEditor = prefs.edit()
            staleAnnualKeys.forEach { annualEditor.remove(it) }
            check(annualEditor.commit()) { "Não foi possível limpar os eventos anuais da carreira anterior" }
        }
        prefs.edit().putInt("calendarSeed_$season", openingSeed).remove("pendingCareerSeed").apply()
        SeasonCalendar.configureSeasonSeed(season, openingSeed)
        InitialTeamProfile.configureCareerSeed(openingSeed)
        writeMap("driverPoints", emptyMap()); writeMap("constructorPoints", emptyMap())
        for (r in 1..SeasonCalendar.forSeason(season).size) prefs.edit().remove("race_$r").apply()
        history.clear()
        // A fresh career must not inherit any completed-GP ledger from the previous
        // save. Otherwise the same season/round keys can block its first races or
        // make the app recover a result belonging to the old team/career.
        val staleRaceKeys = prefs.all.keys.filter { key ->
            key.startsWith("race_finalize_") || key.startsWith("pending_race_result_") ||
                key.startsWith("race_result_acknowledged_") || key.startsWith("qualifyingBonusPaid_") ||
                key.startsWith("driverSalaryPaid_") || key.startsWith("driverEvolutionPendingNews_") ||
                Regex("race_20\\d{2}_\\d+").matches(key)
        }
        if (staleRaceKeys.isNotEmpty()) {
            val ledgerEditor = prefs.edit()
            staleRaceKeys.forEach { ledgerEditor.remove(it) }
            check(ledgerEditor.commit()) { "Não foi possível limpar os registros de corrida da carreira anterior" }
        }
        prefs.edit().remove("driverEvolutionAppliedSeason").remove("driverRegressionAppliedSeason").remove("driverEvolutionBank_$season").remove("driverEvolutionAccumulated_$season").remove("driverEvolutionAttributeGains_$season").apply()
        val openingAttrs = WorldDatabase.allDrivers.associate { it.id to intArrayOf(it.speed,it.qualifying,it.overtaking,it.defense,it.consistency,it.wet,it.tyre) }
        saveDriverAttributes(openingAttrs)
        saveSeasonStartDriverAttributes(season, openingAttrs)
        initializeDriverSeasonTargets()
        val t=WorldDatabase.teams.first { it.id==selectedTeamId }
        saveCar(selectedTeamId, com.f1teammanager.core.manager.InitialTeamProfile.carState(t))
        saveGarage(selectedTeamId, com.f1teammanager.core.manager.TeamGarageFactory.fromInitial(t))
        saveResearch(selectedTeamId, TeamResearchState())
        saveDriverDevelopment(selectedTeamId, com.f1teammanager.core.manager.DriverDevelopmentState())
        saveTechnicalInvestment(selectedTeamId, com.f1teammanager.core.manager.TechnicalInvestmentEngine.forTeam(season, selectedTeamId, selectedTeamId, com.f1teammanager.core.manager.InitialTeamProfile.carState(t)))
        saveFinance(selectedTeamId, TeamFinanceState(com.f1teammanager.core.manager.InitialTeamProfile.initialBudget(t)));
        prefs.edit().remove("aiTeamBudgets").remove("constructorPrizePaidTeams_2026").remove("aiFinanceSnapshot").remove("aiSponsorshipSnapshot").remove("facilityUpgrade_$selectedTeamId").apply()
        putInt("annualDriverSalarySeason_${selectedTeamId}",0); saveSponsors(selectedTeamId, emptyList())
        saveDriverMarket(com.f1teammanager.core.manager.DriverMarketEngine().initialState(season))
    }

    /** True after GP 30 has been archived, while the game is still on the completed season. */
    fun isSeasonEnded(): Boolean =
        roundIndex == SeasonCalendar.forSeason(season).lastIndex && history.isSeasonFinalized(season)

    /** Season-start and season-end presentation events are persisted independently per season. */
    fun hasSeenSeasonStartEvent(seasonNumber: Int = season): Boolean =
        prefs.getBoolean("seasonStartEventSeen_$seasonNumber", false)

    fun markSeasonStartEventSeen(seasonNumber: Int = season) {
        require(seasonNumber >= 1)
        check(prefs.edit().putBoolean("seasonStartEventSeen_$seasonNumber", true).commit()) {
            "Não foi possível salvar a apresentação de início da temporada $seasonNumber"
        }
    }

    fun shouldShowSeasonStartEvent(seasonNumber: Int = season): Boolean =
        hasCareer && currentWeek == 1 && roundIndex == 0 && !hasSeenSeasonStartEvent(seasonNumber)


    /** Regulation presentation is shown before the season-start presentation, once per season. */
    fun hasSeenCarRegulationEvent(seasonNumber: Int = season): Boolean =
        prefs.getBoolean("carRegulationEventSeen_$seasonNumber", false)

    fun markCarRegulationEventSeen(seasonNumber: Int = season) {
        require(seasonNumber >= 1)
        check(prefs.edit().putBoolean("carRegulationEventSeen_$seasonNumber", true).commit()) {
            "Não foi possível salvar a apresentação do regulamento da temporada $seasonNumber"
        }
    }

    fun shouldShowCarRegulationEvent(seasonNumber: Int = season): Boolean {
        if (!hasCareer || currentWeek != 1 || roundIndex != 0 || hasSeenCarRegulationEvent(seasonNumber)) return false
        val rule = ensureCarRegulationRule(seasonNumber)
        return rule.annualEvents.isNotEmpty() || rule.decennialRevolution
    }

    fun hasSeenSeasonEndEvent(seasonNumber: Int = season): Boolean =
        prefs.getBoolean("seasonEndEventSeen_$seasonNumber", false)

    fun markSeasonEndEventSeen(seasonNumber: Int = season) {
        require(seasonNumber >= 1)
        check(prefs.edit().putBoolean("seasonEndEventSeen_$seasonNumber", true).commit()) {
            "Não foi possível salvar a retrospectiva da temporada $seasonNumber"
        }
    }

    fun shouldShowSeasonEndEvent(seasonNumber: Int = season): Boolean =
        isSeasonEnded() && !hasSeenSeasonEndEvent(seasonNumber)

    /**
     * Advance to the next GP after a completed race.
     * GP 30 is deliberately different: it only archives the season and leaves the
     * current year/round intact until the manager explicitly starts the next season.
     */
    fun completeCurrentRace() {
        if (roundIndex < SeasonCalendar.forSeason(season).lastIndex) {
            roundIndex += 1
            // Do NOT move currentWeek here. The completed GP happened in the current
            // week; the manager must return to the calendar and manually advance the
            // remaining free weeks until the next GP week.
        } else {
            history.finalizeSeason(season, driverPoints(), constructorPoints(), loadDriverMarket())
            // Stay on the completed season. No automatic year change here.
        }
    }

    /**
     * V427 durable season-transition journal. Stages are persisted synchronously so a
     * restart can identify an interrupted boundary instead of silently treating it as complete.
     * This journal deliberately does not claim to replay a partially committed transition;
     * callers must resume/repair it before allowing another transition.
     */
    private fun snapshotCareerForSeasonTransition(): Boolean {
        // SharedPreferences cannot copy its own map through Editor; use a dedicated file
        // so the recovery snapshot is committed independently before the journal starts.
        val snapshot = prefs.all
        val backupPrefs = prefsSnapshot()
        val editor = backupPrefs.edit().clear()
        snapshot.forEach { (key, value) ->
            when (value) {
                is String -> editor.putString(key, value)
                is Int -> editor.putInt(key, value)
                is Long -> editor.putLong(key, value)
                is Float -> editor.putFloat(key, value)
                is Boolean -> editor.putBoolean(key, value)
                is Set<*> -> editor.putStringSet(key, value.filterIsInstance<String>().toMutableSet())
            }
        }
        editor.putBoolean("__season_transition_snapshot_ready", true)
        return editor.commit()
    }

    private fun prefsSnapshot() = snapshotContext.getSharedPreferences(
        "f1tm_career_transition_backup", Context.MODE_PRIVATE
    )

    private val snapshotContext: Context get() = transitionContext

    private fun restoreCareerSeasonTransitionSnapshot(): Boolean {
        val backup = prefsSnapshot()
        if (!backup.getBoolean("__season_transition_snapshot_ready", false)) return false
        val editor = prefs.edit().clear()
        backup.all.forEach { (key, value) ->
            if (key == "__season_transition_snapshot_ready") return@forEach
            when (value) {
                is String -> editor.putString(key, value)
                is Int -> editor.putInt(key, value)
                is Long -> editor.putLong(key, value)
                is Float -> editor.putFloat(key, value)
                is Boolean -> editor.putBoolean(key, value)
                is Set<*> -> editor.putStringSet(key, value.filterIsInstance<String>().toMutableSet())
            }
        }
        return editor.commit()
    }

    fun beginSeasonTransitionJournal(fromSeason: Int): Int {
        val pendingFrom = prefs.getInt("seasonTransitionPendingFrom", 0)
        val pendingTo = prefs.getInt("seasonTransitionPendingTo", 0)
        if (pendingFrom != 0 && pendingTo != 0) {
            val stage = prefs.getString("seasonTransitionStage", "PREPARED") ?: "PREPARED"
            if (stage == "STATE_PERSISTED") return pendingTo
            // Any earlier checkpoint means some of the canonical keys may have been
            // written. Restore the pre-transition snapshot, then safely retry from the
            // archived season instead of replaying operations over a mixed state.
            check(restoreCareerSeasonTransitionSnapshot()) {
                "Virada interrompida sem snapshot íntegro. A carreira foi bloqueada para evitar corrupção de dados."
            }
            val restoredSeason = prefs.getInt("season", pendingFrom)
            require(restoredSeason == pendingFrom && isSeasonEnded()) {
                "O snapshot restaurado não corresponde à temporada encerrada."
            }
        }
        require(isSeasonEnded()) { "A temporada atual ainda não foi encerrada." }
        val sourceSeason = prefs.getInt("season", fromSeason)
        check(snapshotCareerForSeasonTransition()) { "Não foi possível salvar o snapshot de segurança da virada." }
        val target = sourceSeason + 1
        check(prefs.edit().putInt("seasonTransitionPendingFrom", sourceSeason)
            .putInt("seasonTransitionPendingTo", target)
            .putString("seasonTransitionStage", "PREPARED").commit()) {
            "Não foi possível gravar o diário da virada."
        }
        return target
    }

    private val seasonTransitionStages = listOf(
        "PREPARED", "SEASON_ADVANCED", "CAREER_RESET_DONE", "MANAGER_STATE_READY",
        "CAR_SAVED", "GARAGE_SAVED", "FACILITIES_SAVED", "TECHNICAL_INVESTMENT_SAVED",
        "RESEARCH_SAVED", "FACTORY_SAVED", "DRIVER_DEVELOPMENT_SAVED", "MARKET_SAVED",
        "FINANCE_SAVED", "SPONSORS_SAVED", "STATE_PERSISTED"
    )

    /**
     * Persist only a monotonic checkpoint. Repeating the current checkpoint is safe,
     * but skipping ahead or moving backwards would make crash recovery ambiguous.
     */
    fun markSeasonTransitionStage(stage: String): Boolean {
        val requestedIndex = seasonTransitionStages.indexOf(stage)
        require(requestedIndex >= 0) { "Etapa de virada inválida." }
        val current = prefs.getString("seasonTransitionStage", null) ?: return false
        val currentIndex = seasonTransitionStages.indexOf(current)
        if (currentIndex < 0 || requestedIndex < currentIndex || requestedIndex > currentIndex + 1) return false
        if (requestedIndex == currentIndex) return true
        return prefs.edit().putString("seasonTransitionStage", stage).commit()
    }

    fun pendingSeasonTransition(): Triple<Int, Int, String>? {
        val from = prefs.getInt("seasonTransitionPendingFrom", 0)
        val to = prefs.getInt("seasonTransitionPendingTo", 0)
        if (from == 0 || to == 0) return null
        return Triple(from, to, prefs.getString("seasonTransitionStage", "PREPARED") ?: "PREPARED")
    }

    /**
     * Roll back an interrupted transition to the exact pre-transition career snapshot.
     * This is only valid before STATE_PERSISTED; committed transitions must be finalized,
     * never rolled back after the durable commit point.
     */
    fun rollbackSeasonTransitionJournal(): Boolean {
        val pending = pendingSeasonTransition() ?: return true
        if (pending.third == "STATE_PERSISTED") return false
        if (!restoreCareerSeasonTransitionSnapshot()) return false
        // The restored career snapshot predates the journal, so it also removes its keys.
        // Clear the backup only after the career restore has committed successfully.
        return prefsSnapshot().edit().clear().commit()
    }

    fun completeSeasonTransitionJournal(): Boolean {
        // Remove the rollback image first. If this fails, the STATE_PERSISTED journal
        // remains available for a safe cleanup retry. If the process dies after this
        // commit, the canonical state is already complete and only journal cleanup remains.
        if (!prefsSnapshot().edit().clear().commit()) return false
        return prefs.edit().remove("seasonTransitionPendingFrom")
            .remove("seasonTransitionPendingTo").remove("seasonTransitionStage").commit()
    }

    /** Explicit player action: starts the archived season's successor. */
    fun startNextSeason() {
        require(isSeasonEnded()) { "A temporada atual ainda não foi encerrada." }
        season += 1
        roundIndex = 0
        currentWeek = 1
        // A new season gets a new 30/50 draw while remaining fixed for that season.
        newCalendarSeed(season)
        writeMap("driverPoints", emptyMap())
        writeMap("constructorPoints", emptyMap())
        for (r in 1..SeasonCalendar.forSeason(season).size) prefs.edit().remove("race_$r").apply()
        prefs.edit().remove("driverEvolutionAppliedSeason").remove("driverRegressionAppliedSeason").remove("driverEvolutionBank_$season").remove("driverEvolutionAccumulated_$season").remove("driverEvolutionAttributeGains_$season").apply()
        saveSeasonStartDriverAttributes(season, driverAttributes())
        initializeDriverSeasonTargets()
        val nextCar = loadCar(teamId)
        saveTechnicalInvestment(teamId, com.f1teammanager.core.manager.TechnicalInvestmentEngine.forTeam(season, teamId, teamId, nextCar))
        loadDriverMarket()?.let { saveDriverMarket(com.f1teammanager.core.manager.DriverMarketEngine().applySeasonTransition(it, season)) }
    }

    /** Advance one or more real calendar weeks. Returns the number of weeks actually advanced. */
    fun advanceCalendarWeeks(weeks: Int): Int {
        val old = currentWeek
        currentWeek = (currentWeek + weeks.coerceAtLeast(0)).coerceAtMost(56)
        return currentWeek - old
    }

    fun jumpToWeek(week: Int): Int {
        val old = currentWeek
        currentWeek = week
        return currentWeek - old
    }

    /** Creates an atomic portable backup of the complete career preferences and race archive. */
    fun exportCareerBackup(): org.json.JSONObject {
        val values = org.json.JSONObject()
        prefs.all.forEach { (key, value) ->
            val item = org.json.JSONObject()
            when (value) {
                is String -> { item.put("type", "string"); item.put("value", value) }
                is Int -> { item.put("type", "int"); item.put("value", value) }
                is Long -> { item.put("type", "long"); item.put("value", value) }
                is Float -> { item.put("type", "float"); item.put("value", value.toDouble()) }
                is Boolean -> { item.put("type", "boolean"); item.put("value", value) }
                is Set<*> -> { item.put("type", "set"); item.put("value", org.json.JSONArray(value.filterIsInstance<String>())) }
            }
            values.put(key, item)
        }
        val historyFile = File(transitionContext.filesDir, "f1tm_historical_v2.db")
        val history = if (historyFile.exists()) android.util.Base64.encodeToString(historyFile.readBytes(), android.util.Base64.NO_WRAP) else ""
        return org.json.JSONObject().put("format", "F1TM_SAVE").put("schema", 1)
            .put("teamId", teamId).put("season", season).put("createdAt", System.currentTimeMillis())
            .put("preferences", values).put("historicalArchive", history)
    }

    /** Validates the complete payload before replacing live preferences or the historical archive. */
    fun importCareerBackup(payload: org.json.JSONObject): Boolean {
        require(payload.optString("format") == "F1TM_SAVE" && payload.optInt("schema") == 1) { "Formato de save não reconhecido." }
        val values = payload.optJSONObject("preferences") ?: error("Backup sem preferências da carreira.")
        require(values.has("hasCareer") && values.has("teamId") && values.has("season")) { "Backup incompleto." }
        val team = values.getJSONObject("teamId").optInt("value", -1)
        val year = values.getJSONObject("season").optInt("value", -1)
        require(team in 1..40 && year >= 2026) { "Equipe ou temporada inválida." }
        val editor = prefs.edit().clear()
        val keys = values.keys()
        while (keys.hasNext()) {
            val key = keys.next(); val item = values.getJSONObject(key); val value = item.opt("value")
            when (item.optString("type")) {
                "string" -> editor.putString(key, value as? String ?: "")
                "int" -> editor.putInt(key, (value as Number).toInt())
                "long" -> editor.putLong(key, (value as Number).toLong())
                "float" -> editor.putFloat(key, (value as Number).toFloat())
                "boolean" -> editor.putBoolean(key, value as Boolean)
                "set" -> { val a = value as org.json.JSONArray; editor.putStringSet(key, (0 until a.length()).map { a.getString(it) }.toMutableSet()) }
                else -> error("Tipo de dado desconhecido no backup.")
            }
        }
        val archiveText = payload.optString("historicalArchive", "")
        val archiveBytes = if (archiveText.isNotBlank()) android.util.Base64.decode(archiveText, android.util.Base64.DEFAULT) else byteArrayOf()
        // Validate before commit. Preserve a rollback copy if the historical archive exists.
        val archiveFile = File(transitionContext.filesDir, "f1tm_historical_v2.db")
        val oldArchive = if (archiveFile.exists()) archiveFile.readBytes() else null
        val oldPrefs = prefs.all.toMap()
        check(editor.commit()) { "Não foi possível gravar a carreira importada." }
        try {
            if (archiveBytes.isNotEmpty()) {
                val atomic = android.util.AtomicFile(archiveFile)
                val out = atomic.startWrite()
                try { out.write(archiveBytes); atomic.finishWrite(out) } catch (t: Throwable) { atomic.failWrite(out); throw t }
            } else if (archiveFile.exists()) archiveFile.delete()
        } catch (t: Throwable) {
            val rollback = prefs.edit().clear()
            oldPrefs.forEach { (k,v) -> when(v) { is String -> rollback.putString(k,v); is Int -> rollback.putInt(k,v); is Long -> rollback.putLong(k,v); is Float -> rollback.putFloat(k,v); is Boolean -> rollback.putBoolean(k,v); is Set<*> -> rollback.putStringSet(k,v.filterIsInstance<String>().toMutableSet()) } }
            rollback.commit()
            if (oldArchive != null) archiveFile.writeBytes(oldArchive)
            throw t
        }
        return true
    }

}
private object WorldTeamResolver { fun teamIdFor(driverId: Int): Int = ((driverId - 1) / 2) + 1 }
