package com.f1teammanager

import android.content.Context
import com.f1teammanager.core.race.RaceResult

/** Persistent career metadata and championship ledger for the active save. */
class CareerPreferences(context: Context) {
    private val prefs = context.getSharedPreferences("f1tm_career", Context.MODE_PRIVATE)

    var hasCareer: Boolean
        get() = prefs.getBoolean("hasCareer", false)
        private set(value) = prefs.edit().putBoolean("hasCareer", value).apply()

    var teamId: Int
        get() = prefs.getInt("teamId", 1)
        private set(value) = prefs.edit().putInt("teamId", value).apply()

    var roundIndex: Int
        get() = prefs.getInt("roundIndex", 0)
        private set(value) = prefs.edit().putInt("roundIndex", value.coerceIn(0, 23)).apply()

    var season: Int
        get() = prefs.getInt("season", 2026)
        private set(value) = prefs.edit().putInt("season", value).apply()

    private fun readMap(key: String): Map<Int, Int> = prefs.getString(key, "")
        .orEmpty()
        .split(',')
        .mapNotNull { token ->
            val p = token.split(':')
            if (p.size == 2) p[0].toIntOrNull()?.let { id -> p[1].toIntOrNull()?.let { value -> id to value } } else null
        }.toMap()

    private fun writeMap(key: String, value: Map<Int, Int>) {
        prefs.edit().putString(key, value.entries.sortedBy { it.key }.joinToString(",") { "${it.key}:${it.value}" }).apply()
    }

    fun driverPoints(): Map<Int, Int> = readMap("driverPoints")
    fun constructorPoints(): Map<Int, Int> = readMap("constructorPoints")

    fun recordRace(result: RaceResult) {
        val drivers = driverPoints().toMutableMap()
        result.points.forEach { (driverId, points) -> drivers[driverId] = (drivers[driverId] ?: 0) + points }
        writeMap("driverPoints", drivers)

        val teams = constructorPoints().toMutableMap()
        result.classification.forEach { finish ->
            teams[WorldTeamResolver.teamIdFor(finish.driverId)] =
                (teams[WorldTeamResolver.teamIdFor(finish.driverId)] ?: 0) + (result.points[finish.driverId] ?: 0)
        }
        writeMap("constructorPoints", teams)
    }

    fun startNewCareer(selectedTeamId: Int) {
        teamId = selectedTeamId
        roundIndex = 0
        season = 2026
        hasCareer = true
        writeMap("driverPoints", emptyMap())
        writeMap("constructorPoints", emptyMap())
    }

    fun advanceRound() {
        if (roundIndex < 23) roundIndex += 1 else {
            season += 1
            roundIndex = 0
            writeMap("driverPoints", emptyMap())
            writeMap("constructorPoints", emptyMap())
        }
    }
}

private object WorldTeamResolver {
    fun teamIdFor(driverId: Int): Int = ((driverId - 1) / 2) + 1
}
