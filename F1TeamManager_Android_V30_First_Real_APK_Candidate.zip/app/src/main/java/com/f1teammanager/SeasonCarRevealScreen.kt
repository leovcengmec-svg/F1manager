package com.f1teammanager

import android.graphics.Bitmap
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Scale
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.f1teammanager.core.manager.SeasonCarRevealSnapshot
import com.f1teammanager.core.season.TeamDefinition
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.text.NumberFormat
import java.util.Locale

private val RevealBg = Color(0xFF070B10)
private val RevealPanel = Color(0xFF101923)
private val RevealLine = Color(0xFF2A3A4A)
private val RevealText = Color(0xFFF4F7FB)
private val RevealMuted = Color(0xFFA8B5C4)
private val RevealRed = Color(0xFFE10600)
private val RevealGreen = Color(0xFF27D4A0)

@Composable
fun SeasonCarRevealScreen(
    team: TeamDefinition,
    snapshot: SeasonCarRevealSnapshot,
    teamRank: Int,
    totalTeams: Int,
    onContinue: () -> Unit
) {
    var stage by remember(snapshot.season) { mutableIntStateOf(0) }
    LaunchedEffect(snapshot.season) {
        while (stage < 4) {
            delay(1_050)
            stage = (stage + 1).coerceAtMost(4)
        }
    }

    val overallTarget = when (stage) {
        0 -> snapshot.startingOverall
        1 -> snapshot.investmentOverall
        2 -> snapshot.inheritedOverall
        else -> snapshot.finalOverall
    }
    val animatedOverall by animateFloatAsState(
        targetValue = overallTarget.toFloat(), animationSpec = tween(780), label = "season-car-overall"
    )
    val reliabilityTarget = if (stage == 0) snapshot.startingReliability else snapshot.finalReliability
    val animatedReliability by animateFloatAsState(
        targetValue = reliabilityTarget.toFloat(), animationSpec = tween(650), label = "season-car-reliability"
    )
    val context = LocalContext.current
    var carBitmap by remember(team.id, team.name) { mutableStateOf<Bitmap?>(null) }
    LaunchedEffect(team.id, team.name) {
        carBitmap = withContext(Dispatchers.IO) { ExternalAssets.loadTeamCarVisual(context, team.id, team.name) }
    }
    val money = remember(snapshot.investmentAmount) {
        NumberFormat.getCurrencyInstance(Locale.GERMANY).format(snapshot.investmentAmount)
    }
    val stepTitle = when (stage) {
        0 -> "ANALISANDO O CARRO ANTERIOR"
        1 -> "1 • INVESTIMENTO APLICADO"
        2 -> "2 • HERANÇA TÉCNICA"
        3 -> "3 • REGULAMENTO APLICADO"
        else -> "FORÇA FINAL REVELADA"
    }
    val stepDescription = when (stage) {
        0 -> "Este era o ponto de partida técnico da equipe."
        1 -> "Investimento reservado: $money • ${snapshot.investmentSteps} etapas técnicas aplicadas."
        2 -> "Transferência de 10% por componente e conhecimento técnico acumulado, conforme as regras do jogo."
        3 -> "As restrições regulamentares da temporada foram aplicadas uma única vez ao carro construído."
        else -> "O carro está pronto. A posição considera a força dos carros do grid para esta temporada."
    }

    BoxWithConstraints(Modifier.fillMaxSize().background(RevealBg)) {
        val compact = maxHeight < 760.dp
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(if (compact) 8.dp else 11.dp)
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text("VIRADA DE TEMPORADA", color = RevealRed, fontSize = 11.sp, fontWeight = FontWeight.Black)
                    Text("${snapshot.season} • APRESENTAÇÃO TÉCNICA", color = RevealMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
                Text("F1 TEAM MANAGER", color = RevealText, fontSize = 10.sp, fontWeight = FontWeight.Black)
            }

            Box(
                Modifier.fillMaxWidth().height(if (compact) 190.dp else 226.dp).clip(RoundedCornerShape(18.dp))
                    .background(Brush.verticalGradient(listOf(Color(0xFF253241), Color(0xFF101923), Color(0xFF090D13))))
                    .border(1.dp, RevealLine, RoundedCornerShape(18.dp))
            ) {
                Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(listOf(RevealRed.copy(alpha = 0.17f), Color.Transparent, Color(0xFF1678C8).copy(alpha = 0.10f)))))
                if (carBitmap != null) {
                    Image(carBitmap!!.asImageBitmap(), contentDescription = "Carro da equipe ${team.name}",
                        modifier = Modifier.align(Alignment.Center).fillMaxWidth(0.94f).height(if (compact) 145.dp else 174.dp),
                        contentScale = ContentScale.Fit)
                } else {
                    Text("F1", color = RevealText.copy(alpha = 0.15f), fontSize = 68.sp, fontWeight = FontWeight.Black, modifier = Modifier.align(Alignment.Center))
                }
                Column(Modifier.align(Alignment.BottomStart).padding(14.dp), verticalArrangement = Arrangement.spacedBy(1.dp)) {
                    Text(team.name.uppercase(), color = RevealText, fontSize = if (compact) 14.sp else 17.sp, fontWeight = FontWeight.Black)
                    Text("O NOVO CARRO ESTÁ SENDO REVELADO", color = RevealRed, fontSize = 9.sp, fontWeight = FontWeight.Black)
                }
            }

            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(RevealPanel)
                    .border(1.dp, RevealLine, RoundedCornerShape(16.dp)).padding(13.dp),
                verticalArrangement = Arrangement.spacedBy(9.dp)
            ) {
                Text(stepTitle, color = RevealText, fontSize = 15.sp, fontWeight = FontWeight.Black)
                Text(stepDescription, color = RevealMuted, fontSize = 11.sp, lineHeight = 15.sp)

                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("FORÇA DO CARRO", color = RevealMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Text("${animatedOverall.toInt()}/100", color = RevealText, fontSize = 22.sp, fontWeight = FontWeight.Black)
                }
                CategoryStrengthBar(overall = animatedOverall.toInt())
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    listOf("FIM", "FRACO", "MÉDIO", "BOM", "EXCELENTE", "TÍTULO").forEachIndexed { index, label ->
                        Text(label, color = if (stage >= 4 && index == categoryIndex(snapshot.finalOverall)) RevealGreen else RevealMuted,
                            fontSize = 7.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                    }
                }

                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                    Icon(Icons.Filled.Build, contentDescription = null, tint = RevealGreen, modifier = Modifier.size(20.dp))
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text("CONFIABILIDADE", color = RevealMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        Text("${animatedReliability.toInt()}/100", color = RevealText, fontSize = 16.sp, fontWeight = FontWeight.Black)
                    }
                    RevealStageIcon(1, stage, Icons.Filled.TrendingUp, "Investimento")
                    RevealStageIcon(2, stage, Icons.Filled.Memory, "Herança técnica")
                    RevealStageIcon(3, stage, Icons.Filled.Scale, "Regulamento")
                }
            }

            if (stage >= 4) {
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp))
                        .background(Brush.horizontalGradient(listOf(Color(0xFF102C2B), Color(0xFF14202C))))
                        .border(1.dp, RevealGreen.copy(alpha = 0.65f), RoundedCornerShape(16.dp)).padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Icon(Icons.Filled.EmojiEvents, contentDescription = "Ranking", tint = RevealGreen, modifier = Modifier.size(38.dp))
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text("RANKING DE FORÇA DA PRÓXIMA TEMPORADA", color = RevealMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        Text(if (teamRank > 0) "$teamRankº LUGAR DE $totalTeams EQUIPES" else "RANKING DISPONÍVEL NA ABERTURA", color = RevealText, fontSize = 18.sp, fontWeight = FontWeight.Black)
                        Text("Desempenho ${snapshot.finalOverall}/100  •  Confiabilidade ${snapshot.finalReliability}/100", color = RevealGreen, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (stage < 4) {
                    Button(
                        onClick = { stage = 4 }, modifier = Modifier.weight(1f).height(48.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF263442), contentColor = RevealText),
                        contentPadding = PaddingValues(horizontal = 8.dp)
                    ) { Text("PULAR ANIMAÇÃO", fontSize = 11.sp, fontWeight = FontWeight.Black, maxLines = 1) }
                } else {
                    Button(
                        onClick = onContinue, modifier = Modifier.weight(1f).height(50.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = RevealRed, contentColor = Color.White),
                        contentPadding = PaddingValues(horizontal = 8.dp)
                    ) { Text("CONTINUAR PARA A TEMPORADA  ›", fontSize = 12.sp, fontWeight = FontWeight.Black, maxLines = 1) }
                }
            }
        }
    }
}

@Composable
private fun CategoryStrengthBar(overall: Int) {
    val mapped = ((overall.coerceIn(40, 100) - 40) / 60f).coerceIn(0f, 1f)
    Box(Modifier.fillMaxWidth().height(22.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xFF1B2733))) {
        Row(Modifier.fillMaxSize().padding(2.dp), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
            val categoryColors: List<Color> = listOf(Color(0xFF596474), Color(0xFF168F9D), Color(0xFF2776C8), Color(0xFFD09124), Color(0xFF24A56F), Color(0xFF16C7A0))
            categoryColors.forEach { color: Color ->
                Box(Modifier.weight(1f).fillMaxSize().clip(RoundedCornerShape(3.dp)).background(color.copy(alpha = 0.5f)))
            }
        }
        BoxWithConstraints(Modifier.fillMaxSize()) {
            Box(Modifier.align(Alignment.CenterStart).fillMaxWidth(mapped).height(18.dp).clip(RoundedCornerShape(6.dp))
                .background(Brush.horizontalGradient(listOf(Color(0xFF1D8391), RevealGreen))))
        }
    }
}

@Composable
private fun RevealStageIcon(number: Int, activeStage: Int, icon: androidx.compose.ui.graphics.vector.ImageVector, label: String) {
    val active = activeStage >= number
    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Box(Modifier.size(30.dp).clip(RoundedCornerShape(8.dp)).background(if (active) RevealGreen.copy(alpha = 0.16f) else Color(0xFF1B2733))
            .border(1.dp, if (active) RevealGreen else RevealLine, RoundedCornerShape(8.dp)), contentAlignment = Alignment.Center) {
            if (active) Icon(Icons.Filled.CheckCircle, contentDescription = label, tint = RevealGreen, modifier = Modifier.size(17.dp))
            else Icon(icon, contentDescription = label, tint = RevealMuted, modifier = Modifier.size(16.dp))
        }
        Text(label, color = if (active) RevealGreen else RevealMuted, fontSize = 6.sp, textAlign = TextAlign.Center, maxLines = 2, lineHeight = 7.sp)
    }
}

private fun categoryIndex(overall: Int): Int = when (overall) {
    in Int.MIN_VALUE..49 -> 0
    in 50..59 -> 1
    in 60..69 -> 2
    in 70..79 -> 3
    in 80..89 -> 4
    else -> 5
}
