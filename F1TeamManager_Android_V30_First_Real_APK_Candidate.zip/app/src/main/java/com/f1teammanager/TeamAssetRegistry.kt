package com.f1teammanager

/**
 * Stable asset IDs. They intentionally mirror the 40 permanent TeamDefinition IDs.
 * Asset filenames must never depend on a displayed team name.
 */
object TeamAssetRegistry {
    fun teamAssetId(teamId: Int): String = teamId.coerceIn(1, 40).toString().padStart(2, '0')
    fun carVisualFileName(teamId: Int): String = "${teamAssetId(teamId)}.png"
}
