package com.f1teammanager

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.SportsMotorsports
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.f1teammanager.core.season.DriverDefinition
import com.f1teammanager.core.season.TeamDefinition
import com.f1teammanager.core.season.WorldDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private val EndBg = Color(0xFF070B10)
private val EndPanel = Color(0xFF0D141D)
private val EndPanelAlt = Color(0xFF121C27)
private val EndLine = Color(0xFF243342)
private val EndRed = Color(0xFFF20D22)
private val EndGold = Color(0xFFFFC94A)
private val EndBlue = Color(0xFF38A5FF)
private val EndGreen = Color(0xFF16D98A)
private val EndText = Color(0xFFF5F7FA)
private val EndMuted = Color(0xFFB0BDCC)

/** Facts passed to the end-of-season screen. Populate these from HistoricalDatabase; no demo values are assumed. */
data class SeasonEndSummary(
    val season: Int,
    val driverChampionId: Int? = null,
    val constructorChampionId: Int? = null,
    val driverChampionPoints: Int = 0,
    val constructorChampionPoints: Int = 0,
    val driverChampionWins: Int = 0,
    val driverChampionPodiums: Int = 0,
    val constructorWins: Int = 0,
    val constructorPodiums: Int = 0,
    val constructorPoles: Int = 0,
    val constructorPoints: Int = 0,
    val mostWinsName: String = "—",
    val mostWins: Int = 0,
    val mostPodiumsName: String = "—",
    val mostPodiums: Int = 0,
    val mostPolesName: String = "—",
    val mostPoles: Int = 0,
    val mostPointsName: String = "—",
    val mostPoints: Int = 0,
    val playerTeamId: Int? = null,
    val playerTeamPosition: Int? = null,
    val playerTeamWins: Int = 0,
    val playerTeamPodiums: Int = 0,
    val playerTeamPoles: Int = 0,
    val playerTeamPoints: Int = 0,
    val playerTeamPositionDelta: Int? = null,
    val highlights: List<SeasonEndHighlight> = emptyList(),
    val teamMovements: List<SeasonEndMovement> = emptyList()
)

data class SeasonEndHighlight(val title: String, val description: String, val imageGrandPrix: String? = null)
data class SeasonEndMovement(val teamId: Int, val teamName: String, val movement: Int, val label: String)

/**
 * Front-end for the approved end-of-season design. Fixed-height sections; deliberately no scrolling.
 * The caller must supply values from HistoricalDatabase and handle the continue action.
 */
@Composable
fun SeasonEndEventScreen(
    summary: SeasonEndSummary,
    teams: List<TeamDefinition> = WorldDatabase.teams,
    drivers: List<DriverDefinition> = WorldDatabase.allDrivers,
    onContinue: () -> Unit
) {
    val driverChampion = remember(summary.driverChampionId, drivers) { drivers.firstOrNull { it.id == summary.driverChampionId } }
    val constructorChampion = remember(summary.constructorChampionId, teams) { teams.firstOrNull { it.id == summary.constructorChampionId } }
    val playerTeam = remember(summary.playerTeamId, teams) { teams.firstOrNull { it.id == summary.playerTeamId } }
    val teamById = remember(teams) { teams.associateBy { it.id } }
    val heroTeam = constructorChampion ?: playerTeam ?: teams.firstOrNull()

    BoxWithConstraints(Modifier.fillMaxSize().background(EndBg)) {
        val compact = maxHeight < 790.dp || maxWidth < 370.dp
        val pad = if (compact) 6.dp else 9.dp
        val gap = if (compact) 3.dp else 5.dp
        Column(Modifier.fillMaxSize().padding(horizontal = pad, vertical = 2.dp), verticalArrangement = Arrangement.spacedBy(gap)) {
            Row(Modifier.fillMaxWidth().height(if (compact) 23.dp else 28.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("‹", color = EndText, fontSize = 28.sp, modifier = Modifier.width(23.dp))
                Text("FIM DA TEMPORADA", color = EndMuted, fontSize = if (compact) 11.sp else 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), maxLines = 1)
                Text("F1 MANAGER", color = EndRed, fontSize = if (compact) 10.sp else 12.sp, fontWeight = FontWeight.Black)
            }

            // Hero banner uses a real champion/team car asset as its visual anchor.
            Row(Modifier.fillMaxWidth().weight(0.92f).clip(RoundedCornerShape(13.dp)).background(EndPanel).border(1.dp, EndLine, RoundedCornerShape(13.dp)).padding(if (compact) 8.dp else 11.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1.12f), verticalArrangement = Arrangement.spacedBy(if (compact) 2.dp else 4.dp)) {
                    Text("ESPECIAL • TEMPORADA ${summary.season}", color = EndRed, fontSize = if (compact) 8.sp else 10.sp, fontWeight = FontWeight.Black, maxLines = 1)
                    Text("TEMPORADA\nENCERRADA", color = EndText, fontSize = if (compact) 18.sp else 23.sp, fontWeight = FontWeight.Black, lineHeight = if (compact) 19.sp else 24.sp, maxLines = 2)
                    Text("Os resultados, as surpresas e os momentos que definiram o campeonato.", color = EndMuted, fontSize = if (compact) 9.sp else 11.sp, lineHeight = if (compact) 11.sp else 14.sp, maxLines = 3, overflow = TextOverflow.Ellipsis)
                }
                if (heroTeam != null) EndTeamCar(heroTeam, Modifier.weight(1f).fillMaxHeight())
            }

            // Champions panel: two equally sized, standardized cards.
            EndSection(Modifier.weight(1.02f), title = "CAMPEÕES DA TEMPORADA", compact = compact, icon = { Icon(Icons.Filled.EmojiEvents, null, tint = EndGold, modifier = Modifier.size(if (compact) 17.dp else 20.dp)) }) {
                Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(gap)) {
                    EndChampionCard("MUNDIAL DE PILOTOS", driverChampion?.name ?: "A definir", driverChampionPoints = summary.driverChampionPoints,
                        subtitle = "${summary.driverChampionWins} VITÓRIAS  •  ${summary.driverChampionPodiums} PÓDIOS", compact = compact, modifier = Modifier.weight(1f)) {
                        if (driverChampion != null) EndDriverPortrait(driverChampion, Modifier.weight(0.72f).fillMaxHeight())
                    }
                    EndChampionCard("MUNDIAL DE EQUIPES", constructorChampion?.name ?: "A definir", driverChampionPoints = summary.constructorPoints,
                        subtitle = "${summary.constructorWins} VITÓRIAS  •  ${summary.constructorPodiums} PÓDIOS", compact = compact, blue = true, modifier = Modifier.weight(1f)) {
                        if (constructorChampion != null) EndTeamCar(constructorChampion, Modifier.weight(0.9f).fillMaxHeight())
                    }
                }
            }

            // Highlights are limited to four cards and text is allowed to wrap across the full width.
            EndSection(Modifier.weight(1.12f), title = "OS GRANDES ACONTECIMENTOS", compact = compact, icon = { Icon(Icons.Filled.Flag, null, tint = EndText, modifier = Modifier.size(if (compact) 17.dp else 20.dp)) }) {
                Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(gap)) {
                    val highlights = summary.highlights.take(4)
                    if (highlights.isEmpty()) {
                        EndHighlightCard(SeasonEndHighlight("TEMPORADA CONCLUÍDA", "O histórico desta carreira ainda não contém destaques suficientes para montar uma retrospectiva."), compact, Modifier.weight(1f))
                    } else highlights.forEach { item -> EndHighlightCard(item, compact, Modifier.weight(1f)) }
                }
            }

            Row(Modifier.weight(1.14f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(gap)) {
                EndSmallPanel(Modifier.weight(1f), "DESTAQUES", compact, icon = { Icon(Icons.Filled.Star, null, tint = EndGold, modifier = Modifier.size(16.dp)) }) {
                    EndRecordRow("Mais vitórias", summary.mostWinsName, summary.mostWins, compact)
                    EndRecordRow("Mais pódios", summary.mostPodiumsName, summary.mostPodiums, compact)
                    EndRecordRow("Mais poles", summary.mostPolesName, summary.mostPoles, compact)
                    EndRecordRow("Mais pontos", summary.mostPointsName, summary.mostPoints, compact)
                }
                EndSmallPanel(Modifier.weight(1f), "EVOLUÇÃO", compact, icon = { Icon(Icons.Filled.TrendingUp, null, tint = EndRed, modifier = Modifier.size(16.dp)) }) {
                    val movements = summary.teamMovements.take(4)
                    if (movements.isEmpty()) EndRecordRow("Comparação", "Histórico anterior indisponível", null, compact)
                    else movements.forEach { movement ->
                        val team = teamById[movement.teamId]
                        EndMovementRow(movement, team, compact)
                    }
                }
                EndSmallPanel(Modifier.weight(1f), "SUA EQUIPE", compact, icon = { Icon(Icons.Filled.SportsMotorsports, null, tint = EndText, modifier = Modifier.size(16.dp)) }) {
                    Text(summary.playerTeamPosition?.let { "${it}º LUGAR" } ?: "SEM CLASSIFICAÇÃO", color = EndText, fontSize = if (compact) 17.sp else 21.sp, fontWeight = FontWeight.Black, maxLines = 1)
                    Text("NO CAMPEONATO", color = EndMuted, fontSize = if (compact) 7.sp else 8.sp, maxLines = 1)
                    Spacer(Modifier.height(2.dp))
                    EndRecordRow("Vitórias", null, summary.playerTeamWins, compact)
                    EndRecordRow("Pódios", null, summary.playerTeamPodiums, compact)
                    EndRecordRow("Poles", null, summary.playerTeamPoles, compact)
                    EndRecordRow("Pontos", null, summary.playerTeamPoints, compact)
                    summary.playerTeamPositionDelta?.let { delta ->
                        Text(if (delta > 0) "▲ +$delta posições" else if (delta < 0) "▼ $delta posições" else "— Sem mudança", color = if (delta > 0) EndGreen else if (delta < 0) EndRed else EndMuted, fontSize = if (compact) 8.sp else 9.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                    }
                }
            }

            Button(onClick = onContinue, modifier = Modifier.fillMaxWidth().height(if (compact) 38.dp else 45.dp), shape = RoundedCornerShape(10.dp), colors = ButtonDefaults.buttonColors(containerColor = EndRed, contentColor = Color.White), contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)) {
                Text("CONTINUAR PARA A PRÓXIMA TEMPORADA  ›", fontSize = if (compact) 11.sp else 13.sp, fontWeight = FontWeight.Black, maxLines = 1)
            }
        }
    }
}

@Composable
private fun EndSection(modifier: Modifier, title: String, compact: Boolean, icon: @Composable () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    Column(modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(EndPanel).border(1.dp, EndLine, RoundedCornerShape(12.dp)).padding(if (compact) 5.dp else 7.dp), verticalArrangement = Arrangement.spacedBy(if (compact) 3.dp else 4.dp)) {
        Row(Modifier.fillMaxWidth().height(if (compact) 18.dp else 22.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            icon()
            Text(title, color = EndText, fontSize = if (compact) 9.sp else 11.sp, fontWeight = FontWeight.Black, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
        }
        Column(Modifier.weight(1f).fillMaxWidth(), content = content)
    }
}

@Composable
private fun EndChampionCard(title: String, name: String, driverChampionPoints: Int, subtitle: String, compact: Boolean, modifier: Modifier, blue: Boolean = false, image: @Composable RowScope.() -> Unit) {
    Column(modifier.fillMaxHeight().clip(RoundedCornerShape(9.dp)).background(if (blue) Color(0xFF0B1B2C) else Color(0xFF241B0D)).border(1.dp, if (blue) EndBlue.copy(alpha = .65f) else EndGold.copy(alpha = .65f), RoundedCornerShape(9.dp)).padding(if (compact) 4.dp else 6.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(title, color = if (blue) EndBlue else EndGold, fontSize = if (compact) 6.sp else 8.sp, fontWeight = FontWeight.Black, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Row(Modifier.weight(1f).fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            image()
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.Center) {
                Text(name, color = EndText, fontSize = if (compact) 9.sp else 11.sp, fontWeight = FontWeight.Black, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text("$driverChampionPoints PTS", color = EndMuted, fontSize = if (compact) 8.sp else 9.sp, maxLines = 1)
            }
        }
        Text(subtitle, color = EndMuted, fontSize = if (compact) 6.sp else 7.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun EndHighlightCard(item: SeasonEndHighlight, compact: Boolean, modifier: Modifier) {
    Column(modifier.fillMaxHeight().clip(RoundedCornerShape(8.dp)).background(EndPanelAlt).border(1.dp, EndLine, RoundedCornerShape(8.dp)).padding(if (compact) 4.dp else 5.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Text(item.title, color = EndText, fontSize = if (compact) 7.sp else 8.sp, fontWeight = FontWeight.Black, maxLines = 2, overflow = TextOverflow.Ellipsis)
        Text(item.description, color = EndMuted, fontSize = if (compact) 7.sp else 8.sp, lineHeight = if (compact) 8.sp else 10.sp, maxLines = 7, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun EndSmallPanel(modifier: Modifier, title: String, compact: Boolean, icon: @Composable () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    Column(modifier.fillMaxHeight().clip(RoundedCornerShape(11.dp)).background(EndPanel).border(1.dp, EndLine, RoundedCornerShape(11.dp)).padding(if (compact) 5.dp else 6.dp), verticalArrangement = Arrangement.spacedBy(if (compact) 3.dp else 4.dp)) {
        Row(Modifier.fillMaxWidth().height(if (compact) 18.dp else 21.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(3.dp)) {
            icon()
            Text(title, color = EndText, fontSize = if (compact) 8.sp else 9.sp, fontWeight = FontWeight.Black, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(if (compact) 2.dp else 3.dp), content = content)
    }
}

@Composable
private fun EndRecordRow(label: String, name: String?, value: Int?, compact: Boolean) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(5.dp)).background(EndPanelAlt).padding(horizontal = 4.dp, vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(label, color = EndMuted, fontSize = if (compact) 6.sp else 7.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (!name.isNullOrBlank()) Text(name, color = EndText, fontSize = if (compact) 7.sp else 8.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        if (value != null) Text(value.toString(), color = EndText, fontSize = if (compact) 9.sp else 11.sp, fontWeight = FontWeight.Black, maxLines = 1)
    }
}

@Composable
private fun EndMovementRow(movement: SeasonEndMovement, team: TeamDefinition?, compact: Boolean) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(5.dp)).background(EndPanelAlt).padding(horizontal = 3.dp, vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        if (team != null) EndTeamLogo(team, Modifier.size(if (compact) 17.dp else 21.dp))
        Column(Modifier.weight(1f).padding(start = 3.dp)) {
            Text(movement.label, color = EndMuted, fontSize = if (compact) 6.sp else 7.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(movement.teamName, color = EndText, fontSize = if (compact) 7.sp else 8.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Text(if (movement.movement > 0) "+${movement.movement} ↑" else if (movement.movement < 0) "${movement.movement} ↓" else "—", color = if (movement.movement > 0) EndGreen else if (movement.movement < 0) EndRed else EndMuted, fontSize = if (compact) 8.sp else 9.sp, fontWeight = FontWeight.Black, maxLines = 1)
    }
}

@Composable
private fun EndTeamCar(team: TeamDefinition, modifier: Modifier) {
    val context = LocalContext.current
    var bitmap by remember(team.id, team.name) { mutableStateOf<Bitmap?>(null) }
    LaunchedEffect(team.id, team.name) { bitmap = withContext(Dispatchers.IO) { ExternalAssets.loadTeamCarVisual(context, team.id, team.name) } }
    if (bitmap != null) Image(bitmap!!.asImageBitmap(), contentDescription = "Carro ${team.name}", modifier = modifier, contentScale = ContentScale.Fit)
    else Box(modifier, contentAlignment = Alignment.Center) { Text(team.name, color = EndMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold) }
}

@Composable
private fun EndTeamLogo(team: TeamDefinition, modifier: Modifier) {
    val context = LocalContext.current
    var bitmap by remember(team.id, team.name) { mutableStateOf<Bitmap?>(null) }
    LaunchedEffect(team.id, team.name) { bitmap = withContext(Dispatchers.IO) { ExternalAssets.loadTeamLogo(context, team.id, team.name) } }
    if (bitmap != null) Image(bitmap!!.asImageBitmap(), contentDescription = "Escudo ${team.name}", modifier = modifier, contentScale = ContentScale.Fit)
    else Icon(Icons.Filled.Flag, null, tint = EndMuted, modifier = modifier)
}

@Composable
private fun EndDriverPortrait(driver: DriverDefinition, modifier: Modifier) {
    val context = LocalContext.current
    var bitmap by remember(driver.id, driver.name) { mutableStateOf<Bitmap?>(null) }
    LaunchedEffect(driver.id, driver.name) { bitmap = withContext(Dispatchers.IO) { ExternalAssets.loadDriverPhoto(context, driver.id, driver.name) } }
    if (bitmap != null) Image(bitmap!!.asImageBitmap(), contentDescription = "Piloto ${driver.name}", modifier = modifier, contentScale = ContentScale.Crop)
    else Box(modifier, contentAlignment = Alignment.Center) { Icon(Icons.Filled.SportsMotorsports, null, tint = EndMuted) }
}
