package com.f1teammanager

import android.content.ContentResolver
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import java.io.File
import java.util.Locale

/**
 * Assets that live outside the APK and therefore survive an uninstall/reinstall.
 * Expected location:
 *   Pictures/F1Manager/Assets/teams/
 *   Pictures/F1Manager/Assets/drivers/
 *   Pictures/F1Manager/Assets/countries/
 * Team shield names may be 01.png, team_01.png or a normalized team name.
 */
object ExternalAssets {
    private const val ROOT = "Pictures/F1Manager/Assets/"

    // Cache de sessão: cada imagem externa é lida do armazenamento uma única vez
    // durante a execução do jogo. As telas reutilizam o mesmo Bitmap em memória.
    private val memoryCache = mutableMapOf<String, Bitmap?>()
    private val cacheLock = Any()

    fun loadTeamLogo(context: Context, teamId: Int, teamName: String): Bitmap? {
        if (teamId <= 0) return null
        val candidates = listOf(
            "%02d".format(Locale.US, teamId),
            teamId.toString(),
            "team_%02d".format(Locale.US, teamId),
            "team_$teamId",
            fileStemKey(teamName)
        ).distinct()
        return loadCached(context, "team:$teamId", "teams", candidates)
    }

    /**
     * Team-specific car visual. External repository:
     * Pictures/F1Manager/Assets/Cars/
     * Preferred filename: 01.png ... 40.png, matching the permanent Team ID.
     */
    fun loadTeamCarVisual(context: Context, teamId: Int, teamName: String): Bitmap? {
        if (teamId <= 0) return null
        val candidates = listOf(
            TeamAssetRegistry.teamAssetId(teamId),
            "%02d".format(Locale.US, teamId),
            "car_%02d".format(Locale.US, teamId),
            "car_$teamId",
            "team_%02d".format(Locale.US, teamId),
            "team_$teamId",
            fileStemKey(teamName)
        ).distinct()
        return loadCached(context, "car:$teamId", "Cars", candidates)
    }

    fun loadDriverPhoto(context: Context, driverId: Int, driverName: String): Bitmap? {
        if (driverId <= 0 || driverName.isBlank()) return null

        // Driver portraits are resolved exclusively by the driver's own display name.
        // Never use numeric ID filenames or aliases from a previous roster: IDs can be
        // reused by roster substitutions and otherwise display another driver's face.
        // Normalization still accepts accents, spaces, underscores, and hyphens, e.g.
        // "Felipe_Massa.png" or "Felipe Massa.png", but the identity must remain the
        // same full name. This applies uniformly to every starter and reserve driver.
        val stem = fileStemKey(driverName)
        if (stem.isBlank()) return null
        val candidates = listOf(
            stem,
            "driver_$stem"
        ).distinct()
        return loadCached(context, "driver:$driverId:$stem", "drivers", candidates)
    }

    fun loadCountryFlag(context: Context, code: String): Bitmap? {
        val normalized = normalizeCountryKey(code)
        if (normalized.isBlank()) return null
        val aliases = COUNTRY_FLAG_ALIASES[normalized].orEmpty()
        val candidates = (listOf(normalized, "flag_$normalized", "flags_$normalized") + aliases.flatMap {
            listOf(it, "flag_$it", "flags_$it")
        }).distinct()
        // Malaysia collections commonly use MY, MYS, Malaysia, or prefixed flag filenames.
        // Include these explicit forms so the flag resolves regardless of the asset pack naming convention.
        val expandedCandidates = if (normalized in setOf("my", "mys", "malaysia", "malasia", "malaysian")) {
            (candidates + listOf("my", "mys", "malaysia", "malasia", "malaysian", "flag_my", "flag_mys", "flag_malaysia", "flags_malaysia")).distinct()
        } else candidates
        // Null results are deliberately not cached: Android may grant media permission
        // after the first composition, and a subsequent composition must retry the lookup.
        // First use the normal countries folder lookup. If the pack was copied into a
        // differently-cased/renamed subfolder under Assets, perform a bounded MediaStore
        // fallback by filename. This specifically supports ISO-3166 alpha-3 assets such
        // as mys.png without requiring the file to be renamed to my.png.
        return loadImage(context, "countries", expandedCandidates)
            ?: loadCountryFlagFromAssetPack(context, expandedCandidates)
    }

    private fun loadCountryFlagFromAssetPack(context: Context, candidates: List<String>): Bitmap? {
        if (Build.VERSION.SDK_INT < 29) {
            val root = File(android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_PICTURES), "F1Manager/Assets")
            val keys = candidates.map(::fileStemKey).toSet()
            val dirs = listOf("countries", "Countries", "flags", "Flags").map { File(root, it) }
            for (dir in dirs) {
                dir.listFiles()?.forEach { file ->
                    if (file.isFile && fileStemKey(file.nameWithoutExtension) in keys) {
                        runCatching { BitmapFactory.decodeFile(file.absolutePath) }.getOrNull()?.let { return it }
                    }
                }
            }
            return null
        }
        val keys = candidates.map(::fileStemKey).toSet()
        if (keys.isEmpty()) return null
        val resolver = context.contentResolver
        val projection = arrayOf(MediaStore.Images.Media._ID, MediaStore.Images.Media.DISPLAY_NAME, MediaStore.Images.Media.RELATIVE_PATH)
        val uri = runCatching {
            resolver.query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                projection,
                "${MediaStore.Images.Media.RELATIVE_PATH} LIKE ?",
                arrayOf("%F1Manager/Assets%"),
                null
            )?.use { cursor ->
                val idIndex = cursor.getColumnIndex(MediaStore.Images.Media._ID)
                val nameIndex = cursor.getColumnIndex(MediaStore.Images.Media.DISPLAY_NAME)
                val pathIndex = cursor.getColumnIndex(MediaStore.Images.Media.RELATIVE_PATH)
                if (idIndex < 0 || nameIndex < 0 || pathIndex < 0) return@use null
                while (cursor.moveToNext()) {
                    val path = cursor.getString(pathIndex).orEmpty().lowercase(Locale.US)
                    if (!(path.contains("/countries/") || path.contains("/flags/"))) continue
                    val name = cursor.getString(nameIndex).orEmpty()
                    if (fileStemKey(name.substringBeforeLast('.', name)) in keys) {
                        return@use Uri.withAppendedPath(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cursor.getLong(idIndex).toString())
                    }
                }
                null
            }
        }.getOrNull() ?: return null
        return runCatching { resolver.openInputStream(uri)?.use(BitmapFactory::decodeStream) }.getOrNull()
    }

    private fun normalizeCountryKey(value: String): String {
        val key = fileStemKey(value)
        return COUNTRY_NAME_TO_CODE[key] ?: key
    }

    // External flag collections commonly mix ISO-2 filenames (br.png), ISO-3 names,
    // English country names, and Portuguese display names. Resolve all of them here.
    private val COUNTRY_NAME_TO_CODE = mapOf(
        "netherlands" to "nl", "paisesbaixos" to "nl", "holanda" to "nl",
        "unitedkingdom" to "gb", "greatbritain" to "gb", "uk" to "gb", "reinounido" to "gb", "inglaterra" to "gb",
        "france" to "fr", "franca" to "fr", "australia" to "au", "spain" to "es", "espana" to "es", "espanha" to "es", "esp" to "es", "spanish" to "es",
        // ISO-3166 alpha-3 and common legacy aliases used by external flag packs.
        "sui" to "ch", "che" to "ch", "swiss" to "ch", "suisse" to "ch",
        "ind" to "in", "indian" to "in", "esp" to "es", "spanish" to "es",
        "thailand" to "th", "tailandia" to "th", "italy" to "it", "italia" to "it", "brazil" to "br", "brasil" to "br",
        "germany" to "de", "alemanha" to "de", "argentina" to "ar", "monaco" to "mc", "bulgaria" to "bg",
        "austria" to "at", "switzerland" to "ch", "suica" to "ch", "belgium" to "be", "belgica" to "be",
        "canada" to "ca", "colombia" to "co", "china" to "cn", "chn" to "cn", "chinese" to "cn", "denmark" to "dk", "dinamarca" to "dk",
        "unitedstates" to "us", "usa" to "us", "estadosunidos" to "us", "finland" to "fi", "finlandia" to "fi",
        "india" to "in", "ireland" to "ie", "irlanda" to "ie", "japan" to "jp", "japao" to "jp",
        "mexico" to "mx", "newzealand" to "nz", "novazelandia" to "nz", "poland" to "pl", "polonia" to "pl",
        "portugal" to "pt", "paraguay" to "py", "paraguai" to "py", "pry" to "py", "sweden" to "se", "suecia" to "se",
        "southkorea" to "kr", "coreiadosul" to "kr", "korea" to "kr", "republicofkorea" to "kr", "korearepublic" to "kr", "kor" to "kr",
        "estonia" to "ee", "estoniae" to "ee", "estoniarepublic" to "ee", "estoniarepublicof" to "ee", "eesti" to "ee", "est" to "ee",
        "norway" to "no", "noruega" to "no", "malaysia" to "my", "malasia" to "my", "malaysian" to "my", "mys" to "my", "southafrica" to "za", "africadosul" to "za",
        "singapore" to "sg", "singapura" to "sg", "saudiarabia" to "sa", "arabiasaudita" to "sa",
        "unitedarabemirates" to "ae", "emiradosarabesunidos" to "ae", "azerbaijan" to "az", "azerbaijao" to "az",
        "turkey" to "tr", "turquia" to "tr", "russia" to "ru", "russiafederacao" to "ru", "ukraine" to "ua", "ucrania" to "ua",
        "mexican" to "mx", "czechrepublic" to "cz", "republicatcheca" to "cz", "hungary" to "hu", "hungria" to "hu"
    )
    private val COUNTRY_FLAG_ALIASES = mapOf(
        "nl" to listOf("netherlands", "paisesbaixos", "holanda"), "gb" to listOf("uk", "unitedkingdom", "greatbritain", "reinounido", "england"),
        "fr" to listOf("france", "franca"), "au" to listOf("australia"),
        "es" to listOf("spain", "espana", "espanha", "esp", "spanish"),
        "py" to listOf("paraguay", "paraguai", "pry", "paraguayan"),
        "th" to listOf("thailand", "tailandia"), "it" to listOf("italy", "italia"), "br" to listOf("brazil", "brasil"),
        "de" to listOf("germany", "alemanha"), "ar" to listOf("argentina"), "mc" to listOf("monaco"), "bg" to listOf("bulgaria"),
        "at" to listOf("austria"), "ch" to listOf("switzerland", "suica", "sui", "che", "swiss", "suisse"), "be" to listOf("belgium", "belgica"),
        "ca" to listOf("canada"), "co" to listOf("colombia"), "cn" to listOf("china", "chn", "chinese"), "dk" to listOf("denmark", "dinamarca"),
        "us" to listOf("usa", "unitedstates", "estadosunidos"), "fi" to listOf("finland", "finlandia"), "in" to listOf("india", "ind", "indian"),
        "ie" to listOf("ireland", "irlanda"), "jp" to listOf("japan", "japao"), "mx" to listOf("mexico"),
        "nz" to listOf("newzealand", "novazelandia"), "pl" to listOf("poland", "polonia"), "pt" to listOf("portugal"),
        "se" to listOf("sweden", "suecia"),
        "kr" to listOf("southkorea", "coreiadosul", "korea", "republicofkorea", "korearepublic", "kor"),
        "ee" to listOf("estonia", "eesti", "est", "estoniae", "estoniarepublic", "estoniarepublicof"),
        "no" to listOf("norway", "noruega"),
        "my" to listOf("malaysia", "malasia", "malaysian", "mys", "flag_my", "flag_mys"), "za" to listOf("southafrica", "africadosul"), "sg" to listOf("singapore", "singapura"),
        "sa" to listOf("saudiarabia", "arabiasaudita"), "ae" to listOf("unitedarabemirates", "emiradosarabesunidos"),
        "az" to listOf("azerbaijan", "azerbaijao"), "tr" to listOf("turkey", "turquia"), "ru" to listOf("russia"),
        "ua" to listOf("ukraine", "ucrania"), "cz" to listOf("czechrepublic", "republicatcheca"), "hu" to listOf("hungary", "hungria")
    )

    fun loadGrandPrixImage(
        context: Context,
        grandPrix: String,
        circuit: String = "",
        assetSearchName: String = ""
    ): Bitmap? {
        // O nome de exibição do GP nem sempre é o nome do arquivo do pack de imagens.
        // Priorize também o circuito e assetSearchName cadastrados na temporada.
        val short = Regex("^GP\\s+(?:do|da|de|dos|das)\\s+", RegexOption.IGNORE_CASE)
            .replace(grandPrix, "")
            .let { Regex("^GP\\s*", RegexOption.IGNORE_CASE).replace(it, "") }
        val aliases = when (fileStemKey(grandPrix)) {
            "gpdaarabiasaudita" -> listOf("Saudi Arabia", "Jeddah", "Jeddah Corniche Circuit F1")
            "gpdeabudhabi" -> listOf("Abu Dhabi", "Yas Marina", "Yas Marina Circuit F1")
            "gpdoseua", "gpdosestadosunidos" -> listOf("United States", "USA", "COTA", "Circuit of the Americas F1")
            "gpdesaopaulo", "gpdobrasil" -> listOf("Brazil", "Brasil", "Interlagos", "Interlagos Circuit F1")
            "gpdagrabretanha" -> listOf("Great Britain", "United Kingdom", "Silverstone", "Silverstone Circuit F1")
            "gpdaemiliaromanha" -> listOf("Emilia Romagna", "Imola", "Imola Circuit F1")
            else -> emptyList()
        }
        val rawCandidates = (listOf(grandPrix, short, circuit, assetSearchName) + aliases)
            .filter { it.isNotBlank() }
        val candidates = (rawCandidates + rawCandidates.flatMap { value ->
            listOf(
                value.replace(Regex("\\s+F1$", RegexOption.IGNORE_CASE), ""),
                value.replace(Regex("\\s+Circuit(?:\\s+F1)?$", RegexOption.IGNORE_CASE), ""),
                value.replace(Regex("\\s+International(?:\\s+Circuit)?(?:\\s+F1)?$", RegexOption.IGNORE_CASE), ""),
                value.replace(Regex("\\s+Autodromo$", RegexOption.IGNORE_CASE), "")
            )
        }).filter { it.isNotBlank() }.distinctBy(::fileStemKey)
        val cacheKey = "gp:${fileStemKey(grandPrix)}:${fileStemKey(circuit)}:${fileStemKey(assetSearchName)}"
        synchronized(cacheLock) {
            if (memoryCache.containsKey(cacheKey)) return memoryCache[cacheKey]
            // Aceita os nomes de pasta já usados nos packs externos: races, GPs/gps,
            // circuits/circuits e tracks. Os arquivos continuam fora do APK.
            for (folder in listOf("races", "GPs", "gps", "circuits", "tracks")) {
                val bitmap = loadImage(context, folder, candidates)
                if (bitmap != null) {
                    memoryCache[cacheKey] = bitmap
                    return bitmap
                }
            }
            return null // não cachear falhas: permite tentar de novo após conceder acesso
        }
    }

    private fun loadCached(context: Context, key: String, folder: String, candidates: List<String>): Bitmap? {
        synchronized(cacheLock) {
            if (memoryCache.containsKey(key)) return memoryCache[key]
            val bitmap = loadImage(context, folder, candidates)
            if (bitmap != null) memoryCache[key] = bitmap
            return bitmap
        }
    }

    fun clearMemoryCache() {
        synchronized(cacheLock) {
            memoryCache.values.filterNotNull().forEach { it.recycle() }
            memoryCache.clear()
        }
    }

    private fun loadImage(context: Context, folder: String, candidates: List<String>): Bitmap? {
        val resolver = context.contentResolver
        // First try exact names, then compare normalized names. This makes names such as
        // "RedBullRacing.png" match the database name "Red Bull Racing".
        for (candidate in candidates) {
            findUri(resolver, folder, candidate)?.let { uri ->
                runCatching { resolver.openInputStream(uri)?.use(BitmapFactory::decodeStream) }
                    .getOrNull()?.let { return it }
            }
        }
        findNormalizedUri(resolver, folder, candidates.map(::fileStemKey).toSet())?.let { uri ->
            runCatching { resolver.openInputStream(uri)?.use(BitmapFactory::decodeStream) }
                .getOrNull()?.let { return it }
        }

        // Android <= 28 fallback for the same public folder.
        if (Build.VERSION.SDK_INT < 29) {
            val dir = File(android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_PICTURES), "F1Manager/Assets/$folder")
            val dirs = listOf(dir, File(dir.parentFile, dir.name.replaceFirstChar { it.uppercaseChar() }))
            val keys = candidates.map(::fileStemKey).toSet()
            for (d in dirs.distinct()) {
                d.listFiles()?.forEach { file ->
                    if (file.isFile && fileStemKey(file.nameWithoutExtension) in keys) {
                        runCatching { BitmapFactory.decodeFile(file.absolutePath) }.getOrNull()?.let { return it }
                    }
                }
            }
        }
        return null
    }

    private fun findUri(resolver: ContentResolver, folder: String, candidate: String): Uri? {
        if (Build.VERSION.SDK_INT < 29) return null
        val projection = arrayOf(MediaStore.Images.Media._ID, MediaStore.Images.Media.DISPLAY_NAME)
        val relativePaths = listOf(ROOT + "$folder/", ROOT + folder.replaceFirstChar { it.uppercaseChar() } + "/")
        for (path in relativePaths.distinct()) {
            val uri = runCatching {
                resolver.query(
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                    projection,
                    "${MediaStore.Images.Media.RELATIVE_PATH} = ? AND ${MediaStore.Images.Media.DISPLAY_NAME} LIKE ?",
                    arrayOf(path, "$candidate.%"),
                    null
                )?.use { cursor ->
                    if (!cursor.moveToFirst()) return@use null
                    val idIndex = cursor.getColumnIndex(MediaStore.Images.Media._ID)
                    if (idIndex < 0) return@use null
                    Uri.withAppendedPath(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cursor.getLong(idIndex).toString())
                }
            }.getOrNull()
            if (uri != null) return uri
        }
        return null
    }

    private fun findNormalizedUri(resolver: ContentResolver, folder: String, keys: Set<String>): Uri? {
        if (Build.VERSION.SDK_INT < 29 || keys.isEmpty()) return null
        val projection = arrayOf(MediaStore.Images.Media._ID, MediaStore.Images.Media.DISPLAY_NAME)
        val relativePaths = listOf(ROOT + "$folder/", ROOT + folder.replaceFirstChar { it.uppercaseChar() } + "/")
        for (path in relativePaths.distinct()) {
            val found = runCatching {
                resolver.query(
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                    projection,
                    "${MediaStore.Images.Media.RELATIVE_PATH} = ?",
                    arrayOf(path),
                    null
                )?.use { cursor ->
                    val idIndex = cursor.getColumnIndex(MediaStore.Images.Media._ID)
                    val nameIndex = cursor.getColumnIndex(MediaStore.Images.Media.DISPLAY_NAME)
                    if (idIndex < 0 || nameIndex < 0) return@use null
                    while (cursor.moveToNext()) {
                        val name = cursor.getString(nameIndex) ?: continue
                        if (fileStemKey(name.substringBeforeLast('.', name)) in keys) {
                            return@use Uri.withAppendedPath(
                                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                                cursor.getLong(idIndex).toString()
                            )
                        }
                    }
                    null
                }
            }.getOrNull()
            if (found != null) return found
        }
        return null
    }

    private fun fileStemKey(value: String): String = value
        .lowercase(Locale.US)
        .let { java.text.Normalizer.normalize(it, java.text.Normalizer.Form.NFD) }
        .replace("\\p{InCombiningDiacriticalMarks}+".toRegex(), "")
        .replace("[^a-z0-9]".toRegex(), "")

}