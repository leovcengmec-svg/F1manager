package com.f1teammanager

import android.content.ContentResolver
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import java.io.File
import java.util.Locale

/**
 * Assets that live outside the APK and therefore survive an uninstall/reinstall.
 * Expected location:
 *   Pictures/F1Manager/Assets/teams/
 *   Pictures/F1Manager/Assets/drivers/
 *   Pictures/F1Manager/Assets/countries/
 * Team shield names may be 01.png, team_01.png or a normalized team name.
 */
object ExternalAssets {
    private const val ROOT = "Pictures/F1Manager/Assets/"

    fun loadTeamLogo(context: Context, teamId: Int, teamName: String): Bitmap? {
        if (teamId <= 0) return null
        val candidates = listOf(
            "%02d".format(Locale.US, teamId),
            teamId.toString(),
            "team_%02d".format(Locale.US, teamId),
            "team_$teamId",
            slug(teamName)
        ).distinct()
        return loadImage(context, "teams", candidates)
    }

    fun loadDriverPhoto(context: Context, driverId: Int, driverName: String): Bitmap? {
        if (driverId <= 0) return null
        val candidates = listOf(
            "%03d".format(Locale.US, driverId),
            driverId.toString(),
            "driver_%03d".format(Locale.US, driverId),
            "driver_$driverId",
            slug(driverName)
        ).distinct()
        return loadImage(context, "drivers", candidates)
    }

    fun loadCountryFlag(context: Context, code: String): Bitmap? {
        val normalized = code.trim().lowercase(Locale.US)
        return loadImage(context, "countries", listOf(normalized, "flag_$normalized"))
    }

    private fun loadImage(context: Context, folder: String, candidates: List<String>): Bitmap? {
        for (candidate in candidates) {
            findUri(context.contentResolver, folder, candidate)?.let { uri ->
                runCatching { context.contentResolver.openInputStream(uri)?.use(BitmapFactory::decodeStream) }.getOrNull()?.let { return it }
            }
        }
        // Android <= 28 fallback for the same public folder.
        if (Build.VERSION.SDK_INT < 29) {
            val dir = File(android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_PICTURES), "F1Manager/Assets/$folder")
            for (candidate in candidates) {
                for (ext in listOf("png", "webp", "jpg", "jpeg")) {
                    val file = File(dir, "$candidate.$ext")
                    if (file.exists()) runCatching { BitmapFactory.decodeFile(file.absolutePath) }.getOrNull()?.let { return it }
                }
            }
        }
        return null
    }

    private fun findUri(resolver: ContentResolver, folder: String, candidate: String): Uri? {
        val projection = arrayOf(MediaStore.Images.Media._ID, MediaStore.Images.Media.DISPLAY_NAME, MediaStore.Images.Media.RELATIVE_PATH)
        val selection: String
        val args: Array<String>
        if (Build.VERSION.SDK_INT >= 29) {
            selection = "${MediaStore.Images.Media.RELATIVE_PATH} = ? AND ${MediaStore.Images.Media.DISPLAY_NAME} LIKE ?"
            args = arrayOf(ROOT + "$folder/", "$candidate.%")
        } else {
            selection = "${MediaStore.Images.Media.DISPLAY_NAME} LIKE ?"
            args = arrayOf("$candidate.%")
        }
        resolver.query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, projection, selection, args, null)?.use { cursor ->
            val id = cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID))
            return Uri.withAppendedPath(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id.toString())
        }
        return null
    }

    private fun slug(value: String): String = value.lowercase(Locale.US)
        .let { java.text.Normalizer.normalize(it, java.text.Normalizer.Form.NFD) }
        .replace("\\p{InCombiningDiacriticalMarks}+".toRegex(), "")
        .replace("[^a-z0-9]+".toRegex(), "_")
        .trim('_')
}
