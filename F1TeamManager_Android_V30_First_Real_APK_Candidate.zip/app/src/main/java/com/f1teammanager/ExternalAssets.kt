package com.f1teammanager

import android.content.ContentResolver
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import java.io.File
import java.util.Locale

/**
 * Assets that live outside the APK and therefore survive an uninstall/reinstall.
 * Expected location:
 *   Pictures/F1Manager/Assets/teams/
 *   Pictures/F1Manager/Assets/drivers/
 *   Pictures/F1Manager/Assets/countries/
 * Team shield names may be 01.png, team_01.png or a normalized team name.
 */
object ExternalAssets {
    private const val ROOT = "Pictures/F1Manager/Assets/"

    fun loadTeamLogo(context: Context, teamId: Int, teamName: String): Bitmap? {
        if (teamId <= 0) return null
        val candidates = listOf(
            "%02d".format(Locale.US, teamId),
            teamId.toString(),
            "team_%02d".format(Locale.US, teamId),
            "team_$teamId",
            fileStemKey(teamName)
        ).distinct()
        return loadImage(context, "teams", candidates)
    }

    fun loadDriverPhoto(context: Context, driverId: Int, driverName: String): Bitmap? {
        if (driverId <= 0) return null
        val candidates = listOf(
            "%03d".format(Locale.US, driverId),
            driverId.toString(),
            "driver_%03d".format(Locale.US, driverId),
            "driver_$driverId",
            fileStemKey(driverName)
        ).distinct()
        return loadImage(context, "drivers", candidates)
    }

    fun loadCountryFlag(context: Context, code: String): Bitmap? {
        val normalized = code.trim().lowercase(Locale.US)
        return loadImage(context, "countries", listOf(normalized, "flag_$normalized"))
    }

    private fun loadImage(context: Context, folder: String, candidates: List<String>): Bitmap? {
        val resolver = context.contentResolver
        // First try exact names, then compare normalized names. This makes names such as
        // "RedBullRacing.png" match the database name "Red Bull Racing".
        for (candidate in candidates) {
            findUri(resolver, folder, candidate)?.let { uri ->
                runCatching { resolver.openInputStream(uri)?.use(BitmapFactory::decodeStream) }
                    .getOrNull()?.let { return it }
            }
        }
        findNormalizedUri(resolver, folder, candidates.map(::fileStemKey).toSet())?.let { uri ->
            runCatching { resolver.openInputStream(uri)?.use(BitmapFactory::decodeStream) }
                .getOrNull()?.let { return it }
        }

        // Android <= 28 fallback for the same public folder.
        if (Build.VERSION.SDK_INT < 29) {
            val dir = File(android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_PICTURES), "F1Manager/Assets/$folder")
            val dirs = listOf(dir, File(dir.parentFile, dir.name.replaceFirstChar { it.uppercaseChar() }))
            val keys = candidates.map(::fileStemKey).toSet()
            for (d in dirs.distinct()) {
                d.listFiles()?.forEach { file ->
                    if (file.isFile && fileStemKey(file.nameWithoutExtension) in keys) {
                        runCatching { BitmapFactory.decodeFile(file.absolutePath) }.getOrNull()?.let { return it }
                    }
                }
            }
        }
        return null
    }

    private fun findUri(resolver: ContentResolver, folder: String, candidate: String): Uri? {
        if (Build.VERSION.SDK_INT < 29) return null
        val projection = arrayOf(MediaStore.Images.Media._ID, MediaStore.Images.Media.DISPLAY_NAME)
        val relativePaths = listOf(ROOT + "$folder/", ROOT + folder.replaceFirstChar { it.uppercaseChar() } + "/")
        for (path in relativePaths.distinct()) {
            val uri = runCatching {
                resolver.query(
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                    projection,
                    "${MediaStore.Images.Media.RELATIVE_PATH} = ? AND ${MediaStore.Images.Media.DISPLAY_NAME} LIKE ?",
                    arrayOf(path, "$candidate.%"),
                    null
                )?.use { cursor ->
                    if (!cursor.moveToFirst()) return@use null
                    val idIndex = cursor.getColumnIndex(MediaStore.Images.Media._ID)
                    if (idIndex < 0) return@use null
                    Uri.withAppendedPath(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cursor.getLong(idIndex).toString())
                }
            }.getOrNull()
            if (uri != null) return uri
        }
        return null
    }

    private fun findNormalizedUri(resolver: ContentResolver, folder: String, keys: Set<String>): Uri? {
        if (Build.VERSION.SDK_INT < 29 || keys.isEmpty()) return null
        val projection = arrayOf(MediaStore.Images.Media._ID, MediaStore.Images.Media.DISPLAY_NAME)
        val relativePaths = listOf(ROOT + "$folder/", ROOT + folder.replaceFirstChar { it.uppercaseChar() } + "/")
        for (path in relativePaths.distinct()) {
            val found = runCatching {
                resolver.query(
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                    projection,
                    "${MediaStore.Images.Media.RELATIVE_PATH} = ?",
                    arrayOf(path),
                    null
                )?.use { cursor ->
                    val idIndex = cursor.getColumnIndex(MediaStore.Images.Media._ID)
                    val nameIndex = cursor.getColumnIndex(MediaStore.Images.Media.DISPLAY_NAME)
                    if (idIndex < 0 || nameIndex < 0) return@use null
                    while (cursor.moveToNext()) {
                        val name = cursor.getString(nameIndex) ?: continue
                        if (fileStemKey(name.substringBeforeLast('.', name)) in keys) {
                            return@use Uri.withAppendedPath(
                                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                                cursor.getLong(idIndex).toString()
                            )
                        }
                    }
                    null
                }
            }.getOrNull()
            if (found != null) return found
        }
        return null
    }

    private fun fileStemKey(value: String): String = value
        .lowercase(Locale.US)
        .let { java.text.Normalizer.normalize(it, java.text.Normalizer.Form.NFD) }
        .replace("\\p{InCombiningDiacriticalMarks}+".toRegex(), "")
        .replace("[^a-z0-9]".toRegex(), "")

}