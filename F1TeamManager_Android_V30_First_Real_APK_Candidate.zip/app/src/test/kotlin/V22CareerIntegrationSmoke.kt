import com.f1teammanager.core.career.CareerRaceIntegration
import com.f1teammanager.core.race.*
import com.f1teammanager.core.season.WorldDatabase
import com.f1teammanager.core.season.toParticipant

fun main() {
    val circuit = RaceCircuit(1, "Teste", 32, 90000L, 1.0, 1.0, safetyCarRisk = 0.8)
    val participants = WorldDatabase.drivers.map { it.toParticipant(WorldDatabase.teams[it.teamId - 1]) }
    var completed = false
    var redSeen = false
    for (seed in 1..80) {
        val game = CareerRaceIntegration(2026, circuit, participants, playerTeamId = 1, seed = seed)
        var s = game.begin()
        game.setStrategy(1, DriverPosture.ATTACK, Tyre.MEDIUM)
        var guard = 0
        while (!s.completed && guard++ < 120) {
            s = game.advance()
            val d = s.decision
            if (d != null) {
                if (d.request.type == ManagerDecisionType.RED_FLAG) {
                    game.chooseRedFlag(Tyre.HARD, DriverPosture.DEFENSE)
                    redSeen = true
                } else {
                    game.choose(ManagerDecisionAction.STAY_OUT)
                }
                s = game.snapshot()
            }
        }
        if (s.completed) completed = true
        if (completed && redSeen) break
    }
    check(completed) { "Career weekend de 80 pilotos não terminou" }
    check(redSeen) { "Nenhuma bandeira vermelha foi exercitada no smoke" }
    val result = run {
        val game = CareerRaceIntegration(2026, circuit, participants, 1, 777)
        var x = game.begin()
        game.setStrategy(1, DriverPosture.DEFENSE, Tyre.SOFT)
        var guard = 0
        while (!x.completed && guard++ < 160) {
            x = game.advance()
            val d = x.decision
            if (d != null) {
                if (d.request.type == ManagerDecisionType.RED_FLAG) game.chooseRedFlag(Tyre.MEDIUM, DriverPosture.BALANCED)
                else game.choose(ManagerDecisionAction.SAVE_FUEL)
                x = game.snapshot()
            }
        }
        game.result()
    }
    check(result.classification.size == 80)
    println("V22_SMOKE_OK redFlag=$redSeen classification=${result.classification.size}")
}
