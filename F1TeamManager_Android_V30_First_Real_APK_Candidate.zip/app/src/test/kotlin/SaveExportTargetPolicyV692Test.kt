package com.f1teammanager

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SaveExportTargetPolicyV692Test {
    @Test
    fun explicitSelectionAlwaysExportsTheSelectedFileEvenWhenCareerIdsMatch() {
        // Two snapshots can belong to the same career ID but different teams/seasons.
        // Presence of a selected path must always disable live-career substitution.
        assertFalse(SaveExportTargetPolicy.shouldExportLiveCareer(
            "/data/user/0/com.f1teammanager/files/career_saves/TIME_PRINCIPAL_Bagos_2026_same-career.json"
        ))
    }

    @Test
    fun explicitSelectionAlsoWinsWhenSelectedSaveBelongsToAnotherCareer() {
        assertFalse(SaveExportTargetPolicy.shouldExportLiveCareer("/saves/another-career.json"))
    }

    @Test
    fun liveCareerIsUsedOnlyWhenThereIsNoExplicitSelection() {
        assertTrue(SaveExportTargetPolicy.shouldExportLiveCareer(null))
        assertTrue(SaveExportTargetPolicy.shouldExportLiveCareer(""))
        assertTrue(SaveExportTargetPolicy.shouldExportLiveCareer("   "))
    }
}
