import com.f1teammanager.core.manager.*
import com.f1teammanager.core.season.*

fun main() {
    val market = DriverMarketEngine(20261003).initialState(2026)
    val team = WorldDatabase.teams.first()
    val car = TeamCarState(com.f1teammanager.core.manager.InitialTeamProfile.strength(team), team.chassis, team.engine, team.reliability, frontWing=team.frontWing, rearWing=team.rearWing, brakes=team.brakes, electricPowerUnit=team.electricPowerUnit)
    var manager = TeamManagerState(season=2026, playerTeamId=team.id, car=car, finance=TeamFinanceState(35_000_000), driverMarket=market)
    val free = WorldDatabase.allDrivers.map { it.id }.filter { id -> market.contracts.none { it.activeIn(2026) && it.driverId == id } }.toSet()
    check(free.size == 20)
    val before = free.associateWith { id -> WorldDatabase.allDrivers.first { it.id == id }.ratingsForManager().toList() }
    var season = SeasonState()
    val engine = ManagerSeasonEngine(20261003)
    repeat(30) { val o=engine.runRound(manager, season); manager=o.state; season=o.season }
    val changed = free.count { id -> manager.driverEvolutionAttributes[id] != before[id] }
    check(changed == 20) { "Esperava evolução dos 20 livres; mudaram $changed" }
    check(manager.driverEvolutionAnnualGains.filterKeys { it in free }.values.all { it.sum() >= 0 })
    println("FreeDriverEvolutionV85Test: PASS (20/20 livres evoluíram a 70% da taxa natural)")
}
private fun DriverDefinition.ratingsForManager() = intArrayOf(speed,qualifying,overtaking,defense,consistency,wet,tyre)
