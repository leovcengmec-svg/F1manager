package com.f1teammanager

import com.f1teammanager.core.season.DriverProfileCatalog
import com.f1teammanager.core.season.WorldDatabase

/** V649: all opening Overalls and potentials must agree with the official class table. */
object Stage1Initial75PercentTest {
    @JvmStatic
    fun main(args: Array<String>) {
        check(DriverProfileCatalog.profiles.size == 100) { "Expected exactly 100 official driver profiles" }
        DriverProfileCatalog.profiles.keys.forEach { name ->
            val profile = DriverProfileCatalog.profile(name)
            val overall = DriverProfileCatalog.overall(profile.ratings)
            check(profile.ratings.size == 7) { "$name must have 7 attributes" }
            check(profile.ratings.all { it in 40..100 }) { "$name has an attribute outside 40..100" }
            check(overall in DriverProfileCatalog.minimumOverall(profile.driverClass)..DriverProfileCatalog.ceiling(profile.driverClass)) {
                "$name starts with Overall $overall outside class ${profile.driverClass}"
            }
            check(profile.potentialOverall in overall..DriverProfileCatalog.maxPotentialOverall(profile.driverClass)) {
                "$name potential ${profile.potentialOverall} outside allowed headroom"
            }
        }

        val max = DriverProfileCatalog.profile("Max Verstappen")
        check(DriverProfileCatalog.overall(max.ratings) >= 94)
        check(max.potentialOverall == 100)
        check(DriverProfileCatalog.overall(DriverProfileCatalog.profile("Ayrton Senna").ratings) >= 97)
        check(DriverProfileCatalog.overall(DriverProfileCatalog.profile("Michael Schumacher").ratings) >= 97)

        val leclerc = DriverProfileCatalog.profile("Charles Leclerc")
        val norris = DriverProfileCatalog.profile("Lando Norris")
        check(leclerc.driverClass == norris.driverClass)
        check(DriverProfileCatalog.overall(leclerc.ratings) != DriverProfileCatalog.overall(norris.ratings))

        check(WorldDatabase.allDrivers.size == 100) { "Grid+market should still contain 100 drivers" }
        WorldDatabase.allDrivers.forEach { driver ->
            val overall = DriverProfileCatalog.overall(intArrayOf(driver.speed,driver.qualifying,driver.overtaking,driver.defense,driver.consistency,driver.wet,driver.tyre))
            check(overall in DriverProfileCatalog.minimumOverall(driver.driverClass)..DriverProfileCatalog.ceiling(driver.driverClass)) {
                "${driver.name} database Overall $overall mismatches class ${driver.driverClass}"
            }
            check(driver.potentialOverall in overall..DriverProfileCatalog.maxPotentialOverall(driver.driverClass)) {
                "${driver.name} database potential mismatches class"
            }
        }
        WorldDatabase.allDrivers.forEach { driver ->
            val current = DriverProfileCatalog.overall(intArrayOf(
                driver.speed, driver.qualifying, driver.overtaking, driver.defense,
                driver.consistency, driver.wet, driver.tyre
            ))
            check(current in DriverProfileCatalog.minimumOverall(driver.driverClass)..DriverProfileCatalog.ceiling(driver.driverClass)) {
                "${driver.name} enters WorldDatabase with Overall $current outside ${driver.driverClass}"
            }
            check(driver.potentialOverall in current..DriverProfileCatalog.maxPotentialOverall(driver.driverClass)) {
                "${driver.name} enters WorldDatabase with potential ${driver.potentialOverall} outside class headroom"
            }
        }
        println("Stage1Initial75PercentTest: PASS (100 pilots, class bands and potentials)")
    }
}
