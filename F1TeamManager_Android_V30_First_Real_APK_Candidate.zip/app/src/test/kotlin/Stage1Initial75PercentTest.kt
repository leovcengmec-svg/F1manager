package com.f1teammanager

import com.f1teammanager.core.season.DriverProfileCatalog

/** Stage 1: all 100 initial driver profiles start at 75% of their class ceiling. */
object Stage1Initial75PercentTest {
    @JvmStatic
    fun main(args: Array<String>) {
        check(DriverProfileCatalog.profiles.size == 100) {
            "Expected exactly 100 official driver profiles"
        }
        DriverProfileCatalog.profiles.keys.forEach { name ->
            val profile = DriverProfileCatalog.profile(name)
            val ceiling = DriverProfileCatalog.ceiling(profile.driverClass)
            val expectedOverall = kotlin.math.round(ceiling * 0.75).toInt()
            val overall = profile.ratings.sum() / 7
            check(overall == expectedOverall) {
                "$name: Overall=$overall, expected=$expectedOverall"
            }
            check(profile.ratings.size == 7) { "$name must have 7 attributes" }
            check(profile.ratings.all { it in 40..ceiling }) {
                "$name has an attribute outside 40..$ceiling"
            }
        }
    }
}
