package com.f1teammanager.core.manager

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Test

class CompletedDesignLatestVisibilityV510Test {
    private fun design(component: CarComponent, version: Int, week: Int) = ResearchDesign(
        designId = "${component.name}-V$version", component = component, version = version,
        performance = 40 + version, reliability = 50 + version, researchSeason = 2026, completedWeek = week
    )

    @Test fun completedDesignCatalogKeepsOnlyNewestVersionPerComponentWithoutMutatingHistory() {
        val history = listOf(
            design(CarComponent.ENGINE, 2, 2),
            design(CarComponent.CHASSIS, 1, 1),
            design(CarComponent.ENGINE, 4, 4),
            design(CarComponent.ENGINE, 3, 3),
            design(CarComponent.CHASSIS, 3, 5)
        )
        val visible = FactoryEngine().latestAvailableDesigns(history)
        assertEquals(2, visible.size)
        assertEquals(4, visible.first { it.component == CarComponent.ENGINE }.version)
        assertEquals(3, visible.first { it.component == CarComponent.CHASSIS }.version)
        assertEquals(5, history.size)
        assertFalse(visible.any { it.component == CarComponent.ENGINE && it.version < 4 })
    }
    @Test fun legacyDuplicateVersionUsesLatestCompletionAsDeterministicTieBreak() {
        val older = design(CarComponent.ENGINE, 4, 2).copy(researchSeason = 2025, designId = "legacy-engine-v4")
        val newer = design(CarComponent.ENGINE, 4, 7).copy(researchSeason = 2026, designId = "engine-v4-new")
        val visible = FactoryEngine().latestAvailableDesigns(listOf(older, newer))
        assertEquals(1, visible.size)
        assertEquals("engine-v4-new", visible.single().designId)
    }

}
