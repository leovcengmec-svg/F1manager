import com.f1teammanager.core.manager.*
import com.f1teammanager.core.season.*

fun main() {
    val market = DriverMarketEngine(20261003).initialState(2026)
    val team = WorldDatabase.teams.first()
    val car = TeamCarState(com.f1teammanager.core.manager.InitialTeamProfile.strength(team), team.chassis, team.engine, team.reliability, frontWing=team.frontWing, rearWing=team.rearWing, brakes=team.brakes, electricPowerUnit=team.electricPowerUnit)
    var manager = TeamManagerState(season=2026, playerTeamId=team.id, car=car, finance=TeamFinanceState(35_000_000), driverMarket=market)
    val free = WorldDatabase.allDrivers.map { it.id }.filter { id -> market.contracts.none { it.activeIn(2026) && it.driverId == id } }.toSet()
    check(free.size == 20)
    check(DriverEvolutionEngine.FREE_DRIVER_GROWTH_RATE == 1.0)
    val before = free.associateWith { id -> WorldDatabase.allDrivers.first { it.id == id }.ratingsForManager().toList() }
    var season = SeasonState()
    val engine = ManagerSeasonEngine(20261003)
    repeat(30) { val o=engine.runRound(manager, season); manager=o.state; season=o.season }
    val changed = free.count { id -> manager.driverEvolutionAttributes[id] != before[id] }
    check(changed == 20) { "Esperava evolução dos 20 livres; mudaram $changed" }
    check(manager.driverEvolutionAnnualGains.filterKeys { it in free }.values.all { it.size == 7 && it.all { gain -> gain >= 0 } })
    check(manager.driverEvolutionPhaseGps.filterKeys { it in free }.values.all { it == 30 }) {
        "Os pilotos livres precisam receber exatamente um tick por GP"
    }
    check(free.none { (manager.driverClassPerformance[it]?.get(2026)?.raceCount ?: 0) > 0 }) {
        "Pilotos livres não podem gerar amostras de desempenho para promoção/rebaixamento"
    }
    println("FreeDriverEvolutionV650Test: PASS (20/20 livres evoluíram a 100% da taxa natural)")
}
private fun DriverDefinition.ratingsForManager() = intArrayOf(speed,qualifying,overtaking,defense,consistency,wet,tyre)
