import com.f1teammanager.core.season.DriverDefinition
import com.f1teammanager.core.season.DriverEvolutionEngine
import com.f1teammanager.core.season.DriverProfileCatalog
import kotlin.math.abs
import kotlin.random.Random
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class FreeDriverGrowthRateV657Test {
    @Test
    fun freeDriverReceivesFullNaturalGrowth() {
        assertEquals(1.0, DriverEvolutionEngine.FREE_DRIVER_GROWTH_RATE, 0.0)
        val driver = DriverDefinition(
            id = 9001, name = "Free-agent growth probe", teamId = 0,
            speed = 70, qualifying = 70, overtaking = 70, defense = 70,
            consistency = 70, wet = 70, tyre = 70,
            driverClass = "Pro", evolution = "Prodígio", potentialOverall = 96
        )
        val natural = DriverEvolutionEngine.applyPerformanceTick(
            driver = driver, performanceIndex = 105.0, currentBank = 0.0,
            annualGains = IntArray(7), random = Random(657), facilityGrowthEfficiency = 1.0
        )
        val free = DriverEvolutionEngine.applyFreeDriverTick(
            driver = driver, currentBank = 0.0, annualGains = IntArray(7), random = Random(657)
        )
        assertTrue("Free-driver growth bank is not exactly 100% of natural baseline", abs(free.bank - natural.bank) < 1e-9)
        assertEquals("Potential headroom should keep the driver in the growth phase", "GROWING", DriverEvolutionEngine.initialPhase(driver))
    }

    @Test
    fun potentialAndAnnualLimitsRemainEnforced() {
        val driver = DriverDefinition(
            id = 9002, name = "Potential-limited free agent", teamId = 0,
            speed = 96, qualifying = 96, overtaking = 96, defense = 96,
            consistency = 96, wet = 96, tyre = 96,
            driverClass = "Elite", evolution = "Prodígio", potentialOverall = 96
        )
        val result = DriverEvolutionEngine.applyFreeDriverTick(
            driver = driver, currentBank = 0.75, annualGains = IntArray(7), random = Random(658)
        )
        assertTrue("Free-agent growth cannot exceed potential", DriverProfileCatalog.overall(intArrayOf(result.driver.speed, result.driver.qualifying, result.driver.overtaking, result.driver.defense, result.driver.consistency, result.driver.wet, result.driver.tyre)) <= driver.potentialOverall)
    }
}
