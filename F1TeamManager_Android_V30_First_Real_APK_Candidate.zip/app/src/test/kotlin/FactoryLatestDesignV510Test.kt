package com.f1teammanager.core.manager

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class FactoryLatestDesignV510Test {
    private fun design(component: CarComponent, version: Int) = ResearchDesign(
        designId = "${component.name}-V$version", component = component, version = version,
        performance = 40 + version, reliability = 50 + version, researchSeason = 2026, completedWeek = version
    )

    @Test fun factoryShowsOnlyHighestVersionForEachComponent() {
        val all = listOf(
            design(CarComponent.ENGINE, 2), design(CarComponent.CHASSIS, 1),
            design(CarComponent.ENGINE, 4), design(CarComponent.ENGINE, 3),
            design(CarComponent.CHASSIS, 3)
        )
        val visible = FactoryEngine().latestAvailableDesigns(all)
        assertEquals(2, visible.size)
        assertEquals(4, visible.first { it.component == CarComponent.ENGINE }.version)
        assertEquals(3, visible.first { it.component == CarComponent.CHASSIS }.version)
        assertTrue(all.size == 5) // source/history remains unchanged
    }

    @Test fun emptyFactoryCatalogRemainsEmpty() {
        assertTrue(FactoryEngine().latestAvailableDesigns(emptyList()).isEmpty())
    }
}
