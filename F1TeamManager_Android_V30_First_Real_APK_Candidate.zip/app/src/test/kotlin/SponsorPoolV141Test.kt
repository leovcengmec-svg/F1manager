import com.f1teammanager.core.manager.SponsorCatalog
import com.f1teammanager.core.manager.SponsorCategory

fun main() {
    for (c in SponsorCategory.values()) {
        check(SponsorCatalog.pool(c, true).size == 10) { "Master inválido em ${c.name}" }
        check(SponsorCatalog.pool(c, false).size == 20) { "Secondary inválido em ${c.name}: ${SponsorCatalog.pool(c, false).size}" }
        check(SponsorCatalog.pool(c, true).none { !it.master })
        check(SponsorCatalog.pool(c, false).none { it.master })
    }
    check(SponsorCatalog.all.size == 180)
    println("PASS SponsorPoolV141Test: 6 categorias, 10 Master + 20 Secondary por categoria")
}
