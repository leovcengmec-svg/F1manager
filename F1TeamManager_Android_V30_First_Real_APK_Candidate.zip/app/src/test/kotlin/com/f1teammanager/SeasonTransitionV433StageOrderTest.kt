package com.f1teammanager

import org.junit.Assert.*
import org.junit.Test
import java.io.File

/** V433 source contract: journal checkpoints must be monotonic and crash-recovery-safe. */
class SeasonTransitionV433StageOrderTest {
    @Test fun checkpointWriterRejectsSkippedOrBackwardStages() {
        val source = File("app/src/main/java/com/f1teammanager/CareerPreferences.kt").readText()
        val body = source.substringAfter("fun markSeasonTransitionStage(stage: String): Boolean {")
            .substringBefore("fun pendingSeasonTransition(): Triple<Int, Int, String>?")
        assertTrue(body.contains("requestedIndex < currentIndex"))
        assertTrue(body.contains("requestedIndex > currentIndex + 1"))
        assertTrue(body.contains("if (requestedIndex == currentIndex) return true"))
        assertTrue(body.contains("prefs.edit().putString(\"seasonTransitionStage\", stage).commit()"))
    }

    @Test fun allStagesAreDefinedInExpectedOrder() {
        val source = File("app/src/main/java/com/f1teammanager/CareerPreferences.kt").readText()
        val stages = listOf(
            "PREPARED", "SEASON_ADVANCED", "CAREER_RESET_DONE", "MANAGER_STATE_READY",
            "CAR_SAVED", "GARAGE_SAVED", "FACILITIES_SAVED", "TECHNICAL_INVESTMENT_SAVED",
            "RESEARCH_SAVED", "FACTORY_SAVED", "DRIVER_DEVELOPMENT_SAVED", "MARKET_SAVED",
            "FINANCE_SAVED", "SPONSORS_SAVED", "STATE_PERSISTED"
        ).map { source.indexOf("\"$it\"") }
        assertTrue("missing transition stage", stages.all { it >= 0 })
        assertTrue("transition stages are not ordered", stages.zipWithNext().all { (a, b) -> a < b })
    }
}
