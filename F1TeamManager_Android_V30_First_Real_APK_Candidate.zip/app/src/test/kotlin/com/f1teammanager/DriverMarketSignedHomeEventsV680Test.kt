package com.f1teammanager

import com.f1teammanager.core.manager.DriverMarketEngine
import com.f1teammanager.core.manager.DriverMarketState
import com.f1teammanager.core.manager.DriverOffer
import com.f1teammanager.core.manager.DriverTeamRole
import com.f1teammanager.core.manager.NegotiationStatus
import com.f1teammanager.core.season.WorldDatabase
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class DriverMarketSignedHomeEventsV680Test {
    @Test fun aiCounterSignatureCreatesHomeCompatibleTransferEvent() {
        val engine = DriverMarketEngine(seed = 680)
        val initial = engine.initialState(2026)
        val incumbent = initial.contracts.first()
        val destination = WorldDatabase.teams.first { it.id != incumbent.teamId }.id
        val offer = DriverOffer(
            driverId = incumbent.driverId, fromTeamId = incumbent.teamId, toTeamId = destination,
            years = 2, salary = incumbent.salary, role = DriverTeamRole.EQUAL,
            marketValue = incumbent.marketValue, interestScore = 80, round = 2,
            expiresAfterWeek = 30, status = NegotiationStatus.COUNTER, seasonTarget = 2027,
            proposerTeamId = destination
        )
        val state = initial.copy(pending = listOf(offer))
        val result = engine.acceptCounterOffer(state, offer, season = 2026, currentWeek = 30)
        val event = result.notifications.single { it.title == "TRANSFERÊNCIA CONFIRMADA" }
        assertTrue(event.message.contains("2027"))
        assertTrue(result.scheduled.any { it.driverId == incumbent.driverId && it.toTeamId == destination })
    }

    @Test fun aiCounterRenewalUsesRenewalCardTitle() {
        val engine = DriverMarketEngine(seed = 681)
        val initial = engine.initialState(2026)
        val incumbent = initial.contracts.first()
        val offer = DriverOffer(
            driverId = incumbent.driverId, fromTeamId = incumbent.teamId, toTeamId = incumbent.teamId,
            years = 2, salary = incumbent.salary, role = DriverTeamRole.EQUAL,
            marketValue = incumbent.marketValue, interestScore = 80, round = 1,
            expiresAfterWeek = 30, status = NegotiationStatus.COUNTER, seasonTarget = 2027,
            proposerTeamId = incumbent.teamId
        )
        val result = engine.acceptCounterOffer(initial.copy(pending = listOf(offer)), offer, 2026, 30)
        assertEquals(1, result.notifications.count { it.title == "RENOVAÇÃO DE CONTRATO" })
    }
}
