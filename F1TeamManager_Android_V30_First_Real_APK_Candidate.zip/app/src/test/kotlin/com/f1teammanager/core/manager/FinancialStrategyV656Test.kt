package com.f1teammanager.core.manager

import com.f1teammanager.core.season.WorldDatabase
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** Regression coverage for V656's revenue-first, two-season financial strategy. */
class FinancialStrategyV656Test {
    private val teamId: Int get() = WorldDatabase.teams.first().id

    @Test fun sponsorshipProjectionIsDeterministicAndDoesNotMutateLivePortfolio() {
        val sponsorship = TeamSponsorshipEngine(seed = 656)
        sponsorship.setMarketingLevel(teamId, 1)
        sponsorship.forTeam(teamId, 2026)
        val before = sponsorship.exportSnapshot()

        val first = sponsorship.projectCashflowForMarketingPlan(
            teamId = teamId,
            season = 2026,
            completedGps = 4,
            currentMarketingLevel = 1,
            upgradedMarketingLevel = 4,
            activationRound = 12
        )
        val second = sponsorship.projectCashflowForMarketingPlan(
            teamId = teamId,
            season = 2026,
            completedGps = 4,
            currentMarketingLevel = 1,
            upgradedMarketingLevel = 4,
            activationRound = 12
        )

        assertEquals(first, second)
        assertTrue(first.currentSeasonIncome > 0L)
        assertTrue(first.nextSeasonIncome > 0L)
        assertEquals("Projection cannot alter the active contracts, events or idempotency ledger", before, sponsorship.exportSnapshot())
    }

    @Test fun financialOutlookSubtractsUnpaidSalaryMaintenanceAndSigningFeeDebt() {
        val ai = AITeamFinancialEngine(seed = 656)
        val finance = TeamFinanceState(
            budget = 100_000_000L,
            salaryOutstanding = mapOf("2026:1" to 2_000_000L),
            facilityMaintenanceOutstanding = mapOf("2026:1" to 1_000_000L),
            signatureFeeSchedules = listOf(
                SignatureFeeSchedule(
                    id = "legacy-signing-debt",
                    amount = 9_000_000L,
                    season = 2025,
                    startRound = 1,
                    installmentCount = 3
                )
            )
        )
        ai.adoptFormerPlayerTeam(
            teamId = teamId,
            season = 2026,
            finance = finance,
            teamFacilities = TeamFacilitiesState(FacilityType.values().associateWith { 0 })
        )

        val outlook = ai.financialOutlook(
            teamId = teamId,
            season = 2026,
            week = 1,
            market = DriverMarketState(),
            sponsorshipEngine = TeamSponsorshipEngine(seed = 656)
        )

        assertEquals(12_000_000L, outlook.outstandingDebt)
        assertTrue(outlook.protectedOperatingReserve >= 15_000_000L)
        assertTrue(outlook.availableForInvestment <= 100_000_000L - outlook.protectedOperatingReserve - 12_000_000L)
        assertTrue("The next-season closing projection must be explicit", outlook.projectedNextSeasonClosingCash < Long.MAX_VALUE)
    }

    @Test fun cashRichTeamCanPrioritizeCommercialUpgradeWhenTwoSeasonPaybackIsPositive() {
        val ai = AITeamFinancialEngine(seed = 656)
        ai.adoptFormerPlayerTeam(
            teamId = teamId,
            season = 2026,
            finance = TeamFinanceState(budget = 250_000_000L),
            teamFacilities = TeamFacilitiesState(FacilityType.values().associateWith { 0 })
        )
        val sponsorship = TeamSponsorshipEngine(seed = 656)
        val market = DriverMarketState()

        ai.advanceFacilityDevelopment(
            teamId = teamId,
            season = 2026,
            week = 8,
            market = market,
            sponsorshipEngine = sponsorship
        )

        assertEquals(FacilityType.MARKETING, ai.facilityUpgrade(teamId)?.facility)
        assertEquals(240_000_000L, ai.state(teamId, 2026).finance.budget)
    }

    @Test fun distressedTeamDoesNotReceiveArtificialMoneyToFundFacilities() {
        val ai = AITeamFinancialEngine(seed = 657)
        ai.adoptFormerPlayerTeam(
            teamId = teamId,
            season = 2026,
            finance = TeamFinanceState(budget = 8_000_000L),
            teamFacilities = TeamFacilitiesState(FacilityType.values().associateWith { 0 })
        )

        ai.advanceFacilityDevelopment(
            teamId = teamId,
            season = 2026,
            week = 8,
            market = DriverMarketState(),
            sponsorshipEngine = TeamSponsorshipEngine(seed = 657)
        )

        assertEquals(null, ai.facilityUpgrade(teamId))
        assertEquals(8_000_000L, ai.state(teamId, 2026).finance.budget)
    }
}
