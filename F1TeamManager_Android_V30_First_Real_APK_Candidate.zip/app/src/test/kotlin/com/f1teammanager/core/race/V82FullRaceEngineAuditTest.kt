package com.f1teammanager.core.race

/** V82: auditoria integrada dos 6 componentes + 7 atributos + quali + corrida + ERS + DRS. */
fun main() {
    val circuit = RaceCircuit(99, "Audit GP", 12, 75_500L, crashRisk = 0.0, reliabilityRisk = 0.0, safetyCarRisk = 0.0)
    val base = RaceParticipant(driverId=1,driverName="A",teamId=1,teamName="T",driverSpeed=70,qualifying=70,overtaking=70,defense=70,consistency=70,enginePerformance=70,tyreGrip=70,tyreWear=70,reliability=95,chassisWear=0,wetSkill=70,
        chassisPerformance=70,frontWingPerformance=70,rearWingPerformance=70,brakesPerformance=70,electricPowerUnitPerformance=70)
    val pace = PitwallPaceModel(kotlin.random.Random(1))

    // 1) Tempo: velocidade entra uma única vez; componentes físicos são a fonte do carro.
    val slow = base.copy(driverSpeed=40)
    val fast = base.copy(driverSpeed=100)
    check(pace.lapTime(fast,circuit,50.0,0,Tyre.MEDIUM,false) < pace.lapTime(slow,circuit,50.0,0,Tyre.MEDIUM,false))

    // 2) Chassi: melhora estabilidade sem duplicar a velocidade do piloto.
    val stable = base.copy(chassisPerformance=100, consistency=70)
    val unstable = base.copy(chassisPerformance=40, consistency=70)
    val stableSamples = (1..40).map { PitwallPaceModel(kotlin.random.Random(it)).consistencyPenalty(stable) }
    val unstableSamples = (1..40).map { PitwallPaceModel(kotlin.random.Random(it)).consistencyPenalty(unstable) }
    check(stableSamples.map { kotlin.math.abs(it) }.average() < unstableSamples.map { kotlin.math.abs(it) }.average())

    // 3) DRS: asas determinam a eficiência e o potencial é proporcional ao GP.
    val drsLow = pace.drsGainMs(base.copy(frontWingPerformance=40,rearWingPerformance=40),circuit)
    val drsHigh = pace.drsGainMs(base.copy(frontWingPerformance=100,rearWingPerformance=100),circuit)
    check(drsHigh > drsLow)
    check(drsHigh.toDouble() < circuit.baseLapTimeMs * 0.02)

    // 4) ERS: carga, freios e unidade elétrica precisam alterar o potencial.
    val ersWeak = pace.ersGainMs(base.copy(brakesPerformance=40,electricPowerUnitPerformance=40),circuit,100.0)
    val ersStrong = pace.ersGainMs(base.copy(brakesPerformance=100,electricPowerUnitPerformance=100),circuit,100.0)
    check(ersStrong > ersWeak)
    check(pace.ersGainMs(base,circuit,50.0) < pace.ersGainMs(base,circuit,100.0))

    // 5) DRS entra diretamente no duelo: carro com DRS tem eficiência ofensiva maior.
    val noDrs = pace.drsAttackEfficiency(base.copy(frontWingPerformance=40,rearWingPerformance=40))
    val maxDrs = pace.drsAttackEfficiency(base.copy(frontWingPerformance=100,rearWingPerformance=100))
    check(maxDrs > noDrs)

    // 6) Qualificação: usa Qualifying + Velocidade + os três componentes de tempo.
    val qLow = pace.qualifyingLapTime(base.copy(qualifying=40),circuit)
    val qHigh = pace.qualifyingLapTime(base.copy(qualifying=100),circuit)
    check(qHigh < qLow)

    // 7) Motor real de corrida: 80 pilotos, quali 80/50/20 e corrida completa.
    val participants = (1..80).map { id ->
        base.copy(driverId=id, driverName="D$id", teamId=((id-1)/2)+1, teamName="T${((id-1)/2)+1}")
    }
    val engine = CareerWeekendEngine(20261007)
    engine.start(participants,circuit,1)
    repeat(3) { engine.simulateQualifyingPhase() }
    check(engine.qualifyingComplete())
    engine.setStrategy(1, DriverStrategyMode.ATTACK)
    engine.setStrategy(2, DriverStrategyMode.BALANCED)
    var snapshot = engine.snapshotForUi()
    var guard = 0
    while (!snapshot.completed && guard++ < 30) {
        snapshot = if (snapshot.decision != null) {
            when (snapshot.decision!!.request.type) {
                ManagerDecisionType.RED_FLAG -> engine.choose(ManagerDecisionAction.RESTART_BALANCED)
                ManagerDecisionType.WEATHER_CHANGE -> engine.choose(ManagerDecisionAction.STAY_OUT)
                else -> engine.choose(ManagerDecisionAction.STAY_OUT)
            }
        } else engine.advance()
    }
    check(snapshot.completed) { "Corrida não terminou em 30 avanços" }
    val result = engine.result()
    check(result.classification.size == 80) { "Classificação final inválida: ${result.classification.size}" }
    println("V82_FULL_RACE_ENGINE_AUDIT_OK")
}
