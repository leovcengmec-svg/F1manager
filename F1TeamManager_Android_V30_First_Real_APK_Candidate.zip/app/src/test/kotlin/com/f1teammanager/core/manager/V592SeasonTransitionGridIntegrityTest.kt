package com.f1teammanager.core.manager

import com.f1teammanager.core.season.WorldDatabase
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class V592SeasonTransitionGridIntegrityTest {
    @Test fun `sufficient budgets leave every team with two unique drivers after rollover`() {
        val engine = DriverMarketEngine(20261017)
        val initial = engine.initialState(2026)
        val budgets = WorldDatabase.teams.associate { it.id to 100_000_000L }
        val next = engine.applySeasonTransition(initial, 2027, budgets)

        WorldDatabase.teams.forEach { team ->
            assertEquals("${team.name} must have two active drivers", 2, engine.roster(next, team.id, season = 2027).size)
        }
        assertEquals("A driver cannot hold two active team contracts", next.contracts.map { it.driverId }.distinct().size, next.contracts.size)
        assertTrue("No active contract may point to an unknown driver", next.contracts.all { deal -> WorldDatabase.allDrivers.any { it.id == deal.driverId } })
    }
}
