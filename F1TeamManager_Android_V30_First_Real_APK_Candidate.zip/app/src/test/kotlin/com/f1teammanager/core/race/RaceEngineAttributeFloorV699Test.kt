package com.f1teammanager.core.race

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class RaceEngineAttributeFloorV699Test {
    private fun roster(withLegacyLowValues: Boolean): List<RaceParticipant> = (1..80).map { id ->
        val legacy = withLegacyLowValues && id == 1
        RaceParticipant(
            driverId = id, driverName = "Driver $id", teamId = ((id - 1) / 2) + 1,
            teamName = "Team ${((id - 1) / 2) + 1}",
            driverSpeed = if (legacy) 0 else 70, qualifying = if (legacy) 1 else 70,
            overtaking = if (legacy) 2 else 70, defense = if (legacy) 3 else 70,
            consistency = if (legacy) 4 else 70, enginePerformance = if (legacy) 5 else 70,
            tyreGrip = if (legacy) 6 else 70, tyreWear = if (legacy) 7 else 70,
            reliability = if (legacy) 8 else 90, wetSkill = if (legacy) 9 else 70,
            chassisPerformance = if (legacy) 10 else 70, frontWingPerformance = if (legacy) 11 else 70,
            rearWingPerformance = if (legacy) 12 else 70, brakesPerformance = if (legacy) 13 else 70,
            electricPowerUnitPerformance = if (legacy) 14 else 70,
            engineReliability = if (legacy) 15 else 90, chassisReliability = if (legacy) 16 else 90,
            frontWingReliability = if (legacy) 17 else 90, rearWingReliability = if (legacy) 18 else 90,
            brakesReliability = if (legacy) 19 else 90, electricPowerUnitReliability = if (legacy) 20 else 90
        )
    }

    @Test
    fun `direct career weekend start normalizes imported pilot and car attributes`() {
        val circuit = RaceCircuit(1, "Floor Test", 5, 90_000L)
        val legacyEngine = CareerWeekendEngine(seed = 699)
        val normalizedEngine = CareerWeekendEngine(seed = 699)
        val legacy = roster(withLegacyLowValues = true)
        val normalized = legacy.map { it.normalized() }

        legacyEngine.start(legacy, circuit, playerTeamId = 1, weekendSeed = 699)
        normalizedEngine.start(normalized, circuit, playerTeamId = 1, weekendSeed = 699)

        val legacyQ1 = legacyEngine.simulateQualifyingPhase()
        val normalizedQ1 = normalizedEngine.simulateQualifyingPhase()
        assertEquals(normalizedQ1.grid, legacyQ1.grid)
        assertEquals(normalizedQ1.qualifyingLapsByDriver, legacyQ1.qualifyingLapsByDriver)
        assertEquals(normalizedQ1.qualifyingDiscardedLapsByDriver, legacyQ1.qualifyingDiscardedLapsByDriver)
        assertTrue(legacy.all { participant ->
            val p = participant.normalized()
            listOf(p.driverSpeed, p.qualifying, p.overtaking, p.defense, p.consistency, p.wetSkill,
                p.enginePerformance, p.chassisPerformance, p.frontWingPerformance, p.rearWingPerformance,
                p.brakesPerformance, p.electricPowerUnitPerformance, p.reliability, p.engineReliability,
                p.chassisReliability, p.frontWingReliability, p.rearWingReliability, p.brakesReliability,
                p.electricPowerUnitReliability).all { it >= 40 }
        })
    }
    @Test
    fun `instant simulation service also accepts and normalizes a legacy low attribute roster`() {
        val circuit = RaceCircuit(2, "Instant Floor Test", 8, 90_000L, crashRisk = 0.0, reliabilityRisk = 0.0, safetyCarRisk = 0.0)
        val completed = InstantSimulationService.simulateWeekendInstantly(
            engine = CareerWeekendEngine(seed = 6992),
            participants = roster(withLegacyLowValues = true),
            circuit = circuit, playerTeamId = 1, weekendSeed = 6992
        )
        assertEquals(80, completed.qualifying.grid?.grid?.size)
        assertEquals(80, completed.result.classification.size)
        assertEquals(8, completed.result.classification.maxOf { it.laps })
    }

}
