package com.f1teammanager.core.manager

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class FacilityBenefitsIntegrationV539Test {
    @Test fun researchWindTunnelAndSimulatorAffectRealResearchOptions() {
        val base = TeamFacilitiesState()
        val improved = base.withLevel(FacilityType.RESEARCH, 5)
            .withLevel(FacilityType.WIND_TUNNEL, 5)
            .withLevel(FacilityType.SIMULATOR, 5)
        val engine = ResearchEngine()
        val aeroBase = engine.calculatedWeeks(base, CarComponent.FRONT_WING, ResearchComplexity.EXPERIMENTAL)
        val aeroImproved = engine.calculatedWeeks(improved, CarComponent.FRONT_WING, ResearchComplexity.EXPERIMENTAL)
        val engineBase = engine.calculatedWeeks(base, CarComponent.ENGINE, ResearchComplexity.EXPERIMENTAL)
        val engineImproved = engine.calculatedWeeks(improved, CarComponent.ENGINE, ResearchComplexity.EXPERIMENTAL)
        assertTrue(aeroImproved < aeroBase)
        assertTrue(engineImproved < engineBase)
        assertTrue(engine.facilityAdjustedCost(10_000_000L, improved, 40) < engine.facilityAdjustedCost(10_000_000L, base, 40))
        assertEquals(engine.calculatedWeeks(improved, CarComponent.FRONT_WING, ResearchComplexity.EXPERIMENTAL), engine.options(improved, CarComponent.FRONT_WING, 40).first { it.complexity == ResearchComplexity.EXPERIMENTAL }.weeks)
    }

    @Test fun everyFacilityHasBoundedAndMonotonicCoreBenefit() {
        for (level in 0..10) {
            val facilities = TeamFacilitiesState().let { s -> FacilityType.values().fold(s) { acc, type -> acc.withLevel(type, level) } }
            assertTrue(FacilityEngine.factoryCapacity(facilities) >= 1)
            assertTrue(FacilityEngine.factoryCapacity(facilities) <= 4)
            assertTrue(FacilityEngine.scoutingPrecision(facilities) in 20..100)
            assertTrue(FacilityEngine.driverDevelopmentEfficiency(facilities) >= 0.80)
            assertTrue(FacilityEngine.marketingQuality(facilities) in 0..80)
            assertTrue(FacilityEngine.weeklyMaintenanceTotal(facilities) >= 0L)
            assertTrue(FacilityEngine.simulatorPerformanceMultiplier(facilities) >= 1.0)
            assertTrue(FacilityEngine.windTunnelPerformanceMultiplier(facilities) >= 1.0)
        }
    }
}
