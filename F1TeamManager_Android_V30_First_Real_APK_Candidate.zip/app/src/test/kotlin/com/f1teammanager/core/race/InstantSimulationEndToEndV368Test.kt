package com.f1teammanager.core.race

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** V368: production instant-simulation boundary exercised with the real race engine. */
class InstantSimulationEndToEndV368Test {
    private val circuit = RaceCircuit(
        id = 368, name = "V368 Integration GP", laps = 8, baseLapTimeMs = 75_500L,
        crashRisk = 0.0, reliabilityRisk = 0.0, safetyCarRisk = 0.0
    )

    private fun participants(): List<RaceParticipant> = (1..80).map { id ->
        val teamId = ((id - 1) / 2) + 1
        RaceParticipant(
            driverId = id, driverName = "Driver $id", teamId = teamId, teamName = "Team $teamId",
            driverSpeed = 70, qualifying = 70, overtaking = 70, defense = 70, consistency = 70,
            enginePerformance = 70, tyreGrip = 70, tyreWear = 50, reliability = 100, wetSkill = 70,
            chassisPerformance = 70, frontWingPerformance = 70, rearWingPerformance = 70,
            brakesPerformance = 70, electricPowerUnitPerformance = 70, engineReliability = 100,
            chassisReliability = 100, frontWingReliability = 100, rearWingReliability = 100,
            brakesReliability = 100, electricPowerUnitReliability = 100
        )
    }

    @Test
    fun productionServiceCompletesQualifyingAndRaceForAllEightyDrivers() {
        val engine = CareerWeekendEngine(seed = 368)
        engine.start(participants(), circuit, playerTeamId = 1)
        val completed = InstantSimulationService.completeStartedWeekend(engine, circuit)

        assertEquals(80, completed.qualifying.grid?.grid?.size)
        assertEquals(listOf(80, 50, 20), completed.qualifying.grid?.phases?.map { it.entries.size })
        assertTrue(completed.race.completed)
        assertEquals(80, completed.result.classification.size)
        assertEquals((1..80).toList(), completed.result.classification.map { it.position }.sorted())
        assertEquals(8, completed.result.classification.maxOf { it.laps })
    }

    @Test
    fun mismatchedCircuitIsRejectedBeforeTheEngineAdvances() {
        val engine = CareerWeekendEngine(seed = 369)
        engine.start(participants(), circuit, playerTeamId = 1)
        val before = engine.snapshotForUi()
        val error = runCatching {
            InstantSimulationService.completeStartedWeekend(engine, circuit.copy(id = circuit.id + 1))
        }.exceptionOrNull()

        assertTrue("A different circuit must be rejected", error is IllegalArgumentException)
        val after = engine.snapshotForUi()
        assertEquals(before.phase, after.phase)
        assertEquals(before.lap, after.lap)
        assertEquals(before.grid, after.grid)
    }
    @Test
    fun malformedRosterIsRejectedBeforeEngineStateChanges() {
        val engine = CareerWeekendEngine(seed = 375)
        val badRoster = participants().mapIndexed { index, participant ->
            if (index == 1) participant.copy(teamId = 40, teamName = "Team 40") else participant
        }
        val error = runCatching {
            InstantSimulationService.simulateWeekendInstantly(engine, badRoster, circuit, playerTeamId = 1)
        }.exceptionOrNull()
        assertTrue("A roster with three drivers for one team must be rejected", error is IllegalArgumentException)
        assertTrue("The engine must remain uninitialized", engine.configuredCircuit() == null)
    }

    @Test
    fun invalidCircuitRiskIsRejectedBeforeEngineStateChanges() {
        val engine = CareerWeekendEngine(seed = 376)
        val invalidCircuit = circuit.copy(safetyCarRisk = Double.NaN)
        val error = runCatching {
            InstantSimulationService.simulateWeekendInstantly(engine, participants(), invalidCircuit, playerTeamId = 1)
        }.exceptionOrNull()
        assertTrue("Non-finite risk must be rejected", error is IllegalArgumentException)
        assertTrue("The engine must remain uninitialized", engine.configuredCircuit() == null)
    }

}
