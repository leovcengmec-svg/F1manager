package com.f1teammanager.core.manager

import com.f1teammanager.core.season.WorldDatabase
import org.junit.Assert.assertTrue
import org.junit.Test

class V591DriverMarketNegotiationRegressionTest {
    @Test fun `AI renewal enters normal delayed negotiation and remains open to rivals until signed`() {
        val engine = DriverMarketEngine(20261017)
        var state = engine.initialState(2026)
        var observedPendingRenewal = false
        for (week in 9..56) {
            state = engine.processAiMarketWeek(state, 2026, week, playerTeamId = -999)
            val renewal = state.pending.firstOrNull { offer ->
                offer.fromTeamId == offer.toTeamId &&
                    offer.seasonTarget == 2027 && offer.status == NegotiationStatus.PENDING &&
                    offer.expiresAfterWeek in (week + 2)..(week + 3)
            }
            if (renewal != null) {
                observedPendingRenewal = true
                assertTrue("Renewal must not sign before its response deadline", state.scheduled.none { it.driverId == renewal.driverId })
                assertTrue("A rival must still be able to compete during renewal window", engine.canReceiveProposals(state, renewal.driverId, 2026))
            }
        }
        assertTrue("AI should create at least one renewal offer through the normal negotiation flow", observedPendingRenewal)
    }

    @Test fun `scheduled movements are distinguishable as renewals or transfers`() {
        val signed = listOf(
            FutureDriverDeal(1, 3, 3, 2027, 2, 1_000_000, DriverTeamRole.EQUAL, 2026, 1),
            FutureDriverDeal(2, 4, 5, 2027, 2, 1_000_000, DriverTeamRole.EQUAL, 2026, 6)
        )
        val renewals = signed.count { it.signedSeason == 2026 && it.startSeason == 2027 && it.fromTeamId == it.toTeamId }
        val transfers = signed.count { it.signedSeason == 2026 && it.startSeason == 2027 && it.fromTeamId != it.toTeamId }
        assertTrue("A signed renewal must count as a renewal", renewals == 1)
        assertTrue("A signed contract with a different destination must count as a transfer", transfers == 1)
    }
}
