package com.f1teammanager.core.season

fun main() {
    check(DriverProfileCatalog.maxAnnualGain("Prodígio") == 15)
    check(DriverProfileCatalog.maxAnnualGain("Auge rápido") == 13)
    check(DriverProfileCatalog.maxAnnualGain("Auge moderado") == 11)
    check(DriverProfileCatalog.maxAnnualGain("Auge tardio") == 10)
    check(DriverProfileCatalog.maxAnnualGain("Normal") == 8)
    check(DriverProfileCatalog.maxAnnualGain("Demorado") == 6)

    val expected = mapOf(
        "Excepcional" to 1.00,
        "Excelente" to .90,
        "Muito bom" to .80,
        "Bom" to .70,
        "Normal" to .60,
        "Abaixo do esperado" to .45,
        "Ruim" to .30,
        "Muito ruim" to .15
    )
    for ((tier, value) in expected) {
        val probe = when (tier) {
            "Excepcional" -> 115.0
            "Excelente" -> 105.0
            "Muito bom" -> 98.0
            "Bom" -> 92.0
            "Normal" -> 85.0
            "Abaixo do esperado" -> 75.0
            "Ruim" -> 60.0
            else -> 0.0
        }
        check(DriverEvolutionEngine.performanceTier(probe) == tier)
        check(DriverEvolutionEngine.performanceUtilization(probe) == value)
    }
    check(DriverEvolutionEngine.performanceUtilization(70.0) > 0.0)
    check(DriverEvolutionEngine.performanceUtilization(70.0) < 1.0)
    println("EvolutionPerformanceCapTest: PASS")
}
