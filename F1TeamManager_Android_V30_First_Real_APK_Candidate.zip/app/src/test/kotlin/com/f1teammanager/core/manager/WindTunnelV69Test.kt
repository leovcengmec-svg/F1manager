package com.f1teammanager.core.manager

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

class WindTunnelV69Test {
    @Test fun tunnelLevel10AddsExactlyTwoPercent() {
        val state = TeamFacilitiesState().withLevel(FacilityType.WIND_TUNNEL, 10)
        assertEquals(1.02, FacilityEngine.windTunnelPerformanceMultiplier(state), 0.000001)
    }

    @Test fun tunnelOnlyAffectsAeroResearch() {
        val state = TeamFacilitiesState().withLevel(FacilityType.WIND_TUNNEL, 10)
        val aero = FacilityEngine.researchWeeks(8, state, CarComponent.FRONT_WING)
        val brakes = FacilityEngine.researchWeeks(8, state, CarComponent.BRAKES)
        assertTrue(aero < brakes)
    }

    @Test fun tunnelDoesNotChangePhysicalPieceValue() {
        val state = TeamFacilitiesState().withLevel(FacilityType.WIND_TUNNEL, 10)
        val piece = CarPiece("P1", CarComponent.FRONT_WING, 2, 80, 75)
        assertEquals(80, piece.performance)
        assertEquals(1.02, FacilityEngine.windTunnelPerformanceMultiplier(state), 0.000001)
    }
}
