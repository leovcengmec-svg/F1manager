package com.f1teammanager.core.manager

import org.junit.Assert.assertEquals
import org.junit.Test

class ResearchCompletionWeekPolicyV699Test {
    @Test fun `multi-week jump reports the exact project completion week`() {
        assertEquals(6, ResearchCompletionWeekPolicy.completionWeek(currentWeek = 4, targetWeek = 12, remainingWeeks = 2))
        assertEquals(5, ResearchCompletionWeekPolicy.completionWeek(currentWeek = 4, targetWeek = 12, remainingWeeks = 1))
        assertEquals(10, ResearchCompletionWeekPolicy.completionWeek(currentWeek = 4, targetWeek = 10, remainingWeeks = 20))
    }

    @Test fun `week calculation does not leave the season calendar`() {
        assertEquals(56, ResearchCompletionWeekPolicy.completionWeek(currentWeek = 55, targetWeek = 56, remainingWeeks = 5))
        assertEquals(56, ResearchCompletionWeekPolicy.completionWeek(currentWeek = 56, targetWeek = 56, remainingWeeks = 1))
    }
}
