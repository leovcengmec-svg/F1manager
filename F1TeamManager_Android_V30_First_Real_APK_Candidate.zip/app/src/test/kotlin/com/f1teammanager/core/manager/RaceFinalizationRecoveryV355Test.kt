package com.f1teammanager.core.manager

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** Regression coverage for replaying financial effects after a process restart. */
class RaceFinalizationRecoveryV355Test {
    @Test fun aiRaceSettlementSurvivesSnapshotRestoreAndReplay() {
        val team = WorldDatabase.teams.first { it.id != WorldDatabase.teams.first().id }
        val sponsorship = TeamSponsorshipEngine(seed = 355).forTeam(team.id, 2027)
        val market = DriverMarketState()
        val firstEngine = AITeamFinancialEngine(seed = 355)
        val first = firstEngine.applyRace(team.id, 2027, 3, sponsorship, market, bestFinish = 4, points = 18)
        val exported = firstEngine.exportSnapshot()

        val restoredEngine = AITeamFinancialEngine(seed = 355)
        restoredEngine.restoreSnapshot(exported)
        val replayed = restoredEngine.applyRace(team.id, 2027, 3, sponsorship, market, bestFinish = 4, points = 18)

        assertEquals(first.finance.budget, replayed.finance.budget)
        assertEquals(first.finance.seasonIncome, replayed.finance.seasonIncome)
        assertEquals(first.finance.seasonExpenses, replayed.finance.seasonExpenses)
        assertEquals(first.finance.raceSettlementKeys, replayed.finance.raceSettlementKeys)
        assertTrue("GP_SETTLEMENT:2027:3" in replayed.finance.raceSettlementKeys)
    }

    @Test fun constructorPrizeDoesNotRepeatAfterSnapshotRestore() {
        val team = WorldDatabase.teams.first()
        val firstEngine = AITeamFinancialEngine(seed = 355)
        val first = firstEngine.applySeasonConstructorsPrize(team.id, 2027, 2)

        val restoredEngine = AITeamFinancialEngine(seed = 355)
        restoredEngine.restoreSnapshot(firstEngine.exportSnapshot())
        val replayed = restoredEngine.applySeasonConstructorsPrize(team.id, 2027, 2)

        assertEquals(first.finance.budget, replayed.finance.budget)
        assertEquals(first.finance.transactions, replayed.finance.transactions)
        assertTrue(2027 in replayed.finance.seasonPrizesPaid)
    }
}
