package com.f1teammanager.core.race

fun main() {
    val base = 90_000L
    check(TyreModel.strategyMultiplier(DriverStrategyMode.ATTACK) == 0.990)
    check(TyreModel.strategyMultiplier(DriverStrategyMode.BALANCED) == 1.0)
    check(TyreModel.strategyMultiplier(DriverStrategyMode.DEFENSE) == 1.010)

    check(TyreModel.performanceMultiplier(Tyre.SOFT, Weather.DRY) == 0.980)
    check(TyreModel.performanceMultiplier(Tyre.MEDIUM, Weather.DRY) == 0.990)
    check(TyreModel.performanceMultiplier(Tyre.HARD, Weather.DRY) == 1.000)
    check(TyreModel.performanceMultiplier(Tyre.INTERMEDIATE, Weather.LIGHT_RAIN) == 1.000)
    check(TyreModel.performanceMultiplier(Tyre.INTERMEDIATE, Weather.MEDIUM_RAIN) == 1.000)
    check(TyreModel.performanceMultiplier(Tyre.WET, Weather.HEAVY_RAIN) == 1.000)
    check(TyreModel.performanceMultiplier(Tyre.SOFT, Weather.HEAVY_RAIN) == 1.300)
    check(TyreModel.performanceMultiplier(Tyre.INTERMEDIATE, Weather.DRY) == 1.080)
    check(TyreModel.performanceMultiplier(Tyre.WET, Weather.DRY) == 1.120)

    check(TyreModel.fuelMultiplier(100.0) == 1.015)
    check(TyreModel.fuelMultiplier(75.0) == 1.011)
    check(TyreModel.fuelMultiplier(50.0) == 1.007)
    check(TyreModel.fuelMultiplier(25.0) == 1.003)
    check(TyreModel.fuelMultiplier(10.0) == 1.001)
    check(TyreModel.fuelMultiplier(0.0) == 1.0)
    check(TyreModel.fuelMultiplier(60.0) in 1.007..1.011)

    val attack = TyreModel.applyLapModifiers(base, base, Tyre.MEDIUM, Weather.DRY, 0, DriverStrategyMode.ATTACK)
    val balanced = TyreModel.applyLapModifiers(base, base, Tyre.MEDIUM, Weather.DRY, 0, DriverStrategyMode.BALANCED)
    val defense = TyreModel.applyLapModifiers(base, base, Tyre.MEDIUM, Weather.DRY, 0, DriverStrategyMode.DEFENSE)
    check(attack < balanced)
    check(balanced < defense)

    check(TyreModel.buildDryPlans(78).size == 4)
    val plans = TyreModel.buildDryPlans(78).values
    check(plans.all { it.stintLaps.sum() >= 78 })
    check(plans.any { Tyre.SOFT in it.sequence })
    check(plans.any { Tyre.MEDIUM in it.sequence })
    check(plans.any { Tyre.HARD in it.sequence })
    println("V89_LAP_MODIFIER_RULES_OK")
}
