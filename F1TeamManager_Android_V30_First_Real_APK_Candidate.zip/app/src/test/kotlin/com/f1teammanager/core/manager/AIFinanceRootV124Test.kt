package com.f1teammanager.core.manager

import com.f1teammanager.core.season.WorldDatabase
import org.junit.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

class AIFinanceRootV124Test {
    @Test
    fun `AI development cannot spend more than real cash`() {
        val team = WorldDatabase.teams.first()
        val finance = AITeamFinancialEngine(20261008)
        finance.ensureAllTeams(2026, -999, DriverMarketState())

        val initialCash = finance.state(team.id, 2026).finance.budget
        val capacity = finance.developmentCapacity(team.id, 2026)
        assertEquals(initialCash, capacity)

        val simulated = AITeamDevelopmentEngine(20261005).simulateFinancial(team, 56, 2026, capacity)
        val spent = capacity - simulated.budget
        assertTrue(spent >= 0L)
        assertTrue(spent <= initialCash, "IA não pode gastar €$spent com apenas €$initialCash em caixa")

        finance.applyDevelopmentCost(team.id, 2026, simulated.budget, capacity)
        val after = finance.state(team.id, 2026).finance.budget
        assertTrue(after >= 0L, "Saldo da IA não pode ficar negativo por P&D")
        assertEquals(initialCash - spent, after)
    }

    @Test
    fun `AI cumulative development does not reset its wallet between weekly ticks`() {
        val team = WorldDatabase.teams.first()
        val finance = AITeamFinancialEngine(20261008)
        finance.ensureAllTeams(2026, -999, DriverMarketState())
        val dev = AITeamDevelopmentEngine(20261005)

        var capacity = finance.developmentCapacity(team.id, 2026)
        var previousCash = finance.state(team.id, 2026).finance.budget
        for (week in 1..12) {
            capacity = finance.developmentCapacity(team.id, 2026)
            val result = dev.simulateFinancial(team, week, 2026, capacity)
            finance.applyDevelopmentCost(team.id, 2026, result.budget, capacity)
            val cash = finance.state(team.id, 2026).finance.budget
            assertTrue(cash >= 0L)
            assertTrue(cash <= previousCash)
            previousCash = cash
        }
    }
}
