package com.f1teammanager.core.manager

import com.f1teammanager.core.season.WorldDatabase

class InitialTeamBudgetV131Test {
    fun allLevelsUseCanonicalBudget() {
        val strong = WorldDatabase.teams.first { it.initialLevel == InitialTeamProfile.FORTE }
        val medium = WorldDatabase.teams.first { it.initialLevel == InitialTeamProfile.MEDIO }
        val weak = WorldDatabase.teams.first { it.initialLevel == InitialTeamProfile.FRACO }
        check(InitialTeamProfile.initialBudget(strong) == 100_000_000L)
        check(InitialTeamProfile.initialBudget(medium) == 83_750_000L)
        check(InitialTeamProfile.initialBudget(weak) == 67_500_000L)
    }
}
