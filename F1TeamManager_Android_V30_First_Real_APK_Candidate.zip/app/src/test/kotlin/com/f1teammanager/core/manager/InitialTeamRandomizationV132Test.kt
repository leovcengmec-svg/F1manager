package com.f1teammanager.core.manager

import com.f1teammanager.core.season.WorldDatabase

fun main() {
    val strong = WorldDatabase.teams.count { it.initialLevel == InitialTeamProfile.FORTE }
    val medium = WorldDatabase.teams.count { it.initialLevel == InitialTeamProfile.MEDIO }
    val weak = WorldDatabase.teams.count { it.initialLevel == InitialTeamProfile.FRACO }
    check(strong == 11) { "Forte count=$strong" }
    check(medium == 14) { "Medio count=$medium" }
    check(weak == 15) { "Fraco count=$weak" }
    InitialTeamProfile.configureCareerSeed(1111)
    val a = WorldDatabase.teams.associate { it.id to InitialTeamProfile.values(it) }
    InitialTeamProfile.configureCareerSeed(2222)
    val b = WorldDatabase.teams.associate { it.id to InitialTeamProfile.values(it) }
    check(a != b) { "Opening cars did not change with career seed" }
    for (t in WorldDatabase.teams) {
        val c = a.getValue(t.id)
        val (lo, hi) = when(t.initialLevel){2->56 to 60;1->48 to 55;else->40 to 47}
        check(c.overall in lo..hi) { "${t.name}: overall=${c.overall}, level=${t.initialLevel}" }
        check(listOf(c.engine,c.chassis,c.frontWing,c.rearWing,c.brakes,c.electricPowerUnit).all { it in lo..hi })
    }
    println("V132 initial-team randomization audit OK")
}
