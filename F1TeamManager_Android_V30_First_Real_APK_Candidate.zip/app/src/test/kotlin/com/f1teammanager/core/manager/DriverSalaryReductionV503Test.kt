package com.f1teammanager.core.manager

import org.junit.Assert.assertTrue
import org.junit.Test

class DriverSalaryReductionV503Test {
    @Test fun generatedDriverSalariesUseReducedScale() {
        val engine = DriverMarketEngine(503)
        val salaries = (1..100).map { engine.salaryFor(it) }
        assertTrue("salary list must not be empty", salaries.isNotEmpty())
        assertTrue("40% reduction must keep generated salaries at or below 42M", salaries.all { it <= 42_000_000L })
        assertTrue("reduced minimum salary must be 300k", salaries.all { it >= 300_000L })
    }
}
