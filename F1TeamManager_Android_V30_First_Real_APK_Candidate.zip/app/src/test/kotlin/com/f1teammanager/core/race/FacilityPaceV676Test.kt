package com.f1teammanager.core.race

import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.random.Random

class FacilityPaceV676Test {
    private fun participant(bonus: Double) = RaceParticipant(
        driverId = 1,
        driverName = "Driver",
        teamId = 1,
        teamName = "Team",
        driverSpeed = 70,
        qualifying = 70,
        overtaking = 70,
        defense = 70,
        consistency = 70,
        enginePerformance = 70,
        chassisPerformance = 70,
        frontWingPerformance = 70,
        rearWingPerformance = 70,
        brakesPerformance = 70,
        electricPowerUnitPerformance = 70,
        facilityPaceBonus = bonus
    )

    @Test fun facilityBonusImprovesRaceLapTimeWithoutChangingPhysicalRatings() {
        val circuit = RaceCircuit(1, "Test", 60, 90_000L)
        val baseline = PitwallPaceModel(Random(77)).lapTime(
            participant(0.0), circuit, 0.0, 1, Tyre.MEDIUM, false
        )
        val improved = PitwallPaceModel(Random(77)).lapTime(
            participant(0.015), circuit, 0.0, 1, Tyre.MEDIUM, false
        )
        assertTrue("Facility level bonus must reduce race lap time", improved < baseline)
        assertTrue("The bonus remains fractional rather than inflating car attributes", participant(0.015).enginePerformance == 70)
    }

    @Test fun facilityBonusImprovesQualifyingLapTime() {
        val circuit = RaceCircuit(1, "Test", 60, 90_000L)
        val baseline = PitwallPaceModel(Random(78)).qualifyingLapTime(participant(0.0), circuit)
        val improved = PitwallPaceModel(Random(78)).qualifyingLapTime(participant(0.015), circuit)
        assertTrue("Facility level bonus must reduce qualifying lap time", improved < baseline)
    }
}
