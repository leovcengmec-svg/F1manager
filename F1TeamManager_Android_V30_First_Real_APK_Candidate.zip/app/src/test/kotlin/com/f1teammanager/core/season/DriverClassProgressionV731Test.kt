package com.f1teammanager.core.season

import org.junit.Assert.*
import org.junit.Test

class DriverClassProgressionV731Test {
    @Test fun activeContractResetsTheConsecutiveAbsenceClock() {
        assertEquals(1, DriverClassProgressionEngine.nextUncontractedSeasonCount(0, false))
        assertEquals(3, DriverClassProgressionEngine.nextUncontractedSeasonCount(2, false))
        assertEquals(0, DriverClassProgressionEngine.nextUncontractedSeasonCount(4, true))
        assertEquals(1, DriverClassProgressionEngine.nextUncontractedSeasonCount(0, false))
    }

    @Test fun absenceThresholdsAreClassSpecificAndOneStepOnly() {
        assertEquals(2, DriverClassProgressionEngine.uncontractedSeasonsToDemote("Forte"))
        assertEquals(3, DriverClassProgressionEngine.uncontractedSeasonsToDemote("Pro"))
        assertEquals(5, DriverClassProgressionEngine.uncontractedSeasonsToDemote("Lenda"))
        assertNull(DriverClassProgressionEngine.uncontractedSeasonsToDemote("Médio"))

        assertNull(DriverClassProgressionEngine.evaluateUncontractedAbsence("Forte", 1))
        val forte = DriverClassProgressionEngine.evaluateUncontractedAbsence("Forte", 2)!!
        assertEquals("Médio", forte.resultingClass)
        assertEquals(DriverClassProgressionEngine.Direction.DEMOTION, forte.direction)

        assertNull(DriverClassProgressionEngine.evaluateUncontractedAbsence("Pro", 2))
        assertEquals("Forte", DriverClassProgressionEngine.evaluateUncontractedAbsence("Pro", 3)!!.resultingClass)
        assertNull(DriverClassProgressionEngine.evaluateUncontractedAbsence("Lenda", 4))
        assertEquals("Pro", DriverClassProgressionEngine.evaluateUncontractedAbsence("Lenda", 5)!!.resultingClass)
        assertNull(DriverClassProgressionEngine.evaluateUncontractedAbsence("Médio", 50))
    }

    @Test fun poorPerformanceCanDemoteLendaProAndForteOnBiennialReview() {
        val poorOne = DriverClassProgressionEngine.SeasonPerformance(2026, 70.0, 30)
        val poorTwo = DriverClassProgressionEngine.SeasonPerformance(2027, 75.0, 30)
        assertEquals("Médio", DriverClassProgressionEngine.evaluate("Forte", 68, poorOne, poorTwo, 30).resultingClass)
        assertEquals("Forte", DriverClassProgressionEngine.evaluate("Pro", 78, poorOne, poorTwo, 30).resultingClass)
        val lenda = DriverClassProgressionEngine.evaluate("Lenda", 88, poorOne, poorTwo, 30, isChampion = true)
        assertEquals("Pro", lenda.resultingClass)
        assertEquals(DriverClassProgressionEngine.Direction.DEMOTION, lenda.direction)
    }

    @Test fun promotionStillNeedsTwoSeasonOutperformanceAndProNeedsCareerTitleForLenda() {
        val greatOne = DriverClassProgressionEngine.SeasonPerformance(2026, 108.0, 30)
        val greatTwo = DriverClassProgressionEngine.SeasonPerformance(2027, 110.0, 30)
        assertEquals("Forte", DriverClassProgressionEngine.evaluate("Médio", 71, greatOne, greatTwo, 30).resultingClass)
        assertEquals("Pro", DriverClassProgressionEngine.evaluate("Forte", 91, greatOne, greatTwo, 30).resultingClass)
        assertEquals("Pro", DriverClassProgressionEngine.evaluate("Pro", 95, greatOne, greatTwo, 30).resultingClass)
        assertEquals("Lenda", DriverClassProgressionEngine.evaluate("Pro", 95, greatOne, greatTwo, 30, isChampion = true).resultingClass)
    }
}
