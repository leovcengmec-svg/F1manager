package com.f1teammanager.core.manager

import org.junit.Assert.assertEquals
import org.junit.Test
import com.f1teammanager.core.season.WorldDatabase

class RaceOperatingCostV438Test {
    @Test fun operatingCostsScaleByTeamLevel() {
        val strong = WorldDatabase.teams.first { it.initialLevel == InitialTeamProfile.FORTE }
        val medium = WorldDatabase.teams.first { it.initialLevel == InitialTeamProfile.MEDIO }
        val weak = WorldDatabase.teams.first { it.initialLevel == InitialTeamProfile.FRACO }
        assertEquals(2_200_000L, RaceOperatingCost.forTeam(strong.id))
        assertEquals(1_700_000L, RaceOperatingCost.forTeam(medium.id))
        assertEquals(1_200_000L, RaceOperatingCost.forTeam(weak.id))
    }

    @Test fun aiReserveCanUseTierSpecificRaceCost() {
        val weak = SeasonInvestmentPolicy.aiOperatingReserve(30_000_000L, 1, 1_200_000L)
        val strong = SeasonInvestmentPolicy.aiOperatingReserve(30_000_000L, 1, 2_200_000L)
        assertEquals(weak + 30_000_000L, strong)
    }
}
