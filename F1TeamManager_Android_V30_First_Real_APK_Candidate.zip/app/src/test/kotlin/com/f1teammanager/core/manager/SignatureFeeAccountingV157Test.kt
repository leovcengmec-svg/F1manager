package com.f1teammanager.core.manager

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SignatureFeeAccountingV157Test {
    @Test fun noCashIsChargedAtSignatureAndRemainingGpsAreUsed() {
        val fee = 12_000_000L
        val signed = FinanceEngine().applySignatureFee(TeamFinanceState(50_000_000L), fee,
            "Taxa de contratação — transferência de Piloto 42 — 2028", 2027, 16)
        assertEquals(50_000_000L, signed.budget)
        assertEquals(15, signed.signatureFeeSchedules.single().installmentCount)
        assertEquals(16, signed.signatureFeeSchedules.single().startRound)
    }

    @Test fun installmentsAreIdempotentAndReconcileToFullFee() {
        val fee = 12_000_017L
        val signed = FinanceEngine().applySignatureFee(TeamFinanceState(50_000_000L), fee,
            "Taxa de contratação — transferência de Piloto 42 — 2027", 2027, 1)
        assertEquals(50_000_000L, signed.budget)
        var state = signed
        for (gp in 1..30) {
            state = SignatureFeeAccounting.recognizeForRace(state, 2027, gp)
            val once = state
            val repeated = SignatureFeeAccounting.recognizeForRace(state, 2027, gp)
            assertEquals(once.budget, repeated.budget)
            state = repeated
        }
        assertEquals(37_999_983L, state.budget)
        assertEquals((1..30).toSet(), state.signatureFeeSchedules.single().paidRounds)
    }

    @Test fun scheduleOnlyChargesInSignatureSeason() {
        val signed = FinanceEngine().applySignatureFee(TeamFinanceState(50_000_000L), 9_000_000L,
            "Taxa de contratação de Piloto — 2028", 2027, 1)
        val wrongSeason = SignatureFeeAccounting.recognizeForRace(signed, 2028, 1)
        assertEquals(50_000_000L, wrongSeason.budget)
        assertTrue(wrongSeason.signatureFeeSchedules.single().paidRounds.isEmpty())
        val rightSeason = SignatureFeeAccounting.recognizeForRace(wrongSeason, 2027, 1)
        assertEquals(49_700_000L, rightSeason.budget)
    }
}
