package com.f1teammanager.core.race

fun main() {
    val laps = 78
    val attackLap = FuelModel.consumptionPerLap(laps, DriverStrategyMode.ATTACK, Weather.DRY, Tyre.MEDIUM)
    val balancedLap = FuelModel.consumptionPerLap(laps, DriverStrategyMode.BALANCED, Weather.DRY, Tyre.MEDIUM)
    val defenseLap = FuelModel.consumptionPerLap(laps, DriverStrategyMode.DEFENSE, Weather.DRY, Tyre.MEDIUM)

    check(attackLap > balancedLap) { "Ataque precisa consumir mais que equilibrado" }
    check(balancedLap > defenseLap) { "Equilibrado precisa consumir mais que defesa" }

    val attackFinish = FuelModel.TANK_CAPACITY_KG - attackLap * laps
    check(attackFinish > 0.0) { "Ataque ficou sem combustível antes do fim" }
    check(attackFinish + 1e-9 >= attackLap * FuelModel.SAFETY_LAPS) {
        "Ataque não terminou com duas voltas de segurança"
    }

    val rainLap = FuelModel.consumptionPerLap(laps, DriverStrategyMode.ATTACK, Weather.MEDIUM_RAIN, Tyre.INTERMEDIATE)
    check(rainLap < attackLap) { "Chuva deveria reduzir o consumo" }

    val afterPit = 42.0
    check(afterPit == 42.0) { "Pit não deve alterar combustível" }
    println("V88_FUEL_MODEL_AUDIT_OK")
    println("78 laps: attack=${"%.3f".format(attackLap)}kg/lap balanced=${"%.3f".format(balancedLap)} defense=${"%.3f".format(defenseLap)} reserveAttack=${"%.3f".format(attackFinish)}kg")
}
