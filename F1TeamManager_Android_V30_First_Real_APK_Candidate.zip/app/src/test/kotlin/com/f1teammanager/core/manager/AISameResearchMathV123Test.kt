package com.f1teammanager.core.manager

import com.f1teammanager.core.season.WorldDatabase
import org.junit.Test
import kotlin.test.assertFalse
import kotlin.test.assertTrue

class AISameResearchMathV123Test {
    @Test
    fun `AI no longer uses a hardcoded 50 50 research split`() {
        val source = java.io.File("app/src/main/java/com/f1teammanager/core/manager/AITeamDevelopmentEngine.kt").readText()
        assertFalse(source.contains("gain * 0.50"))
        assertTrue(source.contains("ResearchFocus.PERFORMANCE"))
        assertTrue(source.contains("ResearchFocus.RELIABILITY"))
        assertTrue(source.contains("ResearchEngine()"))
    }

    @Test
    fun `AI development is based on the researched component rather than team overall`() {
        val source = java.io.File("app/src/main/java/com/f1teammanager/core/manager/AITeamDevelopmentEngine.kt").readText()
        assertTrue(source.contains("basePerformance + performanceGain"))
        assertTrue(source.contains("baseReliability + reliabilityGain"))
    }

    @Test
    fun `all starting reliability remains inside the new category bands`() {
        WorldDatabase.teams.forEach { team ->
            val r = InitialTeamProfile.reliability(team)
            when (team.initialLevel) {
                InitialTeamProfile.FORTE -> assertTrue(r in 65..74)
                InitialTeamProfile.MEDIO -> assertTrue(r in 55..64)
                InitialTeamProfile.FRACO -> assertTrue(r in 45..54)
            }
        }
    }
}
