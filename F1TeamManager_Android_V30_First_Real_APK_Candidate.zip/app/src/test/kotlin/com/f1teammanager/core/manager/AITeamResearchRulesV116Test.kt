package com.f1teammanager.core.manager

import com.f1teammanager.core.season.WorldDatabase
import org.junit.Test
import kotlin.test.assertTrue

class AITeamResearchRulesV116Test {
    @Test
    fun `AI uses per component versions and cooldowns`() {
        val team = WorldDatabase.teams.first { it.name.equals("McLaren", ignoreCase = true) }
        val result = AITeamDevelopmentEngine(20261005).simulateFinancial(team, 7, 2026)
        val designs = result.events.filter {
            it.type == AITeamDevelopmentEngine.DevelopmentEvent.Type.DESIGN_COMPLETED
        }

        designs.groupBy { it.component }.values.forEach { events ->
            val ordered = events.sortedBy { it.week }
            val versions = ordered.map { it.version }
            assertTrue(versions.zipWithNext().all { it.second > it.first })
            assertTrue(ordered.zipWithNext().all { (a, b) -> b.week >= a.week + 5 })
        }

        val chassis = designs.filter { it.component == CarComponent.CHASSIS }
        assertTrue(chassis.all { it.version == 2 }, "Primeira evolução do Chassi da McLaren deve ser V2, não V4/V5.")
    }
}
