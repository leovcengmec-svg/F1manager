package com.f1teammanager.core.manager

import com.f1teammanager.core.race.RaceParticipant
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class RaceOperationsFacilityV708Test {
    @Test fun facilityHasExactlySevenInstallationsAndMigratesTheFormerScoutingSlot() {
        assertEquals(7, FacilityType.values().size)
        assertEquals(FacilityType.RACE_OPERATIONS, FacilityType.fromPersistedName("SCOUTING"))
        assertEquals(FacilityType.RACE_OPERATIONS, FacilityType.fromPersistedName("RACE_OPERATIONS"))
        assertEquals(null, FacilityType.fromPersistedName("UNKNOWN_FACILITY"))
    }

    @Test fun legacyTeamPrincipalFacilityObjectiveMigratesToRaceOperations() {
        val raw = TeamPrincipalCareerState(
            teamId = 1,
            objectives = listOf(TeamPrincipalObjective(
                id = "facility_scouting_2027",
                title = "Melhorar o Scouting",
                detail = "Elevar Scouting para o nível 4",
                kind = "facility_SCOUTING",
                target = 4,
                prestige = 1
            ))
        ).encode()
        val restored = TeamPrincipalCareerState.decode(raw) ?: error("Could not decode legacy TP state")
        val objective = restored.objectives.single()
        assertEquals("facility_RACE_OPERATIONS", objective.kind)
        assertEquals("facility_race_operations_2027", objective.id)
        assertEquals("Melhorar o Centro de Operações de Corrida", objective.title)
    }

    @Test fun legacyTeamPrincipalHandoffPreservesTheFormerScoutingLevel() {
        val team = com.f1teammanager.core.season.WorldDatabase.teams.first()
        val handoff = TeamPrincipalTeamHandoff(
            teamId = team.id,
            closingSeason = 2026,
            garage = TeamGarageFactory.fromInitial(team),
            facilities = TeamFacilitiesState().withLevel(FacilityType.RACE_OPERATIONS, 7),
            nextSeasonInvestment = 0L,
            technicalKnowledge = emptyMap()
        )
        val legacyPayload = handoff.encode().replace("RACE_OPERATIONS:7", "SCOUTING:7")
        val restored = TeamPrincipalTeamHandoff.decode(legacyPayload) ?: error("Could not decode legacy handoff")
        assertEquals(7, restored.facilities.level(FacilityType.RACE_OPERATIONS))
    }

    @Test fun allThreeBenefitsMatchTheSpecifiedEndpointsAndImproveMonotonically() {
        assertEquals(21_000L, RaceOperationsModel.baseStopLossMs(0))
        assertEquals(19_000L, RaceOperationsModel.baseStopLossMs(10))
        assertEquals(0.08, RaceOperationsModel.delayChance(0), 0.000001)
        assertEquals(0.02, RaceOperationsModel.delayChance(10), 0.000001)
        assertEquals(8_000L, RaceOperationsModel.repairAdditionalMs(0))
        assertEquals(5_000L, RaceOperationsModel.repairAdditionalMs(10))

        val stops = (0..10).map(RaceOperationsModel::baseStopLossMs)
        val delays = (0..10).map(RaceOperationsModel::delayChance)
        val repairs = (0..10).map(RaceOperationsModel::repairAdditionalMs)
        assertTrue(stops.zipWithNext().all { (a, b) -> b < a })
        assertTrue(delays.zipWithNext().all { (a, b) -> b < a })
        assertTrue(repairs.zipWithNext().all { (a, b) -> b < a })
    }

    @Test fun operationalDelayIsStableForEachRaceTeamDriverAndStopAndAlwaysWithinTwoToFourSeconds() {
        val outcomes = (1..2_000).map { seed ->
            val first = RaceOperationsModel.deterministicDelayMs(seed, 7, 44, 2, 0)
            val repeated = RaceOperationsModel.deterministicDelayMs(seed, 7, 44, 2, 0)
            assertEquals(first, repeated)
            first
        }
        assertTrue("The chance model must produce both clean and delayed stops", outcomes.any { it == 0L } && outcomes.any { it > 0L })
        assertTrue(outcomes.filter { it > 0L }.all { it in 2_000L..4_000L })

        val levelTenDelays = (1..2_000).count {
            RaceOperationsModel.deterministicDelayMs(it, 7, 44, 2, 10) > 0L
        }
        val levelZeroDelays = outcomes.count { it > 0L }
        assertTrue("Level 10 must reduce the frequency of delay events", levelTenDelays < levelZeroDelays)
    }

    @Test fun raceParticipantCarriesANormalizedOperationsLevelForBothRaceModes() {
        val base = RaceParticipant(
            driverId = 1, driverName = "Test Driver", teamId = 1, teamName = "Test Team",
            driverSpeed = 70, qualifying = 70, overtaking = 70, defense = 70,
            consistency = 70, enginePerformance = 70, raceOperationsLevel = 14
        )
        assertEquals(10, base.normalized().raceOperationsLevel)
        assertEquals(0, base.copy(raceOperationsLevel = -2).normalized().raceOperationsLevel)
    }

    @Test fun actualRaceEngineAppliesEachTeamsOwnFacilityLevelInTheSameGp() {
        val participants = (1..80).map { driverId ->
            val teamId = (driverId - 1) / 2 + 1
            val teamLevel = when (teamId) {
                1 -> 0
                2 -> 10
                else -> 5
            }
            RaceParticipant(
                driverId = driverId,
                driverName = "Driver $driverId",
                teamId = teamId,
                teamName = "Team $teamId",
                driverSpeed = 70, qualifying = 70, overtaking = 70, defense = 70,
                consistency = 70, enginePerformance = 70,
                raceOperationsLevel = teamLevel
            )
        }
        val circuit = com.f1teammanager.core.race.RaceCircuit(
            id = 1, name = "Test GP", laps = 10, baseLapTimeMs = 90_000L,
            crashRisk = 0.0, reliabilityRisk = 0.0, safetyCarRisk = 0.0
        )
        // Seed 1 produces clean stops for team 1/driver 1 and team 2/driver 3,
        // isolating each team's base-time benefit in one shared race session.
        val engine = com.f1teammanager.core.race.CareerWeekendEngine(1)
        engine.start(participants, circuit, playerTeamId = 1, weekendSeed = 1)
        val afterLevelZeroStop = engine.pitNow(1)
        val levelZeroStop = afterLevelZeroStop.carStatus.first { it.driverId == 1 }.lastPitLossSec
        val afterLevelTenStop = engine.pitNow(3)
        val levelTenStop = afterLevelTenStop.carStatus.first { it.driverId == 3 }.lastPitLossSec
        assertEquals(21, levelZeroStop)
        assertEquals(19, levelTenStop)
    }

    @Test fun facilityCardsShowCurrentOperationalValues() {
        val levelZero = FacilityEngine.levelEffect(FacilityType.RACE_OPERATIONS, 0)
        val levelTen = FacilityEngine.levelEffect(FacilityType.RACE_OPERATIONS, 10)
        assertTrue(levelZero.contains("21,0 s"))
        assertTrue(levelZero.contains("8,0%"))
        assertTrue(levelZero.contains("+8,0 s"))
        assertTrue(levelTen.contains("19,0 s"))
        assertTrue(levelTen.contains("2,0%"))
        assertTrue(levelTen.contains("+5,0 s"))
    }
}
