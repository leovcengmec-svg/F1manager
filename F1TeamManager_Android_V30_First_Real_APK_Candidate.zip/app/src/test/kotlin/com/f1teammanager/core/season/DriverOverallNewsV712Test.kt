package com.f1teammanager.core.season

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNull

class DriverOverallNewsV712Test {
    @Test
    fun `overall news includes the reason without exposing attribute names`() {
        val message = DriverEvolutionEngine.overallMovementNews(
            "Oscar Piastri", "McLaren", 4, 86, 85, "declínio natural da idade"
        )
        assertEquals(
            "Oscar Piastri — McLaren — GP 4: perdeu Overall 86 → 85 (-1). Motivo: declínio natural da idade.",
            message
        )
    }

    @Test
    fun `legacy normalization preserves a V712 reason suffix`() {
        val message = "Oscar Piastri — McLaren — GP 4: perdeu Overall 86 → 85 (-1). Motivo: declínio natural da idade."
        assertEquals(message, DriverEvolutionEngine.normalizeOverallMovementNews(message))
    }

    @Test
    fun `overall-neutral attribute changes still do not create news`() {
        assertNull(DriverEvolutionEngine.overallMovementNews("George Russell", "Mercedes", 2, 87, 87, "desempenho esportivo"))
    }
}
