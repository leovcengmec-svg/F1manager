package com.f1teammanager.core.season

import org.junit.Assert.assertEquals
import org.junit.Test

class DriverClassProgressionV735Test {
    @Test fun proPromotionAcceptsAnyCareerTitleNotOnlyTheLatestSeasonChampion() {
        val first = DriverClassProgressionEngine.SeasonPerformance(2030, 108.0, 30)
        val second = DriverClassProgressionEngine.SeasonPerformance(2031, 110.0, 30)
        // isChampion is now supplied by the caller from the full career title ledger.
        val promoted = DriverClassProgressionEngine.evaluate(
            driverClass = "Pro", overall = 94, previous = first, latest = second,
            expectedSeasonRounds = 30, isChampion = true
        )
        assertEquals("Lenda", promoted.resultingClass)
        assertEquals(DriverClassProgressionEngine.Direction.PROMOTION, promoted.direction)
    }
}
