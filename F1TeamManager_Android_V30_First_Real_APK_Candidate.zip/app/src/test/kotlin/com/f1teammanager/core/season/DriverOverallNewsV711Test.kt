package com.f1teammanager.core.season

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNull
import kotlin.test.assertTrue

class DriverOverallNewsV711Test {
    @Test
    fun `no central news is created when only individual attributes change`() {
        assertNull(DriverEvolutionEngine.overallMovementNews("George Russell", "Mercedes", 2, 87, 87))
    }

    @Test
    fun `positive central news reports only overall evolution`() {
        val message = DriverEvolutionEngine.overallMovementNews("George Russell", "Mercedes", 2, 87, 88)
        assertEquals("George Russell — Mercedes — GP 2: evoluiu Overall 87 → 88 (+1).", message)
        assertTrue(message!!.contains("Overall 87 → 88"))
        assertTrue(!message.contains("DEF") && !message.contains("VEL") && !message.contains("desempenho"))
    }

    @Test
    fun `negative central news reports only overall regression`() {
        val message = DriverEvolutionEngine.overallMovementNews("Eddie Irvine", "Rodin Motorsport", 30, 68, 67)
        assertEquals("Eddie Irvine — Rodin Motorsport — GP 30: perdeu Overall 68 → 67 (-1).", message)
    }

    @Test
    fun `legacy pending attribute-only news is discarded`() {
        val legacy = "George Russell — Mercedes — GP 2: teve alterações nos atributos. Overall 87 → 87 (0, desempenho acima das expectativas: DEF +1)."
        assertNull(DriverEvolutionEngine.normalizeOverallMovementNews(legacy))
    }

    @Test
    fun `legacy pending news with overall movement is normalized without attributes`() {
        val legacy = "George Russell — Mercedes — GP 2: teve alterações nos atributos. Overall 87 → 88 (+1, desempenho acima das expectativas: DEF +1)."
        assertEquals(
            "George Russell — Mercedes — GP 2: evoluiu Overall 87 → 88 (+1).",
            DriverEvolutionEngine.normalizeOverallMovementNews(legacy)
        )
    }
}
