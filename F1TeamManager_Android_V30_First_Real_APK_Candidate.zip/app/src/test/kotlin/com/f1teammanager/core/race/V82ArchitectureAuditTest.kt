package com.f1teammanager.core.race

import java.io.File

fun main() {
    val root = File("app/src/main/java/com/f1teammanager/core")
    val source = root.walkTopDown().filter { it.isFile && it.extension == "kt" }.joinToString("\n") { it.readText() }
    listOf("powerFactor", "overtakingFactor", "carBonus", "frontWingDrsGainMs").forEach {
        check(!source.contains(it)) { "Dependência legada ainda presente: $it" }
    }
    check(!source.contains("180L")) { "Bônus ERS fixo antigo encontrado" }
    check(!source.contains("280L")) { "Bônus DRS fixo antigo encontrado" }
    check(File(root, "race/CareerWeekendEngine.kt").readText().contains("drsAttackEfficiency"))
    check(File(root, "race/PitwallPaceModel.kt").readText().contains("0.015"))
    println("V82_ARCHITECTURE_AUDIT_OK")
}
