package com.f1teammanager.core.season

import kotlin.random.Random

/** Regression tests for V604 performance-vs-development calibration. */
fun main() {
    // Hitting target should be neutral; one position behind is a small deviation,
    // not the old severe P1/P2 score of 50.
    check(DriverEvolutionEngine.gpPerformanceIndex(1, 1, 1) == 100.0)
    check(DriverEvolutionEngine.gpPerformanceIndex(1, 2, 2) == 95.0)
    check(DriverEvolutionEngine.gpPerformanceIndex(1, 6, 6) == 75.0)
    check(DriverEvolutionEngine.gpPerformanceIndex(10, 8, 8) == 110.0)

    // At/near expectation, the growth multiplier is calibrated around 1.0.
    check(DriverEvolutionEngine.performanceUtilization(100.0) == 1.05)
    check(DriverEvolutionEngine.performanceUtilization(110.0) == 1.15)
    check(DriverEvolutionEngine.performanceUtilization(80.0) == 0.65)
    check(DriverEvolutionEngine.performanceUtilization(50.0) == 0.30)
    check(DriverEvolutionEngine.phaseDurationSeasons("GROWING") == 5)
    check(DriverEvolutionEngine.phaseDurationSeasons("PEAK") == 2)
    check(DriverEvolutionEngine.phaseDurationSeasons("REGRESSION") == 5)

    // Reproduce the live per-GP accumulation for a Max-class Lenda at target P1
    // with qualifying/race P2 for six rounds. This must yield a visible Overall tick.
    val profile = DriverProfileCatalog.profile("Max Verstappen")
    val ratings = profile.ratings.copyOf()
    var driver = DriverDefinition(
        id = 9, name = "Max Verstappen", teamId = 1,
        speed = ratings[0], qualifying = ratings[1], overtaking = ratings[2], defense = ratings[3],
        consistency = ratings[4], wet = ratings[5], tyre = ratings[6],
        driverClass = profile.driverClass, evolution = profile.evolution
    )
    val startOverall = DriverProfileCatalog.overall(ratings)
    check(startOverall == 75)
    val targetOverall = DriverProfileCatalog.ceiling(profile.driverClass)
    val distance = kotlin.math.abs(targetOverall - startOverall)
    val basePerGp = distance.toDouble() * 7.0 / (5 * 30).toDouble()
    var bank = 0.0
    val annualGains = IntArray(7)
    repeat(6) {
        val index = DriverEvolutionEngine.gpPerformanceIndex(1, 2, 2)
        bank += basePerGp * DriverEvolutionEngine.performanceUtilization(index) * DriverEvolutionEngine.anticipationFactor(index)
        val whole = bank.toInt()
        if (whole > 0) {
            driver = DriverEvolutionEngine.applyPositiveGain(
                driver, whole, annualGains, Random(20261017 + it),
                perAttributeCap = DriverProfileCatalog.maxAnnualGain(driver.evolution)
            )
            bank -= whole.toDouble()
        }
    }
    val finalRatings = intArrayOf(driver.speed, driver.qualifying, driver.overtaking, driver.defense, driver.consistency, driver.wet, driver.tyre)
    check(finalRatings.sum() > ratings.sum()) { "No attributes grew after six expected/near-expected GPs" }
    check(DriverProfileCatalog.overall(finalRatings) >= 76) {
        "Expected visible Overall growth by GP6; stayed at ${DriverProfileCatalog.overall(finalRatings)}"
    }
    check(finalRatings.all { it in 40..DriverProfileCatalog.ceiling(profile.driverClass) })
    println("DriverEvolutionPerformanceV604Test: PASS (target scoring, performance multipliers, 5/2/5, visible GP6 growth)")
}
