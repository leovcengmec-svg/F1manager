package com.f1teammanager.core.season

import kotlin.random.Random

/** V649 contract: performance-led growth, soft class thresholds and shared annual caps. */
fun main() {
    check(DriverEvolutionEngine.gpPerformanceIndex(1, 1, 1) == 100.0)
    check(DriverEvolutionEngine.gpPerformanceIndex(1, 2, 2) == 95.0)
    check(DriverEvolutionEngine.gpPerformanceIndex(1, 6, 6) == 75.0)
    check(DriverEvolutionEngine.gpPerformanceIndex(10, 8, 8) == 110.0)
    check(DriverEvolutionEngine.performanceEvolutionRate(120.0) == 1.30)
    check(DriverEvolutionEngine.performanceEvolutionRate(110.0) == 1.00)
    check(DriverEvolutionEngine.performanceEvolutionRate(100.0) == 0.50)
    check(DriverEvolutionEngine.performanceEvolutionRate(88.0) == 0.0)
    check(DriverEvolutionEngine.performanceEvolutionRate(70.0) < 0.0)

    val developing = DriverDefinition(500, "Potential probe", 1, 89, 89, 89, 89, 89, 89, 89,
        "Pro", "Prodígio", "", 96)
    var driver = developing
    var bank = 0.0
    val annual = IntArray(7)
    fun ratings(d: DriverDefinition) = intArrayOf(d.speed,d.qualifying,d.overtaking,d.defense,d.consistency,d.wet,d.tyre)
    repeat(70) { gp ->
        val tick = DriverEvolutionEngine.applyPerformanceTick(
            driver, performanceIndex = 120.0, currentBank = bank, annualGains = annual,
            random = Random(649 + gp)
        )
        driver = tick.driver
        bank = tick.bank
    }
    check(DriverProfileCatalog.overall(ratings(driver)) > 89) { "High-performing driver could not pass class threshold" }
    check(DriverProfileCatalog.overall(ratings(driver)) <= 96) { "Driver exceeded personal potential" }
    check(annual.all { it <= DriverProfileCatalog.maxAnnualGain("Prodígio") }) {
        "Per-attribute annual development cap was exceeded"
    }

    // Poor performance accumulates fractional regression gradually; neutral performance does not force a phase transition.
    val before = ratings(driver).sum()
    var lossBank = 0.0
    repeat(4) { gp ->
        val tick = DriverEvolutionEngine.applyPerformanceTick(
            driver, performanceIndex = 55.0, currentBank = lossBank, annualGains = IntArray(7),
            random = Random(700 + gp)
        )
        driver = tick.driver
        lossBank = tick.bank
    }
    check(ratings(driver).sum() <= before) { "Persistent poor performance did not start regression" }
    check(ratings(driver).all { it in 40..100 })
    check(DriverEvolutionEngine.initialPhase(developing) == "GROWING")

    val developmentState = com.f1teammanager.core.manager.DriverDevelopmentEngine.start(
        com.f1teammanager.core.manager.DriverDevelopmentState(), level = 10, driverId = developing.id,
        currentWeek = 1, teamDrivers = setOf(developing.id)
    )
    val developmentAnnual = IntArray(7)
    val developmentResult = com.f1teammanager.core.manager.DriverDevelopmentEngine.advanceWeeks(
        developmentState, weeks = 3, currentWeek = 4, drivers = mapOf(developing.id to developing),
        attributes = mapOf(developing.id to intArrayOf(89, 89, 89, 89, 89, 89, 89)), seed = 649,
        annualGains = mapOf(developing.id to developmentAnnual)
    )
    val facilityRatings = developmentResult.attributes.getValue(developing.id)
    check(DriverProfileCatalog.overall(facilityRatings) > 89) { "Development facility could not use its above-class allowance" }
    check(DriverProfileCatalog.overall(facilityRatings) <= 96) { "Development facility exceeded individual potential" }
    check(developmentResult.annualGains.getValue(developing.id).all { it <= 15 })

    println("DriverEvolutionPerformanceV649Test: PASS")
}
