package com.f1teammanager.core.manager

import com.f1teammanager.core.season.WorldDatabase
import org.junit.Assert.*
import org.junit.Test

class AIDriverDevelopmentAndContractsV703Test {
    @Test fun aiDevelopmentCodecPersistsUnusedReservePoints() {
        val teamId = WorldDatabase.teams.first().id
        val driverId = WorldDatabase.allDrivers.first().id
        val state = DriverDevelopmentState(
            programs = listOf(DriverDevelopmentProgram(driverId, 12, 8, 3, 6)),
            reservePoints = mapOf(driverId to 5)
        )
        val encoded = AiDriverDevelopmentCodec.encode(mapOf(teamId to state))
        val restored = AiDriverDevelopmentCodec.decode(encoded).getValue(teamId)
        assertEquals(state.normalized(), restored)
        assertEquals(5, restored.reservePoints[driverId])
        assertEquals(3, restored.programs.single().remainingWeeks)
    }

    @Test fun aiDevelopmentCodecKeepsCompatibilityWithV702QueueRows() {
        val driverId = WorldDatabase.allDrivers.first().id
        val teamId = WorldDatabase.teams.first().id
        val legacy = "$teamId#${driverId},12,8,3,6"
        val restored = AiDriverDevelopmentCodec.decode(legacy).getValue(teamId)
        assertEquals(driverId, restored.programs.single().driverId)
        assertTrue(restored.reservePoints.isEmpty())
    }

    @Test fun playerDriversInFinalContractYearEnterAiApproachPoolButMidContractDriversDoNot() {
        val engine = DriverMarketEngine(seed = 703)
        val initial = engine.initialState(2026)
        val playerTeamId = WorldDatabase.teams.first().id
        val aiTeamId = WorldDatabase.teams.first { it.id != playerTeamId }.id
        val playerDriver = initial.contracts.first { it.teamId == playerTeamId }.driverId
        val expiring = initial.copy(contracts = initial.contracts.map { deal ->
            if (deal.driverId == playerDriver) deal.copy(years = 1, seasonSigned = 2026) else deal
        })
        assertTrue(engine.canReceiveProposals(expiring, playerDriver, 2026))
        val expiringPool = engine.aiApproachCandidates(expiring, aiTeamId, 2026, playerTeamId)
        assertTrue("AI must be able to approach a player's driver in the final contract year", playerDriver in expiringPool)

        val multiYear = expiring.copy(contracts = expiring.contracts.map { deal ->
            if (deal.driverId == playerDriver) deal.copy(years = 4, seasonSigned = 2026) else deal
        })
        assertFalse(engine.canReceiveProposals(multiYear, playerDriver, 2026))
        val multiYearPool = engine.aiApproachCandidates(multiYear, aiTeamId, 2026, playerTeamId)
        assertFalse("AI must not poach a player driver mid-contract", playerDriver in multiYearPool)
    }

    @Test fun aiCancelsDevelopmentProgrammeImmediatelyWhenDriverChangesTeam() {
        val engine = DriverMarketEngine(seed = 703)
        val base = engine.initialState(2026)
        val playerTeamId = WorldDatabase.teams.first().id
        val sourceTeamId = WorldDatabase.teams.first { it.id != playerTeamId }.id
        val sourceDriver = base.contracts.first { it.teamId == sourceTeamId }
        val destinationTeamId = WorldDatabase.teams.first { it.id != playerTeamId && it.id != sourceTeamId }.id
        val destinationDriver = base.contracts.first { it.teamId == destinationTeamId }
        val programme = DriverDevelopmentProgram(sourceDriver.driverId, 14, 8, 5, 6)
        val market = base.copy(
            scheduled = listOf(FutureDriverDeal(
                sourceDriver.driverId, sourceTeamId, destinationTeamId, 2027, 3,
                sourceDriver.salary, DriverTeamRole.EQUAL, 2026, destinationDriver.driverId
            )),
            aiDriverDevelopment = mapOf(sourceTeamId to DriverDevelopmentState(listOf(programme), mapOf(sourceDriver.driverId to 2)))
        )
        val budgets = WorldDatabase.teams.associate { it.id to 0L }
        val transitioned = engine.applySeasonTransition(market, 2027, budgets, playerTeamId)
        assertTrue(transitioned.aiDriverDevelopment[sourceTeamId]?.programs.orEmpty().none { it.driverId == sourceDriver.driverId })
        assertEquals("Reserved points remain persisted when a programme is cancelled", 2,
            transitioned.aiDriverDevelopment[sourceTeamId]?.reservePoints?.get(sourceDriver.driverId) ?: -1)
        val sourceName = WorldDatabase.allDrivers.first { it.id == sourceDriver.driverId }.name
        assertTrue(transitioned.notifications.any {
            it.title == "PROGRAMA DE DESENVOLVIMENTO CANCELADO" && it.message.contains(sourceName) && it.message.contains("vaga foi liberada")
        })
    }

    @Test fun highPotentialDriversDoNotReceiveOneYearDealsOnlyBecauseCurrentOverallIsLow() {
        val candidate = WorldDatabase.allDrivers.first { it.name == "Charles Leclerc" }
        val age = com.f1teammanager.core.season.DriverEvolutionEngine.careerAge(candidate, 2026)
        assertTrue(age in 26..29)
        assertTrue("Charles Leclerc should carry high individual potential", candidate.potentialOverall >= 90)
        val engine = DriverMarketEngine(seed = 703)
        val deliberatelyLowRatings = mapOf(candidate.id to List(7) { 62 })
        val years = engine.chooseAiYears(candidate.id, 2026, 53, deliberatelyLowRatings)
        assertTrue("High potential in prime development age must receive at least a 3-year plan, got $years", years in 3..5)
    }
}
