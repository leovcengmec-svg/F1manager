package com.f1teammanager.core.race

import com.f1teammanager.core.season.*
import java.io.File

fun main(){
    check(WorldDatabase.teams.size==40)
    check(WorldDatabase.drivers.size==80)
    check(WorldDatabase.rounds.size==24)
    val engine=SeasonEngine(20261003)
    var s=SeasonState()
    val (next,r)=engine.runRound(s)
    check(r.classification.size==80)
    check(r.points.values.sum()>0)
    check(next.currentRound==2)
    val f=File.createTempFile("f1tm-v6",".sav")
    SaveGame.save(f,next)
    val loaded=SaveGame.load(f)!!
    check(loaded==next)
    check(engine.table(next).size==80)
    f.delete()
    println("V6 SEASON CORE SMOKE TEST OK")
}
