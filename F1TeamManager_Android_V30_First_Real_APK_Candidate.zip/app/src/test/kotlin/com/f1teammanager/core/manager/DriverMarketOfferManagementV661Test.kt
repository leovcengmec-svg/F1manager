package com.f1teammanager.core.manager

import com.f1teammanager.core.season.WorldDatabase
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class DriverMarketOfferManagementV661Test {
    @Test fun `incoming offer expires without automatic driver decision`() {
        val engine = DriverMarketEngine(6612026)
        val state = engine.initialState(2026)
        val incumbent = state.contracts.first()
        val destination = WorldDatabase.teams.first { it.id != incumbent.teamId }
        val offer = DriverOffer(
            driverId = incumbent.driverId,
            fromTeamId = incumbent.teamId,
            toTeamId = destination.id,
            years = 2,
            salary = incumbent.salary,
            role = DriverTeamRole.EQUAL,
            marketValue = incumbent.marketValue,
            interestScore = 90,
            expiresAfterWeek = 12,
            status = NegotiationStatus.PENDING,
            seasonTarget = 2027,
            proposerTeamId = destination.id
        )
        val withOffer = state.copy(pending = listOf(offer))

        val result = engine.expireOffers(withOffer, 12, 2026, playerTeamId = incumbent.teamId)

        assertTrue(result.pending.none { it.driverId == incumbent.driverId && it.toTeamId == destination.id })
        assertFalse(result.scheduled.any { it.driverId == incumbent.driverId && it.startSeason == 2027 })
        assertTrue(result.notifications.any { it.title == "OFERTA EXPIRADA" })
    }

    @Test fun `incoming offer is still available before its deadline`() {
        val engine = DriverMarketEngine(6612027)
        val state = engine.initialState(2026)
        val incumbent = state.contracts.first()
        val destination = WorldDatabase.teams.first { it.id != incumbent.teamId }
        val offer = DriverOffer(
            incumbent.driverId, incumbent.teamId, destination.id, 2, incumbent.salary,
            DriverTeamRole.EQUAL, incumbent.marketValue, 80,
            expiresAfterWeek = 12, seasonTarget = 2027, proposerTeamId = destination.id
        )
        val result = engine.expireOffers(state.copy(pending = listOf(offer)), 11, 2026, playerTeamId = incumbent.teamId)
        assertEquals(1, result.pending.count { it.driverId == incumbent.driverId && it.toTeamId == destination.id })
    }
}
