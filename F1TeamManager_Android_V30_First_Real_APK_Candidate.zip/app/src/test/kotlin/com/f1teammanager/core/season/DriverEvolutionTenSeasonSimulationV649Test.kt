package com.f1teammanager.core.season

import kotlin.random.Random

fun main() {
    data class SimDriver(var definition: DriverDefinition, var bank: Double = 0.0)
    val drivers = WorldDatabase.allDrivers.associate { d ->
        d.id to SimDriver(d)
    }.toMutableMap()
    val seasonAverages = mutableMapOf<Int, MutableMap<Int, Pair<Double, Int>>>()
    repeat(10) { yearIndex ->
        val season = 2026 + yearIndex
        val seasonRows = mutableMapOf<Int, Pair<Double, Int>>()
        val annualGains = drivers.keys.associateWith { IntArray(7) }
        drivers.toSortedMap().forEach { (id, state) ->
            val performance = when (id % 10) {
                0, 1 -> 120.0
                2, 3, 4 -> 110.0
                5, 6, 7 -> 100.0
                8 -> 90.0
                else -> 70.0
            }
            var sum = 0.0
            repeat(30) { gp ->
                val tick = DriverEvolutionEngine.applyPerformanceTick(
                    state.definition, performance, state.bank, annualGains.getValue(id), Random(id * 100_000 + season * 100 + gp)
                )
                state.definition = tick.driver
                state.bank = tick.bank
                sum += performance
            }
            seasonRows[id] = sum to 30
        }
        seasonAverages[season] = seasonRows
        if (yearIndex >= 1) {
            drivers.forEach { (id, state) ->
                val old = seasonAverages[season - 1]!!.getValue(id)
                val now = seasonRows.getValue(id)
                val decision = DriverClassProgressionEngine.evaluate(
                    state.definition.driverClass,
                    DriverProfileCatalog.overall(intArrayOf(
                        state.definition.speed, state.definition.qualifying, state.definition.overtaking,
                        state.definition.defense, state.definition.consistency, state.definition.wet, state.definition.tyre
                    )),
                    DriverClassProgressionEngine.SeasonPerformance(season - 1, old.first / old.second, old.second),
                    DriverClassProgressionEngine.SeasonPerformance(season, now.first / now.second, now.second),
                    30
                )
                if (decision.changed) state.definition = state.definition.copy(driverClass = decision.resultingClass)
            }
        }
    }
    val distribution = drivers.values.groupingBy { it.definition.driverClass }.eachCount()
    check(distribution.values.sum() == 100)
    check(distribution.getOrDefault("Lenda", 0) < 100) { "Grid collapsed into Lenda after ten seasons: $distribution" }
    drivers.values.forEach { state ->
        val d = state.definition
        val values = intArrayOf(d.speed, d.qualifying, d.overtaking, d.defense, d.consistency, d.wet, d.tyre)
        check(values.all { it in 40..100 })
        val overall = DriverProfileCatalog.overall(values)
        check(overall <= d.potentialOverall) { "${d.name} exceeded potential $overall/${d.potentialOverall}" }
    }
    println("10-season simulation PASS | class distribution=$distribution")
}

