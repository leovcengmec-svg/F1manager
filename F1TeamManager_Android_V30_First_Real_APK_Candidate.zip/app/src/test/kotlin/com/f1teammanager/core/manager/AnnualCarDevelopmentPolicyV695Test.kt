package com.f1teammanager.core.manager

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class AnnualCarDevelopmentPolicyV695Test {
    @Test
    fun `annual current car development allowance shrinks as overall rises`() {
        assertEquals(42, CarDevelopmentEngine.seasonDevelopmentLimit(55))
        assertEquals(36, CarDevelopmentEngine.seasonDevelopmentLimit(68))
        assertEquals(30, CarDevelopmentEngine.seasonDevelopmentLimit(80))
        assertEquals(24, CarDevelopmentEngine.seasonDevelopmentLimit(90))
        assertEquals(18, CarDevelopmentEngine.seasonDevelopmentLimit(97))
    }

    @Test
    fun `elite team cannot use the rebuilding team's annual development allowance`() {
        assertTrue(CarDevelopmentEngine.seasonDevelopmentLimit(97) < CarDevelopmentEngine.seasonDevelopmentLimit(45))
    }
}
