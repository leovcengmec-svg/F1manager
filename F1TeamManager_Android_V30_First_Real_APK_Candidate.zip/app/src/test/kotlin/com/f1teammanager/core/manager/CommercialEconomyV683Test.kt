package com.f1teammanager.core.manager

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class CommercialEconomyV683Test {
    @Test fun levelsZeroToThreeKeepTheirExistingContractValue() {
        assertEquals(1.60, SponsorContractPricing.commercialMultiplier(0), 0.000001)
        assertEquals(1.625, SponsorContractPricing.commercialMultiplier(1), 0.000001)
        assertEquals(1.65, SponsorContractPricing.commercialMultiplier(2), 0.000001)
        assertEquals(1.675, SponsorContractPricing.commercialMultiplier(3), 0.000001)
    }

    @Test fun advancedCommercialLevelsHaveDiminishingContractReturns() {
        val values = (0..10).map(SponsorContractPricing::commercialMultiplier)
        assertTrue(values.zipWithNext().all { (a, b) -> b > a })
        assertEquals(1.7275, values.last(), 0.000001)
        assertTrue("The level 3→10 gain must be smaller than the old 0.175 multiplier growth",
            values.last() - values[3] < 0.06)
    }

    @Test fun storeRevenueGrowthAboveLevelThreeIsCappedAndIncremental() {
        val values = (3..10).map { FacilityEngine.weeklyMerchandiseRevenueRange(it) }
        assertEquals(650_000L..1_000_000L, values.first())
        assertEquals(1_000_000L..1_350_000L, values.last())
        assertTrue(values.zipWithNext().all { (a, b) -> b.first - a.first <= 50_000L && b.last - a.last <= 50_000L })
    }

    @Test fun advancedMarketingMaintenanceRisesFasterThanStoreRevenue() {
        val level3 = FacilityEngine.weeklyMarketingMaintenanceCost(3)
        val level10 = FacilityEngine.weeklyMarketingMaintenanceCost(10)
        assertEquals(80_000L, level3)
        assertEquals(980_000L, level10)
        assertTrue(level10 > level3 * 10L)
        val facilities = TeamFacilitiesState().withLevel(FacilityType.MARKETING, 10)
        assertEquals(level10, FacilityEngine.weeklyMaintenanceTotal(facilities))
    }

    @Test fun nextCarSpendingReducesActualRemainingAnnualBudget() {
        assertEquals(40_000_000L, SeasonInvestmentPolicy.remainingAnnualTechnicalEnvelope(
            200_000_000L, alreadySpentTechnical = 120_000_000L, nextCarAlreadyInvested = 40_000_000L
        ))
        assertEquals(0L, SeasonInvestmentPolicy.remainingAnnualTechnicalEnvelope(
            200_000_000L, alreadySpentTechnical = 120_000_000L, nextCarAlreadyInvested = 80_000_000L
        ))
    }
}
