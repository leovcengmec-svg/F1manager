package com.f1teammanager.core.manager

import com.f1teammanager.core.season.WorldDatabase
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** Historical sponsorship regressions plus V652 adaptive AI facility-investment expectations. */
class SponsorshipAndCommercialAI_V619Test {
    @Test fun allCatalogProfilesAndGeneratedOffersPayEntryAndPerGp() {
        assertEquals(180, SponsorCatalog.all.size)
        assertTrue(SponsorCatalog.all.all { it.paymentModel == SponsorPaymentModel.ENTRY_AND_GP })
        for (level in 0..10) {
            val engine = TeamSponsorshipEngine(seed = 619)
            for (slot in 1..5) {
                val offers = engine.offersForSlot(1, 2026, slot, level, 2)
                assertEquals(3, offers.size)
                assertTrue("Level $level slot $slot contains offer without both payments", offers.all {
                    it.sponsor.upfront > 0L && it.sponsor.racePayment > 0L
                })
            }
        }
    }

    @Test fun legacySponsorPaymentMigrationIsIdempotentAndPreservesExistingAmount() {
        val legacy = SponsorContract(
            name = "Legacy Regional Sponsor", upfront = 4_000_000L, racePayment = 0L,
            pointsBonus = 0L, years = 1, minimumReputation = 0, slot = 2,
            active = true, races = 5, racesRemaining = 4, category = "REGIONAL"
        )
        val migrated = SponsorContractPricing.ensureEntryAndGp(legacy, teamId = 1, season = 2026, marketingLevel = 2)
        assertEquals(legacy.upfront, migrated.upfront)
        assertTrue(migrated.racePayment > 0L)
        assertEquals(migrated, SponsorContractPricing.ensureEntryAndGp(migrated, 1, 2026, 2))
    }

    @Test fun aiPrioritizesTechnicalBaseAndKeepsOperatingReserveBeforeCommercialExpansion() {
        val teamId = WorldDatabase.teams.first().id
        val finance = AITeamFinancialEngine(seed = 619)
        finance.adoptFormerPlayerTeam(
            teamId = teamId, season = 2026,
            finance = TeamFinanceState(budget = 80_000_000L),
            teamFacilities = TeamFacilitiesState(FacilityType.values().associateWith { 0 })
        )
        val started = finance.advanceFacilityDevelopment(teamId, 2026, 8)
        assertEquals(FacilityType.RESEARCH, finance.facilityUpgrade(teamId)?.facility)
        assertEquals(70_000_000L, started.finance.budget)
        for (week in 9..20) finance.advanceFacilityDevelopment(teamId, 2026, week)
        assertEquals(1, finance.facilities(teamId).level(FacilityType.RESEARCH))
        val second = finance.advanceFacilityDevelopment(teamId, 2026, 24)
        assertEquals(FacilityType.RESEARCH, finance.facilityUpgrade(teamId)?.facility)
        assertTrue(second.finance.budget >= 0L)

        val poor = AITeamFinancialEngine(seed = 620)
        poor.adoptFormerPlayerTeam(
            teamId = teamId, season = 2026,
            finance = TeamFinanceState(budget = 12_000_000L),
            teamFacilities = TeamFacilitiesState(FacilityType.values().associateWith { 0 })
        )
        poor.advanceFacilityDevelopment(teamId, 2026, 8)
        assertNull(poor.facilityUpgrade(teamId))
        assertEquals(12_000_000L, poor.state(teamId, 2026).finance.budget)

        // When Marketing is expensive and the team has not rebuilt its technical
        // base, an affordable Research upgrade remains the rational option.
        val fallback = AITeamFinancialEngine(seed = 6201)
        fallback.adoptFormerPlayerTeam(
            teamId = teamId, season = 2026,
            finance = TeamFinanceState(budget = 25_000_000L),
            teamFacilities = TeamFacilitiesState(FacilityType.values().associateWith {
                if (it == FacilityType.MARKETING) 1 else 0
            })
        )
        fallback.advanceFacilityDevelopment(teamId, 2026, 8)
        assertEquals(FacilityType.RESEARCH, fallback.facilityUpgrade(teamId)?.facility)
        assertEquals(15_000_000L, fallback.state(teamId, 2026).finance.budget)

        val healthy = AITeamFinancialEngine(seed = 621)
        healthy.adoptFormerPlayerTeam(
            teamId = teamId, season = 2026,
            finance = TeamFinanceState(budget = 120_000_000L, seasonIncome = 70_000_000L, seasonExpenses = 35_000_000L),
            teamFacilities = TeamFacilitiesState(FacilityType.values().associateWith { if (it == FacilityType.MARKETING) 2 else 0 })
        )
        healthy.advanceFacilityDevelopment(teamId, 2026, 8)
        assertNotNull(healthy.facilityUpgrade(teamId))
        assertEquals(FacilityType.RESEARCH, healthy.facilityUpgrade(teamId)?.facility)
    }

    @Test fun aiWeeklyCommercialRevenueIsDurableAndCannotBeCreditedTwice() {
        val teamId = WorldDatabase.teams.first().id
        val engine = AITeamFinancialEngine(seed = 622)
        engine.adoptFormerPlayerTeam(
            teamId = teamId, season = 2026,
            finance = TeamFinanceState(budget = 20_000_000L),
            teamFacilities = TeamFacilitiesState(FacilityType.values().associateWith { if (it == FacilityType.MARKETING) 2 else 0 })
        )
        val firstCredit = engine.applyWeeklyCommercialRevenue(teamId, 2026, 1).finance.budget
        val repeatedCredit = engine.applyWeeklyCommercialRevenue(teamId, 2026, 1).finance.budget
        assertTrue(firstCredit > 20_000_000L)
        assertEquals(firstCredit, repeatedCredit)
        val restored = AITeamFinancialEngine(seed = 622).also { it.restoreSnapshot(engine.exportSnapshot()) }
        assertEquals(firstCredit, restored.applyWeeklyCommercialRevenue(teamId, 2026, 1).finance.budget)
    }
}
