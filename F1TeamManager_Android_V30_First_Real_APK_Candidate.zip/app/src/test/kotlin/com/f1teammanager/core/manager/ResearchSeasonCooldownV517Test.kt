package com.f1teammanager.core.manager

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertSame

class ResearchSeasonCooldownV517Test {
    @Test
    fun seasonBoundaryClearsCooldownsButPreservesResearchProgress() {
        val project = ResearchProject(
            projectId = "R-2026-52-ENGINE-V5", component = CarComponent.ENGINE, version = 5,
            basePerformance = 48, baseReliability = 59, targetPerformance = 51,
            targetReliability = 61, totalWeeks = 8, remainingWeeks = 3, cost = 10_000_000L,
            startedWeek = 44, focus = ResearchFocus.BALANCED,
            complexity = ResearchComplexity.EXPERIMENTAL, outcome = ResearchOutcome.SUCCESS
        )
        val design = ResearchDesign("D-ENGINE-V4", CarComponent.ENGINE, 4, 48, 59, 2026, 52)
        val before = TeamResearchState(
            activeProjects = listOf(project), completedDesigns = listOf(design),
            cooldownUntil = mapOf(CarComponent.ENGINE to 56, CarComponent.CHASSIS to 54)
        )

        val after = ResearchEngine().clearSeasonBoundaryCooldowns(before)

        assertEquals(emptyMap(), after.cooldownUntil)
        assertEquals(before.activeProjects, after.activeProjects)
        assertEquals(before.completedDesigns, after.completedDesigns)
    }

    @Test
    fun stateWithoutCooldownsIsReturnedUnchanged() {
        val before = TeamResearchState()
        assertSame(before, ResearchEngine().clearSeasonBoundaryCooldowns(before))
    }
}
