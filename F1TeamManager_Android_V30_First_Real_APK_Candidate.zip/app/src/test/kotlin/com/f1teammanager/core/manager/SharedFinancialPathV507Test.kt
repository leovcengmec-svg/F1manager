package com.f1teammanager.core.manager

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SharedFinancialPathV507Test {
    @Test fun playerAndAiInputsUseIdenticalCanonicalRaceSettlement() {
        val sponsor = SponsorContract(
            name = "Patrocinador Teste", upfront = 0L, racePayment = 100_000L,
            pointsBonus = 10_000L, years = 1, minimumReputation = 0, slot = 1,
            qualifyingTarget = 10, qualifyingBonus = 50_000L, raceTarget = 5,
            raceTargetBonus = 75_000L, active = true, races = 10, racesRemaining = 5,
            qualifyingTargetMin = 4, qualifyingTargetMax = 10
        )
        val engine = FinanceEngine()
        val initial = TeamFinanceState(10_000_000L)
        val player = engine.settleRaceFinance(initial, 1, listOf(sponsor), 5, 8, false, 2027, 3, 7)
        val ai = engine.settleRaceFinance(initial, 1, listOf(sponsor), 5, 8, false, 2027, 3, 7)
        assertEquals(player, ai)
        assertTrue(player.raceSettlementKeys.contains("GP_SETTLEMENT:2027:3"))
        assertEquals(1, player.transactions.count { it.contains("Bônus por meta de qualificação") })
        assertFalse(player.transactions.any { it.contains("Bônus por pontos") })
        assertEquals(0L, player.transactions.filter { it.contains("Bônus por pontos") }.size.toLong())
    }

    @Test fun sameSettlementPreventsDuplicateRaceIncomeAndCosts() {
        val sponsor = SponsorContract("Patrocinador", 0, 100_000, 0, 1, 0, active = true)
        val engine = FinanceEngine()
        val first = engine.settleRaceFinance(TeamFinanceState(5_000_000), 1, listOf(sponsor), 20, 0, true, 2027, 4, 0)
        val repeated = engine.settleRaceFinance(first, 1, listOf(sponsor), 20, 0, true, 2027, 4, 0)
        assertEquals(first, repeated)
    }
    @Test fun playerAndAiSponsorshipSigningUseSameCashCreditPath() {
        val engine = FinanceEngine()
        val initial = TeamFinanceState(1_000_000L)
        val player = engine.applySponsorshipUpfrontFinance(initial, 250_000L, "Marca", 2)
        val ai = engine.applySponsorshipUpfrontFinance(initial, 250_000L, "Marca", 2)
        assertEquals(player, ai)
        assertEquals(1_250_000L, player.budget)
        assertTrue(player.transactions.last().contains("Entrada patrocínio: Marca (slot 2)"))
    }

    @Test fun annualEventBudgetAdjustmentRecordsTheSameDeltaForEveryTeam() {
        val engine = FinanceEngine()
        val initial = TeamFinanceState(900_000L)
        val player = engine.applyAnnualEventBudgetFinance(initial, 700_000L, "Evento anual")
        val ai = engine.applyAnnualEventBudgetFinance(initial, 700_000L, "Evento anual")
        assertEquals(player, ai)
        assertEquals(700_000L, player.budget)
        assertEquals(-200_000L, player.seasonExpenses)
    }

    @Test fun sharedDebitNeverPartiallyChargesAnUnaffordableExpense() {
        val engine = FinanceEngine()
        val initial = TeamFinanceState(100_000L)
        val result = engine.applyCashDebitFinance(initial, 150_000L, "Investimento", allowPartial = false)
        assertEquals(initial.budget, result.budget)
        assertEquals(initial.seasonExpenses, result.seasonExpenses)
        assertTrue(result.transactions.last().contains("BLOQUEADO/INSUFICIENTE"))
    }

    @Test fun sharedDebitChargesTheFullAmountWhenAffordable() {
        val engine = FinanceEngine()
        val result = engine.applyCashDebitFinance(TeamFinanceState(200_000L), 150_000L, "Investimento", allowPartial = false)
        assertEquals(50_000L, result.budget)
        assertEquals(150_000L, result.seasonExpenses)
        assertTrue(result.transactions.last().contains("Investimento"))
    }

    @Test fun sharedDebitIsTheSameAccountingPathForAllTeamTypes() {
        val engine = FinanceEngine()
        val initial = TeamFinanceState(25_000_000L)
        val playerResearch = engine.applyCashDebitFinance(initial, 3_000_000L, "P&D asa dianteira")
        val aiResearch = engine.applyCashDebitFinance(initial, 3_000_000L, "P&D asa dianteira")
        assertEquals(playerResearch, aiResearch)
        assertEquals(22_000_000L, playerResearch.budget)
        assertEquals(3_000_000L, playerResearch.seasonExpenses)
    }

    @Test fun sharedDebitDoesNotAllowNegativeCashWhenExpenseIsUnaffordable() {
        val engine = FinanceEngine()
        val initial = TeamFinanceState(2_000_000L)
        val result = engine.applyCashDebitFinance(initial, 3_000_000L, "Fabricação", allowPartial = false)
        assertEquals(2_000_000L, result.budget)
        assertEquals(0L, result.seasonExpenses)
        assertTrue(result.transactions.last().contains("BLOQUEADO/INSUFICIENTE"))
    }

    @Test fun aiDevelopmentReplayUsesSameCashDebitBalanceRule() {
        val engine = FinanceEngine()
        assertEquals(350_000L, FinanceEngine().cashDebitBalance(500_000L, 150_000L))
        assertEquals(100_000L, FinanceEngine().cashDebitBalance(100_000L, 150_000L))
        assertEquals(0L, FinanceEngine().cashDebitBalance(100_000L, 150_000L, allowPartial = true))
        val finance = engine.applyCashDebitFinance(TeamFinanceState(100_000L), 150_000L, "Replay IA", allowPartial = false)
        assertEquals(FinanceEngine().cashDebitBalance(100_000L, 150_000L), finance.budget)
    }

    @Test fun playerAndAiUseSameSeasonClosingLiabilityRule() {
        val engine = FinanceEngine()
        val clear = TeamFinanceState(1_000_000L)
        val unpaidSalary = clear.copy(salaryOutstanding = mapOf("2027:30" to 1_500_000L))
        assertEquals(1_000_000L, engine.effectiveClosingBalance(clear))
        assertEquals(-1_500_000L, engine.effectiveClosingBalance(unpaidSalary))
        assertEquals(false, engine.requiresSeasonEndPenalty(clear))
        assertEquals(true, engine.requiresSeasonEndPenalty(unpaidSalary))
    }

}
