package com.f1teammanager.core.manager

import com.f1teammanager.core.season.WorldDatabase
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class DriverMarketRenewalRealismV618Test {
    @Test fun `expiring renewals can be reconsidered at spaced market checkpoints`() {
        val engine = DriverMarketEngine(6182026)
        var state = engine.initialState(2026)

        val firstMarketWeek = (1..56).first { engine.marketOpen(it, 2026) }
        state = engine.processAiMarketWeek(state, 2026, firstMarketWeek, playerTeamId = -999)
        val evaluatedAtMarketOpen = state.renewalEvaluations.filter { it.startsWith("2026:") }.toSet()
        assertTrue("Market opening should evaluate expiring AI contracts", evaluatedAtMarketOpen.isNotEmpty())

        for (week in (firstMarketWeek + 1)..56) {
            state = engine.processAiMarketWeek(state, 2026, week, playerTeamId = -999)
        }

        val evaluatedAtSeasonEnd = state.renewalEvaluations.filter { it.startsWith("2026:") }.toSet()
        assertTrue("Renewal decisions must be stored with an 8-week checkpoint", evaluatedAtSeasonEnd.all { it.split(':').size == 4 })
        assertTrue("Teams must receive more than one opportunity to reconsider missed renewals", evaluatedAtSeasonEnd.size >= evaluatedAtMarketOpen.size)
        assertTrue("Checkpoint ledger must remain bounded", evaluatedAtSeasonEnd.size <= WorldDatabase.teams.size * 2 * 8)
    }

    @Test fun `AI does not offer a weak expiring driver a renewal when a much stronger free agent is interested`() {
        val engine = DriverMarketEngine(6182027)
        val initial = engine.initialState(2026)
        val expiring = initial.contracts.filter { it.seasonSigned + it.years - 1 == 2026 }
        val target = expiring.maxBy { deal ->
            InitialTeamProfile.strength(WorldDatabase.teams.first { it.id == deal.teamId })
        }
        val freeAgent = engine.freeAgents(initial).maxBy { id -> engine.driverOverallForMarket(id) }
        assertTrue("Test fixture must have an available free agent", freeAgent in engine.freeAgents(initial))

        val attributes = WorldDatabase.allDrivers.associate { driver ->
            driver.id to listOf(driver.speed, driver.qualifying, driver.overtaking, driver.defense, driver.consistency, driver.wet, driver.tyre)
        }.toMutableMap()
        attributes[target.driverId] = List(7) { 42 }
        attributes[freeAgent] = List(7) { 98 }

        val baseDefinition = WorldDatabase.allDrivers.first { it.id == freeAgent }
        val baseOverall = listOf(baseDefinition.speed, baseDefinition.qualifying, baseDefinition.overtaking, baseDefinition.defense, baseDefinition.consistency, baseDefinition.wet, baseDefinition.tyre).average().toInt().coerceAtLeast(1)
        val salaryBenchmark = (engine.salaryFor(freeAgent).toDouble() * 98.0 / baseOverall).toLong().coerceIn(300_000L, 60_000_000L)
        val offeredSalary = (salaryBenchmark * 1.15).toLong()
        val candidateInterest = engine.interestScore(
            initial, freeAgent, target.teamId, offeredSalary, DriverTeamRole.EQUAL, 2026,
            driverAttributes = attributes
        )
        assertTrue("The alternative must be realistically interested for this regression", candidateInterest >= 70)

        val firstMarketWeek = (1..56).first { engine.marketOpen(it, 2026) }
        val afterMarketOpen = engine.processAiMarketWeek(
            initial, 2026, firstMarketWeek, playerTeamId = -999, driverAttributes = attributes
        )
        assertFalse(
            "The team must pursue the clear upgrade rather than send a renewal to its weak incumbent",
            afterMarketOpen.pending.any {
                it.driverId == target.driverId && it.fromTeamId == target.teamId && it.toTeamId == target.teamId &&
                    it.seasonTarget == 2027
            }
        )
    }
}
