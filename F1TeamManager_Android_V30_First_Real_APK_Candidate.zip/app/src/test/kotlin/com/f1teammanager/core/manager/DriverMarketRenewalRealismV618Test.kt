package com.f1teammanager.core.manager

import com.f1teammanager.core.season.WorldDatabase
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class DriverMarketRenewalRealismV618Test {
    @Test fun `each expiring driver receives one late-season renewal evaluation`() {
        val engine = DriverMarketEngine(6182026)
        var state = engine.initialState(2026)
        val firstMarketWeek = (1..56).first { engine.marketOpen(it, 2026) }
        state = engine.processAiMarketWeek(state, 2026, firstMarketWeek, playerTeamId = -999)
        assertTrue("Renewal decisions must not pre-empt the early transfer window", state.renewalEvaluations.none { it.startsWith("2026:") })

        for (week in (firstMarketWeek + 1)..56) {
            state = engine.processAiMarketWeek(state, 2026, week, playerTeamId = -999)
        }

        val keys = state.renewalEvaluations.filter { it.startsWith("2026:") }
        assertTrue("Expiring teams must still evaluate renewals before rollover", keys.isNotEmpty())
        assertTrue("New seasonal keys identify one final evaluation", keys.all { it.endsWith(":FINAL") })
        assertTrue("A pilot cannot be evaluated more than once by the same team in a season", keys.distinct().size == keys.size)
        assertTrue("The ledger remains bounded", keys.size <= WorldDatabase.teams.size * 2)
    }

    @Test fun `a stronger interested candidate blocks an incumbent renewal`() {
        val engine = DriverMarketEngine(6182027)
        val initial = engine.initialState(2026)
        val expiring = initial.contracts.filter { it.seasonSigned + it.years - 1 == 2026 }
        val target = expiring.maxBy { deal -> InitialTeamProfile.strength(WorldDatabase.teams.first { it.id == deal.teamId }) }
        val freeAgent = engine.freeAgents(initial).maxBy { id -> engine.driverOverallForMarket(id) }
        assertTrue(freeAgent in engine.freeAgents(initial))

        val attributes = WorldDatabase.allDrivers.associate { driver ->
            driver.id to listOf(driver.speed, driver.qualifying, driver.overtaking, driver.defense, driver.consistency, driver.wet, driver.tyre)
        }.toMutableMap()
        attributes[target.driverId] = List(7) { 42 }
        attributes[freeAgent] = List(7) { 98 }

        val baseDefinition = WorldDatabase.allDrivers.first { it.id == freeAgent }
        val baseOverall = listOf(baseDefinition.speed, baseDefinition.qualifying, baseDefinition.overtaking, baseDefinition.defense, baseDefinition.consistency, baseDefinition.wet, baseDefinition.tyre).average().toInt().coerceAtLeast(1)
        val salaryBenchmark = (engine.salaryFor(freeAgent).toDouble() * 98.0 / baseOverall).toLong().coerceIn(300_000L, 60_000_000L)
        val candidateInterest = engine.interestScore(initial, freeAgent, target.teamId, (salaryBenchmark * 1.15).toLong(), DriverTeamRole.EQUAL, 2026, driverAttributes = attributes)
        assertTrue(candidateInterest >= 70)

        var afterOffers = initial
        for (week in 21..40) afterOffers = engine.processAiMarketWeek(afterOffers, 2026, week, playerTeamId = -999, driverAttributes = attributes)
        assertFalse(
            "The team must not send a renewal when a much stronger, interested driver is available",
            afterOffers.pending.any { it.driverId == target.driverId && it.fromTeamId == target.teamId && it.toTeamId == target.teamId && it.seasonTarget == 2027 }
        )
    }
}
