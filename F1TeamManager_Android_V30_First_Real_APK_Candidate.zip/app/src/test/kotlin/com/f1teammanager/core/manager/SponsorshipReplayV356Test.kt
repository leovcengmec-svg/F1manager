package com.f1teammanager.core.manager

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SponsorshipReplayV356Test {
    @Test fun sameRoundDoesNotConsumeContractTwiceAfterSnapshotRestore() {
        val teamId = WorldDatabase.teams.first().id
        val firstEngine = TeamSponsorshipEngine(seed = 356)
        val before = firstEngine.forTeam(teamId, 2027)
        val afterFirst = firstEngine.advanceRace(teamId, 2027, 4)
        assertEquals(before.sponsors.map { it.racesRemaining - 1 }, afterFirst.sponsors.map { it.racesRemaining })

        val restored = TeamSponsorshipEngine(seed = 356)
        restored.restoreSnapshot(firstEngine.exportSnapshot())
        val afterReplay = restored.advanceRace(teamId, 2027, 4)

        assertEquals(afterFirst, afterReplay)
        assertTrue("A duplicate replay must not emit new contract events", restored.events().isEmpty())
    }

    @Test fun nextRoundStillAdvancesContractExactlyOnce() {
        val teamId = WorldDatabase.teams.first().id
        val engine = TeamSponsorshipEngine(seed = 356)
        val afterRoundFour = engine.advanceRace(teamId, 2027, 4)
        val afterRoundFive = engine.advanceRace(teamId, 2027, 5)
        assertEquals(afterRoundFour.sponsors.map { (it.racesRemaining - 1).coerceAtLeast(0) }, afterRoundFive.sponsors.map { it.racesRemaining })
        assertEquals(afterRoundFive, engine.advanceRace(teamId, 2027, 5))
    }
}
