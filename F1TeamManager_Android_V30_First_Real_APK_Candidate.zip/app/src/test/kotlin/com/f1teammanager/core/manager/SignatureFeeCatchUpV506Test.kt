package com.f1teammanager.core.manager

/** Regression contract: an unpaid signing-fee installment remains due and is caught up later. */
object SignatureFeeCatchUpV506Test {
    @JvmStatic fun main(args: Array<String>) {
        val registered = SignatureFeeAccounting.register(
            TeamFinanceState(budget = 0L),
            fee = 300L,
            description = "Taxa de contratação — temporada 2026",
            targetSeason = 2026,
            startRound = 1,
            installmentCount = 3
        )
        val noCash = SignatureFeeAccounting.recognizeForRace(registered, 2026, 1)
        check(noCash.budget == 0L)
        check(noCash.signatureFeeSchedules.single().paidRounds.isEmpty())

        // A later income must not cause the missed GP1 installment to disappear.
        val funded = noCash.transact(100L, "Receita de teste")
        val caughtUp = SignatureFeeAccounting.recognizeForRace(funded, 2026, 2)
        check(caughtUp.budget == 0L) { "The missed €100 installment should be paid when funds arrive" }
        check(1 in caughtUp.signatureFeeSchedules.single().paidRounds)
        check(2 in caughtUp.signatureFeeSchedules.single().paidRounds)

        // Replaying the same GP cannot charge an installment twice.
        val replay = SignatureFeeAccounting.recognizeForRace(caughtUp, 2026, 2)
        check(replay.budget == caughtUp.budget)
        check(replay.signatureFeeSchedules.single().paidRounds == caughtUp.signatureFeeSchedules.single().paidRounds)
        println("PASS: overdue signing-fee installments persist, catch up, and are idempotent")
    }
}
