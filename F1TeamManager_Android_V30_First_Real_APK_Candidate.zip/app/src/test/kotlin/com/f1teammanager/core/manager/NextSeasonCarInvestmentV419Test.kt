package com.f1teammanager.core.manager

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class NextSeasonCarInvestmentV419Test {
    @Test fun referenceInvestmentAdaptsToCurrentCarClass() {
        val engine = CarDevelopmentEngine()
        val weak = TeamCarState(aerodynamics = 55, chassis = 55, engine = 55, reliability = 55,
            frontWing = 55, rearWing = 55, brakes = 55, electricPowerUnit = 55)
        val strong = TeamCarState(aerodynamics = 94, chassis = 94, engine = 94, reliability = 94,
            frontWing = 94, rearWing = 94, brakes = 94, electricPowerUnit = 94)
        assertTrue(engine.performanceClass(strong).referenceInvestment > engine.performanceClass(weak).referenceInvestment)
    }

    @Test fun referenceInvestmentForecastsMaintainingCurrentClass() {
        val engine = CarDevelopmentEngine()
        val car = TeamCarState(aerodynamics = 65, chassis = 65, engine = 65, reliability = 65,
            frontWing = 65, rearWing = 65, brakes = 65, electricPowerUnit = 65,
            nextSeasonInvestment = 57_500_000L)
        val state = TeamManagerState(car = car, finance = TeamFinanceState(100_000_000L))
        val forecast = engine.nextSeasonForecast(state)
        assertEquals(CarPerformanceClass.AVERAGE, forecast.currentClass)
        assertEquals(57_500_000L, forecast.referenceInvestment)
        assertEquals(CarPerformanceClass.AVERAGE, forecast.projectedClass)
    }

    @Test fun referenceInvestmentUsesRequestedEightToOneHundredFiftyMillionRange() {
        assertEquals(8_000_000L, CarPerformanceClass.BACK_OF_GRID.referenceInvestment)
        assertEquals(150_000_000L, CarPerformanceClass.TITLE_CONTENDER.referenceInvestment)
        val engine = CarDevelopmentEngine()
        val titleCar = TeamCarState(aerodynamics = 95, chassis = 95, engine = 95, reliability = 95,
            frontWing = 95, rearWing = 95, brakes = 95, electricPowerUnit = 95)
        assertEquals(150_000_000L, engine.nextSeasonInvestmentCap(titleCar))
    }

    @Test fun overallMapsToClassAndReferenceInvestmentAcrossFortyToOneHundred() {
        val engine = CarDevelopmentEngine()
        fun car(overall: Int) = TeamCarState(
            aerodynamics = overall, chassis = overall, engine = overall, reliability = overall,
            frontWing = overall, rearWing = overall, brakes = overall, electricPowerUnit = overall
        )
        val expectedClasses = listOf(
            40 to CarPerformanceClass.BACK_OF_GRID,
            49 to CarPerformanceClass.BACK_OF_GRID,
            50 to CarPerformanceClass.POOR,
            59 to CarPerformanceClass.POOR,
            60 to CarPerformanceClass.AVERAGE,
            69 to CarPerformanceClass.AVERAGE,
            70 to CarPerformanceClass.GOOD,
            79 to CarPerformanceClass.GOOD,
            80 to CarPerformanceClass.EXCELLENT,
            89 to CarPerformanceClass.EXCELLENT,
            90 to CarPerformanceClass.TITLE_CONTENDER,
            100 to CarPerformanceClass.TITLE_CONTENDER
        )
        expectedClasses.forEach { (overall, expectedClass) ->
            val actual = engine.performanceClass(car(overall))
            assertEquals("Overall $overall", expectedClass, actual)
            assertEquals("Overall calculado", overall, engine.carOverall(car(overall)))
        }
        assertEquals(8_000_000L, engine.referenceInvestmentForOverall(40))
        assertEquals(25_000_000L, engine.referenceInvestmentForOverall(50))
        assertEquals(45_000_000L, engine.referenceInvestmentForOverall(60))
        assertEquals(70_000_000L, engine.referenceInvestmentForOverall(70))
        assertEquals(110_000_000L, engine.referenceInvestmentForOverall(80))
        assertEquals(150_000_000L, engine.referenceInvestmentForOverall(100))
        assertTrue(engine.referenceInvestmentForOverall(49) > engine.referenceInvestmentForOverall(40))
        assertTrue(engine.referenceInvestmentForOverall(49) < engine.referenceInvestmentForOverall(50))
        assertTrue(engine.referenceInvestmentForOverall(99) < engine.referenceInvestmentForOverall(100))
        val allReferences = (40..100).map(engine::referenceInvestmentForOverall)
        assertEquals(61, allReferences.distinct().size)
        assertTrue(allReferences.zipWithNext().all { (current, next) -> next > current })
    }


    @Test fun approvedReferenceTableMatchesEveryOverallFrom40Through100() {
        val engine = CarDevelopmentEngine()
        val expected = listOf(
            8_000_000L, 9_000_000L, 10_000_000L, 12_000_000L, 13_000_000L, 14_000_000L, 16_000_000L, 18_000_000L, 20_000_000L, 22_000_000L, 25_000_000L, 27_000_000L, 29_000_000L, 31_000_000L, 33_000_000L, 35_000_000L, 37_000_000L, 39_000_000L, 41_000_000L, 43_000_000L, 45_000_000L, 47_000_000L, 49_000_000L, 51_000_000L, 54_000_000L, 56_000_000L, 59_000_000L, 62_000_000L, 65_000_000L, 67_000_000L, 70_000_000L, 73_000_000L, 76_000_000L, 79_000_000L, 83_000_000L, 86_000_000L, 90_000_000L, 95_000_000L, 100_000_000L, 105_000_000L, 110_000_000L, 112_000_000L, 114_000_000L, 116_000_000L, 118_000_000L, 120_000_000L, 122_000_000L, 124_000_000L, 126_000_000L, 128_000_000L, 130_000_000L, 132_000_000L, 134_000_000L, 136_000_000L, 138_000_000L, 140_000_000L, 142_000_000L, 144_000_000L, 146_000_000L, 148_000_000L, 150_000_000L
        )
        assertEquals("A tabela aprovada precisa conter 61 valores", 61, expected.size)
        (40..100).forEachIndexed { index, overall ->
            assertEquals("Investimento de referência para Overall $overall", expected[index], engine.referenceInvestmentForOverall(overall))
            assertEquals("Investimento de referência integral deve gerar 5 passos no Overall $overall", 5,
                engine.nextSeasonInvestmentSteps(overall, expected[index]))
        }
        assertEquals("Overall 42 deve usar €10M, não €11,4M", 10_000_000L, engine.referenceInvestmentForOverall(42))
        assertEquals("Overall 53 deve usar €31M", 31_000_000L, engine.referenceInvestmentForOverall(53))
    }

    @Test fun nextSeasonTransitionUsesExactOverallReferenceForActualInvestmentEffect() {
        val engine = CarDevelopmentEngine()
        // The same €8M is a full reference at Overall 40, but well below the
        // reference at Overall 49. The real season-transition calculation must
        // therefore apply different effects, not merely show different UI text.
        assertEquals(5, engine.nextSeasonInvestmentSteps(40, 8_000_000L))
        assertEquals(2, engine.nextSeasonInvestmentSteps(49, 8_000_000L))
        assertEquals(0, engine.nextSeasonInvestmentSteps(100, 0L))

        val lowOverallCar = TeamCarState(
            aerodynamics = 40, chassis = 40, engine = 40, reliability = 40,
            frontWing = 40, rearWing = 40, brakes = 40, electricPowerUnit = 40,
            nextSeasonInvestment = 8_000_000L
        )
        val state = TeamManagerState(car = lowOverallCar, finance = TeamFinanceState(10_000_000L))
        val next = engine.startNextSeason(state, 2027)
        assertEquals(2027, next.season)
        assertEquals(0L, next.car.nextSeasonInvestment)
        assertTrue(next.history.last().contains("investimento €8000000 aplicado"))
    }

    @Test fun nextSeasonReferenceIsMonotonicForEveryOverallAndTransitionUsesSameMapping() {
        val engine = CarDevelopmentEngine()
        val refs = (40..100).map(engine::referenceInvestmentForOverall)
        assertEquals(61, refs.distinct().size)
        assertTrue(refs.zipWithNext().all { (a, b) -> b > a })
        (40..100).forEach { overall ->
            val ref = engine.referenceInvestmentForOverall(overall)
            assertEquals(5, engine.nextSeasonInvestmentSteps(overall, ref))
        }
    }

    @Test fun investmentBelowReferenceProjectsLowerClass() {
        val engine = CarDevelopmentEngine()
        val car = TeamCarState(aerodynamics = 72, chassis = 72, engine = 72, reliability = 72,
            frontWing = 72, rearWing = 72, brakes = 72, electricPowerUnit = 72,
            nextSeasonInvestment = 5_000_000L)
        val state = TeamManagerState(car = car, finance = TeamFinanceState(100_000_000L))
        assertTrue(engine.nextSeasonForecast(state).projectedClass.ordinal < CarPerformanceClass.AVERAGE.ordinal)
    }
}
