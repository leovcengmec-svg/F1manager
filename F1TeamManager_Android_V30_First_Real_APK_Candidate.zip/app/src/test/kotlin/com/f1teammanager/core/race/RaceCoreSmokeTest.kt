package com.f1teammanager.core.race

fun main() {
    val circuit = RaceCircuit(1, "Teste", 20, 90000, 1.0, 0.75)
    val drivers = (1..20).map { i ->
        RaceParticipant(i, "D$i", i, "T$i", 70 + i % 25, 70 + i % 25, 70, 70, 75, 70 + i % 20, 80, 70, 70, 70, 90)
    }
    val a = RaceWeekendEngine(42).race(drivers, circuit)
    val b = RaceWeekendEngine(42).race(drivers, circuit)
    check(a == b) { "Seed não determinística" }
    check(a.classification.size == 20)
    check(a.classification.count { it.status == "FINISHED" || it.status == "DNF" } == 20)
    check(a.points.values.sum() >= 0)
    check(a.classification.count { it.status == "DNF" } >= 0)
    println("V5 SMOKE TEST OK")
    println("grid/result: ${a.classification.take(5)}")
    println("events=${a.events.size} safety=${a.safetyCarLaps} vsc=${a.vscLaps}")
}
