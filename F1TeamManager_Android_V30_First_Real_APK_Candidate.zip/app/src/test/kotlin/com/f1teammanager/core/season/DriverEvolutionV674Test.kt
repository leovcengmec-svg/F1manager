package com.f1teammanager.core.season

import kotlin.random.Random

/** V674 regression checks for the 80-driver target scale and driver-safe progression. */
fun main() {
    val inputs = (0 until DriverEvolutionEngine.DRIVER_GRID_SIZE).map { index ->
        val teamIndex = index / 2
        val teammateSlot = index % 2
        val carStrength = (100.0 - teamIndex * 1.35).coerceAtLeast(40.0)
        val overall = (96 - teamIndex / 2 - teammateSlot * 2).coerceAtLeast(55)
        DriverEvolutionEngine.TargetInput(
            driverId = index + 1,
            carStrength = carStrength,
            driverOverall = overall,
            qualifyingStrength = (overall + if (teammateSlot == 0) 2 else -2).coerceIn(40, 100)
        )
    }
    val targets = DriverEvolutionEngine.buildIndividualTargets(inputs)
    check(targets.size == 80) { "A grade de metas não contém os 80 pilotos" }
    check(targets.values.all {
        it.championshipPosition in 1..80 && it.qualifyingPosition in 1..80 && it.racePosition in 1..80
    }) { "Foi gerada meta fora da escala 1–80" }
    check(targets.values.map { it.qualifyingPosition }.toSet().size == 80)
    check(targets.values.map { it.racePosition }.toSet().size == 80)
    check(targets.getValue(79).racePosition >= 60 && targets.getValue(80).racePosition >= 60) {
        "Pilotos de equipe muito fraca não receberam metas no fim da escala de 80 pilotos"
    }

    val target = DriverEvolutionEngine.Target(40, 40, 40)
    check(DriverEvolutionEngine.racePositionForEvolution(target, 80, "DNF • FALHA • MOTOR") == 40) {
        "Falha mecânica foi contabilizada como desempenho ruim do piloto"
    }
    check(DriverEvolutionEngine.racePositionForEvolution(target, 80, "DNF • PANE ELÉTRICA • MGU-K - ERS") == 40)
    check(DriverEvolutionEngine.racePositionForEvolution(target, 80, "DNF • ACIDENTE") == 80) {
        "O tratamento de DNF neutralizou indevidamente um acidente causado pelo piloto"
    }
    check(DriverEvolutionEngine.racePositionForEvolution(target, 80, "DNF • ACIDENTE • COLISÃO") == 40) {
        "Uma colisão sofrida por outro piloto foi penalizada como falha de desempenho"
    }

    fun ratings(driver: DriverDefinition) = intArrayOf(
        driver.speed, driver.qualifying, driver.overtaking, driver.defense,
        driver.consistency, driver.wet, driver.tyre
    )
    val start = DriverDefinition(
        id = 900,
        name = "Piloto de equipe fraca",
        teamId = 40,
        speed = 78, qualifying = 78, overtaking = 78, defense = 78,
        consistency = 78, wet = 78, tyre = 78,
        driverClass = "Médio", evolution = "Auge moderado", potentialOverall = 88
    )
    var driver = start
    var bank = 0.0
    var seasonGains = IntArray(7)
    repeat(60) { gp ->
        if (gp == 30) seasonGains = IntArray(7)
        val performance = DriverEvolutionEngine.gpPerformanceIndex(
            DriverEvolutionEngine.Target(80, 80, 80), qualifyingPosition = 40, racePosition = 40
        )
        val tick = DriverEvolutionEngine.applyPerformanceTick(
            driver = driver,
            performanceIndex = performance,
            currentBank = bank,
            annualGains = seasonGains,
            random = Random(674 + gp)
        )
        driver = tick.driver
        bank = tick.bank
    }
    check(DriverProfileCatalog.overall(ratings(driver)) >= DriverProfileCatalog.overall(ratings(start)) + 2) {
        "Piloto de equipe fraca, com desempenho muito acima da meta, não apresentou evolução perceptível em duas temporadas"
    }
    check(DriverEvolutionEngine.classGrowthFactor("Médio", 80) >= 0.60) {
        "O teto de classe voltou a bloquear mais de 40% do crescimento"
    }
    check(DriverProfileCatalog.overall(ratings(driver)) <= start.potentialOverall) {
        "O piloto ultrapassou seu potencial individual"
    }

    println("DriverEvolutionV674Test: PASS")
}
