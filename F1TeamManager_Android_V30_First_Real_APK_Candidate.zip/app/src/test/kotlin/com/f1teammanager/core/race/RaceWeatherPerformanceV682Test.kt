package com.f1teammanager.core.race

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class RaceWeatherPerformanceV682Test {
    private fun participant(wetSkill: Int, consistency: Int) = RaceParticipant(
        driverId = 1,
        driverName = "Test Driver",
        teamId = 1,
        teamName = "Test Team",
        driverSpeed = 50,
        qualifying = 50,
        overtaking = 50,
        defense = 50,
        consistency = consistency,
        enginePerformance = 50,
        wetSkill = wetSkill
    )

    @Test
    fun `out of range imported wet skill is clamped to supported limits`() {
        val belowRange = RaceWeatherPerformance.rainPenaltyMs(
            participant(-20, 50), Tyre.WET, Weather.HEAVY_RAIN
        )
        val minimum = RaceWeatherPerformance.rainPenaltyMs(
            participant(0, 50), Tyre.WET, Weather.HEAVY_RAIN
        )
        val aboveRange = RaceWeatherPerformance.rainPenaltyMs(
            participant(120, 100), Tyre.WET, Weather.HEAVY_RAIN
        )
        val maximum = RaceWeatherPerformance.rainPenaltyMs(
            participant(100, 100), Tyre.WET, Weather.HEAVY_RAIN
        )
        assertEquals(minimum, belowRange)
        assertEquals(maximum, aboveRange)
    }

    @Test
    fun `out of range consistency is clamped to the same minimum as driver influence`() {
        val invalid = RaceWeatherPerformance.rainPenaltyMs(
            participant(60, 0), Tyre.INTERMEDIATE, Weather.MEDIUM_RAIN
        )
        val bounded = RaceWeatherPerformance.rainPenaltyMs(
            participant(60, 40), Tyre.INTERMEDIATE, Weather.MEDIUM_RAIN
        )
        assertEquals(bounded, invalid)
    }

    @Test
    fun `stronger wet skill does not increase rain pace penalty`() {
        val lowSkill = RaceWeatherPerformance.rainPenaltyMs(
            participant(30, 60), Tyre.WET, Weather.HEAVY_RAIN
        )
        val highSkill = RaceWeatherPerformance.rainPenaltyMs(
            participant(90, 90), Tyre.WET, Weather.HEAVY_RAIN
        )
        assertTrue("Higher wet skill should reduce the penalty", highSkill < lowSkill)
    }

    @Test
    fun `dry and cloudy conditions have no rain penalty`() {
        val p = participant(10, 40)
        assertEquals(0L, RaceWeatherPerformance.rainPenaltyMs(p, Tyre.SOFT, Weather.DRY))
        assertEquals(0L, RaceWeatherPerformance.rainPenaltyMs(p, Tyre.SOFT, Weather.CLOUDY))
    }
}
