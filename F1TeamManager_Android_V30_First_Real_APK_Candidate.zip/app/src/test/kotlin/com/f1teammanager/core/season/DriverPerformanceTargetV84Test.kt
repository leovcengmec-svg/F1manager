package com.f1teammanager.core.season

import com.f1teammanager.core.manager.*

fun main() {
    val team = WorldDatabase.teams.first()
    val market = DriverMarketEngine(20261003).initialState(2026)
    val car = TeamCarState(com.f1teammanager.core.manager.InitialTeamProfile.strength(team), team.chassis, team.engine, team.reliability,
        frontWing = team.frontWing, rearWing = team.rearWing, brakes = team.brakes,
        electricPowerUnit = team.electricPowerUnit)
    // Simulate a V725 save: 80 active driver targets plus free-agent placeholders,
    // but no V726 car-only contract version. The first GP must rebuild the blended map.
    val legacyBlendedTargets = WorldDatabase.allDrivers.associate { driver ->
        driver.id to (((driver.id % 80) + 1) * 100 + (((driver.id * 3) % 80) + 1))
    }
    var manager = TeamManagerState(season=2026, round=1, playerTeamId=team.id, car=car,
        finance=TeamFinanceState(35_000_000), driverMarket=market,
        driverEvolutionSeasonTargets=legacyBlendedTargets,
        driverEvolutionSeasonTargetsVersion=0)
    val engine = ManagerSeasonEngine(20261003)
    var season = SeasonState()
    val first = engine.runRound(manager, season)
    manager = first.state
    season = first.season
    check(manager.driverEvolutionSeasonTargets.size == WorldDatabase.allDrivers.size)
    check(manager.driverEvolutionSeasonTargetsVersion == 1) { "V725 blended goals were not migrated to V726 car-only targets" }
    val activeByTeam = market.contracts.filter { it.activeIn(manager.season) }.groupBy { it.teamId }
    activeByTeam.values.forEach { teammates ->
        if (teammates.size == 2) {
            val first = manager.driverEvolutionSeasonTargets.getValue(teammates[0].driverId)
            val second = manager.driverEvolutionSeasonTargets.getValue(teammates[1].driverId)
            check(first == second) { "Teammates must receive the same car-only goal" }
            val qualifying = first / 100
            val race = first % 100
            check(qualifying == race && qualifying in 1..80) {
                "Qualifying/race goals must share the car-only midpoint: $first"
            }
        }
    }
    val frozen = manager.driverEvolutionSeasonTargets
    repeat(4) {
        val out = engine.runRound(manager, season)
        manager = out.state
        season = out.season
    }
    check(manager.driverEvolutionSeasonTargets == frozen) { "Metas mudaram durante a temporada" }
    check(manager.driverEvolutionSeasonTargetsVersion == 1) { "The target contract version changed mid-season" }
    check(manager.driverEvolutionPhases.values.all { it in setOf("GROWING","REGRESSION","RECOVERY") })
    println("DriverPerformanceTargetV84Test: PASS")
}
