package com.f1teammanager.core.season

import com.f1teammanager.core.manager.*

fun main() {
    val team = WorldDatabase.teams.first()
    val market = DriverMarketEngine(20261003).initialState(2026)
    val car = TeamCarState(team.baseCar, team.chassis, team.engine, team.reliability,
        frontWing = team.frontWing, rearWing = team.rearWing, brakes = team.brakes,
        electricPowerUnit = team.electricPowerUnit)
    var manager = TeamManagerState(season=2026, round=1, playerTeamId=team.id, car=car,
        finance=TeamFinanceState(35_000_000), driverMarket=market)
    val engine = ManagerSeasonEngine(20261003)
    var season = SeasonState()
    val first = engine.runRound(manager, season)
    manager = first.state
    season = first.season
    check(manager.driverEvolutionSeasonTargets.size == 100)
    check(manager.driverEvolutionSeasonTargets.values.all { it in 1..80 })
    val frozen = manager.driverEvolutionSeasonTargets
    repeat(4) {
        val out = engine.runRound(manager, season)
        manager = out.state
        season = out.season
    }
    check(manager.driverEvolutionSeasonTargets == frozen) { "Metas mudaram durante a temporada" }
    check(manager.driverEvolutionPhases.values.all { it in setOf("GROWING","REGRESSION","RECOVERY") })
    println("DriverPerformanceTargetV84Test: PASS")
}
