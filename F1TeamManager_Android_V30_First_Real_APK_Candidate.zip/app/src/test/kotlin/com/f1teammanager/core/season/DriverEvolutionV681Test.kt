package com.f1teammanager.core.season

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class DriverEvolutionV681Test {
    private fun grid(strongPairAtTeam22: Boolean = false): List<DriverEvolutionEngine.TargetInput> =
        (1..40).flatMap { teamId ->
            val car = 100.0 - (teamId - 1) * 1.0
            val skills = if (strongPairAtTeam22 && teamId == 22) listOf(95, 65) else listOf(80, 80)
            skills.mapIndexed { index, skill ->
                DriverEvolutionEngine.TargetInput(
                    driverId = (teamId - 1) * 2 + index + 1,
                    teamId = teamId,
                    carStrength = car,
                    driverOverall = skill,
                    qualifyingStrength = skill
                )
            }
        }

    @Test
    fun constructorRankingMapsToTwoAdjacentDriverSlotsOnTheEightyDriverScale() {
        val targets = DriverEvolutionEngine.buildIndividualTargets(grid())
        assertEquals(80, targets.size)
        assertEquals(1, targets.getValue(1).racePosition)
        assertEquals(2, targets.getValue(2).racePosition)
        assertEquals(19, targets.getValue(19).racePosition)
        assertEquals(20, targets.getValue(20).racePosition)
        assertEquals(43, targets.getValue(43).racePosition)
        assertEquals(44, targets.getValue(44).racePosition)
        assertEquals(59, targets.getValue(59).racePosition)
        assertEquals(60, targets.getValue(60).racePosition)
        assertEquals(79, targets.getValue(79).racePosition)
        assertEquals(80, targets.getValue(80).racePosition)
    }

    @Test
    fun driverSkillOnlyMovesItsOwnExpectationWithinThreePlaces() {
        val targets = DriverEvolutionEngine.buildIndividualTargets(grid(strongPairAtTeam22 = true))
        val stronger = targets.getValue(43)
        val weaker = targets.getValue(44)
        assertTrue(stronger.racePosition < weaker.racePosition)
        assertTrue(stronger.racePosition in 40..46)
        assertTrue(weaker.racePosition in 41..47)
    }

    @Test
    fun finishingP35WithA22ndRankedCarIsClearlyAboveTheP43P44Expectation() {
        val target = DriverEvolutionEngine.Target(44, 44, 44)
        val index = DriverEvolutionEngine.gpPerformanceIndex(target, qualifyingPosition = 35, racePosition = 35)
        assertTrue("P35 should be an above-expectation result; index=$index", index >= 115.0)
        assertTrue(DriverEvolutionEngine.performanceEvolutionRate(index) > 1.0)
    }

    @Test
    fun toleranceIsThreePositionsThroughoutTheDriverGrid() {
        listOf(1, 10, 25, 44, 60, 80).forEach { center ->
            val target = DriverEvolutionEngine.Target(center, center, center)
            assertEquals((center - 3).coerceAtLeast(1), target.raceMinPosition)
            assertEquals((center + 3).coerceAtMost(80), target.raceMaxPosition)
        }
    }

    @Test
    fun invalidConstructorGridCannotBeMistakenForAnEightyDriverGrid() {
        assertTrue(DriverEvolutionEngine.buildIndividualTargets(grid().dropLast(1)).isEmpty())
        val oneDriverMissingFromATeam = grid().map { input ->
            if (input.teamId == 22 && input.driverId == 44) input.copy(teamId = 21) else input
        }
        assertTrue(DriverEvolutionEngine.buildIndividualTargets(oneDriverMissingFromATeam).isEmpty())
    }
}
