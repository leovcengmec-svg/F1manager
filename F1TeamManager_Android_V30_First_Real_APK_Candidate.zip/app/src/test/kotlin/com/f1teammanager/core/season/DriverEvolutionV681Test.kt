package com.f1teammanager.core.season

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class DriverEvolutionV681Test {
    private fun grid(carStrengthOverrides: Map<Int, Double> = emptyMap()): List<DriverEvolutionEngine.TargetInput> =
        (1..40).flatMap { teamId ->
            val car = carStrengthOverrides[teamId] ?: (100.0 - (teamId - 1) * 1.0)
            listOf(
                DriverEvolutionEngine.TargetInput((teamId - 1) * 2 + 1, teamId, car),
                DriverEvolutionEngine.TargetInput((teamId - 1) * 2 + 2, teamId, car)
            )
        }

    @Test
    fun constructorRankingMapsToSharedMidpointOnTheEightyDriverScale() {
        val targets = DriverEvolutionEngine.buildIndividualTargets(grid())
        assertEquals(80, targets.size)
        assertEquals(2, targets.getValue(1).racePosition)
        assertEquals(2, targets.getValue(2).racePosition)
        assertEquals(20, targets.getValue(19).racePosition)
        assertEquals(20, targets.getValue(20).racePosition)
        assertEquals(44, targets.getValue(43).racePosition)
        assertEquals(44, targets.getValue(44).racePosition)
        assertEquals(60, targets.getValue(59).racePosition)
        assertEquals(60, targets.getValue(60).racePosition)
        assertEquals(80, targets.getValue(79).racePosition)
        assertEquals(80, targets.getValue(80).racePosition)
        targets.values.forEach { target ->
            assertEquals(target.qualifyingPosition, target.racePosition)
            assertEquals(target.qualifyingPosition, target.championshipPosition)
        }
    }

    @Test
    fun sameCarTeammatesCannotReceiveDifferentGoals() {
        val targets = DriverEvolutionEngine.buildIndividualTargets(grid())
        (1..40).forEach { teamId ->
            val first = targets.getValue((teamId - 1) * 2 + 1)
            val second = targets.getValue((teamId - 1) * 2 + 2)
            assertEquals(first, second)
        }
    }

    @Test
    fun onlyCarStrengthChangesTheTargetsAndMovesBothTeammatesTogether() {
        val baseline = DriverEvolutionEngine.buildIndividualTargets(grid())
        // Move team 22 from P22 to the strongest car without changing either driver.
        val improved = DriverEvolutionEngine.buildIndividualTargets(grid(mapOf(22 to 120.0)))
        val firstDriver = 43
        val secondDriver = 44
        assertEquals(baseline.getValue(firstDriver), baseline.getValue(secondDriver))
        assertEquals(improved.getValue(firstDriver), improved.getValue(secondDriver))
        assertTrue(improved.getValue(firstDriver).racePosition < baseline.getValue(firstDriver).racePosition)
        assertEquals(improved.getValue(firstDriver).qualifyingPosition, improved.getValue(firstDriver).racePosition)
    }

    @Test
    fun finishingP35WithACarExpectationOfP44IsClearlyAboveExpectation() {
        val target = DriverEvolutionEngine.Target(44, 44, 44)
        val index = DriverEvolutionEngine.gpPerformanceIndex(target, qualifyingPosition = 35, racePosition = 35)
        assertTrue("P35 should be an above-expectation result; index=$index", index >= 115.0)
        assertTrue(DriverEvolutionEngine.performanceEvolutionRate(index) > 1.0)
    }

    @Test
    fun toleranceIsThreePositionsThroughoutTheDriverGrid() {
        listOf(2, 10, 25, 44, 60, 80).forEach { center ->
            val target = DriverEvolutionEngine.Target(center, center, center)
            assertEquals((center - 3).coerceAtLeast(1), target.raceMinPosition)
            assertEquals((center + 3).coerceAtMost(80), target.raceMaxPosition)
        }
    }

    @Test
    fun invalidConstructorGridCannotBeMistakenForAnEightyDriverGrid() {
        assertTrue(DriverEvolutionEngine.buildIndividualTargets(grid().dropLast(1)).isEmpty())
        val oneDriverMissingFromATeam = grid().map { input ->
            if (input.teamId == 22 && input.driverId == 44) input.copy(teamId = 21) else input
        }
        assertTrue(DriverEvolutionEngine.buildIndividualTargets(oneDriverMissingFromATeam).isEmpty())
    }
}
