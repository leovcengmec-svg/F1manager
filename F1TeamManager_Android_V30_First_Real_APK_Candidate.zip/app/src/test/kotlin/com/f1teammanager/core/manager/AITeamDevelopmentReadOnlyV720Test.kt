package com.f1teammanager.core.manager

import com.f1teammanager.core.season.WorldDatabase
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Before
import org.junit.Test

class AITeamDevelopmentReadOnlyV720Test {
    @Before
    fun setUp() {
        TechnicalInvestmentEngine.resetLiveOverallRegistry()
    }

    @After
    fun tearDown() {
        TechnicalInvestmentEngine.resetLiveOverallRegistry()
    }

    @Test
    fun readOnlyProjectionDoesNotPublishItsGarageToCareerRanking() {
        val team = WorldDatabase.teams.first()
        TechnicalInvestmentEngine.recordLiveOverall(team.id, 98.75)
        val engine = AITeamDevelopmentEngine(
            seed = 720_001,
            regulationSeed = 720_001,
            careerScope = "V720_READ_ONLY_TEST"
        )

        val preview = engine.simulateFinancial(
            team = team,
            elapsedWeeks = 0,
            season = 2026,
            startingBudget = 0L,
            publishLiveOverall = false
        )

        assertNotNull(preview.garage)
        assertEquals(98.75, TechnicalInvestmentEngine.liveOverallGrid()[team.id] ?: -1.0, 0.0001)
    }
}
