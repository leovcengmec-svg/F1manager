package com.f1teammanager.core.season

import kotlin.random.Random
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class DriverCareerCycleV709Test {
    private fun driver(id: Int = 9601, profile: String = "Auge tardio") = DriverDefinition(
        id = id, name = "Cycle probe $id", teamId = 1,
        speed = 80, qualifying = 81, overtaking = 82, defense = 83,
        consistency = 84, wet = 85, tyre = 86,
        driverClass = "Pro", evolution = profile, potentialOverall = 96
    )

    @Test
    fun `age reaches end of cycle then restarts at 18 without retirement`() {
        val d = driver()
        val start = DriverEvolutionEngine.careerStartAge(d)
        val seasonsToReset = 44 - start
        assertEquals(43, DriverEvolutionEngine.careerAge(d, 2026 + seasonsToReset - 1))
        assertEquals(18, DriverEvolutionEngine.careerAge(d, 2026 + seasonsToReset))
        assertEquals(1, DriverEvolutionEngine.careerCycleIndex(d, 2026 + seasonsToReset))
        assertEquals(19, DriverEvolutionEngine.careerAge(d, 2027 + seasonsToReset))
        assertEquals(d.evolution, "Auge tardio")
    }

    @Test
    fun `cycle restart recovers half of age-related loss across all seven attributes`() {
        val d = driver()
        val losses = intArrayOf(4, 7, 6, 2, 8, 5, 9)
        val peaks = intArrayOf(90, 92, 95, 94, 96, 95, 96)
        val tick = DriverEvolutionEngine.applyPerformanceTick(
            driver = d,
            performanceIndex = 85.0,
            currentBank = 0.0,
            annualGains = IntArray(7),
            random = Random(696),
            careerAge = 18,
            currentAgeBank = 0.80,
            currentAgePhysicalLosses = losses,
            currentAgePhysicalPeaks = peaks,
            currentAgeCycleIndex = 0,
            careerCycleIndex = 1
        )
        assertTrue(tick.ageCycleRestarted)
        assertEquals(21, tick.ageRecoveredPoints)
        assertArrayEquals(intArrayOf(82, 85, 85, 84, 88, 87, 91), intArrayOf(tick.driver.speed, tick.driver.qualifying, tick.driver.overtaking, tick.driver.defense, tick.driver.consistency, tick.driver.wet, tick.driver.tyre))
        assertArrayEquals(intArrayOf(2, 3, 3, 1, 4, 3, 4), tick.agePhysicalLosses)
        assertEquals(21, tick.ageCycleRecoveryByAttribute.sum())
        assertEquals("Auge tardio", tick.driver.evolution)
        assertEquals("Pro", tick.driver.driverClass)
        assertEquals(0.0, tick.ageBank, 0.0)
    }


    @Test
    fun `odd age losses are rounded once as an aggregate`() {
        val d = driver(id = 9604).copy(
            speed = 80, qualifying = 81, overtaking = 82, defense = 83,
            consistency = 84, wet = 85, tyre = 86
        )
        val before = intArrayOf(d.speed, d.overtaking, d.defense).sum()
        val tick = DriverEvolutionEngine.applyPerformanceTick(
            driver = d,
            performanceIndex = 85.0,
            currentBank = 0.0,
            annualGains = IntArray(7),
            random = Random(6963),
            careerAge = 18,
            currentAgeBank = 0.0,
            currentAgePhysicalLosses = intArrayOf(1, 0, 1, 1, 0, 0, 0),
            currentAgePhysicalPeaks = intArrayOf(90, 81, 92, 93, 84, 85, 86),
            currentAgeCycleIndex = 0,
            careerCycleIndex = 1
        )

        val after = intArrayOf(tick.driver.speed, tick.driver.overtaking, tick.driver.defense).sum()
        assertEquals(2, tick.ageRecoveredPoints)
        assertEquals(2, after - before)
        assertEquals(1, tick.agePhysicalLosses.sum())
        assertEquals(d.qualifying, tick.driver.qualifying)
        assertEquals(d.consistency, tick.driver.consistency)
        assertEquals(d.wet, tick.driver.wet)
        assertEquals(d.tyre, tick.driver.tyre)
    }

    @Test
    fun `aggregate recovery never exceeds historical peak capacity`() {
        val d = driver(id = 9605).copy(
            speed = 80, qualifying = 81, overtaking = 82, defense = 83,
            consistency = 84, wet = 85, tyre = 86
        )
        val peaks = intArrayOf(81, 81, 82, 84, 84, 85, 86)
        val tick = DriverEvolutionEngine.applyPerformanceTick(
            driver = d,
            performanceIndex = 85.0,
            currentBank = 0.0,
            annualGains = IntArray(7),
            random = Random(6964),
            careerAge = 18,
            currentAgeBank = 0.0,
            currentAgePhysicalLosses = intArrayOf(3, 0, 3, 3, 0, 0, 0),
            currentAgePhysicalPeaks = peaks,
            currentAgeCycleIndex = 0,
            careerCycleIndex = 1
        )

        assertEquals(2, tick.ageRecoveredPoints)
        assertTrue(tick.driver.speed <= peaks[0])
        assertTrue(tick.driver.overtaking <= peaks[2])
        assertTrue(tick.driver.defense <= peaks[3])
    }

    @Test
    fun `age pressure can reduce every one of the seven attributes`() {
        var d = driver(id = 9602).copy(
            speed = 80, qualifying = 81, overtaking = 82, defense = 83,
            consistency = 84, wet = 85, tyre = 86
        )
        var ageBank = 0.99
        var losses = IntArray(7)
        var peaks = intArrayOf(d.speed, d.qualifying, d.overtaking, d.defense, d.consistency, d.wet, d.tyre)
        repeat(5_000) { seed ->
            val tick = DriverEvolutionEngine.applyPerformanceTick(
                driver = d,
                performanceIndex = 85.0,
                currentBank = 0.0,
                annualGains = IntArray(7),
                random = Random(6961 + seed),
                careerAge = 43,
                currentAgeBank = ageBank,
                currentAgePhysicalLosses = losses,
                currentAgePhysicalPeaks = peaks,
                currentAgeCycleIndex = 0,
                careerCycleIndex = 0
            )
            d = tick.driver
            ageBank = tick.ageBank
            losses = tick.agePhysicalLosses
            peaks = tick.agePhysicalPeaks
        }
        assertTrue("aging should eventually touch VEL", losses[0] > 0)
        assertTrue("aging should eventually touch CLA", losses[1] > 0)
        assertTrue("aging should eventually touch ULT", losses[2] > 0)
        assertTrue("aging should eventually touch DEF", losses[3] > 0)
        assertTrue("aging should eventually touch CON", losses[4] > 0)
        assertTrue("aging should eventually touch CHU", losses[5] > 0)
        assertTrue("aging should eventually touch PNE", losses[6] > 0)
    }

    @Test
    fun `free-agent growth equals contracted natural baseline`() {
        assertEquals(1.0, DriverEvolutionEngine.FREE_DRIVER_GROWTH_RATE, 0.0)
        val d = driver(id = 9603).copy(speed = 70, qualifying = 70, overtaking = 70, defense = 70,
            consistency = 70, wet = 70, tyre = 70)
        val contracted = DriverEvolutionEngine.applyPerformanceTick(
            d, 105.0, 0.0, IntArray(7), Random(6962), facilityGrowthEfficiency = 1.0, careerAge = 24
        )
        val free = DriverEvolutionEngine.applyFreeDriverTick(
            d, 0.0, IntArray(7), Random(6962), careerAge = 24
        )
        assertEquals(contracted.bank, free.bank, 0.0)
    }
}
