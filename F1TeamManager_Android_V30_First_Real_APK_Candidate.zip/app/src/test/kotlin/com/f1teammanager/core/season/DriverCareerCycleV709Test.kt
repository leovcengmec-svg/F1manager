package com.f1teammanager.core.season

import kotlin.random.Random
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class DriverCareerCycleV709Test {
    private fun driver(id: Int = 9601, profile: String = "Auge tardio") = DriverDefinition(
        id = id, name = "Cycle probe $id", teamId = 1,
        speed = 80, qualifying = 81, overtaking = 82, defense = 83,
        consistency = 84, wet = 85, tyre = 86,
        driverClass = "Pro", evolution = profile, potentialOverall = 96
    )

    @Test
    fun `age reaches end of cycle then restarts at 16 without retirement`() {
        val d = driver()
        val start = DriverEvolutionEngine.careerStartAge(d)
        val seasonsToReset = 46 - start
        assertEquals(45, DriverEvolutionEngine.careerAge(d, 2026 + seasonsToReset - 1))
        assertEquals(16, DriverEvolutionEngine.careerAge(d, 2026 + seasonsToReset))
        assertEquals(1, DriverEvolutionEngine.careerCycleIndex(d, 2026 + seasonsToReset))
        assertEquals(17, DriverEvolutionEngine.careerAge(d, 2027 + seasonsToReset))
        assertEquals(d.evolution, "Auge tardio")
    }

    @Test
    fun `forty year old roster pilots complete age forty five season before reset`() {
        val mansell = driver(id = 9610).copy(name = "Nigel Mansell")
        assertEquals(40, DriverEvolutionEngine.careerAge(mansell, 2026))
        assertEquals(45, DriverEvolutionEngine.careerAge(mansell, 2031))
        assertEquals(16, DriverEvolutionEngine.careerAge(mansell, 2032))
        assertEquals(0, DriverEvolutionEngine.careerCycleIndex(mansell, 2031))
        assertEquals(1, DriverEvolutionEngine.careerCycleIndex(mansell, 2032))
    }

    @Test
    fun `cycle restart reduces every attribute by thirty percent without recovery`() {
        val d = driver()
        val tick = DriverEvolutionEngine.applyPerformanceTick(
            driver = d,
            performanceIndex = 145.0,
            currentBank = 0.80,
            annualGains = IntArray(7),
            random = Random(696),
            careerAge = 16,
            currentAgeBank = 0.80,
            currentAgePhysicalLosses = intArrayOf(4, 7, 6, 2, 8, 5, 9),
            currentAgePhysicalPeaks = intArrayOf(90, 92, 95, 94, 96, 95, 96),
            currentAgeCycleIndex = 0,
            careerCycleIndex = 1
        )
        assertTrue(tick.ageCycleRestarted)
        assertEquals(0, tick.ageRecoveredPoints)
        assertArrayEquals(intArrayOf(56, 56, 57, 58, 58, 59, 60), intArrayOf(tick.driver.speed, tick.driver.qualifying, tick.driver.overtaking, tick.driver.defense, tick.driver.consistency, tick.driver.wet, tick.driver.tyre))
        assertArrayEquals(IntArray(7), tick.agePhysicalLosses)
        assertEquals(0, tick.ageCycleRecoveryByAttribute.sum())
        assertArrayEquals(intArrayOf(-24, -25, -25, -25, -26, -26, -26), tick.ageCycleResetByAttribute)
        assertEquals("Auge tardio", tick.driver.evolution)
        assertEquals("Pro", tick.driver.driverClass)
        assertEquals(0.0, tick.ageBank, 0.0)
        assertEquals(0.0, tick.bank, 0.0)
    }

    @Test
    fun `cycle reset floors each attribute at forty and does not allow performance to offset it`() {
        val d = driver(id = 9605).copy(
            speed = 40, qualifying = 41, overtaking = 55, defense = 90,
            consistency = 84, wet = 85, tyre = 86
        )
        val tick = DriverEvolutionEngine.applyPerformanceTick(
            driver = d,
            performanceIndex = 150.0,
            currentBank = 0.99,
            annualGains = IntArray(7),
            random = Random(6964),
            careerAge = 16,
            currentAgeBank = 0.99,
            currentAgePhysicalLosses = intArrayOf(0, 0, 3, 3, 0, 0, 0),
            currentAgePhysicalPeaks = intArrayOf(40, 41, 58, 93, 84, 85, 86),
            currentAgeCycleIndex = 0,
            careerCycleIndex = 1
        )
        val after = intArrayOf(tick.driver.speed, tick.driver.qualifying, tick.driver.overtaking, tick.driver.defense, tick.driver.consistency, tick.driver.wet, tick.driver.tyre)
        assertArrayEquals(intArrayOf(40, 40, 40, 63, 58, 59, 60), after)
        assertEquals(0, tick.performanceAttributeDeltas.sum())
        assertTrue(tick.ageCycleResetByAttribute.any { it < 0 })
        assertTrue(after.all { it >= 40 })
    }

    @Test
    fun `age pressure can reduce every one of the seven attributes`() {
        var d = driver(id = 9602).copy(
            speed = 80, qualifying = 81, overtaking = 82, defense = 83,
            consistency = 84, wet = 85, tyre = 86
        )
        var ageBank = 0.99
        var losses = IntArray(7)
        var peaks = intArrayOf(d.speed, d.qualifying, d.overtaking, d.defense, d.consistency, d.wet, d.tyre)
        repeat(5_000) { seed ->
            val tick = DriverEvolutionEngine.applyPerformanceTick(
                driver = d,
                performanceIndex = 85.0,
                currentBank = 0.0,
                annualGains = IntArray(7),
                random = Random(6961 + seed),
                careerAge = 45,
                currentAgeBank = ageBank,
                currentAgePhysicalLosses = losses,
                currentAgePhysicalPeaks = peaks,
                currentAgeCycleIndex = 0,
                careerCycleIndex = 0
            )
            d = tick.driver
            ageBank = tick.ageBank
            losses = tick.agePhysicalLosses
            peaks = tick.agePhysicalPeaks
        }
        assertTrue("aging should eventually touch VEL", losses[0] > 0)
        assertTrue("aging should eventually touch CLA", losses[1] > 0)
        assertTrue("aging should eventually touch ULT", losses[2] > 0)
        assertTrue("aging should eventually touch DEF", losses[3] > 0)
        assertTrue("aging should eventually touch CON", losses[4] > 0)
        assertTrue("aging should eventually touch CHU", losses[5] > 0)
        assertTrue("aging should eventually touch PNE", losses[6] > 0)
    }

    @Test
    fun `free-agent growth equals contracted natural baseline`() {
        assertEquals(1.0, DriverEvolutionEngine.FREE_DRIVER_GROWTH_RATE, 0.0)
        val d = driver(id = 9603).copy(speed = 70, qualifying = 70, overtaking = 70, defense = 70,
            consistency = 70, wet = 70, tyre = 70)
        val contracted = DriverEvolutionEngine.applyPerformanceTick(
            d, 105.0, 0.0, IntArray(7), Random(6962), facilityGrowthEfficiency = 1.0, careerAge = 24
        )
        val free = DriverEvolutionEngine.applyFreeDriverTick(
            d, 0.0, IntArray(7), Random(6962), careerAge = 24
        )
        assertEquals(contracted.bank, free.bank, 0.0)
    }
}
