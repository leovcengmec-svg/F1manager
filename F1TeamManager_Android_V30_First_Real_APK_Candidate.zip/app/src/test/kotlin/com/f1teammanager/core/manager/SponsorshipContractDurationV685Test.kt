package com.f1teammanager.core.manager

import com.f1teammanager.core.season.WorldDatabase
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** Regression tests for the level-dependent sponsorship term introduced in V685. */
class SponsorshipContractDurationV685Test {
    private fun expectedRange(level: Int): IntRange = if (level.coerceIn(0, 10) <= 2) 3..10 else 8..14

    @Test
    fun generatedOffersUseTheRequestedCommercialLevelDuration() {
        val teamId = WorldDatabase.teams.first().id
        for (level in 0..10) {
            val engine = TeamSponsorshipEngine(seed = 68_500 + level)
            val offers = engine.offersForSlot(teamId, 2027, slot = 2, marketingLevel = level, round = 1)
            assertEquals("three visible offers at level $level", 3, offers.size)
            assertTrue(
                "level $level must use ${expectedRange(level)}, found ${offers.map { it.sponsor.races }}",
                offers.all { it.sponsor.races in expectedRange(level) }
            )
        }
    }

    @Test
    fun initialAndRenewedAiContractsKeepTheDurationBandOfTheirCurrentLevel() {
        val teamId = WorldDatabase.teams.first().id
        for (level in 0..10) {
            val engine = TeamSponsorshipEngine(seed = 68_600 + level)
            val range = expectedRange(level)
            engine.setMarketingLevel(teamId, level)
            val initial = engine.forTeam(teamId, 2027)
            assertTrue("initial AI contracts at level $level", initial.sponsors.all { it.races in range })

            for (round in 1..30) {
                val updated = engine.advanceRace(teamId, 2027, round)
                assertTrue(
                    "AI renewal at level $level, GP $round",
                    updated.sponsors.all { it.races in range && it.racesRemaining in 1..it.races }
                )
            }
        }
    }


    @Test
    fun everyIntegerFromEightThroughFourteenIsSelectableWithoutGaps() {
        val teamId = WorldDatabase.teams.first().id
        for (level in 3..10) {
            val observed = mutableSetOf<Int>()
            for (seed in 0..80) {
                val offers = TeamSponsorshipEngine(seed = 68_800 + seed)
                    .offersForSlot(teamId, 2027, slot = 2, marketingLevel = level, round = 1)
                observed += offers.map { it.sponsor.races }
                assertTrue("level $level must never offer 15 or 16 GP", offers.all { it.sponsor.races in 8..14 })
            }
            assertEquals("all integer durations must be selectable at level $level", (8..14).toSet(), observed)
        }
    }

    @Test
    fun upgradingMarketingDoesNotRewriteAlreadySignedContractDurations() {
        val teamId = WorldDatabase.teams.first().id
        val engine = TeamSponsorshipEngine(seed = 68_700)
        engine.setMarketingLevel(teamId, 2)
        val before = engine.forTeam(teamId, 2027).sponsors.associate { it.slot to it.races }
        assertTrue(before.values.all { it in 3..10 })

        engine.setMarketingLevel(teamId, 3)
        val after = engine.forTeam(teamId, 2027).sponsors.associate { it.slot to it.races }
        assertEquals("signed terms are grandfathered after an upgrade", before, after)
    }
}
