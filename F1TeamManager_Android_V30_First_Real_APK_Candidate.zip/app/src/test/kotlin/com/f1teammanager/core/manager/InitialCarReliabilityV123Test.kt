package com.f1teammanager.core.manager

import com.f1teammanager.core.season.WorldDatabase
import org.junit.Test
import kotlin.test.assertTrue

class InitialCarReliabilityV123Test {
    @Test
    fun `initial reliability follows the three official categories`() {
        WorldDatabase.teams.forEach { team ->
            val r = InitialTeamProfile.reliability(team)
            when (team.initialLevel) {
                InitialTeamProfile.FORTE -> assertTrue(r in 65..74, "${team.name}: Forte reliability=$r")
                InitialTeamProfile.MEDIO -> assertTrue(r in 55..64, "${team.name}: Médio reliability=$r")
                InitialTeamProfile.FRACO -> assertTrue(r in 45..54, "${team.name}: Fraco reliability=$r")
            }
        }
    }

    @Test
    fun `initial performance and reliability are independent`() {
        WorldDatabase.teams.forEach { team ->
            val values = InitialTeamProfile.values(team)
            val car = InitialTeamProfile.carState(team)
            assertTrue(car.reliability == InitialTeamProfile.reliability(team, values.overall))
        }
    }
}
