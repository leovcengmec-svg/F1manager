package com.f1teammanager.core.manager

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class NextSeasonCarInvestmentV478Test {
    @Test fun baselineCapIsIndependentOfRoundAndUsesAllFreeCash() {
        val baseline = 100_000_000L
        val early = SeasonInvestmentPolicy.maximumCumulativeInvestment(baseline, 1, 150_000_000L)
        val late = SeasonInvestmentPolicy.maximumCumulativeInvestment(baseline, 28, 150_000_000L)
        assertEquals(80_000_000L, early)
        assertEquals(early, late)
        assertTrue(late <= 150_000_000L)
    }

    @Test fun lateSeasonInvestmentUsesMeaningfulChunkWithoutBreakingReserve() {
        val cash = 20_000_000L
        val reserve = maxOf(
            SeasonInvestmentPolicy.protectedCash(cash),
            SeasonInvestmentPolicy.aiOperatingReserve(30_000_000L, 28)
        )
        val spendable = (cash - reserve).coerceAtLeast(0L)
        val desired = ((spendable / 50L) / 100_000L) * 100_000L
        val amount = minOf(10_000_000L, spendable, maxOf(750_000L, desired))
        assertTrue(amount >= 750_000L)
        assertTrue(cash - amount >= reserve)
    }
}
