package com.f1teammanager.core.manager

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** Regression coverage for V651's balanced sponsorship decision model. */
class SponsorshipAiDecisionV651Test {
    private fun offer(
        name: String,
        upfront: Long,
        perGp: Long,
        races: Int,
        qualifyingBonus: Long = 0L,
        qualifyingMin: Int = 0,
        qualifyingMax: Int = 0,
        qualifyingTarget: Int = 0,
        raceBonus: Long = 0L,
        raceTarget: Int = 0
    ) = TeamSponsorshipEngine.SponsorOffer(
        SponsorContract(
            name = name,
            upfront = upfront,
            racePayment = perGp,
            pointsBonus = 0L,
            years = 1,
            minimumReputation = 0,
            slot = 2,
            qualifyingTarget = qualifyingTarget,
            qualifyingBonus = qualifyingBonus,
            raceTarget = raceTarget,
            raceTargetBonus = raceBonus,
            active = true,
            races = races,
            racesRemaining = races,
            category = SponsorCategory.REGIONAL.name,
            qualifyingTargetMin = qualifyingMin,
            qualifyingTargetMax = qualifyingMax,
            raceTargetMin = 0,
            raceTargetMax = raceTarget
        ),
        SponsorCategory.REGIONAL
    )

    @Test fun higherReturnInLessTimeCanBeatTheLongestContract() {
        val engine = TeamSponsorshipEngine(seed = 651)
        val long = offer("Long", 5_000_000, 1_000_000, 10)
        val medium = offer("Medium", 8_000_000, 1_500_000, 6)
        val short = offer("Short", 10_000_000, 2_500_000, 3)

        val selected = engine.selectBestAiSponsorOffer(listOf(long, medium, short), teamRank = 20)

        assertEquals("Short", selected.sponsor.name)
    }

    @Test fun longerContractStillWinsWhenItsTotalAndPerGpReturnsAreClearlySuperior() {
        val engine = TeamSponsorshipEngine(seed = 652)
        val long = offer("HighValueLong", 20_000_000, 4_000_000, 10)
        val short = offer("LowValueShort", 4_000_000, 800_000, 3)

        val selected = engine.selectBestAiSponsorOffer(listOf(long, short), teamRank = 20)

        assertEquals("HighValueLong", selected.sponsor.name)
    }

    @Test fun bonusEstimateRewardsTargetsAlignedWithTeamStrength() {
        val engine = TeamSponsorshipEngine(seed = 653)
        val achievable = offer(
            "Achievable", 1_000_000, 1_000_000, 5,
            qualifyingBonus = 2_000_000, qualifyingMin = 1, qualifyingMax = 5, qualifyingTarget = 5
        ).sponsor
        val unrealistic = offer(
            "Unrealistic", 1_000_000, 1_000_000, 5,
            qualifyingBonus = 2_000_000, qualifyingMin = 76, qualifyingMax = 80, qualifyingTarget = 80
        ).sponsor

        val likely = engine.expectedSponsorBonusPerGp(achievable, teamRank = 1)
        val unlikely = engine.expectedSponsorBonusPerGp(unrealistic, teamRank = 1)

        assertTrue("A top team's expected bonus should be higher for its realistic qualifying window", likely > unlikely * 100.0)
    }

    @Test fun raceBonusProbabilityReflectsTheTeamsExpectedPosition() {
        val engine = TeamSponsorshipEngine(seed = 655)
        val raceTarget = offer(
            "RaceTarget", 1_000_000, 1_000_000, 5,
            raceBonus = 2_000_000, raceTarget = 3
        ).sponsor

        val topTeamEstimate = engine.expectedSponsorBonusPerGp(raceTarget, teamRank = 1)
        val backmarkerEstimate = engine.expectedSponsorBonusPerGp(raceTarget, teamRank = 40)

        assertTrue("The same front-running target should be valued as more attainable by a top team", topTeamEstimate > backmarkerEstimate * 20.0)
    }

    @Test fun rankingDoesNotTreatAZeroBonusOfferAsHavingARealizedBonus() {
        val engine = TeamSponsorshipEngine(seed = 654)
        val noBonus = offer("NoBonus", 1_000_000, 1_000_000, 5).sponsor
        assertEquals(0.0, engine.expectedSponsorBonusPerGp(noBonus, teamRank = 20), 0.0)
    }
}
