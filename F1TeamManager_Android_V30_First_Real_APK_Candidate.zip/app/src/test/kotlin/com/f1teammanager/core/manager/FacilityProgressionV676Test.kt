package com.f1teammanager.core.manager

import com.f1teammanager.core.season.WorldDatabase
import com.f1teammanager.core.season.DriverEvolutionEngine
import com.f1teammanager.core.season.DriverProfileCatalog
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class FacilityProgressionV676Test {
    @Test fun factoryCapacityMatchesTheOfficialSpecificationAtEveryTier() {
        val expected = mapOf(
            0 to 1, 1 to 1, 2 to 1, 3 to 2, 4 to 2, 5 to 2,
            6 to 3, 7 to 3, 8 to 4, 9 to 5, 10 to 6
        )
        expected.forEach { (level, capacity) ->
            val state = TeamFacilitiesState().withLevel(FacilityType.FACTORY, level)
            assertEquals("Factory level $level", capacity, FacilityEngine.factoryCapacity(state))
            assertEquals(capacity, FactorySpecification.level(level).parallelOrders)
        }
    }

    @Test fun driverDevelopmentFacilityHasNoPassiveGrowthAndUsesExplicitProgramTiers() {
        val factors = (0..10).map { level ->
            FacilityEngine.driverDevelopmentEfficiency(
                TeamFacilitiesState().withLevel(FacilityType.DRIVER_DEVELOPMENT, level)
            )
        }
        assertTrue("No facility level may grant passive driver growth", factors.all { kotlin.math.abs(it - 1.0) < 0.000001 })
        assertEquals(0, DriverDevelopmentEngine.capacity(0))
        assertEquals(1, DriverDevelopmentEngine.capacity(1))
        assertEquals(2, DriverDevelopmentEngine.capacity(10))
        assertTrue(DriverDevelopmentEngine.points(10) > DriverDevelopmentEngine.points(1))
        assertTrue(DriverDevelopmentEngine.weeks(10) < DriverDevelopmentEngine.weeks(1))
    }

    @Test fun windTunnelAndSimulatorProduceAContinuousNonRoundedRaceBonus() {
        val base = TeamFacilitiesState()
        val levels = (0..10).map { level ->
            FacilityEngine.racePaceBonus(
                base.withLevel(FacilityType.WIND_TUNNEL, level)
                    .withLevel(FacilityType.SIMULATOR, level)
            )
        }
        assertEquals(0.0, levels.first(), 0.0000001)
        assertEquals(0.015, levels.last(), 0.0000001)
        assertTrue(levels.zipWithNext().all { (a, b) -> b > a })
    }


    @Test fun facilityLevelDoesNotChangeNaturalGpGrowthWithoutAnExplicitProgram() {
        val driver = WorldDatabase.allDrivers.firstOrNull { it.potentialOverall > DriverProfileCatalog.overall(it.ratingsForManager()) }
            ?: error("No eligible driver profile")
        val baseline = DriverEvolutionEngine.applyPerformanceTick(
            driver = driver, performanceIndex = 105.0, currentBank = 0.0,
            annualGains = IntArray(7), random = kotlin.random.Random(676), facilityGrowthEfficiency = 1.0
        )
        val noPassive = DriverEvolutionEngine.applyPerformanceTick(
            driver = driver, performanceIndex = 105.0, currentBank = 0.0,
            annualGains = IntArray(7), random = kotlin.random.Random(676),
            facilityGrowthEfficiency = FacilityEngine.driverDevelopmentEfficiency(
                TeamFacilitiesState().withLevel(FacilityType.DRIVER_DEVELOPMENT, 10)
            )
        )
        assertEquals(baseline.bank, noPassive.bank, 0.000001)
        assertEquals(baseline.driver.ratingsForManager().toList(), noPassive.driver.ratingsForManager().toList())
    }

    @Test fun commercialMultiplierIsStrictlyMonotonic() {
        val values = (0..10).map(SponsorContractPricing::commercialMultiplier)
        assertEquals(1.60, values.first(), 0.000001)
        assertEquals(1.7275, values.last(), 0.000001)
        assertTrue(values.zipWithNext().all { (a, b) -> b > a })
    }

    @Test fun legacyScoutingFacilityKeyMigratesToRaceOperationsAndMarketOverallIsExact() {
        assertEquals(FacilityType.RACE_OPERATIONS, FacilityType.fromPersistedName("SCOUTING"))
        assertEquals(FacilityType.RACE_OPERATIONS, FacilityType.fromPersistedName("RACE_OPERATIONS"))
        val driver = WorldDatabase.allDrivers.maxByOrNull { d ->
            listOf(d.speed, d.qualifying, d.overtaking, d.defense, d.consistency, d.wet, d.tyre).average()
        } ?: error("No driver profile")
        val expected = listOf(driver.speed, driver.qualifying, driver.overtaking, driver.defense,
            driver.consistency, driver.wet, driver.tyre).average().toInt()
        assertEquals(expected, DriverMarketEngine(seed = 676).driverOverallForMarket(driver.id))
    }

    @Test fun everyFacilityHasReadableCurrentAndNextLevelEffects() {
        FacilityType.values().forEach { type ->
            assertTrue("Current effect missing for $type", FacilityEngine.levelEffect(type, 3).isNotBlank())
            assertTrue("Next effect missing for $type", FacilityEngine.nextLevelEffect(type, 3).isNotBlank())
        }
    }

    @Test fun researchCapacityMatchesPlayerAndAiAtAllLevels() {
        val engine = ResearchEngine()
        val expected = listOf(1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3)
        (0..10).forEach { level ->
            assertEquals(expected[level], engine.activeProjectCapacity(level))
        }
    }

    @Test fun researchAndWindTunnelLevelsRaiseTheActualFacilityAwareGainRange() {
        val research = ResearchEngine()
        val base = TeamFacilitiesState()
        val advancedResearch = base.withLevel(FacilityType.RESEARCH, 10)
        val baseEngine = research.maxImprovement(base, CarComponent.ENGINE)
        val advancedEngine = research.maxImprovement(advancedResearch, CarComponent.ENGINE)
        assertTrue(advancedEngine.first > baseEngine.first)
        assertTrue(advancedEngine.last > baseEngine.last)

        val windTunnel = base.withLevel(FacilityType.WIND_TUNNEL, 10)
        val aeroRange = research.maxImprovement(windTunnel, CarComponent.FRONT_WING)
        val nonAeroRange = research.maxImprovement(windTunnel, CarComponent.ENGINE)
        assertTrue(aeroRange.first > nonAeroRange.first)
        assertTrue(aeroRange.last > nonAeroRange.last)
    }

    @Test fun legacyFacilityPreviewHelpersMatchTheAuthoritativeProgression() {
        (0..10).forEach { level ->
            val state = TeamFacilitiesState()
                .withLevel(FacilityType.FACTORY, level)
                .withLevel(FacilityType.WIND_TUNNEL, level)
                .withLevel(FacilityType.SIMULATOR, level)
            val factory = FactorySpecification.level(level)
            assertEquals(kotlin.math.ceil(8 * factory.timeMultiplier).toInt(), FacilityEngine.factoryWeeks(8, state))
            assertEquals((100_000_000L * factory.costMultiplier).toLong(), FacilityEngine.factoryCost(100_000_000L, state))
            assertEquals(1.0 + level * 0.001, FacilityEngine.windTunnelPerformanceMultiplier(state), 0.000001)
            assertEquals(1.0 + level * 0.0005, FacilityEngine.simulatorPerformanceMultiplier(state), 0.000001)
        }
    }

    @Test fun factoryTimeAndCostSavingsNeverRegressWithLevel() {
        val specs = (0..10).map(FactorySpecification::level)
        assertTrue(specs.zipWithNext().all { (a, b) ->
            b.parallelOrders >= a.parallelOrders &&
                b.maxUnitsPerOrder >= a.maxUnitsPerOrder &&
                b.timeMultiplier <= a.timeMultiplier &&
                b.costMultiplier <= a.costMultiplier
        })
    }

    @Test fun aiFactoryBatchSelectionCanUseTheFullLevelCapacity() {
        assertEquals(
            6,
            selectAffordableFactoryQuantity(
                unitCost = 1_000_000L,
                desiredQuantity = 6,
                technicalSpent = 0L,
                technicalCap = 10_000_000L,
                availableBudget = 10_000_000L,
                maxAllowed = 6
            )
        )
        assertEquals(
            2,
            selectAffordableFactoryQuantity(
                unitCost = 1_000_000L,
                desiredQuantity = 6,
                technicalSpent = 0L,
                technicalCap = 10_000_000L,
                availableBudget = 10_000_000L,
                maxAllowed = 2
            )
        )
    }
    @Test fun researchAndWindTunnelLevelsIncreaseTheActualProjectGainRange() {
        val engine = ResearchEngine()
        val base = TeamFacilitiesState()
        val aero = base.withLevel(FacilityType.RESEARCH, 6)
            .withLevel(FacilityType.WIND_TUNNEL, 6)
        val nonAero = base.withLevel(FacilityType.RESEARCH, 6)
        val aeroRange = engine.maxImprovement(aero, CarComponent.FRONT_WING)
        val nonAeroRange = engine.maxImprovement(nonAero, CarComponent.ENGINE)
        assertTrue(aeroRange.first > nonAeroRange.first)
        assertTrue(aeroRange.last > nonAeroRange.last)
        assertEquals(8..12, engine.maxImprovement(base.withLevel(FacilityType.RESEARCH, 6), CarComponent.ENGINE))
    }

    @Test fun researchGainProgressionIsMonotonicForAllFacilities() {
        val engine = ResearchEngine()
        (CarComponent.values()).forEach { component ->
            val ranges = (0..10).map { level ->
                engine.maxImprovement(
                    TeamFacilitiesState().withLevel(FacilityType.RESEARCH, level)
                        .withLevel(FacilityType.WIND_TUNNEL, level), component
                )
            }
            assertTrue("$component minimum gain", ranges.zipWithNext().all { (a, b) -> b.first >= a.first })
            assertTrue("$component maximum gain", ranges.zipWithNext().all { (a, b) -> b.last >= a.last })
        }
    }

    @Test fun playerPreviewUsesTheSameFacilityAwareGainAsTheResearchEngine() {
        val facilities = TeamFacilitiesState().withLevel(FacilityType.RESEARCH, 6)
            .withLevel(FacilityType.WIND_TUNNEL, 8)
        val engine = ResearchEngine()
        val preview = engine.previewGain(
            facilities, CarComponent.FRONT_WING, ResearchFocus.PERFORMANCE,
            ResearchComplexity.MEDIUM, 60, 60
        )
        val expectedRange = engine.maxImprovement(facilities, CarComponent.FRONT_WING)
        val plainRange = engine.maxImprovement(6)
        assertTrue(expectedRange.first > plainRange.first)
        assertTrue(preview.performance.max > 0)
    }

}
