package com.f1teammanager.core.manager

import org.junit.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith

class TechnicalInvestmentEngineV113Test {
    @Test
    fun `annual cap follows the five ranking levels`() {
        assertEquals(200_000_000L, TechnicalInvestmentEngine.capForRank(1))
        assertEquals(200_000_000L, TechnicalInvestmentEngine.capForRank(8))
        assertEquals(250_000_000L, TechnicalInvestmentEngine.capForRank(9))
        assertEquals(250_000_000L, TechnicalInvestmentEngine.capForRank(16))
        assertEquals(300_000_000L, TechnicalInvestmentEngine.capForRank(17))
        assertEquals(300_000_000L, TechnicalInvestmentEngine.capForRank(24))
        assertEquals(350_000_000L, TechnicalInvestmentEngine.capForRank(25))
        assertEquals(350_000_000L, TechnicalInvestmentEngine.capForRank(32))
        assertEquals(400_000_000L, TechnicalInvestmentEngine.capForRank(33))
        assertEquals(400_000_000L, TechnicalInvestmentEngine.capForRank(40))
    }

    @Test
    fun `all three technical categories share the same annual ceiling`() {
        var state = TechnicalInvestmentEngine.create(2026, 17)
        state = state.withSpend(TechnicalInvestmentCategory.RESEARCH_DESIGN, 100_000_000L)
        state = state.withSpend(TechnicalInvestmentCategory.FABRICATION, 100_000_000L)
        state = state.withSpend(TechnicalInvestmentCategory.FACILITY_UPGRADE, 100_000_000L)

        assertEquals(300_000_000L, state.totalSpent)
        assertEquals(0L, state.available)
        assertFailsWith<IllegalArgumentException> {
            state.withSpend(TechnicalInvestmentCategory.RESEARCH_DESIGN, 1L)
        }
    }

    @Test
    fun `new season creates a zeroed annual controller`() {
        val old = TechnicalInvestmentEngine.create(2026, 33)
            .withSpend(TechnicalInvestmentCategory.RESEARCH_DESIGN, 50_000_000L)

        val next = TechnicalInvestmentEngine.ensureSeason(old, 2027, 1)

        assertEquals(2027, next.season)
        assertEquals(1, next.ranking)
        assertEquals(200_000_000L, next.annualCap)
        assertEquals(0L, next.totalSpent)
    }
}
