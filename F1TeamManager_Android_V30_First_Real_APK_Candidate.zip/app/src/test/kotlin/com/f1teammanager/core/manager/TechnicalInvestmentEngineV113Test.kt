package com.f1teammanager.core.manager

import org.junit.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith
import kotlin.test.assertTrue

class TechnicalInvestmentEngineV113Test {
    @Test
    fun `annual cap is uniform for every ranking`() {
        (1..40).forEach { rank -> assertEquals(200_000_000L, TechnicalInvestmentEngine.capForRank(rank)) }
    }

    @Test
    fun `all three technical categories share the same annual ceiling`() {
        var state = TechnicalInvestmentEngine.create(2026, 17)
        state = state.withSpend(TechnicalInvestmentCategory.RESEARCH_DESIGN, 80_000_000L)
        state = state.withSpend(TechnicalInvestmentCategory.FABRICATION, 70_000_000L)
        state = state.withSpend(TechnicalInvestmentCategory.FACILITY_UPGRADE, 50_000_000L)

        assertEquals(200_000_000L, state.totalSpent)
        assertEquals(0L, state.available)
        assertFailsWith<IllegalArgumentException> {
            state.withSpend(TechnicalInvestmentCategory.RESEARCH_DESIGN, 1L)
        }
    }

    @Test
    fun `next season technical cap is ranked from the newly constructed car`() {
        val teamId = com.f1teammanager.core.season.WorldDatabase.teams.first().id
        val weak = TeamCarState(
            aerodynamics = 42, chassis = 42, engine = 42, reliability = 42,
            frontWing = 42, rearWing = 42, brakes = 42, electricPowerUnit = 42
        )
        val strong = TeamCarState(
            aerodynamics = 98, chassis = 98, engine = 98, reliability = 98,
            frontWing = 98, rearWing = 98, brakes = 98, electricPowerUnit = 98
        )
        val weakAnnual = TechnicalInvestmentEngine.forTeam(2027, teamId, teamId, weak)
        val strongAnnual = TechnicalInvestmentEngine.forTeam(2027, teamId, teamId, strong)

        assertEquals(2027, weakAnnual.season)
        assertEquals(2027, strongAnnual.season)
        assertEquals(0L, weakAnnual.totalSpent)
        assertEquals(0L, strongAnnual.totalSpent)
        assertTrue(weakAnnual.ranking > strongAnnual.ranking)
    }

    @Test
    fun `legacy annual cap migrates without deleting recorded spending`() {
        val legacy = TechnicalInvestmentState(2026, 1, 5, 250_000_000L, 40_000_000L, 20_000_000L, 10_000_000L)
        val migrated = TechnicalInvestmentEngine.ensureSeason(legacy, 2026, 1)
        assertEquals(200_000_000L, migrated.annualCap)
        assertEquals(70_000_000L, migrated.totalSpent)
        assertEquals(130_000_000L, migrated.available)
    }

    @Test
    fun `new season creates a zeroed annual controller`() {
        val old = TechnicalInvestmentEngine.create(2026, 33)
            .withSpend(TechnicalInvestmentCategory.RESEARCH_DESIGN, 50_000_000L)

        val next = TechnicalInvestmentEngine.ensureSeason(old, 2027, 1)

        assertEquals(2027, next.season)
        assertEquals(1, next.ranking)
        assertEquals(200_000_000L, next.annualCap)
        assertEquals(0L, next.totalSpent)
    }
}
