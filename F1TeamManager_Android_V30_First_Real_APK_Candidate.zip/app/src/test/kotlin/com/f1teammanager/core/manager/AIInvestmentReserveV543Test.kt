package com.f1teammanager.core.manager

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class AIInvestmentReserveV543Test {
    @Test fun nextCarReserveUsesOnlyRealCashAndGrowsWithBudget() {
        assertEquals(0L, SeasonInvestmentPolicy.aiNextCarReserve(0L))
        assertEquals(2_000_000L, SeasonInvestmentPolicy.aiNextCarReserve(10_000_000L))
        assertEquals(10_000_000L, SeasonInvestmentPolicy.aiNextCarReserve(100_000_000L))
        assertTrue(SeasonInvestmentPolicy.aiNextCarReserve(50_000_000L) <= 50_000_000L)
    }

    @Test fun pAndCannotConsumeTheProtectedNextCarReserve() {
        val cash = 50_000_000L
        val spendable = SeasonInvestmentPolicy.aiDevelopmentSpendableCash(cash)
        assertEquals(40_000_000L, spendable)
        assertTrue(spendable + SeasonInvestmentPolicy.aiNextCarReserve(cash) <= cash)
    }

    @Test fun lowCashNeverCreatesAnArtificialInvestmentBudget() {
        for (cash in listOf(0L, 500_000L, 1_000_000L, 2_000_000L)) {
            assertEquals(0L, SeasonInvestmentPolicy.aiDevelopmentSpendableCash(cash))
            assertTrue(SeasonInvestmentPolicy.aiNextCarReserve(cash) <= cash)
        }
    }
}
