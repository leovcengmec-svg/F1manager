package com.f1teammanager.core.manager

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class AIInvestmentReserveV543Test {
    @Test fun nextCarReserveUsesCashAndIndependentAnnualCapWithoutGeometricDecay() {
        assertEquals(0L, SeasonInvestmentPolicy.aiNextCarReserve(0L))
        assertEquals(5_000_000L, SeasonInvestmentPolicy.aiNextCarReserve(10_000_000L))
        assertEquals(50_000_000L, SeasonInvestmentPolicy.aiNextCarReserve(100_000_000L))
        assertEquals(150_000_000L, SeasonInvestmentPolicy.aiNextCarReserve(1_000_000_000L))
        // The priority is a cash-allocation preference, not a €75M cumulative cap.
        // Only the independent €150M project ceiling limits annual construction.
        assertEquals(75_000_000L, SeasonInvestmentPolicy.aiNextCarReserve(
            1_000_000_000L, alreadyInvested = 75_000_000L, annualEnvelopeRemaining = 120_000_000L
        ))
        assertEquals(0L, SeasonInvestmentPolicy.aiNextCarReserve(
            1_000_000_000L, alreadyInvested = 150_000_000L, annualEnvelopeRemaining = 120_000_000L
        ))
        assertTrue(SeasonInvestmentPolicy.aiNextCarReserve(50_000_000L) <= 50_000_000L)
    }

    @Test fun pAndCannotConsumeTheProtectedNextCarReserve() {
        val cash = 50_000_000L
        val spendable = SeasonInvestmentPolicy.aiDevelopmentSpendableCash(cash)
        assertEquals(25_000_000L, spendable)
        assertTrue(spendable + SeasonInvestmentPolicy.aiNextCarReserve(cash) <= cash)
    }

    @Test fun aiLiquidityBufferStopsGrowingWithAnAccumulatedFortune() {
        assertEquals(40_000_000L, SeasonInvestmentPolicy.aiProtectedCash(200_000_000L))
        assertEquals(50_000_000L, SeasonInvestmentPolicy.aiProtectedCash(1_000_000_000L))
    }

    @Test fun lowCashNeverCreatesAnArtificialInvestmentBudget() {
        for (cash in listOf(0L, 500_000L, 1_000_000L, 2_000_000L)) {
            assertEquals(0L, SeasonInvestmentPolicy.aiDevelopmentSpendableCash(cash))
            assertTrue(SeasonInvestmentPolicy.aiNextCarReserve(cash) <= cash)
        }
    }
}
