package com.f1teammanager.core.manager

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class AIInvestmentReserveV543Test {
    @Test fun nextCarReserveUsesCashAndRemainingSharedEnvelopeInsteadOfAnEightyMillionCap() {
        assertEquals(0L, SeasonInvestmentPolicy.aiNextCarReserve(0L))
        assertEquals(4_000_000L, SeasonInvestmentPolicy.aiNextCarReserve(10_000_000L))
        assertEquals(40_000_000L, SeasonInvestmentPolicy.aiNextCarReserve(100_000_000L))
        assertEquals(80_000_000L, SeasonInvestmentPolicy.aiNextCarReserve(1_000_000_000L))
        // After €80M has been invested, another €48M remains a protected priority
        // from the €120M shared envelope. It is not blocked by the old €80M target.
        assertEquals(48_000_000L, SeasonInvestmentPolicy.aiNextCarReserve(
            1_000_000_000L, alreadyInvested = 80_000_000L, annualEnvelopeRemaining = 120_000_000L
        ))
        assertEquals(0L, SeasonInvestmentPolicy.aiNextCarReserve(
            1_000_000_000L, alreadyInvested = 150_000_000L, annualEnvelopeRemaining = 120_000_000L
        ))
        assertTrue(SeasonInvestmentPolicy.aiNextCarReserve(50_000_000L) <= 50_000_000L)
    }

    @Test fun pAndCannotConsumeTheProtectedNextCarReserve() {
        val cash = 50_000_000L
        val spendable = SeasonInvestmentPolicy.aiDevelopmentSpendableCash(cash)
        assertEquals(30_000_000L, spendable)
        assertTrue(spendable + SeasonInvestmentPolicy.aiNextCarReserve(cash) <= cash)
    }

    @Test fun aiLiquidityBufferStopsGrowingWithAnAccumulatedFortune() {
        assertEquals(40_000_000L, SeasonInvestmentPolicy.aiProtectedCash(200_000_000L))
        assertEquals(50_000_000L, SeasonInvestmentPolicy.aiProtectedCash(1_000_000_000L))
    }

    @Test fun lowCashNeverCreatesAnArtificialInvestmentBudget() {
        for (cash in listOf(0L, 500_000L, 1_000_000L, 2_000_000L)) {
            assertEquals(0L, SeasonInvestmentPolicy.aiDevelopmentSpendableCash(cash))
            assertTrue(SeasonInvestmentPolicy.aiNextCarReserve(cash) <= cash)
        }
    }
}
