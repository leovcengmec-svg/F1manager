package com.f1teammanager.core.race

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class RacePerformanceWeightsV613Test {
    @Test
    fun `dry pace blend uses 70 percent car and 30 percent driver`() {
        assertEquals(0.70, RacePerformanceWeights.carWeight(Weather.DRY), 0.000001)
        assertEquals(0.30, RacePerformanceWeights.driverWeight(Weather.DRY), 0.000001)
        assertEquals(0.70, RacePerformanceWeights.carWeight(Weather.CLOUDY), 0.000001)
        assertEquals(0.30, RacePerformanceWeights.driverWeight(Weather.CLOUDY), 0.000001)
    }

    @Test
    fun `rain contribution scales from 60 40 in rain and 55 45 in heavy rain`() {
        assertEquals(0.60, RacePerformanceWeights.carWeight(Weather.LIGHT_RAIN), 0.000001)
        assertEquals(0.40, RacePerformanceWeights.driverWeight(Weather.LIGHT_RAIN), 0.000001)
        assertEquals(0.60, RacePerformanceWeights.carWeight(Weather.MEDIUM_RAIN), 0.000001)
        assertEquals(0.40, RacePerformanceWeights.driverWeight(Weather.MEDIUM_RAIN), 0.000001)
        assertEquals(0.55, RacePerformanceWeights.carWeight(Weather.HEAVY_RAIN), 0.000001)
        assertEquals(0.45, RacePerformanceWeights.driverWeight(Weather.HEAVY_RAIN), 0.000001)
    }


    @Test
    fun `car and driver weights always sum to one for every weather state`() {
        Weather.values().forEach { weather ->
            assertEquals(
                "Car and driver weights must cover the full pace model for $weather",
                1.0,
                RacePerformanceWeights.carWeight(weather) + RacePerformanceWeights.driverWeight(weather),
                0.000001
            )
        }
    }

    @Test
    fun `heavy rain still rewards car strength while preserving wet driver skill`() {
        val result = RacePerformanceWeights.combinedTimeMultiplier(
            carTimeModifier = 0.04,
            driverPaceModifier = 0.02,
            weather = Weather.HEAVY_RAIN
        )
        assertEquals(1.013, result, 0.000001)
    }

    @Test
    fun `excellent driver cannot make a level zero car faster than neutral baseline`() {
        val poorCarModifier = CarComponentInfluence.engineLapModifier(0) +
            CarComponentInfluence.chassisLapModifier(0) +
            CarComponentInfluence.frontWingLapModifier(0)
        val proDriverModifier = DriverAttributeInfluence.velocity(100)

        val poorCarWithProInDry = RacePerformanceWeights.combinedTimeMultiplier(
            poorCarModifier, proDriverModifier, Weather.DRY
        )
        val poorCarWithProInRain = RacePerformanceWeights.combinedTimeMultiplier(
            poorCarModifier, proDriverModifier, Weather.HEAVY_RAIN
        )
        val poorCarWithAverageDriver = RacePerformanceWeights.combinedTimeMultiplier(
            poorCarModifier, DriverAttributeInfluence.velocity(50), Weather.DRY
        )

        assertTrue("Pro pilot should improve the same poor car", poorCarWithProInDry < poorCarWithAverageDriver)
        assertTrue("Poor car must remain slower than neutral even with a Pro", poorCarWithProInDry > 1.0)
        assertTrue("Car limitation must remain material in rain", poorCarWithProInRain > 1.0)
    }

    @Test
    fun `driver and car contributions are applied once and preserve neutral reference`() {
        assertEquals(
            1.0,
            RacePerformanceWeights.combinedTimeMultiplier(0.0, 0.0, Weather.DRY),
            0.000001
        )
        val carModifier = 0.05
        val driverModifier = 0.02
        assertEquals(
            1.029,
            RacePerformanceWeights.combinedTimeMultiplier(carModifier, driverModifier, Weather.DRY),
            0.000001
        )
    }
}
