package com.f1teammanager.core.race

/** V93: red flag continua funcionando com o novo motor de qualificação visual. */
fun main() {
    val circuit = RaceCircuit(99, "V93 Red Flag Audit", 20, 75_500L, crashRisk = 1000.0, reliabilityRisk = 0.0, safetyCarRisk = 0.0)
    val base = RaceParticipant(
        driverId = 1, driverName = "A", teamId = 1, teamName = "T",
        driverSpeed = 70, qualifying = 70, overtaking = 70, defense = 70, consistency = 70,
        enginePerformance = 70, tyreGrip = 70, tyreWear = 70, reliability = 95, chassisWear = 0,
        wetSkill = 70, chassisPerformance = 70, frontWingPerformance = 70, rearWingPerformance = 70,
        brakesPerformance = 70, electricPowerUnitPerformance = 70
    )
    val participants = (1..80).map { id ->
        base.copy(driverId = id, driverName = "D$id", teamId = ((id - 1) / 2) + 1, teamName = "T${((id - 1) / 2) + 1}")
    }
    // Seed chosen for a deterministic severe-accident/red-flag path under V93's
    // new qualifying order while leaving the race RNG chain isolated from quali.
    val engine = CareerWeekendEngine(610)
    var snapshot = engine.start(participants, circuit, 1)
    repeat(3) { snapshot = engine.simulateQualifyingPhase() }
    check(snapshot.grid?.grid?.size == 80)

    var guard = 0
    while (snapshot.decision?.request?.type != ManagerDecisionType.RED_FLAG && !snapshot.completed) {
        check(++guard < 30) { "Bandeira vermelha não foi encontrada no cenário de auditoria" }
        snapshot = if (snapshot.decision != null) engine.choose(ManagerDecisionAction.STAY_OUT) else engine.advance()
    }

    check(snapshot.decision?.request?.type == ManagerDecisionType.RED_FLAG)
    val remaining = snapshot.totalLaps - snapshot.lap
    val p = snapshot.plans[1] ?: error("Plano do piloto do jogador ausente")
    check(p.tyrePlans.size == 4)
    check(p.tyrePlans.values.all { it.sequence.isNotEmpty() })
    check(p.tyrePlans.values.all { it.sequence.sumOf { tyre -> tyre.targetLaps } >= remaining })
    check(p.tyrePlans.values.flatMap { it.sequence }.toSet().containsAll(setOf(Tyre.SOFT, Tyre.MEDIUM, Tyre.HARD)))

    val fuelBefore = snapshot.carStatus.first { it.driverId == 2 }.fuelPercent
    snapshot = engine.choose(ManagerDecisionAction.RESTART_PLAN_B)
    val restarted = snapshot.carStatus.first { it.driverId == 2 }
    check(restarted.tyreWear == 0)
    check(restarted.fuelPercent == fuelBefore)

    println("V93_RED_FLAG_RESTART_PLAN_OK")
}
