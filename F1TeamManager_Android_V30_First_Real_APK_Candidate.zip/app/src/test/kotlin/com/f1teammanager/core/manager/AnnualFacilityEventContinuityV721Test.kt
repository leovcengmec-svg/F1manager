package com.f1teammanager.core.manager

import java.util.Base64
import kotlin.random.Random
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class AnnualFacilityEventContinuityV721Test {
    @Test
    fun `earthquake rebases paid AI facility project instead of restoring damaged level`() {
        val teamId = 6
        val initial = TeamFacilitiesState().withLevel(FacilityType.FACTORY, 2)
        val facilityData = FacilityType.values().joinToString(",") { "${it.name}:${initial.level(it)}" }
        val encodedFacilities = Base64.getEncoder().encodeToString(facilityData.toByteArray(Charsets.UTF_8))
        val upgradeData = listOf(FacilityType.FACTORY.name, 2, 3, 5, 12, 8_000_000L, 2028, 20).joinToString(":")
        val encodedUpgrade = Base64.getEncoder().encodeToString(upgradeData.toByteArray(Charsets.UTF_8))
        val engine = AITeamFinancialEngine(20261006)
        engine.restoreSnapshot("F|$teamId|$encodedFacilities\nU|$teamId|$encodedUpgrade")

        val damaged = initial.withLevel(FacilityType.FACTORY, 0)
        engine.applyAnnualEventFacilities(teamId, damaged)

        assertEquals(0, engine.facilities(teamId).level(FacilityType.FACTORY))
        val active = engine.facilityUpgrade(teamId)
        assertNotNull(active)
        assertEquals(0, active!!.previousLevel)
        assertEquals(1, active.targetLevel)
        assertEquals(5, active.remainingWeeks)
    }

    @Test
    fun `free annual upgrade does not consume a paid level already under construction`() {
        val active = FacilityUpgradeState(FacilityType.RESEARCH, 2, 3, 7, 12, 8_000_000L, 2028, 10)
        val rebased = active.afterExternalLevelChange(beforeLevel = 2, afterLevel = 3)
        assertNotNull(rebased)
        assertEquals(3, rebased!!.previousLevel)
        assertEquals(4, rebased.targetLevel)
        assertEquals(7, rebased.remainingWeeks)
    }

    @Test
    fun `a project that has no remaining physical level is cancelled`() {
        val active = FacilityUpgradeState(FacilityType.WIND_TUNNEL, 9, 10, 2, 12, 80_000_000L, 2028, 2)
        assertNull(active.afterExternalLevelChange(beforeLevel = 9, afterLevel = 10))
    }

    @Test
    fun `weighted event selection is deterministic and favours weak teams`() {
        fun snapshot(id: Int, rank: Int) = AnnualTeamEventEngine.TeamSnapshot(
            teamId = id,
            strengthRank = rank,
            teamCount = 40,
            budget = 100_000_000L,
            facilities = FacilityType.values().associateWith { 2 },
            car = TeamCarState(aerodynamics = 60, engine = 60, chassis = 60, frontWing = 60, rearWing = 60,
                brakes = 60, electricPowerUnit = 60, reliability = 60)
        )
        val candidates = listOf(snapshot(1, 1), snapshot(2, 20), snapshot(3, 40))
        val first = AnnualTeamEventEngine.weightedTeam(candidates, Random(721))?.teamId
        val second = AnnualTeamEventEngine.weightedTeam(candidates, Random(721))?.teamId
        assertEquals(first, second)

        val counts = mutableMapOf(1 to 0, 2 to 0, 3 to 0)
        (1..5_000).forEach { seed ->
            val selected = AnnualTeamEventEngine.weightedTeam(candidates, Random(seed))
            if (selected != null) counts[selected.teamId] = counts.getValue(selected.teamId) + 1
        }
        assertTrue("weak teams should have the highest selection weight", counts.getValue(3) > counts.getValue(2))
        assertTrue("middle teams should outweigh strong teams", counts.getValue(2) > counts.getValue(1))
    }
    @Test
    fun `multi-week advancement stops at each pending event boundary`() {
        assertEquals(
            listOf(5, 11, 28),
            AnnualTeamEventScheduler.advancementBoundaries(2, 28, listOf(11, 5, 11, 40, 2))
        )
        assertTrue(AnnualTeamEventScheduler.advancementBoundaries(28, 28, listOf(28)).isEmpty())
    }

    @Test
    fun `damaged facility completes only the rebased remaining paid level`() {
        val before = TeamFacilitiesState().withLevel(FacilityType.FACTORY, 2)
        val damaged = before.withLevel(FacilityType.FACTORY, 0)
        val active = FacilityUpgradeState(FacilityType.FACTORY, 2, 3, 5, 12, 8_000_000L, 2028, 20)
        val rebased = FacilityEngine.rebaseUpgradeAfterExternalChange(active, before, damaged)
        val manager = TeamManagerState(
            car = TeamCarState(aerodynamics = 60, chassis = 60, engine = 60, reliability = 60),
            finance = TeamFinanceState(0L),
            facilities = damaged,
            facilityUpgrade = rebased
        )

        val (completed, didComplete) = FacilityEngine.advanceUpgrade(manager, 5)
        assertTrue(didComplete)
        assertEquals(1, completed.facilities.level(FacilityType.FACTORY))
        assertNull(completed.facilityUpgrade)
    }

}
