package com.f1teammanager.core.manager

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class NextSeasonCarGrowthLimitV709Test {
    private val engine = CarDevelopmentEngine()

    private fun state(overall: Int, invested: Long, cash: Long = 100_000_000L): TeamManagerState {
        val car = TeamCarState(
            aerodynamics = overall, chassis = overall, engine = overall, reliability = overall,
            frontWing = overall, rearWing = overall, brakes = overall, electricPowerUnit = overall,
            nextSeasonInvestment = invested
        )
        return TeamManagerState(season = 2026, round = 20, car = car, finance = TeamFinanceState(cash))
    }

    @Test
    fun `overall 46 target 53 locks at the exact 31 million reference`() {
        val forecast = engine.nextSeasonForecast(state(overall = 46, invested = 31_000_000L))
        assertEquals(53, forecast.maximumAllowedOverall)
        assertEquals(31_000_000L, forecast.targetInvestment)
        assertEquals(53, forecast.projectedOverall)
        assertEquals(0L, forecast.remainingToTarget)
        assertTrue(forecast.goalReached)
    }

    @Test
    fun `player cannot spend after reaching annual overall goal even under 150 million cap`() {
        val funded = state(overall = 46, invested = 31_000_000L)
        assertTrue(funded.car.nextSeasonInvestment < SeasonInvestmentPolicy.nextCarAnnualCap())
        try {
            engine.investNextSeason(funded, 1_000_000L)
            throw AssertionError("Aporte deveria ser bloqueado depois de atingir Overall 53")
        } catch (expected: IllegalArgumentException) {
            assertTrue(expected.message.orEmpty().contains("Meta de Overall atingida"))
        }
    }

    @Test
    fun `player can fund only the exact remaining amount to target`() {
        val before = state(overall = 46, invested = 30_000_000L)
        val forecast = engine.nextSeasonForecast(before)
        assertEquals(1_000_000L, forecast.remainingToTarget)
        assertFalse(forecast.goalReached)

        try {
            engine.investNextSeason(before, 2_000_000L)
            throw AssertionError("Aporte acima do necessário deveria ser recusado")
        } catch (expected: IllegalArgumentException) {
            assertTrue(expected.message.orEmpty().contains("restam apenas €1M"))
        }

        val after = engine.investNextSeason(before, 1_000_000L)
        val afterForecast = engine.nextSeasonForecast(after)
        assertEquals(31_000_000L, after.car.nextSeasonInvestment)
        assertEquals(53, afterForecast.projectedOverall)
        assertTrue(afterForecast.goalReached)
    }
}
