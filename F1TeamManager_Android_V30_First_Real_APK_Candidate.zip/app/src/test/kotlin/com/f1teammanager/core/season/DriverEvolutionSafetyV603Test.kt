package com.f1teammanager.core.season

import kotlin.random.Random

/** Runnable JVM contract test; does not require Android or Compose. */
fun main() {
    val classes = mapOf("Fraco" to 59, "Médio" to 69, "Forte" to 79, "Pro" to 89, "Lenda" to 100)
    val floors = mapOf("Fraco" to 40, "Médio" to 45, "Forte" to 50, "Pro" to 55, "Lenda" to 60)
    for ((clazz, ceiling) in classes) {
        check(DriverProfileCatalog.ceiling(clazz) == ceiling) { "$clazz ceiling mismatch" }
        check(DriverProfileCatalog.minimumOverall(clazz) == floors.getValue(clazz)) { "$clazz floor mismatch" }
        val driver = DriverDefinition(
            id = 1, name = "Regression floor probe", teamId = 1,
            speed = 100, qualifying = 100, overtaking = 100, defense = 100,
            consistency = 100, wet = 100, tyre = 100, driverClass = clazz, evolution = "Prodígio"
        )
        var degraded = driver
        repeat(200) { degraded = DriverEvolutionEngine.applyRegression(degraded, 100, Random(1000 + it)) }
        val values = intArrayOf(degraded.speed, degraded.qualifying, degraded.overtaking, degraded.defense,
            degraded.consistency, degraded.wet, degraded.tyre)
        check(DriverProfileCatalog.overall(values) >= floors.getValue(clazz)) {
            "$clazz dropped below overall floor: ${DriverProfileCatalog.overall(values)}"
        }
        check(values.all { it in 40..ceiling }) { "$clazz attribute outside 40..$ceiling" }
    }

    // Cycle is strictly 5/2/5 regardless of growth category.
    check(DriverEvolutionEngine.normalizePhase("UNKNOWN") == "GROWING")
    check(DriverEvolutionEngine.normalizePhase("REGRESSION") == "REGRESSION")
    check(DriverEvolutionEngine.phaseDurationSeasons("GROWING") == 5)
    check(DriverEvolutionEngine.phaseDurationSeasons("PEAK") == 2)
    check(DriverEvolutionEngine.phaseDurationSeasons("REGRESSION") == 5)
    check(DriverEvolutionEngine.ascentSeasons("Normal") == 5)
    check(DriverEvolutionEngine.regressionSeasons("Normal") == 5)

    // Canonical start profiles are normalized by class, so a Lenda starts at OVR 75
    // while still having an attribute ceiling of 100. Felipe's Forte baseline is OVR 59
    // (75% of 79), which is an intentional initial balance, not an identity collision.
    val maxProfile = DriverProfileCatalog.profile("Max Verstappen")
    check(maxProfile.driverClass == "Lenda")
    check(DriverProfileCatalog.overall(maxProfile.ratings) == 75)
    val felipeProfile = DriverProfileCatalog.profile("Felipe Drugovich")
    check(felipeProfile.driverClass == "Forte")
    check(DriverProfileCatalog.overall(felipeProfile.ratings) == 59)
    check(DriverProfileCatalog.ceiling("Lenda") == 100)
    check(DriverProfileCatalog.maxAnnualGain("Prodígio") == 15)
    check(DriverProfileCatalog.maxAnnualGain("Normal") == 8)
    println("DriverEvolutionSafetyV603Test: PASS (5 class caps/floors, strict 5/2/5 cycle, Max/Felipe baselines, regression stress)")
}
