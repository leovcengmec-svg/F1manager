package com.f1teammanager.core.season

import kotlin.random.Random

/** V649 contract: class bands, class-bounded opening potential and performance-only regression. */
fun main() {
    val ceilings = mapOf("Fraco" to 59, "Médio" to 69, "Forte" to 79, "Pro" to 89, "Lenda" to 100)
    val floors = mapOf("Fraco" to 40, "Médio" to 60, "Forte" to 70, "Pro" to 80, "Lenda" to 90)
    for ((clazz, ceiling) in ceilings) {
        check(DriverProfileCatalog.ceiling(clazz) == ceiling)
        check(DriverProfileCatalog.minimumOverall(clazz) == floors.getValue(clazz))
        val samples = DriverProfileCatalog.profiles.keys.filter { DriverProfileCatalog.profiles.getValue(it).driverClass == clazz }
        samples.forEach { name ->
            val sample = DriverProfileCatalog.profile(name)
            val overall = DriverProfileCatalog.overall(sample.ratings)
            check(overall in floors.getValue(clazz)..ceiling) { "$name opening Overall outside $clazz band: $overall" }
            check(sample.potentialOverall in overall..DriverProfileCatalog.maxPotentialOverall(clazz)) {
                "$name potential ${sample.potentialOverall} outside its class headroom"
            }
        }

        val driver = DriverDefinition(
            id = 1, name = "Regression floor probe", teamId = 1,
            speed = 100, qualifying = 100, overtaking = 100, defense = 100,
            consistency = 100, wet = 100, tyre = 100, driverClass = clazz, evolution = "Prodígio",
            potentialOverall = 100
        )
        check(DriverEvolutionEngine.minimumOverall(driver) == 40) { "Regression safety floor must be global" }
        var degraded = driver
        repeat(200) { degraded = DriverEvolutionEngine.applyRegression(degraded, 100, Random(1000 + it)) }
        val values = intArrayOf(degraded.speed, degraded.qualifying, degraded.overtaking, degraded.defense, degraded.consistency, degraded.wet, degraded.tyre)
        check(DriverProfileCatalog.overall(values) >= 40) { "$clazz dropped below the global safety floor" }
        check(values.all { it in 40..100 }) { "$clazz attribute outside 40..100" }
    }

    check(DriverEvolutionEngine.normalizePhase("UNKNOWN") == "GROWING")
    check(DriverEvolutionEngine.normalizePhase("REGRESSION") == "REGRESSION")
    check(DriverEvolutionEngine.normalizePhase("PEAK") == "STABLE")
    check(DriverEvolutionEngine.performanceEvolutionRate(120.0) > 0.0)
    check(DriverEvolutionEngine.performanceEvolutionRate(100.0) > 0.0)
    check(DriverEvolutionEngine.performanceEvolutionRate(88.0) == 0.0)
    check(DriverEvolutionEngine.performanceEvolutionRate(70.0) < 0.0)

    val max = DriverProfileCatalog.profile("Max Verstappen")
    check(max.driverClass == "Lenda")
    check(DriverProfileCatalog.overall(max.ratings) >= 94)
    check(max.potentialOverall == 100)
    val medium = DriverProfileCatalog.profile("Franco Colapinto")
    check(medium.driverClass == "Médio")
    check(DriverProfileCatalog.overall(medium.ratings) in 60..69)
    check(medium.potentialOverall <= 89)
    check(DriverProfileCatalog.maxPotentialOverall("Fraco") == 79)
    check(DriverProfileCatalog.maxPotentialOverall("Médio") == 89)
    check(DriverProfileCatalog.maxAnnualGain("Prodígio") == 15)
    check(DriverProfileCatalog.maxAnnualGain("Normal") == 8)
    check(DriverProfileCatalog.maxAnnualGain("Demorado") == 6)
    println("DriverEvolutionSafetyV649Test: PASS")
}
