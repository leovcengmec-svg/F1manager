package com.f1teammanager.core.season

import kotlin.random.Random
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

class DriverCareerAgingV695Test {
    @Test
    fun `career starting ages are deterministic but cover rookie to veteran cohorts`() {
        val drivers = (1..100).map { id ->
            DriverDefinition(
                id = id, name = "Age probe $id", teamId = 1,
                speed = 80, qualifying = 80, overtaking = 80, defense = 80,
                consistency = 80, wet = 80, tyre = 80,
                driverClass = "Pro", evolution = "Auge tardio", potentialOverall = 95
            )
        }
        val ages = drivers.map(DriverEvolutionEngine::careerStartAge)
        assertTrue(ages.minOrNull()!! >= 16)
        assertTrue(ages.maxOrNull()!! <= DriverEvolutionEngine.AGE_CYCLE_END)
        assertTrue(ages.distinct().size >= 10, "Fallback ages should cover multiple career cohorts")
        assertEquals(DriverEvolutionEngine.careerStartAge(drivers.first()), DriverEvolutionEngine.careerStartAge(drivers.first()))
        val nonVeteran = drivers.first { DriverEvolutionEngine.careerStartAge(it) <= 41 }
        assertEquals(DriverEvolutionEngine.careerStartAge(nonVeteran) + 4, DriverEvolutionEngine.careerAge(nonVeteran, 2030))
    }

    @Test
    fun `veteran age pressure can cause regression even after a good weekend`() {
        val driver = DriverDefinition(
            id = 9401, name = "Veteran probe", teamId = 1,
            speed = 90, qualifying = 90, overtaking = 90, defense = 90,
            consistency = 90, wet = 90, tyre = 90,
            driverClass = "Lenda", evolution = "Prodígio", potentialOverall = 100
        )
        assertTrue(DriverEvolutionEngine.ageDeclineRate(42) > DriverEvolutionEngine.ageDeclineRate(35))
        assertEquals(0.70, DriverEvolutionEngine.ageDeclineRate(45), 0.0)
        assertTrue(DriverEvolutionEngine.ageGrowthFactor(42) < DriverEvolutionEngine.ageGrowthFactor(27))
        val result = DriverEvolutionEngine.applyPerformanceTick(
            driver = driver,
            performanceIndex = 105.0,
            currentBank = 0.0,
            annualGains = IntArray(7),
            random = Random(695),
            careerAge = 42,
            currentAgeBank = 0.80,
            currentAgePhysicalPeaks = intArrayOf(90, 90, 90, 90, 90, 90, 90),
            currentAgeCycleIndex = 0,
            careerCycleIndex = 0
        )
        assertTrue(result.attributeDelta < 0, "A veteran's natural decline should be able to reduce Overall")
    }

    @Test
    fun `overall drops receive a distinct regression news headline`() {
        assertEquals("EVOLUÇÃO DE PILOTO", DriverEvolutionEngine.newsTitle(1))
        assertEquals("REGRESSÃO DE PILOTO", DriverEvolutionEngine.newsTitle(-1))
        assertEquals("EVOLUÇÃO DE PILOTO", DriverEvolutionEngine.newsTitle(0))
    }

    @Test
    fun `younger drivers retain a stronger positive development curve`() {
        assertTrue(DriverEvolutionEngine.ageGrowthFactor(21) > DriverEvolutionEngine.ageGrowthFactor(34))
        assertEquals(0.0, DriverEvolutionEngine.ageDeclineRate(30), 0.0)
        assertTrue(DriverEvolutionEngine.ageDeclineRate(39) > 0.0)
    }
}
