package com.f1teammanager.core.manager

import com.f1teammanager.core.season.WorldDatabase
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class NextSeasonCarConstructionV636Test {
    private val engine = CarDevelopmentEngine()

    private fun uniformGarage(value: Int, reliability: Int = 73): TeamGarage {
        fun car(id: GarageCarId) = PhysicalCar(
            id = id,
            engine = value,
            chassis = value,
            frontWing = value,
            rearWing = value,
            brakes = value,
            electricPowerUnit = value,
            reliability = reliability,
            componentReliabilities = CarComponent.values().associateWith { reliability },
            installedPieces = CarComponent.values().associateWith { "${id.name}-${it.name}-V0" },
            installedPieceVersions = CarComponent.values().associateWith { 0 }
        )
        return TeamGarage(car(GarageCarId.CAR_1), car(GarageCarId.CAR_2))
    }

    @Test fun tableAndSingleTenPercentBonusMatchStudyExamplesIncludingZeroInvestment() {
        assertEquals(0, engine.referenceInvestmentForOverall(0))
        assertEquals(200_000L, engine.referenceInvestmentForOverall(1))
        assertEquals(7_800_000L, engine.referenceInvestmentForOverall(39))
        assertEquals(0, engine.constructionBaseOverallForInvestment(0L))
        assertEquals(0, engine.constructionOverallForInvestment(0L))
        assertEquals(5, engine.constructionBaseOverallForInvestment(1_000_000L))
        assertEquals(6, engine.constructionOverallForInvestment(1_000_000L))
        assertEquals(20, engine.constructionBaseOverallForInvestment(4_000_000L))
        assertEquals(22, engine.constructionOverallForInvestment(4_000_000L))
        assertEquals(39, engine.constructionBaseOverallForInvestment(7_800_000L))
        assertEquals(43, engine.constructionOverallForInvestment(7_800_000L))
        assertEquals(40, engine.constructionBaseOverallForInvestment(8_000_000L))
        assertEquals(44, engine.constructionOverallForInvestment(8_000_000L))
        assertEquals(59, engine.constructionBaseOverallForInvestment(43_000_000L))
        assertEquals(65, engine.constructionOverallForInvestment(43_000_000L))
        assertEquals(62, engine.constructionBaseOverallForInvestment(50_000_000L))
        assertEquals(68, engine.constructionOverallForInvestment(50_000_000L))
        assertEquals(70, engine.constructionBaseOverallForInvestment(70_000_000L))
        assertEquals(77, engine.constructionOverallForInvestment(70_000_000L))
        assertEquals(78, engine.constructionBaseOverallForInvestment(100_000_000L))
        assertEquals(86, engine.constructionOverallForInvestment(100_000_000L))
        assertEquals(90, engine.constructionBaseOverallForInvestment(130_000_000L))
        assertEquals(99, engine.constructionOverallForInvestment(130_000_000L))
        assertEquals(100, engine.constructionOverallForInvestment(150_000_000L))
        assertEquals(100, engine.constructionOverallForInvestment(250_000_000L))
        val investmentLadder = listOf(0L, 200_000L, 1_000_000L, 4_000_000L, 7_800_000L, 8_000_000L, 9_000_000L, 43_000_000L, 50_000_000L, 70_000_000L, 100_000_000L, 150_000_000L)
        val outputs = investmentLadder.map { engine.constructionOverallForInvestment(it)!! }
        assertTrue("Lower investment must not produce a stronger construction", outputs.zipWithNext().all { (a, b) -> a <= b })
    }

    @Test fun aiInvestmentReferenceInvertsTheBonusWithoutDoubleCountingIt() {
        assertEquals(39_000_000L, engine.investmentReferenceForNextSeasonTarget(60, 3))
        assertEquals(63, engine.constructionOverallForInvestment(
            engine.investmentReferenceForNextSeasonTarget(60, 3)
        ))
        assertEquals(56_000_000L, engine.investmentReferenceForNextSeasonTarget(70, 2))
        assertEquals(72, engine.constructionOverallForInvestment(
            engine.investmentReferenceForNextSeasonTarget(70, 2)
        ))
        assertEquals(116_000_000L, engine.investmentReferenceForNextSeasonTarget(90, 1))
        assertEquals(91, engine.constructionOverallForInvestment(
            engine.investmentReferenceForNextSeasonTarget(90, 1)
        ))
        assertEquals(114_000_000L, engine.investmentReferenceForNextSeasonTarget(90, 0))
        assertEquals(90, engine.constructionOverallForInvestment(
            engine.investmentReferenceForNextSeasonTarget(90, 0)
        ))
        // The table can skip some integer Overall values after rounding; choose the
        // smallest next reachable value rather than getting stuck at the same Overall.
        val stepped = engine.investmentReferenceForNextSeasonTarget(81, 1)
        assertEquals(83, engine.constructionOverallForInvestment(stepped))
        // At 100, choose the cheapest row that reaches 100 rather than needlessly
        // paying the €150M row.
        assertEquals(132_000_000L, engine.investmentReferenceForNextSeasonTarget(100, 1))
    }

    @Test fun uniformPhysicalCarsReachTheInvestmentTargetWithoutDuplicateBonuses() {
        val previous = uniformGarage(60)
        val built = engine.buildNextSeasonGarage(previous, 43_000_000L)
        assertEquals(65, built.teamAverageOverall)
        CarComponent.values().forEach { component ->
            assertEquals(65, built.car1.componentValue(component))
            assertEquals(65, built.car2.componentValue(component))
            assertEquals(previous.car1.installedPieces[component], built.car1.installedPieces[component])
            assertEquals(previous.car2.installedPieceVersions[component], built.car2.installedPieceVersions[component])
            assertEquals(73, built.car1.componentReliability(component))
        }
    }

    @Test fun pAndKnowledgeAndFocusSpecializeComponentsWithoutIncreasingTheTargetMean() {
        val previous = uniformGarage(60)
        val built = engine.buildNextSeasonGarage(
            previousGarage = previous,
            invested = 43_000_000L,
            focus = CarDevelopmentFocus.POWER,
            technicalKnowledge = mapOf(CarComponent.ENGINE to 5)
        )
        assertEquals(65, built.teamAverageOverall)
        assertTrue(built.car1.engine > built.car1.brakes)
        assertTrue(built.car1.electricPowerUnit > built.car1.brakes)
    }

    @Test fun zeroInvestmentBuildsTheMinimumCarInsteadOfPreservingOldPerformance() {
        val previous = uniformGarage(60)
        val builtWithoutInvestment = engine.buildNextSeasonGarage(
            previous, 0L, CarDevelopmentFocus.POWER, mapOf(CarComponent.ENGINE to 8)
        )
        assertEquals(1, builtWithoutInvestment.teamAverageOverall)
        assertTrue(builtWithoutInvestment.teamAverageOverall < previous.teamAverageOverall)
        CarComponent.values().forEach { component ->
            assertEquals(1, builtWithoutInvestment.car1.componentValue(component))
            assertEquals(1, builtWithoutInvestment.car2.componentValue(component))
            assertEquals(previous.car1.installedPieces[component], builtWithoutInvestment.car1.installedPieces[component])
            assertEquals(previous.car2.installedPieces[component], builtWithoutInvestment.car2.installedPieces[component])
            assertEquals(previous.car1.installedPieceVersions[component], builtWithoutInvestment.car1.installedPieceVersions[component])
            assertEquals(previous.car2.installedPieceVersions[component], builtWithoutInvestment.car2.installedPieceVersions[component])
            assertEquals(73, builtWithoutInvestment.car1.componentReliability(component))
            assertEquals(previous.car1.componentReliabilities, builtWithoutInvestment.car1.componentReliabilities)
        }

        val car1 = previous.car1.copy(
            frontWing = 0,
            installedPieces = previous.car1.installedPieces - CarComponent.FRONT_WING,
            installedPieceVersions = previous.car1.installedPieceVersions - CarComponent.FRONT_WING
        )
        val garageWithMissingPart = TeamGarage(car1, previous.car2)
        val built = engine.buildNextSeasonGarage(garageWithMissingPart, 150_000_000L)
        assertEquals(0, built.car1.frontWing)
        assertFalse(CarComponent.FRONT_WING in built.car1.installedPieces)
        assertTrue(built.teamAverageOverall < 100)
    }

    @Test fun zeroInvestmentForecastAndSeasonTransitionDoNotKeepThePreviousOverall() {
        val previousGarage = uniformGarage(60)
        val old = TeamCarState(
            aerodynamics = 60, chassis = 60, engine = 60, reliability = 73,
            frontWing = 60, rearWing = 60, brakes = 60, electricPowerUnit = 60,
            nextSeasonInvestment = 0L
        )
        val state = TeamManagerState(
            season = 2026, round = 30, playerTeamId = WorldDatabase.teams.first().id,
            car = old, garage = previousGarage, finance = TeamFinanceState(20_000_000L)
        )
        assertEquals(1, engine.nextSeasonForecast(state).projectedOverall)
        val next = engine.startNextSeason(state, 2027)
        assertEquals(1, next.garage!!.teamAverageOverall)
        assertEquals(0L, next.car.nextSeasonInvestment)
        assertTrue(next.history.last().contains("meta Overall 0/100"))
    }

    @Test fun playerSeasonTransitionUsesTheTableAndResetsInvestmentTracking() {
        val previousGarage = uniformGarage(60)
        val old = TeamCarState(
            aerodynamics = 60, chassis = 60, engine = 60, reliability = 73,
            frontWing = 60, rearWing = 60, brakes = 60, electricPowerUnit = 60,
            nextSeasonInvestment = 43_000_000L
        )
        val state = TeamManagerState(
            season = 2026, round = 30, playerTeamId = WorldDatabase.teams.first().id,
            car = old, garage = previousGarage, finance = TeamFinanceState(20_000_000L)
        )
        val next = engine.startNextSeason(state, 2027)
        assertEquals(2027, next.season)
        assertEquals(65, next.garage!!.teamAverageOverall)
        assertEquals(0L, next.car.nextSeasonInvestment)
        assertEquals(0L, next.car.nextSeasonInvestmentBudgetBase)
        assertEquals(CarDevelopmentFocus.BALANCED, next.car.nextSeasonFocus)
        assertEquals(73, next.car.reliability)
        assertTrue(next.history.last().contains("meta Overall 65/100"))
    }


    @Test fun physicalConstructionDoesNotGetStrongerWhenInvestmentFalls() {
        val uniform = uniformGarage(62)
        val skewed = TeamGarage(
            uniform.car1.copy(engine = 85, chassis = 45, frontWing = 70, rearWing = 55, brakes = 40, electricPowerUnit = 75),
            uniform.car2.copy(engine = 72, chassis = 50, frontWing = 60, rearWing = 48, brakes = 43, electricPowerUnit = 80)
        )
        val missingFront = TeamGarage(
            uniform.car1.copy(
                frontWing = 0,
                installedPieces = uniform.car1.installedPieces - CarComponent.FRONT_WING,
                installedPieceVersions = uniform.car1.installedPieceVersions - CarComponent.FRONT_WING
            ), uniform.car2
        )
        val denseBoundaryChecks = listOf(
            0L, 200_000L, 1_000_000L, 2_000_000L, 4_000_000L, 6_000_000L,
            7_800_000L, 8_000_000L, 9_000_000L, 10_000_000L, 13_000_000L,
            22_000_000L, 43_000_000L, 50_000_000L, 70_000_000L,
            86_000_000L, 100_000_000L, 110_000_000L, 130_000_000L, 150_000_000L
        )
        val fullApprovedTable = (40..100).map { engine.referenceInvestmentForOverall(it) }
            .distinct().sorted()
        fun assertMonotone(garage: TeamGarage, amounts: List<Long>) {
            var previousOverall = -1
            amounts.distinct().sorted().forEach { amount ->
                val output = engine.buildNextSeasonGarage(garage, amount).teamAverageOverall
                assertTrue("Investment $amount yielded $output after $previousOverall", output >= previousOverall)
                previousOverall = output
            }
        }
        assertMonotone(uniform, (denseBoundaryChecks + fullApprovedTable).distinct().sorted())
        assertMonotone(skewed, denseBoundaryChecks)
        assertMonotone(missingFront, denseBoundaryChecks)
    }

    @Test fun forecastDisplaysTheSameOverallThatConstructionWillUse() {
        val car = TeamCarState(
            aerodynamics = 65, chassis = 65, engine = 65, reliability = 65,
            frontWing = 65, rearWing = 65, brakes = 65, electricPowerUnit = 65,
            nextSeasonInvestment = 57_500_000L
        )
        val forecast = engine.nextSeasonForecast(
            TeamManagerState(car = car, finance = TeamFinanceState(100_000_000L))
        )
        assertEquals(72, forecast.projectedOverall)
        assertEquals(engine.performanceClassForOverall(72), forecast.projectedClass)
    }

    @Test fun forecastReportsAchievableOverallWhenPhysicalHardwareIsMissing() {
        val previous = uniformGarage(60)
        val car1 = previous.car1.copy(
            frontWing = 0,
            installedPieces = previous.car1.installedPieces - CarComponent.FRONT_WING,
            installedPieceVersions = previous.car1.installedPieceVersions - CarComponent.FRONT_WING
        )
        val garage = TeamGarage(car1, previous.car2)
        val car = TeamCarState(
            aerodynamics = 60, chassis = 60, engine = 60, reliability = 73,
            frontWing = 60, rearWing = 60, brakes = 60, electricPowerUnit = 60,
            nextSeasonInvestment = 150_000_000L
        )
        val state = TeamManagerState(
            season = 2026, playerTeamId = 1, car = car, garage = garage,
            finance = TeamFinanceState(200_000_000L)
        )
        val forecast = engine.nextSeasonForecast(state)
        val built = engine.buildNextSeasonGarage(garage, car.nextSeasonInvestment)
        assertEquals(built.teamAverageOverall, forecast.projectedOverall)
        assertTrue(forecast.projectedOverall < 100)
    }
}
