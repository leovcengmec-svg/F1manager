package com.f1teammanager.core.season

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNull
import kotlin.test.assertTrue

class DriverOverallNewsV728Test {
    @Test
    fun `attribute-only V725 V727 sporting cards are hidden from the overall feed`() {
        val message = "Gabriel Bortoleto — Sauber — GP 2: desenvolvimento esportivo independente da idade (VEL +1)."
        assertTrue(
            DriverEvolutionEngine.isLegacyAttributeMovementNews("EVOLUÇÃO ESPORTIVA", message)
        )
        assertNull(DriverEvolutionEngine.normalizeOverallMovementNews(message))
    }

    @Test
    fun `legacy overall card keeps the original reason when normalized`() {
        val legacy = "Gabriel Bortoleto — Sauber — GP 2: evolução dos atributos. Overall 82 → 83 (+1). Motivo: desempenho esportivo acima das expectativas."
        assertEquals(
            "Gabriel Bortoleto — Sauber — GP 2: evoluiu Overall 82 → 83 (+1). Motivo: desempenho esportivo acima das expectativas.",
            DriverEvolutionEngine.normalizeOverallMovementNews(legacy)
        )
    }

    @Test
    fun `legacy development center overall card receives its specific reason`() {
        val legacy = "Gabriel Bortoleto — Sauber — Overall 82 → 83 (+1) após desenvolvimento."
        assertEquals(
            "Gabriel Bortoleto — Sauber: evoluiu Overall 82 → 83 (+1). Motivo: programa de desenvolvimento de piloto concluído.",
            DriverEvolutionEngine.normalizeOverallMovementNews(legacy)
        )
    }

    @Test
    fun `reasonless duplicate GP overall card is not published`() {
        val incomplete = "Gabriel Bortoleto — Sauber — GP 2: Overall 82 → 83 (+1)."
        assertNull(DriverEvolutionEngine.normalizeOverallMovementNews(incomplete))
    }

    @Test
    fun `cycle rollover publishes only an overall regression with full cause`() {
        val reason = "reinício do ciclo etário: concluiu a temporada aos 45 anos e iniciou novo ciclo aos 16, com redução de 30% em cada atributo, aplicada individualmente e limitada ao piso 40; identidade, classe e perfil de evolução preservados"
        val message = DriverEvolutionEngine.overallSeasonMovementNews(
            "Niki Lauda", "Ferrari", 2031, 90, 64, reason
        )
        assertEquals(
            "Niki Lauda — Ferrari — abertura da temporada 2031: perdeu Overall 90 → 64 (-26). Motivo: $reason.",
            message
        )
        assertTrue(!message!!.contains("VEL") && !message.contains("CHU") && !message.contains("CLA"))
        assertEquals(message, DriverEvolutionEngine.normalizeOverallMovementNews(message))
    }

    @Test
    fun `non movement driver events are not treated as legacy attribute cards`() {
        assertTrue(
            !DriverEvolutionEngine.isLegacyAttributeMovementNews(
                "PROMOÇÃO DE CLASSE",
                "Sebastian Montoya foi promovido de Médio para Pro após duas temporadas de desempenho consistente."
            )
        )
        assertTrue(
            !DriverEvolutionEngine.isLegacyAttributeMovementNews(
                "PROGRAMA DE DESENVOLVIMENTO CONCLUÍDO",
                "O programa de desenvolvimento de Mari Boya foi concluído."
            )
        )
    }
}
