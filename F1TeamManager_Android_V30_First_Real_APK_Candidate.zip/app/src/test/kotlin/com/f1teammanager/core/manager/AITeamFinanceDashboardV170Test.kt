package com.f1teammanager.core.manager

import com.f1teammanager.core.season.WorldDatabase
import org.junit.Test
import kotlin.test.assertTrue

class AITeamFinanceDashboardV170Test {
    @Test
    fun `AI race and development transactions are reflected in seasonal ledger`() {
        val team = WorldDatabase.teams.first()
        val market = DriverMarketState()
        val engine = AITeamFinancialEngine(170)
        val initial = engine.beginSeason(team.id, 2026, market).finance
        val sponsorship = TeamSponsorshipEngine.TeamSponsorshipState(
            teamId = team.id,
            season = 2026,
            sponsors = emptyList(),
            annualGuaranteedIncome = 0L
        )

        val afterRace = engine.applyRace(team.id, 2026, 1, sponsorship, market, bestFinish = 5, points = 0).finance
        assertTrue(afterRace.seasonIncome > initial.seasonIncome, "Premiação de corrida deve entrar em receitas")
        assertTrue(afterRace.seasonExpenses > initial.seasonExpenses, "Custos de corrida devem entrar em despesas")

        val beforeDevelopmentExpenses = afterRace.seasonExpenses
        val capacity = engine.developmentCapacity(team.id, 2026)
        val requestedSpend = minOf(2_000_000L, capacity)
        if (requestedSpend > 0L) {
            engine.applyDevelopmentCost(team.id, 2026, capacity - requestedSpend, capacity)
            val afterDevelopment = engine.state(team.id, 2026).finance
            assertTrue(afterDevelopment.seasonExpenses > beforeDevelopmentExpenses, "Gasto de P&D deve entrar em despesas da temporada")
        }
    }

    @Test
    fun `AI sponsor objectives use the same qualifying range and race target rules as player`() {
        val team = WorldDatabase.teams.first()
        val market = DriverMarketState()
        val sponsor = SponsorContract(
            name = "Parity",
            upfront = 0L,
            racePayment = 0L,
            pointsBonus = 0L,
            years = 1,
            minimumReputation = 0,
            slot = 1,
            qualifyingTarget = 3,
            qualifyingBonus = 100_000L,
            raceTarget = 5,
            raceTargetBonus = 200_000L,
            active = true,
            races = 5,
            racesRemaining = 5,
            qualifyingTargetMin = 2,
            qualifyingTargetMax = 4,
            raceTargetMin = 1,
            raceTargetMax = 10
        )
        val sponsorship = TeamSponsorshipEngine.TeamSponsorshipState(
            teamId = team.id,
            season = 2026,
            sponsors = listOf(sponsor),
            annualGuaranteedIncome = 0L
        )
        val engine = AITeamFinancialEngine(171)
        val before = engine.beginSeason(team.id, 2026, market).finance
        val after = engine.applyRace(
            team.id, 2026, 1, sponsorship, market,
            bestFinish = 8, points = 0, isDnf = false, bestQualifyingPosition = 4
        ).finance
        assertTrue(after.seasonIncome - before.seasonIncome >= 100_000L,
            "A posição 4 deve cumprir a faixa de qualificação inclusiva 2..4")
        assertTrue(after.transactions.any { it.contains("Bônus por meta de qualificação") },
            "O bônus de qualificação deve aparecer no extrato")
        assertTrue(after.transactions.none { it.contains("200000") || it.contains("200_000") },
            "A chegada em P8 não deve cumprir meta de corrida P5 só porque um intervalo foi configurado")
    }
}
