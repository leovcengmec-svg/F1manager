package com.f1teammanager.core.season

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class DriverEvolutionChartModelV735Test {
    private fun row(season: Int, age: Int, cycle: Int, overall: Int, event: String) =
        DriverEvolutionSnapshot(77, season, age, cycle, overall, List(7) { overall }, event)

    @Test fun chartShowsOnlyNewestCycleAndKeepsItsTwoEndpoints() {
        val rows = listOf(
            row(2026, 24, 0, 80, "BASELINE"),
            row(2027, 25, 0, 82, "SEASON_END"),
            row(2032, 16, 1, 58, "CYCLE_RESET"),
            row(2033, 19, 1, 60, "SEASON_END"),
            row(2034, 20, 1, 63, "SEASON_END")
        )
        val active = DriverEvolutionChartModel.currentCycle(rows)
        assertEquals(listOf(2032, 2033, 2034), active.map { it.season })
        val endpoints = DriverEvolutionChartModel.endpoints(rows)!!
        assertEquals(2032, endpoints.first.season)
        assertEquals(2034, endpoints.second.season)
        assertEquals(80, rows.first().overall) // archived cycle remains untouched
    }

    @Test fun chartWithoutSnapshotsHasNoEndpoints() {
        assertNull(DriverEvolutionChartModel.endpoints(emptyList()))
    }
}
