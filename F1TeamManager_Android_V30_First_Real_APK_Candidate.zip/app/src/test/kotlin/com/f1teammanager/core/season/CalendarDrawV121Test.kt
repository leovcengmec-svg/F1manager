package com.f1teammanager.core.season

object CalendarDrawV121Test {
    @JvmStatic fun main(args: Array<String>) {
        val seeds = listOf(101, 202, 303, 404, 505)
        val calendars = seeds.map { seed ->
            SeasonCalendar.configureSeasonSeed(2026, seed)
            SeasonCalendar.forSeason(2026)
        }
        require(calendars.all { it.size == 30 }) { "Cada temporada deve ter 30 GPs" }
        require(calendars.all { it.map { r -> r.circuit }.distinct().size == 30 }) { "Calendário contém circuito repetido" }
        require(calendars.map { it.map { r -> r.circuit } }.distinct().size > 1) { "Sorteio não varia entre sementes" }
        val first = calendars.first().map { it.circuit }
        SeasonCalendar.configureSeasonSeed(2026, 101)
        require(first == SeasonCalendar.forSeason(2026).map { it.circuit }) { "Calendário não é estável para a mesma semente" }
        require(SeasonCalendar.allGps.size == 50) { "Base deve conter 50 GPs" }
        println("V121_CALENDAR_DRAW_OK pool=${SeasonCalendar.allGps.size} selected=30 unique=true variable=true stable=true")
    }
}
