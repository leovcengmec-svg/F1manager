package com.f1teammanager.core.race

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** Regression contract for V616 Safety Car peloton bunching. */
class SafetyCarGroupingV616Test {
    @Test
    fun gapsWithinQueueTargetDoNotReceiveArtificialCatchUp() {
        assertEquals(0L, SafetyCarGroupingModel.catchUpMilliseconds(0L))
        assertEquals(0L, SafetyCarGroupingModel.catchUpMilliseconds(SafetyCarGroupingModel.TARGET_GAP_MS))
        assertEquals(0L, SafetyCarGroupingModel.catchUpMilliseconds(1_400L))
    }

    @Test
    fun safetyCarLapProgressivelyReducesGapWithoutRewritingCompletedTiming() {
        val referenceLap = 75_000L
        val safetyCarLap = referenceLap + 9_000L
        val previousGap = 5_000L
        val followerLap = SafetyCarGroupingModel.applyCatchUp(
            lapTimeWithSafetyCarPenaltyMs = safetyCarLap,
            gapBehindLeaderMs = previousGap,
            circuitReferenceLapMs = referenceLap
        )

        val nextGap = previousGap + followerLap - safetyCarLap
        assertTrue("A Safety Car lap should reduce a gap larger than the queue target", nextGap < previousGap)
        assertEquals(2_900L, nextGap)
    }

    @Test
    fun largeGapsCloseProgressivelyAndNeutralisedLapRemainsPlausible() {
        val referenceLap = 75_000L
        val scLap = referenceLap + 9_000L
        val adjusted = SafetyCarGroupingModel.applyCatchUp(
            lapTimeWithSafetyCarPenaltyMs = scLap,
            gapBehindLeaderMs = 80_000L,
            circuitReferenceLapMs = referenceLap
        )

        assertEquals(referenceLap + SafetyCarGroupingModel.MIN_LAP_EXTRA_MS, adjusted)
        assertTrue(adjusted >= referenceLap + SafetyCarGroupingModel.MIN_LAP_EXTRA_MS)
        assertEquals(SafetyCarGroupingModel.MAX_CATCH_UP_PER_LAP_MS, SafetyCarGroupingModel.catchUpMilliseconds(80_000L))
    }

    @Test
    fun deployedSafetyCarNarrowsTheActualRaceGapAndDisablesDrs() {
        val participants = (1..80).map { id ->
            val teamId = ((id - 1) / 2) + 1
            RaceParticipant(
                driverId = id, driverName = "Driver $id", teamId = teamId, teamName = "Team $teamId",
                driverSpeed = 40 + (id % 61), qualifying = 40 + (id % 61),
                overtaking = 60, defense = 60, consistency = 70, enginePerformance = 60,
                tyreGrip = 60, tyreWear = 60, reliability = 100, wetSkill = 60,
                chassisPerformance = 60, frontWingPerformance = 60, rearWingPerformance = 60,
                brakesPerformance = 60, electricPowerUnitPerformance = 60,
                engineReliability = 100, chassisReliability = 100, frontWingReliability = 100,
                rearWingReliability = 100, brakesReliability = 100, electricPowerUnitReliability = 100
            )
        }
        val originalCircuit = RaceCircuit(616, "V616 Safety Car regression GP", 12, 75_500L, 0.0, 0.0, 0.0)
        val engine = CareerWeekendEngine(20261018)
        engine.start(participants, originalCircuit, playerTeamId = 1)
        engine.simulateQualifyingInstantly()
        var snapshot = engine.snapshotForUi()

        fun settlePendingDecisions() {
            var guard = 0
            while (snapshot.decision != null && guard++ < 10) {
                snapshot = engine.choose(ManagerDecisionAction.STAY_OUT)
            }
            check(guard < 10) { "Manager decision loop did not resolve" }
        }
        repeat(4) {
            settlePendingDecisions()
            snapshot = engine.advance()
            settlePendingDecisions()
        }
        fun fieldSpreadMs(): Long {
            val active = snapshot.classification.filter { it.status != "DNF" }
            return active.maxOf { it.totalTimeMs } - active.minOf { it.totalTimeMs }
        }
        val spreadBefore = fieldSpreadMs()
        val totalsBefore = snapshot.classification.associate { it.driverId to it.totalTimeMs }

        // Force a Safety Car after four green laps without exposing a production-only test hook.
        // The engine is intentionally initialized with a valid circuit; only this regression
        // test raises the private risk multiplier so deployment is deterministic.
        val circuitField = engine.javaClass.getDeclaredField("circuit").apply { isAccessible = true }
        circuitField.set(engine, originalCircuit.copy(safetyCarRisk = 1_000.0))
        snapshot = engine.advance()
        assertEquals(Neutralisation.SAFETY_CAR, snapshot.neutral)
        assertTrue(snapshot.events.any { it.type == EventType.SAFETY_CAR_DEPLOYED })
        settlePendingDecisions()
        snapshot = engine.advance() // continue the paused lap after manager responses

        val spreadAfter = fieldSpreadMs()
        assertTrue("Safety Car must close the field: before=$spreadBefore after=$spreadAfter", spreadAfter < spreadBefore)
        assertTrue("Completed timing must remain cumulative", snapshot.classification.all { entry ->
            entry.totalTimeMs >= (totalsBefore[entry.driverId] ?: 0L)
        })
        assertTrue("DRS must be disabled under Safety Car", snapshot.carStatus.none { it.drsActive })
    }
}
