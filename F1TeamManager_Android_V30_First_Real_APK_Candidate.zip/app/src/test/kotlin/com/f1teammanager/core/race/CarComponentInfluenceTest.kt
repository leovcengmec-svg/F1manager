package com.f1teammanager.core.race

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

class CarComponentInfluenceTest {
    @Test fun tenLevelsUseOfficial40To100Bands() {
        assertEquals(1, CarComponentInfluence.level(40))
        assertEquals(1, CarComponentInfluence.level(45))
        assertEquals(2, CarComponentInfluence.level(46))
        assertEquals(9, CarComponentInfluence.level(93))
        assertEquals(10, CarComponentInfluence.level(94))
        assertEquals(10, CarComponentInfluence.level(100))
    }

    @Test fun engineUsesAverageGpLapTimeAndImprovesWithLevel() {
        val c = RaceCircuit(1, "Teste", 60, 90_000L)
        val slow = RaceParticipant(driverId=1,driverName="A",teamId=1,teamName="T",driverSpeed=70,qualifying=70,overtaking=70,defense=70,consistency=70,enginePerformance=40,tyreGrip=50,tyreWear=50,reliability=95,chassisWear=0,wetSkill=50,chassisPerformance=50,frontWingPerformance=50,rearWingPerformance=50,brakesPerformance=50,electricPowerUnitPerformance=50)
        val fast = slow.copy(enginePerformance=100)
        val model = PitwallPaceModel(kotlin.random.Random(1))
        assertTrue(model.engineEffect(slow,c) > model.engineEffect(fast,c))
        assertEquals(2_700L, model.engineEffect(slow,c))
        assertEquals(-2_520L, model.engineEffect(fast,c))
    }

    @Test fun continuousRatingsDoNotCollapseHighOverallCarsIntoTheSameBand() {
        assertTrue(CarComponentInfluence.engineLapModifier(99) < CarComponentInfluence.engineLapModifier(90))
        assertTrue(CarComponentInfluence.chassisLapModifier(99) < CarComponentInfluence.chassisLapModifier(90))
        assertTrue(CarComponentInfluence.frontWingLapModifier(99) < CarComponentInfluence.frontWingLapModifier(90))
        assertTrue(CarComponentInfluence.rearWingLapModifier(99) < CarComponentInfluence.rearWingLapModifier(90))
        assertTrue(CarComponentInfluence.brakeLapModifier(99) < CarComponentInfluence.brakeLapModifier(90))
        assertTrue(CarComponentInfluence.electricPowerUnitLapModifier(99) < CarComponentInfluence.electricPowerUnitLapModifier(90))
    }

    @Test fun chassisAddsTimeEffectAndReducesLapVariationAmplitude() {
        val c = RaceCircuit(1, "Teste", 60, 90_000L)
        val low = RaceParticipant(driverId=1,driverName="A",teamId=1,teamName="T",driverSpeed=70,qualifying=70,overtaking=70,defense=70,consistency=70,enginePerformance=50,tyreGrip=50,tyreWear=50,reliability=95,chassisWear=0,wetSkill=50,chassisPerformance=40,frontWingPerformance=50,rearWingPerformance=50,brakesPerformance=50,electricPowerUnitPerformance=50)
        val high = low.copy(chassisPerformance=100)
        val model = PitwallPaceModel(kotlin.random.Random(2))
        assertTrue(model.chassisEffect(low,c) > model.chassisEffect(high,c))
        assertTrue(CarComponentInfluence.chassisStabilityReduction(100) > CarComponentInfluence.chassisStabilityReduction(40))
    }
}
