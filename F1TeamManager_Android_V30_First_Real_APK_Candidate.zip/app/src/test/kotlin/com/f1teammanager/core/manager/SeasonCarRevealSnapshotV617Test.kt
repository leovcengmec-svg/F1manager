package com.f1teammanager.core.manager

import com.f1teammanager.core.season.WorldDatabase
import org.junit.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue
import kotlin.math.roundToInt

class SeasonCarRevealSnapshotV617Test {
    @Test
    fun revealStagesMatchCanonicalInvestmentInheritanceAndRegulationCalculations() {
        val development = CarDevelopmentEngine()
        val team = WorldDatabase.teams.first()
        val starting = TeamGarageFactory.fromInitial(team, playerCareer = true)
        val knowledge = CarComponent.values().associateWith { 2 }
        val oldCar = TeamCarState(
            aerodynamics = starting.teamAverageOverall,
            chassis = starting.teamAverageOverall,
            engine = starting.teamAverageOverall,
            reliability = (starting.car1.reliability + starting.car2.reliability) / 2,
            frontWing = starting.teamAverageOverall,
            rearWing = starting.teamAverageOverall,
            brakes = starting.teamAverageOverall,
            electricPowerUnit = starting.teamAverageOverall,
            nextSeasonInvestment = 100_000_000L,
            nextSeasonFocus = CarDevelopmentFocus.BALANCED,
            developmentKnowledge = knowledge
        )
        val steps = development.nextSeasonInvestmentSteps(starting.teamAverageOverall, oldCar.nextSeasonInvestment)

        fun carry(car: PhysicalCar): PhysicalCar {
            fun value(component: CarComponent) = development.nextSeasonPhysicalComponentValue(
                previousValue = car.componentValue(component),
                installed = component in car.installedPieces,
                investmentSteps = steps,
                focus = oldCar.nextSeasonFocus,
                component = component,
                technicalKnowledge = knowledge[component] ?: 0
            )
            val values = CarComponent.values().associateWith { value(it) }
            val rel = CarComponent.values().associateWith { (car.componentReliability(it) + steps / 2).coerceIn(1, 100) }
            return car.copy(
                engine = values.getValue(CarComponent.ENGINE),
                chassis = values.getValue(CarComponent.CHASSIS),
                frontWing = values.getValue(CarComponent.FRONT_WING),
                rearWing = values.getValue(CarComponent.REAR_WING),
                brakes = values.getValue(CarComponent.BRAKES),
                electricPowerUnit = values.getValue(CarComponent.ELECTRIC_POWER_UNIT),
                componentReliabilities = rel,
                reliability = rel.values.average().roundToInt().coerceIn(1, 100)
            )
        }
        val unregulated = TeamGarage(carry(starting.car1), carry(starting.car2))
        val rule = AnnualCarRegulationEngine.generate(2027, 617)
        val regulated = AnnualCarRegulationEngine.applyToGarage(unregulated, rule, team.id)
        val reveal = SeasonCarRevealSnapshotBuilder.build(
            season = 2027, teamId = team.id, previousCar = oldCar, previousGarage = starting,
            finalRegulatedGarage = regulated, development = development
        )

        assertEquals(starting.teamAverageOverall, reveal.startingOverall)
        assertEquals(unregulated.teamAverageOverall, reveal.inheritedOverall)
        assertEquals(regulated.teamAverageOverall, reveal.finalOverall)
        assertEquals(oldCar.nextSeasonInvestment, reveal.investmentAmount)
        assertEquals(steps, reveal.investmentSteps)
        assertEquals(regulated.car1.reliability.let { (it + regulated.car2.reliability + 1) / 2 }, reveal.finalReliability)
        assertTrue(reveal.investmentOverall in 0..100)
    }
}
