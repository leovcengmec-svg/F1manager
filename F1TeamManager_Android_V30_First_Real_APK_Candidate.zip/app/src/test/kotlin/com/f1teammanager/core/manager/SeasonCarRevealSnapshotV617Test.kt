package com.f1teammanager.core.manager

import com.f1teammanager.core.season.WorldDatabase
import org.junit.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue
import kotlin.math.roundToInt

class SeasonCarRevealSnapshotV617Test {
    @Test
    fun revealStagesMatchTableDrivenConstructionAndSingleRegulation() {
        val development = CarDevelopmentEngine()
        val team = WorldDatabase.teams.first()
        val starting = TeamGarageFactory.fromInitial(team, playerCareer = true)
        val knowledge = CarComponent.values().associateWith { 2 }
        val oldCar = TeamCarState(
            aerodynamics = starting.teamAverageOverall,
            chassis = starting.teamAverageOverall,
            engine = starting.teamAverageOverall,
            reliability = (starting.car1.reliability + starting.car2.reliability) / 2,
            frontWing = starting.teamAverageOverall,
            rearWing = starting.teamAverageOverall,
            brakes = starting.teamAverageOverall,
            electricPowerUnit = starting.teamAverageOverall,
            nextSeasonInvestment = 100_000_000L,
            nextSeasonFocus = CarDevelopmentFocus.BALANCED,
            developmentKnowledge = knowledge
        )
        val investmentStage = development.buildNextSeasonGarage(
            previousGarage = starting, invested = oldCar.nextSeasonInvestment,
            focus = oldCar.nextSeasonFocus, technicalKnowledge = emptyMap(),
            applyTechnicalSpecialization = false
        )
        val technicalStage = development.buildNextSeasonGarage(
            previousGarage = starting, invested = oldCar.nextSeasonInvestment,
            focus = oldCar.nextSeasonFocus, technicalKnowledge = knowledge
        )
        val rule = AnnualCarRegulationEngine.generate(2027, 617)
        val regulated = AnnualCarRegulationEngine.applyToGarage(technicalStage, rule, team.id)
        val reveal = SeasonCarRevealSnapshotBuilder.build(
            season = 2027, teamId = team.id, previousCar = oldCar, previousGarage = starting,
            finalRegulatedGarage = regulated, development = development
        )

        assertEquals(starting.teamAverageOverall, reveal.startingOverall)
        assertEquals(investmentStage.teamAverageOverall, reveal.investmentOverall)
        assertEquals(technicalStage.teamAverageOverall, reveal.inheritedOverall)
        assertEquals("P&D/focus may specialize but not raise the build's mean",
            investmentStage.teamAverageOverall, technicalStage.teamAverageOverall)
        assertEquals(86, reveal.investmentOverall)
        assertEquals(regulated.teamAverageOverall, reveal.finalOverall)
        assertEquals(oldCar.nextSeasonInvestment, reveal.investmentAmount)
        assertEquals(development.nextSeasonInvestmentSteps(starting.teamAverageOverall, oldCar.nextSeasonInvestment), reveal.investmentSteps)
        assertEquals((regulated.car1.reliability + regulated.car2.reliability + 1) / 2, reveal.finalReliability)
    }
}
