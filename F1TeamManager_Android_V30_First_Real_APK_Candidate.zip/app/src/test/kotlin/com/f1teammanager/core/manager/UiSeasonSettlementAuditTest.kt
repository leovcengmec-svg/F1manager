package com.f1teammanager.core.manager

fun main() {
    val points = (1..40).associateWith { id -> 4000 - id * 37 }
    val playerTeam = 17
    val settlement = SeasonSettlementEngine.forTeam(playerTeam, points)
        ?: error("Player team was not ranked")

    check(settlement.position in 1..40)
    check(settlement.prize == SeasonPrizeEngine.prizeForPosition(settlement.position))
    check(SeasonPrizeEngine.prizeForPosition(1) == 100_000_000L)
    check(SeasonPrizeEngine.prizeForPosition(40) == 10_000_000L)
    check((1..39).all { SeasonPrizeEngine.prizeForPosition(it) > SeasonPrizeEngine.prizeForPosition(it + 1) })
    check(SeasonSettlementEngine.rank(points).size == 40)
    check(SeasonSettlementEngine.rank(points).map { it.first }.distinct().size == 40)

    println("UiSeasonSettlementAuditTest: PASS | team=$playerTeam | position=${settlement.position} | prize=${settlement.prize}")
}
