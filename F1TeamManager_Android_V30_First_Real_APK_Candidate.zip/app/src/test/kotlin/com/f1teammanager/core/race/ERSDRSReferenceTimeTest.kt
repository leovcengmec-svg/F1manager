package com.f1teammanager.core.race

import kotlin.random.Random
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

class ERSDRSReferenceTimeTest {
    private val circuit = RaceCircuit(1, "Interlagos", 71, 75_500L)
    private val participant = RaceParticipant(
        driverId=1, driverName="A", teamId=1, teamName="T", driverSpeed=70, qualifying=70, overtaking=70,
        defense=70, consistency=70, enginePerformance=70, tyreGrip=70, tyreWear=70, reliability=95, chassisWear=0, wetSkill=50,
        chassisPerformance=70, frontWingPerformance=70, rearWingPerformance=70, brakesPerformance=70, electricPowerUnitPerformance=70
    )

    @Test fun ersUsesOnePercentOfReferenceLapAndBatteryCharge() {
        val pace = PitwallPaceModel(Random(1))
        // 75,500 ms * 1% * (94% / 90%) * 100% charge = 788 ms (integer).
        assertEquals(788L, pace.ersGainMs(participant, circuit, 100.0))
        assertEquals(394L, pace.ersGainMs(participant, circuit, 50.0))
    }

    @Test fun drsUsesOnePointFivePercentAndWing40_60Weight() {
        val pace = PitwallPaceModel(Random(2))
        // Front N6=90%, rear N6=88% -> combined 88.8%.
        // 75,500 * 1.5% * 88.8% = 1,006 ms.
        assertEquals(1006L, pace.drsGainMs(participant, circuit))
    }

    @Test fun longerReferenceLapProducesProportionallyLargerPotential() {
        val pace = PitwallPaceModel(Random(3))
        val short = pace.ersGainMs(participant, RaceCircuit(2, "A", 60, 60_000L), 100.0)
        val long = pace.ersGainMs(participant, RaceCircuit(3, "B", 60, 90_000L), 100.0)
        assertTrue(long > short)
        assertEquals(1.5, long.toDouble() / short.toDouble(), 0.01)
    }
}
