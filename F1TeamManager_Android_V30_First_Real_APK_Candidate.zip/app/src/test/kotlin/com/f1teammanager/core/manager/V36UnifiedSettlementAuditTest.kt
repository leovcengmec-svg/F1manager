package com.f1teammanager.core.manager

fun main() {
    // Deliberately omit half the teams: a real championship can have teams with 0 points.
    // The settlement must still rank and pay all 40 teams.
    val points = (1..20).associateWith { (21 - it) * 10 }
    val all = SeasonSettlementEngine.settleAll(points)
    check(all.size == 40)
    check(all.map { it.teamId }.toSet().size == 40)
    check(all.map { it.position }.toSet().size == 40)
    check(all.first().prize == 100_000_000L)
    check(all.last().prize == 10_000_000L)
    check(all.sumOf { it.prize } == (1..40).sumOf { SeasonPrizeEngine.prizeForPosition(it) })
    check(all.count { it.teamId !in points.keys && it.position > 20 } == 20)
    println("V36_UNIFIED_SETTLEMENT_PASS")
}
