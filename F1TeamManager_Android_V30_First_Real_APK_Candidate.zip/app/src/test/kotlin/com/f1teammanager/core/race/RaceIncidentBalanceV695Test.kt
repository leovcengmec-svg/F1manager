package com.f1teammanager.core.race

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.random.Random

class RaceIncidentBalanceV695Test {
    @Test
    fun `field wide crash probability is materially lower than previous two percent per lap`() {
        assertEquals(0.006, RaceIncidentBalance.crashChancePerLap(1.0), 0.000001)
        assertEquals(0.009, RaceIncidentBalance.crashChancePerLap(1.5), 0.000001)
        assertTrue(RaceIncidentBalance.crashChancePerLap(1.0) < 0.020)
    }

    @Test
    fun `lower consistency increases crash exposure`() {
        assertTrue(
            RaceIncidentBalance.driverRiskWeight(50, 82, Weather.DRY) >
                RaceIncidentBalance.driverRiskWeight(95, 82, Weather.DRY)
        )
    }

    @Test
    fun `poor wet skill increases heavy rain crash exposure`() {
        assertTrue(
            RaceIncidentBalance.driverRiskWeight(80, 50, Weather.HEAVY_RAIN) >
                RaceIncidentBalance.driverRiskWeight(80, 95, Weather.HEAVY_RAIN)
        )
    }

    @Test
    fun `weighted selection remains deterministic for the same seed`() {
        val drivers = listOf(
            RaceParticipant(1, "A", 1, "T1", 80, 80, 80, 80, 98, 80, wetSkill = 95),
            RaceParticipant(2, "B", 2, "T2", 80, 80, 80, 80, 45, 80, wetSkill = 45)
        )
        val first = RaceIncidentBalance.selectDriverId(drivers, Weather.HEAVY_RAIN, Random(695))
        val second = RaceIncidentBalance.selectDriverId(drivers, Weather.HEAVY_RAIN, Random(695))
        assertEquals(first, second)
    }
}
