package com.f1teammanager.core.manager

import com.f1teammanager.core.season.WorldDatabase
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class NextSeasonCarConsistencyV732Test {
    private class MemoryCheckpointStore : AITeamDevelopmentCheckpointStore {
        private val rows = mutableListOf<AITeamDevelopmentHistoricalCheckpoint>()
        override fun loadCandidates(teamId: Int, beforeSeason: Int): List<AITeamDevelopmentHistoricalCheckpoint> =
            rows.filter { it.teamId == teamId && it.openingSeason < beforeSeason }
        override fun save(checkpoint: AITeamDevelopmentHistoricalCheckpoint) {
            rows.removeAll { it.teamId == checkpoint.teamId && it.openingSeason == checkpoint.openingSeason && it.fingerprint == checkpoint.fingerprint }
            rows += checkpoint
        }
    }

    @Test fun officialProjectionUsesSamePhysicalBuilderAndAppliesRegulationOnce() {
        val team = WorldDatabase.teams.first()
        val previous = TeamGarageFactory.fromInitial(team)
        val development = CarDevelopmentEngine()
        val investment = 59_000_000L
        val unregulated = NextSeasonCarProjectionEngine.buildUnregulatedGarage(
            previousGarage = previous,
            committedInvestment = investment,
            isPlayerTeam = false,
            development = development
        )
        assertEquals(development.buildAiNextSeasonGarage(previous, investment), unregulated)

        val rule = AnnualCarRegulationEngine.generateForCalendarYear(2028, 7_312)
        val once = AnnualCarRegulationEngine.applyToGarage(unregulated, rule, team.id.hashCode())
        val official = NextSeasonCarProjectionEngine.buildOfficialGarage(
            teamId = team.id,
            previousGarage = previous,
            committedInvestment = investment,
            nextSeason = 2028,
            regulationSeed = 7_312,
            isPlayerTeam = false,
            development = development
        )
        assertEquals("Official projection must apply the same regulation once", once, official)
    }

    @Test fun allFortyTeamRankingsAndSeasonOpeningUseTheSameOfficialGarageSnapshot() {
        val store = MemoryCheckpointStore()
        val development = AITeamDevelopmentEngine(
            seed = 73_210,
            regulationSeed = 73_211,
            checkpointStore = store,
            careerScope = "V732_ALL_40"
        )
        WorldDatabase.teams.forEachIndexed { index, team ->
            val previous = TeamGarageFactory.fromInitial(team)
            val investment = (index * 3_250_000L).coerceAtMost(150_000_000L)
            val official = NextSeasonCarProjectionEngine.buildOfficialGarage(
                teamId = team.id,
                previousGarage = previous,
                committedInvestment = investment,
                nextSeason = 2029,
                regulationSeed = 73_211,
                isPlayerTeam = false
            )
            development.persistCanonicalSeasonOpening(
                team = team,
                openingSeason = 2029,
                garage = official,
                facilities = FacilityEngine.initial(team.initialLevel),
                nextSeasonInvestments = mapOf(2028 to investment),
                investmentRankingSnapshot = mapOf(team.id to (index + 1))
            )
            val opening = development.simulateFinancial(
                team = team,
                elapsedWeeks = 0,
                season = 2029,
                startingBudget = InitialTeamProfile.initialBudget(team),
                startingFacilities = FacilityEngine.initial(team.initialLevel),
                nextSeasonInvestments = mapOf(2028 to investment),
                investmentRankingSnapshot = mapOf(team.id to (40 - index)),
                publishLiveOverall = false
            ).garage
            assertEquals("${team.name} must open with its frozen official next-season garage", official, opening)
        }
    }

    @Test fun canonicalGp30SnapshotOverridesHistoricalReplayForOpeningGarage() {
        val team = WorldDatabase.teams.first()
        val store = MemoryCheckpointStore()
        val engine = AITeamDevelopmentEngine(
            seed = 73_201,
            regulationSeed = 73_202,
            checkpointStore = store,
            careerScope = "V732_TEST"
        )
        val base = TeamGarageFactory.fromInitial(team)
        val canonical = base.copy(
            car1 = base.car1.copy(engine = (base.car1.engine + 7).coerceAtMost(100)),
            car2 = base.car2.copy(chassis = (base.car2.chassis + 5).coerceAtMost(100))
        ).normalized()
        val facilities = FacilityEngine.initial(team.initialLevel)
        engine.persistCanonicalSeasonOpening(
            team = team,
            openingSeason = 2028,
            garage = canonical,
            facilities = facilities,
            nextSeasonInvestments = emptyMap(),
            investmentRankingSnapshot = mapOf(team.id to 40)
        )

        val opening = engine.simulateFinancial(
            team = team,
            elapsedWeeks = 0,
            season = 2028,
            startingBudget = 1L,
            startingFacilities = facilities,
            nextSeasonInvestments = emptyMap(),
            investmentRankingSnapshot = mapOf(team.id to 1),
            publishLiveOverall = false
        )
        assertEquals(canonical, opening.garage)
        assertEquals(canonical.teamAverageOverall, opening.car.let { opening.garage!!.teamAverageOverall })
        assertTrue(store.loadCanonicalOpening(team.id, 2028) != null)
    }
}
