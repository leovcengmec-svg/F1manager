package com.f1teammanager.core.season

import kotlin.random.Random
import org.junit.Assert.*
import org.junit.Test

class DriverClassCeilingMarginV702Test {
    private fun ratings(d: DriverDefinition) = intArrayOf(d.speed,d.qualifying,d.overtaking,d.defense,d.consistency,d.wet,d.tyre)

    @Test fun mediumGetsFullFivePointBandWithOrWithoutTeam() {
        assertEquals(5, DriverEvolutionEngine.classGrowthMargin("Médio", isContracted = true, seasonPerformanceAverage = null))
        assertEquals(5, DriverEvolutionEngine.classGrowthMargin("Médio", isContracted = false, seasonPerformanceAverage = null))
        assertEquals(74, DriverProfileCatalog.ceiling("Médio") + DriverEvolutionEngine.classGrowthMargin("Médio", true, null))
    }

    @Test fun freeForteGetsFullBandButContractedForteMustEarnIt() {
        assertEquals(5, DriverEvolutionEngine.classGrowthMargin("Forte", false, null))
        assertEquals(0, DriverEvolutionEngine.classGrowthMargin("Forte", true, null))
        assertEquals(2, DriverEvolutionEngine.classGrowthMargin("Forte", true, 110.0))
        assertEquals(4, DriverEvolutionEngine.classGrowthMargin("Forte", true, 120.0))
        assertEquals(5, DriverEvolutionEngine.classGrowthMargin("Forte", true, 130.0))
        assertEquals(5, DriverEvolutionEngine.classGrowthMargin("Forte", true, 140.0))
        assertEquals(5, DriverEvolutionEngine.classGrowthMargin("Forte", true, 150.0))
        assertEquals(84, DriverProfileCatalog.ceiling("Forte") + DriverEvolutionEngine.classGrowthMargin("Forte", false, null))
    }

    @Test fun proNeedsPerformanceWhetherFreeOrContracted() {
        assertEquals(0, DriverEvolutionEngine.classGrowthMargin("Pro", true, null))
        assertEquals(0, DriverEvolutionEngine.classGrowthMargin("Pro", false, null))
        assertEquals(2, DriverEvolutionEngine.classGrowthMargin("Pro", false, 110.0))
        assertEquals(4, DriverEvolutionEngine.classGrowthMargin("Pro", true, 120.0))
        assertEquals(5, DriverEvolutionEngine.classGrowthMargin("Pro", false, 130.0))
        assertEquals(5, DriverEvolutionEngine.classGrowthMargin("Pro", true, 140.0))
        assertEquals(5, DriverEvolutionEngine.classGrowthMargin("Pro", false, 150.0))
        assertEquals(94, DriverProfileCatalog.ceiling("Pro") + DriverEvolutionEngine.classGrowthMargin("Pro", false, 150.0))
    }

    @Test fun legendaHasNoAdditionalClassBand() {
        assertEquals(0, DriverEvolutionEngine.classGrowthMargin("Lenda", true, 200.0))
        assertEquals(100, DriverProfileCatalog.ceiling("Lenda"))
    }

    @Test fun normalGrowthSpeedIsNotReducedForMediumOrFreeForte() {
        assertEquals(1.0, DriverEvolutionEngine.classGrowthFactor("Médio", 74, true), 0.0)
        assertEquals(1.0, DriverEvolutionEngine.classGrowthFactor("Médio", 74, false), 0.0)
        assertEquals(1.0, DriverEvolutionEngine.classGrowthFactor("Forte", 84, false), 0.0)
        assertTrue(DriverEvolutionEngine.classGrowthFactor("Forte", 82, true) < 1.0)
        assertTrue(DriverEvolutionEngine.classGrowthFactor("Pro", 92, false) < 1.0)
    }

    @Test fun positiveGainCanReachFivePointBandWhenAllowanceIsGranted() {
        val medium = DriverDefinition(9901, "Medium band", 1, 69,69,69,69,69,69,69, "Médio", "Prodígio", "", 89)
        val mediumGains = IntArray(7)
        val mediumNext = DriverEvolutionEngine.applyPositiveGain(
            medium, 35, mediumGains, Random(731), allowClassCeilingExceed = true, classCeilingMargin = 5
        )
        assertEquals(74, DriverProfileCatalog.overall(ratings(mediumNext)))

        val forteFree = medium.copy(id = 9902, name = "Free Forte", driverClass = "Forte", potentialOverall = 100,
            speed = 79, qualifying = 79, overtaking = 79, defense = 79, consistency = 79, wet = 79, tyre = 79)
        val forteGains = IntArray(7)
        val forteNext = DriverEvolutionEngine.applyPositiveGain(
            forteFree, 35, forteGains, Random(732), allowClassCeilingExceed = true, classCeilingMargin = 5
        )
        assertEquals(84, DriverProfileCatalog.overall(ratings(forteNext)))
    }

    @Test fun proFreeAgentCannotCrossNormalCeilingWithoutSeasonEvidence() {
        val driver = DriverDefinition(9903, "Pro free", 0, 89,89,89,89,89,89,89, "Pro", "Prodígio", "", 100)
        var current = driver
        var bank = 0.0
        val annual = IntArray(7)
        repeat(60) { i ->
            val tick = DriverEvolutionEngine.applyFreeDriverTick(
                current, bank, annual, Random(733 + i), careerAge = 21
            )
            current = tick.driver
            bank = tick.bank
        }
        assertEquals(89, DriverProfileCatalog.overall(ratings(current)))
    }


    @Test fun aSingleExcellentGpCannotReplaceTheSeasonAverageRequirement() {
        val driver = DriverDefinition(9922, "Pro single GP", 1, 89,89,89,89,89,89,89, "Pro", "Prodígio", "", 100)
        val tick = DriverEvolutionEngine.applyPerformanceTick(
            driver = driver,
            performanceIndex = 150.0,
            currentBank = 0.0,
            annualGains = IntArray(7),
            random = Random(9922),
            careerAge = 21,
            seasonPerformanceAverage = null,
            isContracted = true
        )
        assertEquals(89, DriverProfileCatalog.overall(ratings(tick.driver)))
    }

    @Test fun facilityProgramsUseTheSameFivePointClassGate() {
        fun completeProgram(average: Double?): Int {
            val driver = DriverDefinition(9933, "Pro facility", 1, 89,89,89,89,89,89,89, "Pro", "Prodígio", "", 100)
            val queue = com.f1teammanager.core.manager.DriverDevelopmentEngine.start(
                com.f1teammanager.core.manager.DriverDevelopmentState(), 10, driver.id, 1, setOf(driver.id)
            )
            val result = com.f1teammanager.core.manager.DriverDevelopmentEngine.advanceWeeks(
                state = queue,
                weeks = 3,
                currentWeek = 4,
                drivers = mapOf(driver.id to driver),
                attributes = mapOf(driver.id to ratings(driver)),
                seed = 9933,
                annualGains = mapOf(driver.id to IntArray(7)),
                contractedDriverIds = setOf(driver.id),
                seasonPerformanceAverages = average?.let { mapOf(driver.id to it) } ?: emptyMap(),
                seasonPerformanceSamples = average?.let { mapOf(driver.id to 5) } ?: emptyMap()
            )
            return DriverProfileCatalog.overall(result.attributes.getValue(driver.id))
        }
        assertEquals(89, completeProgram(104.99))
        assertTrue(completeProgram(150.0) > 89)
    }

    @Test fun contractedProOnlyCrossesAccordingToSeasonPerformanceThreshold() {
        fun simulate(average: Double): Int {
            val driver = DriverDefinition(9910 + average.toInt(), "Pro contract", 1, 89,89,89,89,89,89,89, "Pro", "Prodígio", "", 100)
            var current = driver
            var bank = 0.0
            val annual = IntArray(7)
            repeat(80) { i ->
                val tick = DriverEvolutionEngine.applyPerformanceTick(
                    current, performanceIndex = 135.0, currentBank = bank, annualGains = annual,
                    random = Random(7400 + i), careerAge = 21,
                    seasonPerformanceAverage = average, isContracted = true
                )
                current = tick.driver
                bank = tick.bank
            }
            return DriverProfileCatalog.overall(ratings(current))
        }
        assertTrue(simulate(104.9) <= 89)
        assertTrue(simulate(150.0) in 90..94)
    }
}
