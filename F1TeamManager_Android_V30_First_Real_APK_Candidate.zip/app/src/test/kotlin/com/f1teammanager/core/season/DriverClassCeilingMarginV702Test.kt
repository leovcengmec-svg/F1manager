package com.f1teammanager.core.season

import kotlin.random.Random
import org.junit.Assert.*
import org.junit.Test

class DriverClassCeilingMarginV702Test {
    private fun ratings(d: DriverDefinition) = intArrayOf(d.speed,d.qualifying,d.overtaking,d.defense,d.consistency,d.wet,d.tyre)

    @Test fun exceptionalSeasonAllowsOnlySmallTemporaryMarginAboveClassCeiling() {
        val driver = DriverDefinition(9001, "Margin probe", 1, 89,89,89,89,89,89,89, "Pro", "Prodígio", "", 96)
        var current = driver
        var bank = 0.0
        val annual = IntArray(7)
        repeat(80) { i ->
            val result = DriverEvolutionEngine.applyPerformanceTick(
                current, performanceIndex = 135.0, currentBank = bank, annualGains = annual,
                random = Random(702 + i), careerAge = 21, seasonPerformanceAverage = 135.0
            )
            current = result.driver
            bank = result.bank
        }
        val overall = DriverProfileCatalog.overall(ratings(current))
        assertTrue("Exceptional season should allow a small margin above Pro ceiling", overall > 89)
        assertTrue("Margin must be capped at three Overall points", overall <= 92)
        assertTrue("Personal potential remains an absolute ceiling", overall <= 96)
    }

    @Test fun seasonAverageSelectsOneTwoOrThreePointMargin() {
        fun simulate(average: Double): Int {
            val driver = DriverDefinition(9100 + average.toInt(), "Margin tier", 1, 89,89,89,89,89,89,89, "Pro", "Prodígio", "", 96)
            var current = driver
            var bank = 0.0
            val annual = IntArray(7)
            repeat(80) { i ->
                val tick = DriverEvolutionEngine.applyPerformanceTick(
                    current, performanceIndex = 135.0, currentBank = bank, annualGains = annual,
                    random = Random(7100 + i), careerAge = 21, seasonPerformanceAverage = average
                )
                current = tick.driver
                bank = tick.bank
            }
            return DriverProfileCatalog.overall(ratings(current))
        }
        assertEquals(90, simulate(110.0))
        assertEquals(91, simulate(120.0))
        assertEquals(92, simulate(130.0))
    }

    @Test fun ordinarySeasonCannotUseExceptionalClassMargin() {
        val driver = DriverDefinition(9002, "No margin probe", 1, 89,89,89,89,89,89,89, "Pro", "Prodígio", "", 96)
        var current = driver
        var bank = 0.0
        val annual = IntArray(7)
        repeat(80) { i ->
            val result = DriverEvolutionEngine.applyPerformanceTick(
                current, performanceIndex = 105.0, currentBank = bank, annualGains = annual,
                random = Random(703 + i), careerAge = 21, seasonPerformanceAverage = 105.0
            )
            current = result.driver
            bank = result.bank
        }
        assertTrue(DriverProfileCatalog.overall(ratings(current)) <= 89)
    }
}
