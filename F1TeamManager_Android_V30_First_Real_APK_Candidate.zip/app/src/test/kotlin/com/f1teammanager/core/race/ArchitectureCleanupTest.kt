package com.f1teammanager.core.race

import java.io.File

fun main() {
    val root = File("app/src/main/java/com/f1teammanager/core/race")
    check(!File(root, "RaceWeekendEngine.kt").exists()) { "RaceWeekendEngine legado ainda presente" }
    check(!File(root, "RaceDecisionEngine.kt").exists()) { "RaceDecisionEngine legado ainda presente" }
    check(!File(root, "IncidentEngine.kt").exists()) { "IncidentEngine legado ainda presente" }
    val career = File(root, "CareerWeekendEngine.kt").readText()
    check(career.contains("private fun qualify(")) { "Qualificação não está centralizada no motor jogável" }
    check(!career.contains("RaceWeekendEngine(")) { "Motor jogável ainda delega para engine de corrida duplicada" }
    println("ARCHITECTURE_CLEANUP_OK")
}
