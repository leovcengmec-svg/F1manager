package com.f1teammanager.core.manager

import com.f1teammanager.core.season.WorldDatabase
import java.util.Base64
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** Regression tests for final-GP settlement ordering and replacement activation in V729. */
class SponsorshipExpirySettlementV729Test {
    private fun sponsorSnapshot(teamId: Int, season: Int, sponsor: SponsorContract): String {
        fun encode(value: String): String = Base64.getEncoder().encodeToString(value.toByteArray(Charsets.UTF_8))
        val fields = listOf(
            sponsor.name, sponsor.upfront, sponsor.racePayment, sponsor.pointsBonus, sponsor.years,
            sponsor.minimumReputation, sponsor.slot, sponsor.qualifyingTarget, sponsor.qualifyingBonus,
            sponsor.raceTarget, sponsor.raceTargetBonus, sponsor.active, sponsor.races,
            sponsor.racesRemaining, sponsor.category, sponsor.qualifyingTargetMin,
            sponsor.qualifyingTargetMax, sponsor.raceTargetMin, sponsor.raceTargetMax
        ).joinToString("^") { encode(it.toString()) }
        return "@V356|${encode("")}\n${listOf(teamId, season, 0L, encode(fields)).joinToString("|")}"
    }

    private fun expiringSponsor() = SponsorContract(
        name = "Patrocinador Final GP",
        upfront = 3_000_000L,
        racePayment = 2_000_000L,
        pointsBonus = 0L,
        years = 1,
        minimumReputation = 0,
        slot = 2,
        qualifyingTarget = 0,
        qualifyingBonus = 0L,
        raceTarget = 0,
        raceTargetBonus = 0L,
        active = true,
        races = 10,
        racesRemaining = 1,
        category = SponsorCategory.REGIONAL.name,
        qualifyingTargetMin = 0,
        qualifyingTargetMax = 0,
        raceTargetMin = 0,
        raceTargetMax = 0
    )

    @Test
    fun expiringAiSponsorReceivesItsFinalGpPaymentBeforeReplacementIsOpened() {
        val teamId = WorldDatabase.teams.first().id
        val season = 2027
        val sponsorship = TeamSponsorshipEngine(seed = 729_001)
        val oldContract = expiringSponsor()
        sponsorship.restoreSnapshot(sponsorSnapshot(teamId, season, oldContract))
        sponsorship.setMarketingLevel(teamId, 3)
        val activeForGp = sponsorship.forTeam(teamId, season)
        val aiFinance = AITeamFinancialEngine(seed = 729_002)

        // Mirrors the weekly AI finance pass before the GP, then the canonical
        // V729 settlement lifecycle: settle the old portfolio, only then replace it.
        aiFinance.applySponsorshipSignings(teamId, season, activeForGp)
        val afterGp1 = sponsorship.settleRaceThenAdvance(teamId, season, 1) { completedPortfolio ->
            aiFinance.applyRace(
                teamId = teamId,
                season = season,
                round = 1,
                sponsorship = completedPortfolio,
                market = DriverMarketState(),
                bestFinish = 20,
                points = 0,
                isDnf = false,
                bestQualifyingPosition = 0
            )
        }

        val gp1FixedPayment = aiFinance.state(teamId, season).finance.transactions
            .single { it.contains("Patrocínios fixos GP 1") }
        assertEquals("+${oldContract.racePayment}:Patrocínios fixos GP 1", gp1FixedPayment)

        val replacement = afterGp1.sponsors.single()
        assertNotEquals(oldContract.name, replacement.name)
        assertTrue("level 3 replacement uses the inclusive 8..14 GP band", replacement.races in 8..14)
        var duplicateSettlementCallbackRan = false
        val duplicateRound = sponsorship.settleRaceThenAdvance(teamId, season, 1) {
            duplicateSettlementCallbackRan = true
        }
        assertFalse("a replayed GP must not settle the sponsorship callback twice", duplicateSettlementCallbackRan)
        assertEquals(afterGp1, duplicateRound)
        assertFalse(
            "the new sponsor must not receive a per-GP payment on the old contract's final GP",
            aiFinance.state(teamId, season).finance.transactions.any { it.contains("Patrocínios fixos GP 2") }
        )

        // The replacement becomes eligible for the following GP only.
        aiFinance.applySponsorshipSignings(teamId, season, afterGp1)
        aiFinance.applyRace(
            teamId = teamId,
            season = season,
            round = 2,
            sponsorship = afterGp1,
            market = DriverMarketState(),
            bestFinish = 20,
            points = 0,
            isDnf = false,
            bestQualifyingPosition = 0
        )
        val gp2FixedPayment = aiFinance.state(teamId, season).finance.transactions
            .single { it.contains("Patrocínios fixos GP 2") }
        assertEquals("+${replacement.racePayment}:Patrocínios fixos GP 2", gp2FixedPayment)
    }

    @Test
    fun playerReceivesTheFinalPaymentBeforeExpiredContractIsRemoved() {
        val sponsor = expiringSponsor()
        val state = TeamManagerState(
            season = 2027,
            round = 1,
            playerTeamId = 7,
            car = TeamCarState(aerodynamics = 60, chassis = 60, engine = 60, reliability = 60),
            finance = TeamFinanceState(budget = 50_000_000L),
            sponsor = sponsor,
            sponsors = listOf(sponsor)
        )

        val settled = FinanceEngine().applyRace(
            state = state,
            finishPosition = 20,
            teamPoints = 0,
            isDnf = false,
            season = 2027,
            round = 1,
            bestQualifyingPosition = 0
        )

        assertTrue(
            settled.finance.transactions.any { it == "+${sponsor.racePayment}:Patrocínios fixos GP 1" }
        )
        assertTrue("the completed contract is removed only after settlement", settled.sponsors.isEmpty())
    }
}
