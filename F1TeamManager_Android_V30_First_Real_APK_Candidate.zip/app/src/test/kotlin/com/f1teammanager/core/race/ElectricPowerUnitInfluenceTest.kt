package com.f1teammanager.core.race

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

class ElectricPowerUnitInfluenceTest {
    @Test fun approvedTenLevelScale() {
        assertEquals(0.70, CarComponentInfluence.electricPowerUnitErsEfficiency(40))
        assertEquals(0.90, CarComponentInfluence.electricPowerUnitErsEfficiency(70))
        assertEquals(1.10, CarComponentInfluence.electricPowerUnitErsEfficiency(100))
    }

    @Test fun efficiencyIsMonotonic() {
        val values = listOf(40,46,52,58,64,70,76,82,88,94)
        assertTrue(values.zipWithNext().all { (a,b) -> CarComponentInfluence.electricPowerUnitErsEfficiency(a) < CarComponentInfluence.electricPowerUnitErsEfficiency(b) })
    }

    @Test fun participantCarriesElectricUnitValue() {
        val p = RaceParticipant(driverId=1,driverName="A",teamId=1,teamName="T",driverSpeed=70,qualifying=70,overtaking=70,defense=70,consistency=70,enginePerformance=70,tyreGrip=50,tyreWear=50,reliability=95,chassisWear=0,wetSkill=50,chassisPerformance=70,frontWingPerformance=70,rearWingPerformance=70,brakesPerformance=70,electricPowerUnitPerformance=88)
        assertEquals(88, p.electricPowerUnitPerformance)
    }
}
