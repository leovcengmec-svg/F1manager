package com.f1teammanager.core.season

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class DriverEvolutionSnapshotV725Test {
    @Test fun `snapshot preserves an authentic seasonal point and all seven attributes`() {
        val values = listOf(90, 88, 86, 92, 89, 84, 95)
        val snapshot = DriverEvolutionSnapshot(
            driverId = 101,
            season = 2031,
            age = 45,
            cycleIndex = 0,
            overall = 89,
            attributes = values,
            eventType = "SEASON_END"
        )
        assertEquals(101, snapshot.driverId)
        assertEquals(2031, snapshot.season)
        assertEquals(45, snapshot.age)
        assertEquals(0, snapshot.cycleIndex)
        assertEquals(89, snapshot.overall)
        assertEquals(values, snapshot.attributes)
        assertEquals("SEASON_END", snapshot.eventType)
    }

    @Test fun `cycle reset snapshots start at sixteen and retain a separate cycle index`() {
        val snapshot = DriverEvolutionSnapshot(
            driverId = 101,
            season = 2032,
            age = 16,
            cycleIndex = 1,
            overall = 63,
            attributes = listOf(63, 61, 60, 64, 62, 58, 66),
            eventType = "CYCLE_RESET"
        )
        assertEquals(16, snapshot.age)
        assertEquals(1, snapshot.cycleIndex)
        assertEquals("CYCLE_RESET", snapshot.eventType)
    }

    @Test fun `invalid snapshot data is rejected instead of persisting fabricated points`() {
        val invalidSize = runCatching {
            DriverEvolutionSnapshot(101, 2032, 18, 1, 63, listOf(63, 61, 60), "CYCLE_RESET")
        }.isFailure
        val invalidAge = runCatching {
            DriverEvolutionSnapshot(101, 2032, 15, 1, 63, List(7) { 63 }, "CYCLE_RESET")
        }.isFailure
        val invalidRating = runCatching {
            DriverEvolutionSnapshot(101, 2032, 18, 1, 39, List(7) { 63 }, "CYCLE_RESET")
        }.isFailure
        assertTrue(invalidSize)
        assertTrue(invalidAge)
        assertTrue(invalidRating)
        assertTrue(runCatching {
            DriverEvolutionSnapshot(101, 2032, 16, 1, 63, List(7) { 63 }, "CYCLE_RESET")
        }.isSuccess)
    }
}
