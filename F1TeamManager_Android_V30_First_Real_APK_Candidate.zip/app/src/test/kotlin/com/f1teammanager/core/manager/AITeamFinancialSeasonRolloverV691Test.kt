package com.f1teammanager.core.manager

import com.f1teammanager.core.season.WorldDatabase
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class AITeamFinancialSeasonRolloverV691Test {
    @Test fun newSeasonGetsFreshTwoHundredMillionEnvelopeButCarriesCashAndPrizeLedger() {
        val team = WorldDatabase.teams.first()
        val market2026 = DriverMarketEngine().initialState(2026)
        val engine = AITeamFinancialEngine(691001)

        engine.beginSeason(team.id, 2026, market2026)
        engine.setBudgetForAnnualEvent(team.id, 2026, 500_000_000L, "Capitalização de teste")

        val nextCarInvestment = engine.considerNextSeasonInvestment(
            teamId = team.id,
            season = 2026,
            round = 1,
            currentOverall = 55,
            market = market2026
        )
        assertTrue("A equipe deve conseguir reservar recursos para o próximo carro", nextCarInvestment > 0L)
        assertTrue(engine.remainingTechnicalBudget(team.id, 2026) < 200_000_000L)
        assertEquals(
            "Todo investimento no próximo carro precisa aparecer nas despesas da mesma temporada",
            nextCarInvestment,
            engine.state(team.id, 2026).finance.seasonExpenses
        )

        val afterPrize = engine.applySeasonConstructorsPrize(team.id, 2026, 1)
        assertTrue(2026 in afterPrize.finance.seasonPrizesPaid)
        val carriedCash = afterPrize.finance.budget
        assertTrue(carriedCash > 500_000_000L - nextCarInvestment)

        val newSeason = engine.beginSeason(team.id, 2027, DriverMarketEngine().initialState(2027))
        assertEquals("O caixa real deve atravessar a virada", carriedCash, newSeason.finance.budget)
        assertEquals("Receitas são um acumulado da temporada, não do histórico", 0L, newSeason.finance.seasonIncome)
        assertEquals("Despesas são um acumulado da temporada, não do histórico", 0L, newSeason.finance.seasonExpenses)
        assertEquals("O novo ano recebe um envelope técnico integral", 200_000_000L, engine.remainingTechnicalBudget(team.id, 2027))
        assertEquals("O investimento no carro seguinte da temporada encerrada não pode consumir o novo envelope", 0L, engine.nextSeasonInvestment(team.id, 2027))
    }

    @Test fun restoringAndReopeningTheNewSeasonDoesNotResetItsActualCashOrDuplicatePrize() {
        val team = WorldDatabase.teams.first()
        val market = DriverMarketEngine().initialState(2026)
        val engine = AITeamFinancialEngine(691002)
        engine.beginSeason(team.id, 2026, market)
        engine.setBudgetForAnnualEvent(team.id, 2026, 250_000_000L, "Capitalização de teste")
        val paid = engine.applySeasonConstructorsPrize(team.id, 2026, 3)
        val expectedCash = paid.finance.budget

        val restored = AITeamFinancialEngine(691002)
        restored.restoreSnapshot(engine.exportSnapshot())
        val reopened = restored.beginSeason(team.id, 2027, DriverMarketEngine().initialState(2027))
        val duplicate = restored.applySeasonConstructorsPrize(team.id, 2026, 3)

        assertEquals(expectedCash, reopened.finance.budget)
        assertEquals(expectedCash, duplicate.finance.budget)
        assertEquals(200_000_000L, restored.remainingTechnicalBudget(team.id, 2027))
    }

    @Test fun readingTheNewSeasonBudgetAlsoRekeysTheFinanceStateBeforeShowingTheCard() {
        val team = WorldDatabase.teams.first()
        val engine = AITeamFinancialEngine(691004)
        val market2026 = DriverMarketEngine().initialState(2026)
        engine.beginSeason(team.id, 2026, market2026)
        engine.setBudgetForAnnualEvent(team.id, 2026, 300_000_000L, "Capitalização de teste")
        val closingCash = engine.state(team.id, 2026).finance.budget

        // Simulates the Team Overview being opened before a weekly simulation call
        // has had a chance to invoke beginSeason() for the newly advanced season.
        assertEquals(200_000_000L, engine.remainingTechnicalBudget(team.id, 2027))
        val opened = engine.allStates().single { it.teamId == team.id }
        assertEquals(2027, opened.season)
        assertEquals(closingCash, opened.finance.budget)
        assertEquals(0L, opened.finance.seasonIncome)
        assertEquals(0L, opened.finance.seasonExpenses)
        assertEquals(200_000_000L, engine.remainingTechnicalBudget(team.id, 2027))
    }
    @Test fun explicitBoundaryRepairsSameSeasonSnapshotWithStaleTechnicalDebits() {
        val team = WorldDatabase.teams.first()
        val market = DriverMarketEngine().initialState(2027)
        val engine = AITeamFinancialEngine(691005)
        engine.beginSeason(team.id, 2027, market)
        engine.setBudgetForAnnualEvent(team.id, 2027, 300_000_000L, "Capitalização de teste")
        engine.applyDevelopmentCost(
            teamId = team.id,
            season = 2027,
            developmentBudgetAfter = 50_000_000L,
            startingCapacity = 100_000_000L
        )
        assertTrue(engine.remainingTechnicalBudget(team.id, 2027) < 200_000_000L)
        val cashAtBoundary = engine.state(team.id, 2027).finance.budget

        // Simulates a v690 save in which the finance row already uses 2027 but
        // its 2027 technical ledger still contains spending from the closing year.
        val opened = engine.openNewSeasonAtBoundary(team.id, 2027, market)
        assertEquals(cashAtBoundary, opened.finance.budget)
        assertEquals(0L, opened.finance.seasonIncome)
        assertEquals(0L, opened.finance.seasonExpenses)
        assertEquals(200_000_000L, engine.remainingTechnicalBudget(team.id, 2027))
        assertEquals(0L, engine.technicalInvestment(team.id, 2027).totalSpent)
    }

}
