package com.f1teammanager.core.manager

import com.f1teammanager.core.season.WorldDatabase
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class DriverMarketCareerRealismV653Test {
    @Test fun `championship success reshapes sporting pull beyond the starting profile`() {
        val engine = DriverMarketEngine(6532026)
        val weakestAtStart = WorldDatabase.teams.minBy { InitialTeamProfile.strength(it) }
        val strongestAtStart = WorldDatabase.teams.maxBy { InitialTeamProfile.strength(it) }
        val points = WorldDatabase.teams.associate { team ->
            team.id to when (team.id) {
                weakestAtStart.id -> 500
                strongestAtStart.id -> 0
                else -> 100
            }
        }

        assertTrue("A former backmarker winning the championship must become a top sporting project",
            engine.sportingStrengthForMarket(weakestAtStart.id, points) >= 80)
        assertTrue("A former leader that finishes last must lose sporting pull",
            engine.sportingStrengthForMarket(weakestAtStart.id, points) >
                engine.sportingStrengthForMarket(strongestAtStart.id, points))
    }

    @Test fun `elite driver interest improves when a weak starting team becomes champion`() {
        val engine = DriverMarketEngine(6532027)
        val initial = engine.initialState(2026)
        val weakTeam = WorldDatabase.teams.minBy { InitialTeamProfile.strength(it) }
        val strongestTeam = WorldDatabase.teams.maxBy { InitialTeamProfile.strength(it) }
        val elite = WorldDatabase.allDrivers.maxBy { (it.speed + it.qualifying + it.overtaking + it.defense + it.consistency + it.wet + it.tyre) / 7 }
        val salary = engine.salaryFor(elite.id) * 3
        val role = DriverTeamRole.PILOT_1
        val before = engine.interestScore(initial, elite.id, weakTeam.id, salary, role, 2026)
        val points = WorldDatabase.teams.associate { team ->
            team.id to when (team.id) {
                weakTeam.id -> 500
                strongestTeam.id -> 0
                else -> 100
            }
        }
        val after = engine.interestScore(initial, elite.id, weakTeam.id, salary, role, 2026,
            teamChampionshipPoints = points,
            driverChampionshipPoints = WorldDatabase.allDrivers.associate { it.id to if (it.id == elite.id) 500 else 0 })

        assertTrue("A champion project should be more attractive than its historical starting profile", after >= before + 10)
    }

    @Test fun `final AI market week closes all solvent AI seats before season transition`() {
        val engine = DriverMarketEngine(6532028)
        val initial = engine.initialState(2026)
        val points = WorldDatabase.teams.sortedBy { InitialTeamProfile.strength(it) }
            .mapIndexed { index, team -> team.id to ((WorldDatabase.teams.size - index) * 100) }.toMap()
        val result = engine.processAiMarketWeek(initial, 2026, 56, playerTeamId = -999,
            teamChampionshipPoints = points)

        WorldDatabase.teams.forEach { team ->
            assertEquals("${team.name} must have two projected drivers before rollover", 2,
                engine.projectedRosterForSeason(result, team.id, 2027).size)
        }
        assertEquals("A driver cannot be projected for two teams in the same target season",
            result.scheduled.filter { it.startSeason == 2027 }.map { it.driverId }.distinct().size,
            result.scheduled.filter { it.startSeason == 2027 }.size)
    }

    @Test fun `final AI market closeout never assigns or changes the player roster`() {
        val engine = DriverMarketEngine(6532029)
        val initial = engine.initialState(2026)
        val playerTeam = WorldDatabase.teams.first().id
        val before = engine.projectedRosterForSeason(initial, playerTeam, 2027)
        val after = engine.processAiMarketWeek(initial, 2026, 56, playerTeamId = playerTeam)

        assertEquals(before, engine.projectedRosterForSeason(after, playerTeam, 2027))
    }
}
