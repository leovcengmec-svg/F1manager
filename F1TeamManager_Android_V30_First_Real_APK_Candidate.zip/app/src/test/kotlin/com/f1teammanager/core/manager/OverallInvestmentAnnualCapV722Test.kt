package com.f1teammanager.core.manager

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class OverallInvestmentAnnualCapV722Test {
    private fun garage(overall: Int): TeamGarage {
        fun car(id: GarageCarId) = PhysicalCar(
            id = id, engine = overall, chassis = overall, frontWing = overall,
            rearWing = overall, brakes = overall, electricPowerUnit = overall,
            reliability = 80,
            componentReliabilities = CarComponent.values().associateWith { 80 },
            installedPieces = CarComponent.values().associateWith { "${id.name}-${it.name}-V0" },
            installedPieceVersions = CarComponent.values().associateWith { 0 }
        )
        return TeamGarage(car(GarageCarId.CAR_1), car(GarageCarId.CAR_2))
    }

    @Test fun officialTableMapsInvestmentToOverall() {
        val engine = CarDevelopmentEngine()
        assertEquals(40, engine.constructionOverallForInvestment(8_000_000L))
        assertEquals(50, engine.constructionOverallForInvestment(25_000_000L))
        assertEquals(60, engine.constructionOverallForInvestment(45_000_000L))
        assertEquals(70, engine.constructionOverallForInvestment(70_000_000L))
        assertEquals(80, engine.constructionOverallForInvestment(110_000_000L))
        assertEquals(90, engine.constructionOverallForInvestment(130_000_000L))
        assertEquals(100, engine.constructionOverallForInvestment(150_000_000L))
    }

    @Test fun playerAndAiShareSameAnnualInvestmentResult() {
        val engine = CarDevelopmentEngine()
        val previous = garage(90)
        val ai = engine.buildAiNextSeasonGarage(previous, 119_000_000L)
        val player = engine.buildNextSeasonGarage(
            previousGarage = previous,
            invested = 119_000_000L,
            minimumOverall = 80,
            maximumOverall = 92
        )
        assertEquals(84, ai.teamAverageOverall)
        assertEquals(player.teamAverageOverall, ai.teamAverageOverall)
    }

    @Test fun annualLossNeverExceedsTenAndGrowthUsesExistingPolicy() {
        val engine = CarDevelopmentEngine()
        val previous = garage(90)
        val noInvestment = engine.buildAiNextSeasonGarage(previous, 0L)
        val fullyFunded = engine.buildAiNextSeasonGarage(previous, 150_000_000L)
        assertTrue(90 - noInvestment.teamAverageOverall <= 10)
        assertEquals(80, noInvestment.teamAverageOverall)
        assertEquals(92, fullyFunded.teamAverageOverall)
    }

    @Test fun everyInvestmentLevelIsMonotonic() {
        val engine = CarDevelopmentEngine()
        var previous = 40
        for (million in 8..150) {
            val current = engine.constructionOverallForInvestment(million * 1_000_000L)!!
            assertTrue("investment €${million}M must not lower table Overall", current >= previous)
            previous = current
        }
        assertEquals(100, previous)
    }
}
