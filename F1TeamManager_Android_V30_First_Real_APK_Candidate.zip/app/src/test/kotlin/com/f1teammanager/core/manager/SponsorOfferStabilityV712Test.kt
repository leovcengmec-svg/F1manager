package com.f1teammanager.core.manager

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

class SponsorOfferStabilityV712Test {
    @Test
    fun `same career state always produces same three sponsor proposals`() {
        val seed = (7 * 73856093) xor (2026 * 19349663) xor (4 * 83492791) xor (3 * 265443576)
        val first = TeamSponsorshipEngine(seed).offersForSlot(7, 2026, 2, 3, 4, emptySet())
        val reopened = TeamSponsorshipEngine(seed).offersForSlot(7, 2026, 2, 3, 4, emptySet())
        assertEquals(3, first.size)
        assertEquals(first.map { it.sponsor.name }, reopened.map { it.sponsor.name })
        assertEquals(first.map { it.sponsor.upfront }, reopened.map { it.sponsor.upfront })
        assertEquals(first.map { it.category }, reopened.map { it.category })
    }

    @Test
    fun `level two always offers a basic baseline and can independently offer regional upgrades`() {
        var sawRegional = false
        for (seed in 0..300) {
            val engine = TeamSponsorshipEngine(seed)
            val offers = engine.offersForSlot(31, 2027, 2, 2, 7, emptySet())
            assertEquals(3, offers.size)
            assertEquals(SponsorCategory.BASICO, offers.first().category)
            assertEquals(3, offers.map { it.sponsor.name }.distinct().size)
            if (offers.drop(1).any { it.category == SponsorCategory.REGIONAL }) sawRegional = true
            val reopened = TeamSponsorshipEngine(seed).offersForSlot(31, 2027, 2, 2, 7, emptySet())
            assertEquals(offers.map { it.category }, reopened.map { it.category })
            assertEquals(offers.map { it.sponsor.name }, reopened.map { it.sponsor.name })
        }
        assertTrue(sawRegional, "O nível 2 precisa oferecer chance real de propostas REGIONAIS")
    }
}
