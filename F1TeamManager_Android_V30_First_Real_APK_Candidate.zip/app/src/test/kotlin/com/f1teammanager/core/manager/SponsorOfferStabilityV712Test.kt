package com.f1teammanager.core.manager

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

class SponsorOfferStabilityV712Test {
    @Test
    fun `same career state always produces same three sponsor proposals`() {
        val seed = (7 * 73856093) xor (2026 * 19349663) xor (4 * 83492791) xor (3 * 265443576)
        val first = TeamSponsorshipEngine(seed).offersForSlot(7, 2026, 2, 3, 4, emptySet())
        val reopened = TeamSponsorshipEngine(seed).offersForSlot(7, 2026, 2, 3, 4, emptySet())
        assertEquals(3, first.size)
        assertEquals(first.map { it.sponsor.name }, reopened.map { it.sponsor.name })
        assertEquals(first.map { it.sponsor.upfront }, reopened.map { it.sponsor.upfront })
        assertEquals(first.map { it.category }, reopened.map { it.category })
    }

    @Test
    fun `level two always offers a basic baseline and can independently offer regional upgrades`() {
        var sawRegional = false
        for (seed in 0..300) {
            val engine = TeamSponsorshipEngine(seed)
            val offers = engine.offersForSlot(31, 2027, 2, 2, 7, emptySet())
            assertEquals(3, offers.size)
            assertEquals(SponsorCategory.BASICO, offers.first().category)
            assertEquals(3, offers.map { it.sponsor.name }.distinct().size)
            if (offers.drop(1).any { it.category == SponsorCategory.REGIONAL }) sawRegional = true
            val reopened = TeamSponsorshipEngine(seed).offersForSlot(31, 2027, 2, 2, 7, emptySet())
            assertEquals(offers.map { it.category }, reopened.map { it.category })
            assertEquals(offers.map { it.sponsor.name }, reopened.map { it.sponsor.name })
        }
        assertTrue(sawRegional, "O nível 2 precisa oferecer chance real de propostas REGIONAIS")
    }
    @Test
    fun `new negotiation excludes just-ended sponsor and changes its draw seed`() {
        val teamId = 31
        val categoryPool = SponsorCatalog.pool(SponsorCategory.BASICO, master = false)
        val justEndedA = categoryPool[0].name
        val justEndedB = categoryPool[1].name
        val engine = TeamSponsorshipEngine(seed = 712_730)

        val afterA = engine.offersForSlot(teamId, 2027, 2, 1, 9, setOf(justEndedA))
        val reopenedAfterA = TeamSponsorshipEngine(seed = 712_730)
            .offersForSlot(teamId, 2027, 2, 1, 9, setOf(justEndedA))
        val afterB = TeamSponsorshipEngine(seed = 712_730)
            .offersForSlot(teamId, 2027, 2, 1, 9, setOf(justEndedB))

        assertEquals("the pending proposal set remains stable when Finances is reopened",
            afterA.map { it.sponsor }, reopenedAfterA.map { it.sponsor })
        assertTrue("the just-ended brand is excluded from its slot's next draw",
            afterA.none { it.sponsor.name == justEndedA })
        assertTrue("changing the just-ended brand starts a different proposal draw",
            afterA.map { it.sponsor.name } != afterB.map { it.sponsor.name })
        assertEquals("one negotiation still offers three distinct brands", 3,
            afterA.map { it.sponsor.name }.distinct().size)
    }

}
