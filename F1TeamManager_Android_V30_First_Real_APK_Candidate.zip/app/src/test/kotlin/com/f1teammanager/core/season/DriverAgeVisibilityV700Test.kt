package com.f1teammanager.core.season

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class DriverAgeVisibilityV700Test {
    @Test
    fun `all titular and market drivers have a stable career age`() {
        val drivers = WorldDatabase.allDrivers
        assertEquals("The career roster and market must expose all 100 drivers", 100, drivers.size)

        drivers.forEach { driver ->
            val currentAge = DriverEvolutionEngine.careerAge(driver, 2026)
            assertTrue("${driver.name} has an invalid 2026 age: $currentAge", currentAge in 18..35)
            assertEquals(
                "${driver.name} must advance one year with the career season",
                currentAge + 1,
                DriverEvolutionEngine.careerAge(driver, 2027)
            )
            assertEquals(
                "${driver.name} must resolve the same age in repeated reads",
                currentAge,
                DriverEvolutionEngine.careerAge(driver, 2026)
            )
        }
    }

    @Test
    fun `ages remain independent of attribute development`() {
        val original = WorldDatabase.allDrivers.first { it.name == "Leonardo Vicente" }
        val developed = original.copy(
            speed = 99,
            qualifying = 99,
            overtaking = 99,
            defense = 99,
            consistency = 99,
            wet = 99,
            tyre = 99
        )
        assertEquals(
            DriverEvolutionEngine.careerAge(original, 2026),
            DriverEvolutionEngine.careerAge(developed, 2026)
        )
    }
}
