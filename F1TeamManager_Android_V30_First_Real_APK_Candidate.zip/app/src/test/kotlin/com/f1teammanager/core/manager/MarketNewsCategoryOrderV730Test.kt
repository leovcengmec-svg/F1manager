package com.f1teammanager.core.manager

import org.junit.Assert.assertEquals
import org.junit.Test

class MarketNewsCategoryOrderV730Test {
    @Test
    fun `central categories follow approved five-tab order`() {
        assertEquals(
            listOf(
                MarketNewsCategory.MARKET,
                MarketNewsCategory.DRIVER_EVOLUTION,
                MarketNewsCategory.TEAM_EVOLUTION,
                MarketNewsCategory.DRIVER_EVENTS,
                MarketNewsCategory.ANNUAL_EVENTS
            ),
            MarketNewsCategory.CENTRAL_DISPLAY_ORDER
        )
    }
}
