package com.f1teammanager.core.manager

import com.f1teammanager.core.season.WorldDatabase
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class DriverMarketFutureCarProjectionV660Test {
    @Test fun `elite driver rejects ordinary offer that abandons a leading next season car`() {
        val engine = DriverMarketEngine(6602026)
        val state = engine.initialState(2026)
        val incumbent = state.contracts.maxBy { deal ->
            val driver = WorldDatabase.allDrivers.first { it.id == deal.driverId }
            (driver.speed + driver.qualifying + driver.overtaking + driver.defense + driver.consistency + driver.wet + driver.tyre) / 7
        }
        val elite = WorldDatabase.allDrivers.first { it.id == incumbent.driverId }
        val destination = WorldDatabase.teams.first { it.id != incumbent.teamId }
        val projection = WorldDatabase.teams.associate { team ->
            team.id to when (team.id) {
                incumbent.teamId -> 94
                destination.id -> 18
                else -> 55
            }
        }

        val ordinary = engine.interestScore(
            state, elite.id, destination.id, incumbent.salary, DriverTeamRole.PILOT_1, 2026,
            nextSeasonCarStrength = projection
        )

        assertTrue("A huge future-car downgrade must make an ordinary offer unattractive (score=$ordinary)", ordinary < 78)
    }

    @Test fun `offer is reevaluated at response time instead of using stale interest score`() {
        val engine = DriverMarketEngine(6602027)
        val initial = engine.initialState(2026)
        val incumbent = initial.contracts.maxBy { deal ->
            val driver = WorldDatabase.allDrivers.first { it.id == deal.driverId }
            (driver.speed + driver.qualifying + driver.overtaking + driver.defense + driver.consistency + driver.wet + driver.tyre) / 7
        }
        val elite = WorldDatabase.allDrivers.first { it.id == incumbent.driverId }
        val destination = WorldDatabase.teams.first { it.id != incumbent.teamId }
        val replacement = engine.roster(initial, destination.id, season = 2026).first()
        val offer = DriverOffer(
            driverId = elite.id,
            fromTeamId = incumbent.teamId,
            toTeamId = destination.id,
            years = 3,
            salary = incumbent.salary,
            role = DriverTeamRole.PILOT_1,
            marketValue = incumbent.marketValue,
            interestScore = 100, // Simulates a stale score calculated before the future car worsened.
            expiresAfterWeek = 10,
            status = NegotiationStatus.PENDING,
            seasonTarget = 2027,
            replaceDriverId = replacement,
            proposerTeamId = destination.id
        )
        val state = initial.copy(pending = listOf(offer))
        val projection = WorldDatabase.teams.associate { team ->
            team.id to when (team.id) {
                incumbent.teamId -> 96
                destination.id -> 12
                else -> 50
            }
        }

        val result = engine.expireOffers(
            state, currentWeek = 10, season = 2026, playerTeamId = -999,
            nextSeasonCarStrength = projection
        )

        assertFalse("The stale score must not sign the elite driver into a dramatically weaker project",
            result.scheduled.any { it.driverId == elite.id && it.toTeamId == destination.id && it.startSeason == 2027 })
    }
}
