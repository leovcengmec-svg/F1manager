package com.f1teammanager.core.season

/** Regression coverage for the V672 class floor and Pro-to-Lenda title gate. */
object DriverClassProgressionV649Test {
    @JvmStatic
    fun main(args: Array<String>) {
        val goodOne = DriverClassProgressionEngine.SeasonPerformance(2026, 108.0, 30)
        val goodTwo = DriverClassProgressionEngine.SeasonPerformance(2027, 110.0, 30)
        val promoted = DriverClassProgressionEngine.evaluate("Médio", 71, goodOne, goodTwo, 30)
        check(promoted.changed)
        check(promoted.resultingClass == "Forte")
        check(promoted.direction == DriverClassProgressionEngine.Direction.PROMOTION)

        check(!DriverClassProgressionEngine.evaluate("Médio", 71, null, goodTwo, 30).changed)
        check(!DriverClassProgressionEngine.evaluate("Médio", 71, goodOne, goodTwo.copy(season=2028), 30).changed)
        check(!DriverClassProgressionEngine.evaluate("Médio", 71, goodOne.copy(raceCount=23), goodTwo, 30).changed)
        check(!DriverClassProgressionEngine.evaluate("Médio", 70, goodOne, goodTwo, 30).changed)
        check(!DriverClassProgressionEngine.evaluate("Médio", 71, goodOne.copy(averageIndex=99.0), goodTwo, 30).changed)

        val poorOne = DriverClassProgressionEngine.SeasonPerformance(2026, 76.0, 30)
        val poorTwo = DriverClassProgressionEngine.SeasonPerformance(2027, 78.0, 30)
        val normalFloor = DriverClassProgressionEngine.evaluate("Médio", 58, poorOne, poorTwo, 30)
        check(!normalFloor.changed)
        check(normalFloor.resultingClass == "Médio")
        check(normalFloor.direction == DriverClassProgressionEngine.Direction.KEEP)
        check(!DriverClassProgressionEngine.evaluate("Normal", 58, poorOne, poorTwo, 30).changed)
        check(!DriverClassProgressionEngine.evaluate("Fraco", 40, poorOne, poorTwo, 30).changed)

        val proNotChampion = DriverClassProgressionEngine.evaluate("Pro", 95, goodOne, goodTwo, 30)
        check(!proNotChampion.changed)
        check(proNotChampion.resultingClass == "Pro")
        val proChampion = DriverClassProgressionEngine.evaluate("Pro", 95, goodOne, goodTwo, 30, isChampion = true)
        check(proChampion.changed)
        check(proChampion.resultingClass == "Lenda")
        check(proChampion.direction == DriverClassProgressionEngine.Direction.PROMOTION)

        val forteCanPromoteNormally = DriverClassProgressionEngine.evaluate("Forte", 91, goodOne, goodTwo, 30)
        check(forteCanPromoteNormally.changed)
        check(forteCanPromoteNormally.resultingClass == "Pro")

        println("DriverClassProgressionV672Rules: PASS")
    }
}
