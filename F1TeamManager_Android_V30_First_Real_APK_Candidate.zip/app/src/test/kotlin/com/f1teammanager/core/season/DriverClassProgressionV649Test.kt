package com.f1teammanager.core.season

/** Two consecutive seasons are required; class and Overall conditions must both agree. */
object DriverClassProgressionV649Test {
    @JvmStatic
    fun main(args: Array<String>) {
        val goodOne = DriverClassProgressionEngine.SeasonPerformance(2026, 108.0, 30)
        val goodTwo = DriverClassProgressionEngine.SeasonPerformance(2027, 110.0, 30)
        val promoted = DriverClassProgressionEngine.evaluate("Médio", 71, goodOne, goodTwo, 30)
        check(promoted.changed)
        check(promoted.resultingClass == "Forte")
        check(promoted.direction == DriverClassProgressionEngine.Direction.PROMOTION)

        check(!DriverClassProgressionEngine.evaluate("Médio", 71, null, goodTwo, 30).changed)
        check(!DriverClassProgressionEngine.evaluate("Médio", 71, goodOne, goodTwo.copy(season=2028), 30).changed)
        check(!DriverClassProgressionEngine.evaluate("Médio", 71, goodOne.copy(raceCount=23), goodTwo, 30).changed)
        check(!DriverClassProgressionEngine.evaluate("Médio", 70, goodOne, goodTwo, 30).changed)
        check(!DriverClassProgressionEngine.evaluate("Médio", 71, goodOne.copy(averageIndex=99.0), goodTwo, 30).changed)

        val poorOne = DriverClassProgressionEngine.SeasonPerformance(2026, 76.0, 30)
        val poorTwo = DriverClassProgressionEngine.SeasonPerformance(2027, 78.0, 30)
        val demoted = DriverClassProgressionEngine.evaluate("Médio", 58, poorOne, poorTwo, 30)
        check(demoted.changed)
        check(demoted.resultingClass == "Fraco")
        check(demoted.direction == DriverClassProgressionEngine.Direction.DEMOTION)
        check(!DriverClassProgressionEngine.evaluate("Médio", 60, poorOne, poorTwo, 30).changed)
        check(!DriverClassProgressionEngine.evaluate("Fraco", 40, poorOne, poorTwo, 30).changed)

        println("DriverClassProgressionV649Test: PASS")
    }
}
