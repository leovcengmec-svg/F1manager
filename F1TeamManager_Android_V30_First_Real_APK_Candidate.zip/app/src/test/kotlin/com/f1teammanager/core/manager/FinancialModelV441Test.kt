package com.f1teammanager.core.manager

import com.f1teammanager.core.season.WorldDatabase
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class FinancialModelV441Test {
    @Test fun allFortyConstructorPrizesAreStrictlyDescendingAndBounded() {
        val prizes = (1..40).map(SeasonPrizeEngine::prizeForPosition)
        assertEquals(40, prizes.toSet().size)
        assertTrue(prizes.zipWithNext().all { (a, b) -> a > b })
        assertEquals(100_000_000L, prizes.first())
        assertEquals(40_000_000L, prizes.last())
    }

    @Test fun raceOperatingCostsFollowCanonicalTeamLevels() {
        WorldDatabase.teams.forEach { team ->
            val expected = when (team.initialLevel) {
                InitialTeamProfile.FORTE -> 2_200_000L
                InitialTeamProfile.MEDIO -> 1_700_000L
                else -> 1_200_000L
            }
            assertEquals("team ${team.id}", expected, RaceOperatingCost.forTeam(team.id))
        }
    }

    @Test fun allFortyTeamsHaveValidOpeningBudgets() {
        assertEquals(40, WorldDatabase.teams.size)
        WorldDatabase.teams.forEach { team ->
            assertTrue("team ${team.id}", InitialTeamProfile.initialBudget(team) > 0L)
        }
    }
}
