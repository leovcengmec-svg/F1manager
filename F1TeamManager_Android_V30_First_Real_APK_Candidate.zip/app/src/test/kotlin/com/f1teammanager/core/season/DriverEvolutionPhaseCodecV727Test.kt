package com.f1teammanager.core.season

import org.junit.Assert.assertEquals
import org.junit.Test

class DriverEvolutionPhaseCodecV727Test {
    @Test
    fun decodesLegacyPhaseLedgerAndSkipsMalformedTokens() {
        val decoded = DriverEvolutionPhaseCodec.decode(
            "23:GROWTH;bad-token;7:REGRESSION;not-an-id:STABLE;12:RECOVERY:AGE"
        )

        assertEquals(
            mapOf(23 to "GROWTH", 7 to "REGRESSION", 12 to "RECOVERY:AGE"),
            decoded
        )
    }

    @Test
    fun encoderUsesStableNumericKeyOrdering() {
        val encoded = DriverEvolutionPhaseCodec.encode(
            mapOf(23 to "GROWTH", 7 to "REGRESSION", 12 to "RECOVERY")
        )

        assertEquals("7:REGRESSION;12:RECOVERY;23:GROWTH", encoded)
    }

    @Test
    fun decodeEncodeRoundTripPreservesThePhaseLedger() {
        val source = "7:REGRESSION;12:RECOVERY:AGE;23:GROWTH"
        val encoded = DriverEvolutionPhaseCodec.encode(DriverEvolutionPhaseCodec.decode(source))

        assertEquals(source, encoded)
    }
}
