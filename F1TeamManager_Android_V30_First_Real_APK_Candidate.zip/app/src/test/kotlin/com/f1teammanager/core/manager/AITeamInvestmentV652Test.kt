package com.f1teammanager.core.manager

import com.f1teammanager.core.season.WorldDatabase
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class AITeamInvestmentV652Test {
    private fun uniformGarage(value: Int, reliability: Int = 80): TeamGarage {
        fun car(id: GarageCarId) = PhysicalCar(
            id = id,
            engine = value,
            chassis = value,
            frontWing = value,
            rearWing = value,
            brakes = value,
            electricPowerUnit = value,
            reliability = reliability,
            componentReliabilities = CarComponent.values().associateWith { reliability },
            installedPieces = CarComponent.values().associateWith { "${id.name}-${it.name}-V0" },
            installedPieceVersions = CarComponent.values().associateWith { 0 }
        )
        return TeamGarage(car(GarageCarId.CAR_1), car(GarageCarId.CAR_2))
    }

    @Test fun historicalReplayDoesNotReplaceTheLiveCurrentSeasonBudget() {
        val team = WorldDatabase.teams.first { it.initialLevel == InitialTeamProfile.FORTE }
        val liveCapacity = 43_250_000L
        val result = AITeamDevelopmentEngine(652001, 652002).simulateFinancial(
            team = team,
            elapsedWeeks = 0,
            season = 2027,
            startingBudget = liveCapacity
        )
        assertEquals(liveCapacity, result.budget)
    }

    @Test fun underfundedAiCarPenaltyEqualsMissingMillionsAndCapsAtTenPoints() {
        val engine = CarDevelopmentEngine()
        val target = engine.investmentReferenceForNextSeasonTarget(90, NextSeasonCarGrowthPolicy.maximumGain(90))
        assertEquals(2, NextSeasonCarGrowthPolicy.maximumGain(90))
        assertEquals(0, engine.aiUnderinvestmentPenaltyPoints(90, target))
        assertEquals(7, engine.aiUnderinvestmentPenaltyPoints(90, target - 7_000_000L))
        assertEquals(10, engine.aiUnderinvestmentPenaltyPoints(90, target - 15_000_000L))
        assertEquals(10, engine.aiUnderinvestmentPenaltyPoints(90, 0L))
    }

    @Test fun physicalAiBuildAppliesMissingInvestmentLossToEveryInstalledComponent() {
        val engine = CarDevelopmentEngine()
        val previous = uniformGarage(90)
        val target = engine.investmentReferenceForNextSeasonTarget(90, NextSeasonCarGrowthPolicy.maximumGain(90))
        val fullyFunded = engine.buildAiNextSeasonGarage(previous, target)
        val sevenShort = engine.buildAiNextSeasonGarage(previous, target - 7_000_000L)
        val fifteenShort = engine.buildAiNextSeasonGarage(previous, target - 15_000_000L)
        assertEquals(92, fullyFunded.teamAverageOverall)
        assertEquals(85, sevenShort.teamAverageOverall)
        assertEquals(82, fifteenShort.teamAverageOverall)
        CarComponent.values().forEach { component ->
            assertEquals(92, fullyFunded.car1.componentValue(component))
            assertEquals(85, sevenShort.car1.componentValue(component))
            assertEquals(82, fifteenShort.car1.componentValue(component))
            assertEquals(85, sevenShort.car2.componentValue(component))
            assertEquals(82, fifteenShort.car2.componentValue(component))
            assertEquals(80, fifteenShort.car1.componentReliability(component))
        }
    }

    @Test fun factoryQuantityFallsBackToOneUnitWhenTwoDoNotFit() {
        assertEquals(1, selectAffordableFactoryQuantity(
            unitCost = 10_000_000L,
            desiredQuantity = 2,
            technicalSpent = 185_000_000L,
            technicalCap = 200_000_000L,
            availableBudget = 15_000_000L
        ))
        assertEquals(2, selectAffordableFactoryQuantity(
            unitCost = 10_000_000L,
            desiredQuantity = 2,
            technicalSpent = 170_000_000L,
            technicalCap = 200_000_000L,
            availableBudget = 25_000_000L
        ))
        assertEquals(0, selectAffordableFactoryQuantity(
            unitCost = 10_000_000L,
            desiredQuantity = 2,
            technicalSpent = 195_000_000L,
            technicalCap = 200_000_000L,
            availableBudget = 9_000_000L
        ))
    }


    @Test fun factoryQuantityAccountsForTheResearchCostAlreadyReserved() {
        assertEquals(1, selectAffordableFactoryQuantity(
            unitCost = 6_000_000L,
            desiredQuantity = 2,
            technicalSpent = 190_000_000L,
            technicalCap = 200_000_000L,
            availableBudget = 12_000_000L
        ))
    }

    @Test fun aiFinancialPenaltyReducesAllSixCarComponentsByTwentyPercent() {
        val penalized = FinancialSeasonClosureEngine.applyGaragePenalty(uniformGarage(90, 80))
        CarComponent.values().forEach { component ->
            assertEquals(72, penalized.car1.componentValue(component))
            assertEquals(72, penalized.car2.componentValue(component))
        }
        assertEquals(64, penalized.car1.reliability)
        assertEquals(64, penalized.car2.reliability)
    }

    @Test fun aDecliningTeamPrioritizesTechnicalRecoveryOverCommercialCenterExpansion() {
        val team = WorldDatabase.teams.first { it.initialLevel == InitialTeamProfile.FORTE }
        val market = DriverMarketEngine().initialState(2026)
        val finance = AITeamFinancialEngine(652010)
        finance.beginSeason(team.id, 2026, market)
        finance.setBudgetForAnnualEvent(team.id, 2026, 300_000_000L, "Capital de teste")
        finance.advanceFacilityDevelopment(
            teamId = team.id,
            season = 2026,
            week = 8,
            currentOverall = 30,
            market = market
        )
        val upgrade = finance.facilityUpgrade(team.id)
        assertTrue("A IA deve escolher P&D ou Fábrica quando o carro está muito abaixo do nível inicial", 
            upgrade?.facility == FacilityType.RESEARCH || upgrade?.facility == FacilityType.FACTORY)
    }
}
