package com.f1teammanager.core.manager

import com.f1teammanager.core.season.WorldDatabase
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SeasonPrizeSettlementIdempotencyV691Test {
    @Test fun everyAiTeamReceivesItsFinalRankingPrizeExactlyOnce() {
        val teams = WorldDatabase.teams
        val points = teams.associate { it.id to (teams.size - it.id) * 10 }
        val settlements = SeasonSettlementEngine.settleAll(points)
        val engine = AITeamFinancialEngine(691003)
        val before = teams.associate { it.id to engine.state(it.id, 2026).finance.budget }

        settlements.filter { it.teamId != teams.first().id }.forEach { settlement ->
            engine.applySeasonConstructorsPrize(settlement.teamId, 2026, settlement.position)
        }
        val afterFirst = engine.allStates().associate { it.teamId to it.finance.budget }
        settlements.filter { it.teamId != teams.first().id }.forEach { settlement ->
            engine.applySeasonConstructorsPrize(settlement.teamId, 2026, settlement.position)
        }
        val afterReplay = engine.allStates().associate { it.teamId to it.finance.budget }

        settlements.filter { it.teamId != teams.first().id }.forEach { settlement ->
            assertEquals(
                before.getValue(settlement.teamId) + settlement.prize,
                afterFirst.getValue(settlement.teamId)
            )
            assertEquals(afterFirst.getValue(settlement.teamId), afterReplay.getValue(settlement.teamId))
            assertTrue(2026 in engine.state(settlement.teamId, 2026).finance.seasonPrizesPaid)
        }
    }
}
