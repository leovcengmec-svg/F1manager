package com.f1teammanager.core.manager

import com.f1teammanager.core.season.WorldDatabase
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AITeamFinancialStrategyV732Test {
    @Test fun titleFightUsesSignedGapAgainstStrongestRival() {
        val behindBySixteen = SeasonInvestmentPolicy.signedGapToStrongestRival(69, 85)
        assertEquals(-16, behindBySixteen)
        assertFalse(SeasonInvestmentPolicy.isInTitleFight(ranking = 5, signedGapToStrongestRival = behindBySixteen))
        assertTrue(SeasonInvestmentPolicy.isInTitleFight(ranking = 5, signedGapToStrongestRival = -4))
        assertTrue(SeasonInvestmentPolicy.isInTitleFight(ranking = 4, signedGapToStrongestRival = 3))
        assertFalse(SeasonInvestmentPolicy.isInTitleFight(ranking = 6, signedGapToStrongestRival = 0))
        assertEquals(
            AIInvestmentMindset.STANDARD,
            SeasonInvestmentPolicy.selectAiMindset(
                round = 10, ranking = 5, currentOverall = 69, gapToSecondBest = behindBySixteen,
                inTitleFight = false, availableInvestmentCash = 0L
            )
        )
    }

    @Test fun allSevenFacilitiesHaveIndependentTargetsAndDeficitPriority() {
        assertEquals(7, FacilityType.values().size)
        FacilityType.values().forEach { facility ->
            val target = SeasonInvestmentPolicy.facilityTargetLevel(facility)
            assertTrue("$facility must have a positive target", target in 1..10)
            assertTrue("$facility must be prioritized while under target", SeasonInvestmentPolicy.facilityDeficitBonus(facility, target - 1) > 0)
            assertEquals("$facility must stop receiving deficit bonus at target", 0, SeasonInvestmentPolicy.facilityDeficitBonus(facility, target))
            assertEquals("$facility must not receive bonus above target", 0, SeasonInvestmentPolicy.facilityDeficitBonus(facility, target + 1))
        }
        assertEquals(6, SeasonInvestmentPolicy.facilityTargetLevel(FacilityType.RESEARCH))
        assertEquals(6, SeasonInvestmentPolicy.facilityTargetLevel(FacilityType.FACTORY))
        assertEquals(6, SeasonInvestmentPolicy.facilityTargetLevel(FacilityType.WIND_TUNNEL))
        assertEquals(5, SeasonInvestmentPolicy.facilityTargetLevel(FacilityType.MARKETING))
        assertEquals(5, SeasonInvestmentPolicy.facilityTargetLevel(FacilityType.SIMULATOR))
        assertEquals(5, SeasonInvestmentPolicy.facilityTargetLevel(FacilityType.DRIVER_DEVELOPMENT))
        assertEquals(5, SeasonInvestmentPolicy.facilityTargetLevel(FacilityType.RACE_OPERATIONS))
    }

    @Test fun sharedTechnicalEnvelopeStartsWithTheConfiguredFiftyFiveFortyFivePriority() {
        assertEquals(110_000_000L, SeasonInvestmentPolicy.aiCurrentCarAnnualLimit(200_000_000L))
        assertEquals(90_000_000L, SeasonInvestmentPolicy.aiFacilitiesAnnualLimit(200_000_000L))
        assertEquals(120_000_000L, FacilityEngine.upgradeCost(9))
        assertEquals(55, AIInvestmentMindset.STANDARD.currentCarPercentOfPool)
        assertEquals(45, AIInvestmentMindset.STANDARD.facilitiesPercentOfPool)
        assertEquals(60, AIInvestmentMindset.DOMINANT_CAR.currentCarPercentOfPool)
        assertEquals(40, AIInvestmentMindset.DOMINANT_CAR.facilitiesPercentOfPool)
        assertEquals(65, AIInvestmentMindset.TITLE_FIGHT.currentCarPercentOfPool)
        assertEquals(35, AIInvestmentMindset.TITLE_FIGHT.facilitiesPercentOfPool)
        assertEquals(65, AIInvestmentMindset.NEXT_SEASON_REBUILD.currentCarPercentOfPool)
        assertEquals(35, AIInvestmentMindset.NEXT_SEASON_REBUILD.facilitiesPercentOfPool)
    }

    @Test fun pAndDCannotConsumeProtectedFacilityShareUntilAllFacilitiesAreMaxed() {
        val team = WorldDatabase.teams.first()
        val engine = AITeamFinancialEngine(seed = 73_204)
        engine.adoptFormerPlayerTeam(
            teamId = team.id,
            season = 2028,
            finance = TeamFinanceState(budget = 500_000_000L),
            teamFacilities = TeamFacilitiesState(FacilityType.values().associateWith { 0 })
        )
        val normalCapacity = engine.developmentCapacity(team.id, 2028)
        // Mindsets can allocate up to 65% to current-car work; no non-maxed
        // team may consume the remaining facility share from the P&D pipeline.
        assertTrue("Unbuilt facilities must retain their protected share", normalCapacity <= 130_000_000L)

        engine.adoptFormerPlayerTeam(
            teamId = team.id,
            season = 2028,
            finance = TeamFinanceState(budget = 500_000_000L),
            teamFacilities = TeamFacilitiesState(FacilityType.values().associateWith { 10 })
        )
        val maxedCapacity = engine.developmentCapacity(team.id, 2028)
        assertTrue("Once all facilities are maxed, the full shared envelope can be reused", maxedCapacity <= 200_000_000L)
        assertTrue(maxedCapacity > normalCapacity)
    }

    @Test fun successiveFacilityDecisionsDiversifyAcrossNeglectedInstallationTypes() {
        val team = WorldDatabase.teams.first()
        val engine = AITeamFinancialEngine(seed = 73_205)
        engine.adoptFormerPlayerTeam(
            teamId = team.id,
            season = 2028,
            finance = TeamFinanceState(
                budget = 500_000_000L,
                seasonIncome = 100_000_000L,
                seasonExpenses = 20_000_000L
            ),
            teamFacilities = TeamFacilitiesState(FacilityType.values().associateWith { 0 })
        )
        for (week in 1..80) engine.advanceFacilityDevelopment(team.id, 2028, week, currentOverall = 62)
        val upgraded = FacilityType.values().count { engine.facilities(team.id).level(it) > 0 }
        assertTrue("Facility strategy must correct more than P&D alone", upgraded >= 4)
        assertTrue(engine.state(team.id, 2028).finance.budget >= 0L)
        assertTrue(engine.remainingTechnicalBudget(team.id, 2028) >= 0L)
    }

    @Test fun researchAndManufacturingSpendAreSeparatedInTheTechnicalLedger() {
        val team = WorldDatabase.teams.first()
        val engine = AITeamFinancialEngine(seed = 73_203)
        val initialCash = 100_000_000L
        engine.adoptFormerPlayerTeam(
            teamId = team.id,
            season = 2028,
            finance = TeamFinanceState(budget = initialCash),
            teamFacilities = FacilityEngine.initial(team.initialLevel)
        )
        val capacity = initialCash
        val after = engine.applyDevelopmentCost(
            teamId = team.id,
            season = 2028,
            developmentBudgetAfter = 90_000_000L,
            startingCapacity = capacity,
            cumulativeResearchSpent = 6_000_000L,
            cumulativeFabricationSpent = 4_000_000L
        )
        val ledger = engine.technicalInvestment(team.id, 2028)
        assertEquals(6_000_000L, ledger.researchDesignSpent)
        assertEquals(4_000_000L, ledger.fabricationSpent)
        assertEquals(10_000_000L, ledger.totalSpent)
        assertEquals(initialCash - 10_000_000L, after.finance.budget)
    }
}
