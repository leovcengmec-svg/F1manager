package com.f1teammanager.core.season

object DriverClassProgressionV672Test {
    @JvmStatic
    fun main(args: Array<String>) {
        val one = DriverClassProgressionEngine.SeasonPerformance(2030, 112.0, 30)
        val two = DriverClassProgressionEngine.SeasonPerformance(2031, 114.0, 30)

        // A Pro only becomes Lenda after winning the latest completed championship.
        check(DriverClassProgressionEngine.evaluate("Pro", 96, one, two, 30).resultingClass == "Pro")
        check(DriverClassProgressionEngine.evaluate("Pro", 96, one, two, 30, isChampion = false).resultingClass == "Pro")
        val championPromotion = DriverClassProgressionEngine.evaluate("Pro", 96, one, two, 30, isChampion = true)
        check(championPromotion.resultingClass == "Lenda")

        // Normal/Médio is the floor; low ratings and poor seasons cannot push it to Fraco.
        val poorOne = DriverClassProgressionEngine.SeasonPerformance(2030, 55.0, 30)
        val poorTwo = DriverClassProgressionEngine.SeasonPerformance(2031, 57.0, 30)
        listOf("Médio", "Normal", "Fraco").forEach { legacyOrOfficial ->
            val decision = DriverClassProgressionEngine.evaluate(legacyOrOfficial, 45, poorOne, poorTwo, 30)
            check(!decision.changed)
            check(decision.resultingClass == "Médio")
        }
        check(DriverClassProgressionEngine.ladder.first() == "Médio")
        check("Fraco" !in DriverClassProgressionEngine.ladder)

        // Shared adjacent-class guard also prevents legacy adapters bypassing the rules.
        check(DriverClassProgressionEngine.adjacentClass("Médio", promote = false) == null)
        check(DriverClassProgressionEngine.adjacentClass("Pro", promote = true) == null)
        check(DriverClassProgressionEngine.adjacentClass("Pro", promote = true, isChampion = true) == "Lenda")
        check(DriverClassProgressionEngine.adjacentClass("Normal", promote = true) == "Forte")

        println("DriverClassProgressionV672Test: PASS")
    }
}
