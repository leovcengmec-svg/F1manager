package com.f1teammanager.core.manager

import com.f1teammanager.core.manager.InitialTeamProfile
import com.f1teammanager.core.season.WorldDatabase

/** V86 regression audit for the canonical physical-car chain and facilities. */
fun main() {
    val team = WorldDatabase.teams.first()
    val market = DriverMarketEngine(20261007).initialState(2026)
    var state = TeamManagerState(
        season = 2026, round = 1, playerTeamId = team.id,
        car = InitialTeamProfile.carState(team),
        facilities = FacilityEngine.initial(2)
            .withLevel(FacilityType.WIND_TUNNEL, 10)
            .withLevel(FacilityType.SIMULATOR, 10),
        garage = TeamGarageFactory.fromInitial(team),
        finance = TeamFinanceState(500_000_000L),
        driverMarket = market
    )
    val originalCar2 = state.garage!!.car2.frontWing
    val initialCar1 = state.garage!!.car1.frontWing

    state = ResearchEngine().start(state, CarComponent.FRONT_WING, ResearchFocus.PERFORMANCE, ResearchComplexity.SIMPLE, 1)
    state = ResearchEngine().advanceWeeks(state, 2, 2026, 3)
    check(state.research.completedDesigns.isNotEmpty()) { "P&D não gerou Design" }
    val design = state.research.completedDesigns.last()
    val option = FactoryEngine().options(design, state.facilities).first()
    state = FactoryEngine().start(state, design, option, 3)
    state = FactoryEngine().advanceWeeks(state, option.weeks, 5)
    val piece = state.garage!!.inventory.firstOrNull() ?: error("Fábrica não gerou peça física")
    state = state.copy(garage = state.garage!!.install(piece, GarageCarId.CAR_1))

    check(state.garage!!.car1.frontWing == piece.performance) { "Carro 1 não recebeu a peça" }
    check(state.garage!!.car2.frontWing == originalCar2) { "Carro 2 foi alterado sem instalação" }
    check(state.garage!!.car1.frontWing != initialCar1) { "Peça instalada não alterou o desempenho físico" }

    val raceCar = DynamicGridEngine().participants(
        market, team.id, 1, 2026, 0, emptyMap(), state.garage!!, state.facilities
    ).first { it.teamId == team.id }
    val baseline = DynamicGridEngine().participants(
        market, team.id, 1, 2026, 0, emptyMap(), state.garage!!, TeamFacilitiesState()
    ).first { it.teamId == team.id }
    check(raceCar.frontWingPerformance >= baseline.frontWingPerformance) { "Instalações não chegaram à corrida" }

    println("V86_ROOT_INTEGRATION_AUDIT_OK")
}
