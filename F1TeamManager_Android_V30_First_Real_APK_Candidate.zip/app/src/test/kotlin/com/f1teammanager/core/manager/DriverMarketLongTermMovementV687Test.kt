package com.f1teammanager.core.manager

import com.f1teammanager.core.season.WorldDatabase
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class DriverMarketLongTermMovementV687Test {
    @Test fun `ai market continues to produce transfers beyond the opening season`() {
        val playerTeamId = WorldDatabase.teams.first().id
        val budgets = WorldDatabase.teams.associate { it.id to 100_000_000L }
        val transferCounts = mutableListOf<Int>()

        listOf(20261003, 20261006, 20261018).forEach { seed ->
            val engine = DriverMarketEngine(seed)
            var state = engine.initialState(2026)
            for (season in 2026..2029) {
                for (week in 21..56) state = engine.processAiMarketWeek(state, season, week, playerTeamId = playerTeamId)
                val signed = state.scheduled.filter { it.signedSeason == season && it.startSeason == season + 1 }
                val transfers = signed.count { it.fromTeamId > 0 && it.fromTeamId != it.toTeamId }
                if (season >= 2027) transferCounts += transfers
                state = engine.applySeasonTransition(state, season + 1, budgets, playerTeamId = playerTeamId)
                WorldDatabase.teams.filter { it.id != playerTeamId }.forEach { team ->
                    assertEquals("${team.name} must retain a two-driver grid after ${season + 1}", 2, engine.roster(state, team.id, season = season + 1).size)
                }
                assertEquals(state.contracts.size, state.contracts.map { it.driverId }.distinct().size)
            }
        }

        assertTrue("Later seasons must not collapse into renewals only: $transferCounts", transferCounts.count { it > 0 } >= 8)
        assertTrue("The multi-season market needs recurring team changes, not one opening-season burst: $transferCounts", transferCounts.sum() >= 18)
    }
}
