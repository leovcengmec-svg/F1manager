package com.f1teammanager.core.manager

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class NextSeasonProjectionRunwayV721Test {
    private val engine = CarDevelopmentEngine()

    @Test
    fun `opening week projects the planned investment when cash covers the remaining target`() {
        val overall = 65
        val target = engine.investmentReferenceForNextSeasonTarget(
            overall, NextSeasonCarGrowthPolicy.maximumGain(overall)
        ).coerceAtMost(SeasonInvestmentPolicy.AI_NEXT_CAR_ABSOLUTE_CAP)

        val projected = engine.projectedNextSeasonInvestment(
            currentOverall = overall,
            actualInvested = 0L,
            completedRounds = 0,
            availableCash = 150_000_000L
        )

        assertEquals(target, projected)
        assertTrue(projected > 0L)
    }

    @Test
    fun `projection converges to actual investment at season end`() {
        val actual = 27_000_000L
        val projected = engine.projectedNextSeasonInvestment(
            currentOverall = 71,
            actualInvested = actual,
            completedRounds = 30,
            availableCash = 150_000_000L
        )
        assertEquals(actual, projected)
    }

    @Test
    fun `projection is bounded by cash runway and independent annual cap`() {
        val actual = 10_000_000L
        val cash = 2_000_000L
        val projected = engine.projectedNextSeasonInvestment(
            currentOverall = 75,
            actualInvested = actual,
            completedRounds = 0,
            availableCash = cash
        )
        assertEquals(actual + cash, projected)
        assertTrue(projected <= SeasonInvestmentPolicy.AI_NEXT_CAR_ABSOLUTE_CAP)
    }

    @Test
    fun `projection never reduces already committed investment when no cash remains`() {
        val actual = 42_000_000L
        assertEquals(
            actual,
            engine.projectedNextSeasonInvestment(70, actual, 12, 0L)
        )
    }
}
