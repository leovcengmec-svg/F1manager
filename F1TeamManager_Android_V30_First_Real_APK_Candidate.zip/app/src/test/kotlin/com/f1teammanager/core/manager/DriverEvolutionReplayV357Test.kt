package com.f1teammanager.core.manager

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class DriverEvolutionReplayV357Test {
    @Test fun processedRoundKeyIsScopedBySeasonAndRound() {
        val processed = setOf("2026:1", "2026:2", "2027:1")
        assertTrue("2026:1" in processed)
        assertTrue("2027:1" in processed)
        assertFalse("2027:2" in processed)
        assertEquals(3, processed.size)
    }

    @Test fun duplicateMarkerDoesNotGrowWhenSameRoundIsReplayed() {
        val initial = setOf("2026:8")
        val replay = initial + "2026:8"
        assertEquals(initial, replay)
    }
}
