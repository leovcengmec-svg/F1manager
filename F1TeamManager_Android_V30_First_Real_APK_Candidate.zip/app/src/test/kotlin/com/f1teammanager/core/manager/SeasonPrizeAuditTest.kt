import com.f1teammanager.core.manager.SeasonPrizeEngine
fun main(){
 val p=(1..40).map{SeasonPrizeEngine.prizeForPosition(it)}
 check(p.first()==100_000_000L); check(p.last()==10_000_000L); check(p.distinct().size==40)
 check((1..10).zipWithNext().all{p[it.first-1]>p[it.second-1]})
 check((11..39).zipWithNext().all{p[it.first-1]>p[it.second-1]})
 println("SeasonPrizeAuditTest: PASS — 40 posições distintas; 1º=€100M; 40º=€10M")
}
