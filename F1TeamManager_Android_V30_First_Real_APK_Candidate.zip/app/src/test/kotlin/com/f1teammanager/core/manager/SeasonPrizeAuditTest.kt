import com.f1teammanager.core.manager.SeasonPrizeEngine
fun main(){
 val p=(1..40).map{SeasonPrizeEngine.prizeForPosition(it)}
 check(p.first()==100_000_000L); check(p.last()==40_000_000L); check(p.distinct().size==40)
 check((1..39).all{p[it-1]>p[it]})
 check(p.take(10).zipWithNext().all{(a,b)->a-b>=2_000_000L})
 check(p[9]==60_000_000L)
 check(p[10]==58_500_000L && p[19]==45_000_000L)
 check(p[20]==44_750_000L && p[38]==40_250_000L)
 println("SeasonPrizeAuditTest: PASS — 40 posições únicas; 1º=€100M; 10º=€60M; 40º=€40M; gaps maiores no top 10")
}
