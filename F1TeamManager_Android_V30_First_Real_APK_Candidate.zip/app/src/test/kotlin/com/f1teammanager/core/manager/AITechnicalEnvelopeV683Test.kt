package com.f1teammanager.core.manager

import com.f1teammanager.core.season.WorldDatabase
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class AITechnicalEnvelopeV683Test {
    @Test fun nextCarInvestmentsConsumeTheSharedAnnualEnvelopeAndSurviveRestore() {
        val teamId = WorldDatabase.teams.first().id
        val ai = AITeamFinancialEngine(seed = 683)
        ai.adoptFormerPlayerTeam(
            teamId = teamId,
            season = 2026,
            finance = TeamFinanceState(budget = 300_000_000L),
            teamFacilities = FacilityEngine.initial(0)
        )
        assertEquals(200_000_000L, ai.remainingTechnicalBudget(teamId, 2026))

        var invested = 0L
        for (round in 1..30) {
            invested = ai.considerNextSeasonInvestment(
                teamId = teamId,
                season = 2026,
                round = round,
                currentOverall = 55,
                market = DriverMarketState()
            )
        }
        assertTrue("The cash-rich AI should use its next-car allocation when a target exists", invested > 0L)
        assertTrue(invested <= 80_000_000L)
        assertEquals(200_000_000L - invested, ai.remainingTechnicalBudget(teamId, 2026))

        val restored = AITeamFinancialEngine(seed = 683).also { it.restoreSnapshot(ai.exportSnapshot()) }
        assertEquals(invested, restored.nextSeasonInvestment(teamId, 2026))
        assertEquals(200_000_000L - invested, restored.remainingTechnicalBudget(teamId, 2026))
    }

    @Test fun currentCarCanReuseAnIdleFacilityAllocationInsideTheSharedEnvelope() {
        val teamId = WorldDatabase.teams.first().id
        val ai = AITeamFinancialEngine(seed = 684)
        ai.adoptFormerPlayerTeam(
            teamId = teamId,
            season = 2026,
            finance = TeamFinanceState(budget = 300_000_000L),
            teamFacilities = FacilityEngine.initial(0)
        )
        val capacity = ai.developmentCapacity(teamId, 2026)
        assertTrue(capacity >= 100_000_000L)

        ai.applyDevelopmentCost(
            teamId = teamId,
            season = 2026,
            developmentBudgetAfter = capacity - 100_000_000L,
            startingCapacity = capacity
        )

        assertEquals(100_000_000L, ai.technicalInvestment(teamId, 2026).totalSpent)
        assertEquals(100_000_000L, ai.remainingTechnicalBudget(teamId, 2026))
    }
}
