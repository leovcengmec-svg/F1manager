package com.f1teammanager.core.manager

import com.f1teammanager.core.season.WorldDatabase
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class CommercialEconomyV671Test {
    @Test fun commercialValueNeverFallsWhenMarketingLevelIncreases() {
        val values = (0..10).map { SponsorContractPricing.commercialMultiplier(it) }
        assertEquals(1.60, values.first(), 0.000001)
        assertEquals(1.85, values.last(), 0.000001)
        assertTrue(values.zipWithNext().all { (current, next) -> next > current })
    }

    @Test fun marketingQualityImprovesHigherTierDrawOddsWithoutUnlockingEarly() {
        val engine = TeamSponsorshipEngine(671)
        assertEquals(0, engine.marketingQualityCategoryShift(0))
        assertEquals(1, engine.marketingQualityCategoryShift(1))
        assertEquals(10, engine.marketingQualityCategoryShift(10))
        assertEquals(listOf(SponsorCategory.BASICO), engine.availableCategories(1))
        assertEquals(listOf(SponsorCategory.BASICO, SponsorCategory.REGIONAL), engine.availableCategories(2))
        // The same raw roll must move toward the stronger tier as marketing improves.
        assertEquals(SponsorCategory.BASICO, engine.categoryForQualityRoll(2, 67))
        assertEquals(SponsorCategory.REGIONAL, engine.categoryForQualityRoll(2, 68))
        assertEquals(SponsorCategory.REGIONAL, engine.categoryForQualityRoll(3, 47))
        assertEquals(SponsorCategory.GLOBAL, engine.categoryForQualityRoll(9, 84))
        // Levels 0 and 1 do not unlock a stronger category prematurely.
        assertEquals(SponsorCategory.BASICO, engine.categoryForQualityRoll(1, 99))
    }

    @Test fun raceBonusPaysOnlyWhenFinishIsInsideDisplayedWindow() {
        val sponsor = SponsorContract(
            name = "Patrocinador Janela", upfront = 0L, racePayment = 0L,
            pointsBonus = 0L, years = 1, minimumReputation = 0, slot = 2,
            qualifyingTarget = 0, qualifyingBonus = 0L,
            raceTarget = 8, raceTargetBonus = 500_000L,
            active = true, races = 5, racesRemaining = 5,
            category = "REGIONAL", raceTargetMin = 4, raceTargetMax = 8
        )
        val engine = FinanceEngine()
        fun receivedBonus(position: Int): Boolean {
            val settled = engine.settleRaceFinance(
                TeamFinanceState(20_000_000L), 1, listOf(sponsor), position,
                teamPoints = 0, isDnf = false, season = 2027, round = position,
                bestQualifyingPosition = 0
            )
            return settled.transactions.any { it.startsWith("+500000:Bônus por meta de corrida") }
        }
        assertTrue(receivedBonus(4))
        assertTrue(receivedBonus(8))
        assertFalse(receivedBonus(3))
        assertFalse(receivedBonus(9))
    }

    @Test fun legacyContractMigrationDoesNotApplyNewEntryLevelBonusRetroactively() {
        val legacy = SponsorContract(
            name = "Legacy Regional", upfront = 2_500_000L, racePayment = 0L,
            pointsBonus = 0L, years = 1, minimumReputation = 0, slot = 2,
            active = true, races = 5, racesRemaining = 3, category = "REGIONAL"
        )
        val migrated = SponsorContractPricing.ensureEntryAndGp(legacy, 1, 2027, marketingLevel = 0)
        assertEquals(legacy.upfront, migrated.upfront)
        assertTrue(migrated.racePayment in 250_000L..450_000L)
    }

    @Test fun newOffersDoNotKeepAnUnusedPointsBonus() {
        val offers = TeamSponsorshipEngine(671).offersForSlot(1, 2027, 2, 10, 3)
        assertEquals(3, offers.size)
        assertTrue(offers.all { it.sponsor.pointsBonus == 0L })
    }

    @Test fun unusedFacilitiesShareAccumulatesAndUnlocksUpgradesAboveFortyMillion() {
        val teamId = WorldDatabase.teams.first().id
        val facilities = TeamFacilitiesState(FacilityType.values().associateWith {
            if (it == FacilityType.MARKETING) 5 else 10
        })
        val engine = AITeamFinancialEngine(seed = 671)
        engine.adoptFormerPlayerTeam(teamId, 2026, TeamFinanceState(300_000_000L), facilities)
        assertEquals(40_000_000L, engine.availableAiFacilityAllocation(teamId, 2026))

        // The next season contributes another €40M; the banked €80M can now fund
        // the €52M transition from Commercial Center level 5 to level 6.
        engine.adoptFormerPlayerTeam(teamId, 2027, TeamFinanceState(300_000_000L), facilities)
        assertEquals(80_000_000L, engine.availableAiFacilityAllocation(teamId, 2027))
        val started = engine.advanceFacilityDevelopment(teamId, 2027, 8)
        assertNotNull(engine.facilityUpgrade(teamId))
        assertEquals(FacilityType.MARKETING, engine.facilityUpgrade(teamId)?.facility)
        assertEquals(248_000_000L, started.finance.budget)
        assertEquals(28_000_000L, engine.availableAiFacilityAllocation(teamId, 2027))

        val restored = AITeamFinancialEngine(seed = 671).also { it.restoreSnapshot(engine.exportSnapshot()) }
        assertEquals(28_000_000L, restored.availableAiFacilityAllocation(teamId, 2027))
    }
}
