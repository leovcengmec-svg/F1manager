package com.f1teammanager.core.manager

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Test

class FacilityPercentageFormattingV735Test {
    @Test fun formatsAllFacilityPercentagesWithOneBrazilianDecimalPlace() {
        val values = listOf(0.4, 0.15, 5.6, 12.8, -20.0, 0.0)
        val formatted = values.map(FacilityPercentageFormatter::format)
        assertEquals(listOf("0,4", "0,2", "5,6", "12,8", "-20,0", "0,0"), formatted)
        formatted.forEach { value ->
            assertFalse(value.contains("000000000"))
            assertEquals(1, value.substringAfter(',').length)
        }
    }
}
