package com.f1teammanager.core.manager

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SeasonInvestmentPolicyV437Test {
    @Test fun phaseLimitsBecomeMoreFlexibleAsSeasonProgresses() {
        assertEquals(10, SeasonInvestmentPolicy.phasePercent(1))
        assertEquals(15, SeasonInvestmentPolicy.phasePercent(10))
        assertEquals(25, SeasonInvestmentPolicy.phasePercent(18))
        assertEquals(35, SeasonInvestmentPolicy.phasePercent(30))
    }

    @Test fun cumulativeCapNeverExceedsFreeCashOrGlobalCap() {
        val early = SeasonInvestmentPolicy.maximumCumulativeInvestment(100_000_000L, 1, 150_000_000L)
        val late = SeasonInvestmentPolicy.maximumCumulativeInvestment(100_000_000L, 30, 150_000_000L)
        assertTrue(early > 0L)
        assertTrue(late > early)
        assertTrue(late <= 150_000_000L)
        assertTrue(late <= 80_000_000L * 35L / 100L)
    }

    @Test fun lowCashTeamHasNoDiscretionaryBudgetWhenCashIsFullyProtected() {
        assertEquals(0L, SeasonInvestmentPolicy.maximumCumulativeInvestment(1_000_000L, 1, 150_000_000L))
        assertEquals(0L, SeasonInvestmentPolicy.aiSpendableCash(1_000_000L, 30_000_000L, 1))
    }

    @Test fun aiReserveProtectsNextInstallmentInsteadOfAllFutureGps() {
        val annualSalary = 30_000_000L
        val early = SeasonInvestmentPolicy.aiOperatingReserve(annualSalary, 1)
        val late = SeasonInvestmentPolicy.aiOperatingReserve(annualSalary, 29)
        val finalRound = SeasonInvestmentPolicy.aiOperatingReserve(annualSalary, 30)
        // €1M next salary installment + €850k next GP cost + €2M buffer.
        assertEquals(3_850_000L, early)
        assertEquals(3_850_000L, late)
        assertEquals(3_000_000L, finalRound)
        assertTrue(early < annualSalary)
    }

    @Test fun aiWithCashAboveNextGpReserveHasSpendableBudgetLateInSeason() {
        val reserve = SeasonInvestmentPolicy.aiOperatingReserve(30_000_000L, 28)
        assertEquals(3_850_000L, reserve)
        assertEquals(6_150_000L, SeasonInvestmentPolicy.aiSpendableCash(10_000_000L, 30_000_000L, 28))
    }

    @Test fun frozenBaselineKeepsCumulativeLimitStableAfterInvestment() {
        val base = 100_000_000L
        val earlyCap = SeasonInvestmentPolicy.maximumCumulativeInvestment(base, 1, 150_000_000L)
        val laterCap = SeasonInvestmentPolicy.maximumCumulativeInvestment(base, 10, 150_000_000L)
        assertEquals(8_000_000L, earlyCap)
        assertEquals(12_000_000L, laterCap)
    }

    @Test fun playerCannotSpendProtectedCashOnNextSeasonCar() {
        val engine = CarDevelopmentEngine()
        val car = TeamCarState(55, 55, 55, 55, frontWing = 55, rearWing = 55, brakes = 55, electricPowerUnit = 55)
        val state = TeamManagerState(round = 1, car = car, finance = TeamFinanceState(10_000_000L))
        val allowed = SeasonInvestmentPolicy.maximumCumulativeInvestment(10_000_000L, 1, engine.nextSeasonInvestmentCap(car))
        assertTrue(allowed < 10_000_000L)
        try {
            engine.investNextSeason(state, 8_000_000L)
            throw AssertionError("O investimento deveria ser bloqueado pela reserva operacional")
        } catch (expected: IllegalArgumentException) {
            assertTrue(expected.message.orEmpty().contains("Limite") || expected.message.orEmpty().contains("bloqueado"))
        }
    }
}
