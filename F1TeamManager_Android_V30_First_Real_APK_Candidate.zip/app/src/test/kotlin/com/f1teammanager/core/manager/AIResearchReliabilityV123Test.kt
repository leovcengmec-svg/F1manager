package com.f1teammanager.core.manager

import com.f1teammanager.core.season.WorldDatabase
import org.junit.Test
import kotlin.test.assertTrue

class AIResearchReliabilityV123Test {
    @Test
    fun `AI research uses current component reliability and player focus mechanics`() {
        val team = WorldDatabase.teams.first { it.initialLevel == InitialTeamProfile.FORTE }
        val initial = InitialTeamProfile.carState(team)
        val result = AITeamDevelopmentEngine(20261005).simulateFinancial(team, 7, 2026, 500_000_000L)
        val initialRel = initial.reliability
        val installedRels = result.garage!!.car1.componentReliabilities.values + result.garage.car2.componentReliabilities.values
        assertTrue(installedRels.isNotEmpty())
        assertTrue(installedRels.all { it in 1..100 })
        assertTrue(installedRels.any { it < 94 }, "A IA ainda está recebendo confiabilidade sintética 94..100")
        assertTrue(result.car.reliability >= 1)
        assertTrue(initialRel in 65..74)
    }
}
