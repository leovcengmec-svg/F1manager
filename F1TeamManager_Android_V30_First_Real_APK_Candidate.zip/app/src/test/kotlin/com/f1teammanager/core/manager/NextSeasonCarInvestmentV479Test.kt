package com.f1teammanager.core.manager

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class NextSeasonCarInvestmentV479Test {
    @Test fun targetScalesToReferenceAndRemainingGps() {
        assertEquals(2_000_000L, SeasonInvestmentPolicy.plannedNextCarContribution(40_000_000L, 0L, 11, 0L))
        assertEquals(6_000_000L, SeasonInvestmentPolicy.plannedNextCarContribution(40_000_000L, 10_000_000L, 26, 0L))
        assertEquals(30_000_000L, SeasonInvestmentPolicy.plannedNextCarContribution(40_000_000L, 10_000_000L, 30, 0L))
    }

    @Test fun contributionStopsAtTargetAndUsesMinimumBelowTarget() {
        assertEquals(0L, SeasonInvestmentPolicy.plannedNextCarContribution(40_000_000L, 40_000_000L, 28, 750_000L))
        assertTrue(SeasonInvestmentPolicy.plannedNextCarContribution(40_000_000L, 0L, 29, 750_000L) >= 750_000L)
    }

    @Test fun actualContributionIsBoundedByCashCapsAndChosenImprovementTarget() {
        val target = 82_000_000L // reference for Overall 73, above Overall 70's €70M
        assertEquals(2_500_000L, SeasonInvestmentPolicy.allowedNextCarInvestmentAmount(
            roomUnderCaps = 5_000_000L, spendableCash = 2_500_000L,
            targetCost = target, alreadyInvested = 70_000_000L, desiredChunk = 8_000_000L
        ))
        assertEquals(1_000_000L, SeasonInvestmentPolicy.allowedNextCarInvestmentAmount(
            roomUnderCaps = 1_000_000L, spendableCash = 9_000_000L,
            targetCost = target, alreadyInvested = 70_000_000L, desiredChunk = 8_000_000L
        ))
        assertEquals(500_000L, SeasonInvestmentPolicy.allowedNextCarInvestmentAmount(
            roomUnderCaps = 5_000_000L, spendableCash = 9_000_000L,
            targetCost = target, alreadyInvested = 81_500_000L, desiredChunk = 8_000_000L
        ))
        assertEquals(0L, SeasonInvestmentPolicy.allowedNextCarInvestmentAmount(
            roomUnderCaps = 5_000_000L, spendableCash = 9_000_000L,
            targetCost = target, alreadyInvested = target, desiredChunk = 8_000_000L
        ))
    }

    @Test fun improvementTargetCanExceedCurrentStrengthReference() {
        val development = CarDevelopmentEngine()
        val currentStrengthReference = development.referenceInvestmentForOverall(70)
        val improvementReference = development.referenceInvestmentForOverall(73)
        assertTrue(improvementReference > currentStrengthReference)
        assertEquals(82_000_000L, improvementReference)
        // Once the improvement target is funded, the planned contribution is zero.
        assertEquals(0L, SeasonInvestmentPolicy.plannedNextCarContribution(improvementReference, improvementReference, 25, 1_000_000L))
    }
}
