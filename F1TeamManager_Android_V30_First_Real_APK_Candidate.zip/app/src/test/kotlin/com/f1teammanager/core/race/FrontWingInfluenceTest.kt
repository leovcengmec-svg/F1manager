package com.f1teammanager.core.race

import kotlin.random.Random
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

class FrontWingInfluenceTest {
    @Test fun levelsAndLapModifiersMatchApprovedScale() {
        assertEquals(1, CarComponentInfluence.level(40))
        assertEquals(6, CarComponentInfluence.level(70))
        assertEquals(10, CarComponentInfluence.level(100))
        assertEquals(0.0180, CarComponentInfluence.frontWingLapModifier(40))
        assertEquals(0.0, CarComponentInfluence.frontWingLapModifier(70))
        assertEquals(-0.0140, CarComponentInfluence.frontWingLapModifier(100))
    }

    @Test fun drsEfficiencyUsesFrontWingLevel() {
        val pLow = RaceParticipant(driverId=1,driverName="A",teamId=1,teamName="T",driverSpeed=70,qualifying=70,overtaking=70,defense=70,consistency=70,enginePerformance=70,tyreGrip=50,tyreWear=50,reliability=95,chassisWear=0,wetSkill=50,chassisPerformance=50,frontWingPerformance=40,rearWingPerformance=50,brakesPerformance=50,electricPowerUnitPerformance=50)
        val pMid = pLow.copy(frontWingPerformance = 70)
        val pHigh = pLow.copy(frontWingPerformance = 100)
        val pace = PitwallPaceModel(Random(1))
        val circuit = RaceCircuit(1, "Teste", 60, 90_000L)
        // DRS usa 1,5% do tempo médio e pesa Asa dianteira 40% + traseira 60%.
        assertTrue(pace.drsGainMs(pLow, circuit) < pace.drsGainMs(pHigh, circuit))
    }

    @Test fun rearWingIsPrimaryDrsComponent() {
        val p = RaceParticipant(driverId=1,driverName="A",teamId=1,teamName="T",driverSpeed=70,qualifying=70,overtaking=70,defense=70,consistency=70,enginePerformance=70,tyreGrip=50,tyreWear=50,reliability=95,chassisWear=0,wetSkill=50,chassisPerformance=50,frontWingPerformance=50,rearWingPerformance=50,brakesPerformance=50,electricPowerUnitPerformance=50)
        val low = p.copy(rearWingPerformance = 40)
        val high = p.copy(rearWingPerformance = 100)
        val pace = PitwallPaceModel(Random(2))
        val circuit = RaceCircuit(1, "Teste", 60, 90_000L)
        assertTrue(pace.drsGainMs(low, circuit) < pace.drsGainMs(high, circuit))
        val delta = pace.drsGainMs(high, circuit) - pace.drsGainMs(low, circuit)
        assertTrue(delta >= 60L)
    }
}
