package com.f1teammanager.core.manager

import com.f1teammanager.core.season.WorldDatabase
import org.junit.Assert.assertEquals
import org.junit.Test

/** V652 regression: the AI does not block technical investment behind a commercial-center gate. */
class CommercialPriorityAndSponsorshipV642Test {
    @Test fun aiUsesAffordableTechnicalUpgradeWhenCommercialExpansionWouldBreakItsReserve() {
        val teamId = WorldDatabase.teams.first().id
        val levels = FacilityType.values().associateWith { type ->
            when (type) {
                FacilityType.MARKETING -> 2
                else -> 0
            }
        }
        val ai = AITeamFinancialEngine(seed = 642)
        // €28M covers a €10M level-0 alternative but not the €22M Marketing upgrade
        // while preserving the engine's €15M operating floor.
        val startingFinance = TeamFinanceState(
            budget = 28_000_000L,
            seasonIncome = 10_000_000L,
            seasonExpenses = 5_000_000L
        )
        ai.adoptFormerPlayerTeam(teamId, 2026, startingFinance, TeamFacilitiesState(levels))

        ai.advanceFacilityDevelopment(teamId, 2026, 8)

        assertEquals("Research is affordable while Marketing 2→3 is not", FacilityType.RESEARCH, ai.facilityUpgrade(teamId)?.facility)
        assertEquals("Only the technical upgrade should be debited", 18_000_000L, ai.state(teamId, 2026).finance.budget)
        assertEquals(2, ai.facilities(teamId).level(FacilityType.MARKETING))
    }
}
