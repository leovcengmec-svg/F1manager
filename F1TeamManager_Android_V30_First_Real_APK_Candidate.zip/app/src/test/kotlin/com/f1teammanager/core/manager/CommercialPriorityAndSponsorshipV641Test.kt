package com.f1teammanager.core.manager

import com.f1teammanager.core.season.WorldDatabase
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** Regression tests for V652 risk-based facility investment and AI/player sponsor-market parity. */
class CommercialPriorityAndSponsorshipV641Test {
    @Test fun aiPrioritizesTechnicalRecoveryBeforeCommercialExpansionWhenFacilitiesAreUnderbuilt() {
        val teamId = WorldDatabase.teams.first().id
        val levels = FacilityType.values().associateWith { type ->
            when (type) {
                FacilityType.MARKETING -> 2
                else -> 0
            }
        }
        val ai = AITeamFinancialEngine(seed = 641)
        ai.adoptFormerPlayerTeam(
            teamId, 2026,
            TeamFinanceState(budget = 250_000_000L, seasonIncome = 80_000_000L, seasonExpenses = 25_000_000L),
            TeamFacilitiesState(levels)
        )

        ai.advanceFacilityDevelopment(teamId, 2026, 8)
        assertEquals("Research must lead while technical facilities are still at level 0", FacilityType.RESEARCH, ai.facilityUpgrade(teamId)?.facility)
        assertEquals(1, ai.facilityUpgrade(teamId)?.targetLevel)
        for (week in 9..20) ai.advanceFacilityDevelopment(teamId, 2026, week)
        assertEquals(1, ai.facilities(teamId).level(FacilityType.RESEARCH))
    }

    @Test fun scoutingCannotBeatHigherPriorityFacilitiesOnlyBecauseItsLevelIsLower() {
        val teamId = WorldDatabase.teams.first().id
        val levels = FacilityType.values().associateWith { type ->
            when (type) {
                FacilityType.RESEARCH, FacilityType.FACTORY -> 10
                FacilityType.MARKETING -> 3
                FacilityType.SCOUTING -> 0
                else -> 5
            }
        }
        val ai = AITeamFinancialEngine(seed = 642)
        ai.adoptFormerPlayerTeam(
            teamId, 2026,
            TeamFinanceState(budget = 350_000_000L, seasonIncome = 0L, seasonExpenses = 1L),
            TeamFacilitiesState(levels)
        )
        ai.advanceFacilityDevelopment(teamId, 2026, 8)
        assertEquals("Wind Tunnel must be chosen ahead of low-level Scouting", FacilityType.WIND_TUNNEL, ai.facilityUpgrade(teamId)?.facility)
    }

    @Test fun aiRenewalEvaluatesTheSameThreeOffersThatThePlayerMarketDisplays() {
        val season = 2026
        val marketingLevel = 3
        var scenarioEngine: TeamSponsorshipEngine? = null
        var scenarioTeamId = -1
        var expiring: SponsorContract? = null
        // Find a deterministic case with one unique earliest expiry so no second
        // slot changes the offer exclusion set during the same GP transaction.
        search@ for (seed in 641..670) {
            for (team in WorldDatabase.teams.take(12)) {
                val candidateEngine = TeamSponsorshipEngine(seed)
                candidateEngine.setMarketingLevel(team.id, marketingLevel)
                val sponsors = candidateEngine.forTeam(team.id, season).sponsors
                val shortest = sponsors.minOf { it.racesRemaining }
                val earliest = sponsors.filter { it.racesRemaining == shortest }
                if (earliest.size == 1) {
                    scenarioEngine = candidateEngine
                    scenarioTeamId = team.id
                    expiring = earliest.single()
                    break@search
                }
            }
        }
        assertNotNull("Need a deterministic unique-expiry case", scenarioEngine)
        assertNotNull(expiring)
        val engine = scenarioEngine!!
        val target = expiring!!
        val visibleOffers = engine.offersForSlot(scenarioTeamId, season, target.slot, marketingLevel, target.racesRemaining)
        assertEquals(3, visibleOffers.size)
        val teamRank = WorldDatabase.teams.sortedByDescending {
            val c = InitialTeamProfile.values(it)
            (c.chassis + c.engine + c.frontWing + c.rearWing + c.brakes + c.electricPowerUnit) / 6.0
        }.indexOfFirst { it.id == scenarioTeamId } + 1
        val expected = engine.selectBestAiSponsorOffer(visibleOffers, teamRank).sponsor

        for (round in 1..target.racesRemaining) engine.advanceRace(scenarioTeamId, season, round)
        val actual = engine.forTeam(scenarioTeamId, season).sponsors.first { it.slot == target.slot }
        assertEquals("AI should sign the best of the same 3 market offers", expected.name, actual.name)
        assertTrue("The signed AI contract must follow the same category/market rules", visibleOffers.any { it.category.name == actual.category && it.sponsor.name == actual.name })
        assertEquals("Each team must avoid duplicate active sponsor brands", 5, engine.forTeam(scenarioTeamId, season).sponsors.map { it.name }.distinct().size)
    }

    @Test fun playerOfferGenerationExcludesItsActualActivePortfolio() {
        val teamId = WorldDatabase.teams.first().id
        val season = 2026
        val marketingLevel = 3
        val engine = TeamSponsorshipEngine(seed = 644)
        val actualPortfolio = engine.forTeam(teamId, season).sponsors
        val slot = 2
        val activeNames = actualPortfolio.filter { it.active && it.racesRemaining > 0 && it.slot != slot }
            .map { it.name }.toSet()

        val offers = engine.offersForSlot(teamId, season, slot, marketingLevel, 5, activeNames)
        assertEquals(3, offers.size)
        assertTrue("An active sponsor from another slot must not be re-offered", offers.none { it.sponsor.name in activeNames })
    }

    @Test fun aiUsesSharedRaceSettlementRulesForSponsorPayments() {
        val teamId = WorldDatabase.teams.first().id
        val season = 2026
        val engine = TeamSponsorshipEngine(seed = 643)
        val sponsors = engine.forTeam(teamId, season).sponsors
        val financeBefore = TeamFinanceState(budget = 100_000_000L)
        val expected = FinanceEngine().settleRaceFinance(
            financeBefore, teamId, sponsors, finishPosition = 8, teamPoints = 4,
            isDnf = false, season = season, round = 1, bestQualifyingPosition = 7
        )
        val aiFinance = AITeamFinancialEngine(seed = 643)
        aiFinance.adoptFormerPlayerTeam(teamId, season, financeBefore, FacilityEngine.initial(0))
        val actual = aiFinance.applyRace(
            teamId, season, 1,
            TeamSponsorshipEngine.TeamSponsorshipState(teamId, season, sponsors, sponsors.sumOf { it.upfront } + sponsors.sumOf { it.racePayment } * 30L),
            DriverMarketState(), bestFinish = 8, points = 4, isDnf = false, bestQualifyingPosition = 7
        ).finance
        assertEquals(expected.budget, actual.budget)
        assertEquals(expected.raceSettlementKeys, actual.raceSettlementKeys)
        assertNotEquals("This test must cover a paid sponsorship portfolio", financeBefore.budget, actual.budget)
    }

}
