package com.f1teammanager.core.manager

import com.f1teammanager.core.season.WorldDatabase

fun main() {
    val team = WorldDatabase.teams.first { it.id == 1 }
    val engine = AITeamDevelopmentEngine(20261005)
    val season1 = engine.simulate(team, 56, 2026)
    val season2 = engine.simulate(team, 0, 2027)
    val development = CarDevelopmentEngine()
    val currentOverall = development.carOverall(season1)
    val targetInvestment = development.investmentReferenceForNextSeasonTarget(
        currentOverall, NextSeasonCarGrowthPolicy.maximumGain(currentOverall)
    )
    val minimum = (currentOverall - 10).coerceAtLeast(40)
    val zeroInvestment = development.buildAiNextSeasonLegacyCar(season1, 0L)
    val zeroOverall = development.carOverall(zeroInvestment)
    check(zeroOverall >= minimum) {
        "A construção pela tabela não pode perder mais de 10 pontos de Overall na virada"
    }
    val tableTarget = development.constructionOverallForInvestment(target)!!
    val funded = development.buildAiNextSeasonLegacyCar(season1, target)
    check(development.carOverall(funded) <= tableTarget) {
        "A força final não pode ultrapassar a tabela de investimento e o teto anual"
    }
    check(season2.frontWing != team.frontWing || season2.engine != team.engine || season2.chassis != team.chassis) {
        "Carro AI voltou ao carro-base em vez de carregar a temporada anterior"
    }
    println("AI_CAR_CONTINUITY_OK")
}
