package com.f1teammanager.core.manager

import com.f1teammanager.core.season.WorldDatabase

fun main() {
    val team = WorldDatabase.teams.first { it.id == 1 }
    val engine = AITeamDevelopmentEngine(20261005)
    val season1 = engine.simulate(team, 56, 2026)
    val season2 = engine.simulate(team, 0, 2027)
    val development = CarDevelopmentEngine()
    val reused = development.carryAiCarToNextSeason(season1, 2027, 0L)
    check(reused.engine == season1.engine && reused.chassis == season1.chassis &&
        reused.frontWing == season1.frontWing && reused.rearWing == season1.rearWing &&
        reused.brakes == season1.brakes && reused.electricPowerUnit == season1.electricPowerUnit) {
        "Sem investimento, a construção não deve adicionar bônus aos componentes legados"
    }
    check(season2.frontWing != team.frontWing || season2.engine != team.engine || season2.chassis != team.chassis) {
        "Carro AI voltou ao carro-base em vez de carregar a temporada anterior"
    }
    println("AI_CAR_CONTINUITY_OK")
}
