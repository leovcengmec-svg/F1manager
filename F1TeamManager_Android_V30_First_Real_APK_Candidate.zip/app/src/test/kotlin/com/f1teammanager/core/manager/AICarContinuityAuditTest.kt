package com.f1teammanager.core.manager

import com.f1teammanager.core.season.WorldDatabase

fun main() {
    val team = WorldDatabase.teams.first { it.id == 1 }
    val engine = AITeamDevelopmentEngine(20261005)
    val season1 = engine.simulate(team, 56, 2026)
    val season2 = engine.simulate(team, 0, 2027)
    val expected = CarDevelopmentEngine().carryAiCarToNextSeason(season1, 2027)
    check(season2 == expected) { "Carro AI não preserva a cadeia anual de construção" }
    check(season2.frontWing != team.frontWing || season2.engine != team.engine || season2.chassis != team.chassis) {
        "Carro AI voltou ao carro-base em vez de carregar a temporada anterior"
    }
    println("AI_CAR_CONTINUITY_OK")
}
