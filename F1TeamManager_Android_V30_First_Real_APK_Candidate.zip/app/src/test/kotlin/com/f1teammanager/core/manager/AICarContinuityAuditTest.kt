package com.f1teammanager.core.manager

import com.f1teammanager.core.season.WorldDatabase

fun main() {
    val team = WorldDatabase.teams.first { it.id == 1 }
    val engine = AITeamDevelopmentEngine(20261005)
    val season1 = engine.simulate(team, 56, 2026)
    val season2 = engine.simulate(team, 0, 2027)
    val development = CarDevelopmentEngine()
    val currentOverall = development.carOverall(season1)
    val targetInvestment = development.investmentReferenceForNextSeasonTarget(
        currentOverall, NextSeasonCarGrowthPolicy.maximumGain(currentOverall)
    )
    val fullyFunded = development.buildAiNextSeasonLegacyCar(season1, targetInvestment)
    val reused = development.carryAiCarToNextSeason(season1, 2027, 0L)
    val expectedLoss = development.aiUnderinvestmentPenaltyPoints(currentOverall, 0L)
    fun expected(value: Int) = if (value <= 0) 0 else (value - expectedLoss).coerceAtLeast(40)
    check(reused.engine == expected(fullyFunded.engine) && reused.chassis == expected(fullyFunded.chassis) &&
        reused.frontWing == expected(fullyFunded.frontWing) && reused.rearWing == expected(fullyFunded.rearWing) &&
        reused.brakes == expected(fullyFunded.brakes) && reused.electricPowerUnit == expected(fullyFunded.electricPowerUnit)) {
        "A IA deve perder até 10 pontos por componente conforme o déficit de investimento"
    }
    check(season2.frontWing != team.frontWing || season2.engine != team.engine || season2.chassis != team.chassis) {
        "Carro AI voltou ao carro-base em vez de carregar a temporada anterior"
    }
    println("AI_CAR_CONTINUITY_OK")
}
