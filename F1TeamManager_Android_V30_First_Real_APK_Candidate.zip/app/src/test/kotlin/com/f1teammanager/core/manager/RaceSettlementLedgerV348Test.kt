package com.f1teammanager.core.manager

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class RaceSettlementLedgerV348Test {
    @Test fun raceSettlementIsIdempotentEvenAfterDisplayHistoryRollsOver() {
        val initial = TeamManagerState(
            season = 2027, round = 1, playerTeamId = 7,
            car = TeamCarState(aerodynamics = 60, chassis = 60, engine = 60, reliability = 60),
            finance = TeamFinanceState(budget = 100_000_000L, transactions = (1..120).map { "-1:old transaction $it" })
        )
        val engine = FinanceEngine()
        val first = engine.applyRace(initial, finishPosition = 1, teamPoints = 100, isDnf = false, season = 2027, round = 1)
        assertTrue("GP_SETTLEMENT:2027:1" in first.finance.raceSettlementKeys)
        assertTrue(first.finance.transactions.size <= 100)
        val repeated = engine.applyRace(first, finishPosition = 1, teamPoints = 100, isDnf = false, season = 2027, round = 1)
        assertEquals(first.finance.budget, repeated.finance.budget)
        assertEquals(first.finance.seasonIncome, repeated.finance.seasonIncome)
        assertEquals(first.finance.seasonExpenses, repeated.finance.seasonExpenses)
        assertEquals(first.finance.raceSettlementKeys, repeated.finance.raceSettlementKeys)
    }

    @Test fun settlementLedgerAllowsDifferentSeasonAndRoundKeys() {
        val base = TeamManagerState(
            season = 2027, round = 1, playerTeamId = 7,
            car = TeamCarState(aerodynamics = 60, chassis = 60, engine = 60, reliability = 60),
            finance = TeamFinanceState(budget = 100_000_000L)
        )
        val engine = FinanceEngine()
        val gp1 = engine.applyRace(base, 1, 10, false, 2027, 1)
        val gp2 = engine.applyRace(gp1, 1, 10, false, 2027, 2)
        assertEquals(setOf("GP_SETTLEMENT:2027:1", "GP_SETTLEMENT:2027:2"), gp2.finance.raceSettlementKeys)
    }
}
