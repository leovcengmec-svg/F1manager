package com.f1teammanager.core.season

import kotlin.random.Random
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class DriverCareerCycleV696Test {
    private fun driver(id: Int = 9601, profile: String = "Auge tardio") = DriverDefinition(
        id = id, name = "Cycle probe $id", teamId = 1,
        speed = 80, qualifying = 81, overtaking = 82, defense = 83,
        consistency = 84, wet = 85, tyre = 86,
        driverClass = "Pro", evolution = profile, potentialOverall = 96
    )

    @Test
    fun `age reaches end of cycle then restarts at 18 without retirement`() {
        val d = driver()
        val start = DriverEvolutionEngine.careerStartAge(d)
        val seasonsToReset = 44 - start
        assertEquals(43, DriverEvolutionEngine.careerAge(d, 2026 + seasonsToReset - 1))
        assertEquals(18, DriverEvolutionEngine.careerAge(d, 2026 + seasonsToReset))
        assertEquals(1, DriverEvolutionEngine.careerCycleIndex(d, 2026 + seasonsToReset))
        assertEquals(19, DriverEvolutionEngine.careerAge(d, 2027 + seasonsToReset))
        assertEquals(d.evolution, "Auge tardio")
    }

    @Test
    fun `cycle restart recovers half of age-related physical loss only`() {
        val d = driver()
        val losses = intArrayOf(4, 7, 6, 2, 8, 5, 9)
        val peaks = intArrayOf(90, 92, 95, 94, 96, 95, 96)
        val tick = DriverEvolutionEngine.applyPerformanceTick(
            driver = d,
            performanceIndex = 85.0,
            currentBank = 0.0,
            annualGains = IntArray(7),
            random = Random(696),
            careerAge = 18,
            currentAgeBank = 0.80,
            currentAgePhysicalLosses = losses,
            currentAgePhysicalPeaks = peaks,
            currentAgeCycleIndex = 0,
            careerCycleIndex = 1
        )
        assertTrue(tick.ageCycleRestarted)
        assertEquals(6, tick.ageRecoveredPoints)
        assertArrayEquals(intArrayOf(82, 81, 85, 84, 84, 85, 86), intArrayOf(tick.driver.speed, tick.driver.qualifying, tick.driver.overtaking, tick.driver.defense, tick.driver.consistency, tick.driver.wet, tick.driver.tyre))
        assertArrayEquals(intArrayOf(2, 7, 3, 1, 8, 5, 9), tick.agePhysicalLosses)
        assertEquals("Auge tardio", tick.driver.evolution)
        assertEquals("Pro", tick.driver.driverClass)
        assertEquals(0.0, tick.ageBank, 0.0)
    }


    @Test
    fun `odd physical losses are rounded once as an aggregate`() {
        val d = driver(id = 9604).copy(
            speed = 80, qualifying = 81, overtaking = 82, defense = 83,
            consistency = 84, wet = 85, tyre = 86
        )
        val before = intArrayOf(d.speed, d.overtaking, d.defense).sum()
        val tick = DriverEvolutionEngine.applyPerformanceTick(
            driver = d,
            performanceIndex = 85.0,
            currentBank = 0.0,
            annualGains = IntArray(7),
            random = Random(6963),
            careerAge = 18,
            currentAgeBank = 0.0,
            currentAgePhysicalLosses = intArrayOf(1, 0, 1, 1, 0, 0, 0),
            currentAgePhysicalPeaks = intArrayOf(90, 81, 92, 93, 84, 85, 86),
            currentAgeCycleIndex = 0,
            careerCycleIndex = 1
        )

        val after = intArrayOf(tick.driver.speed, tick.driver.overtaking, tick.driver.defense).sum()
        assertEquals(2, tick.ageRecoveredPoints)
        assertEquals(2, after - before)
        assertEquals(1, tick.agePhysicalLosses.sum())
        assertEquals(d.qualifying, tick.driver.qualifying)
        assertEquals(d.consistency, tick.driver.consistency)
        assertEquals(d.wet, tick.driver.wet)
        assertEquals(d.tyre, tick.driver.tyre)
    }

    @Test
    fun `aggregate recovery never exceeds historical peak capacity`() {
        val d = driver(id = 9605).copy(
            speed = 80, qualifying = 81, overtaking = 82, defense = 83,
            consistency = 84, wet = 85, tyre = 86
        )
        val peaks = intArrayOf(81, 81, 82, 84, 84, 85, 86)
        val tick = DriverEvolutionEngine.applyPerformanceTick(
            driver = d,
            performanceIndex = 85.0,
            currentBank = 0.0,
            annualGains = IntArray(7),
            random = Random(6964),
            careerAge = 18,
            currentAgeBank = 0.0,
            currentAgePhysicalLosses = intArrayOf(3, 0, 3, 3, 0, 0, 0),
            currentAgePhysicalPeaks = peaks,
            currentAgeCycleIndex = 0,
            careerCycleIndex = 1
        )

        assertEquals(2, tick.ageRecoveredPoints)
        assertTrue(tick.driver.speed <= peaks[0])
        assertTrue(tick.driver.overtaking <= peaks[2])
        assertTrue(tick.driver.defense <= peaks[3])
    }

    @Test
    fun `age pressure only reduces physical attributes`() {
        val d = driver(id = 9602).copy(
            speed = 80, qualifying = 81, overtaking = 82, defense = 83,
            consistency = 84, wet = 85, tyre = 86
        )
        val tick = DriverEvolutionEngine.applyPerformanceTick(
            driver = d,
            performanceIndex = 105.0,
            currentBank = 0.0,
            annualGains = IntArray(7),
            random = Random(6961),
            careerAge = 43,
            currentAgeBank = 0.95,
            currentAgePhysicalLosses = IntArray(7),
            currentAgePhysicalPeaks = intArrayOf(d.speed, d.qualifying, d.overtaking, d.defense, d.consistency, d.wet, d.tyre),
            currentAgeCycleIndex = 0,
            careerCycleIndex = 0
        )
        val after = intArrayOf(tick.driver.speed, tick.driver.qualifying, tick.driver.overtaking, tick.driver.defense, tick.driver.consistency, tick.driver.wet, tick.driver.tyre)
        assertTrue(after[0] <= d.speed)
        assertTrue(after[2] <= d.overtaking)
        assertTrue(after[3] <= d.defense)
        assertEquals(d.qualifying, after[1])
        assertEquals(d.consistency, after[4])
        assertEquals(d.wet, after[5])
        assertEquals(d.tyre, after[6])
    }

    @Test
    fun `free-agent growth equals contracted natural baseline`() {
        assertEquals(1.0, DriverEvolutionEngine.FREE_DRIVER_GROWTH_RATE, 0.0)
        val d = driver(id = 9603).copy(speed = 70, qualifying = 70, overtaking = 70, defense = 70,
            consistency = 70, wet = 70, tyre = 70)
        val contracted = DriverEvolutionEngine.applyPerformanceTick(
            d, 105.0, 0.0, IntArray(7), Random(6962), facilityGrowthEfficiency = 1.0, careerAge = 24
        )
        val free = DriverEvolutionEngine.applyFreeDriverTick(
            d, 0.0, IntArray(7), Random(6962), careerAge = 24
        )
        assertEquals(contracted.bank, free.bank, 0.0)
    }
}
