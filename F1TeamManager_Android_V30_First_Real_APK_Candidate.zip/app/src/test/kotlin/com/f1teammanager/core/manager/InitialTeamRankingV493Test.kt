package com.f1teammanager.core.manager

import com.f1teammanager.core.season.WorldDatabase

/** Regression: hard mode must offer exactly positions 38–40 of the immutable opening-car ranking. */
object InitialTeamRankingV493Test {
    @JvmStatic
    fun main(args: Array<String>) {
        InitialTeamProfile.configureCareerSeed(20261013)
        val teams = WorldDatabase.teams
        val ranked = teams.sortedWith(
            compareByDescending<com.f1teammanager.core.season.TeamDefinition> {
                TeamGarageFactory.fromInitial(it).teamAverageOverall
            }.thenBy { it.id }
        )
        val expectedIds = ranked.takeLast(3).map { it.id }.toSet()
        val hardModeIds = InitialTeamProfile.weakestInitialTeams(teams, 3).map { it.id }.toSet()
        check(hardModeIds == expectedIds) {
            "Modo difícil $hardModeIds diverge das últimas três posições do ranking $expectedIds"
        }
        check(InitialTeamProfile.weakestInitialTeams(teams, 3).size == 3)
        check(InitialTeamProfile.weakestInitialTeams(teams, 0).isEmpty())

        // A calendar rollover must not reconfigure the opening-car seed. The
        // persisted opening profile is reused to produce exactly the same trio.
        val firstOpeningTrio = InitialTeamProfile.weakestInitialTeams(teams, 3).map { it.id }
        val reopenedOpeningTrio = InitialTeamProfile.weakestInitialTeams(teams, 3).map { it.id }
        check(firstOpeningTrio == reopenedOpeningTrio) {
            "O trio do Modo Difícil mudou sem uma nova carreira: $firstOpeningTrio vs $reopenedOpeningTrio"
        }
    }
}
