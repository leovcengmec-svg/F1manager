package com.f1teammanager.core.manager

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class InvestmentPriorityTableV606Test {
    @Test fun nextCarPriorityRisesAcrossSeasonWithoutTurningIntoProjectCap() {
        assertEquals(10, SeasonInvestmentPolicy.nextCarPriorityPercent(1))
        assertEquals(10, SeasonInvestmentPolicy.nextCarPriorityPercent(8))
        assertEquals(15, SeasonInvestmentPolicy.nextCarPriorityPercent(9))
        assertEquals(15, SeasonInvestmentPolicy.nextCarPriorityPercent(15))
        assertEquals(25, SeasonInvestmentPolicy.nextCarPriorityPercent(16))
        assertEquals(25, SeasonInvestmentPolicy.nextCarPriorityPercent(22))
        assertEquals(35, SeasonInvestmentPolicy.nextCarPriorityPercent(23))
        assertEquals(35, SeasonInvestmentPolicy.nextCarPriorityPercent(30))
        assertEquals(150_000_000L, SeasonInvestmentPolicy.maximumCumulativeInvestment(32_500_000L, 1, 150_000_000L))
        assertEquals(150_000_000L, SeasonInvestmentPolicy.maximumCumulativeInvestment(100_000_000L, 30, 150_000_000L))
    }

    @Test fun currentSeasonKeepsTechnicalBudgetWhileNextCarShareIsReserved() {
        val cash = 100_000_000L
        assertEquals(10_000_000L, SeasonInvestmentPolicy.aiNextCarReserve(cash, 1))
        assertEquals(35_000_000L, SeasonInvestmentPolicy.aiNextCarReserve(cash, 30))
        assertEquals(80_000_000L, SeasonInvestmentPolicy.aiDevelopmentSpendableCash(cash, 1))
        assertEquals(65_000_000L, SeasonInvestmentPolicy.aiDevelopmentSpendableCash(cash, 30))
        assertTrue(SeasonInvestmentPolicy.aiDevelopmentSpendableCash(cash, 30) > 0L)
    }

    @Test fun nextCarShareNeverOverridesOperatingReserve() {
        val cash = 10_000_000L
        val operating = maxOf(
            SeasonInvestmentPolicy.protectedCash(cash),
            SeasonInvestmentPolicy.aiOperatingReserve(30_000_000L, 29)
        )
        val nextCarShare = SeasonInvestmentPolicy.aiNextCarReserve(cash, 29)
        val available = minOf((cash - operating).coerceAtLeast(0L), nextCarShare)
        assertEquals(3_850_000L, operating)
        assertEquals(3_500_000L, nextCarShare)
        assertEquals(3_500_000L, available)
        assertTrue(cash - available >= operating)
    }
}
