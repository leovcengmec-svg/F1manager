package com.f1teammanager.core.manager

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class InvestmentPriorityTableV606Test {
    @Test fun standardMindsetUsesFiftyFiftyWithSixtyFortyInnerSplit() {
        for (round in listOf(1, 8, 9, 15, 16, 22, 23, 30)) {
            assertEquals(50, SeasonInvestmentPolicy.nextCarPriorityPercent(round))
        }
        assertEquals(60, SeasonInvestmentPolicy.AI_CURRENT_SEASON_CAR_PERCENT)
        assertEquals(40, SeasonInvestmentPolicy.AI_FACILITIES_PERCENT)
        assertEquals(150_000_000L, SeasonInvestmentPolicy.aiNextSeasonCarAnnualLimit(200_000_000L))
        assertEquals(120_000_000L, SeasonInvestmentPolicy.aiCurrentCarAnnualLimit(200_000_000L))
        assertEquals(80_000_000L, SeasonInvestmentPolicy.aiFacilitiesAnnualLimit(200_000_000L))
        assertEquals(150_000_000L, SeasonInvestmentPolicy.maximumCumulativeInvestment(32_500_000L, 1, 150_000_000L))
        // These values are planning references, not independent category ceilings.
    }

    @Test fun currentSeasonKeepsFiftyPercentForNextCarAndProtectsOperations() {
        val cash = 100_000_000L
        assertEquals(50_000_000L, SeasonInvestmentPolicy.aiNextCarReserve(cash, 1))
        assertEquals(50_000_000L, SeasonInvestmentPolicy.aiNextCarReserve(cash, 30))
        assertEquals(50_000_000L, SeasonInvestmentPolicy.aiDevelopmentSpendableCash(cash, 1))
        assertEquals(50_000_000L, SeasonInvestmentPolicy.aiDevelopmentSpendableCash(cash, 30))
        assertTrue(SeasonInvestmentPolicy.aiDevelopmentSpendableCash(cash, 30) > 0L)
    }

    @Test fun nextCarSpendingUsesAnIndependentOneHundredFiftyMillionEnvelope() {
        assertEquals(200_000_000L, SeasonInvestmentPolicy.remainingAnnualTechnicalEnvelope(
            200_000_000L, 0L, 0L
        ))
        assertEquals(120_000_000L, SeasonInvestmentPolicy.remainingAnnualTechnicalEnvelope(
            200_000_000L, 80_000_000L, 40_000_000L
        ))
        assertEquals(80_000_000L, SeasonInvestmentPolicy.remainingAnnualTechnicalEnvelope(
            200_000_000L, 120_000_000L, 80_000_000L
        ))
    }

    @Test fun nextCarShareNeverOverridesOperatingReserve() {
        val cash = 10_000_000L
        val operating = maxOf(
            SeasonInvestmentPolicy.protectedCash(cash),
            SeasonInvestmentPolicy.aiOperatingReserve(30_000_000L, 29)
        )
        val nextCarShare = SeasonInvestmentPolicy.aiNextCarReserve(cash, 29)
        val available = minOf((cash - operating).coerceAtLeast(0L), nextCarShare)
        assertEquals(3_850_000L, operating)
        assertEquals(5_000_000L, nextCarShare)
        assertEquals(5_000_000L, available)
        assertTrue(cash - available >= operating)
    }
}
