package com.f1teammanager.core.manager

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class DecennialCycleBalanceV637Test {
    private fun uniformGarage(value: Int): TeamGarage {
        fun car(id: GarageCarId) = PhysicalCar(
            id = id,
            engine = value,
            chassis = value,
            frontWing = value,
            rearWing = value,
            brakes = value,
            electricPowerUnit = value,
            reliability = 75,
            componentReliabilities = CarComponent.values().associateWith { 75 },
            installedPieces = CarComponent.values().associateWith { "${id.name}-${it.name}-V0" },
            installedPieceVersions = CarComponent.values().associateWith { 0 }
        )
        return TeamGarage(car(GarageCarId.CAR_1), car(GarageCarId.CAR_2))
    }

    @Test fun decennialReductionMapsDevelopedCarsBackIntoTheFortyToSixtyBand() {
        val seed = 20261005
        val revolutionSeason = AnnualCarRegulationEngine.nextDecennialSeasonAfter(1, seed)
        val rule = AnnualCarRegulationEngine.generate(revolutionSeason, seed)
        (80..100).forEach { startingOverall ->
            (1..40).forEach { teamSeed ->
                val regulated = AnnualCarRegulationEngine.applyToGarage(
                    uniformGarage(startingOverall), rule, teamSeed
                )
                assertTrue(
                    "starting=$startingOverall team=$teamSeed resulted=${regulated.teamAverageOverall}",
                    regulated.teamAverageOverall in 40..60
                )
            }
        }
    }

    @Test fun decennialReductionProfileHasFortyPercentAverageAcrossSixComponents() {
        val seed = 20261005
        val revolutionSeason = AnnualCarRegulationEngine.nextDecennialSeasonAfter(1, seed)
        val rule = AnnualCarRegulationEngine.generate(revolutionSeason, seed)
        val reductions = rule.decennialReductions
        assertEquals(40, reductions[CarComponent.ENGINE])
        assertEquals(35, reductions[CarComponent.CHASSIS])
        assertEquals(45, reductions[CarComponent.FRONT_WING])
        assertEquals(45, reductions[CarComponent.REAR_WING])
        assertEquals(35, reductions[CarComponent.BRAKES])
        assertEquals(40, reductions[CarComponent.ELECTRIC_POWER_UNIT])
        assertEquals(240, reductions.values.sum())
    }

    @Test fun fundedAiConstructionAmbitionBuildsTowardTheHighBandThenTapers() {
        assertEquals(7, NextSeasonCarGrowthPolicy.maximumGain(40))
        assertEquals(7, NextSeasonCarGrowthPolicy.maximumGain(69))
        assertEquals(5, NextSeasonCarGrowthPolicy.maximumGain(70))
        assertEquals(5, NextSeasonCarGrowthPolicy.maximumGain(89))
        assertEquals(2, NextSeasonCarGrowthPolicy.maximumGain(90))
        assertEquals(2, NextSeasonCarGrowthPolicy.maximumGain(96))
        assertEquals(1, NextSeasonCarGrowthPolicy.maximumGain(97))
        assertEquals(1, NextSeasonCarGrowthPolicy.maximumGain(100))
    }
}
