package com.f1teammanager.core.manager

fun main() {
    val engine = CarDevelopmentEngine()
    val base = TeamCarState(
        aerodynamics = 95, chassis = 90, engine = 85, reliability = 80,
        frontWing = 95, rearWing = 90, brakes = 85, electricPowerUnit = 80
    )
    val state = TeamManagerState(car = base, finance = TeamFinanceState(100_000_000L))
    val next = engine.startNextSeason(state, 2026).car

    // V575: no 70% regression. Each component receives +10% of its own prior value,
    // rounded individually, before the next-season regulation is applied.
    check(next.engine == 94) { "engine=${next.engine}" } // 85 + round(8.5) = 94
    check(next.chassis == 99) { "chassis=${next.chassis}" } // 90 + 9 = 99
    check(next.frontWing == 100) { "frontWing=${next.frontWing}" } // 95 + 10 + regulation, capped at 100
    check(next.rearWing == 100) { "rearWing=${next.rearWing}" } // 90 + 9 + aero regulation
    check(next.reliability == 80) { "reliability=${next.reliability}" }

    val debtState = state.copy(finance = TeamFinanceState(-1_000_000L))
    val constructed = engine.startNextSeason(debtState, 2026)
    val penalized = FinancialSeasonClosureEngine.applyPlayerPenalty(constructed)
    check(penalized.car.engine == (constructed.car.engine * 80 / 100).coerceAtLeast(1))
    check(penalized.car.chassis == (constructed.car.chassis * 80 / 100).coerceAtLeast(1))

    println("CarConstructionNoGenericAnnualRegressionV548Test: PASS")
}
