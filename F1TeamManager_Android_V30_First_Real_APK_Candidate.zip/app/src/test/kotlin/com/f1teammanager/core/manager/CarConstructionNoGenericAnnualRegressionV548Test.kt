package com.f1teammanager.core.manager

fun main() {
    val engine = CarDevelopmentEngine()
    val base = TeamCarState(
        aerodynamics = 95, chassis = 90, engine = 85, reliability = 80,
        frontWing = 95, rearWing = 90, brakes = 85, electricPowerUnit = 80
    )
    val state = TeamManagerState(car = base, finance = TeamFinanceState(100_000_000L))
    val next = engine.startNextSeason(state, 2026).car

    // V635: with no reserve, reuse the previous car without any construction bonus.
    check(next.engine == 85) { "engine=${next.engine}" }
    check(next.chassis == 90) { "chassis=${next.chassis}" }
    check(next.frontWing == 95) { "frontWing=${next.frontWing}" }
    check(next.rearWing == 90) { "rearWing=${next.rearWing}" }
    check(next.reliability == 80) { "reliability=${next.reliability}" }

    val debtState = state.copy(finance = TeamFinanceState(-1_000_000L))
    val constructed = engine.startNextSeason(debtState, 2026)
    val penalized = FinancialSeasonClosureEngine.applyPlayerPenalty(constructed)
    check(penalized.car.engine == (constructed.car.engine * 80 / 100).coerceAtLeast(1))
    check(penalized.car.chassis == (constructed.car.chassis * 80 / 100).coerceAtLeast(1))

    println("CarConstructionNoGenericAnnualRegressionV548Test: PASS")
}
