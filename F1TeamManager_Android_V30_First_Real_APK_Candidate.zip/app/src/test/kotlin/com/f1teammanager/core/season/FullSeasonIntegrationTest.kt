package com.f1teammanager.core.season

import com.f1teammanager.core.manager.*

/** End-to-end manager-season smoke: 30 GPs, 80 active drivers, 20 free drivers,
 * evolution for all 100 drivers, market opening after GP 8 and persistent news. */
fun main() {
    val market = DriverMarketEngine(20261003).initialState(2026)
    val team = WorldDatabase.teams.first()
    val car = TeamCarState(team.baseCar, team.chassis, team.engine, team.reliability,
        frontWing = team.frontWing, rearWing = team.rearWing, brakes = team.brakes,
        electricPowerUnit = team.electricPowerUnit)
    var manager = TeamManagerState(
        season = 2026,
        playerTeamId = team.id,
        car = car,
        finance = TeamFinanceState(35_000_000),
        driverMarket = market
    )
    var season = SeasonState()
    val engine = ManagerSeasonEngine(20261003)

    check(WorldDatabase.rounds.size == 30)
    check(WorldDatabase.teams.size == 40)
    check(WorldDatabase.allDrivers.size == 100)

    var scheduledBefore8 = 0
    for (gp in 1..30) {
        val outcome = engine.runRound(manager, season)
        manager = outcome.state
        season = outcome.season
        if (gp == 8) scheduledBefore8 = manager.driverMarket.scheduled.size
    }

    check(scheduledBefore8 == 0) { "Market moved before GP 8: $scheduledBefore8" }
    check(season.currentRound == 31)
    check(manager.round == 31)
    check(season.standings.size == 80)
    check(manager.driverEvolutionAttributes.size == 100)
    check(manager.driverEvolutionAnnualGains.size == 100)
    check(manager.driverEvolutionBanks.size == 100)

    val active = manager.driverMarket.contracts.count { it.activeIn(2026) }
    val free = manager.driverMarket.freeAgents.size
    check(active == 80) { "Expected 80 active drivers, got $active" }
    check(free == 20) { "Expected 20 free drivers, got $free" }
    check(manager.driverMarket.scheduled.isNotEmpty()) { "No future market movement after GP 8" }
    check(manager.driverMarket.notifications.any { it.category == MarketNewsCategory.MARKET })

    val gains = manager.driverEvolutionAnnualGains.values.map { it.sum() }
    check(gains.size == 100)
    check(gains.all { it >= 0 })

    println("FullSeasonIntegrationTest: PASS")
    println("30 GPs | 80 active | 20 free | 100 evolved | scheduled=${manager.driverMarket.scheduled.size} | notifications=${manager.driverMarket.notifications.size}")
}
