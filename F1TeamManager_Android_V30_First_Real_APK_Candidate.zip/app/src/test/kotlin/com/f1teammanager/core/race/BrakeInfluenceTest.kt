package com.f1teammanager.core.race

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

class BrakeInfluenceTest {
    @Test fun levelsAndBrakeInfluencesMatchApprovedScale() {
        assertEquals(1, CarComponentInfluence.level(40))
        assertEquals(6, CarComponentInfluence.level(70))
        assertEquals(10, CarComponentInfluence.level(100))
        assertEquals(0.70, CarComponentInfluence.brakeErsRecovery(40))
        assertEquals(0.90, CarComponentInfluence.brakeErsRecovery(70))
        assertEquals(1.10, CarComponentInfluence.brakeErsRecovery(100))
        assertEquals(0.80, CarComponentInfluence.brakeDefenseEfficiency(40))
        assertEquals(0.95, CarComponentInfluence.brakeDefenseEfficiency(70))
        assertEquals(1.10, CarComponentInfluence.brakeDefenseEfficiency(100))
        assertEquals(0.80, CarComponentInfluence.brakeOvertakingEfficiency(40))
        assertEquals(0.95, CarComponentInfluence.brakeOvertakingEfficiency(70))
        assertEquals(1.10, CarComponentInfluence.brakeOvertakingEfficiency(100))
    }

    @Test fun brakeInfluencesAreMonotonic() {
        val values = listOf(40,46,52,58,64,70,76,82,88,100)
        assertTrue(values.zipWithNext().all { (a,b) -> CarComponentInfluence.brakeErsRecovery(a) < CarComponentInfluence.brakeErsRecovery(b) })
        assertTrue(values.zipWithNext().all { (a,b) -> CarComponentInfluence.brakeDefenseEfficiency(a) < CarComponentInfluence.brakeDefenseEfficiency(b) })
        assertTrue(values.zipWithNext().all { (a,b) -> CarComponentInfluence.brakeOvertakingEfficiency(a) < CarComponentInfluence.brakeOvertakingEfficiency(b) })
    }

    @Test fun participantCarriesPhysicalBrakeValue() {
        val p = RaceParticipant(driverId=1,driverName="A",teamId=1,teamName="T",driverSpeed=70,qualifying=70,overtaking=70,defense=70,consistency=70,enginePerformance=70,tyreGrip=50,tyreWear=50,reliability=95,chassisWear=0,wetSkill=50,chassisPerformance=50,frontWingPerformance=50,rearWingPerformance=50,brakesPerformance=88,electricPowerUnitPerformance=50)
        assertEquals(88, p.brakesPerformance)
    }
}
