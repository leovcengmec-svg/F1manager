package com.f1teammanager.core.manager

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SeasonInvestmentPolicyV693Test {
    @Test fun currentCarAndFacilitiesHaveIndependentTwoHundredMillionEnvelope() {
        assertEquals(200_000_000L, SeasonInvestmentPolicy.remainingAnnualTechnicalEnvelope(200_000_000L, 0L, 150_000_000L))
        assertEquals(50_000_000L, SeasonInvestmentPolicy.remainingAnnualTechnicalEnvelope(200_000_000L, 150_000_000L, 120_000_000L))
    }

    @Test fun nextCarHasIndependentOneHundredFiftyMillionAnnualCap() {
        assertEquals(150_000_000L, SeasonInvestmentPolicy.nextCarAnnualCap())
        assertEquals(0L, SeasonInvestmentPolicy.nextCarAnnualCap() - 150_000_000L)
    }

    @Test fun standardMindsetUsesFiftyFiftyAndSixtyFortyInnerSplit() {
        val m = AIInvestmentMindset.STANDARD
        assertEquals(50, m.currentAndFacilitiesPercent)
        assertEquals(60, m.currentCarPercentOfPool)
        assertEquals(40, m.facilitiesPercentOfPool)
        assertEquals(50, m.nextCarPercent)
    }

    @Test fun dominantMindsetPrioritizesNextCar() {
        val m = SeasonInvestmentPolicy.selectAiMindset(12, 2, 88, gapToSecondBest = 7, inTitleFight = true)
        assertEquals(AIInvestmentMindset.DOMINANT_CAR, m)
        assertEquals(70, m.nextCarPercent)
    }

    @Test fun titleFightOverridesLateSeasonRebuild() {
        val m = SeasonInvestmentPolicy.selectAiMindset(24, 5, 72, gapToSecondBest = 1, inTitleFight = true)
        assertEquals(AIInvestmentMindset.TITLE_FIGHT, m)
        assertEquals(40, m.nextCarPercent)
    }

    @Test fun lowerGridTeamsPivotAfterGp20() {
        val m = SeasonInvestmentPolicy.selectAiMindset(21, 27, 48, gapToSecondBest = 0, inTitleFight = false)
        assertEquals(AIInvestmentMindset.NEXT_SEASON_REBUILD, m)
        assertEquals(60, m.nextCarPercent)
    }

    @Test fun fourMindsetsAllocateCashUsingTheRequestedStrategicShares() {
        val cash = 100_000_000L
        assertEquals(50_000_000L, SeasonInvestmentPolicy.aiNextCarReserve(cash, priorityPercent = AIInvestmentMindset.STANDARD.nextCarPercent))
        assertEquals(70_000_000L, SeasonInvestmentPolicy.aiNextCarReserve(cash, priorityPercent = AIInvestmentMindset.DOMINANT_CAR.nextCarPercent))
        assertEquals(40_000_000L, SeasonInvestmentPolicy.aiNextCarReserve(cash, priorityPercent = AIInvestmentMindset.TITLE_FIGHT.nextCarPercent))
        assertEquals(60_000_000L, SeasonInvestmentPolicy.aiNextCarReserve(cash, priorityPercent = AIInvestmentMindset.NEXT_SEASON_REBUILD.nextCarPercent))
    }

    @Test fun lowerGridRebuildStartsAfterGp20HasFinished() {
        assertEquals(AIInvestmentMindset.STANDARD, SeasonInvestmentPolicy.selectAiMindset(20, 27, 48))
        assertEquals(AIInvestmentMindset.NEXT_SEASON_REBUILD, SeasonInvestmentPolicy.selectAiMindset(21, 27, 48))
    }

    @Test fun nextCarCashPriorityIsReleasedAtTheIndependentAnnualCap() {
        assertEquals(50, SeasonInvestmentPolicy.effectiveNextCarPriorityPercent(AIInvestmentMindset.STANDARD, 149_000_000L))
        assertEquals(70, SeasonInvestmentPolicy.effectiveNextCarPriorityPercent(AIInvestmentMindset.DOMINANT_CAR, 149_000_000L))
        assertEquals(0, SeasonInvestmentPolicy.effectiveNextCarPriorityPercent(AIInvestmentMindset.STANDARD, 150_000_000L))
        assertEquals(0, SeasonInvestmentPolicy.effectiveNextCarPriorityPercent(AIInvestmentMindset.DOMINANT_CAR, 155_000_000L))
    }


    @Test fun solventWeakTeamsEnterRebuildBeforeGp21() {
        assertEquals(
            AIInvestmentMindset.NEXT_SEASON_REBUILD,
            SeasonInvestmentPolicy.selectAiMindset(
                round = 8, ranking = 29, currentOverall = 58,
                availableInvestmentCash = 70_000_000L
            )
        )
        assertEquals(
            AIInvestmentMindset.STANDARD,
            SeasonInvestmentPolicy.selectAiMindset(
                round = 8, ranking = 29, currentOverall = 58,
                availableInvestmentCash = 12_000_000L
            )
        )
    }

    @Test fun constructionPaceCanExceedPriorityShareOnlyWhenFreeCashSupportsIt() {
        assertEquals(
            50_000_000L,
            SeasonInvestmentPolicy.nextCarInvestmentSpendableCash(
                cash = 100_000_000L, operatingProtected = 20_000_000L,
                forecastHeadroom = 100_000_000L, annualRoom = 100_000_000L,
                priorityPercent = 40, plannedContribution = 50_000_000L
            )
        )
        assertEquals(
            30_000_000L,
            SeasonInvestmentPolicy.nextCarInvestmentSpendableCash(
                cash = 100_000_000L, operatingProtected = 20_000_000L,
                forecastHeadroom = 30_000_000L, annualRoom = 100_000_000L,
                priorityPercent = 40, plannedContribution = 50_000_000L
            )
        )
        assertEquals(
            10_000_000L,
            SeasonInvestmentPolicy.nextCarInvestmentSpendableCash(
                cash = 30_000_000L, operatingProtected = 20_000_000L,
                forecastHeadroom = 100_000_000L, annualRoom = 100_000_000L,
                priorityPercent = 70, plannedContribution = 50_000_000L
            )
        )
    }

    @Test fun nextCarPriorityDoesNotConsumeTechnicalEnvelope() {
        val currentAndFacilities = SeasonInvestmentPolicy.remainingCurrentAndFacilityEnvelope(200_000_000L, 199_000_000L)
        val nextCarRoom = SeasonInvestmentPolicy.nextCarAnnualCap() - 17_000_000L
        assertEquals(1_000_000L, currentAndFacilities)
        assertEquals(133_000_000L, nextCarRoom)
        assertTrue(currentAndFacilities + nextCarRoom > 1_000_000L)
    }
}
