package com.f1teammanager.core.season

import com.f1teammanager.core.manager.*

/** Full two-season chain audit: race -> evolution -> P&D -> market -> finances -> season transition. */
fun main() {
    val market = DriverMarketEngine(20261003).initialState(2026)
    val team = WorldDatabase.teams.first()
    val car = TeamCarState(com.f1teammanager.core.manager.InitialTeamProfile.strength(team), team.chassis, team.engine, team.reliability,
        frontWing = team.frontWing, rearWing = team.rearWing, brakes = team.brakes,
        electricPowerUnit = team.electricPowerUnit)
    var manager = TeamManagerState(season=2026, round=1, playerTeamId=team.id,
        car=car, finance=TeamFinanceState(35_000_000), driverMarket=market)
    var season = SeasonState()
    val engine = ManagerSeasonEngine(20261003)

    repeat(60) { i ->
        val out = engine.runRound(manager, season)
        manager = out.state
        season = out.season
        if (i == 29) {
            check(manager.season == 2027) { "Season did not transition to 2027: ${manager.season}" }
            check(manager.round == 1) { "Round did not reset: ${manager.round}" }
            check(season.season == 2027 && season.currentRound == 1) { "SeasonState did not reset" }
        }
        if (i == 59) {
            check(manager.season == 2028) { "Second transition failed: ${manager.season}" }
            check(manager.round == 1) { "Second round reset failed: ${manager.round}" }
        }
        check(manager.driverMarket.contracts.count { it.activeIn(manager.season) } == 80) {
            "Grid contract count invalid after GP ${i+1}"
        }
    }
    check(manager.driverEvolutionAttributes.size == 100)
    check(manager.driverMarket.scheduled.none { it.startSeason <= manager.season })
    println("TwoSeasonChainAuditTest: PASS")
    println("60 GPs | season=${manager.season} | round=${manager.round} | active=80 | drivers=${manager.driverEvolutionAttributes.size}")
}
