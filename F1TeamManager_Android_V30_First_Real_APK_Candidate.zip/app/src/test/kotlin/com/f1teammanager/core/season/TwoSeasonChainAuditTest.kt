package com.f1teammanager.core.season

import com.f1teammanager.core.manager.*
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * V370: end-to-end season-chain audit. Each simulated GP validates the actual race
 * result, qualifying phases, standings progression and driver-evolution idempotency
 * before checking the two season transitions.
 */
class TwoSeasonChainAuditTest {
    @Test
    fun runsSixtyRoundsAndTransitionsAcrossTwoCompleteSeasons() {
        val market = DriverMarketEngine(20261003).initialState(2026)
        val team = WorldDatabase.teams.first()
        val car = TeamCarState(
            com.f1teammanager.core.manager.InitialTeamProfile.strength(team),
            team.chassis, team.engine, team.reliability,
            frontWing = team.frontWing, rearWing = team.rearWing, brakes = team.brakes,
            electricPowerUnit = team.electricPowerUnit
        )
        val sponsor = SponsorContract(
            name = "Patrocinador de auditoria", upfront = 0L, racePayment = 150_000L,
            pointsBonus = 2_000L, years = 2, minimumReputation = 0, slot = 1,
            qualifyingTarget = 1, qualifyingBonus = 50_000L, raceTarget = 20,
            raceTargetBonus = 25_000L, active = true, races = 30, racesRemaining = 30
        )
        var manager = TeamManagerState(
            season = 2026, round = 1, playerTeamId = team.id,
            car = car, finance = TeamFinanceState(35_000_000), driverMarket = market,
            sponsor = sponsor, sponsors = listOf(sponsor)
        )
        var season = SeasonState()
        val engine = ManagerSeasonEngine(20261003)

        var totalRacePoints = 0
        repeat(60) { index ->
            val raceSeason = season.season
            val raceRound = season.currentRound
            val roundDefinition = SeasonCalendar.forSeason(raceSeason)[raceRound - 1]
            val outcome = engine.runRound(manager, season)
            manager = outcome.state
            season = outcome.season

            val race = outcome.race
            com.f1teammanager.core.race.RaceResultValidator.requireValid(race, roundDefinition.laps)
            assertEquals("80 classified drivers at ${raceSeason} GP${raceRound}", 80, race.classification.size)
            assertEquals("unique drivers at ${raceSeason} GP${raceRound}", 80, race.classification.map { it.driverId }.toSet().size)
            assertEquals("all positions present at ${raceSeason} GP${raceRound}", (1..80).toList(), race.classification.map { it.position }.sorted())
            val qualifying = race.qualifying ?: throw AssertionError("Missing qualifying result at ${raceSeason} GP${raceRound}")
            assertEquals("80-car qualifying grid", 80, qualifying.grid.size)
            assertEquals("three qualifying phases", 3, qualifying.phases.size)
            assertEquals("Q1 field", 80, qualifying.phases[0].entries.size)
            assertEquals("Q2 field", 50, qualifying.phases[1].entries.size)
            assertEquals("Q3 field", 20, qualifying.phases[2].entries.size)
            assertTrue("race points must not be negative", race.points.values.all { it >= 0 })
            assertTrue("player budget must never be negative at ${raceSeason} GP${raceRound}", manager.finance.budget >= 0L)
            assertEquals("manager/season remain synchronized", manager.season, season.season)
            assertTrue("garage must exist after the first simulated round", manager.garage != null)
            assertTrue("two physical cars in the garage", manager.garage?.car1 != null && manager.garage?.car2 != null)
            if (raceSeason == 2026 && raceRound < 30) {
                assertEquals("sponsor countdown after GP $raceRound", 30 - raceRound, manager.sponsors.firstOrNull()?.racesRemaining)
            }
            if (raceSeason == 2026 && raceRound == 30) {
                assertTrue("first-season sponsor must expire after 30 races", manager.sponsors.none { it.active })
            }
            totalRacePoints += race.points.values.sum()
            assertTrue("driver evolution idempotency marker missing for ${raceSeason}:${raceRound}",
                "${raceSeason}:${raceRound}" in manager.driverEvolutionProcessedRounds)
            if (index % 30 != 29) {
                assertTrue("championship starts should accumulate before season transition", season.starts.isNotEmpty())
            }

            if (index == 29) {
                assertEquals("first season transition", 2027, manager.season)
                assertEquals("first round reset", 1, manager.round)
                assertEquals(2027, season.season)
                assertEquals(1, season.currentRound)
                assertTrue("alternate transition must record application of the annual regulation",
                    manager.history.any { it.contains("Regulamento 2027 aplicado após a construção") })
                val garage = manager.garage ?: throw AssertionError("garage missing after transition")
                assertTrue("Car 1 component versions reset to new-season V0", garage.car1.installedPieceVersions.values.all { it == 0 })
                assertTrue("Car 2 component versions reset to new-season V0", garage.car2.installedPieceVersions.values.all { it == 0 })
                assertEquals("Car 1 version keys match only installed hardware", garage.car1.installedPieces.keys, garage.car1.installedPieceVersions.keys)
                assertEquals("Car 2 version keys match only installed hardware", garage.car2.installedPieces.keys, garage.car2.installedPieceVersions.keys)
                assertTrue("legacy projection matches regulated physical engine average",
                    manager.car.engine == (garage.car1.engine + garage.car2.engine) / 2)
            }
            if (index == 59) {
                assertEquals("second season transition", 2028, manager.season)
                assertEquals("second round reset", 1, manager.round)
                assertEquals(2028, season.season)
                assertEquals(1, season.currentRound)
            }
            assertEquals("80 active driver contracts after GP ${index + 1}", 80,
                manager.driverMarket.contracts.count { it.activeIn(manager.season) })
        }

        assertEquals(100, manager.driverEvolutionAttributes.size)
        assertEquals(100, manager.driverEvolutionAnnualGains.size)
        assertEquals(100, manager.driverEvolutionBanks.size)
        assertEquals("one idempotency marker per simulated GP", 60, manager.driverEvolutionProcessedRounds.size)
        assertTrue("the two-season chain must award championship points", totalRacePoints > 0)
        assertTrue("all planned market moves for the current season should be resolved", manager.driverMarket.scheduled.none { it.startSeason <= manager.season })
        assertEquals("both championship prizes are settled once", setOf(2026, 2027), manager.finance.seasonPrizesPaid)
        assertEquals("one salary ledger entry per GP across both seasons", 60,
            (manager.finance.salaryPaidRounds + manager.finance.salaryOutstanding.keys).size)
        assertTrue("salary ledger keys must identify a season and GP",
            (manager.finance.salaryPaidRounds + manager.finance.salaryOutstanding.keys).all { it.matches(Regex("20\\d{2}:[1-9]\\d?")) })
        assertTrue("finance transactions must remain available", manager.finance.transactions.isNotEmpty())
    }
}
