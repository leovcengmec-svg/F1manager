package com.f1teammanager.core.manager

import com.f1teammanager.core.season.WorldDatabase
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class DriverMarketRealismV608Test {
    private val budgets = WorldDatabase.teams.associate { it.id to 100_000_000L }

    @Test fun `rollover fills AI seats only through accepted offers and preserves grid integrity`() {
        val engine = DriverMarketEngine(20261018)
        val initial = engine.initialState(2026)
        val next = engine.applySeasonTransition(initial, 2027, budgets)

        WorldDatabase.teams.forEach { team ->
            assertEquals("${team.name} must have two drivers after a solvent AI rollover", 2,
                engine.roster(next, team.id, season = 2027).size)
        }
        assertEquals(80, next.contracts.count { it.activeIn(2027) })
        assertEquals(next.contracts.size, next.contracts.map { it.driverId }.distinct().size)
        assertFalse(next.notifications.any { it.title.contains("ELENCO COMPLETADO NA VIRADA") })
        assertFalse(next.history.any { it.contains("Alocação emergencial", ignoreCase = true) })
        assertTrue(next.history.any { it.contains("assinou", ignoreCase = true) || it.contains("Contrato aceito", ignoreCase = true) })
    }

    @Test fun `season transition never auto fills a vacancy in the player team`() {
        val engine = DriverMarketEngine(20261019)
        val initial = engine.initialState(2026)
        val team = WorldDatabase.teams.first { engine.roster(initial, it.id, season = 2027).size < 2 }
        val expected = engine.roster(initial, team.id, season = 2027)

        val next = engine.applySeasonTransition(initial, 2027, budgets, playerTeamId = team.id)
        assertEquals(expected, engine.roster(next, team.id, season = 2027))
    }

    @Test fun `current championship results can outweigh starting team reputation`() {
        val engine = DriverMarketEngine(20261020)
        val frontRunnerAtStart = WorldDatabase.teams.maxBy { InitialTeamProfile.strength(it) }
        val backMarkerAtStart = WorldDatabase.teams.minBy { InitialTeamProfile.strength(it) }
        val points = WorldDatabase.teams.associate { team ->
            team.id to when (team.id) {
                backMarkerAtStart.id -> 500
                frontRunnerAtStart.id -> 0
                else -> 100
            }
        }

        assertTrue(
            engine.sportingStrengthForMarket(backMarkerAtStart.id, points) >
                engine.sportingStrengthForMarket(frontRunnerAtStart.id, points)
        )
    }

    @Test fun `title contender downgrade requires an exceptional salary to become attractive`() {
        val engine = DriverMarketEngine(20261021)
        val initial = engine.initialState(2026)
        val topDriver = WorldDatabase.allDrivers.maxBy {
            (it.speed + it.qualifying + it.overtaking + it.defense + it.consistency + it.wet + it.tyre) / 7
        }
        val lowTeam = WorldDatabase.teams.minBy { InitialTeamProfile.strength(it) }
        val driverPoints = WorldDatabase.allDrivers.associate { it.id to if (it.id == topDriver.id) 500 else 0 }
        val role = DriverTeamRole.PILOT_1
        val normal = engine.interestScore(initial, topDriver.id, lowTeam.id, engine.salaryFor(topDriver.id), role, 2026,
            driverChampionshipPoints = driverPoints)
        val absurd = engine.interestScore(initial, topDriver.id, lowTeam.id, engine.salaryFor(topDriver.id) * 12, role, 2026,
            driverChampionshipPoints = driverPoints)

        assertTrue("A normal offer should not erase a major sporting downgrade", normal < 78)
        assertTrue("An exceptional offer may still change the driver's decision", absurd >= 78)
    }

    @Test fun `AI does not routinely break multi-year deals to make ordinary transfers`() {
        val engine = DriverMarketEngine(20261006)
        val initial = engine.initialState(2026)
        val teamPoints = WorldDatabase.teams.associate { it.id to (it.id * 13) }
        val attributes = WorldDatabase.allDrivers.associate { d -> d.id to listOf(d.speed, d.qualifying, d.overtaking, d.defense, d.consistency, d.wet, d.tyre) }
        val driverPoints = WorldDatabase.allDrivers.associate { it.id to (it.id * 11) }
        var state = initial
        for (week in 9..56) {
            state = engine.processAiMarketWeek(state, 2026, week, playerTeamId = -999,
                teamChampionshipPoints = teamPoints, driverAttributes = attributes,
                driverChampionshipPoints = driverPoints)
        }
        val violations = state.scheduled.filter { it.signedSeason == 2026 && it.startSeason == 2027 }
            .mapNotNull { move ->
                val incumbent = initial.contracts.firstOrNull { it.driverId == move.replaceDriverId }
                val candidate = attributes[move.driverId]?.average() ?: 0.0
                val incumbentOverall = move.replaceDriverId?.let { attributes[it]?.average() } ?: 0.0
                if (incumbent != null && incumbent.activeIn(2027) && incumbent.years > 1 && candidate - incumbentOverall < 9)
                    "${move.driverId} substitui ${incumbent.driverId} sem melhoria clara"
                else null
            }
        assertTrue("Multi-year contracts should only be broken for major upgrades: ${violations.joinToString()}", violations.isEmpty())
    }

    @Test fun `rollover-only signing fee is recorded once and survives AI ledger restore`() {
        val team = WorldDatabase.teams.first()
        val fee = 2_400_000L
        val finance = AITeamFinancialEngine(20261023)
        val first = finance.applyRolloverSigningFee(team.id, 2027, 77, fee)
        assertEquals(1, first.finance.signatureFeeSchedules.count { it.season == 2027 && it.amount == fee })
        val duplicate = finance.applyRolloverSigningFee(team.id, 2027, 77, fee)
        assertEquals(first.finance.signatureFeeSchedules, duplicate.finance.signatureFeeSchedules)
        val restored = AITeamFinancialEngine(20261023)
        restored.restoreSnapshot(finance.exportSnapshot())
        val afterRestore = restored.applyRolloverSigningFee(team.id, 2027, 77, fee)
        assertEquals(first.finance.signatureFeeSchedules, afterRestore.finance.signatureFeeSchedules)
    }

    @Test fun `driver prefers a substantially stronger competing offer`() {
        val engine = DriverMarketEngine(20261022)
        val initial = engine.initialState(2026)
        val freeDriver = engine.freeAgents(initial).first()
        val strongTeam = WorldDatabase.teams.maxBy { InitialTeamProfile.strength(it) }
        val weakTeam = WorldDatabase.teams.minBy { InitialTeamProfile.strength(it) }
        val weakReplacement = engine.roster(initial, weakTeam.id, season = 2026).first()
        val strongReplacement = engine.roster(initial, strongTeam.id, season = 2026).first()

        var state = engine.makeOffer(initial, freeDriver, weakTeam.id, 1, engine.salaryFor(freeDriver),
            DriverTeamRole.PILOT_2, 2026, currentWeek = 30, replaceDriverId = weakReplacement, proposerTeamId = weakTeam.id).first
        state = engine.makeOffer(state, freeDriver, strongTeam.id, 2, engine.salaryFor(freeDriver) * 2,
            DriverTeamRole.PILOT_1, 2026, currentWeek = 30, replaceDriverId = strongReplacement, proposerTeamId = strongTeam.id).first
        state = state.copy(pending = state.pending.map { it.copy(expiresAfterWeek = 35) })
        val decided = engine.expireOffers(state, 35, 2026, playerTeamId = -999)

        assertTrue("The stronger competing offer should sign the driver", decided.scheduled.any {
            it.driverId == freeDriver && it.toTeamId == strongTeam.id && it.startSeason == 2027
        })
        assertFalse("The rejected offer should not create a second contract", decided.scheduled.any {
            it.driverId == freeDriver && it.toTeamId == weakTeam.id
        })
    }
}
