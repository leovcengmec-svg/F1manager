package com.f1teammanager.core.manager

import com.f1teammanager.core.season.DriverEvolutionEngine
import com.f1teammanager.core.season.WorldDatabase
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class DriverMarketAgeContractV736Test {
    private val market = DriverMarketEngine(736)

    private fun seasonAtAge(driverId: Int, age: Int): Int {
        val driver = WorldDatabase.allDrivers.first { it.id == driverId }
        return 2026 + (age - DriverEvolutionEngine.careerStartAge(driver))
    }

    @Test
    fun `career cycle completes age 45 and restarts at 16`() {
        val driver = WorldDatabase.allDrivers.first()
        val finalAge45Season = seasonAtAge(driver.id, 45)

        assertEquals(43, DriverEvolutionEngine.careerAge(driver, finalAge45Season - 2))
        assertEquals(44, DriverEvolutionEngine.careerAge(driver, finalAge45Season - 1))
        assertEquals(45, DriverEvolutionEngine.careerAge(driver, finalAge45Season))
        assertEquals(16, DriverEvolutionEngine.careerAge(driver, finalAge45Season + 1))
        assertEquals(
            DriverEvolutionEngine.careerCycleIndex(driver, finalAge45Season) + 1,
            DriverEvolutionEngine.careerCycleIndex(driver, finalAge45Season + 1)
        )
    }

    @Test
    fun `contract duration is limited to the last season at 45`() {
        val driver = WorldDatabase.allDrivers.first()
        val seasonAt45 = seasonAtAge(driver.id, 45)

        assertEquals(5, market.maximumContractYears(driver.id, seasonAt45 - 3))
        assertEquals(2, market.maximumContractYears(driver.id, seasonAt45 - 2))
        assertEquals(1, market.maximumContractYears(driver.id, seasonAt45 - 1))
        assertEquals(0, market.maximumContractYears(driver.id, seasonAt45))
    }

    @Test
    fun `opening roster keeps every current-season driver even at age 45`() {
        val state = market.initialState(2026)
        val expectedGrid = WorldDatabase.drivers.map { it.id }.toSet()
        val openingDeals = state.contracts.filter { it.activeIn(2026) }.map { it.driverId }.toSet()

        assertEquals(expectedGrid, openingDeals)
        assertTrue(state.contracts.all { it.years >= 1 })
    }

    @Test
    fun `age 44 renewal creates structured Home signature event`() {
        val driver = WorldDatabase.allDrivers.first()
        val seasonAt45 = seasonAtAge(driver.id, 45)
        val seasonAt44 = seasonAt45 - 1
        val teamId = WorldDatabase.teams.first().id
        val state = DriverMarketState(contracts = listOf(
            DriverDeal(driver.id, teamId, 1, 2_000_000L, 5_000_000L, seasonAt44)
        ))

        val renewed = market.renew(
            state, driver.id, teamId, 1, 2_100_000L,
            DriverTeamRole.EQUAL, seasonAt44, currentWeek = 60, playerTeamId = teamId
        )
        val notice = renewed.notifications.first { it.title == "RENOVAÇÃO DE CONTRATO" }

        assertEquals(driver.id, notice.driverId)
        assertEquals(teamId, notice.fromTeamId)
        assertEquals(teamId, notice.toTeamId)
        assertEquals(1, notice.contractYears)
        assertEquals(teamId, notice.relatedTeamId)
    }

    @Test
    fun `age 45 pilot cannot receive or accept a new future deal`() {
        val driver = WorldDatabase.allDrivers.first()
        val seasonAt45 = seasonAtAge(driver.id, 45)
        val state = DriverMarketState(freeAgents = listOf(driver.id))
        val teamId = WorldDatabase.teams.first().id

        assertFalse(market.canReceiveProposals(state, driver.id, seasonAt45))
        val offerFailure = runCatching {
            market.makeOffer(
                state, driver.id, teamId, 1, 1_000_000L, DriverTeamRole.EQUAL,
                seasonAt45, currentWeek = 60
            )
        }
        assertTrue("45-year-old drivers must be blocked from next-season offers", offerFailure.isFailure)

        val contracted = state.copy(contracts = listOf(
            DriverDeal(driver.id, teamId, 1, 1_000_000L, 1_000_000L, seasonAt45)
        ))
        val renewalFailure = runCatching {
            market.renew(contracted, driver.id, teamId, 1, 1_000_000L,
                DriverTeamRole.EQUAL, seasonAt45, currentWeek = 60, playerTeamId = teamId)
        }
        assertTrue("45-year-old drivers must not be renewed", renewalFailure.isFailure)
    }

    @Test
    fun `age 43 and 44 proposals cannot exceed the remaining career window`() {
        val driver = WorldDatabase.allDrivers.first()
        val seasonAt45 = seasonAtAge(driver.id, 45)
        val state = DriverMarketState(freeAgents = listOf(driver.id))
        val teamId = WorldDatabase.teams.first().id

        val tooLongAt43 = runCatching {
            market.makeOffer(state, driver.id, teamId, 3, 1_000_000L, DriverTeamRole.EQUAL, seasonAt45 - 2, currentWeek = 60)
        }
        assertTrue(tooLongAt43.isFailure)

        val validAt43 = market.makeOffer(state, driver.id, teamId, 2, 1_000_000L, DriverTeamRole.EQUAL, seasonAt45 - 2, currentWeek = 60)
        assertEquals(2, validAt43.second.years)

        val tooLongAt44 = runCatching {
            market.makeOffer(state, driver.id, teamId, 2, 1_000_000L, DriverTeamRole.EQUAL, seasonAt45 - 1, currentWeek = 60)
        }
        assertTrue(tooLongAt44.isFailure)

        val validAt44 = market.makeOffer(state, driver.id, teamId, 1, 1_000_000L, DriverTeamRole.EQUAL, seasonAt45 - 1, currentWeek = 60)
        assertEquals(1, validAt44.second.years)
    }
}
