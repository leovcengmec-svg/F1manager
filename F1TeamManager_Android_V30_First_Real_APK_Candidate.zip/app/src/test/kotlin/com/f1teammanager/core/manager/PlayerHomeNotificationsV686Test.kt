package com.f1teammanager.core.manager

import com.f1teammanager.core.season.WorldDatabase
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PlayerHomeNotificationsV686Test {
    @Test fun `all player negotiation stages are eligible for Home and AI only events are excluded`() {
        val player = WorldDatabase.teams.first()
        val other = WorldDatabase.teams.first { it.id != player.id }
        val stages = listOf(
            "PROPOSTA ENVIADA",
            "PROPOSTA RECEBIDA",
            "PROPOSTA RECUSADA",
            "PROPOSTA NÃO CONCLUÍDA",
            "OFERTA EXPIRADA",
            "CONTRAPROPOSTA ENVIADA",
            "CONTRAPROPOSTA RECEBIDA",
            "CONTRAPROPOSTA DA EQUIPE",
            "CONTRAPROPOSTA RECUSADA",
            "CONTRAPROPOSTA RECUSADA NO FECHAMENTO",
            "NEGOCIAÇÃO ENCERRADA",
            "CONTRATO NÃO APLICADO",
            "TRANSFERÊNCIA CANCELADA"
        )

        stages.forEach { title ->
            val playerEvent = MarketNotification(
                season = 2026, week = 20, title = title,
                message = "Evento da equipe ${player.name}", relatedTeamId = player.id
            )
            assertTrue("$title deve aparecer na Home do jogador", PlayerHomeNotificationPolicy.isPlayerMarketEvent(playerEvent, player.id, player.name))
            assertFalse("$title de outra equipe não pode interromper a Home", PlayerHomeNotificationPolicy.isPlayerMarketEvent(playerEvent.copy(relatedTeamId = other.id), player.id, player.name))
        }
    }

    @Test fun `AI incoming proposal for player team is explicitly scoped to that team`() {
        val player = WorldDatabase.teams.first()
        val other = WorldDatabase.teams.first { it.id != player.id }
        val incoming = MarketNotification(
            season = 2028, week = 26, title = "PROPOSTA RECEBIDA",
            message = "A ${other.name} fez uma proposta por um piloto para 2029.",
            relatedTeamId = player.id
        )
        assertTrue(PlayerHomeNotificationPolicy.isPlayerMarketEvent(incoming, player.id, player.name))
        assertFalse(PlayerHomeNotificationPolicy.isPlayerMarketEvent(incoming.copy(relatedTeamId = other.id), player.id, player.name))

        val engineSource = java.io.File("app/src/main/java/com/f1teammanager/core/manager/DriverMarketEngine.kt").readText()
        assertTrue("A proposta recebida pela equipe do jogador precisa ser marcada com relatedTeamId", engineSource.contains("relatedTeamId = playerTeamId)"))
    }

    @Test fun `completed AI signatures remain globally visible on player Home`() {
        val player = WorldDatabase.teams.first()
        val other = WorldDatabase.teams.first { it.id != player.id }
        listOf("RENOVAÇÃO DE CONTRATO", "CONTRATO ASSINADO", "CONTRATO FECHADO", "TRANSFERÊNCIA CONFIRMADA").forEach { title ->
            val aiNotice = MarketNotification(2028, 4, title, "Piloto mudou para ${other.name}.", relatedTeamId = other.id)
            assertTrue("$title deve continuar sendo notícia global", PlayerHomeNotificationPolicy.isPlayerMarketEvent(aiNotice, player.id, player.name))
        }
    }

    @Test fun `legacy market notifications remain readable but unrelated AI messages are excluded`() {
        val player = WorldDatabase.teams.first()
        val other = WorldDatabase.teams.first { it.id != player.id }
        val legacyPlayer = MarketNotification(2026, 20, "PROPOSTA RECUSADA", "A proposta para ${player.name} foi recusada.")
        val legacyOther = MarketNotification(2026, 20, "PROPOSTA RECUSADA", "A proposta para ${other.name} foi recusada.")

        assertTrue(PlayerHomeNotificationPolicy.isPlayerMarketEvent(legacyPlayer, player.id, player.name))
        assertFalse(PlayerHomeNotificationPolicy.isPlayerMarketEvent(legacyOther, player.id, player.name))
    }

    @Test fun `player proposal and counterproposal carry the player team identity`() {
        val engine = DriverMarketEngine(seed = 686)
        val initial = engine.initialState(2026)
        val playerTeam = WorldDatabase.teams.first()
        val playerSeat = initial.contracts.first { it.teamId == playerTeam.id }.driverId
        val candidate = initial.contracts.first {
            it.teamId != playerTeam.id && engine.canReceiveProposals(initial, it.driverId, 2026)
        }

        val (afterProposal, proposal) = engine.makeOffer(
            state = initial,
            driverId = candidate.driverId,
            toTeamId = playerTeam.id,
            years = 2,
            salary = engine.salaryFor(candidate.driverId),
            role = DriverTeamRole.EQUAL,
            season = 2026,
            currentWeek = 23,
            replaceDriverId = playerSeat,
            proposerTeamId = playerTeam.id,
            playerTeamId = playerTeam.id
        )
        val sent = afterProposal.notifications.last()
        assertEquals("PROPOSTA ENVIADA", sent.title)
        assertEquals(playerTeam.id, sent.relatedTeamId)
        assertTrue(PlayerHomeNotificationPolicy.isPlayerMarketEvent(sent, playerTeam.id, playerTeam.name))

        val responseState = engine.expireOffers(
            afterProposal, proposal.expiresAfterWeek, season = 2026, playerTeamId = playerTeam.id,
            onlyDriverId = proposal.driverId, onlyTeamId = playerTeam.id
        )
        val responseNotice = responseState.notifications.last()
        assertTrue(responseNotice.title in setOf("TRANSFERÊNCIA CONFIRMADA", "CONTRATO ASSINADO", "CONTRAPROPOSTA RECEBIDA", "PROPOSTA RECUSADA", "PROPOSTA NÃO CONCLUÍDA"))
        assertEquals(playerTeam.id, responseNotice.relatedTeamId)
        assertTrue(PlayerHomeNotificationPolicy.isPlayerMarketEvent(responseNotice, playerTeam.id, playerTeam.name))

        val priorCounter = proposal.copy(status = NegotiationStatus.COUNTER, round = 1)
        val counterState = afterProposal.copy(
            pending = afterProposal.pending.filterNot { it.driverId == proposal.driverId && it.toTeamId == proposal.toTeamId } + priorCounter
        )
        val (afterCounter, _) = engine.counterOffer(
            state = counterState,
            previous = priorCounter,
            season = 2026,
            currentWeek = 24,
            salary = (proposal.salary * 1.08).toLong(),
            years = proposal.years,
            role = proposal.role,
            replaceDriverId = playerSeat,
            playerTeamId = playerTeam.id
        )
        val counterNotice = afterCounter.notifications.last()
        assertEquals("CONTRAPROPOSTA ENVIADA", counterNotice.title)
        assertEquals(playerTeam.id, counterNotice.relatedTeamId)
        assertTrue(PlayerHomeNotificationPolicy.isPlayerMarketEvent(counterNotice, playerTeam.id, playerTeam.name))
    }

    @Test fun `incoming offer expiry and player rejection both create team scoped Home events`() {
        val engine = DriverMarketEngine(seed = 687)
        val initial = engine.initialState(2026)
        val incumbent = initial.contracts.first()
        val playerTeamId = incumbent.teamId
        val destination = WorldDatabase.teams.first { it.id != playerTeamId }
        val incoming = DriverOffer(
            driverId = incumbent.driverId,
            fromTeamId = playerTeamId,
            toTeamId = destination.id,
            years = 2,
            salary = incumbent.salary,
            role = DriverTeamRole.EQUAL,
            marketValue = incumbent.marketValue,
            interestScore = 80,
            expiresAfterWeek = 12,
            status = NegotiationStatus.PENDING,
            seasonTarget = 2027,
            proposerTeamId = destination.id
        )
        val expired = engine.expireOffers(
            initial.copy(pending = listOf(incoming)), currentWeek = 12,
            season = 2026, playerTeamId = playerTeamId
        ).notifications.last()
        assertEquals("OFERTA EXPIRADA", expired.title)
        assertEquals(playerTeamId, expired.relatedTeamId)
        assertTrue(PlayerHomeNotificationPolicy.isPlayerMarketEvent(expired, playerTeamId, WorldDatabase.teams.first { it.id == playerTeamId }.name))

        val acceptedIncoming = incoming.copy(expiresAfterWeek = 20)
        val signed = engine.acceptIncomingOffer(
            initial.copy(pending = listOf(acceptedIncoming)), acceptedIncoming, 2026, 13, playerTeamId
        ).notifications.last()
        assertEquals("TRANSFERÊNCIA CONFIRMADA", signed.title)
        assertEquals(playerTeamId, signed.relatedTeamId)
        assertTrue(PlayerHomeNotificationPolicy.isPlayerMarketEvent(signed, playerTeamId, WorldDatabase.teams.first { it.id == playerTeamId }.name))

        val counter = incoming.copy(status = NegotiationStatus.COUNTER, proposerTeamId = playerTeamId, expiresAfterWeek = 20)
        val rejected = engine.rejectCounterOffer(
            initial.copy(pending = listOf(counter)), counter, 2026, 13, playerTeamId
        ).notifications.last()
        assertEquals("NEGOCIAÇÃO ENCERRADA", rejected.title)
        assertEquals(playerTeamId, rejected.relatedTeamId)
        assertTrue(PlayerHomeNotificationPolicy.isPlayerMarketEvent(rejected, playerTeamId, WorldDatabase.teams.first { it.id == playerTeamId }.name))
    }

    @Test fun `P and D failure is emitted once at its actual completion week and scoped to player`() {
        val player = WorldDatabase.teams.first()
        val failed = ResearchProject(
            projectId = "V686-FAIL-ENGINE", component = CarComponent.ENGINE, version = 4,
            basePerformance = 80, baseReliability = 80,
            targetPerformance = 80, targetReliability = 80,
            totalWeeks = 2, remainingWeeks = 2, cost = 1_000_000L,
            startedWeek = 10, outcome = ResearchOutcome.FAILURE
        )
        val tooLate = failed.copy(projectId = "V686-FAIL-LATE", remainingWeeks = 4)
        val partial = failed.copy(projectId = "V686-PARTIAL", outcome = ResearchOutcome.PARTIAL)

        val notices = PlayerHomeNotificationPolicy.failedResearchNotices(
            projectsBeforeAdvance = listOf(failed, failed.copy(), failed.copy(projectId = "V686-FAIL-ZERO", remainingWeeks = 0), tooLate, partial),
            season = 2026, currentWeek = 10, targetWeek = 12,
            playerTeamId = player.id, playerTeamName = player.name
        )
        assertEquals(2, notices.size)
        assertEquals(listOf(11, 12), notices.map { it.week }.sorted())
        assertTrue(notices.all { it.relatedTeamId == player.id })
        assertTrue(notices.all { PlayerHomeNotificationPolicy.isPlayerResearchEvent(it, player.id, player.name) })
        assertTrue(notices.none { PlayerHomeNotificationPolicy.isPlayerResearchEvent(it, player.id + 999, "Outra equipe") })

        val legacy = MarketNotification(2026, 12, "FALHA NO P&D — DESIGN NÃO CONCLUÍDO", "${player.name}: a tentativa de Asa V4 falhou.")
        val unrelated = legacy.copy(message = "${WorldDatabase.teams.first { it.id != player.id }.name}: a tentativa de Asa V4 falhou.")
        assertTrue(PlayerHomeNotificationPolicy.isPlayerResearchEvent(legacy, player.id, player.name))
        assertFalse(PlayerHomeNotificationPolicy.isPlayerResearchEvent(unrelated, player.id, player.name))
    }

    @Test fun `Home popup and badges route all player market stages to the market screen and persist team IDs`() {
        val root = java.io.File("app/src/main/java/com/f1teammanager")
        val main = java.io.File(root, "MainActivity.kt").readText()
        val preferences = java.io.File(root, "CareerPreferences.kt").readText()
        assertTrue(main.contains("PlayerHomeNotificationPolicy.isPlayerMarketEvent(notice, teamId, team)"))
        assertTrue(main.contains("PlayerHomeNotificationPolicy.isPlayerResearchEvent(notice, teamId, team)"))
        assertTrue(main.contains("PlayerHomeNotificationPolicy.isPlayerMarketEvent(event, teamId, team) || isMarketWindowOpening -> onMarket()"))
        assertTrue(preferences.contains("row.split('|', limit=7)"))
        assertTrue(preferences.contains("it.relatedTeamId ?: \"\""))
    }
}
