package com.f1teammanager.core.season

import kotlin.random.Random

fun main() {
    val profile = DriverProfileCatalog.profile("Fernando Alonso")
    val ceiling = DriverProfileCatalog.ceiling(profile.driverClass)
    fun driverFrom(r: IntArray) = DriverDefinition(99,"Test",1,r[0],r[1],r[2],r[3],r[4],r[5],r[6],profile.driverClass,profile.evolution)
    check(ceiling == 100)

    // Performance is converted into an annual per-attribute ceiling, not an
    // unrestricted global bonus.
    check(DriverEvolutionEngine.performanceUtilization(115.0) == 1.0)
    check(DriverEvolutionEngine.performanceUtilization(60.0) == 0.30)
    val capExcellent = (DriverProfileCatalog.maxAnnualGain(profile.evolution) * 0.90).toInt().coerceAtLeast(1)
    check(capExcellent < DriverProfileCatalog.maxAnnualGain(profile.evolution))

    // No regression before the class ceiling.
    val below = driverFrom(intArrayOf(90,90,90,90,90,90,90))
    val same = below // Phase gate lives in the season engine; the primitive itself is intentionally pure.
    check(listOf(same.speed,same.qualifying,same.overtaking,same.defense,same.consistency,same.wet,same.tyre).all { it == 90 })

    // Regression never crosses the absolute minimum of 40.
    val minimum = driverFrom(intArrayOf(40,40,40,40,40,40,40))
    val protected = DriverEvolutionEngine.applyRegression(minimum, 20, Random(2))
    check(listOf(protected.speed,protected.qualifying,protected.overtaking,protected.defense,protected.consistency,protected.wet,protected.tyre).all { it >= 40 })

    check(DriverEvolutionEngine.phaseFor(90, ceiling, "GROWING") == "GROWING")
    check(DriverEvolutionEngine.phaseFor(ceiling, ceiling, "GROWING") == "REGRESSION")
    check(DriverEvolutionEngine.phaseFor(49, ceiling, "REGRESSION") == "RECOVERY")
    check(DriverEvolutionEngine.phaseFor(50, ceiling, "RECOVERY") == "GROWING")
    println("DriverEvolutionCycleV83Test: PASS")
}
