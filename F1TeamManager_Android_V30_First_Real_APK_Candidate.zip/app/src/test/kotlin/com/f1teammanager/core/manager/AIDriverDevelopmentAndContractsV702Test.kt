package com.f1teammanager.core.manager

import com.f1teammanager.core.season.WorldDatabase
import org.junit.Assert.*
import org.junit.Test

class AIDriverDevelopmentAndContractsV702Test {
    @Test fun aiQueuesArePersistentInTheCanonicalMarketState() {
        val team = WorldDatabase.teams.first { it.id != WorldDatabase.teams.first().id }
        val driver = WorldDatabase.allDrivers.first()
        val queue = DriverDevelopmentEngine.start(DriverDevelopmentState(), 10, driver.id, 12, setOf(driver.id))
        val market = DriverMarketState(aiDriverDevelopment = mapOf(team.id to queue)).normalized()
        assertEquals(1, market.aiDriverDevelopment.getValue(team.id).programs.size)
        assertEquals(driver.id, market.aiDriverDevelopment.getValue(team.id).programs.single().driverId)
        assertEquals(3, market.aiDriverDevelopment.getValue(team.id).programs.single().totalWeeks)
    }

    @Test fun aiContractPlannerUsesTheFullOneToFiveYearRange() {
        val engine = DriverMarketEngine(seed = 702)
        val durations = WorldDatabase.allDrivers.map { engine.chooseAiYears(it.id, 2026, 53) }.toSet()
        assertTrue("AI should use multi-year deals, not only one-year contracts: $durations", durations.any { it >= 3 })
        assertTrue("All contract lengths must stay within 1..5", durations.all { it in 1..5 })
    }

    @Test fun aiProgrammeCompletesWithTheSamePointAndPotentialRules() {
        val driver = WorldDatabase.allDrivers.first { it.potentialOverall > com.f1teammanager.core.season.DriverProfileCatalog.overall(it.ratingsForTest()) }
        val queue = DriverDevelopmentEngine.start(DriverDevelopmentState(), 10, driver.id, 12, setOf(driver.id))
        val result = DriverDevelopmentEngine.advanceWeeks(
            queue, 3, 15, mapOf(driver.id to driver), mapOf(driver.id to driver.ratingsForTest()),
            702, mapOf(driver.id to IntArray(7))
        )
        assertEquals(1, result.completed.size)
        assertTrue(result.completed.single().appliedPoints in 0..12)
        assertTrue(result.attributes.getValue(driver.id).all { it in 40..100 })
        assertTrue(com.f1teammanager.core.season.DriverProfileCatalog.overall(result.attributes.getValue(driver.id)) <= driver.potentialOverall)
    }

    @Test fun initialAiContractsAreNotHardCodedToOneYear() {
        val initial = DriverMarketEngine(seed = 702).initialState(2026)
        val durations = initial.contracts.map { it.years }.toSet()
        assertTrue("Initial AI roster should include multi-year contracts: $durations", durations.any { it >= 3 })
        assertTrue(durations.all { it in 1..5 })
    }

    @Test fun facilityProgramHasSameFixedSpecificationForAnyTeam() {
        val driver = WorldDatabase.allDrivers.first()
        val playerQueue = DriverDevelopmentEngine.start(DriverDevelopmentState(), 6, driver.id, 10, setOf(driver.id))
        val aiQueue = DriverDevelopmentEngine.start(DriverDevelopmentState(), 6, driver.id, 10, setOf(driver.id))
        assertEquals(playerQueue, aiQueue)
        assertEquals(7, aiQueue.programs.single().points)
        assertEquals(7, aiQueue.programs.single().totalWeeks)
    }
}

private fun com.f1teammanager.core.season.DriverDefinition.ratingsForTest() =
    intArrayOf(speed, qualifying, overtaking, defense, consistency, wet, tyre)

