package com.f1teammanager.core.season

class SeasonCalendarV75Test {
    fun permanentPoolHas50Gps() {
        check(SeasonCalendar.allGps.size == 50)
        check(SeasonCalendar.allGps.map { it.circuit }.toSet().size == 50)
    }

    fun everySeasonHasExactly30UniqueGps() {
        val a = SeasonCalendar.forSeason(2026)
        val b = SeasonCalendar.forSeason(2027)
        check(a.size == 30)
        check(b.size == 30)
        check(a.map { it.circuit }.toSet().size == 30)
        check(b.map { it.circuit }.toSet().size == 30)
        check(a.map { it.circuit }.toSet().size + 20 == 50)
    }

    fun differentSeasonsChangeCalendar() {
        val a = SeasonCalendar.forSeason(2026).map { it.circuit }
        val b = SeasonCalendar.forSeason(2027).map { it.circuit }
        check(a != b)
    }

    fun referenceLapTimeAndAssetSearchAreStored() {
        SeasonCalendar.allGps.forEach {
            check(it.averageLapTimeMs > 0L)
            check(it.assetSearchName.isNotBlank())
            check(it.distanceKm > 0.0)
            check(it.laps > 0)
        }
    }
}
