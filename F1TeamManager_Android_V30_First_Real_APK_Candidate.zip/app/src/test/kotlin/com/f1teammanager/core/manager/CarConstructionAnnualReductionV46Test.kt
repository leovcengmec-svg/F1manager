package com.f1teammanager.core.manager

fun main() {
    check(CarDevelopmentEngine.ANNUAL_CONTINUITY_FACTOR == 0.70)

    val engine = CarDevelopmentEngine()
    val base = TeamCarState(
        aerodynamics = 95, chassis = 90, engine = 85, reliability = 80,
        frontWing = 95, rearWing = 90, brakes = 85, electricPowerUnit = 80
    )
    val state = TeamManagerState(car = base, finance = TeamFinanceState(100_000_000L))
    val next = engine.startNextSeason(state, 2026).car

    // No knowledge/investment/regulation bonus in this setup should move the
    // continuity baseline away from the expected 70% preservation of the gap to 50.
    check(next.engine == 74) { "engine=${next.engine}" }
    check(next.chassis == 78) { "chassis=${next.chassis}" }
    check(next.frontWing == 81) { "frontWing=${next.frontWing}" }
    check(next.rearWing == 78) { "rearWing=${next.rearWing}" }

    val debtState = state.copy(finance = TeamFinanceState(-1_000_000L))
    val constructed = engine.startNextSeason(debtState, 2026)
    val penalized = FinancialSeasonClosureEngine.applyPlayerPenalty(constructed)
    check(penalized.car.engine == (constructed.car.engine * 80 / 100).coerceAtLeast(1))
    check(penalized.car.chassis == (constructed.car.chassis * 80 / 100).coerceAtLeast(1))

    println("CarConstructionAnnualReductionV46Test: PASS")
}
