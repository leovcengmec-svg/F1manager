package com.f1teammanager.core.season

import kotlin.random.Random
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class FreeDriverNaturalGrowthV709Test {
    @Test
    fun `free driver grows beyond class ceiling up to individual potential`() {
        var driver = DriverDefinition(
            id = 97091, name = "Free-agent potential probe", teamId = 0,
            speed = 67, qualifying = 67, overtaking = 67, defense = 67,
            consistency = 67, wet = 67, tyre = 67,
            driverClass = "Médio", evolution = "Prodígio", potentialOverall = 90
        )
        val startingOverall = DriverProfileCatalog.overall(driver.ratingsForTest())
        var bank = 0.0
        val annualGains = IntArray(7)
        repeat(30) { gp ->
            val tick = DriverEvolutionEngine.applyFreeDriverTick(
                driver = driver,
                currentBank = bank,
                annualGains = annualGains,
                random = Random(97091 + gp),
                careerAge = 24
            )
            driver = tick.driver
            bank = tick.bank
            assertTrue("Free agents should never accumulate sporting regression", tick.performanceAttributeDeltas.none { it < 0 })
            assertTrue("Age below 34 should not apply age losses", tick.ageAttributeLossesThisTick.all { it == 0 })
        }
        val finalOverall = DriverProfileCatalog.overall(driver.ratingsForTest())
        assertTrue("free driver should be able to pass the Médio class ceiling 69", finalOverall > 69)
        assertTrue("free driver must remain under personal potential", finalOverall <= 90)
        assertTrue(finalOverall > startingOverall)
    }

    @Test
    fun `free driver regressions come only from all-attribute aging ledger`() {
        val driver = DriverDefinition(
            id = 97092, name = "Free-agent aging probe", teamId = 0,
            speed = 80, qualifying = 80, overtaking = 80, defense = 80,
            consistency = 80, wet = 80, tyre = 80,
            driverClass = "Pro", evolution = "Auge tardio", potentialOverall = 96
        )
        val tick = DriverEvolutionEngine.applyFreeDriverTick(
            driver = driver,
            currentBank = -0.99,
            annualGains = IntArray(7),
            random = Random(97092),
            careerAge = 43,
            currentAgeBank = 0.99
        )
        assertTrue(tick.performanceAttributeDeltas.none { it < 0 })
        assertTrue(tick.ageAttributeLossesThisTick.sum() > 0)
        assertEquals(7, tick.ageAttributeLossesThisTick.size)
        assertTrue(tick.ageAttributeLossesThisTick.any { it > 0 })
        assertTrue("legacy sporting regression bank must be cleared for a free agent", tick.bank >= 0.0)
    }

    @Test
    fun `free driver never inherits negative sporting regression from a previous contract`() {
        val driver = DriverDefinition(
            id = 97094, name = "Previously contracted free-agent probe", teamId = 0,
            speed = 70, qualifying = 70, overtaking = 70, defense = 70,
            consistency = 70, wet = 70, tyre = 70,
            driverClass = "Médio", evolution = "Prodígio", potentialOverall = 90
        )
        val tick = DriverEvolutionEngine.applyFreeDriverTick(
            driver = driver,
            currentBank = -8.75,
            annualGains = IntArray(7),
            random = Random(97094),
            careerAge = 24
        )
        assertTrue("free agent must not lose attributes due to old performance evidence", tick.performanceAttributeDeltas.none { it < 0 })
        assertTrue("free agent must not carry a negative sporting bank", tick.bank >= 0.0)
        assertTrue("natural development can continue after release", tick.performanceAttributeDeltas.any { it > 0 } || tick.bank > 0.0)
    }

    @Test
    fun `news detail names the exact changed attributes and separates causes`() {
        val tick = DriverEvolutionEngine.TickResult(
            driver = DriverDefinition(
                id = 97093, name = "News probe", teamId = 0,
                speed = 80, qualifying = 80, overtaking = 80, defense = 80,
                consistency = 80, wet = 80, tyre = 80,
                driverClass = "Pro", evolution = "Auge tardio", potentialOverall = 96
            ),
            bank = 0.0,
            phase = "GROWING",
            attributeDelta = 0,
            performanceAttributeDeltas = intArrayOf(1, 0, 0, 0, 0, 0, 0),
            ageAttributeLossesThisTick = intArrayOf(0, 1, 0, 0, 0, 0, 0)
        )
        val reason = DriverEvolutionEngine.describeTickCauses(tick, freeAgent = false)
        assertTrue(reason.contains("desempenho acima das expectativas: VEL +1"))
        assertTrue(reason.contains("declínio natural da idade: CLA -1"))
        assertTrue(DriverEvolutionEngine.describeTickCauses(tick, freeAgent = true).contains("desenvolvimento natural: VEL +1"))
    }
}

private fun DriverDefinition.ratingsForTest(): IntArray =
    intArrayOf(speed, qualifying, overtaking, defense, consistency, wet, tyre)
