package com.f1teammanager.core.manager

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class FlexibleInvestmentEnvelopeV690Test {
    @Test fun nextCarCanReceiveMoreThanTheInitialEightyMillionPriorityWhenOtherCategoriesUnderSpend() {
        val firstPriority = SeasonInvestmentPolicy.aiNextCarReserve(
            budget = 1_000_000_000L,
            alreadyInvested = 0L,
            annualEnvelopeRemaining = 200_000_000L
        )
        val releasedPriority = SeasonInvestmentPolicy.aiNextCarReserve(
            budget = 1_000_000_000L,
            alreadyInvested = firstPriority,
            annualEnvelopeRemaining = 120_000_000L
        )
        assertEquals(80_000_000L, firstPriority)
        assertEquals(48_000_000L, releasedPriority)
        assertTrue(firstPriority + releasedPriority > 80_000_000L)
        assertTrue(firstPriority + releasedPriority <= SeasonInvestmentPolicy.AI_NEXT_CAR_ABSOLUTE_CAP)
    }

    @Test fun nextCarStillCannotExceedItsAbsoluteProjectCeilingOrGlobalEnvelope() {
        assertEquals(0L, SeasonInvestmentPolicy.aiNextCarReserve(
            budget = 1_000_000_000L,
            alreadyInvested = 150_000_000L,
            annualEnvelopeRemaining = 50_000_000L
        ))
        assertEquals(20_000_000L, SeasonInvestmentPolicy.aiNextCarReserve(
            budget = 1_000_000_000L,
            alreadyInvested = 100_000_000L,
            annualEnvelopeRemaining = 50_000_000L
        ))
    }

    @Test fun facilityInvestmentCanExceedItsFortyMillionReferenceWhenSharedCapacityExists() {
        val sharedCapacity = SeasonInvestmentPolicy.aiCurrentAndFacilityEnvelopeRemaining(
            budget = 300_000_000L,
            round = 1,
            nextCarAlreadyInvested = 0L,
            annualEnvelopeRemaining = 200_000_000L
        )
        assertEquals(120_000_000L, sharedCapacity)
        assertEquals(66_000_000L, SeasonInvestmentPolicy.allowedAiFacilityInvestmentAmount(
            requestedCost = 66_000_000L,
            spendableCash = 100_000_000L,
            annualEnvelopeRemaining = sharedCapacity,
            forecastHeadroom = 100_000_000L
        ))
        assertEquals(40_000_000L, SeasonInvestmentPolicy.aiFacilitiesAnnualLimit(200_000_000L))
    }

    @Test fun currentCarAndFacilitiesShareTheFlexibleSixtyPercentPoolAfterNextCarPriority() {
        val pool = SeasonInvestmentPolicy.aiCurrentAndFacilityEnvelopeRemaining(
            budget = 500_000_000L,
            round = 1,
            nextCarAlreadyInvested = 80_000_000L,
            annualEnvelopeRemaining = 120_000_000L
        )
        assertEquals(72_000_000L, pool)
        assertTrue(pool > 40_000_000L)
    }

    @Test fun everyCategoryStillSharesTheSameTwoHundredMillionAnnualEnvelope() {
        val cap = 200_000_000L
        val currentCar = 70_000_000L
        val facilities = 60_000_000L
        val nextCar = 50_000_000L
        assertEquals(20_000_000L, SeasonInvestmentPolicy.remainingAnnualTechnicalEnvelope(
            annualCap = cap,
            alreadySpentTechnical = currentCar + facilities,
            nextCarAlreadyInvested = nextCar
        ))
        assertEquals(0L, SeasonInvestmentPolicy.remainingAnnualTechnicalEnvelope(
            annualCap = cap,
            alreadySpentTechnical = currentCar + facilities + 20_000_000L,
            nextCarAlreadyInvested = nextCar
        ))
    }
}
