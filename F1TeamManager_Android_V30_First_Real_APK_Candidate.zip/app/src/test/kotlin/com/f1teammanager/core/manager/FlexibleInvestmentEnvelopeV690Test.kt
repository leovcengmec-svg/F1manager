package com.f1teammanager.core.manager

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class FlexibleInvestmentEnvelopeV690Test {
    @Test fun nextCarCanReceiveMoreThanTheInitialEightyMillionPriorityWhenOtherCategoriesUnderSpend() {
        val firstPriority = SeasonInvestmentPolicy.aiNextCarReserve(
            budget = 1_000_000_000L,
            alreadyInvested = 0L,
            annualEnvelopeRemaining = 200_000_000L
        )
        // Spending €80M in the other categories must not shrink the protected
        // next-car reserve from €80M to €48M (the old geometric-decay bug).
        val afterOtherCategoriesSpend = SeasonInvestmentPolicy.aiNextCarReserve(
            budget = 1_000_000_000L,
            alreadyInvested = 0L,
            annualEnvelopeRemaining = 120_000_000L
        )
        assertEquals(150_000_000L, firstPriority)
        assertEquals(150_000_000L, afterOtherCategoriesSpend)
        assertTrue(afterOtherCategoriesSpend <= SeasonInvestmentPolicy.AI_NEXT_CAR_ABSOLUTE_CAP)
    }

    @Test fun nextCarStillCannotExceedItsIndependentAbsoluteProjectCeiling() {
        assertEquals(0L, SeasonInvestmentPolicy.aiNextCarReserve(
            budget = 1_000_000_000L,
            alreadyInvested = 150_000_000L,
            annualEnvelopeRemaining = 50_000_000L
        ))
        assertEquals(50_000_000L, SeasonInvestmentPolicy.aiNextCarReserve(
            budget = 1_000_000_000L,
            alreadyInvested = 100_000_000L,
            annualEnvelopeRemaining = 50_000_000L
        ))
    }

    @Test fun facilityInvestmentCanExceedItsFortyMillionReferenceWhenSharedCapacityExists() {
        val sharedCapacity = SeasonInvestmentPolicy.aiCurrentAndFacilityEnvelopeRemaining(
            budget = 300_000_000L,
            round = 1,
            nextCarAlreadyInvested = 0L,
            annualEnvelopeRemaining = 200_000_000L
        )
        assertEquals(120_000_000L, sharedCapacity)
        assertEquals(66_000_000L, SeasonInvestmentPolicy.allowedAiFacilityInvestmentAmount(
            requestedCost = 66_000_000L,
            spendableCash = 100_000_000L,
            annualEnvelopeRemaining = sharedCapacity,
            forecastHeadroom = 100_000_000L
        ))
        assertEquals(40_000_000L, SeasonInvestmentPolicy.aiFacilitiesAnnualLimit(200_000_000L))
    }

    @Test fun currentCarAndFacilitiesShareTheFlexibleSixtyPercentPoolAfterNextCarPriority() {
        val pool = SeasonInvestmentPolicy.aiCurrentAndFacilityEnvelopeRemaining(
            budget = 500_000_000L,
            round = 1,
            nextCarAlreadyInvested = 80_000_000L,
            annualEnvelopeRemaining = 120_000_000L
        )
        assertEquals(120_000_000L, pool)
        assertTrue(pool > 40_000_000L)
    }

    @Test fun protectedPriorityDoesNotDecayAfterRepeatedCurrentCarAndFacilitySpending() {
        val firstPool = SeasonInvestmentPolicy.aiCurrentAndFacilityEnvelopeRemaining(
            budget = 500_000_000L, round = 1, nextCarAlreadyInvested = 0L,
            annualEnvelopeRemaining = 200_000_000L
        )
        val afterEightyMillionSpentElsewhere = SeasonInvestmentPolicy.aiCurrentAndFacilityEnvelopeRemaining(
            budget = 500_000_000L, round = 8, nextCarAlreadyInvested = 0L,
            annualEnvelopeRemaining = 120_000_000L
        )
        val afterOneHundredTwentyMillionSpentElsewhere = SeasonInvestmentPolicy.aiCurrentAndFacilityEnvelopeRemaining(
            budget = 500_000_000L, round = 16, nextCarAlreadyInvested = 0L,
            annualEnvelopeRemaining = 80_000_000L
        )
        assertEquals(200_000_000L, firstPool)
        assertEquals(120_000_000L, afterEightyMillionSpentElsewhere)
        assertEquals(80_000_000L, afterOneHundredTwentyMillionSpentElsewhere)
    }

    @Test fun nextCarHasAnIndependentEnvelopeFromCurrentCarAndFacilities() {
        val cap = 200_000_000L
        val currentCar = 70_000_000L
        val facilities = 60_000_000L
        val nextCar = 50_000_000L
        assertEquals(70_000_000L, SeasonInvestmentPolicy.remainingAnnualTechnicalEnvelope(
            annualCap = cap,
            alreadySpentTechnical = currentCar + facilities,
            nextCarAlreadyInvested = nextCar
        ))
        assertEquals(50_000_000L, SeasonInvestmentPolicy.remainingAnnualTechnicalEnvelope(
            annualCap = cap,
            alreadySpentTechnical = currentCar + facilities + 20_000_000L,
            nextCarAlreadyInvested = nextCar
        ))
    }
}
