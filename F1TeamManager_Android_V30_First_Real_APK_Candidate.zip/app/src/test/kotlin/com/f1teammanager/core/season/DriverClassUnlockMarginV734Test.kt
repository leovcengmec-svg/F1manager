package com.f1teammanager.core.season

import com.f1teammanager.core.manager.DriverDevelopmentEngine
import com.f1teammanager.core.manager.DriverDevelopmentState
import kotlin.random.Random
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class DriverClassUnlockMarginV734Test {
    private fun ratings(driver: DriverDefinition) = intArrayOf(
        driver.speed, driver.qualifying, driver.overtaking, driver.defense,
        driver.consistency, driver.wet, driver.tyre
    )

    @Test fun leaderCanEarnTheAdditionalBandWithoutChangingNormalGpScore() {
        // A P1 car gives both drivers the same P2 target. P1/P1 is exceptional even
        // though it remains inside the ordinary ±3 band used by growth/regression.
        val target = DriverEvolutionEngine.Target(2, 2, 2)
        assertEquals(105.0, DriverEvolutionEngine.gpPerformanceIndex(target, 1, 1), 0.0)
        assertEquals(150.0, DriverEvolutionEngine.classUnlockPerformanceIndex(target, 1, 1), 0.0)
        assertEquals(5, DriverEvolutionEngine.performanceClassMargin(
            DriverEvolutionEngine.classUnlockPerformanceIndex(target, 1, 1)
        ))
    }

    @Test fun classUnlockScoreKeepsQualifyingAndRaceWeightsAtFortySixty() {
        val target = DriverEvolutionEngine.Target(2, 2, 2)
        // Qualifying meets target (100); race is one place above target (150).
        assertEquals(130.0, DriverEvolutionEngine.classUnlockPerformanceIndex(target, 2, 1), 0.0)
        assertEquals(5, DriverEvolutionEngine.performanceClassMargin(
            DriverEvolutionEngine.classUnlockPerformanceIndex(target, 2, 1), 5
        ))
    }

    @Test fun earnedMarginRequiresFiveRealGpsAndNeverShrinksWithinTheSeason() {
        assertEquals(0, DriverEvolutionEngine.performanceClassMargin(150.0, 4))
        assertEquals(5, DriverEvolutionEngine.performanceClassMargin(150.0, 5))
        assertEquals(0, DriverEvolutionEngine.nextEarnedClassMargin(0, 150.0, 4))
        assertEquals(5, DriverEvolutionEngine.nextEarnedClassMargin(0, 150.0, 5))
        assertEquals(5, DriverEvolutionEngine.nextEarnedClassMargin(5, 105.0, 10))
        assertEquals(5, DriverEvolutionEngine.nextEarnedClassMargin(3, 140.0, 5))
    }


    @Test fun contractedProMustWaitForFiveRealGpsBeforeUsingPoleWinEvidence() {
        val marginBeforeSample = DriverEvolutionEngine.classGrowthMargin(
            driverClass = "Pro",
            isContracted = true,
            seasonPerformanceAverage = 150.0,
            earnedClassMargin = 0,
            completedGps = 4
        )
        val marginAfterSample = DriverEvolutionEngine.classGrowthMargin(
            driverClass = "Pro",
            isContracted = true,
            seasonPerformanceAverage = 150.0,
            earnedClassMargin = 5,
            completedGps = 5
        )
        assertEquals(0, marginBeforeSample)
        assertEquals(5, marginAfterSample)
    }

    @Test fun contractedProCanUseEarnedMarginAfterExceptionalSeasonEvidence() {
        val driver = DriverDefinition(
            73401, "Pro leader", 1, 89, 89, 89, 89, 89, 89, 89,
            "Pro", "Prodígio", "", 100
        )
        var current = driver
        var bank = 0.0
        val annual = IntArray(7)
        repeat(80) { gp ->
            val tick = DriverEvolutionEngine.applyPerformanceTick(
                driver = current,
                performanceIndex = 105.0,
                currentBank = bank,
                annualGains = annual,
                random = Random(73400 + gp),
                seasonPerformanceAverage = 150.0,
                earnedClassMargin = 5,
                seasonPerformanceSamples = 5,
                careerAge = 21,
                isContracted = true
            )
            current = tick.driver
            bank = tick.bank
        }
        assertTrue("Exceptional car-relative evidence must unlock the Pro +5 band", DriverProfileCatalog.overall(ratings(current)) > 89)
        assertTrue(DriverProfileCatalog.overall(ratings(current)) <= 94)
    }

    @Test fun proFreeAgentCanUseOnlyLastCompletedSeasonEvidence() {
        val driver = DriverDefinition(
            73402, "Pro free agent", 0, 89, 89, 89, 89, 89, 89, 89,
            "Pro", "Prodígio", "", 100
        )
        var current = driver
        var bank = 0.0
        val annual = IntArray(7)
        repeat(80) { gp ->
            val tick = DriverEvolutionEngine.applyFreeDriverTick(
                driver = current,
                currentBank = bank,
                annualGains = annual,
                random = Random(73420 + gp),
                careerAge = 21,
                seasonPerformanceAverage = 150.0,
                earnedClassMargin = 5,
                seasonPerformanceSamples = 5
            )
            current = tick.driver
            bank = tick.bank
        }
        assertTrue(DriverProfileCatalog.overall(ratings(current)) > 89)
        assertTrue(DriverProfileCatalog.overall(ratings(current)) <= 94)
    }

    @Test fun facilityReserveIsReleasedWhenTheSeasonMarginOpens() {
        val driver = DriverDefinition(
            73403, "Pro facility reserve", 1, 89, 89, 89, 89, 89, 89, 89,
            "Pro", "Prodígio", "", 100
        )
        val started = DriverDevelopmentEngine.start(
            DriverDevelopmentState(), 10, driver.id, 1, setOf(driver.id)
        )
        val blocked = DriverDevelopmentEngine.advanceWeeks(
            state = started,
            weeks = 3,
            currentWeek = 4,
            drivers = mapOf(driver.id to driver),
            attributes = mapOf(driver.id to ratings(driver)),
            seed = 73430,
            annualGains = mapOf(driver.id to IntArray(7)),
            contractedDriverIds = setOf(driver.id),
            seasonPerformanceAverages = mapOf(driver.id to 100.0)
        )
        assertEquals(89, DriverProfileCatalog.overall(blocked.attributes.getValue(driver.id)))
        assertTrue(blocked.state.reservePoints.getValue(driver.id) > 0)

        val released = DriverDevelopmentEngine.advanceWeeks(
            state = blocked.state,
            weeks = 1,
            currentWeek = 5,
            drivers = mapOf(driver.id to driver),
            attributes = blocked.attributes,
            seed = 73431,
            annualGains = blocked.annualGains,
            contractedDriverIds = setOf(driver.id),
            seasonPerformanceAverages = mapOf(driver.id to 150.0),
            earnedClassMargins = mapOf(driver.id to 5),
            seasonPerformanceSamples = mapOf(driver.id to 5)
        )
        assertTrue("Reserved programme points should apply when margin becomes available",
            DriverProfileCatalog.overall(released.attributes.getValue(driver.id)) > 89)
        assertTrue((released.state.reservePoints[driver.id] ?: 0) < blocked.state.reservePoints.getValue(driver.id))
    }
    @Test fun v735UnlockThresholdsAllowFrontRunnersToUseTheClassBand() {
        assertEquals(0, DriverEvolutionEngine.performanceClassMargin(94.99, 5))
        assertEquals(1, DriverEvolutionEngine.performanceClassMargin(95.0, 5))
        assertEquals(2, DriverEvolutionEngine.performanceClassMargin(100.0, 5))
        assertEquals(3, DriverEvolutionEngine.performanceClassMargin(105.0, 5))
        assertEquals(4, DriverEvolutionEngine.performanceClassMargin(110.0, 5))
        assertEquals(5, DriverEvolutionEngine.performanceClassMargin(115.0, 5))
    }

    @Test fun proProfilesReceiveAtLeastTheFullNinetyFourPointPotentialBand() {
        val leonardo = DriverProfileCatalog.profile("Leonardo Vicente")
        assertTrue("A Pro prodigy must be able to reach Overall 94 when the class margin is earned", leonardo.potentialOverall >= 94)
        assertEquals("Pro", leonardo.driverClass)
    }

}
