package com.f1teammanager

import com.f1teammanager.core.manager.CarComponent
import com.f1teammanager.core.manager.CarDevelopmentEngine
import com.f1teammanager.core.manager.CarPiece
import com.f1teammanager.core.manager.FactoryOrder
import com.f1teammanager.core.manager.FinancialSeasonClosureEngine
import com.f1teammanager.core.manager.DriverDevelopmentEngine
import com.f1teammanager.core.manager.DriverDevelopmentState
import com.f1teammanager.core.manager.GarageCarId
import com.f1teammanager.core.manager.PhysicalCar
import com.f1teammanager.core.manager.ResearchComplexity
import com.f1teammanager.core.manager.ResearchDesign
import com.f1teammanager.core.manager.ResearchFocus
import com.f1teammanager.core.manager.ResearchOutcome
import com.f1teammanager.core.manager.ResearchProject
import com.f1teammanager.core.manager.TeamCarState
import com.f1teammanager.core.manager.TeamFactoryState
import com.f1teammanager.core.manager.TeamFinanceState
import com.f1teammanager.core.manager.TeamGarage
import com.f1teammanager.core.manager.TeamManagerState
import com.f1teammanager.core.manager.TeamResearchState
import com.f1teammanager.core.manager.SupplierContract
import com.f1teammanager.core.manager.SupplierType
import com.f1teammanager.core.race.RaceParticipant
import com.f1teammanager.core.season.DriverDefinition
import com.f1teammanager.core.season.DriverEvolutionEngine
import com.f1teammanager.core.season.DriverProfileCatalog
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class MinimumAttributeFloorV698Test {
    private fun allAtLeast40(values: IntArray) = assertTrue(values.all { it in 40..100 })

    @Test
    fun `all seven permanent driver attributes and potential are floored`() {
        val driver = DriverDefinition(
            id = 9981, name = "Floor Test", teamId = 1,
            speed = 0, qualifying = 1, overtaking = 39, defense = 40,
            consistency = 41, wet = 101, tyre = 120,
            potentialOverall = 2
        ).normalized()
        val attributes = intArrayOf(driver.speed, driver.qualifying, driver.overtaking,
            driver.defense, driver.consistency, driver.wet, driver.tyre, driver.potentialOverall)
        allAtLeast40(attributes)
        assertEquals(100, driver.wet)
        assertEquals(100, driver.tyre)
        assertEquals(40, driver.potentialOverall)
    }

    @Test
    fun `legacy driver save values are repaired on load`() {
        val rosterDriver = DriverDefinition(9982, "Legacy Pilot", 1, 60, 60, 60, 60, 60, 60, 60).normalized()
        val (merged, repaired) = DriverAttributePersistence.merge(
            "${rosterDriver.id}:1,39,40,101,0,70,88", listOf(rosterDriver)
        )
        assertTrue(repaired)
        allAtLeast40(merged.getValue(rosterDriver.id))
        assertArrayEquals(intArrayOf(40, 40, 40, 100, 40, 70, 88), merged.getValue(rosterDriver.id))
    }

    @Test
    fun `driver overall calculations normalize every raw attribute before averaging`() {
        assertEquals(40, DriverProfileCatalog.overall(intArrayOf(0, 1, 2, 3, 4, 5, 6)))
        assertEquals(100, DriverProfileCatalog.overall(intArrayOf(120, 101, 100, 100, 100, 100, 100)))
    }

    @Test
    fun `driver development repairs a legacy vector even when no week advances`() {
        val result = DriverDevelopmentEngine.advanceWeeks(
            state = DriverDevelopmentState(), weeks = 0, currentWeek = 1,
            drivers = emptyMap(), attributes = mapOf(1 to intArrayOf(1, 2, 3, 4, 5, 6, 7)), seed = 698
        )
        allAtLeast40(result.attributes.getValue(1))
    }

    @Test
    fun `pilot regression cannot cross the universal floor`() {
        val driver = DriverDefinition(9983, "Regression Floor", 1, 40, 40, 40, 40, 40, 40, 40).normalized()
        val regressed = DriverEvolutionEngine.applyRegression(driver, 500, kotlin.random.Random(698))
        allAtLeast40(intArrayOf(regressed.speed, regressed.qualifying, regressed.overtaking,
            regressed.defense, regressed.consistency, regressed.wet, regressed.tyre))
    }

    @Test
    fun `all summary car components and summary reliability are floored`() {
        val car = TeamCarState(
            aerodynamics = 1, chassis = 2, engine = 3, reliability = 0,
            frontWing = 4, rearWing = 5, brakes = 6, electricPowerUnit = 7
        ).normalized()
        assertArrayEquals(intArrayOf(40, 40, 40, 40, 40, 40, 40, 40), intArrayOf(
            car.aerodynamics, car.chassis, car.engine, car.reliability,
            car.frontWing, car.rearWing, car.brakes, car.electricPowerUnit
        ))
    }

    @Test
    fun `physical car components and each component reliability are floored`() {
        val raw = PhysicalCar(
            id = GarageCarId.CAR_1, engine = 0, chassis = 1, frontWing = 2,
            rearWing = 3, brakes = 4, electricPowerUnit = 5, reliability = 6,
            componentReliabilities = CarComponent.values().associateWith { 7 }
        )
        val car = raw.normalized()
        allAtLeast40(intArrayOf(car.engine, car.chassis, car.frontWing, car.rearWing,
            car.brakes, car.electricPowerUnit, car.reliability))
        allAtLeast40(CarComponent.values().map { car.componentReliability(it) }.toIntArray())
    }

    @Test
    fun `installing a legacy low rated part cannot put either car below the floor`() {
        val raw = PhysicalCar(GarageCarId.CAR_1, 1, 2, 3, 4, 5, 6, 7,
            componentReliabilities = CarComponent.values().associateWith { 8 })
        val garage = TeamGarage(raw, raw).install(
            CarPiece("legacy-part", CarComponent.ENGINE, 1, 2, 3), GarageCarId.CAR_2
        )
        listOf(garage.car1, garage.car2).forEach { car ->
            allAtLeast40(intArrayOf(car.engine, car.chassis, car.frontWing, car.rearWing,
                car.brakes, car.electricPowerUnit, car.reliability))
            allAtLeast40(CarComponent.values().map { car.componentReliability(it) }.toIntArray())
        }
        assertEquals(40, garage.car2.engine)
    }

    @Test
    fun `research and factory pipeline cannot store a component below 40`() {
        val project = ResearchProject("p", CarComponent.ENGINE, 1, 1, 2, 3, 4,
            4, 2, 1_000L, 1, ResearchFocus.BALANCED, ResearchComplexity.SIMPLE,
            ResearchOutcome.SUCCESS).normalized()
        val design = ResearchDesign("d", CarComponent.ENGINE, 1, 1, 2, 1, 4).normalized()
        val order = FactoryOrder("o", "d", CarComponent.ENGINE, 1, 1, 2,
            1, 1, 4, 2, 10L, 1).normalized()
        val factory = TeamFactoryState(pendingInstallations = listOf(
            CarPiece("piece", CarComponent.ENGINE, 1, 1, 2)
        )).normalized()
        assertArrayEquals(intArrayOf(40, 40, 40, 40), intArrayOf(
            project.basePerformance, project.baseReliability, project.targetPerformance, project.targetReliability
        ))
        assertArrayEquals(intArrayOf(40, 40, 40, 40), intArrayOf(
            design.performance, design.reliability, order.performance, order.reliability
        ))
        factory.pendingInstallations.forEach { assertTrue(it.performance >= 40 && it.reliability >= 40) }
    }

    @Test
    fun `whole manager snapshot repairs car garage research factory and supplier ratings`() {
        val rawCar = TeamCarState(1, 2, 3, 4, frontWing = 5, rearWing = 6, brakes = 7, electricPowerUnit = 8)
        val rawPhysical = PhysicalCar(GarageCarId.CAR_1, 1, 2, 3, 4, 5, 6, 7)
        val rawResearch = ResearchProject("p", CarComponent.CHASSIS, 1, 1, 2, 3, 4, 4, 2,
            1_000L, 1).let { TeamResearchState(activeProjects = listOf(it)) }
        val state = TeamManagerState(
            car = rawCar, garage = TeamGarage(rawPhysical, rawPhysical), research = rawResearch,
            factory = TeamFactoryState(pendingInstallations = listOf(CarPiece("piece", CarComponent.ENGINE, 1, 1, 1))),
            finance = TeamFinanceState(1_000_000L),
            engineSupplier = SupplierContract(SupplierType.ENGINE, "Legacy", 1, 2, 0L, 1),
            tyreSupplier = SupplierContract(SupplierType.TYRE, "Legacy", 3, 4, 0L, 1),
            driverEvolutionAttributes = mapOf(1 to listOf(1, 2, 3, 4, 5, 6, 7))
        ).normalized()
        allAtLeast40(intArrayOf(state.car.engine, state.car.chassis, state.car.reliability))
        listOf(state.garage!!.car1, state.garage.car2).forEach {
            allAtLeast40(intArrayOf(it.engine, it.chassis, it.frontWing, it.rearWing, it.brakes, it.electricPowerUnit, it.reliability))
        }
        assertTrue(state.research.activeProjects.all { it.basePerformance >= 40 && it.baseReliability >= 40 })
        assertTrue(state.factory.pendingInstallations.all { it.performance >= 40 && it.reliability >= 40 })
        assertTrue(state.engineSupplier.performance >= 40 && state.engineSupplier.reliability >= 40)
        assertTrue(state.tyreSupplier.performance >= 40 && state.tyreSupplier.reliability >= 40)
        allAtLeast40(state.driverEvolutionAttributes.getValue(1).toIntArray())
    }

    @Test
    fun `race participant sporting and factory attributes respect the floor`() {
        val participant = RaceParticipant(
            driverId = 1, driverName = "Probe", teamId = 1, teamName = "Team",
            driverSpeed = 1, qualifying = 2, overtaking = 3, defense = 4, consistency = 5,
            enginePerformance = 6, tyreGrip = 7, tyreWear = 8, reliability = 9,
            wetSkill = 10, chassisPerformance = 11, frontWingPerformance = 12,
            rearWingPerformance = 13, brakesPerformance = 14, electricPowerUnitPerformance = 15,
            engineReliability = 16, chassisReliability = 17, frontWingReliability = 18,
            rearWingReliability = 19, brakesReliability = 20, electricPowerUnitReliability = 21
        ).normalized()
        allAtLeast40(intArrayOf(participant.driverSpeed, participant.qualifying, participant.overtaking,
            participant.defense, participant.consistency, participant.wetSkill, participant.tyreGrip,
            participant.tyreWear, participant.enginePerformance, participant.chassisPerformance,
            participant.frontWingPerformance, participant.rearWingPerformance, participant.brakesPerformance,
            participant.electricPowerUnitPerformance, participant.reliability, participant.engineReliability,
            participant.chassisReliability, participant.frontWingReliability, participant.rearWingReliability,
            participant.brakesReliability, participant.electricPowerUnitReliability))
    }

    @Test
    fun `financial penalties cannot reduce permanent car ratings below 40`() {
        val base = TeamCarState(
            aerodynamics = 45, chassis = 43, engine = 42, reliability = 41,
            frontWing = 44, rearWing = 43, brakes = 42, electricPowerUnit = 41
        )
        val playerResult = FinancialSeasonClosureEngine.applyCarPenalty(base, -1L)
        allAtLeast40(intArrayOf(playerResult.car.aerodynamics, playerResult.car.chassis,
            playerResult.car.engine, playerResult.car.reliability, playerResult.car.frontWing,
            playerResult.car.rearWing, playerResult.car.brakes, playerResult.car.electricPowerUnit))

        val installed = CarComponent.values().associateWith { "installed-${it.name}" }
        val physical = PhysicalCar(
            GarageCarId.CAR_1, 42, 43, 44, 45, 46, 47, 41,
            componentReliabilities = CarComponent.values().associateWith { 41 },
            installedPieces = installed
        )
        val penalizedGarage = FinancialSeasonClosureEngine.applyGaragePenalty(TeamGarage(physical, physical))
        listOf(penalizedGarage.car1, penalizedGarage.car2).forEach { car ->
            allAtLeast40(intArrayOf(car.engine, car.chassis, car.frontWing, car.rearWing,
                car.brakes, car.electricPowerUnit, car.reliability))
            allAtLeast40(CarComponent.values().map { car.componentReliability(it) }.toIntArray())
        }
    }

    @Test
    fun `next season construction keeps all physical components at least 40`() {
        val installed = CarComponent.values().associateWith { "installed-${it.name}" }
        val physical = PhysicalCar(GarageCarId.CAR_1, 1, 2, 3, 4, 5, 6, 7,
            componentReliabilities = CarComponent.values().associateWith { 1 },
            installedPieces = installed).normalized()
        val garage = TeamGarage(physical, physical)
        val built = CarDevelopmentEngine().buildNextSeasonGarage(
            previousGarage = garage, invested = 0L
        )
        listOf(built.car1, built.car2).forEach {
            allAtLeast40(intArrayOf(it.engine, it.chassis, it.frontWing, it.rearWing,
                it.brakes, it.electricPowerUnit, it.reliability))
            allAtLeast40(CarComponent.values().map { component -> it.componentReliability(component) }.toIntArray())
        }
        assertTrue(built.teamAverageOverall >= 40)
    }
}
