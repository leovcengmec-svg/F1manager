package com.f1teammanager

import org.junit.Assert.*
import org.junit.Test
import java.io.File

/**
 * V435 completion gate for the integrated season boundary.
 * These are source-contract tests; the real Android/JUnit run belongs to final validation.
 */
class SeasonTransitionV435CompletionContractTest {
    private val root = File(".")
    private fun source(path: String) = File(root, path).readText()

    @Test fun everyCanonicalSubsystemIsPersistedBeforeCommitPoint() {
        val main = source("app/src/main/java/com/f1teammanager/MainActivity.kt")
        val transition = main.substringAfter("fun startNextSeason() {")
            .substringBefore("fun startDriverDevelopment(")
        val required = listOf(
            "store.saveCar(teamId, managerState.car)",
            "store.saveGarage(teamId,",
            "store.saveFacilities(teamId, managerState.facilities)",
            "store.saveTechnicalInvestment(teamId, managerState.technicalInvestment)",
            "store.saveResearch(teamId, managerState.research)",
            "store.saveFactory(teamId, managerState.factory)",
            "store.saveDriverDevelopment(teamId, managerState.driverDevelopment)",
            "store.saveDriverMarket(managerState.driverMarket)",
            "store.saveFinance(teamId, managerState.finance)",
            "store.saveSponsors(teamId, managerState.sponsors)"
        )
        val positions = required.map { transition.indexOf(it) }
        assertTrue("a canonical subsystem is not persisted", positions.all { it >= 0 })
        val commit = transition.indexOf("markSeasonTransitionStage(\"STATE_PERSISTED\")")
        assertTrue("durable commit point is missing", commit > 0)
        assertTrue("some subsystem is saved after the commit point", positions.all { it < commit })
    }

    @Test fun rollbackIsForbiddenAfterDurableCommitAndRestoresBeforeIt() {
        val store = source("app/src/main/java/com/f1teammanager/CareerPreferences.kt")
        val rollback = store.substringAfter("fun rollbackSeasonTransitionJournal(): Boolean {")
            .substringBefore("fun completeSeasonTransitionJournal()")
        assertTrue(rollback.contains("if (pending.third == \"STATE_PERSISTED\") return false"))
        assertTrue(rollback.contains("restoreCareerSeasonTransitionSnapshot()"))
        assertTrue(rollback.indexOf("restoreCareerSeasonTransitionSnapshot()") <
            rollback.indexOf("prefsSnapshot().edit().clear().commit()"))
    }

    @Test fun overallInvestmentReferenceCoversEveryIntegerFrom40To100() {
        val engine = source("app/src/main/java/com/f1teammanager/core/manager/CarDevelopmentEngine.kt")
        val body = engine.substringAfter("fun referenceInvestmentForOverall(overall: Int): Long {")
            .substringBefore("fun nextSeasonForecast(")
        val values = Regex("\\d[\\d_]*L").findAll(body).map { it.value }.toList()
        assertEquals("must define 61 individual Overall references", 61, values.size)
        assertTrue(body.contains("overall.coerceIn(40, 100) - 40"))
        assertTrue(values.first().contains("8_000_000"))
        assertTrue(values.last().contains("150_000_000"))
    }

    @Test fun officialPackageMetadataAndAssetsArePreserved() {
        val gradle = source("app/build.gradle.kts")
        assertTrue(gradle.contains("versionCode = 443"))
        assertTrue(gradle.contains("versionName = \"0.443.0\""))
        val assets = File("app/src/main/assets")
        assertTrue(assets.exists())
        assertTrue(assets.walkTopDown().count { it.isFile } >= 193)
        assertTrue(File("CHANGELOG.md").isFile)
    }
}
