package com.f1teammanager

import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class ComponentSpecificImagesV522Test {
    @Test fun allSixComponentsHaveDedicatedAssetsAndMappings() {
        val source = File("src/main/java/com/f1teammanager/MainActivity.kt").readText()
        val names = listOf("component_engine.webp", "component_chassis.webp", "component_front_wing.webp",
            "component_rear_wing.webp", "component_brakes.webp", "component_ers.webp")
        names.forEach { assertTrue("Missing component illustration: $it", File("src/main/res/drawable-nodpi/$it").isFile) }
        assertTrue(source.contains("private fun componentImageResource"))
        listOf("R.drawable.component_engine", "R.drawable.component_chassis", "R.drawable.component_front_wing",
            "R.drawable.component_rear_wing", "R.drawable.component_brakes", "R.drawable.component_ers")
            .forEach { assertTrue("Missing resource mapping: $it", source.contains(it)) }
    }

    @Test fun newResearchCardsUseFullBleedImageWithDarkOverlay() {
        val source = File("src/main/java/com/f1teammanager/MainActivity.kt").readText()
        assertTrue(source.contains("modifier = Modifier.fillMaxSize().clip(RoundedCornerShape(11.dp))"))
        assertTrue(source.contains("Brush.horizontalGradient"))
        assertTrue(source.contains("painterResource(componentImageResource(component))"))
    }
}
