package com.f1teammanager

import com.f1teammanager.core.season.WorldDatabase
import org.junit.Test
import org.junit.Assert.*

class SeasonTransitionV35Test {
    @Test fun finalRoundDoesNotAdvanceYear() {
        // Static source-level contract: GP 30 must remain on the same season
        // until startNextSeason is explicitly invoked.
        val source = java.io.File("src/main/java/com/f1teammanager/CareerPreferences.kt").readText()
        assertTrue(source.contains("fun isSeasonEnded()"))
        assertTrue(source.contains("fun startNextSeason()"))
        assertTrue(source.contains("history.finalizeSeason(season, driverPoints(), constructorPoints())"))
        val complete = source.substringAfter("fun completeCurrentRace()").substringBefore("/** Explicit player action")
        assertFalse(complete.contains("season +="))
    }

    @Test fun calendarDatesMustUseCurrentSeason() {
        val source = java.io.File("src/main/java/com/f1teammanager/MainActivity.kt").readText()
        assertTrue(source.contains("seasonDateLabel(round, store.season)"))
        assertTrue(source.contains("HeaderBlock(\"CALENDÁRIO $season\""))
    }

    @Test fun hallChampionsMustUseChampionLedger() {
        val source = java.io.File("src/main/java/com/f1teammanager/HistoricalDatabase.kt").readText()
        val drivers = source.substringAfter("HallScope.DRIVERS").substringBefore("HallScope.CONSTRUCTORS")
        val constructors = source.substringAfter("HallScope.CONSTRUCTORS").substringBefore("fun clear()")
        assertTrue(drivers.contains("driverChampions().count"))
        assertTrue(constructors.contains("constructorChampions().count"))
    }
}
