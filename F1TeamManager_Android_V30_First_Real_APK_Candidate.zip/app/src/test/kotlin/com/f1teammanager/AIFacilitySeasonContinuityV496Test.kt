package com.f1teammanager

import com.f1teammanager.core.manager.*
import com.f1teammanager.core.season.WorldDatabase
import org.junit.Assert.assertEquals
import org.junit.Test

/** Regression for live AI facility levels being overwritten by historical season replay. */
class AIFacilitySeasonContinuityV496Test {
    @Test fun persistedFacilityLevelsSurviveNextSeasonSimulation() {
        val team = WorldDatabase.teams.first { it.id != 1 }
        val levels = FacilityType.values().associateWithIndexedLevel()
        val persisted = TeamFacilitiesState(levels)

        val result = AITeamDevelopmentEngine(496001, 496002).simulateFinancial(
            team = team,
            elapsedWeeks = 0,
            season = 2028,
            startingBudget = 100_000_000L,
            startingFacilities = persisted
        )

        FacilityType.values().forEach { type ->
            assertEquals("${type.name} must retain the persisted level at season start", persisted.level(type), result.facilities.level(type))
        }
    }

    @Test fun aiFinanceSnapshotRoundTripKeepsFacilityLevelsAcrossSeasonBoundary() {
        val team = WorldDatabase.teams.first { it.id != 1 }
        val finance = AITeamFinancialEngine(496003)
        finance.beginSeason(team.id, 2026, DriverMarketEngine().initialState(2026))
        val persisted = TeamFacilitiesState(FacilityType.values().associateWithIndexedLevel())
        finance.setFacilities(team.id, persisted)

        val restored = AITeamFinancialEngine(496004)
        restored.restoreSnapshot(finance.exportSnapshot())
        restored.beginSeason(team.id, 2027, DriverMarketEngine().initialState(2027))

        FacilityType.values().forEach { type ->
            assertEquals("${type.name} must survive snapshot restore and beginSeason", persisted.level(type), restored.facilities(team.id).level(type))
        }
    }


    @Test fun facilityLedgerPersistsEvenBeforeFinancialStateExists() {
        val team = WorldDatabase.teams.first { it.id != 1 }
        val source = AITeamFinancialEngine(496005)
        val persisted = TeamFacilitiesState(FacilityType.values().associateWithIndexedLevel())
        // Simulates an annual event or migration writing facilities before a finance
        // row exists for this team. The facility ledger must still be serialized.
        source.setFacilities(team.id, persisted)
        val restored = AITeamFinancialEngine(496006)
        restored.restoreSnapshot(source.exportSnapshot())
        FacilityType.values().forEach { type ->
            assertEquals("${type.name} must survive independently of a finance row", persisted.level(type), restored.facilities(team.id).level(type))
        }
    }

    @Test fun snapshotKeepsFacilityLevelsAndSeasonLedgersInExtendedRecord() {
        val team = WorldDatabase.teams.first { it.id != 1 }
        val source = AITeamFinancialEngine(496007)
        source.beginSeason(team.id, 2026, DriverMarketEngine().initialState(2026))
        val persisted = TeamFacilitiesState(FacilityType.values().associateWithIndexedLevel())
        source.setFacilities(team.id, persisted)
        val snapshot = source.exportSnapshot()
        val financialRow = snapshot.lineSequence().first { it.startsWith("S|${team.id}|") }
        assertEquals("The financial row must retain all 32 serialized fields", 32, financialRow.split("|").size)
        val restored = AITeamFinancialEngine(496008)
        restored.restoreSnapshot(snapshot)
        restored.beginSeason(team.id, 2027, DriverMarketEngine().initialState(2027))
        FacilityType.values().forEach { type ->
            assertEquals("${type.name} must survive an extended snapshot round-trip", persisted.level(type), restored.facilities(team.id).level(type))
        }
    }

    private fun Array<FacilityType>.associateWithIndexedLevel(): Map<FacilityType, Int> =
        mapIndexed { index, type -> type to (index + 3).coerceAtMost(10) }.toMap()
}
