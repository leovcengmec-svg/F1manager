package com.f1teammanager

import com.f1teammanager.core.manager.DriverMarketState
import com.f1teammanager.core.manager.DriverMarketWindowNotificationPolicy
import com.f1teammanager.core.manager.MarketNewsCategory
import com.f1teammanager.core.manager.MarketNotification
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class DriverMarketWindowHomeEventV615Test {
    @Test fun closedWindowDoesNotCreateEvent() {
        val state = DriverMarketState()
        val result = DriverMarketWindowNotificationPolicy.ensureOpeningNotice(
            state, season = 2026, currentWeek = 19, isMarketOpen = false, playerTeamName = "Equipe Azul"
        )
        assertEquals(state, result)
        assertTrue(result.notifications.isEmpty())
    }

    @Test fun openingCreatesPlayerCareerEventWithMarketCategory() {
        val result = DriverMarketWindowNotificationPolicy.ensureOpeningNotice(
            DriverMarketState(), season = 2026, currentWeek = 21, isMarketOpen = true, playerTeamName = "Equipe Azul"
        )
        val event = result.notifications.single()
        assertEquals(DriverMarketWindowNotificationPolicy.OPEN_TITLE, event.title)
        assertEquals(21, event.week)
        assertEquals(MarketNewsCategory.MARKET, event.category)
        assertTrue(event.important)
        assertTrue(event.message.contains("Equipe Azul", ignoreCase = true))
    }

    @Test fun repeatedRecoveryDoesNotDuplicateOpeningNotice() {
        val first = DriverMarketWindowNotificationPolicy.ensureOpeningNotice(
            DriverMarketState(), season = 2026, currentWeek = 21, isMarketOpen = true, playerTeamName = "Equipe Azul"
        )
        val second = DriverMarketWindowNotificationPolicy.ensureOpeningNotice(
            first, season = 2026, currentWeek = 25, isMarketOpen = true, playerTeamName = "Equipe Azul"
        )
        assertEquals(first, second)
        assertEquals(1, second.notifications.count {
            it.season == 2026 && it.title == DriverMarketWindowNotificationPolicy.OPEN_TITLE
        })
    }

    @Test fun priorSeasonEventDoesNotSuppressNewSeasonOpening() {
        val previousSeasonEvent = MarketNotification(
            season = 2026, week = 21,
            title = DriverMarketWindowNotificationPolicy.OPEN_TITLE,
            message = "A janela de transferência da equipe Equipe Azul está aberta.",
            important = true, category = MarketNewsCategory.MARKET
        )
        val result = DriverMarketWindowNotificationPolicy.ensureOpeningNotice(
            DriverMarketState(notifications = listOf(previousSeasonEvent)),
            season = 2027, currentWeek = 21, isMarketOpen = true, playerTeamName = "Equipe Azul"
        )
        assertEquals(2, result.notifications.size)
        assertTrue(result.notifications.any { it.season == 2027 && it.title == DriverMarketWindowNotificationPolicy.OPEN_TITLE })
    }

    @Test fun doesNotRecreateAnAlreadyRecordedNotice() {
        val existing = MarketNotification(
            season = 2026, week = 21,
            title = DriverMarketWindowNotificationPolicy.OPEN_TITLE,
            message = "A janela de transferência da equipe Equipe Azul está aberta.", important = true, category = MarketNewsCategory.MARKET
        )
        val result = DriverMarketWindowNotificationPolicy.ensureOpeningNotice(
            DriverMarketState(notifications = listOf(existing)), 2026, 21, true, "Equipe Azul"
        )
        assertEquals(1, result.notifications.size)
        assertEquals(1, result.notifications.count { it.title == DriverMarketWindowNotificationPolicy.OPEN_TITLE })
    }
}
