package com.f1teammanager

import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class SeasonEndHighlightsV584Test {
    @Test fun highlightImagesAreCompactAndKeepAspectRatio() {
        val source = File("src/main/java/com/f1teammanager/SeasonEndEventScreen.kt").readText()
        assertTrue(source.contains("height(if (compact) 34.dp else 42.dp)"))
        assertTrue(source.contains("contentScale = ContentScale.Fit"))
        assertTrue(source.contains("Box("))
    }

    @Test fun longHighlightDescriptionsCanScrollInsideEachCard() {
        val source = File("src/main/java/com/f1teammanager/SeasonEndEventScreen.kt").readText()
        assertTrue(source.contains("verticalScroll(rememberScrollState())"))
        assertTrue(source.contains("item.description"))
        assertTrue(source.contains("Modifier.fillMaxWidth().weight(1f, fill = true).verticalScroll"))
    }
}
