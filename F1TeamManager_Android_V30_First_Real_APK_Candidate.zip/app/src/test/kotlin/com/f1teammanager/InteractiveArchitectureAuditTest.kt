package com.f1teammanager

import java.io.File

fun main() {
    val main = File("app/src/main/java/com/f1teammanager/MainActivity.kt").readText()
    check(main.contains("CareerWeekendEngine")) { "UI não usa o motor jogável canônico" }
    check(main.contains("AITeamFinancialEngine")) { "Fluxo interativo não integra finanças da IA" }
    check(main.contains("TeamSponsorshipEngine")) { "Fluxo interativo não integra patrocínios da IA" }
    check(main.contains("SeasonSettlementEngine.settleAll(store.constructorPoints())")) { "Fluxo interativo não usa a autoridade central de settlement" }
    check(main.contains("aiFinance.applyEndOfSeasonFinancialPenalty")) { "Penalidade financeira da IA não está ligada ao GP30 interativo" }
    check(!main.contains("RaceWeekendEngine(")) { "Fluxo interativo ainda chama engine de corrida legado" }
    check(!main.contains("RaceDecisionEngine(")) { "Fluxo interativo ainda chama engine de decisão legado" }
    println("INTERACTIVE_ARCHITECTURE_OK")
}
