package com.f1teammanager

import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class SeasonEndHighlightsV515Test {
    @Test fun fourStandardTitlesAreFixedAndSingleLine() {
        val source = File("src/main/java/com/f1teammanager/SeasonEndEventScreen.kt").readText()
        listOf("Títulos", "+ Vitórias", "GP + Abandonos", "+ Poles").forEach {
            assertTrue("Missing standard season highlight title: $it", source.contains("\\"$it\\""))
        }
        assertTrue(source.contains("maxLines = 1, softWrap = false"))
    }

    @Test fun allGenericSeasonIllustrationsExistAndAreWiredToUi() {
        val source = File("src/main/java/com/f1teammanager/SeasonEndEventScreen.kt").readText()
        val resources = listOf(
            "season_finale_generic.webp",
            "season_highlight_titles.webp",
            "season_highlight_wins.webp",
            "season_highlight_dnf.webp",
            "season_highlight_poles.webp"
        )
        resources.forEach { name ->
            assertTrue("Missing illustration asset: $name",
                File("src/main/res/drawable-nodpi/$name").isFile)
        }
        assertTrue(source.contains("R.drawable.season_finale_generic"))
        assertTrue(source.contains("R.drawable.season_highlight_titles"))
        assertTrue(source.contains("R.drawable.season_highlight_wins"))
        assertTrue(source.contains("R.drawable.season_highlight_dnf"))
        assertTrue(source.contains("R.drawable.season_highlight_poles"))
        assertTrue(source.contains("Image("))
    }

    @Test fun highlightsUseDedicatedIllustrationsInsteadOfTeamCar() {
        val source = File("src/main/java/com/f1teammanager/SeasonEndEventScreen.kt").readText()
        assertTrue(source.contains("val illustration = when (index)"))
        assertTrue(source.contains("painterResource(illustration)"))
        assertTrue(source.contains("Não usa carro/logotipo de uma equipe"))
    }
}
