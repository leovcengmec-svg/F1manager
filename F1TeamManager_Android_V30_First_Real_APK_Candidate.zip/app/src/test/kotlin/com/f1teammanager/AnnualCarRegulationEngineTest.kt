package com.f1teammanager

import com.f1teammanager.core.manager.AnnualCarRegulationEngine
import com.f1teammanager.core.manager.CarComponent
import org.junit.Assert.*
import org.junit.Test

class AnnualCarRegulationEngineTest {
    @Test fun catalogContainsThreeEventsForEachOfSixComponents() {
        val catalog = AnnualCarRegulationEngine.catalog()
        assertEquals(18, catalog.size)
        assertEquals(18, catalog.map { it.id }.distinct().size)
        CarComponent.values().forEach { component ->
            assertEquals("$component should have three events", 3, catalog.count { it.component == component })
        }
        assertTrue(catalog.all { it.reductionPercent in 5..10 })
    }

    @Test fun firstSeasonHasNoRegulationEventAndDrawsTheFirstCycle() {
        val rule = AnnualCarRegulationEngine.generate(1, 12345)
        assertTrue(rule.annualEvents.isEmpty())
        assertFalse(rule.decennialRevolution)
        assertTrue(rule.decennialReductions.isEmpty())
        assertTrue(rule.cycleLength in 6..10)
        assertEquals(1, rule.cycleStartSeason)
    }

    @Test fun annualDrawIsDeterministicAndCanSelectZeroOneOrTwoDistinctComponents() {
        val counts = mutableMapOf(0 to 0, 1 to 0, 2 to 0)
        (1..100).forEach { seed ->
            (2..80).forEach { season ->
                val first = AnnualCarRegulationEngine.generate(season, seed * 7919)
                val second = AnnualCarRegulationEngine.generate(season, seed * 7919)
                assertEquals(AnnualCarRegulationEngine.encode(first), AnnualCarRegulationEngine.encode(second))
                if (!first.decennialRevolution) {
                    assertTrue(first.annualEvents.size in 0..2)
                    assertEquals(first.annualEvents.size, first.annualEvents.map { it.component }.distinct().size)
                    counts[first.annualEvents.size] = counts.getValue(first.annualEvents.size) + 1
                } else {
                    assertTrue("A cycle revolution replaces the ordinary annual rule", first.annualEvents.isEmpty())
                }
            }
        }
        assertTrue("One annual change should be the most common result: $counts", counts.getValue(1) > counts.getValue(0))
        assertTrue("One annual change should be the most common result: $counts", counts.getValue(1) > counts.getValue(2))
        assertTrue("Zero changes should occur", counts.getValue(0) > 0)
        assertTrue("Two changes should occur", counts.getValue(2) > 0)
    }

    @Test fun differentCareerSeedsProduceDifferentAnnualSequences() {
        val firstCareer = (2027..2040).map { year ->
            AnnualCarRegulationEngine.encode(AnnualCarRegulationEngine.generateForCalendarYear(year, 135791))
        }
        val secondCareer = (2027..2040).map { year ->
            AnnualCarRegulationEngine.encode(AnnualCarRegulationEngine.generateForCalendarYear(year, 246802))
        }
        assertNotEquals("Different careers should not share the same full regulation sequence", firstCareer, secondCareer)
    }

    @Test fun cycleLengthIsDrawnFromSixToTenAndRedrawnAtEveryRevolution() {
        val seed = 20261005
        var cycleStart = 1
        repeat(8) {
            val length = AnnualCarRegulationEngine.cycleLengthForStart(cycleStart, seed)
            assertTrue(length in 6..10)
            val revolutionSeason = cycleStart + length
            val before = AnnualCarRegulationEngine.generate(revolutionSeason - 1, seed)
            assertFalse(before.decennialRevolution)
            assertEquals(cycleStart, before.cycleStartSeason)
            assertEquals(length, before.cycleLength)

            val revolution = AnnualCarRegulationEngine.generate(revolutionSeason, seed)
            assertTrue("Expected revolution at season $revolutionSeason", revolution.decennialRevolution)
            assertTrue(revolution.annualEvents.isEmpty())
            assertEquals(revolutionSeason, revolution.cycleStartSeason)
            assertEquals(AnnualCarRegulationEngine.cycleLengthForStart(revolutionSeason, seed), revolution.cycleLength)
            assertEquals(revolutionSeason + revolution.cycleLength,
                AnnualCarRegulationEngine.nextDecennialSeasonAfter(revolutionSeason, seed))
            assertEquals(CarComponent.values().toSet(), revolution.decennialReductions.keys)
            cycleStart = revolutionSeason
        }
    }

    @Test fun decennialSeasonHasOnlyDecennialRuleAndTeamSpecificRandomPenaltyIsStableAndBounded() {
        val seed = 20261005
        val revolutionSeason = AnnualCarRegulationEngine.nextDecennialSeasonAfter(1, seed)
        val rule = AnnualCarRegulationEngine.generate(revolutionSeason, seed)
        assertTrue(rule.decennialRevolution)
        assertTrue(rule.annualEvents.isEmpty())
        val penalties = (1..40).map { teamSeed ->
            val first = AnnualCarRegulationEngine.teamAdaptationReductionPercent(rule, teamSeed)
            assertEquals(first, AnnualCarRegulationEngine.teamAdaptationReductionPercent(rule, teamSeed))
            assertTrue(first in 0..8)
            first
        }
        assertTrue("Different teams should not all receive an identical penalty", penalties.distinct().size > 1)
        val ordinary = if (revolutionSeason < 200) revolutionSeason + 1 else revolutionSeason - 1
        assertEquals(0, AnnualCarRegulationEngine.teamAdaptationReductionPercent(AnnualCarRegulationEngine.generate(ordinary, seed), 123))
    }

    @Test fun encodedRuleRoundTripsAndRejectsUnknownEvents() {
        (1..80).forEach { season ->
            val original = AnnualCarRegulationEngine.generate(season, -765)
            val decoded = AnnualCarRegulationEngine.decode(AnnualCarRegulationEngine.encode(original))
            assertNotNull(decoded)
            assertEquals(original, decoded)
        }
        assertNull(AnnualCarRegulationEngine.decode("2|0|UNKNOWN"))
        val legacyDecennial = AnnualCarRegulationEngine.decode("11|1|MOT-01")
        assertNotNull(legacyDecennial)
        assertTrue("Old saved annual event must be ignored during decennial revolution", legacyDecennial!!.annualEvents.isEmpty())
    }
}
