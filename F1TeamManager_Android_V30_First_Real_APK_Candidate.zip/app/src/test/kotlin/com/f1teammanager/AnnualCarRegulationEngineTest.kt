package com.f1teammanager

import com.f1teammanager.core.manager.AnnualCarRegulationEngine
import com.f1teammanager.core.manager.CarComponent
import org.junit.Assert.*
import org.junit.Test

class AnnualCarRegulationEngineTest {
    @Test fun catalogContainsThreeEventsForEachOfSixComponents() {
        val catalog = AnnualCarRegulationEngine.catalog()
        assertEquals(18, catalog.size)
        assertEquals(18, catalog.map { it.id }.distinct().size)
        CarComponent.values().forEach { component ->
            assertEquals("$component should have three events", 3, catalog.count { it.component == component })
        }
        assertTrue(catalog.all { it.reductionPercent in 5..10 })
    }

    @Test fun firstSeasonHasNoRegulationEvent() {
        val rule = AnnualCarRegulationEngine.generate(1, 12345)
        assertTrue(rule.annualEvents.isEmpty())
        assertFalse(rule.decennialRevolution)
        assertTrue(rule.decennialReductions.isEmpty())
    }

    @Test fun annualDrawIsDeterministicAndTouchesOneOrTwoDistinctComponents() {
        (2..250).forEach { season ->
            val first = AnnualCarRegulationEngine.generate(season, 987654)
            val second = AnnualCarRegulationEngine.generate(season, 987654)
            assertEquals(AnnualCarRegulationEngine.encode(first), AnnualCarRegulationEngine.encode(second))
            if (first.decennialRevolution) {
                assertTrue("Decennial year must replace the annual rule", first.annualEvents.isEmpty())
            } else {
                assertTrue(first.annualEvents.size in 1..2)
            }
            assertEquals(first.annualEvents.size, first.annualEvents.map { it.component }.distinct().size)
        }
    }

    @Test fun differentCareerSeedsProduceDifferentAnnualSequences() {
        val firstCareer = (2027..2040).map { year ->
            AnnualCarRegulationEngine.encode(AnnualCarRegulationEngine.generateForCalendarYear(year, 135791))
        }
        val secondCareer = (2027..2040).map { year ->
            AnnualCarRegulationEngine.encode(AnnualCarRegulationEngine.generateForCalendarYear(year, 246802))
        }
        assertNotEquals("Different careers should not share the same full regulation sequence", firstCareer, secondCareer)
    }

    @Test fun decennialRevolutionStartsAfterTenCompletedSeasonsAndCoversAllComponents() {
        listOf(11, 21, 31, 41, 51).forEach { season ->
            val rule = AnnualCarRegulationEngine.generate(season, 12)
            assertTrue(rule.decennialRevolution)
            assertEquals(CarComponent.values().toSet(), rule.decennialReductions.keys)
            assertEquals(40, rule.decennialReductions[CarComponent.FRONT_WING])
            assertEquals(40, rule.decennialReductions[CarComponent.REAR_WING])
        }
        listOf(10, 12, 20, 22).forEach { season ->
            assertFalse(AnnualCarRegulationEngine.generate(season, 12).decennialRevolution)
        }
    }

    @Test fun decennialSeasonHasOnlyDecennialRuleAndTeamSpecificRandomPenaltyIsStableAndBounded() {
        val rule = AnnualCarRegulationEngine.generate(11, 20261005)
        assertTrue(rule.annualEvents.isEmpty())
        val penalties = (1..40).map { teamSeed ->
            val first = AnnualCarRegulationEngine.teamAdaptationReductionPercent(rule, teamSeed)
            assertEquals(first, AnnualCarRegulationEngine.teamAdaptationReductionPercent(rule, teamSeed))
            assertTrue(first in 0..8)
            first
        }
        assertTrue("Different teams should not all receive an identical penalty", penalties.distinct().size > 1)
        assertEquals(0, AnnualCarRegulationEngine.teamAdaptationReductionPercent(AnnualCarRegulationEngine.generate(12, 20261005), 123))
    }

    @Test fun encodedRuleRoundTripsAndRejectsUnknownEvents() {
        (1..40).forEach { season ->
            val original = AnnualCarRegulationEngine.generate(season, -765)
            val decoded = AnnualCarRegulationEngine.decode(AnnualCarRegulationEngine.encode(original))
            assertNotNull(decoded)
            assertEquals(original, decoded)
        }
        assertNull(AnnualCarRegulationEngine.decode("2|0|UNKNOWN"))
        val legacyDecennial = AnnualCarRegulationEngine.decode("11|1|MOT-01")
        assertNotNull(legacyDecennial)
        assertTrue("Old saved annual event must be ignored during decennial revolution", legacyDecennial!!.annualEvents.isEmpty())
    }
}
