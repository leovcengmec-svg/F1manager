package com.f1teammanager

import com.f1teammanager.core.season.DriverAgeCatalog
import com.f1teammanager.core.season.DriverEvolutionEngine
import com.f1teammanager.core.season.WorldDatabase
import org.junit.Assert.*
import org.junit.Test

class DriverAgeCatalogV701Test {
    @Test fun officialRosterHasOneHundredAgesAndMatchesDatabase() {
        assertEquals(100, DriverAgeCatalog.ageIn2026.size)
        WorldDatabase.allDrivers.forEach { driver -> assertNotNull("Missing age for ${driver.name}", DriverAgeCatalog.age(driver.name)) }
    }
    @Test fun agesAdvanceEachSeasonAndRestartAtEighteenAfterFortyThree() {
        val driver = WorldDatabase.allDrivers.first { it.name == "Lewis Hamilton" }
        assertEquals(33, DriverEvolutionEngine.careerAge(driver, 2026))
        assertEquals(34, DriverEvolutionEngine.careerAge(driver, 2027))
        assertEquals(43, DriverEvolutionEngine.careerAge(driver, 2036))
        assertEquals(18, DriverEvolutionEngine.careerAge(driver, 2037))
    }
}
