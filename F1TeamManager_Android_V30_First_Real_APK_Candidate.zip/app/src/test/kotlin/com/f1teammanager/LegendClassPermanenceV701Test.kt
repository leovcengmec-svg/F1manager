package com.f1teammanager

import com.f1teammanager.core.season.DriverClassProgressionEngine
import org.junit.Assert.*
import org.junit.Test

class LegendClassPermanenceV701Test {
    @Test fun legendCannotBeDemoted() {
        assertNull(DriverClassProgressionEngine.adjacentClass("Lenda", promote = false))
        val poor = DriverClassProgressionEngine.SeasonPerformance(2025, 20.0, 30)
        val latest = DriverClassProgressionEngine.SeasonPerformance(2026, 20.0, 30)
        val result = DriverClassProgressionEngine.evaluate("Lenda", 90, poor, latest, 30, false)
        assertEquals("Lenda", result.resultingClass)
        assertFalse(result.changed)
    }
}
