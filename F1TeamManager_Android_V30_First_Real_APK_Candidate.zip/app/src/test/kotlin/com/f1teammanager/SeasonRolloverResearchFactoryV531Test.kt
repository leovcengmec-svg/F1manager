package com.f1teammanager

import com.f1teammanager.core.manager.*
import org.junit.Assert.*
import org.junit.Test

class SeasonRolloverResearchFactoryV531Test {
    @Test fun newSeasonResearchStartsAtV1FromCurrentPhysicalCar() {
        val garage = TeamGarageFactory.fromCarState(
            TeamCarState(engine = 56, chassis = 54, frontWing = 52, rearWing = 53, brakes = 55, electricPowerUnit = 57),
            1, 2027
        )
        val state = TeamManagerState(
            season = 2027, round = 1,
            car = TeamCarState(engine = 56, chassis = 54, frontWing = 52, rearWing = 53, brakes = 55, electricPowerUnit = 57),
            garage = garage, finance = TeamFinanceState(1_000_000_000L), playerTeamId = 1
        )
        val result = ResearchEngine().start(state, CarComponent.ENGINE, ResearchFocus.PERFORMANCE, ResearchComplexity.SIMPLE, 1)
        val project = result.research.activeProjects.single()
        assertEquals(1, project.version)
        assertEquals(maxOf(garage.car1.engine, garage.car2.engine), project.basePerformance)
    }

    @Test fun newSeasonStateCanDiscardPriorSeasonResearchAndFactoryQueues() {
        val resetResearch = TeamResearchState()
        val resetFactory = TeamFactoryState()
        assertTrue(resetResearch.activeProjects.isEmpty())
        assertTrue(resetResearch.completedDesigns.isEmpty())
        assertTrue(resetResearch.cooldownUntil.isEmpty())
        assertTrue(resetFactory.activeOrders.isEmpty())
        assertTrue(resetFactory.pendingInstallations.isEmpty())
    }
}
