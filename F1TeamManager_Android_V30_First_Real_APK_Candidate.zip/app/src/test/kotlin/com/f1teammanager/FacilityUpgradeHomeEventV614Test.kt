package com.f1teammanager

import com.f1teammanager.core.manager.FacilityEngine
import com.f1teammanager.core.manager.FacilityType
import com.f1teammanager.core.manager.FacilityUpgradeNotificationPolicy
import com.f1teammanager.core.manager.MarketNewsCategory
import com.f1teammanager.core.manager.MarketNotification
import com.f1teammanager.core.manager.TeamFacilitiesState
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class FacilityUpgradeHomeEventV614Test {
    private val season = 2026
    private val playerTeam = "Equipe Azul"

    private fun started(type: FacilityType, from: Int, to: Int, week: Int = 1) = MarketNotification(
        season, week, FacilityUpgradeNotificationPolicy.STARTED_TITLE,
        "$playerTeam iniciou a melhoria de ${FacilityEngine.label(type)} do nível $from para $to. Prazo: 12 semanas.",
        true, MarketNewsCategory.TEAM_EVOLUTION
    )

    private fun facilities(type: FacilityType, level: Int) = TeamFacilitiesState(
        levels = FacilityType.values().associateWith { if (it == type) level else 0 }
    )

    @Test fun initiationIsNotMistakenForCompletion() {
        val notice = started(FacilityType.FACTORY, 2, 3)
        assertFalse(FacilityUpgradeNotificationPolicy.isCompletionNotice(notice))
        assertFalse(FacilityUpgradeNotificationPolicy.isPlayerCompletionNotice(notice, playerTeam, listOf(notice)))
    }

    @Test fun completedEventIsBoundToThePlayerTeam() {
        val notice = MarketNotification(
            season, 13, FacilityUpgradeNotificationPolicy.COMPLETED_TITLE,
            "$playerTeam: Fábrica concluída: nível 2 → 3 após 12 semanas.",
            true, MarketNewsCategory.TEAM_EVOLUTION
        )
        assertTrue(FacilityUpgradeNotificationPolicy.isPlayerCompletionNotice(notice, playerTeam, listOf(notice)))
        assertFalse(FacilityUpgradeNotificationPolicy.isPlayerCompletionNotice(notice, "Outra Equipe", listOf(notice)))
    }

    @Test fun legacyCompletionIsMatchedToPlayersStartNoticeIncludingDriverDevelopmentFacility() {
        val type = FacilityType.DRIVER_DEVELOPMENT
        val start = started(type, 2, 3)
        val completion = MarketNotification(
            season, 13, FacilityUpgradeNotificationPolicy.STARTED_TITLE,
            "${FacilityEngine.label(type)} concluída: nível 2 → 3 após 12 semanas.",
            true, MarketNewsCategory.TEAM_EVOLUTION
        )
        assertTrue(FacilityUpgradeNotificationPolicy.isCompletionNotice(completion))
        assertTrue(FacilityUpgradeNotificationPolicy.isPlayerCompletionNotice(completion, playerTeam, listOf(start, completion)))
        assertFalse(FacilityUpgradeNotificationPolicy.isPlayerCompletionNotice(completion, "Outra Equipe", listOf(start, completion)))
    }

    @Test fun lostCompletionNoticeIsRecoveredFromSavedFacilityLevel() {
        val type = FacilityType.DRIVER_DEVELOPMENT
        val start = started(type, 2, 3)
        val recovered = FacilityUpgradeNotificationPolicy.recoverMissingPlayerCompletionNotices(
            notifications = listOf(start), playerTeamName = playerTeam, season = season,
            currentWeek = 18, facilities = facilities(type, 3), activeUpgrade = null
        )
        assertEquals(1, recovered.size)
        assertEquals(FacilityUpgradeNotificationPolicy.COMPLETED_TITLE, recovered.single().title)
        assertTrue(recovered.single().message.contains("$playerTeam:"))
        assertTrue(recovered.single().message.contains("nível 2 → 3"))
    }

    @Test fun legacyCompletionGetsFreshPlayerSpecificNoticeForHomeCard() {
        val type = FacilityType.DRIVER_DEVELOPMENT
        val start = started(type, 2, 3)
        val legacy = MarketNotification(
            season, 13, FacilityUpgradeNotificationPolicy.STARTED_TITLE,
            "${FacilityEngine.label(type)} concluída: nível 2 → 3 após 12 semanas.",
            true, MarketNewsCategory.TEAM_EVOLUTION
        )
        val recovered = FacilityUpgradeNotificationPolicy.recoverMissingPlayerCompletionNotices(
            listOf(start, legacy), playerTeam, season, 18, facilities(type, 3), null
        )
        assertEquals(1, recovered.size)
        assertEquals(FacilityUpgradeNotificationPolicy.COMPLETED_TITLE, recovered.single().title)
        assertTrue(recovered.single().message.startsWith("$playerTeam:"))
    }

    @Test fun recoveryDoesNotRepeatKnownCompletionOrCompleteAnActiveUpgrade() {
        val type = FacilityType.FACTORY
        val start = started(type, 2, 3)
        val completion = MarketNotification(
            season, 13, FacilityUpgradeNotificationPolicy.COMPLETED_TITLE,
            "$playerTeam: Fábrica concluída: nível 2 → 3 após 12 semanas.",
            true, MarketNewsCategory.TEAM_EVOLUTION
        )
        val known = FacilityUpgradeNotificationPolicy.recoverMissingPlayerCompletionNotices(
            listOf(start, completion), playerTeam, season, 13, facilities(type, 3), null
        )
        assertTrue(known.isEmpty())

        val active = com.f1teammanager.core.manager.FacilityUpgradeState(
            facility = type, previousLevel = 2, targetLevel = 3,
            remainingWeeks = 5, totalWeeks = 12, cost = 1_000_000L,
            startedSeason = season, startedWeek = 1
        )
        val notDone = FacilityUpgradeNotificationPolicy.recoverMissingPlayerCompletionNotices(
            listOf(start), playerTeam, season, 8, facilities(type, 3), active
        )
        assertTrue(notDone.isEmpty())
    }
}
