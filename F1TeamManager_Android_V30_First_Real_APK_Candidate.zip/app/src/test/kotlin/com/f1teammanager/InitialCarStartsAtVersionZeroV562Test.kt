package com.f1teammanager

import com.f1teammanager.core.manager.*
import com.f1teammanager.core.season.WorldDatabase
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** Regression tests for V562: V0 is the base PIECE VERSION, not car performance zero. */
class InitialCarStartsAtVersionZeroV562Test {
    @Test fun newCareerCarsUseTeamOpeningPerformanceAndPieceVersionV0() {
        val team = WorldDatabase.teams.first()
        val profile = InitialTeamProfile.values(team)
        val garage = TeamGarageFactory.fromInitial(team, playerCareer = true)
        for (car in listOf(garage.car1, garage.car2)) {
            assertEquals(profile.engine, car.engine)
            assertEquals(profile.chassis, car.chassis)
            assertEquals(profile.frontWing, car.frontWing)
            assertEquals(profile.rearWing, car.rearWing)
            assertEquals(profile.brakes, car.brakes)
            assertEquals(profile.electricPowerUnit, car.electricPowerUnit)
            assertEquals(6, car.installedPieces.size)
            assertEquals(6, car.installedPieceVersions.size)
            assertTrue("all base pieces must start at V0", car.installedPieceVersions.values.all { it == 0 })
            assertTrue("base hardware has explicit baseline IDs", car.installedPieces.values.all { it.contains("V0") })
        }
        assertEquals(profile.overall, garage.car1.overall)
        assertEquals(profile.overall, garage.car2.overall)
        assertEquals(profile.overall, garage.teamAverageOverall)
    }

    @Test fun playerAndAiBeginWithTheSameTeamPerformanceButPieceVersionZero() {
        val team = WorldDatabase.teams.first()
        val profile = InitialTeamProfile.values(team)
        val playerGarage = TeamGarageFactory.fromInitial(team, playerCareer = true)
        val aiGarage = TeamGarageFactory.fromInitial(team)
        assertEquals(profile.overall, playerGarage.teamAverageOverall)
        assertEquals(profile.overall, aiGarage.teamAverageOverall)
        assertEquals(profile.engine, InitialTeamProfile.carState(team).engine)
        assertEquals(InitialTeamProfile.carState(team).engine, InitialTeamProfile.aiCarState(team).engine)
        for (car in listOf(playerGarage.car1, playerGarage.car2, aiGarage.car1, aiGarage.car2)) {
            assertTrue(car.installedPieces.size == 6)
            assertTrue("initial piece versions must be V0", car.installedPieceVersions.values.all { it == 0 })
        }
    }

    @Test fun researchStartsAtV1FromTeamBaseAndDoesNotImmediatelyChangeThePhysicalCar() {
        val team = WorldDatabase.teams.first()
        val garage = TeamGarageFactory.fromInitial(team, playerCareer = true)
        val before = garage.car1.engine
        val state = TeamManagerState(
            season = 2026,
            round = 1,
            playerTeamId = team.id,
            car = InitialTeamProfile.carState(team),
            garage = garage,
            facilities = InitialTeamProfile.teamFacilities(team.initialLevel),
            finance = TeamFinanceState(InitialTeamProfile.initialBudget(team)),
            research = TeamResearchState()
        )
        val started = ResearchEngine().start(state, CarComponent.ENGINE, ResearchFocus.PERFORMANCE, ResearchComplexity.MEDIUM, 1)
        assertEquals("research start must not change physical performance", before, started.garage!!.car1.engine)
        assertEquals(1, started.research.activeProjects.single().version)
        assertEquals(0, started.garage!!.car1.installedPieceVersions[CarComponent.ENGINE])
    }

    @Test fun annualRegulationPreservesBasePerformanceAndV0HardwareMetadata() {
        val team = WorldDatabase.teams.first()
        val garage = TeamGarageFactory.fromInitial(team, playerCareer = true)
        val regulated = AnnualCarRegulationEngine.applyToGarage(garage,
            AnnualCarRegulationEngine.generate(11, 99), team.id)
        for (car in listOf(regulated.car1, regulated.car2)) {
            assertTrue("baseline component performance remains team-level", car.overall > 0)
            assertEquals(6, car.installedPieces.size)
            assertTrue(car.installedPieceVersions.values.all { it == 0 })
        }
    }

    @Test fun raceInfluenceProgressesAcrossThePerformanceScale() {
        assertEquals(1, com.f1teammanager.core.race.CarComponentInfluence.level(0))
        assertEquals(1, com.f1teammanager.core.race.CarComponentInfluence.level(10))
        assertEquals(2, com.f1teammanager.core.race.CarComponentInfluence.level(50))
        assertEquals(10, com.f1teammanager.core.race.CarComponentInfluence.level(100))
    }
}
