package com.f1teammanager

import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/** V497: season overview must not replace progressed teams with career-start defaults. */
class TeamOverviewSeasonProgressV497Test {
    @Test fun overviewUsesInitialTeamsOnlyAtFirstCareerOpening() {
        val source = File("app/src/main/java/com/f1teammanager/MainActivity.kt").readText()
        assertTrue(source.contains("currentWeek <= 1 && season <= 2026"))
        assertTrue(source.contains("currentWeek <= 1 && store.season <= 2026"))
        assertTrue(source.contains("if (currentWeek <= 1 && store.season <= 2026)"))
    }

    @Test fun laterSeasonOverviewKeepsAiFacilityLedgerWhenSimulationIsSkipped() {
        val source = File("app/src/main/java/com/f1teammanager/MainActivity.kt").readText()
        assertTrue(source.contains("else aiFinance.facilities(team.id)"))
        assertTrue(source.contains("else aiFinance.facilities(t.id)"))
    }
}
