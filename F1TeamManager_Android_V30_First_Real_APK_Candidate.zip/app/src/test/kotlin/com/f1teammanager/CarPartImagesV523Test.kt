package com.f1teammanager

import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class CarPartImagesV523Test {
    @Test fun currentCarComponentCardsUseTheirDedicatedPAndDImages() {
        val source = File("src/main/java/com/f1teammanager/MainActivity.kt").readText()
        val start = source.indexOf("private fun CarPartMiniCard")
        val end = source.indexOf("@Composable\\nprivate fun MiniAverage", start)
        assertTrue("Car part card function missing", start >= 0 && end > start)
        val card = source.substring(start, end)
        assertTrue(card.contains("painterResource(componentImageResource(part.component))"))
        assertTrue(card.contains("Modifier.fillMaxSize()"))
        assertTrue(card.contains("ContentScale.Crop"))
        assertTrue(card.contains("Brush.verticalGradient"))
        listOf("component_engine.webp", "component_chassis.webp", "component_front_wing.webp",
            "component_rear_wing.webp", "component_brakes.webp", "component_ers.webp").forEach {
            assertTrue("Missing component image $it", File("src/main/res/drawable-nodpi/$it").isFile)
        }
    }
}
