package com.f1teammanager

import com.f1teammanager.core.manager.DriverMarketHomeNotificationPolicy
import com.f1teammanager.core.manager.MarketNotification
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class DriverMarketNegotiationHomeEventsV686Test {
    @Test fun homeShowsEveryCompletedAiSignatureGlobally() {
        val teamA = MarketNotification(2028, 1, "TRANSFERÊNCIA CONFIRMADA", "Piloto A mudou da equipe Alpha para Beta. Contrato assinado para 2028.")
        val teamB = MarketNotification(2028, 2, "RENOVAÇÃO DE CONTRATO", "Piloto B renovou contrato com Gamma para a temporada 2029.")
        val freeAgent = MarketNotification(2028, 3, "CONTRATO ASSINADO", "Piloto C assinou contrato com Delta para a temporada 2029.")
        assertTrue(DriverMarketHomeNotificationPolicy.shouldShowOnHome(teamA, "Ferrari"))
        assertTrue(DriverMarketHomeNotificationPolicy.shouldShowOnHome(teamB, "Ferrari"))
        assertTrue(DriverMarketHomeNotificationPolicy.shouldShowOnHome(freeAgent, "Ferrari"))
    }

    @Test fun detailedNegotiationStagesAreExclusiveToThePlayerTeam() {
        val playerCounter = MarketNotification(2028, 12, "CONTRAPROPOSTA RECEBIDA", "Piloto X enviou contraproposta para Ferrari.")
        val rivalCounter = MarketNotification(2028, 12, "CONTRAPROPOSTA RECEBIDA", "Piloto Y enviou contraproposta para McLaren.")
        assertTrue(DriverMarketHomeNotificationPolicy.shouldShowOnHome(playerCounter, "Ferrari"))
        assertFalse(DriverMarketHomeNotificationPolicy.shouldShowOnHome(rivalCounter, "Ferrari"))
    }

    @Test fun playerRejectionsAndExpiredIncomingOffersIdentifyThePlayerTeam() {
        val source = java.io.File("app/src/main/java/com/f1teammanager/core/manager/DriverMarketEngine.kt").readText()
        assertTrue(source.contains("piloto da \${teamName(offer.fromTeamId)}"))
        assertTrue(source.contains("playerTeamId"))
        val main = java.io.File("app/src/main/java/com/f1teammanager/MainActivity.kt").readText()
        assertTrue(main.contains("DriverMarketHomeNotificationPolicy.shouldShowOnHome(notice, team)"))
    }
}
