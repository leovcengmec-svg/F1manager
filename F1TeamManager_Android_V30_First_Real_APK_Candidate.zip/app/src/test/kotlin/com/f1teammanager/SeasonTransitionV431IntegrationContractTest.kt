package com.f1teammanager

import org.junit.Assert.*
import org.junit.Test
import java.io.File

/** V431: cross-subsystem source-contract checks for the complete season boundary. */
class SeasonTransitionV431IntegrationContractTest {
    private fun source(path: String) = File(path).readText()

    @Test fun manualTransitionOrdersRegressionCarBuildAndAnnualCapRefresh() {
        val main = source("app/src/main/java/com/f1teammanager/MainActivity.kt")
        val fn = main.substringAfter("fun startNextSeason() {").substringBefore("fun startDriverDevelopment(")
        val ordered = listOf(
            "store.applySeasonEndRegression(closingSeason)",
            "store.startNextSeason()",
            "development.startNextSeason(managerState, store.season)",
            "TechnicalInvestmentEngine.forTeam(",
            "store.saveTechnicalInvestment(teamId, managerState.technicalInvestment)"
        ).map { fn.indexOf(it) }
        assertTrue("transition call missing", ordered.all { it >= 0 })
        assertTrue("transition ordering invalid", ordered.zipWithNext().all { (a, b) -> a < b })
    }

    @Test fun allOverallReferencesAreExplicitAndSharedWithActualCarTransition() {
        val engine = source("app/src/main/java/com/f1teammanager/core/manager/CarDevelopmentEngine.kt")
        assertTrue(engine.contains("fun referenceInvestmentForOverall(overall: Int): Long"))
        assertTrue(engine.contains("referencesByOverall[overall.coerceIn(40, 100) - 40]"))
        assertTrue(engine.contains("val investmentSteps = nextSeasonInvestmentSteps(overall, old.nextSeasonInvestment)"))
        assertTrue(engine.contains("nextSeasonInvestment = 0L"))
        assertTrue(engine.contains("nextSeasonInvestmentSteps(overall, invested)"))
    }

    @Test fun canonicalWritesAreAllBeforeStatePersistedAndJournalCleanup() {
        val main = source("app/src/main/java/com/f1teammanager/MainActivity.kt")
        val fn = main.substringAfter("fun startNextSeason() {").substringBefore("fun startDriverDevelopment(")
        val writes = listOf(
            "store.saveCar(teamId, managerState.car)",
            "store.saveGarage(teamId, managerState.garage",
            "store.saveFacilities(teamId, managerState.facilities)",
            "store.saveTechnicalInvestment(teamId, managerState.technicalInvestment)",
            "store.saveResearch(teamId, managerState.research)",
            "store.saveFactory(teamId, managerState.factory)",
            "store.saveDriverDevelopment(teamId, managerState.driverDevelopment)",
            "store.saveDriverMarket(managerState.driverMarket)",
            "store.saveFinance(teamId, managerState.finance)",
            "store.saveSponsors(teamId, managerState.sponsors)",
            "markSeasonTransitionStage(\"STATE_PERSISTED\")",
            "completeSeasonTransitionJournal()"
        ).map { fn.indexOf(it) }
        assertTrue("missing canonical write or finalization", writes.all { it >= 0 })
        assertTrue("canonical writes/finalization out of order", writes.zipWithNext().all { (a, b) -> a < b })
    }

    @Test fun interruptionRecoveryHasDistinctCommittedAndRollbackPaths() {
        val prefs = source("app/src/main/java/com/f1teammanager/CareerPreferences.kt")
        val main = source("app/src/main/java/com/f1teammanager/MainActivity.kt")
        assertTrue(prefs.contains("snapshotCareerForSeasonTransition()"))
        assertTrue(prefs.contains("restoreCareerSeasonTransitionSnapshot()"))
        assertTrue(prefs.contains("stage == \"STATE_PERSISTED\""))
        assertTrue(main.contains("if (pendingTransition.third == \"STATE_PERSISTED\")"))
        assertTrue(main.contains("Virada interrompida detectada"))
    }
}
