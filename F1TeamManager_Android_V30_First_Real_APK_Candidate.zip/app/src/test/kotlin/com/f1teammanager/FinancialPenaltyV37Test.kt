package com.f1teammanager

import com.f1teammanager.core.manager.*

fun main() {
    val car = TeamCarState(100, 90, 80, 70, frontWing=75, rearWing=65, brakes=55, electricPowerUnit=85)
    val state = TeamManagerState(car=car, finance=TeamFinanceState(-10_000_000))
    val out = FinancialSeasonClosureEngine.applyPlayerPenalty(state)
    check(out.car.engine == 64)
    check(out.car.chassis == 72)
    check(out.car.frontWing == 60)
    check(out.car.rearWing == 52)
    check(out.car.brakes == 44)
    check(out.car.electricPowerUnit == 68)
    check(FinancialSeasonClosureEngine.applyPlayerPenalty(state.copy(finance=TeamFinanceState(1))).car == car)
    println("FinancialPenaltyV37Test: PASS")
}
