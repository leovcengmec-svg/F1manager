package com.f1teammanager

import com.f1teammanager.core.race.Tyre
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class HistoricalRecordsEngineV713Test {
    private fun race(
        season: Int = 2026, round: Int, driverId: Int, driver: String,
        teamId: Int, team: String, position: Int, points: Int,
        circuit: String = "COTA", fastest: Boolean = false, fastestMs: Long = 90_000L,
        status: String = "FINISHED"
    ) = HistoricalDatabase.RaceRecord(
        season, round, "GP dos EUA", teamId, team, driverId, driver, position,
        points, 56, 5_400_000L, 0L, status, Tyre.MEDIUM, 1,
        fastestMs, fastest, circuit
    )

    @Test
    fun `career board aggregates official race and pole archive and preserves ties`() {
        val races = listOf(
            race(round = 1, driverId = 1, driver = "Driver A", teamId = 10, team = "Team A", position = 1, points = 25, fastest = true),
            race(round = 1, driverId = 2, driver = "Driver B", teamId = 20, team = "Team B", position = 2, points = 18),
            race(round = 2, driverId = 1, driver = "Driver A", teamId = 10, team = "Team A", position = 2, points = 18),
            race(round = 2, driverId = 2, driver = "Driver B", teamId = 20, team = "Team B", position = 1, points = 25)
        )
        val poles = listOf(
            HistoricalDatabase.PoleRecord(2026, 1, "GP dos EUA", 10, "Team A", 1, "Driver A", 90_000L, "COTA"),
            HistoricalDatabase.PoleRecord(2026, 2, "GP dos EUA", 20, "Team B", 2, "Driver B", 89_000L, "COTA")
        )
        val cards = HistoricalRecordsEngine.driverCareer(races, poles, emptyList())
        val wins = cards.first { it.title == "Vitórias na carreira" }
        assertEquals("1", wins.value)
        assertEquals(2, wins.holders.size)
        assertTrue(wins.note.contains("Empate"))
        val points = cards.first { it.title == "Pontos acumulados" }
        assertEquals("43", points.value)
    }

    @Test
    fun `team streak counts a GP once even when both team drivers are archived`() {
        val races = listOf(
            race(round = 1, driverId = 1, driver = "A1", teamId = 10, team = "Team A", position = 1, points = 25),
            race(round = 1, driverId = 2, driver = "A2", teamId = 10, team = "Team A", position = 4, points = 12),
            race(round = 2, driverId = 1, driver = "A1", teamId = 10, team = "Team A", position = 3, points = 15),
            race(round = 2, driverId = 2, driver = "A2", teamId = 10, team = "Team A", position = 1, points = 25)
        )
        val cards = HistoricalRecordsEngine.constructorCareer(races, emptyList(), emptyList())
        val streak = cards.first { it.title == "Maior sequência de vitórias" }
        assertEquals("2", streak.value)
        assertEquals("Team A", streak.holders.single().name)
    }

    @Test
    fun `circuit board separates venues that share the same grand prix name`() {
        val races = listOf(
            race(round = 1, driverId = 1, driver = "Austin Winner", teamId = 10, team = "Team A", position = 1, points = 25, circuit = "COTA"),
            race(round = 2, driverId = 2, driver = "Indy Winner", teamId = 20, team = "Team B", position = 1, points = 25, circuit = "Indianapolis GP")
        )
        val cota = HistoricalRecordsEngine.circuitCards("COTA", races, emptyList())
        val indy = HistoricalRecordsEngine.circuitCards("Indianapolis GP", races, emptyList())
        assertEquals("Austin Winner", cota.first { it.title == "Mais vitórias nesta pista" }.holders.single().name)
        assertEquals("Indy Winner", indy.first { it.title == "Mais vitórias nesta pista" }.holders.single().name)
    }

    @Test
    fun `season cards only show supplied finalized season summaries`() {
        val seasonRows = listOf(
            HistoricalDatabase.DriverSeasonRecord(2026, 1, 1, "Driver A", 10, "Team A", 300, 5, 4, 3, 1, 20),
            HistoricalDatabase.DriverSeasonRecord(2027, 1, 2, "Driver B", 20, "Team B", 350, 6, 5, 4, 0, 22)
        )
        val cards = HistoricalRecordsEngine.driverSeason(seasonRows.filter { it.season == 2026 }, emptyList())
        assertEquals("300", cards.first { it.title == "Mais pontos em uma temporada" }.value)
        assertEquals(2026, cards.first { it.title == "Mais pontos em uma temporada" }.holders.single().season)
    }

    @Test
    fun `season board calculates pole percentage and average points from official starts`() {
        val summary = listOf(
            HistoricalDatabase.DriverSeasonRecord(2026, 1, 1, "Driver A", 10, "Team A", 40, 1, 1, 0, 0, 2)
        )
        val races = listOf(
            race(round = 1, driverId = 1, driver = "Driver A", teamId = 10, team = "Team A", position = 1, points = 25),
            race(round = 2, driverId = 1, driver = "Driver A", teamId = 10, team = "Team A", position = 4, points = 15)
        )
        val cards = HistoricalRecordsEngine.driverSeason(summary, races)
        assertEquals("50.00", cards.first { it.title == "Maior aproveitamento de poles" }.value)
        assertEquals("20.00", cards.first { it.title == "Maior média de pontos por GP" }.value)
    }


    @Test
    fun `career record does not attribute a multi-team driver to an arbitrary single team`() {
        val races = listOf(
            race(round = 1, driverId = 1, driver = "Driver A", teamId = 10, team = "Team A", position = 1, points = 25),
            race(round = 2, driverId = 1, driver = "Driver A", teamId = 20, team = "Team B", position = 1, points = 25)
        )
        val wins = HistoricalRecordsEngine.driverCareer(races, emptyList(), emptyList())
            .first { it.title == "Vitórias na carreira" }
        assertEquals(2, wins.value.toInt())
        assertEquals("Múltiplas equipes", wins.holders.single().teamName)
        assertEquals(0, wins.holders.single().teamId)
    }

    @Test
    fun `milestones rebuild deterministically without writing or duplicating archive rows`() {
        val races = listOf(
            race(round = 1, driverId = 1, driver = "Driver A", teamId = 10, team = "Team A", position = 1, points = 25),
            race(round = 2, driverId = 1, driver = "Driver A", teamId = 10, team = "Team A", position = 1, points = 25)
        )
        val first = HistoricalRecordsEngine.recentMilestones(races, emptyList(), emptyList(), emptyList())
        val second = HistoricalRecordsEngine.recentMilestones(races, emptyList(), emptyList(), emptyList())
        assertEquals(first, second)
        assertTrue(first.any { it.title == "Recorde de vitórias" && it.value == 2 })
        assertEquals(first.size, first.distinct().size)
    }
}
