package com.f1teammanager

import com.f1teammanager.core.manager.AnnualCarRegulationEngine
import com.f1teammanager.core.manager.AnnualCarRegulationEventArt
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Test

class AnnualCarRegulationEventArtTest {
    @Test
    fun allEighteenAnnualRegulationEventsResolveToExistingGenericArtwork() {
        val catalog = AnnualCarRegulationEngine.catalog()
        assertEquals(18, catalog.size)
        assertEquals(18, catalog.map { it.id }.distinct().size)
        catalog.forEach { event ->
            assertNotEquals("Missing artwork for ${event.id}", 0, AnnualCarRegulationEventArt.drawableFor(event))
        }
        // Three events per component intentionally reuse that component's generic art.
        catalog.groupBy { it.component }.values.forEach { group ->
            assertEquals(1, group.map { AnnualCarRegulationEventArt.drawableFor(it) }.distinct().size)
        }
    }
}
