package com.f1teammanager

import org.junit.Assert.*
import org.junit.Test
import java.io.File

/** V434 source contract for pre-commit rollback and in-memory resynchronization. */
class SeasonTransitionV434RollbackTest {
    @Test fun rollbackIsForbiddenAfterDurableCommitAndRestoresBeforeCleanup() {
        val prefs = File("app/src/main/java/com/f1teammanager/CareerPreferences.kt").readText()
        val body = prefs.substringAfter("fun rollbackSeasonTransitionJournal(): Boolean {")
            .substringBefore("fun completeSeasonTransitionJournal(): Boolean {")
        assertTrue(body.contains("pending.third == \"STATE_PERSISTED\""))
        assertTrue(body.indexOf("restoreCareerSeasonTransitionSnapshot()") >= 0)
        assertTrue(body.indexOf("restoreCareerSeasonTransitionSnapshot()") < body.indexOf("prefsSnapshot().edit().clear().commit()"))
    }

    @Test fun failedPreCommitTransitionRebuildsMemoryFromRestoredStore() {
        val main = File("app/src/main/java/com/f1teammanager/MainActivity.kt").readText()
        val body = main.substringAfter("fun startNextSeason() {").substringBefore("fun startDriverDevelopment(")
        assertTrue(body.contains("store.rollbackSeasonTransitionJournal()"))
        assertTrue(body.contains("val restoredCar = store.loadCar(teamId)"))
        assertTrue(body.contains("managerState = initialManagerState(teamId, store)"))
        assertTrue(body.contains("pending.third != \"STATE_PERSISTED\""))
    }
}
