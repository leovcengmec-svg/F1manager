package com.f1teammanager

import org.junit.Assert.*
import org.junit.Test
import java.io.File

/** V430 source-contract audit for the manual season boundary and recovery snapshot. */
class SeasonTransitionV430AuditTest {
    private fun source(path: String) = File(path).readText()

    @Test fun seasonBoundaryRequiresCompletedSeasonAndResetsCalendar() {
        val src = source("app/src/main/java/com/f1teammanager/CareerPreferences.kt")
        val fn = src.substringAfter("fun startNextSeason() {").substringBefore("/** Advance one or more real calendar weeks")
        assertTrue(fn.contains("require(isSeasonEnded())"))
        assertTrue(fn.contains("season += 1"))
        assertTrue(fn.contains("roundIndex = 0"))
        assertTrue(fn.contains("currentWeek = 1"))
        assertTrue(fn.contains("newCalendarSeed(season)"))
        assertTrue(fn.contains("nextSeasonInvestment" ) || src.contains("nextSeasonInvestment"))
    }

    @Test fun annualCapIsRecomputedAfterNewCarAndBeforePersistence() {
        val src = source("app/src/main/java/com/f1teammanager/MainActivity.kt")
        val fn = src.substringAfter("fun startNextSeason() {").substringBefore("fun startDriverDevelopment(")
        val carBuild = fn.indexOf("development.startNextSeason(managerState, store.season)")
        val capRefresh = fn.indexOf("TechnicalInvestmentEngine.forTeam(")
        val saveAnnualController = fn.indexOf("store.saveTechnicalInvestment(teamId, managerState.technicalInvestment)")
        assertTrue("new car must be built", carBuild >= 0)
        assertTrue("annual cap must be refreshed after new car", capRefresh > carBuild)
        assertTrue("refreshed controller must be persisted", saveAnnualController > capRefresh)
    }

    @Test fun seasonTransitionPersistsCanonicalCarAndGarageAndFinance() {
        val src = source("app/src/main/java/com/f1teammanager/MainActivity.kt")
        val fn = src.substringAfter("fun startNextSeason() {").substringBefore("fun startDriverDevelopment(")
        listOf("store.saveCar(teamId, managerState.car)",
            "store.saveGarage(teamId, managerState.garage",
            "store.saveFinance(teamId, managerState.finance)",
            "store.saveDriverMarket(managerState.driverMarket)",
            "store.saveSponsors(teamId, managerState.sponsors)").forEach {
                assertTrue("missing season-boundary persistence: $it", fn.contains(it))
            }
    }

    @Test fun transitionHasDurableJournalAndBlocksUnsafeReplay() {
        val prefs = source("app/src/main/java/com/f1teammanager/CareerPreferences.kt")
        val main = source("app/src/main/java/com/f1teammanager/MainActivity.kt")
        assertTrue(prefs.contains("beginSeasonTransitionJournal"))
        assertTrue(prefs.contains("seasonTransitionPendingFrom"))
        assertTrue(prefs.contains("markSeasonTransitionStage"))
        assertTrue(prefs.contains("completeSeasonTransitionJournal"))
        assertTrue(main.contains("Virada interrompida detectada"))
        assertTrue(main.contains("STATE_PERSISTED"))
        assertTrue(main.contains("completeSeasonTransitionJournal()"))
    }
    @Test fun journalTracksEachDurableSubsystemWriteInOrder() {
        val main = source("app/src/main/java/com/f1teammanager/MainActivity.kt")
        val fn = main.substringAfter("fun startNextSeason() {").substringBefore("fun startDriverDevelopment(")
        val stages = listOf(
            "MANAGER_STATE_READY", "CAR_SAVED", "GARAGE_SAVED", "FACILITIES_SAVED",
            "TECHNICAL_INVESTMENT_SAVED", "RESEARCH_SAVED", "FACTORY_SAVED",
            "DRIVER_DEVELOPMENT_SAVED", "MARKET_SAVED", "FINANCE_SAVED", "SPONSORS_SAVED", "STATE_PERSISTED"
        )
        var previous = -1
        stages.forEach { stage ->
            val index = fn.indexOf("markSeasonTransitionStage(\"$stage\")")
            assertTrue("missing or out-of-order journal stage $stage", index > previous)
            previous = index
        }
    }

    @Test fun journalAcceptsOnlyKnownTransitionStages() {
        val prefs = source("app/src/main/java/com/f1teammanager/CareerPreferences.kt")
        val fn = prefs.substringAfter("fun markSeasonTransitionStage(stage: String): Boolean {").substringBefore("fun pendingSeasonTransition")
        listOf("CAREER_RESET_DONE", "CAR_SAVED", "GARAGE_SAVED", "FINANCE_SAVED", "SPONSORS_SAVED", "STATE_PERSISTED").forEach {
            assertTrue("stage not allowed: $it", fn.contains("\"$it\""))
        }
    }

    @Test fun interruptedTransitionHasCommittedSnapshotAndRestoresBeforeRetry() {
        val prefs = source("app/src/main/java/com/f1teammanager/CareerPreferences.kt")
        val begin = prefs.substringAfter("fun beginSeasonTransitionJournal(fromSeason: Int): Int {").substringBefore("fun markSeasonTransitionStage")
        assertTrue(begin.contains("snapshotCareerForSeasonTransition()"))
        assertTrue(begin.contains("restoreCareerSeasonTransitionSnapshot()"))
        assertTrue(begin.contains("Virada interrompida sem snapshot íntegro"))
        assertTrue(begin.contains("restoredSeason == pendingFrom"))
        val snapshot = prefs.substringAfter("private fun snapshotCareerForSeasonTransition(): Boolean {").substringBefore("private fun prefsSnapshot")
        assertTrue(snapshot.contains("editor.commit()"))
        assertTrue(snapshot.contains("__season_transition_snapshot_ready"))
    }

    @Test fun completedTransitionCleansBackupBeforeJournal() {
        val prefs = source("app/src/main/java/com/f1teammanager/CareerPreferences.kt")
        val fn = prefs.substringAfter("fun completeSeasonTransitionJournal(): Boolean {").substringBefore("/** Explicit player action")
        assertTrue(fn.indexOf("prefsSnapshot().edit().clear().commit()") < fn.indexOf("seasonTransitionPendingFrom"))
    }

}
