package com.f1teammanager

import com.f1teammanager.core.manager.*
import org.junit.Assert.*
import org.junit.Test

class AnnualCarRegulationApplicationTest {
    private fun car(value: Int = 80) = TeamCarState(
        aerodynamics = value, chassis = value, engine = value, reliability = 73,
        frontWing = value, rearWing = value, brakes = value, electricPowerUnit = value
    )

    @Test fun annualRuleReducesOnlyTheSelectedComponentsAndNeverReliability() {
        val rule = AnnualCarRegulationEngine.SeasonRule(
            2, listOf(AnnualCarRegulationEngine.catalog().first { it.id == "MOT-01" }),
            false, emptyMap()
        )
        val result = AnnualCarRegulationEngine.applyToCar(car(), rule)
        assertEquals(73, result.engine) // 80 reduced by 8%, rounded down
        assertEquals(80, result.chassis)
        assertEquals(80, result.frontWing)
        assertEquals(80, result.rearWing)
        assertEquals(80, result.brakes)
        assertEquals(80, result.electricPowerUnit)
        assertEquals(73, result.reliability)
    }

    @Test fun decennialRuleAppliesToAllSixComponentsAndPreservesPhysicalCarIdentityAndReliability() {
        val rule = AnnualCarRegulationEngine.generate(11, 20261005)
        val original = TeamGarageFactory.fromCarState(car(), 1, 11)
        val result = AnnualCarRegulationEngine.applyToGarage(original, rule)
        assertEquals(original.car1.id, result.car1.id)
        assertEquals(original.car2.id, result.car2.id)
        assertEquals(original.car1.reliability, result.car1.reliability)
        assertEquals(original.car2.componentReliability(CarComponent.ENGINE), result.car2.componentReliability(CarComponent.ENGINE))
        CarComponent.values().forEach { component ->
            assertTrue("$component should be reduced on car 1", result.car1.componentValue(component) < original.car1.componentValue(component))
            assertTrue("$component should be reduced on car 2", result.car2.componentValue(component) < original.car2.componentValue(component))
        }
    }

    @Test fun playerAndAiUseTheSameSeasonRuleForSameSeed() {
        (2..40).forEach { season ->
            assertEquals(
                AnnualCarRegulationEngine.encode(AnnualCarRegulationEngine.generate(season, 20261005)),
                AnnualCarRegulationEngine.encode(AnnualCarRegulationEngine.generate(season, 20261005))
            )
        }
    }


    @Test fun firstCalendarSeasonIsExemptAndDecennialMapsTo2036() {
        val first = AnnualCarRegulationEngine.generateForCalendarYear(2026, 20261005)
        assertTrue(first.annualEvents.isEmpty())
        assertFalse(first.decennialRevolution)
        val decennial = AnnualCarRegulationEngine.generateForCalendarYear(2036, 20261005)
        assertTrue(decennial.decennialRevolution)
        assertEquals(11, decennial.season)
    }
}
