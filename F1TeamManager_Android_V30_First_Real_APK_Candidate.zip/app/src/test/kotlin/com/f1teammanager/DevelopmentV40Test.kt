package com.f1teammanager

import com.f1teammanager.core.manager.*
import com.f1teammanager.core.season.WorldDatabase
import org.junit.Test
import org.junit.Assert.*

class DevelopmentV40Test {
    @Test fun startingProjectDoesNotConsumeCurrentWeek() {
        val team = WorldDatabase.teams.first()
        val initial = TeamManagerState(
            season = 2026,
            round = 1,
            playerTeamId = team.id,
            car = TeamCarState(team.baseCar, team.chassis, team.engine, team.reliability,
                frontWing = team.frontWing, rearWing = team.rearWing,
                brakes = team.brakes, electricPowerUnit = team.electricPowerUnit),
            finance = TeamFinanceState(100_000_000L)
        )
        val state = CarDevelopmentEngine().start(initial, CarComponent.ENGINE, DevelopmentIntensity.AGGRESSIVE)
        assertEquals(4, state.car.activeProject!!.remainingWeeks)
    }

    @Test fun sevenElapsedWeeksCannotBecomeTenDevelopmentWeeks() {
        val team = WorldDatabase.teams.first()
        val initial = TeamManagerState(
            season = 2026,
            round = 1,
            playerTeamId = team.id,
            car = TeamCarState(team.baseCar, team.chassis, team.engine, team.reliability,
                frontWing = team.frontWing, rearWing = team.rearWing,
                brakes = team.brakes, electricPowerUnit = team.electricPowerUnit),
            finance = TeamFinanceState(100_000_000L)
        )
        val engine = CarDevelopmentEngine()
        val started = engine.start(initial, CarComponent.ENGINE, DevelopmentIntensity.AGGRESSIVE)
        val afterSevenCalendarWeeks = engine.advanceWeeks(started, 7)
        assertNull(afterSevenCalendarWeeks.car.activeProject)
    }

    @Test fun aiTeamsUseIndependentWeeklyRd() {
        val ai = AITeamDevelopmentEngine()
        val week7 = WorldDatabase.teams.map { ai.simulate(it, 7, 2026) }
        val week9 = WorldDatabase.teams.map { ai.simulate(it, 9, 2026) }
        assertTrue(week7.any { it.seasonDevelopmentGain > 0 })
        assertTrue(week9.zip(week7).any { (later, earlier) -> later.seasonDevelopmentGain >= earlier.seasonDevelopmentGain })
        assertTrue(week9.map { it.seasonDevelopmentGain }.distinct().size > 1)
    }
}
