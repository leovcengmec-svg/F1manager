package com.f1teammanager

import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class HistoricalDatabaseChampionV654Test {
    private val source by lazy { File("app/src/main/java/com/f1teammanager/HistoricalDatabase.kt").readText() }

    @Test fun seasonIsNotFinalizedByAnSdRowAlone() {
        val block = source.substringAfter("fun isSeasonFinalized(season: Int)")
            .substringBefore("private fun reconcileCompletedSeasonSummaries()")
        assertTrue(block.contains("driverWinners.singleOrNull()"))
        assertTrue(block.contains("constructorWinners.singleOrNull()"))
        assertTrue(block.contains("driverChampion.driverId == firstDriver.driverId"))
        assertTrue(block.contains("constructorChampion.teamId == firstConstructor.teamId"))
        assertTrue(block.contains("allRacesPresent"))
    }

    @Test fun incompleteSeasonShardsDoNotHideLegacyChampionRecords() {
        val block = source.substringAfter("private fun readLines()")
            .substringBefore("private fun writeAtomicLines")
        assertTrue(block.contains("summaryRecords"))
        assertTrue(block.contains("seasonRecordKey(line)"))
        assertTrue(block.contains("legacyLines + seasonShards.flatMap"))
    }

    @Test fun completedSeasonsAreReconciledFromAllScheduledGps() {
        val block = source.substringAfter("private fun reconcileCompletedSeasonSummaries()")
            .substringBefore("fun finalizeSeason(")
        assertTrue(block.contains("SeasonCalendar.forSeason(year).size"))
        assertTrue(block.contains("(1..expectedRounds).all"))
        assertTrue(block.contains("rows.groupBy { it.driverId }"))
        assertTrue(block.contains("rows.groupBy { it.teamId }"))
    }

    @Test fun incompleteMarketUsesRaceParticipantsAndPointsLedger() {
        val block = source.substringAfter("fun finalizeSeason(")
            .substringBefore("val driverRows = activeIds")
        assertTrue(block.contains("races.map { it.driverId }"))
        assertTrue(block.contains("effectiveDriverPoints.keys"))
    }

    @Test fun historicalRaceTeamComesFromActiveContractBeforeFallbackName() {
        val block = source.substringAfter("fun recordRace(")
            .substringBefore("writeRaceLines(season, round.round, raceLines)")
        assertTrue(block.contains("market?.contracts?.firstOrNull"))
        assertTrue(block.contains("activeIn(season)"))
        assertTrue(block.contains("fallbackTeamName"))
    }
}
