import com.f1teammanager.core.manager.DriverMarketEngine
import com.f1teammanager.core.season.WorldDatabase
import com.f1teammanager.core.season.DriverProfileCatalog
import com.f1teammanager.core.season.DriverEvolutionEngine
import kotlin.random.Random

fun main() {
    val state = DriverMarketEngine().initialState(2026)
    val active = state.contracts.filter { it.activeIn(2026) }.map { it.driverId }.toSet()
    val free = WorldDatabase.allDrivers.map { it.id }.filter { it !in active }.toSet()
    check(WorldDatabase.allDrivers.size == 100) { "Expected 100 drivers" }
    check(active.size == 80) { "Expected 80 active, got ${active.size}" }
    check(free.size == 20) { "Expected 20 free, got ${free.size}" }
    check(active.intersect(free).isEmpty())
    check(active.size + free.size == 100)
    check(DriverProfileCatalog.maxAnnualGain("Prodígio") == 15)
    check(DriverProfileCatalog.maxAnnualGain("Auge rápido") == 13)
    check(DriverProfileCatalog.maxAnnualGain("Auge moderado") == 11)
    check(DriverProfileCatalog.maxAnnualGain("Auge tardio") == 10)
    check(DriverProfileCatalog.maxAnnualGain("Normal") == 8)
    check(DriverProfileCatalog.maxAnnualGain("Demorado") == 6)
    val freeNatural = DriverEvolutionEngine.FREE_DRIVER_GROWTH_RATE
    check(freeNatural == 0.90)

    // Verify the actual growth bank is exactly 90% of the natural baseline,
    // independently of annual caps and without creating a race-performance sample.
    val sample = WorldDatabase.allDrivers.first { driver ->
        DriverProfileCatalog.overall(intArrayOf(driver.speed, driver.qualifying, driver.overtaking,
            driver.defense, driver.consistency, driver.wet, driver.tyre)) < driver.potentialOverall
    }
    val annualNatural = IntArray(7)
    val annualFree = IntArray(7)
    val baseline = DriverEvolutionEngine.applyPerformanceTick(
        sample, 105.0, 0.0, annualNatural, Random(650), facilityGrowthEfficiency = 1.0
    )
    val freeTick = DriverEvolutionEngine.applyFreeDriverTick(sample, 0.0, annualFree, Random(650))
    check(kotlin.math.abs(freeTick.bank - baseline.bank * 0.90) < 1e-9) {
        "Free driver growth bank is not exactly 90% of natural baseline"
    }
    println("FreeDriverEvolutionTest: PASS (100 total / 80 active / 20 free; exact 90% natural growth)")
}
