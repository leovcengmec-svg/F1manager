import com.f1teammanager.core.manager.DriverMarketEngine
import com.f1teammanager.core.season.WorldDatabase
import com.f1teammanager.core.season.DriverProfileCatalog

fun main() {
    val state = DriverMarketEngine().initialState(2026)
    val active = state.contracts.filter { it.activeIn(2026) }.map { it.driverId }.toSet()
    val free = WorldDatabase.allDrivers.map { it.id }.filter { it !in active }.toSet()
    check(WorldDatabase.allDrivers.size == 100) { "Expected 100 drivers" }
    check(active.size == 80) { "Expected 80 active, got ${active.size}" }
    check(free.size == 20) { "Expected 20 free, got ${free.size}" }
    check(active.intersect(free).isEmpty())
    check(active.size + free.size == 100)
    check(DriverProfileCatalog.maxAnnualGain("Prodígio") == 15)
    check(DriverProfileCatalog.maxAnnualGain("Auge rápido") == 13)
    check(DriverProfileCatalog.maxAnnualGain("Auge moderado") == 11)
    check(DriverProfileCatalog.maxAnnualGain("Auge tardio") == 10)
    check(DriverProfileCatalog.maxAnnualGain("Normal") == 8)
    check(DriverProfileCatalog.maxAnnualGain("Demorado") == 6)
    val freeNatural = 0.70
    check(freeNatural == 0.70)
    println("FreeDriverEvolutionTest: PASS (100 total / 80 active / 20 free; free utilization 70%)")
}
