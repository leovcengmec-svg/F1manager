import com.f1teammanager.core.manager.*
import com.f1teammanager.core.season.*

object ThreeSeasonCommercialAuditTest {
    @JvmStatic fun main(args: Array<String>) {
        check(WorldDatabase.teams.size == 40)
        check(WorldDatabase.allDrivers.size == 100)
        check(WorldDatabase.rounds.size == 30)

        val sponsorship = TeamSponsorshipEngine(20261006)
        var totalExpirations = 0
        var totalReplacements = 0
        for (season in 2026..2028) {
            val initial = sponsorship.allTeams(season)
            check(initial.size == 40)
            check(initial.values.all { it.sponsors.size == 5 })
            check(initial.values.all { it.sponsors.all { s -> s.active && s.racesRemaining in 3..10 } })
            for (round in 1..30) sponsorship.advanceAllTeams(season, round)
            totalExpirations += sponsorship.events().count { it.season == season && it.type == "ENCERRADO" }
            totalReplacements += sponsorship.events().count { it.season == season && it.type == "NOVO_CONTRATO" }
            val end = sponsorship.allTeams(season)
            check(end.values.all { it.sponsors.size == 5 }) { "Alguma equipe ficou sem 5 contratos na temporada $season" }
            check(end.values.all { it.sponsors.all { s -> s.active && s.racesRemaining > 0 } }) { "Contrato expirado permaneceu ativo na temporada $season" }
        }
        check(totalExpirations > 0) { "Nenhum patrocínio encerrou por corridas" }
        check(totalReplacements == totalExpirations) { "Nem todo patrocínio encerrado foi substituído" }
        check(totalReplacements > 0) { "Nenhuma IA assinou novo contrato" }
        check(sponsorship.activeContractCount(2028) == 200) { "Esperados 200 patrocínios ativos no final de 2028" }
        println("ThreeSeasonCommercialAuditTest: PASS | 40 equipes | 200 slots | $totalExpirations encerramentos | $totalReplacements novos contratos")
    }
}
