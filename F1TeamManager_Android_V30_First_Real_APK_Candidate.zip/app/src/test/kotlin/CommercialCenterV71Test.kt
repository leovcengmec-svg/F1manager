import com.f1teammanager.core.season.WorldDatabase
import com.f1teammanager.core.manager.*

object CommercialCenterV71Test {
    @JvmStatic fun main(args:Array<String>) {
        val e=TeamSponsorshipEngine(20261006)
        check(e.availableCategories(0)==listOf(SponsorCategory.BASICO))
        check(e.availableCategories(2)==listOf(SponsorCategory.BASICO,SponsorCategory.REGIONAL))
        check(e.availableCategories(6)==listOf(SponsorCategory.NACIONAL,SponsorCategory.INTERNACIONAL))
        check(e.availableCategories(9)==listOf(SponsorCategory.INTERNACIONAL,SponsorCategory.PREMIUM,SponsorCategory.GLOBAL))
        check(e.availableCategories(10)==listOf(SponsorCategory.PREMIUM,SponsorCategory.GLOBAL))
        val level10=e.offersForSlot(1,2026,1,10,1)
        check(level10.size==3 && level10.all { it.sponsor.slot==1 })
        check(level10.all { SponsorCatalog.pool(it.category,true).any { p -> p.name==it.sponsor.name } })
        val secondary=e.offersForSlot(1,2026,2,6,1)
        check(secondary.size==3 && secondary.all { it.sponsor.slot==2 })
        check(secondary.none { it.sponsor.name in level10.map { x->x.sponsor.name } })
        check(SponsorCatalog.all.size==180) { "Catálogo deveria ter 180 patrocinadores únicos; atual=${SponsorCatalog.all.size}" }
        check(SponsorCategory.values().all { c -> SponsorCatalog.pool(c,false).size==20 })
        check(SponsorCategory.values().all { c -> SponsorCatalog.pool(c,true).size==10 })
        check(WorldDatabase.teams.sortedByDescending { InitialTeamProfile.strength(it) }.map { it.id }.size==40)
        // Commercial multiplier must improve at every level without a downgrade.
        val commercialValues = (0..10).map { SponsorContractPricing.commercialMultiplier(it) }
        check(commercialValues.first() == 1.60)
        check(commercialValues.last() == 1.85)
        check(commercialValues.zipWithNext().all { (a,b) -> b > a })
        val offers0 = TeamSponsorshipEngine(20261006).offersForSlot(1,2026,1,0,2)
        val offers1 = TeamSponsorshipEngine(20261006).offersForSlot(1,2026,1,1,2)
        val offers2 = TeamSponsorshipEngine(20261006).offersForSlot(1,2026,1,2,2)
        check(offers0.all { it.sponsor.pointsBonus == 0L } && offers1.all { it.sponsor.pointsBonus == 0L } && offers2.all { it.sponsor.pointsBonus == 0L })
        check(TeamSponsorshipEngine(20261006).marketingQualityCategoryShift(0) == 0)
        check(TeamSponsorshipEngine(20261006).marketingQualityCategoryShift(10) == 10)
        check(TeamSponsorshipEngine(20261006).categoryForQualityRoll(2, 67) == SponsorCategory.BASICO)
        check(TeamSponsorshipEngine(20261006).categoryForQualityRoll(2, 68) == SponsorCategory.REGIONAL)
        check(TeamSponsorshipEngine(20261006).categoryForQualityRoll(3, 47) == SponsorCategory.REGIONAL)
        check(TeamSponsorshipEngine(20261006).categoryForQualityRoll(9, 84) == SponsorCategory.GLOBAL)
        println("CommercialCenterV71Test: PASS | 180 sponsors | Master slot restricted | monotonic contract values | marketing quality draw")
    }
}
