import com.f1teammanager.core.season.WorldDatabase
import com.f1teammanager.core.manager.*

object CommercialCenterV71Test {
    @JvmStatic fun main(args:Array<String>) {
        val e=TeamSponsorshipEngine(20261006)
        check(e.availableCategories(0)==listOf(SponsorCategory.BASICO))
        check(e.availableCategories(2)==listOf(SponsorCategory.BASICO,SponsorCategory.REGIONAL))
        check(e.availableCategories(6)==listOf(SponsorCategory.NACIONAL,SponsorCategory.INTERNACIONAL))
        check(e.availableCategories(9)==listOf(SponsorCategory.INTERNACIONAL,SponsorCategory.PREMIUM,SponsorCategory.GLOBAL))
        check(e.availableCategories(10)==listOf(SponsorCategory.PREMIUM,SponsorCategory.GLOBAL))
        val level10=e.offersForSlot(1,2026,1,10,1)
        check(level10.size==3 && level10.all { it.sponsor.slot==1 })
        check(level10.all { SponsorCatalog.pool(it.category,true).any { p -> p.name==it.sponsor.name } })
        val secondary=e.offersForSlot(1,2026,2,6,1)
        check(secondary.size==3 && secondary.all { it.sponsor.slot==2 })
        check(secondary.none { it.sponsor.name in level10.map { x->x.sponsor.name } })
        check(SponsorCatalog.all.size==180) { "Catálogo deveria ter 180 patrocinadores únicos; atual=${SponsorCatalog.all.size}" }
        check(SponsorCategory.values().all { c -> SponsorCatalog.pool(c,false).size==20 })
        check(SponsorCategory.values().all { c -> SponsorCatalog.pool(c,true).size==10 })
        check(WorldDatabase.teams.sortedByDescending { InitialTeamProfile.strength(it) }.map { it.id }.size==40)
        println("CommercialCenterV71Test: PASS | 180 sponsors | Master slot restricted | Marketing levels validated")
    }
}
