import com.f1teammanager.core.season.WorldDatabase
import com.f1teammanager.core.manager.*

object CommercialCenterV71Test {
    @JvmStatic fun main(args:Array<String>) {
        val e=TeamSponsorshipEngine(20261006)
        check(e.availableCategories(0)==listOf(SponsorCategory.BASICO))
        check(e.availableCategories(2)==listOf(SponsorCategory.BASICO,SponsorCategory.REGIONAL))
        check(e.availableCategories(6)==listOf(SponsorCategory.NACIONAL,SponsorCategory.INTERNACIONAL))
        check(e.availableCategories(9)==listOf(SponsorCategory.INTERNACIONAL,SponsorCategory.PREMIUM,SponsorCategory.GLOBAL))
        check(e.availableCategories(10)==listOf(SponsorCategory.PREMIUM,SponsorCategory.GLOBAL))
        val level10=e.offersForSlot(1,2026,1,10,1)
        check(level10.size==3 && level10.all { it.sponsor.slot==1 })
        check(level10.all { SponsorCatalog.pool(it.category,true).any { p -> p.name==it.sponsor.name } })
        val secondary=e.offersForSlot(1,2026,2,6,1)
        check(secondary.size==3 && secondary.all { it.sponsor.slot==2 })
        check(secondary.none { it.sponsor.name in level10.map { x->x.sponsor.name } })
        check(SponsorCatalog.all.size==180) { "Catálogo deveria ter 180 patrocinadores únicos; atual=${SponsorCatalog.all.size}" }
        check(SponsorCategory.values().all { c -> SponsorCatalog.pool(c,false).size==20 })
        check(SponsorCategory.values().all { c -> SponsorCatalog.pool(c,true).size==10 })
        check(WorldDatabase.teams.sortedByDescending { InitialTeamProfile.strength(it) }.map { it.id }.size==40)
        // Regression: commercial-center bonuses scale every monetary part of new offers.
        val offers0 = TeamSponsorshipEngine(20261006).offersForSlot(1,2026,1,0,2)
        val offers1 = TeamSponsorshipEngine(20261006).offersForSlot(1,2026,1,1,2)
        val offers2 = TeamSponsorshipEngine(20261006).offersForSlot(1,2026,1,2,2)
        check(offers0.map { it.sponsor.name } == offers1.map { it.sponsor.name } && offers1.map { it.sponsor.name } == offers2.map { it.sponsor.name })
        fun money(s:SponsorContract)=listOf(s.upfront,s.racePayment,s.pointsBonus,s.qualifyingBonus,s.raceTargetBonus)
        for (i in offers0.indices) {
            val base=money(offers2[i].sponsor); val bonus0=money(offers0[i].sponsor); val bonus1=money(offers1[i].sponsor)
            for (j in base.indices) {
                check(kotlin.math.abs(bonus0[j] - kotlin.math.round(base[j] * 1.40).toLong()) <= 1L) { "Nível 0 deve pagar +40%" }
                check(kotlin.math.abs(bonus1[j] - kotlin.math.round(base[j] * 1.20).toLong()) <= 1L) { "Nível 1 deve pagar +20%" }
            }
        }
        println("CommercialCenterV71Test: PASS | 180 sponsors | Master slot restricted | Marketing levels validated")
    }
}
