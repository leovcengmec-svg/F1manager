import com.f1teammanager.core.manager.DriverMarketEngine

/** Validates the agreed 55% renewals / 45% transfers market target and actual notification labels. */
object MarketMovementMixTest {
    @JvmStatic fun main(args: Array<String>) {
        val engine = DriverMarketEngine(20261006)
        var state = engine.initialState(2026)
        for (week in 9..56) {
            state = engine.processAiMarketWeek(state, 2026, week, 1)
        }
        val renewals = state.notifications.count {
            it.season == 2026 && it.title.trim().uppercase() in setOf("RENOVAÇÃO", "RENOVAÇÃO DE CONTRATO", "CONTRATO RENOVADO")
        }
        val transfers = state.notifications.count {
            it.season == 2026 && it.title.trim().uppercase() in setOf("TRANSFERÊNCIA NEGOCIADA", "TRANSFERÊNCIA CONFIRMADA", "CONTRATAÇÃO CONFIRMADA")
        }
        val total = renewals + transfers
        check(total > 0) { "O mercado não gerou nenhuma movimentação" }
        if (total >= 4) {
            check(renewals * 100 >= total * 50) { "Renovações abaixo da faixa esperada para meta 55%: $renewals/$total" }
            check(transfers * 100 <= total * 50) { "Trocas acima da faixa esperada para meta 45%: $transfers/$total" }
        }
        println("MarketMovementMixTest: PASS ($renewals renovações, $transfers trocas, $total total)")
    }
}
