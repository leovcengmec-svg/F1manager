import com.f1teammanager.core.manager.DriverMarketEngine

/** Diagnostic only: validates market activity and due-response cleanup without imposing a quota. */
object MarketMovementMixTest {
    @JvmStatic fun main(args: Array<String>) {
        val engine = DriverMarketEngine(20261006)
        var state = engine.initialState(2026)
        for (week in 9..56) {
            state = engine.processAiMarketWeek(state, 2026, week, 1)
        }
        // Count actual commitments for reporting only. The historical 55/45 ratio is
        // not a decision gate: a team may transfer twice or renew both drivers when its
        // sporting and financial situation makes that the sensible choice.
        val signed = state.scheduled.filter { it.signedSeason == 2026 && it.startSeason == 2027 }
        val renewals = signed.count { it.fromTeamId == it.toTeamId }
        val transfers = signed.count { it.fromTeamId != it.toTeamId }
        val total = renewals + transfers
        check(total > 0) { "O mercado não gerou nenhuma movimentação" }
        check(state.pending.none { it.status == com.f1teammanager.core.manager.NegotiationStatus.PENDING && it.expiresAfterWeek < 56 }) {
            "Existem propostas vencidas sem resolução após a simulação"
        }
        println("MarketMovementMixTest: PASS ($renewals renovações, $transfers trocas, $total total)")
    }
}
