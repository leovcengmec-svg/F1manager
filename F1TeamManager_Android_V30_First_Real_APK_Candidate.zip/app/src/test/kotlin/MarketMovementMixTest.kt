import com.f1teammanager.core.manager.DriverMarketEngine

/** Validates the dynamic market-movement rule: neither side may exceed 60% when enough movements exist. */
object MarketMovementMixTest {
    @JvmStatic fun main(args: Array<String>) {
        val engine = DriverMarketEngine(20261006)
        var state = engine.initialState(2026)
        for (week in 9..56) {
            state = engine.processAiMarketWeek(state, 2026, week, 1)
        }
        val renewals = state.notifications.count { it.season == 2026 && it.title == "RENOVAÇÃO" }
        val transfers = state.notifications.count { it.season == 2026 && it.title == "TRANSFERÊNCIA NEGOCIADA" }
        val total = renewals + transfers
        check(total > 0) { "O mercado não gerou nenhuma movimentação" }
        if (total >= 4) {
            check(renewals * 100 <= total * 60) { "Renovações acima de 60%: $renewals/$total" }
            check(transfers * 100 <= total * 60) { "Trocas acima de 60%: $transfers/$total" }
            check(renewals * 100 >= total * 40) { "Renovações abaixo de 40%: $renewals/$total" }
            check(transfers * 100 >= total * 40) { "Trocas abaixo de 40%: $transfers/$total" }
        }
        println("MarketMovementMixTest: PASS ($renewals renovações, $transfers trocas, $total total)")
    }
}
