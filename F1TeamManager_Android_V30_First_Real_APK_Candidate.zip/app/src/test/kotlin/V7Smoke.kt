import com.f1teammanager.core.manager.*
import com.f1teammanager.core.season.*
import java.io.File

fun main(){
    var manager=TeamManagerState(
        car=TeamCarState(82,80,84,88),
        finance=TeamFinanceState(25_000_000L),
        contracts=WorldDatabase.drivers.filter{it.teamId==1}.map{DriverContract(it.id,2,2_000_000)}
    )
    var season=SeasonState()
    check(manager.finance.budget==25_000_000L)
    manager=ManagerActions().apply(manager,ManagementAction.DEVELOP_AERO)
    check(manager.car.activeProject?.component==CarComponent.AERODYNAMICS)
    check(manager.finance.budget<25_000_000L)
    repeat(4){ manager=CarDevelopmentEngine().advanceRound(manager) }
    check(manager.car.activeProject==null)
    val out=ManagerSeasonEngine(777).runRound(manager,season)
    check(out.race.classification.size==80)
    check(out.season.currentRound==2)
    check(out.state.round==2)
    check(out.state.finance.transactions.isNotEmpty())
    val f=File.createTempFile("f1tm-v7",".sav")
    ManagerSave.save(f,out.state)
    val loaded=ManagerSave.load(f) ?: error("save/load failed")
    check(loaded.round==out.state.round && loaded.playerTeamId==out.state.playerTeamId)
    f.delete()
    println("V7 MANAGER CORE SMOKE TEST OK")
}
