package com.f1teammanager

import com.f1teammanager.core.race.*
import kotlin.test.Test
import kotlin.test.assertTrue

class V37PaceStrategySmoke {
    @Test fun strategyAndEnergyAreSeparate() {
        val p = RaceParticipant(1,"Test",1,"Team",80,80,80,80,80,50,50)
        val c = RaceCircuit(1,"Test",20,90000,1.0,1.0)
        val e = CareerWeekendEngine(7)
        e.start((1..80).map { p.copy(driverId=it, driverName="D$it") }, c, 1)
        e.setStrategy(1, DriverStrategyMode.ATTACK)
        val s = e.advance()
        val cs = s.carStatus.first { it.driverId == 1 }
        assertTrue(cs.lastLapMs < 120000)
        assertTrue(cs.ersPercent <= 100)
    }

    @Test fun tyreWeatherMatrixHasCorrectDirection() {
        // Directional contract encoded in the engine: wet tyres are fastest in heavy rain,
        // intermediates are fastest in light/medium rain, and Soft is fastest in dry.
        val deltas = mapOf(
            Weather.DRY to listOf(Tyre.SOFT, Tyre.MEDIUM, Tyre.HARD),
            Weather.LIGHT_RAIN to listOf(Tyre.INTERMEDIATE, Tyre.WET),
            Weather.MEDIUM_RAIN to listOf(Tyre.INTERMEDIATE, Tyre.WET),
            Weather.HEAVY_RAIN to listOf(Tyre.WET, Tyre.INTERMEDIATE)
        )
        assertTrue(deltas.size == 4)
    }
}
