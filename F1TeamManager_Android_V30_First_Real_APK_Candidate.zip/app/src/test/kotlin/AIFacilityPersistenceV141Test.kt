import com.f1teammanager.core.manager.*
import com.f1teammanager.core.season.*

object AIFacilityPersistenceV141Test {
    @JvmStatic fun main(args: Array<String>) {
        val team = WorldDatabase.teams.first { it.id != 1 }
        val finance = AITeamFinancialEngine(141000)
        val sponsorship = TeamSponsorshipEngine(141100)
        finance.beginSeason(team.id, 2026, DriverMarketEngine().initialState(2026))
        val before = finance.facilities(team.id)
        finance.advanceFacilityDevelopment(team.id, 2026, 8)
        val after = finance.facilities(team.id)
        check(after.levels != before.levels) { "AI facility did not persist an upgrade" }
        sponsorship.setMarketingLevel(team.id, after.level(FacilityType.MARKETING))
        val offers = sponsorship.offersForSlot(team.id, 2026, 2, after.level(FacilityType.MARKETING), 8)
        check(offers.size == 3)
        check(offers.map { it.sponsor.name }.toSet().size == 3)
        check(offers.map { it.category }.toSet().size == 1)
        println("AIFacilityPersistenceV141Test: PASS | facility upgrade persisted | marketing level synchronized")
    }
}
