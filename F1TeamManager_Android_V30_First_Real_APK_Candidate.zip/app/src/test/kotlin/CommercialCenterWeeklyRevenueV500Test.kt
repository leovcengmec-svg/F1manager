package com.f1teammanager

import com.f1teammanager.core.manager.FacilityEngine
import org.junit.Assert.*
import org.junit.Test

class CommercialCenterWeeklyRevenueV500Test {
    @Test fun levelZeroReceivesWeeklyStoreRevenue() {
        assertEquals(200_000L..400_000L, FacilityEngine.weeklyMerchandiseRevenueRange(0))
        val amount = FacilityEngine.weeklyMerchandiseRevenue(1, 2026, 1, 0)
        assertTrue(amount in 200_000L..400_000L)
    }

    @Test fun eachLevelHasTheAgreedRange() {
        val expected = listOf(
            200_000L..400_000L,
            350_000L..600_000L,
            500_000L..800_000L,
            650_000L..1_000_000L,
            800_000L..1_200_000L,
            950_000L..1_500_000L,
            1_100_000L..1_800_000L,
            1_300_000L..2_100_000L,
            1_500_000L..2_400_000L,
            1_750_000L..2_700_000L,
            2_000_000L..3_000_000L
        )
        for (level in 0..10) {
            assertEquals("unexpected range at level $level", expected[level], FacilityEngine.weeklyMerchandiseRevenueRange(level))
        }
    }

    @Test fun weeklyRevenueIsDeterministicAndInsideRange() {
        for (level in 0..10) {
            val range = FacilityEngine.weeklyMerchandiseRevenueRange(level)
            val amount = FacilityEngine.weeklyMerchandiseRevenue(7, 2026, 12, level)
            assertEquals(amount, FacilityEngine.weeklyMerchandiseRevenue(7, 2026, 12, level))
            assertTrue(amount in range.first..range.last)
        }
    }
}
