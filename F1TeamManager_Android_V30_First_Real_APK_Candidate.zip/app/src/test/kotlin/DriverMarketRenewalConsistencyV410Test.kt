import com.f1teammanager.core.manager.DriverMarketEngine
import com.f1teammanager.core.manager.DriverTeamRole
import com.f1teammanager.core.season.WorldDatabase
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class DriverMarketRenewalConsistencyV410Test {
    @Test fun `scheduled renewal is not open to offers and cancelled renewal is not announced as complete`() {
        val engine = DriverMarketEngine(4102026)
        val initial = engine.initialState(2026)
        val deal = initial.contracts.first { it.years == 1 && it.activeIn(2026) }
        val team = WorldDatabase.teams.first { it.id == deal.teamId }
        val renewed = engine.renew(
            initial, deal.driverId, team.id, 2, deal.salary,
            DriverTeamRole.EQUAL, 2026, 10
        )
        assertFalse("A driver with a signed future renewal cannot remain in ABERTO", engine.canReceiveProposals(renewed, deal.driverId, 2026))
        assertTrue(renewed.notifications.any { it.title == "RENOVAÇÃO DE CONTRATO" && it.message.contains("${2027}") })

        val rejected = renewed.scheduled.single { it.driverId == deal.driverId }
        val afterFinancialRejection = engine.cancelUnaffordableScheduledDeals(renewed, listOf(rejected), 2026, 11)
        assertTrue("Rejected renewal must no longer reserve the driver", afterFinancialRejection.scheduled.none { it.driverId == deal.driverId })
        assertTrue("Driver can return to the market after the renewal is rejected", engine.canReceiveProposals(afterFinancialRejection, deal.driverId, 2026))
        assertTrue("A cancellation notice must explain the actual outcome", afterFinancialRejection.notifications.any { it.title == "NEGOCIAÇÃO ENCERRADA" && it.message.contains("saldo insuficiente") })
        assertFalse("Success notice must be removed when its commitment is rolled back", afterFinancialRejection.notifications.any { it.title == "RENOVAÇÃO DE CONTRATO" && it.message.contains(WorldDatabase.allDrivers.first { d -> d.id == deal.driverId }.name) })
    }
}
