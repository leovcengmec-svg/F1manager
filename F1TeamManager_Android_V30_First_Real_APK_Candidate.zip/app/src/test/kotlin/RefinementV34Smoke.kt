import com.f1teammanager.core.manager.DriverMarketEngine
import com.f1teammanager.core.race.*
import com.f1teammanager.core.season.WorldDatabase
import com.f1teammanager.core.season.toParticipant

fun main() {
    check(WorldDatabase.teams.size == 40)
    check(WorldDatabase.drivers.size == 80)
    check(WorldDatabase.allDrivers.size == 100)
    val market = DriverMarketEngine(42).initialState()
    check(market.contracts.size == 80)
    check(market.released.size == 20)

    val circuit = RaceCircuit(1, "Teste", 20, 90000L, 1.0, 1.0, safetyCarRisk = 0.0)
    val participants = WorldDatabase.drivers.map { it.toParticipant(WorldDatabase.teams[it.teamId - 1]) }
    val game = CareerWeekendEngine(1234)
    var s = game.start(participants, circuit, 1)
    WorldDatabase.drivers.filter { it.teamId == 1 }.forEach { game.setPlan(it.id, DriverStrategyMode.DEFENSE, Tyre.SOFT) }
    s = game.snapshotForUi()
    var guard = 0
    while (!s.completed && guard++ < 100) {
        val decision = s.decision
        s = if (decision != null) game.choose(decision.request.options.first()) else game.advance()
    }
    check(s.completed)
    check(s.classification.size == 80)
    check(s.carStatus.size == 80)
    check(s.carStatus.all { it.ersPercent in 0..100 })
    check(s.carStatus.any { it.tyre == Tyre.SOFT })
    check(game.result().events.isNotEmpty())
    println("V34_REFINEMENT_SMOKE_OK teams=40 racing=80 market=100 classified=80")
}
