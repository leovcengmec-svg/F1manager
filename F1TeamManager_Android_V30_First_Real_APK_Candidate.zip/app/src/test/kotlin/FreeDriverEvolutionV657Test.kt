import com.f1teammanager.core.manager.*
import com.f1teammanager.core.season.*
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class FreeDriverEvolutionV657Test {
    @Test
    fun allTwentyFreeAgentsReceiveOne120PercentGrowthTickPerGp() {
        val market = DriverMarketEngine(20261003).initialState(2026)
        val team = WorldDatabase.teams.first()
        val car = TeamCarState(
            com.f1teammanager.core.manager.InitialTeamProfile.strength(team),
            team.chassis, team.engine, team.reliability,
            frontWing = team.frontWing, rearWing = team.rearWing,
            brakes = team.brakes, electricPowerUnit = team.electricPowerUnit
        )
        var manager = TeamManagerState(
            season = 2026, playerTeamId = team.id, car = car,
            finance = TeamFinanceState(35_000_000), driverMarket = market
        )
        val free = WorldDatabase.allDrivers.map { it.id }.filter { id ->
            market.contracts.none { it.activeIn(2026) && it.driverId == id }
        }.toSet()
        assertEquals(20, free.size)
        assertEquals(1.20, DriverEvolutionEngine.FREE_DRIVER_GROWTH_RATE, 0.0)
        val before = free.associateWith { id ->
            WorldDatabase.allDrivers.first { it.id == id }.ratingsForManager().toList()
        }
        var season = SeasonState()
        val engine = ManagerSeasonEngine(20261003)
        repeat(30) {
            val outcome = engine.runRound(manager, season)
            manager = outcome.state
            season = outcome.season
        }
        val changed = free.count { id -> manager.driverEvolutionAttributes[id] != before[id] }
        assertEquals("All 20 free agents should show development during the season", 20, changed)
        assertTrue(manager.driverEvolutionAnnualGains.filterKeys { it in free }.values.all { gains ->
            gains.size == 7 && gains.all { it >= 0 }
        })
        assertTrue(manager.driverEvolutionPhaseGps.filterKeys { it in free }.values.all { it == 30 })
        assertTrue(free.none { id -> (manager.driverClassPerformance[id]?.get(2026)?.raceCount ?: 0) > 0 })
    }
}

private fun DriverDefinition.ratingsForManager() = intArrayOf(speed, qualifying, overtaking, defense, consistency, wet, tyre)
