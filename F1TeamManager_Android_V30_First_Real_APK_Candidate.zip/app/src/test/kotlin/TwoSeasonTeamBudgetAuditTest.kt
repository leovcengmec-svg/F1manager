import com.f1teammanager.core.manager.*
import com.f1teammanager.core.season.*

object TwoSeasonTeamBudgetAuditTest {
 @JvmStatic fun main(args:Array<String>) {
  check(WorldDatabase.teams.size==40)
  check(WorldDatabase.allDrivers.size==100)
  check(WorldDatabase.rounds.size==30)
  val sponsorship=TeamSponsorshipEngine(20261006)
  val finance=AITeamFinancialEngine(20261007)
  val market=DriverMarketEngine(20261008).initialState(2026)
  var negative=0
  var min=Long.MAX_VALUE
  var max=Long.MIN_VALUE
  for(season in 2026..2027){
   finance.ensureAllTeams(season, -1, market)
   for(round in 1..30){
    sponsorship.advanceAllTeams(season,round)
    WorldDatabase.teams.forEach { t ->
      val st=sponsorship.forTeam(t.id,season)
      val f=finance.applyRace(t.id,season,round,st,market)
      min=minOf(min,f.finance.budget); max=maxOf(max,f.finance.budget)
      if(f.finance.budget<0) negative++
    }
   }
  }
  check(finance.allStates().size==40)
  println("TwoSeasonTeamBudgetAuditTest: PASS | 40 equipes | 60 GPs | min=$min | max=$max | saldos negativos em $negative checkpoints")
  finance.allStates().sortedBy { it.finance.budget }.take(5).forEach { println("TEAM ${it.teamId}: €${it.finance.budget}") }
 }
}
