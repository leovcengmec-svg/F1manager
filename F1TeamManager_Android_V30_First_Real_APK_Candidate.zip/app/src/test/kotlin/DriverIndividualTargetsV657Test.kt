import com.f1teammanager.core.season.DriverEvolutionEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class DriverIndividualTargetsV657Test {
    @Test
    fun sameCarDriversReceiveExactlyTheSameCarOnlyTargets() {
        val inputs = (1..40).flatMap { teamId ->
            val car = 100.0 - (teamId - 1) * 1.4
            listOf(
                DriverEvolutionEngine.TargetInput((teamId - 1) * 2 + 1, teamId, car),
                DriverEvolutionEngine.TargetInput((teamId - 1) * 2 + 2, teamId, car)
            )
        }

        val targets = DriverEvolutionEngine.buildIndividualTargets(inputs)
        assertEquals("Expected 80 targets", 80, targets.size)
        (1..40).forEach { teamId ->
            val first = targets.getValue((teamId - 1) * 2 + 1)
            val second = targets.getValue((teamId - 1) * 2 + 2)
            assertEquals("Teammates must share the qualifying target", first.qualifyingPosition, second.qualifyingPosition)
            assertEquals("Teammates must share the race target", first.racePosition, second.racePosition)
            assertEquals("Qualifying and race must use the same car-only center", first.qualifyingPosition, first.racePosition)
        }
        assertEquals(2, targets.getValue(1).qualifyingPosition)
        assertEquals(80, targets.getValue(80).racePosition)
    }

    @Test
    fun targetBandsProvideToleranceAndNormalGrowthInsideTheRange() {
        val target = DriverEvolutionEngine.Target(8, 8, 8)
        val inside = DriverEvolutionEngine.gpPerformanceIndex(target, qualifyingPosition = 10, racePosition = 6)
        assertEquals("Inside the target bands must receive the normal baseline", 105.0, inside, 0.0)
        assertEquals("Expected result must map to normal growth", 1.0, DriverEvolutionEngine.performanceEvolutionRate(inside), 0.0)

        val outside = DriverEvolutionEngine.gpPerformanceIndex(target, qualifyingPosition = 12, racePosition = 8)
        assertTrue("One position outside one band should be a moderate penalty: $outside", outside < 105.0 && outside > 100.0)

        val missing = DriverEvolutionEngine.gpPerformanceIndex(target, qualifyingPosition = 0, racePosition = 0)
        assertEquals("Missing results should use individual target centers", 105.0, missing, 0.0)
    }

    @Test
    fun everyDriverUsesTheSameThreePlaceTolerance() {
        assertEquals(2, DriverEvolutionEngine.Target(5).qualifyingMinPosition)
        assertEquals(22, DriverEvolutionEngine.Target(25).qualifyingMinPosition)
        assertEquals(52, DriverEvolutionEngine.Target(55).qualifyingMinPosition)
        assertEquals(67, DriverEvolutionEngine.Target(70).qualifyingMinPosition)
    }
}
