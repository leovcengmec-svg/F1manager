import com.f1teammanager.core.season.DriverEvolutionEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class DriverIndividualTargetsV657Test {
    @Test
    fun sameCarDriversReceiveIndividualQualifyingAndRaceBands() {
        val inputs = mutableListOf<DriverEvolutionEngine.TargetInput>()
        // Same equipment, different drivers: stronger talent must receive a better target.
        inputs += DriverEvolutionEngine.TargetInput(1, 70.0, 94, 96)
        inputs += DriverEvolutionEngine.TargetInput(2, 70.0, 72, 70)
        // Add a representative grid so expected positions are not merely P1/P2.
        for (id in 3..80) {
            val car = 78.0 - ((id - 3) % 40) * 0.65
            val talent = 90 - ((id * 7) % 24)
            val qualifying = (talent + ((id % 5) - 2)).coerceIn(40, 100)
            inputs += DriverEvolutionEngine.TargetInput(id, car, talent, qualifying)
        }

        val targets = DriverEvolutionEngine.buildIndividualTargets(inputs)
        assertEquals("Expected 80 individual targets", 80, targets.size)
        val strong = targets.getValue(1)
        val weaker = targets.getValue(2)
        assertTrue(
            "Stronger qualifying driver received no better expectation: $strong vs $weaker",
            strong.qualifyingPosition < weaker.qualifyingPosition
        )
        assertTrue(
            "Stronger overall driver received no better race expectation: $strong vs $weaker",
            strong.racePosition < weaker.racePosition
        )
    }

    @Test
    fun targetBandsProvideToleranceAndNormalGrowthInsideTheRange() {
        val target = DriverEvolutionEngine.Target(8, 8, 8)
        val inside = DriverEvolutionEngine.gpPerformanceIndex(target, qualifyingPosition = 10, racePosition = 6)
        assertEquals("Inside the target bands must receive the normal baseline", 105.0, inside, 0.0)
        assertEquals("Expected result must map to normal growth", 1.0, DriverEvolutionEngine.performanceEvolutionRate(inside), 0.0)

        val outside = DriverEvolutionEngine.gpPerformanceIndex(target, qualifyingPosition = 11, racePosition = 8)
        assertTrue("One position outside one band should be a moderate penalty: $outside", outside < 105.0 && outside > 100.0)

        val missing = DriverEvolutionEngine.gpPerformanceIndex(target, qualifyingPosition = 0, racePosition = 0)
        assertEquals("Missing results should use individual target centers", 105.0, missing, 0.0)
    }

    @Test
    fun toleranceMarginsExpandForTheBackOfTheGrid() {
        assertEquals(3, DriverEvolutionEngine.Target(5).qualifyingMinPosition)
        assertEquals(22, DriverEvolutionEngine.Target(25).qualifyingMinPosition)
        assertEquals(51, DriverEvolutionEngine.Target(55).qualifyingMinPosition)
        assertEquals(65, DriverEvolutionEngine.Target(70).qualifyingMinPosition)
    }
}
