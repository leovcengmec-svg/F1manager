package com.f1teammanager

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class V582PlayerResearchHomeNoticeTest {
    @Test fun recognizesPlayerSuccessAndFailureMessageFormats() {
        assertTrue(isPlayerResearchNotice("Ferrari concluiu Asa V4.", "Ferrari"))
        assertTrue(isPlayerResearchNotice("Ferrari: a tentativa de Asa V4 falhou.", "Ferrari"))
    }

    @Test fun excludesOtherTeamsAndEmptyTeamNames() {
        assertFalse(isPlayerResearchNotice("Mercedes: a tentativa de Asa V4 falhou.", "Ferrari"))
        assertFalse(isPlayerResearchNotice("Ferrari: a tentativa falhou.", ""))
    }

    @Test fun homeBadgeAndPopupBothFilterResearchNoticesToPlayerTeam() {
        val source = java.io.File("app/src/main/java/com/f1teammanager/MainActivity.kt").readText()
        assertTrue(source.contains("isPlayerResearchNotice(notice.message, team)"))
        assertTrue(source.contains("val rdCompletionCount = unread.count"))
    }
}
