package com.f1teammanager

import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/** Source-level contract checks for crash recovery; complements runtime persistence tests. */
class V377PendingRaceRecoveryContractTest {
    @Test fun resultIsPersistedBeforeQualifyingBonusAndFinalization() {
        val main = source("app/src/main/java/com/f1teammanager/MainActivity.kt")
        val simulation = main.substring(main.indexOf("fun simulateWeekendInstantlyForCareer()"))
        assertTrue(simulation.indexOf("savePendingRaceFinalization") < simulation.indexOf("applyQualifyingBonusOnce"))
        assertTrue(simulation.indexOf("savePendingRaceFinalization") < simulation.indexOf("finalizeCompletedRace(weekend.race)"))
    }

    @Test fun startupRestoresPendingResultAndRetriesTheSameClassification() {
        val main = source("app/src/main/java/com/f1teammanager/MainActivity.kt")
        assertTrue(main.contains("loadPendingRaceFinalization(store.season, recoveredRound)"))
        assertTrue(main.contains("LaunchedEffect(recoveredPendingRace?.season, recoveredPendingRace?.round)"))
        assertTrue(main.contains("finalizeCompletedRace(pending.toSnapshot())"))
        assertTrue(main.contains("isRaceResultAcknowledged(store.season, recoveredRound)"))
        assertTrue(main.contains("store.acknowledgeRaceAndAdvance(store.season, round.round)"))
    }

    @Test fun pendingResultIsKeptUntilThePlayerAcknowledgesTheResultScreen() {
        val main = source("app/src/main/java/com/f1teammanager/MainActivity.kt")
        val finalization = main.substring(main.indexOf("private fun finalizeCompletedRaceLocked"), main.indexOf("fun simulateWeekendInstantlyForCareer()"))
        assertTrue(finalization.contains("finalizationJournal.complete()"))
        assertTrue(!finalization.contains("clearPendingRaceFinalization"))
        val returnFlow = main.substring(main.indexOf("fun returnToCalendarAfterRace()"), main.indexOf("fun startNextSeason()"))
        assertTrue(returnFlow.indexOf("store.acknowledgeRaceAndAdvance") < returnFlow.indexOf("clearPendingRaceFinalization"))
        val prefs = source("app/src/main/java/com/f1teammanager/CareerPreferences.kt")
        assertTrue(prefs.contains("pending_race_result_${'$'}{seasonNumber}_${'$'}round"))
        assertTrue(prefs.contains("fun savePendingRaceFinalization"))
        assertTrue(prefs.contains("fun loadPendingRaceFinalization"))
        assertTrue(prefs.contains("val staleRaceKeys = prefs.all.keys.filter"))
        assertTrue(prefs.contains("key.startsWith(\"race_finalize_\")"))
    }


    @Test fun resultAcknowledgementAndCalendarAdvanceShareOneDurableCommit() {
        val prefs = source("app/src/main/java/com/f1teammanager/CareerPreferences.kt")
        val transaction = prefs.substring(prefs.indexOf("fun acknowledgeRaceAndAdvance"), prefs.indexOf("@Synchronized\n    fun recordRace"))
        assertTrue(transaction.contains("isRaceFinalized(seasonNumber, round)"))
        assertTrue(transaction.contains("putBoolean(\"race_result_acknowledged_${'$'}{seasonNumber}_${'$'}round\", true)"))
        assertTrue(transaction.contains("editor.putInt(\"roundIndex\", nextIndex)"))
        assertTrue(transaction.contains("editor.commit()"))
        val main = source("app/src/main/java/com/f1teammanager/MainActivity.kt")
        val returnFlow = main.substring(main.indexOf("fun returnToCalendarAfterRace()"), main.indexOf("fun startNextSeason()"))
        assertTrue(returnFlow.contains("store.acknowledgeRaceAndAdvance(store.season, round.round)"))
        assertTrue(!returnFlow.contains("store.completeCurrentRace()"))
        assertTrue(main.contains("V377 migration recovery"))
    }


    @Test fun playerRaceFinanceAndSponsorDurationArePersistedTogether() {
        val prefs = source("app/src/main/java/com/f1teammanager/CareerPreferences.kt")
        assertTrue(prefs.contains("fun saveFinanceAndSponsors(forTeamId: Int, finance: TeamFinanceState, sponsors: List<SponsorContract>): Boolean"))
        assertTrue(prefs.contains("sponsorEditor(financeEditor(forTeamId, finance), forTeamId, sponsors).commit()"))
        val main = source("app/src/main/java/com/f1teammanager/MainActivity.kt")
        val financeStep = main.substring(main.indexOf("runFinalizationStep(\"player_finance\")"), main.indexOf("runFinalizationStep(\"player_salary\")"))
        assertTrue(financeStep.contains("store.saveFinanceAndSponsors(teamId, managerState.finance, managerState.sponsors)"))
        assertTrue(!financeStep.contains("store.saveFinance(teamId, managerState.finance)"))
        assertTrue(!financeStep.contains("store.saveSponsors(teamId, managerState.sponsors)"))
    }


    @Test fun driverEvolutionAndItsNewsUseADurableRecoveryOutbox() {
        val prefs = source("app/src/main/java/com/f1teammanager/CareerPreferences.kt")
        val evolution = prefs.substring(prefs.indexOf("fun applyDriverRaceEvolution(round: Int)"), prefs.indexOf("fun applySeasonEndRegression"))
        assertTrue(evolution.contains("pendingDriverEvolutionNewsKey(season, round)"))
        assertTrue(evolution.contains("flushPendingDriverEvolutionNews(season, round)"))
        assertTrue(evolution.contains("evolutionCommit.commit()"))
        assertTrue(prefs.contains("driverMarketEditor(prefs.edit(), state).remove(pendingKey).commit()"))
        assertTrue(prefs.contains("processedRounds[round] == 1"))
        assertTrue(prefs.contains("flushPendingDriverEvolutionNews(season, round)"))
    }


    @Test fun completedButUnacknowledgedRaceRestoresTheFullPersistedResult() {
        val main = source("app/src/main/java/com/f1teammanager/MainActivity.kt")
        assertTrue(main.contains("!store.isRaceResultAcknowledged(it.season, it.round)"))
        assertTrue(main.contains("pending != null && store.isRaceFinalized(pending.season, pending.round)"))
        assertTrue(main.contains("result = pending.result"))
        assertTrue(main.contains("do not replay career side effects"))
    }

    private fun source(relativePath: String): String {
        val candidates = generateSequence(File(System.getProperty("user.dir"))) { it.parentFile }
            .map { File(it, relativePath) }.firstOrNull { it.isFile }
        return requireNotNull(candidates) { "Source not found: ${'$'}relativePath" }.readText()
    }
}
