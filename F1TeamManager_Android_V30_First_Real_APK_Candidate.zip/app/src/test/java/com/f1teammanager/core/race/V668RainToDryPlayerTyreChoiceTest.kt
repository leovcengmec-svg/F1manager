package com.f1teammanager.core.race

import kotlin.random.Random
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class V668RainToDryPlayerTyreChoiceTest {
    private val circuit = RaceCircuit(25, "Spa-Francorchamps", 58, 92_000L)

    private fun roster(): List<RaceParticipant> = (1..80).map { id ->
        val teamId = (id + 1) / 2
        RaceParticipant(
            driverId = id,
            driverName = "Driver $id",
            teamId = teamId,
            teamName = "Team $teamId",
            driverSpeed = 70,
            qualifying = 70,
            overtaking = 68,
            defense = 68,
            consistency = 75,
            enginePerformance = 72,
            tyreGrip = 70,
            tyreWear = 65,
            wetSkill = 75
        )
    }

    private fun engineWithWetRaceStart(): CareerWeekendEngine {
        val wetSeed = (1..10_000).first { seed ->
            CircuitWeatherModel.raceStartWeather(circuit, Random(seed xor 0x6327EA71)) in
                listOf(Weather.LIGHT_RAIN, Weather.MEDIUM_RAIN, Weather.HEAVY_RAIN)
        }
        val engine = CareerWeekendEngine(wetSeed)
        engine.start(roster(), circuit, playerTeamId = 1)
        engine.simulateQualifyingInstantly()
        val start = engine.prepareRaceStartWeather()
        assertTrue(
            "O cenário de regressão precisa começar com chuva",
            start.weather in listOf(Weather.LIGHT_RAIN, Weather.MEDIUM_RAIN, Weather.HEAVY_RAIN)
        )
        assertEquals(2, start.plans.size)
        assertTrue(start.carStatus.filter { it.driverId in 1..2 }.all { it.tyre in TyreModel.wetCompounds })
        return engine
    }

    @Test
    fun wetRaceStartThenDryingPausesAndNeverMountsHardAutomatically() {
        val engine = engineWithWetRaceStart()
        val paused = engine.requestPlayerTyreChoiceAfterRain(Weather.HEAVY_RAIN, Weather.DRY)
        assertTrue("A transição para seco deve solicitar decisão", paused)

        val snapshot = engine.snapshotForUi()
        assertNotNull(snapshot.decision)
        val decision = snapshot.decision!!
        assertEquals(ManagerDecisionType.WEATHER_CHANGE, decision.request.type)
        assertEquals(ManagerDecisionAction.BOX, decision.request.options.first())
        assertTrue(decision.request.message.contains("nenhuma troca será feita automaticamente", ignoreCase = true))
        assertTrue("O seletor deve cobrir somente os pilotos que ainda usam pneus de chuva",
            snapshot.carStatus.filter { it.driverId in 1..2 }.all { it.tyre in TyreModel.wetCompounds })
        assertTrue("Nenhuma parada pode acontecer antes da escolha do jogador",
            snapshot.carStatus.filter { it.driverId in 1..2 }.all { it.pitStops == 0 })
        assertTrue(snapshot.plans.values.all { it.weatherManualMode })
        assertTrue("BOX direto não pode escolher um composto sem abrir o seletor", runCatching {
            engine.choose(ManagerDecisionAction.BOX)
        }.isFailure)
        val afterBlockedBox = engine.snapshotForUi()
        assertNotNull(afterBlockedBox.decision)
        assertTrue(afterBlockedBox.carStatus.filter { it.driverId in 1..2 }.all { it.tyre in TyreModel.wetCompounds })
        assertTrue(afterBlockedBox.carStatus.filter { it.driverId in 1..2 }.all { it.pitStops == 0 })
    }

    @Test
    fun playerCanChooseSoftAndHardAfterRainWithoutEngineReplacingTheChoice() {
        val engine = engineWithWetRaceStart()
        assertTrue(engine.requestPlayerTyreChoiceAfterRain(Weather.MEDIUM_RAIN, Weather.CLOUDY))
        val firstDriver = engine.snapshotForUi().decision!!.request.driverId
        val secondDriver = (1..2).first { it != firstDriver }

        // A interface resolve a ação BOX como STAY_OUT para liberar o seletor de pneus;
        // depois aplica o composto explicitamente selecionado através de pitNow().
        engine.choose(ManagerDecisionAction.STAY_OUT)
        engine.pitNow(firstDriver, Tyre.SOFT)
        assertEquals(Tyre.SOFT, engine.snapshotForUi().carStatus.first { it.driverId == firstDriver }.tyre)

        engine.choose(ManagerDecisionAction.STAY_OUT)
        engine.pitNow(secondDriver, Tyre.HARD)
        val final = engine.snapshotForUi()
        assertEquals(Tyre.SOFT, final.carStatus.first { it.driverId == firstDriver }.tyre)
        assertEquals(Tyre.HARD, final.carStatus.first { it.driverId == secondDriver }.tyre)
        assertTrue(final.carStatus.filter { it.driverId in 1..2 }.all { it.pitStops == 1 })
    }

    @Test
    fun alreadyDryPlayerCarDoesNotReceiveUnnecessaryRainEndingPrompt() {
        val engine = engineWithWetRaceStart()
        engine.pitNow(1, Tyre.MEDIUM)
        assertTrue(engine.requestPlayerTyreChoiceAfterRain(Weather.LIGHT_RAIN, Weather.DRY))
        val snapshot = engine.snapshotForUi()
        assertEquals(2, snapshot.plans.size)
        assertEquals("Somente o piloto ainda com pneu de chuva deve receber a decisão", 2, snapshot.decision!!.request.driverId)
        assertEquals(Tyre.MEDIUM, snapshot.carStatus.first { it.driverId == 1 }.tyre)
    }

    @Test
    fun dryWeatherTransitionHandlerRejectsNonDryOrNonRainTransitions() {
        val engine = engineWithWetRaceStart()
        assertFalse(engine.requestPlayerTyreChoiceAfterRain(Weather.DRY, Weather.CLOUDY))
        assertFalse(engine.requestPlayerTyreChoiceAfterRain(Weather.HEAVY_RAIN, Weather.MEDIUM_RAIN))
        assertTrue(engine.snapshotForUi().decision == null)
    }
}
