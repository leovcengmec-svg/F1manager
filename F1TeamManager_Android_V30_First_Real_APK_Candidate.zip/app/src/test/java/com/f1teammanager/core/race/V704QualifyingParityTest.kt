package com.f1teammanager.core.race

import kotlin.random.Random
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class V704QualifyingParityTest {
    private fun participants() = (1..80).map { id ->
        RaceParticipant(
            driverId = id,
            driverName = "Driver $id",
            teamId = ((id - 1) / 2) + 1,
            teamName = "Team ${((id - 1) / 2) + 1}",
            driverSpeed = 75,
            qualifying = 75,
            overtaking = 70,
            defense = 70,
            consistency = 90,
            enginePerformance = 75,
            tyreGrip = 75,
            tyreWear = 90,
            reliability = 100,
            wetSkill = 75,
            chassisPerformance = 75,
            frontWingPerformance = 75,
            rearWingPerformance = 75,
            brakesPerformance = 75,
            electricPowerUnitPerformance = 75,
            engineReliability = 100,
            chassisReliability = 100,
            frontWingReliability = 100,
            rearWingReliability = 100,
            brakesReliability = 100,
            electricPowerUnitReliability = 100
        )
    }

    @Test
    fun manualAndInstantQualifyingBuildTheSameGrid() {
        val circuit = RaceCircuit(704, "Parity GP", 5, 90_000L, 0.0, 0.0, 0.0)
        val manual = CareerWeekendEngine(seed = 704)
        val instant = CareerWeekendEngine(seed = 704)
        manual.start(participants(), circuit, 1)
        instant.start(participants(), circuit, 1)

        while (!manual.qualifyingComplete()) manual.advanceQualifyingTimeSlice(20_000L)
        val instantResult = instant.simulateQualifyingInstantly()
        val manualResult = manual.snapshotForUi()

        assertEquals(instantResult.grid!!.grid, manualResult.grid!!.grid)
        assertEquals(instantResult.grid!!.phases, manualResult.grid!!.phases)
    }

    @Test
    fun rainyOpeningQ1UsesWetWeatherCompoundImmediately() {
        val circuit = RaceCircuit(25, "Spa-Francorchamps", 58, 92_000L)
        val seed = (1..10_000).first { candidate ->
            val random = Random(candidate xor 0x5A17C0DE)
            CircuitWeatherModel.qualifyingStartWeather(circuit, random) in setOf(
                Weather.LIGHT_RAIN, Weather.MEDIUM_RAIN, Weather.HEAVY_RAIN
            )
        }
        val engine = CareerWeekendEngine(seed)
        engine.start(participants(), circuit, 1)
        val snapshot = engine.snapshotForUi()
        val expectedTyre = when (snapshot.weather) {
            Weather.LIGHT_RAIN, Weather.MEDIUM_RAIN -> Tyre.INTERMEDIATE
            Weather.HEAVY_RAIN -> Tyre.WET
            Weather.DRY, Weather.CLOUDY -> error("Seed must begin with rain")
        }
        assertTrue(snapshot.qualifyingTyres.isNotEmpty())
        assertTrue(snapshot.qualifyingTyres.values.all { it == expectedTyre })
    }
}
