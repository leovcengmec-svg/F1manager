package com.f1teammanager.core.race

import com.f1teammanager.core.manager.DriverMarketEngine
import com.f1teammanager.core.manager.FinanceEngine
import com.f1teammanager.core.manager.TeamCarState
import com.f1teammanager.core.manager.TeamFinanceState
import com.f1teammanager.core.manager.TeamManagerState
import com.f1teammanager.core.manager.TeamSponsorshipEngine
import com.f1teammanager.core.season.WorldDatabase
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * V366: integration-level domain audit for instant race simulation and replay-safe
 * player settlement. This is not an Android persistence/build test; it exercises the
 * actual domain engines and the exported/restored sponsorship snapshot.
 */
class InstantSimulationCareerSettlementV366Test {
    private fun participants() = (1..80).map { id ->
        val teamId = ((id - 1) / 2) + 1
        RaceParticipant(
            driverId = id, driverName = "Driver $id", teamId = teamId, teamName = "Team $teamId",
            driverSpeed = 68 + id % 17, qualifying = 70 + id % 19,
            overtaking = 65 + id % 23, defense = 64 + id % 21,
            consistency = 78 + id % 18, enginePerformance = 70 + id % 20,
            tyreGrip = 70 + id % 20, tyreWear = 72 + id % 19,
            reliability = 88 + id % 13, wetSkill = 65 + id % 30,
            chassisPerformance = 68 + id % 22, frontWingPerformance = 68 + id % 22,
            rearWingPerformance = 68 + id % 22, brakesPerformance = 68 + id % 22,
            electricPowerUnitPerformance = 68 + id % 22, engineReliability = 88 + id % 13,
            chassisReliability = 88 + id % 13, frontWingReliability = 88 + id % 13,
            rearWingReliability = 88 + id % 13, brakesReliability = 88 + id % 13,
            electricPowerUnitReliability = 88 + id % 13
        )
    }

    @Test
    fun rejectsCircuitMismatchBeforeMutatingStartedWeekend() {
        val teamId = WorldDatabase.teams.first().id
        val drivers = participants()
        val startedCircuit = RaceCircuit(
            id = 77, name = "Circuito correto", laps = 6, baseLapTimeMs = 91_000L,
            crashRisk = 0.2, reliabilityRisk = 0.15, safetyCarRisk = 0.1
        )
        val engine = CareerWeekendEngine(seed = 367)
        engine.start(drivers, startedCircuit, teamId)
        val before = engine.snapshotForUi()
        val wrongCircuit = startedCircuit.copy(id = 78, name = "Circuito incorreto")

        val failure = runCatching {
            InstantSimulationService.completeStartedWeekend(engine, wrongCircuit)
        }.exceptionOrNull()

        assertTrue("mismatch must be rejected", failure is IllegalArgumentException)
        val after = engine.snapshotForUi()
        assertEquals("phase must remain unchanged", before.phase, after.phase)
        assertEquals("lap must remain unchanged", before.lap, after.lap)
        assertEquals("grid must remain unchanged", before.grid, after.grid)
    }

    @Test
    fun sixtyInstantRacesSettleFinanceOnceAndPersistSponsorshipRoundKeys() {
        val playerTeamId = WorldDatabase.teams.first().id
        val market = DriverMarketEngine().initialState(2026)
        var manager = TeamManagerState(
            season = 2026, round = 1, playerTeamId = playerTeamId,
            car = TeamCarState(70, 70, 70, 70),
            finance = TeamFinanceState(250_000_000L), driverMarket = market
        )
        var sponsorship = TeamSponsorshipEngine(seed = 366)
        val drivers = participants()
        var races = 0

        repeat(60) { index ->
            val season = 2026 + index / 30
            val round = index % 30 + 1
            val circuit = RaceCircuit(
                id = index + 1, name = "Season $season GP $round", laps = 5 + round % 3,
                baseLapTimeMs = 90_000L + round * 175L,
                crashRisk = 0.2, reliabilityRisk = 0.2, safetyCarRisk = 0.15
            )
            val engine = CareerWeekendEngine(seed = season * 100 + round)
            engine.start(drivers, circuit, playerTeamId)
            val weekend = InstantSimulationService.completeStartedWeekend(engine, circuit)
            val teamEntries = weekend.result.classification.filter { it.teamId == playerTeamId || it.teamName == "Team $playerTeamId" }
            val best = teamEntries.minOf { it.position }
            val points = teamEntries.sumOf { weekend.result.points[it.driverId] ?: 0 }
            val dnf = teamEntries.all { it.status.startsWith("DNF") }

            manager = manager.copy(season = season, round = round)
            val settled = FinanceEngine().applyRace(manager, best, points, dnf, season, round)
            val replayed = FinanceEngine().applyRace(settled, best, points, dnf, season, round)
            assertEquals("finance replay $season/$round", settled.finance, replayed.finance)
            manager = settled

            val before = sponsorship.forTeam(playerTeamId, season)
            val after = sponsorship.advanceRace(playerTeamId, season, round)
            val restored = TeamSponsorshipEngine(seed = 366)
            restored.restoreSnapshot(sponsorship.exportSnapshot())
            assertEquals("sponsor replay $season/$round", after, restored.advanceRace(playerTeamId, season, round))
            assertEquals("sponsor contract duration $season/$round", after, restored.forTeam(playerTeamId, season))
            assertTrue("sponsor count remains five", before.sponsors.size == 5 && after.sponsors.size == 5)
            sponsorship = restored
            races++
        }

        assertEquals(60, races)
        assertEquals(60, manager.finance.raceSettlementKeys.size)
        val meta = sponsorship.exportSnapshot().lineSequence().first { it.startsWith("@V356|") }.substringAfter("@V356|")
        val processedKeys = String(java.util.Base64.getDecoder().decode(meta), Charsets.UTF_8)
            .lineSequence().filter { it.isNotBlank() }.toSet()
        assertEquals(60, processedKeys.size)
    }
}
