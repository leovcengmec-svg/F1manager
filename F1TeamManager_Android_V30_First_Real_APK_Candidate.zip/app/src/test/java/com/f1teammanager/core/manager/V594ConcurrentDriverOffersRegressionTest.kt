package com.f1teammanager.core.manager

import com.f1teammanager.core.season.WorldDatabase
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class V594ConcurrentDriverOffersRegressionTest {
    @Test
    fun oneAcceptedOfferCancelsCompetingOffersForSameDriverAndSeason() {
        val engine = DriverMarketEngine(20261017)
        val initial = engine.initialState(2026)
        val freeDriver = initial.freeAgents.first()
        val teamA = WorldDatabase.teams[0]
        val teamB = WorldDatabase.teams[1]
        val replacementA = engine.roster(initial, teamA.id, season = 2026).first()
        val replacementB = engine.roster(initial, teamB.id, season = 2026).first()

        val (afterA, offerA) = engine.makeOffer(
            initial, freeDriver, teamA.id, 2, engine.salaryFor(freeDriver), DriverTeamRole.EQUAL,
            2026, currentWeek = 56, replaceDriverId = replacementA, proposerTeamId = teamA.id
        )
        val (afterB, offerB) = engine.makeOffer(
            afterA, freeDriver, teamB.id, 2, engine.salaryFor(freeDriver), DriverTeamRole.EQUAL,
            2026, currentWeek = 56, replaceDriverId = replacementB, proposerTeamId = teamB.id
        )
        val ready = afterB.copy(pending = afterB.pending.map { it.copy(interestScore = 100, expiresAfterWeek = 56) })

        val resolved = engine.expireOffers(ready, currentWeek = 56, season = 2026, playerTeamId = Int.MIN_VALUE)

        assertEquals("Only one future contract may be signed for the driver", 1, resolved.scheduled.count { it.driverId == freeDriver && it.startSeason == 2027 })
        assertTrue("All competing offers for the signed target season must be closed", resolved.pending.none { it.driverId == freeDriver && it.seasonTarget == 2027 })
        assertFalse(
            "A stale offer must not generate a false failure notice",
            resolved.notifications.any { it.title == "PROPOSTA NÃO CONCLUÍDA" && it.message.contains(WorldDatabase.allDrivers.first { d -> d.id == freeDriver }.name) }
        )
        assertTrue("An accepted offer must correspond to exactly one destination", resolved.scheduled.single { it.driverId == freeDriver }.toTeamId in setOf(teamA.id, teamB.id))
        assertEquals("Both input offers were the same target season", offerA.seasonTarget, offerB.seasonTarget)
    }
}
