package com.f1teammanager.core.manager

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class RaceFinalizationJournalV371Test {
    private class FakeStore {
        val done = mutableSetOf<Triple<Int, Int, String>>()
        var failNextCommit = false
        fun journal(season: Int, round: Int, totalRounds: Int = 30) = RaceFinalizationJournal(
            season, round,
            isDone = { s, r, step -> Triple(s, r, step) in done },
            markDone = { s, r, step ->
                if (failNextCommit) { failNextCommit = false; false }
                else done.add(Triple(s, r, step))
            },
            totalRounds = totalRounds
        )
        fun runThrough(season: Int, round: Int, through: String, totalRounds: Int = 30) {
            val j = journal(season, round, totalRounds)
            for (step in RaceFinalizationPlan.steps(round, totalRounds)) {
                if (step == through) return
                j.runStep(step) { }
            }
            error("step '$through' not in plan")
        }
    }

    @Test fun stepsAreScopedToSeasonAndRound() {
        val store = FakeStore()
        var effects = 0
        store.journal(2026, 4).runStep("player_finance") { effects++ }
        store.journal(2027, 4).runStep("player_finance") { effects++ }
        store.journal(2027, 5).runStep("player_finance") { effects++ }
        assertEquals(3, effects)
    }

    @Test fun completedStepIsSkippedAfterItsPredecessorsAreDurable() {
        val store = FakeStore()
        store.runThrough(2026, 4, "race_record")
        var effects = 0
        store.journal(2026, 4).runStep("race_record") { effects++ }
        store.journal(2026, 4).runStep("race_record") { effects++ }
        assertEquals(1, effects)
        assertTrue(Triple(2026, 4, "race_record") in store.done)
    }

    @Test fun outOfOrderStepIsRejectedWithoutRunningItsAction() {
        val store = FakeStore()
        var effects = 0
        val result = runCatching { store.journal(2026, 7).runStep("ai_finance") { effects++ } }
        assertTrue(result.isFailure)
        assertEquals(0, effects)
        assertFalse(Triple(2026, 7, "ai_finance") in store.done)
    }

    @Test fun actionFailureDoesNotWriteCompletionMarker() {
        val store = FakeStore()
        store.runThrough(2026, 7, "ai_finance")
        runCatching { store.journal(2026, 7).runStep("ai_finance") { error("simulated interruption") } }
        assertFalse(Triple(2026, 7, "ai_finance") in store.done)
    }

    @Test fun failedMarkerCommitIsReportedAndCanBeRetried() {
        val store = FakeStore()
        store.runThrough(2026, 8, "race_news")
        var effects = 0
        store.failNextCommit = true
        val first = runCatching { store.journal(2026, 8).runStep("race_news") { effects++ } }
        assertTrue(first.isFailure)
        assertFalse(Triple(2026, 8, "race_news") in store.done)
        store.journal(2026, 8).runStep("race_news") { effects++ }
        assertEquals(2, effects) // action must be idempotent across this crash window
        assertTrue(Triple(2026, 8, "race_news") in store.done)
    }

    @Test fun gp30CannotCompleteUntilSeasonPrizesAndFinalPersistenceAreCommitted() {
        val store = FakeStore()
        val journal = store.journal(2026, 30)
        val premature = runCatching { journal.complete() }
        assertTrue(premature.isFailure)
        for (step in RaceFinalizationPlan.steps(30, 30)) journal.runStep(step) { }
        journal.complete()
        assertTrue(Triple(2026, 30, "season_prizes") in store.done)
        assertTrue(Triple(2026, 30, "persist_final_state") in store.done)
        assertTrue(Triple(2026, 30, "complete") in store.done)
    }

    @Test fun nonFinalGpDoesNotAcceptSeasonPrizeStep() {
        val store = FakeStore()
        val result = runCatching { store.journal(2026, 29).runStep("season_prizes") { } }
        assertTrue(result.isFailure)
    }

    @Test fun invalidRoundIsRejectedBeforeAnyAction() {
        val result = runCatching { RaceFinalizationJournal(2026, 31, { _, _, _ -> false }, { _, _, _ -> true }) }
        assertTrue(result.isFailure)
    }
}
