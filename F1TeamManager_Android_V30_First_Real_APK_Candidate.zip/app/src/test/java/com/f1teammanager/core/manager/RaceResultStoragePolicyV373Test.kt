package com.f1teammanager.core.manager

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class RaceResultStoragePolicyV373Test {
    @Test fun canonicalKeysKeepSameRoundSeparateAcrossSeasons() {
        assertEquals("race_2026_1", RaceResultStoragePolicy.canonicalKey(2026, 1))
        assertEquals("race_2027_1", RaceResultStoragePolicy.canonicalKey(2027, 1))
        assertEquals("race_2026_30", RaceResultStoragePolicy.canonicalKey(2026, 30))
    }

    @Test fun legacyAliasCanOnlyBeReadForFirstSeason() {
        assertEquals("race_1", RaceResultStoragePolicy.legacyReadKey(1, 1))
        assertNull(RaceResultStoragePolicy.legacyReadKey(2026, 1))
        assertNull(RaceResultStoragePolicy.legacyReadKey(2027, 30))
    }

    @Test fun rejectsInvalidSeasonOrRound() {
        val invalidSeason = runCatching { RaceResultStoragePolicy.canonicalKey(0, 1) }.exceptionOrNull()
        val invalidRound = runCatching { RaceResultStoragePolicy.canonicalKey(2026, 31) }.exceptionOrNull()
        assertEquals(IllegalArgumentException::class.java, invalidSeason!!::class.java)
        assertEquals(IllegalArgumentException::class.java, invalidRound!!::class.java)
    }
}
