package com.f1teammanager.core.race

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class FreeTyrePlanV659Test {
    @Test
    fun sixStintsCanCoverEveryLapOfTheGrandPrix() {
        val result = TyreModel.validateFreePlan(
            requiredLaps = 58,
            weather = Weather.DRY,
            mode = DriverStrategyMode.BALANCED,
            driverTyreWear = 50,
            sequence = List(6) { Tyre.HARD },
            stintLaps = listOf(10, 10, 10, 10, 9, 9)
        )

        assertTrue(result.valid)
        assertTrue(result.coverageComplete)
        assertEquals(100, result.coveragePercent)
        assertEquals("APTO • COBRE 100% DO GP", result.status)
    }

    @Test
    fun sixStintsAlsoValidateForBothRainTyreTypes() {
        val wetStints = listOf(10, 10, 10, 10, 9, 9)
        val intermediate = TyreModel.validateFreePlan(
            58, Weather.LIGHT_RAIN, DriverStrategyMode.BALANCED, 50,
            List(6) { Tyre.INTERMEDIATE }, wetStints
        )
        val wet = TyreModel.validateFreePlan(
            58, Weather.HEAVY_RAIN, DriverStrategyMode.BALANCED, 50,
            List(6) { Tyre.WET }, wetStints
        )

        assertTrue(intermediate.valid)
        assertTrue(wet.valid)
        assertEquals(100, intermediate.coveragePercent)
        assertEquals(100, wet.coveragePercent)
    }

    @Test
    fun incompleteAndOverlongPlansAreNotApproved() {
        val short = TyreModel.validateFreePlan(
            58, Weather.DRY, DriverStrategyMode.BALANCED, 50,
            listOf(Tyre.HARD, Tyre.HARD), listOf(29, 28)
        )
        val long = TyreModel.validateFreePlan(
            58, Weather.DRY, DriverStrategyMode.BALANCED, 50,
            listOf(Tyre.HARD, Tyre.HARD), listOf(29, 30)
        )

        assertFalse(short.valid)
        assertEquals(98, short.coveragePercent)
        assertTrue(short.issues.any { it.contains("Faltam 1 volta") })
        assertFalse(long.valid)
        assertTrue(long.issues.any { it.contains("excede o GP") })
    }

    @Test
    fun fullCoverageDoesNotApproveAnUnsafeStint() {
        val result = TyreModel.validateFreePlan(
            58, Weather.DRY, DriverStrategyMode.BALANCED, 50,
            listOf(Tyre.HARD, Tyre.HARD), listOf(31, 27)
        )

        assertTrue(result.coverageComplete)
        assertFalse(result.safe)
        assertFalse(result.valid)
        assertTrue(result.status.contains("100% COBERTO"))
        assertTrue(result.issues.any { it.contains("excedem a janela segura") })
    }

    @Test
    fun weatherCompatibilityIsPartOfTheValidation() {
        val result = TyreModel.validateFreePlan(
            58, Weather.HEAVY_RAIN, DriverStrategyMode.BALANCED, 50,
            listOf(Tyre.INTERMEDIATE, Tyre.WET), listOf(20, 38)
        )

        assertFalse(result.valid)
        assertTrue(result.issues.any { it.contains("incompatível com o clima") })
    }

    @Test
    fun moreThanSixStintsAreRejected() {
        val result = TyreModel.validateFreePlan(
            58, Weather.DRY, DriverStrategyMode.BALANCED, 50,
            List(7) { Tyre.HARD }, listOf(9, 9, 8, 8, 8, 8, 8)
        )

        assertFalse(result.valid)
        assertTrue(result.issues.any { it.contains("limite é de seis stints") })
    }
}
