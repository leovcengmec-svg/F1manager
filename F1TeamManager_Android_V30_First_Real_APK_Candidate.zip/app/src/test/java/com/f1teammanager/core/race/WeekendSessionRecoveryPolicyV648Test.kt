package com.f1teammanager.core.race

import org.junit.Assert.assertEquals
import org.junit.Test

class WeekendSessionRecoveryPolicyV648Test {
    @Test
    fun matchingOutboxAlwaysWinsAndIsFinalizedFromSavedResult() {
        assertEquals(
            WeekendSessionRecoveryPolicy.Action.FINALIZE_DURABLE_RESULT,
            WeekendSessionRecoveryPolicy.decide(hasMatchingPendingResult = true, isAlreadyFinalized = false)
        )
        assertEquals(
            WeekendSessionRecoveryPolicy.Action.FINALIZE_DURABLE_RESULT,
            WeekendSessionRecoveryPolicy.decide(hasMatchingPendingResult = true, isAlreadyFinalized = true)
        )
    }

    @Test
    fun alreadyFinalizedResultIsRestoredWithoutReplayingEffects() {
        assertEquals(
            WeekendSessionRecoveryPolicy.Action.RESTORE_ALREADY_FINALIZED_RESULT,
            WeekendSessionRecoveryPolicy.decide(hasMatchingPendingResult = false, isAlreadyFinalized = true)
        )
    }

    @Test
    fun incompleteSessionIsDiscardedWithoutCareerSettlement() {
        assertEquals(
            WeekendSessionRecoveryPolicy.Action.DISCARD_INCOMPLETE_SESSION,
            WeekendSessionRecoveryPolicy.decide(hasMatchingPendingResult = false, isAlreadyFinalized = false)
        )
    }
}
