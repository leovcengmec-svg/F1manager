package com.f1teammanager.core.manager

import com.f1teammanager.core.season.WorldDatabase
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** Regression coverage for accepting an external Team Principal job at the end of a career season. */
class V638TeamPrincipalHandoffRegressionTest {
    private val budgets = WorldDatabase.teams.associate { it.id to 100_000_000L }

    @Test fun `accepted principal handoff can pass pre-rollover roster gate but ordinary career cannot`() {
        assertTrue(TeamPrincipalCareerEngine.mayAdvanceWithProjectedRoster(0, acceptedHandoffForTargetSeason = true))
        assertTrue(TeamPrincipalCareerEngine.mayAdvanceWithProjectedRoster(1, acceptedHandoffForTargetSeason = true))
        assertFalse(TeamPrincipalCareerEngine.mayAdvanceWithProjectedRoster(0, acceptedHandoffForTargetSeason = false))
        assertFalse(TeamPrincipalCareerEngine.mayAdvanceWithProjectedRoster(1, acceptedHandoffForTargetSeason = false))
        assertTrue(TeamPrincipalCareerEngine.mayAdvanceWithProjectedRoster(2, acceptedHandoffForTargetSeason = false))
        assertFalse(TeamPrincipalCareerEngine.mayAdvanceWithProjectedRoster(3, acceptedHandoffForTargetSeason = false))
    }

    @Test fun `incoming Team Principal team is completed by offseason market before player takes control`() {
        val engine = DriverMarketEngine(20261019)
        val initial = engine.initialState(2026)
        val incomingTeam = WorldDatabase.teams.first { engine.roster(initial, it.id, season = 2027).size < 2 }
        val projectedRosterBeforeOffseason = engine.roster(initial, incomingTeam.id, season = 2027)
        assertTrue("Test fixture must reproduce an incomplete future lineup", projectedRosterBeforeOffseason.size < 2)

        // Normal player-team behavior must stay strict: without a handoff, the engine does not
        // silently assign a driver to the human-controlled team.
        val ordinaryTransition = engine.applySeasonTransition(initial, 2027, budgets, playerTeamId = incomingTeam.id)
        assertEquals(projectedRosterBeforeOffseason, engine.roster(ordinaryTransition, incomingTeam.id, season = 2027))

        // A signed Team Principal contract is the one exception: the incoming team was AI-owned
        // while the offseason market resolves expired contracts, so it receives the same vacancy
        // resolution as the other AI teams before control switches to the player.
        val handoffTransition = engine.applySeasonTransition(
            initial, 2027, budgets, playerTeamId = incomingTeam.id,
            automaticVacancyFillTeamIds = setOf(incomingTeam.id)
        )
        assertEquals(2, engine.roster(handoffTransition, incomingTeam.id, season = 2027).size)
        WorldDatabase.teams.forEach { team ->
            assertEquals("${team.name} must have two signed drivers after a solvent handoff rollover", 2,
                engine.roster(handoffTransition, team.id, season = 2027).size)
        }
        assertEquals(80, handoffTransition.contracts.count { it.activeIn(2027) })
        assertEquals(handoffTransition.contracts.size, handoffTransition.contracts.map { it.driverId }.distinct().size)
    }

    @Test fun `incoming handoff does not abort market transition when the team cannot afford a vacancy`() {
        val engine = DriverMarketEngine(20261019)
        val initial = engine.initialState(2026)
        val incomingTeam = WorldDatabase.teams.first { engine.roster(initial, it.id, season = 2027).size < 2 }
        val constrainedBudgets = budgets + (incomingTeam.id to 0L)

        // The market must finish its transition even if a bankrupt incoming team cannot sign
        // a replacement. CareerPreferences surfaces a warning instead of throwing/rolling back
        // the Team Principal handoff, so the user can reach the new team and the market screen.
        val transitioned = engine.applySeasonTransition(
            initial, 2027, constrainedBudgets, playerTeamId = incomingTeam.id,
            automaticVacancyFillTeamIds = setOf(incomingTeam.id)
        )
        assertTrue(engine.roster(transitioned, incomingTeam.id, season = 2027).size < 2)
    }

    @Test fun `accepted offer switches only at next season boundary`() {
        val openingRanks = (1..40).associateWith { it }
        val current = TeamPrincipalCareerEngine.initial(40, 2032, openingRanks)
            .copy(reviewPending = true, offerTeamIds = listOf(39, 38, 37))
        val accepted = TeamPrincipalCareerEngine.acceptOffer(current, 39, 2033, 12)

        assertEquals("The active contract identity remains on the old team until boundary", 40, current.teamId)
        assertEquals(39, accepted.teamId)
        assertEquals(2033, accepted.contractStartSeason)
        assertFalse(accepted.reviewPending)
        assertEquals(TeamPrincipalCareerEngine.INITIAL_BOARD_SUPPORT, accepted.boardSupport)
        assertTrue(accepted.contractYears in 1..2)
        assertTrue(accepted.offerTeamIds.isEmpty())
    }
}
