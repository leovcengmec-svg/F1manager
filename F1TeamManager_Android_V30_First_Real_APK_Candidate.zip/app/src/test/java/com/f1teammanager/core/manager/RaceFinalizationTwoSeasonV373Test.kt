package com.f1teammanager.core.manager

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** Integration contract for ordered finalization over the 60-GP, two-season chain. */
class RaceFinalizationTwoSeasonV373Test {
    @Test fun allSixtyRacesCompleteInOrderAndReplayDoesNotRepeatCommittedSteps() {
        val committed = mutableSetOf<String>()
        val calls = mutableMapOf<String, Int>()
        repeat(60) { index ->
            val season = 2026 + index / 30
            val round = index % 30 + 1
            val journal = RaceFinalizationJournal(
                season = season,
                round = round,
                isDone = { s, r, step -> "$s:$r:$step" in committed },
                markDone = { s, r, step -> committed.add("$s:$r:$step") },
                totalRounds = 30
            )
            val steps = RaceFinalizationPlan.steps(round, 30)
            steps.forEach { step ->
                journal.runStep(step) { calls["$season:$round:$step"] = (calls["$season:$round:$step"] ?: 0) + 1 }
            }
            journal.complete()
            // Replay all steps after the completion marker, as can happen on a duplicate callback.
            steps.forEach { step ->
                journal.runStep(step) { calls["$season:$round:$step"] = (calls["$season:$round:$step"] ?: 0) + 1 }
            }
            journal.complete()
            assertTrue("GP $season/$round must be durably complete", "$season:$round:${RaceFinalizationPlan.COMPLETE}" in committed)
            assertEquals("GP $season/$round should run each side effect once", steps.size, calls.count { it.key.startsWith("$season:$round:") && it.value == 1 })
            assertEquals("GP $season/$round has no repeated side effects", 0, calls.filterKeys { it.startsWith("$season:$round:") }.values.count { it > 1 })
            assertEquals(round == 30, RaceFinalizationPlan.SEASON_PRIZES in steps)
        }
        assertEquals(60, committed.count { it.endsWith(":${RaceFinalizationPlan.COMPLETE}") })
    }

    @Test fun interruptedStepCanBeRetriedWithoutSkippingItsPredecessors() {
        val committed = mutableSetOf<String>()
        val first = RaceFinalizationJournal(2026, 1,
            isDone = { s, r, step -> "$s:$r:$step" in committed },
            markDone = { s, r, step -> committed.add("$s:$r:$step") })
        val firstStep = RaceFinalizationPlan.steps(1, 30).first()
        runCatching { first.runStep(firstStep) { error("simulated interruption") } }
        assertTrue("failed action must not be marked done", "2026:1:$firstStep" !in committed)
        first.runStep(firstStep) { }
        assertTrue("successful retry must be marked done", "2026:1:$firstStep" in committed)
    }
}
