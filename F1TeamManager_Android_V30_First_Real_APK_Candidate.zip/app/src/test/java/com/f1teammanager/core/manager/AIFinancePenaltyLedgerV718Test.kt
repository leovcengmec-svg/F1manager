package com.f1teammanager.core.manager

import com.f1teammanager.core.season.WorldDatabase
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class AIFinancePenaltyLedgerV718Test {
    @Test
    fun historicalAiPenaltiesSurviveSnapshotRestoreAcrossSeasons() {
        val teamId = WorldDatabase.teams.first().id
        FinancialSeasonClosureEngine.restoreAiPenalties(emptySet())

        val original = AITeamFinancialEngine()
        val facilities = FacilityEngine.initial(WorldDatabase.teams.first().initialLevel)
        original.adoptFormerPlayerTeam(
            teamId,
            2026,
            TeamFinanceState(budget = -10_000_000L),
            facilities
        )
        original.applyEndOfSeasonFinancialPenalty(teamId, 2026)
        assertTrue(original.hadNegativeBalancePenalty(teamId, 2026))

        original.adoptFormerPlayerTeam(
            teamId,
            2027,
            TeamFinanceState(budget = -12_000_000L),
            facilities
        )
        original.applyEndOfSeasonFinancialPenalty(teamId, 2027)
        assertTrue(original.hadNegativeBalancePenalty(teamId, 2027))

        val payload = original.exportSnapshot()
        assertTrue(payload.contains("N|$teamId|2026"))
        assertTrue(payload.contains("N|$teamId|2027"))

        val restored = AITeamFinancialEngine()
        restored.restoreSnapshot(payload)

        assertTrue(restored.hadNegativeBalancePenalty(teamId, 2026))
        assertTrue(restored.hadNegativeBalancePenalty(teamId, 2027))
        assertTrue(FinancialSeasonClosureEngine.aiPenaltyActive(teamId, 2027))
        assertTrue(FinancialSeasonClosureEngine.aiPenaltyActive(teamId, 2028))
        // Export may lazily materialize compatibility defaults; the restored snapshot
        // must nevertheless preserve the exact non-empty projection fingerprint.
        assertEquals(original.performanceFingerprint(2028), restored.performanceFingerprint(2028))
    }
}
