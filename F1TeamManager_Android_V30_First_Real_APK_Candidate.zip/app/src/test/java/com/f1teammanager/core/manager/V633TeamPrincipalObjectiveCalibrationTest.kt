package com.f1teammanager.core.manager

import org.junit.Assert.assertEquals

import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class V633TeamPrincipalObjectiveCalibrationTest {
    private val standings = (1..40).associateWith { it }

    private fun facilities(level: Int): Map<FacilityType, Int> =
        FacilityType.values().associateWith { level.coerceIn(0, 10) }

    private fun goal(state: TeamPrincipalCareerState, kind: String): TeamPrincipalObjective =
        state.objectives.first { it.kind == kind }

    @Test fun newCarStrengthAndFacilityLevelsMakeMainObjectiveMoreDemanding() {
        val initial = TeamPrincipalCareerEngine.initial(40, 2027, standings)
        val basic = TeamPrincipalCareerEngine.prepareObjectivesForOpeningSeason(
            initial, 2027, standings, facilities(0), previousSeasonPoints = 0, cashBalance = 5_000_000L
        )
        val advanced = TeamPrincipalCareerEngine.prepareObjectivesForOpeningSeason(
            initial, 2027, standings, facilities(8), previousSeasonPoints = 0, cashBalance = 300_000_000L
        )

        assertEquals(37, basic.objectiveRank)
        assertTrue("Advanced facilities should raise the bar", advanced.objectiveRank < basic.objectiveRank)
        assertTrue(goal(advanced, "points").target > goal(basic, "points").target)
        assertTrue(goal(advanced, "cash").target > goal(basic, "cash").target)
        assertTrue(advanced.objectives.count { it.kind.startsWith("facility_") } >= 2)
    }

    @Test fun openingRankIsMoreImportantThanPreviousRankButPreviousSeasonStillMatters() {
        val original = TeamPrincipalCareerEngine.initial(20, 2027, standings).copy(lastRank = 24)
        val strongerOpening = TeamPrincipalCareerEngine.prepareObjectivesForOpeningSeason(
            original, 2027, standings + (20 to 8), facilities(4), previousSeasonPoints = 95, cashBalance = 60_000_000L
        )
        val weakerOpening = TeamPrincipalCareerEngine.prepareObjectivesForOpeningSeason(
            original, 2027, standings, facilities(4), previousSeasonPoints = 95, cashBalance = 60_000_000L
        )
        assertTrue(strongerOpening.objectiveRank < weakerOpening.objectiveRank)
        assertTrue(goal(strongerOpening, "points").target > 0)
        val sameWeakCarWithoutPointsHistory = TeamPrincipalCareerEngine.prepareObjectivesForOpeningSeason(
            original, 2027, standings, facilities(4), previousSeasonPoints = 0, cashBalance = 60_000_000L
        )
        assertTrue(goal(weakerOpening, "points").target > goal(sameWeakCarWithoutPointsHistory, "points").target)
    }

    @Test fun calibrationIsIdempotentAndPersistsAcrossSaveLoad() {
        val initial = TeamPrincipalCareerEngine.initial(40, 2027, standings)
        val prepared = TeamPrincipalCareerEngine.prepareObjectivesForOpeningSeason(
            initial, 2027, standings, facilities(8), previousSeasonPoints = 45, cashBalance = 85_000_000L
        )
        assertEquals(2027, prepared.objectivesPreparedForSeason)
        assertEquals(prepared, TeamPrincipalCareerState.decode(prepared.encode()))

        val retryWithChangedInputs = TeamPrincipalCareerEngine.prepareObjectivesForOpeningSeason(
            prepared, 2027, standings + (40 to 2), facilities(0), previousSeasonPoints = 0, cashBalance = 0L
        )
        assertEquals(prepared, retryWithChangedInputs)
    }

    @Test fun legacyCareerSaveLoadsWithoutCalibrationMarkerAndCanBePrepared() {
        val legacy = TeamPrincipalCareerState(
            teamId = 40,
            objectives = listOf(TeamPrincipalObjective("main_2027", "Objetivo principal", "Terminar melhor", "rank", 40, 4))
        )
        val fields = legacy.encode().split('#').take(13).toMutableList()
        fields[0] = "3" // schemas 1–3 didn't carry the calibration marker
        val decoded = TeamPrincipalCareerState.decode(fields.joinToString("#"))
        assertNotNull(decoded)
        assertEquals(0, decoded!!.objectivesPreparedForSeason)
        val prepared = TeamPrincipalCareerEngine.prepareObjectivesForOpeningSeason(
            decoded, 2027, standings, facilities(0), previousSeasonPoints = 10, cashBalance = 8_000_000L
        )
        assertTrue(prepared.objectiveRank < 40)
        assertEquals(2027, prepared.objectivesPreparedForSeason)
    }
}
