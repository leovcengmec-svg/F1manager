package com.f1teammanager.core.manager

import org.junit.Test
import kotlin.test.assertEquals

class ResearchPriceByTechnicalRankV474Test {
    @Test
    fun `P&D discount follows technical ranking bands`() {
        assertEquals(0, ResearchEngine.discountPercentForRank(1))
        assertEquals(0, ResearchEngine.discountPercentForRank(10))
        assertEquals(20, ResearchEngine.discountPercentForRank(11))
        assertEquals(20, ResearchEngine.discountPercentForRank(20))
        assertEquals(40, ResearchEngine.discountPercentForRank(21))
        assertEquals(40, ResearchEngine.discountPercentForRank(30))
        assertEquals(60, ResearchEngine.discountPercentForRank(31))
        assertEquals(60, ResearchEngine.discountPercentForRank(40))
    }

    @Test
    fun `P&D discounts preserve base costs`() {
        assertEquals(5_000_000L, ResearchEngine.adjustedCost(5_000_000L, 1))
        assertEquals(4_000_000L, ResearchEngine.adjustedCost(5_000_000L, 11))
        assertEquals(3_000_000L, ResearchEngine.adjustedCost(5_000_000L, 21))
        assertEquals(2_000_000L, ResearchEngine.adjustedCost(5_000_000L, 31))
        assertEquals(28_000_000L, ResearchEngine.baseCost(ResearchComplexity.EXPERIMENTAL))
    }
}
