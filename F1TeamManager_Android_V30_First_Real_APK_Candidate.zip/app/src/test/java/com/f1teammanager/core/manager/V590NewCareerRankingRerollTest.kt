package com.f1teammanager.core.manager

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Test

class V590NewCareerRankingRerollTest {
    @Test fun newSelectionNeverReusesThePendingSeed() {
        assertNotEquals(123, InitialTeamProfile.freshSelectionSeed(123, 123))
    }

    @Test fun acceptsRandomNonZeroSeedWhenItDiffersFromPrevious() {
        assertEquals(456, InitialTeamProfile.freshSelectionSeed(123, 456))
    }

    @Test fun zeroCandidateFallsBackToDifferentValidSeed() {
        val seed = InitialTeamProfile.freshSelectionSeed(123, 0)
        assertNotEquals(123, seed)
        assertNotEquals(0, seed)
    }

    @Test fun intMaxWrapsSafelyWithoutZero() {
        assertEquals(Int.MIN_VALUE, InitialTeamProfile.freshSelectionSeed(Int.MAX_VALUE, Int.MAX_VALUE))
    }

    @Test fun negativeOneDoesNotProduceZeroFallback() {
        assertEquals(1, InitialTeamProfile.freshSelectionSeed(-1, 0))
    }


    @Test fun freshRankingSeedChangesVisibleOrderAndChallengeChoices() {
        val teams = (1..40).map { id ->
            val level = when {
                id <= 10 -> InitialTeamProfile.FORTE
                id <= 28 -> InitialTeamProfile.MEDIO
                else -> InitialTeamProfile.FRACO
            }
            com.f1teammanager.core.season.TeamDefinition(
                id = id, name = "Equipe $id", driverIds = listOf(id * 2 - 1, id * 2),
                engine = 50, chassis = 50, reliability = 50, frontWing = 50,
                rearWing = 50, brakes = 50, electricPowerUnit = 50, initialLevel = level
            )
        }
        val previousSeed = 11111
        val previousRanking = InitialTeamProfile.openingRanking(teams, previousSeed).map { it.id }
        val previousWeakest = InitialTeamProfile.weakestInitialTeams(teams, 3, previousSeed).map { it.id }
        val nextSeed = InitialTeamProfile.freshRankingSeed(teams, previousSeed, 22222)
        assertNotEquals(previousSeed, nextSeed)
        assertNotEquals(previousRanking, InitialTeamProfile.openingRanking(teams, nextSeed).map { it.id })
        assertNotEquals(previousWeakest, InitialTeamProfile.weakestInitialTeams(teams, 3, nextSeed).map { it.id })
    }

    @Test fun explicitPreviewSeedsChangeChallengeRankingWithoutMutatingActiveCareer() {
        val teams = (1..40).map { id ->
            val level = when {
                id <= 10 -> InitialTeamProfile.FORTE
                id <= 28 -> InitialTeamProfile.MEDIO
                else -> InitialTeamProfile.FRACO
            }
            com.f1teammanager.core.season.TeamDefinition(
                id = id, name = "Equipe $id", driverIds = listOf(id * 2 - 1, id * 2),
                engine = 50, chassis = 50, reliability = 50, frontWing = 50,
                rearWing = 50, brakes = 50, electricPowerUnit = 50, initialLevel = level
            )
        }
        InitialTeamProfile.configureCareerSeed(7654321)
        val activeRankingBefore = InitialTeamProfile.openingRanking(teams).map { it.id }
        val firstChallenge = InitialTeamProfile.weakestInitialTeams(teams, 3, 11111).map { it.id }
        val secondChallenge = InitialTeamProfile.weakestInitialTeams(teams, 3, 22222).map { it.id }
        assertEquals(3, firstChallenge.size)
        assertEquals(3, secondChallenge.size)
        assertNotEquals(firstChallenge, secondChallenge)
        assertEquals(activeRankingBefore, InitialTeamProfile.openingRanking(teams).map { it.id })
    }
}
