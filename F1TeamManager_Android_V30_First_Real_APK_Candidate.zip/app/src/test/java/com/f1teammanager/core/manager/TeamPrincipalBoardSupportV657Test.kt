package com.f1teammanager.core.manager

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class TeamPrincipalBoardSupportV657Test {
    private val ranks = (1..40).associateWith { it }

    @Test fun initialContractStartsWithFiftyPercentBoardSupport() {
        val state = TeamPrincipalCareerEngine.initial(40, 2026, ranks)
        assertEquals(50, state.boardSupport)
    }

    @Test fun changingTeamsStartsTheNewBoardsSupportAtFiftyPercent() {
        val state = TeamPrincipalCareerEngine.initial(40, 2026, ranks).copy(
            boardSupport = 91,
            reviewPending = true,
            offerTeamIds = listOf(39),
            contractOffers = listOf(TeamPrincipalContractOffer(39, 2, false))
        )

        val accepted = TeamPrincipalCareerEngine.acceptOffer(
            state, newTeamId = 39, nextSeason = 2027, newTeamChampionshipRank = 12, contractYears = 2
        )

        assertEquals(39, accepted.teamId)
        assertEquals(50, accepted.boardSupport)
    }

    @Test fun liveSupportStaysAtBaselineBeforeFirstSportingResult() {
        assertEquals(
            50,
            TeamPrincipalCareerEngine.currentBoardSupport(
                baselineSupport = 50,
                rank = 40,
                objectiveRank = 30,
                completedObjectives = 0,
                evaluatedObjectives = 6,
                hasCurrentSeasonResults = false
            )
        )
    }

    @Test fun unplayedLegacyCareerIsNormalizedToFiftyPercentSupport() {
        val legacyOpening = TeamPrincipalCareerEngine.initial(40, 2026, ranks).copy(boardSupport = 75)
        val migrated = TeamPrincipalCareerState.decode(legacyOpening.encode())!!
        assertEquals(50, migrated.boardSupport)
    }

    @Test fun liveSupportRespondsToStandingsAndObjectiveDelivery() {
        val strong = TeamPrincipalCareerEngine.currentBoardSupport(
            baselineSupport = 50,
            rank = 8,
            objectiveRank = 10,
            completedObjectives = 5,
            evaluatedObjectives = 6,
            hasCurrentSeasonResults = true
        )
        val weak = TeamPrincipalCareerEngine.currentBoardSupport(
            baselineSupport = 50,
            rank = 25,
            objectiveRank = 10,
            completedObjectives = 1,
            evaluatedObjectives = 6,
            hasCurrentSeasonResults = true,
            repeatedObjectiveFailure = true
        )

        assertTrue("Good sporting delivery should increase visible support", strong > 50)
        assertTrue("Poor delivery should reduce visible support", weak < 50)
        assertTrue(
            "The live dismissal risk should react to the updated support and sporting position",
            TeamPrincipalCareerEngine.dismissalProbabilityPercent(strong, 8, 10) <
                TeamPrincipalCareerEngine.dismissalProbabilityPercent(weak, 25, 10, true)
        )
    }
}
