package com.f1teammanager.core.race

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class V666AiTyreStrategyTest {
    @Test
    fun dryAiStrategiesVaryByDriverAndTeamProfile() {
        val plans = (1..80).map { id ->
            TyreModel.buildAiRaceStrategy(
                totalLaps = 58,
                weather = Weather.DRY,
                driverTyreWear = 25 + (id * 13) % 70,
                driverSpeed = 55 + (id * 11) % 40,
                consistency = 50 + (id * 7) % 50,
                overtaking = 45 + (id * 17) % 55,
                defense = 45 + (id * 19) % 55,
                teamPace = 50 + (id * 23) % 50,
                gridPosition = id,
                fieldSize = 80,
                strategySeed = 666 * 7919 + id * 37
            )
        }

        assertTrue("A IA deve produzir várias sequências estratégicas", plans.map { it.sequence }.distinct().size >= 3)
        assertTrue("A IA deve variar os compostos de largada", plans.map { it.sequence.first() }.distinct().size >= 3)
        assertTrue("A IA deve variar a quantidade de paradas", plans.map { it.sequence.size }.distinct().size >= 2)
        assertEquals("O planejamento seco normal deve usar os três compostos", TyreModel.dryCompounds.toSet(), plans.flatMap { it.sequence }.toSet())
        assertTrue("As janelas também devem diferenciar planos com a mesma sequência", plans.distinct().size >= 12)
        plans.forEach { plan ->
            assertEquals(58, plan.stintLaps.sum())
            assertEquals(plan.sequence.size, plan.stintLaps.size)
            assertTrue(plan.sequence.size in 2..4)
            assertTrue(plan.sequence.all { it in TyreModel.dryCompounds })
            assertTrue("Stints devem alternar compostos", plan.sequence.zipWithNext().none { it.first == it.second })
            assertTrue("Corrida seca deve contemplar ao menos dois compostos", plan.sequence.distinct().size >= 2)
            assertTrue(plan.stintLaps.all { it > 0 })
        }
    }

    @Test
    fun longDryRaceFallbackStillAlternatesCompoundsAndCoversDistance() {
        val plan = TyreModel.buildAiRaceStrategy(
            totalLaps = 130,
            weather = Weather.DRY,
            driverTyreWear = 65,
            driverSpeed = 72,
            consistency = 70,
            overtaking = 68,
            defense = 75,
            teamPace = 70,
            gridPosition = 12,
            fieldSize = 20,
            strategySeed = 666_130
        )

        assertEquals(130, plan.stintLaps.sum())
        assertEquals(plan.sequence.size, plan.stintLaps.size)
        assertTrue(plan.sequence.distinct().size >= 2)
        assertTrue(plan.sequence.zipWithNext().none { it.first == it.second })
        assertTrue(plan.stintLaps.all { it > 0 })
    }

    @Test
    fun teammatesWithDifferentSkillsCanReceiveDifferentStrategies() {
        val attackingDriver = TyreModel.buildAiRaceStrategy(
            58, Weather.DRY, 25, 92, 82, 90, 65, 88, 18, 20, 12345
        )
        val tyreSavingDriver = TyreModel.buildAiRaceStrategy(
            58, Weather.DRY, 90, 62, 88, 60, 92, 88, 19, 20, 12382
        )

        assertFalse(
            "Companheiros com perfis diferentes não devem herdar a mesma estratégia",
            attackingDriver.sequence == tyreSavingDriver.sequence && attackingDriver.stintLaps == tyreSavingDriver.stintLaps
        )
    }

    @Test
    fun wetAiPlansUseOnlyWeatherCompatibleTyresButCanVaryStopWindows() {
        val intermediateA = TyreModel.buildAiRaceStrategy(
            58, Weather.LIGHT_RAIN, 35, 90, 80, 85, 70, 82, 4, 20, 111
        )
        val intermediateB = TyreModel.buildAiRaceStrategy(
            58, Weather.LIGHT_RAIN, 85, 65, 90, 60, 90, 55, 17, 20, 222
        )
        val wet = TyreModel.buildAiRaceStrategy(
            58, Weather.HEAVY_RAIN, 55, 75, 70, 70, 70, 70, 9, 20, 333
        )

        assertEquals(58, intermediateA.stintLaps.sum())
        assertEquals(58, intermediateB.stintLaps.sum())
        assertEquals(58, wet.stintLaps.sum())
        assertTrue(intermediateA.sequence.all { it == Tyre.INTERMEDIATE })
        assertTrue(intermediateB.sequence.all { it == Tyre.INTERMEDIATE })
        assertTrue(wet.sequence.all { it == Tyre.WET })
        assertTrue("Perfis diferentes podem escalonar suas paradas de chuva", intermediateA.stintLaps != intermediateB.stintLaps || intermediateA.sequence.size != intermediateB.sequence.size)
    }

    @Test
    fun racePreparationCreatesPrivateStrategyForEveryAiDriver() {
        val participants = (1..80).map { id ->
            val teamId = (id + 1) / 2
            RaceParticipant(
                driverId = id,
                driverName = "Driver $id",
                teamId = teamId,
                teamName = "Team $teamId",
                driverSpeed = 55 + (id * 11) % 40,
                qualifying = 55 + (id * 11) % 40,
                overtaking = 45 + (id * 17) % 55,
                defense = 45 + (id * 19) % 55,
                consistency = 50 + (id * 7) % 50,
                enginePerformance = 50 + (id * 23) % 50,
                tyreGrip = 45 + id % 50,
                tyreWear = 25 + (id * 13) % 70,
                wetSkill = 50 + id % 45,
                chassisPerformance = 50 + id % 50,
                frontWingPerformance = 50 + id % 50,
                rearWingPerformance = 50 + id % 50,
                brakesPerformance = 50 + id % 50,
                electricPowerUnitPerformance = 50 + id % 50
            )
        }
        val engine = CareerWeekendEngine(666)
        engine.start(participants, RaceCircuit(66, "Circuito de Teste", 58, 90_000L), playerTeamId = 1)
        engine.simulateQualifyingInstantly()
        val prepared = engine.prepareRaceStartWeather()

        assertEquals("Os planos editáveis continuam exclusivos dos dois pilotos do jogador", 2, prepared.plans.size)
        assertEquals("Todos os demais pilotos precisam de plano próprio", 78, prepared.aiTyreStrategies.size)
        prepared.aiTyreStrategies.forEach { (driverId, plan) ->
            assertTrue(participants.first { it.driverId == driverId }.teamId != 1)
            assertEquals(58, plan.stintLaps.sum())
            val startingTyre = prepared.carStatus.first { it.driverId == driverId }.tyre
            assertEquals(plan.sequence.first(), startingTyre)
            when (prepared.weather) {
                Weather.DRY, Weather.CLOUDY -> {
                    assertTrue(plan.sequence.size in 2..4)
                    assertTrue(plan.sequence.all { it in TyreModel.dryCompounds })
                }
                Weather.LIGHT_RAIN, Weather.MEDIUM_RAIN -> assertTrue(plan.sequence.all { it == Tyre.INTERMEDIATE })
                Weather.HEAVY_RAIN -> assertTrue(plan.sequence.all { it == Tyre.WET })
            }
        }
    }
}
