package com.f1teammanager.core.race

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class AiTyreStrategyPlannerTest {
    private fun driver(
        driverId: Int,
        teamId: Int = 1,
        speed: Int = 75,
        tyreWear: Int = 65,
        consistency: Int = 70,
        tyreGrip: Int = 70
    ) = RaceParticipant(
        driverId = driverId,
        driverName = "Driver $driverId",
        teamId = teamId,
        teamName = "Team $teamId",
        driverSpeed = speed,
        qualifying = speed,
        overtaking = 65,
        defense = 65,
        consistency = consistency,
        enginePerformance = 75,
        tyreGrip = tyreGrip,
        tyreWear = tyreWear
    )

    @Test
    fun dryPlanStintsCoverRaceAndNeverExceedCompoundLife() {
        listOf(20, 30, 58, 70, 90).forEach { laps ->
            val plans = TyreModel.buildPlansForWeather(laps, Weather.DRY)
            plans.values.forEach { plan ->
                val allocation = AiTyreStrategyPlanner.allocateStintLaps(laps, plan)
                assertEquals(laps, allocation.sum())
                assertEquals(plan.sequence.size, allocation.size)
                allocation.forEachIndexed { index, stint ->
                    assertTrue(stint in 1..plan.sequence[index].targetLaps)
                }
            }
        }
    }

    @Test
    fun wetPlansKeepTheCorrectCompoundAndExactRemainingDistance() {
        listOf(Weather.LIGHT_RAIN, Weather.MEDIUM_RAIN, Weather.HEAVY_RAIN).forEach { weather ->
            val laps = 42
            val plans = TyreModel.buildPlansForWeather(laps, weather)
            plans.values.forEach { plan ->
                val allocation = AiTyreStrategyPlanner.allocateStintLaps(laps, plan)
                assertEquals(laps, allocation.sum())
                assertTrue(allocation.all { it > 0 })
                val expected = if (weather == Weather.HEAVY_RAIN) Tyre.WET else Tyre.INTERMEDIATE
                assertTrue(plan.sequence.all { it == expected })
            }
        }
    }

    @Test
    fun teammatesUseDifferentValidPlansWhenAlternativesExist() {
        val laps = 58
        val weather = Weather.DRY
        val plans = TyreModel.buildPlansForWeather(laps, weather)
        val first = driver(101, teamId = 7, speed = 92, tyreWear = 88, consistency = 90)
        val second = driver(102, teamId = 7, speed = 68, tyreWear = 42, consistency = 60)
        val teamPlan = AiTyreStrategyPlanner.chooseTeamPlanId(
            plans, listOf(first, second), circuitId = 4, totalLaps = laps, weather = weather
        )
        val firstPlan = AiTyreStrategyPlanner.chooseDriverPlanId(
            plans, first, laps, weather, teamPlan, gridPosition = 5, circuitId = 4
        )
        val secondPlan = AiTyreStrategyPlanner.chooseDriverPlanId(
            plans, second, laps, weather, teamPlan, gridPosition = 21,
            teammatePlanId = firstPlan, circuitId = 4
        )
        assertNotEquals(firstPlan, secondPlan)
        assertTrue(plans.containsKey(firstPlan))
        assertTrue(plans.containsKey(secondPlan))
    }

    @Test
    fun teamPreferenceVariesAcrossTeamsAndIsDeterministic() {
        val laps = 58
        val weather = Weather.DRY
        val plans = TyreModel.buildPlansForWeather(laps, weather)
        val selected = (1..20).map { teamId ->
            val drivers = listOf(driver(teamId * 2, teamId), driver(teamId * 2 + 1, teamId))
            AiTyreStrategyPlanner.chooseTeamPlanId(plans, drivers, 12, laps, weather)
        }
        assertTrue(selected.distinct().size > 1)
        val repeated = AiTyreStrategyPlanner.chooseTeamPlanId(
            plans, listOf(driver(14, 7), driver(15, 7)), 12, laps, weather
        )
        assertEquals(selected[6], repeated)
    }

    @Test
    fun weatherRegimeDoesNotTreatCloudyAsRain() {
        assertEquals(AiTyreWeatherRegime.DRY, AiTyreStrategyPlanner.weatherRegime(Weather.CLOUDY))
        assertEquals(AiTyreWeatherRegime.INTERMEDIATE, AiTyreStrategyPlanner.weatherRegime(Weather.MEDIUM_RAIN))
        assertEquals(AiTyreWeatherRegime.WET, AiTyreStrategyPlanner.weatherRegime(Weather.HEAVY_RAIN))
        assertNotEquals(
            AiTyreStrategyPlanner.weatherRegime(Weather.LIGHT_RAIN),
            AiTyreStrategyPlanner.weatherRegime(Weather.HEAVY_RAIN)
        )
    }
}
