package com.f1teammanager.core.race

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * V364: executes the real instant qualifying + race engine for 60 consecutive GPs.
 * This is deliberately separate from the manager-calendar audit: a calendar-only
 * test cannot prove that the race simulation itself survives a two-season chain.
 */
class InstantSimulationTwoSeasonChainTest {
    private fun participants() = (1..80).map { id ->
        val teamId = ((id - 1) / 2) + 1
        RaceParticipant(
            driverId = id,
            driverName = "Driver $id",
            teamId = teamId,
            teamName = "Team $teamId",
            driverSpeed = 68 + (id % 17), qualifying = 70 + (id % 19),
            overtaking = 65 + (id % 23), defense = 64 + (id % 21),
            consistency = 78 + (id % 18), enginePerformance = 70 + (id % 20),
            tyreGrip = 70 + (id % 20), tyreWear = 72 + (id % 19),
            reliability = 88 + (id % 13), wetSkill = 65 + (id % 30),
            chassisPerformance = 68 + (id % 22), frontWingPerformance = 68 + (id % 22),
            rearWingPerformance = 68 + (id % 22), brakesPerformance = 68 + (id % 22),
            electricPowerUnitPerformance = 68 + (id % 22),
            engineReliability = 88 + (id % 13), chassisReliability = 88 + (id % 13),
            frontWingReliability = 88 + (id % 13), rearWingReliability = 88 + (id % 13),
            brakesReliability = 88 + (id % 13), electricPowerUnitReliability = 88 + (id % 13)
        )
    }

    @Test
    fun simulatesSixtyCompleteInstantWeekendsAcrossTwoSeasons() {
        val drivers = participants()
        assertEquals(80, drivers.map { it.driverId }.distinct().size)
        val seasonSummaries = mutableMapOf<Int, Int>()
        val uniqueRaceSignatures = mutableSetOf<String>()

        repeat(60) { index ->
            val season = 2026 + index / 30
            val round = index % 30 + 1
            val laps = 5 + (round % 3)
            val circuit = RaceCircuit(
                id = index + 1,
                name = "Season $season GP $round",
                laps = laps,
                baseLapTimeMs = 90_000L + (round * 175L),
                crashRisk = 0.25 + (round % 4) * 0.1,
                reliabilityRisk = 0.25 + (round % 3) * 0.1,
                safetyCarRisk = 0.2 + (round % 5) * 0.1
            )
            val engine = CareerWeekendEngine(seed = season * 100 + round)
            engine.start(drivers, circuit, playerTeamId = 1)

            val weekend = InstantSimulationService.completeStartedWeekend(engine, circuit)
            assertEquals("season $season round $round qualifying entrants", 80,
                weekend.qualifying.grid!!.grid.map { it.driverId }.distinct().size)
            assertEquals("season $season round $round qualifying phases", listOf(80, 50, 20),
                weekend.qualifying.grid!!.phases.map { it.entries.size })
            assertEquals("season $season round $round finishers/classification entries", 80,
                weekend.result.classification.map { it.driverId }.distinct().size)
            assertEquals("season $season round $round positions", (1..80).toList(),
                weekend.result.classification.map { it.position }.sorted())
            assertEquals("season $season round $round programmed distance", laps,
                weekend.result.classification.maxOf { it.laps })
            assertTrue("season $season round $round result validation",
                RaceResultValidator.validate(weekend.result, laps).isEmpty())

            val signature = weekend.result.classification.joinToString(",") { "${it.driverId}:${it.position}:${it.laps}" }
            assertTrue("race signature should be unique for seeded GP $season/$round", uniqueRaceSignatures.add("$season/$round:$signature"))
            seasonSummaries[season] = (seasonSummaries[season] ?: 0) + 1
        }

        assertEquals(mapOf(2026 to 30, 2027 to 30), seasonSummaries)
        assertEquals(60, uniqueRaceSignatures.size)
    }
}
