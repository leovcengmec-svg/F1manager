package com.f1teammanager.core.race

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class AiTyreStrategyEngineIntegrationTest {
    private fun participants(): List<RaceParticipant> = (1..80).map { id ->
        val team = (id + 1) / 2
        RaceParticipant(
            driverId = id,
            driverName = "Driver $id",
            teamId = team,
            teamName = "Team $team",
            driverSpeed = 55 + (id * 7 % 40),
            qualifying = 55 + (id * 5 % 40),
            overtaking = 55 + (id * 3 % 40),
            defense = 55 + (id * 11 % 40),
            consistency = 50 + (id * 13 % 45),
            enginePerformance = 60 + (team * 7 % 35),
            tyreGrip = 50 + (id * 9 % 45),
            tyreWear = 45 + (id * 17 % 50),
            wetSkill = 55 + (id * 7 % 40),
            chassisPerformance = 60 + (team * 3 % 35),
            frontWingPerformance = 60 + (team * 5 % 35),
            rearWingPerformance = 60 + (team * 11 % 35),
            brakesPerformance = 60 + (team * 13 % 35),
            electricPowerUnitPerformance = 60 + (team * 17 % 35)
        )
    }

    @Test
    fun aiTeamsStartWithSplitPlansAndExecuteDifferentPitStrategies() {
        val engine = CareerWeekendEngine(seed = 12345)
        val circuit = RaceCircuit(id = 12, name = "Circuit", laps = 58, baseLapTimeMs = 90_000L)
        engine.start(participants(), circuit, playerTeamId = 1)
        engine.simulateQualifyingInstantly()
        val start = engine.prepareRaceStartWeather()

        assertEquals(Weather.DRY, start.weather)
        val aiCarsAtStart = start.carStatus.filter { it.driverId > 2 }
        assertEquals(78, aiCarsAtStart.size)
        val teamByDriver = participants().associate { it.driverId to it.teamId }
        val hasDifferentTeammateCompounds = aiCarsAtStart.groupBy { teamByDriver[it.driverId] }
            .values.any { cars -> cars.size == 2 && cars.map { it.tyre }.distinct().size > 1 }
        assertTrue("At least one AI team must split its starting compound", hasDifferentTeammateCompounds)

        val race = engine.simulateRaceInstantly()
        assertTrue("The full race must finish", race.completed)
        val aiPitStopCounts = race.carStatus.filter { it.driverId > 2 }.map { it.pitStops }.distinct()
        assertTrue("AI drivers must execute different pit strategies", aiPitStopCounts.size > 1)
    }
}
