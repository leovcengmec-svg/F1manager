package com.f1teammanager.core.race

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class InstantSimulationServiceTest {
    private fun participants() = (1..80).map { id ->
        RaceParticipant(
            driverId = id,
            driverName = "Driver $id",
            teamId = ((id - 1) / 2) + 1,
            teamName = "Team ${((id - 1) / 2) + 1}",
            driverSpeed = 75, qualifying = 75, overtaking = 70, defense = 70,
            consistency = 90, enginePerformance = 75, tyreGrip = 75, tyreWear = 90,
            reliability = 100, wetSkill = 75, chassisPerformance = 75,
            frontWingPerformance = 75, rearWingPerformance = 75, brakesPerformance = 75,
            electricPowerUnitPerformance = 75, engineReliability = 100,
            chassisReliability = 100, frontWingReliability = 100, rearWingReliability = 100,
            brakesReliability = 100, electricPowerUnitReliability = 100
        )
    }

    @Test
    fun completeWeekendValidatesQualifyingRaceAndCareerContractTogether() {
        val circuit = RaceCircuit(362, "V362 Integration GP", 5, 90_000L, 0.0, 0.0, 0.0)
        val engine = CareerWeekendEngine(seed = 362)
        engine.start(participants(), circuit, playerTeamId = 1)

        val outcome = InstantSimulationService.completeStartedWeekend(engine, circuit)

        assertEquals(80, outcome.qualifying.grid!!.grid.size)
        assertEquals(listOf(80, 50, 20), outcome.qualifying.grid!!.phases.map { it.entries.size })
        assertEquals(80, outcome.result.classification.size)
        assertEquals((1..80).toList(), outcome.result.classification.map { it.position }.sorted())
        assertEquals(circuit.laps, outcome.result.classification.maxOf { it.laps })
        assertTrue(RaceResultValidator.validate(outcome.result, circuit.laps).isEmpty())
    }


    @Test
    fun instantEntryPointInitializesFreshEngineWithoutInteractiveStart() {
        val circuit = RaceCircuit(373, "V373 Direct Calendar GP", 5, 90_000L, 0.0, 0.0, 0.0)
        val engine = CareerWeekendEngine(seed = 373)

        val outcome = InstantSimulationService.simulateWeekendInstantly(
            engine, participants(), circuit, playerTeamId = 1
        )

        assertEquals(80, outcome.qualifying.grid!!.grid.size)
        assertEquals(80, outcome.result.classification.size)
        assertEquals(circuit.laps, outcome.result.classification.maxOf { it.laps })
        assertTrue(RaceResultValidator.validate(outcome.result, circuit.laps).isEmpty())
    }

    @Test(expected = IllegalArgumentException::class)
    fun instantServiceRejectsIncompleteCircuitBeforeRunning() {
        val engine = CareerWeekendEngine(seed = 363)
        InstantSimulationService.completeStartedWeekend(engine, RaceCircuit(363, "Invalid GP", 0, 90_000L))
    }
}
