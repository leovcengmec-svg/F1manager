package com.f1teammanager.core.race

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class V204WetStartAndRedFlagPlansTest {
    @Test fun lightAndMediumRainUseIntermediateOnly() {
        listOf(Weather.LIGHT_RAIN, Weather.MEDIUM_RAIN).forEach { weather ->
            val plans = TyreModel.buildPlansForWeather(58, weather)
            val tyres = plans.values.flatMap { it.sequence }.toSet()
            assertEquals(setOf(Tyre.INTERMEDIATE), tyres)
            plans.values.forEach { plan ->
                assertEquals(58, plan.stintLaps.sum())
                assertTrue(plan.stintLaps.all { it <= TyreModel.estimatedStintLifeLaps(Tyre.INTERMEDIATE, weather) })
            }
        }
    }

    @Test fun heavyRainUsesWetOnly() {
        val plans = TyreModel.buildPlansForWeather(58, Weather.HEAVY_RAIN)
        val tyres = plans.values.flatMap { it.sequence }.toSet()
        assertEquals(setOf(Tyre.WET), tyres)
        plans.values.forEach { plan ->
            assertEquals(58, plan.stintLaps.sum())
            assertTrue(plan.stintLaps.all { it <= TyreModel.estimatedStintLifeLaps(Tyre.WET, Weather.HEAVY_RAIN) })
        }
    }

    @Test fun dryWeatherKeepsDryPlansAndExactLapTotals() {
        val plans = TyreModel.buildPlansForWeather(58, Weather.DRY)
        assertTrue(plans.values.flatMap { it.sequence }.all { it in TyreModel.dryCompounds })
        plans.values.forEach { plan ->
            assertEquals(plan.sequence.size, plan.stintLaps.size)
            assertEquals(58, plan.stintLaps.sum())
            plan.sequence.indices.forEach { index ->
                assertTrue(plan.stintLaps[index] <= TyreModel.estimatedStintLifeLaps(plan.sequence[index], Weather.DRY))
            }
        }
    }

    @Test fun oneLapRemainingStillProducesFourDryPlanIds() {
        val plans = TyreModel.buildPlansForWeather(1, Weather.DRY)
        assertEquals(setOf("A", "B", "C", "D"), plans.keys)
        plans.values.forEach { assertEquals(1, it.stintLaps.sum()) }
    }

    @Test fun manualAndAutomaticWearThresholdsAreDistinct() {
        assertEquals(80, TyreModel.MANUAL_TYRE_WARNING_WEAR_PERCENT)
        assertEquals(85, TyreModel.AUTOMATIC_TYRE_CHANGE_WEAR_PERCENT)
    }
}
