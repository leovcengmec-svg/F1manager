package com.f1teammanager.core.manager

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class V410DriverMarketRenewalAvailabilityTest {
    private val engine = DriverMarketEngine(20261003)

    @Test fun renewedDriverIsNotOpenForProposals() {
        val initial = engine.initialState(2026)
        val original = initial.contracts.first { it.driverId == 1 }
        val expiring = original.copy(years = 1, seasonSigned = 2026)
        val state = initial.copy(contracts = initial.contracts.filterNot { it.driverId == 1 } + expiring)
        val renewed = engine.renew(state, 1, expiring.teamId, 2, expiring.salary, expiring.role, 2026, 20)
        assertTrue(engine.hasFutureDecision(renewed, 1, 2026))
        assertFalse(engine.canReceiveProposals(renewed, 1, 2026))
        assertTrue(renewed.scheduled.any { it.driverId == 1 && it.toTeamId == expiring.teamId && it.startSeason == 2027 })
    }

    @Test fun driverWithoutFutureDecisionCanBeOpenInLastContractYear() {
        val initial = engine.initialState(2026)
        val deal = initial.contracts.first { it.driverId == 1 }.copy(years = 1, seasonSigned = 2026)
        val state = initial.copy(contracts = initial.contracts.filterNot { it.driverId == 1 } + deal)
        assertFalse(engine.hasFutureDecision(state, 1, 2026))
        assertTrue(engine.canReceiveProposals(state, 1, 2026))
    }
}
