package com.f1teammanager.core.manager

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Base64

class AIFinanceTransactionCodecTest {
    @Test
    fun smallLedgerRemainsLegacyCompatible() {
        val rows = listOf("+100:Patrocínio", "-25:Manutenção")
        val encoded = AIFinanceTransactionCodec.encode(rows)
        val outer = String(Base64.getDecoder().decode(encoded), Charsets.UTF_8)
        assertTrue(!outer.startsWith("GZ1:"))
        assertEquals(rows, AIFinanceTransactionCodec.decode(encoded))
    }

    @Test
    fun largeLedgerUsesCompressionAndRoundTrips() {
        val rows = (1..20_000).map { index -> "-$index:Pagamento semanal de manutenção da instalação e operação" }
        val encoded = AIFinanceTransactionCodec.encode(rows)
        val outer = String(Base64.getDecoder().decode(encoded), Charsets.UTF_8)
        assertTrue(outer.startsWith("GZ1:"))
        assertEquals(rows, AIFinanceTransactionCodec.decode(encoded))
    }

    @Test
    fun oldUncompressedSnapshotFieldRemainsReadable() {
        val oldRaw = "+100:Patrocínio\n-25:Manutenção"
        val oldField = Base64.getEncoder().encodeToString(oldRaw.toByteArray(Charsets.UTF_8))
        assertEquals(listOf("+100:Patrocínio", "-25:Manutenção"), AIFinanceTransactionCodec.decode(oldField))
    }
}
