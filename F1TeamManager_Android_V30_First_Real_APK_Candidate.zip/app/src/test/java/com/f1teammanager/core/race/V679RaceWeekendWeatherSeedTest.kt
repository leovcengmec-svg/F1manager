package com.f1teammanager.core.race

import com.f1teammanager.core.season.SeasonCalendar
import kotlin.random.Random
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class V679RaceWeekendWeatherSeedTest {
    @Test
    fun everyRoundGetsAStableButDifferentWeekendSeed() {
        val rounds = SeasonCalendar.forSeason(2028)
        assertEquals(30, rounds.size)

        val seeds = rounds.map { round ->
            RaceWeekendSeed.forWeekend(20261003, 2028, round.round, round.circuit)
        }

        assertEquals("Each calendar round must have its own climate stream", 30, seeds.toSet().size)
        rounds.forEach { round ->
            assertEquals(
                "Reloading the same weekend must reproduce its climate seed",
                RaceWeekendSeed.forWeekend(20261003, 2028, round.round, round.circuit),
                RaceWeekendSeed.forWeekend(20261003, 2028, round.round, round.circuit)
            )
        }
    }

    @Test
    fun seasonAndRoundArePartOfTheSeedIdentity() {
        val base = RaceWeekendSeed.forWeekend(20261003, 2028, 1, "Albert Park")
        assertNotEquals(base, RaceWeekendSeed.forWeekend(20261003, 2028, 2, "Shanghai"))
        assertNotEquals(base, RaceWeekendSeed.forWeekend(20261003, 2029, 1, "Albert Park"))
        assertNotEquals(base, RaceWeekendSeed.forWeekend(20261004, 2028, 1, "Albert Park"))
    }

    @Test
    fun thirtyRaceCalendarDoesNotReuseOneIdenticalOpeningWeatherDraw() {
        val rounds = SeasonCalendar.forSeason(2028)
        val openingWeather = rounds.map { round ->
            val circuit = RaceCircuit(round.round, round.circuit, round.laps, round.baseLapTimeMs)
            val seed = RaceWeekendSeed.forWeekend(20261003, 2028, round.round, round.circuit)
            CircuitWeatherModel.raceStartWeather(circuit, Random(seed xor 0x6327EA71))
        }

        assertTrue(
            "The 30 GPs should not all begin with the same weather state: $openingWeather",
            openingWeather.distinct().size >= 2
        )
        assertTrue(
            "A season-wide draw must not make every race start rainy: $openingWeather",
            openingWeather.count { CircuitWeatherModel.isRain(it) } < rounds.size
        )
    }

    @Test
    fun qualifyingAndRaceWeatherUseIndependentStreamsForEachWeekend() {
        val round = SeasonCalendar.forSeason(2028).first()
        val circuit = RaceCircuit(round.round, round.circuit, round.laps, round.baseLapTimeMs)
        val seed = RaceWeekendSeed.forWeekend(20261003, 2028, round.round, round.circuit)
        val qualifying = CircuitWeatherModel.qualifyingStartWeather(circuit, Random(seed xor 0x5A17C0DE))
        val race = CircuitWeatherModel.raceStartWeather(circuit, Random(seed xor 0x6327EA71))

        // The streams are separately derived. They may coincidentally resolve to
        // the same state, but their first RNG values must not be identical.
        val qualifyingDraw = Random(seed xor 0x5A17C0DE).nextDouble()
        val raceDraw = Random(seed xor 0x6327EA71).nextDouble()
        assertNotEquals(qualifyingDraw, raceDraw, 0.0)
        assertTrue(qualifying in Weather.values())
        assertTrue(race in Weather.values())
    }
}
