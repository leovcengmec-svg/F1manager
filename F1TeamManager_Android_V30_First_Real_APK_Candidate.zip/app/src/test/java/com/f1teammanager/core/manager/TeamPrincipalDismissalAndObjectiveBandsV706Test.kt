package com.f1teammanager.core.manager

import org.junit.Assert.*
import org.junit.Test

class TeamPrincipalDismissalAndObjectiveBandsV706Test {
    private val ranks = (1..40).associateWith { it }

    @Test fun firstYearOfTwoYearContractIsProtectedAfterThreeGoalsAndBoardSupportAboveFifty() {
        val state = TeamPrincipalCareerEngine.initial(40, 2026, ranks).copy(
            contractYears = 2,
            objectiveRank = 25,
            lastRank = 28,
            boardSupport = 60,
            objectives = listOf(
                TeamPrincipalObjective("main_2026", "Objetivo principal", "Meta", "rank", 25, 4, 27),
                TeamPrincipalObjective("cash_2026", "Caixa", "Manter caixa", "cash", 0, 1),
                TeamPrincipalObjective("points_2026", "Pontos", "Pontuar", "points", 0, 1),
                TeamPrincipalObjective("defend_2026", "Defesa", "Não cair", "maintain_rank", 40, 1)
            )
        )

        val settled = TeamPrincipalCareerEngine.recordSeason(
            state, 2026, 29, ranks,
            constructorPoints = 0,
            cashBalance = 0,
            dismissalRoll = 0
        )

        assertFalse("Atingir três metas e manter apoio acima de 50 na primeira temporada 1/2 deve impedir demissão", settled.dismissed)
        assertFalse("O contrato de dois anos ainda não deve abrir avaliação", settled.reviewPending)
        assertEquals(64, settled.boardSupport)
        assertTrue(TeamPrincipalCareerEngine.firstYearProtectionApplies(state, 2026, 3, settled.boardSupport))
    }

    @Test fun firstYearProtectionRequiresThreeGoalsAndSupportStrictlyAboveFifty() {
        val state = TeamPrincipalCareerEngine.initial(40, 2026, ranks).copy(contractYears = 2)
        assertTrue(TeamPrincipalCareerEngine.firstYearProtectionApplies(state, 2026, 3, 51))
        assertFalse(TeamPrincipalCareerEngine.firstYearProtectionApplies(state, 2026, 2, 80))
        assertFalse(TeamPrincipalCareerEngine.firstYearProtectionApplies(state, 2026, 3, 50))
        assertFalse(TeamPrincipalCareerEngine.firstYearProtectionApplies(state.copy(contractYears = 1), 2026, 5, 90))
        assertFalse(TeamPrincipalCareerEngine.firstYearProtectionApplies(state, 2027, 5, 90))
    }

    @Test fun missedMainObjectiveIsEvaluatedAtOneYearAndFinalTwoYearContractReviews() {
        val oneYear = TeamPrincipalCareerEngine.initial(40, 2026, ranks).copy(
            contractYears = 1,
            objectiveRank = 25,
            boardSupport = 60,
            objectives = listOf(
                TeamPrincipalObjective("main_2026", "Principal", "Meta", "rank", 25, 4, 27),
                TeamPrincipalObjective("cash_2026", "Caixa", "Caixa", "cash", 1_000, 1),
                TeamPrincipalObjective("points_2026", "Pontos", "Pontos", "points", 100, 1)
            )
        )
        val oneYearResult = TeamPrincipalCareerEngine.recordSeason(
            oneYear, 2026, 40, ranks, cashBalance = 0, constructorPoints = 0, dismissalRoll = 0
        )
        assertTrue("Uma falha grave no contrato 1/1 deve abrir a avaliação imediata", oneYearResult.dismissed)
        assertTrue(oneYearResult.reviewPending)

        val secondYear = TeamPrincipalCareerEngine.initial(40, 2026, ranks).copy(
            contractYears = 2,
            lastProcessedSeason = 2026,
            objectiveRank = 25,
            boardSupport = 60,
            objectives = listOf(
                TeamPrincipalObjective("main_2027", "Principal", "Meta", "rank", 25, 4, 27),
                TeamPrincipalObjective("cash_2027", "Caixa", "Caixa", "cash", 1_000, 1),
                TeamPrincipalObjective("points_2027", "Pontos", "Pontos", "points", 100, 1)
            )
        )
        val secondYearResult = TeamPrincipalCareerEngine.recordSeason(
            secondYear, 2027, 40, ranks, cashBalance = 0, constructorPoints = 0, dismissalRoll = 0
        )
        assertTrue("A falha grave no contrato 2/2 deve ser avaliada na temporada final", secondYearResult.dismissed)
        assertTrue(secondYearResult.reviewPending)
    }

    @Test fun objectiveToleranceIsTwoPlacesOutsideTopTenAndOnePlaceFromElevenToTwenty() {
        assertEquals(1, TeamPrincipalCareerEngine.objectiveRangeMax(1))
        assertEquals(10, TeamPrincipalCareerEngine.objectiveRangeMax(10))
        assertEquals(16, TeamPrincipalCareerEngine.objectiveRangeMax(15))
        assertEquals(27, TeamPrincipalCareerEngine.objectiveRangeMax(25))
        assertEquals(40, TeamPrincipalCareerEngine.objectiveRangeMax(40))
    }

    @Test fun mainGoalRangeAcceptsTwentyFiveToTwentySevenButNotTwentyEight() {
        val state = TeamPrincipalCareerState(
            teamId = 40,
            objectiveRank = 25,
            lastRank = 28,
            objectives = listOf(TeamPrincipalObjective("main_2026", "Principal", "Meta", "rank", 25, 4, 27))
        )
        val atWorstAllowedPosition = TeamPrincipalCareerEngine.evaluateObjectives(
            state, 27, 0, 0, emptyMap(), 0, 0
        )
        val onePlaceOutside = TeamPrincipalCareerEngine.evaluateObjectives(
            state, 28, 0, 0, emptyMap(), 0, 0
        )
        assertEquals("main_2026:1", atWorstAllowedPosition.single())
        assertEquals("main_2026:0", onePlaceOutside.single())
    }

    @Test fun topTenMainTargetsDoNotReceiveAnyPositionMargin() {
        val state = TeamPrincipalCareerState(
            teamId = 40,
            objectiveRank = 10,
            lastRank = 10,
            objectives = listOf(TeamPrincipalObjective("main_2026", "Principal", "Meta", "rank", 10, 4, 10))
        )
        val positionTen = TeamPrincipalCareerEngine.evaluateObjectives(state, 10, 0, 0, emptyMap(), 0, 0)
        val positionEleven = TeamPrincipalCareerEngine.evaluateObjectives(state, 11, 0, 0, emptyMap(), 0, 0)
        assertEquals("main_2026:1", positionTen.single())
        assertEquals("main_2026:0", positionEleven.single())
        val title = TeamPrincipalCareerEngine.primaryObjectiveDescription(1)
        assertTrue(title.contains("Ser campeão"))
        assertFalse(title.contains("1º ou melhor"))
    }

    @Test fun legacySavedMainObjectiveMigratesToRangeAndCorrectDescription() {
        val current = TeamPrincipalCareerState(
            teamId = 40,
            objectiveRank = 25,
            lastRank = 28,
            contractYears = 2,
            objectives = listOf(TeamPrincipalObjective("main_2026", "Objetivo principal", "Terminar em 25º ou melhor no Mundial de Equipes", "rank", 25, 4, 27))
        )
        val legacy = current.encode()
            .replaceFirst("6#", "5#")
            .replace("~rank~25~4~27", "~rank~25~4")
        val migrated = TeamPrincipalCareerState.decode(legacy)!!
        val main = migrated.objectives.single()
        assertEquals(27, main.rangeMax)
        assertEquals(TeamPrincipalCareerEngine.primaryObjectiveDescription(25, 27), main.detail)
        assertTrue(migrated.encode().startsWith("6#"))
    }

    @Test fun seasonHistoryUsesRecordedPrimaryObjectiveResultForRangeAchievement() {
        val insideRange = TeamPrincipalSeasonRecord(2026, 40, 27, 25, 0, "main_2026:1|cash_2026:1")
        val outsideRange = TeamPrincipalSeasonRecord(2026, 40, 28, 25, 0, "main_2026:0|cash_2026:1")
        assertTrue(TeamPrincipalCareerEngine.recordMetPrimaryObjective(insideRange))
        assertFalse(TeamPrincipalCareerEngine.recordMetPrimaryObjective(outsideRange))
    }
}
