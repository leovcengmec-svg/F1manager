package com.f1teammanager.core.manager

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ResearchGainPreviewV495Test {
    private val engine = ResearchEngine()

    @Test
    fun previewReflectsLevelAndFocusUsingResearchSplit() {
        val performance = engine.previewGain(10, ResearchFocus.PERFORMANCE, ResearchComplexity.SIMPLE, 60, 60)
        val reliability = engine.previewGain(10, ResearchFocus.RELIABILITY, ResearchComplexity.SIMPLE, 60, 60)
        val balanced = engine.previewGain(10, ResearchFocus.BALANCED, ResearchComplexity.SIMPLE, 60, 60)

        assertEquals(8, performance.performance.min)
        assertEquals(12, performance.performance.max)
        assertEquals(3, performance.reliability.min)
        assertEquals(5, performance.reliability.max)
        assertTrue(reliability.reliability.max > performance.reliability.max)
        assertTrue(balanced.performance.max in 6..9)
    }

    @Test
    fun complexityAddsTheAgreedBonusRange() {
        assertEquals(1..2, engine.complexityBonus(ResearchComplexity.SIMPLE))
        assertEquals(2..3, engine.complexityBonus(ResearchComplexity.MEDIUM))
        assertEquals(3..4, engine.complexityBonus(ResearchComplexity.ADVANCED))
        assertEquals(4..5, engine.complexityBonus(ResearchComplexity.EXPERIMENTAL))
    }

    @Test
    fun previewHonorsComponentCapAndComplexityRisk() {
        val simple = engine.previewGain(10, ResearchFocus.PERFORMANCE, ResearchComplexity.SIMPLE, 99, 100)
        val experimental = engine.previewGain(10, ResearchFocus.PERFORMANCE, ResearchComplexity.EXPERIMENTAL, 99, 100)

        assertEquals(1, simple.performance.max)
        assertEquals(0, simple.reliability.max)
        assertEquals(1, simple.failureChancePercent)
        assertEquals(8, experimental.failureChancePercent)
        assertTrue(experimental.performance.max >= simple.performance.max)
    }
}
