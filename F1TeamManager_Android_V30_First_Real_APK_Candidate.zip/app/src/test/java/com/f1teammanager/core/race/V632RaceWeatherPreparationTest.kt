package com.f1teammanager.core.race

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class V632RaceWeatherPreparationTest {
    private fun roster(): List<RaceParticipant> = (1..80).map { driverId ->
        val teamId = (driverId + 1) / 2
        RaceParticipant(
            driverId = driverId,
            driverName = "Driver $driverId",
            teamId = teamId,
            teamName = "Team $teamId",
            driverSpeed = 60 + driverId % 35,
            qualifying = 60 + driverId % 35,
            overtaking = 55 + driverId % 40,
            defense = 55 + driverId % 40,
            consistency = 65 + driverId % 30,
            enginePerformance = 55 + driverId % 40,
            wetSkill = 50 + driverId % 45
        )
    }

    @Test fun raceWeatherIsPreparedOnlyOnceAfterQualifyingAndPlansMatchIt() {
        val engine = CareerWeekendEngine(632)
        val circuit = RaceCircuit(12, "Spa-Francorchamps", 44, 111_500L)
        engine.start(roster(), circuit, playerTeamId = 1)
        engine.simulateQualifyingInstantly()
        assertTrue(engine.qualifyingComplete())

        val first = engine.prepareRaceStartWeather()
        val second = engine.prepareRaceStartWeather()
        assertEquals(first.weather, second.weather)
        assertEquals(first.plans, second.plans)
        assertEquals(2, first.plans.size)

        val expectedTyre = when (first.weather) {
            Weather.HEAVY_RAIN -> Tyre.WET
            Weather.LIGHT_RAIN, Weather.MEDIUM_RAIN -> Tyre.INTERMEDIATE
            Weather.DRY, Weather.CLOUDY -> first.plans.values.first().tyrePlans["A"]?.sequence?.first() ?: Tyre.MEDIUM
        }
        if (first.weather == Weather.HEAVY_RAIN || first.weather == Weather.LIGHT_RAIN || first.weather == Weather.MEDIUM_RAIN) {
            assertTrue(first.plans.values.all { it.tyre == expectedTyre })
        }
    }

    @Test fun directHeadlessAdvancePreparesRaceWeatherAutomatically() {
        val engine = CareerWeekendEngine(633)
        engine.start(roster(), RaceCircuit(1, "Albert Park", 58, 87_500L), playerTeamId = 1)
        engine.simulateQualifyingInstantly()
        val race = engine.advance()
        assertEquals("RACE", race.phase)
        assertEquals(2, race.plans.size)
    }
}
