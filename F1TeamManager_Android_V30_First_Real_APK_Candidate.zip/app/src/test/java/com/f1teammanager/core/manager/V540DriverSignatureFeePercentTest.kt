package com.f1teammanager.core.manager

import org.junit.Assert.assertEquals
import org.junit.Test
import kotlin.math.roundToLong
import com.f1teammanager.core.season.WorldDatabase

class V540DriverSignatureFeePercentTest {
    private val engine = DriverMarketEngine(seed = 540)
    private val season = 2026

    @Test fun freeAgentFeeIsTwentyPercentOfMarketValue() {
        val state = engine.initialState(season)
        val driverId = state.freeAgents.first()
        val value = engine.marketValueFor(driverId)
        assertEquals((value * 0.20).roundToLong(), engine.signatureFeeFor(state, driverId, 1, season))
    }

    @Test fun renewalFeeIsTwentyPercentOfContractMarketValue() {
        val state = engine.initialState(season)
        val contract = state.contracts.first()
        assertEquals((contract.marketValue * 0.20).roundToLong(), engine.signatureFeeForRenewal(state, contract.driverId, contract.teamId, season))
        assertEquals((contract.marketValue * 0.20).roundToLong(), engine.signatureFeeFor(state, contract.driverId, contract.teamId, season))
    }

    @Test fun signingFromAnotherTeamCostsFortyPercentOfMarketValue() {
        val state = engine.initialState(season)
        val contract = state.contracts.first()
        val otherTeam = (WorldDatabase.teams.firstOrNull { it.id != contract.teamId }?.id ?: (contract.teamId + 1))
        assertEquals((contract.marketValue * 0.40).roundToLong(), engine.signatureFeeFor(state, contract.driverId, otherTeam, season))
    }
}
