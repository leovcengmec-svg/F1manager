package com.f1teammanager.core.race

import com.f1teammanager.core.season.RoundDefinition
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class RaceCalendarGuardTest {
    private val gp1 = RoundDefinition(
        round = 1, grandPrix = "GP Teste", circuit = "Circuito Teste", laps = 58,
        baseLapTimeMs = 90_000L, weekOfSeason = 8
    )

    @Test fun acceptsOnlyTheScheduledWeekForTheCurrentRound() {
        assertNull(RaceCalendarGuard.validationError(8, 0, gp1, gp1, weekendInProgress = false))
    }

    @Test fun rejectsEarlyInstantSimulationWithoutChangingTheCalendar() {
        val message = RaceCalendarGuard.validationError(7, 0, gp1, gp1, weekendInProgress = false)
        assertEquals(true, message?.contains("semana 8") == true)
    }

    @Test fun rejectsLateInstantSimulationInsteadOfAttachingResultToAnotherWeek() {
        val message = RaceCalendarGuard.validationError(9, 0, gp1, gp1, weekendInProgress = false)
        assertEquals(true, message?.contains("já passou") == true)
    }

    @Test fun rejectsStaleDisplayedRoundEvenWhenWeekMatches() {
        val wrong = gp1.copy(round = 2, weekOfSeason = 10, circuit = "Outro Circuito")
        assertEquals(true, RaceCalendarGuard.validationError(8, 0, gp1, wrong, false)?.contains("não corresponde") == true)
    }

    @Test fun rejectsTryingToStartAnInstantWeekendWhileInteractiveWeekendIsActive() {
        assertEquals(true, RaceCalendarGuard.validationError(8, 0, gp1, gp1, true)?.contains("em andamento") == true)
    }

    @Test fun rejectsMissingNextRound() {
        assertEquals(true, RaceCalendarGuard.validationError(8, 30, null, null, false)?.contains("Não existe GP") == true)
    }
}
