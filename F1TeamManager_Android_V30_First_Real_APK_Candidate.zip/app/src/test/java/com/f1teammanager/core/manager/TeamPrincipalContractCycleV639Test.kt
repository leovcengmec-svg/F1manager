package com.f1teammanager.core.manager

import org.junit.Assert.*
import org.junit.Test

class TeamPrincipalContractCycleV639Test {
    private val ranks = (1..40).associateWith { it }

    @Test fun initialContractLastsOneSeason() {
        val state = TeamPrincipalCareerEngine.initial(40, 2026, ranks)
        assertEquals(1, state.contractYears)
        assertEquals(2026, state.contractEndSeason)
        assertTrue(TeamPrincipalCareerEngine.isEvaluationSeason(state, 2026))
        assertFalse(TeamPrincipalCareerEngine.isEvaluationSeason(state, 2025))
    }

    @Test fun prestigeControlsOneToThreeOutsideOffersStartingAtZero() {
        assertEquals(1, TeamPrincipalCareerEngine.outsideOfferQuota(0))
        assertEquals(1, TeamPrincipalCareerEngine.availableOffers(40, 0, ranks).size)
        assertEquals(1, TeamPrincipalCareerEngine.availableOffers(40, 19, ranks).size)
        assertEquals(1, TeamPrincipalCareerEngine.availableOffers(40, 20, ranks).size)
        assertEquals(1, TeamPrincipalCareerEngine.availableOffers(40, 39, ranks).size)
        assertEquals(2, TeamPrincipalCareerEngine.availableOffers(40, 40, ranks).size)
        assertEquals(2, TeamPrincipalCareerEngine.availableOffers(40, 59, ranks).size)
        assertEquals(3, TeamPrincipalCareerEngine.availableOffers(40, 60, ranks).size)
        assertEquals(3, TeamPrincipalCareerEngine.availableOffers(40, 100, ranks).size)
    }

    @Test fun multiYearContractDoesNotOpenMarketBeforeExpiry() {
        val initial = TeamPrincipalCareerEngine.initial(40, 2026, ranks).copy(
            prestige = 70, boardSupport = 100, contractYears = 2
        )
        val firstYear = TeamPrincipalCareerEngine.recordSeason(
            initial, 2026, 40, ranks, dismissalRoll = 99
        )
        assertFalse(firstYear.reviewPending)
        assertTrue(firstYear.contractOffers.isEmpty())
        assertEquals(2027, firstYear.contractEndSeason)

        val expired = TeamPrincipalCareerEngine.recordSeason(
            firstYear, 2027, 40, ranks, dismissalRoll = 99
        )
        assertTrue(expired.reviewPending)
        assertTrue(expired.contractOffers.any { it.teamId == 40 && it.isCurrentTeam })
        assertTrue(expired.contractOffers.size <= 4)
        assertTrue(expired.contractOffers.count { !it.isCurrentTeam } <= 3)
        assertTrue(expired.contractOffers.all { it.years in 1..2 })
        assertEquals(expired.contractOffers.map { it.teamId }.distinct().size, expired.contractOffers.size)
    }

    @Test fun lowPrestigeReceivesCurrentRenewalAndOneExternalProposal() {
        val initial = TeamPrincipalCareerEngine.initial(40, 2026, ranks).copy(prestige = 1)
        val endOfSeason = TeamPrincipalCareerEngine.recordSeason(
            initial, 2026, 40, ranks, dismissalRoll = 99
        )
        assertTrue(endOfSeason.reviewPending)
        assertFalse(endOfSeason.dismissed)
        assertEquals(2, endOfSeason.contractOffers.size)
        assertTrue(endOfSeason.contractOffers.any { it.isCurrentTeam })
        assertEquals(1, endOfSeason.contractOffers.count { !it.isCurrentTeam })
        assertEquals(40, endOfSeason.contractOffers.first { it.isCurrentTeam }.teamId)
    }

    @Test fun acceptingOfferPersistsTheSpecificTerm() {
        val state = TeamPrincipalCareerEngine.initial(40, 2026, ranks).copy(
            reviewPending = true,
            offerTeamIds = listOf(39),
            contractOffers = listOf(TeamPrincipalContractOffer(39, 2, false)),
            offersSeason = 2026
        )
        val accepted = TeamPrincipalCareerEngine.acceptOffer(state, 39, 2027, 12, contractYears = 2)
        assertEquals(39, accepted.teamId)
        assertEquals(2, accepted.contractYears)
        assertEquals(2028, accepted.contractEndSeason)
        assertFalse(accepted.reviewPending)
        assertTrue(accepted.contractOffers.isEmpty())
    }

    @Test fun freshInitialAndNewTeamContractsStartWithMinimumBoardConfidence() {
        val initial = TeamPrincipalCareerEngine.initial(40, 2026, ranks)
        assertEquals(TeamPrincipalCareerEngine.INITIAL_BOARD_SUPPORT, initial.boardSupport)

        val readyToMove = initial.copy(
            prestige = 65,
            boardSupport = 12,
            reviewPending = true,
            offerTeamIds = listOf(39),
            contractOffers = listOf(TeamPrincipalContractOffer(39, 2, false))
        )
        val accepted = TeamPrincipalCareerEngine.acceptOffer(readyToMove, 39, 2027, 15, contractYears = 2)
        assertEquals(TeamPrincipalCareerEngine.INITIAL_BOARD_SUPPORT, accepted.boardSupport)
        val highConfidenceMove = TeamPrincipalCareerEngine.acceptOffer(
            readyToMove.copy(boardSupport = 92), 39, 2027, 15, contractYears = 2
        )
        assertEquals(92, highConfidenceMove.boardSupport)
        assertEquals(1, accepted.contractStartSeason - 2026)
        assertEquals(2, accepted.contractYears)
    }

    @Test fun everyTeamPrincipalContractIsCappedAtTwoYearsIncludingLegacySaves() {
        val legacyThreeYear = TeamPrincipalCareerEngine.initial(40, 2026, ranks).copy(contractYears = 3)
        assertEquals(2027, legacyThreeYear.contractEndSeason)
        assertEquals(2, TeamPrincipalCareerState.decode(legacyThreeYear.encode())!!.contractYears)

        val schemaFiveWithThreeYears = listOf(
            5, 40, 30, 2026, 35, 2025, 40, 40, 1, 0,
            "40,39", "", "", 2025, 3, 18,
            "40,3,1;39,3,0", 2025
        ).joinToString("#")
        val migrated = TeamPrincipalCareerState.decode(schemaFiveWithThreeYears)!!
        assertEquals(2, migrated.contractYears)
        assertTrue(migrated.contractOffers.all { it.years in 1..2 })
    }

    @Test fun contractDecisionMustBeResolvedBeforeSeasonCanAdvance() {
        val state = TeamPrincipalCareerEngine.initial(40, 2026, ranks)
        assertTrue(TeamPrincipalCareerEngine.mayAdvanceWithContractDecision(state))
        assertFalse(TeamPrincipalCareerEngine.mayAdvanceWithContractDecision(state.copy(reviewPending = true)))
        assertTrue(TeamPrincipalCareerEngine.mayAdvanceWithContractDecision(state.copy(reviewPending = false)))
        assertTrue(TeamPrincipalCareerEngine.mayAdvanceWithContractDecision(null))
    }

    @Test fun boardSupportRiskStaysWithinProbabilityBounds() {
        assertTrue(TeamPrincipalCareerEngine.dismissalProbabilityPercent(90, 1, 5) >= 4)
        assertTrue(TeamPrincipalCareerEngine.dismissalProbabilityPercent(25, 40, 10) in 0..98)
        assertTrue(TeamPrincipalCareerEngine.dismissalProbabilityPercent(25, 40, 10, true) >=
            TeamPrincipalCareerEngine.dismissalProbabilityPercent(25, 40, 10, false))
    }


    @Test fun initialTrustDoesNotMakeDismissalImpossibleAndPoorManagementRaisesRisk() {
        val openingRisk = TeamPrincipalCareerEngine.dismissalProbabilityPercent(75, 37, 37)
        val severeFailureRisk = TeamPrincipalCareerEngine.dismissalProbabilityPercent(
            boardSupport = 75,
            rank = 40,
            objectiveRank = 30,
            repeatedObjectiveFailure = true,
            racePerformance = 10,
            qualifyingPerformance = 15,
            financialStress = 100,
            developmentProgress = 0,
            facilityInvestment = 0,
            objectiveCompletionPercent = 10
        )
        assertTrue("75% initial confidence must still carry real dismissal risk", openingRisk > 0)
        assertTrue("combined sporting and management failures must create severe risk", severeFailureRisk >= 75)
        assertTrue(severeFailureRisk > openingRisk)
    }

    @Test fun qualifyingRaceFinanceAndDevelopmentAreIndependentDismissalFactors() {
        val stable = TeamPrincipalCareerEngine.dismissalProbabilityPercent(75, 30, 30)
        val poorQualifying = TeamPrincipalCareerEngine.dismissalProbabilityPercent(
            75, 30, 30, qualifyingPerformance = 10
        )
        val poorRaces = TeamPrincipalCareerEngine.dismissalProbabilityPercent(
            75, 30, 30, racePerformance = 10
        )
        val financialAndTechnicalCrisis = TeamPrincipalCareerEngine.dismissalProbabilityPercent(
            75, 30, 30, financialStress = 100, developmentProgress = 0, facilityInvestment = 0
        )
        assertTrue(poorQualifying > stable)
        assertTrue(poorRaces > stable)
        assertTrue(financialAndTechnicalCrisis > stable)
    }

    @Test fun encodedStateRoundTripsContractTermSupportAndOffers() {
        val state = TeamPrincipalCareerEngine.initial(40, 2026, ranks).copy(
            contractYears = 2,
            boardSupport = 47,
            reviewPending = true,
            contractOffers = listOf(
                TeamPrincipalContractOffer(40, 2, true),
                TeamPrincipalContractOffer(39, 1, false),
                TeamPrincipalContractOffer(38, 2, false)
            ),
            offerTeamIds = listOf(40, 39, 38),
            offersSeason = 2027
        )
        assertEquals(state, TeamPrincipalCareerState.decode(state.encode()))
    }


    @Test fun activeSchemaFourSaveGetsNextUnprocessedOneYearContractWindow() {
        val legacyActive = listOf(
            4, 40, 18, 2026, 35, 2026, 40, 40, 0, 0,
            "", "2026,40,40,35,0", "", 2026
        ).joinToString("#")
        val migrated = TeamPrincipalCareerState.decode(legacyActive)!!
        assertEquals(2027, migrated.contractStartSeason)
        assertEquals(2027, migrated.contractEndSeason)
        assertFalse(migrated.reviewPending)
    }

    @Test fun schemaFourSaveMigratesCurrentTeamRenewal() {
        val legacy = listOf(
            4, 40, 18, 2026, 35, 2026, 40, 40, 1, 0,
            "39,38", "", "", 2026
        ).joinToString("#")
        val migrated = TeamPrincipalCareerState.decode(legacy)!!
        assertEquals(1, migrated.contractYears)
        assertEquals(75, migrated.boardSupport)
        assertTrue(migrated.contractOffers.any { it.teamId == 40 && it.isCurrentTeam })
        assertEquals(3, migrated.contractOffers.size)
    }
    @Test fun leaderGetsDefendTitleObjectiveInsteadOfImpossibleImprovement() {
        val state = TeamPrincipalCareerEngine.initial(1, 2026, mapOf(1 to 1))
        val improvement = state.objectives.firstOrNull { it.id.startsWith("improve_") }
        assertNotNull(improvement)
        assertEquals("maintain_rank", improvement?.kind)
        assertEquals(1, improvement?.target)
    }

    @Test fun completingSingleFacilityGoalCountsAsFullInvestmentDelivery() {
        val onlyFacility = listOf(TeamPrincipalObjective("facility_factory_2026", "Fábrica", "Upgrade", "facility_FACTORY", 2, 1))
        assertEquals(2, TeamPrincipalCareerEngine.facilityInvestmentScore(onlyFacility, listOf("facility_factory_2026:1")))
        assertEquals(0, TeamPrincipalCareerEngine.facilityInvestmentScore(onlyFacility, listOf("facility_factory_2026:0")))
        assertEquals(1, TeamPrincipalCareerEngine.facilityInvestmentScore(onlyFacility, emptyList(), upgradeProgressPercent = 1))
    }

    @Test fun ongoingResearchAndNewlyManufacturedPieceReceivePartialDevelopmentCredit() {
        assertEquals(1, TeamPrincipalCareerEngine.developmentProgressScore(0, 20, 0))
        assertEquals(1, TeamPrincipalCareerEngine.developmentProgressScore(0, 60, 0))
        assertEquals(1, TeamPrincipalCareerEngine.developmentProgressScore(0, 0, 1))
        assertEquals(1, TeamPrincipalCareerEngine.developmentProgressScore(0, 0, 0, manufacturingProgressPercent = 15))
        assertEquals(2, TeamPrincipalCareerEngine.developmentProgressScore(1, 80, 1))
    }

    @Test fun renewalPreservesLowBoardSupportInsteadOfResettingIt() {
        val state = TeamPrincipalCareerEngine.initial(1, 2026, mapOf(1 to 10)).copy(
            boardSupport = 24, reviewPending = true,
            contractOffers = listOf(TeamPrincipalContractOffer(1, 1, true))
        )
        val renewed = TeamPrincipalCareerEngine.renew(state, 2027, 10)
        assertEquals(24, renewed.boardSupport)
    }

    @Test fun previouslySavedImpossibleLeaderObjectiveIsMigratedWithoutRegeneratingSeason() {
        val initial = TeamPrincipalCareerEngine.initial(1, 2026, mapOf(1 to 1))
        val legacyObjectives = initial.objectives.map { goal ->
            if (goal.kind == "maintain_rank") goal.copy(kind = "improve", title = "Evolução no grid", detail = "Melhorar pelo menos 1 posição", target = 1) else goal
        }
        val legacy = initial.copy(objectives = legacyObjectives, objectivesPreparedForSeason = 2026, lastRank = 1)
        val migrated = TeamPrincipalCareerEngine.prepareObjectivesForOpeningSeason(
            legacy, 2026, mapOf(1 to 1), emptyMap(), 0, 10_000_000L
        )
        assertEquals("maintain_rank", migrated.objectives.first { it.id.startsWith("improve_") }.kind)
        assertEquals("Defender a liderança", migrated.objectives.first { it.id.startsWith("improve_") }.title)
    }

    @Test fun poorSeasonAtPreviousTeamDoesNotCountAsRepeatedFailureAtNewTeam() {
        val state = TeamPrincipalCareerEngine.initial(1, 2026, mapOf(1 to 35, 2 to 10)).copy(
            objectiveRank = 40, lastRank = 40, objectives = emptyList(),
            records = listOf(TeamPrincipalSeasonRecord(2025, 2, 40, 30, -5))
        )
        val result = TeamPrincipalCareerEngine.recordSeason(
            state, 2026, 40, mapOf(1 to 40, 2 to 10),
            cashBalance = 100_000_000L, facilityLevels = emptyMap(),
            completedResearchCount = 1, manufacturedPiecesReady = 1,
            racePerformance = 50, qualifyingPerformance = 50, dismissalRoll = 35
        )
        assertFalse(result.dismissed)
    }

}
