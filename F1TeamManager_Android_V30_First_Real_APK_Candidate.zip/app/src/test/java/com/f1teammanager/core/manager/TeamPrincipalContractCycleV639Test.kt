package com.f1teammanager.core.manager

import org.junit.Assert.*
import org.junit.Test

class TeamPrincipalContractCycleV639Test {
    private val ranks = (1..40).associateWith { it }

    @Test fun initialContractLastsOneSeason() {
        val state = TeamPrincipalCareerEngine.initial(40, 2026, ranks)
        assertEquals(1, state.contractYears)
        assertEquals(2026, state.contractEndSeason)
        assertTrue(TeamPrincipalCareerEngine.isEvaluationSeason(state, 2026))
        assertFalse(TeamPrincipalCareerEngine.isEvaluationSeason(state, 2025))
    }

    @Test fun prestigeControlsZeroToThreeOutsideOffers() {
        assertEquals(0, TeamPrincipalCareerEngine.outsideOfferQuota(0))
        assertEquals(0, TeamPrincipalCareerEngine.availableOffers(40, 19, ranks).size)
        assertEquals(1, TeamPrincipalCareerEngine.availableOffers(40, 20, ranks).size)
        assertEquals(1, TeamPrincipalCareerEngine.availableOffers(40, 39, ranks).size)
        assertEquals(2, TeamPrincipalCareerEngine.availableOffers(40, 40, ranks).size)
        assertEquals(2, TeamPrincipalCareerEngine.availableOffers(40, 59, ranks).size)
        assertEquals(3, TeamPrincipalCareerEngine.availableOffers(40, 60, ranks).size)
        assertEquals(3, TeamPrincipalCareerEngine.availableOffers(40, 100, ranks).size)
    }

    @Test fun multiYearContractDoesNotOpenMarketBeforeExpiry() {
        val initial = TeamPrincipalCareerEngine.initial(40, 2026, ranks).copy(
            prestige = 70, boardSupport = 100, contractYears = 2
        )
        val firstYear = TeamPrincipalCareerEngine.recordSeason(
            initial, 2026, 40, ranks, dismissalRoll = 99
        )
        assertFalse(firstYear.reviewPending)
        assertTrue(firstYear.contractOffers.isEmpty())
        assertEquals(2027, firstYear.contractEndSeason)

        val expired = TeamPrincipalCareerEngine.recordSeason(
            firstYear, 2027, 40, ranks, dismissalRoll = 99
        )
        assertTrue(expired.reviewPending)
        assertTrue(expired.contractOffers.any { it.teamId == 40 && it.isCurrentTeam })
        assertTrue(expired.contractOffers.size <= 4)
        assertTrue(expired.contractOffers.count { !it.isCurrentTeam } <= 3)
        assertTrue(expired.contractOffers.all { it.years in 1..3 })
        assertEquals(expired.contractOffers.map { it.teamId }.distinct().size, expired.contractOffers.size)
    }

    @Test fun lowPrestigeReceivesOnlyCurrentTeamRenewalWhenNotDismissed() {
        val initial = TeamPrincipalCareerEngine.initial(40, 2026, ranks).copy(prestige = 1)
        val endOfSeason = TeamPrincipalCareerEngine.recordSeason(
            initial, 2026, 40, ranks, dismissalRoll = 99
        )
        assertTrue(endOfSeason.reviewPending)
        assertFalse(endOfSeason.dismissed)
        assertEquals(1, endOfSeason.contractOffers.size)
        assertTrue(endOfSeason.contractOffers.single().isCurrentTeam)
        assertEquals(40, endOfSeason.contractOffers.single().teamId)
    }

    @Test fun acceptingOfferPersistsTheSpecificTerm() {
        val state = TeamPrincipalCareerEngine.initial(40, 2026, ranks).copy(
            reviewPending = true,
            offerTeamIds = listOf(39),
            contractOffers = listOf(TeamPrincipalContractOffer(39, 3, false)),
            offersSeason = 2026
        )
        val accepted = TeamPrincipalCareerEngine.acceptOffer(state, 39, 2027, 12, contractYears = 3)
        assertEquals(39, accepted.teamId)
        assertEquals(3, accepted.contractYears)
        assertEquals(2029, accepted.contractEndSeason)
        assertFalse(accepted.reviewPending)
        assertTrue(accepted.contractOffers.isEmpty())
    }

    @Test fun boardSupportRiskStaysWithinProbabilityBounds() {
        assertEquals(0, TeamPrincipalCareerEngine.dismissalProbabilityPercent(90, 1, 5))
        assertTrue(TeamPrincipalCareerEngine.dismissalProbabilityPercent(25, 40, 10) in 0..95)
        assertTrue(TeamPrincipalCareerEngine.dismissalProbabilityPercent(25, 40, 10, true) >=
            TeamPrincipalCareerEngine.dismissalProbabilityPercent(25, 40, 10, false))
    }

    @Test fun encodedStateRoundTripsContractTermSupportAndOffers() {
        val state = TeamPrincipalCareerEngine.initial(40, 2026, ranks).copy(
            contractYears = 2,
            boardSupport = 47,
            reviewPending = true,
            contractOffers = listOf(
                TeamPrincipalContractOffer(40, 2, true),
                TeamPrincipalContractOffer(39, 1, false),
                TeamPrincipalContractOffer(38, 3, false)
            ),
            offerTeamIds = listOf(40, 39, 38),
            offersSeason = 2027
        )
        assertEquals(state, TeamPrincipalCareerState.decode(state.encode()))
    }


    @Test fun activeSchemaFourSaveGetsNextUnprocessedOneYearContractWindow() {
        val legacyActive = listOf(
            4, 40, 18, 2026, 35, 2026, 40, 40, 0, 0,
            "", "2026,40,40,35,0", "", 2026
        ).joinToString("#")
        val migrated = TeamPrincipalCareerState.decode(legacyActive)!!
        assertEquals(2027, migrated.contractStartSeason)
        assertEquals(2027, migrated.contractEndSeason)
        assertFalse(migrated.reviewPending)
    }

    @Test fun schemaFourSaveMigratesCurrentTeamRenewal() {
        val legacy = listOf(
            4, 40, 18, 2026, 35, 2026, 40, 40, 1, 0,
            "39,38", "", "", 2026
        ).joinToString("#")
        val migrated = TeamPrincipalCareerState.decode(legacy)!!
        assertEquals(1, migrated.contractYears)
        assertEquals(75, migrated.boardSupport)
        assertTrue(migrated.contractOffers.any { it.teamId == 40 && it.isCurrentTeam })
        assertEquals(3, migrated.contractOffers.size)
    }
}
