package com.f1teammanager.core.race

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** Regression for weather strategy planning when a race is nearly finished. */
class WetTyreShortRemainingLapsRegressionTest {
    @Test
    fun rainPlansNeverContainZeroLapStintsForOneToThreeLapsRemaining() {
        listOf(Weather.LIGHT_RAIN, Weather.MEDIUM_RAIN, Weather.HEAVY_RAIN).forEach { weather ->
            (1..3).forEach { remainingLaps ->
                val plans = TyreModel.buildPlansForWeather(remainingLaps, weather)
                assertEquals("All four plan IDs must remain available for $weather/$remainingLaps", setOf("A", "B", "C", "D"), plans.keys)
                plans.values.forEach { plan ->
                    assertEquals("Stint count and tyre sequence must match", plan.sequence.size, plan.stintLaps.size)
                    assertTrue("Every stint must cover at least one lap: $weather/$remainingLaps ${plan.id} ${plan.stintLaps}", plan.stintLaps.all { it >= 1 })
                    assertEquals("Stints must cover all remaining laps", remainingLaps, plan.stintLaps.sum())
                    assertTrue("Wet strategy must use the weather-correct compound", plan.sequence.all {
                        if (weather == Weather.HEAVY_RAIN) it == Tyre.WET else it == Tyre.INTERMEDIATE
                    })
                    val compound = plan.sequence.first()
                    assertTrue("Stint must stop before 85% wear", plan.stintLaps.all {
                        it <= TyreModel.estimatedStintLifeLaps(compound, weather)
                    })
                    assertTrue("No strategy may use more stints than laps remaining", plan.stintLaps.size <= remainingLaps)
                }
            }
        }
    }
}
