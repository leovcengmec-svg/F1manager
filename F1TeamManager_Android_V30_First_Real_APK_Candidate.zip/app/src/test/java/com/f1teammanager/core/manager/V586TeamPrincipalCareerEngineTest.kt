package com.f1teammanager.core.manager

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class V586TeamPrincipalCareerEngineTest {
    private val opening = (1..40).associateWith { it }

    @Test fun careerPanelIsRestrictedToTeamPrincipalMode() {
        assertTrue(TeamPrincipalCareerEngine.isActiveMode("TEAM_PRINCIPAL", true))
        assertFalse(TeamPrincipalCareerEngine.isActiveMode("FREE", true))
        assertFalse(TeamPrincipalCareerEngine.isActiveMode("HARD", true))
        assertFalse(TeamPrincipalCareerEngine.isActiveMode("TEAM_PRINCIPAL", false))
        // Old Team Principal saves have state but no mode marker; keep them compatible.
        assertTrue(TeamPrincipalCareerEngine.isActiveMode(null, true))
        assertFalse(TeamPrincipalCareerEngine.isActiveMode(null, false))
    }

    @Test fun startsAtMinimumPrestigeAndSetsReachableBottomGridObjective() {
        val initial = TeamPrincipalCareerEngine.initial(teamId = 40, season = 2026, openingRankByTeam = opening)
        val state = TeamPrincipalCareerEngine.prepareObjectivesForOpeningSeason(
            initial, 2026, opening,
            FacilityType.values().associateWith { 0 }, previousSeasonPoints = 0, cashBalance = 5_000_000L
        )
        assertEquals(1, state.prestige)
        // The actual opening-car calibration moves a 40th-ranked car to a meaningful 37th-place target.
        assertEquals(37, state.objectiveRank)
        assertFalse(state.reviewPending)
        assertEquals(state, TeamPrincipalCareerState.decode(state.encode()))
    }

    @Test fun openingStrengthIsNotMisreportedAsBestSportingResult() {
        val state = TeamPrincipalCareerEngine.initial(40, 2026, opening)
        assertEquals(40, state.bestRank)
        assertEquals(state, TeamPrincipalCareerState.decode(state.encode()))
        val finished = TeamPrincipalCareerEngine.recordSeason(state, 2026, 35, opening, dismissalRoll = 99)
        assertEquals(35, finished.bestRank)
    }

    @Test fun legacyUnplayedCareerDoesNotKeepOpeningStrengthAsBestResult() {
        val state = TeamPrincipalCareerEngine.initial(40, 2026, opening)
        // Legacy schema fields: version, team, prestige, contract start, objective,
        // last processed season, last rank, best rank, review, dismissed, offers, records.
        val legacy = listOf(1, 40, 10, 2026, 37, 2025, 40, 3, 0, 0, "", "").joinToString("#")
        assertEquals(40, TeamPrincipalCareerState.decode(legacy)?.bestRank)
        val oldRecord = "2026,40,35,37,8"
        val legacyWithResult = listOf(1, 40, 18, 2026, 37, 2027, 35, 3, 0, 0, "", oldRecord).joinToString("#")
        assertEquals(35, TeamPrincipalCareerState.decode(legacyWithResult)?.bestRank)
        assertEquals(40, state.bestRank)
    }

    @Test fun initialOneYearContractOpensReviewAtTheEndOfItsSeason() {
        val state = TeamPrincipalCareerEngine.initial(40, 2026, opening)
        assertTrue(TeamPrincipalCareerEngine.isEvaluationSeason(state, 2026))
        assertFalse(TeamPrincipalCareerEngine.isEvaluationSeason(state, 2025))
    }

    @Test fun meetingObjectiveRaisesPrestigeAndCreatesReviewOffers() {
        val advancedFacilities = FacilityType.values().associateWith { 10 }
        var state = TeamPrincipalCareerEngine.initial(40, 2026, opening)
        state = TeamPrincipalCareerEngine.prepareObjectivesForOpeningSeason(
            state, 2026, opening, advancedFacilities, previousSeasonPoints = 100, cashBalance = 500_000_000L
        )
        state = TeamPrincipalCareerEngine.recordSeason(
            state, 2026, 34, opening, constructorPoints = 400, cashBalance = 500_000_000L,
            facilityLevels = advancedFacilities, completedResearchCount = 1, manufacturedPiecesReady = 1,
            dismissalRoll = 99
        )
        assertTrue(state.prestige > 1)
        assertTrue(state.reviewPending)
        assertTrue(state.offerTeamIds.isNotEmpty())
        assertTrue(state.contractOffers.any { it.teamId == 40 && it.isCurrentTeam })
        assertFalse(state.dismissed)
    }

    @Test fun duplicateSeasonSettlementDoesNotChangePrestigeTwice() {
        val state = TeamPrincipalCareerEngine.initial(40, 2026, opening)
        val first = TeamPrincipalCareerEngine.recordSeason(state, 2026, 38, opening, dismissalRoll = 99)
        val retry = TeamPrincipalCareerEngine.recordSeason(first, 2026, 38, opening)
        assertEquals(first, retry)
    }

    @Test fun twoSeverelyFailedSeasonsCanTriggerDismissal() {
        val basicFacilities = FacilityType.values().associateWith { 0 }
        var state = TeamPrincipalCareerEngine.initial(40, 2026, opening)
        state = TeamPrincipalCareerEngine.prepareObjectivesForOpeningSeason(
            state, 2026, opening, basicFacilities, previousSeasonPoints = 0, cashBalance = 5_000_000L
        )
        state = TeamPrincipalCareerEngine.recordSeason(state, 2026, 40, opening, facilityLevels = basicFacilities, dismissalRoll = 99)
        state = TeamPrincipalCareerEngine.prepareObjectivesForOpeningSeason(
            state, 2027, opening, basicFacilities, previousSeasonPoints = 0, cashBalance = 5_000_000L
        )
        state = TeamPrincipalCareerEngine.recordSeason(state, 2027, 40, opening, facilityLevels = basicFacilities, dismissalRoll = 0)
        assertTrue(state.reviewPending)
        assertTrue(state.dismissed)
        assertTrue(state.offerTeamIds.isNotEmpty())
    }

    @Test fun renewalMovesEvaluationWindowAndResetsContractObjective() {
        val state = TeamPrincipalCareerEngine.initial(40, 2026, opening)
        val renewed = TeamPrincipalCareerEngine.renew(state.copy(reviewPending = true), 2028, 35)
        assertEquals(2028, renewed.contractStartSeason)
        assertEquals(40, renewed.objectiveRank) // provisional until the renewed season's opening car is ranked
        assertFalse(renewed.reviewPending)
        assertTrue(TeamPrincipalCareerEngine.isEvaluationSeason(renewed, 2028))
        assertFalse(TeamPrincipalCareerEngine.isEvaluationSeason(renewed, 2029))
    }


    @Test fun hiringOffersUseCurrentChampionshipStrengthNotOnlyOpeningStrength() {
        val currentRanks = mapOf(40 to 40, 1 to 1, 2 to 31, 3 to 32, 4 to 33, 5 to 34)
        val offers = TeamPrincipalCareerEngine.availableOffers(40, 10, currentRanks)
        assertTrue(offers.isEmpty())
        assertEquals(1, TeamPrincipalCareerEngine.availableOffers(40, 30, currentRanks).size)
        assertEquals(2, TeamPrincipalCareerEngine.availableOffers(40, 50, currentRanks).size)
        assertEquals(3, TeamPrincipalCareerEngine.availableOffers(40, 70, currentRanks).size)
    }

    @Test fun acceptedOfferBuildsNextSeasonContractWithoutMutatingCurrentCareerIdentity() {
        var state = TeamPrincipalCareerEngine.initial(40, 2026, opening)
        state = TeamPrincipalCareerEngine.recordSeason(state, 2026, 37, opening, dismissalRoll = 99)
        val accepted = TeamPrincipalCareerEngine.acceptOffer(
            state.copy(reviewPending = true, offerTeamIds = listOf(39)),
            newTeamId = 39, nextSeason = 2028, newTeamChampionshipRank = 12
        )
        assertEquals(40, state.teamId)
        assertEquals(39, accepted.teamId)
        assertEquals(2028, accepted.contractStartSeason)
        assertEquals(40, accepted.records.last().teamId)
        assertTrue(accepted.offerTeamIds.isEmpty())
    }

    @Test fun careerHistoryStoresWhichTeamThePrincipalManagedEachSeason() {
        var state = TeamPrincipalCareerEngine.initial(40, 2026, opening)
        state = TeamPrincipalCareerEngine.recordSeason(state, 2026, 37, opening, dismissalRoll = 99)
        state = TeamPrincipalCareerEngine.acceptOffer(state, 39, 2027, 35, contractYears = 2)
        state = TeamPrincipalCareerEngine.recordSeason(state, 2027, 30, opening, dismissalRoll = 99)
        state = TeamPrincipalCareerEngine.recordSeason(state, 2028, 28, opening, dismissalRoll = 99)
        assertEquals(40, state.records.first().teamId)
        assertEquals(39, state.records.last().teamId)
    }

    @Test fun encodedStateRoundTrips() {
        val state = TeamPrincipalCareerEngine.recordSeason(
            TeamPrincipalCareerEngine.initial(40, 2026, opening), 2026, 38, opening, dismissalRoll = 99
        )
        assertEquals(state, TeamPrincipalCareerState.decode(state.encode()))
    }
}
