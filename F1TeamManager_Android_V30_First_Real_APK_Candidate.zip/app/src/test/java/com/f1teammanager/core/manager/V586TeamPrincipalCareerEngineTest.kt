package com.f1teammanager.core.manager

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class V586TeamPrincipalCareerEngineTest {
    private val opening = (1..40).associateWith { it }

    @Test fun careerPanelIsRestrictedToTeamPrincipalMode() {
        assertTrue(TeamPrincipalCareerEngine.isActiveMode("TEAM_PRINCIPAL", true))
        assertFalse(TeamPrincipalCareerEngine.isActiveMode("FREE", true))
        assertFalse(TeamPrincipalCareerEngine.isActiveMode("HARD", true))
        assertFalse(TeamPrincipalCareerEngine.isActiveMode("TEAM_PRINCIPAL", false))
        // Old Team Principal saves have state but no mode marker; keep them compatible.
        assertTrue(TeamPrincipalCareerEngine.isActiveMode(null, true))
        assertFalse(TeamPrincipalCareerEngine.isActiveMode(null, false))
    }

    @Test fun startsAtMinimumPrestigeAndSetsReachableBottomGridObjective() {
        val state = TeamPrincipalCareerEngine.initial(teamId = 40, season = 2026, openingRankByTeam = opening)
        assertEquals(10, state.prestige)
        assertEquals(37, state.objectiveRank)
        assertFalse(state.reviewPending)
        assertEquals(state, TeamPrincipalCareerState.decode(state.encode()))
    }

    @Test fun openingStrengthIsNotMisreportedAsBestSportingResult() {
        val state = TeamPrincipalCareerEngine.initial(40, 2026, opening)
        assertEquals(40, state.bestRank)
        assertEquals(state, TeamPrincipalCareerState.decode(state.encode()))
        val finished = TeamPrincipalCareerEngine.recordSeason(state, 2026, 35, opening)
        assertEquals(35, finished.bestRank)
    }

    @Test fun legacyUnplayedCareerDoesNotKeepOpeningStrengthAsBestResult() {
        val state = TeamPrincipalCareerEngine.initial(40, 2026, opening)
        // Legacy schema fields: version, team, prestige, contract start, objective,
        // last processed season, last rank, best rank, review, dismissed, offers, records.
        val legacy = listOf(1, 40, 10, 2026, 37, 2025, 40, 3, 0, 0, "", "").joinToString("#")
        assertEquals(40, TeamPrincipalCareerState.decode(legacy)?.bestRank)
        val oldRecord = "2026,40,35,37,8"
        val legacyWithResult = listOf(1, 40, 18, 2026, 37, 2027, 35, 3, 0, 0, "", oldRecord).joinToString("#")
        assertEquals(35, TeamPrincipalCareerState.decode(legacyWithResult)?.bestRank)
        assertEquals(40, state.bestRank)
    }

    @Test fun reviewOccursAfterTwoContractSeasonsNotOne() {
        val state = TeamPrincipalCareerEngine.initial(40, 2026, opening)
        assertFalse(TeamPrincipalCareerEngine.isEvaluationSeason(state, 2026))
        assertTrue(TeamPrincipalCareerEngine.isEvaluationSeason(state, 2027))
    }

    @Test fun meetingObjectiveRaisesPrestigeAndCreatesReviewOffers() {
        var state = TeamPrincipalCareerEngine.initial(40, 2026, opening)
        state = TeamPrincipalCareerEngine.recordSeason(state, 2026, 37, opening)
        assertTrue(state.prestige > 10)
        state = TeamPrincipalCareerEngine.recordSeason(state, 2027, 36, opening)
        assertTrue(state.reviewPending)
        assertTrue(state.offerTeamIds.isNotEmpty())
        assertFalse(state.dismissed)
    }

    @Test fun duplicateSeasonSettlementDoesNotChangePrestigeTwice() {
        val state = TeamPrincipalCareerEngine.initial(40, 2026, opening)
        val first = TeamPrincipalCareerEngine.recordSeason(state, 2026, 38, opening)
        val retry = TeamPrincipalCareerEngine.recordSeason(first, 2026, 38, opening)
        assertEquals(first, retry)
    }

    @Test fun twoSeverelyFailedSeasonsCanTriggerDismissal() {
        var state = TeamPrincipalCareerEngine.initial(40, 2026, opening)
        state = TeamPrincipalCareerEngine.recordSeason(state, 2026, 40, opening)
        state = TeamPrincipalCareerEngine.recordSeason(state, 2027, 40, opening)
        assertTrue(state.reviewPending)
        assertTrue(state.dismissed)
        assertTrue(state.offerTeamIds.isNotEmpty())
    }

    @Test fun renewalMovesEvaluationWindowAndResetsContractObjective() {
        val state = TeamPrincipalCareerEngine.initial(40, 2026, opening)
        val renewed = TeamPrincipalCareerEngine.renew(state.copy(reviewPending = true), 2028, 35)
        assertEquals(2028, renewed.contractStartSeason)
        assertEquals(32, renewed.objectiveRank)
        assertFalse(renewed.reviewPending)
        assertTrue(TeamPrincipalCareerEngine.isEvaluationSeason(renewed, 2029))
    }


    @Test fun hiringOffersUseCurrentChampionshipStrengthNotOnlyOpeningStrength() {
        val currentRanks = mapOf(40 to 40, 1 to 1, 2 to 31, 3 to 32, 4 to 33, 5 to 34)
        val offers = TeamPrincipalCareerEngine.availableOffers(40, 10, currentRanks)
        assertEquals(listOf(2, 3, 4), offers)
    }

    @Test fun acceptedOfferBuildsNextSeasonContractWithoutMutatingCurrentCareerIdentity() {
        var state = TeamPrincipalCareerEngine.initial(40, 2026, opening)
        state = TeamPrincipalCareerEngine.recordSeason(state, 2026, 37, opening)
        val accepted = TeamPrincipalCareerEngine.acceptOffer(
            state.copy(reviewPending = true, offerTeamIds = listOf(39)),
            newTeamId = 39, nextSeason = 2028, newTeamChampionshipRank = 12
        )
        assertEquals(40, state.teamId)
        assertEquals(39, accepted.teamId)
        assertEquals(2028, accepted.contractStartSeason)
        assertEquals(40, accepted.records.last().teamId)
        assertTrue(accepted.offerTeamIds.isEmpty())
    }

    @Test fun careerHistoryStoresWhichTeamThePrincipalManagedEachSeason() {
        var state = TeamPrincipalCareerEngine.initial(40, 2026, opening)
        state = TeamPrincipalCareerEngine.recordSeason(state, 2026, 37, opening)
        state = TeamPrincipalCareerEngine.recordSeason(state, 2027, 36, opening)
        state = TeamPrincipalCareerEngine.acceptOffer(state, 39, 2028, 35)
        state = TeamPrincipalCareerEngine.recordSeason(state, 2028, 30, opening)
        assertEquals(40, state.records.first().teamId)
        assertEquals(39, state.records.last().teamId)
    }

    @Test fun encodedStateRoundTrips() {
        val state = TeamPrincipalCareerEngine.recordSeason(
            TeamPrincipalCareerEngine.initial(40, 2026, opening), 2026, 38, opening
        )
        assertEquals(state, TeamPrincipalCareerState.decode(state.encode()))
    }
}
