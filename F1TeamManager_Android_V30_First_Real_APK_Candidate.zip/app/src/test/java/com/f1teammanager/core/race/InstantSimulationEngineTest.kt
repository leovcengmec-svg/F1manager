package com.f1teammanager.core.race

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class InstantSimulationEngineTest {
    private fun participants() = (1..80).map { id ->
        RaceParticipant(
            driverId = id,
            driverName = "Driver $id",
            teamId = ((id - 1) / 2) + 1,
            teamName = "Team ${((id - 1) / 2) + 1}",
            driverSpeed = 75,
            qualifying = 75,
            overtaking = 70,
            defense = 70,
            consistency = 90,
            enginePerformance = 75,
            tyreGrip = 75,
            tyreWear = 90,
            reliability = 100,
            wetSkill = 75,
            chassisPerformance = 75,
            frontWingPerformance = 75,
            rearWingPerformance = 75,
            brakesPerformance = 75,
            electricPowerUnitPerformance = 75,
            engineReliability = 100,
            chassisReliability = 100,
            frontWingReliability = 100,
            rearWingReliability = 100,
            brakesReliability = 100,
            electricPowerUnitReliability = 100
        )
    }

    @Test
    fun instantQualifyingCompletesAllPhasesAndBuildsFullGrid() {
        val engine = CareerWeekendEngine(seed = 342)
        engine.start(participants(), RaceCircuit(342, "Instant GP", 5, 90_000L, 0.0, 0.0, 0.0), 1)

        val snapshot = engine.simulateQualifyingInstantly()

        assertTrue(engine.qualifyingComplete())
        assertEquals(80, snapshot.grid!!.grid.size)
        assertEquals(3, snapshot.grid!!.phases.count { it.entries.isNotEmpty() })
    }

    @Test
    fun instantRaceProcessesProgrammedDistanceAndReturnsResult() {
        val engine = CareerWeekendEngine(seed = 343)
        val circuit = RaceCircuit(343, "Instant GP", 5, 90_000L, 0.0, 0.0, 0.0)
        engine.start(participants(), circuit, 1)
        engine.simulateQualifyingInstantly()

        val snapshot = engine.simulateRaceInstantly()
        val result = engine.result()

        assertTrue(snapshot.completed)
        assertFalse(result.classification.isEmpty())
        assertTrue(result.classification.all { it.laps <= circuit.laps })
        assertEquals(circuit.laps, result.classification.maxOf { it.laps })
    }

    @Test
    fun instantWeekendRunsQualifyingThenFullRaceAndReturnsBothResults() {
        val engine = CareerWeekendEngine(seed = 344)
        val circuit = RaceCircuit(344, "Instant Weekend GP", 6, 90_000L, 0.0, 0.0, 0.0)
        engine.start(participants(), circuit, 1)
        val weekend = engine.simulateWeekendInstantly()
        assertTrue(weekend.qualifying.grid!!.grid.isNotEmpty())
        assertEquals(80, weekend.qualifying.grid!!.grid.size)
        assertTrue(weekend.race.completed)
        assertEquals(circuit.laps, weekend.result.classification.maxOf { it.laps })
        assertTrue(weekend.result.classification.all { it.laps <= circuit.laps })
    }
}
