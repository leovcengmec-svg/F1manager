package com.f1teammanager.core.manager

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class RaceFinalizationCanonicalGarageV734Test {
    @Test fun gp30PlanIncludesCanonicalGaragesAfterAwardsAndBeforeFinalPersistence() {
        val steps = RaceFinalizationPlan.steps(30, 30)
        val prizes = steps.indexOf(RaceFinalizationPlan.SEASON_PRIZES)
        val garages = steps.indexOf(RaceFinalizationPlan.AI_CANONICAL_NEXT_SEASON_GARAGES)
        val persist = steps.indexOf(RaceFinalizationPlan.PERSIST_FINAL_STATE)
        assertTrue(prizes >= 0)
        assertTrue(garages > prizes)
        assertTrue(persist > garages)
        assertFalse(RaceFinalizationPlan.steps(29, 30).contains(RaceFinalizationPlan.AI_CANONICAL_NEXT_SEASON_GARAGES))
    }

    @Test fun v733PendingGp30CanResumeAtTheNewCanonicalGarageStep() {
        val done = mutableSetOf<String>()
        // Simulate the persisted V733 journal: all old GP30 steps through awards
        // succeeded, then MainActivity requested a step that the old plan omitted.
        done += listOf(
            RaceFinalizationPlan.PLAYER_FINANCE,
            RaceFinalizationPlan.PLAYER_SALARY,
            RaceFinalizationPlan.AI_FINANCE,
            RaceFinalizationPlan.AI_SPONSORSHIP,
            RaceFinalizationPlan.RACE_RECORD,
            RaceFinalizationPlan.DRIVER_EVOLUTION,
            RaceFinalizationPlan.RACE_NEWS,
            RaceFinalizationPlan.SEASON_PRIZES
        )
        val journal = RaceFinalizationJournal(
            2029, 30,
            isDone = { _, _, step -> step in done },
            markDone = { _, _, step -> done.add(step) }
        )
        var garageBuilds = 0
        journal.runStep(RaceFinalizationPlan.AI_CANONICAL_NEXT_SEASON_GARAGES) { garageBuilds++ }
        journal.runStep(RaceFinalizationPlan.AI_CANONICAL_NEXT_SEASON_GARAGES) { garageBuilds++ }
        assertEquals(1, garageBuilds)
        assertTrue(RaceFinalizationPlan.AI_CANONICAL_NEXT_SEASON_GARAGES in done)
        journal.runStep(RaceFinalizationPlan.PERSIST_FINAL_STATE) { }
        journal.complete()
        assertTrue(RaceFinalizationPlan.COMPLETE in done)
    }

    @Test fun canonicalGarageStepCannotRunBeforePrizeSettlement() {
        val done = mutableSetOf<String>()
        val journal = RaceFinalizationJournal(
            2029, 30,
            isDone = { _, _, step -> step in done },
            markDone = { _, _, step -> done.add(step) }
        )
        var invoked = false
        val result = runCatching {
            journal.runStep(RaceFinalizationPlan.AI_CANONICAL_NEXT_SEASON_GARAGES) { invoked = true }
        }
        assertTrue(result.isFailure)
        assertFalse(invoked)
    }
}
