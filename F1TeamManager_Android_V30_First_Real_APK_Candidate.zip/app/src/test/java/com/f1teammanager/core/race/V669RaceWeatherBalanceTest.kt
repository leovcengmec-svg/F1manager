package com.f1teammanager.core.race

import com.f1teammanager.core.season.SeasonCalendar
import kotlin.random.Random
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class V669RaceWeatherBalanceTest {
    private fun isRain(weather: Weather): Boolean = CircuitWeatherModel.isRain(weather)

    @Test
    fun raceStartRainProbabilityRemainsCircuitSpecificButNotFrequent() {
        val arid = RaceCircuit(4, "Sakhir", 57, 100_500L)
        val wet = RaceCircuit(12, "Spa-Francorchamps", 44, 111_500L)
        val trials = 20_000
        val aridRate = (1..trials).count {
            isRain(CircuitWeatherModel.raceStartWeather(arid, Random(it)))
        }.toDouble() / trials
        val wetRate = (1..trials).count {
            isRain(CircuitWeatherModel.raceStartWeather(wet, Random(it)))
        }.toDouble() / trials

        assertTrue("Sakhir rain-start rate too high: $aridRate", aridRate < 0.04)
        assertTrue("Spa must remain more rain-prone than Sakhir: $aridRate vs $wetRate", wetRate > aridRate + 0.15)
        assertTrue("Even a wet circuit should not start rainy in most races: $wetRate", wetRate < 0.24)
    }

    @Test
    fun activeRainHasARealChanceToClearInsteadOfUsingTheDryTrackProbability() {
        val profile = CircuitWeatherModel.profileForCircuit("Silverstone")
        val trials = 20_000
        val wetTransitions = (1..trials).count {
            CircuitWeatherModel.shouldTransitionDuringRace(
                Weather.LIGHT_RAIN, profile, Random(it), continuousRainLaps = 6
            )
        }.toDouble() / trials
        val dryTransitions = (1..trials).count {
            CircuitWeatherModel.shouldTransitionDuringRace(
                Weather.DRY, profile, Random(it), continuousRainLaps = 0
            )
        }.toDouble() / trials

        assertTrue("Rain should be allowed to clear: $wetTransitions", wetTransitions > 0.48)
        assertTrue("New weather fronts should remain uncommon: $dryTransitions", dryTransitions < 0.05)
    }

    @Test
    fun noContinuousRainSpellCanExceedEighteenLaps() {
        repeat(2_000) { seed ->
            val random = Random(seed)
            val profile = CircuitWeatherModel.profileForCircuit("Interlagos")
            var weather = Weather.LIGHT_RAIN
            var rainStartedLap = 1
            var longestRainSpell = 0

            for (lap in 6..96 step 6) {
                val duration = if (isRain(weather)) lap - rainStartedLap + 1 else 0
                if (CircuitWeatherModel.shouldTransitionDuringRace(weather, profile, random, duration)) {
                    weather = CircuitWeatherModel.nextRaceWeather(weather, random, duration)
                }
                if (isRain(weather)) {
                    if (duration == 0) rainStartedLap = lap
                } else if (rainStartedLap > 0) {
                    longestRainSpell = maxOf(longestRainSpell, lap - rainStartedLap)
                    rainStartedLap = -1
                }
            }
            if (rainStartedLap > 0) longestRainSpell = maxOf(longestRainSpell, 97 - rainStartedLap)
            assertTrue("Seed $seed kept a rain front active for $longestRainSpell laps", longestRainSpell <= CircuitWeatherModel.MAX_CONTINUOUS_RAIN_LAPS)
        }
    }

    @Test
    fun fullCircuitPoolKeepsRaceRainOccasionalAcrossManySeasons() {
        val circuits = SeasonCalendar.allGps
        assertEquals(50, circuits.size)
        var rainyRaces = 0
        var totalRaces = 0

        repeat(1_000) { seasonSeed ->
            circuits.forEachIndexed { index, gp ->
                val circuit = RaceCircuit(index + 1, gp.circuit, gp.laps, gp.averageLapTimeMs)
                val profile = CircuitWeatherModel.profileForCircuit(circuit)
                val random = Random(((seasonSeed + 1) * 73 + index) xor 0x6697EA71)
                var weather = CircuitWeatherModel.raceStartWeather(circuit, random)
                var rainStartedLap = if (isRain(weather)) 1 else -1
                var hadRain = isRain(weather)

                for (lap in 6..circuit.laps step 6) {
                    val duration = if (isRain(weather) && rainStartedLap > 0) lap - rainStartedLap + 1 else 0
                    if (CircuitWeatherModel.shouldTransitionDuringRace(weather, profile, random, duration)) {
                        weather = CircuitWeatherModel.nextRaceWeather(weather, random, duration)
                    }
                    if (isRain(weather)) {
                        hadRain = true
                        if (rainStartedLap < 0) rainStartedLap = lap
                    } else {
                        rainStartedLap = -1
                    }
                }
                if (hadRain) rainyRaces++
                totalRaces++
            }
        }
        val rate = rainyRaces.toDouble() / totalRaces
        assertTrue("Rain appeared too rarely across the 50-circuit pool: $rate", rate >= 0.07)
        assertTrue("Rain appeared too often across the 50-circuit pool: $rate", rate <= 0.16)
    }
}
