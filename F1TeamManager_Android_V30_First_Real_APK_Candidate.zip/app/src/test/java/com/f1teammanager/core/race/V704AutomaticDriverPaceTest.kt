package com.f1teammanager.core.race

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class V704AutomaticDriverPaceTest {
    private fun roster() = (1..80).map { id ->
        RaceParticipant(
            driverId = id, driverName = "Driver $id", teamId = ((id - 1) / 2) + 1,
            teamName = "Team ${((id - 1) / 2) + 1}", driverSpeed = if (id <= 2) 90 else 75,
            qualifying = 80, overtaking = 80, defense = 80, consistency = 88,
            enginePerformance = 80, tyreGrip = 80, tyreWear = 80, reliability = 100,
            wetSkill = 80, chassisPerformance = 80, frontWingPerformance = 80,
            rearWingPerformance = 80, brakesPerformance = 80, electricPowerUnitPerformance = 80,
            engineReliability = 100, chassisReliability = 100, frontWingReliability = 100,
            rearWingReliability = 100, brakesReliability = 100, electricPowerUnitReliability = 100
        )
    }

    private fun choose(
        fuelKg: Double = FuelModel.TANK_CAPACITY_KG,
        wear: Int = 20,
        remainingLaps: Int = 20,
        speed: Int = 90,
        overtaking: Int = 85,
        position: Int = 3,
        gap: Long? = 900L,
        weather: Weather = Weather.DRY,
        wetSkill: Int = 80
    ) = AutomaticDriverPacePolicy.choose(
        totalLaps = 58,
        currentLap = 58 - remainingLaps + 1,
        fuelKg = fuelKg,
        tyreWearPercent = wear,
        tyre = Tyre.MEDIUM,
        weather = weather,
        position = position,
        driverSpeed = speed,
        wetSkill = wetSkill,
        overtaking = overtaking,
        nearestRivalGapMs = gap
    )

    @Test
    fun lowFuelAutomaticallySelectsPoupar() {
        val remaining = 12
        val balancedNeed = FuelModel.consumptionPerLap(58, DriverStrategyMode.BALANCED, Weather.DRY, Tyre.MEDIUM) * remaining
        assertEquals(DriverStrategyMode.DEFENSE, choose(fuelKg = balancedNeed * 0.8, remainingLaps = remaining))
    }

    @Test
    fun marginalFuelSelectsBalancedInsteadOfAttack() {
        val remaining = 12
        val attack = FuelModel.consumptionPerLap(58, DriverStrategyMode.ATTACK, Weather.DRY, Tyre.MEDIUM) * remaining
        val balanced = FuelModel.consumptionPerLap(58, DriverStrategyMode.BALANCED, Weather.DRY, Tyre.MEDIUM) * remaining
        val reserve = FuelModel.consumptionPerLap(58, DriverStrategyMode.ATTACK, Weather.DRY, Tyre.MEDIUM) * 0.75
        val fuel = (balanced + reserve + attack + reserve) / 2.0
        assertEquals(DriverStrategyMode.BALANCED, choose(fuelKg = fuel, remainingLaps = remaining))
    }

    @Test
    fun wornTyresSelectPouparAndIntermediateWearSelectsBalanced() {
        assertEquals(DriverStrategyMode.DEFENSE, choose(wear = 84))
        assertEquals(DriverStrategyMode.BALANCED, choose(wear = 68))
    }

    @Test
    fun nearbyBattleCanSelectAttackWhenFuelAndTyresAreSafe() {
        assertEquals(DriverStrategyMode.ATTACK, choose(wear = 20, gap = 700L))
    }

    @Test
    fun noRivalOpportunityDoesNotWasteFuelOrTyresOnAttack() {
        assertEquals(DriverStrategyMode.BALANCED, choose(wear = 30, gap = null, position = 20))
    }
    @Test
    fun legacyManualStrategyApiCannotOverrideThePilot() {
        val engine = CareerWeekendEngine(seed = 704)
        engine.start(roster(), RaceCircuit(704, "API Guard GP", 8, 90_000L, 0.0, 0.0, 0.0), 1)
        val before = engine.snapshotForUi().plans.getValue(1).mode
        engine.setStrategy(1, DriverStrategyMode.ATTACK)
        assertEquals(before, engine.snapshotForUi().plans.getValue(1).mode)
        engine.setPlan(1, mode = DriverStrategyMode.ATTACK)
        assertEquals(before, engine.snapshotForUi().plans.getValue(1).mode)
    }

    @Test
    fun fullRaceAutomaticallyUsesAttackBalancedAndPouparWithoutFuelPrompt() {
        val engine = CareerWeekendEngine(seed = 704)
        engine.start(roster(), RaceCircuit(704, "Automatic Pace GP", 58, 92_000L, 0.0, 0.0, 0.0), 1)
        engine.simulateQualifyingInstantly()
        engine.prepareRaceStartWeather()
        var snapshot = engine.snapshotForUi()
        val observedModes = mutableSetOf<DriverStrategyMode>()
        var guard = 0
        while (!snapshot.completed && ++guard < 200_000) {
            snapshot.plans.values.forEach { observedModes += it.mode }
            val pending = snapshot.decision
            if (pending != null) {
                assertFalse("O combustível crítico não deve pedir escolha manual", pending.request.type == ManagerDecisionType.FUEL_CRITICAL)
                val action = if (pending.request.type == ManagerDecisionType.RED_FLAG) {
                    ManagerDecisionAction.RESTART_PLAN_A
                } else {
                    ManagerDecisionAction.STAY_OUT
                }
                snapshot = engine.choose(action)
            } else {
                snapshot = engine.advance()
            }
        }
        assertTrue("A corrida deve concluir", snapshot.completed)
        assertTrue("O piloto deve usar Ataque quando há oportunidade", DriverStrategyMode.ATTACK in observedModes)
        assertTrue("O piloto deve usar Equilibrado como padrão seguro", DriverStrategyMode.BALANCED in observedModes)
        assertTrue("O piloto deve usar Poupar automaticamente quando necessário", DriverStrategyMode.DEFENSE in observedModes)
        assertEquals(58, engine.result().classification.maxOf { it.laps })
    }

}
