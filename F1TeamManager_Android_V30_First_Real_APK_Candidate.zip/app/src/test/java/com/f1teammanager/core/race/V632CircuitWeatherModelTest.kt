package com.f1teammanager.core.race

import kotlin.random.Random
import com.f1teammanager.core.season.SeasonCalendar
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class V632CircuitWeatherModelTest {
    private fun isRain(weather: Weather): Boolean = weather in setOf(
        Weather.LIGHT_RAIN, Weather.MEDIUM_RAIN, Weather.HEAVY_RAIN
    )

    @Test fun profilesReflectCircuitClimateInsteadOfUsingOneGlobalChance() {
        val desert = CircuitWeatherModel.profileForCircuit("Sakhir")
        val temperate = CircuitWeatherModel.profileForCircuit("Albert Park")
        val wet = CircuitWeatherModel.profileForCircuit("Spa-Francorchamps")
        assertTrue(desert.raceRainStartChance < temperate.raceRainStartChance)
        assertTrue(temperate.raceRainStartChance < wet.raceRainStartChance)
        assertTrue(desert.qualifyingTransitionChance < wet.qualifyingTransitionChance)
        listOf(desert, temperate, wet).forEach { profile ->
            assertTrue(profile.raceRainStartChance in 0.0..1.0)
            assertTrue(profile.qualifyingTransitionChance in 0.0..1.0)
            assertTrue(profile.raceTransitionChance in 0.0..1.0)
        }
    }

    @Test fun raceStartWeatherIsDeterministicForTheSameSeedAndCircuit() {
        val circuit = RaceCircuit(12, "Spa-Francorchamps", 44, 111_500L)
        val first = CircuitWeatherModel.raceStartWeather(circuit, Random(632))
        val second = CircuitWeatherModel.raceStartWeather(circuit, Random(632))
        assertEquals(first, second)
    }

    @Test fun aridRaceStartIsMuchDrierThanWetCircuitOverManySeeds() {
        val dryCircuit = RaceCircuit(4, "Sakhir", 57, 100_500L)
        val wetCircuit = RaceCircuit(12, "Spa-Francorchamps", 44, 111_500L)
        val trials = 20_000
        val dryWetCount = (1..trials).count { isRain(CircuitWeatherModel.raceStartWeather(dryCircuit, Random(it))) }
        val wetWetCount = (1..trials).count { isRain(CircuitWeatherModel.raceStartWeather(wetCircuit, Random(it))) }
        val dryRate = dryWetCount.toDouble() / trials
        val wetRate = wetWetCount.toDouble() / trials
        assertTrue("Sakhir rain-start rate unexpectedly high: $dryRate", dryRate < 0.07)
        assertTrue("Spa should be more rain-prone than Sakhir: dry=$dryRate wet=$wetRate", wetRate > dryRate + 0.18)
        assertTrue("Wet circuit rate should remain below certainty: $wetRate", wetRate < 0.36)
    }


    @Test fun fullFiftyCircuitPoolKeepsRainWeekendFrequencyInTheTargetBand() {
        val circuits = SeasonCalendar.allGps
        assertEquals(50, circuits.size)
        var rainWeekends = 0
        var totalWeekends = 0
        repeat(1_000) { seasonSeed ->
            circuits.forEachIndexed { index, gp ->
                val circuit = RaceCircuit(index + 1, gp.circuit, gp.laps, gp.averageLapTimeMs)
                val profile = CircuitWeatherModel.profileForCircuit(circuit)
                val qualifyingRandom = Random((seasonSeed + 1) * 31 + index xor 0x5A17C0DE)
                var qualifyingWeather = CircuitWeatherModel.qualifyingStartWeather(circuit, qualifyingRandom)
                var qualifyingRain = isRain(qualifyingWeather)
                repeat(12) {
                    if (qualifyingRandom.nextDouble() < profile.qualifyingTransitionChance) {
                        qualifyingWeather = CircuitWeatherModel.nextQualifyingWeather(qualifyingWeather, qualifyingRandom)
                    }
                    if (isRain(qualifyingWeather)) qualifyingRain = true
                }

                val raceRandom = Random((seasonSeed + 1) * 73 + index xor 0x6327EA71)
                var raceWeather = CircuitWeatherModel.raceStartWeather(circuit, raceRandom)
                var raceRain = isRain(raceWeather)
                repeat(10) {
                    if (raceRandom.nextDouble() < profile.raceTransitionChance) {
                        raceWeather = CircuitWeatherModel.nextRaceWeather(raceWeather, raceRandom)
                    }
                    if (isRain(raceWeather)) raceRain = true
                }
                if (qualifyingRain || raceRain) rainWeekends++
                totalWeekends++
            }
        }
        val rate = rainWeekends.toDouble() / totalWeekends
        assertTrue("Rain occurred in too few weekends: $rate", rate >= 0.25)
        assertTrue("Rain occurred in too many weekends: $rate", rate <= 0.45)
    }

    @Test fun qualifyingTransitionsDoNotJumpFromDryDirectlyToHeavyRain() {
        repeat(500) { seed ->
            val next = CircuitWeatherModel.nextQualifyingWeather(Weather.DRY, Random(seed))
            assertTrue(next == Weather.CLOUDY || next == Weather.LIGHT_RAIN)
        }
    }

    @Test fun raceWeatherDoesNotJumpFromDryDirectlyToRain() {
        repeat(500) { seed ->
            assertEquals(Weather.CLOUDY, CircuitWeatherModel.nextRaceWeather(Weather.DRY, Random(seed)))
        }
    }
}
