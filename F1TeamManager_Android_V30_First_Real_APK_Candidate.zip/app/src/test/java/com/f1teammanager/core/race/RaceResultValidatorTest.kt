package com.f1teammanager.core.race

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class RaceResultValidatorTest {
    private fun entry(id: Int, laps: Int, position: Int = id) = FinishEntry(
        position = position,
        driverId = id,
        driverName = "Driver $id",
        teamName = "Team ${(id + 1) / 2}",
        laps = laps,
        totalTimeMs = id * 100_000L,
        status = "FINISHED",
        tyre = Tyre.MEDIUM,
        pitStops = 1
    )

    private fun result(entries: List<FinishEntry>, points: Map<Int, Int> = entries.associate { it.driverId to 10 }) = RaceResult(
        classification = entries,
        events = emptyList(),
        fastestLapDriverId = entries.firstOrNull()?.driverId,
        weather = Weather.DRY,
        points = points,
        safetyCarLaps = 0,
        vscLaps = 0
    )

    @Test
    fun acceptsCompleteClassificationWithUniqueDrivers() {
        assertTrue(RaceResultValidator.validate(result(listOf(entry(1, 5), entry(2, 4))), 5).isEmpty())
    }

    @Test
    fun rejectsDuplicateDriverAndOutOfRangeLaps() {
        val errors = RaceResultValidator.validate(result(listOf(entry(1, 5), entry(1, 6))), 5)
        assertTrue(errors.any { it.contains("duplicados") })
        assertTrue(errors.any { it.contains("fora da distância") })
    }

    @Test
    fun rejectsPointsForDriverOutsideClassification() {
        val errors = RaceResultValidator.validate(result(listOf(entry(1, 5)), mapOf(1 to 10, 2 to 5)), 5)
        assertEquals(1, errors.count { it.contains("ausente da classificação") })
    }

    @Test
    fun rejectsClassificationThatDidNotReachProgrammedDistance() {
        val errors = RaceResultValidator.validate(result(listOf(entry(1, 4), entry(2, 3))), 5)
        assertTrue(errors.any { it.contains("Nenhum piloto concluiu") })
    }
    @Test
    fun rejectsMalformedClassificationMetadata() {
        val malformed = entry(1, 5).copy(
            position = 0,
            driverName = " ",
            totalTimeMs = -1L,
            pitStops = -1
        )
        val errors = RaceResultValidator.validate(result(listOf(malformed)), 5)
        assertTrue(errors.any { it.contains("posição inválida") })
        assertTrue(errors.any { it.contains("sem identificação") })
        assertTrue(errors.any { it.contains("tempo total negativo") })
        assertTrue(errors.any { it.contains("número negativo de paradas") })
    }

    @Test
    fun rejectsNegativeNeutralizationAndFastestLapTimes() {
        val valid = result(listOf(entry(1, 5)))
        val malformed = valid.copy(safetyCarLaps = -1, fastestLapTimeMs = -5L)
        val errors = RaceResultValidator.validate(malformed, 5)
        assertTrue(errors.any { it.contains("neutralização contém número negativo") })
        assertTrue(errors.any { it.contains("volta mais rápida é negativo") })
    }

}
