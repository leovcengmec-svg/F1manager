package com.f1teammanager.core.race

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class InstantSimulationPreflightV369Test {
    private val circuit = RaceCircuit(369, "V369 Test GP", 8, 75_000L, 0.0, 0.0, 0.0)

    private fun roster(): List<RaceParticipant> = (1..80).map { id ->
        RaceParticipant(
            driverId = id, driverName = "Driver $id", teamId = (id - 1) / 2 + 1,
            teamName = "Team ${(id - 1) / 2 + 1}", driverSpeed = 70, qualifying = 70,
            overtaking = 70, defense = 70, consistency = 70, enginePerformance = 70
        )
    }

    @Test fun duplicateDriverIdsAreRejectedBeforeEngineStateChanges() {
        val engine = CareerWeekendEngine(seed = 369)
        val roster = roster().toMutableList()
        roster[79] = roster[79].copy(driverId = roster[0].driverId)

        val failure = runCatching { engine.start(roster, circuit, playerTeamId = 1) }.exceptionOrNull()

        assertTrue(failure is IllegalArgumentException)
        assertNull(engine.configuredCircuit())
    }

    @Test fun invalidCircuitIsRejectedBeforeEngineStateChanges() {
        val engine = CareerWeekendEngine(seed = 369)
        val failure = runCatching { engine.start(roster(), circuit.copy(laps = 0), playerTeamId = 1) }.exceptionOrNull()

        assertTrue(failure is IllegalArgumentException)
        assertNull(engine.configuredCircuit())
    }

    @Test fun validRosterStartsWithAllEightyUniqueDrivers() {
        val engine = CareerWeekendEngine(seed = 369)
        engine.start(roster(), circuit, playerTeamId = 1)

        assertEquals(circuit, engine.configuredCircuit())
        assertEquals(0, engine.snapshotForUi().lap)
    }
}
