# V496 — Evento de falha de P&D na Home

- A falha de P&D da equipe do jogador agora gera um aviso de evento na Home, usando o fluxo de cards/modal de evento já existente.
- O aviso identifica explicitamente a equipe do jogador e informa que nenhum novo design foi criado, que a tecnologia anterior foi preservada e que custo e prazo foram consumidos.
- O filtro do evento exige que a notificação de falha pertença à equipe do jogador; falhas de equipes de IA não são exibidas como alertas de Home.
- O evento usa a arte existente `event_engine_failure.webp`; o restante do fluxo de P&D e o histórico de notícias são preservados.
- Validação realizada: integridade do ZIP e inspeção estática das alterações. Compilação Android não executada neste ambiente.
