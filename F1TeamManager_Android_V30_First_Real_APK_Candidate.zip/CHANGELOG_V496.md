# V496 — Continuidade dos níveis de instalações da IA

- Corrigida a causa raiz em `AITeamDevelopmentEngine.simulateFinancial`: a reconstrução histórica das temporadas anteriores não pode mais sobrescrever os níveis de instalações persistidos para a temporada atual.
- A simulação histórica do carro/garagem continua sendo reconstruída para manter a cadeia de evolução dos carros; imediatamente antes de simular a temporada-alvo, o motor aplica o estado canônico de instalações recebido do ledger persistente.
- Compatibilidade preservada para chamadas antigas sem `startingFacilities`, que continuam reconstruindo a evolução de instalações de forma determinística.
- Adicionados testes de regressão para níveis de instalação na virada de temporada e round-trip do snapshot financeiro das equipes IA.
- Validação de compilação/testes depende de ambiente Gradle/Android disponível.
