# Auditoria V368

## Escopo
Teste de integração do serviço de simulação instantânea com o motor real de qualificação e corrida.

## Alterações
- `InstantSimulationEndToEndV368Test` cobre uma corrida completa de 8 voltas com 80 pilotos.
- Verifica Q1/Q2/Q3 com 80/50/20 participantes, classificação final única e distância programada.
- Testa a rejeição de circuito divergente antes da mutação do estado do motor.
- Versão Android: 0.368.0.

## Estado de execução
- Inspeção estática do teste: concluída.
- Execução JUnit/Gradle: não executada neste ambiente (não há `gradlew` no ZIP nem Gradle instalado).
- Build Android: pendente.
- Persistência da carreira e duas temporadas completas: ainda pendentes; este teste cobre o motor, não o armazenamento Android.
