from pathlib import Path
root=Path(__file__).parent
main=(root/'app/src/main/java/com/f1teammanager/MainActivity.kt').read_text()
gradle=(root/'app/build.gradle.kts').read_text()
checks={
 'versionCode 678':'versionCode = 678' in gradle,
 'versionName 0.678.0':'versionName = "0.678.0"' in gradle,
 'signed contract opens standard Home event modal':'title in setOf("RENOVAÇÃO DE CONTRATO", "CONTRATO ASSINADO", "CONTRATO FECHADO", "TRANSFERÊNCIA CONFIRMADA")' in main,
 'transfer included in modal priority':'"RENOVAÇÃO DE CONTRATO", "CONTRATO ASSINADO", "CONTRATO FECHADO", "TRANSFERÊNCIA CONFIRMADA" -> 2' in main,
 'transfer standard artwork already wired':'normalizedNoticeTitle == "TRANSFERÊNCIA CONFIRMADA" -> R.drawable.notice_market_signed' in main,
 'market count includes transfer':'val signedMarketTitles = setOf("RENOVAÇÃO DE CONTRATO", "CONTRATO ASSINADO", "CONTRATO FECHADO", "TRANSFERÊNCIA CONFIRMADA")' in main,
 'home signed summary includes transfer':'it.title.trim().uppercase(Locale.ROOT) in setOf("RENOVAÇÃO DE CONTRATO", "CONTRATO ASSINADO", "CONTRATO FECHADO", "TRANSFERÊNCIA CONFIRMADA")' in main,
 'negotiation filtering remains unchanged':'Offers, counters and other negotiation stages remain in Central News only.' in main,
}
for k,v in checks.items(): print(('PASS' if v else 'FAIL')+' '+k)
print(f'{sum(checks.values())}/{len(checks)} checks passed')
raise SystemExit(0 if all(checks.values()) else 1)
