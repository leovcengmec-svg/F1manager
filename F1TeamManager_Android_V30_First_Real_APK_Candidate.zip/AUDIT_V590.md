# Auditoria V590 — consolidação da integração dinâmica

## Raiz do defeito corrigida

A reconciliação V589 retirava pilotos vinculados ao roster da lista de agentes livres, mas tentava preencher a própria equipe consultando essa mesma lista já filtrada. Além disso, a reconstrução final da lista de agentes livres podia adicionar novamente todos os pilotos sem contrato, inclusive os vinculados a equipes. V590 separa as fontes de candidatos para preenchimento do roster e aplica o filtro de vínculo também na lista final.

## Escopo alterado

- Mercado e contratos: pilotos novos vinculados vão primeiro para a equipe declarada; agentes livres não vinculados continuam disponíveis para vagas elegíveis.
- Integridade: um piloto não pode estar declarado no roster de duas equipes diferentes sem erro explícito.
- Compatibilidade: contratos existentes, transferências agendadas, negociações, relatórios, notificações e histórico não são apagados pela reconciliação.
- Cobertura: testes de regressão para contratação de pilotos da equipe nova, mercado livre, idempotência e rosters conflitantes.
- Versão: app `0.590.0`, código 590; arquivo ZIP mantém o nome oficial.

## Verificações

- Inspeção estática do fluxo de reconciliação e diff.
- Verificação de integridade do ZIP após empacotamento.
- Compilação Android/JUnit não executada: ambiente sem Gradle e pacote sem `gradlew`.
- Ainda não certificado: testes reais no dispositivo, simulação completa de duas temporadas e workflow de CI. Não declarar aprovação de build ou validação 100% sem esses resultados.
