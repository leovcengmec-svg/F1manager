# V476 — Layout unificado de negociações do mercado

- Padronizadas as janelas de contraproposta e renovação com o layout escuro, cabeçalho vermelho, card de informações do piloto e campos de duração, papel e salário usados na proposta.
- O card de informações do piloto usa altura mínima de 104 dp e texto multilinha para reduzir cortes.
- Mantidas as ações de aceitar, recusar, enviar contraproposta, renovar e cancelar; os campos numéricos continuam aceitando apenas dígitos.
- Validação limitada à inspeção estática e integridade do ZIP. Build Android não executado neste ambiente.
