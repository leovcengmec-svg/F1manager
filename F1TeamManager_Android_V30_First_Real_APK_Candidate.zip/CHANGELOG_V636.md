# V636 — Investimento zero também constrói um carro mais fraco

- Removido o reaproveitamento automático da força tecnológica do carro anterior quando o investimento é zero.
- A tabela investimento × Overall passa a ser universal: todos os valores entre €0 e €150M entram na mesma regra e recebem o bônus de construção de 10% uma única vez.
- A faixa abaixo de €8M foi estendida linearmente: €0 → Overall-base 0; €8M → Overall-base 40. Entre esses extremos, menos investimento resulta em base inferior; de €8M a €150M, os 61 valores aprovados continuam exatos.
- A construção física recalcula o desempenho de componentes instalados conforme a meta financeira mínima, mantendo identidade, versão instalada e confiabilidade. Peças ausentes continuam ausentes.
- Ajustadas as previsões da tela de investimento, o resumo da equipe, o caminho legado e a transição de temporada para refletirem o carro construído, inclusive com investimento zero.
- A IA agora pode inverter a tabela de 0 a 100 para encontrar investimentos de manutenção ou crescimento sem pressupor Overall mínimo 40.
- Versão do aplicativo: 0.636.0 (versionCode 636).

## Validação e limites

- A tabela aprovada (€8M–€150M) não foi alterada. A extensão abaixo de €8M é uma regra nova para preencher a faixa que antes não existia.
- A construção física tem piso prático Overall 1 para componentes instalados; portanto, uma meta matemática 0 é apresentada pela previsão como o resultado físico alcançável.
- Build Android completa e simulação end-to-end dentro do aplicativo dependem de um ambiente Gradle/Android disponível; não devem ser consideradas concluídas apenas pelos testes focados.
