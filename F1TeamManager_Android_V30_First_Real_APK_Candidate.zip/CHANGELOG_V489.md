# V489 — Paridade de P&D da IA e vistoria de patrocínios

- A simulação de P&D das equipes de IA agora aplica `ResearchEngine.adjustedCost` usando o ranking técnico da temporada, igual ao cálculo de preço disponível ao jogador.
- Faixas compartilhadas: posições 1–10 sem desconto; 11–20 com 20%; 21–30 com 40%; 31–40 com 60%.
- Vistoriado o bônus comercial dos contratos de IA: o nível da instalação é sincronizado antes de criar/renovar contratos; o multiplicador é incorporado aos componentes financeiros do contrato; `applySponsorshipSignings` credita o valor de entrada do contrato uma única vez; a liquidação de GP usa o pagamento por corrida e os bônus já calculados no contrato.
- Contratos existentes mantêm os valores definidos quando foram assinados; alterar o nível comercial afeta novos contratos/renovações, não reescreve retroativamente acordos ativos.
- Não executada compilação completa Android/Gradle neste ambiente.
