# V475 — Bônus de patrocínio por nível do Centro Comercial

- Novas ofertas de patrocínio agora aplicam bônus financeiro conforme o nível do Centro Comercial/Marketing da equipe.
- Nível 0: +40%; nível 1: +20%; níveis 2 a 10: sem bônus.
- O multiplicador incide sobre entrada, pagamento por GP, bônus por pontos, bônus de classificação e bônus de corrida, e os valores já ajustados seguem no contrato assinado, evitando pagamento duplicado.
- Adicionadas verificações de regressão para comparar os níveis 0, 1 e 2 usando ofertas determinísticas.

Validação: alteração estática e empacotamento; compilação Android e execução automatizada dos testes ainda precisam ser realizadas em ambiente Gradle/Android.
