# Auditoria V685 — duração dos contratos por nível comercial

## Regra validada
| Centro Comercial | Duração de novos contratos |
|---|---:|
| Níveis 0–2 | 3–10 GPs |
| Níveis 3–10 | 8–16 GPs |

## Cobertura
- `buildContract` resolve o nível comercial efetivo antes de calcular a duração.
- Ofertas apresentadas ao jogador e ofertas usadas pela IA passam pelo mesmo gerador.
- Contratos iniciais e renovações automáticas usam o nível vigente no momento da assinatura.
- A alteração do nível comercial não reescreve a duração de contratos ativos.
- O cálculo de valor da IA usa a duração efetiva da proposta e reconhece ambas as faixas.
- A auditoria de três temporadas valida os termos de todas as equipes a cada GP.

## Compatibilidade
Não foi alterado o formato de persistência de `SponsorContract`; saves anteriores continuam carregando os contratos assinados com os valores e durações originais. Uma mudança de nível comercial altera somente propostas futuras, não a duração de contratos já ativos.

## Verificação estática local
`tools/race_sim_test/v685_contract_duration_audit.py`: **10/10 verificações aprovadas**.

## Limitação
O ambiente de trabalho não possui Gradle nem Gradle Wrapper; a suíte JUnit e `assembleDebug` devem ser confirmados no GitHub Actions.
