# Auditoria V639 — Ciclo de contratos Team Principal

## Escopo

Contratos iniciais de um ano; janelas de ofertas na data de vencimento; até quatro propostas no total; durações de 1/2/3 anos persistidas por oferta; elegibilidade externa derivada do prestígio; apoio da diretoria e risco probabilístico de demissão; evento Home com modal reutilizado; compatibilidade dos saves antigos.

## Regras verificadas no código

- `contractEndSeason = contractStartSeason + contractYears - 1`.
- A janela de ofertas é aberta se o contrato venceu ou se houve demissão ao fim da temporada.
- Oferta da equipe atual incluída quando a diretoria não encerrou o contrato; no máximo três ofertas externas, total máximo quatro.
- Quota externa: prestígio 0–19 = 0; 20–39 = 1; 40–59 = 2; 60–100 = até 3. No caso de demissão com prestígio insuficiente, uma oferta de recuperação de equipe do fundo do grid evita deixar a carreira sem continuação.
- A duração aceita deve corresponder à oferta persistida e é validada no momento de renovar/assinar.
- A notificação de ofertas/demissão e a gravação do estado de carreira são confirmadas no mesmo SharedPreferences.Editor.
- Schema de save aumentado para 5; schema 1–4 continua sendo aceito e é migrado com duração de contrato de um ano e apoio inicial de 75. Saves antigos ainda ativos recebem o novo prazo a partir da próxima temporada ainda não processada, evitando pular a janela de renovação ao trocar para a regra estrita de vencimento.

## Testes necessários

Os testes focados V639 devem cobrir: contrato de um ano inicial; ofertas bloqueadas durante um contrato multi-anual ainda ativo; janela ao vencer; quotas externas por prestígio; no máximo quatro ofertas; durações limitadas a 1–3; risco de demissão dentro de 0–95%; ida e volta de encode/decode; migração schema 4.

## Limitação

O pacote contém o código-fonte e os testes, mas a compilação Android integral e a reprodução visual em dispositivo ainda precisam ser confirmadas no pipeline Android. Nenhuma APK compilada é declarada como produzida nesta etapa.
