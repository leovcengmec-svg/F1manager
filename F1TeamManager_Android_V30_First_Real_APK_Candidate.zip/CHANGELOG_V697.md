# v697 — recuperação física agregada no reinício etário

## Correção principal
- A recuperação de 50% das perdas físicas atribuídas ao envelhecimento passou a ser calculada sobre a soma dos três atributos físicos (velocidade, ultrapassagem e defesa).
- O total é arredondado uma única vez para o inteiro mais próximo e distribuído entre os atributos pelo método dos maiores restos, com desempate determinístico.
- A recuperação por atributo nunca supera a perda de envelhecimento registrada nem ultrapassa o pico histórico daquele atributo.
- Atributos técnicos/mentais e perdas causadas por desempenho continuam fora da recuperação.

## Validação adicionada
- Teste com três perdas ímpares de 1 ponto: o agregado de 3 pontos recupera 2, em vez de 0.
- Teste de capacidade: a recuperação respeita o pico histórico mesmo quando o total teórico de 50% é maior que a capacidade disponível.
- Teste anterior com perdas pares preservado para evitar regressão.
- Verificação local isolada do motor e dos testes direcionados: 6/6 testes passaram. A compilação Android integral permanece pendente no GitHub Actions.

## Identificação
- VersionCode: 697
- VersionName: 0.697.0
- Nome público: F1 Team Manager V30
- ZIP: F1TeamManager_Android_V30_First_Real_APK_Candidate.zip (nome preservado)
- Base: V696

## Limitações de validação
- A compilação Android completa e a suíte JUnit integral dependem do GitHub Actions; este pacote não inclui Gradle Wrapper e o ambiente local não possui Gradle/Android SDK.
